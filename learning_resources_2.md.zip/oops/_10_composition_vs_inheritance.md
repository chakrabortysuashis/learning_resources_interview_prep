# Composition vs Inheritance

## Two Ways to Reuse Code

| Approach | Relationship | Example |
|----------|--------------|---------|
| **Inheritance** | IS-A | Dog **is an** Animal |
| **Composition** | HAS-A | Car **has an** Engine |

## The Vehicle Analogy

```
INHERITANCE (IS-A):                    COMPOSITION (HAS-A):
────────────────────                   ────────────────────

"A Car IS A Vehicle"                   "A Car HAS AN Engine"

┌─────────────┐                        ┌─────────────────────┐
│   Vehicle   │                        │        Car          │
│ ─────────── │                        │ ─────────────────── │
│ + wheels    │                        │ + engine: Engine    │
│ + move()    │                        │ + wheels: Wheels    │
└──────┬──────┘                        │ + transmission: ... │
       │                               │ + stereo: Stereo    │
       │ inherits                      └─────────────────────┘
       │                                        │
       ▼                                        │ has
┌─────────────┐                        ┌────────┴────────┐
│     Car     │                        │                 │
│ ─────────── │                  ┌─────▼─────┐   ┌───────▼───────┐
│ + doors     │                  │  Engine   │   │   Stereo      │
│ + drive()   │                  │ ───────── │   │ ───────────── │
└─────────────┘                  │ + start() │   │ + play_music()│
                                 │ + stop()  │   └───────────────┘
                                 └───────────┘
```

## The Problem with Deep Inheritance

```python
# BAD: Deep inheritance hierarchy
class Animal:
    def eat(self): pass
    def sleep(self): pass

class Mammal(Animal):
    def give_birth(self): pass

class WingedMammal(Mammal):
    def fly(self): pass

class Bat(WingedMammal):
    def echolocate(self): pass

# What if we need a flying fish? A swimming bird?
# Inheritance breaks down with orthogonal behaviors
```

## Composition to the Rescue

```python
# GOOD: Composition with capabilities
class FlyingCapability:
    def fly(self):
        return "Flying through the air!"

class SwimmingCapability:
    def swim(self):
        return "Swimming in water!"

class EcholocationCapability:
    def echolocate(self):
        return "Using echolocation!"


class Animal:
    def __init__(self, name):
        self.name = name
        self.capabilities = []
    
    def add_capability(self, capability):
        self.capabilities.append(capability)
        return self
    
    def can_fly(self):
        return any(isinstance(c, FlyingCapability) for c in self.capabilities)
    
    def can_swim(self):
        return any(isinstance(c, SwimmingCapability) for c in self.capabilities)
    
    def perform_all(self):
        results = []
        for cap in self.capabilities:
            for method_name in dir(cap):
                if not method_name.startswith('_'):
                    method = getattr(cap, method_name)
                    if callable(method):
                        results.append(method())
        return results


# Now we can mix and match!
bat = Animal("Bat")
bat.add_capability(FlyingCapability())
bat.add_capability(EcholocationCapability())

flying_fish = Animal("Flying Fish")
flying_fish.add_capability(FlyingCapability())
flying_fish.add_capability(SwimmingCapability())

duck = Animal("Duck")
duck.add_capability(FlyingCapability())
duck.add_capability(SwimmingCapability())

print(f"{bat.name}: {bat.perform_all()}")
print(f"{flying_fish.name}: {flying_fish.perform_all()}")
```

## Real-World Example: Game Characters

### Using Inheritance (Problematic)

```python
# The inheritance nightmare
class Character:
    def attack(self): pass

class MeleeCharacter(Character):
    def sword_attack(self): pass

class MagicCharacter(Character):
    def cast_spell(self): pass

class FlyingCharacter(Character):
    def fly(self): pass

# What about a flying mage with a sword?
# class FlyingMagicMelee(MeleeCharacter, MagicCharacter, FlyingCharacter): ???
# This leads to multiple inheritance issues!
```

### Using Composition (Better)

```python
# Component classes (behaviors)
class HealthComponent:
    def __init__(self, max_hp):
        self.max_hp = max_hp
        self.current_hp = max_hp
    
    def take_damage(self, amount):
        self.current_hp = max(0, self.current_hp - amount)
        return f"Took {amount} damage. HP: {self.current_hp}/{self.max_hp}"
    
    def heal(self, amount):
        self.current_hp = min(self.max_hp, self.current_hp + amount)
        return f"Healed {amount}. HP: {self.current_hp}/{self.max_hp}"
    
    @property
    def is_alive(self):
        return self.current_hp > 0


class MeleeComponent:
    def __init__(self, weapon_name, damage):
        self.weapon_name = weapon_name
        self.damage = damage
    
    def melee_attack(self, target):
        if hasattr(target, 'health'):
            return target.health.take_damage(self.damage)
        return f"Attacked with {self.weapon_name} for {self.damage} damage"


class MagicComponent:
    def __init__(self, max_mana):
        self.max_mana = max_mana
        self.current_mana = max_mana
        self.spells = {}
    
    def learn_spell(self, name, damage, cost):
        self.spells[name] = {"damage": damage, "cost": cost}
    
    def cast_spell(self, spell_name, target=None):
        if spell_name not in self.spells:
            return f"Don't know spell: {spell_name}"
        
        spell = self.spells[spell_name]
        if self.current_mana < spell["cost"]:
            return "Not enough mana!"
        
        self.current_mana -= spell["cost"]
        if target and hasattr(target, 'health'):
            return target.health.take_damage(spell["damage"])
        return f"Cast {spell_name} for {spell['damage']} damage"


class FlyingComponent:
    def __init__(self, fly_speed):
        self.fly_speed = fly_speed
        self.is_flying = False
    
    def take_off(self):
        self.is_flying = True
        return "Taking off!"
    
    def land(self):
        self.is_flying = False
        return "Landing!"


class InventoryComponent:
    def __init__(self, capacity):
        self.capacity = capacity
        self.items = []
    
    def add_item(self, item):
        if len(self.items) < self.capacity:
            self.items.append(item)
            return f"Added {item}"
        return "Inventory full!"
    
    def remove_item(self, item):
        if item in self.items:
            self.items.remove(item)
            return f"Removed {item}"
        return f"Don't have {item}"


# The Character class composes these components
class Character:
    """A character composed of various components."""
    
    def __init__(self, name):
        self.name = name
        self.health = None
        self.melee = None
        self.magic = None
        self.flying = None
        self.inventory = None
    
    def with_health(self, max_hp):
        self.health = HealthComponent(max_hp)
        return self  # Enable method chaining
    
    def with_melee(self, weapon_name, damage):
        self.melee = MeleeComponent(weapon_name, damage)
        return self
    
    def with_magic(self, max_mana):
        self.magic = MagicComponent(max_mana)
        return self
    
    def with_flying(self, fly_speed):
        self.flying = FlyingComponent(fly_speed)
        return self
    
    def with_inventory(self, capacity):
        self.inventory = InventoryComponent(capacity)
        return self
    
    def __str__(self):
        parts = [f"Character: {self.name}"]
        if self.health:
            parts.append(f"  HP: {self.health.current_hp}/{self.health.max_hp}")
        if self.magic:
            parts.append(f"  Mana: {self.magic.current_mana}/{self.magic.max_mana}")
        if self.melee:
            parts.append(f"  Weapon: {self.melee.weapon_name}")
        if self.flying:
            status = "flying" if self.flying.is_flying else "grounded"
            parts.append(f"  Flight: {status}")
        return '\n'.join(parts)


# Create diverse characters easily!

# Warrior - health, melee, inventory
warrior = (Character("Conan")
    .with_health(150)
    .with_melee("Greatsword", 25)
    .with_inventory(20))

# Mage - health, magic, inventory
mage = (Character("Gandalf")
    .with_health(80)
    .with_magic(100)
    .with_inventory(10))
mage.magic.learn_spell("Fireball", 40, 20)
mage.magic.learn_spell("Ice Storm", 30, 15)

# Battle Mage - has BOTH melee and magic!
battle_mage = (Character("Elric")
    .with_health(100)
    .with_melee("Staff", 10)
    .with_magic(60)
    .with_inventory(15))
battle_mage.magic.learn_spell("Lightning", 35, 18)

# Dragon - flying melee creature
dragon = (Character("Smaug")
    .with_health(500)
    .with_melee("Claws", 50)
    .with_flying(100))

# Test combat
print(warrior)
print()
print(mage)
print()

print(mage.magic.cast_spell("Fireball", warrior))
print(warrior.melee.melee_attack(mage))
print()
print(warrior)
print(mage)
```

## Dependency Injection Pattern

Composition works well with dependency injection:

```python
from abc import ABC, abstractmethod

# Abstract interfaces
class Logger(ABC):
    @abstractmethod
    def log(self, message): pass

class Database(ABC):
    @abstractmethod
    def save(self, data): pass
    @abstractmethod
    def find(self, query): pass


# Concrete implementations
class ConsoleLogger(Logger):
    def log(self, message):
        print(f"[CONSOLE] {message}")

class FileLogger(Logger):
    def __init__(self, filename):
        self.filename = filename
    
    def log(self, message):
        with open(self.filename, 'a') as f:
            f.write(f"{message}\n")

class SQLDatabase(Database):
    def save(self, data):
        print(f"[SQL] Saving: {data}")
        return True
    
    def find(self, query):
        print(f"[SQL] Finding: {query}")
        return []

class MongoDatabase(Database):
    def save(self, data):
        print(f"[MongoDB] Saving: {data}")
        return True
    
    def find(self, query):
        print(f"[MongoDB] Finding: {query}")
        return []


# Service that COMPOSES dependencies (doesn't inherit)
class UserService:
    """Service with injected dependencies."""
    
    def __init__(self, database: Database, logger: Logger):
        self.db = database      # Composition!
        self.logger = logger    # Composition!
    
    def create_user(self, name, email):
        self.logger.log(f"Creating user: {name}")
        user = {"name": name, "email": email}
        self.db.save(user)
        self.logger.log(f"User created successfully")
        return user
    
    def find_user(self, email):
        self.logger.log(f"Searching for user: {email}")
        return self.db.find({"email": email})


# Easy to swap implementations!
# Production
prod_service = UserService(
    database=SQLDatabase(),
    logger=FileLogger("app.log")
)

# Development
dev_service = UserService(
    database=MongoDatabase(),
    logger=ConsoleLogger()
)

# Testing (with mocks)
class MockDatabase(Database):
    def __init__(self):
        self.data = []
    def save(self, data):
        self.data.append(data)
        return True
    def find(self, query):
        return self.data

class MockLogger(Logger):
    def __init__(self):
        self.logs = []
    def log(self, message):
        self.logs.append(message)

test_service = UserService(MockDatabase(), MockLogger())
```

## Strategy Pattern (Composition in Action)

```python
from abc import ABC, abstractmethod

# Strategy interface
class PricingStrategy(ABC):
    @abstractmethod
    def calculate_price(self, base_price, quantity): pass

# Concrete strategies
class RegularPricing(PricingStrategy):
    def calculate_price(self, base_price, quantity):
        return base_price * quantity

class BulkPricing(PricingStrategy):
    def __init__(self, bulk_threshold=10, discount=0.1):
        self.bulk_threshold = bulk_threshold
        self.discount = discount
    
    def calculate_price(self, base_price, quantity):
        total = base_price * quantity
        if quantity >= self.bulk_threshold:
            total *= (1 - self.discount)
        return total

class PremiumPricing(PricingStrategy):
    def __init__(self, premium_rate=1.2):
        self.premium_rate = premium_rate
    
    def calculate_price(self, base_price, quantity):
        return base_price * quantity * self.premium_rate

class SeasonalPricing(PricingStrategy):
    def __init__(self, season_discount=0.2):
        self.season_discount = season_discount
    
    def calculate_price(self, base_price, quantity):
        return base_price * quantity * (1 - self.season_discount)


# Context uses composition to hold strategy
class ShoppingCart:
    def __init__(self, pricing_strategy: PricingStrategy):
        self.items = []
        self.pricing = pricing_strategy  # Composition!
    
    def add_item(self, name, price, quantity=1):
        self.items.append({"name": name, "price": price, "quantity": quantity})
    
    def set_pricing_strategy(self, strategy: PricingStrategy):
        """Can change strategy at runtime!"""
        self.pricing = strategy
    
    def get_total(self):
        total = 0
        for item in self.items:
            total += self.pricing.calculate_price(item["price"], item["quantity"])
        return total


# Usage - strategy can change at runtime
cart = ShoppingCart(RegularPricing())
cart.add_item("Widget", 10.00, 5)
print(f"Regular: ${cart.get_total():.2f}")  # $50.00

cart.set_pricing_strategy(BulkPricing(bulk_threshold=3))
print(f"Bulk: ${cart.get_total():.2f}")  # $45.00 (10% off)

cart.set_pricing_strategy(SeasonalPricing(season_discount=0.25))
print(f"Seasonal: ${cart.get_total():.2f}")  # $37.50 (25% off)
```

## When to Use Each

### Use INHERITANCE when:
- There's a clear **IS-A** relationship
- Subclass is truly a specialized version of parent
- You want to inherit the complete interface
- Behavior changes but interface stays same

```python
# Good inheritance
class Animal:
    def eat(self): pass
    def sleep(self): pass

class Dog(Animal):  # Dog IS-A Animal
    def bark(self): pass

class Cat(Animal):  # Cat IS-A Animal
    def meow(self): pass
```

### Use COMPOSITION when:
- There's a **HAS-A** relationship
- You need to combine multiple behaviors
- You want to change behavior at runtime
- The relationship is more flexible
- You want to avoid deep hierarchies

```python
# Good composition
class Engine:
    def start(self): pass
    def stop(self): pass

class Car:  # Car HAS-A Engine
    def __init__(self, engine):
        self.engine = engine
    
    def start(self):
        self.engine.start()
```

## Composition Over Inheritance Principle

```
"Favor composition over inheritance"
                                    - Gang of Four

Why?
────
1. More flexible - can change at runtime
2. Avoids inheritance hierarchy problems
3. Better encapsulation
4. Easier to test (inject mocks)
5. More explicit relationships
```

## Key Points to Remember

| Aspect | Inheritance | Composition |
|--------|-------------|-------------|
| Relationship | IS-A | HAS-A |
| Coupling | Tight | Loose |
| Flexibility | Less flexible | More flexible |
| Runtime changes | No | Yes |
| Code reuse | Through hierarchy | Through delegation |
| Testing | Harder (tight coupling) | Easier (dependency injection) |

## Practice Exercise

Refactor this inheritance-based code to use composition:

```python
# BEFORE (inheritance)
class Robot:
    def __init__(self, name):
        self.name = name

class WalkingRobot(Robot):
    def walk(self):
        return f"{self.name} is walking"

class FlyingRobot(Robot):
    def fly(self):
        return f"{self.name} is flying"

class TalkingRobot(Robot):
    def talk(self):
        return f"{self.name} says hello"

# How do you make a walking, talking, flying robot?


# AFTER (composition)
class WalkingAbility:
    def walk(self, robot):
        return f"{robot.name} is walking"

class FlyingAbility:
    def fly(self, robot):
        return f"{robot.name} is flying"

class TalkingAbility:
    def talk(self, robot):
        return f"{robot.name} says hello"

class Robot:
    def __init__(self, name):
        self.name = name
        self._abilities = {}
    
    def add_ability(self, name, ability):
        self._abilities[name] = ability
        return self
    
    def perform(self, action):
        if action in self._abilities:
            ability = self._abilities[action]
            method = getattr(ability, action)
            return method(self)
        return f"{self.name} can't {action}"
    
    def list_abilities(self):
        return list(self._abilities.keys())


# Now we can create any combination!
super_robot = (Robot("Optimus")
    .add_ability("walk", WalkingAbility())
    .add_ability("fly", FlyingAbility())
    .add_ability("talk", TalkingAbility()))

print(super_robot.perform("walk"))  # Optimus is walking
print(super_robot.perform("fly"))   # Optimus is flying
print(super_robot.perform("talk"))  # Optimus says hello
print(super_robot.list_abilities()) # ['walk', 'fly', 'talk']

simple_robot = Robot("R2D2").add_ability("talk", TalkingAbility())
print(simple_robot.perform("walk"))  # R2D2 can't walk
print(simple_robot.perform("talk"))  # R2D2 says hello
```
