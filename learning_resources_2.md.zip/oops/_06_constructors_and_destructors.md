# Constructors and Destructors - Object Lifecycle

## What are Constructors and Destructors?

- **Constructor**: A special method called automatically when an object is created
- **Destructor**: A special method called when an object is about to be destroyed

## The Factory Analogy

Think of object creation like manufacturing a product:

```
CONSTRUCTOR (Birth)                    DESTRUCTOR (Cleanup)
────────────────────                   ────────────────────

┌─────────────────┐                   ┌─────────────────┐
│  Raw Materials  │                   │  Product EOL   │
│  (Parameters)   │                   │  (No more refs) │
└────────┬────────┘                   └────────┬────────┘
         │                                     │
         ▼                                     ▼
┌─────────────────┐                   ┌─────────────────┐
│  Assembly Line  │                   │  Disassembly    │
│  (__init__)     │                   │  (__del__)      │
│                 │                   │                 │
│ - Initialize    │                   │ - Close files   │
│ - Set defaults  │                   │ - Release memory│
│ - Validate data │                   │ - Disconnect    │
│ - Open resources│                   │ - Save state    │
└────────┬────────┘                   └────────┬────────┘
         │                                     │
         ▼                                     ▼
┌─────────────────┐                   ┌─────────────────┐
│ Ready Product   │                   │ Resources Freed │
│ (Object)        │                   │ Memory Released │
└─────────────────┘                   └─────────────────┘
```

## Object Creation Flow in Python

```python
class MyClass:
    def __new__(cls, *args, **kwargs):
        """Step 1: Create the instance (rarely overridden)."""
        print("1. __new__ called - creating instance")
        instance = super().__new__(cls)
        return instance
    
    def __init__(self, name):
        """Step 2: Initialize the instance (commonly used)."""
        print("2. __init__ called - initializing instance")
        self.name = name
    
    def __del__(self):
        """Step 3: Cleanup when destroyed (use sparingly)."""
        print(f"3. __del__ called - {self.name} being destroyed")


# Object lifecycle
obj = MyClass("Test")
# Output:
# 1. __new__ called - creating instance
# 2. __init__ called - initializing instance

del obj  # or when obj goes out of scope
# Output:
# 3. __del__ called - Test being destroyed
```

## The `__init__` Constructor

The most commonly used method for object initialization:

```python
class Person:
    """Basic constructor example."""
    
    def __init__(self, name, age, email=None):
        # Required parameters
        self.name = name
        self.age = age
        
        # Optional parameter with default
        self.email = email
        
        # Derived/computed attributes
        self.birth_year = 2024 - age
        
        # Internal state
        self._is_active = True
        
        print(f"Person created: {self.name}")
    
    def __repr__(self):
        return f"Person('{self.name}', {self.age})"


# Different ways to create objects
p1 = Person("Alice", 30)                     # Required args only
p2 = Person("Bob", 25, "bob@email.com")      # With optional arg
p3 = Person(name="Charlie", age=35)          # Keyword arguments
p4 = Person(age=28, name="Diana", email="d@email.com")  # Any order
```

## Constructor Patterns

### 1. Validation in Constructor

```python
class BankAccount:
    """Constructor with validation."""
    
    MINIMUM_BALANCE = 100
    
    def __init__(self, owner, initial_balance):
        # Validate owner
        if not owner or not isinstance(owner, str):
            raise ValueError("Owner name must be a non-empty string")
        
        # Validate balance
        if initial_balance < self.MINIMUM_BALANCE:
            raise ValueError(f"Initial balance must be at least ${self.MINIMUM_BALANCE}")
        
        self.owner = owner.strip()
        self._balance = initial_balance
        self._transactions = []
        
        # Log creation
        self._log_transaction("ACCOUNT_OPENED", initial_balance)
    
    def _log_transaction(self, trans_type, amount):
        from datetime import datetime
        self._transactions.append({
            "type": trans_type,
            "amount": amount,
            "timestamp": datetime.now()
        })


# Valid creation
account = BankAccount("Alice", 500)

# Invalid creation - raises errors
# BankAccount("", 500)        # ValueError: Owner name must be...
# BankAccount("Bob", 50)      # ValueError: Initial balance must be...
```

### 2. Default Values and Factory Pattern

```python
from datetime import datetime

class Task:
    """Constructor with smart defaults."""
    
    _id_counter = 0
    
    def __init__(self, title, description="", priority="medium", due_date=None):
        # Auto-increment ID
        Task._id_counter += 1
        self.id = Task._id_counter
        
        # Required
        self.title = title
        
        # With defaults
        self.description = description
        self.priority = priority
        self.due_date = due_date
        
        # Auto-generated
        self.created_at = datetime.now()
        self.completed = False
    
    @classmethod
    def create_urgent(cls, title, description=""):
        """Factory method for urgent tasks."""
        return cls(title, description, priority="high")
    
    @classmethod
    def create_from_dict(cls, data):
        """Factory method from dictionary."""
        return cls(
            title=data["title"],
            description=data.get("description", ""),
            priority=data.get("priority", "medium"),
            due_date=data.get("due_date")
        )


# Different creation methods
task1 = Task("Write report")
task2 = Task("Review code", "Check PR #123", "low")
task3 = Task.create_urgent("Fix production bug")
task4 = Task.create_from_dict({"title": "Meeting", "priority": "high"})

print(f"Task {task3.id}: {task3.title} (Priority: {task3.priority})")
```

### 3. Composition in Constructor

```python
class Address:
    def __init__(self, street, city, country, zip_code):
        self.street = street
        self.city = city
        self.country = country
        self.zip_code = zip_code
    
    def __str__(self):
        return f"{self.street}, {self.city}, {self.country} {self.zip_code}"


class CreditCard:
    def __init__(self, number, expiry, cvv):
        self.number = number
        self.expiry = expiry
        self._cvv = cvv
    
    @property
    def masked_number(self):
        return "*" * 12 + self.number[-4:]


class Customer:
    """Composed of other objects."""
    
    def __init__(self, name, email, address_data, card_data=None):
        self.name = name
        self.email = email
        
        # Composition: Create Address from data
        self.address = Address(**address_data)
        
        # Optional composition
        self.credit_card = CreditCard(**card_data) if card_data else None
    
    def display_info(self):
        info = f"Customer: {self.name}\nEmail: {self.email}\nAddress: {self.address}"
        if self.credit_card:
            info += f"\nCard: {self.credit_card.masked_number}"
        return info


# Usage
customer = Customer(
    name="Alice Smith",
    email="alice@email.com",
    address_data={
        "street": "123 Main St",
        "city": "New York",
        "country": "USA",
        "zip_code": "10001"
    },
    card_data={
        "number": "4532015112830366",
        "expiry": "12/25",
        "cvv": "123"
    }
)

print(customer.display_info())
```

### 4. Constructor Overloading (Python Style)

Python doesn't support traditional constructor overloading, but uses patterns:

```python
from datetime import datetime, date

class Event:
    """Multiple constructor patterns."""
    
    def __init__(self, name, start_datetime, end_datetime=None, duration_hours=None):
        self.name = name
        self.start = start_datetime
        
        # Different ways to specify end time
        if end_datetime:
            self.end = end_datetime
        elif duration_hours:
            from datetime import timedelta
            self.end = start_datetime + timedelta(hours=duration_hours)
        else:
            # Default 1-hour event
            from datetime import timedelta
            self.end = start_datetime + timedelta(hours=1)
    
    @classmethod
    def from_string(cls, name, datetime_str, format="%Y-%m-%d %H:%M"):
        """Create from string."""
        dt = datetime.strptime(datetime_str, format)
        return cls(name, dt)
    
    @classmethod
    def all_day(cls, name, event_date):
        """Create all-day event."""
        if isinstance(event_date, str):
            event_date = datetime.strptime(event_date, "%Y-%m-%d").date()
        
        start = datetime.combine(event_date, datetime.min.time())
        end = datetime.combine(event_date, datetime.max.time())
        return cls(name, start, end)
    
    @classmethod
    def from_json(cls, json_data):
        """Create from JSON/dict."""
        import json
        if isinstance(json_data, str):
            json_data = json.loads(json_data)
        
        start = datetime.fromisoformat(json_data["start"])
        end = datetime.fromisoformat(json_data["end"]) if "end" in json_data else None
        return cls(json_data["name"], start, end)
    
    def __repr__(self):
        return f"Event('{self.name}', {self.start} - {self.end})"


# Multiple "constructors"
event1 = Event("Meeting", datetime.now())
event2 = Event("Workshop", datetime.now(), duration_hours=3)
event3 = Event.from_string("Call", "2024-12-25 14:00")
event4 = Event.all_day("Holiday", "2024-12-25")
event5 = Event.from_json('{"name": "Review", "start": "2024-12-25T10:00:00"}')

for e in [event1, event2, event3, event4, event5]:
    print(e)
```

## The `__del__` Destructor

Called when an object is garbage collected:

```python
class FileHandler:
    """Example with destructor for cleanup."""
    
    def __init__(self, filename):
        self.filename = filename
        self.file = open(filename, 'w')
        print(f"Opened file: {filename}")
    
    def write(self, text):
        self.file.write(text)
    
    def __del__(self):
        """Cleanup: close file when object is destroyed."""
        if hasattr(self, 'file') and self.file:
            self.file.close()
            print(f"Closed file: {self.filename}")


# File is closed when handler goes out of scope
def process_file():
    handler = FileHandler("test.txt")
    handler.write("Hello, World!")
    # handler.__del__() called automatically when function returns


process_file()  # File closed here
```

## Why Avoid `__del__` - Use Context Managers Instead

`__del__` has issues:
- Timing is unpredictable (garbage collection)
- May not be called if program crashes
- Circular references can prevent cleanup

**Better approach: Context Managers**

```python
class DatabaseConnection:
    """Proper resource management with context manager."""
    
    def __init__(self, host, database):
        self.host = host
        self.database = database
        self.connection = None
    
    def connect(self):
        print(f"Connecting to {self.database}@{self.host}")
        self.connection = {"connected": True}
        return self
    
    def disconnect(self):
        if self.connection:
            print(f"Disconnecting from {self.database}")
            self.connection = None
    
    def execute(self, query):
        if not self.connection:
            raise RuntimeError("Not connected")
        print(f"Executing: {query}")
        return {"result": "success"}
    
    # Context manager protocol
    def __enter__(self):
        return self.connect()
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.disconnect()
        return False  # Don't suppress exceptions


# Proper usage with 'with' statement
with DatabaseConnection("localhost", "mydb") as db:
    db.execute("SELECT * FROM users")
    db.execute("UPDATE users SET active = true")
# Connection automatically closed here, even if exception occurs!


# Manual usage (must remember to cleanup)
db = DatabaseConnection("localhost", "mydb")
try:
    db.connect()
    db.execute("SELECT * FROM users")
finally:
    db.disconnect()
```

## Constructor Inheritance

```python
class Vehicle:
    """Base class with constructor."""
    
    def __init__(self, brand, model, year):
        self.brand = brand
        self.model = model
        self.year = year
        self.mileage = 0
        print(f"Vehicle created: {brand} {model}")
    
    def drive(self, distance):
        self.mileage += distance


class Car(Vehicle):
    """Child adds parameters but calls parent constructor."""
    
    def __init__(self, brand, model, year, num_doors, fuel_type="gasoline"):
        # MUST call parent constructor first
        super().__init__(brand, model, year)
        
        # Then add child-specific attributes
        self.num_doors = num_doors
        self.fuel_type = fuel_type
        print(f"Car initialized with {num_doors} doors")


class ElectricCar(Car):
    """Grandchild extends further."""
    
    def __init__(self, brand, model, year, num_doors, battery_capacity):
        # Call parent (Car) constructor
        super().__init__(brand, model, year, num_doors, fuel_type="electric")
        
        # Add electric-specific attributes
        self.battery_capacity = battery_capacity
        self.charge_level = 100
        print(f"ElectricCar with {battery_capacity}kWh battery")


# Creating objects calls constructors up the chain
tesla = ElectricCar("Tesla", "Model 3", 2024, 4, 75)
# Output:
# Vehicle created: Tesla Model 3
# Car initialized with 4 doors
# ElectricCar with 75kWh battery
```

## Singleton Pattern with `__new__`

```python
class DatabaseConfig:
    """Singleton: only one instance ever exists."""
    
    _instance = None
    
    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            print("Creating new DatabaseConfig instance")
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance
    
    def __init__(self, host="localhost", port=5432):
        # Prevent re-initialization
        if self._initialized:
            return
        
        self.host = host
        self.port = port
        self._initialized = True
        print(f"Initialized with host={host}, port={port}")


# All calls return the same instance
config1 = DatabaseConfig("server1", 3306)
config2 = DatabaseConfig("server2", 5432)  # Ignored!

print(config1 is config2)  # True
print(config1.host)        # server1 (not server2)
```

## Best Practices

### DO:
```python
class Good:
    def __init__(self, required_param, optional_param=None):
        # Validate inputs
        if not required_param:
            raise ValueError("required_param cannot be empty")
        
        # Initialize all attributes
        self.required = required_param
        self.optional = optional_param or "default"
        self._internal = []
        
        # Keep constructor simple - delegate complex logic
        self._initialize_internal_state()
    
    def _initialize_internal_state(self):
        """Complex initialization logic separated."""
        pass
```

### DON'T:
```python
class Bad:
    def __init__(self, data):
        # DON'T: Heavy processing in constructor
        import requests
        self.result = requests.get("http://api.example.com").json()
        
        # DON'T: I/O operations
        with open("data.txt", "w") as f:
            f.write(str(data))
        
        # DON'T: Non-deterministic behavior
        import random
        self.id = random.randint(1, 1000)
```

## Key Points to Remember

| Method | When Called | Purpose |
|--------|-------------|---------|
| `__new__` | Before object exists | Create instance (rarely used) |
| `__init__` | After creation | Initialize attributes |
| `__del__` | Before destruction | Cleanup (avoid - use context managers) |

## Practice Exercise

Create a `Connection` class with:
- Constructor: host, port, timeout (with defaults)
- Connection pooling using `__new__`
- Context manager support for auto-cleanup
- Factory methods: `from_url()`, `from_config()`

```python
from urllib.parse import urlparse

class Connection:
    _pool = {}
    _max_connections = 5
    
    def __new__(cls, host, port=80, timeout=30):
        key = f"{host}:{port}"
        
        # Return existing connection if available
        if key in cls._pool:
            print(f"Reusing connection to {key}")
            return cls._pool[key]
        
        # Check pool limit
        if len(cls._pool) >= cls._max_connections:
            raise RuntimeError("Connection pool exhausted")
        
        # Create new connection
        instance = super().__new__(cls)
        cls._pool[key] = instance
        return instance
    
    def __init__(self, host, port=80, timeout=30):
        if hasattr(self, '_initialized') and self._initialized:
            return
        
        self.host = host
        self.port = port
        self.timeout = timeout
        self._connected = False
        self._initialized = True
    
    def connect(self):
        print(f"Connecting to {self.host}:{self.port}...")
        self._connected = True
        return self
    
    def disconnect(self):
        print(f"Disconnecting from {self.host}:{self.port}")
        self._connected = False
    
    def __enter__(self):
        return self.connect()
    
    def __exit__(self, *args):
        self.disconnect()
        return False
    
    @classmethod
    def from_url(cls, url):
        """Create from URL string."""
        parsed = urlparse(url)
        host = parsed.hostname or "localhost"
        port = parsed.port or 80
        return cls(host, port)
    
    @classmethod
    def from_config(cls, config):
        """Create from config dict."""
        return cls(
            host=config.get("host", "localhost"),
            port=config.get("port", 80),
            timeout=config.get("timeout", 30)
        )


# Test
conn1 = Connection("localhost", 8080)
conn2 = Connection("localhost", 8080)  # Reuses conn1
print(conn1 is conn2)  # True

with Connection.from_url("http://example.com:3000") as conn:
    print(f"Connected to {conn.host}:{conn.port}")

config_conn = Connection.from_config({"host": "db.server.com", "port": 5432})
```
