# Abstraction - Hiding Complexity

## What is Abstraction?

Abstraction means **showing only essential features** while hiding the internal complexity. It's about providing a simple interface for complex operations.

## The Car Dashboard Analogy

When you drive a car:
- You see a **simple interface**: steering wheel, pedals, gauges
- You **don't see**: engine combustion, fuel injection, transmission gears
- You **don't need to know** how the engine works to drive

```
┌───────────────────────────────────────────────────────────┐
│                    WHAT YOU SEE                           │
│  ┌─────────────────────────────────────────────────────┐  │
│  │  [Speedometer]    [Fuel Gauge]    [Temperature]     │  │
│  │  press_gas()      press_brake()   turn_wheel()      │  │
│  └─────────────────────────────────────────────────────┘  │
└───────────────────────────────────────────────────────────┘

┌───────────────────────────────────────────────────────────┐
│                 WHAT'S HIDDEN (Abstracted)                │
│  ┌─────────────────────────────────────────────────────┐  │
│  │  - Fuel injection timing                            │  │
│  │  - Spark plug firing sequence                       │  │
│  │  - Transmission gear ratios                         │  │
│  │  - Brake hydraulic pressure calculation             │  │
│  │  - Anti-lock braking system logic                   │  │
│  │  - Traction control algorithms                      │  │
│  └─────────────────────────────────────────────────────┘  │
└───────────────────────────────────────────────────────────┘
```

## Abstraction vs Encapsulation

| Aspect | Abstraction | Encapsulation |
|--------|-------------|---------------|
| **Focus** | Hiding complexity | Hiding data |
| **Level** | Design level | Implementation level |
| **Goal** | Simple interface | Data protection |
| **How** | Abstract classes, interfaces | Private attributes, getters/setters |

**Analogy:**
- **Abstraction**: A TV remote has "Volume Up" button (hides how sound works)
- **Encapsulation**: The remote's internal circuit is sealed (can't touch wires)

## Abstract Classes in Python

Abstract classes define a **contract** that subclasses must follow:

```python
from abc import ABC, abstractmethod

class Database(ABC):
    """Abstract database interface - defines WHAT, not HOW."""
    
    @abstractmethod
    def connect(self):
        """Establish connection to database."""
        pass
    
    @abstractmethod
    def disconnect(self):
        """Close database connection."""
        pass
    
    @abstractmethod
    def execute_query(self, query):
        """Execute a query and return results."""
        pass
    
    # Non-abstract method - shared implementation
    def log(self, message):
        print(f"[{self.__class__.__name__}] {message}")


# Can't instantiate abstract class
# db = Database()  # TypeError!


class MySQLDatabase(Database):
    """Concrete implementation for MySQL."""
    
    def __init__(self, host, user, password):
        self.host = host
        self.user = user
        self._password = password
        self._connection = None
    
    def connect(self):
        self.log(f"Connecting to MySQL at {self.host}...")
        # Actual MySQL connection logic would go here
        self._connection = f"MySQL://{self.host}"
        self.log("Connected!")
        return True
    
    def disconnect(self):
        self.log("Disconnecting from MySQL...")
        self._connection = None
        return True
    
    def execute_query(self, query):
        if not self._connection:
            raise ConnectionError("Not connected to database")
        self.log(f"Executing: {query}")
        # Actual query execution would go here
        return {"status": "success", "rows": []}


class PostgreSQLDatabase(Database):
    """Concrete implementation for PostgreSQL."""
    
    def __init__(self, connection_string):
        self.connection_string = connection_string
        self._conn = None
    
    def connect(self):
        self.log(f"Connecting to PostgreSQL...")
        self._conn = {"connected": True}
        self.log("Connected!")
        return True
    
    def disconnect(self):
        self.log("Disconnecting from PostgreSQL...")
        self._conn = None
        return True
    
    def execute_query(self, query):
        self.log(f"Running: {query}")
        return {"status": "success", "data": []}


class SQLiteDatabase(Database):
    """Concrete implementation for SQLite (file-based)."""
    
    def __init__(self, filename):
        self.filename = filename
        self._db = None
    
    def connect(self):
        self.log(f"Opening SQLite file: {self.filename}")
        self._db = open(self.filename, 'a+')  # Simplified
        return True
    
    def disconnect(self):
        self.log("Closing SQLite file")
        if self._db:
            self._db.close()
        return True
    
    def execute_query(self, query):
        self.log(f"SQLite query: {query}")
        return {"status": "success"}


# Application code doesn't care which database!
def run_migration(db: Database):
    """Works with ANY database implementation."""
    db.connect()
    db.execute_query("CREATE TABLE users (id INT, name VARCHAR)")
    db.execute_query("INSERT INTO users VALUES (1, 'Alice')")
    db.disconnect()


# Same code, different databases
mysql = MySQLDatabase("localhost", "admin", "secret")
postgres = PostgreSQLDatabase("postgresql://localhost/mydb")
sqlite = SQLiteDatabase("test.db")

for db in [mysql, postgres, sqlite]:
    print(f"\n{'='*50}")
    run_migration(db)
```

## Real-World Example: Payment Gateway Abstraction

```python
from abc import ABC, abstractmethod
from typing import Dict, Any
import random
import string

class PaymentGateway(ABC):
    """
    Abstract payment gateway - defines the interface for all payment providers.
    
    Users of this class don't need to know HOW Stripe/PayPal/Square work internally.
    They just call process_payment() and get_status().
    """
    
    @abstractmethod
    def process_payment(self, amount: float, currency: str, card_details: Dict) -> Dict[str, Any]:
        """Process a payment transaction."""
        pass
    
    @abstractmethod
    def refund(self, transaction_id: str, amount: float) -> Dict[str, Any]:
        """Refund a transaction."""
        pass
    
    @abstractmethod
    def get_transaction_status(self, transaction_id: str) -> str:
        """Get current status of a transaction."""
        pass
    
    # Concrete helper methods (shared by all implementations)
    def _generate_transaction_id(self) -> str:
        return ''.join(random.choices(string.ascii_uppercase + string.digits, k=12))
    
    def _validate_amount(self, amount: float) -> bool:
        return amount > 0
    
    def _mask_card_number(self, card_number: str) -> str:
        return "*" * 12 + card_number[-4:]


class StripeGateway(PaymentGateway):
    """Stripe payment implementation - hides Stripe's complex API."""
    
    def __init__(self, api_key: str):
        self._api_key = api_key
        self._transactions = {}
    
    def process_payment(self, amount: float, currency: str, card_details: Dict) -> Dict[str, Any]:
        if not self._validate_amount(amount):
            return {"success": False, "error": "Invalid amount"}
        
        # All Stripe complexity hidden here
        # In reality: API calls, authentication, error handling, webhooks...
        transaction_id = "stripe_" + self._generate_transaction_id()
        
        self._transactions[transaction_id] = {
            "amount": amount,
            "currency": currency,
            "status": "completed",
            "card": self._mask_card_number(card_details.get("number", ""))
        }
        
        return {
            "success": True,
            "transaction_id": transaction_id,
            "amount": amount,
            "currency": currency
        }
    
    def refund(self, transaction_id: str, amount: float) -> Dict[str, Any]:
        if transaction_id not in self._transactions:
            return {"success": False, "error": "Transaction not found"}
        
        self._transactions[transaction_id]["status"] = "refunded"
        return {"success": True, "refund_id": "ref_" + self._generate_transaction_id()}
    
    def get_transaction_status(self, transaction_id: str) -> str:
        return self._transactions.get(transaction_id, {}).get("status", "not_found")


class PayPalGateway(PaymentGateway):
    """PayPal payment implementation - hides PayPal's REST API complexity."""
    
    def __init__(self, client_id: str, secret: str):
        self._client_id = client_id
        self._secret = secret
        self._orders = {}
    
    def process_payment(self, amount: float, currency: str, card_details: Dict) -> Dict[str, Any]:
        if not self._validate_amount(amount):
            return {"success": False, "error": "Invalid amount"}
        
        # PayPal has its own flow: create order -> capture -> confirm
        # All hidden behind this simple interface
        order_id = "paypal_" + self._generate_transaction_id()
        
        self._orders[order_id] = {
            "amount": amount,
            "currency": currency,
            "status": "COMPLETED"
        }
        
        return {
            "success": True,
            "transaction_id": order_id,
            "amount": amount,
            "currency": currency
        }
    
    def refund(self, transaction_id: str, amount: float) -> Dict[str, Any]:
        if transaction_id not in self._orders:
            return {"success": False, "error": "Order not found"}
        
        self._orders[transaction_id]["status"] = "REFUNDED"
        return {"success": True, "refund_id": "PP_REF_" + self._generate_transaction_id()}
    
    def get_transaction_status(self, transaction_id: str) -> str:
        return self._orders.get(transaction_id, {}).get("status", "NOT_FOUND")


class SquareGateway(PaymentGateway):
    """Square payment implementation."""
    
    def __init__(self, access_token: str, location_id: str):
        self._access_token = access_token
        self._location_id = location_id
        self._payments = {}
    
    def process_payment(self, amount: float, currency: str, card_details: Dict) -> Dict[str, Any]:
        if not self._validate_amount(amount):
            return {"success": False, "error": "Invalid amount"}
        
        payment_id = "sq_" + self._generate_transaction_id()
        
        self._payments[payment_id] = {
            "amount_money": {"amount": int(amount * 100), "currency": currency},
            "status": "COMPLETED"
        }
        
        return {
            "success": True,
            "transaction_id": payment_id,
            "amount": amount,
            "currency": currency
        }
    
    def refund(self, transaction_id: str, amount: float) -> Dict[str, Any]:
        if transaction_id not in self._payments:
            return {"success": False, "error": "Payment not found"}
        
        self._payments[transaction_id]["status"] = "REFUNDED"
        return {"success": True, "refund_id": "sq_ref_" + self._generate_transaction_id()}
    
    def get_transaction_status(self, transaction_id: str) -> str:
        return self._payments.get(transaction_id, {}).get("status", "NOT_FOUND")


# E-commerce checkout - works with ANY payment gateway!
class CheckoutService:
    """
    This service doesn't know or care HOW payments are processed.
    It just uses the abstract PaymentGateway interface.
    """
    
    def __init__(self, payment_gateway: PaymentGateway):
        self.gateway = payment_gateway
    
    def process_order(self, order_total: float, card_info: Dict):
        print(f"Processing order for ${order_total}...")
        
        result = self.gateway.process_payment(order_total, "USD", card_info)
        
        if result["success"]:
            print(f"Payment successful! Transaction ID: {result['transaction_id']}")
            return result["transaction_id"]
        else:
            print(f"Payment failed: {result.get('error')}")
            return None


# Usage - switch payment providers without changing CheckoutService!
stripe = StripeGateway("sk_test_xxx")
paypal = PayPalGateway("client_id", "secret")
square = SquareGateway("access_token", "location_123")

card = {"number": "4242424242424242", "exp": "12/25", "cvv": "123"}

# Same checkout code works with any gateway
for gateway in [stripe, paypal, square]:
    checkout = CheckoutService(gateway)
    checkout.process_order(99.99, card)
    print()
```

## Abstraction Through Interfaces (Protocols)

Python 3.8+ supports `Protocol` for structural subtyping (duck typing with type hints):

```python
from typing import Protocol, List

class Drawable(Protocol):
    """Anything that can be drawn."""
    
    def draw(self) -> str:
        ...

class Movable(Protocol):
    """Anything that can move."""
    
    def move(self, x: int, y: int) -> None:
        ...


class Circle:
    """Circle implements Drawable without explicitly inheriting."""
    
    def __init__(self, x: int, y: int, radius: int):
        self.x = x
        self.y = y
        self.radius = radius
    
    def draw(self) -> str:
        return f"Drawing circle at ({self.x}, {self.y}) with radius {self.radius}"
    
    def move(self, x: int, y: int) -> None:
        self.x = x
        self.y = y


class Rectangle:
    """Rectangle implements both protocols."""
    
    def __init__(self, x: int, y: int, width: int, height: int):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
    
    def draw(self) -> str:
        return f"Drawing rectangle at ({self.x}, {self.y}), {self.width}x{self.height}"
    
    def move(self, x: int, y: int) -> None:
        self.x = x
        self.y = y


class Text:
    """Text only implements Drawable."""
    
    def __init__(self, content: str, x: int, y: int):
        self.content = content
        self.x = x
        self.y = y
    
    def draw(self) -> str:
        return f"Drawing text '{self.content}' at ({self.x}, {self.y})"


# Functions work with anything matching the protocol
def render_all(drawables: List[Drawable]) -> None:
    for item in drawables:
        print(item.draw())

def move_all(movables: List[Movable], dx: int, dy: int) -> None:
    for item in movables:
        item.move(item.x + dx, item.y + dy)


# Usage
shapes = [Circle(0, 0, 5), Rectangle(10, 10, 20, 15), Text("Hello", 5, 5)]
render_all(shapes)  # All are Drawable

# Only Circle and Rectangle are Movable
movable_shapes = [Circle(0, 0, 5), Rectangle(10, 10, 20, 15)]
move_all(movable_shapes, 10, 10)
```

## Levels of Abstraction

Good code has multiple abstraction layers:

```python
# Level 4: User Interface (Highest Abstraction)
class OrderController:
    def __init__(self, order_service):
        self.order_service = order_service
    
    def handle_checkout(self, request):
        """User clicks 'Place Order' - highest level."""
        return self.order_service.place_order(
            request["items"],
            request["shipping_address"],
            request["payment_info"]
        )


# Level 3: Business Logic
class OrderService:
    def __init__(self, inventory, payment, shipping):
        self.inventory = inventory
        self.payment = payment
        self.shipping = shipping
    
    def place_order(self, items, address, payment_info):
        """Orchestrates the order process."""
        # Check inventory
        for item in items:
            if not self.inventory.check_availability(item["sku"], item["quantity"]):
                return {"error": f"Item {item['sku']} not available"}
        
        # Calculate total
        total = sum(item["price"] * item["quantity"] for item in items)
        
        # Process payment
        payment_result = self.payment.charge(total, payment_info)
        if not payment_result["success"]:
            return {"error": "Payment failed"}
        
        # Reserve inventory
        for item in items:
            self.inventory.reserve(item["sku"], item["quantity"])
        
        # Create shipping label
        label = self.shipping.create_label(items, address)
        
        return {"success": True, "tracking": label["tracking_number"]}


# Level 2: Domain Services
class InventoryService:
    def __init__(self, repository):
        self.repo = repository
    
    def check_availability(self, sku, quantity):
        """Check if item is in stock."""
        stock = self.repo.get_stock(sku)
        return stock >= quantity
    
    def reserve(self, sku, quantity):
        """Reserve items for an order."""
        self.repo.decrement_stock(sku, quantity)


class PaymentService:
    def __init__(self, gateway):
        self.gateway = gateway
    
    def charge(self, amount, payment_info):
        """Process payment."""
        return self.gateway.process_payment(amount, "USD", payment_info)


# Level 1: Data Access (Lowest Abstraction)
class InventoryRepository:
    def __init__(self, database):
        self.db = database
    
    def get_stock(self, sku):
        """Query database for stock level."""
        result = self.db.execute_query(f"SELECT quantity FROM inventory WHERE sku = '{sku}'")
        return result.get("quantity", 0)
    
    def decrement_stock(self, sku, amount):
        """Update stock in database."""
        self.db.execute_query(f"UPDATE inventory SET quantity = quantity - {amount} WHERE sku = '{sku}'")
```

## Benefits of Abstraction

```
Without Abstraction:                   With Abstraction:
────────────────────                   ────────────────────

User Code:                             User Code:
┌──────────────────────┐               ┌──────────────────────┐
│ - Know API details   │               │ - Simple interface   │
│ - Handle errors      │               │ - Just call methods  │
│ - Parse responses    │               │ - Get clean results  │
│ - Manage connections │               └──────────────────────┘
│ - Format requests    │                          │
└──────────────────────┘                          ▼
         │                             ┌──────────────────────┐
         ▼                             │  Abstraction Layer   │
┌──────────────────────┐               │  (Handles details)   │
│   Complex System     │               └──────────────────────┘
└──────────────────────┘                          │
                                                  ▼
                                       ┌──────────────────────┐
                                       │   Complex System     │
                                       └──────────────────────┘
```

## Key Points to Remember

1. **Abstract Classes** define WHAT, not HOW
2. **`@abstractmethod`** forces subclasses to implement
3. **Protocols** enable structural typing (duck typing + type hints)
4. **Good abstraction** hides complexity while providing clear interfaces
5. **Multiple layers** of abstraction create maintainable code

## Abstraction Design Principles

| Principle | Description |
|-----------|-------------|
| **Hide complexity** | Users shouldn't need internal knowledge |
| **Expose only essentials** | Minimal but complete interface |
| **Consistent interface** | Similar operations across implementations |
| **Fail clearly** | Abstract errors, don't expose internals |

## Practice Exercise

Create an abstraction for file storage:
- `FileStorage` (ABC): upload(), download(), delete(), list_files()
- `LocalStorage`: saves to local filesystem
- `S3Storage`: simulates AWS S3
- `GoogleCloudStorage`: simulates GCS

```python
from abc import ABC, abstractmethod
from typing import List, Optional
import os

class FileStorage(ABC):
    """Abstract file storage interface."""
    
    @abstractmethod
    def upload(self, file_name: str, content: bytes) -> bool:
        pass
    
    @abstractmethod
    def download(self, file_name: str) -> Optional[bytes]:
        pass
    
    @abstractmethod
    def delete(self, file_name: str) -> bool:
        pass
    
    @abstractmethod
    def list_files(self) -> List[str]:
        pass
    
    def exists(self, file_name: str) -> bool:
        return file_name in self.list_files()


class LocalStorage(FileStorage):
    def __init__(self, base_path: str):
        self.base_path = base_path
        os.makedirs(base_path, exist_ok=True)
    
    def upload(self, file_name: str, content: bytes) -> bool:
        path = os.path.join(self.base_path, file_name)
        with open(path, 'wb') as f:
            f.write(content)
        return True
    
    def download(self, file_name: str) -> Optional[bytes]:
        path = os.path.join(self.base_path, file_name)
        if os.path.exists(path):
            with open(path, 'rb') as f:
                return f.read()
        return None
    
    def delete(self, file_name: str) -> bool:
        path = os.path.join(self.base_path, file_name)
        if os.path.exists(path):
            os.remove(path)
            return True
        return False
    
    def list_files(self) -> List[str]:
        return os.listdir(self.base_path)


class S3Storage(FileStorage):
    def __init__(self, bucket: str):
        self.bucket = bucket
        self._files = {}  # Simulated S3 storage
    
    def upload(self, file_name: str, content: bytes) -> bool:
        key = f"s3://{self.bucket}/{file_name}"
        self._files[file_name] = content
        print(f"Uploaded to {key}")
        return True
    
    def download(self, file_name: str) -> Optional[bytes]:
        return self._files.get(file_name)
    
    def delete(self, file_name: str) -> bool:
        if file_name in self._files:
            del self._files[file_name]
            return True
        return False
    
    def list_files(self) -> List[str]:
        return list(self._files.keys())


# Application code works with ANY storage!
def backup_data(storage: FileStorage, data: dict):
    import json
    content = json.dumps(data).encode()
    storage.upload("backup.json", content)
    print(f"Backup created. Files: {storage.list_files()}")


# Same code, different storage backends
local = LocalStorage("./backups")
s3 = S3Storage("my-bucket")

backup_data(local, {"users": 100, "orders": 500})
backup_data(s3, {"users": 100, "orders": 500})
```
