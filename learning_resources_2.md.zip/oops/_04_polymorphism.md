# Polymorphism - One Interface, Many Forms

## What is Polymorphism?

Polymorphism (from Greek: "poly" = many, "morph" = form) allows objects of different types to be treated through a **uniform interface**. The same operation can behave differently based on the object it's acting on.

## The Remote Control Analogy

Think of a universal TV remote:
- The "Power" button works on **any TV** (Sony, Samsung, LG)
- You press the same button, but each TV responds in its own way
- You don't need to know how each TV works internally
- One interface, many implementations

```
┌─────────────────────────────────────────────────────────────┐
│                    Universal Interface                       │
│                      power_on()                              │
└─────────────────────────────────────────────────────────────┘
                              │
        ┌─────────────────────┼─────────────────────┐
        ▼                     ▼                     ▼
┌───────────────┐    ┌───────────────┐    ┌───────────────┐
│    SonyTV     │    │  SamsungTV    │    │     LG TV     │
│ ───────────── │    │ ───────────── │    │ ───────────── │
│ power_on():   │    │ power_on():   │    │ power_on():   │
│ "Sony Logo"   │    │ "Samsung      │    │ "LG ThinQ"    │
│               │    │  Animation"   │    │               │
└───────────────┘    └───────────────┘    └───────────────┘
```

## Types of Polymorphism in Python

1. **Duck Typing** (most Pythonic)
2. **Method Overriding** (inheritance-based)
3. **Operator Overloading** (special methods)
4. **Method Overloading** (default arguments/\*args)

## 1. Duck Typing - "If It Walks Like a Duck..."

Python doesn't care about the **type** of an object—it cares about what the object **can do**:

> "If it walks like a duck and quacks like a duck, it's a duck."

```python
class Dog:
    def speak(self):
        return "Woof!"

class Cat:
    def speak(self):
        return "Meow!"

class Duck:
    def speak(self):
        return "Quack!"

class Robot:
    def speak(self):
        return "Beep boop!"


def make_speak(animal):
    """Works with ANY object that has a speak() method."""
    print(animal.speak())


# No inheritance needed - just have the method!
make_speak(Dog())    # Woof!
make_speak(Cat())    # Meow!
make_speak(Duck())   # Quack!
make_speak(Robot())  # Beep boop! (not an animal, but it works!)
```

### Duck Typing with File-like Objects

```python
import io

class LogWriter:
    """Custom writer that logs everything."""
    
    def __init__(self):
        self.logs = []
    
    def write(self, text):
        if text.strip():  # Ignore empty writes
            self.logs.append(f"[LOG] {text}")
    
    def get_logs(self):
        return '\n'.join(self.logs)


def process_data(writer):
    """Works with any object that has a write() method."""
    writer.write("Processing started")
    writer.write("Data loaded: 1000 records")
    writer.write("Processing complete")


# Works with real file
with open("output.txt", "w") as f:
    process_data(f)

# Works with StringIO (in-memory file)
buffer = io.StringIO()
process_data(buffer)
print(buffer.getvalue())

# Works with our custom LogWriter
logger = LogWriter()
process_data(logger)
print(logger.get_logs())
```

## 2. Method Overriding (Inheritance-Based Polymorphism)

Child classes provide their own implementation of parent methods:

```python
from abc import ABC, abstractmethod
import math

class Shape(ABC):
    """Abstract base defining the interface."""
    
    @abstractmethod
    def area(self):
        pass
    
    @abstractmethod
    def perimeter(self):
        pass
    
    def describe(self):
        return f"{self.__class__.__name__}: Area={self.area():.2f}, Perimeter={self.perimeter():.2f}"


class Rectangle(Shape):
    def __init__(self, width, height):
        self.width = width
        self.height = height
    
    def area(self):
        return self.width * self.height
    
    def perimeter(self):
        return 2 * (self.width + self.height)


class Circle(Shape):
    def __init__(self, radius):
        self.radius = radius
    
    def area(self):
        return math.pi * self.radius ** 2
    
    def perimeter(self):
        return 2 * math.pi * self.radius


class Triangle(Shape):
    def __init__(self, a, b, c):
        self.a, self.b, self.c = a, b, c
    
    def area(self):
        # Heron's formula
        s = (self.a + self.b + self.c) / 2
        return math.sqrt(s * (s-self.a) * (s-self.b) * (s-self.c))
    
    def perimeter(self):
        return self.a + self.b + self.c


# Polymorphism in action - same interface, different behavior
shapes = [
    Rectangle(5, 3),
    Circle(4),
    Triangle(3, 4, 5)
]

def calculate_total_area(shapes):
    """Works with any iterable of Shape objects."""
    return sum(shape.area() for shape in shapes)

for shape in shapes:
    print(shape.describe())

print(f"\nTotal area: {calculate_total_area(shapes):.2f}")
```

## 3. Operator Overloading (Magic Methods)

Make your objects work with Python operators:

```python
class Vector:
    """2D Vector with operator overloading."""
    
    def __init__(self, x, y):
        self.x = x
        self.y = y
    
    # Addition: v1 + v2
    def __add__(self, other):
        return Vector(self.x + other.x, self.y + other.y)
    
    # Subtraction: v1 - v2
    def __sub__(self, other):
        return Vector(self.x - other.x, self.y - other.y)
    
    # Multiplication: v * scalar
    def __mul__(self, scalar):
        return Vector(self.x * scalar, self.y * scalar)
    
    # Right multiplication: scalar * v
    def __rmul__(self, scalar):
        return self.__mul__(scalar)
    
    # Equality: v1 == v2
    def __eq__(self, other):
        return self.x == other.x and self.y == other.y
    
    # Less than: v1 < v2 (by magnitude)
    def __lt__(self, other):
        return self.magnitude() < other.magnitude()
    
    # String representation
    def __repr__(self):
        return f"Vector({self.x}, {self.y})"
    
    # Length: len(v)
    def __len__(self):
        return 2  # Always 2D
    
    # Iteration: for coord in v
    def __iter__(self):
        return iter([self.x, self.y])
    
    # Absolute value: abs(v) returns magnitude
    def __abs__(self):
        return self.magnitude()
    
    def magnitude(self):
        return (self.x ** 2 + self.y ** 2) ** 0.5


# Using operators with our custom class
v1 = Vector(3, 4)
v2 = Vector(1, 2)

print(v1 + v2)       # Vector(4, 6)
print(v1 - v2)       # Vector(2, 2)
print(v1 * 3)        # Vector(9, 12)
print(3 * v1)        # Vector(9, 12)
print(v1 == v2)      # False
print(v1 == Vector(3, 4))  # True
print(abs(v1))       # 5.0 (magnitude)

# Can use in sorting
vectors = [Vector(5, 5), Vector(1, 1), Vector(3, 4)]
print(sorted(vectors))  # Sorted by magnitude
```

### Money Example with Operator Overloading

```python
class Money:
    """Currency-aware money class."""
    
    exchange_rates = {
        ('USD', 'EUR'): 0.85,
        ('EUR', 'USD'): 1.18,
        ('USD', 'GBP'): 0.73,
        ('GBP', 'USD'): 1.37,
    }
    
    def __init__(self, amount, currency='USD'):
        self.amount = round(amount, 2)
        self.currency = currency
    
    def convert_to(self, target_currency):
        if self.currency == target_currency:
            return Money(self.amount, target_currency)
        
        key = (self.currency, target_currency)
        if key not in self.exchange_rates:
            raise ValueError(f"No exchange rate for {key}")
        
        rate = self.exchange_rates[key]
        return Money(self.amount * rate, target_currency)
    
    def __add__(self, other):
        if isinstance(other, Money):
            if self.currency != other.currency:
                other = other.convert_to(self.currency)
            return Money(self.amount + other.amount, self.currency)
        return Money(self.amount + other, self.currency)
    
    def __sub__(self, other):
        if isinstance(other, Money):
            if self.currency != other.currency:
                other = other.convert_to(self.currency)
            return Money(self.amount - other.amount, self.currency)
        return Money(self.amount - other, self.currency)
    
    def __mul__(self, factor):
        return Money(self.amount * factor, self.currency)
    
    def __truediv__(self, divisor):
        return Money(self.amount / divisor, self.currency)
    
    def __lt__(self, other):
        if self.currency != other.currency:
            other = other.convert_to(self.currency)
        return self.amount < other.amount
    
    def __eq__(self, other):
        if self.currency != other.currency:
            other = other.convert_to(self.currency)
        return abs(self.amount - other.amount) < 0.01
    
    def __repr__(self):
        return f"{self.currency} {self.amount:,.2f}"


# Usage
salary = Money(5000, 'USD')
bonus = Money(500, 'USD')
tax = Money(1200, 'USD')

print(f"Salary: {salary}")
print(f"After bonus: {salary + bonus}")
print(f"After tax: {salary + bonus - tax}")
print(f"In EUR: {salary.convert_to('EUR')}")

# Can compare money in different currencies
usd = Money(100, 'USD')
eur = Money(85, 'EUR')
print(f"${usd} == €{eur.amount}? {usd == eur}")  # True (approximately)
```

## 4. Function Overloading (Python Style)

Python doesn't have traditional function overloading, but achieves it through:

### Default Arguments

```python
class Greeter:
    def greet(self, name=None, formal=False):
        if name is None:
            return "Hello there!"
        elif formal:
            return f"Good day, {name}. How may I assist you?"
        else:
            return f"Hey {name}!"


g = Greeter()
print(g.greet())                    # Hello there!
print(g.greet("Alice"))             # Hey Alice!
print(g.greet("Mr. Smith", True))   # Good day, Mr. Smith...
```

### *args and **kwargs

```python
class Calculator:
    """Calculator with flexible method signatures."""
    
    def add(self, *numbers):
        """Add any number of arguments."""
        return sum(numbers)
    
    def multiply(self, *numbers):
        """Multiply any number of arguments."""
        result = 1
        for n in numbers:
            result *= n
        return result
    
    def calculate(self, operation, *args, **kwargs):
        """Flexible calculator with keyword options."""
        operations = {
            'add': lambda x: sum(x),
            'sub': lambda x: x[0] - sum(x[1:]) if x else 0,
            'mul': lambda x: self.multiply(*x),
            'avg': lambda x: sum(x) / len(x) if x else 0,
        }
        
        if operation not in operations:
            raise ValueError(f"Unknown operation: {operation}")
        
        result = operations[operation](args)
        
        if kwargs.get('round_to'):
            result = round(result, kwargs['round_to'])
        
        return result


calc = Calculator()

print(calc.add(1, 2))           # 3
print(calc.add(1, 2, 3, 4, 5))  # 15
print(calc.multiply(2, 3, 4))   # 24

print(calc.calculate('add', 1, 2, 3))            # 6
print(calc.calculate('avg', 1, 2, 3, 4, 5))      # 3.0
print(calc.calculate('avg', 10, 7, round_to=2))  # 8.5
```

### Using `singledispatch` for True Overloading

```python
from functools import singledispatch

@singledispatch
def process(data):
    """Default handler."""
    return f"Unknown type: {type(data)}"

@process.register(str)
def _(data):
    return f"Processing string: '{data}' (length: {len(data)})"

@process.register(int)
def _(data):
    return f"Processing integer: {data} (doubled: {data * 2})"

@process.register(list)
def _(data):
    return f"Processing list with {len(data)} items"

@process.register(dict)
def _(data):
    return f"Processing dict with keys: {list(data.keys())}"


# Different types, same function name
print(process("Hello"))         # Processing string: 'Hello' (length: 5)
print(process(42))              # Processing integer: 42 (doubled: 84)
print(process([1, 2, 3]))       # Processing list with 3 items
print(process({"a": 1}))        # Processing dict with keys: ['a']
```

## Real-World Example: Payment Processing

```python
from abc import ABC, abstractmethod
from datetime import datetime

class PaymentMethod(ABC):
    """Abstract base for payment methods."""
    
    @abstractmethod
    def process_payment(self, amount):
        pass
    
    @abstractmethod
    def refund(self, amount):
        pass
    
    def generate_receipt(self, amount, transaction_id):
        return {
            "method": self.__class__.__name__,
            "amount": amount,
            "transaction_id": transaction_id,
            "timestamp": datetime.now().isoformat()
        }


class CreditCard(PaymentMethod):
    def __init__(self, card_number, expiry, cvv):
        self.card_number = card_number
        self.expiry = expiry
        self.__cvv = cvv
    
    def process_payment(self, amount):
        # Simulate credit card processing
        print(f"Charging ${amount} to card ending in {self.card_number[-4:]}")
        return {"status": "success", "auth_code": "CC" + str(hash(self.card_number))[:8]}
    
    def refund(self, amount):
        print(f"Refunding ${amount} to card ending in {self.card_number[-4:]}")
        return {"status": "refunded"}


class PayPal(PaymentMethod):
    def __init__(self, email):
        self.email = email
    
    def process_payment(self, amount):
        # Simulate PayPal processing
        print(f"Processing ${amount} via PayPal ({self.email})")
        return {"status": "success", "transaction_id": "PP" + str(hash(self.email))[:8]}
    
    def refund(self, amount):
        print(f"PayPal refund of ${amount} to {self.email}")
        return {"status": "refunded"}


class BankTransfer(PaymentMethod):
    def __init__(self, account_number, routing_number):
        self.account_number = account_number
        self.routing_number = routing_number
    
    def process_payment(self, amount):
        # Simulate bank transfer (slower)
        print(f"Initiating bank transfer of ${amount}")
        print("Note: Transfer may take 2-3 business days")
        return {"status": "pending", "eta": "2-3 days"}
    
    def refund(self, amount):
        print(f"Bank refund of ${amount} initiated")
        return {"status": "pending", "eta": "5-7 days"}


class Crypto(PaymentMethod):
    def __init__(self, wallet_address, currency="BTC"):
        self.wallet_address = wallet_address
        self.currency = currency
    
    def process_payment(self, amount):
        crypto_amount = amount / 45000  # Simplified BTC conversion
        print(f"Requesting {crypto_amount:.8f} {self.currency}")
        return {"status": "awaiting_confirmation", "crypto_amount": crypto_amount}
    
    def refund(self, amount):
        print(f"Crypto refund to {self.wallet_address[:10]}...")
        return {"status": "processing"}


# Payment processor that works with any payment method
class PaymentProcessor:
    def checkout(self, payment_method: PaymentMethod, amount: float):
        """Process checkout with any payment method - polymorphism!"""
        print(f"\n{'='*40}")
        print(f"Processing ${amount} payment...")
        
        result = payment_method.process_payment(amount)
        
        if result.get("status") in ["success", "pending", "awaiting_confirmation"]:
            receipt = payment_method.generate_receipt(amount, result.get("transaction_id", "N/A"))
            print(f"Receipt generated: {receipt}")
            return receipt
        
        print("Payment failed!")
        return None


# Usage - same interface, different implementations
processor = PaymentProcessor()

# Different payment methods, same checkout process
cc = CreditCard("4532015112830366", "12/25", "123")
paypal = PayPal("user@email.com")
bank = BankTransfer("123456789", "021000021")
crypto = Crypto("1BvBMSEYstWetqTFn5Au4m4GFg7xJaNVN2")

for payment_method in [cc, paypal, bank, crypto]:
    processor.checkout(payment_method, 99.99)
```

## Key Points to Remember

| Concept | Description | Example |
|---------|-------------|---------|
| Duck Typing | If it has the method, use it | Any object with `speak()` |
| Method Overriding | Child changes parent behavior | `Dog.speak()` vs `Animal.speak()` |
| Operator Overloading | Custom behavior for operators | `__add__`, `__eq__`, etc. |
| Interface Polymorphism | Same method name across classes | `shape.area()` |

## Benefits of Polymorphism

1. **Flexibility**: Add new types without changing existing code
2. **Extensibility**: New classes just implement the interface
3. **Clean Code**: Single function handles multiple types
4. **Loose Coupling**: Code depends on interface, not implementation

## Practice Exercise

Create a notification system with polymorphism:
- `NotificationChannel` (ABC): send(), format_message()
- `EmailNotification`: sends via email
- `SMSNotification`: sends via SMS (character limit)
- `PushNotification`: sends to mobile app
- `SlackNotification`: sends to Slack channel

```python
from abc import ABC, abstractmethod
from datetime import datetime

class NotificationChannel(ABC):
    @abstractmethod
    def send(self, recipient, message):
        pass
    
    @abstractmethod
    def format_message(self, message):
        pass
    
    def log_notification(self, recipient, message):
        return f"[{datetime.now():%Y-%m-%d %H:%M}] Sent to {recipient}"


class EmailNotification(NotificationChannel):
    def __init__(self, subject="Notification"):
        self.subject = subject
    
    def format_message(self, message):
        return f"Subject: {self.subject}\n\n{message}\n\n--\nSent via Email"
    
    def send(self, recipient, message):
        formatted = self.format_message(message)
        print(f"Sending email to {recipient}")
        print(formatted)
        return True


class SMSNotification(NotificationChannel):
    MAX_LENGTH = 160
    
    def format_message(self, message):
        if len(message) > self.MAX_LENGTH:
            return message[:self.MAX_LENGTH-3] + "..."
        return message
    
    def send(self, recipient, message):
        formatted = self.format_message(message)
        print(f"Sending SMS to {recipient}: {formatted}")
        return True


class PushNotification(NotificationChannel):
    def __init__(self, app_name="MyApp"):
        self.app_name = app_name
    
    def format_message(self, message):
        return {"title": self.app_name, "body": message[:100]}
    
    def send(self, recipient, message):
        payload = self.format_message(message)
        print(f"Push to device {recipient}: {payload}")
        return True


class SlackNotification(NotificationChannel):
    def __init__(self, channel="#general"):
        self.channel = channel
    
    def format_message(self, message):
        return f":bell: {message}"
    
    def send(self, recipient, message):
        formatted = self.format_message(message)
        print(f"Slack message to {self.channel}: {formatted}")
        return True


# Notification service using polymorphism
class NotificationService:
    def notify(self, channel: NotificationChannel, recipient: str, message: str):
        """Send notification via any channel - polymorphism!"""
        success = channel.send(recipient, message)
        if success:
            print(channel.log_notification(recipient, message))


# Test
service = NotificationService()
message = "Your order #12345 has been shipped!"

channels = [
    (EmailNotification("Order Update"), "user@email.com"),
    (SMSNotification(), "+1234567890"),
    (PushNotification("ShopApp"), "device_token_123"),
    (SlackNotification("#orders"), "@user"),
]

for channel, recipient in channels:
    service.notify(channel, recipient, message)
    print()
```
