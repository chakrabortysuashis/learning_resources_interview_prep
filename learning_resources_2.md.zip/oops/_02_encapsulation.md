# Encapsulation - Protecting Your Data

## What is Encapsulation?

Encapsulation is the bundling of data (attributes) and the methods that operate on that data into a single unit (class), while **restricting direct access** to some of the object's components.

## The Capsule Analogy

Think of a medicine capsule:
- The **outer shell** protects the medicine inside
- You can't directly touch the medicine
- You interact with it through a controlled interface (swallowing it)
- The capsule ensures the medicine is delivered correctly

```
┌─────────────────────────────────────┐
│         Public Interface            │  ← What the outside world sees
│  ┌───────────────────────────────┐  │
│  │        Protected Zone         │  │  ← Limited access
│  │  ┌─────────────────────────┐  │  │
│  │  │    Private Core         │  │  │  ← Hidden from outside
│  │  │   (sensitive data)      │  │  │
│  │  └─────────────────────────┘  │  │
│  └───────────────────────────────┘  │
└─────────────────────────────────────┘
```

## Why Encapsulation?

1. **Data Protection**: Prevent accidental modification of critical data
2. **Controlled Access**: Provide getter/setter methods with validation
3. **Hide Complexity**: Internal implementation details are hidden
4. **Flexibility**: Change internal implementation without affecting external code
5. **Maintainability**: Easier to debug and modify

## Access Modifiers in Python

Python uses naming conventions (not keywords) to indicate access levels:

| Convention | Access Level | Description |
|------------|--------------|-------------|
| `name` | Public | Accessible from anywhere |
| `_name` | Protected | "Internal use" (convention only) |
| `__name` | Private | Name mangling applied |

### Understanding Each Level

```python
class AccessDemo:
    def __init__(self):
        self.public = "I'm public"           # Anyone can access
        self._protected = "I'm protected"    # Internal use suggested
        self.__private = "I'm private"       # Name mangling applied
    
    def get_private(self):
        """Public method to access private attribute."""
        return self.__private


demo = AccessDemo()

# Public - direct access works
print(demo.public)          # Output: I'm public

# Protected - access works but signals "be careful"
print(demo._protected)      # Output: I'm protected (but you shouldn't!)

# Private - direct access fails!
# print(demo.__private)     # AttributeError!

# Private - must use public method
print(demo.get_private())   # Output: I'm private

# Python's name mangling: __name becomes _ClassName__name
print(demo._AccessDemo__private)  # Works but DON'T do this!
```

## Real-World Example: Bank Account

Without encapsulation (BAD):

```python
class BadBankAccount:
    def __init__(self, owner, balance):
        self.owner = owner
        self.balance = balance  # Public - anyone can modify!


# The problem:
account = BadBankAccount("Alice", 1000)
account.balance = -500  # Oops! Invalid negative balance allowed
account.balance = 999999999  # Fraud! No validation
```

With encapsulation (GOOD):

```python
class BankAccount:
    """A secure bank account with encapsulation."""
    
    def __init__(self, owner, initial_balance=0):
        self._owner = owner                # Protected
        self.__balance = initial_balance   # Private
        self.__transaction_history = []    # Private
        self.__pin = None                  # Private
    
    # GETTER - controlled read access
    def get_balance(self):
        """Returns the current balance."""
        return self.__balance
    
    # No direct setter for balance - must use deposit/withdraw
    
    def deposit(self, amount):
        """Deposit money with validation."""
        if amount <= 0:
            raise ValueError("Deposit amount must be positive")
        
        self.__balance += amount
        self.__log_transaction("DEPOSIT", amount)
        return f"Deposited ${amount}. New balance: ${self.__balance}"
    
    def withdraw(self, amount, pin):
        """Withdraw money with validation and authentication."""
        if not self.__verify_pin(pin):
            raise PermissionError("Invalid PIN")
        
        if amount <= 0:
            raise ValueError("Withdrawal amount must be positive")
        
        if amount > self.__balance:
            raise ValueError("Insufficient funds")
        
        self.__balance -= amount
        self.__log_transaction("WITHDRAWAL", amount)
        return f"Withdrew ${amount}. Remaining: ${self.__balance}"
    
    def set_pin(self, new_pin):
        """Set a new PIN with validation."""
        if not isinstance(new_pin, str) or len(new_pin) != 4 or not new_pin.isdigit():
            raise ValueError("PIN must be a 4-digit string")
        self.__pin = new_pin
        return "PIN set successfully"
    
    def __verify_pin(self, pin):
        """Private method to verify PIN."""
        return pin == self.__pin
    
    def __log_transaction(self, trans_type, amount):
        """Private method to log transactions."""
        from datetime import datetime
        self.__transaction_history.append({
            "type": trans_type,
            "amount": amount,
            "timestamp": datetime.now().isoformat(),
            "balance_after": self.__balance
        })
    
    def get_statement(self):
        """Public method to view transaction history."""
        return self.__transaction_history.copy()  # Return a copy for safety


# Usage
account = BankAccount("Alice", 1000)
account.set_pin("1234")

# Can't directly modify balance
# account.__balance = 999999  # AttributeError!

# Must use controlled methods
print(account.deposit(500))
print(account.withdraw(200, "1234"))
print(f"Current balance: ${account.get_balance()}")

# account.withdraw(200, "0000")  # PermissionError: Invalid PIN
# account.withdraw(-100, "1234")  # ValueError: Withdrawal amount must be positive
```

## Property Decorators - Pythonic Encapsulation

Python provides `@property` decorator for elegant encapsulation:

```python
class Temperature:
    """Temperature class with property-based encapsulation."""
    
    def __init__(self, celsius=0):
        self._celsius = celsius
    
    @property
    def celsius(self):
        """Getter for celsius."""
        return self._celsius
    
    @celsius.setter
    def celsius(self, value):
        """Setter with validation."""
        if value < -273.15:
            raise ValueError("Temperature below absolute zero is not possible")
        self._celsius = value
    
    @property
    def fahrenheit(self):
        """Computed property - no direct setter."""
        return (self._celsius * 9/5) + 32
    
    @fahrenheit.setter
    def fahrenheit(self, value):
        """Set temperature in Fahrenheit, converts to Celsius."""
        celsius_value = (value - 32) * 5/9
        if celsius_value < -273.15:
            raise ValueError("Temperature below absolute zero is not possible")
        self._celsius = celsius_value
    
    @property
    def kelvin(self):
        """Read-only property."""
        return self._celsius + 273.15


# Usage - looks like regular attribute access!
temp = Temperature(25)

print(temp.celsius)     # 25 (using getter)
print(temp.fahrenheit)  # 77.0 (computed property)
print(temp.kelvin)      # 298.15

temp.celsius = 100      # Using setter with validation
print(temp.fahrenheit)  # 212.0

temp.fahrenheit = 32    # Set via Fahrenheit
print(temp.celsius)     # 0.0

# temp.celsius = -300   # ValueError: Temperature below absolute zero
# temp.kelvin = 100     # AttributeError: can't set attribute (read-only)
```

## Another Example: User Profile

```python
class UserProfile:
    """User profile with encapsulated sensitive data."""
    
    def __init__(self, username, email, password):
        self.username = username          # Public
        self._email = email               # Protected
        self.__password = self.__hash_password(password)  # Private
        self.__failed_attempts = 0        # Private
        self.__is_locked = False          # Private
    
    @property
    def email(self):
        """Get email (partially hidden for privacy)."""
        parts = self._email.split('@')
        hidden = parts[0][0] + '***' + parts[0][-1]
        return f"{hidden}@{parts[1]}"
    
    @email.setter
    def email(self, new_email):
        """Set email with validation."""
        if '@' not in new_email or '.' not in new_email:
            raise ValueError("Invalid email format")
        self._email = new_email
    
    def __hash_password(self, password):
        """Private method to hash password."""
        import hashlib
        return hashlib.sha256(password.encode()).hexdigest()
    
    def verify_password(self, password):
        """Public method to verify password."""
        if self.__is_locked:
            return False, "Account is locked. Contact support."
        
        if self.__hash_password(password) == self.__password:
            self.__failed_attempts = 0
            return True, "Login successful"
        else:
            self.__failed_attempts += 1
            if self.__failed_attempts >= 3:
                self.__is_locked = True
                return False, "Account locked after 3 failed attempts"
            return False, f"Invalid password. {3 - self.__failed_attempts} attempts remaining"
    
    def change_password(self, old_password, new_password):
        """Change password with old password verification."""
        success, message = self.verify_password(old_password)
        if not success:
            return message
        
        if len(new_password) < 8:
            return "Password must be at least 8 characters"
        
        self.__password = self.__hash_password(new_password)
        return "Password changed successfully"


# Usage
user = UserProfile("john_doe", "john.smith@email.com", "mypassword123")

print(user.username)     # john_doe (public)
print(user.email)        # j***h@email.com (protected via property)

# Can't access password directly
# print(user.__password)  # AttributeError!

# Must use public interface
print(user.verify_password("wrongpassword"))
print(user.verify_password("wrongpassword"))
print(user.verify_password("wrongpassword"))  # Account locked!
```

## Encapsulation with Data Validation

```python
class Product:
    """E-commerce product with validated attributes."""
    
    def __init__(self, name, price, quantity):
        self._name = None
        self._price = None
        self._quantity = None
        
        # Use setters for validation
        self.name = name
        self.price = price
        self.quantity = quantity
    
    @property
    def name(self):
        return self._name
    
    @name.setter
    def name(self, value):
        if not value or not isinstance(value, str):
            raise ValueError("Name must be a non-empty string")
        if len(value) > 100:
            raise ValueError("Name must be less than 100 characters")
        self._name = value.strip()
    
    @property
    def price(self):
        return self._price
    
    @price.setter
    def price(self, value):
        if not isinstance(value, (int, float)):
            raise TypeError("Price must be a number")
        if value < 0:
            raise ValueError("Price cannot be negative")
        self._price = round(float(value), 2)
    
    @property
    def quantity(self):
        return self._quantity
    
    @quantity.setter
    def quantity(self, value):
        if not isinstance(value, int):
            raise TypeError("Quantity must be an integer")
        if value < 0:
            raise ValueError("Quantity cannot be negative")
        self._quantity = value
    
    @property
    def total_value(self):
        """Computed property - inventory value."""
        return self._price * self._quantity
    
    @property
    def in_stock(self):
        """Computed property - availability."""
        return self._quantity > 0


# Usage
product = Product("Laptop", 999.99, 50)
print(f"{product.name}: ${product.price} x {product.quantity} = ${product.total_value}")
print(f"In stock: {product.in_stock}")

# Validation works
product.price = 899.99  # OK
# product.price = -100    # ValueError: Price cannot be negative
# product.quantity = 10.5 # TypeError: Quantity must be an integer
```

## Key Points to Remember

1. **Public (`name`)**: Use for attributes that are safe to access/modify freely
2. **Protected (`_name`)**: Use for internal attributes that subclasses might need
3. **Private (`__name`)**: Use for sensitive data that should never be directly accessed
4. **Properties**: Pythonic way to add getters/setters without changing the interface
5. **Validation**: Always validate data in setters before storing

## Encapsulation Benefits Summary

```
Without Encapsulation:               With Encapsulation:
┌─────────────────────┐              ┌─────────────────────┐
│  Direct Access      │              │  Controlled Access  │
│  ────────────────   │              │  ────────────────   │
│  obj.data = value   │              │  obj.data = value   │
│  - No validation    │              │  └→ setter()        │
│  - No logging       │              │      - validation   │
│  - No protection    │              │      - logging      │
│  - No conversion    │              │      - conversion   │
└─────────────────────┘              └─────────────────────┘
```

## Practice Exercise

Create a `CreditCard` class with:
- Private: card_number, cvv, expiry_date
- Methods: get_masked_number(), validate_cvv(cvv), is_expired()
- Properties: masked_number (shows only last 4 digits)

```python
from datetime import datetime

class CreditCard:
    def __init__(self, card_number, cvv, expiry_date):
        self.__card_number = self.__validate_card_number(card_number)
        self.__cvv = self.__validate_cvv(cvv)
        self.__expiry_date = expiry_date  # Format: MM/YY
    
    def __validate_card_number(self, number):
        number = number.replace(" ", "").replace("-", "")
        if not number.isdigit() or len(number) != 16:
            raise ValueError("Invalid card number")
        return number
    
    def __validate_cvv(self, cvv):
        if not cvv.isdigit() or len(cvv) not in [3, 4]:
            raise ValueError("Invalid CVV")
        return cvv
    
    @property
    def masked_number(self):
        """Returns card number with only last 4 digits visible."""
        return "**** **** **** " + self.__card_number[-4:]
    
    def verify_cvv(self, cvv):
        """Verify if provided CVV matches."""
        return cvv == self.__cvv
    
    def is_expired(self):
        """Check if card is expired."""
        month, year = self.__expiry_date.split('/')
        expiry = datetime(2000 + int(year), int(month), 1)
        return datetime.now() > expiry


# Test it!
card = CreditCard("1234 5678 9012 3456", "123", "12/25")
print(card.masked_number)    # **** **** **** 3456
print(card.verify_cvv("123"))  # True
print(card.is_expired())      # Depends on current date
```
