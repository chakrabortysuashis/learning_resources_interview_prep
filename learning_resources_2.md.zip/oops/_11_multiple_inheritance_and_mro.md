# Multiple Inheritance and Method Resolution Order (MRO)

## What is Multiple Inheritance?

Multiple inheritance allows a class to inherit from **more than one parent class**, combining their features.

```
Single Inheritance:              Multiple Inheritance:

    Parent                        Parent1    Parent2
       │                             │          │
       │                             └────┬─────┘
       ▼                                  ▼
    Child                              Child
```

## The Swiss Army Knife Analogy

Think of a Swiss Army Knife:
- It's a Knife (can cut)
- It's a Screwdriver (can screw)
- It's a Bottle Opener (can open bottles)
- It inherits capabilities from ALL of these

```
┌─────────────┐    ┌─────────────┐    ┌─────────────┐
│    Knife    │    │ Screwdriver │    │ BottleOpener│
│ ─────────── │    │ ─────────── │    │ ─────────── │
│ + cut()     │    │ + screw()   │    │ + open()    │
└──────┬──────┘    └──────┬──────┘    └──────┬──────┘
       │                  │                  │
       └─────────────────┬┴─────────────────┘
                         │
                ┌────────▼────────┐
                │ SwissArmyKnife  │
                │ ─────────────── │
                │ + cut()         │  (inherited)
                │ + screw()       │  (inherited)
                │ + open()        │  (inherited)
                └─────────────────┘
```

## Basic Multiple Inheritance

```python
class Flyer:
    def fly(self):
        return "Flying through the air!"
    
    def take_off(self):
        return "Taking off..."

class Swimmer:
    def swim(self):
        return "Swimming in water!"
    
    def dive(self):
        return "Diving deep..."

class Runner:
    def run(self):
        return "Running fast!"
    
    def sprint(self):
        return "Sprinting!"


# Duck inherits from all three
class Duck(Flyer, Swimmer, Runner):
    def quack(self):
        return "Quack!"


donald = Duck()
print(donald.fly())    # From Flyer
print(donald.swim())   # From Swimmer
print(donald.run())    # From Runner
print(donald.quack())  # Own method

# Check inheritance
print(isinstance(donald, Flyer))    # True
print(isinstance(donald, Swimmer))  # True
print(isinstance(donald, Runner))   # True
```

## The Diamond Problem

The most famous issue with multiple inheritance:

```
           ┌───────────┐
           │     A     │
           │ method()  │
           └─────┬─────┘
                 │
        ┌────────┴────────┐
        │                 │
   ┌────▼────┐      ┌─────▼────┐
   │    B    │      │    C     │
   │ method()│      │ method() │
   └────┬────┘      └────┬─────┘
        │                │
        └────────┬───────┘
                 │
           ┌─────▼─────┐
           │     D     │
           │ method()? │  ← Which one?
           └───────────┘
```

```python
class A:
    def method(self):
        return "A's method"

class B(A):
    def method(self):
        return "B's method"

class C(A):
    def method(self):
        return "C's method"

class D(B, C):
    pass


d = D()
print(d.method())  # Which one is called?

# Python uses MRO to decide
print(D.__mro__)
# (<class 'D'>, <class 'B'>, <class 'C'>, <class 'A'>, <class 'object'>)
```

## Method Resolution Order (MRO)

Python uses the **C3 Linearization** algorithm to determine the order in which parent classes are searched.

### Rules of C3 Linearization:
1. Children before parents
2. Parents in the order they were listed
3. Respect all constraints (consistent ordering)

```python
class A:
    def greet(self):
        return "Hello from A"

class B(A):
    def greet(self):
        return "Hello from B"

class C(A):
    def greet(self):
        return "Hello from C"

class D(B, C):
    pass

class E(C, B):
    pass


# MRO determines method lookup order
print("D's MRO:", [cls.__name__ for cls in D.__mro__])
# ['D', 'B', 'C', 'A', 'object']

print("E's MRO:", [cls.__name__ for cls in E.__mro__])
# ['E', 'C', 'B', 'A', 'object']

print(D().greet())  # "Hello from B" (B comes before C in D's MRO)
print(E().greet())  # "Hello from C" (C comes before B in E's MRO)
```

## The `super()` Function in Multiple Inheritance

`super()` follows the MRO, not just the immediate parent:

```python
class A:
    def __init__(self):
        print("A.__init__")
        super().__init__()

class B(A):
    def __init__(self):
        print("B.__init__")
        super().__init__()

class C(A):
    def __init__(self):
        print("C.__init__")
        super().__init__()

class D(B, C):
    def __init__(self):
        print("D.__init__")
        super().__init__()


print("Creating D:")
d = D()
# Output:
# D.__init__
# B.__init__
# C.__init__
# A.__init__

print("\nMRO:", [cls.__name__ for cls in D.__mro__])
# MRO: ['D', 'B', 'C', 'A', 'object']
```

### How `super()` Travels the MRO

```
MRO: D → B → C → A → object

D.__init__()
    │
    ├── print("D.__init__")
    │
    └── super().__init__()  →  B.__init__()  (next in MRO)
                                    │
                                    ├── print("B.__init__")
                                    │
                                    └── super().__init__()  →  C.__init__()
                                                                    │
                                                                    ├── print("C.__init__")
                                                                    │
                                                                    └── super().__init__()  →  A.__init__()
                                                                                                    │
                                                                                                    └── print("A.__init__")
```

## Cooperative Multiple Inheritance

For multiple inheritance to work correctly, all classes must cooperate:

```python
class Base:
    def __init__(self, **kwargs):
        # End of the line - consume remaining kwargs
        pass

class Named(Base):
    def __init__(self, name, **kwargs):
        print(f"Named.__init__(name={name})")
        self.name = name
        super().__init__(**kwargs)  # Pass remaining kwargs up

class Aged(Base):
    def __init__(self, age, **kwargs):
        print(f"Aged.__init__(age={age})")
        self.age = age
        super().__init__(**kwargs)

class Colored(Base):
    def __init__(self, color, **kwargs):
        print(f"Colored.__init__(color={color})")
        self.color = color
        super().__init__(**kwargs)


# Combine any subset of features
class Person(Named, Aged):
    def __init__(self, name, age, **kwargs):
        super().__init__(name=name, age=age, **kwargs)

class Pet(Named, Aged, Colored):
    def __init__(self, name, age, color, **kwargs):
        super().__init__(name=name, age=age, color=color, **kwargs)


print("Creating Person:")
p = Person(name="Alice", age=30)
print(f"Person: {p.name}, {p.age}")

print("\nCreating Pet:")
pet = Pet(name="Buddy", age=5, color="brown")
print(f"Pet: {pet.name}, {pet.age}, {pet.color}")

print("\nPet MRO:", [c.__name__ for c in Pet.__mro__])
```

## Mixins - A Pattern for Multiple Inheritance

Mixins are classes designed to be combined with others, not instantiated alone:

```python
import json
from datetime import datetime

class JsonMixin:
    """Mixin that adds JSON serialization capability."""
    
    def to_json(self):
        return json.dumps(self.__dict__, default=str)
    
    @classmethod
    def from_json(cls, json_str):
        data = json.loads(json_str)
        return cls(**data)


class TimestampMixin:
    """Mixin that adds timestamp tracking."""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.created_at = datetime.now()
        self.updated_at = datetime.now()
    
    def touch(self):
        """Update the timestamp."""
        self.updated_at = datetime.now()


class ValidateMixin:
    """Mixin that adds validation capability."""
    
    required_fields = []
    
    def validate(self):
        errors = []
        for field in self.required_fields:
            if not hasattr(self, field) or getattr(self, field) is None:
                errors.append(f"Missing required field: {field}")
        return errors if errors else None


class LoggingMixin:
    """Mixin that adds logging capability."""
    
    def log(self, message, level="INFO"):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"[{timestamp}] [{level}] {self.__class__.__name__}: {message}")


# Base model class
class Model:
    def __init__(self, **kwargs):
        for key, value in kwargs.items():
            setattr(self, key, value)


# Combine mixins with model
class User(JsonMixin, TimestampMixin, ValidateMixin, LoggingMixin, Model):
    required_fields = ['username', 'email']
    
    def __init__(self, username, email, **kwargs):
        super().__init__(username=username, email=email, **kwargs)
        self.log(f"User created: {username}")


class Product(JsonMixin, TimestampMixin, Model):
    def __init__(self, name, price, **kwargs):
        super().__init__(name=name, price=price, **kwargs)


# Usage
user = User(username="alice", email="alice@email.com", role="admin")
print(user.to_json())
print(f"Created at: {user.created_at}")
print(f"Validation: {user.validate()}")  # None (valid)
user.log("Performing action", level="DEBUG")

product = Product(name="Laptop", price=999.99)
print(product.to_json())
```

## Real-World Example: Django-Style Models

```python
from abc import ABC, abstractmethod
from datetime import datetime
import uuid

# Mixins for model functionality
class PKMixin:
    """Adds primary key field."""
    def __init__(self, *args, **kwargs):
        self.id = kwargs.pop('id', str(uuid.uuid4())[:8])
        super().__init__(*args, **kwargs)

class TimestampMixin:
    """Adds created/updated timestamps."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.created_at = kwargs.get('created_at', datetime.now())
        self.updated_at = kwargs.get('updated_at', datetime.now())
    
    def save(self):
        self.updated_at = datetime.now()
        return super().save() if hasattr(super(), 'save') else None

class SoftDeleteMixin:
    """Adds soft delete functionality."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.is_deleted = False
        self.deleted_at = None
    
    def delete(self):
        self.is_deleted = True
        self.deleted_at = datetime.now()
    
    def restore(self):
        self.is_deleted = False
        self.deleted_at = None

class AuditMixin:
    """Adds audit trail."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._audit_log = []
    
    def log_change(self, field, old_value, new_value, user=None):
        self._audit_log.append({
            'field': field,
            'old': old_value,
            'new': new_value,
            'user': user,
            'timestamp': datetime.now()
        })
    
    def get_audit_log(self):
        return self._audit_log


# Base model
class BaseModel:
    _table_name = None
    
    def __init__(self, **kwargs):
        for key, value in kwargs.items():
            setattr(self, key, value)
    
    def save(self):
        print(f"Saving to {self._table_name}: {self.id}")
        return True
    
    def to_dict(self):
        return {k: v for k, v in self.__dict__.items() if not k.startswith('_')}


# Combine mixins to create feature-rich models
class User(PKMixin, TimestampMixin, SoftDeleteMixin, AuditMixin, BaseModel):
    _table_name = "users"
    
    def __init__(self, username, email, **kwargs):
        super().__init__(username=username, email=email, **kwargs)
    
    def update_email(self, new_email, updated_by=None):
        old_email = self.email
        self.email = new_email
        self.log_change('email', old_email, new_email, updated_by)


class Order(PKMixin, TimestampMixin, BaseModel):
    _table_name = "orders"
    
    def __init__(self, customer_id, total, **kwargs):
        super().__init__(customer_id=customer_id, total=total, **kwargs)


# Usage
print("=== User (with all mixins) ===")
user = User(username="alice", email="alice@old.com")
print(f"ID: {user.id}")
print(f"Created: {user.created_at}")

user.update_email("alice@new.com", updated_by="admin")
print(f"Audit log: {user.get_audit_log()}")

user.save()
user.delete()
print(f"Deleted: {user.is_deleted}")
user.restore()
print(f"Restored: {user.is_deleted}")

print("\n=== Order (fewer mixins) ===")
order = Order(customer_id=user.id, total=99.99)
print(f"Order: {order.to_dict()}")

# Order doesn't have soft delete or audit
# order.delete()  # Would fail - no SoftDeleteMixin
```

## Avoiding MRO Conflicts

Sometimes multiple inheritance creates impossible MRO:

```python
# This will FAIL!
class A: pass
class B(A): pass
class C(A, B): pass  # TypeError: Cannot create a consistent MRO

# Why? C says A before B, but B inherits from A (A after B)
```

### Rules to Avoid MRO Conflicts:

1. **List parents in order of specificity** (specific to general)
2. **Don't inherit from a class and its ancestor simultaneously**
3. **Keep inheritance hierarchies simple**

```python
# WRONG: C(A, B) when B inherits from A
class A: pass
class B(A): pass
# class C(A, B): pass  # Error!

# RIGHT: Let B provide access to A
class C(B): pass  # Gets both B and A methods
```

## Multiple Inheritance Best Practices

### DO:
```python
# Use mixins for orthogonal functionality
class JSONSerializable:
    def to_json(self): pass

class Timestamped:
    def __init__(self):
        self.created = datetime.now()

# Keep a clear primary inheritance
class MyModel(Timestamped, JSONSerializable, BaseModel):
    pass
```

### DON'T:
```python
# Don't create deep, complex hierarchies
class A: pass
class B(A): pass
class C(B): pass
class D(C): pass
class E(D): pass  # 5 levels deep - hard to understand

# Don't use multiple inheritance for everything
class X(A, B, C, D, E, F, G): pass  # Too many parents!
```

## Key Points to Remember

1. **MRO** determines method lookup order (C3 Linearization)
2. **`super()`** follows MRO, not just immediate parent
3. **Cooperative inheritance** requires `**kwargs` passing
4. **Mixins** are designed to add features, not be instantiated
5. **Diamond problem** is solved by MRO, but avoid complex diamonds
6. **Prefer composition** over complex multiple inheritance

## Quick Reference: MRO Commands

```python
# View MRO
print(MyClass.__mro__)
print(MyClass.mro())

# Check if class is in MRO
issubclass(Child, Parent)

# Get method from specific parent
ParentClass.method(self)

# Call next in MRO
super().method()
```

## Practice Exercise

Create a plugin system using mixins:
- `PluginBase`: Basic plugin interface
- `LoggingMixin`: Adds logging
- `ConfigMixin`: Adds configuration loading
- `MetricsMixin`: Adds performance metrics

```python
from datetime import datetime
import time

class PluginBase:
    name = "base"
    version = "1.0"
    
    def execute(self):
        raise NotImplementedError

class LoggingMixin:
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._logs = []
    
    def log(self, message):
        entry = f"[{datetime.now():%H:%M:%S}] {self.name}: {message}"
        self._logs.append(entry)
        print(entry)

class ConfigMixin:
    def __init__(self, *args, **kwargs):
        self._config = kwargs.pop('config', {})
        super().__init__(*args, **kwargs)
    
    def get_config(self, key, default=None):
        return self._config.get(key, default)

class MetricsMixin:
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._execution_times = []
    
    def timed_execute(self):
        start = time.time()
        result = self.execute()
        elapsed = time.time() - start
        self._execution_times.append(elapsed)
        return result
    
    @property
    def avg_execution_time(self):
        if not self._execution_times:
            return 0
        return sum(self._execution_times) / len(self._execution_times)


# Create plugins by combining mixins
class DataProcessorPlugin(LoggingMixin, ConfigMixin, MetricsMixin, PluginBase):
    name = "DataProcessor"
    version = "2.0"
    
    def execute(self):
        self.log("Starting data processing")
        batch_size = self.get_config('batch_size', 100)
        self.log(f"Processing with batch size: {batch_size}")
        time.sleep(0.1)  # Simulate work
        self.log("Processing complete")
        return {"processed": batch_size}


# Usage
plugin = DataProcessorPlugin(config={'batch_size': 500})

# Execute with metrics
for _ in range(3):
    result = plugin.timed_execute()

print(f"\nAvg execution time: {plugin.avg_execution_time:.4f}s")
print(f"Total logs: {len(plugin._logs)}")
```
