# Inheritance - Reusing and Extending Code

## What is Inheritance?

Inheritance is a mechanism where a new class (child/derived) inherits attributes and methods from an existing class (parent/base). It establishes an **"IS-A"** relationship.

## The Family Tree Analogy

Think of biological inheritance:
- A child inherits traits from parents (eye color, height tendencies)
- But the child is also their own person with unique traits
- The child doesn't need to redefine everything from scratch

```
                    ┌─────────────────┐
                    │     Animal      │  ← Parent/Base Class
                    │ ─────────────── │
                    │ + eat()         │
                    │ + sleep()       │
                    └────────┬────────┘
                             │ inherits
           ┌─────────────────┼─────────────────┐
           │                 │                 │
    ┌──────▼──────┐   ┌──────▼──────┐   ┌──────▼──────┐
    │    Dog      │   │    Cat      │   │    Bird     │  ← Child/Derived
    │ ─────────── │   │ ─────────── │   │ ─────────── │
    │ + bark()    │   │ + meow()    │   │ + fly()     │  ← Own methods
    │ + fetch()   │   │ + scratch() │   │ + chirp()   │
    └─────────────┘   └─────────────┘   └─────────────┘
    
    Dog IS-A Animal    Cat IS-A Animal   Bird IS-A Animal
```

## Why Use Inheritance?

1. **Code Reuse**: Don't repeat common code
2. **Hierarchy**: Model real-world relationships
3. **Polymorphism**: Treat different objects uniformly
4. **Extension**: Add new features without modifying existing code

## Basic Inheritance Syntax

```python
class Parent:
    """Base/Parent class."""
    
    def __init__(self, name):
        self.name = name
    
    def greet(self):
        return f"Hello, I'm {self.name}"


class Child(Parent):  # Child inherits from Parent
    """Derived/Child class."""
    
    def __init__(self, name, age):
        super().__init__(name)  # Call parent's __init__
        self.age = age
    
    def introduce(self):
        return f"I'm {self.name}, {self.age} years old"


# Usage
child = Child("Alice", 10)
print(child.greet())      # Inherited from Parent: Hello, I'm Alice
print(child.introduce())  # Own method: I'm Alice, 10 years old
```

## Understanding `super()`

`super()` returns a proxy object that allows you to access methods of the parent class:

```python
class Vehicle:
    def __init__(self, brand, model):
        self.brand = brand
        self.model = model
        print(f"Vehicle __init__ called for {brand} {model}")
    
    def start(self):
        return f"{self.brand} {self.model} is starting..."


class Car(Vehicle):
    def __init__(self, brand, model, num_doors):
        # Call parent's __init__ FIRST
        super().__init__(brand, model)
        # Then add child-specific attributes
        self.num_doors = num_doors
        print(f"Car __init__ called with {num_doors} doors")
    
    def start(self):
        # Extend parent's method
        parent_message = super().start()
        return f"{parent_message} Engine revving!"
    
    def honk(self):
        return "Beep beep!"


# Usage
car = Car("Toyota", "Camry", 4)
# Output:
# Vehicle __init__ called for Toyota Camry
# Car __init__ called with 4 doors

print(car.start())  # Toyota Camry is starting... Engine revving!
print(car.honk())   # Beep beep!
```

## Method Overriding

A child class can **override** (replace) parent methods to provide specialized behavior:

```python
class Animal:
    def __init__(self, name):
        self.name = name
    
    def speak(self):
        return "Some generic sound"
    
    def describe(self):
        return f"I am {self.name}"


class Dog(Animal):
    def speak(self):  # Override parent's method
        return f"{self.name} says: Woof!"
    
    def fetch(self):  # New method
        return f"{self.name} is fetching the ball"


class Cat(Animal):
    def speak(self):  # Override with different behavior
        return f"{self.name} says: Meow!"
    
    def scratch(self):
        return f"{self.name} is scratching"


class Cow(Animal):
    # Uses inherited speak() without override
    pass


# Usage
dog = Dog("Buddy")
cat = Cat("Whiskers")
cow = Cow("Bessie")

print(dog.speak())     # Buddy says: Woof! (overridden)
print(cat.speak())     # Whiskers says: Meow! (overridden)
print(cow.speak())     # Some generic sound (inherited)

print(dog.describe())  # I am Buddy (inherited from Animal)
```

## Real-World Example: Employee Hierarchy

```python
from datetime import datetime

class Employee:
    """Base class for all employees."""
    
    company = "TechCorp"
    
    def __init__(self, name, employee_id, salary):
        self.name = name
        self.employee_id = employee_id
        self._salary = salary
        self.hire_date = datetime.now()
    
    @property
    def salary(self):
        return self._salary
    
    def get_info(self):
        return f"{self.name} (ID: {self.employee_id}) - ${self._salary}/year"
    
    def calculate_bonus(self):
        """Default bonus: 10% of salary."""
        return self._salary * 0.10
    
    def work(self):
        return f"{self.name} is working..."


class Developer(Employee):
    """Developer inherits from Employee."""
    
    def __init__(self, name, employee_id, salary, programming_languages):
        super().__init__(name, employee_id, salary)
        self.programming_languages = programming_languages
        self.projects = []
    
    def work(self):
        return f"{self.name} is writing code in {', '.join(self.programming_languages)}"
    
    def add_project(self, project_name):
        self.projects.append(project_name)
        return f"{self.name} assigned to {project_name}"
    
    def calculate_bonus(self):
        """Developers get 15% bonus + extra per project."""
        base_bonus = self._salary * 0.15
        project_bonus = len(self.projects) * 500
        return base_bonus + project_bonus


class Manager(Employee):
    """Manager inherits from Employee."""
    
    def __init__(self, name, employee_id, salary, department):
        super().__init__(name, employee_id, salary)
        self.department = department
        self.team = []
    
    def work(self):
        return f"{self.name} is managing the {self.department} department"
    
    def add_team_member(self, employee):
        self.team.append(employee)
        return f"{employee.name} added to {self.name}'s team"
    
    def calculate_bonus(self):
        """Managers get 20% bonus + extra per team member."""
        base_bonus = self._salary * 0.20
        team_bonus = len(self.team) * 200
        return base_bonus + team_bonus
    
    def get_team_info(self):
        if not self.team:
            return f"{self.name} has no team members"
        members = [emp.name for emp in self.team]
        return f"{self.name}'s team: {', '.join(members)}"


class Intern(Employee):
    """Intern with limited privileges."""
    
    def __init__(self, name, employee_id, salary, university, mentor):
        super().__init__(name, employee_id, salary)
        self.university = university
        self.mentor = mentor
    
    def work(self):
        return f"{self.name} is learning from {self.mentor.name}"
    
    def calculate_bonus(self):
        """Interns get a smaller fixed bonus."""
        return 1000  # Fixed bonus for interns


# Usage
dev1 = Developer("Alice", "D001", 90000, ["Python", "JavaScript"])
dev2 = Developer("Bob", "D002", 85000, ["Java", "Go"])
manager = Manager("Charlie", "M001", 120000, "Engineering")
intern = Intern("Dave", "I001", 40000, "MIT", manager)

# Add projects and team members
dev1.add_project("API Redesign")
dev1.add_project("Mobile App")
manager.add_team_member(dev1)
manager.add_team_member(dev2)

# All have the same interface
employees = [dev1, dev2, manager, intern]

for emp in employees:
    print(emp.get_info())
    print(f"  Work: {emp.work()}")
    print(f"  Bonus: ${emp.calculate_bonus():,.2f}")
    print()
```

## Checking Inheritance

```python
# isinstance() - check if object is instance of a class
print(isinstance(dev1, Developer))  # True
print(isinstance(dev1, Employee))   # True (also an Employee!)
print(isinstance(dev1, Manager))    # False

# issubclass() - check if class inherits from another
print(issubclass(Developer, Employee))  # True
print(issubclass(Manager, Employee))    # True
print(issubclass(Developer, Manager))   # False

# type() - get exact type
print(type(dev1))  # <class '__main__.Developer'>
print(type(dev1) == Developer)  # True
print(type(dev1) == Employee)   # False (not exact match)
```

## Multi-Level Inheritance

Classes can form inheritance chains:

```python
class LivingThing:
    """Top of the hierarchy."""
    
    def __init__(self, name):
        self.name = name
        self.is_alive = True
    
    def breathe(self):
        return f"{self.name} is breathing"


class Animal(LivingThing):
    """Animals are living things that can move."""
    
    def __init__(self, name, species):
        super().__init__(name)
        self.species = species
    
    def move(self):
        return f"{self.name} is moving"


class Mammal(Animal):
    """Mammals are animals that are warm-blooded."""
    
    def __init__(self, name, species, fur_color):
        super().__init__(name, species)
        self.fur_color = fur_color
        self.warm_blooded = True
    
    def nurse(self):
        return f"{self.name} is nursing young"


class Dog(Mammal):
    """Dogs are mammals."""
    
    def __init__(self, name, breed, fur_color):
        super().__init__(name, species="Canis familiaris", fur_color=fur_color)
        self.breed = breed
    
    def bark(self):
        return f"{self.name} says: Woof!"
    
    def fetch(self):
        return f"{self.name} is fetching"


# Dog inherits from the entire chain
buddy = Dog("Buddy", "Golden Retriever", "Golden")

print(buddy.breathe())  # From LivingThing
print(buddy.move())     # From Animal
print(buddy.nurse())    # From Mammal
print(buddy.bark())     # From Dog

# Check the inheritance chain
print(Dog.__mro__)
# (<class 'Dog'>, <class 'Mammal'>, <class 'Animal'>, 
#  <class 'LivingThing'>, <class 'object'>)
```

## Abstract Base Classes

Sometimes you want to define a base class that **cannot** be instantiated and **forces** children to implement certain methods:

```python
from abc import ABC, abstractmethod

class Shape(ABC):
    """Abstract base class for shapes."""
    
    def __init__(self, color):
        self.color = color
    
    @abstractmethod
    def area(self):
        """Calculate area - must be implemented by subclasses."""
        pass
    
    @abstractmethod
    def perimeter(self):
        """Calculate perimeter - must be implemented by subclasses."""
        pass
    
    def describe(self):
        """Non-abstract method - inherited by all."""
        return f"A {self.color} shape"


class Rectangle(Shape):
    def __init__(self, color, width, height):
        super().__init__(color)
        self.width = width
        self.height = height
    
    def area(self):
        return self.width * self.height
    
    def perimeter(self):
        return 2 * (self.width + self.height)


class Circle(Shape):
    def __init__(self, color, radius):
        super().__init__(color)
        self.radius = radius
    
    def area(self):
        import math
        return math.pi * self.radius ** 2
    
    def perimeter(self):
        import math
        return 2 * math.pi * self.radius


# Can't instantiate abstract class
# shape = Shape("red")  # TypeError!

# Can instantiate concrete classes
rect = Rectangle("blue", 5, 3)
circle = Circle("red", 4)

print(f"Rectangle: area={rect.area()}, perimeter={rect.perimeter()}")
print(f"Circle: area={circle.area():.2f}, perimeter={circle.perimeter():.2f}")

# Both can be treated as Shapes
shapes = [rect, circle]
for shape in shapes:
    print(f"{shape.describe()}: Area = {shape.area():.2f}")
```

## When to Use Inheritance

**USE inheritance when:**
- There's a clear IS-A relationship
- Child shares most behavior with parent
- You need polymorphism
- You're modeling a natural hierarchy

**AVOID inheritance when:**
- Just want to reuse some code (use composition)
- The relationship is HAS-A not IS-A
- The hierarchy is more than 3-4 levels deep
- Behavior varies significantly between classes

## Key Points to Remember

1. **Child classes** inherit all attributes and methods from parents
2. **`super()`** calls parent class methods
3. **Method overriding** lets children specialize behavior
4. **`isinstance()`** checks if object is instance of class (includes inheritance)
5. **`issubclass()`** checks class inheritance
6. **Abstract classes** define interfaces that children must implement

## Practice Exercise

Create a hierarchy for a game:
- `Character` (base): name, health, attack()
- `Warrior` (child): strength, special_attack()
- `Mage` (child): mana, cast_spell()
- `Healer` (child): heal_power, heal()

```python
from abc import ABC, abstractmethod

class Character(ABC):
    def __init__(self, name, health):
        self.name = name
        self.health = health
        self.max_health = health
    
    def attack(self, target):
        damage = 10
        target.take_damage(damage)
        return f"{self.name} attacks {target.name} for {damage} damage"
    
    def take_damage(self, damage):
        self.health = max(0, self.health - damage)
        if self.health == 0:
            return f"{self.name} has been defeated!"
    
    @abstractmethod
    def special_ability(self):
        pass
    
    def status(self):
        return f"{self.name}: {self.health}/{self.max_health} HP"


class Warrior(Character):
    def __init__(self, name, health, strength):
        super().__init__(name, health)
        self.strength = strength
    
    def special_ability(self):
        return f"{self.name} uses Power Strike!"
    
    def attack(self, target):
        damage = 10 + self.strength
        target.take_damage(damage)
        return f"{self.name} swings sword at {target.name} for {damage} damage"


class Mage(Character):
    def __init__(self, name, health, mana):
        super().__init__(name, health)
        self.mana = mana
    
    def special_ability(self):
        if self.mana >= 20:
            self.mana -= 20
            return f"{self.name} casts Fireball!"
        return f"{self.name} doesn't have enough mana"
    
    def cast_spell(self, target, spell_power=25):
        if self.mana >= 10:
            self.mana -= 10
            target.take_damage(spell_power)
            return f"{self.name} casts magic on {target.name} for {spell_power} damage"
        return "Not enough mana!"


class Healer(Character):
    def __init__(self, name, health, heal_power):
        super().__init__(name, health)
        self.heal_power = heal_power
    
    def special_ability(self):
        return f"{self.name} uses Divine Light!"
    
    def heal(self, target):
        heal_amount = self.heal_power
        target.health = min(target.max_health, target.health + heal_amount)
        return f"{self.name} heals {target.name} for {heal_amount} HP"


# Test the game
warrior = Warrior("Conan", 150, 15)
mage = Mage("Gandalf", 80, 100)
healer = Healer("Elara", 100, 30)

print(warrior.attack(mage))
print(mage.status())
print(healer.heal(mage))
print(mage.status())
print(mage.cast_spell(warrior))
print(warrior.status())
```
