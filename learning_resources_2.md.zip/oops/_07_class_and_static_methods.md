# Class Methods and Static Methods

## Types of Methods in Python

Python classes can have three types of methods:

| Type | First Argument | Access to | Decorator |
|------|----------------|-----------|-----------|
| Instance Method | `self` (instance) | Instance + Class | None |
| Class Method | `cls` (class) | Class only | `@classmethod` |
| Static Method | None | Neither | `@staticmethod` |

## Visual Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                         MyClass                                 │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  INSTANCE METHOD                                                │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  def method(self):                                       │   │
│  │      # Can access:                                       │   │
│  │      # - self.instance_attr                              │   │
│  │      # - self.__class__.class_attr                       │   │
│  │      # - Other instance methods                          │   │
│  └─────────────────────────────────────────────────────────┘   │
│                           │                                     │
│                           ▼                                     │
│              Works on SPECIFIC OBJECT                           │
│                                                                 │
│  CLASS METHOD                                                   │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  @classmethod                                            │   │
│  │  def method(cls):                                        │   │
│  │      # Can access:                                       │   │
│  │      # - cls.class_attr                                  │   │
│  │      # - Other class methods                             │   │
│  │      # - Cannot access self (no instance)                │   │
│  └─────────────────────────────────────────────────────────┘   │
│                           │                                     │
│                           ▼                                     │
│              Works on CLASS ITSELF                              │
│                                                                 │
│  STATIC METHOD                                                  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  @staticmethod                                           │   │
│  │  def method():                                           │   │
│  │      # Cannot access:                                    │   │
│  │      # - self (no instance)                              │   │
│  │      # - cls (no class)                                  │   │
│  │      # Just a regular function in class namespace        │   │
│  └─────────────────────────────────────────────────────────┘   │
│                           │                                     │
│                           ▼                                     │
│              UTILITY FUNCTION (grouped in class)                │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

## Instance Methods (Default)

The most common type - they operate on a specific instance:

```python
class Dog:
    species = "Canis familiaris"  # Class attribute
    
    def __init__(self, name, age):
        self.name = name    # Instance attribute
        self.age = age
    
    # Instance method - has access to 'self'
    def bark(self):
        return f"{self.name} says: Woof!"
    
    def birthday(self):
        self.age += 1       # Can modify instance state
        return f"{self.name} is now {self.age}"
    
    def describe(self):
        # Can access both instance and class attributes
        return f"{self.name} is a {self.species}, age {self.age}"


# Instance methods work on specific objects
buddy = Dog("Buddy", 3)
max_dog = Dog("Max", 5)

print(buddy.bark())      # Buddy says: Woof!
print(max_dog.bark())    # Max says: Woof!
print(buddy.birthday())  # Buddy is now 4
```

## Class Methods

Methods that operate on the **class itself**, not instances:

```python
from datetime import datetime

class Employee:
    """Demonstrates class methods."""
    
    # Class attributes
    company = "TechCorp"
    _employee_count = 0
    _all_employees = []
    
    def __init__(self, name, salary):
        self.name = name
        self.salary = salary
        self.hire_date = datetime.now()
        
        # Update class-level data
        Employee._employee_count += 1
        Employee._all_employees.append(self)
    
    # Instance method
    def get_info(self):
        return f"{self.name}: ${self.salary}/year at {self.company}"
    
    # CLASS METHODS - use @classmethod decorator
    @classmethod
    def get_employee_count(cls):
        """Returns total employee count - works on class level."""
        return cls._employee_count
    
    @classmethod
    def set_company(cls, new_name):
        """Changes company name for ALL employees."""
        cls.company = new_name
    
    @classmethod
    def get_all_employees(cls):
        """Returns list of all employees."""
        return cls._all_employees.copy()
    
    # Class method as FACTORY (alternative constructor)
    @classmethod
    def from_string(cls, emp_string):
        """Create Employee from 'name-salary' string."""
        name, salary = emp_string.split('-')
        return cls(name, int(salary))
    
    @classmethod
    def create_intern(cls, name):
        """Factory: create intern with standard salary."""
        return cls(name, 40000)


# Using class methods
print(Employee.get_employee_count())  # 0 (before creating any)

emp1 = Employee("Alice", 75000)
emp2 = Employee("Bob", 85000)
emp3 = Employee.from_string("Charlie-95000")  # Factory method
intern = Employee.create_intern("Dave")        # Factory method

print(Employee.get_employee_count())  # 4

# Class method changes affect all instances
Employee.set_company("NewTechCorp")
print(emp1.company)  # NewTechCorp
print(emp2.company)  # NewTechCorp

# Get all employees
for emp in Employee.get_all_employees():
    print(emp.get_info())
```

## Static Methods

Utility functions that belong logically to the class but don't need access to class or instance:

```python
class MathUtils:
    """Static methods as utility functions."""
    
    # Static method - no self or cls
    @staticmethod
    def is_prime(n):
        """Check if number is prime."""
        if n < 2:
            return False
        for i in range(2, int(n ** 0.5) + 1):
            if n % i == 0:
                return False
        return True
    
    @staticmethod
    def factorial(n):
        """Calculate factorial."""
        if n <= 1:
            return 1
        result = 1
        for i in range(2, n + 1):
            result *= i
        return result
    
    @staticmethod
    def fibonacci(n):
        """Generate first n Fibonacci numbers."""
        if n <= 0:
            return []
        elif n == 1:
            return [0]
        
        fib = [0, 1]
        for _ in range(2, n):
            fib.append(fib[-1] + fib[-2])
        return fib


# Called on class (no instance needed)
print(MathUtils.is_prime(17))      # True
print(MathUtils.factorial(5))       # 120
print(MathUtils.fibonacci(10))      # [0, 1, 1, 2, 3, 5, 8, 13, 21, 34]

# Can also call on instance (but doesn't make much sense)
utils = MathUtils()
print(utils.is_prime(17))  # Works, but why create instance?
```

## Combining All Three Method Types

```python
from datetime import datetime, date

class Person:
    """Complete example using all method types."""
    
    # Class attributes
    population = 0
    _instances = []
    
    def __init__(self, name, birth_date):
        self.name = name
        self.birth_date = birth_date
        
        Person.population += 1
        Person._instances.append(self)
    
    # INSTANCE METHOD: operates on specific person
    def get_age(self):
        today = date.today()
        age = today.year - self.birth_date.year
        if (today.month, today.day) < (self.birth_date.month, self.birth_date.day):
            age -= 1
        return age
    
    def introduce(self):
        return f"Hi, I'm {self.name}, {self.get_age()} years old"
    
    # CLASS METHOD: operates on the class
    @classmethod
    def get_population(cls):
        """Get total number of Person instances."""
        return cls.population
    
    @classmethod
    def get_all_people(cls):
        """Get list of all people."""
        return cls._instances.copy()
    
    @classmethod
    def from_birth_year(cls, name, year):
        """Factory: create Person from birth year."""
        birth_date = date(year, 1, 1)
        return cls(name, birth_date)
    
    @classmethod
    def from_string(cls, person_string):
        """Factory: create from 'name,YYYY-MM-DD' string."""
        name, date_str = person_string.split(',')
        birth_date = datetime.strptime(date_str, '%Y-%m-%d').date()
        return cls(name, birth_date)
    
    # STATIC METHOD: utility function
    @staticmethod
    def is_valid_name(name):
        """Validate name - doesn't need class or instance."""
        return bool(name) and len(name) >= 2 and name.replace(' ', '').isalpha()
    
    @staticmethod
    def calculate_age_difference(person1, person2):
        """Calculate age difference between two people."""
        return abs(person1.get_age() - person2.get_age())
    
    @staticmethod
    def is_adult(age, country="US"):
        """Check if age qualifies as adult."""
        adult_ages = {"US": 18, "UK": 18, "Japan": 20, "Germany": 18}
        return age >= adult_ages.get(country, 18)


# Usage examples
print("=== Creating People ===")
alice = Person("Alice", date(1990, 5, 15))
bob = Person.from_birth_year("Bob", 1985)
charlie = Person.from_string("Charlie,1995-08-20")

print(f"Population: {Person.get_population()}")  # 3

print("\n=== Instance Methods ===")
for person in Person.get_all_people():
    print(person.introduce())

print("\n=== Static Methods ===")
print(f"Valid name 'John': {Person.is_valid_name('John')}")
print(f"Valid name '123': {Person.is_valid_name('123')}")
print(f"Age difference: {Person.calculate_age_difference(alice, bob)} years")
print(f"Is 21 adult in Japan? {Person.is_adult(21, 'Japan')}")
```

## Real-World Example: Database Configuration

```python
import json
from pathlib import Path

class DatabaseConfig:
    """Configuration manager using all method types."""
    
    # Class-level defaults
    DEFAULT_HOST = "localhost"
    DEFAULT_PORT = 5432
    _configs = {}
    
    def __init__(self, name, host=None, port=None, database=None):
        self.name = name
        self.host = host or self.DEFAULT_HOST
        self.port = port or self.DEFAULT_PORT
        self.database = database or name
        
        # Register this config
        DatabaseConfig._configs[name] = self
    
    # Instance method: get connection string for THIS config
    def get_connection_string(self):
        return f"postgresql://{self.host}:{self.port}/{self.database}"
    
    def to_dict(self):
        return {
            "name": self.name,
            "host": self.host,
            "port": self.port,
            "database": self.database
        }
    
    # Class methods: manage all configs
    @classmethod
    def get_config(cls, name):
        """Get a registered config by name."""
        return cls._configs.get(name)
    
    @classmethod
    def list_configs(cls):
        """List all registered config names."""
        return list(cls._configs.keys())
    
    @classmethod
    def set_defaults(cls, host=None, port=None):
        """Change default values for future configs."""
        if host:
            cls.DEFAULT_HOST = host
        if port:
            cls.DEFAULT_PORT = port
    
    # Factory class methods
    @classmethod
    def from_json(cls, json_string):
        """Create config from JSON string."""
        data = json.loads(json_string)
        return cls(**data)
    
    @classmethod
    def from_file(cls, file_path):
        """Create config from JSON file."""
        with open(file_path) as f:
            data = json.load(f)
        return cls(**data)
    
    @classmethod
    def from_env(cls, prefix="DB"):
        """Create config from environment variables."""
        import os
        return cls(
            name=os.getenv(f"{prefix}_NAME", "default"),
            host=os.getenv(f"{prefix}_HOST"),
            port=int(os.getenv(f"{prefix}_PORT", cls.DEFAULT_PORT)),
            database=os.getenv(f"{prefix}_DATABASE")
        )
    
    # Static methods: validation utilities
    @staticmethod
    def is_valid_host(host):
        """Validate hostname format."""
        import re
        pattern = r'^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)*$'
        return bool(re.match(pattern, host))
    
    @staticmethod
    def is_valid_port(port):
        """Validate port number."""
        return isinstance(port, int) and 1 <= port <= 65535
    
    @staticmethod
    def parse_connection_string(conn_str):
        """Parse a connection string into components."""
        from urllib.parse import urlparse
        parsed = urlparse(conn_str)
        return {
            "host": parsed.hostname,
            "port": parsed.port,
            "database": parsed.path.lstrip('/'),
            "username": parsed.username,
            "password": parsed.password
        }


# Usage
print("=== Creating Configs ===")
dev = DatabaseConfig("development", database="myapp_dev")
prod = DatabaseConfig("production", "prod.db.server.com", 5432, "myapp")

print(dev.get_connection_string())
print(prod.get_connection_string())

print("\n=== Using Class Methods ===")
print(f"All configs: {DatabaseConfig.list_configs()}")
print(f"Dev config: {DatabaseConfig.get_config('development').to_dict()}")

# Change defaults for future configs
DatabaseConfig.set_defaults(host="db.internal.com", port=3306)
test = DatabaseConfig("test")
print(f"Test uses new defaults: {test.get_connection_string()}")

print("\n=== Using Static Methods ===")
print(f"Valid host 'localhost': {DatabaseConfig.is_valid_host('localhost')}")
print(f"Valid port 5432: {DatabaseConfig.is_valid_port(5432)}")

conn_string = "postgresql://user:pass@localhost:5432/mydb"
print(f"Parsed: {DatabaseConfig.parse_connection_string(conn_string)}")
```

## When to Use Each Method Type

| Use Case | Method Type | Why |
|----------|-------------|-----|
| Modify/access instance state | Instance | Needs `self` |
| Alternative constructors | Class | Returns `cls(...)` |
| Access/modify class state | Class | Needs `cls` |
| Factory patterns | Class | Creates new instances |
| Utility functions | Static | No state needed |
| Validation helpers | Static | Just logic |
| Group related functions | Static | Namespace organization |

## Key Points to Remember

1. **Instance methods** get `self` - work on specific objects
2. **Class methods** get `cls` - work on the class, great for factories
3. **Static methods** get nothing - utility functions in class namespace
4. **Factories** use `@classmethod` so subclasses inherit properly
5. **Validators** often use `@staticmethod` since they're pure functions

## Practice Exercise

Create a `Temperature` class with:
- Instance method: `to_fahrenheit()`, `to_kelvin()`
- Class method: `from_fahrenheit()`, `from_kelvin()` (factories)
- Static method: `is_valid_celsius()`, `celsius_to_fahrenheit()`

```python
class Temperature:
    """Temperature class demonstrating all method types."""
    
    ABSOLUTE_ZERO_C = -273.15
    
    def __init__(self, celsius):
        if not self.is_valid_celsius(celsius):
            raise ValueError(f"Temperature cannot be below {self.ABSOLUTE_ZERO_C}C")
        self._celsius = celsius
    
    # Instance methods
    @property
    def celsius(self):
        return self._celsius
    
    def to_fahrenheit(self):
        """Convert this temperature to Fahrenheit."""
        return self.celsius_to_fahrenheit(self._celsius)
    
    def to_kelvin(self):
        """Convert this temperature to Kelvin."""
        return self.celsius_to_kelvin(self._celsius)
    
    def __repr__(self):
        return f"Temperature({self._celsius}°C)"
    
    # Class methods (factories)
    @classmethod
    def from_fahrenheit(cls, fahrenheit):
        """Create Temperature from Fahrenheit value."""
        celsius = cls.fahrenheit_to_celsius(fahrenheit)
        return cls(celsius)
    
    @classmethod
    def from_kelvin(cls, kelvin):
        """Create Temperature from Kelvin value."""
        celsius = cls.kelvin_to_celsius(kelvin)
        return cls(celsius)
    
    @classmethod
    def absolute_zero(cls):
        """Factory for absolute zero."""
        return cls(cls.ABSOLUTE_ZERO_C)
    
    # Static methods (conversions)
    @staticmethod
    def is_valid_celsius(value):
        """Check if temperature is physically possible."""
        return value >= Temperature.ABSOLUTE_ZERO_C
    
    @staticmethod
    def celsius_to_fahrenheit(celsius):
        """Convert Celsius to Fahrenheit."""
        return (celsius * 9/5) + 32
    
    @staticmethod
    def fahrenheit_to_celsius(fahrenheit):
        """Convert Fahrenheit to Celsius."""
        return (fahrenheit - 32) * 5/9
    
    @staticmethod
    def celsius_to_kelvin(celsius):
        """Convert Celsius to Kelvin."""
        return celsius + 273.15
    
    @staticmethod
    def kelvin_to_celsius(kelvin):
        """Convert Kelvin to Celsius."""
        return kelvin - 273.15


# Test all method types
print("=== Instance Methods ===")
t = Temperature(25)
print(f"{t} = {t.to_fahrenheit()}°F = {t.to_kelvin()}K")

print("\n=== Class Methods (Factories) ===")
from_f = Temperature.from_fahrenheit(98.6)
from_k = Temperature.from_kelvin(300)
abs_zero = Temperature.absolute_zero()

print(f"98.6°F = {from_f}")
print(f"300K = {from_k}")
print(f"Absolute Zero = {abs_zero}")

print("\n=== Static Methods ===")
print(f"100°C = {Temperature.celsius_to_fahrenheit(100)}°F")
print(f"Is -300°C valid? {Temperature.is_valid_celsius(-300)}")
```
