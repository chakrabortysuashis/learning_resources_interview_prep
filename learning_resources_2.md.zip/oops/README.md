# Object-Oriented Programming (OOP) in Python

A comprehensive guide to mastering OOP concepts with intuitive explanations and practical Python examples.

## Table of Contents

| # | Topic | Description |
|---|-------|-------------|
| 01 | [Classes and Objects](_01_classes_and_objects.md) | Foundation of OOP - blueprints and instances |
| 02 | [Encapsulation](_02_encapsulation.md) | Protecting data with access control |
| 03 | [Inheritance](_03_inheritance.md) | Code reuse through IS-A relationships |
| 04 | [Polymorphism](_04_polymorphism.md) | One interface, many implementations |
| 05 | [Abstraction](_05_abstraction.md) | Hiding complexity behind simple interfaces |
| 06 | [Constructors & Destructors](_06_constructors_and_destructors.md) | Object lifecycle management |
| 07 | [Class & Static Methods](_07_class_and_static_methods.md) | Different types of methods |
| 08 | [Properties & Descriptors](_08_properties_and_descriptors.md) | Managed attribute access |
| 09 | [Magic Methods](_09_magic_methods.md) | Dunder methods for Python integration |
| 10 | [Composition vs Inheritance](_10_composition_vs_inheritance.md) | Choosing the right relationship |
| 11 | [Multiple Inheritance & MRO](_11_multiple_inheritance_and_mro.md) | Advanced inheritance patterns |
| 12 | [SOLID Principles](_12_solid_principles.md) | Design principles for clean code |

## Learning Path

### Beginner (Start Here)
1. **Classes and Objects** - Understand the building blocks
2. **Constructors & Destructors** - Learn object creation
3. **Encapsulation** - Protect your data

### Intermediate
4. **Inheritance** - Reuse code effectively
5. **Polymorphism** - Write flexible code
6. **Abstraction** - Design clean interfaces
7. **Class & Static Methods** - Master different method types
8. **Properties & Descriptors** - Control attribute access

### Advanced
9. **Magic Methods** - Make your objects Pythonic
10. **Composition vs Inheritance** - Make better design choices
11. **Multiple Inheritance & MRO** - Handle complex hierarchies
12. **SOLID Principles** - Write professional-grade code

## Quick Reference

### The Four Pillars of OOP

```
┌─────────────────────────────────────────────────────────────────┐
│                    OBJECT-ORIENTED PROGRAMMING                   │
├─────────────────┬─────────────────┬─────────────────┬───────────┤
│  ENCAPSULATION  │   INHERITANCE   │  POLYMORPHISM   │ABSTRACTION│
├─────────────────┼─────────────────┼─────────────────┼───────────┤
│ Hide internal   │ Reuse code from │ Same interface  │ Hide      │
│ data, expose    │ parent classes  │ different       │ complexity│
│ only what's     │ (IS-A relation) │ behaviors       │ show only │
│ necessary       │                 │                 │ essentials│
└─────────────────┴─────────────────┴─────────────────┴───────────┘
```

### Python OOP Syntax Cheat Sheet

```python
# Class definition
class MyClass:
    class_attr = "shared"           # Class attribute
    
    def __init__(self, value):      # Constructor
        self.instance_attr = value   # Instance attribute
        self._protected = "internal" # Protected (convention)
        self.__private = "hidden"    # Private (name mangling)
    
    def instance_method(self):       # Instance method
        return self.instance_attr
    
    @classmethod
    def class_method(cls):           # Class method
        return cls.class_attr
    
    @staticmethod
    def static_method():             # Static method
        return "utility"
    
    @property
    def computed(self):              # Property (getter)
        return self._protected
    
    @computed.setter
    def computed(self, value):       # Property setter
        self._protected = value


# Inheritance
class Child(Parent):
    def __init__(self, value, extra):
        super().__init__(value)      # Call parent constructor
        self.extra = extra


# Abstract class
from abc import ABC, abstractmethod

class Abstract(ABC):
    @abstractmethod
    def must_implement(self):
        pass
```

## Each File Contains

- Concept explanation with real-world analogy
- Visual diagrams (ASCII art)
- Python code examples
- Common mistakes to avoid
- Best practices
- Practice exercises

## How to Use This Guide

1. **Read sequentially** for comprehensive understanding
2. **Use as reference** when you need a specific topic
3. **Practice the exercises** at the end of each file
4. **Build projects** applying these concepts

Happy Learning!
