# Classes and Objects - The Foundation of OOP

## What is Object-Oriented Programming?

Object-Oriented Programming (OOP) is a programming paradigm that organizes code around **objects** rather than functions and logic. Think of it as modeling real-world entities in your code.

## The Blueprint Analogy

Imagine you're an architect designing houses:

- **Class** = The blueprint of a house (defines what a house should have)
- **Object** = An actual house built from that blueprint (a real instance)

You can build many houses from one blueprint. Each house has the same structure but can have different colors, sizes, and furniture.

```
Blueprint (Class)              Actual Houses (Objects)
┌─────────────────┐           ┌─────────────────┐
│  House          │           │  House #1       │
│  - rooms        │  ──────►  │  rooms = 3      │
│  - color        │           │  color = "blue" │
│  - area         │           │  area = 1500    │
│  + get_info()   │           └─────────────────┘
└─────────────────┘           ┌─────────────────┐
                              │  House #2       │
                              │  rooms = 5      │
                              │  color = "red"  │
                              │  area = 2500    │
                              └─────────────────┘
```

## Core Concepts

### 1. Class
A class is a template or blueprint that defines:
- **Attributes** (data/properties) - What the object HAS
- **Methods** (functions) - What the object CAN DO

### 2. Object (Instance)
An object is a concrete instance created from a class. It has actual values for the attributes defined in the class.

## Python Code Examples

### Basic Class Definition

```python
class Dog:
    """A simple Dog class - the blueprint for creating dog objects."""
    
    # Class attribute (shared by all instances)
    species = "Canis familiaris"
    
    # Constructor method - called when creating a new object
    def __init__(self, name, age, breed):
        # Instance attributes (unique to each object)
        self.name = name
        self.age = age
        self.breed = breed
    
    # Instance method - defines behavior
    def bark(self):
        return f"{self.name} says: Woof! Woof!"
    
    def describe(self):
        return f"{self.name} is a {self.age}-year-old {self.breed}"
    
    def birthday(self):
        self.age += 1
        return f"Happy Birthday {self.name}! Now {self.age} years old."


# Creating objects (instantiation)
dog1 = Dog("Buddy", 3, "Golden Retriever")
dog2 = Dog("Max", 5, "German Shepherd")

# Accessing attributes
print(dog1.name)        # Output: Buddy
print(dog2.breed)       # Output: German Shepherd

# Calling methods
print(dog1.bark())      # Output: Buddy says: Woof! Woof!
print(dog2.describe())  # Output: Max is a 5-year-old German Shepherd

# Modifying state through methods
print(dog1.birthday())  # Output: Happy Birthday Buddy! Now 4 years old.

# Class attribute is shared
print(dog1.species)     # Output: Canis familiaris
print(dog2.species)     # Output: Canis familiaris
```

### Understanding `self`

The `self` parameter is a reference to the **current instance** of the class. It's how the object refers to itself.

```python
class BankAccount:
    def __init__(self, owner, balance=0):
        self.owner = owner      # self.owner belongs to THIS specific account
        self.balance = balance
    
    def deposit(self, amount):
        self.balance += amount  # Modify THIS account's balance
        return f"Deposited ${amount}. New balance: ${self.balance}"
    
    def withdraw(self, amount):
        if amount > self.balance:
            return "Insufficient funds!"
        self.balance -= amount
        return f"Withdrew ${amount}. Remaining: ${self.balance}"


# Create two different accounts
alice_account = BankAccount("Alice", 1000)
bob_account = BankAccount("Bob", 500)

# Each object maintains its own state
print(alice_account.deposit(200))   # Alice's balance: 1200
print(bob_account.withdraw(100))    # Bob's balance: 400

# They don't interfere with each other
print(alice_account.balance)  # 1200
print(bob_account.balance)    # 400
```

### Class vs Instance Attributes

```python
class Employee:
    # Class attribute - shared by ALL employees
    company = "TechCorp"
    employee_count = 0
    
    def __init__(self, name, salary):
        # Instance attributes - unique to each employee
        self.name = name
        self.salary = salary
        
        # Modify class attribute
        Employee.employee_count += 1
    
    def get_info(self):
        return f"{self.name} works at {self.company} earning ${self.salary}"


# Create employees
emp1 = Employee("John", 50000)
emp2 = Employee("Jane", 60000)

print(Employee.employee_count)  # Output: 2 (class attribute)

# Instance attributes are different
print(emp1.salary)  # 50000
print(emp2.salary)  # 60000

# Class attribute is the same
print(emp1.company)  # TechCorp
print(emp2.company)  # TechCorp

# Changing class attribute affects all instances
Employee.company = "NewTechCorp"
print(emp1.company)  # NewTechCorp
print(emp2.company)  # NewTechCorp
```

## Real-World Example: Library System

```python
class Book:
    """Represents a book in a library system."""
    
    total_books = 0  # Track total books in the library
    
    def __init__(self, title, author, isbn, copies=1):
        self.title = title
        self.author = author
        self.isbn = isbn
        self.total_copies = copies
        self.available_copies = copies
        self.borrowers = []
        
        Book.total_books += copies
    
    def borrow(self, borrower_name):
        """Borrow a copy of the book."""
        if self.available_copies > 0:
            self.available_copies -= 1
            self.borrowers.append(borrower_name)
            return f"'{self.title}' borrowed by {borrower_name}. {self.available_copies} copies left."
        return f"Sorry, '{self.title}' is not available."
    
    def return_book(self, borrower_name):
        """Return a borrowed book."""
        if borrower_name in self.borrowers:
            self.borrowers.remove(borrower_name)
            self.available_copies += 1
            return f"'{self.title}' returned by {borrower_name}."
        return f"{borrower_name} didn't borrow this book."
    
    def get_status(self):
        """Get current status of the book."""
        return f"'{self.title}' by {self.author} - {self.available_copies}/{self.total_copies} available"
    
    def __str__(self):
        return f"Book: {self.title} by {self.author}"


# Using the Book class
book1 = Book("Python Crash Course", "Eric Matthes", "978-1593279288", copies=3)
book2 = Book("Clean Code", "Robert Martin", "978-0132350884", copies=2)

print(book1.get_status())
# Output: 'Python Crash Course' by Eric Matthes - 3/3 available

print(book1.borrow("Alice"))
# Output: 'Python Crash Course' borrowed by Alice. 2 copies left.

print(book1.borrow("Bob"))
print(book1.borrow("Charlie"))
print(book1.borrow("David"))  # Should fail - no copies left

print(book1.return_book("Alice"))
print(book1.get_status())

print(f"\nTotal books in library: {Book.total_books}")
```

## Memory Model: How Objects Work

```
Memory Layout:
┌─────────────────────────────────────────┐
│           Class: Dog                     │
│  ┌────────────────────────────────────┐ │
│  │ species = "Canis familiaris"       │ │  ← Class attribute (one copy)
│  │ __init__, bark, describe methods   │ │  ← Methods (shared)
│  └────────────────────────────────────┘ │
└─────────────────────────────────────────┘
              │
              ▼
┌──────────────────┐    ┌──────────────────┐
│  Object: dog1    │    │  Object: dog2    │
│  ┌────────────┐  │    │  ┌────────────┐  │
│  │name="Buddy"│  │    │  │name="Max"  │  │  ← Instance attributes
│  │age=3       │  │    │  │age=5       │  │    (separate for each object)
│  │breed="GR"  │  │    │  │breed="GS"  │  │
│  └────────────┘  │    └──└────────────┘──┘
└──────────────────┘
```

## Key Points to Remember

1. **Class** = Blueprint/Template that defines structure and behavior
2. **Object** = Instance created from a class with actual data
3. **`self`** = Reference to the current instance
4. **`__init__`** = Constructor method, called automatically when creating an object
5. **Class attributes** = Shared by all instances
6. **Instance attributes** = Unique to each instance

## Common Mistakes to Avoid

```python
# WRONG: Forgetting self
class Wrong:
    def greet():  # Missing self!
        return "Hello"

# RIGHT:
class Right:
    def greet(self):
        return "Hello"


# WRONG: Modifying mutable class attributes
class Wrong:
    items = []  # Shared mutable list - dangerous!
    
    def add_item(self, item):
        self.items.append(item)  # All instances share this list!

# RIGHT:
class Right:
    def __init__(self):
        self.items = []  # Each instance gets its own list
    
    def add_item(self, item):
        self.items.append(item)
```

## When to Use Classes

Use classes when you need to:
- Model real-world entities with data and behavior
- Create multiple similar objects with their own state
- Organize related data and functions together
- Implement inheritance and polymorphism
- Maintain state across multiple method calls

## Practice Exercise

Try creating a `Student` class with:
- Attributes: name, student_id, grades (list)
- Methods: add_grade(), get_average(), is_passing()

```python
# Your implementation here
class Student:
    def __init__(self, name, student_id):
        self.name = name
        self.student_id = student_id
        self.grades = []
    
    def add_grade(self, grade):
        if 0 <= grade <= 100:
            self.grades.append(grade)
            return f"Grade {grade} added for {self.name}"
        return "Invalid grade. Must be between 0 and 100."
    
    def get_average(self):
        if not self.grades:
            return 0
        return sum(self.grades) / len(self.grades)
    
    def is_passing(self, passing_grade=60):
        return self.get_average() >= passing_grade


# Test it!
student = Student("Alice", "S001")
student.add_grade(85)
student.add_grade(90)
student.add_grade(78)
print(f"Average: {student.get_average():.2f}")
print(f"Passing: {student.is_passing()}")
```
