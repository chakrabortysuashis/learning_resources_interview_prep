# SOLID Principles - Object-Oriented Design Guidelines

## What is SOLID?

SOLID is an acronym for five design principles that make software designs more understandable, flexible, and maintainable.

| Letter | Principle | Key Idea |
|--------|-----------|----------|
| **S** | Single Responsibility | One class = One job |
| **O** | Open/Closed | Open for extension, closed for modification |
| **L** | Liskov Substitution | Subtypes must be substitutable |
| **I** | Interface Segregation | Many specific interfaces > one general |
| **D** | Dependency Inversion | Depend on abstractions, not concretions |

## S - Single Responsibility Principle (SRP)

> "A class should have one, and only one, reason to change."

### The Problem (Violation)

```python
# BAD: UserManager does too many things
class UserManager:
    def __init__(self):
        self.users = []
    
    # User management
    def create_user(self, name, email):
        user = {"name": name, "email": email}
        self.users.append(user)
        return user
    
    def delete_user(self, email):
        self.users = [u for u in self.users if u["email"] != email]
    
    # Database operations (different responsibility!)
    def save_to_database(self, user):
        # Database logic here
        print(f"Saving {user} to database")
    
    # Email operations (different responsibility!)
    def send_welcome_email(self, user):
        # Email logic here
        print(f"Sending email to {user['email']}")
    
    # Logging (different responsibility!)
    def log_action(self, action):
        print(f"[LOG] {action}")
    
    # Report generation (different responsibility!)
    def generate_user_report(self):
        return f"Total users: {len(self.users)}"
```

### The Solution (Following SRP)

```python
# GOOD: Each class has ONE responsibility

class User:
    """Represents a user entity."""
    def __init__(self, name, email):
        self.name = name
        self.email = email


class UserRepository:
    """Handles user data storage."""
    def __init__(self):
        self.users = []
    
    def add(self, user):
        self.users.append(user)
    
    def remove(self, email):
        self.users = [u for u in self.users if u.email != email]
    
    def find_by_email(self, email):
        return next((u for u in self.users if u.email == email), None)
    
    def get_all(self):
        return self.users.copy()


class UserDatabase:
    """Handles database operations."""
    def save(self, user):
        print(f"Saving {user.name} to database")
    
    def load(self, email):
        print(f"Loading user {email} from database")


class EmailService:
    """Handles email operations."""
    def send_welcome(self, user):
        print(f"Sending welcome email to {user.email}")
    
    def send_notification(self, user, message):
        print(f"Sending '{message}' to {user.email}")


class Logger:
    """Handles logging."""
    def log(self, message, level="INFO"):
        print(f"[{level}] {message}")


class UserReportGenerator:
    """Generates user reports."""
    def __init__(self, repository):
        self.repository = repository
    
    def generate(self):
        users = self.repository.get_all()
        return f"Total users: {len(users)}"


# Usage - each component has a clear responsibility
repo = UserRepository()
db = UserDatabase()
email = EmailService()
logger = Logger()

user = User("Alice", "alice@email.com")
repo.add(user)
db.save(user)
email.send_welcome(user)
logger.log(f"User {user.name} created")

report_gen = UserReportGenerator(repo)
print(report_gen.generate())
```

## O - Open/Closed Principle (OCP)

> "Software entities should be open for extension, but closed for modification."

### The Problem (Violation)

```python
# BAD: Must modify class to add new payment types
class PaymentProcessor:
    def process(self, payment_type, amount):
        if payment_type == "credit_card":
            print(f"Processing credit card: ${amount}")
            # Credit card logic
        elif payment_type == "paypal":
            print(f"Processing PayPal: ${amount}")
            # PayPal logic
        elif payment_type == "bitcoin":
            print(f"Processing Bitcoin: ${amount}")
            # Bitcoin logic
        # Adding new payment type requires modifying this class!
        else:
            raise ValueError(f"Unknown payment type: {payment_type}")
```

### The Solution (Following OCP)

```python
from abc import ABC, abstractmethod

# GOOD: Open for extension (new payment methods), closed for modification

class PaymentMethod(ABC):
    """Abstract base for payment methods."""
    
    @abstractmethod
    def process(self, amount):
        pass
    
    @abstractmethod
    def validate(self):
        pass


class CreditCardPayment(PaymentMethod):
    def __init__(self, card_number, expiry, cvv):
        self.card_number = card_number
        self.expiry = expiry
        self.cvv = cvv
    
    def validate(self):
        return len(self.card_number) == 16
    
    def process(self, amount):
        if not self.validate():
            raise ValueError("Invalid card")
        print(f"Processing credit card payment: ${amount}")
        return True


class PayPalPayment(PaymentMethod):
    def __init__(self, email):
        self.email = email
    
    def validate(self):
        return "@" in self.email
    
    def process(self, amount):
        if not self.validate():
            raise ValueError("Invalid PayPal email")
        print(f"Processing PayPal payment: ${amount}")
        return True


class BitcoinPayment(PaymentMethod):
    def __init__(self, wallet_address):
        self.wallet_address = wallet_address
    
    def validate(self):
        return len(self.wallet_address) > 20
    
    def process(self, amount):
        if not self.validate():
            raise ValueError("Invalid wallet address")
        btc_amount = amount / 45000  # Simplified conversion
        print(f"Processing Bitcoin payment: {btc_amount:.8f} BTC")
        return True


# New payment method - NO modification needed!
class ApplePayPayment(PaymentMethod):
    def __init__(self, device_token):
        self.device_token = device_token
    
    def validate(self):
        return bool(self.device_token)
    
    def process(self, amount):
        if not self.validate():
            raise ValueError("Invalid device token")
        print(f"Processing Apple Pay: ${amount}")
        return True


class PaymentProcessor:
    """Processes any PaymentMethod - closed for modification."""
    
    def process_payment(self, payment_method: PaymentMethod, amount: float):
        return payment_method.process(amount)


# Usage
processor = PaymentProcessor()

# Different payment methods, same processor
methods = [
    CreditCardPayment("1234567890123456", "12/25", "123"),
    PayPalPayment("user@paypal.com"),
    BitcoinPayment("1BvBMSEYstWetqTFn5Au4m4GFg7xJaNVN2"),
    ApplePayPayment("device_token_abc123"),  # New method works without changes!
]

for method in methods:
    processor.process_payment(method, 99.99)
```

## L - Liskov Substitution Principle (LSP)

> "Objects of a superclass should be replaceable with objects of its subclasses without affecting program correctness."

### The Problem (Violation)

```python
# BAD: Square violates LSP for Rectangle
class Rectangle:
    def __init__(self, width, height):
        self._width = width
        self._height = height
    
    @property
    def width(self):
        return self._width
    
    @width.setter
    def width(self, value):
        self._width = value
    
    @property
    def height(self):
        return self._height
    
    @height.setter
    def height(self, value):
        self._height = value
    
    def area(self):
        return self._width * self._height


class Square(Rectangle):
    def __init__(self, size):
        super().__init__(size, size)
    
    @Rectangle.width.setter
    def width(self, value):
        # Violates LSP: changes both dimensions!
        self._width = value
        self._height = value
    
    @Rectangle.height.setter
    def height(self, value):
        # Violates LSP: changes both dimensions!
        self._width = value
        self._height = value


# This function expects Rectangle behavior
def test_rectangle_area(rect):
    rect.width = 5
    rect.height = 4
    # Expects area = 20
    assert rect.area() == 20, f"Expected 20, got {rect.area()}"


rect = Rectangle(2, 3)
test_rectangle_area(rect)  # Passes

square = Square(2)
test_rectangle_area(square)  # FAILS! area = 16, not 20
```

### The Solution (Following LSP)

```python
from abc import ABC, abstractmethod

# GOOD: Separate interfaces, proper substitutability

class Shape(ABC):
    @abstractmethod
    def area(self):
        pass
    
    @abstractmethod
    def perimeter(self):
        pass


class Rectangle(Shape):
    def __init__(self, width, height):
        self._width = width
        self._height = height
    
    @property
    def width(self):
        return self._width
    
    @property
    def height(self):
        return self._height
    
    def area(self):
        return self._width * self._height
    
    def perimeter(self):
        return 2 * (self._width + self._height)


class Square(Shape):
    """Square is NOT a Rectangle - it's a separate Shape."""
    
    def __init__(self, side):
        self._side = side
    
    @property
    def side(self):
        return self._side
    
    def area(self):
        return self._side ** 2
    
    def perimeter(self):
        return 4 * self._side


# Function works with any Shape
def print_shape_info(shape: Shape):
    print(f"Area: {shape.area()}")
    print(f"Perimeter: {shape.perimeter()}")


# Both work correctly as Shapes
print_shape_info(Rectangle(5, 4))
print_shape_info(Square(5))
```

## I - Interface Segregation Principle (ISP)

> "Clients should not be forced to depend on interfaces they don't use."

### The Problem (Violation)

```python
from abc import ABC, abstractmethod

# BAD: Fat interface forces classes to implement methods they don't need
class Worker(ABC):
    @abstractmethod
    def work(self):
        pass
    
    @abstractmethod
    def eat(self):
        pass
    
    @abstractmethod
    def sleep(self):
        pass
    
    @abstractmethod
    def take_vacation(self):
        pass
    
    @abstractmethod
    def receive_salary(self):
        pass


class HumanWorker(Worker):
    def work(self):
        print("Human working")
    
    def eat(self):
        print("Human eating")
    
    def sleep(self):
        print("Human sleeping")
    
    def take_vacation(self):
        print("Human on vacation")
    
    def receive_salary(self):
        print("Human receiving salary")


class RobotWorker(Worker):
    def work(self):
        print("Robot working")
    
    # Robots don't eat!
    def eat(self):
        raise NotImplementedError("Robots don't eat")
    
    # Robots don't sleep!
    def sleep(self):
        raise NotImplementedError("Robots don't sleep")
    
    # Robots don't take vacation!
    def take_vacation(self):
        raise NotImplementedError("Robots don't take vacation")
    
    # Robots don't receive salary!
    def receive_salary(self):
        raise NotImplementedError("Robots don't receive salary")
```

### The Solution (Following ISP)

```python
from abc import ABC, abstractmethod

# GOOD: Segregated interfaces - implement only what you need

class Workable(ABC):
    @abstractmethod
    def work(self):
        pass


class Eatable(ABC):
    @abstractmethod
    def eat(self):
        pass


class Sleepable(ABC):
    @abstractmethod
    def sleep(self):
        pass


class Employable(ABC):
    @abstractmethod
    def take_vacation(self):
        pass
    
    @abstractmethod
    def receive_salary(self):
        pass


class Maintainable(ABC):
    @abstractmethod
    def perform_maintenance(self):
        pass
    
    @abstractmethod
    def check_battery(self):
        pass


# Human implements human-relevant interfaces
class HumanWorker(Workable, Eatable, Sleepable, Employable):
    def __init__(self, name):
        self.name = name
    
    def work(self):
        print(f"{self.name} is working")
    
    def eat(self):
        print(f"{self.name} is eating lunch")
    
    def sleep(self):
        print(f"{self.name} is sleeping")
    
    def take_vacation(self):
        print(f"{self.name} is on vacation")
    
    def receive_salary(self):
        print(f"{self.name} received salary")


# Robot implements robot-relevant interfaces
class RobotWorker(Workable, Maintainable):
    def __init__(self, model):
        self.model = model
    
    def work(self):
        print(f"Robot {self.model} is working")
    
    def perform_maintenance(self):
        print(f"Robot {self.model} maintenance complete")
    
    def check_battery(self):
        print(f"Robot {self.model} battery at 80%")


# Functions depend only on interfaces they need
def assign_work(worker: Workable):
    worker.work()

def lunch_break(eater: Eatable):
    eater.eat()

def maintenance_check(machine: Maintainable):
    machine.check_battery()
    machine.perform_maintenance()


# Usage
human = HumanWorker("Alice")
robot = RobotWorker("R2D2")

assign_work(human)  # Works
assign_work(robot)  # Works

lunch_break(human)  # Works
# lunch_break(robot)  # Type error - robot isn't Eatable

maintenance_check(robot)  # Works
# maintenance_check(human)  # Type error - human isn't Maintainable
```

## D - Dependency Inversion Principle (DIP)

> "High-level modules should not depend on low-level modules. Both should depend on abstractions."

### The Problem (Violation)

```python
# BAD: High-level module depends on low-level details

class MySQLDatabase:
    def connect(self):
        print("Connecting to MySQL")
    
    def execute(self, query):
        print(f"MySQL executing: {query}")


class UserService:
    def __init__(self):
        # Direct dependency on MySQL - can't easily switch databases!
        self.db = MySQLDatabase()
    
    def create_user(self, name, email):
        self.db.connect()
        self.db.execute(f"INSERT INTO users VALUES ('{name}', '{email}')")


# What if we want to use PostgreSQL or MongoDB?
# We'd have to modify UserService!
```

### The Solution (Following DIP)

```python
from abc import ABC, abstractmethod

# GOOD: Depend on abstractions

# Abstract interface (abstraction)
class Database(ABC):
    @abstractmethod
    def connect(self):
        pass
    
    @abstractmethod
    def execute(self, query):
        pass
    
    @abstractmethod
    def disconnect(self):
        pass


# Low-level modules implement the abstraction
class MySQLDatabase(Database):
    def connect(self):
        print("Connecting to MySQL")
    
    def execute(self, query):
        print(f"MySQL: {query}")
        return {"status": "success"}
    
    def disconnect(self):
        print("Disconnecting from MySQL")


class PostgreSQLDatabase(Database):
    def connect(self):
        print("Connecting to PostgreSQL")
    
    def execute(self, query):
        print(f"PostgreSQL: {query}")
        return {"status": "success"}
    
    def disconnect(self):
        print("Disconnecting from PostgreSQL")


class MongoDatabase(Database):
    def connect(self):
        print("Connecting to MongoDB")
    
    def execute(self, query):
        print(f"MongoDB: {query}")
        return {"status": "success"}
    
    def disconnect(self):
        print("Disconnecting from MongoDB")


# High-level module depends on abstraction
class UserService:
    def __init__(self, database: Database):  # Depends on abstraction!
        self.db = database
    
    def create_user(self, name, email):
        self.db.connect()
        result = self.db.execute(f"INSERT INTO users VALUES ('{name}', '{email}')")
        self.db.disconnect()
        return result
    
    def get_user(self, email):
        self.db.connect()
        result = self.db.execute(f"SELECT * FROM users WHERE email = '{email}'")
        self.db.disconnect()
        return result


# Easy to switch databases!
mysql_service = UserService(MySQLDatabase())
postgres_service = UserService(PostgreSQLDatabase())
mongo_service = UserService(MongoDatabase())

mysql_service.create_user("Alice", "alice@email.com")
postgres_service.create_user("Bob", "bob@email.com")
mongo_service.create_user("Charlie", "charlie@email.com")


# Easy to mock for testing!
class MockDatabase(Database):
    def __init__(self):
        self.queries = []
    
    def connect(self):
        pass
    
    def execute(self, query):
        self.queries.append(query)
        return {"status": "success"}
    
    def disconnect(self):
        pass


def test_user_creation():
    mock_db = MockDatabase()
    service = UserService(mock_db)
    service.create_user("Test", "test@test.com")
    
    assert len(mock_db.queries) == 1
    assert "Test" in mock_db.queries[0]
    print("Test passed!")


test_user_creation()
```

## Complete SOLID Example: E-Commerce System

```python
from abc import ABC, abstractmethod
from datetime import datetime
from typing import List

# ============================================
# INTERFACES (Abstractions)
# ============================================

class PaymentGateway(ABC):
    """Payment interface - DIP, ISP"""
    @abstractmethod
    def charge(self, amount: float) -> bool:
        pass

class NotificationService(ABC):
    """Notification interface - DIP, ISP"""
    @abstractmethod
    def send(self, recipient: str, message: str) -> bool:
        pass

class OrderRepository(ABC):
    """Order storage interface - DIP"""
    @abstractmethod
    def save(self, order) -> str:
        pass
    
    @abstractmethod
    def find(self, order_id: str):
        pass

# ============================================
# ENTITIES (Single Responsibility)
# ============================================

class Product:
    """SRP: Only represents product data"""
    def __init__(self, name: str, price: float, sku: str):
        self.name = name
        self.price = price
        self.sku = sku

class OrderItem:
    """SRP: Only represents an item in an order"""
    def __init__(self, product: Product, quantity: int):
        self.product = product
        self.quantity = quantity
    
    @property
    def subtotal(self) -> float:
        return self.product.price * self.quantity

class Order:
    """SRP: Only represents order data"""
    def __init__(self, customer_email: str):
        self.id = None
        self.customer_email = customer_email
        self.items: List[OrderItem] = []
        self.status = "pending"
        self.created_at = datetime.now()
    
    def add_item(self, item: OrderItem):
        self.items.append(item)
    
    @property
    def total(self) -> float:
        return sum(item.subtotal for item in self.items)

# ============================================
# CONCRETE IMPLEMENTATIONS (OCP - Extensible)
# ============================================

class StripePayment(PaymentGateway):
    def charge(self, amount: float) -> bool:
        print(f"Stripe: Charging ${amount:.2f}")
        return True

class PayPalPayment(PaymentGateway):
    def charge(self, amount: float) -> bool:
        print(f"PayPal: Charging ${amount:.2f}")
        return True

class EmailNotification(NotificationService):
    def send(self, recipient: str, message: str) -> bool:
        print(f"Email to {recipient}: {message}")
        return True

class SMSNotification(NotificationService):
    def send(self, recipient: str, message: str) -> bool:
        print(f"SMS to {recipient}: {message[:50]}...")
        return True

class InMemoryOrderRepository(OrderRepository):
    def __init__(self):
        self.orders = {}
        self._counter = 0
    
    def save(self, order: Order) -> str:
        self._counter += 1
        order.id = f"ORD-{self._counter:04d}"
        self.orders[order.id] = order
        return order.id
    
    def find(self, order_id: str) -> Order:
        return self.orders.get(order_id)

# ============================================
# SERVICES (Depend on Abstractions - DIP)
# ============================================

class PricingService:
    """SRP: Only handles pricing calculations"""
    
    def calculate_tax(self, amount: float, rate: float = 0.1) -> float:
        return amount * rate
    
    def apply_discount(self, amount: float, discount_percent: float) -> float:
        return amount * (1 - discount_percent / 100)

class OrderService:
    """SRP: Only orchestrates order processing"""
    
    def __init__(
        self,
        repository: OrderRepository,       # DIP: Depends on abstraction
        payment: PaymentGateway,           # DIP: Depends on abstraction
        notification: NotificationService,  # DIP: Depends on abstraction
        pricing: PricingService
    ):
        self.repository = repository
        self.payment = payment
        self.notification = notification
        self.pricing = pricing
    
    def place_order(self, order: Order, discount: float = 0) -> str:
        # Calculate final amount
        subtotal = order.total
        discount_amount = self.pricing.apply_discount(subtotal, discount)
        tax = self.pricing.calculate_tax(discount_amount)
        total = discount_amount + tax
        
        # Process payment
        if not self.payment.charge(total):
            raise Exception("Payment failed")
        
        # Save order
        order.status = "confirmed"
        order_id = self.repository.save(order)
        
        # Notify customer
        self.notification.send(
            order.customer_email,
            f"Order {order_id} confirmed! Total: ${total:.2f}"
        )
        
        return order_id

# ============================================
# USAGE
# ============================================

# Create dependencies (can easily swap implementations)
repository = InMemoryOrderRepository()
payment = StripePayment()  # Could be PayPalPayment()
notification = EmailNotification()  # Could be SMSNotification()
pricing = PricingService()

# Create service with injected dependencies
order_service = OrderService(repository, payment, notification, pricing)

# Create and place order
order = Order("customer@example.com")
order.add_item(OrderItem(Product("Laptop", 999.99, "LAP-001"), 1))
order.add_item(OrderItem(Product("Mouse", 29.99, "MOU-001"), 2))

order_id = order_service.place_order(order, discount=10)
print(f"\nOrder placed: {order_id}")

# Easy to extend with new payment method (OCP)
class CryptoPayment(PaymentGateway):
    def charge(self, amount: float) -> bool:
        btc = amount / 45000
        print(f"Crypto: Charging {btc:.8f} BTC")
        return True

# Just inject different implementation - no changes to OrderService!
crypto_order_service = OrderService(repository, CryptoPayment(), notification, pricing)
```

## SOLID Benefits Summary

| Principle | Benefit |
|-----------|---------|
| **SRP** | Easier to understand, test, and maintain |
| **OCP** | Add features without breaking existing code |
| **LSP** | Reliable inheritance, no surprises |
| **ISP** | Focused interfaces, no unused dependencies |
| **DIP** | Loose coupling, easy to test and swap |

## Key Takeaways

1. **SRP**: Each class should have one reason to change
2. **OCP**: Use abstractions and polymorphism for extensibility
3. **LSP**: Subtypes must honor the parent's contract
4. **ISP**: Prefer many small interfaces over one large one
5. **DIP**: Depend on abstractions, inject dependencies

Following SOLID principles leads to code that is:
- **Maintainable**: Easy to understand and modify
- **Testable**: Easy to test in isolation
- **Flexible**: Easy to extend and adapt
- **Reusable**: Components can be used in different contexts
