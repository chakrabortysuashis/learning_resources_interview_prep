# Magic Methods (Dunder Methods)

## What are Magic Methods?

Magic methods (also called "dunder" methods for "double underscore") are special methods with names surrounded by double underscores (`__name__`). They allow your objects to integrate with Python's built-in operations.

## The Orchestra Analogy

Think of Python as a conductor, and magic methods as how your object responds to the conductor's cues:

```
Python (Conductor)                    Your Object (Musician)
──────────────────                    ──────────────────────

print(obj)          ──────────►       __str__() → "Human readable"
repr(obj)           ──────────►       __repr__() → "Developer info"
len(obj)            ──────────►       __len__() → 42
obj1 + obj2         ──────────►       __add__() → new object
obj == other        ──────────►       __eq__() → True/False
obj[key]            ──────────►       __getitem__() → value
for x in obj        ──────────►       __iter__() → iterator
with obj            ──────────►       __enter__/__exit__()
```

## Categories of Magic Methods

### 1. Object Representation

```python
class Product:
    """Demonstrating representation methods."""
    
    def __init__(self, name, price, sku):
        self.name = name
        self.price = price
        self.sku = sku
    
    def __str__(self):
        """
        Called by str(), print(), and f-strings.
        Should be human-readable.
        """
        return f"{self.name} - ${self.price}"
    
    def __repr__(self):
        """
        Called by repr() and in the REPL.
        Should be unambiguous, ideally valid Python.
        """
        return f"Product('{self.name}', {self.price}, '{self.sku}')"
    
    def __format__(self, format_spec):
        """
        Called by format() and f-strings with format spec.
        """
        if format_spec == "short":
            return self.name
        elif format_spec == "full":
            return f"{self.name} (SKU: {self.sku}) - ${self.price:.2f}"
        return str(self)


product = Product("Laptop", 999.99, "LAP-001")

print(product)              # Laptop - $999.99 (__str__)
print(repr(product))        # Product('Laptop', 999.99, 'LAP-001') (__repr__)
print(f"{product:short}")   # Laptop (__format__)
print(f"{product:full}")    # Laptop (SKU: LAP-001) - $999.99
```

### 2. Comparison Methods

```python
from functools import total_ordering

@total_ordering  # Fills in missing comparison methods
class Version:
    """Version comparison using magic methods."""
    
    def __init__(self, major, minor, patch):
        self.major = major
        self.minor = minor
        self.patch = patch
    
    def __eq__(self, other):
        """v1 == v2"""
        if not isinstance(other, Version):
            return NotImplemented
        return (self.major, self.minor, self.patch) == \
               (other.major, other.minor, other.patch)
    
    def __lt__(self, other):
        """v1 < v2"""
        if not isinstance(other, Version):
            return NotImplemented
        return (self.major, self.minor, self.patch) < \
               (other.major, other.minor, other.patch)
    
    def __hash__(self):
        """Enable use in sets and as dict keys."""
        return hash((self.major, self.minor, self.patch))
    
    def __repr__(self):
        return f"Version({self.major}, {self.minor}, {self.patch})"
    
    def __str__(self):
        return f"{self.major}.{self.minor}.{self.patch}"


v1 = Version(1, 0, 0)
v2 = Version(1, 2, 0)
v3 = Version(2, 0, 0)

print(v1 < v2)   # True
print(v2 <= v3)  # True (filled in by @total_ordering)
print(v1 == Version(1, 0, 0))  # True

# Can use in sets/dicts because we defined __hash__
versions = {v1, v2, v3}
print(sorted(versions))  # [1.0.0, 1.2.0, 2.0.0]
```

### 3. Arithmetic Operations

```python
class Money:
    """Money class with arithmetic operations."""
    
    def __init__(self, amount, currency="USD"):
        self.amount = round(float(amount), 2)
        self.currency = currency
    
    def __add__(self, other):
        """self + other"""
        if isinstance(other, Money):
            if self.currency != other.currency:
                raise ValueError("Cannot add different currencies")
            return Money(self.amount + other.amount, self.currency)
        elif isinstance(other, (int, float)):
            return Money(self.amount + other, self.currency)
        return NotImplemented
    
    def __radd__(self, other):
        """other + self (when other doesn't know how to add)"""
        return self.__add__(other)
    
    def __sub__(self, other):
        """self - other"""
        if isinstance(other, Money):
            if self.currency != other.currency:
                raise ValueError("Cannot subtract different currencies")
            return Money(self.amount - other.amount, self.currency)
        elif isinstance(other, (int, float)):
            return Money(self.amount - other, self.currency)
        return NotImplemented
    
    def __mul__(self, factor):
        """self * factor"""
        if isinstance(factor, (int, float)):
            return Money(self.amount * factor, self.currency)
        return NotImplemented
    
    def __rmul__(self, factor):
        """factor * self"""
        return self.__mul__(factor)
    
    def __truediv__(self, divisor):
        """self / divisor"""
        if isinstance(divisor, (int, float)):
            return Money(self.amount / divisor, self.currency)
        return NotImplemented
    
    def __neg__(self):
        """-self"""
        return Money(-self.amount, self.currency)
    
    def __abs__(self):
        """abs(self)"""
        return Money(abs(self.amount), self.currency)
    
    def __repr__(self):
        return f"Money({self.amount}, '{self.currency}')"
    
    def __str__(self):
        return f"{self.currency} {self.amount:,.2f}"


# Usage
price = Money(100)
tax = Money(8.5)
discount = Money(10)

total = price + tax - discount
print(total)              # USD 98.50

tip = total * 0.15
print(tip)                # USD 14.78

split = total / 2
print(split)              # USD 49.25

print(sum([Money(10), Money(20), Money(30)]))  # USD 60.00 (uses __radd__)
```

### 4. Container Methods

```python
class Playlist:
    """Playlist with container magic methods."""
    
    def __init__(self, name):
        self.name = name
        self._songs = []
    
    def __len__(self):
        """len(playlist)"""
        return len(self._songs)
    
    def __getitem__(self, index):
        """playlist[index] or playlist[start:stop]"""
        return self._songs[index]
    
    def __setitem__(self, index, song):
        """playlist[index] = song"""
        self._songs[index] = song
    
    def __delitem__(self, index):
        """del playlist[index]"""
        del self._songs[index]
    
    def __contains__(self, song):
        """song in playlist"""
        return song in self._songs
    
    def __iter__(self):
        """for song in playlist"""
        return iter(self._songs)
    
    def __reversed__(self):
        """reversed(playlist)"""
        return reversed(self._songs)
    
    def append(self, song):
        self._songs.append(song)
    
    def __repr__(self):
        return f"Playlist('{self.name}', {len(self)} songs)"


playlist = Playlist("Road Trip")
playlist.append("Song A")
playlist.append("Song B")
playlist.append("Song C")

print(len(playlist))           # 3
print(playlist[0])             # Song A
print(playlist[-1])            # Song C
print(playlist[1:])            # ['Song B', 'Song C']
print("Song B" in playlist)    # True

for song in playlist:
    print(f"Playing: {song}")

playlist[1] = "New Song B"
del playlist[0]
```

### 5. Callable Objects

```python
class Multiplier:
    """Callable object that multiplies."""
    
    def __init__(self, factor):
        self.factor = factor
    
    def __call__(self, value):
        """Makes the object callable like a function."""
        return value * self.factor


double = Multiplier(2)
triple = Multiplier(3)

print(double(5))   # 10
print(triple(5))   # 15

# Can use like a function
numbers = [1, 2, 3, 4, 5]
doubled = list(map(double, numbers))
print(doubled)  # [2, 4, 6, 8, 10]
```

### 6. Context Managers

```python
import time

class Timer:
    """Context manager for timing code blocks."""
    
    def __init__(self, name="Timer"):
        self.name = name
        self.start = None
        self.elapsed = None
    
    def __enter__(self):
        """Called when entering 'with' block."""
        self.start = time.time()
        return self  # Value assigned to 'as' variable
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        Called when exiting 'with' block.
        exc_type, exc_val, exc_tb: exception info if error occurred
        Return True to suppress exception, False to propagate
        """
        self.elapsed = time.time() - self.start
        print(f"{self.name}: {self.elapsed:.4f} seconds")
        return False  # Don't suppress exceptions


# Usage
with Timer("Data processing"):
    # Simulate work
    total = sum(range(1000000))

print(f"Result: {total}")

# Timer can capture elapsed time
with Timer("Quick task") as t:
    time.sleep(0.1)
print(f"Captured: {t.elapsed:.4f}s")
```

### 7. Attribute Access

```python
class DynamicObject:
    """Object with dynamic attribute handling."""
    
    def __init__(self, **kwargs):
        self._data = kwargs
    
    def __getattr__(self, name):
        """
        Called when attribute not found normally.
        Only called for missing attributes!
        """
        if name in self._data:
            return self._data[name]
        raise AttributeError(f"'{type(self).__name__}' has no attribute '{name}'")
    
    def __setattr__(self, name, value):
        """Called on every attribute assignment."""
        if name.startswith('_'):
            # Allow setting private attributes normally
            super().__setattr__(name, value)
        else:
            # Store public attributes in _data
            if '_data' not in self.__dict__:
                super().__setattr__('_data', {})
            self._data[name] = value
    
    def __delattr__(self, name):
        """Called when deleting an attribute."""
        if name in self._data:
            del self._data[name]
        else:
            raise AttributeError(f"'{name}' not found")
    
    def __dir__(self):
        """Customize dir() output."""
        return list(self._data.keys()) + ['_data']


obj = DynamicObject(name="Alice", age=30)
print(obj.name)      # Alice (via __getattr__)
obj.city = "NYC"     # Stored in _data
print(obj.city)      # NYC
del obj.age
print(dir(obj))      # ['name', 'city', '_data']
```

## Complete Example: Custom Collection

```python
from collections.abc import MutableSequence

class SortedList:
    """A list that always stays sorted."""
    
    def __init__(self, items=None, key=None, reverse=False):
        self._key = key
        self._reverse = reverse
        self._items = []
        
        if items:
            for item in items:
                self.add(item)
    
    def add(self, item):
        """Add item in sorted position."""
        import bisect
        key_func = self._key or (lambda x: x)
        
        # Find insertion point
        keys = [key_func(x) for x in self._items]
        if self._reverse:
            keys = [-k if isinstance(k, (int, float)) else k for k in keys]
            item_key = -key_func(item) if isinstance(key_func(item), (int, float)) else key_func(item)
        else:
            item_key = key_func(item)
        
        index = bisect.bisect_left(keys, item_key)
        self._items.insert(index, item)
    
    # Length
    def __len__(self):
        return len(self._items)
    
    # Indexing
    def __getitem__(self, index):
        return self._items[index]
    
    # Containment
    def __contains__(self, item):
        return item in self._items
    
    # Iteration
    def __iter__(self):
        return iter(self._items)
    
    # Comparison
    def __eq__(self, other):
        if isinstance(other, SortedList):
            return self._items == other._items
        return self._items == list(other)
    
    # Boolean
    def __bool__(self):
        return len(self._items) > 0
    
    # Representation
    def __repr__(self):
        return f"SortedList({self._items})"
    
    def __str__(self):
        return str(self._items)
    
    # Concatenation (returns new SortedList)
    def __add__(self, other):
        new_list = SortedList(key=self._key, reverse=self._reverse)
        for item in self._items:
            new_list.add(item)
        for item in other:
            new_list.add(item)
        return new_list
    
    # In-place concatenation
    def __iadd__(self, other):
        for item in other:
            self.add(item)
        return self
    
    # Multiplication (repeat)
    def __mul__(self, n):
        new_list = SortedList(key=self._key, reverse=self._reverse)
        for _ in range(n):
            for item in self._items:
                new_list.add(item)
        return new_list


# Usage
numbers = SortedList([5, 2, 8, 1, 9])
print(numbers)          # [1, 2, 5, 8, 9]

numbers.add(3)
numbers.add(7)
print(numbers)          # [1, 2, 3, 5, 7, 8, 9]

print(len(numbers))     # 7
print(numbers[0])       # 1 (min)
print(numbers[-1])      # 9 (max)
print(5 in numbers)     # True

# Operations
more = numbers + [4, 6]
print(more)             # [1, 2, 3, 4, 5, 6, 7, 8, 9]

for num in numbers:
    print(num, end=' ')  # 1 2 3 5 7 8 9
```

## Magic Methods Reference Table

| Category | Method | Triggered By |
|----------|--------|--------------|
| **Creation** | `__new__`, `__init__`, `__del__` | `Class()`, `del obj` |
| **Representation** | `__str__`, `__repr__`, `__format__` | `str()`, `repr()`, `format()` |
| **Comparison** | `__eq__`, `__lt__`, `__le__`, `__gt__`, `__ge__`, `__ne__` | `==`, `<`, `<=`, `>`, `>=`, `!=` |
| **Arithmetic** | `__add__`, `__sub__`, `__mul__`, `__truediv__`, `__floordiv__`, `__mod__`, `__pow__` | `+`, `-`, `*`, `/`, `//`, `%`, `**` |
| **Right Arithmetic** | `__radd__`, `__rsub__`, etc. | When left operand doesn't support operation |
| **In-place** | `__iadd__`, `__isub__`, etc. | `+=`, `-=`, etc. |
| **Unary** | `__neg__`, `__pos__`, `__abs__`, `__invert__` | `-obj`, `+obj`, `abs()`, `~obj` |
| **Container** | `__len__`, `__getitem__`, `__setitem__`, `__delitem__`, `__contains__` | `len()`, `[]`, `del []`, `in` |
| **Iteration** | `__iter__`, `__next__`, `__reversed__` | `for`, `next()`, `reversed()` |
| **Callable** | `__call__` | `obj()` |
| **Context** | `__enter__`, `__exit__` | `with` |
| **Attributes** | `__getattr__`, `__setattr__`, `__delattr__`, `__getattribute__` | Attribute access |
| **Hashing** | `__hash__` | `hash()`, dict keys, sets |
| **Boolean** | `__bool__` | `bool()`, `if obj:` |

## Key Points to Remember

1. **`__str__`** for humans, **`__repr__`** for developers
2. **`NotImplemented`** (not `NotImplementedError`) signals "try other operand"
3. **`@total_ordering`** fills in missing comparison methods
4. **`__getattr__`** only called for missing attributes
5. **`__getattribute__`** called for ALL attribute access (use carefully!)
6. **Context managers** should return `False` from `__exit__` unless suppressing exceptions

## Practice Exercise

Create a `Matrix` class with:
- `__init__`: Initialize from 2D list
- `__add__`, `__sub__`: Matrix addition/subtraction
- `__mul__`: Matrix multiplication and scalar multiplication
- `__getitem__`: Access elements with `matrix[i][j]` or `matrix[i, j]`
- `__repr__`, `__str__`: Display matrix
- `__eq__`: Compare matrices

```python
class Matrix:
    def __init__(self, data):
        self.data = [row[:] for row in data]  # Deep copy
        self.rows = len(data)
        self.cols = len(data[0]) if data else 0
    
    def __repr__(self):
        return f"Matrix({self.data})"
    
    def __str__(self):
        rows = [' '.join(f'{val:>6.2f}' for val in row) for row in self.data]
        return '\n'.join(rows)
    
    def __getitem__(self, key):
        if isinstance(key, tuple):
            i, j = key
            return self.data[i][j]
        return self.data[key]
    
    def __setitem__(self, key, value):
        if isinstance(key, tuple):
            i, j = key
            self.data[i][j] = value
        else:
            self.data[key] = value
    
    def __eq__(self, other):
        if not isinstance(other, Matrix):
            return False
        return self.data == other.data
    
    def __add__(self, other):
        if self.rows != other.rows or self.cols != other.cols:
            raise ValueError("Matrix dimensions must match")
        result = [[self.data[i][j] + other.data[i][j] 
                   for j in range(self.cols)] 
                  for i in range(self.rows)]
        return Matrix(result)
    
    def __sub__(self, other):
        if self.rows != other.rows or self.cols != other.cols:
            raise ValueError("Matrix dimensions must match")
        result = [[self.data[i][j] - other.data[i][j] 
                   for j in range(self.cols)] 
                  for i in range(self.rows)]
        return Matrix(result)
    
    def __mul__(self, other):
        if isinstance(other, (int, float)):
            # Scalar multiplication
            result = [[self.data[i][j] * other 
                       for j in range(self.cols)] 
                      for i in range(self.rows)]
            return Matrix(result)
        elif isinstance(other, Matrix):
            # Matrix multiplication
            if self.cols != other.rows:
                raise ValueError("Incompatible dimensions for multiplication")
            result = [[sum(self.data[i][k] * other.data[k][j] 
                          for k in range(self.cols))
                       for j in range(other.cols)]
                      for i in range(self.rows)]
            return Matrix(result)
        return NotImplemented
    
    def __rmul__(self, other):
        return self.__mul__(other)


# Test
A = Matrix([[1, 2], [3, 4]])
B = Matrix([[5, 6], [7, 8]])

print("A:")
print(A)
print("\nB:")
print(B)
print("\nA + B:")
print(A + B)
print("\nA * B:")
print(A * B)
print("\nA * 2:")
print(A * 2)
print("\nA[0, 1] =", A[0, 1])
```
