# Properties and Descriptors - Managed Attributes

## What are Properties?

Properties provide a way to **control access** to instance attributes while keeping the syntax clean. They look like regular attributes but execute methods behind the scenes.

## The Thermostat Analogy

Think of a smart thermostat:
- You set a temperature (looks simple)
- Behind the scenes: validation, conversion, HVAC control
- You read the temperature
- Behind the scenes: sensor reading, averaging, unit conversion

```
User Interface (Simple)              Behind the Scenes (Complex)
────────────────────────            ────────────────────────────

thermostat.temp = 72                → Validate range (32-100°F)
                                    → Convert to internal units
                                    → Notify HVAC system
                                    → Log the change

print(thermostat.temp)              → Read sensor values
                                    → Average multiple readings
                                    → Apply calibration
                                    → Return formatted value
```

## Basic Property Syntax

```python
class Circle:
    """Basic property example."""
    
    def __init__(self, radius):
        self._radius = radius  # Private storage
    
    # GETTER: Called when reading circle.radius
    @property
    def radius(self):
        """Get the radius."""
        print("Getting radius")
        return self._radius
    
    # SETTER: Called when assigning circle.radius = value
    @radius.setter
    def radius(self, value):
        """Set the radius with validation."""
        print(f"Setting radius to {value}")
        if value < 0:
            raise ValueError("Radius cannot be negative")
        self._radius = value
    
    # DELETER: Called when using del circle.radius
    @radius.deleter
    def radius(self):
        """Delete the radius."""
        print("Deleting radius")
        del self._radius


# Usage - looks like regular attribute access!
c = Circle(5)

print(c.radius)      # Getting radius → 5
c.radius = 10        # Setting radius to 10
print(c.radius)      # Getting radius → 10

# c.radius = -5      # ValueError: Radius cannot be negative
# del c.radius       # Deleting radius
```

## Read-Only Properties (Computed Attributes)

```python
import math

class Circle:
    """Properties for computed values."""
    
    def __init__(self, radius):
        self._radius = radius
    
    @property
    def radius(self):
        return self._radius
    
    @radius.setter
    def radius(self, value):
        if value < 0:
            raise ValueError("Radius cannot be negative")
        self._radius = value
    
    # READ-ONLY: No setter defined
    @property
    def diameter(self):
        """Computed property - always 2x radius."""
        return self._radius * 2
    
    @property
    def area(self):
        """Computed property - πr²."""
        return math.pi * self._radius ** 2
    
    @property
    def circumference(self):
        """Computed property - 2πr."""
        return 2 * math.pi * self._radius


c = Circle(5)
print(f"Radius: {c.radius}")
print(f"Diameter: {c.diameter}")
print(f"Area: {c.area:.2f}")
print(f"Circumference: {c.circumference:.2f}")

c.radius = 10  # OK - has setter
# c.diameter = 20  # AttributeError: can't set attribute (no setter)
```

## Properties with Validation

```python
class Person:
    """Properties with comprehensive validation."""
    
    def __init__(self, name, age, email):
        # Use setters for validation during __init__
        self.name = name
        self.age = age
        self.email = email
    
    @property
    def name(self):
        return self._name
    
    @name.setter
    def name(self, value):
        if not value or not isinstance(value, str):
            raise ValueError("Name must be a non-empty string")
        if len(value) < 2:
            raise ValueError("Name must be at least 2 characters")
        self._name = value.strip().title()
    
    @property
    def age(self):
        return self._age
    
    @age.setter
    def age(self, value):
        if not isinstance(value, int):
            raise TypeError("Age must be an integer")
        if value < 0 or value > 150:
            raise ValueError("Age must be between 0 and 150")
        self._age = value
    
    @property
    def email(self):
        return self._email
    
    @email.setter
    def email(self, value):
        import re
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        if not re.match(pattern, value):
            raise ValueError("Invalid email format")
        self._email = value.lower()
    
    # Computed property
    @property
    def is_adult(self):
        return self._age >= 18


# Valid creation
person = Person("alice smith", 25, "ALICE@Email.COM")
print(f"Name: {person.name}")    # Alice Smith (formatted)
print(f"Email: {person.email}")  # alice@email.com (lowercased)
print(f"Adult: {person.is_adult}")

# Invalid values raise errors
# Person("", 25, "test@test.com")     # ValueError: Name must be non-empty
# Person("Alice", -5, "test@test.com") # ValueError: Age must be between...
# Person("Alice", 25, "invalid-email") # ValueError: Invalid email format
```

## Caching Expensive Computations

```python
class DataProcessor:
    """Cached property for expensive operations."""
    
    def __init__(self, data):
        self._data = data
        self._stats_cache = None
    
    @property
    def data(self):
        return self._data
    
    @data.setter
    def data(self, value):
        self._data = value
        self._stats_cache = None  # Invalidate cache when data changes
    
    @property
    def statistics(self):
        """Expensive computation - cached until data changes."""
        if self._stats_cache is None:
            print("Computing statistics... (expensive)")
            # Simulate expensive computation
            self._stats_cache = {
                "count": len(self._data),
                "sum": sum(self._data),
                "mean": sum(self._data) / len(self._data),
                "min": min(self._data),
                "max": max(self._data)
            }
        return self._stats_cache


processor = DataProcessor([1, 2, 3, 4, 5])

# First access - computes
print(processor.statistics)  # Computing statistics...

# Second access - uses cache
print(processor.statistics)  # No "Computing" message

# Data changed - cache invalidated
processor.data = [10, 20, 30]
print(processor.statistics)  # Computing statistics... (recomputed)
```

## Using `functools.cached_property`

Python 3.8+ provides built-in caching:

```python
from functools import cached_property
import time

class Report:
    """Using cached_property for lazy, cached computation."""
    
    def __init__(self, data_source):
        self.data_source = data_source
    
    @cached_property
    def expensive_report(self):
        """Computed once, then cached forever."""
        print("Generating report... (takes time)")
        time.sleep(1)  # Simulate slow operation
        return f"Report for {self.data_source}: 100 pages"


report = Report("sales_db")

# First access - slow
print(report.expensive_report)  # Generating report...

# Subsequent access - instant (cached)
print(report.expensive_report)  # No delay

# To invalidate, delete the attribute
del report.expensive_report
print(report.expensive_report)  # Generating report... (recomputed)
```

## Real-World Example: Bank Account

```python
from datetime import datetime
from decimal import Decimal

class BankAccount:
    """Complete bank account with properties."""
    
    MINIMUM_BALANCE = Decimal("100.00")
    
    def __init__(self, owner, initial_balance):
        self._owner = None
        self._balance = Decimal("0")
        self._transactions = []
        self._is_frozen = False
        
        # Use setters for validation
        self.owner = owner
        self.deposit(initial_balance)
    
    @property
    def owner(self):
        return self._owner
    
    @owner.setter
    def owner(self, value):
        if not value or len(value.strip()) < 2:
            raise ValueError("Owner name must be at least 2 characters")
        self._owner = value.strip()
    
    @property
    def balance(self):
        """Read-only balance - can't set directly."""
        return self._balance
    
    @property
    def is_frozen(self):
        return self._is_frozen
    
    @property
    def transactions(self):
        """Return copy of transactions (immutable from outside)."""
        return self._transactions.copy()
    
    # Computed properties
    @property
    def is_above_minimum(self):
        return self._balance >= self.MINIMUM_BALANCE
    
    @property
    def available_balance(self):
        """Balance minus minimum requirement."""
        available = self._balance - self.MINIMUM_BALANCE
        return max(Decimal("0"), available)
    
    @property
    def last_transaction(self):
        return self._transactions[-1] if self._transactions else None
    
    # Methods that modify balance (not properties)
    def deposit(self, amount):
        if self._is_frozen:
            raise RuntimeError("Account is frozen")
        
        amount = Decimal(str(amount))
        if amount <= 0:
            raise ValueError("Deposit must be positive")
        
        self._balance += amount
        self._log_transaction("DEPOSIT", amount)
        return self._balance
    
    def withdraw(self, amount):
        if self._is_frozen:
            raise RuntimeError("Account is frozen")
        
        amount = Decimal(str(amount))
        if amount <= 0:
            raise ValueError("Withdrawal must be positive")
        if amount > self.available_balance:
            raise ValueError(f"Insufficient funds. Available: {self.available_balance}")
        
        self._balance -= amount
        self._log_transaction("WITHDRAWAL", amount)
        return self._balance
    
    def freeze(self):
        self._is_frozen = True
        self._log_transaction("FREEZE", Decimal("0"))
    
    def unfreeze(self):
        self._is_frozen = False
        self._log_transaction("UNFREEZE", Decimal("0"))
    
    def _log_transaction(self, trans_type, amount):
        self._transactions.append({
            "type": trans_type,
            "amount": amount,
            "balance_after": self._balance,
            "timestamp": datetime.now()
        })


# Usage
account = BankAccount("Alice Smith", 1000)

print(f"Balance: ${account.balance}")
print(f"Available: ${account.available_balance}")
print(f"Above minimum: {account.is_above_minimum}")

account.deposit(500)
account.withdraw(200)

print(f"Last transaction: {account.last_transaction}")
print(f"All transactions: {len(account.transactions)}")

# Can't directly modify balance
# account.balance = 1000000  # AttributeError!
# account._balance = 1000000  # Works but violates encapsulation!
```

## Descriptors - The Engine Behind Properties

Properties are actually built using **descriptors**. Understanding descriptors gives you more power:

```python
class Validator:
    """A descriptor that validates values."""
    
    def __init__(self, min_value=None, max_value=None):
        self.min_value = min_value
        self.max_value = max_value
    
    def __set_name__(self, owner, name):
        """Called when descriptor is assigned to class attribute."""
        self.name = name
        self.private_name = f"_{name}"
    
    def __get__(self, obj, objtype=None):
        """Called when attribute is accessed."""
        if obj is None:
            return self
        return getattr(obj, self.private_name, None)
    
    def __set__(self, obj, value):
        """Called when attribute is assigned."""
        if self.min_value is not None and value < self.min_value:
            raise ValueError(f"{self.name} must be >= {self.min_value}")
        if self.max_value is not None and value > self.max_value:
            raise ValueError(f"{self.name} must be <= {self.max_value}")
        setattr(obj, self.private_name, value)


class Product:
    """Using custom descriptor for validation."""
    
    # Descriptors are class attributes
    price = Validator(min_value=0)
    quantity = Validator(min_value=0, max_value=10000)
    rating = Validator(min_value=0, max_value=5)
    
    def __init__(self, name, price, quantity, rating=0):
        self.name = name
        self.price = price        # Uses Validator.__set__
        self.quantity = quantity
        self.rating = rating


# Usage
product = Product("Laptop", 999.99, 50, 4.5)
print(f"{product.name}: ${product.price}")

product.rating = 4.8  # OK
# product.rating = 6  # ValueError: rating must be <= 5
# product.price = -10 # ValueError: price must be >= 0
```

## Type-Checking Descriptor

```python
class TypedAttribute:
    """Descriptor that enforces type."""
    
    def __init__(self, expected_type, default=None):
        self.expected_type = expected_type
        self.default = default
    
    def __set_name__(self, owner, name):
        self.name = name
        self.private_name = f"_{name}"
    
    def __get__(self, obj, objtype=None):
        if obj is None:
            return self
        return getattr(obj, self.private_name, self.default)
    
    def __set__(self, obj, value):
        if not isinstance(value, self.expected_type):
            raise TypeError(
                f"{self.name} must be {self.expected_type.__name__}, "
                f"got {type(value).__name__}"
            )
        setattr(obj, self.private_name, value)


class String(TypedAttribute):
    def __init__(self, default=""):
        super().__init__(str, default)


class Integer(TypedAttribute):
    def __init__(self, default=0):
        super().__init__(int, default)


class Float(TypedAttribute):
    def __init__(self, default=0.0):
        super().__init__((int, float), default)


class Employee:
    """Using type-checking descriptors."""
    
    name = String()
    age = Integer()
    salary = Float()
    
    def __init__(self, name, age, salary):
        self.name = name
        self.age = age
        self.salary = salary


emp = Employee("Alice", 30, 75000.0)
print(f"{emp.name}, {emp.age}, ${emp.salary}")

# Type errors
# Employee("Bob", "thirty", 50000)  # TypeError: age must be int
# Employee("Charlie", 25, "fifty")  # TypeError: salary must be float
```

## Lazy Property Descriptor

```python
class LazyProperty:
    """Descriptor for lazy-loaded, cached properties."""
    
    def __init__(self, function):
        self.function = function
        self.name = function.__name__
    
    def __get__(self, obj, objtype=None):
        if obj is None:
            return self
        
        # Compute and cache in instance __dict__
        value = self.function(obj)
        setattr(obj, self.name, value)  # Replace descriptor with value
        return value


class DataAnalyzer:
    """Using lazy properties for expensive computations."""
    
    def __init__(self, data):
        self._data = data
    
    @LazyProperty
    def sorted_data(self):
        """Expensive: sorts large dataset once."""
        print("Sorting data...")
        return sorted(self._data)
    
    @LazyProperty
    def statistics(self):
        """Expensive: calculates statistics once."""
        print("Calculating statistics...")
        return {
            "mean": sum(self._data) / len(self._data),
            "min": min(self._data),
            "max": max(self._data)
        }


analyzer = DataAnalyzer([5, 2, 8, 1, 9, 3])

# First access - computes
print(analyzer.statistics)  # Calculating statistics...
# Second access - cached (no print)
print(analyzer.statistics)

print(analyzer.sorted_data)  # Sorting data...
print(analyzer.sorted_data)  # Cached
```

## When to Use Properties vs Descriptors

| Use Case | Solution |
|----------|----------|
| Simple getter/setter | `@property` |
| One-off validation | `@property` with setter |
| Reusable validation | Descriptor class |
| Computed values | `@property` (read-only) |
| Cached computation | `@functools.cached_property` |
| Type enforcement (reusable) | Descriptor class |
| Complex attribute logic | Descriptor class |

## Key Points to Remember

1. **Properties** make methods look like attributes
2. **Getters** (`@property`) control read access
3. **Setters** (`@name.setter`) control write access with validation
4. **Computed properties** derive values from other attributes
5. **Descriptors** are reusable property logic
6. **`__get__`, `__set__`, `__delete__`** are the descriptor protocol

## Practice Exercise

Create a `Temperature` class with:
- Property `celsius` with validation (>= -273.15)
- Computed properties `fahrenheit` and `kelvin`
- Bidirectional: setting fahrenheit updates celsius

```python
class Temperature:
    """Temperature with bidirectional properties."""
    
    ABSOLUTE_ZERO = -273.15
    
    def __init__(self, celsius=0):
        self.celsius = celsius
    
    @property
    def celsius(self):
        return self._celsius
    
    @celsius.setter
    def celsius(self, value):
        if value < self.ABSOLUTE_ZERO:
            raise ValueError(f"Temperature cannot be below {self.ABSOLUTE_ZERO}°C")
        self._celsius = value
    
    @property
    def fahrenheit(self):
        return (self._celsius * 9/5) + 32
    
    @fahrenheit.setter
    def fahrenheit(self, value):
        celsius = (value - 32) * 5/9
        self.celsius = celsius  # Use celsius setter for validation
    
    @property
    def kelvin(self):
        return self._celsius + 273.15
    
    @kelvin.setter
    def kelvin(self, value):
        self.celsius = value - 273.15
    
    def __repr__(self):
        return f"Temperature({self._celsius}°C / {self.fahrenheit}°F / {self.kelvin}K)"


# Test
t = Temperature(25)
print(t)  # 25°C / 77°F / 298.15K

t.fahrenheit = 212
print(t)  # 100°C / 212°F / 373.15K

t.kelvin = 0
print(t)  # -273.15°C / -459.67°F / 0K

# t.celsius = -300  # ValueError!
```
