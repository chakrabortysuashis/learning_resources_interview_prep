"""
State Reducers in LangGraph - Working Examples
==============================================

This file demonstrates different reducer patterns and their behavior.
Run each example to see how reducers affect state updates.

Requirements:
    pip install langgraph
"""

import operator
from typing import TypedDict, Annotated, List
from langgraph.graph import StateGraph, END


# =============================================================================
# EXAMPLE 1: Default Behavior (Overwrite)
# =============================================================================
# Without any reducer, values are simply replaced

class SimpleState(TypedDict):
    """State without any reducers - values get overwritten"""
    value: str
    count: int


def node_a(state: SimpleState) -> dict:
    """First node - sets initial values"""
    print(f"  Node A received: {state}")
    return {"value": "from_a", "count": 10}


def node_b(state: SimpleState) -> dict:
    """Second node - overwrites values"""
    print(f"  Node B received: {state}")
    return {"value": "from_b", "count": 20}  # Completely replaces!


def example_1_overwrite():
    """
    Demonstrates default overwrite behavior.

    Flow:
        START -> node_a -> node_b -> END

    Each node's output replaces the previous value entirely.
    """
    print("\n" + "="*60)
    print("EXAMPLE 1: Default Overwrite Behavior")
    print("="*60)

    # Build the graph
    graph = StateGraph(SimpleState)
    graph.add_node("node_a", node_a)
    graph.add_node("node_b", node_b)
    graph.add_edge("__start__", "node_a")
    graph.add_edge("node_a", "node_b")
    graph.add_edge("node_b", END)

    app = graph.compile()

    # Run with initial state
    initial = {"value": "initial", "count": 0}
    print(f"\nInitial state: {initial}")
    print("\nExecution:")

    result = app.invoke(initial)

    print(f"\nFinal state: {result}")
    print("Notice: 'value' and 'count' were overwritten by node_b")

    return result


# =============================================================================
# EXAMPLE 2: List Accumulation with operator.add
# =============================================================================
# The most common pattern - appending to a list

class MessageState(TypedDict):
    """State with a reducer for accumulating messages"""
    messages: Annotated[List[str], operator.add]  # Will append, not replace
    current_speaker: str  # No reducer - will overwrite


def user_node(state: MessageState) -> dict:
    """Simulates user input"""
    return {
        "messages": ["User: Hello, how are you?"],
        "current_speaker": "user"
    }


def assistant_node(state: MessageState) -> dict:
    """Simulates assistant response"""
    return {
        "messages": ["Assistant: I'm doing great, thanks for asking!"],
        "current_speaker": "assistant"
    }


def example_2_list_accumulation():
    """
    Demonstrates list accumulation with operator.add.

    Messages are appended to the list, not replaced.
    current_speaker is overwritten each time.
    """
    print("\n" + "="*60)
    print("EXAMPLE 2: List Accumulation with operator.add")
    print("="*60)

    graph = StateGraph(MessageState)
    graph.add_node("user", user_node)
    graph.add_node("assistant", assistant_node)
    graph.add_edge("__start__", "user")
    graph.add_edge("user", "assistant")
    graph.add_edge("assistant", END)

    app = graph.compile()

    # Start with empty messages
    initial = {"messages": [], "current_speaker": "system"}
    print(f"\nInitial state: {initial}")

    result = app.invoke(initial)

    print(f"\nFinal state:")
    print(f"  messages: {result['messages']}")
    print(f"  current_speaker: {result['current_speaker']}")
    print("\nNotice: messages were APPENDED, current_speaker was OVERWRITTEN")

    return result


# =============================================================================
# EXAMPLE 3: Numeric Accumulation
# =============================================================================
# Using operator.add for numbers

class CounterState(TypedDict):
    """State for counting operations"""
    total: Annotated[int, operator.add]  # Adds numbers together
    operations: Annotated[List[str], operator.add]  # Logs operations


def add_five(state: CounterState) -> dict:
    """Adds 5 to the total"""
    return {
        "total": 5,
        "operations": ["Added 5"]
    }


def add_ten(state: CounterState) -> dict:
    """Adds 10 to the total"""
    return {
        "total": 10,
        "operations": ["Added 10"]
    }


def multiply_by_two(state: CounterState) -> dict:
    """
    Note: This doesn't actually multiply - it adds the current total again.
    This is just to demonstrate that the reducer always ADDS.
    """
    current = state.get("total", 0)
    return {
        "total": current,  # Adding current value = doubling
        "operations": [f"Doubled (added {current})"]
    }


def example_3_numeric_accumulation():
    """
    Demonstrates numeric accumulation.

    Flow: START -> add_five -> add_ten -> multiply_by_two -> END
    Total: 0 + 5 + 10 + 15 = 30
    """
    print("\n" + "="*60)
    print("EXAMPLE 3: Numeric Accumulation")
    print("="*60)

    graph = StateGraph(CounterState)
    graph.add_node("add_five", add_five)
    graph.add_node("add_ten", add_ten)
    graph.add_node("double", multiply_by_two)
    graph.add_edge("__start__", "add_five")
    graph.add_edge("add_five", "add_ten")
    graph.add_edge("add_ten", "double")
    graph.add_edge("double", END)

    app = graph.compile()

    initial = {"total": 0, "operations": ["Started"]}
    print(f"\nInitial state: {initial}")

    result = app.invoke(initial)

    print(f"\nFinal state:")
    print(f"  total: {result['total']}")
    print(f"  operations: {result['operations']}")
    print("\nCalculation: 0 + 5 + 10 + 15 = 30")

    return result


# =============================================================================
# EXAMPLE 4: Custom Reducer Functions
# =============================================================================
# Define your own merge logic

def merge_dicts(current: dict, new: dict) -> dict:
    """
    Custom reducer that merges dictionaries.
    New values override existing keys.
    """
    if current is None:
        return new
    return {**current, **new}


def keep_max(current: int, new: int) -> int:
    """
    Custom reducer that keeps the maximum value.
    """
    if current is None:
        return new
    return max(current, new)


def unique_list(current: List[str], new: List[str]) -> List[str]:
    """
    Custom reducer that only keeps unique items.
    """
    if current is None:
        return new
    combined = current + new
    return list(dict.fromkeys(combined))  # Preserves order, removes duplicates


class CustomReducerState(TypedDict):
    """State with custom reducer functions"""
    metadata: Annotated[dict, merge_dicts]
    high_score: Annotated[int, keep_max]
    tags: Annotated[List[str], unique_list]


def process_step_1(state: CustomReducerState) -> dict:
    """First processing step"""
    return {
        "metadata": {"step": 1, "status": "processing"},
        "high_score": 75,
        "tags": ["initial", "step1"]
    }


def process_step_2(state: CustomReducerState) -> dict:
    """Second processing step"""
    return {
        "metadata": {"step": 2, "data": "some_value"},  # Merges with existing
        "high_score": 50,  # Lower than 75, will be ignored
        "tags": ["step2", "initial"]  # "initial" is duplicate, will be ignored
    }


def process_step_3(state: CustomReducerState) -> dict:
    """Third processing step"""
    return {
        "metadata": {"step": 3, "status": "complete"},  # Updates status
        "high_score": 90,  # Higher! Will be kept
        "tags": ["final", "step3"]
    }


def example_4_custom_reducers():
    """
    Demonstrates custom reducer functions.

    - metadata: Dictionaries are merged
    - high_score: Only the maximum value is kept
    - tags: Duplicates are removed
    """
    print("\n" + "="*60)
    print("EXAMPLE 4: Custom Reducer Functions")
    print("="*60)

    graph = StateGraph(CustomReducerState)
    graph.add_node("step1", process_step_1)
    graph.add_node("step2", process_step_2)
    graph.add_node("step3", process_step_3)
    graph.add_edge("__start__", "step1")
    graph.add_edge("step1", "step2")
    graph.add_edge("step2", "step3")
    graph.add_edge("step3", END)

    app = graph.compile()

    initial = {"metadata": {}, "high_score": 0, "tags": []}
    print(f"\nInitial state: {initial}")

    result = app.invoke(initial)

    print(f"\nFinal state:")
    print(f"  metadata: {result['metadata']}")
    print(f"  high_score: {result['high_score']}")
    print(f"  tags: {result['tags']}")

    print("\nAnalysis:")
    print("  - metadata: All keys merged, 'status' updated to 'complete'")
    print("  - high_score: 90 (highest of 75, 50, 90)")
    print("  - tags: Unique tags only, 'initial' appears once")

    return result


# =============================================================================
# EXAMPLE 5: Conditional Reducer
# =============================================================================
# Reducer that applies logic based on values

def priority_reducer(current: dict, new: dict) -> dict:
    """
    Custom reducer that only updates if new priority is higher.

    Each dict has format: {"priority": int, "value": any}
    """
    if current is None:
        return new
    if new.get("priority", 0) > current.get("priority", 0):
        return new
    return current  # Keep current if priority is not higher


class PriorityState(TypedDict):
    """State with priority-based updates"""
    task: Annotated[dict, priority_reducer]
    log: Annotated[List[str], operator.add]


def low_priority_task(state: PriorityState) -> dict:
    """Submits a low priority task"""
    return {
        "task": {"priority": 1, "value": "Low priority work"},
        "log": ["Submitted low priority task"]
    }


def high_priority_task(state: PriorityState) -> dict:
    """Submits a high priority task"""
    return {
        "task": {"priority": 10, "value": "URGENT: Critical work!"},
        "log": ["Submitted high priority task"]
    }


def medium_priority_task(state: PriorityState) -> dict:
    """Submits a medium priority task (won't override high)"""
    return {
        "task": {"priority": 5, "value": "Medium priority work"},
        "log": ["Submitted medium priority task"]
    }


def example_5_conditional_reducer():
    """
    Demonstrates a conditional reducer.

    Tasks are only replaced if the new priority is higher.
    Flow: low(1) -> high(10) -> medium(5)
    Final task: high(10) because medium(5) < high(10)
    """
    print("\n" + "="*60)
    print("EXAMPLE 5: Conditional (Priority-Based) Reducer")
    print("="*60)

    graph = StateGraph(PriorityState)
    graph.add_node("low", low_priority_task)
    graph.add_node("high", high_priority_task)
    graph.add_node("medium", medium_priority_task)
    graph.add_edge("__start__", "low")
    graph.add_edge("low", "high")
    graph.add_edge("high", "medium")
    graph.add_edge("medium", END)

    app = graph.compile()

    initial = {"task": {"priority": 0, "value": "None"}, "log": []}
    print(f"\nInitial state: task priority = 0")

    result = app.invoke(initial)

    print(f"\nFinal state:")
    print(f"  task: {result['task']}")
    print(f"  log: {result['log']}")
    print("\nNotice: High priority task was kept, medium couldn't override it!")

    return result


# =============================================================================
# MAIN: Run All Examples
# =============================================================================

if __name__ == "__main__":
    print("\n" + "="*60)
    print("       STATE REDUCERS - WORKING EXAMPLES")
    print("="*60)

    # Run all examples
    example_1_overwrite()
    example_2_list_accumulation()
    example_3_numeric_accumulation()
    example_4_custom_reducers()
    example_5_conditional_reducer()

    print("\n" + "="*60)
    print("                 ALL EXAMPLES COMPLETE")
    print("="*60)
    print("""

    KEY TAKEAWAYS:

    1. Default behavior is OVERWRITE
    2. operator.add APPENDS lists and ADDS numbers
    3. Custom reducers give you full control
    4. Reducers receive (current, new) and return combined
    5. Use Annotated[Type, reducer] to specify behavior

    NEXT: See 03_annotated_state.md for more on the Annotated pattern

    """)


# =============================================================================
# 📌 INTERVIEW TIP
# =============================================================================
"""
INTERVIEW QUESTION: "How would you implement a state field that only keeps
the most recent N items?"

ANSWER: Create a custom reducer that limits the list size:

```python
def last_n_items(n: int):
    def reducer(current: list, new: list) -> list:
        combined = (current or []) + (new or [])
        return combined[-n:]  # Keep only last n items
    return reducer

class State(TypedDict):
    recent_messages: Annotated[List[str], last_n_items(10)]
```

This demonstrates understanding of:
- Reducer factory pattern
- Closures in Python
- Practical state management needs
"""
