"""
Annotated State Examples in LangGraph
======================================

This file demonstrates various patterns for using Annotated types
with reducers in LangGraph state management.

Requirements:
    pip install langgraph langchain-core
"""

from typing import TypedDict, Annotated, List, Optional, Dict, Any
import operator
from langgraph.graph import StateGraph, END


# =============================================================================
# EXAMPLE 1: Basic Chat State with Message Accumulation
# =============================================================================

class ChatMessage(TypedDict):
    """Structure for a chat message"""
    role: str  # "user", "assistant", "system"
    content: str


class BasicChatState(TypedDict):
    """
    Simple chat state demonstrating the most common pattern.

    messages: Accumulates using operator.add
    turn_count: Also accumulates (counts turns)
    current_input: Overwrites (only need latest)
    """
    messages: Annotated[List[ChatMessage], operator.add]
    turn_count: Annotated[int, operator.add]
    current_input: str


def user_input_node(state: BasicChatState) -> dict:
    """
    Simulates receiving user input.

    Returns a partial state update - only the fields being changed.
    """
    user_message: ChatMessage = {
        "role": "user",
        "content": state.get("current_input", "Hello!")
    }

    return {
        "messages": [user_message],  # List! Will be appended
        "turn_count": 1              # Will be added to total
    }


def assistant_response_node(state: BasicChatState) -> dict:
    """
    Simulates assistant generating a response.

    In real implementation, this would call an LLM.
    """
    # Get the last user message
    last_message = state["messages"][-1]["content"] if state["messages"] else ""

    assistant_message: ChatMessage = {
        "role": "assistant",
        "content": f"I received your message: '{last_message}'"
    }

    return {
        "messages": [assistant_message],
        "turn_count": 1
    }


def example_1_basic_chat():
    """
    Run a simple chat example showing message accumulation.

    Expected flow:
    1. User sends "Hi there!"
    2. Messages: [user_msg]
    3. Assistant responds
    4. Messages: [user_msg, assistant_msg]
    """
    print("\n" + "=" * 60)
    print("EXAMPLE 1: Basic Chat with Message Accumulation")
    print("=" * 60)

    # Build graph
    graph = StateGraph(BasicChatState)
    graph.add_node("user_input", user_input_node)
    graph.add_node("assistant", assistant_response_node)
    graph.add_edge("__start__", "user_input")
    graph.add_edge("user_input", "assistant")
    graph.add_edge("assistant", END)

    app = graph.compile()

    # Initial state
    initial_state = {
        "messages": [],
        "turn_count": 0,
        "current_input": "Hi there!"
    }

    print(f"\nInitial state:")
    print(f"  messages: {initial_state['messages']}")
    print(f"  turn_count: {initial_state['turn_count']}")
    print(f"  current_input: '{initial_state['current_input']}'")

    # Run the graph
    result = app.invoke(initial_state)

    print(f"\nFinal state:")
    print(f"  turn_count: {result['turn_count']}")
    print(f"  messages ({len(result['messages'])} total):")
    for msg in result["messages"]:
        print(f"    [{msg['role']}]: {msg['content']}")

    return result


# =============================================================================
# EXAMPLE 2: Agent State with Multiple Accumulators
# =============================================================================

class AgentState(TypedDict):
    """
    More complex state for an agent with tool use.

    Demonstrates multiple accumulating fields.
    """
    # Conversation history - always append
    messages: Annotated[List[Dict], operator.add]

    # Track all tools called - for debugging
    tool_history: Annotated[List[str], operator.add]

    # Accumulate errors - don't lose any
    errors: Annotated[List[str], operator.add]

    # Token usage tracking - sum up
    total_tokens: Annotated[int, operator.add]

    # Current step - overwrite (only care about current)
    current_step: str

    # Is processing complete?
    is_complete: bool


def agent_think(state: AgentState) -> dict:
    """Agent thinking step - decides what to do"""
    print("  [Agent] Thinking...")
    return {
        "messages": [{"role": "assistant", "content": "Let me search for that..."}],
        "current_step": "thinking",
        "total_tokens": 50
    }


def agent_use_tool(state: AgentState) -> dict:
    """Agent uses a tool"""
    print("  [Agent] Using search tool...")
    return {
        "tool_history": ["search_web"],
        "messages": [{"role": "tool", "content": "Search results: ..."}],
        "current_step": "tool_use",
        "total_tokens": 30
    }


def agent_respond(state: AgentState) -> dict:
    """Agent generates final response"""
    print("  [Agent] Generating response...")
    return {
        "messages": [{"role": "assistant", "content": "Based on my search, here's what I found..."}],
        "current_step": "complete",
        "is_complete": True,
        "total_tokens": 100
    }


def example_2_agent_state():
    """
    Demonstrates a multi-step agent with accumulating state.

    Watch how different fields accumulate vs overwrite.
    """
    print("\n" + "=" * 60)
    print("EXAMPLE 2: Agent State with Multiple Accumulators")
    print("=" * 60)

    graph = StateGraph(AgentState)
    graph.add_node("think", agent_think)
    graph.add_node("tool", agent_use_tool)
    graph.add_node("respond", agent_respond)

    graph.add_edge("__start__", "think")
    graph.add_edge("think", "tool")
    graph.add_edge("tool", "respond")
    graph.add_edge("respond", END)

    app = graph.compile()

    initial = {
        "messages": [{"role": "user", "content": "What's the weather today?"}],
        "tool_history": [],
        "errors": [],
        "total_tokens": 0,
        "current_step": "start",
        "is_complete": False
    }

    print(f"\nInitial tokens: {initial['total_tokens']}")
    print("Running agent...\n")

    result = app.invoke(initial)

    print(f"\nFinal state:")
    print(f"  current_step: {result['current_step']}")
    print(f"  is_complete: {result['is_complete']}")
    print(f"  total_tokens: {result['total_tokens']} (accumulated from all steps)")
    print(f"  tool_history: {result['tool_history']}")
    print(f"  messages: {len(result['messages'])} messages")

    return result


# =============================================================================
# EXAMPLE 3: Custom Reducers with Annotated
# =============================================================================

# --- Custom Reducer Functions ---

def unique_append(current: List[str], new: List[str]) -> List[str]:
    """
    Custom reducer: Append only unique items.
    Preserves order, removes duplicates.
    """
    if current is None:
        current = []
    if new is None:
        new = []

    seen = set(current)
    result = list(current)
    for item in new:
        if item not in seen:
            result.append(item)
            seen.add(item)
    return result


def merge_metadata(current: Dict, new: Dict) -> Dict:
    """
    Custom reducer: Deep merge dictionaries.
    New values override existing ones.
    """
    if current is None:
        return new or {}
    if new is None:
        return current

    result = current.copy()
    for key, value in new.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = merge_metadata(result[key], value)
        else:
            result[key] = value
    return result


def keep_highest(current: float, new: float) -> float:
    """
    Custom reducer: Keep the highest value.
    Useful for tracking best scores.
    """
    if current is None:
        return new
    if new is None:
        return current
    return max(current, new)


def sliding_window(max_size: int):
    """
    Reducer factory: Creates a sliding window reducer.

    Args:
        max_size: Maximum items to keep

    Returns:
        A reducer function that keeps only the last max_size items
    """
    def reducer(current: List, new: List) -> List:
        combined = (current or []) + (new or [])
        return combined[-max_size:]
    return reducer


# --- State Definition with Custom Reducers ---

class CustomReducerState(TypedDict):
    """State demonstrating custom reducer functions"""

    # Unique tags only - no duplicates
    tags: Annotated[List[str], unique_append]

    # Nested metadata - deep merged
    metadata: Annotated[Dict[str, Any], merge_metadata]

    # Best confidence score seen
    best_confidence: Annotated[float, keep_highest]

    # Only keep last 3 log entries
    recent_logs: Annotated[List[str], sliding_window(3)]


def process_step_1(state: CustomReducerState) -> dict:
    """First processing step"""
    return {
        "tags": ["important", "processed"],
        "metadata": {"step1": {"status": "done", "time": 100}},
        "best_confidence": 0.75,
        "recent_logs": ["Step 1 started", "Step 1 completed"]
    }


def process_step_2(state: CustomReducerState) -> dict:
    """Second processing step - tests custom reducers"""
    return {
        "tags": ["important", "verified", "step2"],  # "important" is duplicate
        "metadata": {"step2": {"status": "done"}, "step1": {"verified": True}},
        "best_confidence": 0.65,  # Lower, won't replace
        "recent_logs": ["Step 2 started", "Step 2 completed"]
    }


def process_step_3(state: CustomReducerState) -> dict:
    """Third processing step"""
    return {
        "tags": ["final"],
        "metadata": {"step3": {"status": "done"}},
        "best_confidence": 0.95,  # Highest!
        "recent_logs": ["Step 3 completed"]
    }


def example_3_custom_reducers():
    """
    Demonstrates custom reducer functions in action.

    Watch:
    - tags: Duplicates are removed
    - metadata: Dictionaries are deep-merged
    - best_confidence: Only highest value kept
    - recent_logs: Only last 3 entries kept
    """
    print("\n" + "=" * 60)
    print("EXAMPLE 3: Custom Reducers")
    print("=" * 60)

    graph = StateGraph(CustomReducerState)
    graph.add_node("step1", process_step_1)
    graph.add_node("step2", process_step_2)
    graph.add_node("step3", process_step_3)

    graph.add_edge("__start__", "step1")
    graph.add_edge("step1", "step2")
    graph.add_edge("step2", "step3")
    graph.add_edge("step3", END)

    app = graph.compile()

    initial = {
        "tags": [],
        "metadata": {},
        "best_confidence": 0.0,
        "recent_logs": []
    }

    print("\nRunning pipeline with custom reducers...\n")
    result = app.invoke(initial)

    print("Final state:")
    print(f"\n  tags (unique_append):")
    print(f"    {result['tags']}")
    print(f"    Notice: 'important' appears only once despite being added twice")

    print(f"\n  metadata (merge_metadata):")
    for key, value in result['metadata'].items():
        print(f"    {key}: {value}")
    print(f"    Notice: step1 has both 'status' and 'verified' (deep merged)")

    print(f"\n  best_confidence (keep_highest):")
    print(f"    {result['best_confidence']}")
    print(f"    Notice: 0.95 kept (highest of 0.75, 0.65, 0.95)")

    print(f"\n  recent_logs (sliding_window(3)):")
    for log in result['recent_logs']:
        print(f"    - {log}")
    print(f"    Notice: Only last 3 logs kept, earlier ones dropped")

    return result


# =============================================================================
# EXAMPLE 4: Mixed State - Accumulate and Overwrite
# =============================================================================

class MixedState(TypedDict):
    """
    Real-world state mixing accumulated and overwritten fields.

    This pattern is common in production agents.
    """
    # === ACCUMULATED (with reducers) ===
    conversation: Annotated[List[Dict], operator.add]
    debug_log: Annotated[List[str], operator.add]
    api_calls: Annotated[int, operator.add]

    # === OVERWRITTEN (no reducers) ===
    current_phase: str
    last_error: Optional[str]
    final_output: Optional[str]
    config: Dict[str, Any]


def phase_init(state: MixedState) -> dict:
    """Initialize the pipeline"""
    return {
        "current_phase": "init",
        "debug_log": ["Pipeline initialized"],
        "api_calls": 1,
        "config": {"timeout": 30, "retries": 3}
    }


def phase_process(state: MixedState) -> dict:
    """Main processing phase"""
    return {
        "current_phase": "processing",
        "conversation": [{"step": "process", "data": "..."}],
        "debug_log": ["Processing started", "Processing complete"],
        "api_calls": 2,
        # Note: config is NOT returned, so it stays unchanged
    }


def phase_complete(state: MixedState) -> dict:
    """Finalization phase"""
    return {
        "current_phase": "complete",
        "final_output": "Pipeline completed successfully!",
        "debug_log": ["Finalization complete"],
        "api_calls": 1
    }


def example_4_mixed_state():
    """
    Shows real-world pattern of mixed accumulation and overwrite.
    """
    print("\n" + "=" * 60)
    print("EXAMPLE 4: Mixed State (Accumulate + Overwrite)")
    print("=" * 60)

    graph = StateGraph(MixedState)
    graph.add_node("init", phase_init)
    graph.add_node("process", phase_process)
    graph.add_node("complete", phase_complete)

    graph.add_edge("__start__", "init")
    graph.add_edge("init", "process")
    graph.add_edge("process", "complete")
    graph.add_edge("complete", END)

    app = graph.compile()

    initial = {
        "conversation": [],
        "debug_log": [],
        "api_calls": 0,
        "current_phase": "not_started",
        "last_error": None,
        "final_output": None,
        "config": {}
    }

    print("\nRunning pipeline...")
    result = app.invoke(initial)

    print("\nFinal state analysis:")
    print("\n  ACCUMULATED FIELDS:")
    print(f"    api_calls: {result['api_calls']} (1 + 2 + 1 = 4)")
    print(f"    debug_log: {len(result['debug_log'])} entries")
    for log in result['debug_log']:
        print(f"      - {log}")

    print("\n  OVERWRITTEN FIELDS:")
    print(f"    current_phase: {result['current_phase']} (latest value)")
    print(f"    final_output: {result['final_output']}")
    print(f"    config: {result['config']} (set in init, unchanged after)")

    return result


# =============================================================================
# MAIN: Run All Examples
# =============================================================================

if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("      ANNOTATED STATE EXAMPLES")
    print("=" * 60)

    example_1_basic_chat()
    example_2_agent_state()
    example_3_custom_reducers()
    example_4_mixed_state()

    print("\n" + "=" * 60)
    print("              ALL EXAMPLES COMPLETE")
    print("=" * 60)
    print("""
    KEY TAKEAWAYS:

    1. Annotated[Type, reducer] defines merge behavior
    2. operator.add appends lists / adds numbers
    3. Custom reducers give full control
    4. Mix accumulated and overwritten fields as needed
    5. Reducer factories (like sliding_window) are powerful

    NEXT: See 05_state_channels.md for advanced state patterns
    """)


# =============================================================================
# 📌 INTERVIEW TIP
# =============================================================================
"""
INTERVIEW QUESTION: "Design a state schema for a RAG agent that:
- Accumulates retrieved documents
- Tracks query history
- Keeps only the best answer by score
- Limits context to last 5 interactions"

ANSWER:

```python
from typing import TypedDict, Annotated, List
import operator

def keep_best_score(current: dict, new: dict) -> dict:
    if not current or new.get('score', 0) > current.get('score', 0):
        return new
    return current

def last_n(n: int):
    def reducer(current: list, new: list) -> list:
        return ((current or []) + (new or []))[-n:]
    return reducer

class RAGState(TypedDict):
    # Accumulate all retrieved docs for reference
    all_documents: Annotated[List[dict], operator.add]

    # Track query history
    queries: Annotated[List[str], operator.add]

    # Keep only the highest scored answer
    best_answer: Annotated[dict, keep_best_score]

    # Rolling context window
    context_window: Annotated[List[dict], last_n(5)]

    # Current state (overwrite)
    status: str
```

This shows:
- Understanding of accumulation vs replacement
- Custom reducers for specific logic
- Reducer factories for parameterized behavior
- Practical RAG architecture knowledge
"""
