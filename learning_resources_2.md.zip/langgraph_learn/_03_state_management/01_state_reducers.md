# State Reducers in LangGraph

## What is a Reducer?

A **reducer** is a function that determines **how to combine** the current state with new updates from a node. Think of it as the "merge strategy" for your state.

---

## The Problem Reducers Solve

Without reducers, every state update would simply **overwrite** the previous value:

```
Before: {"messages": ["Hello"]}
Update: {"messages": ["How are you?"]}
After:  {"messages": ["How are you?"]}  # "Hello" is lost!
```

With a reducer (like `operator.add`), we can **append** instead:

```
Before: {"messages": ["Hello"]}
Update: {"messages": ["How are you?"]}
After:  {"messages": ["Hello", "How are you?"]}  # Both preserved!
```

---

## How State Updates Work

```
┌─────────────────────────────────────────────────────────────────┐
│                     STATE UPDATE FLOW                           │
└─────────────────────────────────────────────────────────────────┘

     CURRENT STATE              NODE OUTPUT              NEW STATE
  ┌───────────────┐         ┌───────────────┐        ┌───────────────┐
  │ messages: [A] │         │ messages: [B] │        │ messages: [?] │
  │ count: 1      │    +    │ count: 2      │   =    │ count: ?      │
  └───────────────┘         └───────────────┘        └───────────────┘
          │                         │                        │
          │                         │                        │
          └─────────────┬───────────┘                        │
                        │                                    │
                        v                                    │
               ┌─────────────────┐                          │
               │    REDUCER      │                          │
               │                 │                          │
               │ messages: ADD   │ ─────────────────────────┘
               │ count: REPLACE  │
               └─────────────────┘

Result: messages = [A, B] (appended)
        count = 2 (replaced)
```

---

## Default Behavior: Overwrite

By default, LangGraph uses the **overwrite** strategy:

```python
from typing import TypedDict

class State(TypedDict):
    value: str
    items: list

# Node returns partial update
def my_node(state: State) -> dict:
    return {"value": "new_value"}  # Only updates 'value'
    # 'items' remains unchanged
```

```
State Before:  {"value": "old", "items": [1, 2, 3]}
Node Output:   {"value": "new"}
State After:   {"value": "new", "items": [1, 2, 3]}
               ▲                 ▲
               │                 │
           Updated           Unchanged
```

---

## The Append Problem

Consider a chatbot that adds messages:

```
┌────────────────────────────────────────────────────────────────┐
│  WITHOUT REDUCER (Overwrite)                                   │
└────────────────────────────────────────────────────────────────┘

Initial State:
┌─────────────────────────────────────┐
│ messages: ["User: Hello"]           │
└─────────────────────────────────────┘
                    │
                    v
            ┌───────────────┐
            │  Agent Node   │
            │ Returns:      │
            │ ["AI: Hi!"]   │
            └───────────────┘
                    │
                    v
┌─────────────────────────────────────┐
│ messages: ["AI: Hi!"]               │  <-- User message LOST!
└─────────────────────────────────────┘


┌────────────────────────────────────────────────────────────────┐
│  WITH REDUCER (operator.add)                                   │
└────────────────────────────────────────────────────────────────┘

Initial State:
┌─────────────────────────────────────┐
│ messages: ["User: Hello"]           │
└─────────────────────────────────────┘
                    │
                    v
            ┌───────────────┐
            │  Agent Node   │
            │ Returns:      │
            │ ["AI: Hi!"]   │
            └───────────────┘
                    │
                    v
        ┌───────────────────────┐
        │       REDUCER         │
        │   operator.add        │
        │   old + new           │
        └───────────────────────┘
                    │
                    v
┌─────────────────────────────────────┐
│ messages: ["User: Hello", "AI: Hi!"]│  <-- Both preserved!
└─────────────────────────────────────┘
```

---

## Built-in Reducer Functions

LangGraph provides several reducer strategies:

### 1. Overwrite (Default)
```python
# Just returns the new value
def overwrite(current, new):
    return new
```

### 2. Append (operator.add)
```python
import operator

# For lists: concatenates
# For numbers: adds
# For strings: concatenates
operator.add([1, 2], [3, 4])  # [1, 2, 3, 4]
operator.add(5, 3)             # 8
```

### 3. Custom Reducers
```python
# Merge dictionaries
def merge_dicts(current, new):
    return {**current, **new}

# Keep unique items only
def unique_append(current, new):
    return list(set(current + new))

# Conditional update
def max_value(current, new):
    return max(current, new)
```

---

## Reducer Function Signature

Every reducer follows this pattern:

```python
def reducer(current_value, new_value) -> combined_value:
    """
    Args:
        current_value: The existing value in state
        new_value: The value returned by the node
    
    Returns:
        The combined/merged value
    """
    pass
```

```
┌─────────────────────────────────────────────────────────────────┐
│                    REDUCER SIGNATURE                            │
└─────────────────────────────────────────────────────────────────┘

                    reducer(current, new) -> result
                           │       │           │
                           │       │           │
    ┌──────────────────────┘       │           └──────────────────┐
    │                              │                              │
    v                              v                              v
┌────────────┐            ┌────────────┐               ┌────────────┐
│  CURRENT   │            │    NEW     │               │   RESULT   │
│   STATE    │     +      │   UPDATE   │      =        │   STATE    │
│   VALUE    │            │   VALUE    │               │   VALUE    │
└────────────┘            └────────────┘               └────────────┘
```

---

## When to Use Different Reducers

| Scenario | Reducer | Example |
|----------|---------|---------|
| Chat messages | `operator.add` | Append new messages |
| Counter | `operator.add` | Increment count |
| Latest result | Default (overwrite) | Current response |
| Accumulate unique | Custom | Dedup list items |
| Merge configs | Custom | Combine dictionaries |
| Track max/min | Custom | `max(current, new)` |

---

## Reducer Execution Flow

```
┌────────────────────────────────────────────────────────────────────┐
│                    COMPLETE EXECUTION FLOW                         │
└────────────────────────────────────────────────────────────────────┘

    START
      │
      v
┌──────────────┐
│ Initial State│
│ {a: 1, b: []}│
└──────────────┘
      │
      v
┌──────────────┐     ┌─────────────┐
│   Node A     │────>│ Output:     │
│              │     │ {a: 2, b: X}│
└──────────────┘     └─────────────┘
      │                     │
      │         ┌───────────┘
      │         │
      v         v
┌───────────────────────────┐
│        REDUCERS           │
│                           │
│  a: overwrite(1, 2) = 2   │
│  b: add([], [X]) = [X]    │
└───────────────────────────┘
      │
      v
┌──────────────┐
│ State After A│
│ {a: 2, b:[X]}│
└──────────────┘
      │
      v
┌──────────────┐     ┌─────────────┐
│   Node B     │────>│ Output:     │
│              │     │ {a: 3, b: Y}│
└──────────────┘     └─────────────┘
      │                     │
      │         ┌───────────┘
      │         │
      v         v
┌───────────────────────────┐
│        REDUCERS           │
│                           │
│  a: overwrite(2, 3) = 3   │
│  b: add([X], [Y]) = [X,Y] │
└───────────────────────────┘
      │
      v
┌──────────────┐
│  Final State │
│{a: 3, b:[X,Y]}│
└──────────────┘
      │
      v
     END
```

---

## Common Mistakes

### Mistake 1: Forgetting to Return a List
```python
# WRONG - returns a single item, not a list
def bad_node(state):
    return {"messages": "Hello"}  # String, not list!

# CORRECT - return a list for add reducer
def good_node(state):
    return {"messages": ["Hello"]}  # List!
```

### Mistake 2: Mutating State Directly
```python
# WRONG - mutates original state
def bad_node(state):
    state["messages"].append("Hello")  # Direct mutation!
    return state

# CORRECT - return new data
def good_node(state):
    return {"messages": ["Hello"]}  # Reducer handles merging
```

---

## 📌 Interview Tip

> **Q: What is a reducer in LangGraph?**
> 
> **A:** A reducer is a function that defines how to merge state updates from nodes with the current state. It takes two arguments: the current value and the new value, and returns the combined result. The most common reducer is `operator.add` which appends lists together, essential for accumulating messages in chatbots.

---

## 💡 Key Takeaways

1. **Reducers control merge behavior** - They determine how new values combine with existing state
2. **Default is overwrite** - Without a reducer, new values replace old ones
3. **operator.add is most common** - Perfect for accumulating lists (like chat messages)
4. **Custom reducers are powerful** - You can define any merge logic you need
5. **Nodes return partial updates** - Only return what changed; reducers handle the rest

---

## Next Steps

Continue to `02_reducer_examples.py` to see working code examples of different reducer patterns.
