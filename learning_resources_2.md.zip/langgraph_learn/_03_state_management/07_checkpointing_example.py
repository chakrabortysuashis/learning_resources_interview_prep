"""
Checkpointing in LangGraph - Working Examples
==============================================

This file demonstrates checkpointing for state persistence,
conversation continuity, and resumption.

Requirements:
    pip install langgraph langchain-core
"""

from typing import TypedDict, Annotated, List, Optional
import operator
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver


# =============================================================================
# EXAMPLE 1: Basic Checkpointing with MemorySaver
# =============================================================================

class ConversationState(TypedDict):
    """State for a simple conversation"""
    messages: Annotated[List[dict], operator.add]
    turn_count: Annotated[int, operator.add]
    user_name: Optional[str]


def greet_user(state: ConversationState) -> dict:
    """First interaction - greet the user"""
    name = state.get("user_name", "friend")
    return {
        "messages": [{"role": "assistant", "content": f"Hello {name}! How can I help?"}],
        "turn_count": 1
    }


def process_input(state: ConversationState) -> dict:
    """Process user input (simulated)"""
    last_msg = state["messages"][-1]["content"] if state["messages"] else ""
    return {
        "messages": [{"role": "assistant", "content": f"I understand you said: {last_msg}"}],
        "turn_count": 1
    }


def example_1_basic_checkpointing():
    """
    Demonstrates basic checkpointing with MemorySaver.

    Shows how state persists across multiple invocations
    using the same thread_id.
    """
    print("\n" + "=" * 60)
    print("EXAMPLE 1: Basic Checkpointing")
    print("=" * 60)

    # Create the checkpointer
    checkpointer = MemorySaver()

    # Build the graph
    graph = StateGraph(ConversationState)
    graph.add_node("greet", greet_user)
    graph.add_node("process", process_input)
    graph.add_edge("__start__", "greet")
    graph.add_edge("greet", END)  # End after greeting for this example

    # Compile WITH checkpointer
    app = graph.compile(checkpointer=checkpointer)

    # Configuration with thread_id - this identifies our conversation
    config = {"configurable": {"thread_id": "conversation-001"}}

    # First invocation
    print("\n--- First Invocation ---")
    initial_state = {
        "messages": [],
        "turn_count": 0,
        "user_name": "Alice"
    }

    result1 = app.invoke(initial_state, config)
    print(f"Messages: {len(result1['messages'])}")
    print(f"Turn count: {result1['turn_count']}")
    for msg in result1["messages"]:
        print(f"  [{msg['role']}]: {msg['content']}")

    # Second invocation - SAME thread_id, state is loaded from checkpoint
    print("\n--- Second Invocation (same thread) ---")

    # Add a user message to continue the conversation
    new_input = {
        "messages": [{"role": "user", "content": "I need help with Python"}],
        "turn_count": 0,  # Will be added to existing
        "user_name": None
    }

    # Rebuild graph with process node as entry
    graph2 = StateGraph(ConversationState)
    graph2.add_node("process", process_input)
    graph2.add_edge("__start__", "process")
    graph2.add_edge("process", END)
    app2 = graph2.compile(checkpointer=checkpointer)

    result2 = app2.invoke(new_input, config)
    print(f"Messages: {len(result2['messages'])}")
    print(f"Turn count: {result2['turn_count']}")
    for msg in result2["messages"]:
        print(f"  [{msg['role']}]: {msg['content']}")

    print("\nNotice: State accumulated from previous checkpoint!")

    return result2


# =============================================================================
# EXAMPLE 2: Conversation Continuity
# =============================================================================

class ChatState(TypedDict):
    """Chat state with history"""
    messages: Annotated[List[dict], operator.add]
    context: dict


def chat_respond(state: ChatState) -> dict:
    """Generate a response based on conversation history"""
    history_length = len(state["messages"])
    last_user_msg = None

    # Find the last user message
    for msg in reversed(state["messages"]):
        if msg.get("role") == "user":
            last_user_msg = msg["content"]
            break

    response = f"(Turn {history_length + 1}) Response to: '{last_user_msg}'"

    return {
        "messages": [{"role": "assistant", "content": response}]
    }


def example_2_conversation_continuity():
    """
    Shows how checkpointing enables multi-session conversations.

    Simulates a user chatting, closing the app, and continuing later.
    """
    print("\n" + "=" * 60)
    print("EXAMPLE 2: Conversation Continuity Across Sessions")
    print("=" * 60)

    checkpointer = MemorySaver()

    graph = StateGraph(ChatState)
    graph.add_node("respond", chat_respond)
    graph.add_edge("__start__", "respond")
    graph.add_edge("respond", END)

    app = graph.compile(checkpointer=checkpointer)

    thread_id = "user-bob-session-1"
    config = {"configurable": {"thread_id": thread_id}}

    # Session 1: Morning
    print("\n--- SESSION 1 (Morning) ---")

    session1_msg1 = {
        "messages": [{"role": "user", "content": "Hi, I want to book a flight"}],
        "context": {"session": "morning"}
    }
    result1 = app.invoke(session1_msg1, config)
    print(f"User: {session1_msg1['messages'][0]['content']}")
    print(f"Assistant: {result1['messages'][-1]['content']}")

    session1_msg2 = {
        "messages": [{"role": "user", "content": "To Paris, please"}],
        "context": {}
    }
    result2 = app.invoke(session1_msg2, config)
    print(f"User: {session1_msg2['messages'][0]['content']}")
    print(f"Assistant: {result2['messages'][-1]['content']}")

    print("\n[User closes app...]")
    print(f"Total messages in history: {len(result2['messages'])}")

    # Session 2: Afternoon (same thread_id continues conversation)
    print("\n--- SESSION 2 (Afternoon) ---")
    print("[User opens app again with same thread_id]")

    session2_msg1 = {
        "messages": [{"role": "user", "content": "Actually, make it Rome instead"}],
        "context": {}
    }
    result3 = app.invoke(session2_msg1, config)
    print(f"User: {session2_msg1['messages'][0]['content']}")
    print(f"Assistant: {result3['messages'][-1]['content']}")

    print(f"\nFull conversation history ({len(result3['messages'])} messages):")
    for i, msg in enumerate(result3['messages'], 1):
        print(f"  {i}. [{msg['role']}]: {msg['content']}")

    print("\nConversation continued seamlessly across sessions!")

    return result3


# =============================================================================
# EXAMPLE 3: Multiple Threads (Parallel Conversations)
# =============================================================================

def example_3_multiple_threads():
    """
    Demonstrates multiple independent conversations using different thread_ids.

    Each thread_id maintains its own separate state.
    """
    print("\n" + "=" * 60)
    print("EXAMPLE 3: Multiple Independent Threads")
    print("=" * 60)

    checkpointer = MemorySaver()

    graph = StateGraph(ChatState)
    graph.add_node("respond", chat_respond)
    graph.add_edge("__start__", "respond")
    graph.add_edge("respond", END)

    app = graph.compile(checkpointer=checkpointer)

    # Thread for Alice
    alice_config = {"configurable": {"thread_id": "user-alice"}}

    # Thread for Bob
    bob_config = {"configurable": {"thread_id": "user-bob"}}

    print("\n--- Parallel Conversations ---")

    # Alice's first message
    alice_msg1 = {"messages": [{"role": "user", "content": "Hi, I'm Alice!"}], "context": {}}
    alice_result1 = app.invoke(alice_msg1, alice_config)
    print(f"Alice thread - Messages: {len(alice_result1['messages'])}")

    # Bob's first message
    bob_msg1 = {"messages": [{"role": "user", "content": "Hello, I'm Bob!"}], "context": {}}
    bob_result1 = app.invoke(bob_msg1, bob_config)
    print(f"Bob thread - Messages: {len(bob_result1['messages'])}")

    # Alice's second message
    alice_msg2 = {"messages": [{"role": "user", "content": "I need help"}], "context": {}}
    alice_result2 = app.invoke(alice_msg2, alice_config)
    print(f"Alice thread - Messages: {len(alice_result2['messages'])}")

    # Bob's second message
    bob_msg2 = {"messages": [{"role": "user", "content": "Can you help me?"}], "context": {}}
    bob_result2 = app.invoke(bob_msg2, bob_config)
    print(f"Bob thread - Messages: {len(bob_result2['messages'])}")

    # Alice's third message
    alice_msg3 = {"messages": [{"role": "user", "content": "Thanks!"}], "context": {}}
    alice_result3 = app.invoke(alice_msg3, alice_config)
    print(f"Alice thread - Messages: {len(alice_result3['messages'])}")

    print("\n--- Final State Comparison ---")
    print(f"\nAlice's conversation ({len(alice_result3['messages'])} messages):")
    for msg in alice_result3['messages']:
        print(f"  [{msg['role']}]: {msg['content']}")

    print(f"\nBob's conversation ({len(bob_result2['messages'])} messages):")
    for msg in bob_result2['messages']:
        print(f"  [{msg['role']}]: {msg['content']}")

    print("\nNotice: Each thread has completely independent state!")

    return alice_result3, bob_result2


# =============================================================================
# EXAMPLE 4: Inspecting Checkpoint History
# =============================================================================

def example_4_checkpoint_history():
    """
    Shows how to access and inspect checkpoint history.

    Useful for debugging and understanding graph execution.
    """
    print("\n" + "=" * 60)
    print("EXAMPLE 4: Inspecting Checkpoint History")
    print("=" * 60)

    checkpointer = MemorySaver()

    graph = StateGraph(ChatState)
    graph.add_node("respond", chat_respond)
    graph.add_edge("__start__", "respond")
    graph.add_edge("respond", END)

    app = graph.compile(checkpointer=checkpointer)

    thread_id = "history-demo"
    config = {"configurable": {"thread_id": thread_id}}

    # Create some conversation history
    print("\n--- Creating Conversation History ---")

    messages = [
        "First message",
        "Second message",
        "Third message"
    ]

    for i, msg in enumerate(messages, 1):
        input_state = {"messages": [{"role": "user", "content": msg}], "context": {}}
        result = app.invoke(input_state, config)
        print(f"Turn {i}: {msg}")

    # Get state at different points
    print("\n--- Inspecting Checkpoints ---")

    # Get current state
    current_state = app.get_state(config)
    print(f"\nCurrent state:")
    print(f"  Thread ID: {thread_id}")
    print(f"  Messages: {len(current_state.values.get('messages', []))}")

    # List state history
    print("\n--- State History ---")
    history = list(app.get_state_history(config))

    print(f"Found {len(history)} checkpoints:")
    for i, state in enumerate(history):
        msg_count = len(state.values.get('messages', []))
        print(f"  Checkpoint {i + 1}: {msg_count} messages")

    print("\nYou can use this history to:")
    print("  - Debug graph execution")
    print("  - Time travel to previous states")
    print("  - Understand state evolution")

    return history


# =============================================================================
# EXAMPLE 5: Resuming from Specific Checkpoint
# =============================================================================

def example_5_resume_from_checkpoint():
    """
    Demonstrates resuming execution from a specific checkpoint.

    This enables "time travel" and branching from past states.
    """
    print("\n" + "=" * 60)
    print("EXAMPLE 5: Resuming from Specific Checkpoint")
    print("=" * 60)

    checkpointer = MemorySaver()

    graph = StateGraph(ChatState)
    graph.add_node("respond", chat_respond)
    graph.add_edge("__start__", "respond")
    graph.add_edge("respond", END)

    app = graph.compile(checkpointer=checkpointer)

    thread_id = "resume-demo"
    config = {"configurable": {"thread_id": thread_id}}

    # Build up some history
    print("\n--- Building Conversation ---")

    for i, msg in enumerate(["Hello", "I want option A", "Confirm A"], 1):
        input_state = {"messages": [{"role": "user", "content": msg}], "context": {}}
        app.invoke(input_state, config)
        print(f"Turn {i}: {msg}")

    # Get the history
    history = list(app.get_state_history(config))
    print(f"\nCreated {len(history)} checkpoints")

    # Find a checkpoint from the past (e.g., after "Hello" but before choosing option A)
    # History is in reverse order (newest first)
    past_checkpoint = history[-2] if len(history) >= 2 else None

    if past_checkpoint:
        past_config = past_checkpoint.config
        past_messages = past_checkpoint.values.get('messages', [])

        print(f"\n--- Resuming from past checkpoint ---")
        print(f"Past state had {len(past_messages)} messages")

        # Update state at that checkpoint (branching)
        # This is like "going back in time" and making a different choice
        print("\nThis demonstrates how you could branch from a past state!")
        print("In a real app, you could:")
        print("  1. Load a past checkpoint")
        print("  2. Modify the state")
        print("  3. Continue execution from there")

    return history


# =============================================================================
# EXAMPLE 6: Stream with Checkpointing
# =============================================================================

def example_6_streaming_with_checkpoints():
    """
    Shows streaming output while using checkpoints.

    Useful for real-time UI updates.
    """
    print("\n" + "=" * 60)
    print("EXAMPLE 6: Streaming with Checkpointing")
    print("=" * 60)

    checkpointer = MemorySaver()

    # More complex graph with multiple nodes
    def node_a(state: ChatState) -> dict:
        return {"messages": [{"role": "system", "content": "Processing A..."}]}

    def node_b(state: ChatState) -> dict:
        return {"messages": [{"role": "system", "content": "Processing B..."}]}

    def node_c(state: ChatState) -> dict:
        return {"messages": [{"role": "assistant", "content": "Complete!"}]}

    graph = StateGraph(ChatState)
    graph.add_node("a", node_a)
    graph.add_node("b", node_b)
    graph.add_node("c", node_c)
    graph.add_edge("__start__", "a")
    graph.add_edge("a", "b")
    graph.add_edge("b", "c")
    graph.add_edge("c", END)

    app = graph.compile(checkpointer=checkpointer)

    config = {"configurable": {"thread_id": "stream-demo"}}
    initial = {"messages": [{"role": "user", "content": "Start"}], "context": {}}

    print("\n--- Streaming Execution ---")

    # Stream mode "updates" shows node outputs
    print("\nStream mode 'updates' (node outputs):")
    for event in app.stream(initial, config, stream_mode="updates"):
        print(f"  Update: {event}")

    # Get final state from checkpoint
    final_state = app.get_state(config)
    print(f"\nFinal state from checkpoint: {len(final_state.values['messages'])} messages")

    # Demonstrate continuing the conversation
    print("\n--- Continuing Conversation ---")
    follow_up = {"messages": [{"role": "user", "content": "What's next?"}], "context": {}}

    print("Streaming follow-up:")
    for event in app.stream(follow_up, config, stream_mode="updates"):
        print(f"  Update: {event}")

    final_state = app.get_state(config)
    print(f"\nFinal message count: {len(final_state.values['messages'])}")

    return final_state


# =============================================================================
# MAIN: Run All Examples
# =============================================================================

if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("      CHECKPOINTING EXAMPLES")
    print("=" * 60)

    example_1_basic_checkpointing()
    example_2_conversation_continuity()
    example_3_multiple_threads()
    example_4_checkpoint_history()
    example_5_resume_from_checkpoint()
    example_6_streaming_with_checkpoints()

    print("\n" + "=" * 60)
    print("              ALL EXAMPLES COMPLETE")
    print("=" * 60)
    print("""
    KEY TAKEAWAYS:

    1. MemorySaver stores checkpoints in memory (dev only)
    2. thread_id identifies each conversation uniquely
    3. State persists across multiple invoke() calls
    4. get_state_history() enables time travel
    5. Streaming works seamlessly with checkpointing

    FOR PRODUCTION:
    - Use PostgresSaver or SqliteSaver
    - Generate unique thread_ids per user/session
    - Consider checkpoint retention policies

    NEXT: See 08_memory_patterns.md for memory design patterns
    """)


# =============================================================================
# 📌 INTERVIEW TIP
# =============================================================================
"""
INTERVIEW QUESTION: "How would you implement persistent memory for a
production chatbot using LangGraph?"

ANSWER:

```python
from langgraph.checkpoint.postgres import PostgresSaver
from langgraph.graph import StateGraph

# 1. Use PostgreSQL for production persistence
checkpointer = PostgresSaver.from_conn_string(
    "postgresql://user:pass@localhost:5432/chatbot_db"
)

# 2. Design state with proper accumulation
class ChatState(TypedDict):
    messages: Annotated[List[dict], operator.add]  # Accumulate history
    user_id: str  # For filtering/access control

# 3. Compile with checkpointer
app = graph.compile(checkpointer=checkpointer)

# 4. Use consistent thread_id strategy
def get_thread_id(user_id: str, session_id: str) -> str:
    return f"{user_id}-{session_id}"

# 5. Always pass thread_id in config
config = {"configurable": {"thread_id": get_thread_id(user_id, session_id)}}
result = app.invoke(input_state, config)
```

Key considerations:
- Thread ID strategy (per-user, per-session, per-task)
- Checkpoint cleanup/retention policy
- Handling database connection pooling
- Security: validate user access to thread_ids
"""
