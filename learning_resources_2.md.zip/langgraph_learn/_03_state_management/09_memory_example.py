"""
Memory Patterns in LangGraph - Working Examples
================================================

This file demonstrates various memory patterns for building
conversational agents with short-term and long-term memory.

Requirements:
    pip install langgraph langchain-core langchain-openai
"""

from typing import TypedDict, Annotated, List, Dict, Any, Optional
import operator
from datetime import datetime
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver


# =============================================================================
# HELPER: Custom Reducers for Memory Patterns
# =============================================================================

def sliding_window(max_items: int):
    """
    Creates a reducer that keeps only the last N items.

    Useful for:
    - Limiting conversation history
    - Managing context window size
    - Bounded memory usage
    """
    def reducer(current: list, new: list) -> list:
        combined = (current or []) + (new or [])
        return combined[-max_items:]
    return reducer


def merge_dict(current: dict, new: dict) -> dict:
    """
    Merges dictionaries, with new values overriding current.

    Useful for:
    - Updating user profiles
    - Accumulating facts
    - Configuration updates
    """
    if current is None:
        return new or {}
    if new is None:
        return current
    return {**current, **new}


# =============================================================================
# EXAMPLE 1: Basic Conversation Memory
# =============================================================================

class BasicChatState(TypedDict):
    """
    Simple chat state with message accumulation.

    This is the most common pattern - messages append automatically.
    """
    messages: Annotated[List[Dict], operator.add]
    metadata: Dict[str, Any]


def simulate_llm_response(messages: List[Dict]) -> str:
    """
    Simulates an LLM response based on conversation history.

    In production, this would call your actual LLM.
    """
    if not messages:
        return "Hello! How can I help you today?"

    last_user_msg = None
    for msg in reversed(messages):
        if msg.get("role") == "user":
            last_user_msg = msg.get("content", "")
            break

    if last_user_msg:
        # Simple response showing memory works
        msg_count = len([m for m in messages if m.get("role") == "user"])
        return f"I understand '{last_user_msg}'. This is your message #{msg_count}."

    return "I'm here to help!"


def chat_node(state: BasicChatState) -> dict:
    """Main chat node that generates responses"""
    response = simulate_llm_response(state["messages"])
    return {
        "messages": [{"role": "assistant", "content": response}]
    }


def example_1_basic_conversation():
    """
    Demonstrates basic conversation memory.

    Messages accumulate throughout the session.
    """
    print("\n" + "=" * 60)
    print("EXAMPLE 1: Basic Conversation Memory")
    print("=" * 60)

    checkpointer = MemorySaver()

    graph = StateGraph(BasicChatState)
    graph.add_node("chat", chat_node)
    graph.add_edge("__start__", "chat")
    graph.add_edge("chat", END)

    app = graph.compile(checkpointer=checkpointer)

    config = {"configurable": {"thread_id": "basic-chat-1"}}

    # Simulate a conversation
    user_messages = [
        "Hi, my name is Alice",
        "I'm looking for a good restaurant",
        "Something Italian would be nice"
    ]

    print("\n--- Conversation ---")

    for user_msg in user_messages:
        # Add user message and get response
        input_state = {
            "messages": [{"role": "user", "content": user_msg}],
            "metadata": {"timestamp": datetime.now().isoformat()}
        }

        result = app.invoke(input_state, config)

        print(f"\nUser: {user_msg}")
        print(f"Assistant: {result['messages'][-1]['content']}")

    # Show final message history
    final_state = app.get_state(config)
    print(f"\n--- Message History ({len(final_state.values['messages'])} messages) ---")
    for msg in final_state.values['messages']:
        role = msg['role'].upper()
        print(f"  [{role}]: {msg['content'][:50]}...")

    return final_state


# =============================================================================
# EXAMPLE 2: Sliding Window Memory
# =============================================================================

class SlidingWindowState(TypedDict):
    """
    State with limited message history.

    Only keeps the last N messages to manage memory/context size.
    """
    # Only keep last 4 messages (2 turns)
    messages: Annotated[List[Dict], sliding_window(4)]
    total_messages_sent: Annotated[int, operator.add]


def sliding_chat_node(state: SlidingWindowState) -> dict:
    """Chat node for sliding window example"""
    history_size = len(state["messages"])
    response = f"Responding (I can see {history_size} messages in my context)"

    return {
        "messages": [{"role": "assistant", "content": response}],
        "total_messages_sent": 1
    }


def example_2_sliding_window():
    """
    Demonstrates sliding window memory.

    Old messages are dropped to maintain bounded context.
    """
    print("\n" + "=" * 60)
    print("EXAMPLE 2: Sliding Window Memory (max 4 messages)")
    print("=" * 60)

    checkpointer = MemorySaver()

    graph = StateGraph(SlidingWindowState)
    graph.add_node("chat", sliding_chat_node)
    graph.add_edge("__start__", "chat")
    graph.add_edge("chat", END)

    app = graph.compile(checkpointer=checkpointer)

    config = {"configurable": {"thread_id": "sliding-window-1"}}

    # Send many messages
    for i in range(6):
        input_state = {
            "messages": [{"role": "user", "content": f"Message {i + 1}"}],
            "total_messages_sent": 1
        }

        result = app.invoke(input_state, config)

        visible_msgs = len(result['messages'])
        total_sent = result['total_messages_sent']

        print(f"Turn {i + 1}: Visible messages = {visible_msgs}, Total sent = {total_sent}")

    # Show what's in the window
    final_state = app.get_state(config)
    print("\n--- Current Window Contents ---")
    for msg in final_state.values['messages']:
        print(f"  [{msg['role']}]: {msg['content']}")

    print("\nNotice: Only the 4 most recent messages are kept!")
    print(f"Total messages sent: {final_state.values['total_messages_sent']}")

    return final_state


# =============================================================================
# EXAMPLE 3: User Profile Memory (Long-Term)
# =============================================================================

# Simulated persistent storage (in production: database, Redis, etc.)
USER_PROFILES_DB: Dict[str, Dict] = {}


class ProfileMemoryState(TypedDict):
    """
    State that includes both conversation and user profile.

    Profile is loaded at start and saved at end.
    """
    messages: Annotated[List[Dict], operator.add]
    user_id: str
    user_profile: Annotated[Dict, merge_dict]
    extracted_facts: Annotated[List[str], operator.add]


def load_profile_node(state: ProfileMemoryState) -> dict:
    """Load user profile from long-term storage"""
    user_id = state.get("user_id", "unknown")

    # Load from "database"
    profile = USER_PROFILES_DB.get(user_id, {
        "name": None,
        "preferences": {},
        "facts": [],
        "interaction_count": 0
    })

    print(f"  [Memory] Loaded profile for {user_id}: {profile}")

    return {
        "user_profile": profile,
        "messages": [{"role": "system", "content": f"User profile loaded: {profile}"}]
    }


def extract_facts_node(state: ProfileMemoryState) -> dict:
    """
    Extract facts from the conversation to remember.

    In production, this could use an LLM to identify important facts.
    """
    facts = []
    profile_updates = {}

    for msg in state["messages"]:
        if msg.get("role") == "user":
            content = msg.get("content", "").lower()

            # Simple fact extraction (use LLM in production)
            if "my name is" in content:
                name = content.split("my name is")[-1].strip().split()[0].title()
                facts.append(f"User's name is {name}")
                profile_updates["name"] = name

            if "i like" in content:
                preference = content.split("i like")[-1].strip()
                facts.append(f"User likes {preference}")
                profile_updates.setdefault("preferences", {})["likes"] = preference

            if "i prefer" in content:
                preference = content.split("i prefer")[-1].strip()
                facts.append(f"User prefers {preference}")
                profile_updates.setdefault("preferences", {})["prefers"] = preference

    if facts:
        print(f"  [Memory] Extracted facts: {facts}")

    return {
        "extracted_facts": facts,
        "user_profile": profile_updates
    }


def save_profile_node(state: ProfileMemoryState) -> dict:
    """Save updated profile to long-term storage"""
    user_id = state.get("user_id", "unknown")
    profile = state.get("user_profile", {})

    # Increment interaction count
    profile["interaction_count"] = profile.get("interaction_count", 0) + 1
    profile["last_interaction"] = datetime.now().isoformat()

    # Save to "database"
    USER_PROFILES_DB[user_id] = profile

    print(f"  [Memory] Saved profile for {user_id}")

    return {
        "messages": [{"role": "system", "content": "Profile saved"}]
    }


def respond_with_memory_node(state: ProfileMemoryState) -> dict:
    """Generate response using profile information"""
    profile = state.get("user_profile", {})
    name = profile.get("name", "there")

    # Personalize response based on profile
    if profile.get("preferences"):
        prefs = profile["preferences"]
        response = f"Hello {name}! Based on what I remember, you {list(prefs.values())[0] if prefs else 'have some preferences'}."
    else:
        response = f"Hello {name}! Tell me about yourself so I can remember you."

    return {
        "messages": [{"role": "assistant", "content": response}]
    }


def example_3_user_profile_memory():
    """
    Demonstrates long-term user profile memory.

    Facts are extracted from conversations and persisted.
    """
    print("\n" + "=" * 60)
    print("EXAMPLE 3: User Profile Memory (Long-Term)")
    print("=" * 60)

    checkpointer = MemorySaver()

    # Build graph with memory nodes
    graph = StateGraph(ProfileMemoryState)
    graph.add_node("load_profile", load_profile_node)
    graph.add_node("respond", respond_with_memory_node)
    graph.add_node("extract_facts", extract_facts_node)
    graph.add_node("save_profile", save_profile_node)

    graph.add_edge("__start__", "load_profile")
    graph.add_edge("load_profile", "respond")
    graph.add_edge("respond", "extract_facts")
    graph.add_edge("extract_facts", "save_profile")
    graph.add_edge("save_profile", END)

    app = graph.compile(checkpointer=checkpointer)

    user_id = "user-123"

    # Session 1: User introduces themselves
    print("\n--- Session 1: First Interaction ---")
    config1 = {"configurable": {"thread_id": f"{user_id}-session-1"}}

    result1 = app.invoke({
        "messages": [{"role": "user", "content": "Hi! My name is Alice and I like Italian food"}],
        "user_id": user_id,
        "user_profile": {},
        "extracted_facts": []
    }, config1)

    print(f"\nAssistant: {[m for m in result1['messages'] if m['role'] == 'assistant'][-1]['content']}")
    print(f"Facts extracted: {result1['extracted_facts']}")

    # Session 2: User returns later (different session, same user)
    print("\n--- Session 2: User Returns Later ---")
    config2 = {"configurable": {"thread_id": f"{user_id}-session-2"}}

    result2 = app.invoke({
        "messages": [{"role": "user", "content": "Hello again!"}],
        "user_id": user_id,
        "user_profile": {},
        "extracted_facts": []
    }, config2)

    print(f"\nAssistant: {[m for m in result2['messages'] if m['role'] == 'assistant'][-1]['content']}")
    print(f"\nStored profile: {USER_PROFILES_DB.get(user_id)}")

    return result2


# =============================================================================
# EXAMPLE 4: Working Memory (Scratchpad)
# =============================================================================

class WorkingMemoryState(TypedDict):
    """
    State with working memory for complex reasoning.

    scratchpad: Temporary notes during processing
    reasoning_steps: Track thought process
    """
    messages: Annotated[List[Dict], operator.add]
    scratchpad: str  # Overwrites each step
    reasoning_steps: Annotated[List[str], operator.add]
    final_answer: Optional[str]


def analyze_request_node(state: WorkingMemoryState) -> dict:
    """First reasoning step: Analyze the request"""
    last_msg = state["messages"][-1]["content"] if state["messages"] else ""

    analysis = f"Analyzing: '{last_msg}'"

    return {
        "scratchpad": analysis,
        "reasoning_steps": [f"Step 1: {analysis}"]
    }


def gather_info_node(state: WorkingMemoryState) -> dict:
    """Second reasoning step: Gather information"""
    # Build on previous scratchpad
    previous = state.get("scratchpad", "")

    new_info = f"Gathering info based on: {previous[:50]}..."

    return {
        "scratchpad": new_info,
        "reasoning_steps": [f"Step 2: {new_info}"]
    }


def formulate_answer_node(state: WorkingMemoryState) -> dict:
    """Final step: Formulate the answer"""
    steps = state.get("reasoning_steps", [])

    answer = f"Based on {len(steps)} reasoning steps, here is my answer..."

    return {
        "scratchpad": "",  # Clear working memory
        "reasoning_steps": [f"Step 3: Formulated answer"],
        "final_answer": answer,
        "messages": [{"role": "assistant", "content": answer}]
    }


def example_4_working_memory():
    """
    Demonstrates working memory (scratchpad) pattern.

    Useful for chain-of-thought reasoning.
    """
    print("\n" + "=" * 60)
    print("EXAMPLE 4: Working Memory (Scratchpad)")
    print("=" * 60)

    graph = StateGraph(WorkingMemoryState)
    graph.add_node("analyze", analyze_request_node)
    graph.add_node("gather", gather_info_node)
    graph.add_node("answer", formulate_answer_node)

    graph.add_edge("__start__", "analyze")
    graph.add_edge("analyze", "gather")
    graph.add_edge("gather", "answer")
    graph.add_edge("answer", END)

    app = graph.compile()

    print("\n--- Processing with Working Memory ---")

    result = app.invoke({
        "messages": [{"role": "user", "content": "What's the best way to learn Python?"}],
        "scratchpad": "",
        "reasoning_steps": [],
        "final_answer": None
    })

    print("\nReasoning Steps:")
    for step in result["reasoning_steps"]:
        print(f"  - {step}")

    print(f"\nFinal Answer: {result['final_answer']}")
    print(f"Scratchpad (cleared): '{result['scratchpad']}'")

    return result


# =============================================================================
# EXAMPLE 5: Complete Memory-Enabled Agent
# =============================================================================

class FullMemoryState(TypedDict):
    """
    Complete state for a memory-enabled conversational agent.

    Combines multiple memory patterns.
    """
    # Session memory (short-term)
    messages: Annotated[List[Dict], sliding_window(20)]

    # User memory (long-term, loaded/saved)
    user_id: str
    user_profile: Annotated[Dict, merge_dict]

    # Working memory (task-specific)
    current_intent: Optional[str]
    context: Dict[str, Any]

    # Metrics
    interaction_count: Annotated[int, operator.add]


def initialize_memory(state: FullMemoryState) -> dict:
    """Load all relevant memory at conversation start"""
    user_id = state.get("user_id", "anonymous")

    # Load user profile
    profile = USER_PROFILES_DB.get(user_id, {
        "name": None,
        "preferences": {},
        "history_summary": ""
    })

    return {
        "user_profile": profile,
        "context": {"initialized": True, "timestamp": datetime.now().isoformat()}
    }


def detect_intent(state: FullMemoryState) -> dict:
    """Detect user intent from the message"""
    last_msg = ""
    for msg in reversed(state["messages"]):
        if msg.get("role") == "user":
            last_msg = msg.get("content", "").lower()
            break

    # Simple intent detection (use NLU/LLM in production)
    if any(word in last_msg for word in ["book", "reserve", "schedule"]):
        intent = "booking"
    elif any(word in last_msg for word in ["help", "how", "what"]):
        intent = "question"
    elif any(word in last_msg for word in ["hi", "hello", "hey"]):
        intent = "greeting"
    else:
        intent = "general"

    return {
        "current_intent": intent,
        "context": {"detected_intent": intent}
    }


def generate_response(state: FullMemoryState) -> dict:
    """Generate response using all available memory"""
    profile = state.get("user_profile", {})
    intent = state.get("current_intent", "general")
    name = profile.get("name", "there")

    responses = {
        "greeting": f"Hello {name}! Great to see you again. How can I help?",
        "booking": f"I'd be happy to help you with a booking, {name}. What would you like to book?",
        "question": f"Good question, {name}! Let me help you with that.",
        "general": f"I understand, {name}. Please tell me more."
    }

    response = responses.get(intent, responses["general"])

    return {
        "messages": [{"role": "assistant", "content": response}],
        "interaction_count": 1
    }


def update_memory(state: FullMemoryState) -> dict:
    """Update long-term memory at end of interaction"""
    user_id = state.get("user_id", "anonymous")
    profile = state.get("user_profile", {})

    # Update interaction count in profile
    profile["total_interactions"] = profile.get("total_interactions", 0) + 1
    profile["last_seen"] = datetime.now().isoformat()

    # Save to storage
    USER_PROFILES_DB[user_id] = profile

    return {"user_profile": profile}


def example_5_complete_agent():
    """
    Demonstrates a complete memory-enabled agent.

    Combines short-term, long-term, and working memory.
    """
    print("\n" + "=" * 60)
    print("EXAMPLE 5: Complete Memory-Enabled Agent")
    print("=" * 60)

    checkpointer = MemorySaver()

    graph = StateGraph(FullMemoryState)
    graph.add_node("init_memory", initialize_memory)
    graph.add_node("detect_intent", detect_intent)
    graph.add_node("respond", generate_response)
    graph.add_node("update_memory", update_memory)

    graph.add_edge("__start__", "init_memory")
    graph.add_edge("init_memory", "detect_intent")
    graph.add_edge("detect_intent", "respond")
    graph.add_edge("respond", "update_memory")
    graph.add_edge("update_memory", END)

    app = graph.compile(checkpointer=checkpointer)

    user_id = "user-456"

    # Pre-populate some user history
    USER_PROFILES_DB[user_id] = {
        "name": "Bob",
        "preferences": {"contact": "email"},
        "total_interactions": 5
    }

    config = {"configurable": {"thread_id": f"{user_id}-main"}}

    print("\n--- Conversation with Full Memory ---")

    conversations = [
        "Hello!",
        "I need help booking a flight",
        "How do I check my reservation?"
    ]

    for user_msg in conversations:
        result = app.invoke({
            "messages": [{"role": "user", "content": user_msg}],
            "user_id": user_id,
            "user_profile": {},
            "current_intent": None,
            "context": {},
            "interaction_count": 0
        }, config)

        print(f"\nUser: {user_msg}")
        print(f"Intent: {result['current_intent']}")
        assistant_msg = [m for m in result["messages"] if m["role"] == "assistant"][-1]
        print(f"Assistant: {assistant_msg['content']}")

    print(f"\n--- Session Stats ---")
    print(f"Messages in context: {len(result['messages'])}")
    print(f"Interactions this session: {result['interaction_count']}")
    print(f"Total user interactions: {USER_PROFILES_DB[user_id]['total_interactions']}")

    return result


# =============================================================================
# MAIN: Run All Examples
# =============================================================================

if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("      MEMORY PATTERNS EXAMPLES")
    print("=" * 60)

    example_1_basic_conversation()
    example_2_sliding_window()
    example_3_user_profile_memory()
    example_4_working_memory()
    example_5_complete_agent()

    print("\n" + "=" * 60)
    print("              ALL EXAMPLES COMPLETE")
    print("=" * 60)
    print("""
    MEMORY PATTERNS SUMMARY:

    1. BASIC CONVERSATION: operator.add accumulates messages
    2. SLIDING WINDOW: Custom reducer limits history size
    3. USER PROFILE: External storage for long-term memory
    4. WORKING MEMORY: Scratchpad for complex reasoning
    5. COMPLETE AGENT: Combines all patterns

    PRODUCTION CONSIDERATIONS:
    - Use PostgresSaver for persistent checkpoints
    - Use Redis/DynamoDB for user profiles
    - Use vector DB for semantic memory search
    - Implement token-aware context management
    - Add memory summarization for long conversations

    This completes the State Management module!
    """)


# =============================================================================
# 📌 INTERVIEW TIP
# =============================================================================
"""
INTERVIEW QUESTION: "Design a memory system for a customer support agent
that remembers past tickets and user preferences."

ANSWER:

```python
from typing import TypedDict, Annotated, List
import operator

class SupportAgentState(TypedDict):
    # Short-term: Current conversation
    messages: Annotated[List[dict], sliding_window(30)]

    # Long-term: User data (loaded from DB)
    user_id: str
    user_profile: dict
    past_tickets: List[dict]  # Recent relevant tickets

    # Working: Current ticket context
    current_ticket_id: str
    ticket_category: str
    sentiment: str

    # RAG: Retrieved similar cases
    similar_cases: List[dict]

# Memory flow:
# 1. On conversation start:
#    - Load user profile from user DB
#    - Query ticket history DB
#    - Vector search for similar past cases
#
# 2. During conversation:
#    - Update working memory (intent, sentiment)
#    - Messages accumulate in sliding window
#
# 3. On ticket resolution:
#    - Save ticket to history
#    - Update user preferences
#    - Index for future retrieval
```

This demonstrates:
- Multi-tier memory architecture
- Appropriate storage for each type
- RAG integration for relevant context
- Practical customer support knowledge
"""
