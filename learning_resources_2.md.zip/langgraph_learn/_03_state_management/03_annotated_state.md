# Annotated State in LangGraph

## What is Annotated?

`Annotated` is a Python typing feature (from `typing` module) that lets you attach **metadata** to type hints. In LangGraph, we use this metadata to specify **reducer functions**.

```python
from typing import Annotated, List
import operator

# Regular type hint - no reducer (default overwrite)
messages: List[str]

# Annotated type hint - with reducer
messages: Annotated[List[str], operator.add]
#         ▲          ▲              ▲
#         │          │              │
#    Annotated   Base Type     Reducer Function
#    wrapper
```

---

## Why Use Annotated?

```
┌────────────────────────────────────────────────────────────────┐
│                   WITHOUT ANNOTATED                            │
└────────────────────────────────────────────────────────────────┘

    TypedDict alone can't specify merge behavior.
    You'd need separate configuration or manual handling.
    
┌────────────────────────────────────────────────────────────────┐
│                   WITH ANNOTATED                               │
└────────────────────────────────────────────────────────────────┘

    Type + Behavior defined together:
    
    class State(TypedDict):
        messages: Annotated[List[str], operator.add]
        #         ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
        #         "This is a List[str] that APPENDS on update"
```

---

## The Syntax Breakdown

```
┌─────────────────────────────────────────────────────────────────┐
│              ANNOTATED TYPE ANATOMY                             │
└─────────────────────────────────────────────────────────────────┘

    Annotated [ List[str]    ,    operator.add ]
       │          │                    │
       │          │                    │
       │          │                    └──────────────────────┐
       │          │                                          │
       │          └───────────────────────────┐              │
       │                                      │              │
       v                                      v              v
┌──────────────┐                    ┌──────────────┐  ┌────────────┐
│   WRAPPER    │                    │  BASE TYPE   │  │  METADATA  │
│              │                    │              │  │  (Reducer) │
│ Annotated[]  │                    │  List[str]   │  │ operator.  │
│              │                    │  int         │  │ add        │
│ Tells Python │                    │  dict        │  │            │
│ "look inside │                    │  str         │  │ custom_fn  │
│ for metadata"│                    │  Any         │  │            │
└──────────────┘                    └──────────────┘  └────────────┘
```

---

## Basic Pattern: The Add Operator

The most common pattern uses `operator.add`:

```python
from typing import TypedDict, Annotated, List
import operator

class ChatState(TypedDict):
    # Messages accumulate (append behavior)
    messages: Annotated[List[str], operator.add]
    
    # Metadata also accumulates
    sources: Annotated[List[str], operator.add]
    
    # Current response is replaced each time
    current_response: str  # No Annotated = overwrite
```

### How operator.add Works

```
┌───────────────────────────────────────────────────────────────┐
│                  operator.add BEHAVIOR                        │
└───────────────────────────────────────────────────────────────┘

For LISTS:
    operator.add([1, 2], [3, 4])
    Result: [1, 2, 3, 4]
    
    ┌─────────┐     ┌─────────┐     ┌─────────────────┐
    │ [1, 2]  │  +  │ [3, 4]  │  =  │ [1, 2, 3, 4]    │
    └─────────┘     └─────────┘     └─────────────────┘

For NUMBERS:
    operator.add(10, 5)
    Result: 15
    
    ┌─────────┐     ┌─────────┐     ┌─────────────────┐
    │   10    │  +  │    5    │  =  │      15         │
    └─────────┘     └─────────┘     └─────────────────┘

For STRINGS:
    operator.add("Hello ", "World")
    Result: "Hello World"
    
    ┌─────────┐     ┌─────────┐     ┌─────────────────┐
    │"Hello " │  +  │"World"  │  =  │ "Hello World"   │
    └─────────┘     └─────────┘     └─────────────────┘
```

---

## Complete State Definition Example

```python
from typing import TypedDict, Annotated, List, Optional
import operator


class AgentState(TypedDict):
    """
    Complete state for a conversational agent.
    
    Demonstrates mixing Annotated and regular fields.
    """
    
    # === ACCUMULATED FIELDS (use Annotated) ===
    
    # Chat history - always append new messages
    messages: Annotated[List[dict], operator.add]
    
    # Tool calls made - track all tools used
    tool_calls: Annotated[List[str], operator.add]
    
    # Errors encountered - accumulate for debugging
    errors: Annotated[List[str], operator.add]
    
    # Total tokens used - sum up across nodes
    total_tokens: Annotated[int, operator.add]
    
    
    # === OVERWRITTEN FIELDS (regular types) ===
    
    # Current step in the workflow
    current_step: str
    
    # Most recent LLM response
    last_response: Optional[str]
    
    # Whether we should continue processing
    should_continue: bool
    
    # Final answer when complete
    final_answer: Optional[str]
```

---

## Execution Flow with Annotated State

```
┌────────────────────────────────────────────────────────────────────┐
│          STATE FLOW WITH ANNOTATED TYPES                          │
└────────────────────────────────────────────────────────────────────┘

INITIAL STATE:
┌──────────────────────────────────────────────────────────────────┐
│  messages: []                    (Annotated[List, operator.add]) │
│  tool_calls: []                  (Annotated[List, operator.add]) │
│  total_tokens: 0                 (Annotated[int, operator.add])  │
│  current_step: "start"           (regular str)                   │
│  should_continue: True           (regular bool)                  │
└──────────────────────────────────────────────────────────────────┘
                                    │
                                    v
┌────────────────────────────────────────┐
│              NODE 1: Agent             │
│                                        │
│  Returns:                              │
│  {                                     │
│    "messages": [{"role": "user"...}],  │
│    "current_step": "processing",       │
│    "total_tokens": 150                 │
│  }                                     │
└────────────────────────────────────────┘
                                    │
                                    v
                        ┌───────────────────────┐
                        │      REDUCERS         │
                        │                       │
                        │ messages: [] + [msg]  │
                        │ total_tokens: 0 + 150 │
                        │ current_step: REPLACE │
                        └───────────────────────┘
                                    │
                                    v
STATE AFTER NODE 1:
┌──────────────────────────────────────────────────────────────────┐
│  messages: [{"role": "user"...}]                                 │
│  tool_calls: []                                                  │
│  total_tokens: 150                                               │
│  current_step: "processing"                                      │
│  should_continue: True                                           │
└──────────────────────────────────────────────────────────────────┘
                                    │
                                    v
┌────────────────────────────────────────┐
│              NODE 2: Tool              │
│                                        │
│  Returns:                              │
│  {                                     │
│    "tool_calls": ["search"],           │
│    "messages": [{"role": "tool"...}],  │
│    "total_tokens": 50                  │
│  }                                     │
└────────────────────────────────────────┘
                                    │
                                    v
                        ┌───────────────────────┐
                        │      REDUCERS         │
                        │                       │
                        │ messages: + [tool_msg]│
                        │ tool_calls: + [search]│
                        │ total_tokens: + 50    │
                        └───────────────────────┘
                                    │
                                    v
STATE AFTER NODE 2:
┌──────────────────────────────────────────────────────────────────┐
│  messages: [{"role": "user"...}, {"role": "tool"...}]            │
│  tool_calls: ["search"]                                          │
│  total_tokens: 200   (150 + 50)                                  │
│  current_step: "processing"                                      │
│  should_continue: True                                           │
└──────────────────────────────────────────────────────────────────┘
```

---

## Custom Reducers with Annotated

You can use any function as a reducer:

```python
from typing import TypedDict, Annotated, List


# Custom reducer: Keep only last 5 items
def last_five(current: List, new: List) -> List:
    combined = (current or []) + (new or [])
    return combined[-5:]  # Keep last 5


# Custom reducer: Merge dictionaries deeply
def deep_merge(current: dict, new: dict) -> dict:
    if current is None:
        return new
    result = current.copy()
    for key, value in new.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = deep_merge(result[key], value)
        else:
            result[key] = value
    return result


# Custom reducer: Keep maximum value
def keep_max(current: int, new: int) -> int:
    return max(current or 0, new or 0)


class AdvancedState(TypedDict):
    # Only keep last 5 messages (sliding window)
    recent_messages: Annotated[List[dict], last_five]
    
    # Deeply merge configuration
    config: Annotated[dict, deep_merge]
    
    # Track highest score
    best_score: Annotated[int, keep_max]
```

---

## The Reducer Contract

Every reducer must follow this contract:

```
┌────────────────────────────────────────────────────────────────┐
│                    REDUCER CONTRACT                            │
└────────────────────────────────────────────────────────────────┘

def reducer(current: T, new: T) -> T:
    """
    ┌─────────────┐
    │   INPUTS    │
    ├─────────────┤
    │ current     │  The existing value in state
    │             │  May be None on first update
    │             │
    │ new         │  The value returned by the node
    │             │  The update to apply
    └─────────────┘
    
    ┌─────────────┐
    │   OUTPUT    │
    ├─────────────┤
    │ return      │  The combined/merged value
    │             │  This becomes the new state
    └─────────────┘
    
    ┌─────────────┐
    │   RULES     │
    ├─────────────┤
    │ 1. Handle None - current may be None initially
    │ 2. Same type - return same type as inputs
    │ 3. Pure function - no side effects
    │ 4. Deterministic - same inputs = same output
    └─────────────┘
    """
    pass
```

---

## Common Patterns

### Pattern 1: Message Accumulation (Most Common)

```python
class ChatState(TypedDict):
    messages: Annotated[List[BaseMessage], operator.add]
```

### Pattern 2: Counter/Accumulator

```python
class MetricsState(TypedDict):
    request_count: Annotated[int, operator.add]
    total_latency: Annotated[float, operator.add]
```

### Pattern 3: Set-Like Behavior (Unique Items)

```python
def unique_items(current: List, new: List) -> List:
    return list(set((current or []) + (new or [])))

class TagState(TypedDict):
    tags: Annotated[List[str], unique_items]
```

### Pattern 4: Sliding Window

```python
def sliding_window(size: int):
    def reducer(current: List, new: List) -> List:
        return ((current or []) + (new or []))[-size:]
    return reducer

class WindowState(TypedDict):
    recent: Annotated[List[str], sliding_window(10)]
```

---

## 📌 Interview Tip

> **Q: Explain how Annotated types work with reducers in LangGraph.**
>
> **A:** `Annotated` is a Python typing feature that lets us attach metadata to types. In LangGraph, we use it to specify how state fields should be updated when nodes return values. The second argument to Annotated is a reducer function that takes (current_value, new_value) and returns the combined result.
>
> The most common pattern is `Annotated[List[str], operator.add]` which appends new items to a list instead of replacing it. This is essential for chat applications where we need to accumulate messages.
>
> Without Annotated, LangGraph uses a default "overwrite" strategy where new values completely replace old ones.

---

## ⚠️ Common Mistakes

### Mistake 1: Forgetting Annotated Import

```python
# WRONG - will cause NameError
messages: Annotated[List[str], operator.add]

# CORRECT - import first
from typing import Annotated, List
import operator

messages: Annotated[List[str], operator.add]
```

### Mistake 2: Wrong Return Type in Node

```python
# WRONG - returning single item instead of list
def node(state):
    return {"messages": "Hello"}  # String!

# CORRECT - return a list
def node(state):
    return {"messages": ["Hello"]}  # List!
```

### Mistake 3: None Handling in Custom Reducers

```python
# WRONG - will crash if current is None
def bad_reducer(current: list, new: list) -> list:
    return current + new  # TypeError if current is None!

# CORRECT - handle None case
def good_reducer(current: list, new: list) -> list:
    return (current or []) + (new or [])
```

---

## 💡 Key Takeaways

1. **Annotated = Type + Behavior** - Combines type hint with update logic
2. **operator.add is your friend** - Works for lists, numbers, and strings
3. **Custom reducers are flexible** - Any function with the right signature works
4. **Handle None** - First update may have None as current value
5. **Keep it pure** - Reducers should have no side effects

---

## Next Steps

See `04_annotated_example.py` for complete working examples of Annotated state patterns.
