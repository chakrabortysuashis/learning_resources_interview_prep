# Checkpointing in LangGraph

## What is Checkpointing?

Checkpointing is the process of **saving the state of your graph** at various points during execution. This enables:

- **Resumption**: Continue from where you left off
- **Time Travel**: Go back to previous states
- **Human-in-the-Loop**: Pause, modify, and resume
- **Fault Tolerance**: Recover from crashes

---

## Why Checkpointing Matters

```
┌────────────────────────────────────────────────────────────────────┐
│                WITHOUT CHECKPOINTING                               │
└────────────────────────────────────────────────────────────────────┘

    User: "Book me a flight"
         │
         v
    ┌─────────────┐     ┌─────────────┐     ┌─────────────┐
    │ Search      │────>│ Select      │────>│ Payment     │
    │ Flights     │     │ Flight      │     │             │
    └─────────────┘     └─────────────┘     └──────┬──────┘
                                                   │
                                            💥 CRASH!
                                                   │
                                                   v
                                         ALL PROGRESS LOST!
                                         Start from scratch


┌────────────────────────────────────────────────────────────────────┐
│                 WITH CHECKPOINTING                                 │
└────────────────────────────────────────────────────────────────────┘

    User: "Book me a flight"
         │
         v
    ┌─────────────┐     ┌─────────────┐     ┌─────────────┐
    │ Search      │────>│ Select      │────>│ Payment     │
    │ Flights     │     │ Flight      │     │             │
    └──────┬──────┘     └──────┬──────┘     └──────┬──────┘
           │                   │                   │
           v                   v                   v
    ┌──────────────────────────────────────────────────────┐
    │              CHECKPOINT STORAGE                       │
    │   [cp1] ──────────> [cp2] ──────────> [cp3]          │
    │   State after      State after       State after      │
    │   search           selection         crash            │
    └──────────────────────────────────────────────────────┘
                                                   │
                                            💥 CRASH!
                                                   │
                                                   v
                                      ✅ Resume from [cp3]!
                                      No work lost!
```

---

## How Checkpointing Works

```
┌────────────────────────────────────────────────────────────────────┐
│                 CHECKPOINT LIFECYCLE                               │
└────────────────────────────────────────────────────────────────────┘

1. GRAPH STARTS
   ─────────────
        │
        v
   ┌────────────────────────────────────┐
   │ Checkpointer creates initial       │
   │ checkpoint with thread_id          │
   └────────────────────────────────────┘
        │
        v
2. NODE EXECUTES
   ─────────────
   ┌─────────────┐
   │   Node A    │
   │ Processes   │
   │ and returns │
   │ updates     │
   └──────┬──────┘
          │
          v
3. STATE UPDATED + CHECKPOINTED
   ─────────────────────────────
   ┌────────────────────────────────────┐
   │ 1. Reducer merges updates          │
   │ 2. New checkpoint created          │
   │ 3. Checkpoint stored               │
   └────────────────────────────────────┘
          │
          v
4. NEXT NODE (repeat 2-3)
   ──────────────────────
          │
          v
5. GRAPH COMPLETES
   ────────────────
   ┌────────────────────────────────────┐
   │ Final checkpoint stored            │
   │ Full history available             │
   └────────────────────────────────────┘
```

---

## Checkpoint Structure

Each checkpoint contains:

```
┌────────────────────────────────────────────────────────────────────┐
│                    CHECKPOINT ANATOMY                              │
└────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────┐
│                      CHECKPOINT                               │
├──────────────────────────────────────────────────────────────┤
│                                                               │
│  thread_id: "conversation-123"                               │
│  ├── Unique identifier for this execution                    │
│                                                               │
│  checkpoint_id: "cp-abc-789"                                 │
│  ├── Unique ID for this specific checkpoint                  │
│                                                               │
│  parent_checkpoint_id: "cp-abc-788"                          │
│  ├── Links to previous checkpoint (history)                  │
│                                                               │
│  channel_values:                                              │
│  ├── messages: [msg1, msg2, msg3]                           │
│  ├── current_step: "processing"                              │
│  └── context: {...}                                          │
│                                                               │
│  metadata:                                                    │
│  ├── step: 3                                                  │
│  ├── created_at: "2024-01-15T10:30:00Z"                      │
│  └── source: "node_a"                                         │
│                                                               │
│  pending_sends: []                                            │
│  ├── Messages waiting to be processed                        │
│                                                               │
└──────────────────────────────────────────────────────────────┘
```

---

## Available Checkpointers

LangGraph provides several checkpointer implementations:

### 1. MemorySaver (Development)

```python
from langgraph.checkpoint.memory import MemorySaver

checkpointer = MemorySaver()
```

| Pros | Cons |
|------|------|
| No setup required | Data lost on restart |
| Fast | Not suitable for production |
| Great for testing | Memory-bound |

### 2. SqliteSaver (Local Persistence)

```python
from langgraph.checkpoint.sqlite import SqliteSaver

# File-based
checkpointer = SqliteSaver.from_conn_string("checkpoints.db")

# In-memory SQLite (for testing)
checkpointer = SqliteSaver.from_conn_string(":memory:")
```

| Pros | Cons |
|------|------|
| Persistent storage | Single machine only |
| Easy setup | Not for distributed systems |
| Good for local dev | Concurrent access limited |

### 3. PostgresSaver (Production)

```python
from langgraph.checkpoint.postgres import PostgresSaver

checkpointer = PostgresSaver.from_conn_string(
    "postgresql://user:pass@localhost/db"
)
```

| Pros | Cons |
|------|------|
| Production-ready | Requires PostgreSQL |
| Scalable | More setup |
| Concurrent access | External dependency |

---

## Setting Up Checkpointing

```
┌────────────────────────────────────────────────────────────────────┐
│                    SETUP PROCESS                                   │
└────────────────────────────────────────────────────────────────────┘

Step 1: Import checkpointer
─────────────────────────────
    from langgraph.checkpoint.memory import MemorySaver
    
Step 2: Create checkpointer instance
────────────────────────────────────
    checkpointer = MemorySaver()
    
Step 3: Compile graph with checkpointer
───────────────────────────────────────
    app = graph.compile(checkpointer=checkpointer)
    
Step 4: Invoke with thread_id
─────────────────────────────
    config = {"configurable": {"thread_id": "unique-id-123"}}
    result = app.invoke(inputs, config)
```

---

## Thread ID: Identifying Conversations

The `thread_id` is crucial - it identifies which conversation/session to continue:

```
┌────────────────────────────────────────────────────────────────────┐
│                    THREAD ISOLATION                                │
└────────────────────────────────────────────────────────────────────┘

Thread ID: "user-alice-chat-1"
┌─────────────────────────────────────────┐
│  Checkpoint 1 -> Checkpoint 2 -> ...    │
│  Alice's first conversation             │
└─────────────────────────────────────────┘

Thread ID: "user-alice-chat-2"
┌─────────────────────────────────────────┐
│  Checkpoint 1 -> Checkpoint 2 -> ...    │
│  Alice's second conversation            │
└─────────────────────────────────────────┘

Thread ID: "user-bob-chat-1"
┌─────────────────────────────────────────┐
│  Checkpoint 1 -> Checkpoint 2 -> ...    │
│  Bob's conversation (completely separate)│
└─────────────────────────────────────────┘
```

---

## Common Use Cases

### Use Case 1: Conversation Continuity

```
┌────────────────────────────────────────────────────────────────────┐
│               CONVERSATION CONTINUITY                              │
└────────────────────────────────────────────────────────────────────┘

Session 1 (Morning):
    User: "Find me a hotel in Paris"
    Agent: "I found 5 hotels. Which one?"
    User: "The second one"
    Agent: "Hotel Lumiere. Shall I book?"
    ────── Session ends, checkpoints saved ──────
    
Session 2 (Afternoon):
    User: "Yes, book it"  <-- Continues from checkpoint!
    Agent: "Booking Hotel Lumiere for you..."
```

### Use Case 2: Human-in-the-Loop

```
┌────────────────────────────────────────────────────────────────────┐
│               HUMAN-IN-THE-LOOP                                    │
└────────────────────────────────────────────────────────────────────┘

    Agent processes request
            │
            v
    ┌─────────────────┐
    │ PAUSE FOR       │ <── Graph saves checkpoint
    │ HUMAN APPROVAL  │     and waits
    └────────┬────────┘
             │
    Human reviews & approves
             │
             v
    ┌─────────────────┐
    │ RESUME FROM     │ <── Load checkpoint
    │ CHECKPOINT      │     continue execution
    └─────────────────┘
```

### Use Case 3: Error Recovery

```
┌────────────────────────────────────────────────────────────────────┐
│                  ERROR RECOVERY                                    │
└────────────────────────────────────────────────────────────────────┘

    ┌────────┐     ┌────────┐     ┌────────┐
    │ Step 1 │────>│ Step 2 │────>│ Step 3 │──── 💥 API Error!
    └────┬───┘     └────┬───┘     └────────┘
         │              │
     [cp-1]          [cp-2]
         
    After API is back:
    ───────────────────
    Load [cp-2] ──────> │ Step 3 │────> ✅ Complete!
                        └────────┘
```

---

## Checkpoint History (Time Travel)

```
┌────────────────────────────────────────────────────────────────────┐
│                  CHECKPOINT HISTORY                                │
└────────────────────────────────────────────────────────────────────┘

thread_id: "task-123"

    [cp-001]        [cp-002]        [cp-003]        [cp-004]
       │               │               │               │
       v               v               v               v
┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐
│ Initial  │───>│ After    │───>│ After    │───>│ After    │
│ state    │    │ Step 1   │    │ Step 2   │    │ Step 3   │
└──────────┘    └──────────┘    └──────────┘    └──────────┘

You can:
- Resume from any checkpoint
- Inspect state at any point
- Branch from previous states
```

---

## Checkpointing with Subgraphs

```
┌────────────────────────────────────────────────────────────────────┐
│              SUBGRAPH CHECKPOINTING                                │
└────────────────────────────────────────────────────────────────────┘

PARENT GRAPH
┌───────────────────────────────────────────────────────────────┐
│   ┌─────────┐                              ┌─────────┐        │
│   │ Node A  │                              │ Node C  │        │
│   └────┬────┘                              └────┬────┘        │
│        │         ┌──────────────────┐          │              │
│        │         │    SUBGRAPH      │          │              │
│        └────────>│  ┌────┐  ┌────┐  │──────────┘              │
│                  │  │ S1 │─>│ S2 │  │                         │
│                  │  └────┘  └────┘  │                         │
│                  └──────────────────┘                         │
│                                                               │
│   Checkpoints saved for:                                      │
│   - Parent graph state                                        │
│   - Subgraph state (nested)                                   │
└───────────────────────────────────────────────────────────────┘
```

---

## Performance Considerations

| Factor | Impact | Recommendation |
|--------|--------|----------------|
| Checkpoint frequency | Every node = more overhead | Default is fine for most |
| State size | Large state = slower saves | Keep state lean |
| Storage backend | Memory > SQLite > Postgres | Match to use case |
| History retention | More history = more storage | Configure retention |

---

## 📌 Interview Tip

> **Q: Why is checkpointing important in LangGraph?**
>
> **A:** Checkpointing is essential for building production-ready AI agents because it enables:
>
> 1. **Fault tolerance** - Recover from crashes without losing work
> 2. **Human-in-the-loop workflows** - Pause for human review and continue
> 3. **Conversation memory** - Continue conversations across sessions
> 4. **Time travel debugging** - Go back to previous states to understand behavior
> 5. **Scalability** - Each thread_id is independent, enabling parallel conversations
>
> The key configuration is the `thread_id` which uniquely identifies each conversation or task, allowing multiple concurrent executions to be tracked independently.

---

## ⚠️ Common Mistakes

### Mistake 1: Forgetting thread_id

```python
# WRONG - will error or create random thread
app.invoke(inputs)

# CORRECT - always specify thread_id
app.invoke(inputs, config={"configurable": {"thread_id": "my-thread"}})
```

### Mistake 2: Using MemorySaver in Production

```python
# WRONG - data lost on restart
checkpointer = MemorySaver()  # Only for development!

# CORRECT - use persistent storage
checkpointer = PostgresSaver.from_conn_string(connection_string)
```

### Mistake 3: Large Objects in State

```python
# WRONG - storing file contents
state = {"file_data": large_binary_content}  # Slow checkpoints!

# CORRECT - store references
state = {"file_path": "/path/to/file"}  # Fast checkpoints!
```

---

## 💡 Key Takeaways

1. **Checkpointing = Persistence** - Saves state between nodes
2. **thread_id identifies sessions** - Each conversation is separate
3. **MemorySaver for dev** - Use Postgres for production
4. **Enables human-in-the-loop** - Pause and resume workflows
5. **Time travel debugging** - Access previous states

---

## Next Steps

See `07_checkpointing_example.py` for working code demonstrating checkpointing in action.
