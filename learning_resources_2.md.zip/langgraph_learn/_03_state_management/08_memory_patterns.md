# Memory Patterns in LangGraph

## What is Agent Memory?

Memory is how agents **retain and use information** across interactions. Just like humans have short-term and long-term memory, AI agents need different memory strategies for different purposes.

---

## Types of Memory

```
┌────────────────────────────────────────────────────────────────────┐
│                    MEMORY TYPES OVERVIEW                          │
└────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                                                                  │
│   ┌──────────────────────┐    ┌──────────────────────┐         │
│   │   SHORT-TERM MEMORY  │    │   LONG-TERM MEMORY   │         │
│   │                      │    │                      │         │
│   │  - Current session   │    │  - Persists forever  │         │
│   │  - Recent messages   │    │  - User preferences  │         │
│   │  - Working context   │    │  - Past interactions │         │
│   │  - Temporary data    │    │  - Learned info      │         │
│   │                      │    │                      │         │
│   │  Lifespan: Session   │    │  Lifespan: Forever   │         │
│   └──────────────────────┘    └──────────────────────┘         │
│                                                                  │
│   ┌──────────────────────┐    ┌──────────────────────┐         │
│   │   WORKING MEMORY     │    │   EPISODIC MEMORY    │         │
│   │                      │    │                      │         │
│   │  - Current task      │    │  - Specific events   │         │
│   │  - Active reasoning  │    │  - Past conversations│         │
│   │  - Scratchpad        │    │  - What happened     │         │
│   │                      │    │                      │         │
│   │  Lifespan: Task      │    │  Lifespan: Forever   │         │
│   └──────────────────────┘    └──────────────────────┘         │
│                                                                  │
│   ┌──────────────────────┐    ┌──────────────────────┐         │
│   │   SEMANTIC MEMORY    │    │   PROCEDURAL MEMORY  │         │
│   │                      │    │                      │         │
│   │  - Facts & knowledge │    │  - How to do things  │         │
│   │  - Relationships     │    │  - Learned skills    │         │
│   │  - Concepts          │    │  - Task patterns     │         │
│   │                      │    │                      │         │
│   │  Lifespan: Forever   │    │  Lifespan: Forever   │         │
│   └──────────────────────┘    └──────────────────────┘         │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## Short-Term vs Long-Term Memory

### Short-Term Memory (Conversation Memory)

```
┌────────────────────────────────────────────────────────────────────┐
│                    SHORT-TERM MEMORY                               │
└────────────────────────────────────────────────────────────────────┘

    ┌─────────────────────────────────────────────────────────────┐
    │                    CURRENT SESSION                          │
    │                                                              │
    │   User: "Find flights to Paris"                             │
    │   Agent: "When do you want to travel?"                      │
    │   User: "Next Monday"                                       │
    │   Agent: "Found 5 flights..."                               │
    │   User: "Book the cheapest"           <-- Can reference     │
    │         ▲                                 "Paris" and       │
    │         │                                 "Monday" from     │
    │         │                                 earlier!          │
    │   ┌─────┴─────┐                                             │
    │   │  Context  │                                             │
    │   │  Window   │  Messages stay in memory during session     │
    │   └───────────┘                                             │
    │                                                              │
    └─────────────────────────────────────────────────────────────┘
    
    Implementation: Annotated[List[BaseMessage], operator.add]
    
    Stored via: Checkpointing (MemorySaver, PostgresSaver, etc.)
```

### Long-Term Memory (Persistent)

```
┌────────────────────────────────────────────────────────────────────┐
│                    LONG-TERM MEMORY                                │
└────────────────────────────────────────────────────────────────────┘

    Session 1 (January):
    ┌──────────────────────────────────────────┐
    │ User: "My name is Alice"                 │
    │ User: "I prefer window seats"            │──────┐
    │ User: "I'm vegetarian"                   │      │
    └──────────────────────────────────────────┘      │
                                                      │
                                                      v
                                            ┌─────────────────┐
                                            │  LONG-TERM      │
                                            │  MEMORY STORE   │
                                            │                 │
                                            │  name: Alice    │
                                            │  seat: window   │
                                            │  diet: veg      │
                                            └────────┬────────┘
                                                     │
    Session 2 (March):                               │
    ┌──────────────────────────────────────────┐     │
    │ User: "Book me a flight"                 │     │
    │ Agent: "Hi Alice! Would you like a       │<────┘
    │        window seat with a vegetarian     │
    │        meal as usual?"                   │
    └──────────────────────────────────────────┘
    
    Implementation: External store (vector DB, key-value store)
```

---

## Memory Patterns in LangGraph

### Pattern 1: Message History (Short-Term)

The most basic and common pattern.

```python
from typing import TypedDict, Annotated, List
import operator

class State(TypedDict):
    messages: Annotated[List[dict], operator.add]

# Messages accumulate automatically during the session
```

```
┌─────────────────────────────────────────────────────────────────┐
│              MESSAGE HISTORY PATTERN                            │
└─────────────────────────────────────────────────────────────────┘

    Node 1 returns: {"messages": [user_msg]}
           │
           v
    State: messages = [user_msg]
           │
           v
    Node 2 returns: {"messages": [assistant_msg]}
           │
           v
    State: messages = [user_msg, assistant_msg]
           │
           v
    Node 3 returns: {"messages": [user_msg_2]}
           │
           v
    State: messages = [user_msg, assistant_msg, user_msg_2]
    
    ✅ Full history preserved automatically
```

### Pattern 2: Sliding Window Memory

Keep only recent messages to manage context length.

```python
def sliding_window(max_messages: int):
    """Keep only the last N messages"""
    def reducer(current: list, new: list) -> list:
        combined = (current or []) + (new or [])
        return combined[-max_messages:]
    return reducer

class State(TypedDict):
    # Only keep last 20 messages
    messages: Annotated[List[dict], sliding_window(20)]
```

```
┌─────────────────────────────────────────────────────────────────┐
│              SLIDING WINDOW PATTERN                             │
└─────────────────────────────────────────────────────────────────┘

    Window size: 3

    Turn 1: [msg1]
    Turn 2: [msg1, msg2]
    Turn 3: [msg1, msg2, msg3]        <-- Window full
    Turn 4: [msg2, msg3, msg4]        <-- msg1 dropped
    Turn 5: [msg3, msg4, msg5]        <-- msg2 dropped
    
    ┌────────────────────────────────────┐
    │ BENEFITS                           │
    │                                    │
    │ ✅ Bounded memory usage            │
    │ ✅ Fits LLM context window         │
    │ ✅ Recent context prioritized      │
    └────────────────────────────────────┘
```

### Pattern 3: Summarized Memory

Compress older messages into summaries.

```
┌─────────────────────────────────────────────────────────────────┐
│              SUMMARIZATION PATTERN                              │
└─────────────────────────────────────────────────────────────────┘

    Full Conversation:
    ┌─────────────────────────────────────────────────────────────┐
    │ msg1 │ msg2 │ msg3 │ msg4 │ msg5 │ msg6 │ msg7 │ msg8 │ msg9│
    └──────┴──────┴──────┴──────┴──────┴──────┴──────┴──────┴─────┘
    
                      │
                      │  After summarization threshold
                      v
    
    ┌────────────────────────┐  ┌──────────────────────────────────┐
    │       SUMMARY          │  │     RECENT MESSAGES              │
    │                        │  │                                  │
    │ "User discussed travel │  │ msg7 │ msg8 │ msg9               │
    │  plans to Paris for    │  │                                  │
    │  business. Prefers     │  │ (Full detail preserved)          │
    │  morning flights..."   │  │                                  │
    └────────────────────────┘  └──────────────────────────────────┘
    
    Combined context sent to LLM:
    [summary] + [recent messages]
```

### Pattern 4: User Profile Memory (Long-Term)

Store and retrieve user-specific information.

```
┌─────────────────────────────────────────────────────────────────┐
│              USER PROFILE PATTERN                               │
└─────────────────────────────────────────────────────────────────┘

    ┌──────────────────┐           ┌──────────────────┐
    │   CONVERSATION   │           │   USER PROFILE   │
    │                  │           │   (Persistent)   │
    │  messages: [...]│            │                  │
    │                  │   <───>   │  preferences: {} │
    │                  │           │  facts: []       │
    │                  │           │  history: []     │
    └──────────────────┘           └──────────────────┘
    
    class State(TypedDict):
        messages: Annotated[List[dict], operator.add]
        user_profile: dict  # Loaded at start, saved at end
```

### Pattern 5: Working Memory (Scratchpad)

Temporary storage for complex reasoning.

```
┌─────────────────────────────────────────────────────────────────┐
│              WORKING MEMORY PATTERN                             │
└─────────────────────────────────────────────────────────────────┘

    class State(TypedDict):
        messages: Annotated[List, operator.add]  # Permanent
        
        # Working memory - cleared after use
        scratchpad: str           # Reasoning notes
        intermediate_results: list # Step-by-step results
        current_hypothesis: str    # Current thinking

    ┌─────────────────────────────────────────────────────────────┐
    │  REASONING NODE                                             │
    │                                                              │
    │  1. Read problem from messages                              │
    │  2. Write thoughts to scratchpad                            │
    │  3. Store intermediate calculations                         │
    │  4. Formulate hypothesis                                    │
    │  5. Output final answer to messages                         │
    │  6. Clear working memory                                    │
    └─────────────────────────────────────────────────────────────┘
```

---

## Memory Management Strategies

### Strategy 1: Token-Based Trimming

```
┌─────────────────────────────────────────────────────────────────┐
│              TOKEN-BASED TRIMMING                               │
└─────────────────────────────────────────────────────────────────┘

    Context limit: 4000 tokens
    
    Messages:
    ┌────────────┬────────┐
    │  Message   │ Tokens │
    ├────────────┼────────┤
    │  msg1      │  150   │  <── May be trimmed
    │  msg2      │  200   │  <── May be trimmed
    │  msg3      │  180   │
    │  msg4      │  220   │
    │  msg5      │  300   │  <── Recent, keep
    │  msg6      │  400   │  <── Recent, keep
    │  msg7      │  350   │  <── Recent, keep
    └────────────┴────────┘
    
    Trim from oldest until under limit
```

### Strategy 2: Importance-Based Filtering

```
┌─────────────────────────────────────────────────────────────────┐
│              IMPORTANCE-BASED FILTERING                         │
└─────────────────────────────────────────────────────────────────┘

    Messages with importance scores:
    
    ┌────────────────────────┬────────────┬────────┐
    │       Message          │ Importance │  Keep? │
    ├────────────────────────┼────────────┼────────┤
    │ "Hi"                   │    0.1     │   ❌   │
    │ "My name is Alice"     │    0.9     │   ✅   │
    │ "OK"                   │    0.1     │   ❌   │
    │ "I need flights to NYC"│    0.8     │   ✅   │
    │ "Thanks"               │    0.2     │   ❌   │
    │ "Book window seat"     │    0.7     │   ✅   │
    └────────────────────────┴────────────┴────────┘
    
    Keep messages above importance threshold
```

### Strategy 3: Role-Based Retention

```
┌─────────────────────────────────────────────────────────────────┐
│              ROLE-BASED RETENTION                               │
└─────────────────────────────────────────────────────────────────┘

    Different retention rules per role:
    
    ┌──────────────────────────────────────────────────────────┐
    │  SYSTEM messages:  Always keep (instructions)           │
    │  USER messages:    Keep last 10                         │
    │  ASSISTANT:        Keep last 5                          │
    │  TOOL results:     Keep last 3 or summarize             │
    └──────────────────────────────────────────────────────────┘
```

---

## Memory Architecture

```
┌────────────────────────────────────────────────────────────────────┐
│                COMPLETE MEMORY ARCHITECTURE                        │
└────────────────────────────────────────────────────────────────────┘

                    ┌─────────────────────────────────┐
                    │         USER REQUEST            │
                    └─────────────────┬───────────────┘
                                      │
                                      v
    ┌─────────────────────────────────────────────────────────────┐
    │                    MEMORY RETRIEVAL                         │
    │                                                              │
    │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐         │
    │  │ Short-Term  │  │ Long-Term   │  │ External    │         │
    │  │ (Session)   │  │ (User Prof) │  │ (Vector DB) │         │
    │  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘         │
    │         │                │                │                  │
    │         └────────────────┼────────────────┘                  │
    │                          │                                   │
    └──────────────────────────┼───────────────────────────────────┘
                               │
                               v
    ┌─────────────────────────────────────────────────────────────┐
    │                    CONTEXT ASSEMBLY                         │
    │                                                              │
    │   [System Prompt]                                           │
    │   [User Profile Summary]                                    │
    │   [Relevant Past Conversations]                             │
    │   [Recent Messages]                                         │
    │   [Current Query]                                           │
    └─────────────────────────┬───────────────────────────────────┘
                               │
                               v
    ┌─────────────────────────────────────────────────────────────┐
    │                    LLM PROCESSING                           │
    └─────────────────────────┬───────────────────────────────────┘
                               │
                               v
    ┌─────────────────────────────────────────────────────────────┐
    │                    MEMORY UPDATE                            │
    │                                                              │
    │  - Add response to short-term memory                        │
    │  - Extract facts for long-term storage                      │
    │  - Update user profile if needed                            │
    │  - Index in vector store for retrieval                      │
    └─────────────────────────────────────────────────────────────┘
```

---

## Implementing Memory in LangGraph

### Basic Implementation

```python
class MemoryState(TypedDict):
    # Short-term: Current conversation
    messages: Annotated[List[BaseMessage], operator.add]
    
    # Working memory: Current task context
    current_task: str
    scratchpad: str
    
    # Long-term reference: Loaded at start
    user_preferences: dict
    conversation_summary: str
```

### With Memory Retrieval Node

```
┌─────────────────────────────────────────────────────────────────┐
│              MEMORY-AWARE GRAPH                                 │
└─────────────────────────────────────────────────────────────────┘

    START
      │
      v
┌──────────────┐
│   RETRIEVE   │ ─── Load long-term memory
│   MEMORY     │     Fetch relevant history
└──────┬───────┘
       │
       v
┌──────────────┐
│   PROCESS    │ ─── Use full context
│   REQUEST    │     Generate response
└──────┬───────┘
       │
       v
┌──────────────┐
│   UPDATE     │ ─── Save new info
│   MEMORY     │     Update profile
└──────┬───────┘
       │
       v
      END
```

---

## 📌 Interview Tip

> **Q: How would you implement long-term memory for a conversational agent?**
>
> **A:** I would use a multi-tier memory architecture:
>
> 1. **Short-term (Session)**: Use LangGraph's checkpointing with `Annotated[List, operator.add]` for the current conversation
>
> 2. **Long-term (Facts)**: Store user facts and preferences in a key-value store (Redis, DynamoDB) indexed by user_id
>
> 3. **Episodic (Past Conversations)**: Index conversation summaries in a vector database for semantic retrieval
>
> The graph would have:
> - A memory retrieval node at the start that queries relevant past context
> - A memory update node at the end that extracts and stores new information
> - Checkpointing for session persistence
>
> This provides both immediate context (recent messages) and relevant historical context (similar past interactions).

---

## ⚠️ Common Pitfalls

### Pitfall 1: Unlimited Message Accumulation

```python
# PROBLEM: Memory grows unbounded
messages: Annotated[List, operator.add]  # No limit!

# SOLUTION: Use sliding window
messages: Annotated[List, sliding_window(50)]
```

### Pitfall 2: Ignoring Token Limits

```python
# PROBLEM: Exceeding LLM context window
# Sending 100 messages to a 4K context model

# SOLUTION: Token-aware trimming before LLM call
def prepare_context(messages, max_tokens=3000):
    # Trim from oldest until under limit
    pass
```

### Pitfall 3: No Memory Persistence

```python
# PROBLEM: Using MemorySaver in production
checkpointer = MemorySaver()  # Lost on restart!

# SOLUTION: Use persistent storage
checkpointer = PostgresSaver.from_conn_string(...)
```

---

## 💡 Key Takeaways

1. **Short-term = Session state** (via checkpointing)
2. **Long-term = External storage** (vector DB, key-value store)
3. **Sliding window** prevents unbounded growth
4. **Summarization** compresses old context
5. **Working memory** supports complex reasoning
6. **Token awareness** prevents context overflow

---

## Next Steps

See `09_memory_example.py` for a complete implementation of a conversational agent with memory.
