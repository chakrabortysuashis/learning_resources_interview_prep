# State Channels in LangGraph

## What are State Channels?

State channels are the underlying mechanism that LangGraph uses to manage how data flows through a graph. Think of them as **dedicated communication pathways** between nodes.

When you define a `TypedDict` state, LangGraph automatically creates channels for each field. Understanding channels helps you build more sophisticated state management patterns.

---

## Conceptual Overview

```
┌────────────────────────────────────────────────────────────────────┐
│                    STATE CHANNEL ARCHITECTURE                      │
└────────────────────────────────────────────────────────────────────┘

            ┌─────────────────────────────────────────────┐
            │              GRAPH STATE                    │
            │                                             │
            │  ┌─────────┐ ┌─────────┐ ┌─────────┐       │
            │  │Channel A│ │Channel B│ │Channel C│       │
            │  │messages │ │ count   │ │ config  │       │
            │  └────┬────┘ └────┬────┘ └────┬────┘       │
            │       │           │           │             │
            └───────┼───────────┼───────────┼─────────────┘
                    │           │           │
        ┌───────────┼───────────┼───────────┼───────────┐
        │           │           │           │           │
        v           v           v           v           v
   ┌────────┐  ┌────────┐  ┌────────┐  ┌────────┐  ┌────────┐
   │ Node 1 │  │ Node 2 │  │ Node 3 │  │ Node 4 │  │ Node 5 │
   └────────┘  └────────┘  └────────┘  └────────┘  └────────┘
   
   Each node can:
   - READ from any channel
   - WRITE to any channel (via return dict)
   - Channel's reducer determines how writes are applied
```

---

## How Channels Work Internally

```
┌────────────────────────────────────────────────────────────────────┐
│                  CHANNEL UPDATE PROCESS                            │
└────────────────────────────────────────────────────────────────────┘

Step 1: Node reads current channel values
─────────────────────────────────────────
    ┌─────────────┐
    │  Channel    │
    │  messages   │ ──────────────┐
    │  [msg1]     │               │
    └─────────────┘               │     ┌─────────────┐
                                  ├────>│    Node     │
    ┌─────────────┐               │     │             │
    │  Channel    │               │     │ Reads state │
    │  count      │ ──────────────┘     │             │
    │  5          │                     └──────┬──────┘
    └─────────────┘                            │
                                               │
                                               v
Step 2: Node returns updates
─────────────────────────────────────────
                                        ┌─────────────┐
                                        │    Node     │
                                        │             │
                                        │ Returns:    │
                                        │ {messages:  │
                                        │  [msg2],    │
                                        │  count: 3}  │
                                        └──────┬──────┘
                                               │
                                               v
Step 3: Updates go through channel reducers
─────────────────────────────────────────
    ┌─────────────────────────────────────────────────────┐
    │              CHANNEL REDUCERS                       │
    │                                                     │
    │  messages channel:                                  │
    │    reducer = operator.add                           │
    │    [msg1] + [msg2] = [msg1, msg2]                  │
    │                                                     │
    │  count channel:                                     │
    │    reducer = overwrite (default)                    │
    │    5 -> 3 (replaced)                               │
    └─────────────────────────────────────────────────────┘
                                               │
                                               v
Step 4: Channels updated with results
─────────────────────────────────────────
    ┌─────────────┐     ┌─────────────┐
    │  Channel    │     │  Channel    │
    │  messages   │     │  count      │
    │  [msg1,msg2]│     │  3          │
    └─────────────┘     └─────────────┘
```

---

## Channel Types

LangGraph supports different channel types for various use cases:

### 1. LastValue Channel (Default)

The default channel type - stores only the most recent value.

```python
class State(TypedDict):
    result: str  # LastValue channel - always overwrites
```

```
┌─────────────────────────────────────────────────────┐
│                LASTVALUE CHANNEL                    │
└─────────────────────────────────────────────────────┘

    Update 1: "first"     ─────>  Value: "first"
    Update 2: "second"    ─────>  Value: "second"
    Update 3: "third"     ─────>  Value: "third"
    
    Only the last value is kept!
```

### 2. BinaryOperator Channel (with Annotated)

Uses a reducer function to combine values.

```python
class State(TypedDict):
    messages: Annotated[list, operator.add]  # BinaryOperator channel
```

```
┌─────────────────────────────────────────────────────┐
│            BINARYOPERATOR CHANNEL                   │
└─────────────────────────────────────────────────────┘

    Initial:  []
    Update 1: ["a"]      ─────>  Value: [] + ["a"] = ["a"]
    Update 2: ["b"]      ─────>  Value: ["a"] + ["b"] = ["a", "b"]
    Update 3: ["c"]      ─────>  Value: ["a", "b"] + ["c"] = ["a", "b", "c"]
    
    Values are combined using the reducer!
```

---

## Channel Dependencies and Ordering

Channels can have dependencies, affecting execution order:

```
┌────────────────────────────────────────────────────────────────────┐
│                    CHANNEL DEPENDENCIES                            │
└────────────────────────────────────────────────────────────────────┘

Scenario: Node B depends on output from Node A

    ┌────────────┐                           ┌────────────┐
    │   Node A   │                           │   Node B   │
    │            │                           │            │
    │ Writes to  │                           │ Reads from │
    │ channel_x  │──────────────────────────>│ channel_x  │
    └────────────┘                           └────────────┘
    
    LangGraph ensures:
    1. Node A executes first
    2. Channel_x is updated
    3. Node B can then read the updated value
```

---

## Explicit Channel Configuration

For advanced use cases, you can configure channels explicitly:

```python
from langgraph.graph import StateGraph
from langgraph.channels import LastValue, BinaryOperatorAggregate


class MyState(TypedDict):
    messages: list
    count: int


# Explicit channel configuration (advanced)
graph = StateGraph(
    MyState,
    # Channels can be configured here for complex scenarios
)
```

---

## Channel Visibility and Scope

```
┌────────────────────────────────────────────────────────────────────┐
│                    CHANNEL SCOPE                                   │
└────────────────────────────────────────────────────────────────────┘

GRAPH SCOPE (Default):
──────────────────────
All nodes can read/write all channels

    ┌───────────────────────────────────────────────┐
    │                 GRAPH STATE                    │
    │  ┌─────────┐  ┌─────────┐  ┌─────────┐       │
    │  │ chan_a  │  │ chan_b  │  │ chan_c  │       │
    │  └────┬────┘  └────┬────┘  └────┬────┘       │
    └───────┼───────────┼───────────┼──────────────┘
            │           │           │
            │     All accessible    │
            │           │           │
    ┌───────┴───────────┴───────────┴──────────────┐
    │  ┌────────┐  ┌────────┐  ┌────────┐         │
    │  │ Node 1 │  │ Node 2 │  │ Node 3 │         │
    │  └────────┘  └────────┘  └────────┘         │
    └─────────────────────────────────────────────┘


INPUT/OUTPUT CHANNELS (For Subgraphs):
─────────────────────────────────────
Subgraphs can specify which channels are exposed

    PARENT GRAPH
    ┌─────────────────────────────────────────────┐
    │                                             │
    │    ┌─────────────────────────────────┐     │
    │    │         SUBGRAPH                │     │
    │    │                                 │     │
    │    │  Input:  [query]               │     │
    │    │  Output: [result]              │     │
    │    │                                 │     │
    │    │  Internal channels hidden       │     │
    │    │  from parent                    │     │
    │    └─────────────────────────────────┘     │
    │                                             │
    └─────────────────────────────────────────────┘
```

---

## Practical Channel Patterns

### Pattern 1: Shared Context Channel

```python
class State(TypedDict):
    # Shared context that any node can update
    context: Annotated[dict, merge_dicts]
    
    # Each node can add to context without overwriting
    # other nodes' contributions
```

### Pattern 2: Parallel Aggregation

```
┌────────────────────────────────────────────────────────────────────┐
│              PARALLEL AGGREGATION PATTERN                          │
└────────────────────────────────────────────────────────────────────┘

                        ┌─────────────┐
                        │   START     │
                        └──────┬──────┘
                               │
              ┌────────────────┼────────────────┐
              │                │                │
              v                v                v
        ┌───────────┐   ┌───────────┐   ┌───────────┐
        │  Search A │   │  Search B │   │  Search C │
        │           │   │           │   │           │
        │ Returns:  │   │ Returns:  │   │ Returns:  │
        │ results:  │   │ results:  │   │ results:  │
        │ [a1,a2]   │   │ [b1,b2]   │   │ [c1,c2]   │
        └─────┬─────┘   └─────┬─────┘   └─────┬─────┘
              │               │               │
              └───────────────┼───────────────┘
                              │
                              v
              ┌───────────────────────────────────┐
              │         RESULTS CHANNEL           │
              │   Reducer: operator.add           │
              │                                   │
              │   All results combined:           │
              │   [a1, a2, b1, b2, c1, c2]        │
              └───────────────┬───────────────────┘
                              │
                              v
                       ┌────────────┐
                       │  Aggregate │
                       │    Node    │
                       └────────────┘
```

### Pattern 3: Priority Queue Channel

```python
def priority_merge(current: list, new: list) -> list:
    """Keep items sorted by priority"""
    combined = (current or []) + (new or [])
    return sorted(combined, key=lambda x: x.get('priority', 0), reverse=True)

class PriorityState(TypedDict):
    tasks: Annotated[list, priority_merge]
```

---

## Channel Debugging

Understanding channel state helps with debugging:

```python
# When using stream_mode, you can see channel updates
for event in app.stream(initial_state, stream_mode="updates"):
    print(f"Node: {event}")
    # Shows which channels were updated by each node

for event in app.stream(initial_state, stream_mode="values"):
    print(f"State: {event}")
    # Shows full state after each node
```

---

## 📌 Interview Tip

> **Q: What are state channels in LangGraph?**
>
> **A:** State channels are the underlying mechanism for state management in LangGraph. Each field in your state TypedDict becomes a channel. Channels determine:
>
> 1. **How values are stored** (LastValue for simple overwrite, or with reducers for accumulation)
> 2. **How concurrent updates are merged** (important for parallel node execution)
> 3. **What nodes can access** (input/output scoping for subgraphs)
>
> When you use `Annotated[List, operator.add]`, you're configuring that channel to use the `add` operator as its reducer instead of the default overwrite behavior.

---

## ⚠️ Common Pitfalls

### Pitfall 1: Forgetting About Parallel Updates

When nodes run in parallel, their channel updates must be mergeable:

```python
# If two parallel nodes both return:
# Node A: {"results": ["a"]}
# Node B: {"results": ["b"]}

# With operator.add: results = ["a", "b"]  ✅
# Without reducer: one overwrites the other  ⚠️
```

### Pitfall 2: Large State in Channels

Channels hold state in memory. Avoid storing large objects:

```python
# AVOID: Storing large files in state
class BadState(TypedDict):
    file_content: str  # Could be megabytes!

# BETTER: Store references
class GoodState(TypedDict):
    file_path: str  # Just the path, load when needed
```

---

## 💡 Key Takeaways

1. **Channels = State Fields** - Each TypedDict field is a channel
2. **Reducers control merging** - Define how concurrent updates combine
3. **Default is overwrite** - Without Annotated, last value wins
4. **Parallel-safe by design** - Reducers handle concurrent node outputs
5. **Subgraphs can scope channels** - Control what's visible to parent

---

## Next Steps

See `06_checkpointing.md` to learn how to persist channel state for recovery and resumption.
