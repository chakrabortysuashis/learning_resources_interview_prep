# Deployment Strategies for LangGraph Applications

## Overview

This guide covers different approaches to deploying LangGraph applications, from
local development servers to production-grade cloud deployments.

```
+------------------------------------------------------------------+
|                 DEPLOYMENT OPTIONS SPECTRUM                       |
+------------------------------------------------------------------+
|                                                                   |
|   Simplicity                                    Control           |
|   <-------------------------------------------------->           |
|                                                                   |
|   +----------+    +----------+    +----------+    +----------+   |
|   | LangGraph|    |   Cloud  |    |Container |    |    Self  |   |
|   | Platform |    | Functions|    |  (K8s)   |    |  Managed |   |
|   +----------+    +----------+    +----------+    +----------+   |
|       |               |               |               |          |
|   Fully          Serverless      Orchestrated      Full          |
|   Managed        Functions       Containers        Control       |
|                                                                   |
+------------------------------------------------------------------+
```

## Strategy 1: Local Development Server

Best for: Development, testing, demonstrations

### Using LangGraph's Built-in Server

```python
# serve.py
from langgraph.graph import StateGraph
from langgraph.prebuilt import create_react_agent
from langchain_openai import ChatOpenAI

# Define your graph
llm = ChatOpenAI(model="gpt-4")
graph = create_react_agent(llm, tools=[])

# Serve locally
if __name__ == "__main__":
    # LangGraph provides a development server
    # This is for local development only
    from langgraph.cli import serve
    serve(graph, port=8000)
```

### Using FastAPI (Recommended for Custom Control)

```python
# main.py
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional
import uvicorn

from my_graph import create_graph

app = FastAPI(title="LangGraph API")
graph = create_graph()

class Message(BaseModel):
    role: str
    content: str

class InvokeRequest(BaseModel):
    messages: List[Message]
    thread_id: Optional[str] = None

@app.post("/invoke")
async def invoke_graph(request: InvokeRequest):
    try:
        result = await graph.ainvoke({
            "messages": [m.dict() for m in request.messages]
        })
        return {"result": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
```

## Strategy 2: Cloud Platform Deployment

### Option A: LangGraph Platform (Managed)

```
+------------------------------------------------------------------+
|              LANGGRAPH PLATFORM DEPLOYMENT                        |
+------------------------------------------------------------------+
|                                                                   |
|   1. Configure (langgraph.json)                                   |
|      +------------------+                                         |
|      | {                |                                         |
|      |   "graphs": {},  |                                         |
|      |   "deps": []     |                                         |
|      | }                |                                         |
|      +------------------+                                         |
|              |                                                    |
|              v                                                    |
|   2. Deploy (CLI)                                                 |
|      $ langgraph deploy                                           |
|              |                                                    |
|              v                                                    |
|   3. Access (API/SDK)                                             |
|      https://api.langgraph.dev/runs/...                           |
|                                                                   |
+------------------------------------------------------------------+
```

### Option B: AWS Deployment

```
+------------------------------------------------------------------+
|                    AWS ARCHITECTURE                               |
+------------------------------------------------------------------+
|                                                                   |
|   Internet                                                        |
|      |                                                            |
|      v                                                            |
|   +------------------+                                            |
|   |   API Gateway    |   (Rate limiting, Auth)                    |
|   +------------------+                                            |
|      |                                                            |
|      v                                                            |
|   +------------------+     +------------------+                   |
|   |    Lambda /      |<--->|   DynamoDB       |                   |
|   |    ECS Fargate   |     |   (State Store)  |                   |
|   +------------------+     +------------------+                   |
|      |                                                            |
|      v                                                            |
|   +------------------+                                            |
|   |  Secrets Manager |   (API Keys)                               |
|   +------------------+                                            |
|                                                                   |
+------------------------------------------------------------------+
```

#### AWS Lambda Deployment

```python
# lambda_handler.py
import json
from mangum import Mangum
from fastapi import FastAPI
from my_graph import create_graph

app = FastAPI()
graph = create_graph()

@app.post("/invoke")
async def invoke(event: dict):
    result = await graph.ainvoke(event["input"])
    return {"statusCode": 200, "body": json.dumps(result)}

# Adapter for AWS Lambda
handler = Mangum(app)
```

```yaml
# serverless.yml (Serverless Framework)
service: langgraph-api

provider:
  name: aws
  runtime: python3.11
  timeout: 300  # 5 minutes for long-running graphs
  memorySize: 1024

functions:
  api:
    handler: lambda_handler.handler
    events:
      - http:
          path: /{proxy+}
          method: ANY
    environment:
      OPENAI_API_KEY: ${ssm:/langgraph/openai-key}
```

### Option C: Google Cloud Platform

```
+------------------------------------------------------------------+
|                    GCP ARCHITECTURE                               |
+------------------------------------------------------------------+
|                                                                   |
|   Internet                                                        |
|      |                                                            |
|      v                                                            |
|   +------------------+                                            |
|   |  Cloud Load      |                                            |
|   |  Balancer        |                                            |
|   +------------------+                                            |
|      |                                                            |
|      v                                                            |
|   +------------------+     +------------------+                   |
|   |   Cloud Run      |<--->|   Firestore /    |                   |
|   |   (Container)    |     |   Cloud SQL      |                   |
|   +------------------+     +------------------+                   |
|      |                                                            |
|      v                                                            |
|   +------------------+                                            |
|   | Secret Manager   |                                            |
|   +------------------+                                            |
|                                                                   |
+------------------------------------------------------------------+
```

#### Cloud Run Deployment

```dockerfile
# Dockerfile
FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

# Cloud Run sets PORT environment variable
CMD exec uvicorn main:app --host 0.0.0.0 --port ${PORT:-8080}
```

```bash
# Deploy to Cloud Run
gcloud run deploy langgraph-api \
    --source . \
    --platform managed \
    --region us-central1 \
    --allow-unauthenticated \
    --set-secrets=OPENAI_API_KEY=openai-key:latest \
    --memory 1Gi \
    --timeout 300
```

### Option D: Azure Deployment

```python
# Azure Functions with FastAPI
import azure.functions as func
from fastapi import FastAPI
from my_graph import create_graph

app = FastAPI()
graph = create_graph()

@app.post("/api/invoke")
async def invoke(request: dict):
    return await graph.ainvoke(request)

# Azure Functions adapter
async def main(req: func.HttpRequest) -> func.HttpResponse:
    return await func.AsgiMiddleware(app).handle_async(req)
```

## Strategy 3: Container Orchestration (Kubernetes)

Best for: High availability, auto-scaling, complex deployments

```
+------------------------------------------------------------------+
|                 KUBERNETES ARCHITECTURE                           |
+------------------------------------------------------------------+
|                                                                   |
|   +----------------------------------------------------------+   |
|   |                    Kubernetes Cluster                     |   |
|   |                                                           |   |
|   |   +------------------+    +------------------+            |   |
|   |   |    Ingress       |    |   ConfigMaps    |            |   |
|   |   |   Controller     |    |   & Secrets     |            |   |
|   |   +------------------+    +------------------+            |   |
|   |          |                                                |   |
|   |          v                                                |   |
|   |   +------------------+                                    |   |
|   |   |     Service      |                                    |   |
|   |   | (Load Balancer)  |                                    |   |
|   |   +------------------+                                    |   |
|   |          |                                                |   |
|   |          v                                                |   |
|   |   +--------+  +--------+  +--------+                     |   |
|   |   |  Pod   |  |  Pod   |  |  Pod   |   (HPA: 3-10)       |   |
|   |   | Graph  |  | Graph  |  | Graph  |                     |   |
|   |   +--------+  +--------+  +--------+                     |   |
|   |                                                           |   |
|   |   +------------------+    +------------------+            |   |
|   |   |    Redis         |    |   PostgreSQL    |            |   |
|   |   | (State Cache)    |    | (Checkpoints)   |            |   |
|   |   +------------------+    +------------------+            |   |
|   |                                                           |   |
|   +----------------------------------------------------------+   |
|                                                                   |
+------------------------------------------------------------------+
```

### Kubernetes Manifests

```yaml
# deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: langgraph-api
  labels:
    app: langgraph-api
spec:
  replicas: 3
  selector:
    matchLabels:
      app: langgraph-api
  template:
    metadata:
      labels:
        app: langgraph-api
    spec:
      containers:
      - name: langgraph-api
        image: your-registry/langgraph-api:latest
        ports:
        - containerPort: 8000
        resources:
          requests:
            memory: "512Mi"
            cpu: "250m"
          limits:
            memory: "1Gi"
            cpu: "1000m"
        env:
        - name: OPENAI_API_KEY
          valueFrom:
            secretKeyRef:
              name: langgraph-secrets
              key: openai-api-key
        livenessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 10
          periodSeconds: 30
        readinessProbe:
          httpGet:
            path: /ready
            port: 8000
          initialDelaySeconds: 5
          periodSeconds: 10
---
# service.yaml
apiVersion: v1
kind: Service
metadata:
  name: langgraph-api
spec:
  selector:
    app: langgraph-api
  ports:
  - port: 80
    targetPort: 8000
  type: ClusterIP
---
# hpa.yaml (Horizontal Pod Autoscaler)
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: langgraph-api-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: langgraph-api
  minReplicas: 3
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
```

## Strategy 4: Serverless Deployment

Best for: Variable workloads, cost optimization, simple APIs

```
+------------------------------------------------------------------+
|                 SERVERLESS CONSIDERATIONS                         |
+------------------------------------------------------------------+
|                                                                   |
|   Pros:                          Cons:                            |
|   +---------------------+        +------------------------+       |
|   | - Pay per execution |        | - Cold start latency   |       |
|   | - Auto scaling      |        | - Timeout limits       |       |
|   | - No server mgmt    |        | - Stateless (need DB)  |       |
|   | - High availability |        | - Vendor lock-in       |       |
|   +---------------------+        +------------------------+       |
|                                                                   |
|   Best Practices:                                                 |
|   ---------------                                                 |
|   1. Keep functions warm with scheduled pings                     |
|   2. Use provisioned concurrency for critical paths               |
|   3. Implement proper timeout handling                            |
|   4. Use external state storage (Redis, DynamoDB)                 |
|   5. Consider step functions for long workflows                   |
|                                                                   |
+------------------------------------------------------------------+
```

### AWS Step Functions Integration

For long-running workflows, use AWS Step Functions:

```json
{
  "Comment": "LangGraph Workflow with Step Functions",
  "StartAt": "ProcessInput",
  "States": {
    "ProcessInput": {
      "Type": "Task",
      "Resource": "arn:aws:lambda:us-east-1:123456789:function:process-input",
      "Next": "RunAgent"
    },
    "RunAgent": {
      "Type": "Task",
      "Resource": "arn:aws:lambda:us-east-1:123456789:function:run-agent",
      "TimeoutSeconds": 300,
      "Retry": [
        {
          "ErrorEquals": ["Lambda.ServiceException"],
          "IntervalSeconds": 2,
          "MaxAttempts": 3,
          "BackoffRate": 2
        }
      ],
      "Next": "CheckCompletion"
    },
    "CheckCompletion": {
      "Type": "Choice",
      "Choices": [
        {
          "Variable": "$.status",
          "StringEquals": "complete",
          "Next": "Success"
        }
      ],
      "Default": "RunAgent"
    },
    "Success": {
      "Type": "Succeed"
    }
  }
}
```

## Deployment Configuration Comparison

| Aspect | Local | Cloud Functions | Containers | K8s |
|--------|-------|-----------------|------------|-----|
| Setup Time | Minutes | Hours | Hours | Days |
| Scaling | Manual | Auto | Manual/Auto | Auto |
| Cost Model | Fixed | Per-execution | Per-hour | Per-hour |
| Cold Start | None | Yes | None | None |
| Max Timeout | Unlimited | 5-15 min | Unlimited | Unlimited |
| State Mgmt | In-memory | External | External | External |
| Complexity | Low | Medium | Medium | High |

## Essential Deployment Patterns

### 1. Health Checks

```python
from fastapi import FastAPI
from datetime import datetime

app = FastAPI()

@app.get("/health")
async def health_check():
    """Liveness probe - is the service alive?"""
    return {"status": "healthy", "timestamp": datetime.utcnow().isoformat()}

@app.get("/ready")
async def readiness_check():
    """Readiness probe - is the service ready to accept traffic?"""
    # Check dependencies
    checks = {
        "database": await check_database(),
        "llm_api": await check_llm_api(),
        "memory": check_memory_usage()
    }
    
    all_healthy = all(checks.values())
    return {
        "ready": all_healthy,
        "checks": checks
    }

async def check_database():
    try:
        # Verify database connection
        return True
    except Exception:
        return False

async def check_llm_api():
    try:
        # Verify LLM API is reachable
        return True
    except Exception:
        return False

def check_memory_usage():
    import psutil
    return psutil.virtual_memory().percent < 90
```

### 2. Graceful Shutdown

```python
import signal
import asyncio
from contextlib import asynccontextmanager
from fastapi import FastAPI

# Track active requests
active_requests = set()
shutdown_event = asyncio.Event()

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    print("Starting up...")
    yield
    # Shutdown
    print("Shutting down gracefully...")
    shutdown_event.set()
    
    # Wait for active requests to complete (max 30 seconds)
    if active_requests:
        print(f"Waiting for {len(active_requests)} active requests...")
        await asyncio.wait_for(
            asyncio.gather(*active_requests),
            timeout=30
        )

app = FastAPI(lifespan=lifespan)

@app.middleware("http")
async def track_requests(request, call_next):
    task = asyncio.current_task()
    active_requests.add(task)
    try:
        response = await call_next(request)
        return response
    finally:
        active_requests.discard(task)
```

### 3. Configuration Management

```python
from pydantic_settings import BaseSettings
from functools import lru_cache

class Settings(BaseSettings):
    # API Configuration
    app_name: str = "LangGraph API"
    debug: bool = False
    
    # LLM Configuration
    openai_api_key: str
    model_name: str = "gpt-4"
    temperature: float = 0.7
    
    # Database Configuration
    database_url: str = "sqlite:///./langgraph.db"
    
    # Rate Limiting
    rate_limit_requests: int = 100
    rate_limit_window: int = 60
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"

@lru_cache()
def get_settings():
    return Settings()
```

## Interview Tips

```
+------------------------------------------------------------------+
|                       INTERVIEW TIP                               |
+------------------------------------------------------------------+
| Q: "How would you deploy a LangGraph application that needs to    |
|     handle 1000 concurrent users with variable load?"             |
|                                                                   |
| A: I would consider these factors:                                |
|                                                                   |
| 1. Architecture Choice                                            |
|    - Kubernetes for auto-scaling and high availability            |
|    - Or LangGraph Platform for managed scaling                    |
|                                                                   |
| 2. State Management                                               |
|    - Redis for session state and caching                          |
|    - PostgreSQL for durable checkpoint storage                    |
|                                                                   |
| 3. Scaling Strategy                                               |
|    - Horizontal Pod Autoscaler based on CPU/memory                |
|    - Custom metrics based on request queue length                 |
|    - Pre-warm pods during known peak hours                        |
|                                                                   |
| 4. Cost Optimization                                              |
|    - Spot instances for non-critical workloads                    |
|    - Right-size containers based on actual usage                  |
|    - Implement request queuing to smooth spikes                   |
|                                                                   |
| 5. Reliability                                                    |
|    - Multi-AZ deployment for fault tolerance                      |
|    - Circuit breakers for LLM API failures                        |
|    - Graceful degradation when overloaded                         |
+------------------------------------------------------------------+
```

## Summary

Choose your deployment strategy based on:

1. **Team Expertise** - Match complexity to capabilities
2. **Scale Requirements** - Right-size for expected load
3. **Cost Constraints** - Balance performance with budget
4. **Time to Market** - Managed services are faster to deploy
5. **Control Needs** - Self-managed for maximum customization

---

Next: [Deployment Example](./03_deployment_example.py)
