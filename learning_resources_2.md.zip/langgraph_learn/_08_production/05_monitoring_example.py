"""
LangGraph Monitoring and Tracing Example
========================================

This module demonstrates comprehensive monitoring and observability
setup for production LangGraph applications, including:
- LangSmith integration for tracing
- Prometheus metrics for dashboards
- Structured logging
- Custom callbacks for monitoring
- Performance tracking

Architecture:
+------------------------------------------------------------------+
|                    MONITORING STACK                               |
+------------------------------------------------------------------+
|                                                                   |
|   LangGraph Application                                           |
|   +----------------------------------------------------------+   |
|   |                                                           |   |
|   |   +-------------+    +-------------+    +-------------+   |   |
|   |   |  Callbacks  |    |   Metrics   |    |   Logger    |   |   |
|   |   +-------------+    +-------------+    +-------------+   |   |
|   |         |                  |                  |           |   |
|   +---------|------------------|------------------|----------+   |
|             |                  |                  |               |
|             v                  v                  v               |
|   +-------------+    +-------------+    +-------------+          |
|   |  LangSmith  |    | Prometheus  |    |  Log Agg    |          |
|   |  (Traces)   |    |  (Metrics)  |    | (ELK/etc)   |          |
|   +-------------+    +-------------+    +-------------+          |
|                                                                   |
+------------------------------------------------------------------+

Usage:
    # Set environment variables
    export LANGCHAIN_TRACING_V2=true
    export LANGCHAIN_API_KEY=your-key
    export LANGCHAIN_PROJECT=production-monitoring

    # Run the example
    python 05_monitoring_example.py
"""

import os
import time
import json
import logging
import asyncio
from datetime import datetime
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field
from contextlib import contextmanager
from functools import wraps

# LangGraph and LangChain imports
from langgraph.graph import StateGraph, START, END
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, AIMessage, BaseMessage
from langchain_core.callbacks import BaseCallbackHandler
from langchain_core.outputs import LLMResult

# Monitoring imports
try:
    from prometheus_client import Counter, Histogram, Gauge, start_http_server
    PROMETHEUS_AVAILABLE = True
except ImportError:
    PROMETHEUS_AVAILABLE = False
    print("prometheus_client not installed. Metrics will be logged only.")


# =============================================================================
# CONFIGURATION
# =============================================================================

@dataclass
class MonitoringConfig:
    """Configuration for monitoring components."""

    # LangSmith settings
    langsmith_enabled: bool = True
    langsmith_project: str = "production-langgraph"

    # Prometheus settings
    prometheus_enabled: bool = True
    prometheus_port: int = 9090

    # Logging settings
    log_level: str = "INFO"
    log_format: str = "json"  # "json" or "text"

    # Tracing settings
    trace_inputs: bool = True
    trace_outputs: bool = True
    trace_tokens: bool = True


def get_monitoring_config() -> MonitoringConfig:
    """Load monitoring configuration from environment."""
    return MonitoringConfig(
        langsmith_enabled=os.getenv("LANGCHAIN_TRACING_V2", "true").lower() == "true",
        langsmith_project=os.getenv("LANGCHAIN_PROJECT", "production-langgraph"),
        prometheus_enabled=os.getenv("PROMETHEUS_ENABLED", "true").lower() == "true",
        prometheus_port=int(os.getenv("PROMETHEUS_PORT", "9090")),
        log_level=os.getenv("LOG_LEVEL", "INFO"),
    )


# =============================================================================
# PROMETHEUS METRICS
# =============================================================================

if PROMETHEUS_AVAILABLE:
    # Request metrics
    REQUEST_COUNT = Counter(
        "langgraph_requests_total",
        "Total number of graph invocations",
        ["status", "graph_name"]
    )

    REQUEST_LATENCY = Histogram(
        "langgraph_request_duration_seconds",
        "Request latency in seconds",
        ["graph_name"],
        buckets=[0.1, 0.5, 1.0, 2.0, 5.0, 10.0, 30.0, 60.0]
    )

    # Node metrics
    NODE_EXECUTION_COUNT = Counter(
        "langgraph_node_executions_total",
        "Total node executions",
        ["node_name", "status"]
    )

    NODE_LATENCY = Histogram(
        "langgraph_node_duration_seconds",
        "Node execution latency",
        ["node_name"],
        buckets=[0.01, 0.05, 0.1, 0.5, 1.0, 2.0, 5.0]
    )

    # LLM metrics
    LLM_CALLS = Counter(
        "langgraph_llm_calls_total",
        "Total LLM API calls",
        ["model", "status"]
    )

    LLM_LATENCY = Histogram(
        "langgraph_llm_duration_seconds",
        "LLM call latency",
        ["model"],
        buckets=[0.1, 0.5, 1.0, 2.0, 5.0, 10.0, 30.0]
    )

    TOKEN_USAGE = Counter(
        "langgraph_tokens_total",
        "Total tokens used",
        ["model", "type"]  # type: input/output
    )

    # Active executions gauge
    ACTIVE_EXECUTIONS = Gauge(
        "langgraph_active_executions",
        "Currently active graph executions"
    )


class MetricsCollector:
    """
    Centralized metrics collection for LangGraph applications.

    This class provides a clean interface for recording metrics
    whether or not Prometheus is available.
    """

    def __init__(self, config: MonitoringConfig):
        self.config = config
        self.enabled = PROMETHEUS_AVAILABLE and config.prometheus_enabled
        self._local_metrics: Dict[str, Any] = {}

    def start_server(self):
        """Start the Prometheus metrics server."""
        if self.enabled:
            start_http_server(self.config.prometheus_port)
            print(f"Prometheus metrics available at :{self.config.prometheus_port}/metrics")

    def record_request(self, graph_name: str, status: str, duration: float):
        """Record a graph invocation."""
        if self.enabled:
            REQUEST_COUNT.labels(status=status, graph_name=graph_name).inc()
            REQUEST_LATENCY.labels(graph_name=graph_name).observe(duration)

        # Always log for debugging
        logging.info(f"Request: graph={graph_name}, status={status}, duration={duration:.3f}s")

    def record_node_execution(self, node_name: str, status: str, duration: float):
        """Record a node execution."""
        if self.enabled:
            NODE_EXECUTION_COUNT.labels(node_name=node_name, status=status).inc()
            NODE_LATENCY.labels(node_name=node_name).observe(duration)

    def record_llm_call(self, model: str, status: str, duration: float):
        """Record an LLM API call."""
        if self.enabled:
            LLM_CALLS.labels(model=model, status=status).inc()
            LLM_LATENCY.labels(model=model).observe(duration)

    def record_tokens(self, model: str, input_tokens: int, output_tokens: int):
        """Record token usage."""
        if self.enabled:
            TOKEN_USAGE.labels(model=model, type="input").inc(input_tokens)
            TOKEN_USAGE.labels(model=model, type="output").inc(output_tokens)

    @contextmanager
    def track_execution(self):
        """Context manager to track active executions."""
        if self.enabled:
            ACTIVE_EXECUTIONS.inc()
        try:
            yield
        finally:
            if self.enabled:
                ACTIVE_EXECUTIONS.dec()


# =============================================================================
# STRUCTURED LOGGING
# =============================================================================

class StructuredLogger:
    """
    Production-ready structured logger.

    Outputs JSON-formatted logs for easy parsing by log aggregation
    systems (ELK, Datadog, CloudWatch Logs, etc.).
    """

    def __init__(self, name: str, config: MonitoringConfig):
        self.logger = logging.getLogger(name)
        self.logger.setLevel(getattr(logging, config.log_level))
        self.config = config

        # Clear existing handlers
        self.logger.handlers = []

        # Add appropriate handler based on format
        handler = logging.StreamHandler()
        if config.log_format == "json":
            handler.setFormatter(self.JsonFormatter())
        else:
            handler.setFormatter(logging.Formatter(
                "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
            ))
        self.logger.addHandler(handler)

    class JsonFormatter(logging.Formatter):
        """JSON log formatter."""
        def format(self, record):
            log_data = {
                "timestamp": datetime.utcnow().isoformat(),
                "level": record.levelname,
                "logger": record.name,
                "message": record.getMessage(),
            }

            # Add extra fields if present
            if hasattr(record, "extra_data"):
                log_data.update(record.extra_data)

            return json.dumps(log_data)

    def _log(self, level: str, message: str, **extra):
        """Internal logging method with extra data support."""
        record = logging.LogRecord(
            name=self.logger.name,
            level=getattr(logging, level),
            pathname="",
            lineno=0,
            msg=message,
            args=(),
            exc_info=None
        )
        record.extra_data = extra
        self.logger.handle(record)

    def info(self, message: str, **extra):
        self._log("INFO", message, **extra)

    def warning(self, message: str, **extra):
        self._log("WARNING", message, **extra)

    def error(self, message: str, **extra):
        self._log("ERROR", message, **extra)

    def debug(self, message: str, **extra):
        self._log("DEBUG", message, **extra)

    # Specialized logging methods for LangGraph

    def graph_start(self, graph_name: str, thread_id: str, input_data: Any = None):
        """Log graph execution start."""
        self.info(
            "Graph execution started",
            event="graph_start",
            graph_name=graph_name,
            thread_id=thread_id,
            input_preview=str(input_data)[:200] if input_data else None
        )

    def graph_end(self, graph_name: str, thread_id: str, duration: float, status: str):
        """Log graph execution end."""
        self.info(
            "Graph execution completed",
            event="graph_end",
            graph_name=graph_name,
            thread_id=thread_id,
            duration_seconds=duration,
            status=status
        )

    def node_start(self, node_name: str, thread_id: str):
        """Log node execution start."""
        self.debug(
            f"Node started: {node_name}",
            event="node_start",
            node_name=node_name,
            thread_id=thread_id
        )

    def node_end(self, node_name: str, thread_id: str, duration: float, status: str):
        """Log node execution end."""
        self.debug(
            f"Node completed: {node_name}",
            event="node_end",
            node_name=node_name,
            thread_id=thread_id,
            duration_seconds=duration,
            status=status
        )

    def llm_call(
        self,
        model: str,
        input_tokens: int,
        output_tokens: int,
        duration: float
    ):
        """Log LLM API call."""
        self.info(
            "LLM call completed",
            event="llm_call",
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            total_tokens=input_tokens + output_tokens,
            duration_seconds=duration
        )


# =============================================================================
# LANGCHAIN CALLBACK HANDLER
# =============================================================================

class MonitoringCallbackHandler(BaseCallbackHandler):
    """
    Custom callback handler for monitoring LLM calls.

    This handler integrates with both LangSmith (via the standard
    callback mechanism) and our custom metrics/logging systems.

    Callbacks are called automatically by LangChain/LangGraph
    during execution.
    """

    def __init__(
        self,
        metrics: MetricsCollector,
        logger: StructuredLogger,
        thread_id: str = "unknown"
    ):
        self.metrics = metrics
        self.logger = logger
        self.thread_id = thread_id
        self._call_start_times: Dict[str, float] = {}

    def on_llm_start(
        self,
        serialized: Dict[str, Any],
        prompts: List[str],
        **kwargs
    ):
        """Called when LLM starts processing."""
        run_id = str(kwargs.get("run_id", "unknown"))
        self._call_start_times[run_id] = time.time()

        model = serialized.get("kwargs", {}).get("model_name", "unknown")
        self.logger.debug(
            "LLM call started",
            event="llm_start",
            model=model,
            thread_id=self.thread_id,
            prompt_count=len(prompts)
        )

    def on_llm_end(self, response: LLMResult, **kwargs):
        """Called when LLM completes processing."""
        run_id = str(kwargs.get("run_id", "unknown"))
        start_time = self._call_start_times.pop(run_id, time.time())
        duration = time.time() - start_time

        # Extract token usage if available
        token_usage = {}
        if response.llm_output:
            token_usage = response.llm_output.get("token_usage", {})

        input_tokens = token_usage.get("prompt_tokens", 0)
        output_tokens = token_usage.get("completion_tokens", 0)
        model = token_usage.get("model_name", "unknown")

        # Record metrics
        self.metrics.record_llm_call(model, "success", duration)
        if input_tokens or output_tokens:
            self.metrics.record_tokens(model, input_tokens, output_tokens)

        # Log the call
        self.logger.llm_call(model, input_tokens, output_tokens, duration)

    def on_llm_error(self, error: Exception, **kwargs):
        """Called when LLM encounters an error."""
        run_id = str(kwargs.get("run_id", "unknown"))
        start_time = self._call_start_times.pop(run_id, time.time())
        duration = time.time() - start_time

        self.metrics.record_llm_call("unknown", "error", duration)

        self.logger.error(
            f"LLM call failed: {error}",
            event="llm_error",
            thread_id=self.thread_id,
            error_type=type(error).__name__,
            duration_seconds=duration
        )

    def on_chain_start(self, serialized: Dict[str, Any], inputs: Dict[str, Any], **kwargs):
        """Called when a chain starts."""
        chain_name = serialized.get("name", "unknown")
        self.logger.debug(
            f"Chain started: {chain_name}",
            event="chain_start",
            chain_name=chain_name,
            thread_id=self.thread_id
        )

    def on_chain_end(self, outputs: Dict[str, Any], **kwargs):
        """Called when a chain completes."""
        self.logger.debug(
            "Chain completed",
            event="chain_end",
            thread_id=self.thread_id
        )

    def on_tool_start(self, serialized: Dict[str, Any], input_str: str, **kwargs):
        """Called when a tool starts."""
        tool_name = serialized.get("name", "unknown")
        self.logger.info(
            f"Tool started: {tool_name}",
            event="tool_start",
            tool_name=tool_name,
            thread_id=self.thread_id
        )

    def on_tool_end(self, output: str, **kwargs):
        """Called when a tool completes."""
        self.logger.info(
            "Tool completed",
            event="tool_end",
            thread_id=self.thread_id,
            output_preview=str(output)[:100]
        )

    def on_tool_error(self, error: Exception, **kwargs):
        """Called when a tool encounters an error."""
        self.logger.error(
            f"Tool failed: {error}",
            event="tool_error",
            thread_id=self.thread_id,
            error_type=type(error).__name__
        )


# =============================================================================
# MONITORED GRAPH WRAPPER
# =============================================================================

class MonitoredGraph:
    """
    Wrapper that adds monitoring to any LangGraph graph.

    This wrapper:
    - Tracks execution metrics
    - Logs graph lifecycle events
    - Integrates with LangSmith tracing
    - Handles errors gracefully

    Usage:
        graph = create_my_graph()
        monitored = MonitoredGraph(graph, "my_graph", config)
        result = monitored.invoke({"messages": [...]}, thread_id="123")
    """

    def __init__(
        self,
        graph,
        graph_name: str,
        config: MonitoringConfig = None
    ):
        self.graph = graph
        self.graph_name = graph_name
        self.config = config or get_monitoring_config()

        self.metrics = MetricsCollector(self.config)
        self.logger = StructuredLogger(f"langgraph.{graph_name}", self.config)

    def invoke(
        self,
        input_data: Dict[str, Any],
        thread_id: str = "default",
        **kwargs
    ) -> Dict[str, Any]:
        """
        Invoke the graph with full monitoring.

        Args:
            input_data: Input state for the graph
            thread_id: Thread ID for conversation tracking
            **kwargs: Additional arguments passed to graph.invoke()

        Returns:
            Graph execution result
        """
        # Create callback handler for this invocation
        callback_handler = MonitoringCallbackHandler(
            self.metrics,
            self.logger,
            thread_id
        )

        # Merge callbacks
        existing_callbacks = kwargs.get("config", {}).get("callbacks", [])
        callbacks = existing_callbacks + [callback_handler]

        # Update config
        config = kwargs.get("config", {})
        config["callbacks"] = callbacks
        config["configurable"] = config.get("configurable", {})
        config["configurable"]["thread_id"] = thread_id
        kwargs["config"] = config

        # Log start
        self.logger.graph_start(self.graph_name, thread_id, input_data)

        start_time = time.time()
        status = "success"

        with self.metrics.track_execution():
            try:
                result = self.graph.invoke(input_data, **kwargs)
                return result

            except Exception as e:
                status = "error"
                self.logger.error(
                    f"Graph execution failed: {e}",
                    event="graph_error",
                    graph_name=self.graph_name,
                    thread_id=thread_id,
                    error_type=type(e).__name__
                )
                raise

            finally:
                duration = time.time() - start_time
                self.metrics.record_request(self.graph_name, status, duration)
                self.logger.graph_end(self.graph_name, thread_id, duration, status)

    async def ainvoke(
        self,
        input_data: Dict[str, Any],
        thread_id: str = "default",
        **kwargs
    ) -> Dict[str, Any]:
        """Async version of invoke with monitoring."""
        # Similar implementation with async handling
        callback_handler = MonitoringCallbackHandler(
            self.metrics,
            self.logger,
            thread_id
        )

        config = kwargs.get("config", {})
        config["callbacks"] = config.get("callbacks", []) + [callback_handler]
        config["configurable"] = config.get("configurable", {})
        config["configurable"]["thread_id"] = thread_id
        kwargs["config"] = config

        self.logger.graph_start(self.graph_name, thread_id, input_data)

        start_time = time.time()
        status = "success"

        with self.metrics.track_execution():
            try:
                result = await self.graph.ainvoke(input_data, **kwargs)
                return result

            except Exception as e:
                status = "error"
                self.logger.error(f"Graph execution failed: {e}")
                raise

            finally:
                duration = time.time() - start_time
                self.metrics.record_request(self.graph_name, status, duration)
                self.logger.graph_end(self.graph_name, thread_id, duration, status)


# =============================================================================
# EXAMPLE: MONITORED GRAPH
# =============================================================================

def create_monitored_chat_graph():
    """
    Create a simple chat graph with full monitoring.

    Graph structure:
        START -> chat_node -> END
    """

    # State type
    class ChatState(dict):
        messages: List[BaseMessage]

    # Initialize LLM
    llm = ChatOpenAI(
        model="gpt-3.5-turbo",
        temperature=0.7
    )

    def chat_node(state: ChatState) -> ChatState:
        """Process chat messages through LLM."""
        messages = state.get("messages", [])
        response = llm.invoke(messages)
        return {"messages": messages + [response]}

    # Build graph
    builder = StateGraph(ChatState)
    builder.add_node("chat", chat_node)
    builder.add_edge(START, "chat")
    builder.add_edge("chat", END)

    return builder.compile()


# =============================================================================
# MAIN EXAMPLE
# =============================================================================

def main():
    """
    Demonstrate monitoring setup and usage.
    """
    print("=" * 60)
    print("LangGraph Monitoring Example")
    print("=" * 60)

    # Load configuration
    config = get_monitoring_config()
    print(f"\nConfiguration:")
    print(f"  LangSmith enabled: {config.langsmith_enabled}")
    print(f"  LangSmith project: {config.langsmith_project}")
    print(f"  Prometheus enabled: {config.prometheus_enabled}")
    print(f"  Log level: {config.log_level}")

    # Initialize metrics server (if enabled)
    metrics = MetricsCollector(config)
    if config.prometheus_enabled and PROMETHEUS_AVAILABLE:
        metrics.start_server()

    # Create monitored graph
    print("\nCreating monitored graph...")
    base_graph = create_monitored_chat_graph()
    monitored_graph = MonitoredGraph(base_graph, "chat_agent", config)

    # Example invocation
    print("\nInvoking graph...")
    print("-" * 40)

    try:
        result = monitored_graph.invoke(
            {"messages": [HumanMessage(content="What is LangGraph?")]},
            thread_id="demo-thread-001"
        )

        print("\nResult:")
        for msg in result.get("messages", []):
            role = "User" if isinstance(msg, HumanMessage) else "Assistant"
            print(f"  {role}: {msg.content[:100]}...")

    except Exception as e:
        print(f"\nError: {e}")
        print("(This is expected if OPENAI_API_KEY is not set)")

    print("\n" + "=" * 60)
    print("Monitoring Demo Complete")
    print("=" * 60)

    # Keep server running if metrics are enabled
    if config.prometheus_enabled and PROMETHEUS_AVAILABLE:
        print(f"\nMetrics server running on port {config.prometheus_port}")
        print("Press Ctrl+C to stop...")
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\nShutting down...")


if __name__ == "__main__":
    main()


# =============================================================================
# INTERVIEW TIP
# =============================================================================
"""
+------------------------------------------------------------------+
|                       INTERVIEW TIP                               |
+------------------------------------------------------------------+
| Q: "What metrics would you track for a production LangGraph       |
|     application and why?"                                         |
|                                                                   |
| A: I would track metrics across four categories:                  |
|                                                                   |
| 1. Performance Metrics (SLOs)                                     |
|    - Request latency (p50, p95, p99): User experience             |
|    - Error rate: Reliability indicator                            |
|    - Throughput (requests/sec): Capacity planning                 |
|                                                                   |
| 2. LLM-Specific Metrics                                           |
|    - Token usage: Cost tracking                                   |
|    - LLM latency: API performance                                 |
|    - Rate limit hits: Capacity issues                             |
|    - Model errors: Quality issues                                 |
|                                                                   |
| 3. Graph Execution Metrics                                        |
|    - Node execution times: Bottleneck identification              |
|    - Path distribution: Behavior patterns                         |
|    - Cycle count: Runaway graph detection                         |
|    - State size: Memory concerns                                  |
|                                                                   |
| 4. Business Metrics                                               |
|    - User satisfaction (feedback): Quality                        |
|    - Task completion rate: Effectiveness                          |
|    - Escalation rate: AI limitations                              |
|                                                                   |
| Key insight: LLM applications need metrics beyond traditional     |
| web services because costs scale with usage (tokens) and quality  |
| is harder to measure than correctness.                            |
+------------------------------------------------------------------+
"""
