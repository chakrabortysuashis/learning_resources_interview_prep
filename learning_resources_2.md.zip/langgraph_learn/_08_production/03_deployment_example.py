"""
LangGraph Production Deployment Example with FastAPI
====================================================

This module demonstrates a production-ready deployment of a LangGraph
application using FastAPI. It includes:
- RESTful API endpoints for graph invocation
- Streaming support for real-time responses
- Thread management for conversation persistence
- Health checks for orchestration platforms
- Error handling and logging
- Rate limiting and authentication basics

Architecture:
+------------------------------------------------------------------+
|                    FastAPI Application                            |
+------------------------------------------------------------------+
|                                                                   |
|   +------------------+     +------------------+                   |
|   |   API Router     |     |  Health Router   |                   |
|   |  /invoke         |     |  /health         |                   |
|   |  /stream         |     |  /ready          |                   |
|   |  /threads        |     |  /metrics        |                   |
|   +------------------+     +------------------+                   |
|           |                        |                              |
|           v                        v                              |
|   +------------------+     +------------------+                   |
|   |  LangGraph       |     |   Dependency     |                   |
|   |  Graph Engine    |     |   Checks         |                   |
|   +------------------+     +------------------+                   |
|           |                                                       |
|           v                                                       |
|   +------------------+                                            |
|   |   Checkpointer   |                                            |
|   |   (PostgreSQL)   |                                            |
|   +------------------+                                            |
|                                                                   |
+------------------------------------------------------------------+

Usage:
    # Development
    uvicorn 03_deployment_example:app --reload --port 8000

    # Production with Gunicorn
    gunicorn 03_deployment_example:app -w 4 -k uvicorn.workers.UvicornWorker

    # Docker
    docker build -t langgraph-api .
    docker run -p 8000:8000 -e OPENAI_API_KEY=your-key langgraph-api
"""

import os
import uuid
import asyncio
import logging
from typing import Optional, List, Dict, Any, AsyncGenerator
from datetime import datetime
from contextlib import asynccontextmanager
from functools import lru_cache

# FastAPI imports
from fastapi import FastAPI, HTTPException, Depends, BackgroundTasks, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

# LangGraph imports
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.memory import MemorySaver
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, AIMessage, BaseMessage

# =============================================================================
# CONFIGURATION
# =============================================================================

class Settings(BaseModel):
    """
    Application configuration loaded from environment variables.

    In production, these would typically come from:
    - Environment variables (injected by K8s, Docker, etc.)
    - Secret management services (AWS Secrets Manager, HashiCorp Vault)
    - Configuration files (mounted as volumes)
    """

    # Application settings
    app_name: str = "LangGraph Production API"
    debug: bool = False
    log_level: str = "INFO"

    # Server settings
    host: str = "0.0.0.0"
    port: int = 8000
    workers: int = 4

    # LLM settings
    openai_api_key: str = ""
    model_name: str = "gpt-4"
    temperature: float = 0.7
    max_tokens: int = 1000

    # Rate limiting
    rate_limit_requests: int = 100
    rate_limit_window_seconds: int = 60

    # Timeouts
    request_timeout_seconds: int = 120
    llm_timeout_seconds: int = 60

    class Config:
        env_prefix = ""  # No prefix for env vars


@lru_cache()
def get_settings() -> Settings:
    """
    Get cached settings instance.
    Using lru_cache ensures settings are loaded only once.
    """
    return Settings(
        openai_api_key=os.getenv("OPENAI_API_KEY", ""),
        debug=os.getenv("DEBUG", "false").lower() == "true",
        log_level=os.getenv("LOG_LEVEL", "INFO"),
        model_name=os.getenv("MODEL_NAME", "gpt-4"),
    )


# =============================================================================
# LOGGING SETUP
# =============================================================================

def setup_logging(settings: Settings) -> logging.Logger:
    """
    Configure structured logging for production.

    In production, you might want to:
    - Use JSON formatting for log aggregation
    - Send logs to external services (Datadog, CloudWatch)
    - Include correlation IDs for request tracing
    """
    logging.basicConfig(
        level=getattr(logging, settings.log_level),
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )
    return logging.getLogger(__name__)


logger = setup_logging(get_settings())


# =============================================================================
# REQUEST/RESPONSE MODELS
# =============================================================================

class MessageInput(BaseModel):
    """Input message model for API requests."""
    role: str = Field(..., description="Message role: 'user' or 'assistant'")
    content: str = Field(..., description="Message content")


class InvokeRequest(BaseModel):
    """
    Request model for graph invocation.

    Example:
        {
            "messages": [
                {"role": "user", "content": "What is LangGraph?"}
            ],
            "thread_id": "optional-thread-id",
            "config": {"temperature": 0.5}
        }
    """
    messages: List[MessageInput] = Field(..., description="List of messages")
    thread_id: Optional[str] = Field(None, description="Thread ID for conversation continuity")
    config: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Additional configuration")


class InvokeResponse(BaseModel):
    """Response model for graph invocation."""
    thread_id: str = Field(..., description="Thread ID for this conversation")
    messages: List[Dict[str, Any]] = Field(..., description="Response messages")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Execution metadata")


class ThreadInfo(BaseModel):
    """Information about a conversation thread."""
    thread_id: str
    created_at: datetime
    message_count: int
    last_updated: datetime


class HealthStatus(BaseModel):
    """Health check response model."""
    status: str
    timestamp: datetime
    version: str = "1.0.0"
    checks: Dict[str, bool] = Field(default_factory=dict)


# =============================================================================
# LANGGRAPH SETUP
# =============================================================================

class ConversationState(dict):
    """
    State for the conversation graph.

    Using a dict subclass allows for flexible state management
    while maintaining type hints.
    """
    messages: List[BaseMessage]


def create_graph(settings: Settings):
    """
    Create and compile the LangGraph workflow.

    This is a simple conversational agent for demonstration.
    In production, you would have more complex graphs with:
    - Multiple nodes for different tasks
    - Conditional routing
    - Tool integration
    - Error handling nodes

    Architecture:

        +-------+     +------------+     +-----+
        | START | --> | chat_node  | --> | END |
        +-------+     +------------+     +-----+
    """

    # Initialize LLM with production settings
    llm = ChatOpenAI(
        model=settings.model_name,
        temperature=settings.temperature,
        max_tokens=settings.max_tokens,
        timeout=settings.llm_timeout_seconds,
        # Production settings
        max_retries=3,  # Built-in retry logic
    )

    def chat_node(state: ConversationState) -> ConversationState:
        """
        Main chat node that processes messages through the LLM.

        In production, this node would typically:
        - Validate input
        - Apply any preprocessing
        - Call the LLM
        - Handle errors gracefully
        - Log relevant information
        """
        messages = state.get("messages", [])

        logger.info(f"Processing {len(messages)} messages")

        try:
            response = llm.invoke(messages)
            messages.append(response)
            return {"messages": messages}
        except Exception as e:
            logger.error(f"LLM invocation failed: {e}")
            # Return error message instead of crashing
            error_message = AIMessage(
                content=f"I apologize, but I encountered an error processing your request. Please try again."
            )
            messages.append(error_message)
            return {"messages": messages}

    # Build the graph
    builder = StateGraph(ConversationState)
    builder.add_node("chat", chat_node)
    builder.add_edge(START, "chat")
    builder.add_edge("chat", END)

    # Compile with checkpointer for state persistence
    # In production, use PostgresSaver or other durable storage
    checkpointer = MemorySaver()

    return builder.compile(checkpointer=checkpointer)


# =============================================================================
# APPLICATION LIFESPAN
# =============================================================================

# Global graph instance (initialized on startup)
graph = None
active_requests: set = set()
shutdown_event = asyncio.Event()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Application lifespan manager.

    Handles:
    - Startup: Initialize resources (graph, database connections, etc.)
    - Shutdown: Graceful cleanup (wait for active requests, close connections)

    This pattern ensures proper resource management in production.
    """
    global graph

    # === STARTUP ===
    logger.info("Starting LangGraph API...")

    settings = get_settings()

    # Validate configuration
    if not settings.openai_api_key:
        logger.warning("OPENAI_API_KEY not set - API calls will fail")

    # Initialize the graph
    graph = create_graph(settings)
    logger.info("Graph initialized successfully")

    # Initialize other resources (database connections, caches, etc.)
    # await init_database()
    # await init_cache()

    logger.info("LangGraph API started successfully")

    yield  # Application runs here

    # === SHUTDOWN ===
    logger.info("Shutting down LangGraph API...")

    # Signal shutdown
    shutdown_event.set()

    # Wait for active requests to complete (with timeout)
    if active_requests:
        logger.info(f"Waiting for {len(active_requests)} active requests to complete...")
        try:
            # Wait up to 30 seconds for active requests
            await asyncio.wait_for(
                asyncio.gather(*[asyncio.sleep(0.1) for _ in range(300)]),
                timeout=30
            )
        except asyncio.TimeoutError:
            logger.warning("Timeout waiting for requests - forcing shutdown")

    # Cleanup resources
    # await close_database()
    # await close_cache()

    logger.info("LangGraph API shutdown complete")


# =============================================================================
# FASTAPI APPLICATION
# =============================================================================

app = FastAPI(
    title="LangGraph Production API",
    description="Production-ready LangGraph deployment with FastAPI",
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/docs" if get_settings().debug else None,  # Disable in production
    redoc_url="/redoc" if get_settings().debug else None,
)

# CORS middleware for web clients
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# =============================================================================
# MIDDLEWARE
# =============================================================================

@app.middleware("http")
async def request_tracking_middleware(request: Request, call_next):
    """
    Middleware to track active requests for graceful shutdown.

    Also useful for:
    - Request logging
    - Correlation ID injection
    - Request timing
    """
    request_id = str(uuid.uuid4())
    request.state.request_id = request_id

    # Track this request
    task = asyncio.current_task()
    active_requests.add(task)

    start_time = datetime.utcnow()

    try:
        response = await call_next(request)

        # Log request completion
        duration = (datetime.utcnow() - start_time).total_seconds()
        logger.info(
            f"Request {request_id} completed: {request.method} {request.url.path} "
            f"- Status: {response.status_code} - Duration: {duration:.3f}s"
        )

        # Add correlation headers
        response.headers["X-Request-ID"] = request_id
        response.headers["X-Response-Time"] = f"{duration:.3f}s"

        return response
    except Exception as e:
        logger.error(f"Request {request_id} failed: {e}")
        raise
    finally:
        active_requests.discard(task)


# =============================================================================
# HEALTH CHECK ENDPOINTS
# =============================================================================

@app.get("/health", response_model=HealthStatus, tags=["Health"])
async def health_check():
    """
    Liveness probe endpoint.

    Used by orchestration platforms (K8s, ECS) to determine if the
    application is alive. Should return quickly and not check dependencies.

    Returns 200 if the service is alive.
    """
    return HealthStatus(
        status="healthy",
        timestamp=datetime.utcnow(),
        checks={"alive": True}
    )


@app.get("/ready", response_model=HealthStatus, tags=["Health"])
async def readiness_check():
    """
    Readiness probe endpoint.

    Used to determine if the application is ready to accept traffic.
    Checks all critical dependencies.

    Returns 200 if ready, 503 if not ready.
    """
    checks = {}

    # Check if graph is initialized
    checks["graph_initialized"] = graph is not None

    # Check OpenAI API key
    settings = get_settings()
    checks["openai_configured"] = bool(settings.openai_api_key)

    # Check if we're shutting down
    checks["not_shutting_down"] = not shutdown_event.is_set()

    # Add more checks as needed:
    # checks["database"] = await check_database_connection()
    # checks["cache"] = await check_cache_connection()

    all_healthy = all(checks.values())

    if not all_healthy:
        raise HTTPException(
            status_code=503,
            detail={"status": "not_ready", "checks": checks}
        )

    return HealthStatus(
        status="ready",
        timestamp=datetime.utcnow(),
        checks=checks
    )


@app.get("/metrics", tags=["Health"])
async def metrics():
    """
    Metrics endpoint for monitoring.

    In production, you would expose Prometheus metrics here.
    See 05_monitoring_example.py for detailed implementation.
    """
    return {
        "active_requests": len(active_requests),
        "timestamp": datetime.utcnow().isoformat()
    }


# =============================================================================
# GRAPH INVOCATION ENDPOINTS
# =============================================================================

@app.post("/invoke", response_model=InvokeResponse, tags=["Graph"])
async def invoke_graph(request: InvokeRequest):
    """
    Invoke the graph synchronously.

    This endpoint runs the graph to completion and returns the final result.
    Use this for simple requests where you don't need streaming.

    Example:
        POST /invoke
        {
            "messages": [{"role": "user", "content": "Hello!"}],
            "thread_id": "my-thread-123"
        }

    Returns:
        {
            "thread_id": "my-thread-123",
            "messages": [...],
            "metadata": {"duration_seconds": 1.23}
        }
    """
    if graph is None:
        raise HTTPException(status_code=503, detail="Graph not initialized")

    # Generate thread ID if not provided
    thread_id = request.thread_id or str(uuid.uuid4())

    # Convert input messages to LangChain format
    messages = []
    for msg in request.messages:
        if msg.role == "user":
            messages.append(HumanMessage(content=msg.content))
        else:
            messages.append(AIMessage(content=msg.content))

    # Prepare config with thread ID
    config = {
        "configurable": {"thread_id": thread_id},
        **request.config
    }

    start_time = datetime.utcnow()

    try:
        # Invoke the graph
        result = await asyncio.wait_for(
            asyncio.to_thread(
                graph.invoke,
                {"messages": messages},
                config
            ),
            timeout=get_settings().request_timeout_seconds
        )

        duration = (datetime.utcnow() - start_time).total_seconds()

        # Format response
        response_messages = []
        for msg in result.get("messages", []):
            response_messages.append({
                "role": "assistant" if isinstance(msg, AIMessage) else "user",
                "content": msg.content
            })

        return InvokeResponse(
            thread_id=thread_id,
            messages=response_messages,
            metadata={
                "duration_seconds": duration,
                "model": get_settings().model_name
            }
        )

    except asyncio.TimeoutError:
        logger.error(f"Request timeout for thread {thread_id}")
        raise HTTPException(status_code=504, detail="Request timeout")
    except Exception as e:
        logger.error(f"Graph invocation failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/stream", tags=["Graph"])
async def stream_graph(request: InvokeRequest):
    """
    Invoke the graph with streaming response.

    This endpoint streams results as Server-Sent Events (SSE),
    allowing the client to receive updates in real-time.

    Example:
        POST /stream
        {
            "messages": [{"role": "user", "content": "Tell me a story"}]
        }

    Returns: Server-Sent Events stream
        data: {"type": "token", "content": "Once"}
        data: {"type": "token", "content": " upon"}
        data: {"type": "done", "thread_id": "..."}
    """
    if graph is None:
        raise HTTPException(status_code=503, detail="Graph not initialized")

    thread_id = request.thread_id or str(uuid.uuid4())

    # Convert messages
    messages = []
    for msg in request.messages:
        if msg.role == "user":
            messages.append(HumanMessage(content=msg.content))
        else:
            messages.append(AIMessage(content=msg.content))

    config = {"configurable": {"thread_id": thread_id}}

    async def generate_stream() -> AsyncGenerator[str, None]:
        """Generate SSE stream from graph execution."""
        try:
            # Stream graph execution
            for event in graph.stream(
                {"messages": messages},
                config,
                stream_mode="values"
            ):
                # Format as SSE
                import json
                data = json.dumps({
                    "type": "update",
                    "data": {
                        "messages": [
                            {"content": m.content, "role": type(m).__name__}
                            for m in event.get("messages", [])
                        ]
                    }
                })
                yield f"data: {data}\n\n"

            # Send completion event
            yield f"data: {json.dumps({'type': 'done', 'thread_id': thread_id})}\n\n"

        except Exception as e:
            logger.error(f"Stream error: {e}")
            import json
            yield f"data: {json.dumps({'type': 'error', 'message': str(e)})}\n\n"

    return StreamingResponse(
        generate_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Thread-ID": thread_id
        }
    )


# =============================================================================
# THREAD MANAGEMENT ENDPOINTS
# =============================================================================

@app.get("/threads/{thread_id}", tags=["Threads"])
async def get_thread(thread_id: str):
    """
    Get information about a specific thread.

    Returns the thread's message history and metadata.
    """
    if graph is None:
        raise HTTPException(status_code=503, detail="Graph not initialized")

    config = {"configurable": {"thread_id": thread_id}}

    try:
        # Get thread state from checkpointer
        state = graph.get_state(config)

        if state.values is None:
            raise HTTPException(status_code=404, detail="Thread not found")

        messages = []
        for msg in state.values.get("messages", []):
            messages.append({
                "role": "assistant" if isinstance(msg, AIMessage) else "user",
                "content": msg.content
            })

        return {
            "thread_id": thread_id,
            "messages": messages,
            "metadata": state.metadata or {}
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get thread {thread_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/threads/{thread_id}", tags=["Threads"])
async def delete_thread(thread_id: str, background_tasks: BackgroundTasks):
    """
    Delete a thread and its history.

    Note: This is a soft delete in most implementations.
    Actual deletion happens asynchronously.
    """
    # In a real implementation, you would:
    # 1. Mark the thread as deleted
    # 2. Schedule background cleanup

    def cleanup_thread():
        logger.info(f"Cleaning up thread {thread_id}")
        # Actual cleanup logic here

    background_tasks.add_task(cleanup_thread)

    return {"status": "deleted", "thread_id": thread_id}


# =============================================================================
# MAIN ENTRY POINT
# =============================================================================

if __name__ == "__main__":
    import uvicorn

    settings = get_settings()

    uvicorn.run(
        "03_deployment_example:app",
        host=settings.host,
        port=settings.port,
        reload=settings.debug,
        workers=1 if settings.debug else settings.workers,
        log_level=settings.log_level.lower(),
    )


# =============================================================================
# INTERVIEW TIP
# =============================================================================
"""
+------------------------------------------------------------------+
|                       INTERVIEW TIP                               |
+------------------------------------------------------------------+
| Q: "How would you ensure zero-downtime deployments for a          |
|     LangGraph API?"                                               |
|                                                                   |
| A: I would implement these strategies:                            |
|                                                                   |
| 1. Health Checks                                                  |
|    - Liveness probe: Is the process alive?                        |
|    - Readiness probe: Can it accept traffic?                      |
|    - Startup probe: Has it finished initializing?                 |
|                                                                   |
| 2. Graceful Shutdown                                              |
|    - Stop accepting new requests                                  |
|    - Wait for in-flight requests to complete                      |
|    - Set a maximum wait time (e.g., 30s)                          |
|    - Clean up resources properly                                  |
|                                                                   |
| 3. Rolling Updates                                                |
|    - Update pods one at a time                                    |
|    - Wait for new pod to be ready before terminating old          |
|    - Use PodDisruptionBudgets to ensure minimum availability      |
|                                                                   |
| 4. Connection Draining                                            |
|    - Load balancer stops sending new requests to old pods         |
|    - Existing connections are allowed to complete                 |
|                                                                   |
| 5. Blue-Green or Canary Deployments                               |
|    - Blue-Green: Switch traffic instantly between versions        |
|    - Canary: Gradually shift traffic to new version               |
+------------------------------------------------------------------+
"""
