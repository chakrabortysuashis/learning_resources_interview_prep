"""
LangGraph Testing Example
=========================

This module demonstrates comprehensive testing strategies for LangGraph
applications, including:
- Unit tests for individual nodes
- Integration tests for graph flows
- Mocking strategies for LLMs
- Testing with checkpointers
- Async testing patterns

Test Structure:
+------------------------------------------------------------------+
|                     TEST ORGANIZATION                             |
+------------------------------------------------------------------+
|                                                                   |
|   Unit Tests                                                      |
|   +----------------------------------------------------------+   |
|   | test_nodes.py        - Individual node logic              |   |
|   | test_reducers.py     - State reduction functions          |   |
|   | test_routing.py      - Conditional edge functions         |   |
|   +----------------------------------------------------------+   |
|                                                                   |
|   Integration Tests                                               |
|   +----------------------------------------------------------+   |
|   | test_graph_flow.py   - Complete graph execution           |   |
|   | test_streaming.py    - Streaming functionality            |   |
|   | test_persistence.py  - Checkpointing and state            |   |
|   +----------------------------------------------------------+   |
|                                                                   |
|   E2E Tests                                                       |
|   +----------------------------------------------------------+   |
|   | test_e2e.py          - Full system with real LLMs         |   |
|   +----------------------------------------------------------+   |
|                                                                   |
+------------------------------------------------------------------+

Usage:
    # Run all tests
    pytest 07_testing_example.py -v

    # Run only unit tests
    pytest 07_testing_example.py -v -m "not integration and not e2e"

    # Run with coverage
    pytest 07_testing_example.py --cov=my_graph --cov-report=html
"""

import pytest
import asyncio
from typing import List, Dict, Any, Optional
from unittest.mock import Mock, patch, MagicMock
from dataclasses import dataclass

# LangGraph imports
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.memory import MemorySaver
from langchain_core.messages import HumanMessage, AIMessage, BaseMessage, ToolMessage
from langchain_openai import ChatOpenAI


# =============================================================================
# GRAPH UNDER TEST
# =============================================================================

class ChatState(dict):
    """State for the chat graph being tested."""
    messages: List[BaseMessage]
    intent: Optional[str]
    context: Optional[Dict[str, Any]]
    tool_calls_count: int


def create_test_graph(llm=None):
    """
    Create a simple chat graph for testing.

    Graph structure:

        +-------+     +-----------+     +------------+
        | START | --> | classify  | --> |   route    |
        +-------+     +-----------+     +------------+
                                              |
                      +----------+------------+----------+
                      |          |            |          |
                      v          v            v          v
                 +--------+ +--------+  +---------+ +-------+
                 |  qa    | |  help  |  | escalate| |  end  |
                 +--------+ +--------+  +---------+ +-------+
                      |          |            |
                      +----------+------------+
                                 |
                                 v
                             +-------+
                             |  END  |
                             +-------+
    """

    # Use provided LLM or create default
    if llm is None:
        llm = ChatOpenAI(model="gpt-3.5-turbo", temperature=0)

    def classify_intent(state: ChatState) -> ChatState:
        """Classify the user's intent from their message."""
        messages = state.get("messages", [])

        if not messages:
            return {"intent": "unknown"}

        last_message = messages[-1]
        content = last_message.content.lower() if hasattr(last_message, 'content') else ""

        # Simple rule-based classification for testing
        if "help" in content or "how" in content:
            intent = "help"
        elif "problem" in content or "issue" in content or "error" in content:
            intent = "escalate"
        elif "?" in content:
            intent = "question"
        else:
            intent = "general"

        return {"intent": intent}

    def route_by_intent(state: ChatState) -> str:
        """Route to appropriate node based on intent."""
        intent = state.get("intent", "general")

        routes = {
            "question": "qa_node",
            "help": "help_node",
            "escalate": "escalate_node",
            "general": "qa_node",
            "unknown": "help_node"
        }

        return routes.get(intent, "qa_node")

    def qa_node(state: ChatState) -> ChatState:
        """Handle question answering."""
        messages = state.get("messages", [])

        # Use LLM for response
        response = llm.invoke(messages)

        return {"messages": messages + [response]}

    def help_node(state: ChatState) -> ChatState:
        """Provide help information."""
        messages = state.get("messages", [])

        help_response = AIMessage(
            content="I'm here to help! You can ask me questions, "
                    "report issues, or request assistance with any topic."
        )

        return {"messages": messages + [help_response]}

    def escalate_node(state: ChatState) -> ChatState:
        """Handle escalation to human support."""
        messages = state.get("messages", [])

        escalate_response = AIMessage(
            content="I understand you're experiencing an issue. "
                    "I'm connecting you with our support team."
        )

        return {
            "messages": messages + [escalate_response],
            "context": {"escalated": True, "reason": state.get("intent")}
        }

    # Build the graph
    builder = StateGraph(ChatState)

    # Add nodes
    builder.add_node("classify", classify_intent)
    builder.add_node("qa_node", qa_node)
    builder.add_node("help_node", help_node)
    builder.add_node("escalate_node", escalate_node)

    # Add edges
    builder.add_edge(START, "classify")
    builder.add_conditional_edges("classify", route_by_intent)
    builder.add_edge("qa_node", END)
    builder.add_edge("help_node", END)
    builder.add_edge("escalate_node", END)

    return builder.compile()


# =============================================================================
# TEST FIXTURES
# =============================================================================

@pytest.fixture
def mock_llm():
    """
    Create a mock LLM for testing.

    This mock returns predictable responses, making tests deterministic.
    """
    mock = Mock(spec=ChatOpenAI)
    mock.invoke.return_value = AIMessage(content="This is a mock response.")
    return mock


@pytest.fixture
def mock_llm_with_responses():
    """
    Create a mock LLM that returns different responses sequentially.

    Useful for testing multi-turn conversations.
    """
    mock = Mock(spec=ChatOpenAI)
    mock.invoke.side_effect = [
        AIMessage(content="First response"),
        AIMessage(content="Second response"),
        AIMessage(content="Third response"),
    ]
    return mock


@pytest.fixture
def graph(mock_llm):
    """Create a graph with mocked LLM for testing."""
    return create_test_graph(llm=mock_llm)


@pytest.fixture
def graph_with_checkpointer(mock_llm):
    """Create a graph with memory checkpointer for persistence testing."""
    builder = StateGraph(ChatState)

    # Simplified graph for checkpointer testing
    def chat_node(state: ChatState) -> ChatState:
        messages = state.get("messages", [])
        response = mock_llm.invoke(messages)
        return {"messages": messages + [response]}

    builder.add_node("chat", chat_node)
    builder.add_edge(START, "chat")
    builder.add_edge("chat", END)

    checkpointer = MemorySaver()
    return builder.compile(checkpointer=checkpointer)


# =============================================================================
# UNIT TESTS: NODES
# =============================================================================

class TestClassifyIntentNode:
    """Unit tests for the intent classification node."""

    def test_classifies_question_intent(self):
        """Should classify messages with '?' as questions."""
        from langgraph.graph import StateGraph

        # Test the classification logic directly
        state = {"messages": [HumanMessage(content="What is Python?")]}

        # Extract classification logic
        content = state["messages"][-1].content.lower()
        if "?" in content:
            intent = "question"
        else:
            intent = "general"

        assert intent == "question"

    def test_classifies_help_intent(self):
        """Should classify 'help' or 'how' as help requests."""
        test_cases = [
            "How do I use this?",
            "Help me understand",
            "I need help",
        ]

        for content in test_cases:
            if "help" in content.lower() or "how" in content.lower():
                intent = "help"
            else:
                intent = "general"

            assert intent == "help", f"Failed for: {content}"

    def test_classifies_escalation_intent(self):
        """Should classify problems/issues as escalation."""
        test_cases = [
            "I have a problem",
            "There's an issue with my order",
            "Error in the system",
        ]

        for content in test_cases:
            content_lower = content.lower()
            if any(word in content_lower for word in ["problem", "issue", "error"]):
                intent = "escalate"
            else:
                intent = "general"

            assert intent == "escalate", f"Failed for: {content}"

    def test_handles_empty_messages(self):
        """Should handle empty message list gracefully."""
        state = {"messages": []}

        if not state["messages"]:
            intent = "unknown"

        assert intent == "unknown"


class TestRouteByIntent:
    """Unit tests for the routing function."""

    @pytest.mark.parametrize("intent,expected_node", [
        ("question", "qa_node"),
        ("help", "help_node"),
        ("escalate", "escalate_node"),
        ("general", "qa_node"),
        ("unknown", "help_node"),
    ])
    def test_routes_correctly(self, intent, expected_node):
        """Should route to correct node based on intent."""
        routes = {
            "question": "qa_node",
            "help": "help_node",
            "escalate": "escalate_node",
            "general": "qa_node",
            "unknown": "help_node"
        }

        result = routes.get(intent, "qa_node")
        assert result == expected_node

    def test_handles_unknown_intent(self):
        """Should default to qa_node for unknown intents."""
        routes = {"question": "qa_node"}
        result = routes.get("nonexistent", "qa_node")

        assert result == "qa_node"


# =============================================================================
# UNIT TESTS: STATE MANAGEMENT
# =============================================================================

class TestStateManagement:
    """Tests for state handling and reducers."""

    def test_messages_append_correctly(self):
        """Messages should be appended, not replaced."""
        initial_messages = [HumanMessage(content="Hello")]
        new_message = AIMessage(content="Hi there!")

        # Simulate state update
        updated_messages = initial_messages + [new_message]

        assert len(updated_messages) == 2
        assert isinstance(updated_messages[0], HumanMessage)
        assert isinstance(updated_messages[1], AIMessage)

    def test_state_preserves_metadata(self):
        """State updates should preserve existing metadata."""
        initial_state = {
            "messages": [],
            "intent": None,
            "context": {"user_id": "123"},
            "tool_calls_count": 0
        }

        # Simulate partial update
        update = {"intent": "question"}

        # LangGraph merges updates
        final_state = {**initial_state, **update}

        assert final_state["context"]["user_id"] == "123"
        assert final_state["intent"] == "question"


# =============================================================================
# INTEGRATION TESTS: GRAPH FLOW
# =============================================================================

class TestGraphFlow:
    """Integration tests for complete graph execution."""

    def test_graph_executes_successfully(self, graph):
        """Graph should complete without errors."""
        result = graph.invoke({
            "messages": [HumanMessage(content="Hello")]
        })

        assert "messages" in result
        assert len(result["messages"]) >= 1

    def test_graph_routes_question_correctly(self, graph, mock_llm):
        """Questions should be routed to QA node."""
        result = graph.invoke({
            "messages": [HumanMessage(content="What is the capital of France?")]
        })

        # QA node uses the LLM
        mock_llm.invoke.assert_called_once()

    def test_graph_routes_help_correctly(self, graph, mock_llm):
        """Help requests should be routed to help node."""
        result = graph.invoke({
            "messages": [HumanMessage(content="Help me please")]
        })

        # Help node doesn't use LLM
        mock_llm.invoke.assert_not_called()

        # Should have help message
        last_message = result["messages"][-1]
        assert "help" in last_message.content.lower()

    def test_graph_handles_escalation(self, graph, mock_llm):
        """Issues should be escalated correctly."""
        result = graph.invoke({
            "messages": [HumanMessage(content="I have a problem with my order")]
        })

        # Check escalation
        assert result.get("context", {}).get("escalated") == True

    def test_graph_preserves_message_history(self, graph):
        """Graph should maintain complete message history."""
        messages = [
            HumanMessage(content="Hello"),
        ]

        result = graph.invoke({"messages": messages})

        # Original message should still be there
        assert any(
            isinstance(m, HumanMessage) and m.content == "Hello"
            for m in result["messages"]
        )


class TestGraphWithCheckpointer:
    """Tests for graph persistence and state recovery."""

    def test_state_is_persisted(self, graph_with_checkpointer):
        """State should be saved after execution."""
        config = {"configurable": {"thread_id": "test-thread-1"}}

        result = graph_with_checkpointer.invoke(
            {"messages": [HumanMessage(content="Hello")]},
            config
        )

        # Get state from checkpointer
        state = graph_with_checkpointer.get_state(config)

        assert state.values is not None
        assert len(state.values.get("messages", [])) > 0

    def test_conversation_continuity(self, graph_with_checkpointer, mock_llm):
        """Continued conversations should include history."""
        config = {"configurable": {"thread_id": "test-thread-2"}}

        # Configure mock for multiple calls
        mock_llm.invoke.side_effect = [
            AIMessage(content="Response 1"),
            AIMessage(content="Response 2"),
        ]

        # First turn
        graph_with_checkpointer.invoke(
            {"messages": [HumanMessage(content="First message")]},
            config
        )

        # Second turn
        result = graph_with_checkpointer.invoke(
            {"messages": [HumanMessage(content="Second message")]},
            config
        )

        # Should have full history
        assert len(result["messages"]) >= 2

    def test_different_threads_isolated(self, graph_with_checkpointer):
        """Different threads should have isolated state."""
        config1 = {"configurable": {"thread_id": "thread-a"}}
        config2 = {"configurable": {"thread_id": "thread-b"}}

        # Invoke on thread A
        graph_with_checkpointer.invoke(
            {"messages": [HumanMessage(content="Thread A message")]},
            config1
        )

        # Invoke on thread B
        graph_with_checkpointer.invoke(
            {"messages": [HumanMessage(content="Thread B message")]},
            config2
        )

        # Get states
        state_a = graph_with_checkpointer.get_state(config1)
        state_b = graph_with_checkpointer.get_state(config2)

        # Should be different
        assert state_a.values["messages"][0].content != state_b.values["messages"][0].content


# =============================================================================
# INTEGRATION TESTS: STREAMING
# =============================================================================

class TestStreaming:
    """Tests for streaming functionality."""

    def test_stream_yields_events(self, graph):
        """Streaming should yield events for each node."""
        events = list(graph.stream(
            {"messages": [HumanMessage(content="Hello")]},
            stream_mode="values"
        ))

        assert len(events) > 0

    def test_stream_updates_mode(self, graph):
        """Updates mode should yield node outputs."""
        events = list(graph.stream(
            {"messages": [HumanMessage(content="Hello")]},
            stream_mode="updates"
        ))

        # Should have updates from nodes
        node_names = [list(e.keys())[0] for e in events if e]
        assert "classify" in node_names or len(node_names) > 0


# =============================================================================
# ASYNC TESTS
# =============================================================================

class TestAsyncExecution:
    """Tests for async graph execution."""

    @pytest.fixture
    def async_graph(self, mock_llm):
        """Create an async-capable graph."""
        return create_test_graph(llm=mock_llm)

    @pytest.mark.asyncio
    async def test_async_invoke(self, async_graph):
        """Graph should support async invocation."""
        result = await async_graph.ainvoke({
            "messages": [HumanMessage(content="Hello")]
        })

        assert "messages" in result

    @pytest.mark.asyncio
    async def test_async_stream(self, async_graph):
        """Graph should support async streaming."""
        events = []
        async for event in async_graph.astream(
            {"messages": [HumanMessage(content="Hello")]},
            stream_mode="values"
        ):
            events.append(event)

        assert len(events) > 0

    @pytest.mark.asyncio
    async def test_concurrent_invocations(self, async_graph):
        """Graph should handle concurrent invocations."""
        tasks = [
            async_graph.ainvoke({"messages": [HumanMessage(content=f"Message {i}")]})
            for i in range(3)
        ]

        results = await asyncio.gather(*tasks)

        assert len(results) == 3
        assert all("messages" in r for r in results)


# =============================================================================
# ERROR HANDLING TESTS
# =============================================================================

class TestErrorHandling:
    """Tests for error handling and edge cases."""

    def test_handles_empty_input(self, graph):
        """Graph should handle empty message list."""
        result = graph.invoke({"messages": []})

        # Should not crash, should have some response
        assert "messages" in result

    def test_handles_llm_error(self):
        """Graph should handle LLM errors gracefully."""
        # Create mock that raises error
        error_llm = Mock()
        error_llm.invoke.side_effect = Exception("LLM API error")

        graph = create_test_graph(llm=error_llm)

        # Should raise the error (or handle it if error handling is implemented)
        with pytest.raises(Exception):
            graph.invoke({
                "messages": [HumanMessage(content="What is Python?")]
            })

    def test_handles_malformed_state(self, graph):
        """Graph should handle malformed state input."""
        # Missing required keys - should still work
        result = graph.invoke({})

        assert "messages" in result or "intent" in result


# =============================================================================
# MOCK RESPONSE FIXTURES
# =============================================================================

class MockResponses:
    """Predefined mock responses for testing."""

    GREETING = AIMessage(content="Hello! How can I help you today?")

    HELP_INFO = AIMessage(
        content="I can help you with: questions, problems, and general assistance."
    )

    ESCALATION = AIMessage(
        content="I'm connecting you with a human agent."
    )

    ERROR = AIMessage(
        content="I apologize, but I encountered an error. Please try again."
    )

    @classmethod
    def get_qa_response(cls, topic: str) -> AIMessage:
        """Generate a mock QA response for a topic."""
        return AIMessage(content=f"Here's information about {topic}...")


# =============================================================================
# EVALUATION TESTS (For use with LangSmith)
# =============================================================================

class TestEvaluation:
    """
    Evaluation-based tests for quality assessment.

    These tests use criteria-based evaluation rather than exact matching.
    In production, you would use LangSmith's evaluation framework.
    """

    def test_response_is_not_empty(self, graph):
        """Responses should never be empty."""
        result = graph.invoke({
            "messages": [HumanMessage(content="Tell me something")]
        })

        response = result["messages"][-1].content
        assert len(response) > 0

    def test_response_is_relevant(self, graph, mock_llm):
        """Response should be relevant to the question."""
        mock_llm.invoke.return_value = AIMessage(
            content="Python is a high-level programming language."
        )

        result = graph.invoke({
            "messages": [HumanMessage(content="What is Python?")]
        })

        response = result["messages"][-1].content.lower()

        # Check for topic relevance (simple keyword check)
        assert "python" in response or "programming" in response

    def test_escalation_mentions_support(self, graph):
        """Escalation should mention support/help."""
        result = graph.invoke({
            "messages": [HumanMessage(content="I have a problem")]
        })

        response = result["messages"][-1].content.lower()

        assert any(word in response for word in ["support", "team", "help", "connecting"])


# =============================================================================
# MAIN TEST RUNNER
# =============================================================================

if __name__ == "__main__":
    # Run tests with pytest
    pytest.main([__file__, "-v", "--tb=short"])


# =============================================================================
# INTERVIEW TIP
# =============================================================================
"""
+------------------------------------------------------------------+
|                       INTERVIEW TIP                               |
+------------------------------------------------------------------+
| Q: "How do you test a LangGraph application that uses external    |
|     services like OpenAI?"                                        |
|                                                                   |
| A: I use a layered mocking strategy:                              |
|                                                                   |
| 1. Unit Tests (Most tests)                                        |
|    - Mock ALL external services                                   |
|    - Test individual nodes in isolation                           |
|    - Test routing logic with fixed inputs                         |
|    - Fast, deterministic, free                                    |
|                                                                   |
| 2. Integration Tests (Many tests)                                 |
|    - Mock LLMs but use real databases if possible                 |
|    - Test complete graph flows                                    |
|    - Test checkpointing and state management                      |
|    - Medium speed, deterministic                                  |
|                                                                   |
| 3. Contract Tests (Few tests)                                     |
|    - Test that mocks match real API behavior                      |
|    - Run periodically against real APIs                           |
|    - Ensures mocks don't drift from reality                       |
|                                                                   |
| 4. E2E Tests (Very few tests)                                     |
|    - Use real services for critical paths                         |
|    - Run before deployment                                        |
|    - Use semantic assertions, not exact matches                   |
|    - Expensive but high confidence                                |
|                                                                   |
| Key pattern: Use dependency injection to swap implementations:    |
|                                                                   |
|   def create_graph(llm=None):                                     |
|       llm = llm or ChatOpenAI()  # Default to real                |
|       ...                                                         |
|                                                                   |
|   # In tests:                                                     |
|   mock_llm = Mock()                                               |
|   graph = create_graph(llm=mock_llm)                              |
+------------------------------------------------------------------+
"""
