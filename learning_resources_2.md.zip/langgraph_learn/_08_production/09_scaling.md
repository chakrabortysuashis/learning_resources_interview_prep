# Scaling LangGraph Applications

## Overview

Scaling LangGraph applications presents unique challenges due to LLM latency,
token costs, and state management complexity. This guide covers strategies for
handling increased load efficiently.

```
+------------------------------------------------------------------+
|                    SCALING DIMENSIONS                             |
+------------------------------------------------------------------+
|                                                                   |
|   +------------+     +------------+     +------------+            |
|   |  Vertical  |     | Horizontal |     | Functional |            |
|   |  Scaling   |     |  Scaling   |     |  Scaling   |            |
|   +------------+     +------------+     +------------+            |
|        |                  |                  |                    |
|        v                  v                  v                    |
|   More CPU/RAM       More instances      Split by function        |
|   per instance       behind LB           (microservices)          |
|                                                                   |
|   Best for:          Best for:           Best for:                |
|   - Dev/Test         - Production        - Complex systems        |
|   - Predictable      - Variable load     - Team scaling           |
|     load                                                          |
|                                                                   |
+------------------------------------------------------------------+
```

## Async Execution

### Why Async Matters for LLM Applications

```
+------------------------------------------------------------------+
|              SYNC vs ASYNC COMPARISON                             |
+------------------------------------------------------------------+
|                                                                   |
|   Synchronous (Blocking):                                         |
|   -----------------------                                         |
|   Thread 1: [Request]=====[Wait for LLM]=====[Response]           |
|   Thread 2:          [Request]=====[Wait]=====....                |
|   Thread 3:                   [Request]====[Wait]====...          |
|                                                                   |
|   Problem: Each request blocks a thread during LLM wait           |
|   Result: Need many threads, high memory usage                    |
|                                                                   |
|   Asynchronous (Non-Blocking):                                    |
|   ----------------------------                                    |
|   Event Loop: [Req1][Req2][Req3]...[Resp1][Resp2][Resp3]...       |
|                  |     |     |        ^      ^      ^             |
|                  +-----+-----+--------+------+------+             |
|                  (Concurrent LLM calls)                           |
|                                                                   |
|   Benefit: Single thread handles many concurrent requests         |
|   Result: Better resource utilization, higher throughput          |
|                                                                   |
+------------------------------------------------------------------+
```

### Async Graph Implementation

```python
import asyncio
from typing import List, Dict, Any
from langgraph.graph import StateGraph, START, END
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, AIMessage

class AsyncChatState(dict):
    """State for async chat graph."""
    messages: List
    metadata: Dict[str, Any]


def create_async_graph():
    """
    Create an async-optimized graph.
    
    Key considerations:
    1. Use async node functions where possible
    2. LangChain's ChatOpenAI supports async natively
    3. Use asyncio for concurrent operations within nodes
    """
    
    # LLM with async support
    llm = ChatOpenAI(
        model="gpt-4",
        temperature=0.7,
    )
    
    async def process_node(state: AsyncChatState) -> AsyncChatState:
        """Async node that processes messages."""
        messages = state.get("messages", [])
        
        # Async LLM call - doesn't block the event loop
        response = await llm.ainvoke(messages)
        
        return {"messages": messages + [response]}
    
    async def enrich_node(state: AsyncChatState) -> AsyncChatState:
        """Async node that enriches context."""
        # Simulate async operations (e.g., database lookup, API calls)
        await asyncio.sleep(0.1)
        
        return {"metadata": {"enriched": True}}
    
    # Build graph
    builder = StateGraph(AsyncChatState)
    builder.add_node("process", process_node)
    builder.add_node("enrich", enrich_node)
    builder.add_edge(START, "enrich")
    builder.add_edge("enrich", "process")
    builder.add_edge("process", END)
    
    return builder.compile()


# Usage
async def handle_request(input_data: dict):
    graph = create_async_graph()
    result = await graph.ainvoke(input_data)
    return result


# Running concurrent requests
async def handle_multiple_requests(requests: List[dict]):
    """Handle multiple requests concurrently."""
    graph = create_async_graph()
    
    # Create tasks for all requests
    tasks = [graph.ainvoke(req) for req in requests]
    
    # Execute concurrently
    results = await asyncio.gather(*tasks)
    
    return results
```

### Async Best Practices

```python
# DO: Use async context managers

async def async_with_resources():
    async with aiohttp.ClientSession() as session:
        # Use session for multiple requests
        pass


# DO: Use asyncio.gather for concurrent operations

async def parallel_operations(state):
    """Run independent operations in parallel."""
    
    # These operations don't depend on each other
    results = await asyncio.gather(
        fetch_context(state),
        get_user_preferences(state),
        load_history(state),
    )
    
    context, preferences, history = results
    return {
        "context": context,
        "preferences": preferences,
        "history": history
    }


# DON'T: Block the event loop with sync operations

async def bad_example(state):
    # This blocks the event loop!
    import time
    time.sleep(5)  # BAD
    
    # Use this instead
    await asyncio.sleep(5)  # GOOD


# DO: Use semaphores for rate limiting

class RateLimitedClient:
    """Client with async rate limiting."""
    
    def __init__(self, max_concurrent: int = 10):
        self.semaphore = asyncio.Semaphore(max_concurrent)
    
    async def call_api(self, data):
        async with self.semaphore:
            # Only max_concurrent calls at a time
            return await self._make_request(data)
```

## Batching Strategies

### Why Batching Helps

```
+------------------------------------------------------------------+
|                    BATCHING BENEFITS                              |
+------------------------------------------------------------------+
|                                                                   |
|   Without Batching:                                               |
|   -----------------                                               |
|   Request 1 --> [API Call] --> Response 1                         |
|   Request 2 --> [API Call] --> Response 2                         |
|   Request 3 --> [API Call] --> Response 3                         |
|   Request 4 --> [API Call] --> Response 4                         |
|                                                                   |
|   4 API calls, 4x latency overhead                                |
|                                                                   |
|   With Batching:                                                  |
|   --------------                                                  |
|   Request 1 --|                                                   |
|   Request 2 --|-> [Single Batch API Call] --> Response 1,2,3,4    |
|   Request 3 --|                                                   |
|   Request 4 --|                                                   |
|                                                                   |
|   1 API call, reduced overhead                                    |
|                                                                   |
|   Best for:                                                       |
|   - Embedding generation                                          |
|   - Vector database operations                                    |
|   - Bulk processing                                               |
|                                                                   |
+------------------------------------------------------------------+
```

### Batch Processing Implementation

```python
import asyncio
from typing import List, Dict, Any, Callable
from dataclasses import dataclass
from collections import defaultdict
import time

@dataclass
class BatchConfig:
    """Configuration for batch processing."""
    max_batch_size: int = 10
    max_wait_time: float = 0.1  # seconds
    enabled: bool = True


class BatchProcessor:
    """
    Batch processor for efficient API calls.
    
    Collects individual requests and processes them in batches
    to reduce API overhead.
    """
    
    def __init__(
        self,
        process_batch: Callable,
        config: BatchConfig = None
    ):
        self.process_batch = process_batch
        self.config = config or BatchConfig()
        self.queue: List[Dict] = []
        self.futures: List[asyncio.Future] = []
        self.lock = asyncio.Lock()
        self._batch_task = None
    
    async def add(self, item: Dict) -> Any:
        """Add item to batch queue and wait for result."""
        if not self.config.enabled:
            # Process immediately if batching disabled
            results = await self.process_batch([item])
            return results[0]
        
        future = asyncio.Future()
        
        async with self.lock:
            self.queue.append(item)
            self.futures.append(future)
            
            # Start batch timer if this is the first item
            if len(self.queue) == 1:
                self._batch_task = asyncio.create_task(
                    self._wait_and_process()
                )
            
            # Process immediately if batch is full
            if len(self.queue) >= self.config.max_batch_size:
                await self._process_current_batch()
        
        return await future
    
    async def _wait_and_process(self):
        """Wait for max_wait_time then process batch."""
        await asyncio.sleep(self.config.max_wait_time)
        async with self.lock:
            if self.queue:
                await self._process_current_batch()
    
    async def _process_current_batch(self):
        """Process all items in current batch."""
        if not self.queue:
            return
        
        items = self.queue.copy()
        futures = self.futures.copy()
        self.queue.clear()
        self.futures.clear()
        
        try:
            results = await self.process_batch(items)
            for future, result in zip(futures, results):
                future.set_result(result)
        except Exception as e:
            for future in futures:
                future.set_exception(e)


# Usage example: Batch embeddings
class BatchEmbeddings:
    """Batch embedding generation for efficiency."""
    
    def __init__(self, embeddings_model):
        self.embeddings_model = embeddings_model
        self.processor = BatchProcessor(
            process_batch=self._generate_batch,
            config=BatchConfig(max_batch_size=100, max_wait_time=0.05)
        )
    
    async def _generate_batch(self, texts: List[str]) -> List[List[float]]:
        """Generate embeddings for a batch of texts."""
        return await self.embeddings_model.aembed_documents(texts)
    
    async def embed(self, text: str) -> List[float]:
        """Embed a single text (automatically batched)."""
        return await self.processor.add(text)


# In a LangGraph node
async def batch_embedding_node(state):
    """Node that uses batched embeddings."""
    batch_embedder = BatchEmbeddings(embeddings_model)
    
    documents = state.get("documents", [])
    
    # These will be automatically batched
    embedding_tasks = [
        batch_embedder.embed(doc.page_content)
        for doc in documents
    ]
    
    embeddings = await asyncio.gather(*embedding_tasks)
    
    return {"embeddings": embeddings}
```

## Horizontal Scaling

### Load Balancing Architecture

```
+------------------------------------------------------------------+
|              HORIZONTALLY SCALED ARCHITECTURE                     |
+------------------------------------------------------------------+
|                                                                   |
|                         Internet                                  |
|                            |                                      |
|                            v                                      |
|                   +----------------+                              |
|                   | Load Balancer  |                              |
|                   | (Round Robin)  |                              |
|                   +----------------+                              |
|                            |                                      |
|            +---------------+---------------+                      |
|            |               |               |                      |
|            v               v               v                      |
|     +----------+    +----------+    +----------+                  |
|     | Instance |    | Instance |    | Instance |                  |
|     |    1     |    |    2     |    |    3     |                  |
|     +----------+    +----------+    +----------+                  |
|            |               |               |                      |
|            +---------------+---------------+                      |
|                            |                                      |
|                            v                                      |
|                   +----------------+                              |
|                   | Shared State   |                              |
|                   | (Redis/Postgres)|                             |
|                   +----------------+                              |
|                                                                   |
+------------------------------------------------------------------+
```

### Stateless Design for Scaling

```python
"""
Stateless graph design for horizontal scaling.

Key principle: Don't store state in instance memory.
Use external storage for all state.
"""

from langgraph.checkpoint.postgres import PostgresSaver
import redis

class ScalableGraphService:
    """
    Scalable graph service that works with multiple instances.
    """
    
    def __init__(self, postgres_url: str, redis_url: str):
        # External state storage
        self.checkpointer = PostgresSaver.from_conn_string(postgres_url)
        self.redis = redis.from_url(redis_url)
        self.graph = self._create_graph()
    
    def _create_graph(self):
        """Create graph with external checkpointer."""
        builder = StateGraph(ChatState)
        # ... add nodes ...
        return builder.compile(checkpointer=self.checkpointer)
    
    async def invoke(self, thread_id: str, input_data: dict):
        """
        Invoke graph with external state.
        
        Any instance can handle any thread because
        state is stored externally.
        """
        config = {"configurable": {"thread_id": thread_id}}
        return await self.graph.ainvoke(input_data, config)
    
    async def acquire_lock(self, thread_id: str, timeout: int = 30) -> bool:
        """
        Acquire distributed lock for thread.
        
        Prevents concurrent modifications to same thread
        across instances.
        """
        lock_key = f"lock:{thread_id}"
        return self.redis.set(lock_key, "1", nx=True, ex=timeout)
    
    async def release_lock(self, thread_id: str):
        """Release distributed lock."""
        lock_key = f"lock:{thread_id}"
        self.redis.delete(lock_key)


# FastAPI with stateless design
from fastapi import FastAPI, HTTPException

app = FastAPI()
service = ScalableGraphService(
    postgres_url="postgresql://...",
    redis_url="redis://..."
)

@app.post("/invoke/{thread_id}")
async def invoke_graph(thread_id: str, input_data: dict):
    # Acquire lock to prevent concurrent modifications
    if not await service.acquire_lock(thread_id):
        raise HTTPException(
            status_code=409,
            detail="Thread is being processed by another request"
        )
    
    try:
        result = await service.invoke(thread_id, input_data)
        return result
    finally:
        await service.release_lock(thread_id)
```

## Caching Strategies

### Caching Architecture

```
+------------------------------------------------------------------+
|                    CACHING LAYERS                                 |
+------------------------------------------------------------------+
|                                                                   |
|   Request --> [L1: In-Memory] --> [L2: Redis] --> [LLM API]       |
|                    |                   |               |          |
|                    v                   v               v          |
|               Fastest             Fast            Slowest         |
|               (ns-us)            (ms)             (s)             |
|               Per-instance       Shared           External        |
|                                                                   |
|   What to Cache:                                                  |
|   --------------                                                  |
|   - Embeddings (high reuse potential)                             |
|   - Static LLM responses (FAQ-like queries)                       |
|   - Tool results (when inputs are identical)                      |
|   - Intermediate computations                                     |
|                                                                   |
|   What NOT to Cache:                                              |
|   ------------------                                              |
|   - Conversational responses (context-dependent)                  |
|   - Time-sensitive data                                           |
|   - User-specific results                                         |
|                                                                   |
+------------------------------------------------------------------+
```

### Caching Implementation

```python
import hashlib
import json
from typing import Optional, Any
from functools import wraps
import redis.asyncio as redis

class LLMCache:
    """
    Caching layer for LLM responses.
    
    Uses semantic hashing to identify similar queries.
    """
    
    def __init__(self, redis_url: str, ttl: int = 3600):
        self.redis = redis.from_url(redis_url)
        self.ttl = ttl
    
    def _generate_key(self, messages: list, model: str) -> str:
        """Generate cache key from messages and model."""
        content = json.dumps({
            "messages": [
                {"role": m.type, "content": m.content}
                for m in messages
            ],
            "model": model
        }, sort_keys=True)
        
        hash_value = hashlib.sha256(content.encode()).hexdigest()
        return f"llm_cache:{hash_value}"
    
    async def get(self, messages: list, model: str) -> Optional[str]:
        """Get cached response if available."""
        key = self._generate_key(messages, model)
        result = await self.redis.get(key)
        return result.decode() if result else None
    
    async def set(self, messages: list, model: str, response: str):
        """Cache a response."""
        key = self._generate_key(messages, model)
        await self.redis.setex(key, self.ttl, response)


def with_cache(cache: LLMCache):
    """Decorator to add caching to LLM calls."""
    def decorator(func):
        @wraps(func)
        async def wrapper(messages, **kwargs):
            model = kwargs.get("model", "default")
            
            # Check cache
            cached = await cache.get(messages, model)
            if cached:
                return AIMessage(content=cached)
            
            # Call LLM
            result = await func(messages, **kwargs)
            
            # Cache result
            await cache.set(messages, model, result.content)
            
            return result
        return wrapper
    return decorator


# Usage
cache = LLMCache(redis_url="redis://localhost:6379")

@with_cache(cache)
async def cached_llm_call(messages, model="gpt-4"):
    return await llm.ainvoke(messages)
```

## Queue-Based Processing

### Message Queue Architecture

```
+------------------------------------------------------------------+
|              QUEUE-BASED ARCHITECTURE                             |
+------------------------------------------------------------------+
|                                                                   |
|   API Server (Fast)                                               |
|   +----------------------------------------------------------+   |
|   |  Receive Request --> Validate --> Enqueue --> Return 202 |   |
|   +----------------------------------------------------------+   |
|                              |                                    |
|                              v                                    |
|   +----------------------------------------------------------+   |
|   |                    Message Queue                          |   |
|   |              (Redis, RabbitMQ, SQS)                       |   |
|   +----------------------------------------------------------+   |
|                              |                                    |
|         +--------------------+--------------------+               |
|         |                    |                    |               |
|         v                    v                    v               |
|   +-----------+        +-----------+        +-----------+        |
|   |  Worker 1 |        |  Worker 2 |        |  Worker 3 |        |
|   |  (Graph)  |        |  (Graph)  |        |  (Graph)  |        |
|   +-----------+        +-----------+        +-----------+        |
|         |                    |                    |               |
|         +--------------------+--------------------+               |
|                              |                                    |
|                              v                                    |
|   +----------------------------------------------------------+   |
|   |              Results Store (Redis/S3)                     |   |
|   +----------------------------------------------------------+   |
|                                                                   |
+------------------------------------------------------------------+
```

### Queue Implementation

```python
import asyncio
import json
from typing import Dict, Any
from dataclasses import dataclass
import redis.asyncio as redis

@dataclass
class Job:
    """Represents a processing job."""
    job_id: str
    input_data: Dict[str, Any]
    thread_id: str
    created_at: float


class JobQueue:
    """
    Distributed job queue for graph processing.
    """
    
    def __init__(self, redis_url: str):
        self.redis = redis.from_url(redis_url)
        self.queue_name = "langgraph:jobs"
        self.results_prefix = "langgraph:results:"
    
    async def enqueue(self, job: Job) -> str:
        """Add job to queue."""
        job_data = json.dumps({
            "job_id": job.job_id,
            "input_data": job.input_data,
            "thread_id": job.thread_id,
            "created_at": job.created_at
        })
        
        await self.redis.lpush(self.queue_name, job_data)
        return job.job_id
    
    async def dequeue(self, timeout: int = 30) -> Optional[Job]:
        """Get next job from queue (blocking)."""
        result = await self.redis.brpop(self.queue_name, timeout=timeout)
        
        if not result:
            return None
        
        _, job_data = result
        data = json.loads(job_data)
        
        return Job(
            job_id=data["job_id"],
            input_data=data["input_data"],
            thread_id=data["thread_id"],
            created_at=data["created_at"]
        )
    
    async def store_result(self, job_id: str, result: Any, ttl: int = 3600):
        """Store job result."""
        key = f"{self.results_prefix}{job_id}"
        await self.redis.setex(key, ttl, json.dumps(result))
    
    async def get_result(self, job_id: str) -> Optional[Dict]:
        """Get job result if available."""
        key = f"{self.results_prefix}{job_id}"
        result = await self.redis.get(key)
        return json.loads(result) if result else None


class Worker:
    """
    Worker that processes jobs from queue.
    """
    
    def __init__(self, queue: JobQueue, graph):
        self.queue = queue
        self.graph = graph
        self.running = False
    
    async def run(self):
        """Main worker loop."""
        self.running = True
        
        while self.running:
            try:
                job = await self.queue.dequeue(timeout=5)
                
                if job:
                    await self.process_job(job)
                    
            except Exception as e:
                print(f"Worker error: {e}")
                await asyncio.sleep(1)
    
    async def process_job(self, job: Job):
        """Process a single job."""
        try:
            config = {"configurable": {"thread_id": job.thread_id}}
            result = await self.graph.ainvoke(job.input_data, config)
            
            await self.queue.store_result(job.job_id, {
                "status": "success",
                "result": result
            })
            
        except Exception as e:
            await self.queue.store_result(job.job_id, {
                "status": "error",
                "error": str(e)
            })
    
    def stop(self):
        """Stop the worker."""
        self.running = False


# API endpoint for async processing
@app.post("/process")
async def submit_job(input_data: dict):
    """Submit job for async processing."""
    import uuid
    import time
    
    job = Job(
        job_id=str(uuid.uuid4()),
        input_data=input_data,
        thread_id=input_data.get("thread_id", str(uuid.uuid4())),
        created_at=time.time()
    )
    
    await queue.enqueue(job)
    
    return {
        "job_id": job.job_id,
        "status": "queued",
        "check_url": f"/results/{job.job_id}"
    }


@app.get("/results/{job_id}")
async def get_result(job_id: str):
    """Get job result."""
    result = await queue.get_result(job_id)
    
    if not result:
        return {"status": "pending"}
    
    return result
```

## Interview Tips

```
+------------------------------------------------------------------+
|                       INTERVIEW TIP                               |
+------------------------------------------------------------------+
| Q: "How would you design a LangGraph system to handle 10,000      |
|     concurrent users?"                                            |
|                                                                   |
| A: I would implement a multi-tier scaling strategy:               |
|                                                                   |
| 1. Async Architecture (Foundation)                                |
|    - All I/O operations async (LLM calls, DB, etc.)               |
|    - Each server handles thousands of concurrent connections      |
|    - Use asyncio.gather for parallel operations within requests   |
|                                                                   |
| 2. Horizontal Scaling (Compute)                                   |
|    - Stateless application servers behind load balancer           |
|    - Auto-scaling based on CPU/memory/queue depth                 |
|    - External state storage (PostgreSQL, Redis)                   |
|                                                                   |
| 3. Queue-Based Processing (Decoupling)                            |
|    - Separate API servers from workers                            |
|    - Queue absorbs traffic spikes                                 |
|    - Workers scale independently                                  |
|                                                                   |
| 4. Caching (Efficiency)                                           |
|    - Cache embeddings and repeated queries                        |
|    - Reduce LLM calls by 30-50% for common queries                |
|    - Use Redis for distributed caching                            |
|                                                                   |
| 5. Rate Limiting (Protection)                                     |
|    - Per-user rate limits                                         |
|    - Global rate limits for LLM APIs                              |
|    - Graceful degradation under load                              |
|                                                                   |
| Key metrics to monitor:                                           |
|    - Request queue depth                                          |
|    - LLM API latency and error rate                               |
|    - Cache hit ratio                                              |
|    - Tokens per second                                            |
+------------------------------------------------------------------+
```

## Summary

```
Scaling Strategy Summary:
=========================

For Low Scale (< 100 users):
---------------------------
- Single instance with async
- In-memory checkpointer
- Basic caching

For Medium Scale (100-1000 users):
---------------------------------
- Multiple instances with load balancer
- PostgreSQL checkpointer
- Redis caching
- Basic rate limiting

For High Scale (1000+ users):
----------------------------
- Queue-based architecture
- Auto-scaling worker pools
- Distributed caching
- Advanced rate limiting
- Multi-region deployment

Key Principles:
--------------
1. Async everywhere (LLM calls are slow)
2. Stateless servers (scale horizontally)
3. External state storage (shared access)
4. Cache aggressively (reduce LLM calls)
5. Queue for durability (handle spikes)
```

---

This completes the Production Considerations module for LangGraph!
