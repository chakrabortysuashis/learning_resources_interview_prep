# LangGraph Platform Overview

## What is LangGraph Platform?

LangGraph Platform (also known as LangGraph Cloud) is a managed infrastructure solution
provided by LangChain for deploying, managing, and scaling LangGraph applications in
production environments.

```
+------------------------------------------------------------------+
|                    LANGGRAPH PLATFORM                             |
+------------------------------------------------------------------+
|                                                                   |
|    +------------------+     +------------------+                  |
|    |   Your Graph     |     |   LangGraph      |                  |
|    |   Application    | --> |   Platform API   |                  |
|    +------------------+     +------------------+                  |
|                                    |                              |
|              +---------------------+---------------------+        |
|              |                     |                     |        |
|              v                     v                     v        |
|    +----------------+    +----------------+    +----------------+ |
|    |   Managed      |    |   Built-in     |    |   Auto         | |
|    |   Persistence  |    |   Streaming    |    |   Scaling      | |
|    +----------------+    +----------------+    +----------------+ |
|              |                     |                     |        |
|              v                     v                     v        |
|    +----------------+    +----------------+    +----------------+ |
|    |   LangSmith    |    |   Human-in-    |    |   State        | |
|    |   Integration  |    |   the-Loop     |    |   Management   | |
|    +----------------+    +----------------+    +----------------+ |
|                                                                   |
+------------------------------------------------------------------+
```

## Key Features

### 1. Managed Infrastructure

LangGraph Platform handles the operational complexity of running AI agents:

```
Self-Managed                          LangGraph Platform
+------------------+                  +------------------+
| You manage:      |                  | Platform manages:|
| - Servers        |                  | - Infrastructure |
| - Scaling        |      --->        | - Scaling        |
| - State storage  |                  | - Persistence    |
| - Load balancing |                  | - Load balancing |
| - Monitoring     |                  | - Monitoring     |
+------------------+                  +------------------+
```

### 2. Built-in Persistence

The platform provides automatic state persistence without additional setup:

```python
# Without Platform - Manual persistence setup
from langgraph.checkpoint.sqlite import SqliteSaver

# You need to manage the database
memory = SqliteSaver.from_conn_string(":memory:")
graph = builder.compile(checkpointer=memory)

# With Platform - Automatic persistence
# State is automatically persisted and retrievable
# No database setup required
```

### 3. Streaming Support

Native support for multiple streaming modes:

```
Streaming Modes in LangGraph Platform:
======================================

1. Values Mode
   - Stream full state after each node
   - Best for: UI updates, progress tracking

2. Updates Mode  
   - Stream only the changes from each node
   - Best for: Efficient updates, bandwidth savings

3. Messages Mode
   - Stream LLM tokens as they're generated
   - Best for: Chat interfaces, real-time responses

4. Events Mode
   - Stream all internal events
   - Best for: Debugging, detailed monitoring
```

### 4. Human-in-the-Loop Support

Built-in mechanisms for human intervention:

```
+------------------------------------------------------------------+
|              HUMAN-IN-THE-LOOP WORKFLOW                           |
+------------------------------------------------------------------+
|                                                                   |
|    Graph Execution                                                |
|    +----------+     +----------+     +----------+                 |
|    |  Node 1  | --> |  Node 2  | --> | Interrupt| ----+          |
|    +----------+     +----------+     +----------+     |          |
|                                                        |          |
|                                          +-------------+          |
|                                          |                        |
|                                          v                        |
|                                   +--------------+                |
|                                   | Human Review |                |
|                                   |   (Pending)  |                |
|                                   +--------------+                |
|                                          |                        |
|                           Approve/Reject/Modify                   |
|                                          |                        |
|                                          v                        |
|                                   +----------+                    |
|                                   |  Node 3  | --> Continue       |
|                                   +----------+                    |
|                                                                   |
+------------------------------------------------------------------+
```

## LangGraph Platform vs Self-Hosted

| Feature | Self-Hosted | LangGraph Platform |
|---------|-------------|-------------------|
| Setup Time | Hours/Days | Minutes |
| Infrastructure | You manage | Managed |
| Scaling | Manual | Automatic |
| Persistence | Configure yourself | Built-in |
| Streaming | Implement yourself | Built-in |
| Human-in-the-Loop | Build yourself | Built-in |
| Monitoring | Set up LangSmith | Integrated |
| Cost | Infrastructure + Time | Subscription |

## When to Use LangGraph Platform

### Use Platform When:

- You need rapid deployment without infrastructure management
- Your team lacks DevOps expertise for AI systems
- You require built-in human-in-the-loop capabilities
- You want automatic scaling without configuration
- Compliance allows third-party managed services

### Self-Host When:

- You have strict data residency requirements
- You need complete control over infrastructure
- Cost optimization is critical at high scale
- You have existing infrastructure to leverage
- Custom networking or security requirements

## Architecture Components

```
+------------------------------------------------------------------+
|                 PLATFORM ARCHITECTURE                             |
+------------------------------------------------------------------+
|                                                                   |
|  Client Applications                                              |
|  +--------+  +--------+  +--------+                              |
|  | Web UI |  | Mobile |  |  API   |                              |
|  +--------+  +--------+  +--------+                              |
|       |          |           |                                    |
|       +----------+-----------+                                    |
|                  |                                                |
|                  v                                                |
|  +----------------------------------------+                      |
|  |        LangGraph Platform API          |                      |
|  |  +----------+  +----------+  +------+  |                      |
|  |  | Threads  |  |   Runs   |  | Crons|  |                      |
|  |  +----------+  +----------+  +------+  |                      |
|  +----------------------------------------+                      |
|                  |                                                |
|                  v                                                |
|  +----------------------------------------+                      |
|  |           Execution Engine             |                      |
|  |  +----------+  +----------+  +------+  |                      |
|  |  | Workers  |  |Schedulers|  |Queue |  |                      |
|  |  +----------+  +----------+  +------+  |                      |
|  +----------------------------------------+                      |
|                  |                                                |
|                  v                                                |
|  +----------------------------------------+                      |
|  |           Storage Layer                |                      |
|  |  +--------------+  +--------------+    |                      |
|  |  | State Store  |  | Blob Storage |    |                      |
|  |  +--------------+  +--------------+    |                      |
|  +----------------------------------------+                      |
|                                                                   |
+------------------------------------------------------------------+
```

## Core Concepts

### 1. Assistants

Assistants are deployed graph configurations:

```python
# An assistant is a specific configuration of a graph
# You can have multiple assistants from the same graph
# with different configurations

assistant_config = {
    "graph_id": "my-agent-graph",
    "config": {
        "model": "gpt-4",
        "temperature": 0.7,
        "max_tokens": 1000
    },
    "metadata": {
        "name": "Customer Support Agent",
        "version": "1.0.0"
    }
}
```

### 2. Threads

Threads represent conversation sessions with persistent state:

```
Thread Lifecycle:
=================

Create Thread --> Add Messages --> Run Graph --> Get Results
     |                                              |
     |              +------------------+            |
     +------------->| Persistent State |<-----------+
                    | (Checkpoints)    |
                    +------------------+
                           |
                    Resume Later
                           |
                           v
                    Continue Conversation
```

### 3. Runs

Runs are individual graph executions within a thread:

```python
# Creating a run
run = await client.runs.create(
    thread_id="thread_abc123",
    assistant_id="my-assistant",
    input={"messages": [{"role": "user", "content": "Hello"}]},
    config={"recursion_limit": 25}
)

# Run states: pending -> running -> success/error/interrupted
```

### 4. Crons

Scheduled executions for automated workflows:

```python
# Schedule a daily report generation
cron_config = {
    "assistant_id": "report-generator",
    "schedule": "0 9 * * *",  # Every day at 9 AM
    "input": {"report_type": "daily_summary"}
}
```

## API Overview

### LangGraph SDK

```python
from langgraph_sdk import get_client

# Initialize client
client = get_client(url="https://api.langgraph.dev")

# Common operations
# -----------------

# List assistants
assistants = await client.assistants.list()

# Create a thread
thread = await client.threads.create()

# Run a graph
run = await client.runs.create(
    thread_id=thread["thread_id"],
    assistant_id="my-assistant",
    input={"query": "What is LangGraph?"}
)

# Wait for completion
result = await client.runs.join(
    thread_id=thread["thread_id"],
    run_id=run["run_id"]
)

# Stream results
async for event in client.runs.stream(
    thread_id=thread["thread_id"],
    assistant_id="my-assistant",
    input={"query": "Tell me more"},
    stream_mode="messages"
):
    print(event)
```

## Deployment to Platform

### Step 1: Create langgraph.json

```json
{
    "graphs": {
        "my_agent": {
            "module": "src.agent:graph"
        }
    },
    "dependencies": [
        "langchain-openai>=0.1.0",
        "langgraph>=0.1.0"
    ],
    "env_vars": {
        "OPENAI_API_KEY": {
            "required": true,
            "description": "OpenAI API key for LLM calls"
        }
    }
}
```

### Step 2: Deploy Using CLI

```bash
# Install LangGraph CLI
pip install langgraph-cli

# Login to platform
langgraph auth login

# Deploy your graph
langgraph deploy ./my-project

# Check deployment status
langgraph deployments list
```

## Pricing Considerations

```
+------------------------------------------------------------------+
|                    PRICING MODEL                                  |
+------------------------------------------------------------------+
|                                                                   |
|   Component              Pricing Basis                            |
|   ---------              -------------                            |
|   Compute                Per second of execution                  |
|   Storage                Per GB of state stored                   |
|   API Calls              Per request                              |
|   Streaming              Per streamed token                       |
|                                                                   |
|   Cost Optimization Tips:                                         |
|   -----------------------                                         |
|   1. Use efficient graphs (minimize unnecessary nodes)            |
|   2. Implement caching for repeated queries                       |
|   3. Clean up old threads and state                               |
|   4. Use appropriate streaming mode for your use case             |
|   5. Set reasonable recursion limits                              |
|                                                                   |
+------------------------------------------------------------------+
```

## Interview Tips

```
+------------------------------------------------------------------+
|                       INTERVIEW TIP                               |
+------------------------------------------------------------------+
| Q: "When would you choose LangGraph Platform over self-hosting?"  |
|                                                                   |
| A: Consider these factors:                                        |
|                                                                   |
| 1. Team Size & Expertise                                          |
|    - Small team without DevOps -> Platform                        |
|    - Large team with infra expertise -> Consider self-host        |
|                                                                   |
| 2. Time to Market                                                 |
|    - Need to ship fast -> Platform                                |
|    - Have time to build -> Self-host is viable                    |
|                                                                   |
| 3. Scale Requirements                                             |
|    - Variable/unpredictable load -> Platform (auto-scaling)       |
|    - Predictable high load -> Self-host may be cheaper            |
|                                                                   |
| 4. Compliance & Security                                          |
|    - Strict data residency -> Self-host                           |
|    - Standard compliance -> Platform works                        |
|                                                                   |
| Key insight: Platform is about buying operational excellence,     |
| not just infrastructure. The value is in reduced complexity.      |
+------------------------------------------------------------------+
```

## Summary

LangGraph Platform provides:

- **Managed Infrastructure** - Focus on building, not operating
- **Built-in Persistence** - Automatic state management
- **Streaming Support** - Multiple modes for different use cases
- **Human-in-the-Loop** - Native support for human intervention
- **LangSmith Integration** - Seamless monitoring and debugging

The platform is ideal for teams wanting to deploy production LangGraph applications
without the overhead of managing infrastructure, while self-hosting remains a valid
choice for specific compliance or cost requirements.

---

Next: [Deployment Strategies](./02_deployment_strategies.md)
