# Testing LangGraph Workflows

## Overview

Testing LangGraph applications requires a multi-layered approach that addresses
the unique challenges of testing AI-powered workflows: non-determinism,
external API dependencies, and complex state transitions.

```
+------------------------------------------------------------------+
|                    TESTING PYRAMID                                |
+------------------------------------------------------------------+
|                                                                   |
|                        /\                                         |
|                       /  \     E2E Tests                          |
|                      /    \    - Full system with real LLMs       |
|                     /------\   - Few, expensive, slow             |
|                    /        \                                     |
|                   / Integra- \  Integration Tests                 |
|                  /   tion     \ - Graph with mocked LLMs          |
|                 /--------------\- Multiple components             |
|                /                \                                 |
|               /    Unit Tests    \ Unit Tests                     |
|              /                    \- Individual nodes             |
|             /----------------------\- State transformations       |
|            /                        \- Pure functions             |
|                                                                   |
+------------------------------------------------------------------+
```

## Testing Challenges

### Challenge 1: Non-Determinism

LLM outputs vary even with the same input:

```
Input: "What is Python?"

Run 1: "Python is a high-level programming language..."
Run 2: "Python is a versatile, interpreted language..."
Run 3: "Python is an easy-to-learn programming language..."

All correct, but different!
```

**Solutions:**
- Use low temperature (0.0) for deterministic tests
- Test for semantic correctness, not exact matches
- Use mocked LLM responses for unit tests
- Define acceptance criteria rather than expected outputs

### Challenge 2: External Dependencies

```
+------------------------------------------------------------------+
|                 EXTERNAL DEPENDENCIES                             |
+------------------------------------------------------------------+
|                                                                   |
|   Your Graph                                                      |
|       |                                                           |
|       +---> OpenAI API (rate limits, costs, availability)         |
|       |                                                           |
|       +---> Vector Database (connection, data state)              |
|       |                                                           |
|       +---> External Tools (web search, APIs)                     |
|                                                                   |
|   Testing Strategy:                                               |
|   -----------------                                               |
|   Unit Tests:      Mock ALL external dependencies                 |
|   Integration:     Mock LLMs, use real databases                  |
|   E2E Tests:       Use real services (sparingly)                  |
|                                                                   |
+------------------------------------------------------------------+
```

### Challenge 3: State Complexity

```
State transitions in a typical graph:

Initial State
    |
    v
+-------------------+
| messages: []      |
| context: None     |
| tools_called: []  |
+-------------------+
    |
    | (after node 1)
    v
+-------------------+
| messages: [user]  |
| context: {...}    |
| tools_called: []  |
+-------------------+
    |
    | (after node 2)
    v
+-------------------+
| messages: [u, a]  |
| context: {...}    |
| tools_called: [1] |
+-------------------+

Test each transition independently!
```

## Unit Testing Strategies

### Testing Individual Nodes

```python
# Example: Testing a node in isolation

import pytest
from my_graph import classify_intent_node

class TestClassifyIntentNode:
    """Unit tests for the intent classification node."""
    
    def test_returns_correct_state_structure(self):
        """Node should return state with required keys."""
        input_state = {"messages": [...], "intent": None}
        
        result = classify_intent_node(input_state)
        
        assert "intent" in result
        assert "confidence" in result
    
    def test_handles_empty_messages(self):
        """Node should handle edge case of empty messages."""
        input_state = {"messages": [], "intent": None}
        
        result = classify_intent_node(input_state)
        
        assert result["intent"] == "unknown"
    
    def test_preserves_existing_state(self):
        """Node should not remove existing state keys."""
        input_state = {
            "messages": [...],
            "user_id": "123",
            "session_data": {...}
        }
        
        result = classify_intent_node(input_state)
        
        # Node returns only changed keys, but shouldn't error
        assert "intent" in result
```

### Testing State Reducers

```python
# Example: Testing custom state reducers

from my_graph import merge_messages, aggregate_scores

class TestStateReducers:
    """Tests for custom state reduction logic."""
    
    def test_merge_messages_appends(self):
        """Messages should be appended, not replaced."""
        existing = [{"role": "user", "content": "Hi"}]
        new = [{"role": "assistant", "content": "Hello!"}]
        
        result = merge_messages(existing, new)
        
        assert len(result) == 2
        assert result[0]["role"] == "user"
        assert result[1]["role"] == "assistant"
    
    def test_aggregate_scores_averages(self):
        """Scores should be averaged correctly."""
        existing = {"relevance": 0.8, "count": 2}
        new = {"relevance": 0.9}
        
        result = aggregate_scores(existing, new)
        
        expected_avg = (0.8 * 2 + 0.9) / 3
        assert abs(result["relevance"] - expected_avg) < 0.001
```

### Testing Conditional Edges

```python
# Example: Testing routing logic

from my_graph import should_use_tool, route_by_intent

class TestConditionalEdges:
    """Tests for graph routing decisions."""
    
    def test_should_use_tool_when_tool_requested(self):
        """Should route to tool node when LLM requests tool."""
        state = {
            "messages": [...],
            "last_response": {
                "tool_calls": [{"name": "search", "args": {...}}]
            }
        }
        
        result = should_use_tool(state)
        
        assert result == "tool_node"
    
    def test_should_end_when_no_tool(self):
        """Should end when no tool is requested."""
        state = {
            "messages": [...],
            "last_response": {"content": "Here's your answer..."}
        }
        
        result = should_use_tool(state)
        
        assert result == END
    
    @pytest.mark.parametrize("intent,expected_node", [
        ("question", "qa_node"),
        ("complaint", "escalation_node"),
        ("feedback", "feedback_node"),
        ("unknown", "clarification_node"),
    ])
    def test_route_by_intent(self, intent, expected_node):
        """Should route to correct node based on intent."""
        state = {"intent": intent}
        
        result = route_by_intent(state)
        
        assert result == expected_node
```

## Integration Testing

### Testing Graph Execution with Mocked LLMs

```python
# Example: Integration test with mocked LLM

import pytest
from unittest.mock import Mock, patch
from langchain_core.messages import AIMessage
from my_graph import create_agent_graph

class TestGraphIntegration:
    """Integration tests for the complete graph."""
    
    @pytest.fixture
    def mock_llm(self):
        """Create a mock LLM that returns predictable responses."""
        mock = Mock()
        mock.invoke.return_value = AIMessage(
            content="This is a test response"
        )
        return mock
    
    @pytest.fixture
    def graph_with_mock(self, mock_llm):
        """Create graph with mocked LLM."""
        with patch("my_graph.ChatOpenAI", return_value=mock_llm):
            return create_agent_graph()
    
    def test_graph_completes_successfully(self, graph_with_mock):
        """Graph should complete without errors."""
        input_state = {
            "messages": [{"role": "user", "content": "Hello"}]
        }
        
        result = graph_with_mock.invoke(input_state)
        
        assert "messages" in result
        assert len(result["messages"]) > 1
    
    def test_graph_handles_multiple_turns(self, graph_with_mock, mock_llm):
        """Graph should handle multi-turn conversations."""
        # Configure mock for multiple responses
        mock_llm.invoke.side_effect = [
            AIMessage(content="First response"),
            AIMessage(content="Second response"),
        ]
        
        # First turn
        state1 = graph_with_mock.invoke({
            "messages": [{"role": "user", "content": "Hi"}]
        })
        
        # Second turn (continuing conversation)
        state2 = graph_with_mock.invoke({
            "messages": state1["messages"] + [
                {"role": "user", "content": "Tell me more"}
            ]
        })
        
        assert len(state2["messages"]) == 4  # 2 user + 2 assistant
```

### Testing Tool Integration

```python
# Example: Testing tool execution

class TestToolIntegration:
    """Tests for tool integration in graphs."""
    
    @pytest.fixture
    def mock_search_tool(self):
        """Mock search tool with predictable results."""
        mock = Mock()
        mock.invoke.return_value = "Search result: Python is great"
        mock.name = "search"
        return mock
    
    def test_tool_is_called_when_needed(self, graph_with_tools, mock_search_tool):
        """Graph should call tool when LLM requests it."""
        # Configure LLM to request tool
        # ... setup ...
        
        result = graph_with_tools.invoke({
            "messages": [{"role": "user", "content": "Search for Python"}]
        })
        
        mock_search_tool.invoke.assert_called_once()
    
    def test_tool_result_is_used(self, graph_with_tools, mock_search_tool):
        """Tool results should be incorporated into response."""
        result = graph_with_tools.invoke({
            "messages": [{"role": "user", "content": "Search for Python"}]
        })
        
        # Check that tool result influenced final response
        final_message = result["messages"][-1]
        assert "Python" in final_message.content
```

## End-to-End Testing

### E2E Test Structure

```
+------------------------------------------------------------------+
|                    E2E TEST STRATEGY                              |
+------------------------------------------------------------------+
|                                                                   |
|   When to Run:                                                    |
|   - Pre-deployment validation                                     |
|   - Scheduled regression tests (nightly)                          |
|   - After significant changes                                     |
|                                                                   |
|   What to Test:                                                   |
|   - Critical user journeys                                        |
|   - Edge cases that mocks might miss                              |
|   - Integration with real external services                       |
|                                                                   |
|   Considerations:                                                 |
|   - Cost: Real LLM calls are expensive                            |
|   - Time: Tests are slow                                          |
|   - Flakiness: Network issues, rate limits                        |
|                                                                   |
+------------------------------------------------------------------+
```

### E2E Test Example

```python
# Example: E2E test with real LLM (use sparingly!)

import pytest
import os

# Skip if no API key (CI without secrets)
pytestmark = pytest.mark.skipif(
    not os.getenv("OPENAI_API_KEY"),
    reason="OPENAI_API_KEY not set"
)

class TestE2EWithRealLLM:
    """
    End-to-end tests with real LLM.
    
    These tests are expensive and slow - run sparingly!
    """
    
    @pytest.fixture(scope="class")
    def real_graph(self):
        """Create graph with real LLM (once per test class)."""
        from my_graph import create_production_graph
        return create_production_graph()
    
    @pytest.mark.slow
    @pytest.mark.e2e
    def test_basic_question_answering(self, real_graph):
        """Graph should answer basic questions correctly."""
        result = real_graph.invoke({
            "messages": [{"role": "user", "content": "What is 2 + 2?"}]
        })
        
        response = result["messages"][-1].content.lower()
        
        # Check for semantic correctness, not exact match
        assert "4" in response or "four" in response
    
    @pytest.mark.slow
    @pytest.mark.e2e
    def test_handles_ambiguous_input(self, real_graph):
        """Graph should handle ambiguous input gracefully."""
        result = real_graph.invoke({
            "messages": [{"role": "user", "content": "???"}]
        })
        
        # Should not crash
        assert "messages" in result
        # Should ask for clarification
        response = result["messages"][-1].content.lower()
        assert any(word in response for word in ["clarify", "help", "understand"])
```

## Testing Patterns

### Pattern 1: Snapshot Testing

```python
# Compare outputs against known-good snapshots

import json
import pytest

class TestSnapshotTesting:
    """Snapshot tests for graph outputs."""
    
    def test_graph_output_structure(self, graph, snapshot):
        """Output structure should match snapshot."""
        result = graph.invoke({"messages": [...]})
        
        # Remove non-deterministic fields
        sanitized = {
            "message_count": len(result["messages"]),
            "has_tool_calls": "tool_calls" in result,
            "final_node": result.get("_final_node")
        }
        
        assert sanitized == snapshot
```

### Pattern 2: Property-Based Testing

```python
# Test properties that should always hold

from hypothesis import given, strategies as st

class TestPropertyBased:
    """Property-based tests for graph invariants."""
    
    @given(st.text(min_size=1, max_size=1000))
    def test_graph_never_crashes_on_input(self, input_text, graph):
        """Graph should handle any text input without crashing."""
        try:
            result = graph.invoke({
                "messages": [{"role": "user", "content": input_text}]
            })
            assert "messages" in result
        except Exception as e:
            # Only expected exceptions are allowed
            assert isinstance(e, (ValueError, TimeoutError))
    
    @given(st.integers(min_value=1, max_value=10))
    def test_message_count_always_increases(self, turn_count, graph):
        """Message count should always increase."""
        state = {"messages": []}
        
        for i in range(turn_count):
            prev_count = len(state["messages"])
            state = graph.invoke({
                "messages": state["messages"] + [
                    {"role": "user", "content": f"Message {i}"}
                ]
            })
            assert len(state["messages"]) > prev_count
```

### Pattern 3: Evaluation-Based Testing

```python
# Use LLM-as-judge for quality testing

from langsmith.evaluation import evaluate

class TestWithEvaluators:
    """Tests using LLM evaluators for quality assessment."""
    
    def test_response_relevance(self, graph, evaluator):
        """Responses should be relevant to questions."""
        test_cases = [
            {"input": "What is Python?", "topic": "Python programming"},
            {"input": "How do I sort a list?", "topic": "sorting algorithms"},
        ]
        
        for case in test_cases:
            result = graph.invoke({
                "messages": [{"role": "user", "content": case["input"]}]
            })
            
            response = result["messages"][-1].content
            relevance_score = evaluator.evaluate_relevance(
                response, 
                case["topic"]
            )
            
            assert relevance_score > 0.7, f"Low relevance for: {case['input']}"
```

## Test Organization

```
tests/
+-- unit/
|   +-- test_nodes.py           # Individual node tests
|   +-- test_reducers.py        # State reducer tests
|   +-- test_routing.py         # Conditional edge tests
|   +-- test_tools.py           # Tool function tests
|
+-- integration/
|   +-- test_graph_flow.py      # Graph execution tests
|   +-- test_checkpointing.py   # State persistence tests
|   +-- test_streaming.py       # Streaming tests
|
+-- e2e/
|   +-- test_user_journeys.py   # Critical path tests
|   +-- test_error_recovery.py  # Failure handling tests
|
+-- fixtures/
|   +-- mock_responses.py       # Predefined LLM responses
|   +-- test_data.py            # Test input data
|
+-- conftest.py                 # Shared fixtures
```

## Interview Tips

```
+------------------------------------------------------------------+
|                       INTERVIEW TIP                               |
+------------------------------------------------------------------+
| Q: "How do you test an AI application that produces              |
|     non-deterministic outputs?"                                   |
|                                                                   |
| A: I use a multi-layered testing strategy:                        |
|                                                                   |
| 1. Deterministic Tests (Majority)                                 |
|    - Mock LLM responses for unit tests                            |
|    - Set temperature=0 for reproducible tests                     |
|    - Test state transitions, not content                          |
|                                                                   |
| 2. Semantic Tests (Medium)                                        |
|    - Check for presence of key information                        |
|    - Verify response format/structure                             |
|    - Use fuzzy matching or keyword checks                         |
|                                                                   |
| 3. Property Tests (Invariants)                                    |
|    - "Response should never be empty"                             |
|    - "Should not crash on any input"                              |
|    - "Message count should increase"                              |
|                                                                   |
| 4. Evaluation Tests (Few, Expensive)                              |
|    - LLM-as-judge for quality scoring                             |
|    - Human evaluation for critical paths                          |
|    - Statistical assertions (>X% should pass)                     |
|                                                                   |
| Key insight: Focus testing effort on what you CAN control         |
| (routing, state management, error handling) and use evaluation    |
| frameworks for what you can't (LLM output quality).               |
+------------------------------------------------------------------+
```

## Summary

Effective testing of LangGraph workflows requires:

1. **Unit Tests** - Test nodes, reducers, and routing in isolation
2. **Integration Tests** - Test graph flow with mocked LLMs
3. **E2E Tests** - Validate critical paths with real services
4. **Property Tests** - Ensure invariants hold across inputs
5. **Evaluation Tests** - Measure quality with automated evaluators

---

Next: [Testing Example](./07_testing_example.py)
