# Monitoring and Observability for LangGraph

## Overview

Monitoring LangGraph applications requires observability across multiple dimensions:
LLM calls, graph execution, application health, and business metrics.

```
+------------------------------------------------------------------+
|                 OBSERVABILITY PILLARS                             |
+------------------------------------------------------------------+
|                                                                   |
|     LOGS              METRICS            TRACES                   |
|   +--------+        +--------+        +--------+                  |
|   | What   |        | How    |        | Where  |                  |
|   |happened|        | much   |        | & When |                  |
|   +--------+        +--------+        +--------+                  |
|       |                 |                 |                       |
|       v                 v                 v                       |
|   +--------+        +--------+        +--------+                  |
|   | Debug  |        | Alert  |        |  Root  |                  |
|   | Issues |        |  On    |        | Cause  |                  |
|   +--------+        +--------+        +--------+                  |
|                                                                   |
+------------------------------------------------------------------+
```

## LangSmith Integration

LangSmith is LangChain's observability platform, providing deep insights into
LLM applications including LangGraph workflows.

### Why LangSmith?

```
+------------------------------------------------------------------+
|                 LANGSMITH CAPABILITIES                            |
+------------------------------------------------------------------+
|                                                                   |
|   1. Trace Visualization                                          |
|      +----------------------------------------------------+      |
|      | Run: agent_abc123                                   |      |
|      | +-- Node: router (45ms)                            |      |
|      | |   +-- LLM: gpt-4 (320ms, 150 tokens)            |      |
|      | +-- Node: search_tool (1.2s)                       |      |
|      | |   +-- Tool: web_search                           |      |
|      | +-- Node: synthesize (890ms)                       |      |
|      |     +-- LLM: gpt-4 (780ms, 450 tokens)            |      |
|      +----------------------------------------------------+      |
|                                                                   |
|   2. Token & Cost Tracking                                        |
|      - Input tokens: 2,450                                        |
|      - Output tokens: 890                                         |
|      - Total cost: $0.089                                         |
|                                                                   |
|   3. Quality Monitoring                                           |
|      - Human feedback integration                                 |
|      - Automated evaluators                                       |
|      - A/B testing support                                        |
|                                                                   |
|   4. Dataset & Testing                                            |
|      - Create datasets from production traces                     |
|      - Run evaluations                                            |
|      - Compare model versions                                     |
|                                                                   |
+------------------------------------------------------------------+
```

### Setting Up LangSmith

```bash
# Environment variables for LangSmith
export LANGCHAIN_TRACING_V2="true"
export LANGCHAIN_API_KEY="your-langsmith-api-key"
export LANGCHAIN_PROJECT="my-langgraph-production"

# Optional: Endpoint for self-hosted LangSmith
export LANGCHAIN_ENDPOINT="https://api.smith.langchain.com"
```

### Programmatic Configuration

```python
from langsmith import Client
import os

# Initialize LangSmith client
client = Client(
    api_key=os.getenv("LANGCHAIN_API_KEY"),
    api_url=os.getenv("LANGCHAIN_ENDPOINT", "https://api.smith.langchain.com")
)

# Configure tracing at runtime
os.environ["LANGCHAIN_TRACING_V2"] = "true"
os.environ["LANGCHAIN_PROJECT"] = "production-graph"
```

## Trace Anatomy

Understanding how traces work in LangGraph:

```
+------------------------------------------------------------------+
|                    TRACE STRUCTURE                                |
+------------------------------------------------------------------+
|                                                                   |
|   Trace (Top-Level Run)                                           |
|   +----------------------------------------------------------+   |
|   | ID: trace_abc123                                          |   |
|   | Name: "CustomerSupportAgent"                              |   |
|   | Start: 2024-01-15T10:30:00Z                               |   |
|   | End: 2024-01-15T10:30:05Z                                 |   |
|   | Status: success                                           |   |
|   |                                                           |   |
|   | Child Runs (Spans):                                       |   |
|   | +------------------------------------------------------+  |   |
|   | | Node: "classify_intent"                              |  |   |
|   | | +--------------------------------------------------+ |  |   |
|   | | | LLM Call: ChatOpenAI                             | |  |   |
|   | | | - Model: gpt-4                                   | |  |   |
|   | | | - Input tokens: 150                              | |  |   |
|   | | | - Output tokens: 25                              | |  |   |
|   | | | - Latency: 450ms                                 | |  |   |
|   | | +--------------------------------------------------+ |  |   |
|   | +------------------------------------------------------+  |   |
|   | +------------------------------------------------------+  |   |
|   | | Node: "fetch_context"                                |  |   |
|   | | +--------------------------------------------------+ |  |   |
|   | | | Tool Call: VectorSearch                          | |  |   |
|   | | | - Query: "order status"                          | |  |   |
|   | | | - Results: 5 documents                           | |  |   |
|   | | | - Latency: 120ms                                 | |  |   |
|   | | +--------------------------------------------------+ |  |   |
|   | +------------------------------------------------------+  |   |
|   +----------------------------------------------------------+   |
|                                                                   |
+------------------------------------------------------------------+
```

## Key Metrics to Monitor

### 1. Performance Metrics

```
+------------------------------------------------------------------+
|                  PERFORMANCE METRICS                              |
+------------------------------------------------------------------+
|                                                                   |
|   Metric                  What It Tells You                       |
|   ------                  ------------------                      |
|   Request Latency         How long requests take (p50, p95, p99)  |
|   Node Duration           Time spent in each graph node           |
|   LLM Latency             Time waiting for LLM responses          |
|   Token Throughput        Tokens processed per second             |
|   Queue Depth             Pending requests (backpressure)         |
|                                                                   |
|   Example Thresholds:                                             |
|   ------------------                                              |
|   - p95 latency < 5 seconds                                       |
|   - LLM timeout rate < 1%                                         |
|   - Error rate < 0.1%                                             |
|                                                                   |
+------------------------------------------------------------------+
```

### 2. Cost Metrics

```
+------------------------------------------------------------------+
|                     COST METRICS                                  |
+------------------------------------------------------------------+
|                                                                   |
|   Token Usage Dashboard                                           |
|   ---------------------                                           |
|                                                                   |
|   Daily Token Usage:                                              |
|   +---------------------------------------------------+          |
|   |                    *                               |          |
|   |              *    * *     *                       |          |
|   |    *   *   *  *  *   *   * *                      |          |
|   | * * * * * *    **     * *   *  *                  |          |
|   +---------------------------------------------------+          |
|     Mon  Tue  Wed  Thu  Fri  Sat  Sun                            |
|                                                                   |
|   Cost by Model:                                                  |
|   +------------------+----------+----------+                      |
|   | Model            | Tokens   | Cost     |                      |
|   +------------------+----------+----------+                      |
|   | gpt-4            | 1.2M     | $48.00   |                      |
|   | gpt-3.5-turbo    | 5.4M     | $10.80   |                      |
|   | text-embedding   | 8.1M     | $0.81    |                      |
|   +------------------+----------+----------+                      |
|   | TOTAL            | 14.7M    | $59.61   |                      |
|   +------------------+----------+----------+                      |
|                                                                   |
+------------------------------------------------------------------+
```

### 3. Quality Metrics

```
+------------------------------------------------------------------+
|                    QUALITY METRICS                                |
+------------------------------------------------------------------+
|                                                                   |
|   User Feedback:                                                  |
|   +------------------------------------------+                    |
|   |  Thumbs Up:    85%  ████████████████░░   |                    |
|   |  Thumbs Down:  15%  ███░░░░░░░░░░░░░░░   |                    |
|   +------------------------------------------+                    |
|                                                                   |
|   Automated Evaluations:                                          |
|   +-------------------------------+--------+                      |
|   | Evaluator                     | Score  |                      |
|   +-------------------------------+--------+                      |
|   | Relevance                     | 0.89   |                      |
|   | Factual Accuracy              | 0.92   |                      |
|   | Response Completeness         | 0.85   |                      |
|   | Toxicity (lower is better)    | 0.02   |                      |
|   +-------------------------------+--------+                      |
|                                                                   |
|   Graph Path Analysis:                                            |
|   +-------------------------------+--------+                      |
|   | Path                          | Count  |                      |
|   +-------------------------------+--------+                      |
|   | classify -> search -> respond | 45%    |                      |
|   | classify -> respond (direct)  | 35%    |                      |
|   | classify -> escalate          | 15%    |                      |
|   | classify -> error             | 5%     |                      |
|   +-------------------------------+--------+                      |
|                                                                   |
+------------------------------------------------------------------+
```

## Logging Best Practices

### Structured Logging

```python
import logging
import json
from datetime import datetime
from typing import Any, Dict

class StructuredLogger:
    """
    Structured logger for production LangGraph applications.
    
    Outputs JSON-formatted logs for easy parsing by log aggregation
    systems like Elasticsearch, Datadog, or CloudWatch.
    """
    
    def __init__(self, name: str, level: int = logging.INFO):
        self.logger = logging.getLogger(name)
        self.logger.setLevel(level)
        
        # JSON formatter
        handler = logging.StreamHandler()
        handler.setFormatter(JsonFormatter())
        self.logger.addHandler(handler)
    
    def log(
        self,
        level: str,
        message: str,
        **context: Any
    ):
        """Log with structured context."""
        log_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "level": level,
            "message": message,
            **context
        }
        
        log_method = getattr(self.logger, level.lower())
        log_method(json.dumps(log_entry))
    
    def graph_event(
        self,
        event_type: str,
        thread_id: str,
        node_name: str = None,
        **extra
    ):
        """Log graph execution events."""
        self.log(
            "INFO",
            f"Graph event: {event_type}",
            event_type=event_type,
            thread_id=thread_id,
            node_name=node_name,
            **extra
        )


class JsonFormatter(logging.Formatter):
    """Format log records as JSON."""
    
    def format(self, record: logging.LogRecord) -> str:
        return record.getMessage()


# Usage
logger = StructuredLogger("langgraph.production")

# Log graph events
logger.graph_event(
    event_type="node_start",
    thread_id="thread_123",
    node_name="classify_intent",
    input_size=150
)

logger.graph_event(
    event_type="node_complete",
    thread_id="thread_123",
    node_name="classify_intent",
    duration_ms=450,
    output_class="support_query"
)
```

### Log Levels Guide

```
+------------------------------------------------------------------+
|                    LOG LEVEL GUIDE                                |
+------------------------------------------------------------------+
|                                                                   |
|   Level     When to Use                        Example            |
|   -----     -----------                        -------            |
|   DEBUG     Detailed debugging info            "LLM prompt: ..."  |
|             (disable in production)                               |
|                                                                   |
|   INFO      Normal operation events            "Node completed"   |
|             (request start/end, node          "Thread created"   |
|              transitions)                                         |
|                                                                   |
|   WARNING   Unexpected but handled             "Retry attempt 2"  |
|             situations                         "Slow response"    |
|                                                                   |
|   ERROR     Failures requiring attention       "LLM API error"    |
|             (still recoverable)                "Tool failed"      |
|                                                                   |
|   CRITICAL  System-level failures              "Out of memory"    |
|             (requires immediate action)        "Database down"    |
|                                                                   |
+------------------------------------------------------------------+
```

## Distributed Tracing

For complex deployments, integrate with distributed tracing systems:

```
+------------------------------------------------------------------+
|              DISTRIBUTED TRACING FLOW                             |
+------------------------------------------------------------------+
|                                                                   |
|   Client                                                          |
|     |                                                             |
|     | trace_id: abc123                                            |
|     v                                                             |
|   +------------------+                                            |
|   |   API Gateway    |  span: gateway (5ms)                       |
|   +------------------+                                            |
|     |                                                             |
|     | trace_id: abc123, parent_span: gateway                      |
|     v                                                             |
|   +------------------+                                            |
|   |  LangGraph API   |  span: langgraph (2.5s)                    |
|   +------------------+                                            |
|     |                                                             |
|     +---> Node: router     span: router (100ms)                   |
|     |                                                             |
|     +---> Node: search     span: search (800ms)                   |
|     |       |                                                     |
|     |       +---> Vector DB   span: vectordb (200ms)              |
|     |                                                             |
|     +---> Node: llm        span: llm (1.5s)                       |
|             |                                                     |
|             +---> OpenAI API  span: openai (1.4s)                 |
|                                                                   |
+------------------------------------------------------------------+
```

### OpenTelemetry Integration

```python
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor

# Initialize tracing
trace.set_tracer_provider(TracerProvider())
tracer = trace.get_tracer(__name__)

# Configure exporter (e.g., to Jaeger, Zipkin, or OTLP endpoint)
otlp_exporter = OTLPSpanExporter(endpoint="http://otel-collector:4317")
span_processor = BatchSpanProcessor(otlp_exporter)
trace.get_tracer_provider().add_span_processor(span_processor)

# Instrument FastAPI
FastAPIInstrumentor.instrument_app(app)

# Custom spans for graph nodes
def traced_node(func):
    """Decorator to add tracing to graph nodes."""
    def wrapper(state):
        with tracer.start_as_current_span(
            func.__name__,
            attributes={
                "langgraph.node": func.__name__,
                "langgraph.state_keys": list(state.keys())
            }
        ) as span:
            try:
                result = func(state)
                span.set_attribute("langgraph.success", True)
                return result
            except Exception as e:
                span.set_attribute("langgraph.success", False)
                span.record_exception(e)
                raise
    return wrapper
```

## Alerting Strategies

```
+------------------------------------------------------------------+
|                   ALERTING PYRAMID                                |
+------------------------------------------------------------------+
|                                                                   |
|                     /\                                            |
|                    /  \     CRITICAL: Page immediately            |
|                   /    \    - Service down                        |
|                  /------\   - Error rate > 10%                    |
|                 /        \                                        |
|                /   HIGH   \  HIGH: Page during business hours     |
|               /            \ - Error rate > 5%                    |
|              /--------------\- Latency p99 > 30s                  |
|             /                \                                    |
|            /      MEDIUM      \ MEDIUM: Slack notification        |
|           /                    \- Error rate > 1%                 |
|          /----------------------\- Latency p95 > 10s              |
|         /                        \                                |
|        /          LOW             \ LOW: Daily digest             |
|       /                            \- Cost anomalies              |
|      /------------------------------\- Quality score drop         |
|                                                                   |
+------------------------------------------------------------------+
```

### Example Alert Rules

```yaml
# alerting_rules.yml (Prometheus format)
groups:
  - name: langgraph_alerts
    rules:
      # High error rate
      - alert: HighErrorRate
        expr: |
          sum(rate(langgraph_requests_total{status="error"}[5m]))
          / sum(rate(langgraph_requests_total[5m])) > 0.05
        for: 5m
        labels:
          severity: high
        annotations:
          summary: "High error rate detected"
          description: "Error rate is {{ $value | humanizePercentage }}"
      
      # High latency
      - alert: HighLatency
        expr: |
          histogram_quantile(0.95, 
            sum(rate(langgraph_request_duration_seconds_bucket[5m])) 
            by (le)
          ) > 10
        for: 5m
        labels:
          severity: medium
        annotations:
          summary: "High latency detected"
          description: "p95 latency is {{ $value }}s"
      
      # LLM API failures
      - alert: LLMAPIFailures
        expr: |
          sum(rate(langgraph_llm_errors_total[5m])) > 0.1
        for: 2m
        labels:
          severity: high
        annotations:
          summary: "LLM API errors detected"
          description: "{{ $value }} errors per second"
      
      # Cost anomaly
      - alert: CostAnomaly
        expr: |
          sum(increase(langgraph_tokens_total[1h])) 
          > avg_over_time(sum(increase(langgraph_tokens_total[1h]))[7d:1h]) * 2
        for: 1h
        labels:
          severity: low
        annotations:
          summary: "Unusual token usage detected"
          description: "Token usage is 2x normal"
```

## Dashboard Design

```
+------------------------------------------------------------------+
|              PRODUCTION DASHBOARD LAYOUT                          |
+------------------------------------------------------------------+
|                                                                   |
|  +-------------------+  +-------------------+  +----------------+ |
|  | Requests/min      |  | Error Rate        |  | Avg Latency    | |
|  |     1,234         |  |     0.12%         |  |    2.3s        | |
|  | [=========>    ]  |  | [=>            ]  |  | [=====>     ]  | |
|  +-------------------+  +-------------------+  +----------------+ |
|                                                                   |
|  +--------------------------------------------------------------+|
|  |  Request Latency Over Time (p50, p95, p99)                   ||
|  |  ^                                                           ||
|  |  |    ___                    ___                             ||
|  |  |   /   \    p99          /   \                            ||
|  |  |  /     \_______________/     \___                        ||
|  |  | /                             p95 \_____                 ||
|  |  |/  p50 ___________________________________________        ||
|  |  +-------------------------------------------------->       ||
|  |    00:00    06:00    12:00    18:00    24:00                 ||
|  +--------------------------------------------------------------+|
|                                                                   |
|  +-----------------------------+  +----------------------------+ |
|  | Token Usage by Model        |  | Node Execution Times       | |
|  | [GPT-4      ] 45%           |  | router:      120ms avg     | |
|  | [GPT-3.5    ] 35%           |  | search:      450ms avg     | |
|  | [Embeddings ] 20%           |  | synthesize: 1.8s avg       | |
|  +-----------------------------+  +----------------------------+ |
|                                                                   |
|  +--------------------------------------------------------------+|
|  |  Recent Errors                                               ||
|  |  +----------------------------------------------------------+||
|  |  | 10:32:15 | thread_abc | LLM timeout after 60s           |||
|  |  | 10:31:42 | thread_def | Rate limit exceeded             |||
|  |  | 10:30:55 | thread_ghi | Invalid tool response           |||
|  |  +----------------------------------------------------------+||
|  +--------------------------------------------------------------+|
|                                                                   |
+------------------------------------------------------------------+
```

## Interview Tips

```
+------------------------------------------------------------------+
|                       INTERVIEW TIP                               |
+------------------------------------------------------------------+
| Q: "How would you debug a production LangGraph application that   |
|     has intermittent failures?"                                   |
|                                                                   |
| A: I would follow a systematic approach:                          |
|                                                                   |
| 1. Check Dashboards First                                         |
|    - Error rate trends: Is it getting worse?                      |
|    - Correlation with traffic: Load-related?                      |
|    - Time patterns: Specific times of day?                        |
|                                                                   |
| 2. Analyze Traces in LangSmith                                    |
|    - Find failed runs                                             |
|    - Compare with successful runs                                 |
|    - Look for common patterns (specific nodes, inputs)            |
|                                                                   |
| 3. Check External Dependencies                                    |
|    - LLM API status (OpenAI status page)                          |
|    - Database/cache health                                        |
|    - Network issues                                               |
|                                                                   |
| 4. Examine Logs                                                   |
|    - Filter by correlation ID from failed traces                  |
|    - Look for warnings before errors                              |
|    - Check for resource exhaustion                                |
|                                                                   |
| 5. Reproduce in Staging                                           |
|    - Use production traces as test cases                          |
|    - Enable debug logging                                         |
|    - Add temporary instrumentation if needed                      |
|                                                                   |
| Key insight: LangSmith traces are invaluable because they show    |
| the exact inputs, outputs, and timing of every step.              |
+------------------------------------------------------------------+
```

## Summary

Effective monitoring for LangGraph requires:

1. **LangSmith Integration** - Deep visibility into LLM operations
2. **Structured Logging** - Machine-parseable logs for aggregation
3. **Distributed Tracing** - End-to-end request visibility
4. **Comprehensive Metrics** - Performance, cost, and quality
5. **Smart Alerting** - Right alerts to the right people

---

Next: [Monitoring Example](./05_monitoring_example.py)
