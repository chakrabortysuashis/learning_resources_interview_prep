# Production Best Practices for LangGraph

## Overview

This guide covers essential patterns and practices for running LangGraph
applications reliably in production environments.

```
+------------------------------------------------------------------+
|              PRODUCTION BEST PRACTICES PILLARS                    |
+------------------------------------------------------------------+
|                                                                   |
|   +------------+  +------------+  +------------+  +------------+  |
|   |   Error    |  |   Retry    |  |  Timeout   |  |  Security  |  |
|   |  Handling  |  |   Logic    |  | Management |  |  Practices |  |
|   +------------+  +------------+  +------------+  +------------+  |
|        |              |              |              |              |
|        v              v              v              v              |
|   +----------------------------------------------------------+   |
|   |              RELIABLE PRODUCTION SYSTEM                   |   |
|   +----------------------------------------------------------+   |
|                                                                   |
+------------------------------------------------------------------+
```

## Error Handling

### Error Handling Hierarchy

```
+------------------------------------------------------------------+
|                 ERROR HANDLING LEVELS                             |
+------------------------------------------------------------------+
|                                                                   |
|   Level 1: Node-Level Handling                                    |
|   +----------------------------------------------------------+   |
|   | try:                                                      |   |
|   |     result = llm.invoke(messages)                         |   |
|   | except RateLimitError:                                    |   |
|   |     # Handle rate limiting                                |   |
|   | except APIError:                                          |   |
|   |     # Handle API errors                                   |   |
|   +----------------------------------------------------------+   |
|                                                                   |
|   Level 2: Graph-Level Handling                                   |
|   +----------------------------------------------------------+   |
|   | try:                                                      |   |
|   |     result = graph.invoke(input)                          |   |
|   | except GraphExecutionError:                               |   |
|   |     # Handle graph failures                               |   |
|   +----------------------------------------------------------+   |
|                                                                   |
|   Level 3: Application-Level Handling                             |
|   +----------------------------------------------------------+   |
|   | @app.exception_handler(Exception)                         |   |
|   | async def handle_error(request, exc):                     |   |
|   |     # Global error handling                               |   |
|   +----------------------------------------------------------+   |
|                                                                   |
+------------------------------------------------------------------+
```

### Error Types in LangGraph

```python
# Common error types and how to handle them

from langchain_core.exceptions import OutputParserException
from openai import RateLimitError, APIError, Timeout

class ErrorTypes:
    """
    Error classification for LangGraph applications.
    """
    
    # Transient errors (can retry)
    TRANSIENT = [
        "RateLimitError",      # Too many requests
        "Timeout",             # Request timeout
        "ServiceUnavailable",  # Temporary outage
        "ConnectionError",     # Network issues
    ]
    
    # Permanent errors (don't retry)
    PERMANENT = [
        "AuthenticationError",  # Invalid API key
        "InvalidRequestError",  # Bad request format
        "ContentFilterError",   # Content blocked
        "ContextLengthExceeded" # Token limit exceeded
    ]
    
    # Recoverable errors (can handle gracefully)
    RECOVERABLE = [
        "OutputParserException",  # Failed to parse output
        "ToolExecutionError",     # Tool failed
        "ValidationError",        # Input validation failed
    ]
```

### Error Handling Patterns

```python
# Pattern 1: Fallback responses

def node_with_fallback(state):
    """Node that provides fallback on error."""
    try:
        response = llm.invoke(state["messages"])
        return {"messages": [response]}
    except Exception as e:
        # Provide graceful fallback
        fallback = AIMessage(
            content="I apologize, but I'm having trouble processing "
                    "your request. Please try again or rephrase your question."
        )
        return {
            "messages": [fallback],
            "error": {"type": type(e).__name__, "message": str(e)}
        }


# Pattern 2: Error routing

def error_router(state):
    """Route based on error presence."""
    if state.get("error"):
        error_type = state["error"]["type"]
        
        if error_type in ErrorTypes.TRANSIENT:
            return "retry_node"
        elif error_type in ErrorTypes.RECOVERABLE:
            return "recovery_node"
        else:
            return "error_response_node"
    
    return "continue_node"


# Pattern 3: Circuit breaker state

class CircuitBreakerState:
    """Track failures for circuit breaker pattern."""
    
    def __init__(self, threshold: int = 5, timeout: int = 60):
        self.failures = 0
        self.threshold = threshold
        self.timeout = timeout
        self.last_failure_time = None
        self.state = "closed"  # closed, open, half-open
    
    def record_failure(self):
        self.failures += 1
        self.last_failure_time = time.time()
        if self.failures >= self.threshold:
            self.state = "open"
    
    def record_success(self):
        self.failures = 0
        self.state = "closed"
    
    def can_proceed(self) -> bool:
        if self.state == "closed":
            return True
        if self.state == "open":
            if time.time() - self.last_failure_time > self.timeout:
                self.state = "half-open"
                return True
            return False
        return True  # half-open
```

## Retry Strategies

### Retry Pattern Overview

```
+------------------------------------------------------------------+
|                    RETRY STRATEGIES                               |
+------------------------------------------------------------------+
|                                                                   |
|   Strategy         Use Case                  Implementation       |
|   --------         --------                  --------------       |
|   Fixed Delay      Simple retries            wait(1s) each time   |
|   Exponential      Rate limiting             wait(2^n seconds)    |
|   Jitter           Thundering herd           random(0, 2^n)       |
|   Circuit Breaker  Persistent failures       stop after N fails   |
|                                                                   |
|   Retry Decision Tree:                                            |
|   -------------------                                             |
|                                                                   |
|   Error Occurred                                                  |
|        |                                                          |
|        v                                                          |
|   Is it transient? --No--> Don't retry, handle error              |
|        |                                                          |
|       Yes                                                         |
|        |                                                          |
|        v                                                          |
|   Under retry limit? --No--> Don't retry, circuit breaker         |
|        |                                                          |
|       Yes                                                         |
|        |                                                          |
|        v                                                          |
|   Wait with backoff --> Retry                                     |
|                                                                   |
+------------------------------------------------------------------+
```

### Implementation

```python
import time
import random
from functools import wraps
from typing import Tuple, Type

def retry_with_backoff(
    max_retries: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 60.0,
    exponential_base: float = 2.0,
    jitter: bool = True,
    retryable_exceptions: Tuple[Type[Exception], ...] = (Exception,)
):
    """
    Decorator for retry with exponential backoff.
    
    Args:
        max_retries: Maximum number of retry attempts
        base_delay: Initial delay in seconds
        max_delay: Maximum delay in seconds
        exponential_base: Base for exponential backoff
        jitter: Add randomness to prevent thundering herd
        retryable_exceptions: Exceptions that trigger retry
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            last_exception = None
            
            for attempt in range(max_retries + 1):
                try:
                    return func(*args, **kwargs)
                except retryable_exceptions as e:
                    last_exception = e
                    
                    if attempt == max_retries:
                        raise
                    
                    # Calculate delay with exponential backoff
                    delay = min(
                        base_delay * (exponential_base ** attempt),
                        max_delay
                    )
                    
                    # Add jitter
                    if jitter:
                        delay = delay * (0.5 + random.random())
                    
                    print(f"Retry {attempt + 1}/{max_retries} after {delay:.2f}s")
                    time.sleep(delay)
            
            raise last_exception
        
        return wrapper
    return decorator


# Usage in a node
@retry_with_backoff(
    max_retries=3,
    base_delay=1.0,
    retryable_exceptions=(RateLimitError, Timeout)
)
def call_llm(messages):
    return llm.invoke(messages)
```

## Timeout Management

### Timeout Layers

```
+------------------------------------------------------------------+
|                    TIMEOUT LAYERS                                 |
+------------------------------------------------------------------+
|                                                                   |
|   +----------------------------------------------------------+   |
|   |  Request Timeout (outermost)                              |   |
|   |  - Total time for entire request                          |   |
|   |  - Typically 30-120 seconds for web requests              |   |
|   |                                                           |   |
|   |  +------------------------------------------------------+ |   |
|   |  |  Graph Timeout                                       | |   |
|   |  |  - Time limit for graph execution                    | |   |
|   |  |  - Should be less than request timeout               | |   |
|   |  |                                                      | |   |
|   |  |  +--------------------------------------------------+| |   |
|   |  |  |  Node Timeout                                    || |   |
|   |  |  |  - Per-node time limit                           || |   |
|   |  |  |                                                  || |   |
|   |  |  |  +----------------------------------------------+|| |   |
|   |  |  |  |  LLM Timeout                                 ||| |   |
|   |  |  |  |  - Time waiting for LLM response             ||| |   |
|   |  |  |  |  - Usually 30-60 seconds                     ||| |   |
|   |  |  |  +----------------------------------------------+|| |   |
|   |  |  +--------------------------------------------------+| |   |
|   |  +------------------------------------------------------+ |   |
|   +----------------------------------------------------------+   |
|                                                                   |
+------------------------------------------------------------------+
```

### Timeout Implementation

```python
import asyncio
from contextlib import contextmanager
import signal

# Sync timeout using signals (Unix only)
@contextmanager
def timeout(seconds: int):
    """Context manager for timeout (Unix only)."""
    def timeout_handler(signum, frame):
        raise TimeoutError(f"Operation timed out after {seconds}s")
    
    # Set the signal handler
    old_handler = signal.signal(signal.SIGALRM, timeout_handler)
    signal.alarm(seconds)
    
    try:
        yield
    finally:
        signal.alarm(0)
        signal.signal(signal.SIGALRM, old_handler)


# Async timeout (cross-platform)
async def with_timeout(coro, seconds: float, default=None):
    """Execute coroutine with timeout."""
    try:
        return await asyncio.wait_for(coro, timeout=seconds)
    except asyncio.TimeoutError:
        if default is not None:
            return default
        raise


# Usage in graph
class TimeoutConfig:
    """Centralized timeout configuration."""
    
    REQUEST_TIMEOUT = 120     # 2 minutes for full request
    GRAPH_TIMEOUT = 90        # 90 seconds for graph execution
    NODE_TIMEOUT = 30         # 30 seconds per node
    LLM_TIMEOUT = 60          # 60 seconds for LLM calls
    TOOL_TIMEOUT = 30         # 30 seconds for tool execution


# In FastAPI
@app.post("/invoke")
async def invoke_graph(request: InvokeRequest):
    try:
        result = await asyncio.wait_for(
            graph.ainvoke(request.input),
            timeout=TimeoutConfig.GRAPH_TIMEOUT
        )
        return result
    except asyncio.TimeoutError:
        raise HTTPException(
            status_code=504,
            detail="Request timed out"
        )
```

## Security Best Practices

### Security Checklist

```
+------------------------------------------------------------------+
|               SECURITY BEST PRACTICES                             |
+------------------------------------------------------------------+
|                                                                   |
|   [ ] Input Validation                                            |
|       - Sanitize user inputs                                      |
|       - Limit input length                                        |
|       - Validate data types                                       |
|                                                                   |
|   [ ] Secrets Management                                          |
|       - Never hardcode API keys                                   |
|       - Use environment variables or secret managers              |
|       - Rotate keys regularly                                     |
|                                                                   |
|   [ ] Prompt Injection Prevention                                 |
|       - Separate user input from system prompts                   |
|       - Use input/output guardrails                               |
|       - Monitor for suspicious patterns                           |
|                                                                   |
|   [ ] Output Sanitization                                         |
|       - Filter sensitive information                              |
|       - Validate LLM outputs before use                           |
|       - Prevent XSS in web contexts                               |
|                                                                   |
|   [ ] Access Control                                              |
|       - Implement authentication                                  |
|       - Use rate limiting                                         |
|       - Audit logging                                             |
|                                                                   |
+------------------------------------------------------------------+
```

### Input Validation

```python
from pydantic import BaseModel, Field, validator
from typing import List
import re

class SecureInput(BaseModel):
    """Validated input model with security checks."""
    
    messages: List[dict] = Field(..., max_items=100)
    thread_id: str = Field(..., max_length=100)
    
    @validator("messages")
    def validate_messages(cls, messages):
        for msg in messages:
            content = msg.get("content", "")
            
            # Length check
            if len(content) > 10000:
                raise ValueError("Message too long")
            
            # Basic prompt injection detection
            suspicious_patterns = [
                r"ignore previous instructions",
                r"disregard all prior",
                r"system prompt",
                r"you are now",
            ]
            
            for pattern in suspicious_patterns:
                if re.search(pattern, content.lower()):
                    raise ValueError("Suspicious input detected")
        
        return messages
    
    @validator("thread_id")
    def validate_thread_id(cls, v):
        # Only allow alphanumeric and hyphens
        if not re.match(r"^[a-zA-Z0-9-]+$", v):
            raise ValueError("Invalid thread ID format")
        return v


# Output sanitization
def sanitize_output(response: str) -> str:
    """Remove potentially sensitive information from output."""
    
    # Remove potential API keys
    response = re.sub(r"sk-[a-zA-Z0-9]{32,}", "[REDACTED]", response)
    
    # Remove potential emails
    response = re.sub(r"\b[\w.-]+@[\w.-]+\.\w+\b", "[EMAIL]", response)
    
    # Remove potential phone numbers
    response = re.sub(r"\b\d{3}[-.]?\d{3}[-.]?\d{4}\b", "[PHONE]", response)
    
    return response
```

## Resource Management

### Memory Management

```
+------------------------------------------------------------------+
|               MEMORY MANAGEMENT                                   |
+------------------------------------------------------------------+
|                                                                   |
|   Problem: LLM applications can consume significant memory        |
|                                                                   |
|   State Growth Over Time:                                         |
|   +----------------------------------+                            |
|   |                              ****|                            |
|   |                         *****   |                            |
|   |                    *****        |                            |
|   |               *****             |  <- Without limits         |
|   |          *****                  |                            |
|   |     *****                       |                            |
|   +----------------------------------+                            |
|     Turn 1   10    20    30    40                                |
|                                                                   |
|   Solutions:                                                      |
|   ----------                                                      |
|   1. Message windowing (keep last N messages)                     |
|   2. Message summarization (compress old messages)                |
|   3. State pruning (remove unnecessary data)                      |
|   4. Streaming (don't buffer entire responses)                    |
|                                                                   |
+------------------------------------------------------------------+
```

### Message Window Implementation

```python
from typing import List
from langchain_core.messages import BaseMessage, SystemMessage

def apply_message_window(
    messages: List[BaseMessage],
    max_messages: int = 20,
    always_keep_system: bool = True
) -> List[BaseMessage]:
    """
    Apply a sliding window to message history.
    
    Keeps the most recent messages while optionally
    preserving system messages.
    """
    if len(messages) <= max_messages:
        return messages
    
    if always_keep_system:
        # Separate system messages
        system_msgs = [m for m in messages if isinstance(m, SystemMessage)]
        other_msgs = [m for m in messages if not isinstance(m, SystemMessage)]
        
        # Keep system messages + most recent others
        remaining_slots = max_messages - len(system_msgs)
        return system_msgs + other_msgs[-remaining_slots:]
    
    return messages[-max_messages:]


# Message summarization for long conversations
async def summarize_old_messages(
    messages: List[BaseMessage],
    threshold: int = 30,
    summarize_count: int = 20
) -> List[BaseMessage]:
    """
    Summarize old messages when history gets too long.
    """
    if len(messages) <= threshold:
        return messages
    
    # Messages to summarize
    old_messages = messages[:summarize_count]
    recent_messages = messages[summarize_count:]
    
    # Create summary
    summary_prompt = "Summarize this conversation concisely:\n"
    for msg in old_messages:
        role = "User" if isinstance(msg, HumanMessage) else "Assistant"
        summary_prompt += f"{role}: {msg.content}\n"
    
    summary = await llm.ainvoke([HumanMessage(content=summary_prompt)])
    
    # Return summary + recent messages
    return [
        SystemMessage(content=f"Previous conversation summary: {summary.content}")
    ] + recent_messages
```

## Configuration Management

### Environment-Based Configuration

```python
from pydantic_settings import BaseSettings
from typing import Optional
from functools import lru_cache

class ProductionSettings(BaseSettings):
    """Production configuration with environment variable support."""
    
    # Application
    app_name: str = "LangGraph Production"
    environment: str = "production"
    debug: bool = False
    
    # LLM Configuration
    openai_api_key: str
    model_name: str = "gpt-4"
    temperature: float = 0.7
    max_tokens: int = 2000
    
    # Timeouts (seconds)
    request_timeout: int = 120
    llm_timeout: int = 60
    
    # Retry Configuration
    max_retries: int = 3
    retry_base_delay: float = 1.0
    
    # Rate Limiting
    rate_limit_requests: int = 100
    rate_limit_window: int = 60
    
    # Memory Management
    max_message_history: int = 50
    
    # Monitoring
    langsmith_enabled: bool = True
    langsmith_project: str = "production"
    
    class Config:
        env_file = ".env"
        env_prefix = ""


@lru_cache()
def get_settings() -> ProductionSettings:
    """Get cached settings instance."""
    return ProductionSettings()


# Usage
settings = get_settings()
llm = ChatOpenAI(
    model=settings.model_name,
    temperature=settings.temperature,
    max_tokens=settings.max_tokens,
    timeout=settings.llm_timeout,
    max_retries=settings.max_retries,
)
```

## Logging and Auditing

### Audit Log Pattern

```python
from datetime import datetime
from typing import Any, Dict
import json

class AuditLogger:
    """
    Audit logger for compliance and debugging.
    
    Records all significant events with context for
    later analysis and compliance requirements.
    """
    
    def __init__(self, service_name: str):
        self.service_name = service_name
    
    def log_event(
        self,
        event_type: str,
        user_id: str,
        thread_id: str,
        details: Dict[str, Any],
        sensitive: bool = False
    ):
        """Log an audit event."""
        event = {
            "timestamp": datetime.utcnow().isoformat(),
            "service": self.service_name,
            "event_type": event_type,
            "user_id": user_id,
            "thread_id": thread_id,
            "details": details if not sensitive else "[REDACTED]",
        }
        
        # In production, send to audit log service
        print(json.dumps(event))
    
    def log_request(self, user_id: str, thread_id: str, input_preview: str):
        """Log incoming request."""
        self.log_event(
            "REQUEST",
            user_id,
            thread_id,
            {"input_preview": input_preview[:100]}
        )
    
    def log_response(self, user_id: str, thread_id: str, duration: float):
        """Log response sent."""
        self.log_event(
            "RESPONSE",
            user_id,
            thread_id,
            {"duration_seconds": duration}
        )
    
    def log_error(self, user_id: str, thread_id: str, error: Exception):
        """Log error occurrence."""
        self.log_event(
            "ERROR",
            user_id,
            thread_id,
            {"error_type": type(error).__name__, "message": str(error)}
        )
```

## Interview Tips

```
+------------------------------------------------------------------+
|                       INTERVIEW TIP                               |
+------------------------------------------------------------------+
| Q: "What are the most critical production considerations for a    |
|     LangGraph application?"                                       |
|                                                                   |
| A: I prioritize these areas:                                      |
|                                                                   |
| 1. Reliability (Most Critical)                                    |
|    - LLM APIs can fail; implement retries with backoff            |
|    - Use circuit breakers to prevent cascade failures             |
|    - Have fallback responses for graceful degradation             |
|                                                                   |
| 2. Cost Control                                                   |
|    - Token usage grows with conversation length                   |
|    - Implement message windowing/summarization                    |
|    - Monitor and alert on cost anomalies                          |
|    - Cache responses where appropriate                            |
|                                                                   |
| 3. Security                                                       |
|    - Prompt injection is a real risk                              |
|    - Validate all inputs, sanitize outputs                        |
|    - Use secrets management for API keys                          |
|    - Audit all interactions for compliance                        |
|                                                                   |
| 4. Observability                                                  |
|    - LLM apps are hard to debug without good tracing              |
|    - Use LangSmith or similar for LLM-specific observability      |
|    - Track both technical and quality metrics                     |
|                                                                   |
| 5. User Experience                                                |
|    - Timeouts must be user-friendly                               |
|    - Streaming improves perceived latency                         |
|    - Error messages should be helpful                             |
+------------------------------------------------------------------+
```

## Summary Checklist

```
Production Readiness Checklist:
===============================

Error Handling:
[ ] Node-level error handling with fallbacks
[ ] Graph-level error recovery
[ ] Appropriate error messages for users
[ ] Logging of all errors with context

Retries:
[ ] Exponential backoff implemented
[ ] Jitter to prevent thundering herd
[ ] Circuit breaker for persistent failures
[ ] Retry limits configured

Timeouts:
[ ] Request-level timeout
[ ] Graph execution timeout
[ ] LLM call timeout
[ ] Tool execution timeout

Security:
[ ] Input validation
[ ] Output sanitization
[ ] Secrets in environment variables
[ ] Rate limiting

Resource Management:
[ ] Message history limits
[ ] Memory monitoring
[ ] Connection pooling
[ ] Graceful shutdown

Monitoring:
[ ] Structured logging
[ ] Metrics collection
[ ] Alerting configured
[ ] Audit logging
```

---

Next: [Scaling Considerations](./09_scaling.md)
