# What is LangGraph?

## Introduction

LangGraph is a library built on top of LangChain that enables you to build **stateful, multi-actor applications** with Large Language Models (LLMs). It provides a way to create complex agent workflows using **graph-based architectures** instead of simple linear chains.

---

## The Problem LangGraph Solves

Traditional LangChain applications follow a **linear chain** pattern:

```
Traditional LangChain Chain:
============================

[Input] --> [Step 1] --> [Step 2] --> [Step 3] --> [Output]
    |           |           |           |
    v           v           v           v
  User       Prompt       LLM       Parser
  Query     Template      Call      Output

Problem: What if Step 2 needs to go back to Step 1?
         What if we need conditional branching?
         What if multiple steps run in parallel?
```

Real-world AI applications often need:
- **Loops** (retry mechanisms, iterative refinement)
- **Conditional branching** (different paths based on results)
- **Parallel execution** (multiple operations at once)
- **Human-in-the-loop** (pause for human approval)

---

## LangGraph's Solution: Graphs

LangGraph introduces **Directed Graphs** to model complex workflows:

```
LangGraph Approach:
===================

                    +-------------+
                    |    START    |
                    +------+------+
                           |
                           v
                    +------+------+
                    |   Agent     |
                    | (Reasoning) |
                    +------+------+
                           |
              +------------+------------+
              |                         |
              v                         v
       +------+------+          +-------+-----+
       |  Use Tool   |          |   Respond   |
       +------+------+          +------+------+
              |                        |
              |    +------------+      |
              +--->|   Agent    |<-----+
                   | (Re-think) |
                   +-----+------+
                         |
                         v
                   +-----+------+
                   |    END     |
                   +------------+

Key Features:
- Cycles (loops) are possible
- Conditional edges based on output
- State persists across nodes
```

---

## Core Concepts at a Glance

### 1. State
The shared data structure that flows through the graph.

```python
# Example State
class AgentState(TypedDict):
    messages: list[BaseMessage]      # Conversation history
    current_step: str                 # Where are we?
    intermediate_results: list[str]  # Collected results
```

### 2. Nodes
Functions that process and modify state.

```
+------------------+
|      NODE        |
+------------------+
|  Input: State    |
|  Process: Logic  |
|  Output: State   |
+------------------+
```

### 3. Edges
Connections between nodes that define the flow.

```
Types of Edges:
===============

Normal Edge:     [A] ---------> [B]
                      (always)

Conditional:     [A] ---?---> [B]
                      |
                      +-----> [C]
                 (based on condition)
```

---

## Why Was LangGraph Created?

```
+--------------------------------------------------+
|              EVOLUTION OF LLM APPS               |
+--------------------------------------------------+
|                                                  |
|  Phase 1: Simple Prompts                         |
|  "Summarize this text"                           |
|  --> Single LLM call                             |
|                                                  |
|  Phase 2: Chains (LangChain)                     |
|  "Research and summarize"                        |
|  --> Linear sequence of calls                    |
|                                                  |
|  Phase 3: Agents (LangGraph)                     |
|  "Research, analyze, decide, iterate"            |
|  --> Complex, stateful, multi-step workflows     |
|                                                  |
+--------------------------------------------------+
```

---

## LangGraph Architecture

```
+------------------------------------------------------------+
|                      YOUR APPLICATION                       |
+------------------------------------------------------------+
|                                                             |
|   +---------------------------------------------------+    |
|   |                   LANGGRAPH                        |    |
|   +---------------------------------------------------+    |
|   |                                                   |    |
|   |   +-------+    +-------+    +-------+            |    |
|   |   | Node  |--->| Node  |--->| Node  |            |    |
|   |   |   A   |    |   B   |    |   C   |            |    |
|   |   +-------+    +-------+    +-------+            |    |
|   |        ^            |                             |    |
|   |        |            v                             |    |
|   |        +----[Conditional Loop]                   |    |
|   |                                                   |    |
|   |   +-------------------------------------------+   |    |
|   |   |              STATE MANAGER                |   |    |
|   |   | (Keeps track of data across all nodes)   |   |    |
|   |   +-------------------------------------------+   |    |
|   |                                                   |    |
|   +---------------------------------------------------+    |
|                           |                                 |
|   +---------------------------------------------------+    |
|   |                   LANGCHAIN                        |    |
|   | (LLMs, Prompts, Tools, Memory, Retrievers, etc.)  |    |
|   +---------------------------------------------------+    |
|                                                             |
+------------------------------------------------------------+
```

---

## Key Benefits of LangGraph

| Benefit | Description |
|---------|-------------|
| **Cyclical Workflows** | Create loops for iterative refinement |
| **State Management** | Built-in state persistence across nodes |
| **Human-in-the-Loop** | Pause execution for human input |
| **Streaming** | Stream outputs from any node |
| **Persistence** | Save and resume graph execution |
| **Debugging** | Visual debugging tools (LangSmith) |

---

## Simple Mental Model

Think of LangGraph as a **flowchart executor for AI**:

```
+------------------------------------------+
|         LangGraph Mental Model           |
+------------------------------------------+
|                                          |
|   You Draw:        LangGraph Runs:       |
|   ----------       ----------------      |
|                                          |
|   [Start]          Initializes state     |
|      |                                   |
|      v                                   |
|   [Think]  ------> Calls LLM             |
|      |                                   |
|      v                                   |
|   [Decide] ------> Evaluates condition   |
|    /   \                                 |
|   v     v                                |
| [Act] [End]  ----> Executes branch       |
|   |                                      |
|   +---> loops back if needed             |
|                                          |
+------------------------------------------+
```

---

## Interview Tips

```
+----------------------------------------------------------+
|  INTERVIEW TIP                                            |
+----------------------------------------------------------+
|                                                           |
|  When asked "What is LangGraph?", structure your answer:  |
|                                                           |
|  1. START with the problem it solves:                     |
|     "LangChain chains are linear, but real AI apps        |
|      need loops, branches, and state management."         |
|                                                           |
|  2. EXPLAIN the solution:                                 |
|     "LangGraph uses directed graphs to enable complex,    |
|      stateful, multi-step agent workflows."               |
|                                                           |
|  3. GIVE an example:                                      |
|     "For example, an agent that researches, thinks,       |
|      uses tools, and iterates until satisfied."           |
|                                                           |
+----------------------------------------------------------+
```

---

## Quick Reference

```
LangGraph = LangChain + Graph-based Workflow + State Management

Key Components:
- StateGraph: The main graph builder class
- Nodes: Python functions that process state
- Edges: Connections (normal or conditional)
- State: TypedDict shared across all nodes
- Checkpointing: Save/resume execution state
```

---

## What's Next?

Now that you understand what LangGraph is, let's explore:
- How it compares to plain LangChain (next file)
- The fundamentals of directed graphs
- Building your first LangGraph application

---

## Summary

- LangGraph extends LangChain with graph-based workflows
- It solves the limitations of linear chains
- Core concepts: State, Nodes, Edges
- Enables loops, conditionals, and complex agent patterns
- Built for production-grade AI applications
