# Directed Graphs Basics

## Introduction

Before diving deep into LangGraph, you need to understand the fundamental concept it's built upon: **Directed Graphs**. Don't worry - we'll make this simple and visual!

---

## What is a Graph?

In computer science, a **graph** is a data structure consisting of:
- **Nodes** (also called vertices): Points that represent entities
- **Edges**: Lines connecting nodes, representing relationships

```
Simple Graph (Undirected):
==========================

      [A] ------- [B]
       |           |
       |           |
      [C] ------- [D]

- A, B, C, D are NODES
- The lines between them are EDGES
- You can travel in any direction
```

---

## Directed vs Undirected Graphs

### Undirected Graph
```
Undirected: Can go both ways
==============================

    [Home] ----- [Office]
       
    You can go: Home --> Office
    You can go: Office --> Home
```

### Directed Graph
```
Directed: One-way arrows
========================

    [Home] -----> [Office]
    
    You can ONLY go: Home --> Office
    You CANNOT go: Office --> Home
    
    (Unless there's another arrow going back!)
```

---

## LangGraph Uses Directed Graphs

In LangGraph, we use **directed graphs** because:
- Workflow has a direction (start to end)
- Each step leads to specific next steps
- We need to control the flow

```
LangGraph Directed Graph:
=========================

    [START]
        |
        v
    [Get User Input]
        |
        v
    [Process with LLM]
        |
        +-------+-------+
        |               |
        v               v
    [Use Tool]    [Respond]
        |               |
        +-------+-------+
                |
                v
            [END]
            
Arrows show the DIRECTION of data flow
```

---

## Core Components Explained

### 1. Nodes (Vertices)

Nodes are the **processing units** in your graph. In LangGraph, each node is a Python function.

```
+----------------------------------+
|            NODE                  |
+----------------------------------+
|                                  |
|  Input:  State (dictionary)      |
|                                  |
|  Process: Your Python logic      |
|           - Call LLM             |
|           - Use tools            |
|           - Transform data       |
|                                  |
|  Output: Updated State           |
|                                  |
+----------------------------------+

Example Nodes:
- "agent" node: Decides what to do
- "tools" node: Executes actions  
- "human" node: Gets human input
```

### 2. Edges (Connections)

Edges define **how nodes connect** and the order of execution.

```
Types of Edges in LangGraph:
============================

1. NORMAL EDGE (Unconditional)
   Always goes from A to B
   
   [A] ---------> [B]
   
   Code: graph.add_edge("A", "B")
   

2. CONDITIONAL EDGE
   Goes to B or C based on condition
   
   [A] ----?----> [B]
         |
         +------> [C]
         
   Code: graph.add_conditional_edges("A", router_function)
   

3. ENTRY EDGE
   Where the graph starts
   
   START --------> [First Node]
   
   Code: graph.set_entry_point("first_node")
```

### 3. State

State is the **shared data** that flows through all nodes.

```
+----------------------------------------+
|              STATE                      |
+----------------------------------------+
|                                         |
|  Think of it as a "backpack" that      |
|  travels through every node             |
|                                         |
|  +----------------------------------+   |
|  |  messages: ["Hello", "Hi!"]     |   |
|  |  current_step: "processing"     |   |
|  |  tool_results: [...]            |   |
|  |  should_continue: True          |   |
|  +----------------------------------+   |
|                                         |
|  Each node:                             |
|  1. Reads from state                    |
|  2. Does something                      |
|  3. Updates state                       |
|                                         |
+----------------------------------------+
```

---

## State Machines Explained

LangGraph graphs are essentially **state machines**:

```
State Machine Concept:
======================

A state machine has:
1. States (where you are)
2. Transitions (how you move between states)
3. Events (what triggers transitions)

Example: Traffic Light
+--------+     timer     +--------+     timer     +-------+
|  RED   | ------------> | GREEN  | ------------> |YELLOW |
+--------+               +--------+               +-------+
    ^                                                  |
    |                      timer                       |
    +--------------------------------------------------+

Example: LangGraph Agent
+--------+   "use tool"   +-------+
| AGENT  | -------------> | TOOLS |
+--------+                +-------+
    ^                         |
    |      "return result"    |
    +-------------------------+
    |
    | "respond to user"
    v
+--------+
|  END   |
+--------+
```

---

## Visual Walkthrough: Building a Graph

Let's build a simple graph step by step:

### Step 1: Define Nodes

```
Our nodes (functions):
======================

[Greeter]           [Processor]           [Responder]
    |                    |                     |
    v                    v                     v
"Adds greeting"    "Processes input"    "Formats output"
to state           with logic           for user
```

### Step 2: Connect with Edges

```
Connect the dots:
================

[START]
    |
    | (entry edge)
    v
[Greeter] ------> [Processor] ------> [Responder]
                                           |
                                           v
                                        [END]
```

### Step 3: Add State Flow

```
State flows through:
====================

State: {input: "Hello"}
         |
         v
[Greeter] --> State: {input: "Hello", greeting: "Hi!"}
                              |
                              v
         [Processor] --> State: {input: "Hello", 
                                 greeting: "Hi!",
                                 processed: True}
                                        |
                                        v
                   [Responder] --> State: {input: "Hello",
                                           greeting: "Hi!", 
                                           processed: True,
                                           output: "Hi! Response..."}
                                                    |
                                                    v
                                                 [END]
```

---

## Cycles and Loops

One of LangGraph's superpowers is **cycles** (loops):

```
Without Cycles (Linear):
========================

[A] --> [B] --> [C] --> [END]

Can only go forward. Once past B, can't return.


With Cycles (LangGraph):
========================

         +----------------+
         |                |
         v                |
[A] --> [B] --> [C] ------+
         |
         | (exit condition)
         v
       [END]

Can loop back from C to B until a condition is met!
```

### Real Example: Agent Loop

```
Agent Loop Pattern:
==================

                    +------------------+
                    |                  |
                    v                  |
[User Input] --> [Agent] --> [Tools] -+
                    |
                    | (when done)
                    v
               [Response] --> [END]

The agent can:
1. Think about what to do
2. Use a tool
3. Get result
4. Think again (LOOP!)
5. Eventually respond
```

---

## Common Graph Patterns

### Pattern 1: Sequential

```
Sequential:
===========
[A] --> [B] --> [C] --> [END]

Use when: Steps must happen in order
Example: Fetch data --> Process --> Save
```

### Pattern 2: Branching

```
Branching:
==========
            +--> [B] --+
            |          |
[A] --------+          +--> [D] --> [END]
            |          |
            +--> [C] --+

Use when: Different paths based on conditions
Example: If question is simple --> quick answer
         If complex --> detailed analysis
```

### Pattern 3: Parallel

```
Parallel:
=========
         +--> [B] --+
         |         |
[A] -----+--> [C] -+--> [D] --> [END]
         |         |
         +--> [D] --+

Use when: Independent operations can run together
Example: Search multiple sources simultaneously
```

### Pattern 4: Loop with Exit

```
Loop with Exit:
===============
        +--------+
        |        |
        v        |
[A] --> [B] -----+ (condition: not done)
        |
        | (condition: done)
        v
      [END]

Use when: Repeat until condition met
Example: Keep researching until answer found
```

---

## Interview Tips

```
+----------------------------------------------------------+
|  INTERVIEW TIP                                            |
+----------------------------------------------------------+
|                                                           |
|  When explaining graphs in LangGraph context:             |
|                                                           |
|  1. "Nodes are Python functions that process state"       |
|                                                           |
|  2. "Edges define the flow - can be conditional"          |
|                                                           |
|  3. "State is the shared data traveling through nodes"    |
|                                                           |
|  4. "Cycles enable iterative agent behaviors"             |
|                                                           |
|  5. "Unlike DAGs in Airflow, LangGraph supports cycles    |
|      which is crucial for agent loops"                    |
|                                                           |
+----------------------------------------------------------+
```

---

## Terminology Quick Reference

```
+----------------+------------------------------------------+
|     Term       |            Meaning in LangGraph          |
+----------------+------------------------------------------+
| Graph          | The entire workflow structure            |
| Node           | A Python function that processes state   |
| Edge           | Connection between nodes                 |
| Directed       | Edges have direction (one-way)           |
| State          | Data shared across all nodes             |
| Cycle          | A path that loops back to a prior node   |
| Entry Point    | Where graph execution starts             |
| Conditional    | Edge that depends on a condition         |
| END            | Special node marking completion          |
+----------------+------------------------------------------+
```

---

## Hands-On Exercise

Try drawing these graphs yourself:

### Exercise 1: Simple Chain
```
Create a graph with: Input --> Process --> Output

Your answer:
[        ] --> [        ] --> [        ]
```

### Exercise 2: Conditional Branch
```
Create a graph where:
- Start with analysis
- If simple: give quick answer
- If complex: do research first, then answer

Your answer:
                +--> [          ] --+
                |                   |
[         ] ----+                   +--> [         ]
                |                   |
                +--> [          ] --+
```

### Exercise 3: Agent Loop
```
Create a graph where:
- Agent decides action
- If tool needed: use tool, loop back
- If done: respond and end

Your answer:
(Draw your solution!)
```

---

## Summary

```
+-------------------------------------------------------+
|              KEY TAKEAWAYS                             |
+-------------------------------------------------------+
|                                                        |
|  1. Graphs = Nodes + Edges                            |
|                                                        |
|  2. Directed = One-way arrows                         |
|                                                        |
|  3. Nodes = Functions that process state              |
|                                                        |
|  4. Edges = Flow control (normal or conditional)      |
|                                                        |
|  5. State = Data backpack traveling through graph     |
|                                                        |
|  6. Cycles = Loops for iterative processing           |
|                                                        |
|  7. LangGraph = State machine for AI workflows        |
|                                                        |
+-------------------------------------------------------+
```

---

## Next Steps

Now that you understand graph basics, you're ready to:
1. Set up LangGraph (next file)
2. Build your first graph
3. Create powerful agent workflows!
