"""
LangGraph Hello World Example
==============================

This is your first LangGraph application!
We'll build a simple graph that demonstrates core concepts:
- State definition
- Node creation
- Edge connections
- Graph compilation and execution

Author: Learning Resources
Topic: LangGraph Foundations - Module 01
"""

# =============================================================================
# IMPORTS
# =============================================================================

# TypedDict: Used to define the structure of our state
# Annotated: Used for special state operations (like appending to lists)
from typing import TypedDict, Annotated
import operator

# StateGraph: The main class for building LangGraph applications
# END: Special constant indicating the graph should terminate
from langgraph.graph import StateGraph, END

# For our simple example, we won't use an LLM
# But here's how you'd import it:
# from langchain_openai import ChatOpenAI

# =============================================================================
# STEP 1: DEFINE THE STATE
# =============================================================================
"""
State is the central concept in LangGraph.
It's a dictionary-like object that:
- Flows through every node in the graph
- Gets updated by each node
- Maintains data across the entire workflow

Think of it as a "shared notebook" that every node can read and write to.

+------------------------------------------+
|              STATE                        |
+------------------------------------------+
|  input: str      <- User's input         |
|  messages: list  <- Accumulated messages |
|  output: str     <- Final result         |
+------------------------------------------+
"""


class HelloWorldState(TypedDict):
    """
    Our state definition using TypedDict.

    Each field represents data that flows through the graph:
    - input: The user's initial input
    - messages: A list that accumulates messages (uses Annotated for appending)
    - step_count: Tracks how many nodes we've passed through
    - output: The final output of our graph
    """

    input: str
    # Annotated with operator.add means new values are APPENDED, not replaced
    messages: Annotated[list[str], operator.add]
    step_count: int
    output: str


# =============================================================================
# STEP 2: DEFINE THE NODES
# =============================================================================
"""
Nodes are Python functions that:
1. Receive the current state
2. Perform some processing
3. Return updates to the state

Each node MUST return a dictionary with state updates.

+------------------+        +------------------+        +------------------+
|   greet_node     | -----> |  process_node    | -----> |  farewell_node   |
+------------------+        +------------------+        +------------------+
| Adds greeting    |        | Processes input  |        | Adds farewell    |
| to messages      |        | increments count |        | creates output   |
+------------------+        +------------------+        +------------------+
"""


def greet_node(state: HelloWorldState) -> dict:
    """
    First node: Greets the user.

    This node:
    1. Reads the input from state
    2. Creates a greeting message
    3. Returns updates to add to state

    Args:
        state: The current state dictionary

    Returns:
        Dictionary with state updates
    """
    # Read from state
    user_input = state["input"]

    # Process (create greeting)
    greeting = f"Hello! I received your message: '{user_input}'"

    # Log for visibility
    print(f"[greet_node] Processing input: {user_input}")
    print(f"[greet_node] Created greeting: {greeting}")

    # Return state updates
    # Note: messages is Annotated with operator.add, so this APPENDS
    return {
        "messages": [greeting],  # This gets APPENDED to existing messages
        "step_count": 1          # This REPLACES the step_count
    }


def process_node(state: HelloWorldState) -> dict:
    """
    Second node: Processes the input.

    This node:
    1. Reads current state
    2. Performs some "processing"
    3. Updates the state

    In a real application, this might call an LLM or tool.
    """
    # Read from state
    user_input = state["input"]
    current_count = state["step_count"]

    # Process
    processed_message = f"Processing complete for: '{user_input}'"
    new_count = current_count + 1

    print(f"[process_node] Step count: {current_count} -> {new_count}")
    print(f"[process_node] Added: {processed_message}")

    # Return updates
    return {
        "messages": [processed_message],  # Appends to messages list
        "step_count": new_count            # Updates step count
    }


def farewell_node(state: HelloWorldState) -> dict:
    """
    Final node: Creates the output and says farewell.

    This node:
    1. Reads all accumulated messages
    2. Creates final output
    3. Adds farewell message
    """
    # Read from state
    all_messages = state["messages"]
    final_count = state["step_count"] + 1

    # Create final output
    output = f"Completed {final_count} steps. Messages: {len(all_messages) + 1}"
    farewell = "Goodbye! Thanks for using LangGraph!"

    print(f"[farewell_node] Creating final output")
    print(f"[farewell_node] Total messages so far: {len(all_messages)}")

    # Return updates
    return {
        "messages": [farewell],  # Appends farewell
        "step_count": final_count,
        "output": output          # Sets final output
    }


# =============================================================================
# STEP 3: BUILD THE GRAPH
# =============================================================================
"""
Now we connect everything together:

1. Create a StateGraph with our state type
2. Add nodes (the functions we defined)
3. Add edges (how nodes connect)
4. Set entry point (where to start)
5. Compile the graph

Visual representation:
======================

[START]
    |
    v
[greet_node]
    |
    v
[process_node]
    |
    v
[farewell_node]
    |
    v
[END]
"""


def build_hello_world_graph():
    """
    Build and return the compiled LangGraph.

    Returns:
        Compiled graph ready for execution
    """

    # -------------------------------------------------------------------------
    # Step 3.1: Create the graph with our state type
    # -------------------------------------------------------------------------
    # StateGraph is parameterized by the state type
    # This ensures type safety throughout the graph
    graph = StateGraph(HelloWorldState)

    # -------------------------------------------------------------------------
    # Step 3.2: Add nodes to the graph
    # -------------------------------------------------------------------------
    # add_node(name, function)
    # - name: String identifier for the node
    # - function: The Python function to execute

    graph.add_node("greet", greet_node)
    graph.add_node("process", process_node)
    graph.add_node("farewell", farewell_node)

    # -------------------------------------------------------------------------
    # Step 3.3: Add edges (connections between nodes)
    # -------------------------------------------------------------------------
    # add_edge(from_node, to_node)
    # This creates a direct, unconditional connection

    graph.add_edge("greet", "process")      # greet -> process
    graph.add_edge("process", "farewell")   # process -> farewell
    graph.add_edge("farewell", END)         # farewell -> END

    # -------------------------------------------------------------------------
    # Step 3.4: Set the entry point
    # -------------------------------------------------------------------------
    # set_entry_point tells the graph where to start

    graph.set_entry_point("greet")

    # -------------------------------------------------------------------------
    # Step 3.5: Compile the graph
    # -------------------------------------------------------------------------
    # compile() validates the graph and returns an executable

    compiled_graph = graph.compile()

    return compiled_graph


# =============================================================================
# STEP 4: RUN THE GRAPH
# =============================================================================
"""
To run the graph, we:
1. Create the initial state
2. Call invoke() with the initial state
3. Get the final state as output

+------------------------------------------+
|            EXECUTION FLOW                 |
+------------------------------------------+
|                                           |
|  Initial State                            |
|  {input: "Hello LangGraph!"}             |
|           |                               |
|           v                               |
|      [Run Graph]                          |
|           |                               |
|           v                               |
|  Final State                              |
|  {input: "...",                          |
|   messages: ["...", "...", "..."],       |
|   step_count: 3,                         |
|   output: "Completed 3 steps..."}        |
|                                           |
+------------------------------------------+
"""


def run_hello_world():
    """
    Execute the Hello World graph.
    """

    print("=" * 60)
    print("LANGGRAPH HELLO WORLD")
    print("=" * 60)
    print()

    # Build the graph
    print("Building graph...")
    app = build_hello_world_graph()
    print("Graph built successfully!")
    print()

    # Define initial state
    # Note: We only need to provide required initial values
    # Other fields will be populated by nodes
    initial_state = {
        "input": "Hello, LangGraph!",
        "messages": [],  # Start with empty messages
        "step_count": 0,
        "output": ""
    }

    print("Initial State:")
    print(f"  input: {initial_state['input']}")
    print(f"  messages: {initial_state['messages']}")
    print(f"  step_count: {initial_state['step_count']}")
    print()

    # Run the graph
    print("-" * 60)
    print("EXECUTING GRAPH...")
    print("-" * 60)
    print()

    # invoke() runs the graph and returns the final state
    final_state = app.invoke(initial_state)

    print()
    print("-" * 60)
    print("EXECUTION COMPLETE!")
    print("-" * 60)
    print()

    # Display results
    print("Final State:")
    print(f"  input: {final_state['input']}")
    print(f"  messages: {final_state['messages']}")
    print(f"  step_count: {final_state['step_count']}")
    print(f"  output: {final_state['output']}")

    return final_state


# =============================================================================
# BONUS: STREAMING EXECUTION
# =============================================================================

def run_with_streaming():
    """
    Demonstrate streaming execution.

    stream() yields the state after EACH node executes,
    allowing you to see the graph's progress in real-time.
    """

    print("\n" + "=" * 60)
    print("STREAMING EXECUTION DEMO")
    print("=" * 60)
    print()

    app = build_hello_world_graph()

    initial_state = {
        "input": "Streaming example!",
        "messages": [],
        "step_count": 0,
        "output": ""
    }

    print("Streaming through nodes...")
    print()

    # stream() yields state after each node
    for step_num, state_update in enumerate(app.stream(initial_state)):
        print(f"After step {step_num + 1}:")
        print(f"  Node executed: {list(state_update.keys())[0]}")
        print(f"  State update: {state_update}")
        print()


# =============================================================================
# MAIN EXECUTION
# =============================================================================

if __name__ == "__main__":
    # Run the basic example
    final_state = run_hello_world()

    # Run the streaming example
    run_with_streaming()

    print("\n" + "=" * 60)
    print("CONGRATULATIONS!")
    print("=" * 60)
    print("""
You've just run your first LangGraph application!

Key concepts demonstrated:
1. State: Defined with TypedDict, flows through all nodes
2. Nodes: Python functions that process and update state
3. Edges: Connections defining the flow between nodes
4. Compile: Validates and creates executable graph
5. Invoke: Runs the graph with initial state
6. Stream: Watch execution progress in real-time

Next steps:
- Try modifying the nodes to do different things
- Add a conditional edge (see next module)
- Integrate an LLM (coming in Module 02)
    """)


# =============================================================================
# EXERCISES
# =============================================================================
"""
+----------------------------------------------------------+
|  PRACTICE EXERCISES                                       |
+----------------------------------------------------------+
|                                                           |
|  Exercise 1: Add a new node                               |
|  - Create a "validate_node" between greet and process    |
|  - It should check if input is not empty                 |
|                                                           |
|  Exercise 2: Modify the state                             |
|  - Add a "timestamp" field to HelloWorldState            |
|  - Update nodes to record when they execute              |
|                                                           |
|  Exercise 3: Multiple inputs                              |
|  - Modify run_hello_world() to accept user input        |
|  - Use input() to get a message from the user           |
|                                                           |
+----------------------------------------------------------+
"""


# =============================================================================
# INTERVIEW TIP
# =============================================================================
"""
+----------------------------------------------------------+
|  INTERVIEW TIP                                            |
+----------------------------------------------------------+
|                                                           |
|  When explaining LangGraph basics:                        |
|                                                           |
|  1. State Management:                                     |
|     "State in LangGraph is like a shared context that    |
|      flows through every node. I use TypedDict for type  |
|      safety and Annotated for special operations like    |
|      appending to lists."                                |
|                                                           |
|  2. Node Functions:                                       |
|     "Nodes are just Python functions. They receive the   |
|      current state, do some processing, and return       |
|      a dictionary with state updates."                   |
|                                                           |
|  3. Graph Compilation:                                    |
|     "compile() validates the graph structure - ensuring  |
|      all nodes are connected and there's a valid path   |
|      from start to end."                                 |
|                                                           |
|  4. Execution:                                            |
|     "invoke() runs the entire graph synchronously.      |
|      stream() lets you see intermediate states, which   |
|      is useful for real-time feedback in chat apps."    |
|                                                           |
+----------------------------------------------------------+
"""
