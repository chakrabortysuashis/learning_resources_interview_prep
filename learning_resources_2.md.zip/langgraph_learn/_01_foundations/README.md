# LangGraph Foundations - Module 01

## Overview

Welcome to the first module of our LangGraph learning journey! This module covers the fundamental concepts you need to understand before building complex agentic applications with LangGraph.

---

## Learning Objectives

By the end of this module, you will be able to:

- [ ] Understand what LangGraph is and why it exists
- [ ] Differentiate between LangGraph and LangChain
- [ ] Grasp core graph concepts (nodes, edges, state)
- [ ] Set up a LangGraph development environment
- [ ] Build and run your first LangGraph application

---

## Module Contents

| File | Description | Estimated Time |
|------|-------------|----------------|
| `01_what_is_langgraph.md` | Introduction to LangGraph and its purpose | 15 mins |
| `02_langgraph_vs_langchain.md` | Comparing LangGraph with LangChain | 10 mins |
| `03_directed_graphs_basics.md` | Understanding graphs, nodes, and edges | 20 mins |
| `04_installation_setup.py` | Setting up your environment | 10 mins |
| `05_hello_world_example.py` | Your first LangGraph application | 15 mins |

**Total Estimated Time:** ~70 minutes

---

## Prerequisites

Before starting this module, you should have:

- Basic Python knowledge (functions, classes, decorators)
- Familiarity with LangChain basics (helpful but not required)
- Python 3.9+ installed on your system
- An OpenAI API key (or another LLM provider)

---

## Key Takeaways Preview

```
+------------------------------------------+
|           WHAT YOU'LL LEARN              |
+------------------------------------------+
|                                          |
|  1. LangGraph = LangChain + Graph Logic  |
|                                          |
|  2. Graphs > Chains for complex agents   |
|                                          |
|  3. State management is central          |
|                                          |
|  4. Nodes = Functions, Edges = Flow      |
|                                          |
+------------------------------------------+
```

---

## Quick Start

If you want to jump straight into code:

```bash
# 1. Install LangGraph
pip install langgraph langchain-openai

# 2. Run the hello world example
python 05_hello_world_example.py
```

---

## Interview Relevance

Topics from this module frequently appear in interviews for:
- ML/AI Engineer roles
- LLM Application Developer positions
- Backend Engineer (AI/ML teams)

Common questions covered:
- "What is LangGraph and how is it different from LangChain?"
- "Explain the concept of state in LangGraph"
- "What are nodes and edges in LangGraph?"

---

## Next Steps

After completing this module, proceed to:
- **Module 02:** State Management Deep Dive
- **Module 03:** Building Complex Agents
- **Module 04:** Memory and Persistence

---

Happy Learning! Let's build intelligent agents with LangGraph.
