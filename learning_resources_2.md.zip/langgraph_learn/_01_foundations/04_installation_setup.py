"""
LangGraph Installation and Setup Guide
=======================================

This file contains installation instructions and a verification script
to ensure your LangGraph environment is correctly configured.

Author: Learning Resources
Topic: LangGraph Foundations - Module 01
"""

# =============================================================================
# INSTALLATION COMMANDS (Run these in your terminal)
# =============================================================================

# -----------------------------------------------------------------------------
# Step 1: Create a virtual environment (recommended)
# -----------------------------------------------------------------------------
# python -m venv langgraph_env
#
# Activate on Windows:
# langgraph_env\Scripts\activate
#
# Activate on macOS/Linux:
# source langgraph_env/bin/activate

# -----------------------------------------------------------------------------
# Step 2: Install core packages
# -----------------------------------------------------------------------------
# pip install langgraph

# -----------------------------------------------------------------------------
# Step 3: Install LangChain components (required for LLM integration)
# -----------------------------------------------------------------------------
# pip install langchain-openai    # For OpenAI models
# pip install langchain-anthropic # For Anthropic Claude models
# pip install langchain-core      # Core LangChain components

# -----------------------------------------------------------------------------
# Step 4: Install optional but recommended packages
# -----------------------------------------------------------------------------
# pip install python-dotenv       # For environment variable management
# pip install langsmith           # For debugging and tracing

# -----------------------------------------------------------------------------
# Quick install (all at once):
# -----------------------------------------------------------------------------
# pip install langgraph langchain-openai langchain-core python-dotenv

# =============================================================================
# ENVIRONMENT SETUP
# =============================================================================

import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# -----------------------------------------------------------------------------
# Setting up API Keys
# -----------------------------------------------------------------------------
# Create a .env file in your project root with:
#
# OPENAI_API_KEY=your-openai-key-here
# ANTHROPIC_API_KEY=your-anthropic-key-here
# LANGSMITH_API_KEY=your-langsmith-key-here  # Optional, for tracing
#
# Or set them directly (not recommended for production):
# os.environ["OPENAI_API_KEY"] = "your-key-here"

# =============================================================================
# VERIFICATION SCRIPT
# =============================================================================

def verify_installation():
    """
    Verify that all required packages are installed correctly.
    Run this function to check your setup.
    """

    print("=" * 60)
    print("LangGraph Installation Verification")
    print("=" * 60)
    print()

    results = []

    # -------------------------------------------------------------------------
    # Check 1: LangGraph
    # -------------------------------------------------------------------------
    print("Checking LangGraph installation...")
    try:
        import langgraph
        from langgraph.graph import StateGraph, END
        version = getattr(langgraph, '__version__', 'unknown')
        print(f"  [OK] langgraph installed (version: {version})")
        results.append(("langgraph", True))
    except ImportError as e:
        print(f"  [FAIL] langgraph not installed: {e}")
        print("  Fix: pip install langgraph")
        results.append(("langgraph", False))

    # -------------------------------------------------------------------------
    # Check 2: LangChain Core
    # -------------------------------------------------------------------------
    print("\nChecking LangChain Core...")
    try:
        import langchain_core
        from langchain_core.messages import HumanMessage, AIMessage
        version = getattr(langchain_core, '__version__', 'unknown')
        print(f"  [OK] langchain-core installed (version: {version})")
        results.append(("langchain-core", True))
    except ImportError as e:
        print(f"  [FAIL] langchain-core not installed: {e}")
        print("  Fix: pip install langchain-core")
        results.append(("langchain-core", False))

    # -------------------------------------------------------------------------
    # Check 3: LangChain OpenAI
    # -------------------------------------------------------------------------
    print("\nChecking LangChain OpenAI integration...")
    try:
        from langchain_openai import ChatOpenAI
        print("  [OK] langchain-openai installed")
        results.append(("langchain-openai", True))
    except ImportError as e:
        print(f"  [WARN] langchain-openai not installed: {e}")
        print("  Fix: pip install langchain-openai")
        results.append(("langchain-openai", False))

    # -------------------------------------------------------------------------
    # Check 4: Python-dotenv
    # -------------------------------------------------------------------------
    print("\nChecking python-dotenv...")
    try:
        from dotenv import load_dotenv
        print("  [OK] python-dotenv installed")
        results.append(("python-dotenv", True))
    except ImportError as e:
        print(f"  [WARN] python-dotenv not installed: {e}")
        print("  Fix: pip install python-dotenv")
        results.append(("python-dotenv", False))

    # -------------------------------------------------------------------------
    # Check 5: API Keys
    # -------------------------------------------------------------------------
    print("\nChecking API keys...")

    openai_key = os.environ.get("OPENAI_API_KEY")
    if openai_key and openai_key != "your-openai-key-here":
        print("  [OK] OPENAI_API_KEY is set")
        results.append(("OPENAI_API_KEY", True))
    else:
        print("  [WARN] OPENAI_API_KEY not set or is placeholder")
        print("  Fix: Set OPENAI_API_KEY in your .env file")
        results.append(("OPENAI_API_KEY", False))

    anthropic_key = os.environ.get("ANTHROPIC_API_KEY")
    if anthropic_key and anthropic_key != "your-anthropic-key-here":
        print("  [OK] ANTHROPIC_API_KEY is set")
        results.append(("ANTHROPIC_API_KEY", True))
    else:
        print("  [INFO] ANTHROPIC_API_KEY not set (optional)")
        results.append(("ANTHROPIC_API_KEY", None))

    # -------------------------------------------------------------------------
    # Summary
    # -------------------------------------------------------------------------
    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)

    required_passed = all(
        status for name, status in results
        if name in ["langgraph", "langchain-core"]
    )

    if required_passed:
        print("""
+--------------------------------------------------+
|  [OK] Core installation successful!              |
|                                                  |
|  You're ready to start using LangGraph.          |
|  Proceed to 05_hello_world_example.py            |
+--------------------------------------------------+
        """)
    else:
        print("""
+--------------------------------------------------+
|  [!] Some required packages are missing.         |
|                                                  |
|  Please install them using:                      |
|  pip install langgraph langchain-core            |
+--------------------------------------------------+
        """)

    return required_passed


def print_useful_imports():
    """
    Print commonly used imports for LangGraph development.
    Copy these to start your LangGraph projects.
    """

    imports = '''
# =============================================================================
# COMMON LANGGRAPH IMPORTS
# =============================================================================

# Core LangGraph imports
from langgraph.graph import StateGraph, END, START
from langgraph.checkpoint.memory import MemorySaver

# Type hints for state
from typing import TypedDict, Annotated, Literal
import operator

# LangChain message types
from langchain_core.messages import (
    HumanMessage,
    AIMessage,
    SystemMessage,
    BaseMessage,
)

# LLM providers
from langchain_openai import ChatOpenAI
# from langchain_anthropic import ChatAnthropic  # For Claude

# Tools and agents
from langchain_core.tools import tool
from langgraph.prebuilt import ToolNode, tools_condition

# Environment management
import os
from dotenv import load_dotenv
load_dotenv()
'''

    print(imports)


# =============================================================================
# MAIN EXECUTION
# =============================================================================

if __name__ == "__main__":
    # Run verification
    verify_installation()

    print("\n")
    print("=" * 60)
    print("USEFUL IMPORTS FOR YOUR PROJECTS")
    print("=" * 60)
    print_useful_imports()

    print("""
# =============================================================================
# NEXT STEPS
# =============================================================================
#
# 1. If verification passed, run: python 05_hello_world_example.py
#
# 2. If you see errors, install missing packages:
#    pip install langgraph langchain-openai langchain-core python-dotenv
#
# 3. Create a .env file with your API keys:
#    OPENAI_API_KEY=sk-...
#
# 4. For tracing/debugging, sign up at: https://smith.langchain.com
#
# =============================================================================
    """)


# =============================================================================
# INTERVIEW TIP
# =============================================================================
"""
+----------------------------------------------------------+
|  INTERVIEW TIP                                            |
+----------------------------------------------------------+
|                                                           |
|  When discussing LangGraph setup in interviews:           |
|                                                           |
|  1. Mention that LangGraph is built on LangChain:         |
|     "LangGraph requires langchain-core as a dependency"   |
|                                                           |
|  2. Know the key packages:                                |
|     - langgraph: Core graph functionality                 |
|     - langchain-openai: OpenAI LLM integration           |
|     - langsmith: Debugging and tracing (optional)         |
|                                                           |
|  3. Understand environment management:                    |
|     "I use python-dotenv to manage API keys securely"    |
|                                                           |
+----------------------------------------------------------+
"""
