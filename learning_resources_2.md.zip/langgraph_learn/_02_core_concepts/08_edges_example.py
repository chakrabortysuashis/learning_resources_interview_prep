"""
Edges Examples in LangGraph
============================

This file demonstrates different types of edges:
- Regular edges
- Conditional edges
- Loops
- Branching and merging
"""

from typing import TypedDict, Annotated, Optional, List, Literal
from langgraph.graph import StateGraph, START, END
import operator


# =============================================================================
# STATE DEFINITIONS
# =============================================================================

class SimpleState(TypedDict):
    """State for basic examples."""
    value: str
    steps: Annotated[List[str], operator.add]


class RouterState(TypedDict):
    """State for routing examples."""
    input: str
    input_type: Optional[str]  # "question", "command", "greeting"
    result: Optional[str]
    steps: Annotated[List[str], operator.add]


class LoopState(TypedDict):
    """State for loop examples."""
    count: int
    max_count: int
    history: Annotated[List[str], operator.add]


# =============================================================================
# EXAMPLE 1: Regular Edges (Linear Pipeline)
# =============================================================================

def step_a(state: SimpleState) -> dict:
    print("  Executing Step A")
    return {"value": state["value"] + " -> A", "steps": ["step_a"]}


def step_b(state: SimpleState) -> dict:
    print("  Executing Step B")
    return {"value": state["value"] + " -> B", "steps": ["step_b"]}


def step_c(state: SimpleState) -> dict:
    print("  Executing Step C")
    return {"value": state["value"] + " -> C", "steps": ["step_c"]}


def demo_regular_edges():
    """
    Demonstrate regular (unconditional) edges.

    Graph structure:
        START -> step_a -> step_b -> step_c -> END
    """
    print("=" * 60)
    print("Example 1: Regular Edges (Linear Pipeline)")
    print("=" * 60)

    graph = StateGraph(SimpleState)

    # Add nodes
    graph.add_node("step_a", step_a)
    graph.add_node("step_b", step_b)
    graph.add_node("step_c", step_c)

    # Add regular edges - simple connections
    graph.add_edge(START, "step_a")
    graph.add_edge("step_a", "step_b")
    graph.add_edge("step_b", "step_c")
    graph.add_edge("step_c", END)

    app = graph.compile()

    result = app.invoke({
        "value": "START",
        "steps": []
    })

    print(f"\nFinal value: {result['value']}")
    print(f"Steps taken: {result['steps']}")


# =============================================================================
# EXAMPLE 2: Conditional Edges (Routing)
# =============================================================================

def classifier(state: RouterState) -> dict:
    """Classify the input type."""
    input_lower = state["input"].lower()

    if "?" in state["input"]:
        input_type = "question"
    elif input_lower.startswith(("do", "run", "execute", "make")):
        input_type = "command"
    elif input_lower.startswith(("hi", "hello", "hey")):
        input_type = "greeting"
    else:
        input_type = "other"

    print(f"  Classified as: {input_type}")
    return {"input_type": input_type, "steps": ["classifier"]}


def handle_question(state: RouterState) -> dict:
    """Handle question inputs."""
    print("  Handling question...")
    return {"result": f"Answer to: {state['input']}", "steps": ["handle_question"]}


def handle_command(state: RouterState) -> dict:
    """Handle command inputs."""
    print("  Executing command...")
    return {"result": f"Executed: {state['input']}", "steps": ["handle_command"]}


def handle_greeting(state: RouterState) -> dict:
    """Handle greeting inputs."""
    print("  Responding to greeting...")
    return {"result": "Hello! How can I help?", "steps": ["handle_greeting"]}


def handle_other(state: RouterState) -> dict:
    """Handle other inputs."""
    print("  Default handling...")
    return {"result": f"I received: {state['input']}", "steps": ["handle_other"]}


def route_by_type(state: RouterState) -> str:
    """
    Router function for conditional edges.

    Returns the name of the next node based on state.
    """
    return state["input_type"]


def demo_conditional_edges():
    """
    Demonstrate conditional edges for routing.

    Graph structure:
        START -> classifier -> [question|command|greeting|other] -> END
    """
    print("\n" + "=" * 60)
    print("Example 2: Conditional Edges (Routing)")
    print("=" * 60)

    graph = StateGraph(RouterState)

    # Add nodes
    graph.add_node("classifier", classifier)
    graph.add_node("question", handle_question)
    graph.add_node("command", handle_command)
    graph.add_node("greeting", handle_greeting)
    graph.add_node("other", handle_other)

    # Regular edge to classifier
    graph.add_edge(START, "classifier")

    # Conditional edges from classifier
    graph.add_conditional_edges(
        "classifier",           # Source node
        route_by_type,          # Router function
        {
            "question": "question",
            "command": "command",
            "greeting": "greeting",
            "other": "other"
        }
    )

    # All handlers go to END
    graph.add_edge("question", END)
    graph.add_edge("command", END)
    graph.add_edge("greeting", END)
    graph.add_edge("other", END)

    app = graph.compile()

    # Test different inputs
    test_inputs = [
        "What is the weather?",
        "Run the tests",
        "Hello there!",
        "Random text"
    ]

    for test_input in test_inputs:
        print(f"\nInput: '{test_input}'")
        result = app.invoke({
            "input": test_input,
            "input_type": None,
            "result": None,
            "steps": []
        })
        print(f"Result: {result['result']}")
        print(f"Path: {result['steps']}")


# =============================================================================
# EXAMPLE 3: Conditional Edges with Lambda
# =============================================================================

def demo_lambda_routing():
    """
    Demonstrate conditional edges using inline lambda.
    """
    print("\n" + "=" * 60)
    print("Example 3: Conditional Edges with Lambda")
    print("=" * 60)

    graph = StateGraph(SimpleState)

    graph.add_node("start", lambda s: {
        "value": "long" if len(s["value"]) > 5 else "short",
        "steps": ["start"]
    })
    graph.add_node("long_handler", lambda s: {
        "value": f"LONG: {s['value']}",
        "steps": ["long_handler"]
    })
    graph.add_node("short_handler", lambda s: {
        "value": f"SHORT: {s['value']}",
        "steps": ["short_handler"]
    })

    graph.add_edge(START, "start")

    # Lambda router - inline routing logic
    graph.add_conditional_edges(
        "start",
        lambda state: state["value"],  # Returns "long" or "short"
        {
            "long": "long_handler",
            "short": "short_handler"
        }
    )

    graph.add_edge("long_handler", END)
    graph.add_edge("short_handler", END)

    app = graph.compile()

    # Test short input
    print("\nShort input ('Hi'):")
    result1 = app.invoke({"value": "Hi", "steps": []})
    print(f"  Result: {result1['value']}, Path: {result1['steps']}")

    # Test long input
    print("\nLong input ('Hello World'):")
    result2 = app.invoke({"value": "Hello World", "steps": []})
    print(f"  Result: {result2['value']}, Path: {result2['steps']}")


# =============================================================================
# EXAMPLE 4: Loops with Conditional Edges
# =============================================================================

def counter(state: LoopState) -> dict:
    """Increment counter and record history."""
    new_count = state["count"] + 1
    print(f"  Count: {new_count}")
    return {
        "count": new_count,
        "history": [f"iteration_{new_count}"]
    }


def should_continue(state: LoopState) -> Literal["loop", "exit"]:
    """
    Decide whether to continue looping or exit.

    Returns:
        "loop" to continue, "exit" to stop
    """
    if state["count"] < state["max_count"]:
        return "loop"
    else:
        return "exit"


def demo_loop_edges():
    """
    Demonstrate creating loops with conditional edges.

    Graph structure:
        START -> counter <--+
                    |       |
                    +-------+ (while count < max)
                    |
                    v (when count >= max)
                   END
    """
    print("\n" + "=" * 60)
    print("Example 4: Loops with Conditional Edges")
    print("=" * 60)

    graph = StateGraph(LoopState)

    graph.add_node("counter", counter)

    graph.add_edge(START, "counter")

    # Conditional edge that creates a loop
    graph.add_conditional_edges(
        "counter",
        should_continue,
        {
            "loop": "counter",  # Loop back to same node!
            "exit": END         # Exit the graph
        }
    )

    app = graph.compile()

    result = app.invoke({
        "count": 0,
        "max_count": 5,
        "history": []
    })

    print(f"\nFinal count: {result['count']}")
    print(f"History: {result['history']}")


# =============================================================================
# EXAMPLE 5: Branch and Merge Pattern
# =============================================================================

class BranchState(TypedDict):
    """State for branch and merge example."""
    input: str
    branch_a_result: Optional[str]
    branch_b_result: Optional[str]
    final_result: Optional[str]
    steps: Annotated[List[str], operator.add]


def splitter(state: BranchState) -> dict:
    """Start node that prepares for branching."""
    print("  Splitting work...")
    return {"steps": ["splitter"]}


def branch_a(state: BranchState) -> dict:
    """Process branch A."""
    print("  Processing Branch A...")
    return {
        "branch_a_result": f"A processed: {state['input'].upper()}",
        "steps": ["branch_a"]
    }


def branch_b(state: BranchState) -> dict:
    """Process branch B."""
    print("  Processing Branch B...")
    return {
        "branch_b_result": f"B processed: {state['input'][::-1]}",
        "steps": ["branch_b"]
    }


def merger(state: BranchState) -> dict:
    """Merge results from both branches."""
    print("  Merging results...")
    combined = f"Combined: {state['branch_a_result']} + {state['branch_b_result']}"
    return {
        "final_result": combined,
        "steps": ["merger"]
    }


def demo_branch_merge():
    """
    Demonstrate branch and merge pattern.

    Note: This example shows sequential branching.
    For true parallel execution, use Send API (covered in advanced topics).

    Graph structure:
        START -> splitter -> branch_a -> merger -> END
                         \-> branch_b -/
    """
    print("\n" + "=" * 60)
    print("Example 5: Branch and Merge Pattern")
    print("=" * 60)

    graph = StateGraph(BranchState)

    graph.add_node("splitter", splitter)
    graph.add_node("branch_a", branch_a)
    graph.add_node("branch_b", branch_b)
    graph.add_node("merger", merger)

    graph.add_edge(START, "splitter")

    # Branch out (sequential in this basic example)
    graph.add_edge("splitter", "branch_a")
    graph.add_edge("branch_a", "branch_b")  # Sequential for now

    # Merge
    graph.add_edge("branch_b", "merger")
    graph.add_edge("merger", END)

    app = graph.compile()

    result = app.invoke({
        "input": "Hello",
        "branch_a_result": None,
        "branch_b_result": None,
        "final_result": None,
        "steps": []
    })

    print(f"\nBranch A result: {result['branch_a_result']}")
    print(f"Branch B result: {result['branch_b_result']}")
    print(f"Final result: {result['final_result']}")
    print(f"Execution path: {result['steps']}")


# =============================================================================
# EXAMPLE 6: Multiple Conditional Edges from One Node
# =============================================================================

class MultiRouteState(TypedDict):
    """State for multi-route example."""
    score: int
    grade: Optional[str]
    message: Optional[str]


def calculate_grade(state: MultiRouteState) -> dict:
    """Calculate grade from score."""
    score = state["score"]
    if score >= 90:
        grade = "A"
    elif score >= 80:
        grade = "B"
    elif score >= 70:
        grade = "C"
    elif score >= 60:
        grade = "D"
    else:
        grade = "F"
    return {"grade": grade}


def route_by_grade(state: MultiRouteState) -> str:
    """Route based on grade."""
    return state["grade"]


def excellent(state: MultiRouteState) -> dict:
    return {"message": "Excellent work!"}


def good(state: MultiRouteState) -> dict:
    return {"message": "Good job!"}


def average(state: MultiRouteState) -> dict:
    return {"message": "Keep improving!"}


def needs_work(state: MultiRouteState) -> dict:
    return {"message": "Let's work harder!"}


def demo_multi_route():
    """Demonstrate routing to multiple destinations."""
    print("\n" + "=" * 60)
    print("Example 6: Multiple Route Destinations")
    print("=" * 60)

    graph = StateGraph(MultiRouteState)

    graph.add_node("grader", calculate_grade)
    graph.add_node("excellent", excellent)
    graph.add_node("good", good)
    graph.add_node("average", average)
    graph.add_node("needs_work", needs_work)

    graph.add_edge(START, "grader")

    graph.add_conditional_edges(
        "grader",
        route_by_grade,
        {
            "A": "excellent",
            "B": "good",
            "C": "average",
            "D": "needs_work",
            "F": "needs_work"  # Multiple values can route to same node
        }
    )

    # All feedback nodes go to END
    for node in ["excellent", "good", "average", "needs_work"]:
        graph.add_edge(node, END)

    app = graph.compile()

    # Test different scores
    for score in [95, 82, 75, 55]:
        result = app.invoke({
            "score": score,
            "grade": None,
            "message": None
        })
        print(f"Score: {score} -> Grade: {result['grade']}, Message: {result['message']}")


# =============================================================================
# RUN ALL DEMOS
# =============================================================================

if __name__ == "__main__":
    demo_regular_edges()
    demo_conditional_edges()
    demo_lambda_routing()
    demo_loop_edges()
    demo_branch_merge()
    demo_multi_route()

    print("\n" + "=" * 60)
    print("All edge examples completed!")
    print("=" * 60)
