"""
State Definition Examples
==========================

This file shows different ways to define state in LangGraph,
from simple to complex use cases.
"""

from typing import TypedDict, Annotated, Optional, List, Dict, Any, Union
from pydantic import BaseModel, Field
import operator


# =============================================================================
# EXAMPLE 1: Simple TypedDict State
# =============================================================================

class SimpleState(TypedDict):
    """
    The simplest form of state - just field definitions.
    No reducers, no defaults.
    """
    input_text: str
    output_text: str
    is_processed: bool


def demo_simple_state():
    """Show how SimpleState works."""
    print("=" * 50)
    print("Example 1: Simple TypedDict State")
    print("=" * 50)

    # Creating state
    state: SimpleState = {
        "input_text": "Hello, world!",
        "output_text": "",
        "is_processed": False
    }

    print(f"Initial state: {state}")

    # Simulating a node update (overwrites the field)
    node_output = {"output_text": "HELLO, WORLD!", "is_processed": True}
    state = {**state, **node_output}  # Merge update

    print(f"After update: {state}")


# =============================================================================
# EXAMPLE 2: State with Reducers
# =============================================================================

class MessageState(TypedDict):
    """
    State with reducer for message accumulation.

    The Annotated type with operator.add means:
    - When a node returns {"messages": ["new"]},
    - It ADDS to existing list, not replaces
    """
    messages: Annotated[List[str], operator.add]
    current_speaker: str


def demo_reducer_state():
    """Demonstrate how reducers work."""
    print("\n" + "=" * 50)
    print("Example 2: State with Reducers")
    print("=" * 50)

    # Initial state
    state = {
        "messages": ["Hello!"],
        "current_speaker": "User"
    }
    print(f"Initial: {state}")

    # Simulating node updates
    # With reducer: messages accumulate
    # Without reducer: current_speaker overwrites

    update1 = {"messages": ["Hi there!"], "current_speaker": "Assistant"}
    # Reducer applies: messages = ["Hello!"] + ["Hi there!"]
    state["messages"] = state["messages"] + update1["messages"]
    state["current_speaker"] = update1["current_speaker"]

    print(f"After update 1: {state}")

    update2 = {"messages": ["How can I help?"]}
    state["messages"] = state["messages"] + update2["messages"]

    print(f"After update 2: {state}")
    print(f"Total messages: {len(state['messages'])}")


# =============================================================================
# EXAMPLE 3: Complex State with Multiple Reducers
# =============================================================================

def merge_metadata(existing: Dict, new: Dict) -> Dict:
    """Custom reducer to merge dictionaries."""
    return {**existing, **new}


class AgentState(TypedDict):
    """
    Complex agent state with multiple reducers.
    """
    # Accumulates conversation
    messages: Annotated[List[Dict[str, str]], operator.add]

    # Accumulates list of used tools
    tools_used: Annotated[List[str], operator.add]

    # Sums up token usage
    total_tokens: Annotated[int, operator.add]

    # Overwrites (no reducer)
    current_step: str

    # Will be None until set
    final_answer: Optional[str]


def demo_complex_state():
    """Demonstrate complex state with multiple reducers."""
    print("\n" + "=" * 50)
    print("Example 3: Complex Agent State")
    print("=" * 50)

    state = {
        "messages": [],
        "tools_used": [],
        "total_tokens": 0,
        "current_step": "init",
        "final_answer": None
    }

    print(f"Initial state: {state}")

    # Simulate multiple node updates
    updates = [
        {
            "messages": [{"role": "user", "content": "What's 2+2?"}],
            "current_step": "received_input",
            "total_tokens": 10
        },
        {
            "messages": [{"role": "assistant", "content": "Let me calculate..."}],
            "tools_used": ["calculator"],
            "current_step": "using_tool",
            "total_tokens": 15
        },
        {
            "messages": [{"role": "assistant", "content": "2+2 = 4"}],
            "current_step": "completed",
            "total_tokens": 8,
            "final_answer": "4"
        }
    ]

    for i, update in enumerate(updates, 1):
        # Apply reducers manually (LangGraph does this automatically)
        if "messages" in update:
            state["messages"] = state["messages"] + update["messages"]
        if "tools_used" in update:
            state["tools_used"] = state["tools_used"] + update["tools_used"]
        if "total_tokens" in update:
            state["total_tokens"] = state["total_tokens"] + update["total_tokens"]
        if "current_step" in update:
            state["current_step"] = update["current_step"]
        if "final_answer" in update:
            state["final_answer"] = update["final_answer"]

        print(f"\nAfter update {i}:")
        print(f"  Messages: {len(state['messages'])}")
        print(f"  Tools used: {state['tools_used']}")
        print(f"  Total tokens: {state['total_tokens']}")
        print(f"  Current step: {state['current_step']}")


# =============================================================================
# EXAMPLE 4: Pydantic State (With Validation)
# =============================================================================

class PydanticChatState(BaseModel):
    """
    State using Pydantic for validation.

    Benefits:
    - Default values
    - Type validation
    - Constraints
    - Easy serialization
    """
    messages: List[Dict[str, str]] = Field(default_factory=list)
    user_name: str = Field(min_length=1, max_length=100)
    temperature: float = Field(default=0.7, ge=0.0, le=2.0)
    max_tokens: int = Field(default=1000, gt=0)

    class Config:
        extra = "forbid"  # Don't allow extra fields


def demo_pydantic_state():
    """Demonstrate Pydantic state with validation."""
    print("\n" + "=" * 50)
    print("Example 4: Pydantic State with Validation")
    print("=" * 50)

    # Valid state
    state = PydanticChatState(
        user_name="Alice",
        temperature=0.9
    )
    print(f"Valid state: {state.model_dump()}")

    # Try invalid state
    print("\nTrying invalid states:")

    try:
        invalid = PydanticChatState(user_name="")  # Too short!
        print(f"Invalid: {invalid}")
    except Exception as e:
        print(f"  Empty user_name: REJECTED - {type(e).__name__}")

    try:
        invalid = PydanticChatState(user_name="Bob", temperature=5.0)  # Too high!
        print(f"Invalid: {invalid}")
    except Exception as e:
        print(f"  temperature=5.0: REJECTED - {type(e).__name__}")


# =============================================================================
# EXAMPLE 5: Nested State
# =============================================================================

class ToolResult(TypedDict):
    """Result from a tool execution."""
    tool_name: str
    success: bool
    output: Any


class ConversationMessage(TypedDict):
    """A single message in the conversation."""
    role: str  # "user", "assistant", "system"
    content: str
    timestamp: Optional[str]


class NestedAgentState(TypedDict):
    """
    State with nested structures.

    This shows how to organize complex state with
    multiple levels of nesting.
    """
    # Nested list of message objects
    conversation: Annotated[List[ConversationMessage], operator.add]

    # Nested list of tool results
    tool_history: Annotated[List[ToolResult], operator.add]

    # Nested config object
    config: Dict[str, Any]

    # Current status
    status: str


def demo_nested_state():
    """Demonstrate nested state structures."""
    print("\n" + "=" * 50)
    print("Example 5: Nested State Structures")
    print("=" * 50)

    state: NestedAgentState = {
        "conversation": [
            {
                "role": "system",
                "content": "You are a helpful assistant.",
                "timestamp": "2024-01-01T10:00:00"
            }
        ],
        "tool_history": [],
        "config": {
            "model": "gpt-4",
            "temperature": 0.7,
            "tools_enabled": ["search", "calculator"]
        },
        "status": "ready"
    }

    print("Initial state structure:")
    print(f"  Conversation messages: {len(state['conversation'])}")
    print(f"  Config keys: {list(state['config'].keys())}")

    # Add a user message
    new_message: ConversationMessage = {
        "role": "user",
        "content": "Search for Python tutorials",
        "timestamp": "2024-01-01T10:01:00"
    }
    state["conversation"] = state["conversation"] + [new_message]

    # Add a tool result
    tool_result: ToolResult = {
        "tool_name": "search",
        "success": True,
        "output": ["result1", "result2"]
    }
    state["tool_history"] = state["tool_history"] + [tool_result]

    print("\nAfter updates:")
    print(f"  Conversation messages: {len(state['conversation'])}")
    print(f"  Tool history entries: {len(state['tool_history'])}")


# =============================================================================
# EXAMPLE 6: State for Conditional Routing
# =============================================================================

class RouterState(TypedDict):
    """
    State designed for conditional edge routing.

    The 'next_action' field is commonly used to determine
    which node to route to next.
    """
    input: str
    classification: Optional[str]  # "question", "command", "chat"
    next_action: str  # Used for routing: "search", "execute", "respond"
    response: Optional[str]


def demo_router_state():
    """Show state designed for routing."""
    print("\n" + "=" * 50)
    print("Example 6: State for Conditional Routing")
    print("=" * 50)

    state: RouterState = {
        "input": "What is the weather?",
        "classification": None,
        "next_action": "classify",
        "response": None
    }

    print(f"Initial: next_action = '{state['next_action']}'")

    # Classifier node sets classification and next_action
    state["classification"] = "question"
    state["next_action"] = "search"  # Route to search node

    print(f"After classify: next_action = '{state['next_action']}'")
    print(f"  -> Will route to: {state['next_action']} node")


# =============================================================================
# RUN ALL EXAMPLES
# =============================================================================

if __name__ == "__main__":
    demo_simple_state()
    demo_reducer_state()
    demo_complex_state()
    demo_pydantic_state()
    demo_nested_state()
    demo_router_state()

    print("\n" + "=" * 50)
    print("All examples completed!")
    print("=" * 50)
