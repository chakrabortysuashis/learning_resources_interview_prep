"""
StateGraph Example - Building Your First Graph
================================================

This file demonstrates how to create a simple StateGraph
with multiple nodes and edges.

We'll build a simple text processing pipeline:
    START → analyze → transform → summarize → END
"""

from typing import TypedDict, Annotated
from langgraph.graph import StateGraph, START, END
import operator


# =============================================================================
# STEP 1: Define the State
# =============================================================================
# The state is a TypedDict that defines what data flows through our graph.
# Every node will receive this state and can read/modify it.

class TextProcessingState(TypedDict):
    """
    State for our text processing pipeline.

    Attributes:
        original_text: The input text to process
        word_count: Number of words in the text
        transformed_text: Text after transformation
        summary: Final summary of the text
        steps_completed: List of completed processing steps
    """
    original_text: str
    word_count: int
    transformed_text: str
    summary: str
    steps_completed: Annotated[list[str], operator.add]  # This uses a reducer!


# =============================================================================
# STEP 2: Define Node Functions
# =============================================================================
# Each node is a function that:
#   - Takes the current state as input
#   - Returns a dict with state updates

def analyze_text(state: TextProcessingState) -> dict:
    """
    Node 1: Analyze the input text.

    This node counts words and performs basic analysis.
    """
    print("📊 Analyzing text...")

    text = state["original_text"]
    word_count = len(text.split())

    # Return only the fields we want to update
    return {
        "word_count": word_count,
        "steps_completed": ["analyze"]  # This will be ADDED to the list (reducer)
    }


def transform_text(state: TextProcessingState) -> dict:
    """
    Node 2: Transform the text.

    This node converts text to uppercase and adds formatting.
    """
    print("🔄 Transforming text...")

    text = state["original_text"]
    transformed = text.upper()

    return {
        "transformed_text": f"[TRANSFORMED] {transformed}",
        "steps_completed": ["transform"]
    }


def summarize_text(state: TextProcessingState) -> dict:
    """
    Node 3: Summarize the processing.

    This node creates a summary of what was done.
    """
    print("📝 Creating summary...")

    summary = (
        f"Processed text with {state['word_count']} words. "
        f"Steps completed: {', '.join(state['steps_completed'])}"
    )

    return {
        "summary": summary,
        "steps_completed": ["summarize"]
    }


# =============================================================================
# STEP 3: Build the Graph
# =============================================================================

def create_text_processing_graph():
    """
    Create and return the compiled graph.

    Graph Structure:

        START
          │
          ▼
      ┌────────┐
      │analyze │
      └────┬───┘
           │
           ▼
      ┌──────────┐
      │transform │
      └────┬─────┘
           │
           ▼
      ┌──────────┐
      │summarize │
      └────┬─────┘
           │
           ▼
          END
    """

    # Create the graph with our state type
    graph = StateGraph(TextProcessingState)

    # Add nodes
    # The first argument is the node name (string)
    # The second argument is the function to execute
    graph.add_node("analyze", analyze_text)
    graph.add_node("transform", transform_text)
    graph.add_node("summarize", summarize_text)

    # Add edges to define the flow
    # START is a special constant representing the entry point
    graph.add_edge(START, "analyze")
    graph.add_edge("analyze", "transform")
    graph.add_edge("transform", "summarize")
    graph.add_edge("summarize", END)  # END is the exit point

    # Compile the graph into a runnable application
    # This validates the graph and creates the execution engine
    app = graph.compile()

    return app


# =============================================================================
# STEP 4: Run the Graph
# =============================================================================

def main():
    """
    Main function to demonstrate the graph execution.
    """
    print("=" * 60)
    print("StateGraph Example: Text Processing Pipeline")
    print("=" * 60)

    # Create the compiled graph
    app = create_text_processing_graph()

    # Define initial state
    # We must provide values for fields that nodes will read
    initial_state = {
        "original_text": "Hello world! This is a simple example of LangGraph.",
        "word_count": 0,
        "transformed_text": "",
        "summary": "",
        "steps_completed": []  # Start with empty list
    }

    print("\n📥 Input State:")
    print(f"   Text: {initial_state['original_text']}")
    print()

    # Invoke the graph
    # This runs all nodes in sequence and returns the final state
    result = app.invoke(initial_state)

    print()
    print("📤 Final State:")
    print(f"   Word Count: {result['word_count']}")
    print(f"   Transformed: {result['transformed_text']}")
    print(f"   Summary: {result['summary']}")
    print(f"   Steps: {result['steps_completed']}")


# =============================================================================
# ALTERNATIVE: Using Stream Instead of Invoke
# =============================================================================

def main_with_streaming():
    """
    Demonstrate streaming execution to see each step.
    """
    print("\n" + "=" * 60)
    print("Streaming Execution Example")
    print("=" * 60)

    app = create_text_processing_graph()

    initial_state = {
        "original_text": "LangGraph makes building agents easy!",
        "word_count": 0,
        "transformed_text": "",
        "summary": "",
        "steps_completed": []
    }

    print("\n🔄 Streaming through nodes...\n")

    # Stream returns an iterator of (node_name, state) tuples
    for step_output in app.stream(initial_state):
        # step_output is a dict with node name as key
        for node_name, node_output in step_output.items():
            print(f"✅ Node '{node_name}' completed")
            print(f"   Output: {node_output}")
            print()


# =============================================================================
# EXERCISE: Try Modifying This Graph
# =============================================================================
"""
📝 Exercise 1: Add a new node

   Add a "validate" node between START and "analyze" that checks
   if the text is not empty.

📝 Exercise 2: Add error handling

   What happens if original_text is None? Add handling for this.

📝 Exercise 3: Make it async

   Convert the node functions to async and use ainvoke().
"""


if __name__ == "__main__":
    main()
    main_with_streaming()
