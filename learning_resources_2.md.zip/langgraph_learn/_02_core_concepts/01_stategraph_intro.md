# StateGraph Introduction

```
╔═══════════════════════════════════════════════════════════════════════════╗
║                           STATEGRAPH                                       ║
║                    The Heart of LangGraph                                  ║
╚═══════════════════════════════════════════════════════════════════════════╝
```

## What is StateGraph?

**StateGraph** is the core class in LangGraph that allows you to build stateful, multi-step applications. Think of it as a blueprint for creating workflows where:

1. **State** flows through the graph
2. **Nodes** process and transform the state
3. **Edges** define the path between nodes

---

## Visual Representation

```
                    ┌─────────────────────────────────────────┐
                    │              StateGraph                 │
                    │                                         │
                    │   ┌─────────┐       ┌─────────┐        │
                    │   │  Node A │──────▶│  Node B │        │
                    │   └─────────┘       └─────────┘        │
                    │        │                 │              │
                    │        │     STATE       │              │
                    │        │   ┌───────┐     │              │
                    │        └──▶│ data  │◀────┘              │
                    │            └───────┘                    │
                    │                                         │
                    └─────────────────────────────────────────┘
```

---

## Key Characteristics

| Feature | Description |
|---------|-------------|
| **Stateful** | Maintains state across all nodes |
| **Directed** | Edges have direction (A → B) |
| **Cyclic** | Can have loops (unlike simple chains) |
| **Compilable** | Must be compiled before execution |

---

## Basic Structure

```python
from langgraph.graph import StateGraph, START, END
from typing import TypedDict

# 1. Define your state structure
class MyState(TypedDict):
    messages: list
    current_step: str

# 2. Create the graph with state type
graph = StateGraph(MyState)

# 3. Add nodes (functions that process state)
graph.add_node("step1", my_function)
graph.add_node("step2", another_function)

# 4. Add edges (connections between nodes)
graph.add_edge(START, "step1")
graph.add_edge("step1", "step2")
graph.add_edge("step2", END)

# 5. Compile the graph
app = graph.compile()

# 6. Run the graph
result = app.invoke({"messages": [], "current_step": ""})
```

---

## The Graph Lifecycle

```
    ┌──────────────────────────────────────────────────────────────┐
    │                      GRAPH LIFECYCLE                          │
    └──────────────────────────────────────────────────────────────┘
    
    ┌─────────┐    ┌─────────┐    ┌─────────┐    ┌─────────┐    ┌─────────┐
    │ Define  │───▶│   Add   │───▶│   Add   │───▶│ Compile │───▶│  Invoke │
    │  State  │    │  Nodes  │    │  Edges  │    │  Graph  │    │   App   │
    └─────────┘    └─────────┘    └─────────┘    └─────────┘    └─────────┘
         │              │              │              │              │
         ▼              ▼              ▼              ▼              ▼
    TypedDict/     Functions      START/END      Returns        Execute
    Pydantic       that take      + routing      compiled       with
    schema         state          logic          app            initial state
```

---

## StateGraph vs Regular Function Chains

```
    REGULAR CHAIN (Linear)              STATEGRAPH (Flexible)
    ─────────────────────               ──────────────────────
    
    ┌───┐   ┌───┐   ┌───┐              ┌───┐───────────┐
    │ A │──▶│ B │──▶│ C │              │ A │           │
    └───┘   └───┘   └───┘              └─┬─┘           │
                                         │             │
    Only forward, no                   ┌─▼─┐   ┌───┐   │
    branching or loops                 │ B │──▶│ D │   │
                                       └─┬─┘   └───┘   │
                                         │             │
                                       ┌─▼─┐           │
                                       │ C │───────────┘
                                       └───┘
                                       
                                       Branching, loops,
                                       conditional routing
```

---

## Why Use StateGraph?

### ✅ Use StateGraph When:

1. **You need loops** - Agent that retries until success
2. **You need branching** - Route to different handlers based on input
3. **You need state persistence** - Maintain conversation history
4. **You need human-in-the-loop** - Pause for user input
5. **You need complex workflows** - Multi-step processes with dependencies

### ❌ Don't Use StateGraph When:

1. Simple linear chain is sufficient
2. No state needs to be maintained
3. Single LLM call with no routing

---

## 📌 Interview Tip

> **Common Question**: "What's the difference between StateGraph and a simple LangChain chain?"
>
> **Answer**: StateGraph provides:
> - **Cycles/loops** - Chains are strictly linear
> - **Conditional branching** - Route to different nodes based on state
> - **Built-in state management** - Automatic state passing between nodes
> - **Checkpointing** - Save and resume from any point
> - **Human-in-the-loop** - Pause execution for human input
>
> Use chains for simple sequential operations; use StateGraph for complex, stateful workflows.

---

## State Flow Visualization

```
    Initial State                    After Node A                 After Node B
    ─────────────                    ────────────                 ────────────
    
    ┌─────────────┐                 ┌─────────────┐              ┌─────────────┐
    │ messages: []│      Node A     │ messages:   │    Node B    │ messages:   │
    │ step: ""    │ ───────────────▶│   ["Hi"]    │ ────────────▶│   ["Hi",    │
    │             │  Adds message   │ step: "A"   │ Adds reply   │    "Hello"] │
    └─────────────┘                 └─────────────┘              │ step: "B"   │
                                                                 └─────────────┘
    
    State is passed through and modified by each node
```

---

## Key Methods

| Method | Purpose | Example |
|--------|---------|---------|
| `add_node(name, fn)` | Add a processing node | `graph.add_node("chat", chat_fn)` |
| `add_edge(a, b)` | Connect two nodes | `graph.add_edge("a", "b")` |
| `add_conditional_edges(a, fn, map)` | Conditional routing | Route based on state |
| `compile()` | Create runnable app | `app = graph.compile()` |
| `invoke(state)` | Run synchronously | `app.invoke({"msg": []})` |
| `ainvoke(state)` | Run asynchronously | `await app.ainvoke({})` |
| `stream(state)` | Stream execution | `for s in app.stream({})` |

---

## Next Steps

Now that you understand what StateGraph is, let's:
1. See a working example → `02_stategraph_example.py`
2. Learn about defining state → `03_defining_state.md`
