# Edges in LangGraph

```
╔═══════════════════════════════════════════════════════════════════════════╗
║                              EDGES                                         ║
║                   Connecting the Dots in Your Graph                        ║
╚═══════════════════════════════════════════════════════════════════════════╝
```

## What are Edges?

**Edges** define the connections between nodes. They determine:
- **Flow direction**: Which node executes next
- **Routing logic**: Conditional paths based on state

---

## Two Types of Edges

```
    ┌────────────────────────────────────────────────────────────────────┐
    │                        EDGE TYPES                                   │
    ├────────────────────────────────────────────────────────────────────┤
    │                                                                    │
    │   ┌──────────────────────┐      ┌──────────────────────┐          │
    │   │    Regular Edges     │      │   Conditional Edges  │          │
    │   │                      │      │                      │          │
    │   │    A ────────▶ B     │      │    A ────?───▶ B     │          │
    │   │                      │      │        └───▶ C       │          │
    │   │   Always goes A→B    │      │   Routes based on    │          │
    │   │                      │      │   state or function  │          │
    │   └──────────────────────┘      └──────────────────────┘          │
    │                                                                    │
    └────────────────────────────────────────────────────────────────────┘
```

---

## Regular Edges

Simple, unconditional connections between nodes.

```python
# Syntax
graph.add_edge(source_node, target_node)

# Examples
graph.add_edge(START, "process")      # Entry point
graph.add_edge("process", "analyze")  # Node to node
graph.add_edge("analyze", END)        # Exit point
```

### Visual

```
    START ──────▶ process ──────▶ analyze ──────▶ END
    
    Always follows the same path, no branching.
```

---

## Conditional Edges

Route to different nodes based on state or logic.

### Method 1: Using a Router Function

```python
def route_based_on_type(state: MyState) -> str:
    """
    Router function that returns the name of the next node.
    """
    if state["type"] == "question":
        return "answer_question"
    elif state["type"] == "command":
        return "execute_command"
    else:
        return "default_handler"

# Add conditional edge
graph.add_conditional_edges(
    "classifier",           # Source node
    route_based_on_type,    # Router function
    {
        # Mapping of return values to node names
        "answer_question": "answer_question",
        "execute_command": "execute_command",
        "default_handler": "default_handler"
    }
)
```

### Visual

```
                                    ┌──────────────────┐
                              ┌────▶│ answer_question  │
                              │     └──────────────────┘
                              │
    ┌────────────┐     ┌──────┴─────┐
    │ classifier │────▶│   ROUTER   │
    └────────────┘     └──────┬─────┘
                              │     ┌──────────────────┐
                              ├────▶│ execute_command  │
                              │     └──────────────────┘
                              │
                              │     ┌──────────────────┐
                              └────▶│ default_handler  │
                                    └──────────────────┘
```

---

## Method 2: Direct State Field Routing

Route based on a state field value without a function.

```python
# State has a field "next_node" that contains the target node name
graph.add_conditional_edges(
    "decision_node",
    lambda state: state["next_node"],  # Read from state
    {
        "search": "search_node",
        "calculate": "calc_node",
        "respond": "response_node"
    }
)
```

---

## Special Edge Targets

| Target | Meaning |
|--------|---------|
| `START` | Entry point (can only be source) |
| `END` | Exit point (terminates graph) |
| Node name | Any defined node |

```python
from langgraph.graph import START, END

# START can only be a source
graph.add_edge(START, "first_node")  # ✅ Correct
# graph.add_edge("node", START)      # ❌ Invalid

# END can only be a target
graph.add_edge("last_node", END)     # ✅ Correct
# graph.add_edge(END, "node")        # ❌ Invalid
```

---

## Conditional Edges with END

Route to END conditionally to stop execution.

```python
def should_continue(state: MyState) -> str:
    """Decide whether to continue or stop."""
    if state["is_complete"]:
        return "end"
    else:
        return "continue"

graph.add_conditional_edges(
    "check_status",
    should_continue,
    {
        "continue": "process_more",
        "end": END  # Special: routes to END
    }
)
```

### Visual

```
                          ┌──────────────┐
                     ┌───▶│ process_more │───┐
                     │    └──────────────┘   │
                     │                       │
    ┌──────────────┐ │                       │
    │ check_status │─┤                       │
    └──────────────┘ │                       │
                     │    ┌──────┐           │
                     └───▶│ END  │           │
                          └──────┘           │
                     ▲                       │
                     └───────────────────────┘
                         (Loop back)
```

---

## Creating Loops with Edges

Loops are created when edges form a cycle.

```python
def should_loop(state: MyState) -> str:
    """Decide whether to loop or exit."""
    if state["iteration"] < state["max_iterations"]:
        return "continue"
    return "done"

# Build a loop
graph.add_edge(START, "process")
graph.add_conditional_edges(
    "process",
    should_loop,
    {
        "continue": "process",  # Loop back to self!
        "done": END
    }
)
```

### Visual

```
                    ┌──────────────┐
                    │              │
                    ▼              │
    START ────▶ process ──────────┘
                    │
                    │ (when done)
                    ▼
                   END
```

---

## Edge Patterns

### Pattern 1: Linear Pipeline

```python
graph.add_edge(START, "step1")
graph.add_edge("step1", "step2")
graph.add_edge("step2", "step3")
graph.add_edge("step3", END)
```

```
    START ──▶ step1 ──▶ step2 ──▶ step3 ──▶ END
```

### Pattern 2: Branch and Merge

```python
graph.add_edge(START, "classifier")
graph.add_conditional_edges("classifier", route_fn, {...})
# Multiple branches merge at "finalizer"
graph.add_edge("branch_a", "finalizer")
graph.add_edge("branch_b", "finalizer")
graph.add_edge("branch_c", "finalizer")
graph.add_edge("finalizer", END)
```

```
                   ┌─▶ branch_a ─┐
                   │             │
    START ──▶ classifier ──▶ branch_b ─┼──▶ finalizer ──▶ END
                   │             │
                   └─▶ branch_c ─┘
```

### Pattern 3: Agent Loop

```python
graph.add_edge(START, "agent")
graph.add_conditional_edges("agent", should_continue, {
    "tool": "tools",
    "end": END
})
graph.add_edge("tools", "agent")  # Loop back
```

```
    START ──▶ agent ◀───┐
                │       │
                ▼       │
              tools ────┘
                │
                ▼ (when done)
               END
```

---

## 📌 Interview Tip

> **Common Question**: "How do conditional edges differ from if/else in a node?"
>
> **Answer**: 
>
> | Aspect | Conditional Edges | If/Else in Node |
> |--------|-------------------|-----------------|
> | **Purpose** | Route to different NODES | Different logic in SAME node |
> | **Visibility** | Clear in graph visualization | Hidden inside node |
> | **Reusability** | Separates routing from logic | Coupled |
> | **Debugging** | Easy to trace path | Harder to follow |
>
> **Best Practice**: Use conditional edges for routing between different processing paths. Use if/else within nodes for minor logic variations.

---

## Common Mistakes

### ❌ Missing Edge to END

```python
# Bad: No path to END
graph.add_edge(START, "process")
graph.add_edge("process", "analyze")
# Graph will hang! No way to finish
```

### ❌ Unreachable Nodes

```python
# Bad: "orphan" node is never reached
graph.add_node("orphan", orphan_fn)
graph.add_edge(START, "main")
graph.add_edge("main", END)
# "orphan" has no incoming edge
```

### ❌ Missing Conditional Route

```python
# Bad: Router might return value not in mapping
def router(state):
    return state["type"]  # Could be "unknown"!

graph.add_conditional_edges("node", router, {
    "a": "node_a",
    "b": "node_b"
    # What if type is "c"? Error!
})
```

### ✅ Fix: Always Include Default

```python
graph.add_conditional_edges("node", router, {
    "a": "node_a",
    "b": "node_b",
    "__default__": "fallback_node"  # Catch-all
})
```

---

## Next Steps

- See edge examples in code → `08_edges_example.py`
- Learn about START and END → `09_start_end_nodes.md`
