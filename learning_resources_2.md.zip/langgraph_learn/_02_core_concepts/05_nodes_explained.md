# Nodes in LangGraph

```
╔═══════════════════════════════════════════════════════════════════════════╗
║                              NODES                                         ║
║                    The Workers of Your Graph                               ║
╚═══════════════════════════════════════════════════════════════════════════╝
```

## What is a Node?

A **node** is a function that:
1. Receives the current state
2. Performs some operation
3. Returns state updates

Think of nodes as **workers** in an assembly line, each doing a specific job.

---

## Visual Representation

```
                        ┌─────────────────────────┐
                        │         NODE            │
                        │                         │
         State In       │   ┌─────────────────┐   │      State Out
    ──────────────────▶ │   │    Function     │   │ ──────────────────▶
    {messages: [...]}   │   │                 │   │   {messages: [...],
                        │   │  • Read state   │   │    new_field: ...}
                        │   │  • Do work      │   │
                        │   │  • Return dict  │   │
                        │   └─────────────────┘   │
                        │                         │
                        └─────────────────────────┘
```

---

## Node Function Anatomy

```python
def my_node(state: MyState) -> dict:
    """
    A node function.
    
    Args:
        state: The current graph state (read-only access to all fields)
    
    Returns:
        dict: Only the fields to update (not the full state!)
    """
    # 1. Read from state
    current_value = state["some_field"]
    
    # 2. Do some processing
    new_value = process(current_value)
    
    # 3. Return updates only
    return {"some_field": new_value}
```

---

## Types of Nodes

```
    ┌────────────────────────────────────────────────────────────────────┐
    │                        NODE TYPES                                   │
    ├────────────────────────────────────────────────────────────────────┤
    │                                                                    │
    │   ┌──────────────┐   ┌──────────────┐   ┌──────────────┐          │
    │   │   Regular    │   │    Async     │   │    Class     │          │
    │   │   Function   │   │   Function   │   │    Based     │          │
    │   └──────────────┘   └──────────────┘   └──────────────┘          │
    │                                                                    │
    │   def node(s):       async def node(s):  class MyNode:            │
    │     return {...}       return {...}        def __call__(s):       │
    │                                              return {...}         │
    │                                                                    │
    └────────────────────────────────────────────────────────────────────┘
```

---

## Example: Different Node Types

### 1. Regular Function Node

```python
def greet_node(state: ChatState) -> dict:
    """Simple greeting node."""
    user_name = state.get("user_name", "User")
    return {
        "messages": [f"Hello, {user_name}!"]
    }
```

### 2. Async Function Node

```python
async def fetch_data_node(state: DataState) -> dict:
    """Async node for external API calls."""
    async with aiohttp.ClientSession() as session:
        async with session.get(state["url"]) as response:
            data = await response.json()
    return {"fetched_data": data}
```

### 3. Class-Based Node

```python
class LLMNode:
    """Node that uses an LLM."""
    
    def __init__(self, model_name: str):
        self.llm = ChatOpenAI(model=model_name)
    
    def __call__(self, state: ChatState) -> dict:
        response = self.llm.invoke(state["messages"])
        return {"messages": [response]}

# Usage
llm_node = LLMNode("gpt-4")
graph.add_node("chat", llm_node)
```

---

## Adding Nodes to Graph

```python
from langgraph.graph import StateGraph

# Create graph
graph = StateGraph(MyState)

# Method 1: Add with function reference
graph.add_node("process", process_function)

# Method 2: Add with lambda
graph.add_node("simple", lambda state: {"done": True})

# Method 3: Add class instance
graph.add_node("llm", LLMNode("gpt-4"))
```

---

## Node Execution Flow

```
    ┌─────────────────────────────────────────────────────────────────────┐
    │                      NODE EXECUTION FLOW                             │
    └─────────────────────────────────────────────────────────────────────┘
    
    1. Node Receives State
       ┌─────────────────────────────────┐
       │ {                               │
       │   messages: ["Hello"],          │
       │   count: 5,                     │
       │   done: false                   │
       │ }                               │
       └─────────────────────────────────┘
                      │
                      ▼
    2. Node Processes
       ┌─────────────────────────────────┐
       │ def my_node(state):             │
       │     # Read state                │
       │     msgs = state["messages"]    │
       │     # Process                   │
       │     new_msg = "Processed!"      │
       │     # Return updates            │
       │     return {                    │
       │       "messages": [new_msg],    │
       │       "done": true              │
       │     }                           │
       └─────────────────────────────────┘
                      │
                      ▼
    3. State is Updated (merged)
       ┌─────────────────────────────────┐
       │ {                               │
       │   messages: ["Hello",           │
       │              "Processed!"],     │ ← Added (reducer)
       │   count: 5,                     │ ← Unchanged
       │   done: true                    │ ← Updated
       │ }                               │
       └─────────────────────────────────┘
```

---

## Common Node Patterns

### Pattern 1: LLM Call Node

```python
from langchain_openai import ChatOpenAI

def llm_node(state: ChatState) -> dict:
    """Call an LLM with the conversation."""
    llm = ChatOpenAI(model="gpt-4")
    messages = state["messages"]
    response = llm.invoke(messages)
    return {"messages": [response]}
```

### Pattern 2: Tool Execution Node

```python
def tool_node(state: AgentState) -> dict:
    """Execute tools based on LLM decision."""
    tool_calls = state["pending_tools"]
    results = []
    
    for tool_call in tool_calls:
        result = execute_tool(tool_call)
        results.append(result)
    
    return {
        "tool_results": results,
        "pending_tools": []  # Clear pending
    }
```

### Pattern 3: Routing Decision Node

```python
def router_node(state: RouterState) -> dict:
    """Decide next action based on input."""
    user_input = state["input"].lower()
    
    if "search" in user_input:
        next_action = "search"
    elif "calculate" in user_input:
        next_action = "calculate"
    else:
        next_action = "respond"
    
    return {"next_action": next_action}
```

### Pattern 4: Validation Node

```python
def validate_node(state: FormState) -> dict:
    """Validate user input."""
    errors = []
    
    if not state.get("email"):
        errors.append("Email is required")
    if not state.get("name"):
        errors.append("Name is required")
    
    return {
        "validation_errors": errors,
        "is_valid": len(errors) == 0
    }
```

---

## 📌 Interview Tip

> **Common Question**: "What should a node function return?"
>
> **Answer**: A node should return a **dictionary** containing **only the fields it wants to update**. Key points:
>
> 1. **Don't return the full state** - Only return changed fields
> 2. **Reducers apply automatically** - For annotated fields
> 3. **Return empty dict if no changes** - `return {}`
> 4. **Can return None** - Equivalent to empty dict
>
> ```python
> # ✅ Good: Only return what changed
> def node(state):
>     return {"count": state["count"] + 1}
>
> # ❌ Bad: Don't return full state
> def node(state):
>     state["count"] += 1
>     return state  # Wrong!
> ```

---

## Node Naming Best Practices

| Name | Good/Bad | Why |
|------|----------|-----|
| `process_input` | ✅ Good | Descriptive action |
| `llm_call` | ✅ Good | Clear purpose |
| `validate_and_route` | ✅ Good | Describes dual purpose |
| `node1` | ❌ Bad | Not descriptive |
| `do_stuff` | ❌ Bad | Vague |
| `handleEverything` | ❌ Bad | Too broad |

---

## Error Handling in Nodes

```python
def safe_node(state: MyState) -> dict:
    """Node with error handling."""
    try:
        result = risky_operation(state["input"])
        return {
            "result": result,
            "error": None
        }
    except Exception as e:
        return {
            "result": None,
            "error": str(e),
            "should_retry": True
        }
```

---

## Next Steps

- See node examples in code → `06_nodes_example.py`
- Learn about edges → `07_edges_explained.md`
