"""
Complete LangGraph Example
===========================

This file combines all core concepts:
- StateGraph
- State with TypedDict and reducers
- Nodes (functions)
- Regular and conditional edges
- START and END

We'll build a simple customer support classifier that:
1. Receives a customer message
2. Classifies the intent
3. Routes to appropriate handler
4. Generates a response
"""

from typing import TypedDict, Annotated, Optional, List, Literal
from langgraph.graph import StateGraph, START, END
import operator


# =============================================================================
# STEP 1: DEFINE THE STATE
# =============================================================================

class CustomerSupportState(TypedDict):
    """
    State for our customer support system.

    This state flows through all nodes and accumulates information
    as the request is processed.
    """
    # Input from customer
    customer_message: str
    customer_id: Optional[str]

    # Classification results
    intent: Optional[str]  # "billing", "technical", "general", "complaint"
    sentiment: Optional[str]  # "positive", "neutral", "negative"
    priority: Optional[str]  # "low", "medium", "high"

    # Processing results
    response: Optional[str]

    # Tracking (uses reducer to accumulate)
    processing_steps: Annotated[List[str], operator.add]

    # Metadata
    requires_human: bool


# =============================================================================
# STEP 2: DEFINE NODE FUNCTIONS
# =============================================================================

def classify_intent(state: CustomerSupportState) -> dict:
    """
    Node 1: Classify the customer's intent.

    In a real application, this would use an LLM.
    Here we use simple keyword matching for demonstration.
    """
    message = state["customer_message"].lower()

    # Simple keyword-based classification
    if any(word in message for word in ["bill", "charge", "payment", "invoice", "refund"]):
        intent = "billing"
    elif any(word in message for word in ["error", "bug", "broken", "not working", "crash"]):
        intent = "technical"
    elif any(word in message for word in ["angry", "upset", "terrible", "worst", "hate"]):
        intent = "complaint"
    else:
        intent = "general"

    print(f"  [classify_intent] Classified as: {intent}")

    return {
        "intent": intent,
        "processing_steps": ["classify_intent"]
    }


def analyze_sentiment(state: CustomerSupportState) -> dict:
    """
    Node 2: Analyze the sentiment of the message.
    """
    message = state["customer_message"].lower()

    positive_words = ["thanks", "great", "love", "excellent", "happy", "pleased"]
    negative_words = ["angry", "upset", "terrible", "worst", "hate", "frustrated"]

    pos_count = sum(1 for word in positive_words if word in message)
    neg_count = sum(1 for word in negative_words if word in message)

    if neg_count > pos_count:
        sentiment = "negative"
    elif pos_count > neg_count:
        sentiment = "positive"
    else:
        sentiment = "neutral"

    print(f"  [analyze_sentiment] Sentiment: {sentiment}")

    return {
        "sentiment": sentiment,
        "processing_steps": ["analyze_sentiment"]
    }


def determine_priority(state: CustomerSupportState) -> dict:
    """
    Node 3: Determine priority based on intent and sentiment.
    """
    intent = state["intent"]
    sentiment = state["sentiment"]

    # High priority: complaints or negative sentiment
    if intent == "complaint" or sentiment == "negative":
        priority = "high"
    # Medium priority: billing or technical issues
    elif intent in ["billing", "technical"]:
        priority = "medium"
    else:
        priority = "low"

    print(f"  [determine_priority] Priority: {priority}")

    return {
        "priority": priority,
        "processing_steps": ["determine_priority"]
    }


# =============================================================================
# STEP 3: DEFINE HANDLER NODES (for different intents)
# =============================================================================

def handle_billing(state: CustomerSupportState) -> dict:
    """Handle billing inquiries."""
    print("  [handle_billing] Processing billing inquiry...")

    response = (
        "Thank you for contacting us about billing. "
        "I can help you with invoices, payments, and refunds. "
        "Your case has been logged and our billing team will review it."
    )

    return {
        "response": response,
        "processing_steps": ["handle_billing"],
        "requires_human": state["priority"] == "high"
    }


def handle_technical(state: CustomerSupportState) -> dict:
    """Handle technical issues."""
    print("  [handle_technical] Processing technical issue...")

    response = (
        "I understand you're experiencing a technical issue. "
        "Our technical team has been notified and will investigate. "
        "In the meantime, please try restarting the application."
    )

    return {
        "response": response,
        "processing_steps": ["handle_technical"],
        "requires_human": state["priority"] == "high"
    }


def handle_complaint(state: CustomerSupportState) -> dict:
    """Handle complaints - always escalates."""
    print("  [handle_complaint] Processing complaint...")

    response = (
        "I sincerely apologize for any inconvenience you've experienced. "
        "Your feedback is important to us, and I've escalated this to our team. "
        "A supervisor will contact you within 24 hours."
    )

    return {
        "response": response,
        "processing_steps": ["handle_complaint"],
        "requires_human": True  # Complaints always need human review
    }


def handle_general(state: CustomerSupportState) -> dict:
    """Handle general inquiries."""
    print("  [handle_general] Processing general inquiry...")

    response = (
        "Thank you for reaching out! "
        "I'd be happy to help you with your question. "
        "Is there anything specific you'd like to know?"
    )

    return {
        "response": response,
        "processing_steps": ["handle_general"],
        "requires_human": False
    }


# =============================================================================
# STEP 4: DEFINE ROUTER FUNCTION
# =============================================================================

def route_to_handler(state: CustomerSupportState) -> Literal[
    "handle_billing", "handle_technical", "handle_complaint", "handle_general"
]:
    """
    Router function for conditional edges.

    Returns the name of the handler node based on the classified intent.
    """
    intent = state["intent"]

    if intent == "billing":
        return "handle_billing"
    elif intent == "technical":
        return "handle_technical"
    elif intent == "complaint":
        return "handle_complaint"
    else:
        return "handle_general"


# =============================================================================
# STEP 5: BUILD THE GRAPH
# =============================================================================

def create_customer_support_graph():
    """
    Build and compile the customer support graph.

    Graph Structure:

        START
          │
          ▼
    ┌─────────────────┐
    │ classify_intent │
    └────────┬────────┘
             │
             ▼
    ┌──────────────────┐
    │analyze_sentiment │
    └────────┬─────────┘
             │
             ▼
    ┌───────────────────┐
    │determine_priority │
    └────────┬──────────┘
             │
             ▼
      ┌──────┴───────┐
      │   ROUTER     │
      └──┬───┬───┬───┘
         │   │   │
         ▼   ▼   ▼
    ┌────┐ ┌────┐ ┌────┐ ┌────┐
    │bill│ │tech│ │comp│ │gen │
    └──┬─┘ └──┬─┘ └──┬─┘ └──┬─┘
       │      │      │      │
       └──────┴──────┴──────┘
                  │
                  ▼
                 END
    """

    # Create the graph with our state type
    graph = StateGraph(CustomerSupportState)

    # Add processing nodes
    graph.add_node("classify_intent", classify_intent)
    graph.add_node("analyze_sentiment", analyze_sentiment)
    graph.add_node("determine_priority", determine_priority)

    # Add handler nodes
    graph.add_node("handle_billing", handle_billing)
    graph.add_node("handle_technical", handle_technical)
    graph.add_node("handle_complaint", handle_complaint)
    graph.add_node("handle_general", handle_general)

    # Add edges for the processing pipeline
    graph.add_edge(START, "classify_intent")
    graph.add_edge("classify_intent", "analyze_sentiment")
    graph.add_edge("analyze_sentiment", "determine_priority")

    # Add conditional edges for routing to handlers
    graph.add_conditional_edges(
        "determine_priority",
        route_to_handler,
        {
            "handle_billing": "handle_billing",
            "handle_technical": "handle_technical",
            "handle_complaint": "handle_complaint",
            "handle_general": "handle_general"
        }
    )

    # All handlers go to END
    graph.add_edge("handle_billing", END)
    graph.add_edge("handle_technical", END)
    graph.add_edge("handle_complaint", END)
    graph.add_edge("handle_general", END)

    # Compile and return
    return graph.compile()


# =============================================================================
# STEP 6: RUN THE GRAPH
# =============================================================================

def process_customer_request(message: str, customer_id: str = "CUST001"):
    """
    Process a customer support request through the graph.
    """
    app = create_customer_support_graph()

    # Create initial state
    initial_state: CustomerSupportState = {
        "customer_message": message,
        "customer_id": customer_id,
        "intent": None,
        "sentiment": None,
        "priority": None,
        "response": None,
        "processing_steps": [],
        "requires_human": False
    }

    # Run the graph
    result = app.invoke(initial_state)

    return result


def main():
    """
    Main function demonstrating the complete example.
    """
    print("=" * 70)
    print("Customer Support System - Complete LangGraph Example")
    print("=" * 70)

    # Test cases
    test_messages = [
        "I need help with my invoice, there's an incorrect charge.",
        "The app keeps crashing when I try to login!",
        "I'm so frustrated! This is the worst service ever!",
        "Hi, I just wanted to ask about your services."
    ]

    for i, message in enumerate(test_messages, 1):
        print(f"\n{'─' * 70}")
        print(f"Test Case {i}")
        print(f"{'─' * 70}")
        print(f"Customer: \"{message}\"")
        print()

        result = process_customer_request(message)

        print(f"\n📊 Results:")
        print(f"   Intent: {result['intent']}")
        print(f"   Sentiment: {result['sentiment']}")
        print(f"   Priority: {result['priority']}")
        print(f"   Requires Human: {result['requires_human']}")
        print(f"   Processing Steps: {' → '.join(result['processing_steps'])}")
        print(f"\n💬 Response:")
        print(f"   {result['response']}")


# =============================================================================
# BONUS: Streaming Execution
# =============================================================================

def process_with_streaming(message: str):
    """
    Process a request with streaming to see each step.
    """
    print("\n" + "=" * 70)
    print("Streaming Execution Example")
    print("=" * 70)

    app = create_customer_support_graph()

    initial_state: CustomerSupportState = {
        "customer_message": message,
        "customer_id": "CUST002",
        "intent": None,
        "sentiment": None,
        "priority": None,
        "response": None,
        "processing_steps": [],
        "requires_human": False
    }

    print(f"\nProcessing: \"{message}\"")
    print("\n🔄 Streaming through nodes:\n")

    for step in app.stream(initial_state):
        # step is a dict with node name as key
        for node_name, node_state in step.items():
            print(f"✅ Completed: {node_name}")
            # Show what was updated
            if "intent" in node_state:
                print(f"   → Intent: {node_state['intent']}")
            if "sentiment" in node_state:
                print(f"   → Sentiment: {node_state['sentiment']}")
            if "priority" in node_state:
                print(f"   → Priority: {node_state['priority']}")
            if "response" in node_state:
                print(f"   → Response generated")


# =============================================================================
# RUN
# =============================================================================

if __name__ == "__main__":
    main()

    # Also show streaming example
    process_with_streaming("I'm having trouble with a payment that didn't go through")

    print("\n" + "=" * 70)
    print("Complete example finished!")
    print("=" * 70)
    print("\n📚 You've learned all core concepts:")
    print("   ✅ StateGraph - Creating and compiling graphs")
    print("   ✅ State - TypedDict with reducers (Annotated)")
    print("   ✅ Nodes - Functions that process state")
    print("   ✅ Edges - Regular and conditional routing")
    print("   ✅ START/END - Entry and exit points")
    print("\n🎯 Next: Move to _03_state_management for advanced state handling!")
