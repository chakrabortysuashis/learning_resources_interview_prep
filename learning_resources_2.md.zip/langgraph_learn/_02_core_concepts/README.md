# LangGraph Topic 2: Core Concepts

## Overview

This module covers the fundamental building blocks of LangGraph. Understanding these core concepts is essential for building any LangGraph application.

---

## Learning Objectives

By the end of this module, you will be able to:

1. **Understand StateGraph** - The main class for building graph-based applications
2. **Define State** - Create state schemas using TypedDict and Pydantic
3. **Work with Nodes** - Create and add node functions to your graph
4. **Configure Edges** - Connect nodes with regular and conditional edges
5. **Use Special Nodes** - Understand START and END nodes for graph flow control

---

## Module Structure

```
_02_core_concepts/
│
├── 01_stategraph_intro.md      # StateGraph class explanation
├── 02_stategraph_example.py    # StateGraph working example
│
├── 03_defining_state.md        # State definition concepts
├── 04_state_example.py         # State definition examples
│
├── 05_nodes_explained.md       # Node concepts and creation
├── 06_nodes_example.py         # Node working examples
│
├── 07_edges_explained.md       # Edge types and routing
├── 08_edges_example.py         # Edge examples
│
├── 09_start_end_nodes.md       # Special START/END nodes
│
└── 10_complete_example.py      # Complete working example
```

---

## Visual Overview of Core Concepts

```
┌─────────────────────────────────────────────────────────────────┐
│                      LANGGRAPH CORE CONCEPTS                    │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   ┌──────────────────┐                                          │
│   │   StateGraph     │  ◄── Container for your entire graph     │
│   └────────┬─────────┘                                          │
│            │                                                    │
│            │ Contains                                           │
│            ▼                                                    │
│   ┌──────────────────┐                                          │
│   │      State       │  ◄── Data structure (TypedDict/Pydantic) │
│   └────────┬─────────┘                                          │
│            │                                                    │
│            │ Flows through                                      │
│            ▼                                                    │
│   ┌──────────────────┐                                          │
│   │      Nodes       │  ◄── Functions that process state        │
│   └────────┬─────────┘                                          │
│            │                                                    │
│            │ Connected by                                       │
│            ▼                                                    │
│   ┌──────────────────┐                                          │
│   │      Edges       │  ◄── Define execution flow               │
│   └──────────────────┘                                          │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Prerequisites

Before starting this module, ensure you have:
- Completed Topic 1: Introduction to LangGraph
- Python 3.9+ installed
- LangGraph installed (`pip install langgraph`)

---

## Key Terminology

| Term | Definition |
|------|------------|
| **StateGraph** | The main class for creating graph-based workflows |
| **State** | A data structure that holds information passed between nodes |
| **Node** | A function that processes and potentially modifies the state |
| **Edge** | A connection between nodes that defines execution flow |
| **START** | Special node marking where execution begins |
| **END** | Special node marking where execution terminates |

---

## Quick Reference

```python
from langgraph.graph import StateGraph, START, END
from typing import TypedDict

# 1. Define State
class MyState(TypedDict):
    data: str

# 2. Create Graph
graph = StateGraph(MyState)

# 3. Add Nodes
graph.add_node("my_node", my_function)

# 4. Add Edges
graph.add_edge(START, "my_node")
graph.add_edge("my_node", END)

# 5. Compile and Run
app = graph.compile()
result = app.invoke({"data": "hello"})
```

---

## Recommended Learning Path

1. Start with `01_stategraph_intro.md` and `02_stategraph_example.py`
2. Move to state definition (`03` and `04`)
3. Learn about nodes (`05` and `06`)
4. Understand edges (`07` and `08`)
5. Study START/END nodes (`09`)
6. Review the complete example (`10`)

---

💡 **Tip**: Run each example file as you learn. Experimentation is the best way to understand these concepts!
