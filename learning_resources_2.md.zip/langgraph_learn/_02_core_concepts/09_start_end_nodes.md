# START and END Nodes

```
╔═══════════════════════════════════════════════════════════════════════════╗
║                          START and END                                     ║
║                   The Entry and Exit Points                                ║
╚═══════════════════════════════════════════════════════════════════════════╝
```

## Overview

Every LangGraph workflow needs:
- **START**: Where execution begins
- **END**: Where execution terminates

These are special constants imported from `langgraph.graph`.

```python
from langgraph.graph import StateGraph, START, END
```

---

## Visual Representation

```
    ╔═══════════════════════════════════════════════════════════════════╗
    ║                                                                   ║
    ║   ┌───────┐                                          ┌───────┐   ║
    ║   │ START │                                          │  END  │   ║
    ║   │       │     ┌─────┐    ┌─────┐    ┌─────┐       │       │   ║
    ║   │ Entry │────▶│  A  │───▶│  B  │───▶│  C  │──────▶│ Exit  │   ║
    ║   │ Point │     └─────┘    └─────┘    └─────┘       │ Point │   ║
    ║   └───────┘                                          └───────┘   ║
    ║                                                                   ║
    ║   • Not a real node       Your processing nodes      • Not a     ║
    ║   • Just marks entry                                   real node ║
    ║   • Receives initial                                 • Marks     ║
    ║     state                                              completion║
    ║                                                                   ║
    ╚═══════════════════════════════════════════════════════════════════╝
```

---

## START Node

### What It Is

- **Not an actual node** - It's a marker for where to begin
- **Entry point** - The first edge must come from START
- **Initial state** - Receives the state you pass to `invoke()`

### Rules

| ✅ Allowed | ❌ Not Allowed |
|-----------|----------------|
| `graph.add_edge(START, "node")` | `graph.add_edge("node", START)` |
| `graph.add_conditional_edges(START, ...)` | `graph.add_node("START", ...)` |

### Example

```python
# Correct: START as source
graph.add_edge(START, "first_node")

# Can also use conditional edges from START
graph.add_conditional_edges(
    START,
    lambda state: "urgent" if state["priority"] == "high" else "normal",
    {
        "urgent": "urgent_handler",
        "normal": "normal_handler"
    }
)
```

---

## END Node

### What It Is

- **Not an actual node** - It's a marker for completion
- **Exit point** - Execution stops when END is reached
- **Final state** - The state at END is returned from `invoke()`

### Rules

| ✅ Allowed | ❌ Not Allowed |
|-----------|----------------|
| `graph.add_edge("node", END)` | `graph.add_edge(END, "node")` |
| Routing to END conditionally | Using END as a source |

### Example

```python
# Correct: END as target
graph.add_edge("final_node", END)

# Conditional routing to END
graph.add_conditional_edges(
    "check_done",
    lambda state: "end" if state["is_complete"] else "continue",
    {
        "end": END,
        "continue": "process_more"
    }
)
```

---

## Multiple Paths to END

A graph can have multiple ways to reach END:

```
                   ┌───────────┐
              ┌───▶│  path_a   │───┐
              │    └───────────┘   │
              │                    │
    START ───▶│    ┌───────────┐   │───▶ END
              │    │  path_b   │───┤
              ├───▶│           │   │
              │    └───────────┘   │
              │                    │
              │    ┌───────────┐   │
              └───▶│  path_c   │───┘
                   └───────────┘
```

```python
# Multiple nodes can connect to END
graph.add_edge("success_handler", END)
graph.add_edge("error_handler", END)
graph.add_edge("timeout_handler", END)
```

---

## Conditional Entry from START

Route to different first nodes based on initial state:

```python
def route_entry(state: MyState) -> str:
    """Determine entry point based on initial state."""
    if state.get("mode") == "fast":
        return "quick_process"
    elif state.get("mode") == "thorough":
        return "deep_process"
    else:
        return "default_process"

graph.add_conditional_edges(
    START,
    route_entry,
    {
        "quick_process": "quick_process",
        "deep_process": "deep_process",
        "default_process": "default_process"
    }
)
```

---

## Conditional Exit to END

Exit the graph based on conditions:

```python
def should_exit(state: AgentState) -> str:
    """Determine if we should exit or continue."""
    if state.get("error"):
        return "error_exit"
    elif state.get("task_complete"):
        return "success_exit"
    else:
        return "continue"

graph.add_conditional_edges(
    "check_status",
    should_exit,
    {
        "error_exit": END,      # Exit on error
        "success_exit": END,    # Exit on success
        "continue": "next_step" # Keep going
    }
)
```

---

## Common Patterns

### Pattern 1: Simple Linear

```python
graph.add_edge(START, "process")
graph.add_edge("process", END)
```

```
    START ──▶ process ──▶ END
```

### Pattern 2: Multiple Entry Points

```python
graph.add_conditional_edges(START, router, {
    "type_a": "handler_a",
    "type_b": "handler_b"
})
```

```
              ┌──▶ handler_a ──┐
    START ───┤                 ├──▶ END
              └──▶ handler_b ──┘
```

### Pattern 3: Loop with Exit

```python
graph.add_edge(START, "loop_body")
graph.add_conditional_edges("loop_body", check_done, {
    "continue": "loop_body",
    "done": END
})
```

```
    START ──▶ loop_body ◀──┐
                  │        │
                  ├────────┘ (continue)
                  │
                  └──▶ END (done)
```

### Pattern 4: Error Handling

```python
graph.add_edge(START, "process")
graph.add_conditional_edges("process", check_result, {
    "success": "finalize",
    "error": "error_handler"
})
graph.add_edge("finalize", END)
graph.add_edge("error_handler", END)
```

```
                  ┌──▶ finalize ──────▶ END
    START ──▶ process
                  └──▶ error_handler ──▶ END
```

---

## 📌 Interview Tip

> **Common Question**: "What happens if there's no path to END?"
>
> **Answer**: The graph will **hang indefinitely** if no path reaches END. This is a common bug in cyclic graphs where the exit condition is never met.
>
> **Best Practice**: Always ensure:
> 1. Every branch eventually reaches END
> 2. Loop conditions will eventually become false
> 3. Use `recursion_limit` parameter in compile() as a safety net
>
> ```python
> # Add safety limit for loops
> app = graph.compile()
> app.invoke(state, {"recursion_limit": 100})
> ```

---

## Debugging Tips

### Check Graph Structure

```python
# Print all edges to verify START and END connections
app = graph.compile()
print(app.get_graph().edges)
```

### Visualize the Graph

```python
# Get ASCII representation
print(app.get_graph().draw_ascii())

# Or get Mermaid diagram
print(app.get_graph().draw_mermaid())
```

---

## Next Steps

- See complete working example → `10_complete_example.py`
- Move to State Management → `../_03_state_management/`
