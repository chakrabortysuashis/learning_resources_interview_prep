"""
Node Examples in LangGraph
===========================

This file demonstrates different types of nodes
and how to use them in a StateGraph.
"""

from typing import TypedDict, Annotated, Optional, List
from langgraph.graph import StateGraph, START, END
import operator
import asyncio


# =============================================================================
# STATE DEFINITION
# =============================================================================

class DemoState(TypedDict):
    """State for our node demonstrations."""
    input: str
    messages: Annotated[List[str], operator.add]
    step_count: int
    result: Optional[str]


# =============================================================================
# EXAMPLE 1: Basic Function Nodes
# =============================================================================

def input_processor(state: DemoState) -> dict:
    """
    Node 1: Process the input.

    This is a basic synchronous node that reads input
    and returns processed output.
    """
    print(f"  [input_processor] Received: {state['input']}")

    processed = state["input"].strip().lower()

    return {
        "messages": [f"Input processed: '{processed}'"],
        "step_count": state["step_count"] + 1
    }


def analyzer(state: DemoState) -> dict:
    """
    Node 2: Analyze the processed input.
    """
    print(f"  [analyzer] Analyzing at step {state['step_count']}")

    word_count = len(state["input"].split())
    analysis = f"Analysis: {word_count} words detected"

    return {
        "messages": [analysis],
        "step_count": state["step_count"] + 1
    }


def finalizer(state: DemoState) -> dict:
    """
    Node 3: Create final result.
    """
    print(f"  [finalizer] Creating result at step {state['step_count']}")

    all_messages = state["messages"]
    result = f"Completed {state['step_count']} steps. Summary: {len(all_messages)} messages."

    return {
        "result": result,
        "messages": ["Processing complete!"],
        "step_count": state["step_count"] + 1
    }


def demo_basic_nodes():
    """Demonstrate basic function nodes."""
    print("=" * 60)
    print("Example 1: Basic Function Nodes")
    print("=" * 60)

    # Build graph
    graph = StateGraph(DemoState)

    graph.add_node("process", input_processor)
    graph.add_node("analyze", analyzer)
    graph.add_node("finalize", finalizer)

    graph.add_edge(START, "process")
    graph.add_edge("process", "analyze")
    graph.add_edge("analyze", "finalize")
    graph.add_edge("finalize", END)

    app = graph.compile()

    # Run
    initial_state = {
        "input": "Hello World from LangGraph!",
        "messages": [],
        "step_count": 0,
        "result": None
    }

    print("\nExecuting graph...")
    result = app.invoke(initial_state)

    print(f"\nFinal Result: {result['result']}")
    print(f"Messages: {result['messages']}")
    print(f"Total Steps: {result['step_count']}")


# =============================================================================
# EXAMPLE 2: Class-Based Nodes
# =============================================================================

class TextTransformer:
    """
    A class-based node for text transformation.

    Class-based nodes are useful when you need:
    - Initialization with parameters
    - Shared state across calls
    - More complex logic organization
    """

    def __init__(self, transform_type: str = "upper"):
        """
        Initialize the transformer.

        Args:
            transform_type: "upper", "lower", "title", or "reverse"
        """
        self.transform_type = transform_type
        self.call_count = 0

    def __call__(self, state: DemoState) -> dict:
        """
        Execute the transformation.

        The __call__ method makes the class callable like a function.
        """
        self.call_count += 1
        text = state["input"]

        if self.transform_type == "upper":
            transformed = text.upper()
        elif self.transform_type == "lower":
            transformed = text.lower()
        elif self.transform_type == "title":
            transformed = text.title()
        elif self.transform_type == "reverse":
            transformed = text[::-1]
        else:
            transformed = text

        return {
            "messages": [f"Transformed ({self.transform_type}): {transformed}"],
            "result": transformed
        }


def demo_class_nodes():
    """Demonstrate class-based nodes."""
    print("\n" + "=" * 60)
    print("Example 2: Class-Based Nodes")
    print("=" * 60)

    # Create node instances with different configurations
    upper_transformer = TextTransformer("upper")
    reverse_transformer = TextTransformer("reverse")

    # Build graph
    graph = StateGraph(DemoState)

    # Add class instances as nodes
    graph.add_node("to_upper", upper_transformer)
    graph.add_node("reverse", reverse_transformer)

    graph.add_edge(START, "to_upper")
    graph.add_edge("to_upper", END)

    app = graph.compile()

    # Run
    result = app.invoke({
        "input": "hello langgraph",
        "messages": [],
        "step_count": 0,
        "result": None
    })

    print(f"\nResult: {result['result']}")
    print(f"Transformer was called {upper_transformer.call_count} time(s)")


# =============================================================================
# EXAMPLE 3: Lambda Nodes (Inline Nodes)
# =============================================================================

def demo_lambda_nodes():
    """Demonstrate inline lambda nodes."""
    print("\n" + "=" * 60)
    print("Example 3: Lambda (Inline) Nodes")
    print("=" * 60)

    graph = StateGraph(DemoState)

    # Lambda nodes for simple operations
    graph.add_node(
        "init",
        lambda state: {"messages": ["Started processing"], "step_count": 1}
    )

    graph.add_node(
        "double",
        lambda state: {"step_count": state["step_count"] * 2}
    )

    graph.add_node(
        "finalize",
        lambda state: {"result": f"Final count: {state['step_count']}"}
    )

    graph.add_edge(START, "init")
    graph.add_edge("init", "double")
    graph.add_edge("double", "finalize")
    graph.add_edge("finalize", END)

    app = graph.compile()

    result = app.invoke({
        "input": "",
        "messages": [],
        "step_count": 0,
        "result": None
    })

    print(f"\nResult: {result['result']}")
    print(f"Messages: {result['messages']}")


# =============================================================================
# EXAMPLE 4: Async Nodes
# =============================================================================

class AsyncState(TypedDict):
    """State for async demonstration."""
    urls: List[str]
    results: Annotated[List[str], operator.add]
    errors: Annotated[List[str], operator.add]


async def async_fetcher(state: AsyncState) -> dict:
    """
    Async node that simulates fetching data.

    In real applications, this would make actual HTTP requests.
    """
    print("  [async_fetcher] Starting async fetch...")

    results = []
    for url in state["urls"]:
        # Simulate async I/O
        await asyncio.sleep(0.1)
        results.append(f"Fetched: {url}")

    print(f"  [async_fetcher] Fetched {len(results)} URLs")

    return {"results": results}


async def async_processor(state: AsyncState) -> dict:
    """
    Async node that processes the fetched data.
    """
    print("  [async_processor] Processing results...")

    await asyncio.sleep(0.05)  # Simulate processing time

    processed = [f"[PROCESSED] {r}" for r in state["results"]]

    return {"results": processed}


def demo_async_nodes():
    """Demonstrate async nodes."""
    print("\n" + "=" * 60)
    print("Example 4: Async Nodes")
    print("=" * 60)

    graph = StateGraph(AsyncState)

    graph.add_node("fetch", async_fetcher)
    graph.add_node("process", async_processor)

    graph.add_edge(START, "fetch")
    graph.add_edge("fetch", "process")
    graph.add_edge("process", END)

    app = graph.compile()

    # Run async graph
    initial_state = {
        "urls": ["https://example.com", "https://test.com"],
        "results": [],
        "errors": []
    }

    print("\nRunning async graph...")
    result = asyncio.run(app.ainvoke(initial_state))

    print(f"\nResults: {result['results']}")


# =============================================================================
# EXAMPLE 5: Nodes with Error Handling
# =============================================================================

class ErrorState(TypedDict):
    """State for error handling demo."""
    input: str
    output: Optional[str]
    error: Optional[str]
    success: bool


def risky_node(state: ErrorState) -> dict:
    """
    Node that might fail.

    Shows how to handle errors within nodes.
    """
    try:
        # Simulate risky operation
        if "error" in state["input"].lower():
            raise ValueError("Simulated error!")

        result = state["input"].upper()

        return {
            "output": result,
            "error": None,
            "success": True
        }

    except Exception as e:
        return {
            "output": None,
            "error": str(e),
            "success": False
        }


def error_handler(state: ErrorState) -> dict:
    """Handle errors from previous nodes."""
    if not state["success"]:
        print(f"  [error_handler] Handling error: {state['error']}")
        return {
            "output": f"ERROR: {state['error']}",
        }
    return {}


def demo_error_handling():
    """Demonstrate error handling in nodes."""
    print("\n" + "=" * 60)
    print("Example 5: Nodes with Error Handling")
    print("=" * 60)

    graph = StateGraph(ErrorState)

    graph.add_node("risky", risky_node)
    graph.add_node("handle_error", error_handler)

    graph.add_edge(START, "risky")
    graph.add_edge("risky", "handle_error")
    graph.add_edge("handle_error", END)

    app = graph.compile()

    # Test success case
    print("\nTest 1: Successful input")
    result1 = app.invoke({
        "input": "hello world",
        "output": None,
        "error": None,
        "success": False
    })
    print(f"  Output: {result1['output']}")
    print(f"  Success: {result1['success']}")

    # Test error case
    print("\nTest 2: Input that causes error")
    result2 = app.invoke({
        "input": "this will error",
        "output": None,
        "error": None,
        "success": False
    })
    print(f"  Output: {result2['output']}")
    print(f"  Success: {result2['success']}")


# =============================================================================
# EXAMPLE 6: Node Returning Empty Dict
# =============================================================================

def conditional_updater(state: DemoState) -> dict:
    """
    Node that only updates state under certain conditions.

    Returns empty dict when no updates needed.
    """
    if len(state["input"]) > 10:
        return {"messages": ["Input is long enough"]}
    else:
        # No updates - return empty dict
        return {}


def demo_empty_return():
    """Demonstrate nodes that return empty dict."""
    print("\n" + "=" * 60)
    print("Example 6: Conditional Updates (Empty Return)")
    print("=" * 60)

    graph = StateGraph(DemoState)

    graph.add_node("check", conditional_updater)

    graph.add_edge(START, "check")
    graph.add_edge("check", END)

    app = graph.compile()

    # Short input
    print("\nShort input ('Hi'):")
    result1 = app.invoke({
        "input": "Hi",
        "messages": ["Initial"],
        "step_count": 0,
        "result": None
    })
    print(f"  Messages: {result1['messages']}")

    # Long input
    print("\nLong input ('Hello, this is a longer message'):")
    result2 = app.invoke({
        "input": "Hello, this is a longer message",
        "messages": ["Initial"],
        "step_count": 0,
        "result": None
    })
    print(f"  Messages: {result2['messages']}")


# =============================================================================
# RUN ALL DEMOS
# =============================================================================

if __name__ == "__main__":
    demo_basic_nodes()
    demo_class_nodes()
    demo_lambda_nodes()
    demo_async_nodes()
    demo_error_handling()
    demo_empty_return()

    print("\n" + "=" * 60)
    print("All node examples completed!")
    print("=" * 60)
