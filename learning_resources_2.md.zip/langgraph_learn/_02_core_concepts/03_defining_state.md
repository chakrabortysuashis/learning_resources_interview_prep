# Defining State in LangGraph

```
╔═══════════════════════════════════════════════════════════════════════════╗
║                           STATE DEFINITION                                 ║
║                  The Foundation of Your Graph                             ║
╚═══════════════════════════════════════════════════════════════════════════╝
```

## What is State?

State is the **data container** that flows through your graph. Every node:
- Receives the current state
- Can read any field
- Returns updates to specific fields

---

## Two Ways to Define State

```
    ┌────────────────────────────────────────────────────────────────┐
    │                    STATE DEFINITION OPTIONS                     │
    ├────────────────────────────────────────────────────────────────┤
    │                                                                │
    │   ┌─────────────────────┐      ┌─────────────────────┐        │
    │   │     TypedDict       │      │      Pydantic       │        │
    │   │   (Lightweight)     │      │    (Full-featured)  │        │
    │   └─────────────────────┘      └─────────────────────┘        │
    │                                                                │
    │   • Simple syntax              • Runtime validation           │
    │   • Type hints only            • Default values               │
    │   • No validation              • Complex types                │
    │   • Good for simple cases      • Serialization built-in       │
    │                                                                │
    └────────────────────────────────────────────────────────────────┘
```

---

## Option 1: TypedDict (Recommended for Most Cases)

TypedDict is Python's built-in way to define typed dictionaries.

```python
from typing import TypedDict, Annotated, Optional
import operator

class ChatState(TypedDict):
    """State for a chat application."""
    messages: list[str]              # Required field
    user_name: str                   # Required field
    context: Optional[str]           # Optional field (can be None)
```

### With Reducers (Annotated)

```python
from typing import Annotated
import operator

class ChatState(TypedDict):
    # This field ACCUMULATES - new values are ADDED to the list
    messages: Annotated[list[str], operator.add]
    
    # This field OVERWRITES - new values replace old ones
    current_topic: str
```

---

## Option 2: Pydantic (For Complex Validation)

Pydantic provides runtime validation and more features.

```python
from pydantic import BaseModel, Field
from typing import List, Optional

class ChatState(BaseModel):
    """State with validation."""
    messages: List[str] = Field(default_factory=list)
    user_name: str = Field(min_length=1)  # Validation!
    temperature: float = Field(ge=0, le=2)  # Range validation
    
    class Config:
        # Allow extra fields (useful for flexibility)
        extra = "allow"
```

---

## Comparison Table

| Feature | TypedDict | Pydantic |
|---------|-----------|----------|
| **Syntax** | Simple | More verbose |
| **Validation** | None (type hints only) | Full runtime validation |
| **Default Values** | Not directly supported | Built-in |
| **Performance** | Faster | Slightly slower |
| **Serialization** | Manual | Automatic (json(), dict()) |
| **Reducers** | Via Annotated | Via custom validators |
| **Best For** | Simple state | Complex validation needs |

---

## State Field Types

### Basic Types

```python
class BasicState(TypedDict):
    text: str                    # String
    count: int                   # Integer
    score: float                 # Float
    is_done: bool                # Boolean
    items: list                  # List (any type)
    metadata: dict               # Dictionary
```

### Complex Types

```python
from typing import List, Dict, Optional, Union, Any

class ComplexState(TypedDict):
    messages: List[str]              # List of strings
    config: Dict[str, Any]           # Dict with string keys
    result: Optional[str]            # Can be None
    response: Union[str, dict]       # String OR dict
```

---

## Reducer Patterns

Reducers define **HOW** state fields are updated.

```
    WITHOUT REDUCER                      WITH REDUCER (operator.add)
    ────────────────                     ──────────────────────────
    
    Initial: ["A"]                       Initial: ["A"]
                                         
    Node returns: ["B"]                  Node returns: ["B"]
                                         
    Result: ["B"]                        Result: ["A", "B"]
    (REPLACED)                           (ACCUMULATED)
```

### Common Reducers

```python
from typing import Annotated
import operator

class StateWithReducers(TypedDict):
    # ADD: Concatenate lists
    messages: Annotated[list, operator.add]
    
    # ADD: Sum numbers
    total_tokens: Annotated[int, operator.add]
    
    # Custom reducer
    def merge_dicts(a: dict, b: dict) -> dict:
        return {**a, **b}
    
    metadata: Annotated[dict, merge_dicts]
```

---

## Visual: How State Flows

```
    ┌─────────────────────────────────────────────────────────────────┐
    │                        STATE FLOW                                │
    └─────────────────────────────────────────────────────────────────┘
    
    Initial State              Node A Returns          New State
    ─────────────              ──────────────          ─────────
    
    ┌───────────────┐          ┌───────────────┐       ┌───────────────┐
    │ messages: []  │          │ messages:     │       │ messages:     │
    │ count: 0      │  ──────▶ │   ["Hello"]   │ ────▶ │   ["Hello"]   │
    │ done: False   │          │               │       │ count: 0      │
    └───────────────┘          └───────────────┘       │ done: False   │
                                                       └───────────────┘
                               Only updated fields     Merged with
                               are returned            original state
```

---

## 📌 Interview Tip

> **Common Question**: "When would you use Pydantic over TypedDict for state?"
>
> **Answer**: Use **Pydantic** when you need:
> 1. **Runtime validation** - Ensure data meets requirements
> 2. **Default values** - Initialize fields automatically
> 3. **Complex nested structures** - Better handling of nested models
> 4. **Serialization** - Easy JSON conversion
>
> Use **TypedDict** when you need:
> 1. **Simplicity** - Less boilerplate
> 2. **Performance** - No validation overhead
> 3. **Compatibility** - Works with any dict

---

## Best Practices

### ✅ DO:

```python
# 1. Use descriptive field names
class GoodState(TypedDict):
    conversation_history: list  # Clear!
    current_user_intent: str    # Descriptive!

# 2. Use reducers for accumulating fields
class GoodState(TypedDict):
    messages: Annotated[list, operator.add]  # Accumulates

# 3. Document your state
class DocumentedState(TypedDict):
    """
    State for the customer support bot.
    
    Attributes:
        messages: Conversation history
        ticket_id: Current support ticket
    """
    messages: list
    ticket_id: str
```

### ❌ DON'T:

```python
# 1. Vague field names
class BadState(TypedDict):
    x: list     # What is x?
    data: dict  # Too generic

# 2. Forgetting reducers for lists
class BadState(TypedDict):
    messages: list  # Will overwrite, not accumulate!

# 3. Overly complex nested structures
class BadState(TypedDict):
    # This becomes hard to manage
    deeply_nested: Dict[str, Dict[str, List[Dict[str, Any]]]]
```

---

## Complete Example

```python
from typing import TypedDict, Annotated, Optional
from langgraph.graph import StateGraph, START, END
import operator

# Define comprehensive state
class AgentState(TypedDict):
    """
    State for an AI agent.
    
    messages: Conversation history (accumulates)
    current_task: What the agent is working on
    tools_used: List of tools invoked (accumulates)
    final_answer: The agent's response
    iteration: Current loop iteration
    """
    messages: Annotated[list[dict], operator.add]
    current_task: Optional[str]
    tools_used: Annotated[list[str], operator.add]
    final_answer: Optional[str]
    iteration: int

# Create graph with this state
graph = StateGraph(AgentState)
```

---

## Next Steps

- See practical examples → `04_state_example.py`
- Learn about nodes → `05_nodes_explained.md`
