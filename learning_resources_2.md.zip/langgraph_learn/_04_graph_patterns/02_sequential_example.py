"""
Sequential Workflow Example: Document Processing Pipeline

This example demonstrates a sequential workflow for processing a document:
    Extract → Clean → Analyze → Summarize

Real-world use case: Processing customer feedback documents

Graph Structure:
    ┌─────────────┐     ┌─────────────┐     ┌─────────────┐     ┌─────────────┐
    │   EXTRACT   │────▶│    CLEAN    │────▶│   ANALYZE   │────▶│  SUMMARIZE  │
    │             │     │             │     │             │     │             │
    │  Get raw    │     │  Remove     │     │  Count &    │     │  Generate   │
    │  content    │     │  noise      │     │  categorize │     │  summary    │
    └─────────────┘     └─────────────┘     └─────────────┘     └─────────────┘
"""

from typing import TypedDict, List
from langgraph.graph import StateGraph, START, END
import re


# =============================================================================
# STEP 1: Define the State
# =============================================================================
# The state holds all data that flows through our pipeline.
# Each node can read from and write to specific state keys.

class DocumentState(TypedDict):
    """
    State structure for document processing pipeline.

    Attributes:
        raw_document: The original input document
        cleaned_text: Document after noise removal
        word_count: Number of words in the document
        sentences: List of sentences extracted
        keywords: Important keywords found
        summary: Final generated summary
        processing_log: List of processing steps completed
    """
    raw_document: str
    cleaned_text: str
    word_count: int
    sentences: List[str]
    keywords: List[str]
    summary: str
    processing_log: List[str]


# =============================================================================
# STEP 2: Define Node Functions
# =============================================================================
# Each function represents one step in our sequential pipeline.
# They receive the current state and return updates to the state.

def extract_content(state: DocumentState) -> dict:
    """
    Node 1: Extract Content

    This node simulates extracting raw content from a source.
    In real scenarios, this might:
    - Read from a file
    - Fetch from an API
    - Parse from HTML/PDF

    Input: raw_document (from initial state)
    Output: Updates processing_log
    """
    print("📄 Step 1: Extracting content...")

    raw_doc = state["raw_document"]

    # Log what we received
    log_entry = f"Extracted document with {len(raw_doc)} characters"

    return {
        "processing_log": [log_entry]  # Start the log
    }


def clean_text(state: DocumentState) -> dict:
    """
    Node 2: Clean Text

    This node cleans the raw document by:
    - Converting to lowercase
    - Removing extra whitespace
    - Removing special characters (keeping basic punctuation)

    Input: raw_document
    Output: cleaned_text, updated processing_log
    """
    print("🧹 Step 2: Cleaning text...")

    raw_doc = state["raw_document"]

    # Cleaning operations
    # 1. Convert to lowercase for consistency
    text = raw_doc.lower()

    # 2. Remove extra whitespace (multiple spaces, tabs, newlines)
    text = re.sub(r'\s+', ' ', text)

    # 3. Remove special characters but keep letters, numbers, basic punctuation
    text = re.sub(r'[^\w\s.,!?-]', '', text)

    # 4. Strip leading/trailing whitespace
    text = text.strip()

    log_entry = f"Cleaned text: removed {len(raw_doc) - len(text)} characters"

    return {
        "cleaned_text": text,
        "processing_log": state["processing_log"] + [log_entry]
    }


def analyze_document(state: DocumentState) -> dict:
    """
    Node 3: Analyze Document

    This node analyzes the cleaned text to extract:
    - Word count
    - Individual sentences
    - Keywords (simple extraction based on word frequency)

    Input: cleaned_text
    Output: word_count, sentences, keywords, updated processing_log
    """
    print("🔍 Step 3: Analyzing document...")

    cleaned_text = state["cleaned_text"]

    # Count words
    words = cleaned_text.split()
    word_count = len(words)

    # Extract sentences (split on period, exclamation, question mark)
    sentences = re.split(r'[.!?]+', cleaned_text)
    sentences = [s.strip() for s in sentences if s.strip()]  # Remove empty

    # Simple keyword extraction (words longer than 5 chars, appearing multiple times)
    word_freq = {}
    for word in words:
        # Clean the word of punctuation for counting
        clean_word = re.sub(r'[^\w]', '', word)
        if len(clean_word) > 5:  # Only consider longer words
            word_freq[clean_word] = word_freq.get(clean_word, 0) + 1

    # Get top keywords (words appearing more than once, or top 5 by frequency)
    sorted_words = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)
    keywords = [word for word, count in sorted_words[:5]]

    log_entry = f"Analysis complete: {word_count} words, {len(sentences)} sentences, {len(keywords)} keywords"

    return {
        "word_count": word_count,
        "sentences": sentences,
        "keywords": keywords,
        "processing_log": state["processing_log"] + [log_entry]
    }


def generate_summary(state: DocumentState) -> dict:
    """
    Node 4: Generate Summary

    This node creates a summary of the document using the analysis results.
    In a real scenario, you might use an LLM here.

    Input: cleaned_text, word_count, sentences, keywords
    Output: summary, updated processing_log
    """
    print("📝 Step 4: Generating summary...")

    word_count = state["word_count"]
    sentences = state["sentences"]
    keywords = state["keywords"]

    # Create a simple summary (in production, use LLM)
    summary_parts = [
        f"Document Analysis Summary:",
        f"- Total words: {word_count}",
        f"- Total sentences: {len(sentences)}",
        f"- Key topics: {', '.join(keywords) if keywords else 'None identified'}",
        f"",
        f"First sentence: {sentences[0] if sentences else 'N/A'}",
    ]

    summary = "\n".join(summary_parts)

    log_entry = "Summary generated successfully"

    return {
        "summary": summary,
        "processing_log": state["processing_log"] + [log_entry]
    }


# =============================================================================
# STEP 3: Build the Graph
# =============================================================================
def create_document_pipeline() -> StateGraph:
    """
    Creates and returns the document processing pipeline graph.

    Graph structure:
        START → extract → clean → analyze → summarize → END
    """
    # Initialize the graph with our state schema
    graph = StateGraph(DocumentState)

    # Add all nodes to the graph
    # Each node is registered with a name and its function
    graph.add_node("extract", extract_content)
    graph.add_node("clean", clean_text)
    graph.add_node("analyze", analyze_document)
    graph.add_node("summarize", generate_summary)

    # Define the sequential flow with edges
    # This creates: START → extract → clean → analyze → summarize → END
    graph.add_edge(START, "extract")      # Entry point
    graph.add_edge("extract", "clean")    # After extract, go to clean
    graph.add_edge("clean", "analyze")    # After clean, go to analyze
    graph.add_edge("analyze", "summarize") # After analyze, go to summarize
    graph.add_edge("summarize", END)      # Exit point

    return graph


# =============================================================================
# STEP 4: Run the Pipeline
# =============================================================================
def main():
    """
    Main function to demonstrate the sequential workflow.
    """
    print("=" * 60)
    print("SEQUENTIAL WORKFLOW: Document Processing Pipeline")
    print("=" * 60)
    print()

    # Create the pipeline
    graph = create_document_pipeline()

    # Compile the graph into an executable application
    app = graph.compile()

    # Sample document to process
    sample_document = """
    Artificial Intelligence (AI) is transforming the way we work and live.
    Machine learning algorithms can now process vast amounts of data!
    Companies are investing heavily in AI research and development.
    The future of technology depends on responsible AI innovation.
    AI systems must be designed with ethics and fairness in mind...
    Natural Language Processing enables computers to understand human language.
    Deep learning has achieved remarkable results in image recognition.
    """

    # Prepare the initial state
    # We only need to provide the input; other fields will be populated by nodes
    initial_state = {
        "raw_document": sample_document,
        "cleaned_text": "",
        "word_count": 0,
        "sentences": [],
        "keywords": [],
        "summary": "",
        "processing_log": []
    }

    print("Input Document:")
    print("-" * 40)
    print(sample_document.strip())
    print("-" * 40)
    print()

    # Execute the pipeline
    print("Executing Pipeline...")
    print()

    result = app.invoke(initial_state)

    # Display results
    print()
    print("=" * 60)
    print("RESULTS")
    print("=" * 60)
    print()

    print("📊 Generated Summary:")
    print("-" * 40)
    print(result["summary"])
    print()

    print("📋 Processing Log:")
    print("-" * 40)
    for i, log in enumerate(result["processing_log"], 1):
        print(f"  {i}. {log}")
    print()

    print("🔑 Extracted Keywords:", result["keywords"])
    print("📈 Word Count:", result["word_count"])
    print("📝 Sentence Count:", len(result["sentences"]))


# =============================================================================
# BONUS: Streaming Execution
# =============================================================================
def main_with_streaming():
    """
    Demonstrates streaming execution to see state updates in real-time.
    """
    print("=" * 60)
    print("SEQUENTIAL WORKFLOW WITH STREAMING")
    print("=" * 60)
    print()

    graph = create_document_pipeline()
    app = graph.compile()

    sample_document = """
    LangGraph is a powerful library for building stateful AI applications.
    It provides tools for creating complex multi-agent workflows.
    Developers can define custom state schemas and processing nodes.
    """

    initial_state = {
        "raw_document": sample_document,
        "cleaned_text": "",
        "word_count": 0,
        "sentences": [],
        "keywords": [],
        "summary": "",
        "processing_log": []
    }

    print("Streaming execution - watching state updates:")
    print("-" * 40)

    # Use stream() instead of invoke() to see incremental updates
    for event in app.stream(initial_state):
        # event is a dict with node_name: state_update
        for node_name, state_update in event.items():
            print(f"\n✅ Node '{node_name}' completed")
            print(f"   Updated keys: {list(state_update.keys())}")


# =============================================================================
# INTERVIEW TIP
# =============================================================================
"""
┌─────────────────────────────────────────────────────────────────────┐
│ 💡 INTERVIEW TIP                                                    │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│ Q: "How would you add error handling to this sequential pipeline?"  │
│                                                                     │
│ A: "There are several approaches:                                   │
│                                                                     │
│    1. NODE-LEVEL: Add try/except in each node function, store      │
│       errors in state, and check error state in subsequent nodes   │
│                                                                     │
│    2. GRAPH-LEVEL: Add an 'error_handler' node and use             │
│       conditional edges to route to it when errors occur           │
│                                                                     │
│    3. WRAPPER: Create a decorator that wraps node functions        │
│       with standardized error handling                             │
│                                                                     │
│    Example state addition:                                          │
│       class State(TypedDict):                                       │
│           error: Optional[str]                                      │
│           error_node: Optional[str]                                 │
│                                                                     │
│    Then check 'error' at the start of each node."                  │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
"""


if __name__ == "__main__":
    # Run the basic example
    main()

    print("\n" + "=" * 60 + "\n")

    # Run the streaming example
    main_with_streaming()
