# Sequential Workflows in LangGraph

## What is a Sequential Workflow?

A sequential workflow is the simplest graph pattern where nodes execute **one after another**
in a predetermined order. Think of it like a relay race - one runner must finish before
the next can start.

```
    ╔═══════════════════════════════════════════════════════════════╗
    ║                  SEQUENTIAL WORKFLOW PATTERN                   ║
    ╠═══════════════════════════════════════════════════════════════╣
    ║                                                                ║
    ║                        ┌─────────────┐                         ║
    ║                        │    START    │                         ║
    ║                        └──────┬──────┘                         ║
    ║                               │                                ║
    ║                               ▼                                ║
    ║                        ┌─────────────┐                         ║
    ║                        │   Node A    │                         ║
    ║                        │  (Step 1)   │                         ║
    ║                        └──────┬──────┘                         ║
    ║                               │                                ║
    ║                               ▼                                ║
    ║                        ┌─────────────┐                         ║
    ║                        │   Node B    │                         ║
    ║                        │  (Step 2)   │                         ║
    ║                        └──────┬──────┘                         ║
    ║                               │                                ║
    ║                               ▼                                ║
    ║                        ┌─────────────┐                         ║
    ║                        │   Node C    │                         ║
    ║                        │  (Step 3)   │                         ║
    ║                        └──────┬──────┘                         ║
    ║                               │                                ║
    ║                               ▼                                ║
    ║                        ┌─────────────┐                         ║
    ║                        │     END     │                         ║
    ║                        └─────────────┘                         ║
    ║                                                                ║
    ╚═══════════════════════════════════════════════════════════════╝
```

---

## Real-World Analogy: Assembly Line

Imagine a car assembly line:

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   STATION   │     │   STATION   │     │   STATION   │     │   STATION   │
│      1      │────▶│      2      │────▶│      3      │────▶│      4      │
│             │     │             │     │             │     │             │
│  Install    │     │   Install   │     │   Install   │     │   Quality   │
│   Frame     │     │   Engine    │     │    Doors    │     │   Check     │
└─────────────┘     └─────────────┘     └─────────────┘     └─────────────┘

     Each station MUST complete before the next can begin!
```

- You can't install doors before the frame exists
- You can't do quality check before all parts are installed
- Order matters!

---

## When to Use Sequential Workflows

✅ **Use sequential when:**

| Scenario | Example |
|----------|---------|
| Tasks have dependencies | Parse HTML → Extract data → Save to DB |
| Order matters for correctness | Authenticate → Authorize → Execute |
| Each step transforms data for the next | Raw text → Cleaned text → Analyzed text |
| Debugging/logging needs clear flow | Step-by-step audit trail |

⚠️ **Avoid sequential when:**

| Scenario | Better Pattern |
|----------|----------------|
| Tasks are independent | Parallel execution |
| Different paths based on input | Branching |
| Need to retry/refine | Cycles |

---

## Code Structure

```
Sequential Workflow Code Pattern:

    ┌────────────────────────────────────────────────────────────────┐
    │  1. DEFINE STATE                                               │
    │     ┌──────────────────────────────────────────────────────┐   │
    │     │  class State(TypedDict):                             │   │
    │     │      data: str                                       │   │
    │     │      step1_result: str                               │   │
    │     │      step2_result: str                               │   │
    │     │      final_result: str                               │   │
    │     └──────────────────────────────────────────────────────┘   │
    │                                                                │
    │  2. DEFINE NODES (functions)                                   │
    │     ┌──────────────────────────────────────────────────────┐   │
    │     │  def step1(state): ...                               │   │
    │     │  def step2(state): ...                               │   │
    │     │  def step3(state): ...                               │   │
    │     └──────────────────────────────────────────────────────┘   │
    │                                                                │
    │  3. BUILD GRAPH                                                │
    │     ┌──────────────────────────────────────────────────────┐   │
    │     │  graph = StateGraph(State)                           │   │
    │     │  graph.add_node("step1", step1)                      │   │
    │     │  graph.add_node("step2", step2)                      │   │
    │     │  graph.add_node("step3", step3)                      │   │
    │     └──────────────────────────────────────────────────────┘   │
    │                                                                │
    │  4. ADD EDGES (define order)                                   │
    │     ┌──────────────────────────────────────────────────────┐   │
    │     │  graph.add_edge(START, "step1")                      │   │
    │     │  graph.add_edge("step1", "step2")                    │   │
    │     │  graph.add_edge("step2", "step3")                    │   │
    │     │  graph.add_edge("step3", END)                        │   │
    │     └──────────────────────────────────────────────────────┘   │
    │                                                                │
    │  5. COMPILE & RUN                                              │
    │     ┌──────────────────────────────────────────────────────┐   │
    │     │  app = graph.compile()                               │   │
    │     │  result = app.invoke({"data": "input"})              │   │
    │     └──────────────────────────────────────────────────────┘   │
    └────────────────────────────────────────────────────────────────┘
```

---

## Data Flow in Sequential Workflows

```
    Input State                 After Step 1              After Step 2              Final State
    ┌──────────────┐            ┌──────────────┐          ┌──────────────┐          ┌──────────────┐
    │ data: "raw"  │            │ data: "raw"  │          │ data: "raw"  │          │ data: "raw"  │
    │ step1: None  │  ────▶     │ step1: "A"   │  ────▶   │ step1: "A"   │  ────▶   │ step1: "A"   │
    │ step2: None  │  Step 1    │ step2: None  │  Step 2  │ step2: "B"   │  Step 3  │ step2: "B"   │
    │ final: None  │            │ final: None  │          │ final: None  │          │ final: "C"   │
    └──────────────┘            └──────────────┘          └──────────────┘          └──────────────┘
    
    Each node reads the current state and adds/updates its portion!
```

---

## Common Sequential Patterns

### Pattern 1: ETL Pipeline (Extract-Transform-Load)

```
    ┌───────────────┐     ┌───────────────┐     ┌───────────────┐
    │    EXTRACT    │     │   TRANSFORM   │     │     LOAD      │
    │               │────▶│               │────▶│               │
    │  Fetch from   │     │   Clean &     │     │   Store in    │
    │   source      │     │   Process     │     │   database    │
    └───────────────┘     └───────────────┘     └───────────────┘
```

### Pattern 2: AI Processing Pipeline

```
    ┌───────────────┐     ┌───────────────┐     ┌───────────────┐     ┌───────────────┐
    │   PREPROCESS  │     │   ANALYZE     │     │   GENERATE    │     │  POSTPROCESS  │
    │               │────▶│               │────▶│               │────▶│               │
    │  Clean text,  │     │  Classify,    │     │  Create LLM   │     │  Format,      │
    │  tokenize     │     │  extract      │     │  response     │     │  validate     │
    └───────────────┘     └───────────────┘     └───────────────┘     └───────────────┘
```

### Pattern 3: Multi-Step Reasoning

```
    ┌───────────────┐     ┌───────────────┐     ┌───────────────┐     ┌───────────────┐
    │   UNDERSTAND  │     │   PLAN        │     │   EXECUTE     │     │   REVIEW      │
    │               │────▶│               │────▶│               │────▶│               │
    │  Parse user   │     │  Create       │     │  Carry out    │     │  Verify       │
    │  request      │     │  action plan  │     │  the plan     │     │  results      │
    └───────────────┘     └───────────────┘     └───────────────┘     └───────────────┘
```

---

## Key API: add_edge()

```python
graph.add_edge(source_node, target_node)
```

| Parameter | Description |
|-----------|-------------|
| `source_node` | Node that runs first (string name or START) |
| `target_node` | Node that runs next (string name or END) |

```
    add_edge("A", "B")
    
    ┌───────────┐         ┌───────────┐
    │     A     │────────▶│     B     │
    └───────────┘         └───────────┘
    
    "After A completes, always go to B"
```

---

## Special Nodes: START and END

```python
from langgraph.graph import START, END
```

```
    START                                END
    ┌─────────────┐                     ┌─────────────┐
    │   ◉ START   │                     │   ⬛ END    │
    │             │                     │             │
    │  Virtual    │                     │  Virtual    │
    │  entry      │                     │  exit       │
    │  point      │                     │  point      │
    └─────────────┘                     └─────────────┘
    
    START: Where execution begins (entry point to graph)
    END: Where execution stops (signals completion)
```

---

## Interview Tip

```
┌─────────────────────────────────────────────────────────────────────┐
│ 💡 INTERVIEW TIP                                                    │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│ Q: "When would you NOT use a sequential workflow?"                  │
│                                                                     │
│ A: "I would avoid sequential workflows when:                        │
│                                                                     │
│    1. Tasks are INDEPENDENT - Use parallel execution instead        │
│       to improve performance                                        │
│                                                                     │
│    2. Different PATHS are needed based on input - Use               │
│       conditional branching instead                                 │
│                                                                     │
│    3. ITERATION is required - Use cycles/loops when we need         │
│       to repeat steps until a condition is met                      │
│                                                                     │
│    Sequential is great for its SIMPLICITY and PREDICTABILITY,       │
│    but can be inefficient when parallelism is possible."            │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Execution Visualization

```
Timeline of Sequential Execution:

Time ──────────────────────────────────────────────────────────────────▶

     │         │              │              │              │
     │  START  │   Node A     │   Node B     │   Node C     │  END
     │    │    │   executes   │   executes   │   executes   │   │
     │    ▼    │              │              │              │   ▼
     ├─────────┼──────────────┼──────────────┼──────────────┼────────
     │    ●────┼──────●───────┼──────●───────┼──────●───────┼────●
     │         │      │       │      │       │      │       │
              t0     t1      t2     t3      t4     t5
     
     Total time = t1 + t2 + t3 (sum of all node execution times)
     
     Note: Each node must WAIT for the previous to complete!
```

---

## Best Practices

| Practice | Description |
|----------|-------------|
| **Single Responsibility** | Each node does ONE thing well |
| **Clear Naming** | Node names describe their action (e.g., "validate_input") |
| **Error Handling** | Handle failures at each step |
| **State Updates** | Only update state keys relevant to that node |
| **Logging** | Log entry/exit for debugging |

---

## Summary

```
┌─────────────────────────────────────────────────────────────────────┐
│                        KEY TAKEAWAYS                                │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ✅ Sequential workflows execute nodes in a fixed order             │
│                                                                     │
│  ✅ Use add_edge() to connect nodes in sequence                     │
│                                                                     │
│  ✅ START and END are special virtual nodes                         │
│                                                                     │
│  ✅ Best for dependent tasks where order matters                    │
│                                                                     │
│  ✅ Simple to debug and understand                                  │
│                                                                     │
│  ⚠️  Not optimal when tasks could run in parallel                   │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Next Steps

Now that you understand the theory, let's see it in action!
Continue to [02_sequential_example.py](./02_sequential_example.py) for a working code example.
