"""
Parallel Execution Example: Multi-Source Data Aggregation

This example demonstrates parallel execution patterns where we:
1. Fetch data from multiple sources simultaneously
2. Process each source's data in parallel
3. Aggregate all results into a unified report

Use Case: A dashboard that needs data from multiple APIs

Graph Structure:

                    ┌─────────────────┐
                    │      START      │
                    └────────┬────────┘
                             │
                             ▼
                    ┌─────────────────┐
                    │    Prepare      │
                    │    Sources      │
                    └────────┬────────┘
                             │
              ┌──────────────┼──────────────┐
              │              │              │
              ▼              ▼              ▼
        ┌───────────┐  ┌───────────┐  ┌───────────┐
        │  Fetch    │  │  Fetch    │  │  Fetch    │   PARALLEL!
        │  Source A │  │  Source B │  │  Source C │
        └─────┬─────┘  └─────┬─────┘  └─────┬─────┘
              │              │              │
              └──────────────┼──────────────┘
                             │
                             ▼
                    ┌─────────────────┐
                    │   Aggregate     │
                    │   Results       │
                    └────────┬────────┘
                             │
                             ▼
                    ┌─────────────────┐
                    │      END        │
                    └─────────────────┘
"""

from typing import TypedDict, List, Annotated
from langgraph.graph import StateGraph, START, END
from langgraph.constants import Send
import operator
import time
import random


# =============================================================================
# STEP 1: Define State with Reducer
# =============================================================================
# The key insight: we use Annotated with operator.add to combine
# results from parallel executions

class DataAggregationState(TypedDict):
    """
    State for multi-source data aggregation.

    Important: The 'fetched_data' field uses a reducer (operator.add)
    to combine results from parallel fetch operations.
    """
    # Input: List of sources to fetch from
    sources: List[str]

    # Results from parallel fetches
    # Annotated with operator.add means lists will be concatenated
    # When multiple parallel nodes return {"fetched_data": [...]},
    # all those lists are combined into one
    fetched_data: Annotated[List[dict], operator.add]

    # Final aggregated report
    report: dict

    # Metadata
    start_time: float
    total_fetch_time: float


# =============================================================================
# STEP 2: Define Node Functions
# =============================================================================

def prepare_sources(state: DataAggregationState) -> dict:
    """
    Node: Prepare Sources

    Initializes the state with sources to fetch.
    Records start time for performance tracking.
    """
    print("\n📋 Preparing data sources...")

    sources = ["finance_api", "weather_api", "news_api"]
    print(f"   Sources to fetch: {sources}")

    return {
        "sources": sources,
        "start_time": time.time(),
        "fetched_data": []  # Initialize empty
    }


def fetch_data_source(state: dict) -> dict:
    """
    Node: Fetch Data Source (PARALLEL WORKER)

    This node is called once for each data source.
    Multiple instances run in parallel.

    Note: This receives a partial state specific to this parallel instance.
    """
    source = state["source"]
    index = state["index"]

    print(f"\n🔄 [{index}] Fetching from: {source}")

    # Simulate API call with variable latency
    # In production, this would be actual API calls
    fetch_time = random.uniform(0.5, 2.0)
    time.sleep(fetch_time)  # Simulate network delay

    # Generate mock data based on source type
    if source == "finance_api":
        data = {
            "source": source,
            "data": {
                "stock_price": round(random.uniform(100, 500), 2),
                "market_cap": f"${random.randint(10, 500)}B",
                "daily_change": f"{random.uniform(-5, 5):.2f}%"
            },
            "fetch_time": round(fetch_time, 2)
        }
    elif source == "weather_api":
        data = {
            "source": source,
            "data": {
                "temperature": f"{random.randint(60, 90)}°F",
                "condition": random.choice(["Sunny", "Cloudy", "Rainy"]),
                "humidity": f"{random.randint(30, 80)}%"
            },
            "fetch_time": round(fetch_time, 2)
        }
    elif source == "news_api":
        data = {
            "source": source,
            "data": {
                "headline": "Breaking: AI Advances Continue",
                "sentiment": random.choice(["positive", "neutral", "negative"]),
                "article_count": random.randint(10, 100)
            },
            "fetch_time": round(fetch_time, 2)
        }
    else:
        data = {
            "source": source,
            "data": {"status": "unknown source"},
            "fetch_time": round(fetch_time, 2)
        }

    print(f"   ✅ [{index}] Completed {source} in {fetch_time:.2f}s")

    # Return as a list so the reducer can concatenate
    return {"fetched_data": [data]}


def distribute_fetches(state: DataAggregationState) -> List[Send]:
    """
    Router: Distribute to Parallel Workers

    This function uses the Send API to create parallel executions.
    Instead of returning a next node name, it returns a list of
    Send objects - one for each source to fetch.

    Each Send creates a parallel execution of the "fetch" node
    with its own isolated state.
    """
    sources = state["sources"]

    print(f"\n🚀 Distributing work to {len(sources)} parallel workers...")

    # Create a Send for each source
    # Send(node_name, state_for_that_worker)
    sends = [
        Send("fetch", {"source": source, "index": i})
        for i, source in enumerate(sources)
    ]

    return sends


def aggregate_results(state: DataAggregationState) -> dict:
    """
    Node: Aggregate Results (FAN-IN)

    This node runs after ALL parallel fetches complete.
    It receives the combined fetched_data from all workers
    (combined by the reducer).
    """
    print("\n📊 Aggregating results from all sources...")

    fetched_data = state["fetched_data"]
    start_time = state["start_time"]

    # Calculate total time (wall clock time, not sum of fetch times)
    total_time = time.time() - start_time

    # Sum up individual fetch times (what sequential would have taken)
    sequential_time = sum(d["fetch_time"] for d in fetched_data)

    # Create aggregated report
    report = {
        "sources_fetched": len(fetched_data),
        "data": {d["source"]: d["data"] for d in fetched_data},
        "performance": {
            "parallel_time": round(total_time, 2),
            "sequential_time_estimate": round(sequential_time, 2),
            "speedup": round(sequential_time / total_time, 2) if total_time > 0 else 0
        }
    }

    print(f"   Sources aggregated: {report['sources_fetched']}")
    print(f"   Parallel time: {report['performance']['parallel_time']}s")
    print(f"   Sequential estimate: {report['performance']['sequential_time_estimate']}s")
    print(f"   Speedup: {report['performance']['speedup']}x")

    return {
        "report": report,
        "total_fetch_time": total_time
    }


# =============================================================================
# STEP 3: Build the Graph
# =============================================================================

def create_aggregation_graph() -> StateGraph:
    """
    Creates the parallel data aggregation graph.

    Key points:
    1. prepare_sources initializes the work
    2. distribute_fetches uses Send API to create parallel tasks
    3. fetch nodes run in parallel
    4. aggregate_results collects all results (via reducer)
    """
    graph = StateGraph(DataAggregationState)

    # Add nodes
    graph.add_node("prepare", prepare_sources)
    graph.add_node("fetch", fetch_data_source)  # This will run in parallel!
    graph.add_node("aggregate", aggregate_results)

    # Define flow
    graph.add_edge(START, "prepare")

    # Use conditional edges with Send API for parallel fan-out
    graph.add_conditional_edges("prepare", distribute_fetches, ["fetch"])

    # All parallel fetches converge to aggregate
    graph.add_edge("fetch", "aggregate")

    graph.add_edge("aggregate", END)

    return graph


# =============================================================================
# STEP 4: Run the Example
# =============================================================================

def main():
    """
    Main function demonstrating parallel execution.
    """
    print("=" * 70)
    print("PARALLEL EXECUTION: Multi-Source Data Aggregation")
    print("=" * 70)

    # Create and compile the graph
    graph = create_aggregation_graph()
    app = graph.compile()

    # Initial state
    initial_state = {
        "sources": [],
        "fetched_data": [],
        "report": {},
        "start_time": 0.0,
        "total_fetch_time": 0.0
    }

    print("\n🏁 Starting parallel data aggregation...")
    print("   Watch for parallel fetch operations...")

    # Execute
    result = app.invoke(initial_state)

    # Display results
    print("\n" + "=" * 70)
    print("FINAL REPORT")
    print("=" * 70)

    report = result["report"]

    print("\n📈 Data by Source:")
    for source, data in report["data"].items():
        print(f"\n   {source}:")
        for key, value in data.items():
            print(f"      {key}: {value}")

    print("\n⚡ Performance:")
    perf = report["performance"]
    print(f"   Actual time (parallel): {perf['parallel_time']}s")
    print(f"   Would have taken (sequential): {perf['sequential_time_estimate']}s")
    print(f"   Speedup achieved: {perf['speedup']}x faster!")


# =============================================================================
# BONUS: Alternative Pattern with Static Fan-Out
# =============================================================================

class StaticFanOutState(TypedDict):
    """State for static fan-out pattern."""
    input_text: str
    analysis_results: Annotated[List[dict], operator.add]
    summary: str


def analyze_sentiment(state: StaticFanOutState) -> dict:
    """Parallel: Sentiment analysis."""
    print("   Running sentiment analysis...")
    time.sleep(0.5)
    return {
        "analysis_results": [{
            "type": "sentiment",
            "result": "positive",
            "confidence": 0.85
        }]
    }


def analyze_entities(state: StaticFanOutState) -> dict:
    """Parallel: Entity extraction."""
    print("   Running entity extraction...")
    time.sleep(0.5)
    return {
        "analysis_results": [{
            "type": "entities",
            "result": ["AI", "Technology", "Innovation"],
            "count": 3
        }]
    }


def analyze_topics(state: StaticFanOutState) -> dict:
    """Parallel: Topic classification."""
    print("   Running topic classification...")
    time.sleep(0.5)
    return {
        "analysis_results": [{
            "type": "topics",
            "result": ["Technology", "Business"],
            "primary": "Technology"
        }]
    }


def summarize_analyses(state: StaticFanOutState) -> dict:
    """Combine all parallel results."""
    results = state["analysis_results"]
    summary = f"Analyzed text with {len(results)} parallel analyses"
    return {"summary": summary}


def create_static_fanout_graph() -> StateGraph:
    """
    Creates a graph with static fan-out (known parallel branches).

    This pattern is simpler when you know exactly which
    parallel operations you need at graph build time.
    """
    graph = StateGraph(StaticFanOutState)

    # Add all analysis nodes
    graph.add_node("sentiment", analyze_sentiment)
    graph.add_node("entities", analyze_entities)
    graph.add_node("topics", analyze_topics)
    graph.add_node("summarize", summarize_analyses)

    # Fan-out: Multiple edges from START
    # These can run in parallel!
    graph.add_edge(START, "sentiment")
    graph.add_edge(START, "entities")
    graph.add_edge(START, "topics")

    # Fan-in: All analyses go to summarize
    graph.add_edge("sentiment", "summarize")
    graph.add_edge("entities", "summarize")
    graph.add_edge("topics", "summarize")

    graph.add_edge("summarize", END)

    return graph


def demonstrate_static_fanout():
    """Demonstrates the static fan-out pattern."""
    print("\n" + "=" * 70)
    print("STATIC FAN-OUT PATTERN")
    print("=" * 70)

    graph = create_static_fanout_graph()
    app = graph.compile()

    result = app.invoke({
        "input_text": "AI technology is transforming businesses worldwide.",
        "analysis_results": [],
        "summary": ""
    })

    print(f"\n📊 Results: {len(result['analysis_results'])} analyses completed")
    for analysis in result["analysis_results"]:
        print(f"   - {analysis['type']}: {analysis['result']}")


# =============================================================================
# INTERVIEW TIP
# =============================================================================
"""
┌─────────────────────────────────────────────────────────────────────┐
│ 💡 INTERVIEW TIP                                                    │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│ Q: "When would you use Send API vs static fan-out edges?"           │
│                                                                     │
│ A: "The choice depends on whether the parallel tasks are known      │
│    at graph build time or runtime:                                  │
│                                                                     │
│    STATIC FAN-OUT (multiple edges from same source):                │
│    - Use when parallel branches are known at BUILD time             │
│    - Example: Always run sentiment + entity + topic analysis        │
│    - Simpler to implement and understand                            │
│    - Fixed number of parallel paths                                 │
│                                                                     │
│    SEND API (dynamic fan-out):                                      │
│    - Use when parallel tasks determined at RUNTIME                  │
│    - Example: Process N documents where N varies per request        │
│    - More flexible but slightly more complex                        │
│    - Number of parallel paths can vary per execution                │
│                                                                     │
│    Example comparison:                                              │
│    - 'Analyze this text with 3 specific models' → Static            │
│    - 'Process all items in this list' → Send API                    │
│                                                                     │
│    Both use reducers for fan-in. The key difference is              │
│    compile-time vs runtime determination of parallelism."           │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
"""


# =============================================================================
# BONUS: Demonstrating Reducer Behavior
# =============================================================================

def demonstrate_reducer():
    """
    Shows exactly how reducers combine parallel updates.
    """
    print("\n" + "=" * 70)
    print("REDUCER DEMONSTRATION")
    print("=" * 70)

    print("""
    Without reducer (last write wins):
    ┌─────────────┐     ┌─────────────┐     ┌─────────────┐
    │  Worker 1   │     │  Worker 2   │     │  Worker 3   │
    │ result="A"  │     │ result="B"  │     │ result="C"  │
    └──────┬──────┘     └──────┬──────┘     └──────┬──────┘
           │                   │                   │
           └───────────────────┼───────────────────┘
                               ▼
                     Final: result="C"  ← Only last one!

    With reducer (operator.add for lists):
    ┌─────────────┐     ┌─────────────┐     ┌─────────────┐
    │  Worker 1   │     │  Worker 2   │     │  Worker 3   │
    │result=["A"] │     │result=["B"] │     │result=["C"] │
    └──────┬──────┘     └──────┬──────┘     └──────┬──────┘
           │                   │                   │
           └───────────────────┼───────────────────┘
                               ▼
                  Final: result=["A","B","C"]  ← All combined!
    """)

    print("   The Annotated[List[T], operator.add] pattern ensures")
    print("   all parallel results are preserved and combined.")


if __name__ == "__main__":
    # Run the main parallel example
    main()

    # Show static fan-out alternative
    demonstrate_static_fanout()

    # Explain reducer behavior
    demonstrate_reducer()
