"""
Cycles/Loops Example: Self-Correcting Code Generator

This example demonstrates a loop pattern where an AI agent:
1. Generates code based on a specification
2. Runs tests on the code
3. If tests fail, analyzes errors and regenerates
4. Continues until tests pass OR max iterations reached

Graph Structure:

    ┌─────────────────┐
    │     START       │
    └────────┬────────┘
             │
             ▼
    ┌─────────────────┐
    │    generate     │◄─────────────────────────────┐
    │     code        │                              │
    └────────┬────────┘                              │
             │                                       │
             ▼                                       │
    ┌─────────────────┐                              │
    │   run_tests     │                              │
    └────────┬────────┘                              │
             │                                       │
             ▼                                       │
    ┌─────────────────┐                              │
    │  check_results  │──── tests failed ────────────┘
    └────────┬────────┘      & attempts left
             │
      tests passed
      OR max attempts
             │
             ▼
    ┌─────────────────┐
    │      END        │
    └─────────────────┘
"""

from typing import TypedDict, List, Optional
from langgraph.graph import StateGraph, START, END
import re


# =============================================================================
# STEP 1: Define the State
# =============================================================================

class CodeGenState(TypedDict):
    """
    State for code generation loop.

    Attributes:
        specification: What the code should do
        generated_code: The current version of generated code
        test_results: Results from running tests
        errors: List of error messages from failed tests
        iteration: Current iteration number
        max_iterations: Maximum allowed iterations
        is_complete: Whether the task is finished (success or max attempts)
        history: List of all attempts for debugging
    """
    specification: str
    generated_code: str
    test_results: dict
    errors: List[str]
    iteration: int
    max_iterations: int
    is_complete: bool
    history: List[dict]


# =============================================================================
# STEP 2: Define Node Functions
# =============================================================================

def generate_code(state: CodeGenState) -> dict:
    """
    Node: Generate Code

    This node generates code based on the specification.
    If there are errors from previous iterations, it incorporates
    feedback to fix the issues.

    In production, this would call an LLM like Claude.
    """
    iteration = state["iteration"] + 1
    spec = state["specification"]
    errors = state.get("errors", [])

    print(f"\n{'='*50}")
    print(f"🔧 ITERATION {iteration}: Generating code...")
    print(f"{'='*50}")

    # Simulated code generation based on specification and iteration
    # In real scenarios, this would be an LLM call

    if "add two numbers" in spec.lower():
        # Simulate progressively better code over iterations
        if iteration == 1:
            # First attempt: Has a bug (uses subtraction)
            code = """
def add_numbers(a, b):
    # BUG: Accidentally using subtraction
    return a - b
"""
            print("   Generated initial code (with intentional bug)")

        elif iteration == 2:
            # Second attempt: Fixed subtraction but missing type handling
            code = """
def add_numbers(a, b):
    return a + b
"""
            print("   Fixed subtraction bug, but no type validation")

        else:
            # Third+ attempt: Fully correct with type handling
            code = """
def add_numbers(a, b):
    # Validate inputs
    if not isinstance(a, (int, float)):
        raise TypeError(f"Expected number, got {type(a)}")
    if not isinstance(b, (int, float)):
        raise TypeError(f"Expected number, got {type(b)}")
    return a + b
"""
            print("   Generated robust version with type checking")

    else:
        # Generic code for other specifications
        code = f"""
def process(data):
    # Generated for: {spec}
    return f"Processed: {{data}}"
"""

    # Record this attempt in history
    history_entry = {
        "iteration": iteration,
        "code": code,
        "errors_addressed": errors.copy() if errors else []
    }

    current_history = state.get("history", [])

    return {
        "generated_code": code,
        "iteration": iteration,
        "errors": [],  # Clear errors for fresh test run
        "history": current_history + [history_entry]
    }


def run_tests(state: CodeGenState) -> dict:
    """
    Node: Run Tests

    Executes tests against the generated code.
    Returns test results and any error messages.

    In production, this would actually execute the code
    and run a test suite.
    """
    print(f"\n🧪 Running tests on generated code...")

    code = state["generated_code"]
    iteration = state["iteration"]

    # Simulated test execution
    # In real scenarios, you'd use exec() or subprocess

    test_results = {
        "total_tests": 3,
        "passed": 0,
        "failed": 0,
        "errors": []
    }

    # Simulate different test outcomes based on code quality
    # This mimics discovering bugs through testing

    if "a - b" in code:
        # Code has the subtraction bug
        test_results["passed"] = 1
        test_results["failed"] = 2
        test_results["errors"] = [
            "Test 'test_add_positive': Expected 5, got -1 for add_numbers(2, 3)",
            "Test 'test_add_negative': Expected -5, got 5 for add_numbers(-2, -3)"
        ]
        print(f"   ❌ Tests FAILED: {test_results['failed']}/{test_results['total_tests']}")

    elif "isinstance" not in code and "add_numbers" in code:
        # Code works but lacks input validation
        test_results["passed"] = 2
        test_results["failed"] = 1
        test_results["errors"] = [
            "Test 'test_type_error': Expected TypeError for add_numbers('a', 2), but got 'a2'"
        ]
        print(f"   ⚠️ Partial pass: {test_results['passed']}/{test_results['total_tests']}")

    else:
        # Code passes all tests
        test_results["passed"] = 3
        test_results["failed"] = 0
        test_results["errors"] = []
        print(f"   ✅ All tests PASSED: {test_results['passed']}/{test_results['total_tests']}")

    return {
        "test_results": test_results,
        "errors": test_results["errors"]
    }


def check_results(state: CodeGenState) -> dict:
    """
    Node: Check Results

    Evaluates test results to determine if we should:
    - Mark as complete (tests passed)
    - Mark as complete (max iterations reached)
    - Continue iterating (tests failed, attempts remaining)
    """
    print(f"\n📊 Checking results...")

    test_results = state["test_results"]
    iteration = state["iteration"]
    max_iterations = state["max_iterations"]

    # Check if all tests passed
    all_passed = test_results["failed"] == 0

    # Check if we've hit the iteration limit
    at_limit = iteration >= max_iterations

    if all_passed:
        print(f"   🎉 SUCCESS! All tests passed on iteration {iteration}")
        is_complete = True
    elif at_limit:
        print(f"   ⏰ TIMEOUT: Max iterations ({max_iterations}) reached")
        print(f"   Final status: {test_results['passed']}/{test_results['total_tests']} tests passing")
        is_complete = True
    else:
        remaining = max_iterations - iteration
        print(f"   🔄 Tests failed. {remaining} attempts remaining. Continuing...")
        is_complete = False

    return {"is_complete": is_complete}


# =============================================================================
# STEP 3: Define the Router Function (Loop Control)
# =============================================================================

def should_continue(state: CodeGenState) -> str:
    """
    Router Function: Controls the loop.

    Decides whether to:
    - Loop back to generate_code for another attempt
    - Exit to END if complete

    This is the KEY function that creates the cycle!
    """
    if state["is_complete"]:
        print("\n➡️  Routing to: END")
        return END
    else:
        print("\n➡️  Routing to: generate_code (loop back)")
        return "generate_code"


# =============================================================================
# STEP 4: Build the Graph with Cycle
# =============================================================================

def create_code_gen_graph() -> StateGraph:
    """
    Creates the self-correcting code generation graph.

    The key cycle is created by:
    1. check_results can route back to generate_code
    2. This creates the loop: generate → test → check → (generate again or END)
    """
    graph = StateGraph(CodeGenState)

    # Add nodes
    graph.add_node("generate_code", generate_code)
    graph.add_node("run_tests", run_tests)
    graph.add_node("check_results", check_results)

    # Define the flow

    # Entry point: Start with code generation
    graph.add_edge(START, "generate_code")

    # Sequential: generate → test → check
    graph.add_edge("generate_code", "run_tests")
    graph.add_edge("run_tests", "check_results")

    # THE CYCLE: check_results decides to loop back or exit
    graph.add_conditional_edges(
        "check_results",
        should_continue,
        {
            "generate_code": "generate_code",  # Loop back
            END: END                            # Exit
        }
    )

    return graph


# =============================================================================
# STEP 5: Run the Example
# =============================================================================

def main():
    """
    Main function demonstrating the self-correcting loop.
    """
    print("=" * 60)
    print("CYCLE/LOOP PATTERN: Self-Correcting Code Generator")
    print("=" * 60)

    # Create and compile the graph
    graph = create_code_gen_graph()

    # IMPORTANT: Set recursion_limit as a safety measure
    # This is LangGraph's built-in protection against infinite loops
    app = graph.compile(
        recursion_limit=15  # Max number of node transitions
    )

    # Prepare initial state
    initial_state = {
        "specification": "Create a function to add two numbers",
        "generated_code": "",
        "test_results": {},
        "errors": [],
        "iteration": 0,
        "max_iterations": 5,  # Our own limit (separate from recursion_limit)
        "is_complete": False,
        "history": []
    }

    print(f"\n📋 Specification: {initial_state['specification']}")
    print(f"📊 Max iterations: {initial_state['max_iterations']}")

    # Execute the workflow
    result = app.invoke(initial_state)

    # Display final results
    print("\n" + "=" * 60)
    print("FINAL RESULTS")
    print("=" * 60)

    print(f"\n✅ Completed in {result['iteration']} iteration(s)")
    print(f"\n📝 Final Code:")
    print("-" * 40)
    print(result["generated_code"])

    print(f"\n📊 Test Results:")
    print(f"   Passed: {result['test_results']['passed']}")
    print(f"   Failed: {result['test_results']['failed']}")

    print(f"\n📜 Iteration History:")
    for entry in result["history"]:
        print(f"   Iteration {entry['iteration']}: Generated code")
        if entry["errors_addressed"]:
            print(f"      Addressed: {entry['errors_addressed'][:1]}...")


def demonstrate_early_termination():
    """
    Shows what happens when max iterations is reached without success.
    """
    print("\n" + "=" * 60)
    print("EARLY TERMINATION DEMO (Max Iterations = 1)")
    print("=" * 60)

    graph = create_code_gen_graph()
    app = graph.compile(recursion_limit=15)

    # Set max_iterations to 1 - will stop after first attempt
    initial_state = {
        "specification": "Create a function to add two numbers",
        "generated_code": "",
        "test_results": {},
        "errors": [],
        "iteration": 0,
        "max_iterations": 1,  # Only one attempt allowed!
        "is_complete": False,
        "history": []
    }

    result = app.invoke(initial_state)

    print(f"\n📊 Result: Stopped at iteration {result['iteration']}")
    print(f"   Tests passing: {result['test_results']['passed']}/{result['test_results']['total_tests']}")
    print(f"   (Code still has bugs because only 1 iteration allowed)")


# =============================================================================
# BONUS: Streaming to Watch the Loop
# =============================================================================

def demonstrate_streaming():
    """
    Shows how to watch the loop execute in real-time using streaming.
    """
    print("\n" + "=" * 60)
    print("STREAMING DEMO: Watch the Loop Execute")
    print("=" * 60)

    graph = create_code_gen_graph()
    app = graph.compile(recursion_limit=15)

    initial_state = {
        "specification": "Create a function to add two numbers",
        "generated_code": "",
        "test_results": {},
        "errors": [],
        "iteration": 0,
        "max_iterations": 5,
        "is_complete": False,
        "history": []
    }

    print("\n🔄 Streaming execution...\n")

    for event in app.stream(initial_state):
        for node_name, output in event.items():
            print(f"📍 Node completed: {node_name}")
            if "iteration" in output:
                print(f"   Current iteration: {output['iteration']}")
            if "test_results" in output and output["test_results"]:
                tr = output["test_results"]
                print(f"   Tests: {tr['passed']} passed, {tr['failed']} failed")


# =============================================================================
# INTERVIEW TIP
# =============================================================================
"""
┌─────────────────────────────────────────────────────────────────────┐
│ 💡 INTERVIEW TIP                                                    │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│ Q: "How would you implement exponential backoff in a retry loop?"   │
│                                                                     │
│ A: "I would track the attempt number in state and calculate         │
│    the delay accordingly:                                           │
│                                                                     │
│    class State(TypedDict):                                          │
│        attempt: int                                                 │
│        base_delay: float  # e.g., 1.0 seconds                       │
│        max_delay: float   # e.g., 60.0 seconds                      │
│                                                                     │
│    def retry_with_backoff(state):                                   │
│        delay = min(                                                 │
│            state['base_delay'] * (2 ** state['attempt']),           │
│            state['max_delay']                                       │
│        )                                                            │
│        # Add jitter to prevent thundering herd                      │
│        delay = delay * (0.5 + random.random())                      │
│        time.sleep(delay)                                            │
│        return {'attempt': state['attempt'] + 1}                     │
│                                                                     │
│    This gives delays of ~1s, ~2s, ~4s, ~8s... up to max_delay.     │
│    The jitter prevents multiple instances from retrying             │
│    at exactly the same time."                                       │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
"""


# =============================================================================
# BONUS: ReAct Pattern (Reasoning + Acting)
# =============================================================================

class AgentState(TypedDict):
    """State for a simple ReAct agent."""
    task: str
    thoughts: List[str]
    actions: List[str]
    observations: List[str]
    iteration: int
    max_iterations: int
    is_complete: bool


def think(state: AgentState) -> dict:
    """Agent thinks about what to do next."""
    iteration = state["iteration"] + 1
    task = state["task"]
    observations = state.get("observations", [])

    # Simulate thinking based on observations
    if not observations:
        thought = f"I need to accomplish: {task}. Let me start by gathering information."
    elif len(observations) < 2:
        thought = "I have some information. Let me gather more to complete the task."
    else:
        thought = "I now have enough information to complete the task."

    return {
        "thoughts": state["thoughts"] + [thought],
        "iteration": iteration
    }


def act(state: AgentState) -> dict:
    """Agent takes an action."""
    iteration = state["iteration"]

    # Simulate different actions based on iteration
    actions_sequence = [
        "search(query='relevant information')",
        "analyze(data=search_results)",
        "synthesize(analysis=analysis_results)"
    ]

    action_idx = min(iteration - 1, len(actions_sequence) - 1)
    action = actions_sequence[action_idx]

    return {"actions": state["actions"] + [action]}


def observe(state: AgentState) -> dict:
    """Agent observes the result of its action."""
    latest_action = state["actions"][-1] if state["actions"] else ""

    # Simulate observations
    if "search" in latest_action:
        observation = "Found 3 relevant documents"
    elif "analyze" in latest_action:
        observation = "Analysis complete: key insights extracted"
    else:
        observation = "Task completed successfully"

    # Check if task is complete
    is_complete = state["iteration"] >= 3  # Simple completion condition

    return {
        "observations": state["observations"] + [observation],
        "is_complete": is_complete
    }


def create_react_agent() -> StateGraph:
    """Creates a simple ReAct agent graph."""
    graph = StateGraph(AgentState)

    graph.add_node("think", think)
    graph.add_node("act", act)
    graph.add_node("observe", observe)

    graph.add_edge(START, "think")
    graph.add_edge("think", "act")
    graph.add_edge("act", "observe")

    def should_continue_react(state):
        if state["is_complete"]:
            return END
        if state["iteration"] >= state["max_iterations"]:
            return END
        return "think"  # Loop back

    graph.add_conditional_edges("observe", should_continue_react)

    return graph


if __name__ == "__main__":
    # Run the main self-correcting code generator example
    main()

    # Show early termination behavior
    demonstrate_early_termination()

    # Show streaming
    demonstrate_streaming()
