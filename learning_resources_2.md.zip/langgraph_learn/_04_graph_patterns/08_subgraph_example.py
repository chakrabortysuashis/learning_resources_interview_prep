"""
Subgraph Example: Modular Document Processing Pipeline

This example demonstrates how to create reusable subgraphs:
1. A validation subgraph for input validation
2. An enrichment subgraph for adding metadata
3. A parent graph that composes these subgraphs

Architecture:

    ┌─────────────────────────────────────────────────────────────────────┐
    │                         PARENT GRAPH                                │
    │                                                                     │
    │   ┌─────────┐     ┌───────────────────┐     ┌───────────────────┐  │
    │   │ Receive │     │   VALIDATION      │     │   ENRICHMENT      │  │
    │   │ Input   │────▶│   SUBGRAPH        │────▶│   SUBGRAPH        │──┤
    │   └─────────┘     │ ┌─────┐ ┌─────┐   │     │ ┌─────┐ ┌─────┐   │  │
    │                   │ │Check│→│Clean│   │     │ │Meta │→│Tags │   │  │
    │                   │ └─────┘ └─────┘   │     │ └─────┘ └─────┘   │  │
    │                   └───────────────────┘     └───────────────────┘  │
    │                                                          │         │
    │                                                          ▼         │
    │                                                    ┌───────────┐   │
    │                                                    │  Output   │   │
    │                                                    │  Result   │   │
    │                                                    └───────────┘   │
    │                                                                     │
    └─────────────────────────────────────────────────────────────────────┘
"""

from typing import TypedDict, List, Optional
from langgraph.graph import StateGraph, START, END
import re
from datetime import datetime


# =============================================================================
# SECTION 1: VALIDATION SUBGRAPH
# =============================================================================
# This subgraph handles input validation and is reusable across applications

class ValidationState(TypedDict):
    """
    State for the validation subgraph.

    This is the interface contract for the validation subgraph.
    Any parent using this subgraph must provide these keys.
    """
    raw_input: str              # Input to validate
    cleaned_input: str          # Cleaned version
    is_valid: bool              # Validation result
    validation_errors: List[str]  # List of errors found


def check_format(state: ValidationState) -> dict:
    """
    Validation Step 1: Check Format

    Validates that the input meets basic format requirements:
    - Not empty
    - Not too short
    - Not too long
    - Contains actual content (not just whitespace)
    """
    print("   [Validation] Checking format...")

    raw_input = state["raw_input"]
    errors = []

    # Check for empty input
    if not raw_input or not raw_input.strip():
        errors.append("Input cannot be empty")

    # Check minimum length
    elif len(raw_input.strip()) < 10:
        errors.append("Input must be at least 10 characters")

    # Check maximum length
    elif len(raw_input) > 10000:
        errors.append("Input exceeds maximum length of 10000 characters")

    is_valid = len(errors) == 0

    return {
        "is_valid": is_valid,
        "validation_errors": errors
    }


def clean_input(state: ValidationState) -> dict:
    """
    Validation Step 2: Clean Input

    Sanitizes the input by:
    - Removing extra whitespace
    - Stripping leading/trailing spaces
    - Normalizing line endings
    """
    print("   [Validation] Cleaning input...")

    # Only clean if validation passed
    if not state["is_valid"]:
        return {"cleaned_input": ""}

    raw_input = state["raw_input"]

    # Clean the input
    cleaned = raw_input.strip()
    cleaned = re.sub(r'\s+', ' ', cleaned)  # Normalize whitespace
    cleaned = re.sub(r'\n+', '\n', cleaned)  # Normalize newlines

    return {"cleaned_input": cleaned}


def create_validation_subgraph() -> StateGraph:
    """
    Creates and returns the validation subgraph.

    This subgraph can be reused in any parent graph that needs
    input validation.
    """
    graph = StateGraph(ValidationState)

    graph.add_node("check_format", check_format)
    graph.add_node("clean_input", clean_input)

    graph.add_edge(START, "check_format")
    graph.add_edge("check_format", "clean_input")
    graph.add_edge("clean_input", END)

    return graph


# =============================================================================
# SECTION 2: ENRICHMENT SUBGRAPH
# =============================================================================
# This subgraph adds metadata and tags to documents

class EnrichmentState(TypedDict):
    """
    State for the enrichment subgraph.
    """
    content: str                 # Content to enrich
    metadata: dict               # Generated metadata
    tags: List[str]             # Generated tags
    enrichment_complete: bool    # Whether enrichment succeeded


def generate_metadata(state: EnrichmentState) -> dict:
    """
    Enrichment Step 1: Generate Metadata

    Creates metadata about the content:
    - Word count
    - Character count
    - Processing timestamp
    - Content hash (for deduplication)
    """
    print("   [Enrichment] Generating metadata...")

    content = state["content"]

    # Generate metadata
    metadata = {
        "word_count": len(content.split()),
        "char_count": len(content),
        "processed_at": datetime.now().isoformat(),
        "content_hash": hash(content) % 10**8,  # Simple hash
        "language": "en"  # In production, use language detection
    }

    return {"metadata": metadata}


def generate_tags(state: EnrichmentState) -> dict:
    """
    Enrichment Step 2: Generate Tags

    Automatically tags content based on keywords.
    In production, this could use an LLM for better tagging.
    """
    print("   [Enrichment] Generating tags...")

    content = state["content"].lower()

    # Simple keyword-based tagging
    # In production, use NLP or LLM for better results
    tag_keywords = {
        "technology": ["ai", "machine learning", "software", "computer", "data", "algorithm"],
        "business": ["company", "market", "revenue", "profit", "strategy", "growth"],
        "science": ["research", "study", "experiment", "hypothesis", "theory"],
        "education": ["learn", "course", "student", "teacher", "university"],
        "health": ["medical", "health", "patient", "treatment", "disease"]
    }

    tags = []
    for tag, keywords in tag_keywords.items():
        if any(keyword in content for keyword in keywords):
            tags.append(tag)

    # Add default tag if no matches
    if not tags:
        tags.append("general")

    return {
        "tags": tags,
        "enrichment_complete": True
    }


def create_enrichment_subgraph() -> StateGraph:
    """
    Creates and returns the enrichment subgraph.
    """
    graph = StateGraph(EnrichmentState)

    graph.add_node("generate_metadata", generate_metadata)
    graph.add_node("generate_tags", generate_tags)

    graph.add_edge(START, "generate_metadata")
    graph.add_edge("generate_metadata", "generate_tags")
    graph.add_edge("generate_tags", END)

    return graph


# =============================================================================
# SECTION 3: PARENT GRAPH
# =============================================================================
# The parent graph composes the subgraphs into a complete pipeline

class DocumentState(TypedDict):
    """
    State for the parent document processing graph.

    Note: This includes keys from both subgraph states!
    The subgraphs will read/write to their respective keys.
    """
    # Input
    raw_input: str

    # From validation subgraph
    cleaned_input: str
    is_valid: bool
    validation_errors: List[str]

    # For enrichment subgraph (maps cleaned_input -> content)
    content: str

    # From enrichment subgraph
    metadata: dict
    tags: List[str]
    enrichment_complete: bool

    # Final output
    final_result: dict


def receive_input(state: DocumentState) -> dict:
    """
    Parent Node 1: Receive Input

    Prepares the initial state for processing.
    """
    print("\n📥 Receiving input...")
    print(f"   Input length: {len(state['raw_input'])} characters")

    return {
        "is_valid": False,
        "validation_errors": [],
        "cleaned_input": "",
        "content": "",
        "metadata": {},
        "tags": [],
        "enrichment_complete": False
    }


def prepare_for_enrichment(state: DocumentState) -> dict:
    """
    Parent Node 2: Prepare for Enrichment

    This is a "bridge" node that transforms state between subgraphs.
    It copies cleaned_input to content for the enrichment subgraph.
    """
    print("\n🔄 Preparing for enrichment...")

    if not state["is_valid"]:
        print("   ⚠️ Skipping enrichment - validation failed")
        return {"content": ""}

    # Map cleaned_input to content for enrichment subgraph
    return {"content": state["cleaned_input"]}


def compile_result(state: DocumentState) -> dict:
    """
    Parent Node 3: Compile Result

    Aggregates all results into a final output structure.
    """
    print("\n📋 Compiling final result...")

    if not state["is_valid"]:
        final_result = {
            "success": False,
            "error": "Validation failed",
            "validation_errors": state["validation_errors"],
            "document": None
        }
    else:
        final_result = {
            "success": True,
            "document": {
                "content": state["content"],
                "metadata": state["metadata"],
                "tags": state["tags"]
            },
            "validation_errors": []
        }

    return {"final_result": final_result}


def should_continue_to_enrichment(state: DocumentState) -> str:
    """
    Router: Decide whether to continue to enrichment or skip.
    """
    if state["is_valid"]:
        return "prepare_enrichment"
    else:
        return "compile_result"


def create_document_pipeline() -> StateGraph:
    """
    Creates the parent graph that composes the subgraphs.
    """
    # First, create and compile the subgraphs
    validation_subgraph = create_validation_subgraph().compile()
    enrichment_subgraph = create_enrichment_subgraph().compile()

    # Create the parent graph
    graph = StateGraph(DocumentState)

    # Add parent nodes
    graph.add_node("receive_input", receive_input)
    graph.add_node("prepare_enrichment", prepare_for_enrichment)
    graph.add_node("compile_result", compile_result)

    # Add subgraphs as nodes!
    # They look like regular nodes to the parent graph
    graph.add_node("validate", validation_subgraph)    # <-- Subgraph!
    graph.add_node("enrich", enrichment_subgraph)       # <-- Subgraph!

    # Define the flow
    graph.add_edge(START, "receive_input")
    graph.add_edge("receive_input", "validate")

    # After validation, decide whether to continue
    graph.add_conditional_edges(
        "validate",
        should_continue_to_enrichment,
        {
            "prepare_enrichment": "prepare_enrichment",
            "compile_result": "compile_result"
        }
    )

    graph.add_edge("prepare_enrichment", "enrich")
    graph.add_edge("enrich", "compile_result")
    graph.add_edge("compile_result", END)

    return graph


# =============================================================================
# SECTION 4: RUNNING THE EXAMPLES
# =============================================================================

def main():
    """
    Demonstrates the subgraph composition pattern.
    """
    print("=" * 70)
    print("SUBGRAPH PATTERN: Modular Document Processing Pipeline")
    print("=" * 70)

    # Create and compile the full pipeline
    pipeline = create_document_pipeline()
    app = pipeline.compile()

    # Test Case 1: Valid input
    print("\n" + "=" * 70)
    print("TEST CASE 1: Valid Input")
    print("=" * 70)

    valid_input = """
    Artificial Intelligence and Machine Learning are transforming the software
    industry. Companies are investing heavily in AI research to gain competitive
    advantage in the market. Data scientists are in high demand.
    """

    result1 = app.invoke({
        "raw_input": valid_input,
        "cleaned_input": "",
        "is_valid": False,
        "validation_errors": [],
        "content": "",
        "metadata": {},
        "tags": [],
        "enrichment_complete": False,
        "final_result": {}
    })

    print("\n📊 Result:")
    print(f"   Success: {result1['final_result']['success']}")
    if result1['final_result']['success']:
        doc = result1['final_result']['document']
        print(f"   Tags: {doc['tags']}")
        print(f"   Word count: {doc['metadata']['word_count']}")
        print(f"   Processed at: {doc['metadata']['processed_at']}")

    # Test Case 2: Invalid input (too short)
    print("\n" + "=" * 70)
    print("TEST CASE 2: Invalid Input (too short)")
    print("=" * 70)

    invalid_input = "Hi"

    result2 = app.invoke({
        "raw_input": invalid_input,
        "cleaned_input": "",
        "is_valid": False,
        "validation_errors": [],
        "content": "",
        "metadata": {},
        "tags": [],
        "enrichment_complete": False,
        "final_result": {}
    })

    print("\n📊 Result:")
    print(f"   Success: {result2['final_result']['success']}")
    print(f"   Errors: {result2['final_result']['validation_errors']}")


def demonstrate_subgraph_testing():
    """
    Shows how subgraphs can be tested independently.
    """
    print("\n" + "=" * 70)
    print("INDEPENDENT SUBGRAPH TESTING")
    print("=" * 70)

    # Test validation subgraph independently
    print("\n🧪 Testing Validation Subgraph independently...")

    validation_graph = create_validation_subgraph()
    validation_app = validation_graph.compile()

    # Test with valid input
    val_result = validation_app.invoke({
        "raw_input": "This is a valid test input for validation",
        "cleaned_input": "",
        "is_valid": False,
        "validation_errors": []
    })

    print(f"   Valid input test:")
    print(f"   - is_valid: {val_result['is_valid']}")
    print(f"   - cleaned: '{val_result['cleaned_input'][:30]}...'")

    # Test enrichment subgraph independently
    print("\n🧪 Testing Enrichment Subgraph independently...")

    enrichment_graph = create_enrichment_subgraph()
    enrichment_app = enrichment_graph.compile()

    enrich_result = enrichment_app.invoke({
        "content": "Machine learning and AI research at the university",
        "metadata": {},
        "tags": [],
        "enrichment_complete": False
    })

    print(f"   Enrichment test:")
    print(f"   - tags: {enrich_result['tags']}")
    print(f"   - word_count: {enrich_result['metadata']['word_count']}")


def demonstrate_subgraph_reuse():
    """
    Shows how the same subgraph can be used in different parent graphs.
    """
    print("\n" + "=" * 70)
    print("SUBGRAPH REUSE DEMONSTRATION")
    print("=" * 70)

    # Compile validation subgraph once
    validation_subgraph = create_validation_subgraph().compile()

    # Use in a simple validation-only pipeline
    class SimpleState(TypedDict):
        raw_input: str
        cleaned_input: str
        is_valid: bool
        validation_errors: List[str]
        result_message: str

    def report_result(state):
        if state["is_valid"]:
            return {"result_message": f"Valid: {state['cleaned_input'][:20]}..."}
        else:
            return {"result_message": f"Invalid: {state['validation_errors']}"}

    simple_graph = StateGraph(SimpleState)
    simple_graph.add_node("validate", validation_subgraph)  # Reusing!
    simple_graph.add_node("report", report_result)
    simple_graph.add_edge(START, "validate")
    simple_graph.add_edge("validate", "report")
    simple_graph.add_edge("report", END)

    simple_app = simple_graph.compile()

    result = simple_app.invoke({
        "raw_input": "This is a test of reusing the validation subgraph",
        "cleaned_input": "",
        "is_valid": False,
        "validation_errors": [],
        "result_message": ""
    })

    print(f"\n   Simple pipeline using validation subgraph:")
    print(f"   {result['result_message']}")
    print(f"\n   The same validation_subgraph can be used in multiple parent graphs!")


# =============================================================================
# INTERVIEW TIP
# =============================================================================
"""
┌─────────────────────────────────────────────────────────────────────┐
│ 💡 INTERVIEW TIP                                                    │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│ Q: "How do you handle state schema mismatches between parent        │
│     and subgraph?"                                                  │
│                                                                     │
│ A: "There are several approaches:                                   │
│                                                                     │
│    1. SHARED KEYS: The simplest approach - ensure both parent       │
│       and subgraph states have overlapping keys. The subgraph       │
│       reads/writes to these shared keys.                            │
│                                                                     │
│    2. BRIDGE NODES: Add transformation nodes in the parent that     │
│       map parent state keys to subgraph expectations before the     │
│       subgraph, and map back after.                                 │
│                                                                     │
│    3. WRAPPER FUNCTION: Instead of adding the compiled subgraph     │
│       directly, wrap it in a function that handles state mapping:   │
│                                                                     │
│       def wrapped_subgraph(parent_state):                           │
│           sub_input = {'sub_key': parent_state['parent_key']}       │
│           sub_output = subgraph.invoke(sub_input)                   │
│           return {'parent_key': sub_output['sub_key']}              │
│                                                                     │
│    The best approach depends on how tightly coupled the             │
│    subgraph is to the parent. For reusable subgraphs,               │
│    I prefer wrapper functions or bridge nodes."                     │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
"""


if __name__ == "__main__":
    # Run main example
    main()

    # Show independent testing
    demonstrate_subgraph_testing()

    # Show reuse
    demonstrate_subgraph_reuse()
