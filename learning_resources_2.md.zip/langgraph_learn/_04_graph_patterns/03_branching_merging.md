# Branching and Merging Patterns in LangGraph

## What is Branching?

Branching allows your graph to take **different paths based on conditions**. Think of it like
a road intersection where you choose which way to go based on your destination.

```
    ╔═══════════════════════════════════════════════════════════════╗
    ║                    BRANCHING PATTERN                          ║
    ╠═══════════════════════════════════════════════════════════════╣
    ║                                                                ║
    ║                        ┌─────────────┐                         ║
    ║                        │   Router    │                         ║
    ║                        │   Node      │                         ║
    ║                        └──────┬──────┘                         ║
    ║                               │                                ║
    ║               ┌───────────────┼───────────────┐                ║
    ║               │               │               │                ║
    ║        condition A      condition B     condition C            ║
    ║               │               │               │                ║
    ║               ▼               ▼               ▼                ║
    ║        ┌───────────┐   ┌───────────┐   ┌───────────┐          ║
    ║        │  Path A   │   │  Path B   │   │  Path C   │          ║
    ║        └───────────┘   └───────────┘   └───────────┘          ║
    ║                                                                ║
    ╚═══════════════════════════════════════════════════════════════╝
```

---

## Real-World Analogy: Customer Support Routing

Imagine a customer service system:

```
                              ┌─────────────────┐
                              │ Incoming Query  │
                              └────────┬────────┘
                                       │
                              ┌────────▼────────┐
                              │  Classify Query │
                              └────────┬────────┘
                                       │
            ┌──────────────────────────┼──────────────────────────┐
            │                          │                          │
     "billing issue"           "technical problem"         "general inquiry"
            │                          │                          │
            ▼                          ▼                          ▼
    ┌───────────────┐         ┌───────────────┐         ┌───────────────┐
    │    Billing    │         │   Technical   │         │     FAQ       │
    │     Team      │         │    Support    │         │     Bot       │
    └───────────────┘         └───────────────┘         └───────────────┘

    Different paths for different customer needs!
```

---

## What is Merging?

Merging (also called **fan-in**) is when multiple paths converge back to a single node.
This is useful when different branches need to produce a unified result.

```
    ╔═══════════════════════════════════════════════════════════════╗
    ║                     MERGING PATTERN                            ║
    ╠═══════════════════════════════════════════════════════════════╣
    ║                                                                ║
    ║        ┌───────────┐   ┌───────────┐   ┌───────────┐          ║
    ║        │  Path A   │   │  Path B   │   │  Path C   │          ║
    ║        └─────┬─────┘   └─────┬─────┘   └─────┬─────┘          ║
    ║              │               │               │                 ║
    ║              └───────────────┼───────────────┘                 ║
    ║                              │                                 ║
    ║                              ▼                                 ║
    ║                       ┌─────────────┐                          ║
    ║                       │   Merge     │                          ║
    ║                       │   Node      │                          ║
    ║                       └─────────────┘                          ║
    ║                                                                ║
    ╚═══════════════════════════════════════════════════════════════╝
```

---

## Fan-Out / Fan-In Pattern (Complete Picture)

The most powerful pattern combines both: **fan-out** (branching) followed by **fan-in** (merging).

```
    ╔═══════════════════════════════════════════════════════════════════════╗
    ║                    FAN-OUT / FAN-IN PATTERN                           ║
    ╠═══════════════════════════════════════════════════════════════════════╣
    ║                                                                        ║
    ║                           ┌─────────────┐                              ║
    ║                           │    START    │                              ║
    ║                           └──────┬──────┘                              ║
    ║                                  │                                     ║
    ║                           ┌──────▼──────┐                              ║
    ║                           │   Router    │                              ║
    ║                           │  (decides)  │                              ║
    ║                           └──────┬──────┘                              ║
    ║                                  │                                     ║
    ║        ┌─────────────────────────┼─────────────────────────┐          ║
    ║        │                         │                         │          ║
    ║        ▼                         ▼                         ▼          ║
    ║   ┌─────────┐              ┌─────────┐              ┌─────────┐       ║
    ║   │ Branch  │              │ Branch  │              │ Branch  │       ║
    ║   │    A    │              │    B    │              │    C    │       ║
    ║   └────┬────┘              └────┬────┘              └────┬────┘       ║
    ║        │                        │                        │            ║
    ║        │         FAN-OUT        │         FAN-IN         │            ║
    ║        │       (Branching)      │       (Merging)        │            ║
    ║        └────────────────────────┼────────────────────────┘            ║
    ║                                 │                                      ║
    ║                           ┌─────▼─────┐                                ║
    ║                           │  Combine  │                                ║
    ║                           │  Results  │                                ║
    ║                           └─────┬─────┘                                ║
    ║                                 │                                      ║
    ║                           ┌─────▼─────┐                                ║
    ║                           │    END    │                                ║
    ║                           └───────────┘                                ║
    ║                                                                        ║
    ╚═══════════════════════════════════════════════════════════════════════╝
```

---

## Key API: add_conditional_edges()

This is the magic method that enables branching:

```python
graph.add_conditional_edges(
    source_node,      # Node that makes the decision
    router_function,  # Function that returns the next node name
    path_map          # Optional: mapping of return values to node names
)
```

### How the Router Function Works

```
                         ┌─────────────────────────────┐
                         │     Router Function         │
                         │                             │
    State ──────────────▶│  def router(state):        │──────────────▶ "node_name"
                         │      if condition_a:       │
                         │          return "node_a"   │
                         │      elif condition_b:     │
                         │          return "node_b"   │
                         │      else:                 │
                         │          return "node_c"   │
                         │                             │
                         └─────────────────────────────┘
    
    The router examines the state and returns which node to execute next!
```

---

## Three Ways to Define Conditional Edges

### Method 1: Return Node Names Directly

```python
def router(state):
    if state["query_type"] == "billing":
        return "billing_handler"
    elif state["query_type"] == "technical":
        return "tech_handler"
    else:
        return "general_handler"

graph.add_conditional_edges("classifier", router)
```

### Method 2: Use a Path Map

```python
def router(state):
    if state["query_type"] == "billing":
        return "billing"  # Returns a key
    elif state["query_type"] == "technical":
        return "technical"  # Returns a key
    else:
        return "general"  # Returns a key

# Map the returned keys to actual node names
graph.add_conditional_edges(
    "classifier",
    router,
    {
        "billing": "billing_handler_node",
        "technical": "tech_support_node",
        "general": "faq_bot_node"
    }
)
```

### Method 3: Route to END

```python
from langgraph.graph import END

def should_continue(state):
    if state["is_complete"]:
        return END  # Special constant to end execution
    else:
        return "continue_processing"

graph.add_conditional_edges("check_status", should_continue)
```

---

## Branching Patterns

### Pattern 1: Simple If-Else Branch

```
            ┌───────────────┐
            │   Evaluate    │
            └───────┬───────┘
                    │
            ┌───────┴───────┐
            │               │
        condition       condition
          TRUE            FALSE
            │               │
            ▼               ▼
      ┌───────────┐   ┌───────────┐
      │  Path A   │   │  Path B   │
      └───────────┘   └───────────┘
```

```python
def binary_router(state):
    return "path_a" if state["condition"] else "path_b"
```

### Pattern 2: Multi-Way Branch (Switch)

```
                    ┌───────────────┐
                    │   Classify    │
                    └───────┬───────┘
                            │
        ┌───────────┬───────┼───────┬───────────┐
        │           │       │       │           │
     "type_1"   "type_2" "type_3" "type_4"  "default"
        │           │       │       │           │
        ▼           ▼       ▼       ▼           ▼
      ┌───┐       ┌───┐   ┌───┐   ┌───┐       ┌───┐
      │ A │       │ B │   │ C │   │ D │       │ E │
      └───┘       └───┘   └───┘   └───┘       └───┘
```

```python
def multi_router(state):
    type_to_node = {
        "type_1": "handler_a",
        "type_2": "handler_b",
        "type_3": "handler_c",
        "type_4": "handler_d",
    }
    return type_to_node.get(state["item_type"], "default_handler")
```

### Pattern 3: Early Exit

```
      ┌───────────────┐
      │   Validate    │
      └───────┬───────┘
              │
      ┌───────┴───────┐
      │               │
    valid          invalid
      │               │
      ▼               ▼
  ┌───────┐       ┌───────┐
  │Process│       │  END  │  ← Early termination
  └───────┘       └───────┘
```

```python
from langgraph.graph import END

def validation_router(state):
    if state["is_valid"]:
        return "process"
    else:
        return END  # Stop execution immediately
```

---

## Merging Patterns

### Pattern 1: All Paths Merge to One

```
    ┌───┐     ┌───┐     ┌───┐
    │ A │     │ B │     │ C │
    └─┬─┘     └─┬─┘     └─┬─┘
      │         │         │
      └────┬────┴────┬────┘
           │         │
           ▼         ▼
        ┌─────────────┐
        │   Combine   │
        └─────────────┘
```

```python
# Simply add edges from all branches to the merge node
graph.add_edge("branch_a", "combine")
graph.add_edge("branch_b", "combine")
graph.add_edge("branch_c", "combine")
```

### Pattern 2: Conditional Merge

```
    ┌───────┐     ┌───────┐
    │   A   │     │   B   │
    └───┬───┘     └───┬───┘
        │             │
        ▼             ▼
    ┌───────┐     ┌───────┐
    │Router │     │Router │
    └───┬───┘     └───┬───┘
        │             │
    ┌───┴───┐     ┌───┴───┐
    │       │     │       │
    ▼       ▼     ▼       ▼
  ┌───┐   ┌───┐ ┌───┐   ┌───┐
  │END│   │ M │ │ M │   │END│
  └───┘   └───┘ └───┘   └───┘
```

Some paths might end early while others converge.

---

## State Management in Branching

📌 **Important**: Only ONE branch executes per invocation in standard branching!

```
    ┌─────────────────────────────────────────────────────────────────┐
    │                    STATE FLOW IN BRANCHING                      │
    ├─────────────────────────────────────────────────────────────────┤
    │                                                                 │
    │   Initial State          After Router         After Branch      │
    │  ┌─────────────┐        ┌─────────────┐      ┌─────────────┐   │
    │  │ type: "A"   │        │ type: "A"   │      │ type: "A"   │   │
    │  │ data: {...} │ ─────▶ │ data: {...} │ ───▶ │ data: {...} │   │
    │  │ result: ""  │        │ result: ""  │      │ result: "X" │   │
    │  └─────────────┘        └─────────────┘      └─────────────┘   │
    │                                                                 │
    │   Only the selected branch modifies the state!                  │
    │                                                                 │
    └─────────────────────────────────────────────────────────────────┘
```

---

## Interview Tip

```
┌─────────────────────────────────────────────────────────────────────┐
│ 💡 INTERVIEW TIP                                                    │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│ Q: "How does LangGraph handle state when multiple branches          │
│     converge at a merge node?"                                      │
│                                                                     │
│ A: "In standard conditional branching, only ONE branch executes     │
│    per graph invocation - the router picks a single path based      │
│    on the state. So there's no conflict at the merge node.          │
│                                                                     │
│    However, if you need TRUE parallel execution where multiple      │
│    branches run simultaneously and their results need to be         │
│    combined, you would use:                                         │
│                                                                     │
│    1. The Send() API for fan-out to multiple nodes                  │
│    2. Reducer functions to combine parallel updates                 │
│    3. Proper state channel configuration                            │
│                                                                     │
│    The key distinction is:                                          │
│    - Conditional edges = ONE path selected                          │
│    - Send() API = MULTIPLE paths executed in parallel"              │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Common Mistakes to Avoid

```
┌─────────────────────────────────────────────────────────────────────┐
│ ⚠️  COMMON MISTAKE #1: Forgetting to handle all cases              │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│   BAD:                                                              │
│   def router(state):                                                │
│       if state["type"] == "A":                                      │
│           return "handler_a"                                        │
│       # What if type is "B" or "C"? Runtime error!                 │
│                                                                     │
│   GOOD:                                                             │
│   def router(state):                                                │
│       if state["type"] == "A":                                      │
│           return "handler_a"                                        │
│       else:                                                         │
│           return "default_handler"  # Always have a fallback!      │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│ ⚠️  COMMON MISTAKE #2: Router returning invalid node name          │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│   BAD:                                                              │
│   return "handlerA"  # Typo! Node is named "handler_a"             │
│                                                                     │
│   GOOD:                                                             │
│   # Define constants for node names                                 │
│   HANDLER_A = "handler_a"                                           │
│   HANDLER_B = "handler_b"                                           │
│   return HANDLER_A                                                  │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Decision Tree Visualization

```
    How to Choose Your Branching Strategy:
    
                              ┌─────────────────────┐
                              │ Do you need to pick │
                              │  different paths?   │
                              └──────────┬──────────┘
                                         │
                           ┌─────────────┴─────────────┐
                           │                           │
                          YES                          NO
                           │                           │
              ┌────────────▼────────────┐    ┌────────▼────────┐
              │ How many paths maximum? │    │ Use sequential  │
              └────────────┬────────────┘    │    workflow     │
                           │                 └─────────────────┘
              ┌────────────┴────────────┐
              │                         │
             2-3                       4+
              │                         │
    ┌─────────▼─────────┐    ┌─────────▼─────────┐
    │  Simple if/else   │    │  Use path_map     │
    │  in router func   │    │  for cleaner code │
    └───────────────────┘    └───────────────────┘
```

---

## Summary

```
┌─────────────────────────────────────────────────────────────────────┐
│                        KEY TAKEAWAYS                                │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ✅ add_conditional_edges() enables dynamic path selection          │
│                                                                     │
│  ✅ Router functions examine state and return next node name        │
│                                                                     │
│  ✅ Use path_map for cleaner mapping of conditions to nodes         │
│                                                                     │
│  ✅ Return END to terminate execution early                         │
│                                                                     │
│  ✅ Merging is done by adding edges from branches to one node       │
│                                                                     │
│  ✅ In standard branching, only ONE path executes per invocation    │
│                                                                     │
│  ✅ Always handle all possible cases in your router                 │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Next Steps

Continue to [04_branching_example.py](./04_branching_example.py) to see branching and merging in action!
