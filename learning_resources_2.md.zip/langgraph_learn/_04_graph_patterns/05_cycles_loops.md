# Cycles and Loops in LangGraph

## What are Cycles?

A cycle (or loop) is a graph pattern where execution can **return to a previous node**.
This enables iterative refinement, retries, and agent-like behavior where the system
continues working until a goal is achieved.

```
    ╔═══════════════════════════════════════════════════════════════╗
    ║                      CYCLE/LOOP PATTERN                        ║
    ╠═══════════════════════════════════════════════════════════════╣
    ║                                                                ║
    ║                        ┌─────────────┐                         ║
    ║                        │    START    │                         ║
    ║                        └──────┬──────┘                         ║
    ║                               │                                ║
    ║                               ▼                                ║
    ║                   ┌──────────────────────┐                     ║
    ║                   │                      │                     ║
    ║                   │     Process Node     │◄─────────┐          ║
    ║                   │                      │          │          ║
    ║                   └──────────┬───────────┘          │          ║
    ║                              │                      │          ║
    ║                              ▼                      │          ║
    ║                   ┌──────────────────────┐          │          ║
    ║                   │                      │          │          ║
    ║                   │    Check Condition   │          │          ║
    ║                   │                      │          │   LOOP   ║
    ║                   └──────────┬───────────┘          │  BACK    ║
    ║                              │                      │          ║
    ║               ┌──────────────┴──────────────┐       │          ║
    ║               │                             │       │          ║
    ║            DONE?                        NOT DONE    │          ║
    ║               │                             │       │          ║
    ║               ▼                             └───────┘          ║
    ║        ┌─────────────┐                                         ║
    ║        │     END     │                                         ║
    ║        └─────────────┘                                         ║
    ║                                                                ║
    ╚═══════════════════════════════════════════════════════════════╝
```

---

## Real-World Analogy: Writing an Essay

```
    ┌─────────────────────────────────────────────────────────────────┐
    │                    ESSAY WRITING PROCESS                         │
    │                                                                  │
    │                        ┌─────────────┐                           │
    │                        │   Draft     │                           │
    │                        │   Essay     │◄─────────────┐            │
    │                        └──────┬──────┘              │            │
    │                               │                     │            │
    │                               ▼                     │            │
    │                        ┌─────────────┐              │            │
    │                        │   Review    │              │            │
    │                        │   & Check   │              │            │
    │                        └──────┬──────┘              │            │
    │                               │                     │            │
    │                    ┌──────────┴──────────┐          │            │
    │                    │                     │          │            │
    │               "Looks good!"        "Needs work"     │            │
    │                    │                     │          │            │
    │                    ▼                     └──────────┘            │
    │               ┌─────────┐                   (Revise)             │
    │               │ Submit  │                                        │
    │               └─────────┘                                        │
    │                                                                  │
    │   You keep revising until the essay meets quality standards!     │
    └─────────────────────────────────────────────────────────────────┘
```

---

## When to Use Cycles

✅ **Use cycles when:**

| Scenario | Example |
|----------|---------|
| **Iterative refinement** | LLM generates code → Test → Fix errors → Test again |
| **Retry with backoff** | API call fails → Wait → Retry → Eventually succeed |
| **Goal-seeking agents** | Agent tries actions until task is complete |
| **Quality validation** | Generate → Validate → Regenerate if quality is low |
| **Human-in-the-loop** | Get feedback → Incorporate → Get more feedback |

⚠️ **Avoid cycles when:**

| Scenario | Better Pattern |
|----------|----------------|
| Simple sequential task | Sequential workflow |
| One-time decision | Branching pattern |
| Fixed number of steps known | Unroll into sequential nodes |

---

## The Anatomy of a Loop

Every loop has these essential components:

```
    ┌─────────────────────────────────────────────────────────────────┐
    │                    ESSENTIAL LOOP COMPONENTS                     │
    ├─────────────────────────────────────────────────────────────────┤
    │                                                                  │
    │   1. WORK NODE - Does the actual processing                      │
    │      ┌──────────────────────────────────────────────┐           │
    │      │  def process(state):                         │           │
    │      │      result = do_work(state)                 │           │
    │      │      return {"result": result}               │           │
    │      └──────────────────────────────────────────────┘           │
    │                                                                  │
    │   2. CHECK NODE - Evaluates if loop should continue              │
    │      ┌──────────────────────────────────────────────┐           │
    │      │  def check(state):                           │           │
    │      │      is_done = evaluate(state["result"])     │           │
    │      │      return {"is_done": is_done}             │           │
    │      └──────────────────────────────────────────────┘           │
    │                                                                  │
    │   3. ROUTER - Decides to continue or exit                        │
    │      ┌──────────────────────────────────────────────┐           │
    │      │  def should_continue(state):                 │           │
    │      │      if state["is_done"]:                    │           │
    │      │          return END                          │           │
    │      │      return "process"  # Loop back           │           │
    │      └──────────────────────────────────────────────┘           │
    │                                                                  │
    │   4. TERMINATION CONDITION - Prevents infinite loops!            │
    │      ┌──────────────────────────────────────────────┐           │
    │      │  - Maximum iterations                        │           │
    │      │  - Quality threshold reached                 │           │
    │      │  - Timeout exceeded                          │           │
    │      │  - Error limit reached                       │           │
    │      └──────────────────────────────────────────────┘           │
    │                                                                  │
    └─────────────────────────────────────────────────────────────────┘
```

---

## Loop Visualization: State Through Iterations

```
    Iteration 1          Iteration 2          Iteration 3          Final
    ┌──────────────┐     ┌──────────────┐     ┌──────────────┐     ┌──────────────┐
    │ attempt: 1   │     │ attempt: 2   │     │ attempt: 3   │     │ attempt: 3   │
    │ quality: 0.3 │ ──▶ │ quality: 0.6 │ ──▶ │ quality: 0.9 │ ──▶ │ quality: 0.9 │
    │ is_done: ✗   │     │ is_done: ✗   │     │ is_done: ✓   │     │ is_done: ✓   │
    └──────────────┘     └──────────────┘     └──────────────┘     └──────────────┘
         │                    │                    │                    │
         │                    │                    │                    │
         └──── Loop ──────────┴───── Loop ────────┘                   END
              Back                  Back
    
    Quality improves each iteration until threshold is met!
```

---

## Preventing Infinite Loops

⚠️ **CRITICAL**: Always implement safeguards against infinite loops!

```
    ┌─────────────────────────────────────────────────────────────────┐
    │                  INFINITE LOOP PREVENTION                        │
    ├─────────────────────────────────────────────────────────────────┤
    │                                                                  │
    │   Strategy 1: ITERATION COUNTER                                  │
    │   ┌──────────────────────────────────────────────────────────┐  │
    │   │  class State(TypedDict):                                 │  │
    │   │      iteration: int                                      │  │
    │   │      max_iterations: int                                 │  │
    │   │                                                          │  │
    │   │  def should_continue(state):                             │  │
    │   │      if state["iteration"] >= state["max_iterations"]:   │  │
    │   │          return END  # Force exit                        │  │
    │   │      ...                                                 │  │
    │   └──────────────────────────────────────────────────────────┘  │
    │                                                                  │
    │   Strategy 2: TIMEOUT                                            │
    │   ┌──────────────────────────────────────────────────────────┐  │
    │   │  class State(TypedDict):                                 │  │
    │   │      start_time: float                                   │  │
    │   │      timeout_seconds: float                              │  │
    │   │                                                          │  │
    │   │  def should_continue(state):                             │  │
    │   │      elapsed = time.time() - state["start_time"]         │  │
    │   │      if elapsed > state["timeout_seconds"]:              │  │
    │   │          return END  # Timeout                           │  │
    │   │      ...                                                 │  │
    │   └──────────────────────────────────────────────────────────┘  │
    │                                                                  │
    │   Strategy 3: DIMINISHING RETURNS                                │
    │   ┌──────────────────────────────────────────────────────────┐  │
    │   │  def should_continue(state):                             │  │
    │   │      # Stop if improvement is minimal                    │  │
    │   │      improvement = state["current"] - state["previous"]  │  │
    │   │      if improvement < 0.01:  # Less than 1% improvement  │  │
    │   │          return END  # Diminishing returns               │  │
    │   │      ...                                                 │  │
    │   └──────────────────────────────────────────────────────────┘  │
    │                                                                  │
    └─────────────────────────────────────────────────────────────────┘
```

---

## Common Loop Patterns

### Pattern 1: Retry Loop

```
                    ┌─────────────────────┐
                    │      Attempt        │
                    │    Operation        │◄──────────────┐
                    └──────────┬──────────┘               │
                               │                          │
                               ▼                          │
                    ┌─────────────────────┐               │
                    │   Success?          │               │
                    └──────────┬──────────┘               │
                               │                          │
              ┌────────────────┼────────────────┐         │
              │                │                │         │
           SUCCESS          FAILURE          MAX RETRIES  │
              │                │                │         │
              ▼                │                ▼         │
         ┌─────────┐           └────────▶ ┌─────────┐     │
         │   END   │                      │ Handle  │     │
         │ (done)  │                      │ Failure │     │
         └─────────┘                      └─────────┘     │
                                                          │
    Use case: API calls, network requests                 │
```

### Pattern 2: Refinement Loop

```
                    ┌─────────────────────┐
                    │    Generate         │
                    │    Output           │◄──────────────┐
                    └──────────┬──────────┘               │
                               │                          │
                               ▼                          │
                    ┌─────────────────────┐               │
                    │    Evaluate         │               │
                    │    Quality          │               │
                    └──────────┬──────────┘               │
                               │                          │
              ┌────────────────┴────────────────┐         │
              │                                 │         │
         MEETS THRESHOLD                  BELOW THRESHOLD │
              │                                 │         │
              ▼                                 └─────────┘
         ┌─────────┐                            (refine)
         │   END   │
         └─────────┘
    
    Use case: Code generation, content creation
```

### Pattern 3: Agent Action Loop (ReAct Pattern)

```
                    ┌─────────────────────┐
                    │       Think         │
                    │  (Reason about      │◄──────────────┐
                    │   next action)      │               │
                    └──────────┬──────────┘               │
                               │                          │
                               ▼                          │
                    ┌─────────────────────┐               │
                    │        Act          │               │
                    │   (Execute tool)    │               │
                    └──────────┬──────────┘               │
                               │                          │
                               ▼                          │
                    ┌─────────────────────┐               │
                    │      Observe        │               │
                    │   (Check result)    │               │
                    └──────────┬──────────┘               │
                               │                          │
              ┌────────────────┴────────────────┐         │
              │                                 │         │
         TASK COMPLETE                    NEED MORE WORK  │
              │                                 │         │
              ▼                                 └─────────┘
         ┌─────────┐
         │   END   │
         └─────────┘
    
    Use case: AI agents, autonomous systems
```

---

## Code Structure for Loops

```python
from langgraph.graph import StateGraph, START, END

# 1. State with loop tracking
class State(TypedDict):
    data: str
    iteration: int
    max_iterations: int
    is_complete: bool

# 2. Work node (what gets repeated)
def process(state):
    return {
        "data": transform(state["data"]),
        "iteration": state["iteration"] + 1
    }

# 3. Check node (evaluate completion)
def evaluate(state):
    is_complete = check_quality(state["data"])
    return {"is_complete": is_complete}

# 4. Router (decide: loop or exit)
def should_continue(state):
    # Exit if complete
    if state["is_complete"]:
        return END
    # Exit if max iterations
    if state["iteration"] >= state["max_iterations"]:
        return END
    # Continue looping
    return "process"

# 5. Build graph with cycle
graph = StateGraph(State)
graph.add_node("process", process)
graph.add_node("evaluate", evaluate)

graph.add_edge(START, "process")
graph.add_edge("process", "evaluate")
graph.add_conditional_edges("evaluate", should_continue)
```

---

## Interview Tip

```
┌─────────────────────────────────────────────────────────────────────┐
│ 💡 INTERVIEW TIP                                                    │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│ Q: "How do you prevent infinite loops in a LangGraph agent?"        │
│                                                                     │
│ A: "I use multiple safeguards working together:                     │
│                                                                     │
│    1. ITERATION LIMIT: Track iteration count in state and           │
│       force termination after N iterations                          │
│                                                                     │
│    2. TIMEOUT: Store start time and check elapsed time              │
│       at each loop iteration                                        │
│                                                                     │
│    3. RECURSION LIMIT: LangGraph has a built-in recursion_limit     │
│       parameter on compile() - I set this explicitly                │
│                                                                     │
│    4. DIMINISHING RETURNS: If improvement between iterations        │
│       is below a threshold, stop early                              │
│                                                                     │
│    5. ERROR ACCUMULATOR: Track consecutive errors and               │
│       terminate if too many failures occur                          │
│                                                                     │
│    Example:                                                         │
│    app = graph.compile(recursion_limit=25)  # Built-in limit       │
│                                                                     │
│    Best practice is to use BOTH built-in limits and explicit        │
│    state-based counters for defense in depth."                      │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Recursion Limit in LangGraph

```python
# Built-in protection against infinite loops
app = graph.compile(
    recursion_limit=25  # Maximum number of "super-steps"
)

# A "super-step" is one complete traversal through nodes
# If limit is exceeded, LangGraph raises GraphRecursionError
```

```
    Super-step counting:
    
    Step 1: START → process
    Step 2: process → evaluate  
    Step 3: evaluate → process (loop back) ← Counts as step 3
    Step 4: process → evaluate
    Step 5: evaluate → END
    
    Total super-steps: 5
```

---

## Debugging Loops

```
    ┌─────────────────────────────────────────────────────────────────┐
    │                    LOOP DEBUGGING TIPS                          │
    ├─────────────────────────────────────────────────────────────────┤
    │                                                                 │
    │  1. USE STREAMING to watch state changes:                       │
    │     for event in app.stream(state):                             │
    │         print(f"Iteration {state['iteration']}: {event}")       │
    │                                                                 │
    │  2. ADD LOGGING in your router:                                 │
    │     def should_continue(state):                                 │
    │         print(f"Check at iteration {state['iteration']}")       │
    │         print(f"  is_complete: {state['is_complete']}")         │
    │         ...                                                     │
    │                                                                 │
    │  3. START WITH LOW LIMITS during development:                   │
    │     max_iterations: 3  # Easier to debug                        │
    │     recursion_limit=10  # Catch runaway loops fast              │
    │                                                                 │
    │  4. STORE HISTORY for analysis:                                 │
    │     class State(TypedDict):                                     │
    │         history: List[dict]  # Each iteration's state           │
    │                                                                 │
    └─────────────────────────────────────────────────────────────────┘
```

---

## Summary

```
┌─────────────────────────────────────────────────────────────────────┐
│                        KEY TAKEAWAYS                                │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ✅ Cycles enable iterative refinement and agent-like behavior      │
│                                                                     │
│  ✅ Every loop needs: work node, check node, router, exit condition │
│                                                                     │
│  ✅ Use add_conditional_edges to create the loop-back path          │
│                                                                     │
│  ✅ ALWAYS implement safeguards: iteration limits, timeouts         │
│                                                                     │
│  ✅ LangGraph's recursion_limit provides built-in protection        │
│                                                                     │
│  ✅ Common patterns: retry loops, refinement loops, agent loops     │
│                                                                     │
│  ⚠️  Test with low limits during development                        │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Next Steps

Continue to [06_cycles_example.py](./06_cycles_example.py) to see a working example of an
agent loop that refines code until it passes tests!
