# Parallel Execution in LangGraph

## What is Parallel Execution?

Parallel execution allows multiple nodes to run **simultaneously** rather than sequentially.
This is powerful for tasks that are independent and can benefit from concurrent processing.

```
    ╔═══════════════════════════════════════════════════════════════════════╗
    ║                      PARALLEL EXECUTION PATTERN                       ║
    ╠═══════════════════════════════════════════════════════════════════════╣
    ║                                                                        ║
    ║        SEQUENTIAL (Slow)              PARALLEL (Fast)                  ║
    ║        ═══════════════                ═══════════════                  ║
    ║                                                                        ║
    ║        ┌───────────┐                     ┌───────────┐                 ║
    ║        │     A     │                     │     A     │                 ║
    ║        └─────┬─────┘                     └─────┬─────┘                 ║
    ║              │                          ┌──────┼──────┐                ║
    ║              ▼                          │      │      │                ║
    ║        ┌───────────┐                    ▼      ▼      ▼                ║
    ║        │     B     │               ┌─────┐ ┌─────┐ ┌─────┐             ║
    ║        └─────┬─────┘               │  B  │ │  C  │ │  D  │             ║
    ║              │                     └──┬──┘ └──┬──┘ └──┬──┘             ║
    ║              ▼                        │      │      │                  ║
    ║        ┌───────────┐                  └──────┼──────┘                  ║
    ║        │     C     │                         │                         ║
    ║        └─────┬─────┘                         ▼                         ║
    ║              │                          ┌───────────┐                  ║
    ║              ▼                          │     E     │                  ║
    ║        ┌───────────┐                    │  (merge)  │                  ║
    ║        │     D     │                    └───────────┘                  ║
    ║        └───────────┘                                                   ║
    ║                                                                        ║
    ║        Time: A + B + C + D           Time: A + max(B,C,D) + E          ║
    ║                                                                        ║
    ╚═══════════════════════════════════════════════════════════════════════╝
```

---

## Real-World Analogy: Research Team

```
    ┌─────────────────────────────────────────────────────────────────────┐
    │                     RESEARCH PROJECT                                 │
    │                                                                      │
    │                        ┌────────────────┐                            │
    │                        │  Project Lead  │                            │
    │                        │  Assigns Tasks │                            │
    │                        └───────┬────────┘                            │
    │                                │                                     │
    │              ┌─────────────────┼─────────────────┐                   │
    │              │                 │                 │                   │
    │              ▼                 ▼                 ▼                   │
    │      ┌─────────────┐   ┌─────────────┐   ┌─────────────┐            │
    │      │  Analyst 1  │   │  Analyst 2  │   │  Analyst 3  │            │
    │      │  Research   │   │  Research   │   │  Research   │            │
    │      │  Finance    │   │  Marketing  │   │  Operations │            │
    │      └──────┬──────┘   └──────┬──────┘   └──────┬──────┘            │
    │             │                 │                 │                   │
    │             └─────────────────┼─────────────────┘                   │
    │                               │                                     │
    │                               ▼                                     │
    │                        ┌────────────────┐                            │
    │                        │  Project Lead  │                            │
    │                        │  Combines All  │                            │
    │                        └────────────────┘                            │
    │                                                                      │
    │   All analysts work simultaneously, then results are combined!       │
    └─────────────────────────────────────────────────────────────────────┘
```

---

## Two Ways to Achieve Parallelism in LangGraph

### Method 1: Multiple Edges to Same Target (Fan-In)

When multiple nodes have edges to the same destination, they can run in parallel
if their source node is the same.

```python
# This creates potential for parallel execution
graph.add_edge(START, "task_a")
graph.add_edge(START, "task_b")  
graph.add_edge(START, "task_c")
# All three start from START, so they can run in parallel
```

### Method 2: Send API (Dynamic Fan-Out)

The `Send` API allows you to dynamically send work to multiple parallel instances.

```python
from langgraph.constants import Send

def distribute_work(state):
    # Dynamically create parallel tasks
    return [
        Send("worker", {"task": task}) 
        for task in state["tasks"]
    ]
```

---

## Fan-Out Pattern (Distributing Work)

```
    ╔═══════════════════════════════════════════════════════════════════════╗
    ║                         FAN-OUT PATTERN                               ║
    ╠═══════════════════════════════════════════════════════════════════════╣
    ║                                                                        ║
    ║                        ┌─────────────────┐                             ║
    ║                        │   Distributor   │                             ║
    ║                        │  (splits work)  │                             ║
    ║                        └────────┬────────┘                             ║
    ║                                 │                                      ║
    ║            ┌────────────────────┼────────────────────┐                 ║
    ║            │                    │                    │                 ║
    ║            ▼                    ▼                    ▼                 ║
    ║     ┌────────────┐       ┌────────────┐       ┌────────────┐          ║
    ║     │  Worker 1  │       │  Worker 2  │       │  Worker 3  │          ║
    ║     │  (item 1)  │       │  (item 2)  │       │  (item 3)  │          ║
    ║     └────────────┘       └────────────┘       └────────────┘          ║
    ║                                                                        ║
    ║     Using Send API:                                                    ║
    ║     return [Send("worker", item) for item in items]                    ║
    ║                                                                        ║
    ╚═══════════════════════════════════════════════════════════════════════╝
```

---

## Fan-In Pattern (Collecting Results)

```
    ╔═══════════════════════════════════════════════════════════════════════╗
    ║                          FAN-IN PATTERN                               ║
    ╠═══════════════════════════════════════════════════════════════════════╣
    ║                                                                        ║
    ║     ┌────────────┐       ┌────────────┐       ┌────────────┐          ║
    ║     │  Worker 1  │       │  Worker 2  │       │  Worker 3  │          ║
    ║     │  result=A  │       │  result=B  │       │  result=C  │          ║
    ║     └──────┬─────┘       └──────┬─────┘       └──────┬─────┘          ║
    ║            │                    │                    │                 ║
    ║            └────────────────────┼────────────────────┘                 ║
    ║                                 │                                      ║
    ║                                 ▼                                      ║
    ║                        ┌─────────────────┐                             ║
    ║                        │    Aggregator   │                             ║
    ║                        │  results=[A,B,C]│                             ║
    ║                        └─────────────────┘                             ║
    ║                                                                        ║
    ║     Using reducer in state:                                            ║
    ║     results: Annotated[List[str], operator.add]                        ║
    ║                                                                        ║
    ╚═══════════════════════════════════════════════════════════════════════╝
```

---

## State Reducers: Handling Parallel Updates

📌 **Key Concept**: When multiple nodes update the same state key, you need a **reducer**
to combine the updates.

```python
from typing import Annotated
import operator

class State(TypedDict):
    # Without reducer: Last write wins (usually not what you want!)
    simple_value: str
    
    # With reducer: All values are combined
    # operator.add for lists = concatenate
    results: Annotated[List[str], operator.add]
```

### How Reducers Work

```
    ┌─────────────────────────────────────────────────────────────────┐
    │                    REDUCER IN ACTION                             │
    ├─────────────────────────────────────────────────────────────────┤
    │                                                                  │
    │   Worker 1 returns: {"results": ["A"]}                           │
    │   Worker 2 returns: {"results": ["B"]}                           │
    │   Worker 3 returns: {"results": ["C"]}                           │
    │                                                                  │
    │                        │                                         │
    │                        ▼                                         │
    │              ┌─────────────────────┐                             │
    │              │  REDUCER            │                             │
    │              │  operator.add       │                             │
    │              │  ["A"] + ["B"] +... │                             │
    │              └─────────────────────┘                             │
    │                        │                                         │
    │                        ▼                                         │
    │              Final state:                                        │
    │              {"results": ["A", "B", "C"]}                        │
    │                                                                  │
    └─────────────────────────────────────────────────────────────────┘
```

### Common Reducers

| Reducer | Use Case | Example |
|---------|----------|---------|
| `operator.add` | Concatenate lists | `[1] + [2] = [1, 2]` |
| `lambda a, b: {**a, **b}` | Merge dicts | `{a:1} + {b:2} = {a:1, b:2}` |
| `lambda a, b: a + b` | Sum numbers | `5 + 3 = 8` |
| Custom function | Complex logic | Any custom merge |

---

## The Send API

The `Send` API is the primary way to create dynamic parallel execution:

```python
from langgraph.constants import Send

def create_parallel_tasks(state):
    """
    Instead of returning state updates, return a list of Send objects.
    Each Send creates a parallel execution path.
    """
    tasks = state["items_to_process"]
    
    # Create one Send for each task
    # Send(node_name, state_for_that_execution)
    return [
        Send("process_item", {"item": task, "index": i})
        for i, task in enumerate(tasks)
    ]

# In graph building:
graph.add_conditional_edges("distributor", create_parallel_tasks)
```

### Send API Visualization

```
    State: {"items": ["X", "Y", "Z"]}
    
    create_parallel_tasks returns:
    [
        Send("worker", {"item": "X", "index": 0}),
        Send("worker", {"item": "Y", "index": 1}),
        Send("worker", {"item": "Z", "index": 2})
    ]
    
                    ┌─────────────┐
                    │ distributor │
                    └──────┬──────┘
                           │
              ┌────────────┼────────────┐
              │            │            │
              ▼            ▼            ▼
        ┌─────────┐  ┌─────────┐  ┌─────────┐
        │ worker  │  │ worker  │  │ worker  │
        │ item="X"│  │ item="Y"│  │ item="Z"│
        └─────────┘  └─────────┘  └─────────┘
    
    Three parallel executions of the same "worker" node!
```

---

## Interview Tip

```
┌─────────────────────────────────────────────────────────────────────┐
│ 💡 INTERVIEW TIP                                                    │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│ Q: "How does LangGraph handle state conflicts in parallel           │
│     execution?"                                                     │
│                                                                     │
│ A: "LangGraph uses a reducer-based approach:                        │
│                                                                     │
│    1. STATE CHANNELS: Each state key is a 'channel' that can        │
│       have a reducer function                                       │
│                                                                     │
│    2. REDUCERS: When parallel nodes write to the same key,          │
│       the reducer combines updates:                                 │
│       - operator.add for lists (concatenate)                        │
│       - Custom functions for complex merging                        │
│                                                                     │
│    3. LAST WRITER WINS: Without a reducer, the last completed       │
│       node's value overwrites earlier ones (usually not desired)    │
│                                                                     │
│    4. TYPING: Use Annotated[Type, reducer_func] to specify:         │
│       results: Annotated[List[str], operator.add]                   │
│                                                                     │
│    Best practice: Always define reducers for state keys that        │
│    might be updated by parallel nodes."                             │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Complete Parallel Pattern

```
    ┌─────────────────────────────────────────────────────────────────┐
    │                COMPLETE FAN-OUT / FAN-IN PATTERN                │
    │                                                                 │
    │                        ┌───────────────┐                        │
    │                        │     START     │                        │
    │                        └───────┬───────┘                        │
    │                                │                                │
    │                                ▼                                │
    │                        ┌───────────────┐                        │
    │                        │   Prepare     │  ← Prepare work items  │
    │                        │   Work Items  │                        │
    │                        └───────┬───────┘                        │
    │                                │                                │
    │                                ▼                                │
    │                        ┌───────────────┐                        │
    │                        │  Distribute   │  ← Returns Send()      │
    │                        │  (fan-out)    │                        │
    │                        └───────┬───────┘                        │
    │                                │                                │
    │              ┌─────────────────┼─────────────────┐              │
    │              │                 │                 │              │
    │              ▼                 ▼                 ▼              │
    │        ┌───────────┐    ┌───────────┐    ┌───────────┐         │
    │        │  Worker   │    │  Worker   │    │  Worker   │  PARALLEL│
    │        │   (0)     │    │   (1)     │    │   (2)     │         │
    │        └─────┬─────┘    └─────┬─────┘    └─────┬─────┘         │
    │              │                 │                 │              │
    │              │     Uses reducer to combine       │              │
    │              └─────────────────┼─────────────────┘              │
    │                                │                                │
    │                                ▼                                │
    │                        ┌───────────────┐                        │
    │                        │   Aggregate   │  ← Combine results     │
    │                        │   (fan-in)    │                        │
    │                        └───────┬───────┘                        │
    │                                │                                │
    │                                ▼                                │
    │                        ┌───────────────┐                        │
    │                        │      END      │                        │
    │                        └───────────────┘                        │
    │                                                                 │
    └─────────────────────────────────────────────────────────────────┘
```

---

## When to Use Parallel Execution

✅ **Use parallel execution when:**

| Scenario | Example |
|----------|---------|
| **Independent tasks** | Fetching from multiple APIs |
| **Same operation on multiple items** | Processing a batch of documents |
| **Multiple analyses of same data** | Sentiment + Entity + Topic extraction |
| **Redundancy/ensemble** | Multiple LLMs for consensus |

⚠️ **Avoid parallel execution when:**

| Scenario | Reason |
|----------|--------|
| Tasks have dependencies | Must be sequential |
| Shared resource contention | Parallelism won't help |
| Small workloads | Overhead not worth it |
| Order matters | Parallel doesn't guarantee order |

---

## Performance Considerations

```
    ┌─────────────────────────────────────────────────────────────────┐
    │                  PARALLEL PERFORMANCE                           │
    ├─────────────────────────────────────────────────────────────────┤
    │                                                                 │
    │   Speedup = Time(Sequential) / Time(Parallel)                   │
    │                                                                 │
    │   Example:                                                      │
    │   - 4 tasks, each takes 2 seconds                              │
    │   - Sequential: 4 × 2 = 8 seconds                              │
    │   - Parallel: max(2,2,2,2) = 2 seconds                         │
    │   - Speedup: 8 / 2 = 4x                                        │
    │                                                                 │
    │   Real-world factors:                                           │
    │   - I/O bound tasks: Great parallel speedup                    │
    │   - CPU bound tasks: Limited by CPU cores                      │
    │   - Memory bound: May cause contention                         │
    │   - Network bound: Limited by bandwidth                        │
    │                                                                 │
    │   Best use case: I/O bound operations like API calls!          │
    │                                                                 │
    └─────────────────────────────────────────────────────────────────┘
```

---

## Summary

```
┌─────────────────────────────────────────────────────────────────────┐
│                        KEY TAKEAWAYS                                │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ✅ Parallel execution runs multiple nodes simultaneously           │
│                                                                     │
│  ✅ Use Send API for dynamic fan-out to parallel workers            │
│                                                                     │
│  ✅ Use reducers (Annotated[type, reducer]) to combine parallel     │
│     state updates                                                   │
│                                                                     │
│  ✅ Fan-out = distribute work, Fan-in = collect results             │
│                                                                     │
│  ✅ Best for I/O bound tasks (API calls, file operations)           │
│                                                                     │
│  ✅ Without reducers, last-write-wins (usually not desired)         │
│                                                                     │
│  ⚠️  Tasks must be independent (no dependencies between them)       │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Next Steps

Continue to [10_parallel_example.py](./10_parallel_example.py) to see parallel execution
in action with a multi-source data aggregation example!
