# Subgraphs in LangGraph

## What are Subgraphs?

Subgraphs are **self-contained graphs that can be embedded within a parent graph**.
Think of them as reusable modules or components that encapsulate a specific workflow.

```
    ╔═══════════════════════════════════════════════════════════════════════╗
    ║                         SUBGRAPH PATTERN                              ║
    ╠═══════════════════════════════════════════════════════════════════════╣
    ║                                                                        ║
    ║                           PARENT GRAPH                                 ║
    ║   ┌───────────────────────────────────────────────────────────────┐   ║
    ║   │                                                               │   ║
    ║   │   ┌─────────┐     ┌─────────────────────────┐     ┌────────┐  │   ║
    ║   │   │  Node   │     │       SUBGRAPH          │     │  Node  │  │   ║
    ║   │   │    A    │────▶│  ┌─────┐     ┌─────┐   │────▶│    D   │  │   ║
    ║   │   └─────────┘     │  │  B  │────▶│  C  │   │     └────────┘  │   ║
    ║   │                   │  └─────┘     └─────┘   │                  │   ║
    ║   │                   └─────────────────────────┘                  │   ║
    ║   │                                                               │   ║
    ║   └───────────────────────────────────────────────────────────────┘   ║
    ║                                                                        ║
    ║   The subgraph looks like a single node to the parent!                 ║
    ║                                                                        ║
    ╚═══════════════════════════════════════════════════════════════════════╝
```

---

## Real-World Analogy: Company Departments

```
    ┌─────────────────────────────────────────────────────────────────────┐
    │                         COMPANY (Parent Graph)                       │
    │                                                                      │
    │   ┌─────────────┐     ┌─────────────────────────────────────────┐   │
    │   │  Receive    │     │          SALES DEPARTMENT               │   │
    │   │  Customer   │────▶│  ┌────────┐  ┌────────┐  ┌────────┐    │   │
    │   │  Request    │     │  │Qualify │─▶│Propose │─▶│ Close  │    │   │
    │   └─────────────┘     │  │ Lead   │  │Solution│  │ Deal   │    │   │
    │                       │  └────────┘  └────────┘  └────────┘    │   │
    │                       └─────────────────────────────────────────┘   │
    │                                         │                           │
    │                                         ▼                           │
    │                       ┌─────────────────────────────────────────┐   │
    │                       │       FULFILLMENT DEPARTMENT            │   │
    │                       │  ┌────────┐  ┌────────┐  ┌────────┐    │   │
    │                       │  │Process │─▶│ Ship   │─▶│Invoice │    │   │
    │                       │  │ Order  │  │Product │  │Customer│    │   │
    │                       │  └────────┘  └────────┘  └────────┘    │   │
    │                       └─────────────────────────────────────────┘   │
    │                                                                      │
    │   Each department is a subgraph with its own internal workflow!      │
    └─────────────────────────────────────────────────────────────────────┘
```

---

## Why Use Subgraphs?

| Benefit | Description |
|---------|-------------|
| **Modularity** | Break complex workflows into manageable pieces |
| **Reusability** | Use the same subgraph in multiple parent graphs |
| **Encapsulation** | Hide internal complexity from the parent |
| **Testability** | Test subgraphs independently |
| **Team Collaboration** | Different teams can own different subgraphs |
| **Maintainability** | Update subgraphs without changing parent |

---

## When to Use Subgraphs

✅ **Use subgraphs when:**

| Scenario | Example |
|----------|---------|
| Repeated patterns | Authentication flow used in multiple graphs |
| Complex sub-workflows | Multi-step data validation pipeline |
| Domain separation | Billing logic vs. User management logic |
| Conditional complexity | Different complex paths for different conditions |

⚠️ **Avoid subgraphs when:**

| Scenario | Better Pattern |
|----------|----------------|
| Simple 2-3 node sequences | Keep in parent graph |
| Tight coupling needed | Single graph with shared state |
| One-time use | Not worth the abstraction overhead |

---

## Creating a Subgraph

```
    ┌─────────────────────────────────────────────────────────────────┐
    │                    SUBGRAPH CREATION STEPS                       │
    ├─────────────────────────────────────────────────────────────────┤
    │                                                                  │
    │   1. DEFINE SUBGRAPH STATE                                       │
    │      ┌────────────────────────────────────────────────────────┐ │
    │      │  class SubState(TypedDict):                            │ │
    │      │      input_data: str     # What it receives            │ │
    │      │      output_data: str    # What it produces            │ │
    │      └────────────────────────────────────────────────────────┘ │
    │                                                                  │
    │   2. BUILD THE SUBGRAPH                                          │
    │      ┌────────────────────────────────────────────────────────┐ │
    │      │  subgraph = StateGraph(SubState)                       │ │
    │      │  subgraph.add_node("step1", step1_func)                │ │
    │      │  subgraph.add_node("step2", step2_func)                │ │
    │      │  subgraph.add_edge(START, "step1")                     │ │
    │      │  subgraph.add_edge("step1", "step2")                   │ │
    │      │  subgraph.add_edge("step2", END)                       │ │
    │      └────────────────────────────────────────────────────────┘ │
    │                                                                  │
    │   3. COMPILE THE SUBGRAPH                                        │
    │      ┌────────────────────────────────────────────────────────┐ │
    │      │  compiled_subgraph = subgraph.compile()                │ │
    │      └────────────────────────────────────────────────────────┘ │
    │                                                                  │
    │   4. ADD TO PARENT GRAPH AS A NODE                               │
    │      ┌────────────────────────────────────────────────────────┐ │
    │      │  parent_graph.add_node("my_subgraph", compiled_subgraph)│ │
    │      └────────────────────────────────────────────────────────┘ │
    │                                                                  │
    └─────────────────────────────────────────────────────────────────┘
```

---

## State Management with Subgraphs

📌 **Key Concept**: Subgraphs can have their own state schema that differs from the parent.

```
    Parent State                     Subgraph State
    ┌────────────────────┐          ┌────────────────────┐
    │ user_id: "123"     │          │ data_to_process: ? │
    │ query: "help"      │  ──?──▶  │ result: ?          │
    │ session: {...}     │          └────────────────────┘
    │ result: None       │
    └────────────────────┘
    
    How do states connect?
```

### State Sharing Approaches

```
    ┌─────────────────────────────────────────────────────────────────┐
    │              APPROACH 1: Shared State Schema                     │
    ├─────────────────────────────────────────────────────────────────┤
    │                                                                  │
    │   Both parent and subgraph use the SAME state type.              │
    │   State flows through directly.                                  │
    │                                                                  │
    │   class SharedState(TypedDict):                                  │
    │       data: str                                                  │
    │       processed: str                                             │
    │                                                                  │
    │   parent_graph = StateGraph(SharedState)                         │
    │   sub_graph = StateGraph(SharedState)  # Same type!              │
    │                                                                  │
    └─────────────────────────────────────────────────────────────────┘

    ┌─────────────────────────────────────────────────────────────────┐
    │              APPROACH 2: State Transformation                    │
    ├─────────────────────────────────────────────────────────────────┤
    │                                                                  │
    │   Use wrapper nodes to transform state between schemas.          │
    │                                                                  │
    │   def prepare_for_subgraph(parent_state):                        │
    │       return {                                                   │
    │           "sub_input": parent_state["query"]                     │
    │       }                                                          │
    │                                                                  │
    │   def extract_from_subgraph(sub_state):                          │
    │       return {                                                   │
    │           "result": sub_state["sub_output"]                      │
    │       }                                                          │
    │                                                                  │
    │   parent → prepare → [subgraph] → extract → parent               │
    │                                                                  │
    └─────────────────────────────────────────────────────────────────┘
```

---

## Subgraph Execution Flow

```
    Parent Graph Execution with Subgraph:

    ┌─────────────────────────────────────────────────────────────────┐
    │                                                                 │
    │   PARENT: START                                                 │
    │       │                                                         │
    │       ▼                                                         │
    │   PARENT: node_a                                                │
    │       │                                                         │
    │       ▼                                                         │
    │   PARENT: subgraph_node ──────────────────────┐                │
    │       │                                        │                │
    │       │    ┌──────────────────────────────────┼────────────┐   │
    │       │    │ SUBGRAPH EXECUTION:              │            │   │
    │       │    │                                  ▼            │   │
    │       │    │    sub_START → sub_a → sub_b → sub_END       │   │
    │       │    │                                               │   │
    │       │    └───────────────────────────────────────────────┘   │
    │       │                                        │                │
    │       ◄────────────────────────────────────────┘                │
    │       │                                                         │
    │       ▼                                                         │
    │   PARENT: node_b                                                │
    │       │                                                         │
    │       ▼                                                         │
    │   PARENT: END                                                   │
    │                                                                 │
    └─────────────────────────────────────────────────────────────────┘
```

---

## Nested Subgraphs

Subgraphs can contain other subgraphs (but keep nesting reasonable!):

```
    ┌─────────────────────────────────────────────────────────────────┐
    │                        PARENT GRAPH                              │
    │                                                                  │
    │   ┌───────────────────────────────────────────────────────┐     │
    │   │                    SUBGRAPH A                          │     │
    │   │                                                        │     │
    │   │   ┌────────────────────────────────────────┐          │     │
    │   │   │           SUBGRAPH A.1                  │          │     │
    │   │   │                                         │          │     │
    │   │   │   ┌─────┐     ┌─────┐                  │          │     │
    │   │   │   │ A1a │────▶│ A1b │                  │          │     │
    │   │   │   └─────┘     └─────┘                  │          │     │
    │   │   │                                         │          │     │
    │   │   └────────────────────────────────────────┘          │     │
    │   │                                                        │     │
    │   └───────────────────────────────────────────────────────┘     │
    │                                                                  │
    │   ⚠️ Don't nest too deeply - harder to debug and maintain!      │
    │                                                                  │
    └─────────────────────────────────────────────────────────────────┘
```

---

## Interview Tip

```
┌─────────────────────────────────────────────────────────────────────┐
│ 💡 INTERVIEW TIP                                                    │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│ Q: "What are the benefits of using subgraphs in LangGraph?"         │
│                                                                     │
│ A: "Subgraphs provide several key benefits:                         │
│                                                                     │
│    1. MODULARITY: Break complex graphs into manageable units.       │
│       Each subgraph has a single responsibility.                    │
│                                                                     │
│    2. REUSABILITY: A compiled subgraph can be used in multiple      │
│       parent graphs. For example, an authentication subgraph        │
│       could be used by multiple different applications.             │
│                                                                     │
│    3. INDEPENDENT TESTING: You can unit test subgraphs in           │
│       isolation before integrating them into the parent graph.      │
│                                                                     │
│    4. ENCAPSULATION: Internal complexity is hidden from the         │
│       parent graph. The parent only sees a single 'node'.           │
│                                                                     │
│    5. TEAM SCALABILITY: Different teams can own different           │
│       subgraphs, enabling parallel development.                     │
│                                                                     │
│    The main tradeoff is added complexity in state management        │
│    when subgraph and parent states differ."                         │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Code Structure

```python
from langgraph.graph import StateGraph, START, END

# ============================================================
# 1. DEFINE SUBGRAPH
# ============================================================
class SubState(TypedDict):
    task: str
    result: str

def sub_step1(state):
    return {"result": f"Processed: {state['task']}"}

def sub_step2(state):
    return {"result": f"Validated: {state['result']}"}

# Build subgraph
subgraph = StateGraph(SubState)
subgraph.add_node("step1", sub_step1)
subgraph.add_node("step2", sub_step2)
subgraph.add_edge(START, "step1")
subgraph.add_edge("step1", "step2")
subgraph.add_edge("step2", END)

# Compile subgraph
compiled_sub = subgraph.compile()

# ============================================================
# 2. USE SUBGRAPH IN PARENT
# ============================================================
class ParentState(TypedDict):
    task: str       # Shared key!
    result: str     # Shared key!
    meta: str       # Parent-only key

# Add compiled subgraph as a node
parent = StateGraph(ParentState)
parent.add_node("prepare", prepare_task)
parent.add_node("process", compiled_sub)  # <-- Subgraph!
parent.add_node("finalize", finalize_result)

parent.add_edge(START, "prepare")
parent.add_edge("prepare", "process")
parent.add_edge("process", "finalize")
parent.add_edge("finalize", END)
```

---

## Common Subgraph Patterns

### Pattern 1: Validation Subgraph

```
    ┌─────────────────────────────────────────────────────────────────┐
    │                    VALIDATION SUBGRAPH                          │
    │                                                                 │
    │   ┌──────────┐     ┌──────────┐     ┌──────────┐               │
    │   │  Schema  │────▶│  Format  │────▶│ Business │               │
    │   │ Validate │     │  Check   │     │  Rules   │               │
    │   └──────────┘     └──────────┘     └──────────┘               │
    │                                                                 │
    │   Input: raw_data                                               │
    │   Output: validated_data, validation_errors                     │
    │                                                                 │
    │   Reuse in: User registration, Order processing, API inputs    │
    └─────────────────────────────────────────────────────────────────┘
```

### Pattern 2: Multi-Model Ensemble Subgraph

```
    ┌─────────────────────────────────────────────────────────────────┐
    │                    ENSEMBLE SUBGRAPH                            │
    │                                                                 │
    │                        ┌───────────┐                            │
    │                        │ Distribute│                            │
    │                        └─────┬─────┘                            │
    │                   ┌──────────┼──────────┐                       │
    │                   ▼          ▼          ▼                       │
    │              ┌─────────┐┌─────────┐┌─────────┐                  │
    │              │ Model A ││ Model B ││ Model C │                  │
    │              └────┬────┘└────┬────┘└────┬────┘                  │
    │                   └──────────┼──────────┘                       │
    │                              ▼                                  │
    │                        ┌───────────┐                            │
    │                        │ Aggregate │                            │
    │                        └───────────┘                            │
    │                                                                 │
    │   Use: Get consensus from multiple LLMs                         │
    └─────────────────────────────────────────────────────────────────┘
```

### Pattern 3: Error Recovery Subgraph

```
    ┌─────────────────────────────────────────────────────────────────┐
    │                   ERROR RECOVERY SUBGRAPH                       │
    │                                                                 │
    │   ┌──────────┐     ┌──────────┐     ┌──────────┐               │
    │   │  Parse   │────▶│  Log     │────▶│ Generate │               │
    │   │  Error   │     │  Details │     │ Response │               │
    │   └──────────┘     └──────────┘     └──────────┘               │
    │                                                                 │
    │   Use: Standardized error handling across the application       │
    └─────────────────────────────────────────────────────────────────┘
```

---

## Best Practices

| Practice | Description |
|----------|-------------|
| **Clear Interfaces** | Document what state keys the subgraph expects and produces |
| **Minimal Coupling** | Subgraphs should be as independent as possible |
| **Version Control** | Treat subgraphs as separate modules with versions |
| **Error Propagation** | Decide how subgraph errors bubble up to parent |
| **Testing First** | Test subgraphs in isolation before integration |

---

## Summary

```
┌─────────────────────────────────────────────────────────────────────┐
│                        KEY TAKEAWAYS                                │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ✅ Subgraphs are compiled graphs used as nodes in parent graphs    │
│                                                                     │
│  ✅ Enable modularity, reusability, and independent testing         │
│                                                                     │
│  ✅ State can be shared (same schema) or transformed between graphs │
│                                                                     │
│  ✅ To the parent, a subgraph looks like a single node              │
│                                                                     │
│  ✅ Compile subgraph first, then add to parent with add_node()      │
│                                                                     │
│  ✅ Subgraphs can be nested, but avoid deep nesting                 │
│                                                                     │
│  ⚠️  Plan state management carefully when schemas differ            │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Next Steps

Continue to [08_subgraph_example.py](./08_subgraph_example.py) to see subgraphs in action
with a document processing pipeline that uses reusable validation and enrichment subgraphs!
