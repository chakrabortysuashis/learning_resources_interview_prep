# Topic 4: Graph Patterns in LangGraph

## Overview

Graph patterns are the **architectural blueprints** for building AI workflows. Just like a city planner
designs road networks for different traffic patterns, you'll learn to design graph structures for
different AI task requirements.

```
    ╔═══════════════════════════════════════════════════════════════╗
    ║                    GRAPH PATTERNS TOOLKIT                      ║
    ╠═══════════════════════════════════════════════════════════════╣
    ║                                                                ║
    ║   SEQUENTIAL          BRANCHING           CYCLES/LOOPS         ║
    ║   ┌───┐               ┌───┐               ┌───────────┐        ║
    ║   │ A │               │ A │               │     A     │        ║
    ║   └─┬─┘               └─┬─┘               └─────┬─────┘        ║
    ║     │                 ┌─┴─┐                     │              ║
    ║     ▼                 ▼   ▼                     ▼              ║
    ║   ┌───┐             ┌───┐ ┌───┐           ┌─────────┐         ║
    ║   │ B │             │ B │ │ C │           │    B    │◄────┐   ║
    ║   └─┬─┘             └─┬─┘ └─┬─┘           └────┬────┘     │   ║
    ║     │                 └──┬──┘                  │          │   ║
    ║     ▼                    ▼                     ▼          │   ║
    ║   ┌───┐               ┌───┐               ┌─────────┐     │   ║
    ║   │ C │               │ D │               │ Check?  │─────┘   ║
    ║   └───┘               └───┘               └─────────┘         ║
    ║                                                                ║
    ║   SUBGRAPHS           PARALLEL                                 ║
    ║   ┌─────────────┐     ┌───┐                                   ║
    ║   │ ┌───┐ ┌───┐ │     │ A │                                   ║
    ║   │ │ A │→│ B │ │     └─┬─┘                                   ║
    ║   │ └───┘ └───┘ │   ┌───┼───┐                                 ║
    ║   └─────────────┘   ▼   ▼   ▼                                 ║
    ║        │          ┌───┐┌───┐┌───┐                             ║
    ║        ▼          │ B ││ C ││ D │  (parallel)                 ║
    ║   ┌─────────────┐ └─┬─┘└─┬─┘└─┬─┘                             ║
    ║   │ ┌───┐ ┌───┐ │   └────┼────┘                               ║
    ║   │ │ C │→│ D │ │        ▼                                    ║
    ║   │ └───┘ └───┘ │     ┌───┐                                   ║
    ║   └─────────────┘     │ E │                                   ║
    ║                       └───┘                                   ║
    ╚═══════════════════════════════════════════════════════════════╝
```

---

## Learning Objectives

By the end of this module, you will be able to:

| # | Objective | File(s) |
|---|-----------|---------|
| 1 | Design **sequential workflows** for step-by-step processing | `01`, `02` |
| 2 | Implement **branching and merging** patterns for conditional logic | `03`, `04` |
| 3 | Create **cycles and loops** for iterative agent behaviors | `05`, `06` |
| 4 | Compose **subgraphs** for modular, reusable components | `07`, `08` |
| 5 | Execute nodes in **parallel** for performance optimization | `09`, `10` |

---

## When to Use Each Pattern

```
┌─────────────────────────────────────────────────────────────────────┐
│                    PATTERN SELECTION GUIDE                          │
├─────────────────────┬───────────────────────────────────────────────┤
│ PATTERN             │ USE WHEN...                                   │
├─────────────────────┼───────────────────────────────────────────────┤
│ Sequential          │ Tasks must happen in strict order             │
│                     │ Each step depends on the previous             │
│                     │ Example: Parse → Validate → Process → Save    │
├─────────────────────┼───────────────────────────────────────────────┤
│ Branching/Merging   │ Different paths based on conditions           │
│                     │ Multiple outcomes possible                     │
│                     │ Example: Route queries to different handlers  │
├─────────────────────┼───────────────────────────────────────────────┤
│ Cycles/Loops        │ Iterative refinement needed                   │
│                     │ Agent needs multiple attempts                 │
│                     │ Example: Self-correcting code generation      │
├─────────────────────┼───────────────────────────────────────────────┤
│ Subgraphs           │ Complex workflows need organization           │
│                     │ Reusable components across graphs             │
│                     │ Example: Auth flow used in multiple places    │
├─────────────────────┼───────────────────────────────────────────────┤
│ Parallel Execution  │ Independent tasks can run simultaneously      │
│                     │ Performance optimization needed               │
│                     │ Example: Fetch data from multiple APIs        │
└─────────────────────┴───────────────────────────────────────────────┘
```

---

## Module Structure

```
_04_graph_patterns/
├── README.md                      # You are here
├── 01_sequential_workflows.md     # Theory: Sequential patterns
├── 02_sequential_example.py       # Code: Sequential workflow
├── 03_branching_merging.md        # Theory: Branching patterns
├── 04_branching_example.py        # Code: Conditional branching
├── 05_cycles_loops.md             # Theory: Cycles and loops
├── 06_cycles_example.py           # Code: Agent loop example
├── 07_subgraphs.md                # Theory: Subgraph composition
├── 08_subgraph_example.py         # Code: Subgraph example
├── 09_parallel_execution.md       # Theory: Parallel patterns
└── 10_parallel_example.py         # Code: Parallel execution
```

---

## Prerequisites

Before starting this module, ensure you understand:

- Topic 1: LangGraph Foundations (StateGraph basics)
- Topic 2: Core Concepts (State, Nodes, Edges)
- Basic Python typing (TypedDict, Annotated)

---

## Real-World Analogy: Restaurant Kitchen

Think of graph patterns like a restaurant kitchen workflow:

| Pattern | Kitchen Analogy |
|---------|-----------------|
| **Sequential** | Prep → Cook → Plate → Serve (one after another) |
| **Branching** | Different cooking methods based on order (grill vs fry vs bake) |
| **Cycles** | Taste → Adjust seasoning → Taste again (until perfect) |
| **Subgraphs** | Sauce station has its own workflow, used by multiple dishes |
| **Parallel** | Multiple burners cooking different components simultaneously |

---

## Quick Reference Card

```python
# Sequential: A → B → C
graph.add_edge("A", "B")
graph.add_edge("B", "C")

# Branching: A → (B or C based on condition)
graph.add_conditional_edges("A", router_function, {"path1": "B", "path2": "C"})

# Merging: B, C → D
graph.add_edge("B", "D")
graph.add_edge("C", "D")

# Cycle: B → Check → B (if condition)
graph.add_conditional_edges("check", should_continue, {"continue": "B", "end": END})

# Subgraph: Compose smaller graphs
parent_graph.add_node("sub", subgraph.compile())

# Parallel: Run B, C, D at same time (via state channels)
# Use Send() API for fan-out
```

---

## Interview Preparation Focus

📌 **Key topics frequently asked in interviews:**

1. When would you choose branching over sequential?
2. How do you prevent infinite loops in cycles?
3. What's the benefit of subgraphs for testing?
4. How does LangGraph handle parallel state updates?
5. Explain fan-out/fan-in patterns

---

## Let's Begin!

Start with [01_sequential_workflows.md](./01_sequential_workflows.md) to learn the simplest but most
fundamental pattern in graph-based AI workflows.

---

*Estimated completion time: 2-3 hours*
