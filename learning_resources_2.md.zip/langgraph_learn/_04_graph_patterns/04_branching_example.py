"""
Branching and Merging Example: Customer Support Router

This example demonstrates a customer support system that:
1. Classifies incoming queries
2. Routes to appropriate handlers (branching)
3. Generates a unified response (merging)

Graph Structure:

                    ┌─────────────────┐
                    │  classify_query │
                    └────────┬────────┘
                             │
           ┌─────────────────┼─────────────────┐
           │                 │                 │
        "billing"       "technical"       "general"
           │                 │                 │
           ▼                 ▼                 ▼
    ┌─────────────┐   ┌─────────────┐   ┌─────────────┐
    │   billing   │   │  technical  │   │   general   │
    │   handler   │   │   handler   │   │   handler   │
    └──────┬──────┘   └──────┬──────┘   └──────┬──────┘
           │                 │                 │
           └─────────────────┼─────────────────┘
                             │
                             ▼
                    ┌─────────────────┐
                    │ format_response │
                    └─────────────────┘
"""

from typing import TypedDict, Literal
from langgraph.graph import StateGraph, START, END


# =============================================================================
# STEP 1: Define the State
# =============================================================================

class SupportState(TypedDict):
    """
    State for customer support workflow.

    Attributes:
        customer_query: The original customer question
        query_type: Classified type (billing/technical/general)
        handler_response: Response from the specific handler
        final_response: Formatted final response to customer
        confidence_score: How confident the classification was
    """
    customer_query: str
    query_type: str
    handler_response: str
    final_response: str
    confidence_score: float


# =============================================================================
# STEP 2: Define Node Functions
# =============================================================================

def classify_query(state: SupportState) -> dict:
    """
    Node: Classify Query

    Analyzes the customer query and determines which category it belongs to.
    In production, this would use an LLM or ML model for classification.

    This node sets query_type which the router will use to branch.
    """
    print("🔍 Classifying query...")

    query = state["customer_query"].lower()

    # Simple keyword-based classification
    # In production, use an LLM or trained classifier

    billing_keywords = ["bill", "payment", "charge", "invoice", "refund", "price", "cost", "subscription"]
    technical_keywords = ["error", "bug", "crash", "not working", "issue", "problem", "fix", "broken", "slow"]

    # Count keyword matches
    billing_score = sum(1 for kw in billing_keywords if kw in query)
    technical_score = sum(1 for kw in technical_keywords if kw in query)

    # Determine category and confidence
    if billing_score > technical_score and billing_score > 0:
        query_type = "billing"
        confidence = min(0.5 + billing_score * 0.15, 0.95)
    elif technical_score > billing_score and technical_score > 0:
        query_type = "technical"
        confidence = min(0.5 + technical_score * 0.15, 0.95)
    else:
        query_type = "general"
        confidence = 0.6  # Default confidence for general queries

    print(f"   Classified as: {query_type} (confidence: {confidence:.2f})")

    return {
        "query_type": query_type,
        "confidence_score": confidence
    }


def billing_handler(state: SupportState) -> dict:
    """
    Node: Billing Handler

    Handles billing-related queries.
    This would integrate with billing systems in production.
    """
    print("💰 Billing handler processing...")

    query = state["customer_query"].lower()

    # Simulate different billing responses based on keywords
    if "refund" in query:
        response = (
            "I understand you're inquiring about a refund. "
            "Refunds are typically processed within 5-7 business days. "
            "Please provide your order number for faster assistance."
        )
    elif "invoice" in query:
        response = (
            "For invoice requests, you can download your invoices directly "
            "from your account dashboard under 'Billing History'. "
            "Would you like me to guide you through the process?"
        )
    elif "subscription" in query:
        response = (
            "Regarding your subscription, you can manage your plan, "
            "upgrade, downgrade, or cancel anytime from your account settings. "
            "What specific changes would you like to make?"
        )
    else:
        response = (
            "Thank you for your billing inquiry. Our billing team "
            "is here to help. Could you please provide more details "
            "about your billing concern?"
        )

    return {"handler_response": response}


def technical_handler(state: SupportState) -> dict:
    """
    Node: Technical Handler

    Handles technical support queries.
    This would integrate with ticketing systems in production.
    """
    print("🔧 Technical handler processing...")

    query = state["customer_query"].lower()

    # Simulate different technical responses
    if "error" in query or "bug" in query:
        response = (
            "I see you're experiencing an error. Let's troubleshoot this together. "
            "First, could you try clearing your browser cache and cookies? "
            "If the issue persists, please share the exact error message you're seeing."
        )
    elif "slow" in query:
        response = (
            "Performance issues can be frustrating. Here are some steps to try: "
            "1) Check your internet connection, 2) Close unnecessary tabs, "
            "3) Try a different browser. Let me know if the issue continues."
        )
    elif "not working" in query or "broken" in query:
        response = (
            "I'm sorry to hear something isn't working properly. "
            "To help you better, could you describe: "
            "1) What you were trying to do, "
            "2) What happened instead, "
            "3) Any error messages you saw?"
        )
    else:
        response = (
            "Thank you for reaching out to technical support. "
            "I'm here to help resolve your issue. "
            "Could you provide more details about the problem you're experiencing?"
        )

    return {"handler_response": response}


def general_handler(state: SupportState) -> dict:
    """
    Node: General Handler

    Handles general inquiries that don't fit billing or technical categories.
    """
    print("📋 General handler processing...")

    query = state["customer_query"].lower()

    # Simulate different general responses
    if "hours" in query or "contact" in query:
        response = (
            "Our support team is available 24/7 via chat and email. "
            "Phone support is available Monday-Friday, 9 AM - 6 PM EST. "
            "How else can I assist you today?"
        )
    elif "feature" in query or "request" in query:
        response = (
            "Thank you for your feature suggestion! We love hearing from our users. "
            "I'll make sure to pass this along to our product team. "
            "Is there anything else I can help you with?"
        )
    else:
        response = (
            "Thank you for contacting us! I'm happy to help answer "
            "any questions you have. Could you please provide more "
            "details about what you'd like to know?"
        )

    return {"handler_response": response}


def format_response(state: SupportState) -> dict:
    """
    Node: Format Response (Merge Point)

    This node receives responses from ANY of the handler branches
    and formats them into a consistent final response.

    This is the "merge" point where all branches converge.
    """
    print("📝 Formatting final response...")

    query_type = state["query_type"]
    handler_response = state["handler_response"]
    confidence = state["confidence_score"]

    # Add appropriate prefix based on query type
    type_emoji = {
        "billing": "💰",
        "technical": "🔧",
        "general": "📋"
    }

    emoji = type_emoji.get(query_type, "📋")

    # Format the final response
    final_response = f"""
{emoji} Support Response
{'=' * 40}

Category: {query_type.title()} Support
Confidence: {confidence:.0%}

{handler_response}

{'=' * 40}
Thank you for using our support service!
    """.strip()

    return {"final_response": final_response}


# =============================================================================
# STEP 3: Define the Router Function
# =============================================================================

def route_to_handler(state: SupportState) -> Literal["billing", "technical", "general"]:
    """
    Router Function: Decides which handler to route to.

    This function is used with add_conditional_edges().
    It examines the state and returns the name of the next node.

    Returns:
        str: The name of the handler node to route to
    """
    query_type = state["query_type"]

    print(f"🔀 Routing to {query_type} handler...")

    # Return the node name based on query type
    # The returned string must match a node name in the graph
    if query_type == "billing":
        return "billing"
    elif query_type == "technical":
        return "technical"
    else:
        return "general"


# =============================================================================
# STEP 4: Build the Graph
# =============================================================================

def create_support_graph() -> StateGraph:
    """
    Creates the customer support workflow graph with branching and merging.
    """
    # Initialize graph with state schema
    graph = StateGraph(SupportState)

    # Add all nodes
    graph.add_node("classify", classify_query)
    graph.add_node("billing", billing_handler)
    graph.add_node("technical", technical_handler)
    graph.add_node("general", general_handler)
    graph.add_node("format", format_response)

    # Define the flow

    # 1. Start with classification
    graph.add_edge(START, "classify")

    # 2. Branch based on classification (conditional edges)
    graph.add_conditional_edges(
        "classify",              # Source node (after this node completes...)
        route_to_handler,        # Router function (call this to decide...)
        {                        # Path map (map return values to node names)
            "billing": "billing",
            "technical": "technical",
            "general": "general"
        }
    )

    # 3. Merge: All handlers converge to format_response
    graph.add_edge("billing", "format")
    graph.add_edge("technical", "format")
    graph.add_edge("general", "format")

    # 4. End after formatting
    graph.add_edge("format", END)

    return graph


# =============================================================================
# STEP 5: Alternative - Using Path Map with Enum
# =============================================================================
# This is a cleaner approach for larger applications

from enum import Enum

class QueryType(Enum):
    BILLING = "billing"
    TECHNICAL = "technical"
    GENERAL = "general"


def route_with_enum(state: SupportState) -> str:
    """
    Alternative router using enum for type safety.
    """
    query_type = state["query_type"]

    type_mapping = {
        "billing": QueryType.BILLING.value,
        "technical": QueryType.TECHNICAL.value,
        "general": QueryType.GENERAL.value
    }

    return type_mapping.get(query_type, QueryType.GENERAL.value)


# =============================================================================
# STEP 6: Run Examples
# =============================================================================

def main():
    """
    Main function demonstrating the branching workflow.
    """
    print("=" * 60)
    print("BRANCHING & MERGING: Customer Support Router")
    print("=" * 60)
    print()

    # Create and compile the graph
    graph = create_support_graph()
    app = graph.compile()

    # Test queries for different branches
    test_queries = [
        "I need a refund for my last payment, it was charged twice!",
        "The app keeps crashing and showing error 500",
        "What are your business hours?",
        "My subscription billing is not working correctly",
    ]

    for i, query in enumerate(test_queries, 1):
        print(f"\n{'=' * 60}")
        print(f"TEST CASE {i}")
        print(f"{'=' * 60}")
        print(f"\n📧 Customer Query: {query}")
        print()

        # Prepare initial state
        initial_state = {
            "customer_query": query,
            "query_type": "",
            "handler_response": "",
            "final_response": "",
            "confidence_score": 0.0
        }

        # Execute the workflow
        result = app.invoke(initial_state)

        print()
        print("📬 Final Response:")
        print("-" * 40)
        print(result["final_response"])
        print()


def demonstrate_streaming():
    """
    Shows how to stream execution to see the branching in action.
    """
    print("\n" + "=" * 60)
    print("STREAMING DEMONSTRATION")
    print("=" * 60)

    graph = create_support_graph()
    app = graph.compile()

    query = "There's an error in my account and my payment failed"

    print(f"\n📧 Query: {query}")
    print("\nExecution trace:")
    print("-" * 40)

    initial_state = {
        "customer_query": query,
        "query_type": "",
        "handler_response": "",
        "final_response": "",
        "confidence_score": 0.0
    }

    # Stream to see each node execution
    for event in app.stream(initial_state):
        for node_name, output in event.items():
            print(f"\n✅ Completed: {node_name}")
            if "query_type" in output:
                print(f"   → Classified as: {output['query_type']}")


# =============================================================================
# INTERVIEW TIP
# =============================================================================
"""
┌─────────────────────────────────────────────────────────────────────┐
│ 💡 INTERVIEW TIP                                                    │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│ Q: "How would you handle a situation where a query could            │
│     belong to multiple categories?"                                 │
│                                                                     │
│ A: "There are several strategies:                                   │
│                                                                     │
│    1. PRIORITY-BASED: Define a priority order for categories        │
│       and pick the highest-priority match.                          │
│                                                                     │
│    2. CONFIDENCE THRESHOLD: Only accept a classification if         │
│       confidence exceeds a threshold; otherwise, route to a         │
│       human agent or ask for clarification.                         │
│                                                                     │
│    3. MULTI-LABEL: Use the Send() API to route to MULTIPLE          │
│       handlers in parallel, then merge their responses.             │
│                                                                     │
│    4. HYBRID: Route to a 'multi-handler' node that can              │
│       address multiple concerns in a single response.               │
│                                                                     │
│    The best approach depends on your use case. For customer         │
│    support, I might use confidence thresholds to escalate           │
│    ambiguous queries to human agents."                              │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
"""


# =============================================================================
# BONUS: Early Exit Pattern
# =============================================================================

def create_graph_with_early_exit() -> StateGraph:
    """
    Demonstrates early exit pattern - ending execution based on conditions.
    """

    def check_spam(state: SupportState) -> dict:
        """Check if query is spam and should be rejected."""
        query = state["customer_query"].lower()
        spam_indicators = ["buy now", "free money", "click here", "winner"]

        is_spam = any(indicator in query for indicator in spam_indicators)
        return {"query_type": "spam" if is_spam else ""}

    def spam_router(state: SupportState) -> str:
        """Route spam to END, legitimate queries to classification."""
        if state["query_type"] == "spam":
            print("🚫 Spam detected - terminating")
            return END
        return "classify"

    graph = StateGraph(SupportState)

    graph.add_node("spam_check", check_spam)
    graph.add_node("classify", classify_query)
    graph.add_node("billing", billing_handler)
    graph.add_node("technical", technical_handler)
    graph.add_node("general", general_handler)
    graph.add_node("format", format_response)

    graph.add_edge(START, "spam_check")

    # Conditional: Either END (spam) or continue to classify
    graph.add_conditional_edges(
        "spam_check",
        spam_router,
        {
            END: END,
            "classify": "classify"
        }
    )

    graph.add_conditional_edges("classify", route_to_handler)

    graph.add_edge("billing", "format")
    graph.add_edge("technical", "format")
    graph.add_edge("general", "format")
    graph.add_edge("format", END)

    return graph


if __name__ == "__main__":
    main()
    demonstrate_streaming()
