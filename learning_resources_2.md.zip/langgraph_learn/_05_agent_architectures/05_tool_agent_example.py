"""
Tool Calling Agent Example in LangGraph
========================================

This module demonstrates a practical tool-calling agent that can:
- Search for information
- Perform calculations
- Look up weather data
- Get current date/time
- Manage a simple todo list

The agent dynamically selects and calls tools based on user queries.

Architecture:
                    +-------+
                    | START |
                    +-------+
                        |
                        v
                    +-------+
            +-----> | AGENT | -----+
            |       +-------+      |
            |           |          |
            |      has tools?   no tools
            |           |          |
            |           v          v
            |       +-------+   +-----+
            +------ | TOOLS |   | END |
          (loop)    +-------+   +-----+

Author: Learning Module
Topic: Agent Architectures - Tool Calling Agents
"""

from typing import TypedDict, Annotated, Literal, Optional
from langgraph.graph import StateGraph, START, END
from langchain_core.messages import HumanMessage, AIMessage, ToolMessage, SystemMessage
from langchain_openai import ChatOpenAI
from langchain_core.tools import tool
import operator
from datetime import datetime
import json


# =============================================================================
# SECTION 1: DEFINE TOOLS
# =============================================================================
# Each tool is a capability the agent can use

@tool
def web_search(query: str) -> str:
    """
    Search the web for current information.

    Use this tool when you need to find facts, current events,
    or information that might not be in your training data.
    Good for: news, facts, definitions, current data.

    Args:
        query: The search query

    Returns:
        Search results as text
    """
    # Mock implementation - in production, use a real search API
    mock_data = {
        "python": "Python is a high-level, interpreted programming language known for its simplicity and readability. Created by Guido van Rossum in 1991.",
        "langgraph": "LangGraph is a library by LangChain for building stateful, multi-actor applications with LLMs. It uses a graph-based architecture.",
        "artificial intelligence": "Artificial Intelligence (AI) is the simulation of human intelligence by machines. It includes machine learning, natural language processing, and robotics.",
        "climate change": "Climate change refers to long-term shifts in global temperatures and weather patterns. Human activities have been the main driver since the 1800s.",
    }

    query_lower = query.lower()
    for key, value in mock_data.items():
        if key in query_lower:
            return f"Search results for '{query}':\n{value}"

    return f"Search results for '{query}': Found general information. The topic relates to {query}. For specific data, try a more detailed query."


@tool
def calculator(expression: str) -> str:
    """
    Perform mathematical calculations.

    Use this tool for any math operations including:
    - Basic arithmetic: +, -, *, /
    - Powers: ** (e.g., 2**3 = 8)
    - Parentheses for grouping
    - Decimal numbers

    Args:
        expression: A mathematical expression (e.g., "2 + 2", "100 / 4", "2 ** 10")

    Returns:
        The calculated result

    Examples:
        "15 * 24" -> "360"
        "(100 + 50) / 3" -> "50.0"
    """
    try:
        # Validate input for safety
        allowed = set("0123456789+-*/.()" + " ")
        if not all(c in allowed for c in expression):
            return f"Error: Invalid characters in expression. Only numbers and +-*/() allowed."

        result = eval(expression)
        return f"Calculation: {expression} = {result}"
    except ZeroDivisionError:
        return "Error: Division by zero is not allowed."
    except SyntaxError:
        return f"Error: Invalid mathematical expression: {expression}"
    except Exception as e:
        return f"Error: Could not calculate '{expression}'. {str(e)}"


@tool
def get_weather(city: str, units: str = "celsius") -> str:
    """
    Get current weather information for a city.

    Use this tool when the user asks about weather conditions,
    temperature, or forecasts for a specific location.

    Args:
        city: Name of the city (e.g., "New York", "London", "Tokyo")
        units: Temperature units - "celsius" or "fahrenheit" (default: celsius)

    Returns:
        Current weather conditions including temperature, conditions, humidity
    """
    # Mock weather data
    weather_db = {
        "new york": {"temp_c": 22, "temp_f": 72, "condition": "Partly Cloudy", "humidity": 65},
        "london": {"temp_c": 15, "temp_f": 59, "condition": "Rainy", "humidity": 80},
        "tokyo": {"temp_c": 28, "temp_f": 82, "condition": "Sunny", "humidity": 55},
        "paris": {"temp_c": 20, "temp_f": 68, "condition": "Clear", "humidity": 60},
        "sydney": {"temp_c": 18, "temp_f": 64, "condition": "Windy", "humidity": 70},
    }

    city_lower = city.lower()
    if city_lower in weather_db:
        data = weather_db[city_lower]
        temp = data["temp_c"] if units == "celsius" else data["temp_f"]
        unit_symbol = "C" if units == "celsius" else "F"
        return f"Weather in {city}: {temp}°{unit_symbol}, {data['condition']}, Humidity: {data['humidity']}%"

    return f"Weather data not available for '{city}'. Try a major city like New York, London, or Tokyo."


@tool
def get_datetime() -> str:
    """
    Get the current date and time.

    Use this tool when the user asks about:
    - Current date
    - Current time
    - Today's date
    - What day it is

    Returns:
        Current date and time information
    """
    now = datetime.now()
    return f"Current date and time: {now.strftime('%A, %B %d, %Y at %I:%M %p')}"


# Simple in-memory todo list for demonstration
TODO_LIST = []

@tool
def add_todo(task: str, priority: str = "medium") -> str:
    """
    Add a task to the todo list.

    Use this when the user wants to:
    - Add a task
    - Remember something
    - Create a todo item

    Args:
        task: The task description
        priority: Priority level - "high", "medium", or "low" (default: medium)

    Returns:
        Confirmation of the added task
    """
    todo_item = {
        "id": len(TODO_LIST) + 1,
        "task": task,
        "priority": priority,
        "created": datetime.now().isoformat(),
        "completed": False
    }
    TODO_LIST.append(todo_item)
    return f"Added task #{todo_item['id']}: '{task}' with {priority} priority. You now have {len(TODO_LIST)} tasks."


@tool
def list_todos() -> str:
    """
    List all tasks in the todo list.

    Use this when the user wants to:
    - See their tasks
    - Check their todo list
    - View pending items

    Returns:
        List of all todo items
    """
    if not TODO_LIST:
        return "Your todo list is empty. Add tasks using the add_todo tool."

    result = "Your Todo List:\n"
    for item in TODO_LIST:
        status = "DONE" if item["completed"] else "PENDING"
        result += f"  #{item['id']} [{status}] ({item['priority'].upper()}) - {item['task']}\n"

    return result


@tool
def complete_todo(task_id: int) -> str:
    """
    Mark a task as completed.

    Use this when the user wants to:
    - Complete a task
    - Mark something as done
    - Check off an item

    Args:
        task_id: The ID number of the task to complete

    Returns:
        Confirmation of completion
    """
    for item in TODO_LIST:
        if item["id"] == task_id:
            item["completed"] = True
            return f"Task #{task_id} '{item['task']}' marked as completed!"

    return f"Task #{task_id} not found. Use list_todos to see available tasks."


# Collect all tools
TOOLS = [
    web_search,
    calculator,
    get_weather,
    get_datetime,
    add_todo,
    list_todos,
    complete_todo
]

# Create tool mapping
TOOL_MAP = {t.name: t for t in TOOLS}


# =============================================================================
# SECTION 2: DEFINE STATE
# =============================================================================

class AgentState(TypedDict):
    """
    State for the tool-calling agent.

    Attributes:
        messages: Conversation history (accumulates with each turn)
        tool_call_count: Number of tool calls made (for monitoring)
    """
    messages: Annotated[list, operator.add]
    tool_call_count: int


# =============================================================================
# SECTION 3: CREATE AGENT NODE
# =============================================================================

def create_agent(model_name: str = "gpt-4o-mini"):
    """
    Create the agent node with tools bound to the LLM.

    Args:
        model_name: The OpenAI model to use

    Returns:
        Agent node function
    """
    # Initialize LLM
    llm = ChatOpenAI(model=model_name, temperature=0)

    # Bind tools to LLM
    llm_with_tools = llm.bind_tools(TOOLS)

    def agent_node(state: AgentState) -> dict:
        """
        The agent decides what to do based on the conversation.

        Steps:
        1. Read conversation history
        2. Decide: respond directly OR call a tool
        3. Return the decision
        """
        print(f"\n[AGENT] Processing...")

        # System prompt defining agent behavior
        system = SystemMessage(content="""You are a helpful AI assistant with access to various tools.

Available capabilities:
- Web search for information
- Mathematical calculations
- Weather lookups
- Date/time queries
- Todo list management (add, list, complete tasks)

Guidelines:
1. Use tools when they're helpful, but don't overuse them
2. For simple questions you know, answer directly
3. Combine multiple tool results when needed
4. Be concise but thorough
5. If a tool fails, explain the issue and try alternatives""")

        # Build message list
        messages = [system] + state["messages"]

        # Invoke LLM
        response = llm_with_tools.invoke(messages)

        # Log for debugging
        if response.tool_calls:
            tools_called = [tc["name"] for tc in response.tool_calls]
            print(f"[AGENT] Calling tools: {tools_called}")
        else:
            print(f"[AGENT] Responding directly")

        return {"messages": [response]}

    return agent_node


# =============================================================================
# SECTION 4: CREATE TOOLS NODE
# =============================================================================

def tools_node(state: AgentState) -> dict:
    """
    Execute tools requested by the agent.

    This node:
    1. Gets the last AI message (with tool calls)
    2. Executes each tool call
    3. Returns results as ToolMessages
    """
    print(f"\n[TOOLS] Executing...")

    messages = state["messages"]
    last_message = messages[-1]

    results = []
    tool_count = state.get("tool_call_count", 0)

    for tool_call in last_message.tool_calls:
        name = tool_call["name"]
        args = tool_call["args"]
        call_id = tool_call["id"]

        print(f"  - {name}({args})")

        # Execute the tool
        if name in TOOL_MAP:
            try:
                result = TOOL_MAP[name].invoke(args)
            except Exception as e:
                result = f"Tool error: {str(e)}"
        else:
            result = f"Unknown tool: {name}"

        print(f"    Result: {result[:100]}..." if len(str(result)) > 100 else f"    Result: {result}")

        # Create ToolMessage
        results.append(ToolMessage(content=str(result), tool_call_id=call_id))
        tool_count += 1

    return {
        "messages": results,
        "tool_call_count": tool_count
    }


# =============================================================================
# SECTION 5: ROUTING LOGIC
# =============================================================================

def should_continue(state: AgentState) -> Literal["tools", "end"]:
    """
    Decide whether to continue with tools or end.

    Routes to:
    - "tools": if the last message has tool calls
    - "end": if it's a final response (no tool calls)
    """
    # Prevent infinite loops
    MAX_TOOL_CALLS = 15
    if state.get("tool_call_count", 0) >= MAX_TOOL_CALLS:
        print(f"[ROUTER] Max tool calls reached ({MAX_TOOL_CALLS})")
        return "end"

    messages = state["messages"]
    if not messages:
        return "end"

    last = messages[-1]

    if hasattr(last, "tool_calls") and last.tool_calls:
        return "tools"

    return "end"


# =============================================================================
# SECTION 6: BUILD THE GRAPH
# =============================================================================

def create_tool_agent():
    """
    Build the complete tool-calling agent graph.

    Returns:
        Compiled LangGraph
    """
    # Create graph
    graph = StateGraph(AgentState)

    # Add nodes
    graph.add_node("agent", create_agent())
    graph.add_node("tools", tools_node)

    # Add edges
    graph.add_edge(START, "agent")
    graph.add_conditional_edges(
        "agent",
        should_continue,
        {"tools": "tools", "end": END}
    )
    graph.add_edge("tools", "agent")

    # Compile
    return graph.compile()


# =============================================================================
# SECTION 7: CONVERSATION HELPER
# =============================================================================

def chat(agent, message: str, conversation: list = None) -> tuple[str, list]:
    """
    Send a message to the agent and get a response.

    Args:
        agent: The compiled agent graph
        message: User's message
        conversation: Previous conversation messages (optional)

    Returns:
        Tuple of (response_text, updated_conversation)
    """
    if conversation is None:
        conversation = []

    # Add user message
    conversation.append(HumanMessage(content=message))

    # Create initial state
    state = {
        "messages": conversation,
        "tool_call_count": 0
    }

    # Run agent
    result = agent.invoke(state)

    # Extract response
    final_messages = result["messages"]

    # Find the last AI message (the actual response)
    response = ""
    for msg in reversed(final_messages):
        if isinstance(msg, AIMessage) and msg.content:
            response = msg.content
            break

    return response, final_messages


# =============================================================================
# SECTION 8: INTERACTIVE DEMO
# =============================================================================

def run_demo():
    """
    Run an interactive demonstration of the tool-calling agent.
    """
    print("=" * 60)
    print("TOOL CALLING AGENT DEMO")
    print("=" * 60)
    print("\nThis agent can:")
    print("  - Search the web for information")
    print("  - Perform calculations")
    print("  - Check weather for cities")
    print("  - Tell you the current date/time")
    print("  - Manage a todo list")
    print("\n" + "=" * 60)

    # Create agent
    agent = create_tool_agent()
    conversation = []

    # Demo queries
    demo_queries = [
        "What is LangGraph?",
        "What's 15 * 24 + (100 / 4)?",
        "What's the weather in Tokyo?",
        "Add 'Learn LangGraph' to my todo list with high priority",
        "Also add 'Practice Python' as medium priority",
        "Show me my todo list",
    ]

    for query in demo_queries:
        print(f"\n{'='*60}")
        print(f"USER: {query}")
        print("-" * 60)

        response, conversation = chat(agent, query, conversation)

        print(f"\nASSISTANT: {response}")

    print(f"\n{'='*60}")
    print("Demo complete!")
    print(f"Total messages in conversation: {len(conversation)}")


# =============================================================================
# SECTION 9: INTERACTIVE MODE
# =============================================================================

def run_interactive():
    """
    Run the agent in interactive mode for real conversations.
    """
    print("=" * 60)
    print("INTERACTIVE TOOL AGENT")
    print("=" * 60)
    print("Type 'quit' to exit, 'clear' to reset conversation")
    print("=" * 60)

    agent = create_tool_agent()
    conversation = []

    while True:
        try:
            user_input = input("\nYou: ").strip()

            if not user_input:
                continue

            if user_input.lower() == "quit":
                print("Goodbye!")
                break

            if user_input.lower() == "clear":
                conversation = []
                TODO_LIST.clear()
                print("Conversation and todo list cleared.")
                continue

            response, conversation = chat(agent, user_input, conversation)
            print(f"\nAssistant: {response}")

        except KeyboardInterrupt:
            print("\nGoodbye!")
            break
        except Exception as e:
            print(f"\nError: {e}")


# =============================================================================
# SECTION 10: MAIN
# =============================================================================

if __name__ == "__main__":
    import sys

    print("\nTool Calling Agent Example")
    print("-" * 40)

    if len(sys.argv) > 1 and sys.argv[1] == "--interactive":
        run_interactive()
    else:
        run_demo()


# =============================================================================
# INTERVIEW TIPS
# =============================================================================
"""
Interview Tips for Tool Calling Agents:

1. Q: "How does tool calling work with LLMs?"
   A: "The LLM receives a schema of available tools (name, description,
      parameters). When appropriate, instead of generating text, it returns
      a structured tool call with the function name and arguments. The
      application executes the tool and returns results for the LLM to use."

2. Q: "How do you decide what to make into a tool?"
   A: "Tools should wrap capabilities the LLM lacks: real-time data access,
      computation, external API calls, database queries. Keep tools focused
      and well-documented. The description is crucial - it's how the LLM
      decides when to use each tool."

3. Q: "How do you handle tool errors?"
   A: "Return meaningful error messages that help the LLM recover. Instead of
      raising exceptions, return error strings that the LLM can understand
      and act on. Include suggestions for alternatives when possible."

4. Q: "What about tool safety?"
   A: "Categorize tools by risk level. Read-only tools are generally safe.
      Tools that modify data or perform actions should have validation,
      rate limiting, and possibly human-in-the-loop confirmation using
      LangGraph's interrupt features."

5. Q: "How do you prevent tool call loops?"
   A: "Set maximum iteration limits, track tool call counts, and implement
      loop detection. Good prompting also helps - instruct the LLM to use
      tools only when necessary and to recognize when it has enough
      information."
"""
