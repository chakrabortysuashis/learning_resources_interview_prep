# The ReAct Pattern: Reason + Act

## Introduction

**ReAct** (Reasoning and Acting) is a paradigm that interleaves reasoning traces with action execution. It was introduced in the paper "ReAct: Synergizing Reasoning and Acting in Language Models" and has become the foundation for most modern agent implementations.

The core insight: **LLMs perform better when they "think out loud" before acting.**

---

## The ReAct Loop

```
+------------------------------------------------------------------+
|                      THE REACT LOOP                              |
+------------------------------------------------------------------+
|                                                                  |
|   +----------+      +----------+      +-----------+              |
|   |          |      |          |      |           |              |
|   |  REASON  | ---> |   ACT    | ---> |  OBSERVE  |              |
|   | (Think)  |      | (Do)     |      | (See)     |              |
|   |          |      |          |      |           |              |
|   +----------+      +----------+      +-----------+              |
|        ^                                    |                    |
|        |                                    |                    |
|        +------------------------------------+                    |
|                    (Loop until done)                             |
|                                                                  |
+------------------------------------------------------------------+
```

---

## The Three Components

### 1. REASON (Thought)

The agent explicitly states its reasoning:

```
Thought: The user is asking about the weather in Tokyo.
         I need to use the weather tool to get current data.
         Let me call the weather API with "Tokyo" as the location.
```

### 2. ACT (Action)

The agent executes a specific action:

```
Action: weather_lookup
Action Input: {"location": "Tokyo", "units": "celsius"}
```

### 3. OBSERVE (Observation)

The agent receives and processes the result:

```
Observation: {"temperature": 22, "condition": "Partly Cloudy", 
              "humidity": 65, "wind": "10 km/h NE"}
```

---

## Complete ReAct Trace Example

```
+------------------------------------------------------------------+
|                    REACT TRACE EXAMPLE                           |
+------------------------------------------------------------------+
|                                                                  |
|  User: What's the population of France and its GDP per capita?   |
|                                                                  |
|  -----------------------------------------------------------------
|                                                                  |
|  Thought 1: I need to find two pieces of information:            |
|             1) Population of France                              |
|             2) GDP per capita of France                          |
|             Let me start by searching for France's population.   |
|                                                                  |
|  Action 1: search                                                |
|  Action Input: "France population 2024"                          |
|                                                                  |
|  Observation 1: France has a population of approximately         |
|                 68 million people (2024 estimate).               |
|                                                                  |
|  -----------------------------------------------------------------
|                                                                  |
|  Thought 2: Good, I have the population. Now I need the GDP      |
|             per capita. Let me search for that.                  |
|                                                                  |
|  Action 2: search                                                |
|  Action Input: "France GDP per capita 2024"                      |
|                                                                  |
|  Observation 2: France's GDP per capita is approximately         |
|                 $44,408 USD (2024 estimate).                     |
|                                                                  |
|  -----------------------------------------------------------------
|                                                                  |
|  Thought 3: I now have both pieces of information. I can         |
|             provide a complete answer to the user.               |
|                                                                  |
|  Final Answer: France has a population of approximately          |
|                68 million people with a GDP per capita of        |
|                about $44,408 USD.                                |
|                                                                  |
+------------------------------------------------------------------+
```

---

## ReAct vs Other Patterns

### Comparison Table

```
+------------------------------------------------------------------+
|  Pattern       |  Reasoning  |  Actions  |  Best For            |
+------------------------------------------------------------------+
|  Chain-of-     |     Yes     |    No     |  Pure reasoning      |
|  Thought       |             |           |  tasks               |
+------------------------------------------------------------------+
|  Action-Only   |     No      |    Yes    |  Simple automation   |
|                |             |           |                      |
+------------------------------------------------------------------+
|  ReAct         |     Yes     |    Yes    |  Complex tasks       |
|                |             |           |  requiring both      |
+------------------------------------------------------------------+
```

### Visual Comparison

```
Chain-of-Thought:
  Question --> Think --> Think --> Think --> Answer
                (no external actions)

Action-Only:
  Question --> Action --> Action --> Action --> Answer
                (no explicit reasoning)

ReAct:
  Question --> Think --> Act --> Observe --> Think --> Act --> Answer
                (synergy of reasoning and acting)
```

---

## Benefits of ReAct

### 1. Interpretability

```
+-----------------------------------+
|  WITHOUT ReAct (Black Box)        |
+-----------------------------------+
|  Input: "Find cheap flights"      |
|            |                      |
|            v                      |
|      [  ????  ]                   |
|            |                      |
|            v                      |
|  Output: "Flight XYZ $299"        |
+-----------------------------------+

+-----------------------------------+
|  WITH ReAct (Transparent)         |
+-----------------------------------+
|  Input: "Find cheap flights"      |
|            |                      |
|  Thought: Need departure city...  |
|  Action: Ask user for details     |
|  Observation: NYC to LA           |
|  Thought: Now search flights...   |
|  Action: Search flight API        |
|  Observation: Found 5 options     |
|  Thought: Select cheapest...      |
|            |                      |
|  Output: "Flight XYZ $299"        |
+-----------------------------------+
```

### 2. Error Recovery

```
Thought: The search returned an error. Let me try a different query.
Action: search
Action Input: "France population statistics"  (modified query)
Observation: [Success - found data]
```

### 3. Grounded Reasoning

Actions provide real-world data to inform reasoning:

```
Without Grounding:        With Grounding (ReAct):
                         
"I think the price       Thought: Let me check actual price
 is around $500"         Action: price_lookup("AAPL")
     |                   Observation: $178.50
     v                        |
   (might be wrong)           v
                         "The current price is $178.50"
                              (verified fact)
```

---

## ReAct in LangGraph Architecture

```
+------------------------------------------------------------------+
|                    LANGGRAPH REACT STRUCTURE                     |
+------------------------------------------------------------------+
|                                                                  |
|                        +--------+                                |
|                        | START  |                                |
|                        +--------+                                |
|                            |                                     |
|                            v                                     |
|   +------------------------------------------------+             |
|   |                 AGENT NODE                     |             |
|   |  +------------------------------------------+  |             |
|   |  |  1. Receive messages                     |  |             |
|   |  |  2. LLM generates thought + action       |  |             |
|   |  |  3. Parse action from response           |  |             |
|   |  +------------------------------------------+  |             |
|   +------------------------------------------------+             |
|                            |                                     |
|                            v                                     |
|                   +-----------------+                            |
|                   | Conditional     |                            |
|                   | Edge Decision   |                            |
|                   +-----------------+                            |
|                    /             \                               |
|                   /               \                              |
|             has_action?        no_action                         |
|                 |                  |                             |
|                 v                  v                             |
|   +----------------+         +--------+                          |
|   |   TOOL NODE    |         |  END   |                          |
|   |  Execute tool  |         +--------+                          |
|   |  Return result |                                             |
|   +----------------+                                             |
|          |                                                       |
|          | (observation added to messages)                       |
|          |                                                       |
|          +-------> Back to AGENT NODE                            |
|                                                                  |
+------------------------------------------------------------------+
```

---

## The ReAct Prompt Template

```
+------------------------------------------------------------------+
|                    REACT PROMPT STRUCTURE                        |
+------------------------------------------------------------------+

Answer the following questions as best you can. You have access to 
the following tools:

{tool_descriptions}

Use the following format:

Question: the input question you must answer
Thought: you should always think about what to do
Action: the action to take, should be one of [{tool_names}]
Action Input: the input to the action
Observation: the result of the action
... (this Thought/Action/Action Input/Observation can repeat N times)
Thought: I now know the final answer
Final Answer: the final answer to the original input question

Begin!

Question: {input}
Thought: {agent_scratchpad}

+------------------------------------------------------------------+
```

---

## State Management in ReAct

```python
class ReActState(TypedDict):
    # The original user question
    question: str
    
    # List of (thought, action, observation) tuples
    scratchpad: list[dict]
    
    # Current step in the reasoning process
    current_step: int
    
    # Whether we've reached a final answer
    is_complete: bool
    
    # The final answer (if complete)
    final_answer: Optional[str]
```

```
State Evolution:
+------------------------------------------------------------------+
|  Step  |  scratchpad                                             |
+------------------------------------------------------------------+
|   0    |  []                                                     |
+------------------------------------------------------------------+
|   1    |  [{"thought": "Need to search...",                      |
|        |    "action": "search",                                  |
|        |    "observation": "Found: ..."}]                        |
+------------------------------------------------------------------+
|   2    |  [{"thought": "Need to search...", ...},                |
|        |   {"thought": "Now I should...",                        |
|        |    "action": "calculate",                               |
|        |    "observation": "Result: 42"}]                        |
+------------------------------------------------------------------+
|   3    |  [..., {"thought": "I have the answer",                 |
|        |         "final_answer": "The answer is 42"}]            |
+------------------------------------------------------------------+
```

---

## Common ReAct Pitfalls

### 1. Infinite Loops

```
Thought: I need more information
Action: search "data"
Observation: Found some data
Thought: I need more information  <-- Stuck in loop!
Action: search "data"
...
```

**Solution**: Add maximum iteration limits and loop detection.

### 2. Premature Termination

```
Thought: This looks complicated. I'll just guess.
Final Answer: Probably around 100.  <-- Didn't use tools!
```

**Solution**: Require minimum tool usage for certain query types.

### 3. Wrong Tool Selection

```
Thought: I need to calculate 2 + 2
Action: search "2 + 2"  <-- Should use calculator!
```

**Solution**: Better tool descriptions and examples in the prompt.

---

## Interview Tips

> 💡 **Interview Tip: What is ReAct?**
> 
> "ReAct stands for Reasoning and Acting. It's a pattern where the agent alternates between thinking (generating reasoning traces) and acting (executing tools). This interleaving allows the agent to plan, verify, and adapt its approach based on real-world observations."

> 💡 **Interview Tip: Why is ReAct Effective?**
> 
> "ReAct is effective because it combines the planning capabilities of chain-of-thought prompting with the grounding provided by tool use. The explicit reasoning traces also make the agent's decision process interpretable and debuggable."

> 💡 **Interview Tip: ReAct Limitations**
> 
> "ReAct can be token-heavy due to verbose reasoning traces. It may also struggle with tasks requiring parallel actions or very long action sequences. For these cases, you might consider planning-based approaches or hierarchical agent architectures."

---

## Key Takeaways

1. **ReAct = Reason + Act**: Interleave thinking with doing
2. **Three components**: Thought, Action, Observation
3. **Loop until complete**: Continue until final answer is reached
4. **Interpretable**: Every decision is traced and explainable
5. **Grounded**: Actions provide real-world data to inform reasoning

---

## Next Steps

Continue to `03_react_example.py` for a complete working implementation of a ReAct agent in LangGraph.
