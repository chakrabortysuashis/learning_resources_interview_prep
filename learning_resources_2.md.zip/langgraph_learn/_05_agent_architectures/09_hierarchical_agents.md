# Hierarchical Agent Patterns

## Introduction

Hierarchical agent architectures extend the supervisor pattern by introducing multiple levels of coordination. Like an organizational chart, agents are arranged in a tree structure where supervisors manage sub-teams, and those sub-teams may have their own supervisors.

This pattern is essential for complex systems that would overwhelm a single supervisor.

---

## From Flat to Hierarchical

```
+------------------------------------------------------------------+
|                    FLAT SUPERVISOR (Limited)                     |
+------------------------------------------------------------------+
|                                                                  |
|                        +------------+                            |
|                        | SUPERVISOR |  <-- Bottleneck!           |
|                        +------------+                            |
|                       /   |   |   \                              |
|                      /    |   |    \                             |
|                     v     v   v     v                            |
|                   [W1]  [W2] [W3]  [W4] ... [W10] [W11] [W12]    |
|                                                                  |
|   Problem: Single supervisor managing too many workers           |
|   - Cognitive overload                                           |
|   - Coordination bottleneck                                      |
|   - Context window limits                                        |
|                                                                  |
+------------------------------------------------------------------+

+------------------------------------------------------------------+
|                  HIERARCHICAL (Scalable)                         |
+------------------------------------------------------------------+
|                                                                  |
|                        +------------+                            |
|                        |    CEO     |  <-- Top-level             |
|                        +------------+                            |
|                       /      |      \                            |
|                      v       v       v                           |
|               +-------+ +-------+ +-------+                      |
|               |  VP1  | |  VP2  | |  VP3  |  <-- Mid-level       |
|               +-------+ +-------+ +-------+                      |
|               /   \       / \       /   \                        |
|              v     v     v   v     v     v                       |
|            [W1]  [W2]  [W3] [W4] [W5]  [W6]  <-- Workers         |
|                                                                  |
|   Benefits:                                                      |
|   - Each supervisor has manageable scope                         |
|   - Specialized sub-teams                                        |
|   - Parallel team execution                                      |
|   - Clear responsibility boundaries                              |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Real-World Analogy: Corporate Structure

```
+------------------------------------------------------------------+
|                    CORPORATE HIERARCHY                           |
+------------------------------------------------------------------+
|                                                                  |
|                        +----------+                              |
|                        |   CEO    |                              |
|                        | (Owns    |                              |
|                        |  vision) |                              |
|                        +----------+                              |
|                      /      |      \                             |
|                     /       |       \                            |
|                    v        v        v                           |
|            +--------+  +--------+  +--------+                    |
|            |  CTO   |  |  CFO   |  |  CMO   |                    |
|            | (Tech) |  |(Finance|  |(Market)|                    |
|            +--------+  +--------+  +--------+                    |
|             /     \        |        /    \                       |
|            v       v       v       v      v                      |
|       +------+ +------+ +------+ +------+ +------+               |
|       | Eng  | | Eng  | |Acctg | |Brand | |Sales |               |
|       |Team 1| |Team 2| | Team | | Team | | Team |               |
|       +------+ +------+ +------+ +------+ +------+               |
|        /   \    /   \      |      /   \    /   \                 |
|       v     v  v     v     v     v     v  v     v                |
|      [Dev] [Dev][Dev][Dev][CPA] [Dsgn][PR][Rep][Rep]             |
|                                                                  |
+------------------------------------------------------------------+
```

Mapping to AI Agents:
- **CEO Agent**: High-level planning, delegates major initiatives
- **VP Agents**: Domain supervisors (Engineering, Finance, Marketing)
- **Team Leads**: Sub-domain coordinators
- **Workers**: Specialized task executors

---

## Hierarchical Communication Patterns

### 1. Top-Down Delegation

```
+------------------------------------------------------------------+
|                    TOP-DOWN FLOW                                 |
+------------------------------------------------------------------+
|                                                                  |
|   [CEO] "Build a new product feature"                            |
|     |                                                            |
|     | delegates to                                               |
|     v                                                            |
|   [CTO] "Design and implement the feature"                       |
|     |                                                            |
|     | breaks down                                                |
|     +-------------+                                              |
|     |             |                                              |
|     v             v                                              |
|   [Team1]       [Team2]                                          |
|   "Frontend"    "Backend"                                        |
|     |             |                                              |
|     v             v                                              |
|   [Worker]      [Worker]                                         |
|   "Build UI"    "Build API"                                      |
|                                                                  |
+------------------------------------------------------------------+
```

### 2. Bottom-Up Reporting

```
+------------------------------------------------------------------+
|                    BOTTOM-UP FLOW                                |
+------------------------------------------------------------------+
|                                                                  |
|   [Worker] "UI completed" ----+                                  |
|                               |                                  |
|   [Worker] "API completed" ---+                                  |
|                               |                                  |
|                               v                                  |
|                    [Team Lead] "Frontend done"                   |
|                    [Team Lead] "Backend done"                    |
|                               |                                  |
|                               v                                  |
|                         [CTO] "Implementation complete"          |
|                               |                                  |
|                               v                                  |
|                         [CEO] "Feature ready for launch"         |
|                                                                  |
+------------------------------------------------------------------+
```

### 3. Lateral Coordination

```
+------------------------------------------------------------------+
|                   LATERAL COMMUNICATION                          |
+------------------------------------------------------------------+
|                                                                  |
|                        [CEO]                                     |
|                       /     \                                    |
|                      v       v                                   |
|                   [CTO]<--->[CMO]  <-- VPs coordinate            |
|                    / \       / \                                 |
|                   v   v     v   v                                |
|                [T1]  [T2] [T3] [T4]                               |
|                  |     \   /    |                                |
|                  |      \ /     |                                |
|                  |       X      |                                |
|                  |      / \     |                                |
|                  v     v   v    v                                |
|                       Teams coordinate                           |
|                       across divisions                           |
|                                                                  |
+------------------------------------------------------------------+
```

---

## LangGraph Hierarchical Implementation

### Subgraphs for Teams

```python
from langgraph.graph import StateGraph, START, END

# Each team is its own subgraph
def create_engineering_team() -> StateGraph:
    """Create the engineering team as a subgraph."""
    team_graph = StateGraph(TeamState)

    # Add team lead (supervisor)
    team_graph.add_node("lead", engineering_lead)

    # Add team workers
    team_graph.add_node("frontend_dev", frontend_worker)
    team_graph.add_node("backend_dev", backend_worker)
    team_graph.add_node("qa", qa_worker)

    # Team internal routing
    team_graph.add_edge(START, "lead")
    team_graph.add_conditional_edges("lead", route_to_dev)
    team_graph.add_edge("frontend_dev", "lead")
    team_graph.add_edge("backend_dev", "lead")
    team_graph.add_edge("qa", "lead")

    return team_graph.compile()


# Main graph uses team subgraphs
def create_organization():
    """Create the full hierarchical organization."""
    org_graph = StateGraph(OrgState)

    # Add CEO (top supervisor)
    org_graph.add_node("ceo", ceo_agent)

    # Add teams as subgraphs
    org_graph.add_node("engineering", create_engineering_team())
    org_graph.add_node("marketing", create_marketing_team())
    org_graph.add_node("finance", create_finance_team())

    # CEO delegates to teams
    org_graph.add_edge(START, "ceo")
    org_graph.add_conditional_edges("ceo", route_to_team)

    # Teams report back to CEO
    org_graph.add_edge("engineering", "ceo")
    org_graph.add_edge("marketing", "ceo")
    org_graph.add_edge("finance", "ceo")

    return org_graph.compile()
```

---

## State Management Across Levels

```
+------------------------------------------------------------------+
|                   HIERARCHICAL STATE                             |
+------------------------------------------------------------------+
|                                                                  |
|   ORGANIZATION STATE (Global)                                    |
|   +----------------------------------------------------------+   |
|   | strategic_goal: str          # Set by CEO                |   |
|   | budget: float                # Shared resource           |   |
|   | deadline: datetime           # Global constraint         |   |
|   | team_statuses: dict          # Each team's status        |   |
|   +----------------------------------------------------------+   |
|                                                                  |
|   TEAM STATE (Per Team)                                          |
|   +----------------------------------------------------------+   |
|   | team_goal: str               # Delegated from CEO        |   |
|   | team_budget: float           # Allocated portion         |   |
|   | worker_results: dict         # Each worker's output      |   |
|   | team_status: str             # Ready/Working/Done        |   |
|   +----------------------------------------------------------+   |
|                                                                  |
|   WORKER STATE (Per Worker)                                      |
|   +----------------------------------------------------------+   |
|   | task: str                    # Specific assignment       |   |
|   | output: str                  # Work product              |   |
|   | status: str                  # Pending/Complete/Blocked  |   |
|   +----------------------------------------------------------+   |
|                                                                  |
+------------------------------------------------------------------+
```

```python
from typing import TypedDict, Annotated
import operator

class WorkerState(TypedDict):
    """State for individual workers."""
    task: str
    output: str
    status: str

class TeamState(TypedDict):
    """State for a team (used in team subgraph)."""
    team_goal: str
    team_budget: float
    worker_results: Annotated[dict, operator.or_]
    team_status: str

class OrgState(TypedDict):
    """State for the entire organization."""
    strategic_goal: str
    budget: float
    deadline: str
    team_statuses: dict
    final_output: str
```

---

## Delegation Patterns

### Pattern 1: Cascade Delegation

```
+------------------------------------------------------------------+
|                   CASCADE DELEGATION                             |
+------------------------------------------------------------------+
|                                                                  |
|   CEO receives: "Launch new product in Q4"                       |
|        |                                                         |
|        | translates to                                           |
|        v                                                         |
|   CTO receives: "Build product tech stack"                       |
|        |                                                         |
|        | translates to                                           |
|        v                                                         |
|   Team Lead receives: "Implement user authentication"            |
|        |                                                         |
|        | translates to                                           |
|        v                                                         |
|   Developer receives: "Write OAuth2 integration code"            |
|                                                                  |
|   Each level adds specificity and context                        |
|                                                                  |
+------------------------------------------------------------------+
```

### Pattern 2: Parallel Team Dispatch

```
+------------------------------------------------------------------+
|                   PARALLEL DISPATCH                              |
+------------------------------------------------------------------+
|                                                                  |
|                         [CEO]                                    |
|                           |                                      |
|            +--------------+---------------+                      |
|            |              |               |                      |
|            v              v               v                      |
|     [Engineering]   [Marketing]    [Operations]                  |
|     "Build it"      "Market it"    "Deploy it"                   |
|            |              |               |                      |
|            |   (parallel execution)       |                      |
|            |              |               |                      |
|            v              v               v                      |
|       [Results]      [Results]       [Results]                   |
|            |              |               |                      |
|            +--------------+---------------+                      |
|                           |                                      |
|                         [CEO]                                    |
|                    (aggregation)                                 |
|                                                                  |
+------------------------------------------------------------------+
```

### Pattern 3: Sequential Dependencies

```
+------------------------------------------------------------------+
|                   SEQUENTIAL DEPENDENCIES                        |
+------------------------------------------------------------------+
|                                                                  |
|   [CEO] "Build and launch product"                               |
|     |                                                            |
|     v                                                            |
|   [Engineering] "Build product"                                  |
|     |                                                            |
|     | (must complete first)                                      |
|     v                                                            |
|   [QA] "Test product"                                            |
|     |                                                            |
|     | (must pass)                                                |
|     v                                                            |
|   [Operations] "Deploy product"                                  |
|     |                                                            |
|     | (must deploy)                                              |
|     v                                                            |
|   [Marketing] "Announce launch"                                  |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Error Handling in Hierarchies

```
+------------------------------------------------------------------+
|                   ERROR ESCALATION                               |
+------------------------------------------------------------------+
|                                                                  |
|   Level 0 (Worker):                                              |
|   - Try to fix locally                                           |
|   - If can't fix -> escalate to team lead                        |
|                                                                  |
|   Level 1 (Team Lead):                                           |
|   - Reassign to different worker                                 |
|   - Retry with different approach                                |
|   - If team can't handle -> escalate to VP                       |
|                                                                  |
|   Level 2 (VP/Director):                                         |
|   - Coordinate across teams                                      |
|   - Reallocate resources                                         |
|   - If major blocker -> escalate to CEO                          |
|                                                                  |
|   Level 3 (CEO):                                                 |
|   - Strategic decision                                           |
|   - Change direction                                             |
|   - Request human intervention                                   |
|                                                                  |
+------------------------------------------------------------------+

Code Pattern:

def team_lead_node(state: TeamState) -> dict:
    try:
        result = execute_with_team(state)
        return {"team_status": "success", "output": result}
    except MinorError as e:
        # Retry with different worker
        return {"retry_worker": True, "error": str(e)}
    except MajorError as e:
        # Escalate to higher level
        return {"escalate": True, "error": str(e)}
```

---

## Benefits of Hierarchical Architecture

### 1. Scalability

```
Flat:     1 supervisor, 100 workers = overwhelmed
Hierarchy: 1 CEO, 10 VPs, 100 workers = manageable

Each supervisor handles ~10 direct reports
```

### 2. Specialization

```
+------------------+
| CEO: Strategy    |  <-- Big picture
+------------------+

+--------+--------+--------+
| VP Eng | VP Mkt | VP Ops |  <-- Domain expertise
+--------+--------+--------+

+----+----+----+----+----+----+
|Dev1|Dev2|Ads |PR  |SRE |Sec |  <-- Specialized skills
+----+----+----+----+----+----+
```

### 3. Context Isolation

```
Each level only needs to know:
- Its own responsibilities
- How to communicate up/down one level

Developer doesn't need CEO's strategic context
CEO doesn't need developer's technical details
```

### 4. Parallel Processing

```
Teams work independently:
  [Engineering]---->|
                    |
  [Marketing]------>|---> [CEO aggregates]
                    |
  [Operations]----->|
```

---

## Design Considerations

### Depth vs Breadth

```
Deep Hierarchy:              Broad Hierarchy:
    [L0]                        [L0]
     |                    /   /  |  \   \
    [L1]                [L1][L1][L1][L1][L1]
     |
    [L2]
     |
    [L3]

Pro: Fine control         Pro: Less overhead
Con: Slow decisions       Con: Supervisor overload

Balance: 2-3 levels is usually optimal
```

### Cross-Team Coordination

```
Problem: Teams need to share information

Solution 1: Through common parent
  [CEO] coordinates between [Eng] and [Mkt]

Solution 2: Direct peer communication
  [Eng] <---> [Mkt] with notification to [CEO]

Solution 3: Shared state
  Both teams read/write to common state
```

---

## Interview Tips

> 💡 **Interview Tip: When Hierarchical?**
> 
> "Use hierarchical architectures when: (1) A single supervisor becomes a bottleneck, (2) Tasks naturally decompose into domain-specific sub-problems, (3) You need clear separation of concerns, or (4) The system needs to scale to many agents."

> 💡 **Interview Tip: Subgraphs**
> 
> "In LangGraph, hierarchical architectures are implemented using subgraphs. Each team or division is its own compiled graph that gets used as a node in the parent graph. This provides clean encapsulation and reusability."

> 💡 **Interview Tip: State Propagation**
> 
> "The key challenge in hierarchical systems is state management. Global state needs to flow down, and results need to flow up. Design your state carefully to include both global context and local working space."

> 💡 **Interview Tip: Depth Trade-offs**
> 
> "Each level of hierarchy adds latency and potential for miscommunication. Generally, 2-3 levels work well. Deeper hierarchies should only be used when the added control is worth the overhead."

---

## Key Takeaways

1. **Multiple supervision levels** - Not just one supervisor, but supervisors of supervisors
2. **Subgraphs for teams** - Each team is a self-contained graph
3. **State flows both ways** - Goals down, results up
4. **Scalability through structure** - Handle more complexity by organizing, not overloading
5. **Error escalation paths** - Clear chain of command for handling failures
6. **Balance depth and breadth** - Too deep = slow, too broad = overloaded

---

## Next Steps

Continue to `10_hierarchical_example.py` for a complete implementation of a hierarchical agent system.
