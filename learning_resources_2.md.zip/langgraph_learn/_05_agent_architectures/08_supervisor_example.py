"""
Supervisor Pattern Example in LangGraph
========================================

This module demonstrates a complete supervisor/orchestrator pattern implementation.
The supervisor coordinates multiple specialized worker agents to complete complex tasks.

Architecture:
                    +------------+
                    |    USER    |
                    +------------+
                          |
                          v
                    +------------+
           +------->| SUPERVISOR |<-------+
           |        +------------+        |
           |         /    |    \          |
           |        v     v     v         |
           |   +-----+ +-----+ +-----+    |
           |   |Rsrch| |Analy| |Write|    |
           |   +-----+ +-----+ +-----+    |
           |        \    |    /           |
           +----------\--|---/------------+
                       \ | /
                        vvv
                    +------------+
                    | SYNTHESIZE |
                    +------------+
                          |
                          v
                    +------------+
                    |   OUTPUT   |
                    +------------+

Author: Learning Module
Topic: Agent Architectures - Supervisor Pattern
"""

from typing import TypedDict, Annotated, Literal, Optional
from langgraph.graph import StateGraph, START, END
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langchain_openai import ChatOpenAI
from langchain_core.tools import tool
import operator
import json


# =============================================================================
# SECTION 1: STATE DEFINITION
# =============================================================================

class SupervisorState(TypedDict):
    """
    State shared across the supervisor and all workers.

    This state allows:
    - Supervisor to track task progress
    - Workers to receive instructions
    - Results to be aggregated
    """
    # Original user request
    user_request: str

    # Conversation messages (accumulates)
    messages: Annotated[list, operator.add]

    # Which worker should handle the next step
    next_worker: str

    # Results from each worker
    research_result: Optional[str]
    analysis_result: Optional[str]
    writing_result: Optional[str]

    # List of completed workers
    completed_workers: list[str]

    # Final synthesized response
    final_response: Optional[str]

    # Error tracking
    errors: list[str]


# =============================================================================
# SECTION 2: WORKER DEFINITIONS
# =============================================================================
# Each worker is a specialized agent with specific capabilities

class ResearchWorker:
    """
    Research worker that gathers information from external sources.

    Capabilities:
    - Web search
    - Data lookup
    - Fact gathering
    """

    def __init__(self, llm: ChatOpenAI):
        self.llm = llm
        self.name = "researcher"

    def __call__(self, state: SupervisorState) -> dict:
        """Execute research based on the user request."""
        print(f"\n[RESEARCHER] Starting research...")

        # Create research prompt
        prompt = f"""You are a research specialist. Your job is to gather relevant
information for the following request:

User Request: {state['user_request']}

Provide a comprehensive research summary including:
1. Key facts and data
2. Relevant statistics
3. Important context

Keep your response focused and factual. Cite sources if available."""

        # In a real implementation, this would use search tools
        messages = [
            SystemMessage(content="You are a thorough research assistant."),
            HumanMessage(content=prompt)
        ]

        response = self.llm.invoke(messages)

        # Mock research enhancement for demonstration
        research_result = f"""Research Findings:

{response.content}

Additional mock data for demonstration:
- Market size: $50B (growing 12% YoY)
- Key players: 3 major competitors
- Recent trends: AI adoption increasing 40%"""

        print(f"[RESEARCHER] Completed research")

        return {
            "research_result": research_result,
            "completed_workers": state.get("completed_workers", []) + ["researcher"],
            "messages": [AIMessage(content=f"[Researcher]: Completed research")]
        }


class AnalysisWorker:
    """
    Analysis worker that interprets data and provides insights.

    Capabilities:
    - Data analysis
    - Pattern recognition
    - Insight generation
    """

    def __init__(self, llm: ChatOpenAI):
        self.llm = llm
        self.name = "analyst"

    def __call__(self, state: SupervisorState) -> dict:
        """Analyze the research results."""
        print(f"\n[ANALYST] Starting analysis...")

        research = state.get("research_result", "No research available")

        prompt = f"""You are a data analyst. Based on the following research,
provide a thorough analysis:

Research Data:
{research}

Original Request: {state['user_request']}

Provide:
1. Key insights from the data
2. Patterns or trends identified
3. Implications and recommendations
4. Any data gaps or limitations"""

        messages = [
            SystemMessage(content="You are an insightful data analyst."),
            HumanMessage(content=prompt)
        ]

        response = self.llm.invoke(messages)

        print(f"[ANALYST] Completed analysis")

        return {
            "analysis_result": response.content,
            "completed_workers": state.get("completed_workers", []) + ["analyst"],
            "messages": [AIMessage(content=f"[Analyst]: Completed analysis")]
        }


class WritingWorker:
    """
    Writing worker that creates polished content.

    Capabilities:
    - Report writing
    - Content creation
    - Document formatting
    """

    def __init__(self, llm: ChatOpenAI):
        self.llm = llm
        self.name = "writer"

    def __call__(self, state: SupervisorState) -> dict:
        """Create written content based on research and analysis."""
        print(f"\n[WRITER] Starting writing...")

        research = state.get("research_result", "No research")
        analysis = state.get("analysis_result", "No analysis")

        prompt = f"""You are a professional writer. Create a well-structured
document based on the following:

Research:
{research}

Analysis:
{analysis}

Original Request: {state['user_request']}

Create a professional report with:
1. Executive Summary
2. Key Findings
3. Analysis
4. Recommendations
5. Conclusion

Make it clear, concise, and actionable."""

        messages = [
            SystemMessage(content="You are a skilled professional writer."),
            HumanMessage(content=prompt)
        ]

        response = self.llm.invoke(messages)

        print(f"[WRITER] Completed writing")

        return {
            "writing_result": response.content,
            "completed_workers": state.get("completed_workers", []) + ["writer"],
            "messages": [AIMessage(content=f"[Writer]: Completed document")]
        }


# =============================================================================
# SECTION 3: SUPERVISOR DEFINITION
# =============================================================================

class Supervisor:
    """
    The Supervisor orchestrates the workflow by:
    1. Understanding the user request
    2. Deciding which worker should act next
    3. Monitoring progress
    4. Synthesizing final results
    """

    def __init__(self, llm: ChatOpenAI, workers: list[str]):
        self.llm = llm
        self.workers = workers
        self.name = "supervisor"

    def __call__(self, state: SupervisorState) -> dict:
        """
        Decide which worker should handle the next step.

        This can be rule-based or LLM-based.
        Here we use a hybrid approach.
        """
        print(f"\n[SUPERVISOR] Evaluating next step...")

        completed = state.get("completed_workers", [])

        # Rule-based routing for our workflow
        # Order: research -> analysis -> writing -> done
        workflow_order = ["researcher", "analyst", "writer"]

        for worker in workflow_order:
            if worker not in completed:
                print(f"[SUPERVISOR] Routing to: {worker}")
                return {
                    "next_worker": worker,
                    "messages": [AIMessage(content=f"[Supervisor]: Delegating to {worker}")]
                }

        # All workers done
        print(f"[SUPERVISOR] All workers complete, moving to synthesis")
        return {
            "next_worker": "done",
            "messages": [AIMessage(content=f"[Supervisor]: All tasks complete, synthesizing")]
        }


class LLMSupervisor:
    """
    Alternative supervisor that uses LLM for routing decisions.
    More flexible but also more expensive.
    """

    def __init__(self, llm: ChatOpenAI, workers: list[str]):
        self.llm = llm
        self.workers = workers

    def __call__(self, state: SupervisorState) -> dict:
        """Use LLM to decide next worker."""
        completed = state.get("completed_workers", [])
        available = [w for w in self.workers if w not in completed]

        if not available:
            return {"next_worker": "done"}

        prompt = f"""You are a project supervisor coordinating a team.

User Request: {state['user_request']}

Available workers:
- researcher: Gathers information and data
- analyst: Analyzes data and provides insights
- writer: Creates written reports and documents

Completed workers: {completed}

Current results:
- Research: {'Done' if 'researcher' in completed else 'Pending'}
- Analysis: {'Done' if 'analyst' in completed else 'Pending'}
- Writing: {'Done' if 'writer' in completed else 'Pending'}

Which worker should handle the next step? Consider dependencies:
- Analysis needs research first
- Writing needs both research and analysis

Respond with ONLY the worker name (researcher/analyst/writer) or "done" if complete."""

        messages = [HumanMessage(content=prompt)]
        response = self.llm.invoke(messages)

        next_worker = response.content.strip().lower()

        # Validate response
        if next_worker not in self.workers + ["done"]:
            # Default to first available
            next_worker = available[0] if available else "done"

        return {
            "next_worker": next_worker,
            "messages": [AIMessage(content=f"[Supervisor]: Routing to {next_worker}")]
        }


# =============================================================================
# SECTION 4: SYNTHESIS NODE
# =============================================================================

def synthesis_node(state: SupervisorState) -> dict:
    """
    Combine all worker results into a final response.

    This node runs after all workers have completed.
    """
    print(f"\n[SYNTHESIS] Creating final response...")

    research = state.get("research_result", "No research available")
    analysis = state.get("analysis_result", "No analysis available")
    writing = state.get("writing_result", "No writing available")

    # The writing result is typically the final document
    # But we can add metadata or summaries
    final_response = f"""
================================================================================
FINAL REPORT
================================================================================

{writing}

================================================================================
APPENDIX
================================================================================

Raw Research Data:
{research[:500]}...

Analysis Summary:
{analysis[:500]}...

================================================================================
Report generated by multi-agent system
Workers involved: {', '.join(state.get('completed_workers', []))}
================================================================================
"""

    print(f"[SYNTHESIS] Complete")

    return {
        "final_response": final_response,
        "messages": [AIMessage(content="Final report generated")]
    }


# =============================================================================
# SECTION 5: ROUTING FUNCTION
# =============================================================================

def route_to_worker(state: SupervisorState) -> str:
    """
    Route to the appropriate worker based on supervisor's decision.

    Returns:
        String key for conditional edge routing
    """
    next_worker = state.get("next_worker", "done")

    routing_map = {
        "researcher": "researcher",
        "analyst": "analyst",
        "writer": "writer",
        "done": "synthesize"
    }

    return routing_map.get(next_worker, "synthesize")


# =============================================================================
# SECTION 6: BUILD THE GRAPH
# =============================================================================

def create_supervisor_graph():
    """
    Build the complete supervisor graph.

    Graph structure:

        START
          |
          v
      SUPERVISOR <--------+
          |               |
    +-----+-----+         |
    |     |     |         |
    v     v     v         |
   RSR   ANL   WRT        |
    |     |     |         |
    +-----+-----+---------+
          |
          v (when done)
      SYNTHESIZE
          |
          v
         END
    """
    # Initialize LLM
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)

    # Create workers
    researcher = ResearchWorker(llm)
    analyst = AnalysisWorker(llm)
    writer = WritingWorker(llm)

    # Create supervisor
    workers = ["researcher", "analyst", "writer"]
    supervisor = Supervisor(llm, workers)

    # Build graph
    graph = StateGraph(SupervisorState)

    # Add nodes
    graph.add_node("supervisor", supervisor)
    graph.add_node("researcher", researcher)
    graph.add_node("analyst", analyst)
    graph.add_node("writer", writer)
    graph.add_node("synthesize", synthesis_node)

    # Add edges
    # Start -> Supervisor
    graph.add_edge(START, "supervisor")

    # Supervisor -> Workers (conditional)
    graph.add_conditional_edges(
        "supervisor",
        route_to_worker,
        {
            "researcher": "researcher",
            "analyst": "analyst",
            "writer": "writer",
            "synthesize": "synthesize"
        }
    )

    # Workers -> Supervisor (loop back)
    graph.add_edge("researcher", "supervisor")
    graph.add_edge("analyst", "supervisor")
    graph.add_edge("writer", "supervisor")

    # Synthesize -> End
    graph.add_edge("synthesize", END)

    # Compile
    return graph.compile()


# =============================================================================
# SECTION 7: EXECUTION HELPERS
# =============================================================================

def run_supervisor_agent(request: str) -> str:
    """
    Run the supervisor agent with a user request.

    Args:
        request: The user's request

    Returns:
        The final synthesized response
    """
    print("=" * 60)
    print("SUPERVISOR AGENT")
    print("=" * 60)
    print(f"\nUser Request: {request}")
    print("-" * 60)

    # Create graph
    graph = create_supervisor_graph()

    # Initialize state
    initial_state = {
        "user_request": request,
        "messages": [HumanMessage(content=request)],
        "next_worker": "",
        "research_result": None,
        "analysis_result": None,
        "writing_result": None,
        "completed_workers": [],
        "final_response": None,
        "errors": []
    }

    # Run the graph
    final_state = graph.invoke(initial_state)

    return final_state.get("final_response", "No response generated")


def run_with_streaming(request: str):
    """
    Run with streaming to see each step in real-time.
    """
    graph = create_supervisor_graph()

    initial_state = {
        "user_request": request,
        "messages": [HumanMessage(content=request)],
        "next_worker": "",
        "research_result": None,
        "analysis_result": None,
        "writing_result": None,
        "completed_workers": [],
        "final_response": None,
        "errors": []
    }

    print(f"\nStreaming execution for: {request}\n")

    for step in graph.stream(initial_state):
        for node_name, output in step.items():
            print(f"\n[STEP] {node_name}")
            if "next_worker" in output:
                print(f"  Next worker: {output['next_worker']}")
            if "completed_workers" in output:
                print(f"  Completed: {output['completed_workers']}")


# =============================================================================
# SECTION 8: DEMO
# =============================================================================

def main():
    """
    Demonstrate the supervisor pattern.
    """
    print("\n" + "=" * 60)
    print("SUPERVISOR PATTERN DEMONSTRATION")
    print("=" * 60)

    # Example request
    request = """
    Create a market analysis report for the AI chatbot industry.
    Include market size, key players, trends, and recommendations
    for a company looking to enter this space.
    """

    # Run the agent
    result = run_supervisor_agent(request)

    # Print result
    print("\n" + "=" * 60)
    print("FINAL OUTPUT")
    print("=" * 60)
    print(result)


# =============================================================================
# SECTION 9: ADVANCED PATTERNS
# =============================================================================

class ParallelSupervisor:
    """
    Advanced supervisor that can run independent workers in parallel.

    Use this when workers don't have dependencies on each other.
    """

    def __init__(self, llm: ChatOpenAI):
        self.llm = llm

    def identify_parallel_tasks(self, request: str) -> list[list[str]]:
        """
        Identify which tasks can run in parallel.

        Returns list of phases, each phase contains workers that can run together.
        """
        # For this example: research and initial_analysis can run in parallel
        # But writing needs both to be complete
        return [
            ["researcher"],  # Phase 1
            ["analyst"],     # Phase 2 (depends on research)
            ["writer"]       # Phase 3 (depends on both)
        ]


def create_parallel_supervisor_graph():
    """
    Create a graph that supports parallel worker execution.

    This is a more advanced pattern for when workers are independent.
    """
    # Implementation would use LangGraph's support for parallel branches
    # This is a placeholder for the concept
    pass


# =============================================================================
# INTERVIEW TIPS
# =============================================================================
"""
Interview Tips for Supervisor Pattern:

1. Q: "Explain the supervisor pattern"
   A: "The supervisor pattern uses a central orchestrating agent that
      delegates tasks to specialized worker agents, monitors their progress,
      and aggregates their results. It's similar to a manager coordinating
      a team of specialists."

2. Q: "Rule-based vs LLM-based supervisor?"
   A: "Rule-based supervisors are faster and more predictable - use them
      when the workflow is well-defined. LLM-based supervisors are more
      flexible and can handle novel situations, but are slower and more
      expensive. Many systems use a hybrid approach."

3. Q: "How do you handle worker failures?"
   A: "Options include: retry the same worker, fall back to an alternative
      worker, skip the failed step and continue with partial results, or
      escalate to human oversight. The choice depends on the criticality
      of the failed step."

4. Q: "How does state management work?"
   A: "All agents share a common state object. Workers read context and
      write their results. The supervisor reads completion status and
      decides next steps. LangGraph's TypedDict state makes this explicit
      and type-safe."

5. Q: "When would you NOT use supervisor pattern?"
   A: "When you need peer-to-peer collaboration (agents building on each
      other's ideas), when the supervisor becomes a bottleneck in high-
      throughput systems, or when tasks are simple enough for a single
      agent to handle."
"""


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"\nError: {e}")
        print("\nMake sure you have:")
        print("1. Set OPENAI_API_KEY environment variable")
        print("2. Installed: pip install langgraph langchain-openai")
