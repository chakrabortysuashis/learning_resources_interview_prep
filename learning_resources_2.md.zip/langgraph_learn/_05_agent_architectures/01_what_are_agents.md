# What Are Agents in LangGraph?

## Introduction

In the context of LangGraph and modern AI systems, an **agent** is an autonomous program that can perceive its environment, reason about its goals, and take actions to achieve those goals. Unlike simple chains that follow a predetermined path, agents make dynamic decisions at runtime.

---

## The Agent Mental Model

Think of an agent like a skilled employee:

```
+------------------------------------------------------------------+
|                        AGENT MENTAL MODEL                        |
+------------------------------------------------------------------+
|                                                                  |
|   Employee (Simple Chain):                                       |
|   - Follows a fixed checklist                                    |
|   - Same steps every time                                        |
|   - Cannot adapt to unexpected situations                        |
|                                                                  |
|   vs.                                                            |
|                                                                  |
|   Skilled Professional (Agent):                                  |
|   - Assesses the situation                                       |
|   - Decides which tools to use                                   |
|   - Adapts approach based on results                             |
|   - Knows when to ask for help or stop                           |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Key Characteristics of Agents

### 1. Autonomy

Agents operate independently without step-by-step human guidance:

```
+-----------------+     +------------------+     +----------------+
|    Receive      | --> |     Process      | --> |     Deliver    |
|      Goal       |     |  Autonomously    |     |     Result     |
+-----------------+     +------------------+     +----------------+
                              |
                    +--------------------+
                    |  - Reason          |
                    |  - Plan            |
                    |  - Execute         |
                    |  - Evaluate        |
                    +--------------------+
```

### 2. Goal-Directed Behavior

Agents work toward specific objectives:

```python
# Chain approach (no goal awareness)
def chain_approach(query):
    result = search(query)
    result = summarize(result)
    return result  # Always same steps, regardless of outcome

# Agent approach (goal-aware)
def agent_approach(query, goal="comprehensive_answer"):
    while not goal_achieved:
        thought = reason_about_progress()
        action = decide_next_action()
        result = execute_action(action)
        evaluate_if_goal_met(result, goal)
    return final_answer
```

### 3. Tool Usage

Agents can dynamically select and use tools:

```
+------------------------------------------------------------------+
|                        AGENT TOOLBOX                             |
+------------------------------------------------------------------+
|                                                                  |
|    [Search]    [Calculator]    [Database]    [API Call]         |
|        |            |              |             |               |
|        +------------+--------------+-------------+               |
|                           |                                      |
|                    +------v------+                               |
|                    |    AGENT    |                               |
|                    |             |                               |
|                    | Selects the |                               |
|                    | right tool  |                               |
|                    | at runtime  |                               |
|                    +-------------+                               |
|                                                                  |
+------------------------------------------------------------------+
```

### 4. Perception and Observation

Agents observe the results of their actions:

```
Action --> Result --> Observation --> Updated Understanding
                                              |
                                              v
                                    Next Action Decision
```

---

## Agent vs Chain: A Detailed Comparison

```
+------------------------------------------------------------------+
|                    CHAIN (Deterministic)                         |
+------------------------------------------------------------------+
|                                                                  |
|   Input                                                          |
|     |                                                            |
|     v                                                            |
|   [Step 1: Parse] --> [Step 2: Search] --> [Step 3: Format]     |
|                                                   |              |
|                                                   v              |
|                                                Output            |
|                                                                  |
|   - Fixed sequence                                               |
|   - Predictable execution                                        |
|   - No decision points                                           |
|                                                                  |
+------------------------------------------------------------------+

+------------------------------------------------------------------+
|                      AGENT (Dynamic)                             |
+------------------------------------------------------------------+
|                                                                  |
|   Input                                                          |
|     |                                                            |
|     v                                                            |
|   [Reason]                                                       |
|     |                                                            |
|     +-- What do I need to do?                                    |
|     |                                                            |
|     v                                                            |
|   [Decide] --> Which tool? --> [Execute Tool]                   |
|     |                               |                            |
|     |                               v                            |
|     +<-------- [Observe Result] <---+                            |
|     |                                                            |
|     +-- Goal achieved?                                           |
|     |       |                                                    |
|     |      No --> Continue loop                                  |
|     |       |                                                    |
|     v      Yes                                                   |
|   Output                                                         |
|                                                                  |
+------------------------------------------------------------------+
```

---

## The Agent Loop in LangGraph

LangGraph implements agents using its graph-based execution model:

```
                    +----------------+
                    |     START      |
                    +----------------+
                           |
                           v
                    +----------------+
             +----->|    REASON      |
             |      | (LLM decides)  |
             |      +----------------+
             |             |
             |             v
             |      +----------------+
             |      |  Should Act?   |
             |      +----------------+
             |        |          |
             |       Yes         No
             |        |          |
             |        v          v
             |  +----------+  +------+
             |  |   ACT    |  | END  |
             |  | (tool)   |  +------+
             |  +----------+
             |        |
             |        v
             |  +----------+
             |  | OBSERVE  |
             |  +----------+
             |        |
             +--------+
```

---

## Why Use Agents?

### When Chains Are Sufficient

- Fixed, well-defined workflows
- Predictable input/output patterns
- No need for dynamic decision-making
- Simple transformations

### When Agents Are Necessary

| Scenario | Why Agent? |
|----------|------------|
| Complex queries | May need multiple tools |
| Uncertain paths | Decision depends on intermediate results |
| Multi-step reasoning | Need to evaluate progress |
| Error handling | Must adapt when things fail |
| Open-ended tasks | No fixed sequence possible |

---

## Agent Components in LangGraph

```python
from langgraph.graph import StateGraph, START, END
from typing import TypedDict, Annotated, Literal
import operator

# 1. STATE: What the agent knows
class AgentState(TypedDict):
    messages: Annotated[list, operator.add]  # Conversation history
    thoughts: list                            # Agent's reasoning
    current_goal: str                         # What it's trying to achieve
    tools_used: list                          # Actions taken
    
# 2. NODES: What the agent can do
def reason(state: AgentState) -> dict:
    """Agent thinks about what to do next"""
    # LLM generates reasoning
    pass

def act(state: AgentState) -> dict:
    """Agent executes a tool"""
    # Execute selected tool
    pass

def observe(state: AgentState) -> dict:
    """Agent processes tool results"""
    # Update understanding
    pass

# 3. EDGES: How decisions are made
def should_continue(state: AgentState) -> Literal["act", "end"]:
    """Decide whether to keep going"""
    if goal_achieved(state):
        return "end"
    return "act"

# 4. GRAPH: Putting it all together
graph = StateGraph(AgentState)
graph.add_node("reason", reason)
graph.add_node("act", act)
graph.add_node("observe", observe)

graph.add_edge(START, "reason")
graph.add_conditional_edges("reason", should_continue)
graph.add_edge("act", "observe")
graph.add_edge("observe", "reason")

agent = graph.compile()
```

---

## Real-World Analogy: The Research Librarian

Imagine asking a librarian: "Find me information about climate change impacts on agriculture."

**Simple Chain (Inexperienced Clerk):**
1. Go to shelf A
2. Pull first book
3. Copy first paragraph
4. Return to patron

**Agent (Expert Librarian):**
1. Understand the question (climate + agriculture)
2. Decide: Should I search journals, books, or databases?
3. Search scientific journals (Action 1)
4. Observe: Found some papers, but need economic data
5. Decide: Search economic databases (Action 2)
6. Observe: Good data, but need recent statistics
7. Decide: Check government reports (Action 3)
8. Observe: Have comprehensive information now
9. Synthesize and present findings

---

## Interview Tips

> 💡 **Interview Tip: Definition**
> 
> "An agent is an autonomous system that uses an LLM as its reasoning engine to decide which actions to take and in what order. Unlike chains with fixed sequences, agents dynamically choose their execution path based on observations."

> 💡 **Interview Tip: When to Use**
> 
> "Use agents when the task requires dynamic decision-making based on intermediate results, or when multiple tools might be needed depending on the situation. Use chains for predictable, fixed workflows."

> 💡 **Interview Tip: LangGraph Advantage**
> 
> "LangGraph provides fine-grained control over agent loops with explicit state management, conditional edges, and the ability to checkpoint and resume agent execution - something harder to achieve with other frameworks."

---

## Key Takeaways

1. **Agents are autonomous**: They make decisions without step-by-step guidance
2. **Agents are goal-directed**: They work toward objectives, not just execute steps
3. **Agents use tools**: They dynamically select and use capabilities
4. **Agents observe and adapt**: They learn from action results
5. **LangGraph enables control**: Graph-based design gives precise control over agent behavior

---

## Next Steps

Continue to `02_react_pattern.md` to learn about the ReAct pattern - the foundational reasoning pattern for most agents.
