# The Supervisor Pattern

## Introduction

The **Supervisor Pattern** (also called Orchestrator Pattern) is the most common multi-agent architecture. A central supervisor agent receives tasks, delegates them to specialized worker agents, collects results, and synthesizes the final output.

---

## The Supervisor Concept

```
+------------------------------------------------------------------+
|                    SUPERVISOR PATTERN                            |
+------------------------------------------------------------------+
|                                                                  |
|                         USER REQUEST                             |
|                              |                                   |
|                              v                                   |
|                    +------------------+                          |
|                    |                  |                          |
|                    |    SUPERVISOR    |                          |
|                    |                  |                          |
|                    | - Understands    |                          |
|                    |   the full task  |                          |
|                    | - Routes to      |                          |
|                    |   workers        |                          |
|                    | - Aggregates     |                          |
|                    |   results        |                          |
|                    |                  |                          |
|                    +------------------+                          |
|                      /      |       \                            |
|                     /       |        \                           |
|                    v        v         v                          |
|              +-------+  +-------+  +-------+                     |
|              |Worker |  |Worker |  |Worker |                     |
|              |  A    |  |  B    |  |  C    |                     |
|              |       |  |       |  |       |                     |
|              |Search |  |Analyze|  | Write |                     |
|              +-------+  +-------+  +-------+                     |
|                    \        |        /                           |
|                     \       |       /                            |
|                      v      v      v                             |
|                    +------------------+                          |
|                    |    SUPERVISOR    |                          |
|                    | (collects &      |                          |
|                    |  synthesizes)    |                          |
|                    +------------------+                          |
|                              |                                   |
|                              v                                   |
|                       FINAL RESPONSE                             |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Real-World Analogy: The Restaurant Kitchen

```
+------------------------------------------------------------------+
|                    RESTAURANT KITCHEN                            |
+------------------------------------------------------------------+
|                                                                  |
|   Customer Order: "Steak dinner with salad and dessert"          |
|                                                                  |
|                    +-------------------+                         |
|                    |    HEAD CHEF      |  <-- SUPERVISOR         |
|                    |   (Expeditor)     |                         |
|                    +-------------------+                         |
|                      /      |       \                            |
|                     /       |        \                           |
|                    v        v         v                          |
|             +--------+ +--------+ +--------+                     |
|             | GRILL  | | GARDE  | |PASTRY  |  <-- WORKERS        |
|             | CHEF   | | MANGER | | CHEF   |                     |
|             |        | |        | |        |                     |
|             | Makes  | | Makes  | | Makes  |                     |
|             | steak  | | salad  | |dessert |                     |
|             +--------+ +--------+ +--------+                     |
|                     \       |       /                            |
|                      \      |      /                             |
|                       v     v     v                              |
|                    +-------------------+                         |
|                    |    HEAD CHEF      |                         |
|                    | (plates & serves) |                         |
|                    +-------------------+                         |
|                              |                                   |
|                              v                                   |
|                    Complete Dinner Served                        |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Supervisor Responsibilities

```
+------------------------------------------------------------------+
|                   SUPERVISOR DUTIES                              |
+------------------------------------------------------------------+
|                                                                  |
|  1. TASK UNDERSTANDING                                           |
|     +----------------------------------------------------------+ |
|     |  Parse user request                                      | |
|     |  Identify required sub-tasks                             | |
|     |  Determine dependencies                                  | |
|     +----------------------------------------------------------+ |
|                                                                  |
|  2. WORKER SELECTION                                             |
|     +----------------------------------------------------------+ |
|     |  Match sub-tasks to worker capabilities                  | |
|     |  Consider worker availability                            | |
|     |  Optimize for efficiency                                 | |
|     +----------------------------------------------------------+ |
|                                                                  |
|  3. DELEGATION                                                   |
|     +----------------------------------------------------------+ |
|     |  Assign tasks to workers                                 | |
|     |  Provide necessary context                               | |
|     |  Set expectations/constraints                            | |
|     +----------------------------------------------------------+ |
|                                                                  |
|  4. MONITORING                                                   |
|     +----------------------------------------------------------+ |
|     |  Track worker progress                                   | |
|     |  Handle failures/retries                                 | |
|     |  Manage timeouts                                         | |
|     +----------------------------------------------------------+ |
|                                                                  |
|  5. SYNTHESIS                                                    |
|     +----------------------------------------------------------+ |
|     |  Collect all worker results                              | |
|     |  Combine into coherent output                            | |
|     |  Quality check final result                              | |
|     +----------------------------------------------------------+ |
|                                                                  |
+------------------------------------------------------------------+
```

---

## LangGraph Implementation

### Basic Structure

```python
from langgraph.graph import StateGraph, START, END
from typing import TypedDict, Annotated, Literal
import operator

class SupervisorState(TypedDict):
    messages: Annotated[list, operator.add]
    next_worker: str
    worker_results: dict
    final_response: str

def supervisor_node(state: SupervisorState) -> dict:
    """
    The supervisor decides which worker to call next.
    """
    # Analyze task and decide routing
    next_worker = decide_next_worker(state)
    return {"next_worker": next_worker}

def worker_a_node(state: SupervisorState) -> dict:
    """Worker A handles research tasks."""
    result = do_research(state)
    return {"worker_results": {**state["worker_results"], "research": result}}

def worker_b_node(state: SupervisorState) -> dict:
    """Worker B handles analysis tasks."""
    result = do_analysis(state)
    return {"worker_results": {**state["worker_results"], "analysis": result}}

def synthesis_node(state: SupervisorState) -> dict:
    """Combine all worker results."""
    final = synthesize_results(state["worker_results"])
    return {"final_response": final}

# Build graph
graph = StateGraph(SupervisorState)
graph.add_node("supervisor", supervisor_node)
graph.add_node("worker_a", worker_a_node)
graph.add_node("worker_b", worker_b_node)
graph.add_node("synthesize", synthesis_node)

# Routing from supervisor
graph.add_conditional_edges(
    "supervisor",
    route_to_worker,
    {"research": "worker_a", "analysis": "worker_b", "done": "synthesize"}
)
```

---

## Supervisor Routing Decision

```
+------------------------------------------------------------------+
|                   SUPERVISOR ROUTING LOGIC                       |
+------------------------------------------------------------------+
|                                                                  |
|   def route_to_worker(state):                                    |
|       """                                                        |
|       Determine which worker should handle the next step.        |
|                                                                  |
|       Decision tree:                                             |
|                                                                  |
|       Is research done?                                          |
|           |                                                      |
|          NO --> route to "research" worker                       |
|           |                                                      |
|          YES                                                     |
|           |                                                      |
|           v                                                      |
|       Is analysis done?                                          |
|           |                                                      |
|          NO --> route to "analysis" worker                       |
|           |                                                      |
|          YES                                                     |
|           |                                                      |
|           v                                                      |
|       Is writing done?                                           |
|           |                                                      |
|          NO --> route to "writing" worker                        |
|           |                                                      |
|          YES --> route to "done" (synthesis)                     |
|       """                                                        |
|       results = state.get("worker_results", {})                  |
|                                                                  |
|       if "research" not in results:                              |
|           return "research"                                      |
|       if "analysis" not in results:                              |
|           return "analysis"                                      |
|       if "writing" not in results:                               |
|           return "writing"                                       |
|       return "done"                                              |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Complete Graph Flow

```
+------------------------------------------------------------------+
|                  SUPERVISOR GRAPH FLOW                           |
+------------------------------------------------------------------+
|                                                                  |
|        +-------+                                                 |
|        | START |                                                 |
|        +-------+                                                 |
|            |                                                     |
|            v                                                     |
|     +------------+                                               |
|     | SUPERVISOR |<------------------------------------------+   |
|     +------------+                                           |   |
|            |                                                 |   |
|            | (decides next worker)                           |   |
|            |                                                 |   |
|     +------+------+------+------+                            |   |
|     |      |      |      |      |                            |   |
|     v      v      v      v      v                            |   |
| research analysis write review done                          |   |
|     |      |      |      |      |                            |   |
|     v      v      v      v      |                            |   |
| +------+ +------+ +------+ +------+                          |   |
| |Worker| |Worker| |Worker| |Worker|                          |   |
| |  A   | |  B   | |  C   | |  D   |                          |   |
| +------+ +------+ +------+ +------+                          |   |
|     |      |      |      |                                   |   |
|     +------+------+------+                                   |   |
|            |                                                 |   |
|            +-------------------------------------------------+   |
|            (loop back to supervisor)                             |
|                                                                  |
|     When supervisor returns "done":                              |
|            |                                                     |
|            v                                                     |
|     +------------+                                               |
|     | SYNTHESIZE |                                               |
|     +------------+                                               |
|            |                                                     |
|            v                                                     |
|        +-----+                                                   |
|        | END |                                                   |
|        +-----+                                                   |
|                                                                  |
+------------------------------------------------------------------+
```

---

## LLM-Based Supervisor

The supervisor can use an LLM to make routing decisions:

```python
def llm_supervisor_node(state: SupervisorState) -> dict:
    """
    Use an LLM to decide which worker to call next.
    """
    # Define available workers and their capabilities
    workers = """
    Available workers:
    - researcher: Searches for information online
    - analyst: Analyzes data and provides insights
    - writer: Creates reports and documents
    - reviewer: Reviews and improves content
    """

    # Get current state
    messages = state["messages"]
    completed = list(state.get("worker_results", {}).keys())

    # Create prompt for supervisor LLM
    prompt = f"""
    You are a supervisor coordinating a team of workers.

    {workers}

    User request: {messages[0].content}

    Already completed: {completed}

    Based on the user request and what's been completed,
    which worker should handle the next step?

    Respond with ONLY the worker name, or "done" if all work is complete.
    """

    # Call LLM
    response = llm.invoke(prompt)

    return {"next_worker": response.content.strip().lower()}
```

---

## Handling Worker Results

```
+------------------------------------------------------------------+
|                   RESULT AGGREGATION                             |
+------------------------------------------------------------------+
|                                                                  |
|   Worker A completes:                                            |
|   state["worker_results"]["research"] = "Found 3 competitors..." |
|                                                                  |
|   Worker B completes:                                            |
|   state["worker_results"]["analysis"] = "Market growing 15%..."  |
|                                                                  |
|   Worker C completes:                                            |
|   state["worker_results"]["draft"] = "Report: Based on..."       |
|                                                                  |
|   Synthesis Node:                                                |
|   +----------------------------------------------------------+   |
|   |  results = state["worker_results"]                       |   |
|   |                                                          |   |
|   |  final_report = f'''                                     |   |
|   |  # Market Analysis Report                                |   |
|   |                                                          |   |
|   |  ## Research Findings                                    |   |
|   |  {results["research"]}                                   |   |
|   |                                                          |   |
|   |  ## Analysis                                             |   |
|   |  {results["analysis"]}                                   |   |
|   |                                                          |   |
|   |  ## Recommendations                                      |   |
|   |  {results["draft"]}                                      |   |
|   |  '''                                                     |   |
|   +----------------------------------------------------------+   |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Parallel Worker Execution

For independent tasks, workers can run in parallel:

```
Sequential (Slow):
+----------+      +----------+      +----------+
| Worker A | ---> | Worker B | ---> | Worker C |
+----------+      +----------+      +----------+
     10s               10s               10s
                Total: 30 seconds

Parallel (Fast):
+----------+
| Worker A |  10s
+----------+
+----------+
| Worker B |  10s
+----------+
+----------+
| Worker C |  10s
+----------+
          Total: 10 seconds (parallel)
```

LangGraph supports this through branching:

```python
# Workers A and B run in parallel, then C
graph.add_edge("supervisor", "worker_a")
graph.add_edge("supervisor", "worker_b")  # Both start together
graph.add_edge("worker_a", "aggregator")
graph.add_edge("worker_b", "aggregator")  # Wait for both
graph.add_edge("aggregator", "worker_c")
```

---

## Error Handling in Supervisor Pattern

```
+------------------------------------------------------------------+
|                   ERROR HANDLING                                 |
+------------------------------------------------------------------+
|                                                                  |
|   Supervisor receives worker failure:                            |
|                                                                  |
|   +----------------------------------------------------------+   |
|   |  Strategy 1: RETRY                                       |   |
|   |  - Same worker, same task                                |   |
|   |  - Maybe with different parameters                       |   |
|   |  - Limited retry count                                   |   |
|   +----------------------------------------------------------+   |
|                                                                  |
|   +----------------------------------------------------------+   |
|   |  Strategy 2: FALLBACK                                    |   |
|   |  - Route to alternative worker                           |   |
|   |  - Use backup capability                                 |   |
|   +----------------------------------------------------------+   |
|                                                                  |
|   +----------------------------------------------------------+   |
|   |  Strategy 3: DEGRADE                                     |   |
|   |  - Skip failed component                                 |   |
|   |  - Continue with partial results                         |   |
|   |  - Inform user of limitation                             |   |
|   +----------------------------------------------------------+   |
|                                                                  |
|   +----------------------------------------------------------+   |
|   |  Strategy 4: ESCALATE                                    |   |
|   |  - Ask user for guidance                                 |   |
|   |  - Human-in-the-loop decision                            |   |
|   +----------------------------------------------------------+   |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Supervisor Pattern Variations

### 1. Round-Robin Supervisor

```
Tasks distributed evenly:
Task1 -> Worker A
Task2 -> Worker B
Task3 -> Worker C
Task4 -> Worker A (cycles back)
```

### 2. Load-Aware Supervisor

```
Track worker load:
Worker A: 3 tasks in queue
Worker B: 0 tasks in queue  <-- assign here
Worker C: 2 tasks in queue
```

### 3. Capability-Based Supervisor

```
Match task requirements to worker skills:
"Math problem" -> Calculator Worker
"Research question" -> Search Worker
"Writing task" -> Writing Worker
```

---

## Interview Tips

> 💡 **Interview Tip: What is Supervisor Pattern?**
> 
> "The supervisor pattern uses a central coordinating agent that receives tasks, delegates them to specialized worker agents, monitors progress, and aggregates results. It's like a project manager orchestrating a team."

> 💡 **Interview Tip: Supervisor vs Peer-to-Peer**
> 
> "Supervisor pattern has centralized control - one agent makes all decisions. This is simpler to implement and debug but creates a bottleneck. Peer-to-peer allows direct agent communication, which is more flexible but harder to coordinate."

> 💡 **Interview Tip: LLM vs Rule-Based Routing**
> 
> "Rule-based routing (if/else logic) is faster and more predictable. LLM-based routing is more flexible and can handle novel situations. Choose rule-based for well-defined workflows, LLM-based for open-ended tasks."

> 💡 **Interview Tip: Scaling Supervisor Pattern**
> 
> "As complexity grows, a single supervisor becomes a bottleneck. Solution: hierarchical supervisors where each manages a sub-team, or parallel worker execution for independent tasks."

---

## Key Takeaways

1. **Central coordinator** - Supervisor makes all routing decisions
2. **Specialized workers** - Each worker handles specific task types
3. **Clear responsibilities** - Supervisor delegates, workers execute
4. **Result synthesis** - Supervisor combines worker outputs
5. **Error handling** - Supervisor manages retries and fallbacks
6. **Scalability consideration** - May need hierarchy for large systems

---

## Next Steps

Continue to `08_supervisor_example.py` for a complete working implementation of the supervisor pattern.
