"""
ReAct Agent Implementation in LangGraph
========================================

This module demonstrates a complete ReAct (Reason + Act) agent implementation
using LangGraph. The agent can reason about problems and use tools to gather
information before providing a final answer.

The ReAct Loop:
    +----------+      +----------+      +-----------+
    |  REASON  | ---> |   ACT    | ---> |  OBSERVE  |
    | (Think)  |      | (Tool)   |      | (Result)  |
    +----------+      +----------+      +-----------+
         ^                                    |
         |                                    |
         +------------------------------------+
                   (Loop until done)

Author: Learning Module
Topic: Agent Architectures - ReAct Pattern
"""

from typing import TypedDict, Annotated, Literal, Optional
from langgraph.graph import StateGraph, START, END
from langchain_core.messages import HumanMessage, AIMessage, ToolMessage, SystemMessage
from langchain_openai import ChatOpenAI
from langchain_core.tools import tool
import operator
import json

# =============================================================================
# SECTION 1: DEFINE TOOLS
# =============================================================================
# Tools are the "Act" part of ReAct - the actions the agent can take

@tool
def search(query: str) -> str:
    """
    Search for information on the web.

    Use this tool when you need to find current information, facts,
    or data that you don't have in your training data.

    Args:
        query: The search query string

    Returns:
        Search results as a string
    """
    # In production, this would call a real search API
    # For demonstration, we return mock results
    mock_results = {
        "python": "Python is a high-level programming language created by Guido van Rossum in 1991.",
        "langgraph": "LangGraph is a library for building stateful, multi-actor applications with LLMs.",
        "weather": "Current weather: 72F (22C), Partly Cloudy, Humidity 45%",
        "population france": "France has a population of approximately 68 million people (2024).",
        "gdp france": "France's GDP per capita is approximately $44,408 USD (2024).",
    }

    # Simple keyword matching for demo
    query_lower = query.lower()
    for key, value in mock_results.items():
        if key in query_lower:
            return value

    return f"Search results for '{query}': No specific results found. Try a more specific query."


@tool
def calculator(expression: str) -> str:
    """
    Perform mathematical calculations.

    Use this tool when you need to compute mathematical expressions.
    Supports basic arithmetic: +, -, *, /, **, (), etc.

    Args:
        expression: A mathematical expression as a string (e.g., "2 + 2 * 3")

    Returns:
        The result of the calculation
    """
    try:
        # Safety: only allow safe mathematical operations
        # In production, use a proper math parser
        allowed_chars = set("0123456789+-*/.() ")
        if not all(c in allowed_chars for c in expression):
            return "Error: Expression contains invalid characters"

        result = eval(expression)  # Note: Use safer alternative in production
        return f"Result: {result}"
    except Exception as e:
        return f"Calculation error: {str(e)}"


@tool
def get_current_date() -> str:
    """
    Get the current date.

    Use this tool when you need to know today's date.

    Returns:
        Current date in YYYY-MM-DD format
    """
    from datetime import datetime
    return f"Current date: {datetime.now().strftime('%Y-%m-%d')}"


# Collect all tools
TOOLS = [search, calculator, get_current_date]

# Create a mapping of tool names to tool functions
TOOL_MAP = {tool.name: tool for tool in TOOLS}


# =============================================================================
# SECTION 2: DEFINE STATE
# =============================================================================
# State tracks everything the agent knows and has done

class ReActState(TypedDict):
    """
    State for the ReAct agent.

    Attributes:
        messages: List of all messages in the conversation (accumulates)
        iteration: Current iteration count (for loop protection)
        final_answer: The final answer once reasoning is complete

    The 'messages' field uses operator.add to accumulate messages
    rather than replace them, building up the conversation history.
    """
    # Messages accumulate throughout the conversation
    # This includes: User input, AI thoughts, Tool calls, Tool results
    messages: Annotated[list, operator.add]

    # Track iterations to prevent infinite loops
    iteration: int

    # Store final answer when complete
    final_answer: Optional[str]


# =============================================================================
# SECTION 3: DEFINE THE AGENT NODE (REASON)
# =============================================================================
# This is the "Reason" part of ReAct - where the LLM thinks

def create_agent_node(llm: ChatOpenAI, tools: list):
    """
    Create the agent node that performs reasoning.

    The agent node:
    1. Receives the current state (including message history)
    2. Calls the LLM to reason about what to do next
    3. Returns either a tool call or a final answer

    Args:
        llm: The language model to use for reasoning
        tools: List of tools available to the agent

    Returns:
        A function that can be used as a LangGraph node
    """

    # Bind tools to the LLM so it knows what's available
    llm_with_tools = llm.bind_tools(tools)

    def agent_node(state: ReActState) -> dict:
        """
        The main reasoning node.

        This is where the "Thought" part of ReAct happens.
        The LLM decides whether to:
        - Call a tool (Action)
        - Provide a final answer
        """
        print(f"\n{'='*60}")
        print(f"AGENT NODE - Iteration {state.get('iteration', 0) + 1}")
        print(f"{'='*60}")

        # Get the conversation history
        messages = state["messages"]

        # Add system message with ReAct instructions
        system_message = SystemMessage(content="""You are a helpful assistant that uses the ReAct pattern.

For each step, you should:
1. THINK: Reason about what you need to do
2. ACT: Choose a tool to use (if needed)
3. OBSERVE: Look at the tool result (handled automatically)

When you have gathered enough information, provide your final answer directly
without calling any more tools.

Be concise in your reasoning but thorough in your research.""")

        # Prepare messages for the LLM
        full_messages = [system_message] + messages

        # Call the LLM
        response = llm_with_tools.invoke(full_messages)

        print(f"\nLLM Response:")
        print(f"  Content: {response.content[:200]}..." if len(response.content) > 200 else f"  Content: {response.content}")
        print(f"  Tool Calls: {len(response.tool_calls) if response.tool_calls else 0}")

        # Return the response as a new message
        return {
            "messages": [response],
            "iteration": state.get("iteration", 0) + 1
        }

    return agent_node


# =============================================================================
# SECTION 4: DEFINE THE TOOL NODE (ACT)
# =============================================================================
# This is the "Act" part of ReAct - executing tools

def tool_node(state: ReActState) -> dict:
    """
    Execute tools requested by the agent.

    This node:
    1. Extracts tool calls from the last AI message
    2. Executes each tool
    3. Returns the results as ToolMessages

    The results become the "Observation" in the ReAct pattern.
    """
    print(f"\n{'='*60}")
    print("TOOL NODE - Executing Tools")
    print(f"{'='*60}")

    # Get the last message (should be an AI message with tool calls)
    messages = state["messages"]
    last_message = messages[-1]

    # Collect tool results
    tool_messages = []

    # Execute each tool call
    for tool_call in last_message.tool_calls:
        tool_name = tool_call["name"]
        tool_args = tool_call["args"]
        tool_id = tool_call["id"]

        print(f"\n  Executing: {tool_name}")
        print(f"  Arguments: {tool_args}")

        # Find and execute the tool
        if tool_name in TOOL_MAP:
            tool_fn = TOOL_MAP[tool_name]
            try:
                # Execute the tool
                result = tool_fn.invoke(tool_args)
                print(f"  Result: {result}")
            except Exception as e:
                result = f"Error executing {tool_name}: {str(e)}"
                print(f"  Error: {result}")
        else:
            result = f"Unknown tool: {tool_name}"
            print(f"  Error: {result}")

        # Create a ToolMessage with the result
        tool_messages.append(
            ToolMessage(
                content=str(result),
                tool_call_id=tool_id
            )
        )

    return {"messages": tool_messages}


# =============================================================================
# SECTION 5: ROUTING LOGIC
# =============================================================================
# Decide whether to continue acting or finish

def should_continue(state: ReActState) -> Literal["tools", "end"]:
    """
    Determine whether the agent should continue or stop.

    The agent should CONTINUE (go to tools) when:
    - The last message contains tool calls

    The agent should STOP (go to end) when:
    - The last message is a final answer (no tool calls)
    - We've exceeded maximum iterations

    Returns:
        "tools" to execute tools
        "end" to finish
    """
    # Check iteration limit (prevent infinite loops)
    MAX_ITERATIONS = 10
    if state.get("iteration", 0) >= MAX_ITERATIONS:
        print(f"\n[!] Maximum iterations ({MAX_ITERATIONS}) reached. Stopping.")
        return "end"

    # Get the last message
    messages = state["messages"]
    if not messages:
        return "end"

    last_message = messages[-1]

    # Check if the last message has tool calls
    if hasattr(last_message, "tool_calls") and last_message.tool_calls:
        print(f"\n[->] Routing to TOOLS (found {len(last_message.tool_calls)} tool calls)")
        return "tools"
    else:
        print(f"\n[->] Routing to END (no tool calls, final answer)")
        return "end"


# =============================================================================
# SECTION 6: BUILD THE GRAPH
# =============================================================================
# Assemble the ReAct agent graph

def create_react_agent():
    """
    Create a complete ReAct agent using LangGraph.

    Graph Structure:

        +-------+
        | START |
        +-------+
            |
            v
        +-------+     has tools      +-------+
        | AGENT | ----------------> | TOOLS |
        +-------+                   +-------+
            |                           |
            | no tools                  |
            |                           |
            v                           |
        +-----+                         |
        | END | <-----------------------+
        +-----+        (loop back to agent)

    Returns:
        A compiled LangGraph that implements the ReAct pattern
    """
    # Initialize the LLM
    # Using GPT-4 for better reasoning capabilities
    llm = ChatOpenAI(
        model="gpt-4o-mini",  # Or "gpt-4" for better reasoning
        temperature=0  # Deterministic for reproducibility
    )

    # Create the graph
    graph = StateGraph(ReActState)

    # Add nodes
    graph.add_node("agent", create_agent_node(llm, TOOLS))
    graph.add_node("tools", tool_node)

    # Add edges
    # Start -> Agent
    graph.add_edge(START, "agent")

    # Agent -> Conditional (tools or end)
    graph.add_conditional_edges(
        "agent",
        should_continue,
        {
            "tools": "tools",
            "end": END
        }
    )

    # Tools -> Agent (continue the loop)
    graph.add_edge("tools", "agent")

    # Compile the graph
    return graph.compile()


# =============================================================================
# SECTION 7: HELPER FUNCTIONS
# =============================================================================

def print_final_state(state: dict):
    """Pretty print the final state of the agent."""
    print(f"\n{'='*60}")
    print("FINAL STATE")
    print(f"{'='*60}")
    print(f"Total iterations: {state.get('iteration', 0)}")
    print(f"Total messages: {len(state.get('messages', []))}")

    # Print the final answer
    messages = state.get("messages", [])
    if messages:
        last_ai_messages = [m for m in messages if isinstance(m, AIMessage)]
        if last_ai_messages:
            final_message = last_ai_messages[-1]
            print(f"\nFinal Answer:")
            print(f"  {final_message.content}")


def run_agent(agent, question: str):
    """
    Run the ReAct agent with a question.

    Args:
        agent: The compiled LangGraph agent
        question: The user's question

    Returns:
        The final state after agent execution
    """
    print(f"\n{'#'*60}")
    print(f"RUNNING REACT AGENT")
    print(f"{'#'*60}")
    print(f"\nQuestion: {question}")

    # Initialize state with the user's question
    initial_state = {
        "messages": [HumanMessage(content=question)],
        "iteration": 0,
        "final_answer": None
    }

    # Run the agent
    final_state = agent.invoke(initial_state)

    return final_state


# =============================================================================
# SECTION 8: MAIN EXECUTION
# =============================================================================

def main():
    """
    Main function demonstrating the ReAct agent.

    This runs several example queries to show the ReAct pattern in action.
    """
    # Create the agent
    print("Creating ReAct Agent...")
    agent = create_react_agent()

    # Example queries that demonstrate different aspects of ReAct
    queries = [
        # Query 1: Simple search
        "What is LangGraph and what is it used for?",

        # Query 2: Multiple tools
        "What is the population of France? Also, what is 68000000 / 12 (monthly average)?",

        # Query 3: Computation
        "Calculate 15 * 24 + 100 / 4",
    ]

    # Run each query
    for query in queries:
        final_state = run_agent(agent, query)
        print_final_state(final_state)
        print("\n" + "="*60 + "\n")

    print("ReAct Agent demonstration complete!")


# =============================================================================
# SECTION 9: ALTERNATIVE IMPLEMENTATION WITH STREAMING
# =============================================================================

def create_react_agent_with_streaming():
    """
    Alternative implementation that supports streaming output.

    This version streams the agent's thoughts and actions in real-time,
    which is useful for user-facing applications.
    """
    llm = ChatOpenAI(
        model="gpt-4o-mini",
        temperature=0,
        streaming=True  # Enable streaming
    )

    graph = StateGraph(ReActState)
    graph.add_node("agent", create_agent_node(llm, TOOLS))
    graph.add_node("tools", tool_node)

    graph.add_edge(START, "agent")
    graph.add_conditional_edges("agent", should_continue, {"tools": "tools", "end": END})
    graph.add_edge("tools", "agent")

    return graph.compile()


def run_agent_with_streaming(agent, question: str):
    """
    Run agent with streaming to see each step in real-time.

    This is useful for:
    - User interfaces that need to show progress
    - Debugging agent behavior
    - Long-running queries where feedback is important
    """
    initial_state = {
        "messages": [HumanMessage(content=question)],
        "iteration": 0,
        "final_answer": None
    }

    print(f"\nStreaming agent execution for: {question}\n")

    # Stream the execution
    for step in agent.stream(initial_state):
        # Each step contains the node name and its output
        for node_name, output in step.items():
            print(f"[{node_name}] Output keys: {output.keys()}")


# =============================================================================
# INTERVIEW TIPS
# =============================================================================
"""
Interview Tips for ReAct Pattern:

1. Q: "Explain the ReAct pattern"
   A: "ReAct interleaves reasoning traces with action execution. The agent
      thinks about what to do, takes an action, observes the result, and
      repeats until it has enough information to answer."

2. Q: "Why use ReAct instead of just calling tools directly?"
   A: "ReAct provides interpretability (we see the reasoning), better
      planning (the model thinks before acting), and error recovery
      (it can adapt based on observations)."

3. Q: "How do you prevent infinite loops in ReAct?"
   A: "Use iteration limits, detect repeated actions, and ensure clear
      termination conditions. Also provide good tool descriptions so the
      model knows when it has enough information."

4. Q: "What's the role of the 'Observation' in ReAct?"
   A: "Observations ground the agent's reasoning in reality. They provide
      real-world data that the agent uses to inform its next thought
      and action, preventing hallucination."

5. Q: "How does LangGraph implement ReAct?"
   A: "LangGraph uses a StateGraph with an agent node (reasoning), a tools
      node (action), and conditional edges to route between them. The state
      accumulates messages (thoughts, actions, observations) throughout."
"""


if __name__ == "__main__":
    # Note: This requires OPENAI_API_KEY environment variable to be set
    # export OPENAI_API_KEY="your-key-here"

    try:
        main()
    except Exception as e:
        print(f"\nError: {e}")
        print("\nMake sure you have:")
        print("1. Set OPENAI_API_KEY environment variable")
        print("2. Installed required packages: pip install langgraph langchain-openai")
