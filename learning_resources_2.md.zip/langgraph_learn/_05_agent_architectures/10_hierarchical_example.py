"""
Hierarchical Agent Example in LangGraph
========================================

This module demonstrates a complete hierarchical agent architecture with:
- A CEO agent (top-level supervisor)
- VP agents (mid-level supervisors)
- Worker agents (task executors)

Each VP manages a team of workers, and the CEO coordinates the VPs.

Architecture:

                            +----------+
                            |   CEO    |
                            +----------+
                           /     |      \
                          v      v       v
                    +------+ +------+ +------+
                    |VP Eng| |VP Mkt| |VP Ops|
                    +------+ +------+ +------+
                     /   \    /   \    /   \
                    v     v  v     v  v     v
                  [Dev] [QA][Ad] [PR][SRE][Sec]

Author: Learning Module
Topic: Agent Architectures - Hierarchical Patterns
"""

from typing import TypedDict, Annotated, Literal, Optional, Any
from langgraph.graph import StateGraph, START, END
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langchain_openai import ChatOpenAI
import operator
import json
from datetime import datetime


# =============================================================================
# SECTION 1: STATE DEFINITIONS
# =============================================================================

class WorkerState(TypedDict):
    """State for individual worker execution."""
    task: str
    context: str
    output: Optional[str]
    status: str  # pending, working, complete, error


class TeamState(TypedDict):
    """State for team-level (VP) operations."""
    team_name: str
    team_goal: str
    messages: Annotated[list, operator.add]
    worker_outputs: dict
    completed_workers: list[str]
    team_output: Optional[str]
    team_status: str


class OrganizationState(TypedDict):
    """State for organization-level (CEO) operations."""
    strategic_goal: str
    messages: Annotated[list, operator.add]
    current_team: str
    team_outputs: dict
    completed_teams: list[str]
    final_output: Optional[str]
    org_status: str


# =============================================================================
# SECTION 2: WORKER AGENTS
# =============================================================================

class WorkerAgent:
    """
    Base class for worker agents.

    Workers are the lowest level - they execute specific tasks
    and report results back to their team lead (VP).
    """

    def __init__(self, name: str, role: str, llm: ChatOpenAI):
        self.name = name
        self.role = role
        self.llm = llm

    def __call__(self, state: TeamState) -> dict:
        """Execute the worker's task."""
        print(f"    [{self.name.upper()}] Starting work...")

        # Get task for this worker
        task = state.get("team_goal", "")

        # Create role-specific prompt
        prompt = f"""You are a {self.role} on a team.

Team Goal: {task}

Your specific responsibilities as {self.name}:
{self._get_responsibilities()}

Provide your contribution to the team goal. Be specific and actionable.
Keep your response focused and under 200 words."""

        messages = [
            SystemMessage(content=f"You are {self.name}, a {self.role}."),
            HumanMessage(content=prompt)
        ]

        response = self.llm.invoke(messages)

        print(f"    [{self.name.upper()}] Complete")

        # Update worker outputs
        current_outputs = state.get("worker_outputs", {})
        current_outputs[self.name] = response.content

        return {
            "worker_outputs": current_outputs,
            "completed_workers": state.get("completed_workers", []) + [self.name],
            "messages": [AIMessage(content=f"[{self.name}]: Work complete")]
        }

    def _get_responsibilities(self) -> str:
        """Override in subclasses to define specific responsibilities."""
        return f"Execute tasks related to {self.role}"


class DeveloperWorker(WorkerAgent):
    def __init__(self, llm: ChatOpenAI):
        super().__init__("developer", "Software Developer", llm)

    def _get_responsibilities(self) -> str:
        return """
- Write and review code
- Implement features and fix bugs
- Ensure code quality and best practices
- Document technical decisions"""


class QAWorker(WorkerAgent):
    def __init__(self, llm: ChatOpenAI):
        super().__init__("qa", "QA Engineer", llm)

    def _get_responsibilities(self) -> str:
        return """
- Design and execute test plans
- Identify bugs and edge cases
- Ensure quality standards are met
- Report testing results and coverage"""


class AdvertisingWorker(WorkerAgent):
    def __init__(self, llm: ChatOpenAI):
        super().__init__("advertising", "Advertising Specialist", llm)

    def _get_responsibilities(self) -> str:
        return """
- Create advertising campaigns
- Define target audiences
- Optimize ad performance
- Track and report metrics"""


class PRWorker(WorkerAgent):
    def __init__(self, llm: ChatOpenAI):
        super().__init__("pr", "PR Specialist", llm)

    def _get_responsibilities(self) -> str:
        return """
- Manage public communications
- Write press releases
- Handle media relations
- Maintain brand voice"""


class SREWorker(WorkerAgent):
    def __init__(self, llm: ChatOpenAI):
        super().__init__("sre", "Site Reliability Engineer", llm)

    def _get_responsibilities(self) -> str:
        return """
- Ensure system reliability
- Set up monitoring and alerts
- Handle incident response
- Optimize performance"""


class SecurityWorker(WorkerAgent):
    def __init__(self, llm: ChatOpenAI):
        super().__init__("security", "Security Engineer", llm)

    def _get_responsibilities(self) -> str:
        return """
- Assess security risks
- Implement security measures
- Conduct security reviews
- Ensure compliance"""


# =============================================================================
# SECTION 3: VP (TEAM LEAD) AGENTS
# =============================================================================

class VPAgent:
    """
    VP agents are mid-level supervisors.

    They receive goals from the CEO, delegate to workers,
    and synthesize team results.
    """

    def __init__(self, name: str, department: str, workers: list[str], llm: ChatOpenAI):
        self.name = name
        self.department = department
        self.workers = workers
        self.llm = llm

    def delegate(self, state: TeamState) -> dict:
        """Decide which worker should act next."""
        print(f"  [{self.name.upper()}] Delegating...")

        completed = state.get("completed_workers", [])

        for worker in self.workers:
            if worker not in completed:
                print(f"  [{self.name.upper()}] Assigning to: {worker}")
                return {
                    "current_worker": worker,
                    "messages": [AIMessage(content=f"[{self.name}]: Delegating to {worker}")]
                }

        print(f"  [{self.name.upper()}] All workers complete")
        return {
            "current_worker": "synthesize",
            "messages": [AIMessage(content=f"[{self.name}]: All tasks complete")]
        }

    def synthesize(self, state: TeamState) -> dict:
        """Combine worker outputs into team deliverable."""
        print(f"  [{self.name.upper()}] Synthesizing team output...")

        worker_outputs = state.get("worker_outputs", {})

        # Create synthesis prompt
        prompt = f"""You are the {self.name}, leading the {self.department} team.

Team Goal: {state.get('team_goal', '')}

Your team members have provided the following:
"""
        for worker, output in worker_outputs.items():
            prompt += f"\n{worker}:\n{output}\n"

        prompt += """
Synthesize these contributions into a cohesive team deliverable.
Include:
1. Summary of team achievements
2. Key outputs and decisions
3. Any risks or blockers identified
4. Recommendations for next steps"""

        messages = [
            SystemMessage(content=f"You are {self.name} of {self.department}."),
            HumanMessage(content=prompt)
        ]

        response = self.llm.invoke(messages)

        print(f"  [{self.name.upper()}] Synthesis complete")

        return {
            "team_output": response.content,
            "team_status": "complete",
            "messages": [AIMessage(content=f"[{self.name}]: Team deliverable ready")]
        }


# =============================================================================
# SECTION 4: CEO AGENT
# =============================================================================

class CEOAgent:
    """
    The CEO is the top-level supervisor.

    Receives the strategic goal, delegates to VPs (teams),
    monitors progress, and creates the final deliverable.
    """

    def __init__(self, teams: list[str], llm: ChatOpenAI):
        self.teams = teams
        self.llm = llm
        self.name = "ceo"

    def strategize(self, state: OrganizationState) -> dict:
        """Initial strategy and delegation decisions."""
        print(f"\n[CEO] Strategizing...")

        goal = state.get("strategic_goal", "")

        prompt = f"""You are the CEO coordinating a product launch.

Strategic Goal: {goal}

You have three teams available:
- Engineering: Development and technical implementation
- Marketing: Advertising, PR, and market positioning
- Operations: Reliability, security, and deployment

Briefly outline how you'll coordinate these teams to achieve the goal."""

        messages = [
            SystemMessage(content="You are a strategic CEO."),
            HumanMessage(content=prompt)
        ]

        response = self.llm.invoke(messages)

        print(f"[CEO] Strategy defined")

        return {
            "messages": [AIMessage(content=f"[CEO]: {response.content}")],
            "org_status": "coordinating"
        }

    def delegate_to_team(self, state: OrganizationState) -> dict:
        """Decide which team should work next."""
        print(f"\n[CEO] Delegating to team...")

        completed = state.get("completed_teams", [])

        for team in self.teams:
            if team not in completed:
                print(f"[CEO] Assigning to: {team}")
                return {
                    "current_team": team,
                    "messages": [AIMessage(content=f"[CEO]: Delegating to {team} team")]
                }

        print(f"[CEO] All teams complete")
        return {
            "current_team": "finalize",
            "messages": [AIMessage(content=f"[CEO]: All teams complete")]
        }

    def finalize(self, state: OrganizationState) -> dict:
        """Create the final organizational output."""
        print(f"\n[CEO] Finalizing...")

        team_outputs = state.get("team_outputs", {})

        prompt = f"""You are the CEO preparing the final deliverable.

Strategic Goal: {state.get('strategic_goal', '')}

Team Deliverables:
"""
        for team, output in team_outputs.items():
            prompt += f"\n=== {team.upper()} TEAM ===\n{output}\n"

        prompt += """
Create an executive summary that:
1. Confirms goal achievement
2. Highlights key accomplishments from each team
3. Identifies any outstanding risks or issues
4. Provides recommendations for next steps"""

        messages = [
            SystemMessage(content="You are the CEO delivering final results."),
            HumanMessage(content=prompt)
        ]

        response = self.llm.invoke(messages)

        print(f"[CEO] Finalization complete")

        return {
            "final_output": response.content,
            "org_status": "complete",
            "messages": [AIMessage(content=f"[CEO]: Final deliverable ready")]
        }


# =============================================================================
# SECTION 5: TEAM SUBGRAPHS
# =============================================================================

def create_team_graph(team_name: str, workers: list[WorkerAgent], vp: VPAgent) -> StateGraph:
    """
    Create a subgraph for a team.

    Structure:
        VP (delegate) --> Worker1 --> VP (delegate) --> Worker2 --> ... --> VP (synthesize)
    """
    graph = StateGraph(TeamState)

    # Add VP node for delegation
    graph.add_node("vp_delegate", vp.delegate)

    # Add worker nodes
    for worker in workers:
        graph.add_node(worker.name, worker)

    # Add VP synthesis node
    graph.add_node("vp_synthesize", vp.synthesize)

    # Routing function
    def route_worker(state: TeamState) -> str:
        current = state.get("current_worker", "")
        if current == "synthesize":
            return "synthesize"
        return current

    # Build edges
    graph.add_edge(START, "vp_delegate")

    # VP delegates to workers
    routing_map = {w.name: w.name for w in workers}
    routing_map["synthesize"] = "vp_synthesize"

    graph.add_conditional_edges("vp_delegate", route_worker, routing_map)

    # Workers loop back to VP
    for worker in workers:
        graph.add_edge(worker.name, "vp_delegate")

    # Synthesis ends the team
    graph.add_edge("vp_synthesize", END)

    return graph


def create_engineering_team(llm: ChatOpenAI):
    """Create the Engineering team subgraph."""
    workers = [DeveloperWorker(llm), QAWorker(llm)]
    vp = VPAgent("VP Engineering", "Engineering", ["developer", "qa"], llm)
    return create_team_graph("engineering", workers, vp).compile()


def create_marketing_team(llm: ChatOpenAI):
    """Create the Marketing team subgraph."""
    workers = [AdvertisingWorker(llm), PRWorker(llm)]
    vp = VPAgent("VP Marketing", "Marketing", ["advertising", "pr"], llm)
    return create_team_graph("marketing", workers, vp).compile()


def create_operations_team(llm: ChatOpenAI):
    """Create the Operations team subgraph."""
    workers = [SREWorker(llm), SecurityWorker(llm)]
    vp = VPAgent("VP Operations", "Operations", ["sre", "security"], llm)
    return create_team_graph("operations", workers, vp).compile()


# =============================================================================
# SECTION 6: ORGANIZATION GRAPH
# =============================================================================

def create_organization_graph():
    """
    Create the full hierarchical organization graph.

    Structure:
        CEO --> Engineering Team --> CEO --> Marketing Team --> CEO --> Ops Team --> CEO (finalize)
    """
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)

    # Create CEO
    teams = ["engineering", "marketing", "operations"]
    ceo = CEOAgent(teams, llm)

    # Create team subgraphs
    eng_team = create_engineering_team(llm)
    mkt_team = create_marketing_team(llm)
    ops_team = create_operations_team(llm)

    # Build main graph
    graph = StateGraph(OrganizationState)

    # Add CEO nodes
    graph.add_node("ceo_strategize", ceo.strategize)
    graph.add_node("ceo_delegate", ceo.delegate_to_team)
    graph.add_node("ceo_finalize", ceo.finalize)

    # Add team wrapper nodes
    def run_engineering(state: OrganizationState) -> dict:
        print(f"\n[ENGINEERING TEAM] Starting...")
        team_state = {
            "team_name": "engineering",
            "team_goal": f"Technical implementation for: {state['strategic_goal']}",
            "messages": [],
            "worker_outputs": {},
            "completed_workers": [],
            "team_output": None,
            "team_status": "working"
        }
        result = eng_team.invoke(team_state)
        return {
            "team_outputs": {**state.get("team_outputs", {}), "engineering": result["team_output"]},
            "completed_teams": state.get("completed_teams", []) + ["engineering"],
            "messages": [AIMessage(content="[Engineering Team]: Complete")]
        }

    def run_marketing(state: OrganizationState) -> dict:
        print(f"\n[MARKETING TEAM] Starting...")
        team_state = {
            "team_name": "marketing",
            "team_goal": f"Marketing strategy for: {state['strategic_goal']}",
            "messages": [],
            "worker_outputs": {},
            "completed_workers": [],
            "team_output": None,
            "team_status": "working"
        }
        result = mkt_team.invoke(team_state)
        return {
            "team_outputs": {**state.get("team_outputs", {}), "marketing": result["team_output"]},
            "completed_teams": state.get("completed_teams", []) + ["marketing"],
            "messages": [AIMessage(content="[Marketing Team]: Complete")]
        }

    def run_operations(state: OrganizationState) -> dict:
        print(f"\n[OPERATIONS TEAM] Starting...")
        team_state = {
            "team_name": "operations",
            "team_goal": f"Operational readiness for: {state['strategic_goal']}",
            "messages": [],
            "worker_outputs": {},
            "completed_workers": [],
            "team_output": None,
            "team_status": "working"
        }
        result = ops_team.invoke(team_state)
        return {
            "team_outputs": {**state.get("team_outputs", {}), "operations": result["team_output"]},
            "completed_teams": state.get("completed_teams", []) + ["operations"],
            "messages": [AIMessage(content="[Operations Team]: Complete")]
        }

    graph.add_node("engineering", run_engineering)
    graph.add_node("marketing", run_marketing)
    graph.add_node("operations", run_operations)

    # Routing function
    def route_to_team(state: OrganizationState) -> str:
        current = state.get("current_team", "")
        if current == "finalize":
            return "finalize"
        return current

    # Build edges
    graph.add_edge(START, "ceo_strategize")
    graph.add_edge("ceo_strategize", "ceo_delegate")

    graph.add_conditional_edges(
        "ceo_delegate",
        route_to_team,
        {
            "engineering": "engineering",
            "marketing": "marketing",
            "operations": "operations",
            "finalize": "ceo_finalize"
        }
    )

    # Teams loop back to CEO
    graph.add_edge("engineering", "ceo_delegate")
    graph.add_edge("marketing", "ceo_delegate")
    graph.add_edge("operations", "ceo_delegate")

    # Finalize ends
    graph.add_edge("ceo_finalize", END)

    return graph.compile()


# =============================================================================
# SECTION 7: EXECUTION
# =============================================================================

def run_organization(strategic_goal: str) -> str:
    """
    Run the hierarchical organization with a strategic goal.

    Args:
        strategic_goal: The top-level goal for the organization

    Returns:
        The final executive summary
    """
    print("=" * 70)
    print("HIERARCHICAL AGENT SYSTEM")
    print("=" * 70)
    print(f"\nStrategic Goal: {strategic_goal}")
    print("-" * 70)

    # Create organization
    org = create_organization_graph()

    # Initialize state
    initial_state = {
        "strategic_goal": strategic_goal,
        "messages": [HumanMessage(content=strategic_goal)],
        "current_team": "",
        "team_outputs": {},
        "completed_teams": [],
        "final_output": None,
        "org_status": "starting"
    }

    # Run
    final_state = org.invoke(initial_state)

    return final_state.get("final_output", "No output generated")


# =============================================================================
# SECTION 8: DEMO
# =============================================================================

def main():
    """Demonstrate the hierarchical agent system."""

    goal = """
    Launch a new AI-powered customer service chatbot product.
    The product should be ready for market in Q4.
    Target audience: mid-size e-commerce companies.
    """

    result = run_organization(goal)

    print("\n" + "=" * 70)
    print("FINAL EXECUTIVE SUMMARY")
    print("=" * 70)
    print(result)


# =============================================================================
# SECTION 9: ALTERNATIVE PATTERNS
# =============================================================================

def create_parallel_organization():
    """
    Alternative: Run teams in parallel when they're independent.

    This is faster when teams don't have dependencies.
    """
    # In LangGraph, you can use branching to run teams in parallel
    # All teams start at the same time, CEO waits for all to complete

    # Implementation would use:
    # graph.add_edge("ceo_delegate", "engineering")
    # graph.add_edge("ceo_delegate", "marketing")
    # graph.add_edge("ceo_delegate", "operations")
    # (All three run in parallel)

    # Then aggregate:
    # graph.add_edge("engineering", "aggregator")
    # graph.add_edge("marketing", "aggregator")
    # graph.add_edge("operations", "aggregator")
    pass


def create_deep_hierarchy():
    """
    Alternative: Deeper hierarchy with more levels.

    CEO -> VPs -> Directors -> Managers -> Workers

    Use when teams are large and need more granular coordination.
    """
    pass


# =============================================================================
# INTERVIEW TIPS
# =============================================================================
"""
Interview Tips for Hierarchical Agents:

1. Q: "When should you use hierarchical vs flat architecture?"
   A: "Use hierarchical when: a single supervisor becomes a bottleneck,
      teams naturally have different domains, you need to scale to many
      agents, or you want clear separation of concerns. Stick with flat
      for simpler systems where the overhead isn't justified."

2. Q: "How do you handle state in hierarchical systems?"
   A: "State is typically layered: global state for org-wide context,
      team state for team-specific work, worker state for individual
      tasks. LangGraph subgraphs help encapsulate each level's state
      while allowing necessary information to flow between levels."

3. Q: "How do subgraphs work in LangGraph?"
   A: "A subgraph is a compiled graph that can be used as a node in a
      parent graph. When the parent routes to that node, the entire
      subgraph executes. This provides clean encapsulation - the parent
      doesn't need to know the subgraph's internal structure."

4. Q: "How do you handle errors in hierarchical systems?"
   A: "Errors can be handled locally (retry at worker level), escalated
      (report to team lead, who might reassign), or propagated up
      (major issues reach CEO who can make strategic decisions or
      request human intervention)."

5. Q: "What's the performance impact of hierarchical systems?"
   A: "More levels mean more LLM calls and higher latency. However,
      teams can often run in parallel, and each agent has a smaller
      context to process. The trade-off is usually worth it for
      complex systems that would overwhelm a single supervisor."
"""


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"\nError: {e}")
        print("\nMake sure you have:")
        print("1. Set OPENAI_API_KEY environment variable")
        print("2. Installed: pip install langgraph langchain-openai")
