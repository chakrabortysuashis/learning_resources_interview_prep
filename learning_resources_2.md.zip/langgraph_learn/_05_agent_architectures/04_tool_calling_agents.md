# Tool Calling Agents in LangGraph

## Introduction

Tool calling is a fundamental capability of modern AI agents. It allows LLMs to extend beyond text generation and interact with external systems, APIs, databases, and services. In LangGraph, tool calling agents are implemented as graphs that dynamically select and execute tools based on the current context.

---

## What is Tool Calling?

Tool calling (also known as function calling) is when an LLM decides to invoke an external function instead of generating text directly.

```
+------------------------------------------------------------------+
|                      TOOL CALLING FLOW                           |
+------------------------------------------------------------------+
|                                                                  |
|   User: "What's the weather in Tokyo?"                           |
|                                                                  |
|         |                                                        |
|         v                                                        |
|   +-----------+                                                  |
|   |    LLM    |  (Decides: I need to call a tool)                |
|   +-----------+                                                  |
|         |                                                        |
|         v                                                        |
|   +------------------+                                           |
|   | Tool Selection   |                                           |
|   | "get_weather"    |                                           |
|   | args: {city:     |                                           |
|   |        "Tokyo"}  |                                           |
|   +------------------+                                           |
|         |                                                        |
|         v                                                        |
|   +-----------+                                                  |
|   |   Tool    |  (External API call)                             |
|   | Execution |                                                  |
|   +-----------+                                                  |
|         |                                                        |
|         v                                                        |
|   Result: {"temp": 22, "condition": "Sunny"}                     |
|         |                                                        |
|         v                                                        |
|   +-----------+                                                  |
|   |    LLM    |  (Formats response)                              |
|   +-----------+                                                  |
|         |                                                        |
|         v                                                        |
|   Response: "It's 22C and sunny in Tokyo!"                       |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Anatomy of a Tool

A tool in LangGraph/LangChain consists of several components:

```
+------------------------------------------------------------------+
|                        TOOL ANATOMY                              |
+------------------------------------------------------------------+
|                                                                  |
|   @tool                                <-- Decorator             |
|   def weather_lookup(                                            |
|       city: str,                       <-- Parameters (typed)    |
|       units: str = "celsius"                                     |
|   ) -> str:                            <-- Return type           |
|       """                                                        |
|       Get current weather for a city.  <-- Description           |
|                                            (LLM reads this!)     |
|       Args:                                                      |
|           city: The city name          <-- Param descriptions    |
|           units: Temperature units                               |
|                                                                  |
|       Returns:                                                   |
|           Weather information          <-- Return description    |
|       """                                                        |
|       return call_weather_api(city, units)  <-- Implementation   |
|                                                                  |
+------------------------------------------------------------------+
```

### The LLM Sees This Schema:

```json
{
  "name": "weather_lookup",
  "description": "Get current weather for a city.",
  "parameters": {
    "type": "object",
    "properties": {
      "city": {
        "type": "string",
        "description": "The city name"
      },
      "units": {
        "type": "string",
        "description": "Temperature units",
        "default": "celsius"
      }
    },
    "required": ["city"]
  }
}
```

---

## Tool Binding in LangGraph

```python
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI

# Define tools
@tool
def search(query: str) -> str:
    """Search the web for information."""
    return f"Results for: {query}"

@tool
def calculator(expression: str) -> str:
    """Calculate a mathematical expression."""
    return str(eval(expression))

# Collect tools
tools = [search, calculator]

# Bind tools to the LLM
llm = ChatOpenAI(model="gpt-4o-mini")
llm_with_tools = llm.bind_tools(tools)

# Now the LLM can decide to call these tools
```

---

## How the LLM Decides Which Tool to Use

```
+------------------------------------------------------------------+
|                   TOOL SELECTION PROCESS                         |
+------------------------------------------------------------------+
|                                                                  |
|   User Query: "What is 15 * 24 + 100?"                           |
|                                                                  |
|   LLM Receives:                                                  |
|   +----------------------------------------------------------+   |
|   | Available Tools:                                         |   |
|   |                                                          |   |
|   | 1. search(query: str)                                    |   |
|   |    - Search the web for information                      |   |
|   |                                                          |   |
|   | 2. calculator(expression: str)                           |   |
|   |    - Calculate a mathematical expression                 |   |
|   |                                                          |   |
|   | 3. weather(city: str)                                    |   |
|   |    - Get weather for a city                              |   |
|   +----------------------------------------------------------+   |
|                                                                  |
|   LLM Thinks:                                                    |
|   "This is a math problem. I should use the calculator tool."   |
|                                                                  |
|   LLM Output:                                                    |
|   +----------------------------------------------------------+   |
|   | tool_calls: [                                            |   |
|   |   {                                                      |   |
|   |     "name": "calculator",                                |   |
|   |     "args": {"expression": "15 * 24 + 100"}              |   |
|   |   }                                                      |   |
|   | ]                                                        |   |
|   +----------------------------------------------------------+   |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Tool Calling Agent Architecture

```
+------------------------------------------------------------------+
|              TOOL CALLING AGENT IN LANGGRAPH                     |
+------------------------------------------------------------------+
|                                                                  |
|                        +-------+                                 |
|                        | START |                                 |
|                        +-------+                                 |
|                            |                                     |
|                            v                                     |
|   +------------------------------------------------+             |
|   |                  AGENT NODE                    |             |
|   |  +------------------------------------------+  |             |
|   |  |  LLM with bound tools                    |  |             |
|   |  |  - Analyzes user query                   |  |             |
|   |  |  - Decides: tool call OR direct answer   |  |             |
|   |  +------------------------------------------+  |             |
|   +------------------------------------------------+             |
|                            |                                     |
|               +------------+------------+                        |
|               |                         |                        |
|         has tool_calls           no tool_calls                   |
|               |                         |                        |
|               v                         v                        |
|   +-------------------+           +---------+                    |
|   |    TOOLS NODE     |           |   END   |                    |
|   |  +-------------+  |           +---------+                    |
|   |  | Execute     |  |                                          |
|   |  | each tool   |  |                                          |
|   |  | call        |  |                                          |
|   |  +-------------+  |                                          |
|   +-------------------+                                          |
|               |                                                  |
|               | (results added to messages)                      |
|               |                                                  |
|               +---------> Back to AGENT NODE                     |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Multiple Tool Calls

Modern LLMs can call multiple tools in parallel:

```
+------------------------------------------------------------------+
|                   PARALLEL TOOL CALLS                            |
+------------------------------------------------------------------+
|                                                                  |
|   User: "What's the weather in NYC and what's 100/4?"            |
|                                                                  |
|   LLM Output:                                                    |
|   +----------------------------------------------------------+   |
|   | tool_calls: [                                            |   |
|   |   {"name": "weather", "args": {"city": "NYC"}},          |   |
|   |   {"name": "calculator", "args": {"expression": "100/4"}}|   |
|   | ]                                                        |   |
|   +----------------------------------------------------------+   |
|                                                                  |
|   Execution:                                                     |
|                                                                  |
|   +-------------+     +-------------+                            |
|   |   weather   |     | calculator  |                            |
|   |   (NYC)     |     |  (100/4)    |                            |
|   +-------------+     +-------------+                            |
|         |                   |                                    |
|         v                   v                                    |
|   "72F, Sunny"         "25.0"                                    |
|         |                   |                                    |
|         +-------+-----------+                                    |
|                 |                                                |
|                 v                                                |
|   LLM combines: "It's 72F and sunny in NYC, and 100/4 = 25"     |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Tool Result Handling

The results from tools are passed back to the LLM as `ToolMessage`:

```python
from langchain_core.messages import ToolMessage

# After executing a tool call
tool_message = ToolMessage(
    content="Result: 25.0",           # The tool's output
    tool_call_id="call_abc123",       # Matches the original call
)
```

The message flow looks like:

```
Messages Timeline:
+------------------------------------------------------------------+
|  1. HumanMessage: "Calculate 100/4"                              |
|                                                                  |
|  2. AIMessage:                                                   |
|     content: ""                                                  |
|     tool_calls: [{"name": "calculator", "args": {...}}]          |
|                                                                  |
|  3. ToolMessage:                                                 |
|     content: "Result: 25.0"                                      |
|     tool_call_id: "call_abc123"                                  |
|                                                                  |
|  4. AIMessage:                                                   |
|     content: "The result of 100/4 is 25"                         |
|     tool_calls: []  (no more tools needed)                       |
+------------------------------------------------------------------+
```

---

## Best Practices for Tool Design

### 1. Clear Descriptions

```python
# BAD - Vague description
@tool
def get_data(x: str) -> str:
    """Gets data."""
    pass

# GOOD - Clear, specific description
@tool  
def get_stock_price(symbol: str) -> str:
    """
    Get the current stock price for a given ticker symbol.
    
    Use this when the user asks about stock prices, market data,
    or wants to know how a specific company's stock is performing.
    
    Args:
        symbol: Stock ticker symbol (e.g., 'AAPL', 'GOOGL', 'MSFT')
        
    Returns:
        Current stock price and daily change percentage
    """
    pass
```

### 2. Type Hints and Defaults

```python
from typing import Optional, Literal

@tool
def search_products(
    query: str,
    category: Optional[str] = None,
    sort_by: Literal["price", "rating", "newest"] = "rating",
    max_results: int = 10
) -> str:
    """
    Search for products in the catalog.
    
    Args:
        query: Search terms
        category: Filter by category (optional)
        sort_by: Sort results by price, rating, or newest
        max_results: Maximum number of results to return
    """
    pass
```

### 3. Error Handling

```python
@tool
def divide_numbers(a: float, b: float) -> str:
    """
    Divide two numbers.
    
    Args:
        a: The dividend
        b: The divisor (must not be zero)
    """
    if b == 0:
        return "Error: Cannot divide by zero"
    return f"Result: {a / b}"
```

---

## Tool Categories

```
+------------------------------------------------------------------+
|                     COMMON TOOL TYPES                            |
+------------------------------------------------------------------+
|                                                                  |
|  INFORMATION RETRIEVAL                                           |
|  +------------------+  +------------------+  +----------------+   |
|  | Web Search       |  | Database Query   |  | API Lookup     |   |
|  +------------------+  +------------------+  +----------------+   |
|                                                                  |
|  COMPUTATION                                                     |
|  +------------------+  +------------------+  +----------------+   |
|  | Calculator       |  | Code Execution   |  | Data Analysis  |   |
|  +------------------+  +------------------+  +----------------+   |
|                                                                  |
|  EXTERNAL ACTIONS                                                |
|  +------------------+  +------------------+  +----------------+   |
|  | Send Email       |  | Create Document  |  | Update Record  |   |
|  +------------------+  +------------------+  +----------------+   |
|                                                                  |
|  SYSTEM UTILITIES                                                |
|  +------------------+  +------------------+  +----------------+   |
|  | Get Current Time |  | Read File        |  | List Directory |   |
|  +------------------+  +------------------+  +----------------+   |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Tool Execution Safety

### Dangerous Tools Need Confirmation

```
+------------------------------------------------------------------+
|                     TOOL SAFETY LEVELS                           |
+------------------------------------------------------------------+
|                                                                  |
|  SAFE (Auto-execute):                                            |
|  - Search queries                                                |
|  - Calculations                                                  |
|  - Read-only lookups                                             |
|                                                                  |
|  SENSITIVE (Log/Review):                                         |
|  - Database queries                                              |
|  - File reads                                                    |
|  - External API calls                                            |
|                                                                  |
|  DANGEROUS (Require Confirmation):                               |
|  - Sending emails                                                |
|  - Modifying data                                                |
|  - Financial transactions                                        |
|  - Deleting records                                              |
|                                                                  |
+------------------------------------------------------------------+
```

```python
# Implementation with human-in-the-loop
from langgraph.checkpoint.memory import MemorySaver

# Use interrupt_before for dangerous tools
graph = workflow.compile(
    checkpointer=MemorySaver(),
    interrupt_before=["send_email", "delete_record"]  # Pause here
)
```

---

## Interview Tips

> 💡 **Interview Tip: Tool Calling Basics**
> 
> "Tool calling allows LLMs to invoke external functions. The LLM receives tool schemas (name, description, parameters), and when appropriate, returns structured tool calls instead of text. The results are fed back for the LLM to incorporate into its response."

> 💡 **Interview Tip: Tool Design**
> 
> "Good tool design is critical. Clear descriptions help the LLM choose the right tool. Strong typing prevents errors. Error handling ensures graceful failures. Think of tool descriptions as API documentation for the LLM."

> 💡 **Interview Tip: Parallel vs Sequential**
> 
> "Modern LLMs can request multiple tool calls in parallel when they're independent. LangGraph's tool node should handle this by executing all calls and returning all results. This improves efficiency for complex queries."

> 💡 **Interview Tip: Safety Considerations**
> 
> "Not all tools are equal in risk. Read-only tools are safe to auto-execute. Tools that modify data or perform actions should have human-in-the-loop confirmation. Use LangGraph's interrupt features for this."

---

## Key Takeaways

1. **Tools extend LLM capabilities** - Beyond text generation to real actions
2. **Schema matters** - Clear descriptions help LLMs choose the right tool
3. **Type safety** - Use proper typing for reliable tool execution
4. **Handle errors gracefully** - Tools should return useful error messages
5. **Consider safety** - Dangerous tools need human oversight
6. **LangGraph makes it elegant** - Graph structure naturally handles the tool loop

---

## Next Steps

Continue to `05_tool_agent_example.py` for a complete implementation of a tool-calling agent.
