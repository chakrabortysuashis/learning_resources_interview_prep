# LangGraph Comparison Interview Questions

## Overview

These questions test your understanding of when to use LangGraph versus other
approaches. Interviewers want to see that you can make informed architectural
decisions.

---

## Section 1: LangGraph vs LangChain (LCEL)

### Q1. When would you choose LCEL over LangGraph? [MEDIUM]

**Answer:**

**Choose LCEL when:**
1. **Linear workflows**: Simple prompt -> LLM -> output pipelines
2. **No cycles needed**: Each step executes exactly once
3. **Stateless operations**: No need to maintain conversation state
4. **Simple composition**: Chaining a few components together
5. **Quick prototypes**: Getting something working fast

**LCEL example (appropriate use):**
```python
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI

# Simple linear chain - LCEL is perfect
chain = (
    ChatPromptTemplate.from_template("Translate to French: {text}")
    | ChatOpenAI()
    | StrOutputParser()
)

result = chain.invoke({"text": "Hello world"})
```

**When LCEL becomes limiting:**
```python
# This is awkward in LCEL:
# - Agent needs to loop until done
# - State needs to persist across iterations
# - Conditional branching based on LLM output

# You end up with:
while not done:
    result = chain.invoke(state)
    if result.tool_calls:
        tool_result = execute_tools(result.tool_calls)
        state.append(tool_result)
    else:
        done = True
```

**What interviewers look for:**
- Understanding that LCEL and LangGraph are complementary
- Ability to identify when complexity warrants LangGraph
- Recognition that overengineering simple tasks is also bad

---

### Q2. What can LangGraph do that LCEL cannot? [MEDIUM]

**Answer:**

| Capability | LCEL | LangGraph |
|------------|------|-----------|
| Linear chains | Yes | Yes |
| Cycles/loops | No | Yes |
| Persistent state | No | Yes (checkpointing) |
| Human-in-the-loop | Difficult | Native support |
| Conditional branching | Limited | Full support |
| Parallel execution | RunnableParallel | Send API |
| Time travel/replay | No | Yes |
| Subgraphs | No | Yes |

**Key differentiators:**

1. **Cycles for agent loops:**
```
LCEL: prompt -> llm -> tools -> ??? (can't loop back)
LangGraph: agent <-> tools (cycles naturally)
```

2. **Checkpointing:**
```python
# LangGraph can resume from any step
config = {"configurable": {"thread_id": "123"}}
# ... system crashes ...
app.invoke(None, config)  # Resumes from last checkpoint
```

3. **Human intervention points:**
```python
# Not possible in LCEL
app = graph.compile(interrupt_before=["send_email"])
```

4. **Complex state management:**
```python
# LangGraph state with reducers
class State(TypedDict):
    messages: Annotated[list, add]      # Accumulates
    current_step: str                    # Replaces
    attempts: Annotated[int, lambda a, b: a + b]  # Custom
```

---

### Q3. Can you use LCEL inside LangGraph? How? [EASY]

**Answer:**

Yes! LCEL chains can be nodes in LangGraph. This is a common and recommended pattern.

```python
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langgraph.graph import StateGraph

# LCEL chain
summarize_chain = (
    ChatPromptTemplate.from_template("Summarize: {text}")
    | llm
    | StrOutputParser()
)

# Use as LangGraph node
def summarize_node(state):
    summary = summarize_chain.invoke({"text": state["document"]})
    return {"summary": summary}

graph = StateGraph(State)
graph.add_node("summarize", summarize_node)
```

**Why this is powerful:**
- Best of both worlds
- LCEL for clean prompt composition
- LangGraph for orchestration and state
- Gradual migration from LCEL to LangGraph

---

## Section 2: LangGraph vs Plain Python

### Q4. Why not just write agent loops in plain Python? [MEDIUM]

**Answer:**

**You could, but LangGraph provides:**

1. **Persistence out of the box:**
```python
# Plain Python - you build this yourself:
def save_state(state, db):
    db.save(state)

def load_state(thread_id, db):
    return db.load(thread_id)

# LangGraph - built in:
app = graph.compile(checkpointer=PostgresSaver(conn))
```

2. **Streaming with proper abstractions:**
```python
# Plain Python - manual yield management
def stream_agent():
    while not done:
        token = llm.stream_next()
        yield token

# LangGraph - multiple stream modes, async support
async for event in app.astream(input, stream_mode="messages"):
    handle(event)
```

3. **Declarative graph definition:**
```python
# Plain Python - imperative spaghetti
def run_workflow(state):
    if state["type"] == "A":
        state = process_a(state)
        if state["needs_review"]:
            state = review(state)
    else:
        state = process_b(state)
    # ... more nested conditionals

# LangGraph - declarative and visual
graph.add_conditional_edges("classifier", route_by_type)
graph.add_edge("process_a", "review")  # Clear structure
```

4. **Built-in parallelism:**
```python
# Plain Python
import asyncio
results = await asyncio.gather(*[process(item) for item in items])

# LangGraph - Send handles it
return [Send("process", {"item": item}) for item in items]
```

5. **Human-in-the-loop patterns:**
```python
# Plain Python - complex interrupt/resume logic
# LangGraph - first-class support
app = graph.compile(interrupt_before=["approval_node"])
```

**When plain Python is fine:**
- One-off scripts
- Simple linear processing
- No persistence needed
- No streaming required

---

### Q5. What's the overhead of using LangGraph vs plain Python? [MEDIUM]

**Answer:**

**Performance overhead:**
- Minimal computational overhead (microseconds per node transition)
- Main overhead is in serialization/deserialization of state
- Checkpointing adds I/O overhead (database writes)

**Memory overhead:**
- State is copied between nodes (can configure reducers to minimize)
- Checkpoint history can grow large (configure retention policies)

**Complexity overhead:**
- Learning curve for graph concepts
- More files/structure for simple tasks
- Overkill for simple scripts

**When overhead matters:**
```python
# High-frequency, low-latency requirements
# Consider: Is 1-5ms overhead acceptable?

# Large state objects
# Consider: Only include necessary fields in state

# Many checkpoints
# Consider: Use selective checkpointing, prune old checkpoints
```

**Mitigation strategies:**
```python
# 1. Lean state design
class State(TypedDict):
    essential_field: str  # Only what's needed
    # NOT: huge_document: str  # Store ID, not content

# 2. Checkpoint selectively
app = graph.compile(
    checkpointer=checkpointer,
    # Only checkpoint at important nodes
)

# 3. Use async for I/O-bound operations
async def efficient_node(state):
    result = await async_api_call()
    return {"result": result}
```

---

## Section 3: LangGraph vs Other Agent Frameworks

### Q6. How does LangGraph compare to AutoGPT/BabyAGI? [MEDIUM]

**Answer:**

| Aspect | LangGraph | AutoGPT/BabyAGI |
|--------|-----------|-----------------|
| Control | Explicit, developer-defined | Autonomous, LLM-driven |
| Predictability | High | Low |
| Customization | Full | Limited |
| Production-ready | Yes | Experimental |
| Debugging | Excellent (step-through) | Difficult |
| Cost control | Fine-grained | Hard to limit |

**LangGraph philosophy:**
- Developer defines the workflow structure
- LLM makes decisions within defined boundaries
- Explicit state and transitions
- "Guardrails by design"

**AutoGPT philosophy:**
- LLM autonomously decides next steps
- Minimal structure
- "Let the LLM figure it out"

**When to choose each:**

```
LangGraph:
- Production applications
- Predictable behavior required
- Cost sensitivity
- Compliance/audit requirements
- Complex but defined workflows

AutoGPT-style:
- Research/exploration
- Open-ended creative tasks
- When you truly don't know the workflow
- Prototyping novel approaches
```

**Hybrid approach in LangGraph:**
```python
# Give LLM freedom within structure
def autonomous_node(state):
    # LLM can choose from defined actions
    decision = llm.invoke(
        "Given this state, choose action: research, write, or review"
    )
    return {"next_action": decision}

# But routing is still explicit
graph.add_conditional_edges(
    "autonomous",
    lambda s: s["next_action"],
    {"research": "research_node", "write": "write_node", "review": "review_node"}
)
```

---

### Q7. How does LangGraph compare to LlamaIndex workflows? [HARD]

**Answer:**

**Similarities:**
- Both support stateful workflows
- Both enable multi-step agent patterns
- Both integrate with LangChain ecosystem

**Differences:**

| Aspect | LangGraph | LlamaIndex Workflows |
|--------|-----------|---------------------|
| Primary focus | Orchestration | RAG and data |
| State management | TypedDict + reducers | Events and context |
| Graph model | Explicit StateGraph | Event-driven |
| Persistence | Checkpointers | Index persistence |
| Streaming | Multiple modes | Event streaming |

**LlamaIndex Workflows architecture:**
```python
from llama_index.core.workflow import Workflow, step, Event

class MyWorkflow(Workflow):
    @step
    async def process(self, ev: StartEvent) -> ProcessedEvent:
        # Event-driven pattern
        return ProcessedEvent(data=processed)
```

**LangGraph architecture:**
```python
from langgraph.graph import StateGraph

graph = StateGraph(MyState)
graph.add_node("process", process_fn)
# Explicit graph structure
```

**When to choose:**
- **LangGraph**: Complex agent orchestration, human-in-the-loop, multi-agent
- **LlamaIndex**: RAG-heavy applications, document processing pipelines

**They can work together:**
```python
# LlamaIndex for retrieval, LangGraph for orchestration
def retrieval_node(state):
    # Use LlamaIndex query engine
    results = index.as_query_engine().query(state["question"])
    return {"context": results}

# Orchestrate with LangGraph
graph.add_node("retrieve", retrieval_node)
graph.add_node("generate", generate_node)
```

---

### Q8. How does LangGraph compare to CrewAI? [MEDIUM]

**Answer:**

| Aspect | LangGraph | CrewAI |
|--------|-----------|--------|
| Abstraction level | Low-level, flexible | High-level, opinionated |
| Multi-agent | Build your own patterns | Built-in crew/agent/task |
| Customization | Maximum | Limited by framework |
| Learning curve | Steeper | Gentler |
| Production control | Full | Less control |

**CrewAI example:**
```python
from crewai import Crew, Agent, Task

researcher = Agent(role="Researcher", goal="Find information")
writer = Agent(role="Writer", goal="Write content")

crew = Crew(
    agents=[researcher, writer],
    tasks=[research_task, write_task],
    process=Process.sequential
)
```

**Equivalent in LangGraph:**
```python
def researcher_node(state):
    # Full control over researcher logic
    pass

def writer_node(state):
    # Full control over writer logic
    pass

graph.add_node("researcher", researcher_node)
graph.add_node("writer", writer_node)
graph.add_edge("researcher", "writer")
```

**Choose CrewAI when:**
- Rapid prototyping of multi-agent systems
- Standard agent patterns suffice
- Less experienced team

**Choose LangGraph when:**
- Custom agent behaviors needed
- Production requirements (persistence, streaming)
- Complex state management
- Need to understand every detail

---

### Q9. How does LangGraph compare to Microsoft AutoGen? [HARD]

**Answer:**

| Aspect | LangGraph | AutoGen |
|--------|-----------|---------|
| Conversation model | State + messages | Agent conversations |
| Graph definition | Explicit | Implicit through agents |
| Human participation | interrupt_before/after | UserProxyAgent |
| Code execution | Via tools | Built-in executor |
| Streaming | Native | Limited |

**AutoGen's model:**
```python
# Agents talk to each other
assistant = AssistantAgent("assistant")
user_proxy = UserProxyAgent("user")
user_proxy.initiate_chat(assistant, message="Hello")
```

**LangGraph's model:**
```python
# Explicit graph of operations
def agent_node(state):
    return {"messages": [assistant_response]}

def human_node(state):
    human_input = interrupt("Your input?")
    return {"messages": [HumanMessage(human_input)]}
```

**Key insight:**
- AutoGen: Agents are first-class, conversations are implicit
- LangGraph: State/graph is first-class, agents are nodes

**AutoGen strengths:**
- Multi-agent conversations feel natural
- Good for group chat simulations
- Built-in code execution environment

**LangGraph strengths:**
- More control over execution flow
- Better persistence and streaming
- Production-ready infrastructure

---

## Section 4: Architecture Decisions

### Q10. How do you decide between using tools vs subgraphs? [MEDIUM]

**Answer:**

**Tools:**
- Single function call
- Stateless operation
- External API calls
- Simple input/output

**Subgraphs:**
- Multi-step processes
- Internal state management
- Complex logic encapsulation
- Reusable workflows

```
Tools: "Call calculator(2+2)" -> 4

Subgraphs: "Research this topic"
           -> search -> filter -> summarize -> validate -> result
```

**Decision framework:**

```
Is it a single operation?
    Yes -> Tool
    No  -> Continue

Does it need internal state?
    Yes -> Subgraph
    No  -> Continue

Is it reused across graphs?
    Yes -> Subgraph
    No  -> Continue

Is it complex enough to test independently?
    Yes -> Subgraph
    No  -> Tool
```

**Example - Research capability:**

As a tool (simple):
```python
@tool
def search_web(query: str) -> str:
    """Search the web for information."""
    return search_api.search(query)
```

As a subgraph (complex):
```python
research_graph = StateGraph(ResearchState)
research_graph.add_node("search", search_node)
research_graph.add_node("filter", filter_results_node)
research_graph.add_node("summarize", summarize_node)
# ... more nodes

# Use in parent
parent_graph.add_node("research", research_graph.compile())
```

---

### Q11. When should you use multiple graphs vs one large graph? [MEDIUM]

**Answer:**

**Single graph advantages:**
- Simpler state management
- Easier debugging
- No inter-graph communication overhead
- All nodes have access to full state

**Multiple graphs advantages:**
- Separation of concerns
- Independent deployment
- Different teams can own different graphs
- Cleaner testing

**Decision criteria:**

```
                        Single Graph        Multiple Graphs
Nodes < 10             Recommended         Overkill
Nodes 10-30            Consider splitting  Good choice
Nodes > 30             Hard to maintain    Recommended

State coupling          High -> Single      Low -> Multiple
Team size              Small -> Single     Large -> Multiple
Deployment unit        Same -> Single      Different -> Multiple
```

**Splitting strategies:**

1. **By capability:**
```
Main Graph
  |-> Research Subgraph
  |-> Writing Subgraph
  |-> Review Subgraph
```

2. **By conversation phase:**
```
Intake Graph -> Processing Graph -> Delivery Graph
```

3. **By user type:**
```
Customer Graph (simpler)
Admin Graph (more features)
```

**Communication between graphs:**
```python
# Option 1: Subgraphs (tight coupling)
main_graph.add_node("research", research_graph.compile())

# Option 2: API calls (loose coupling)
def call_research_service(state):
    result = requests.post("http://research-service/run", json=state)
    return {"research_result": result.json()}
```

---

### Q12. Monolithic agent vs specialized agents - when to choose which? [HARD]

**Answer:**

**Monolithic Agent:**
Single LLM with many tools, handles everything.

```
+------------------+
|  SUPER AGENT     |
|  - 20+ tools     |
|  - One prompt    |
|  - All contexts  |
+------------------+
```

**Specialized Agents:**
Multiple focused agents, each with specific capabilities.

```
+----------+  +----------+  +----------+
| RESEARCH |  |  WRITER  |  |  CODER   |
| 3 tools  |  | 2 tools  |  | 4 tools  |
+----------+  +----------+  +----------+
      \            |            /
       \           |           /
        +----------+----------+
        |     SUPERVISOR      |
        +---------------------+
```

**Comparison:**

| Aspect | Monolithic | Specialized |
|--------|------------|-------------|
| Context window | Gets crowded | Focused |
| Tool confusion | Higher risk | Lower risk |
| Latency | Single LLM call | Multiple calls |
| Cost | Lower (one call) | Higher (many calls) |
| Debugging | Harder | Easier |
| Flexibility | Less | More |

**Choose monolithic when:**
- Few tools (< 5-7)
- Tools are cohesive
- Speed is critical
- Simple use cases

**Choose specialized when:**
- Many tools (> 7)
- Tools span different domains
- Need expert-level performance
- Complex workflows

**Hybrid approach:**
```python
# Tier 1: Simple queries -> Monolithic
# Tier 2: Complex queries -> Specialized team

def router(state):
    complexity = assess_complexity(state["query"])
    if complexity < 0.5:
        return "simple_agent"
    return "supervisor"

graph.add_conditional_edges(START, router)
```

---

## Section 5: Migration Questions

### Q13. How would you migrate from a plain LangChain app to LangGraph? [MEDIUM]

**Answer:**

**Step-by-step migration:**

**1. Identify the workflow:**
```python
# Existing LangChain
chain = prompt | llm | parser

# Identify: Is it truly linear, or do you have loops?
```

**2. Define state:**
```python
# What data flows through your app?
class State(TypedDict):
    messages: Annotated[list, add]
    context: str
    # ... map your existing variables
```

**3. Convert functions to nodes:**
```python
# Before (standalone function)
def process(text):
    return llm.invoke(text)

# After (node function)
def process_node(state):
    result = llm.invoke(state["text"])
    return {"result": result}
```

**4. Build graph:**
```python
graph = StateGraph(State)

# Add each processing step as a node
graph.add_node("step1", step1_node)
graph.add_node("step2", step2_node)

# Connect them
graph.add_edge(START, "step1")
graph.add_edge("step1", "step2")
graph.add_edge("step2", END)
```

**5. Add LangGraph features incrementally:**
```python
# Start simple
app = graph.compile()

# Add checkpointing
app = graph.compile(checkpointer=MemorySaver())

# Add human-in-the-loop
app = graph.compile(
    checkpointer=MemorySaver(),
    interrupt_before=["critical_step"]
)
```

**Migration checklist:**
```
[ ] Map existing state to TypedDict
[ ] Convert functions to node functions
[ ] Identify conditional logic -> conditional edges
[ ] Identify loops -> cycles in graph
[ ] Add persistence if needed
[ ] Add streaming if needed
[ ] Update tests
```

---

### Q14. How would you evaluate if LangGraph is the right choice for a project? [HARD]

**Answer:**

**Evaluation framework:**

**1. Requirements Analysis:**
```
Requirement                    Points toward LangGraph
----------------------------------------------------------
Agent loops needed            +3
Human approval workflows      +3
Conversation persistence      +2
Complex conditional logic     +2
Multiple specialized agents   +2
Streaming responses           +1
Production deployment         +1
Simple linear flow            -2
One-off script               -3
```

**2. Team Assessment:**
- Python proficiency: Required
- Graph concepts understanding: Helpful
- LangChain familiarity: Helpful

**3. Infrastructure Needs:**
```
Development: MemorySaver (no setup)
Staging: SQLite (minimal setup)
Production: PostgreSQL (requires infrastructure)
```

**4. Alternatives Considered:**
```
If your answer is "just LCEL" for most:
  - Simple chains -> LCEL
  - One agent, few tools -> create_react_agent
  - Complex orchestration -> Custom LangGraph
  - RAG-heavy -> Consider LlamaIndex
```

**5. Proof of Concept:**
```python
# Build minimal POC in 1-2 days
# Test these scenarios:
# 1. Happy path
# 2. Error handling
# 3. Persistence/resume
# 4. Streaming to UI

# If POC feels natural, proceed with LangGraph
```

**Red flags (maybe don't use LangGraph):**
- Team has no Python experience
- Extremely simple use case
- Real-time latency requirements (< 100ms)
- No state management needed

**Green flags (definitely use LangGraph):**
- Building production AI agents
- Need human-in-the-loop
- Complex multi-step workflows
- Want to leverage LangChain ecosystem

---

### Q15. How would you integrate LangGraph with an existing microservices architecture? [HARD]

**Answer:**

**Integration patterns:**

**1. LangGraph as a Service:**
```
+-------------+     +------------------+     +-------------+
|   Client    |---->| LangGraph        |---->| Downstream  |
|   Service   |     | Orchestration    |     | Services    |
|             |<----| Service          |<----|             |
+-------------+     +------------------+     +-------------+
```

```python
# FastAPI wrapper
from fastapi import FastAPI
from langgraph.graph import StateGraph

app = FastAPI()
graph = create_agent_graph()

@app.post("/agent/invoke")
async def invoke_agent(request: AgentRequest):
    config = {"configurable": {"thread_id": request.thread_id}}
    result = await graph.ainvoke(request.input, config)
    return result
```

**2. Nodes call microservices:**
```python
async def order_service_node(state):
    async with httpx.AsyncClient() as client:
        response = await client.post(
            "http://order-service/api/orders",
            json={"items": state["cart"]}
        )
    return {"order_id": response.json()["id"]}
```

**3. Event-driven integration:**
```python
from kafka import KafkaProducer, KafkaConsumer

def publish_event_node(state):
    producer.send("agent-events", {
        "type": "task_completed",
        "data": state["result"]
    })
    return state

# Other services consume events
```

**4. Service mesh considerations:**
```yaml
# LangGraph service in Kubernetes
apiVersion: apps/v1
kind: Deployment
metadata:
  name: langgraph-agent
spec:
  replicas: 3
  template:
    spec:
      containers:
      - name: agent
        image: my-langgraph-app
        env:
        - name: POSTGRES_URL
          valueFrom:
            secretKeyRef:
              name: db-credentials
              key: url
```

**Best practices:**
- Use async throughout for better performance
- Implement circuit breakers for external calls
- Use distributed tracing (OpenTelemetry)
- Configure timeouts appropriately
- Handle partial failures gracefully

```python
# Circuit breaker example
from circuitbreaker import circuit

@circuit(failure_threshold=5, recovery_timeout=30)
async def call_external_service(data):
    return await client.post(url, json=data)

async def resilient_node(state):
    try:
        result = await call_external_service(state["data"])
        return {"result": result, "status": "success"}
    except CircuitBreakerError:
        return {"result": None, "status": "service_unavailable"}
```
