# LangGraph Conceptual Interview Questions

## Section 1: Fundamentals

### Q1. What is LangGraph and why was it created? [EASY]

**Answer:**
LangGraph is a library built on top of LangChain for building stateful, multi-actor
applications with LLMs, structured as graphs. It was created to address limitations
of simple chains (LCEL) when building complex, cyclic, and stateful AI workflows.

**Key motivations:**
1. **Cyclical flows**: Unlike DAGs (Directed Acyclic Graphs), LangGraph supports cycles,
   enabling iterative agent behaviors (think-act-observe loops)
2. **Fine-grained control**: Provides explicit state management and step-by-step execution
3. **Persistence**: Built-in checkpointing for long-running conversations
4. **Human-in-the-loop**: First-class support for human intervention points

**What interviewers look for:**
- Understanding that LangGraph solves the "agent loop" problem
- Awareness of LangChain ecosystem relationship
- Knowledge of when LangGraph is preferable to simple chains

---

### Q2. Explain the core components of a LangGraph application. [EASY]

**Answer:**
A LangGraph application consists of four core components:

```
+------------------+     +------------------+     +------------------+
|      STATE       |     |      NODES       |     |      EDGES       |
| (TypedDict or    |---->| (Functions that  |---->| (Connections     |
|  Pydantic model) |     |  transform state)|     |  between nodes)  |
+------------------+     +------------------+     +------------------+
                                   |
                                   v
                         +------------------+
                         |      GRAPH       |
                         | (StateGraph that |
                         |  orchestrates)   |
                         +------------------+
```

1. **State**: A schema (TypedDict or Pydantic) defining data that flows through the graph
2. **Nodes**: Functions that receive state, perform operations, and return state updates
3. **Edges**: Connections that define flow between nodes (normal or conditional)
4. **Graph**: The StateGraph object that compiles nodes and edges into an executable

**Example structure:**
```python
from langgraph.graph import StateGraph, START, END
from typing import TypedDict

class MyState(TypedDict):
    messages: list
    context: str

def node_a(state: MyState) -> dict:
    return {"context": "updated"}

graph = StateGraph(MyState)
graph.add_node("a", node_a)
graph.add_edge(START, "a")
graph.add_edge("a", END)
app = graph.compile()
```

---

### Q3. What is the difference between `add_edge` and `add_conditional_edges`? [EASY]

**Answer:**

| Aspect | `add_edge` | `add_conditional_edges` |
|--------|-----------|------------------------|
| Flow type | Static, unconditional | Dynamic, based on state |
| Use case | Linear progression | Branching logic |
| Arguments | source, destination | source, function, mapping |

**`add_edge`**: Creates a fixed connection between two nodes.
```python
graph.add_edge("node_a", "node_b")  # Always goes from A to B
```

**`add_conditional_edges`**: Routes to different nodes based on a routing function.
```python
def router(state):
    if state["needs_tool"]:
        return "tool_node"
    return "response_node"

graph.add_conditional_edges(
    "agent",
    router,
    {
        "tool_node": "tool_node",
        "response_node": "response_node"
    }
)
```

**What interviewers look for:**
- Understanding of when to use each
- Ability to write routing functions
- Knowledge that conditional edges enable cycles

---

### Q4. Explain the State in LangGraph. How does state reduction work? [MEDIUM]

**Answer:**

**State** is the central data structure that:
1. Flows through all nodes in the graph
2. Gets updated by each node's return value
3. Can have custom reducers for combining updates

**State Reduction** handles how multiple updates to the same field are combined:

```python
from typing import Annotated
from operator import add

class State(TypedDict):
    # Default: Replace semantics (last write wins)
    current_step: str
    
    # With reducer: Append semantics
    messages: Annotated[list, add]  # New messages are appended
    
    # Custom reducer example
    count: Annotated[int, lambda old, new: old + new]
```

**Built-in reducer behaviors:**
- **Replace (default)**: New value replaces old value
- **Add (`operator.add`)**: Lists are concatenated, numbers are summed
- **Custom function**: Any `(old, new) -> combined` function

**Why reducers matter:**
- Enable parallel node execution without conflicts
- Allow accumulative patterns (message history)
- Support complex state merging logic

**Common reducer patterns:**
```python
# Message accumulation
messages: Annotated[list[BaseMessage], add]

# Counter increment
attempt_count: Annotated[int, lambda x, y: x + y]

# Keep latest non-None
result: Annotated[Optional[str], lambda old, new: new if new else old]
```

---

### Q5. What is checkpointing and why is it important? [MEDIUM]

**Answer:**

**Checkpointing** is LangGraph's persistence mechanism that saves graph state at
each step, enabling:

1. **Resume after failure**: Pick up where you left off
2. **Time travel**: Go back to previous states
3. **Human-in-the-loop**: Pause, review, modify, and continue
4. **Long-running workflows**: Span multiple sessions

**Implementation:**
```python
from langgraph.checkpoint.memory import MemorySaver

# Create checkpointer
checkpointer = MemorySaver()

# Compile with checkpointing
app = graph.compile(checkpointer=checkpointer)

# Invoke with thread_id for persistence
config = {"configurable": {"thread_id": "user-123"}}
result = app.invoke({"messages": [...]}, config=config)

# Later: Resume same conversation
result = app.invoke({"messages": [new_message]}, config=config)
```

**Checkpointer options:**
- `MemorySaver`: In-memory (development)
- `SqliteSaver`: SQLite database
- `PostgresSaver`: PostgreSQL for production
- Custom implementations possible

**What interviewers look for:**
- Understanding of thread_id concept
- Production vs development checkpointers
- Use cases for checkpointing (not just persistence)

---

### Q6. Explain the concept of "Human-in-the-Loop" in LangGraph. [MEDIUM]

**Answer:**

Human-in-the-Loop (HITL) allows human intervention at specific points in the graph:

**Three main patterns:**

1. **Interrupt Before**: Pause before a node executes
```python
app = graph.compile(
    checkpointer=checkpointer,
    interrupt_before=["sensitive_action"]  # Pause before this node
)
```

2. **Interrupt After**: Pause after a node executes (review output)
```python
app = graph.compile(
    checkpointer=checkpointer,
    interrupt_after=["draft_response"]  # Pause to review draft
)
```

3. **Dynamic Interrupt**: Raise interrupt based on conditions
```python
from langgraph.types import interrupt

def risky_node(state):
    if state["risk_level"] > 0.8:
        human_input = interrupt("High risk detected. Approve?")
        # Execution pauses here, resumes when human provides input
    return {"approved": human_input == "yes"}
```

**Resuming after interrupt:**
```python
# First run - will pause at interrupt
result = app.invoke(input_data, config)

# Check state and provide human input
state = app.get_state(config)
if state.next:  # There's a pending node
    # Update state with human decision
    app.update_state(config, {"human_approved": True})
    # Resume execution
    result = app.invoke(None, config)
```

**Use cases:**
- Approval workflows
- Content moderation
- Correcting agent mistakes
- Compliance requirements

---

### Q7. What are subgraphs and when would you use them? [MEDIUM]

**Answer:**

**Subgraphs** are nested graphs within a parent graph, enabling:
- Modular, reusable components
- Encapsulated state
- Cleaner architecture for complex systems

```
+------------------------------------------+
|              PARENT GRAPH                |
|                                          |
|   +-------------+    +--------------+    |
|   |  Subgraph A |    |  Subgraph B  |    |
|   | +---------+ |    | +----------+ |    |
|   | | Node 1  | |    | | Node X   | |    |
|   | +---------+ |    | +----------+ |    |
|   | | Node 2  | |    | | Node Y   | |    |
|   | +---------+ |    | +----------+ |    |
|   +-------------+    +--------------+    |
|                                          |
+------------------------------------------+
```

**Implementation:**
```python
# Define subgraph
subgraph = StateGraph(SubState)
subgraph.add_node("sub_node_1", sub_func_1)
subgraph.add_node("sub_node_2", sub_func_2)
subgraph.add_edge(START, "sub_node_1")
subgraph.add_edge("sub_node_1", "sub_node_2")
subgraph.add_edge("sub_node_2", END)

# Add compiled subgraph to parent
parent_graph = StateGraph(ParentState)
parent_graph.add_node("subgraph_node", subgraph.compile())
parent_graph.add_edge(START, "subgraph_node")
parent_graph.add_edge("subgraph_node", END)
```

**When to use:**
- Complex multi-step processes (document processing pipelines)
- Reusable agent patterns (research agent, writer agent)
- Team architectures (supervisor managing specialist subgraphs)
- Testing components in isolation

---

### Q8. Explain streaming in LangGraph. What are the different streaming modes? [MEDIUM]

**Answer:**

LangGraph supports multiple streaming modes for real-time output:

**Streaming Modes:**

1. **`values`**: Stream complete state after each node
```python
for state in app.stream(input_data, stream_mode="values"):
    print(state)  # Full state object
```

2. **`updates`**: Stream only the state changes from each node
```python
for update in app.stream(input_data, stream_mode="updates"):
    print(update)  # {"node_name": {changed_fields}}
```

3. **`messages`**: Stream LLM tokens as they're generated
```python
async for event in app.astream(input_data, stream_mode="messages"):
    if event[0].content:
        print(event[0].content, end="")  # Token by token
```

4. **`events`**: Detailed events including node starts/ends
```python
async for event in app.astream_events(input_data, version="v2"):
    print(event["event"], event.get("data"))
```

**Combining modes:**
```python
for chunk in app.stream(input_data, stream_mode=["values", "updates"]):
    # Receive both complete states and updates
    pass
```

**Production considerations:**
- Use async streaming (`astream`) for better performance
- `messages` mode requires nodes to yield LLM outputs properly
- Streaming works with checkpointing for resumable streams

---

### Q9. What is the difference between `invoke`, `stream`, and `batch`? [EASY]

**Answer:**

| Method | Return Type | Use Case | Blocking |
|--------|-------------|----------|----------|
| `invoke` | Final state | Single request, wait for result | Yes |
| `stream` | Iterator of states | Real-time UI updates | Yields incrementally |
| `batch` | List of final states | Process multiple inputs | Yes |

**Examples:**

```python
# invoke - Single execution, returns final state
result = app.invoke({"messages": [user_msg]})

# stream - Iterate through execution
for state in app.stream({"messages": [user_msg]}):
    print(f"Current step: {state}")

# batch - Process multiple inputs
results = app.batch([
    {"messages": [msg1]},
    {"messages": [msg2]},
    {"messages": [msg3]}
])
```

**Async variants:**
```python
result = await app.ainvoke(input_data)
async for state in app.astream(input_data):
    pass
results = await app.abatch([input1, input2])
```

---

### Q10. How do you handle errors in LangGraph? [MEDIUM]

**Answer:**

**Error handling strategies:**

1. **Node-level try/except:**
```python
def my_node(state):
    try:
        result = risky_operation()
        return {"result": result, "error": None}
    except Exception as e:
        return {"result": None, "error": str(e)}
```

2. **Conditional routing on errors:**
```python
def error_router(state):
    if state.get("error"):
        return "error_handler"
    return "next_step"

graph.add_conditional_edges("risky_node", error_router)
```

3. **Retry patterns:**
```python
def retry_node(state):
    max_retries = 3
    for attempt in range(max_retries):
        try:
            return {"result": do_operation()}
        except TransientError:
            if attempt == max_retries - 1:
                raise
            time.sleep(2 ** attempt)  # Exponential backoff
```

4. **Global error handling with checkpoints:**
```python
try:
    result = app.invoke(input_data, config)
except Exception:
    # Get last successful state
    last_state = app.get_state(config)
    # Modify and retry from checkpoint
    app.update_state(config, {"retry": True})
    result = app.invoke(None, config)
```

5. **Error state accumulation:**
```python
class State(TypedDict):
    errors: Annotated[list[str], add]  # Accumulate all errors

def node_with_error_tracking(state):
    try:
        return {"result": compute()}
    except Exception as e:
        return {"errors": [f"Node failed: {e}"]}
```

---

## Section 2: Advanced Concepts

### Q11. Explain the ReAct pattern and how to implement it in LangGraph. [HARD]

**Answer:**

**ReAct (Reasoning + Acting)** is an agent pattern where the LLM:
1. **Thinks** about what to do
2. **Acts** by calling tools
3. **Observes** tool results
4. **Repeats** until task is complete

```
+-------+     +--------+     +---------+     +-------+
| START |---->| AGENT  |---->| TOOLS   |---->| AGENT |----> ...
+-------+     | (Think)|     | (Act)   |     |(Observe)
              +--------+     +---------+     +-------+
                   ^                              |
                   |______________________________|
                            (Loop until done)
```

**Implementation:**
```python
from langgraph.graph import StateGraph, START, END
from langgraph.prebuilt import ToolNode
from langchain_core.messages import HumanMessage, AIMessage

class AgentState(TypedDict):
    messages: Annotated[list, add]

def agent_node(state):
    """The thinking node - decides what to do."""
    response = llm_with_tools.invoke(state["messages"])
    return {"messages": [response]}

def should_continue(state):
    """Router - check if agent wants to use tools."""
    last_message = state["messages"][-1]
    if last_message.tool_calls:
        return "tools"
    return END

# Build graph
graph = StateGraph(AgentState)
graph.add_node("agent", agent_node)
graph.add_node("tools", ToolNode(tools))

graph.add_edge(START, "agent")
graph.add_conditional_edges("agent", should_continue, {"tools": "tools", END: END})
graph.add_edge("tools", "agent")  # Loop back after tool execution

app = graph.compile()
```

**Key insight:** The cycle (`agent -> tools -> agent`) is what makes LangGraph
essential - LCEL can't easily express this loop.

---

### Q12. What are the different multi-agent architectures in LangGraph? [HARD]

**Answer:**

**1. Supervisor Architecture:**
A central supervisor routes tasks to specialized agents.

```
                    +------------+
                    | SUPERVISOR |
                    +-----+------+
                          |
          +---------------+---------------+
          |               |               |
    +-----v-----+   +-----v-----+   +-----v-----+
    | RESEARCH  |   |  WRITER   |   |  CRITIC   |
    |   AGENT   |   |   AGENT   |   |   AGENT   |
    +-----------+   +-----------+   +-----------+
```

```python
def supervisor(state):
    decision = llm.invoke("Which agent should handle: " + state["task"])
    return {"next_agent": decision}

graph.add_conditional_edges("supervisor", lambda s: s["next_agent"])
```

**2. Hierarchical Architecture:**
Multi-level supervision with team leads.

```
                +----------------+
                | TOP SUPERVISOR |
                +-------+--------+
                        |
        +---------------+---------------+
        |                               |
+-------v-------+               +-------v-------+
| TEAM A LEAD   |               | TEAM B LEAD   |
+-------+-------+               +-------+-------+
        |                               |
    +---+---+                       +---+---+
    |       |                       |       |
 Agent1  Agent2                  Agent3  Agent4
```

**3. Collaborative (Peer) Architecture:**
Agents communicate directly without central control.

```
+----------+     +----------+
| AGENT A  |<--->| AGENT B  |
+----+-----+     +-----+----+
     |                 |
     +--------+--------+
              |
        +-----v-----+
        |  AGENT C  |
        +-----------+
```

**4. Pipeline Architecture:**
Sequential processing with handoffs.

```
+-------+     +--------+     +--------+     +------+
| AGENT |---->| AGENT  |---->| AGENT  |---->| END  |
|   A   |     |   B    |     |   C    |     |      |
+-------+     +--------+     +--------+     +------+
```

**Choosing the right architecture:**
- **Supervisor**: When you need central control and routing
- **Hierarchical**: Large teams with different specializations
- **Collaborative**: Peer review, brainstorming, debates
- **Pipeline**: Linear workflows with distinct phases

---

### Q13. How do you implement memory in LangGraph beyond conversation history? [HARD]

**Answer:**

LangGraph supports multiple memory types:

**1. Short-term Memory (Conversation History):**
```python
class State(TypedDict):
    messages: Annotated[list[BaseMessage], add]
```

**2. Long-term Memory (Cross-session):**
```python
from langgraph.store.memory import InMemoryStore

store = InMemoryStore()

# Store memories
store.put(("user", "123"), "preferences", {"theme": "dark"})

# Access in nodes
def personalized_node(state, config, store):
    user_id = config["configurable"]["user_id"]
    prefs = store.get(("user", user_id), "preferences")
    return {"response": f"Using your {prefs['theme']} theme"}

# Compile with store
app = graph.compile(checkpointer=checkpointer, store=store)
```

**3. Semantic Memory (Vector Store):**
```python
from langchain_community.vectorstores import FAISS

def memory_retrieval_node(state):
    # Retrieve relevant past interactions
    relevant_memories = vector_store.similarity_search(
        state["current_query"],
        k=3
    )
    return {"context": relevant_memories}

def memory_storage_node(state):
    # Store new interactions
    vector_store.add_texts([state["interaction_summary"]])
    return {}
```

**4. Structured Memory (Entity Tracking):**
```python
class MemoryState(TypedDict):
    messages: list
    entities: dict  # {"John": "CEO of Acme Corp", ...}
    facts: list     # ["User prefers Python", ...]

def entity_extractor(state):
    new_entities = extract_entities(state["messages"][-1])
    return {"entities": {**state["entities"], **new_entities}}
```

**Memory architecture pattern:**
```
+-----------+
| RAW INPUT |
+-----+-----+
      |
+-----v--------+     +----------------+
| WORKING      |<--->| LONG-TERM      |
| MEMORY       |     | MEMORY (Store) |
| (State)      |     +----------------+
+-----+--------+
      |
+-----v--------+     +----------------+
| SEMANTIC     |<--->| VECTOR STORE   |
| RETRIEVAL    |     +----------------+
+--------------+
```

---

### Q14. Explain the concept of "send" and parallel execution in LangGraph. [HARD]

**Answer:**

The `Send` API enables dynamic, parallel fan-out patterns:

```python
from langgraph.constants import Send

def router_node(state):
    """Dynamically spawn parallel executions."""
    items = state["items_to_process"]
    
    # Create a Send for each item - all run in parallel
    return [
        Send("process_item", {"item": item, "index": i})
        for i, item in enumerate(items)
    ]

def process_item(state):
    """Each Send spawns an instance of this node."""
    item = state["item"]
    return {"processed": transform(item)}
```

**Use cases:**
1. **Map-Reduce patterns:**
```
            +-> process(item1) -+
            |                   |
START -> split -> process(item2) -> reduce -> END
            |                   |
            +-> process(item3) -+
```

2. **Parallel tool execution:**
```python
def agent_with_parallel_tools(state):
    tool_calls = state["messages"][-1].tool_calls
    return [
        Send("tool_executor", {"tool_call": tc})
        for tc in tool_calls
    ]
```

3. **Multi-agent brainstorming:**
```python
def spawn_experts(state):
    experts = ["technical", "business", "legal"]
    return [
        Send("expert_agent", {"role": expert, "question": state["question"]})
        for expert in experts
    ]
```

**Collecting parallel results:**
```python
class State(TypedDict):
    results: Annotated[list, add]  # Reducer collects all parallel outputs

def collect_results(state):
    # All parallel results are now in state["results"]
    return {"final_answer": synthesize(state["results"])}
```

---

### Q15. How do you test LangGraph applications? [MEDIUM]

**Answer:**

**Testing strategies:**

1. **Unit testing nodes:**
```python
def test_classifier_node():
    state = {"input": "What's the weather?", "category": None}
    result = classifier_node(state)
    assert result["category"] == "weather"
```

2. **Integration testing graphs:**
```python
def test_full_graph():
    app = graph.compile()
    result = app.invoke({
        "messages": [HumanMessage("Hello")]
    })
    assert "messages" in result
    assert len(result["messages"]) > 1
```

3. **Testing with mocked LLMs:**
```python
from langchain_core.language_models import FakeListLLM

def test_with_mock_llm():
    fake_llm = FakeListLLM(responses=["I'll help you", "Done!"])
    # Inject mock LLM into your graph
    app = create_graph(llm=fake_llm).compile()
    result = app.invoke(test_input)
    assert "Done!" in result["messages"][-1].content
```

4. **Testing state transitions:**
```python
def test_routing():
    app = graph.compile()
    
    # Test path A
    result = app.invoke({"type": "question"})
    assert was_node_visited(result, "answer_node")
    
    # Test path B
    result = app.invoke({"type": "command"})
    assert was_node_visited(result, "execute_node")
```

5. **Testing checkpointing:**
```python
def test_resume_from_checkpoint():
    checkpointer = MemorySaver()
    app = graph.compile(checkpointer=checkpointer)
    config = {"configurable": {"thread_id": "test-1"}}
    
    # First invocation
    app.invoke({"step": 1}, config)
    
    # Simulate restart - should resume
    result = app.invoke({"step": 2}, config)
    assert result["total_steps"] == 2
```

6. **Snapshot testing:**
```python
def test_state_snapshots():
    states = list(app.stream(input_data))
    
    # Verify expected state progression
    assert states[0]["phase"] == "init"
    assert states[1]["phase"] == "processing"
    assert states[-1]["phase"] == "complete"
```

---

### Q16. What is the prebuilt `create_react_agent` and when should you use it vs custom? [MEDIUM]

**Answer:**

`create_react_agent` is a prebuilt function that creates a standard ReAct agent:

```python
from langgraph.prebuilt import create_react_agent

# Quick setup
agent = create_react_agent(
    model=llm,
    tools=[search_tool, calculator_tool],
    checkpointer=MemorySaver()
)

result = agent.invoke({"messages": [HumanMessage("What's 2+2?")]})
```

**When to use `create_react_agent`:**
- Rapid prototyping
- Standard tool-calling agents
- When you don't need custom state
- Learning LangGraph basics

**When to build custom:**
| Use Case | Prebuilt | Custom |
|----------|----------|--------|
| Simple tool use | Yes | No |
| Custom state fields | No | Yes |
| Multiple agent types | No | Yes |
| Complex routing logic | No | Yes |
| Human-in-the-loop | Limited | Full control |
| Parallel execution | No | Yes |
| Subgraphs | No | Yes |

**Custom equivalent:**
```python
# What create_react_agent does internally
graph = StateGraph(AgentState)
graph.add_node("agent", call_model)
graph.add_node("tools", ToolNode(tools))
graph.add_edge(START, "agent")
graph.add_conditional_edges("agent", should_continue)
graph.add_edge("tools", "agent")
app = graph.compile()
```

---

### Q17. How do you implement rate limiting and backoff in LangGraph? [HARD]

**Answer:**

**Strategies for rate limiting:**

1. **Token bucket in state:**
```python
import time

class State(TypedDict):
    messages: list
    last_api_call: float
    api_calls_this_minute: int

def rate_limited_node(state):
    # Check rate limit
    now = time.time()
    if now - state["last_api_call"] < 60:
        if state["api_calls_this_minute"] >= 10:
            time.sleep(60 - (now - state["last_api_call"]))
    
    # Make call
    result = api_call()
    
    return {
        "result": result,
        "last_api_call": time.time(),
        "api_calls_this_minute": state["api_calls_this_minute"] + 1
    }
```

2. **Exponential backoff wrapper:**
```python
from tenacity import retry, wait_exponential, stop_after_attempt

@retry(
    wait=wait_exponential(multiplier=1, min=4, max=60),
    stop=stop_after_attempt(5)
)
def call_with_backoff(prompt):
    return llm.invoke(prompt)

def resilient_node(state):
    try:
        result = call_with_backoff(state["prompt"])
        return {"result": result}
    except Exception as e:
        return {"error": str(e)}
```

3. **Queue-based rate limiting:**
```python
import asyncio
from asyncio import Semaphore

# Limit concurrent API calls
semaphore = Semaphore(5)

async def rate_limited_node(state):
    async with semaphore:
        result = await llm.ainvoke(state["messages"])
        await asyncio.sleep(0.1)  # Minimum delay between calls
    return {"result": result}
```

4. **Circuit breaker pattern:**
```python
class CircuitBreaker:
    def __init__(self, failure_threshold=5, reset_timeout=60):
        self.failures = 0
        self.threshold = failure_threshold
        self.reset_timeout = reset_timeout
        self.last_failure = 0
        self.state = "closed"
    
    def call(self, func, *args):
        if self.state == "open":
            if time.time() - self.last_failure > self.reset_timeout:
                self.state = "half-open"
            else:
                raise Exception("Circuit breaker is open")
        
        try:
            result = func(*args)
            self.failures = 0
            self.state = "closed"
            return result
        except Exception as e:
            self.failures += 1
            self.last_failure = time.time()
            if self.failures >= self.threshold:
                self.state = "open"
            raise

breaker = CircuitBreaker()

def protected_node(state):
    return {"result": breaker.call(api_call, state["input"])}
```

---

### Q18. What are Command objects and how are they used? [HARD]

**Answer:**

`Command` objects provide fine-grained control over graph execution:

```python
from langgraph.types import Command

def node_with_command(state):
    if state["needs_goto"]:
        # Jump to specific node, skipping normal flow
        return Command(
            update={"status": "redirected"},
            goto="special_handler"
        )
    
    return {"status": "normal"}
```

**Command capabilities:**

1. **`goto`**: Jump to a specific node
```python
Command(goto="target_node")
```

2. **`update`**: Update state
```python
Command(update={"field": "value"}, goto="next")
```

3. **Multiple destinations (parallel):**
```python
Command(goto=["node_a", "node_b"])  # Both execute
```

4. **Combining with Send:**
```python
from langgraph.constants import Send

def complex_routing(state):
    return Command(
        goto=[
            Send("processor", {"item": item})
            for item in state["items"]
        ]
    )
```

**Use cases:**
- Error recovery (jump to error handler)
- Skip steps based on conditions
- Implement complex control flow
- Dynamic workflow modification

**vs Conditional Edges:**
- Conditional edges: Defined at compile time, static routing options
- Commands: Runtime decisions, can jump anywhere

---

### Q19. How do you implement caching in LangGraph? [MEDIUM]

**Answer:**

**Caching strategies:**

1. **LLM response caching (LangChain level):**
```python
from langchain_community.cache import InMemoryCache
from langchain.globals import set_llm_cache

set_llm_cache(InMemoryCache())

# Or Redis for production
from langchain_community.cache import RedisCache
set_llm_cache(RedisCache(redis_client))
```

2. **Node-level caching:**
```python
from functools import lru_cache

@lru_cache(maxsize=100)
def expensive_computation(input_hash):
    return compute(input_hash)

def cached_node(state):
    # Hash the relevant input
    input_hash = hash(frozenset(state["params"].items()))
    result = expensive_computation(input_hash)
    return {"result": result}
```

3. **State-based memoization:**
```python
class State(TypedDict):
    cache: dict
    query: str

def memoized_node(state):
    cache_key = hash(state["query"])
    
    if cache_key in state["cache"]:
        return {"result": state["cache"][cache_key]}
    
    result = expensive_operation(state["query"])
    
    return {
        "result": result,
        "cache": {**state["cache"], cache_key: result}
    }
```

4. **Semantic caching:**
```python
def semantic_cache_node(state):
    query_embedding = embed(state["query"])
    
    # Check for semantically similar cached queries
    similar = vector_store.similarity_search_with_score(
        query_embedding, k=1
    )
    
    if similar and similar[0][1] > 0.95:  # High similarity
        return {"result": similar[0][0].metadata["response"]}
    
    # Cache miss - compute and store
    result = compute(state["query"])
    vector_store.add_texts(
        [state["query"]],
        metadatas=[{"response": result}]
    )
    return {"result": result}
```

---

### Q20. Explain LangGraph Platform/Cloud and its benefits. [MEDIUM]

**Answer:**

**LangGraph Platform** is a managed infrastructure for deploying LangGraph applications:

**Key features:**

1. **Managed Persistence:**
   - Built-in PostgreSQL for checkpoints
   - No database setup required
   - Automatic scaling

2. **Streaming Support:**
   - WebSocket connections
   - Server-sent events (SSE)
   - Token-level streaming

3. **Background Tasks:**
   - Long-running workflows
   - Async job processing
   - Webhook callbacks

4. **Observability:**
   - LangSmith integration
   - Tracing and debugging
   - Performance metrics

5. **Deployment Options:**
   - LangGraph Cloud (fully managed)
   - Self-hosted (Docker)
   - Kubernetes

**Deployment structure:**
```yaml
# langgraph.json
{
  "graphs": {
    "my_agent": "./agent.py:graph"
  },
  "dependencies": ["requirements.txt"],
  "env": ".env"
}
```

**Client SDK:**
```python
from langgraph_sdk import get_client

client = get_client(url="https://your-deployment.langgraph.cloud")

# Create thread
thread = await client.threads.create()

# Run graph
run = await client.runs.create(
    thread_id=thread["thread_id"],
    graph_id="my_agent",
    input={"messages": [...]}
)

# Stream results
async for event in client.runs.stream(run["run_id"]):
    print(event)
```

**When to use Platform vs self-managed:**
- **Platform**: Production apps, need managed infra, quick deployment
- **Self-managed**: Air-gapped environments, custom infrastructure, cost control

---

### Q21. How do you handle long-running tasks in LangGraph? [HARD]

**Answer:**

**Patterns for long-running tasks:**

1. **Background execution with checkpointing:**
```python
# Client initiates
run = await client.runs.create(
    thread_id=thread_id,
    graph_id="long_task",
    input=data,
    background=True  # Don't wait for completion
)

# Poll or webhook for completion
status = await client.runs.get(run["run_id"])
while status["status"] == "running":
    await asyncio.sleep(5)
    status = await client.runs.get(run["run_id"])
```

2. **Progress tracking in state:**
```python
class State(TypedDict):
    total_items: int
    processed_items: int
    progress_percent: float
    status: str

def processing_node(state):
    item = get_next_item(state)
    result = process(item)
    
    processed = state["processed_items"] + 1
    progress = (processed / state["total_items"]) * 100
    
    return {
        "processed_items": processed,
        "progress_percent": progress,
        "status": "processing" if processed < state["total_items"] else "complete"
    }
```

3. **Chunked processing with yields:**
```python
async def batch_processor(state):
    batch_size = 10
    items = state["items"]
    
    for i in range(0, len(items), batch_size):
        batch = items[i:i + batch_size]
        results = await process_batch(batch)
        
        # Yield intermediate state
        yield {
            "processed": state.get("processed", []) + results,
            "current_batch": i // batch_size
        }
```

4. **Timeout handling:**
```python
import asyncio

async def node_with_timeout(state):
    try:
        result = await asyncio.wait_for(
            long_operation(state["input"]),
            timeout=300  # 5 minutes
        )
        return {"result": result, "timed_out": False}
    except asyncio.TimeoutError:
        return {"result": None, "timed_out": True}

def timeout_router(state):
    if state["timed_out"]:
        return "fallback_handler"
    return "next_step"
```

5. **Webhook notifications:**
```python
def completion_node(state):
    # Process complete, notify via webhook
    requests.post(
        state["webhook_url"],
        json={"status": "complete", "result": state["result"]}
    )
    return state
```

---

### Q22. What are the best practices for production LangGraph deployments? [HARD]

**Answer:**

**1. State Design:**
```python
# DO: Use clear, typed state
class State(TypedDict):
    messages: Annotated[list[BaseMessage], add]
    user_id: str
    session_metadata: dict

# DON'T: Use untyped or overly nested state
```

**2. Error Handling:**
```python
# Comprehensive error states
class State(TypedDict):
    result: Optional[str]
    error: Optional[str]
    error_code: Optional[int]
    retry_count: int

def robust_node(state):
    if state["retry_count"] >= 3:
        return {"error": "Max retries exceeded", "error_code": 500}
    try:
        result = risky_operation()
        return {"result": result}
    except Exception as e:
        return {"error": str(e), "retry_count": state["retry_count"] + 1}
```

**3. Observability:**
```python
import structlog

logger = structlog.get_logger()

def observable_node(state, config):
    run_id = config.get("run_id")
    logger.info("node_start", run_id=run_id, node="observable_node")
    
    result = process(state)
    
    logger.info("node_complete", run_id=run_id, result_size=len(result))
    return result
```

**4. Configuration Management:**
```python
# Externalize configuration
def configurable_node(state, config):
    settings = config["configurable"]
    model = settings.get("model", "gpt-4")
    temperature = settings.get("temperature", 0.7)
    
    llm = ChatOpenAI(model=model, temperature=temperature)
    return {"response": llm.invoke(state["messages"])}
```

**5. Resource Management:**
```python
# Connection pooling
from contextlib import asynccontextmanager

@asynccontextmanager
async def get_db_connection():
    conn = await pool.acquire()
    try:
        yield conn
    finally:
        await pool.release(conn)

async def db_node(state):
    async with get_db_connection() as conn:
        result = await conn.fetch(state["query"])
    return {"db_result": result}
```

**6. Security:**
```python
# Input validation
from pydantic import BaseModel, validator

class UserInput(BaseModel):
    query: str
    
    @validator('query')
    def sanitize_query(cls, v):
        if len(v) > 10000:
            raise ValueError("Query too long")
        return v.strip()

def safe_input_node(state):
    validated = UserInput(query=state["raw_input"])
    return {"query": validated.query}
```

**7. Testing & Deployment:**
```
+----------------+     +----------------+     +----------------+
|   DEVELOPMENT  |---->|    STAGING     |---->|   PRODUCTION   |
| - Unit tests   |     | - Integration  |     | - Canary       |
| - Mock LLMs    |     | - Real LLMs    |     | - Gradual roll |
| - Fast         |     | - Sample data  |     | - Monitoring   |
+----------------+     +----------------+     +----------------+
```

---

## Section 3: Quick-Fire Questions

### Q23. What's the difference between StateGraph and MessageGraph? [EASY]

**Answer:**
- `StateGraph`: Generic, works with any TypedDict state
- `MessageGraph`: Specialized for chat, state is just a list of messages

`MessageGraph` is essentially `StateGraph` with `messages: list` as the only state field.

---

### Q24. Can LangGraph handle async operations? [EASY]

**Answer:**
Yes! LangGraph fully supports async:
- `ainvoke`, `astream`, `abatch` methods
- Async node functions with `async def`
- Async tool execution
- Parallel async operations

---

### Q25. What happens if a node returns None? [EASY]

**Answer:**
If a node returns `None`, the state remains unchanged. This is useful for side-effect-only nodes (logging, external API calls that don't affect state).

---

### Q26. How do you access the config in a node? [EASY]

**Answer:**
```python
def my_node(state, config):
    thread_id = config["configurable"]["thread_id"]
    custom_param = config["configurable"].get("my_param")
    return state
```

Add `config` as the second parameter to your node function.

---

### Q27. What is START and END in LangGraph? [EASY]

**Answer:**
- `START`: Virtual entry point; first node must connect from START
- `END`: Virtual exit point; terminal nodes connect to END

```python
from langgraph.graph import START, END

graph.add_edge(START, "first_node")
graph.add_edge("last_node", END)
```
