# LangGraph Quick Revision Cheat Sheet

## One-Page Summary for Last-Minute Review

---

## Core Concepts (30 seconds each)

### What is LangGraph?
- Library for building **stateful, multi-actor** LLM applications
- Built on LangChain, supports **cycles** (unlike LCEL)
- Key features: State management, Checkpointing, Human-in-the-loop

### Four Building Blocks
```
STATE (TypedDict) --> NODES (Functions) --> EDGES (Connections) --> GRAPH (Orchestrator)
```

### Basic Pattern
```python
from langgraph.graph import StateGraph, START, END
from typing import TypedDict, Annotated
from operator import add

class State(TypedDict):
    messages: Annotated[list, add]  # <-- Reducer!

def my_node(state: State) -> dict:
    return {"messages": ["response"]}  # <-- Return UPDATES only

graph = StateGraph(State)
graph.add_node("node", my_node)
graph.add_edge(START, "node")
graph.add_edge("node", END)
app = graph.compile()
```

---

## State & Reducers

| Pattern | Code | Behavior |
|---------|------|----------|
| Replace (default) | `field: str` | Last write wins |
| Append | `field: Annotated[list, add]` | Lists concatenate |
| Custom | `field: Annotated[T, func]` | `func(old, new)` |

**Remember**: Return updates, NOT mutated state!

---

## Edges Quick Reference

```python
# Normal edge - always follows this path
graph.add_edge("A", "B")

# Conditional edge - routes based on state
graph.add_conditional_edges("A", router_func, {
    "option1": "B",
    "option2": "C",
    END: END
})

# Router function pattern
def router_func(state) -> str:
    if condition:
        return "option1"
    return "option2"
```

---

## ReAct Agent Pattern (Most Common!)

```
+-------+          +-------+
| AGENT |<-------->| TOOLS |
+-------+          +-------+
    |
    v (no tool calls)
  [END]
```

```python
def should_continue(state):
    last = state["messages"][-1]
    if last.tool_calls:
        return "tools"
    return END

graph.add_conditional_edges("agent", should_continue)
graph.add_edge("tools", "agent")  # Loop back!
```

---

## Checkpointing (Persistence)

```python
from langgraph.checkpoint.memory import MemorySaver

app = graph.compile(checkpointer=MemorySaver())

# MUST provide thread_id!
config = {"configurable": {"thread_id": "user-123"}}
result = app.invoke(input_data, config)
```

**Checkpointers**: `MemorySaver` (dev) | `SqliteSaver` | `PostgresSaver` (prod)

---

## Human-in-the-Loop

```python
# Interrupt before a node
app = graph.compile(
    checkpointer=checkpointer,
    interrupt_before=["approval_node"]
)

# First invoke - pauses
app.invoke(input, config)

# Human updates state
app.update_state(config, {"approved": True})

# Resume
app.invoke(None, config)  # <-- None to continue!
```

---

## Streaming Modes

```python
# Full state after each node
app.stream(input, stream_mode="values")

# Only state changes
app.stream(input, stream_mode="updates")

# LLM tokens
app.astream(input, stream_mode="messages")
```

---

## Methods Quick Reference

| Method | Returns | Use Case |
|--------|---------|----------|
| `invoke` | Final state | Single request |
| `stream` | Iterator | Real-time updates |
| `batch` | List of states | Multiple inputs |
| `ainvoke` | Async final | Async single |
| `astream` | Async iterator | Async streaming |

---

## Parallel Execution (Send API)

```python
from langgraph.constants import Send

def dispatcher(state):
    return [
        Send("processor", {"item": item})
        for item in state["items"]
    ]
```

---

## Multi-Agent Architectures

```
SUPERVISOR         HIERARCHICAL       PIPELINE
    |                   |            A -> B -> C
  / | \             Lead1  Lead2
 A  B  C              |      |
                   [team] [team]
```

---

## Common Mistakes Checklist

```
[ ] Returning updates, not mutated state
[ ] Using reducers for accumulating fields
[ ] Cycles have termination conditions
[ ] Thread ID with checkpointing
[ ] START and END connected
[ ] Error handling in nodes
```

---

## Key Interview Phrases

- "LangGraph enables **cyclical flows** for agent loops"
- "State uses **reducers** for controlled updates"
- "**Checkpointing** enables persistence and time-travel"
- "**Human-in-the-loop** via interrupt_before/after"
- "**Conditional edges** enable dynamic routing"

---

## When to Use What

| Need | Solution |
|------|----------|
| Simple chain | LCEL |
| Agent with tools | `create_react_agent` or custom |
| Complex orchestration | Custom StateGraph |
| Multiple agents | Supervisor/hierarchy pattern |
| Persistence | Add checkpointer |
| Human review | interrupt_before/after |
| Parallel processing | Send API |

---

## Code Snippet Templates

### Basic Node
```python
def my_node(state: State) -> dict:
    # Process
    result = process(state["input"])
    # Return updates
    return {"output": result}
```

### Node with Config
```python
def my_node(state: State, config: dict) -> dict:
    thread_id = config["configurable"]["thread_id"]
    # ...
```

### Conditional Router
```python
def router(state: State) -> str:
    if state["condition"]:
        return "path_a"
    return "path_b"
```

### Tool Node
```python
from langgraph.prebuilt import ToolNode
tools = [tool1, tool2]
graph.add_node("tools", ToolNode(tools))
```

---

## Final Tips

1. **Draw the graph first** - visualize before coding
2. **State minimal** - only what's needed
3. **Handle errors** - every external call can fail
4. **Consider streaming** - better UX
5. **Test incrementally** - verify each node

---

**Good luck!**
