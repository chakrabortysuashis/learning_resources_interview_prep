# Common LangGraph Interview Mistakes

## Overview

This guide covers common mistakes candidates make when discussing or implementing
LangGraph solutions. Avoid these pitfalls to make a strong impression.

---

## Mistake 1: Confusing State Mutation vs State Return

### The Mistake

```python
# WRONG - Mutating state directly
def bad_node(state):
    state["messages"].append(new_message)  # Direct mutation!
    state["count"] += 1
    return state  # Returns same mutated object
```

### Why It's Wrong

- LangGraph expects nodes to return **updates**, not mutated state
- Direct mutation breaks checkpointing and time-travel
- Can cause race conditions in parallel execution

### The Fix

```python
# CORRECT - Return updates only
def good_node(state):
    return {
        "messages": [new_message],  # Will be added via reducer
        "count": state["count"] + 1  # Return new value
    }
```

### What Interviewers Notice

- Understanding of immutable state patterns
- Knowledge of how reducers work
- Awareness of parallel execution implications

---

## Mistake 2: Not Using Reducers When Needed

### The Mistake

```python
# WRONG - No reducer, messages get replaced
class State(TypedDict):
    messages: list  # Last node's messages replace all previous!

def node_a(state):
    return {"messages": ["Hello"]}

def node_b(state):
    return {"messages": ["World"]}  # "Hello" is lost!
```

### Why It's Wrong

- Without a reducer, each update **replaces** the field
- Message history gets lost
- Common in chat applications

### The Fix

```python
from typing import Annotated
from operator import add

# CORRECT - With reducer
class State(TypedDict):
    messages: Annotated[list, add]  # Accumulates messages

def node_a(state):
    return {"messages": ["Hello"]}

def node_b(state):
    return {"messages": ["World"]}  # Results in ["Hello", "World"]
```

### When to Use Reducers

- Message accumulation
- Log collection
- Error tracking
- Any field that should accumulate, not replace

---

## Mistake 3: Creating Cycles Without Termination

### The Mistake

```python
# WRONG - Infinite loop!
graph.add_edge("agent", "tools")
graph.add_edge("tools", "agent")  # Always loops back

# No conditional exit!
```

### Why It's Wrong

- Graph never terminates
- Consumes resources indefinitely
- Real agents need termination conditions

### The Fix

```python
# CORRECT - Conditional exit
def should_continue(state):
    if state["done"] or state["iterations"] > MAX_ITER:
        return END
    if state["messages"][-1].tool_calls:
        return "tools"
    return END

graph.add_conditional_edges("agent", should_continue)
graph.add_edge("tools", "agent")
```

### Always Consider

- Maximum iterations
- Completion conditions
- Error/failure exits
- Budget/cost limits

---

## Mistake 4: Ignoring Error Handling

### The Mistake

```python
# WRONG - No error handling
def risky_node(state):
    result = external_api.call(state["query"])  # Can fail!
    return {"result": result}
```

### Why It's Wrong

- API failures crash the entire graph
- No recovery mechanism
- Poor user experience

### The Fix

```python
# CORRECT - Proper error handling
def resilient_node(state):
    try:
        result = external_api.call(state["query"])
        return {"result": result, "error": None}
    except APIError as e:
        logger.error(f"API failed: {e}")
        return {"result": None, "error": str(e)}

# Route based on error
def error_router(state):
    if state.get("error"):
        return "error_handler"
    return "next_step"
```

### Production Error Patterns

- Retry with backoff
- Fallback to cached data
- Graceful degradation
- Error accumulation in state

---

## Mistake 5: Overcomplicating State

### The Mistake

```python
# WRONG - Kitchen sink state
class BadState(TypedDict):
    messages: list
    user_preferences: dict
    all_documents: list  # 100MB of documents!
    entire_database_cache: dict
    session_history_all_time: list
    debug_traces: list
    temporary_calculations: dict
    # ... 20 more fields
```

### Why It's Wrong

- State is serialized at each checkpoint
- Large state = slow performance
- Hard to understand and maintain
- Most fields unnecessary for most nodes

### The Fix

```python
# CORRECT - Minimal, focused state
class GoodState(TypedDict):
    messages: Annotated[list, add]
    current_document_id: str  # Reference, not content
    context_summary: str  # Summarized, not raw
    phase: str

# Fetch details when needed, don't store everything
def document_node(state):
    doc = fetch_document(state["current_document_id"])  # Fetch on demand
    summary = summarize(doc)
    return {"context_summary": summary}
```

### State Design Principles

- Store IDs, not large objects
- Summarize instead of storing raw data
- Only include what's needed for routing/decisions
- Consider checkpoint size

---

## Mistake 6: Forgetting Thread ID for Persistence

### The Mistake

```python
# WRONG - No thread_id
checkpointer = MemorySaver()
app = graph.compile(checkpointer=checkpointer)

# All conversations share the same state!
app.invoke({"messages": [msg1]})
app.invoke({"messages": [msg2]})  # Continues msg1's conversation??
```

### Why It's Wrong

- Different users/sessions collide
- State bleeds between conversations
- Security and privacy issues

### The Fix

```python
# CORRECT - Unique thread_id per conversation
app.invoke(
    {"messages": [msg1]},
    config={"configurable": {"thread_id": "user-123-session-1"}}
)

app.invoke(
    {"messages": [msg2]},
    config={"configurable": {"thread_id": "user-456-session-1"}}  # Different user
)
```

### Thread ID Best Practices

- Include user identifier
- Include session/conversation identifier
- Use UUIDs for security
- Document your ID scheme

---

## Mistake 7: Not Understanding Conditional Edge Mapping

### The Mistake

```python
# WRONG - Function returns unlisted value
def router(state):
    return "special_case"  # Not in mapping!

graph.add_conditional_edges(
    "node_a",
    router,
    {
        "case_1": "handler_1",
        "case_2": "handler_2"
        # "special_case" not mapped!
    }
)
# Runtime error when "special_case" is returned
```

### Why It's Wrong

- Router can return values not in mapping
- Causes runtime errors
- Graph silently breaks

### The Fix

```python
# CORRECT - All return values mapped
def router(state):
    if condition_1:
        return "case_1"
    elif condition_2:
        return "case_2"
    else:
        return "default"  # Always have a default

graph.add_conditional_edges(
    "node_a",
    router,
    {
        "case_1": "handler_1",
        "case_2": "handler_2",
        "default": "default_handler"
    }
)

# OR use direct node names (no mapping needed)
graph.add_conditional_edges("node_a", router)  # Returns node names directly
```

---

## Mistake 8: Blocking Async Operations

### The Mistake

```python
# WRONG - Blocking in async context
async def bad_async_node(state):
    # This blocks the event loop!
    result = requests.get(url)  # Sync HTTP!
    time.sleep(5)  # Sync sleep!
    return {"result": result.text}
```

### Why It's Wrong

- Blocks entire event loop
- Defeats purpose of async
- Poor performance under load

### The Fix

```python
# CORRECT - Proper async
import asyncio
import httpx

async def good_async_node(state):
    async with httpx.AsyncClient() as client:
        result = await client.get(url)  # Async HTTP
    
    await asyncio.sleep(5)  # Async sleep if needed
    
    return {"result": result.text}
```

### Async Best Practices

- Use `httpx` or `aiohttp` instead of `requests`
- Use `asyncio.sleep` instead of `time.sleep`
- Use async database drivers
- Use `ainvoke` and `astream` methods

---

## Mistake 9: Misunderstanding START and END

### The Mistake

```python
# WRONG - No connection to START
graph.add_node("first", first_node)
graph.add_node("second", second_node)
graph.add_edge("first", "second")
graph.add_edge("second", END)

# Graph can't start! No edge from START
```

### Why It's Wrong

- Graph has no entry point
- Will error on compile or invoke
- Easy to forget

### The Fix

```python
# CORRECT - Always connect START and END
from langgraph.graph import START, END

graph.add_node("first", first_node)
graph.add_node("second", second_node)

graph.add_edge(START, "first")  # Entry point
graph.add_edge("first", "second")
graph.add_edge("second", END)  # Exit point(s)
```

### Remember

- START must connect to at least one node
- All terminal paths must reach END
- Conditional edges can route to END
- Graph must have at least one path from START to END

---

## Mistake 10: Over-Engineering Simple Problems

### The Mistake

```python
# WRONG - Building a complex graph for simple task
# Task: "Summarize this text"

class OverEngineeredState(TypedDict):
    text: str
    tokens: list
    parsed_sentences: list
    embeddings: list
    cluster_assignments: list
    intermediate_summaries: list
    final_summary: str

# 10 nodes, 15 edges, subgraphs...
# When all you need is one LLM call!
```

### Why It's Wrong

- Added complexity without benefit
- Harder to maintain
- Slower execution
- Impressive-looking but impractical

### The Fix

```python
# CORRECT - Right tool for the job
# For simple task, use simple solution

# Option 1: Just use LLM directly
summary = llm.invoke(f"Summarize: {text}")

# Option 2: Simple LCEL chain
chain = prompt | llm | StrOutputParser()

# Use LangGraph when you actually need:
# - Cycles/loops
# - Complex state
# - Human-in-the-loop
# - Persistence
```

### The Right Question

Before building a LangGraph, ask:
1. Does this need cycles? (If no, consider LCEL)
2. Does this need persistence? (If no, maybe just functions)
3. Does this need human intervention? (If no, simpler might work)
4. Will this grow in complexity? (Plan ahead, but don't over-build)

---

## Mistake 11: Ignoring Streaming

### The Mistake

```python
# WRONG - Only using invoke
result = app.invoke({"messages": [long_query]})
# User waits 30 seconds with no feedback...
print(result)
```

### Why It's Wrong

- Poor user experience
- No progress indication
- Can't show partial results
- Feels slow even if total time is same

### The Fix

```python
# CORRECT - Use streaming for better UX
async for event in app.astream(
    {"messages": [long_query]},
    stream_mode="messages"
):
    # Show tokens as they arrive
    if event[0].content:
        print(event[0].content, end="", flush=True)

# Or stream state updates
for state in app.stream(input_data, stream_mode="values"):
    print(f"Current phase: {state.get('phase')}")
```

### When to Stream

- Chat interfaces (always)
- Long-running operations
- Multi-step processes with progress
- Real-time dashboards

---

## Mistake 12: Hardcoding Instead of Configuring

### The Mistake

```python
# WRONG - Hardcoded values
def agent_node(state):
    llm = ChatOpenAI(model="gpt-4", temperature=0.7)  # Hardcoded!
    max_tokens = 1000  # Hardcoded!
    
    response = llm.invoke(state["messages"])
    return {"response": response}
```

### Why It's Wrong

- Can't change behavior without code changes
- No A/B testing capability
- Environment-specific configs mixed with logic
- Hard to test with different models

### The Fix

```python
# CORRECT - Use configuration
def agent_node(state, config):
    # Get config values with defaults
    settings = config.get("configurable", {})
    model = settings.get("model", "gpt-4")
    temperature = settings.get("temperature", 0.7)
    max_tokens = settings.get("max_tokens", 1000)
    
    llm = ChatOpenAI(model=model, temperature=temperature)
    response = llm.invoke(state["messages"])
    
    return {"response": response}

# Usage
app.invoke(
    {"messages": [msg]},
    config={
        "configurable": {
            "thread_id": "user-1",
            "model": "gpt-3.5-turbo",  # Override model
            "temperature": 0.3
        }
    }
)
```

---

## Interview Red Flags Summary

When interviewers see these, it raises concerns:

| Red Flag | What It Suggests |
|----------|------------------|
| Direct state mutation | Doesn't understand LangGraph's model |
| No error handling | No production experience |
| Infinite loops | Doesn't think about edge cases |
| Massive state objects | Doesn't consider performance |
| No thread_id usage | Doesn't understand persistence |
| All sync, no async | Limited Python experience |
| Over-engineering | Poor judgment on tool selection |
| No streaming | Doesn't consider UX |
| Hardcoded everything | No production/ops experience |

---

## Quick Self-Check Before Interview

Run through this checklist:

```
[ ] State is immutable - I return updates, not mutations
[ ] Reducers are used for accumulating fields
[ ] All cycles have termination conditions
[ ] Error handling is comprehensive
[ ] State is minimal and focused
[ ] Thread IDs are used with checkpointing
[ ] All conditional edge returns are mapped
[ ] Async operations are truly async
[ ] START and END are properly connected
[ ] Solution complexity matches problem complexity
[ ] Streaming is considered for UX
[ ] Configuration is externalized
```

---

## Practice Exercise

Review this code and identify all mistakes:

```python
class State(TypedDict):
    messages: list  # Mistake 1: ?
    full_documents: list  # Mistake 2: ?

def process(state):
    state["messages"].append("new")  # Mistake 3: ?
    result = requests.get(api_url)  # Mistake 4: ?
    return state  # Mistake 5: ?

graph = StateGraph(State)
graph.add_node("process", process)
graph.add_edge("process", "process")  # Mistake 6: ?
# Mistake 7: Missing what?

app = graph.compile(checkpointer=MemorySaver())
app.invoke({"messages": []})  # Mistake 8: ?
```

**Answers:**
1. No reducer for messages
2. Storing full documents (should store IDs)
3. Direct state mutation
4. Sync HTTP in potentially async context
5. Returning mutated state instead of updates
6. Infinite loop with no exit condition
7. Missing START edge
8. Missing thread_id in config
