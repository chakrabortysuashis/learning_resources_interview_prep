# Real-World Scenario Interview Questions

## Overview

These scenario-based questions test how you'd apply LangGraph to real problems.
They assess practical thinking, trade-off analysis, and production awareness.

---

## Scenario 1: E-Commerce Chatbot Migration [MEDIUM]

### The Situation

> "We have an existing customer service chatbot built with basic LangChain. It handles
> order queries, returns, and general questions. We're seeing issues:
> - Customers have to repeat information across messages
> - The bot loses context after errors
> - We can't hand off to humans smoothly
>
> How would you migrate this to LangGraph?"

### How to Approach

**1. Identify Pain Points -> LangGraph Solutions**

| Pain Point | LangGraph Solution |
|------------|-------------------|
| Lost context | Checkpointing with PostgresSaver |
| Error recovery | Checkpoint resume + error state |
| Human handoff | interrupt_before + state inspection |
| Repeated info | Persistent state with thread_id |

**2. Propose Migration Steps**

```
Phase 1: State Design
- Define TypedDict with customer context, order info, conversation history
- Plan reducers for message accumulation

Phase 2: Basic Graph
- Convert existing logic to nodes
- Add conditional routing for different query types
- Implement START -> classify -> handle -> respond -> END

Phase 3: Add Persistence
- Integrate PostgresSaver
- Implement thread_id scheme (user_id + session_id)
- Test resume scenarios

Phase 4: Human Handoff
- Add escalation node with interrupt_before
- Build admin interface to view state and provide input
- Implement state update for human decisions

Phase 5: Gradual Rollout
- A/B test with subset of users
- Monitor error rates and satisfaction
- Full rollout with monitoring
```

**3. Discuss Trade-offs**

- Migration effort vs immediate benefits
- Downtime during migration
- Training team on new architecture
- Monitoring and debugging new system

---

## Scenario 2: Document Processing Pipeline [MEDIUM]

### The Situation

> "We need to process legal documents:
> 1. Extract key clauses
> 2. Check for compliance issues
> 3. Flag risks for human review
> 4. Generate summaries
>
> Volume: 1000 documents/day. Some need human review."

### How to Approach

**1. Design the Graph**

```
                +-------------+
                |   INTAKE    |
                +------+------+
                       |
                +------v------+
                |    PARSE    |
                +------+------+
                       |
          +------------+------------+
          |                         |
    +-----v-----+             +-----v-----+
    | EXTRACT   |             | COMPLIANCE|
    | CLAUSES   |             |   CHECK   |
    +-----+-----+             +-----+-----+
          |                         |
          +------------+------------+
                       |
                +------v------+
                | RISK ASSESS |
                +------+------+
                       |
            +----------+----------+
            |                     |
      +-----v-----+         +-----v-----+
      |   AUTO    |         |  HUMAN    |
      | APPROVE   |         |  REVIEW   |
      +-----------+         +-----------+
                                  |
                            [INTERRUPT]
```

**2. Key Design Decisions**

```python
class DocumentState(TypedDict):
    doc_id: str
    raw_content: str
    clauses: list
    compliance_issues: list
    risk_score: float
    needs_review: bool
    human_decision: Optional[str]
    summary: str
```

**3. Address Scale**

- Use `batch` for processing multiple documents
- Implement parallel extraction with Send API
- Queue documents for async processing
- Checkpoint after each major step for resume

**4. Human Review Design**

```python
def risk_assessment(state):
    risk_score = calculate_risk(state["compliance_issues"])
    return {
        "risk_score": risk_score,
        "needs_review": risk_score > THRESHOLD
    }

# Compile with conditional interrupt
app = graph.compile(
    checkpointer=PostgresSaver(conn),
    interrupt_before=["human_review"]
)
```

---

## Scenario 3: Multi-Agent Research System [HARD]

### The Situation

> "We want to build a research assistant that:
> - Accepts research questions
> - Searches multiple sources (web, papers, internal docs)
> - Synthesizes findings
> - Can engage in back-and-forth with the user to refine
>
> Users are researchers who need citations and may redirect mid-research."

### How to Approach

**1. Architecture: Supervisor Pattern**

```
                    +------------+
                    | SUPERVISOR |
                    +-----+------+
                          |
        +-----------------+-----------------+
        |                 |                 |
  +-----v-----+     +-----v-----+     +-----v-----+
  |   WEB     |     |  PAPER    |     | INTERNAL  |
  | SEARCHER  |     | SEARCHER  |     |   DOCS    |
  +-----------+     +-----------+     +-----------+
        |                 |                 |
        +-----------------+-----------------+
                          |
                    +-----v------+
                    | SYNTHESIZER|
                    +-----+------+
                          |
                    +-----v------+
                    |   USER     |
                    | DIALOGUE   |
                    +------------+
```

**2. State Design for Multi-Turn**

```python
class ResearchState(TypedDict):
    messages: Annotated[list, add]
    research_question: str
    refined_questions: list
    sources: Annotated[list[Source], add]
    synthesis: str
    citations: list
    phase: Literal["clarify", "search", "synthesize", "discuss"]
    iteration: int
```

**3. Handle User Redirection**

```python
def user_dialogue(state):
    # Analyze user's latest message
    intent = classify_intent(state["messages"][-1])
    
    if intent == "refine":
        # User wants to adjust research direction
        return {"phase": "search", "research_question": extract_new_question(state)}
    elif intent == "clarify":
        # User asking for clarification
        return {"phase": "discuss"}
    elif intent == "done":
        return {"phase": "complete"}
    else:
        return {"phase": "discuss"}
```

**4. Citation Management**

```python
class Source(BaseModel):
    url: str
    title: str
    authors: list[str]
    date: str
    relevance_score: float
    
    def to_citation(self, style: str = "APA") -> str:
        # Generate formatted citation
        pass
```

---

## Scenario 4: Automated Code Review Bot [HARD]

### The Situation

> "We want to automate initial code review:
> - Runs on every PR
> - Checks style, security, performance
> - Posts comments on specific lines
> - Approves simple PRs, flags complex ones for human review
>
> Integrate with GitHub, handle large PRs efficiently."

### How to Approach

**1. Integration Architecture**

```
GitHub Webhook
      |
      v
+-------------+     +----------------+
|  LANGGRAPH  |<--->| GitHub API     |
|   SERVICE   |     | (fetch diff,   |
|             |     |  post comments)|
+-------------+     +----------------+
      |
      v
+-------------+
|  POSTGRES   |
| (Checkpoints|
|  & Results) |
+-------------+
```

**2. Handle Large PRs**

```python
def chunk_large_pr(state):
    diff = state["diff"]
    files = parse_diff_to_files(diff)
    
    # For large PRs, process in chunks
    if len(files) > 20:
        # Send files in batches
        batches = [files[i:i+5] for i in range(0, len(files), 5)]
        return [
            Send("review_batch", {"files": batch, "batch_num": i})
            for i, batch in enumerate(batches)
        ]
    
    return [Send("review_all", {"files": files})]
```

**3. Comment Posting Strategy**

```python
class ReviewComment(BaseModel):
    file: str
    line: int
    body: str
    severity: Literal["critical", "suggestion", "nitpick"]

def post_comments(state):
    comments = state["review_comments"]
    
    # Group by severity
    critical = [c for c in comments if c.severity == "critical"]
    
    # Post critical as review comments
    for comment in critical:
        github_api.create_review_comment(
            pr=state["pr_number"],
            file=comment.file,
            line=comment.line,
            body=f":warning: **Critical**: {comment.body}"
        )
    
    # Determine approval
    if critical:
        github_api.request_changes(state["pr_number"])
    elif len(comments) > 10:
        github_api.comment(state["pr_number"], "Please review suggestions")
    else:
        github_api.approve(state["pr_number"])
```

**4. Caching for Efficiency**

```python
def review_file(state, config, store):
    file_hash = hash_file(state["file"])
    
    # Check cache
    cached = store.get(("reviews",), file_hash)
    if cached:
        return {"review_comments": cached["comments"]}
    
    # New review
    comments = perform_review(state["file"])
    store.put(("reviews",), file_hash, {"comments": comments})
    
    return {"review_comments": comments}
```

---

## Scenario 5: Real-Time Monitoring Agent [HARD]

### The Situation

> "We want an AI agent that:
> - Monitors system metrics continuously
> - Detects anomalies
> - Investigates issues automatically
> - Escalates to on-call if needed
>
> 24/7 operation, needs to be reliable and not overwhelm on-call with false alarms."

### How to Approach

**1. Continuous Operation Design**

```
+-------------+
| POLL METRICS|<----------+
+------+------+           |
       |                  |
+------v------+           |
|   ANALYZE   |           |
+------+------+           |
       |                  |
   +---+---+              |
   |       |              |
Normal  Anomaly           |
   |       |              |
   +--+    +------v-------+
      |    | INVESTIGATE  |
      |    +------+-------+
      |           |
      |    +------v------+
      |    |   DECIDE    |
      |    +------+------+
      |           |
      |    +------+------+
      |    |             |
      |   False      Real Issue
      |   Alarm          |
      |    |       +-----v-----+
      |    |       | ESCALATE  |
      |    |       +-----------+
      |    |             |
      +----+-------------+
           |
     WAIT & LOOP
```

**2. Prevent Alert Fatigue**

```python
class MonitorState(TypedDict):
    metrics: dict
    anomalies: list
    investigation_result: str
    confidence: float
    recent_alerts: Annotated[list, add]
    cooldown_until: Optional[datetime]

def should_escalate(state):
    # Don't spam on-call
    if state.get("cooldown_until") and datetime.now() < state["cooldown_until"]:
        return "log_only"
    
    # Check confidence
    if state["confidence"] < 0.8:
        return "investigate_more"
    
    # Check if similar recent alert
    similar = find_similar(state["investigation_result"], state["recent_alerts"])
    if similar:
        return "correlate"
    
    return "escalate"

def escalate(state):
    # Send alert
    pagerduty.trigger(
        summary=state["investigation_result"],
        severity="high" if state["confidence"] > 0.9 else "warning"
    )
    
    # Set cooldown
    return {
        "recent_alerts": [state["investigation_result"]],
        "cooldown_until": datetime.now() + timedelta(minutes=30)
    }
```

**3. Investigation Agent**

```python
def investigate_anomaly(state):
    anomaly = state["anomalies"][0]
    
    # Gather context
    context = []
    context.append(get_related_logs(anomaly["service"], anomaly["time"]))
    context.append(get_recent_deployments())
    context.append(get_dependency_status(anomaly["service"]))
    
    # Ask LLM to analyze
    investigation = llm.invoke(f"""
    Investigate this anomaly:
    {anomaly}
    
    Context:
    {context}
    
    Determine:
    1. Is this a real issue or noise?
    2. Likely root cause
    3. Confidence level (0-1)
    4. Recommended action
    """)
    
    return {
        "investigation_result": investigation.content,
        "confidence": extract_confidence(investigation.content)
    }
```

---

## Scenario 6: Content Moderation Pipeline [MEDIUM]

### The Situation

> "We need to moderate user-generated content:
> - Check for policy violations
> - Auto-approve safe content
> - Queue borderline content for human review
> - Learn from human decisions
>
> Handle 10,000 posts/day with 99.9% uptime."

### Key Design Points

**1. Multi-Level Review**

```
       +----------+
       |  INTAKE  |
       +----+-----+
            |
      +-----v-----+
      |  CLASSIFY |
      +-----+-----+
            |
    +-------+-------+
    |       |       |
   Safe  Borderline Violation
    |       |       |
+---v---+ +-v----+ +v--------+
| AUTO  | |HUMAN | | AUTO    |
|APPROVE| |QUEUE | | REJECT  |
+-------+ +------+ +---------+
```

**2. Confidence-Based Routing**

```python
def classify_content(state):
    result = moderation_model.classify(state["content"])
    
    return {
        "category": result.category,
        "confidence": result.confidence,
        "reasons": result.reasons
    }

def route_by_confidence(state):
    conf = state["confidence"]
    cat = state["category"]
    
    if cat == "safe" and conf > 0.95:
        return "auto_approve"
    elif cat == "violation" and conf > 0.95:
        return "auto_reject"
    else:
        return "human_queue"
```

**3. Learning from Humans**

```python
def human_review_complete(state):
    # Store human decision for training
    training_store.add({
        "content": state["content"],
        "model_prediction": state["category"],
        "model_confidence": state["confidence"],
        "human_decision": state["human_decision"],
        "timestamp": datetime.now()
    })
    
    # Periodically retrain model
    # (handled by separate batch job)
    
    return {"final_status": state["human_decision"]}
```

---

## Interview Discussion Points

For each scenario, be prepared to discuss:

### Architecture
- Why this graph structure?
- What alternatives did you consider?
- How does it scale?

### State Design
- Why these fields?
- Which need reducers?
- How big is the state?

### Error Handling
- What can fail?
- How do you recover?
- What's the fallback?

### Production Concerns
- How do you monitor?
- What alerts do you set?
- How do you debug issues?

### Cost Optimization
- How many LLM calls?
- Can you cache?
- What's the cost per operation?

---

## Template for Scenario Answers

Use this structure when answering:

1. **Clarify Requirements** (30 seconds)
   - Ask about scale, latency, existing systems

2. **High-Level Design** (2 minutes)
   - Draw the graph
   - Identify main nodes and flow

3. **State Design** (1 minute)
   - Key fields
   - Reducers needed

4. **Key Implementation Details** (2 minutes)
   - Critical nodes
   - Routing logic
   - Error handling

5. **Production Considerations** (1 minute)
   - Monitoring
   - Scaling
   - Failure modes

6. **Trade-offs** (1 minute)
   - What you'd do differently with more time
   - Alternative approaches

---

## Practice Exercise

Pick one scenario and:
1. Sketch the graph on paper
2. Write the State TypedDict
3. Implement the main routing function
4. List three things that could go wrong
5. Describe how you'd monitor it

Time yourself: 15 minutes total.
