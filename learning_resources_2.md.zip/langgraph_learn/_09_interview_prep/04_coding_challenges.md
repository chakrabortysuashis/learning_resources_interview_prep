# LangGraph Coding Challenges

## Overview

These coding challenges test your practical ability to implement LangGraph solutions.
Attempt them without looking at solutions first, then compare your approach.

---

## Challenge 1: Basic Chatbot with Memory [EASY]

### Problem Statement

Create a simple chatbot that:
1. Maintains conversation history
2. Can greet users by name if they introduce themselves
3. Tracks how many messages have been exchanged

### Requirements

```python
# Expected behavior:
# User: "Hi, I'm Alice"
# Bot: "Hello Alice! Nice to meet you."
# User: "What's my name?"
# Bot: "Your name is Alice!"
# User: "How many messages have we exchanged?"
# Bot: "We've exchanged 3 messages so far."
```

### Starter Code

```python
from typing import TypedDict, Annotated, Optional
from operator import add
from langgraph.graph import StateGraph, START, END
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, AIMessage

# TODO: Define state
class ChatState(TypedDict):
    pass  # Your implementation

# TODO: Implement nodes
def chatbot_node(state):
    pass  # Your implementation

# TODO: Build and compile graph
def create_chatbot():
    pass  # Your implementation

# Test
if __name__ == "__main__":
    app = create_chatbot()
    config = {"configurable": {"thread_id": "test-1"}}
    
    response = app.invoke({"messages": [HumanMessage("Hi, I'm Alice")]}, config)
    print(response["messages"][-1].content)
```

### Hints

1. Use a reducer for messages
2. Extract name from messages using the LLM
3. Track message count in state

---

## Challenge 2: Tool-Calling Agent [EASY]

### Problem Statement

Build an agent that can use two tools:
1. `get_weather(city: str)` - Returns weather for a city
2. `calculate(expression: str)` - Evaluates math expressions

The agent should be able to answer questions like:
- "What's the weather in Paris?"
- "What's 25 * 4 + 10?"
- "Is it warmer in London or Tokyo?"

### Requirements

- Implement the ReAct pattern (agent -> tools -> agent loop)
- Handle cases where no tools are needed
- Maximum 5 tool calls per query

### Starter Code

```python
from typing import TypedDict, Annotated
from operator import add
from langgraph.graph import StateGraph, START, END
from langgraph.prebuilt import ToolNode
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI

@tool
def get_weather(city: str) -> str:
    """Get the current weather for a city."""
    # Mock implementation
    weather_data = {
        "paris": "Sunny, 22C",
        "london": "Cloudy, 15C",
        "tokyo": "Rainy, 18C",
    }
    return weather_data.get(city.lower(), "Weather data not available")

@tool
def calculate(expression: str) -> str:
    """Evaluate a mathematical expression."""
    try:
        result = eval(expression)  # Note: In production, use a safe parser
        return str(result)
    except Exception as e:
        return f"Error: {e}"

# TODO: Define state
class AgentState(TypedDict):
    pass

# TODO: Implement agent node
def agent(state):
    pass

# TODO: Implement routing function
def should_continue(state):
    pass

# TODO: Build graph
def create_agent():
    pass
```

---

## Challenge 3: Branching Workflow [MEDIUM]

### Problem Statement

Create a customer inquiry router that:
1. Classifies inquiries into: "technical", "billing", "sales", "other"
2. Routes to specialized handlers
3. Each handler produces a response
4. All paths converge to a response formatter

### Expected Flow

```
                    +----------+
                    | CLASSIFY |
                    +----+-----+
                         |
     +----------+--------+--------+----------+
     |          |        |        |          |
+----v---+ +----v---+ +--v----+ +-v------+
|TECHNICAL| |BILLING | | SALES | | OTHER  |
+----+----+ +----+---+ +---+---+ +---+----+
     |          |          |         |
     +----------+----------+---------+
                    |
               +----v-----+
               | RESPOND  |
               +----------+
```

### Starter Code

```python
from typing import TypedDict, Literal, Annotated
from operator import add
from langgraph.graph import StateGraph, START, END

class InquiryState(TypedDict):
    inquiry: str
    category: Literal["technical", "billing", "sales", "other", None]
    handler_response: str
    final_response: str

# TODO: Implement classifier
def classify_inquiry(state):
    """Classify the inquiry into a category."""
    pass

# TODO: Implement handlers
def technical_handler(state):
    pass

def billing_handler(state):
    pass

def sales_handler(state):
    pass

def other_handler(state):
    pass

# TODO: Implement response formatter
def format_response(state):
    pass

# TODO: Implement routing function
def route_inquiry(state):
    pass

# TODO: Build graph
def create_inquiry_router():
    pass
```

---

## Challenge 4: Parallel Execution with Fan-Out/Fan-In [MEDIUM]

### Problem Statement

Create a content analysis system that:
1. Takes a piece of text
2. Runs three parallel analyses: sentiment, topics, and entities
3. Combines all results into a final report

### Requirements

- All three analyses should run in parallel
- Results should be combined once all complete
- Handle partial failures gracefully

### Starter Code

```python
from typing import TypedDict, Annotated, Optional
from operator import add
from langgraph.graph import StateGraph, START, END
from langgraph.constants import Send

class AnalysisState(TypedDict):
    text: str
    # Individual results
    sentiment: Optional[dict]
    topics: Optional[list[str]]
    entities: Optional[list[dict]]
    # Combined
    analysis_complete: int  # Count of completed analyses
    final_report: Optional[str]
    errors: Annotated[list[str], add]

# TODO: Implement dispatcher that sends to parallel nodes
def dispatch_analyses(state):
    pass

# TODO: Implement analysis nodes
def analyze_sentiment(state):
    pass

def extract_topics(state):
    pass

def extract_entities(state):
    pass

# TODO: Implement combiner
def combine_results(state):
    pass

# TODO: Build graph
def create_analyzer():
    pass
```

---

## Challenge 5: Human-in-the-Loop Approval [MEDIUM]

### Problem Statement

Create a document approval workflow:
1. User submits a document
2. AI reviews and provides summary
3. If sensitive content detected, pause for human approval
4. Human can approve, reject, or request modifications
5. Final processing based on decision

### Requirements

- Use `interrupt_before` for human checkpoints
- Implement state update for human decisions
- Handle all three decision paths

### Starter Code

```python
from typing import TypedDict, Literal, Optional
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.memory import MemorySaver

class ApprovalState(TypedDict):
    document: str
    summary: str
    sensitivity_score: float
    requires_approval: bool
    human_decision: Optional[Literal["approve", "reject", "modify"]]
    modification_notes: Optional[str]
    final_status: str

# TODO: Implement nodes
def analyze_document(state):
    """Analyze document and determine sensitivity."""
    pass

def check_sensitivity(state):
    """Route based on sensitivity score."""
    pass

def await_approval(state):
    """This node will be interrupted for human input."""
    pass

def process_approved(state):
    pass

def process_rejected(state):
    pass

def process_modified(state):
    pass

# TODO: Build graph with interrupts
def create_approval_workflow():
    pass

# Usage pattern:
# 1. app.invoke({"document": "..."}, config) -> pauses at approval
# 2. app.update_state(config, {"human_decision": "approve"})
# 3. app.invoke(None, config) -> continues
```

---

## Challenge 6: Retry with Backoff [MEDIUM]

### Problem Statement

Create a resilient API caller that:
1. Attempts to call an unreliable API
2. On failure, retries with exponential backoff
3. Maximum 3 retries
4. Tracks all attempts in state
5. Falls back to cached data after max retries

### Requirements

- Implement retry logic within the graph
- Track attempt count and timing
- Provide meaningful error messages

### Starter Code

```python
from typing import TypedDict, Annotated, Optional
from operator import add
import time
import random
from langgraph.graph import StateGraph, START, END

class RetryState(TypedDict):
    query: str
    attempt: int
    max_attempts: int
    last_error: Optional[str]
    result: Optional[str]
    attempt_log: Annotated[list[dict], add]
    use_fallback: bool

def unreliable_api(query: str) -> str:
    """Simulates an unreliable API - fails 70% of the time."""
    if random.random() < 0.7:
        raise Exception("API temporarily unavailable")
    return f"Result for: {query}"

# TODO: Implement nodes
def call_api(state):
    """Attempt to call the API."""
    pass

def check_result(state):
    """Determine next step based on result."""
    pass

def wait_backoff(state):
    """Wait with exponential backoff before retry."""
    pass

def use_fallback(state):
    """Use cached/fallback data."""
    pass

# TODO: Build graph
def create_resilient_caller():
    pass
```

---

## Challenge 7: Multi-Agent Debate [HARD]

### Problem Statement

Create a debate system where:
1. Two AI agents argue opposing sides of a topic
2. A moderator controls the flow
3. Debate continues for N rounds
4. A judge evaluates and declares a winner

### Requirements

- Three distinct agent personas
- Clear turn-taking
- Score tracking
- Summary generation

### Starter Code

```python
from typing import TypedDict, Annotated, Literal
from operator import add
from langgraph.graph import StateGraph, START, END

class DebateMessage(TypedDict):
    speaker: str
    content: str
    round: int

class DebateState(TypedDict):
    topic: str
    pro_position: str
    con_position: str
    current_round: int
    max_rounds: int
    messages: Annotated[list[DebateMessage], add]
    current_speaker: Literal["moderator", "pro", "con", "judge"]
    scores: dict[str, int]  # {"pro": 0, "con": 0}
    winner: Optional[str]
    summary: Optional[str]

# TODO: Implement agent nodes
def moderator(state):
    """Controls debate flow, introduces rounds."""
    pass

def pro_agent(state):
    """Argues in favor of the topic."""
    pass

def con_agent(state):
    """Argues against the topic."""
    pass

def judge(state):
    """Evaluates arguments and scores."""
    pass

# TODO: Implement routing
def next_speaker(state):
    """Determine who speaks next."""
    pass

# TODO: Build graph
def create_debate_system():
    pass
```

---

## Challenge 8: Subgraph Communication [HARD]

### Problem Statement

Create a hierarchical agent system:
1. Main supervisor graph
2. Research subgraph (search, analyze, summarize)
3. Writing subgraph (outline, draft, edit)
4. Subgraphs should share context appropriately

### Requirements

- Clean interface between graphs
- State transformation at boundaries
- Error handling across graphs

### Starter Code

```python
from typing import TypedDict, Annotated, Optional
from operator import add
from langgraph.graph import StateGraph, START, END

# Subgraph states
class ResearchState(TypedDict):
    query: str
    sources: list[str]
    summary: str

class WritingState(TypedDict):
    topic: str
    context: str
    outline: list[str]
    draft: str
    final: str

# Main graph state
class SupervisorState(TypedDict):
    task: str
    research_complete: bool
    writing_complete: bool
    research_output: Optional[str]
    writing_output: Optional[str]
    final_deliverable: Optional[str]

# TODO: Build research subgraph
def create_research_subgraph():
    pass

# TODO: Build writing subgraph
def create_writing_subgraph():
    pass

# TODO: Build supervisor graph
def create_supervisor():
    pass
```

---

## Challenge 9: Dynamic Graph Modification [HARD]

### Problem Statement

Create a workflow builder that:
1. Accepts a JSON workflow definition
2. Dynamically builds a LangGraph from it
3. Executes the workflow
4. Handles dynamic node addition/removal

### Example Input

```json
{
    "nodes": [
        {"id": "start", "type": "input"},
        {"id": "process", "type": "llm", "prompt": "Summarize: {input}"},
        {"id": "validate", "type": "condition", "check": "length > 100"},
        {"id": "end", "type": "output"}
    ],
    "edges": [
        {"from": "start", "to": "process"},
        {"from": "process", "to": "validate"},
        {"from": "validate", "to": "end", "condition": "pass"},
        {"from": "validate", "to": "process", "condition": "fail"}
    ]
}
```

### Starter Code

```python
from typing import TypedDict, Any
from langgraph.graph import StateGraph, START, END
import json

class DynamicState(TypedDict):
    input: str
    current_data: Any
    node_outputs: dict[str, Any]
    execution_path: list[str]

def build_graph_from_json(workflow_json: str):
    """Build a LangGraph from JSON definition."""
    workflow = json.loads(workflow_json)
    
    # TODO: Parse nodes
    # TODO: Create node functions
    # TODO: Add edges
    # TODO: Compile and return
    pass

def create_node_function(node_def: dict):
    """Create a node function from definition."""
    # TODO: Handle different node types
    pass
```

---

## Challenge 10: Production-Ready Agent [HARD]

### Problem Statement

Create a production-ready customer service agent with:
1. Rate limiting
2. Input validation
3. Output filtering
4. Comprehensive logging
5. Graceful degradation
6. Metrics collection

### Requirements

- All production concerns addressed
- Clean, maintainable code
- Proper error handling throughout

### Starter Code

```python
from typing import TypedDict, Annotated, Optional
from operator import add
import time
import logging
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.postgres import PostgresSaver

logger = logging.getLogger(__name__)

class ProductionState(TypedDict):
    # Input
    user_id: str
    message: str
    
    # Validation
    is_valid: bool
    validation_error: Optional[str]
    
    # Processing
    response: Optional[str]
    
    # Safety
    input_filtered: bool
    output_filtered: bool
    
    # Metrics
    processing_time_ms: float
    llm_calls: int
    tokens_used: int
    
    # Audit
    audit_log: Annotated[list[dict], add]

# TODO: Implement rate limiter
class RateLimiter:
    pass

# TODO: Implement input validator
def validate_input(state):
    pass

# TODO: Implement input filter
def filter_input(state):
    pass

# TODO: Implement main processing
def process_message(state):
    pass

# TODO: Implement output filter
def filter_output(state):
    pass

# TODO: Implement metrics collector
def collect_metrics(state):
    pass

# TODO: Build production graph
def create_production_agent():
    pass
```

---

## Grading Rubric

For each challenge, evaluate your solution on:

### Code Quality (25%)
- Clean, readable code
- Proper type hints
- Meaningful variable names
- Appropriate comments

### Correctness (25%)
- Solution works for basic cases
- Edge cases handled
- No runtime errors

### LangGraph Best Practices (25%)
- Proper state design
- Appropriate use of reducers
- Correct edge types (normal vs conditional)
- Efficient graph structure

### Production Readiness (25%)
- Error handling
- Logging
- Configurability
- Testability

---

## Submission Tips

When presenting your solution in an interview:

1. **Explain your approach first** - Don't just start coding
2. **Discuss trade-offs** - Why did you make certain choices?
3. **Consider edge cases** - What could go wrong?
4. **Think about production** - How would this scale?
5. **Be ready to iterate** - Interviewers may ask for modifications
