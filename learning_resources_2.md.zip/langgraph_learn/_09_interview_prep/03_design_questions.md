# LangGraph System Design Interview Questions

## Overview

System design questions test your ability to architect complete solutions using
LangGraph. These questions are common for senior roles and require demonstrating
both breadth of knowledge and depth of understanding.

---

## Design Question 1: Customer Support Bot [MEDIUM]

### Problem Statement

Design a customer support chatbot for an e-commerce company that can:
- Answer questions about products and orders
- Process returns and refunds
- Escalate to human agents when needed
- Maintain conversation context across sessions

### Solution Approach

**1. High-Level Architecture:**

```
+------------------+     +------------------+     +------------------+
|     FRONTEND     |---->|   LANGGRAPH      |---->|    BACKEND       |
| (Chat Interface) |     |   AGENT          |     |    SERVICES      |
|                  |<----|                  |<----|                  |
+------------------+     +------------------+     +------------------+
                               |
                               v
                         +-----------+
                         | POSTGRES  |
                         | (State)   |
                         +-----------+
```

**2. State Design:**

```python
from typing import TypedDict, Annotated, Optional, Literal
from operator import add

class CustomerSupportState(TypedDict):
    # Conversation
    messages: Annotated[list[BaseMessage], add]
    
    # Customer context
    customer_id: Optional[str]
    order_history: list[dict]
    current_order: Optional[dict]
    
    # Workflow state
    intent: Optional[str]  # inquiry, return, complaint, other
    sentiment: Literal["positive", "neutral", "negative"]
    escalation_needed: bool
    
    # Action tracking
    actions_taken: Annotated[list[str], add]
    resolution_status: Optional[str]
```

**3. Graph Structure:**

```
                              +-------+
                              | START |
                              +---+---+
                                  |
                              +---v---+
                              | GREET |
                              +---+---+
                                  |
                              +---v-------+
                              | CLASSIFY  |
                              | INTENT    |
                              +---+-------+
                                  |
        +------------+------------+------------+
        |            |            |            |
    +---v---+    +---v---+    +---v---+    +---v------+
    | ORDER |    |PRODUCT|    |RETURN |    | GENERAL  |
    | INFO  |    | INFO  |    |PROCESS|    | INQUIRY  |
    +---+---+    +---+---+    +---+---+    +---+------+
        |            |            |            |
        +------------+------------+------------+
                                  |
                              +---v-------+
                              | SENTIMENT |
                              | CHECK     |
                              +---+-------+
                                  |
                    +-------------+-------------+
                    |                           |
                +---v---+                   +---v------+
                | HAPPY |                   | ESCALATE |
                | PATH  |                   | TO HUMAN |
                +---+---+                   +----------+
                    |
                +---v---+
                |  END  |
                +-------+
```

**4. Key Nodes Implementation:**

```python
from langgraph.graph import StateGraph, START, END
from langgraph.prebuilt import ToolNode
from langgraph.checkpoint.postgres import PostgresSaver

def intent_classifier(state):
    """Classify customer intent from their message."""
    last_message = state["messages"][-1].content
    
    classification = llm.invoke(
        f"""Classify this customer message into one of:
        - order: Questions about order status, delivery, tracking
        - product: Questions about product features, availability
        - return: Return or refund requests
        - general: General inquiries
        
        Message: {last_message}
        
        Return only the category name."""
    )
    
    return {"intent": classification.content.strip().lower()}

def sentiment_analyzer(state):
    """Analyze customer sentiment throughout conversation."""
    recent_messages = state["messages"][-5:]
    
    analysis = llm.invoke(
        f"Analyze sentiment of this conversation: {recent_messages}. "
        "Return: positive, neutral, or negative"
    )
    
    sentiment = analysis.content.strip().lower()
    escalation_needed = sentiment == "negative" and len(state["messages"]) > 4
    
    return {
        "sentiment": sentiment,
        "escalation_needed": escalation_needed
    }

def order_info_node(state):
    """Handle order-related queries."""
    order_tool_result = order_service.get_order(
        customer_id=state["customer_id"],
        order_id=state.get("current_order", {}).get("id")
    )
    
    response = llm.invoke(
        f"Based on this order info: {order_tool_result}, "
        f"respond to: {state['messages'][-1].content}"
    )
    
    return {
        "messages": [AIMessage(content=response.content)],
        "actions_taken": ["order_lookup"]
    }

def escalation_node(state):
    """Escalate to human agent."""
    summary = llm.invoke(
        f"Summarize this conversation for a human agent: {state['messages']}"
    )
    
    # Create ticket in support system
    ticket = support_system.create_ticket(
        customer_id=state["customer_id"],
        summary=summary.content,
        conversation=state["messages"],
        priority="high" if state["sentiment"] == "negative" else "normal"
    )
    
    return {
        "messages": [AIMessage(
            content="I'm connecting you with a human agent who can better assist. "
            f"Your ticket number is {ticket['id']}. They'll be with you shortly."
        )],
        "resolution_status": "escalated"
    }
```

**5. Routing Logic:**

```python
def route_by_intent(state):
    intent = state.get("intent", "general")
    return {
        "order": "order_info",
        "product": "product_info",
        "return": "return_process",
        "general": "general_inquiry"
    }.get(intent, "general_inquiry")

def route_by_sentiment(state):
    if state["escalation_needed"]:
        return "escalate"
    return "respond"

# Build graph
graph = StateGraph(CustomerSupportState)

graph.add_node("greet", greet_node)
graph.add_node("classify_intent", intent_classifier)
graph.add_node("order_info", order_info_node)
graph.add_node("product_info", product_info_node)
graph.add_node("return_process", return_process_node)
graph.add_node("general_inquiry", general_inquiry_node)
graph.add_node("sentiment_check", sentiment_analyzer)
graph.add_node("respond", respond_node)
graph.add_node("escalate", escalation_node)

graph.add_edge(START, "greet")
graph.add_edge("greet", "classify_intent")
graph.add_conditional_edges("classify_intent", route_by_intent)
graph.add_edge("order_info", "sentiment_check")
graph.add_edge("product_info", "sentiment_check")
graph.add_edge("return_process", "sentiment_check")
graph.add_edge("general_inquiry", "sentiment_check")
graph.add_conditional_edges("sentiment_check", route_by_sentiment)
graph.add_edge("respond", END)
graph.add_edge("escalate", END)
```

**6. Production Considerations:**

- **Persistence**: PostgresSaver for customer conversation history
- **Streaming**: Token streaming for responsive UX
- **Rate limiting**: Prevent abuse
- **Logging**: Track all interactions for analysis
- **Fallback**: Graceful degradation if LLM fails

---

## Design Question 2: Research Assistant Agent [HARD]

### Problem Statement

Design a research assistant that can:
- Search the web and academic papers
- Read and summarize documents
- Synthesize information from multiple sources
- Provide citations
- Allow user to guide research direction

### Solution Approach

**1. Multi-Phase Architecture:**

```
+------------------------------------------+
|            RESEARCH ASSISTANT            |
+------------------------------------------+
                    |
    +---------------+---------------+
    |               |               |
+---v---+       +---v---+       +---v---+
|SEARCH |       |ANALYZE|       |SYNTH- |
| PHASE |  -->  | PHASE |  -->  | ESIZE |
|       |       |       |       | PHASE |
+-------+       +-------+       +-------+
    |               |               |
    v               v               v
 Sources         Summaries       Report
```

**2. State Design:**

```python
from pydantic import BaseModel, Field
from typing import Annotated
from operator import add

class Source(BaseModel):
    url: str
    title: str
    content: str
    relevance_score: float
    citation: str

class ResearchState(TypedDict):
    # User interaction
    messages: Annotated[list[BaseMessage], add]
    research_question: str
    
    # Search phase
    search_queries: list[str]
    sources: Annotated[list[Source], add]
    search_complete: bool
    
    # Analysis phase
    summaries: dict[str, str]  # url -> summary
    key_findings: Annotated[list[str], add]
    contradictions: list[dict]
    
    # Synthesis phase
    draft_sections: dict[str, str]
    final_report: Optional[str]
    citations: list[str]
    
    # Control
    iteration: int
    max_iterations: int
    user_feedback: Optional[str]
```

**3. Graph Design:**

```
+-------+
| START |
+---+---+
    |
+---v-----------+
| UNDERSTAND    |
| QUESTION      |
+---+-----------+
    |
+---v-----------+
| PLAN          |
| RESEARCH      |
+---+-----------+
    |
+---v-----------+       +---------------+
| SEARCH        |<------| MORE SOURCES  |
| SOURCES       |       | NEEDED?       |
+---+-----------+       +-------^-------+
    |                           |
+---v-----------+               |
| EVALUATE      +---------------+
| SOURCES       |
+---+-----------+
    |
+---v-----------+
| ANALYZE       |
| SOURCES       |
+---+-----------+
    |
+---v-----------+       +---------------+
| SYNTHESIZE    |<------| REFINE?       |
| FINDINGS      |       +-------^-------+
+---+-----------+               |
    |                           |
+---v-----------+               |
| DRAFT         |               |
| REPORT        +---------------+
+---+-----------+
    |
+---v-----------+
| HUMAN REVIEW  |  <-- INTERRUPT HERE
+---+-----------+
    |
+---v-----------+
| FINALIZE      |
+---+-----------+
    |
+---v---+
|  END  |
+-------+
```

**4. Implementation:**

```python
# Tools for research
tools = [
    web_search_tool,      # Search web
    arxiv_search_tool,    # Search academic papers
    url_reader_tool,      # Read URL content
    pdf_reader_tool,      # Read PDFs
]

def plan_research(state):
    """Generate search queries based on research question."""
    response = llm.invoke(f"""
    Research question: {state['research_question']}
    
    Generate 3-5 search queries that would help answer this question.
    Consider:
    - Main concepts
    - Related terms
    - Academic vs web searches
    
    Return as JSON list of strings.
    """)
    
    queries = json.loads(response.content)
    return {"search_queries": queries}

def search_sources(state):
    """Execute search queries and collect sources."""
    all_sources = []
    
    for query in state["search_queries"]:
        # Web search
        web_results = web_search_tool.invoke(query)
        
        # Academic search
        arxiv_results = arxiv_search_tool.invoke(query)
        
        all_sources.extend(web_results + arxiv_results)
    
    # Score relevance
    scored = score_relevance(all_sources, state["research_question"])
    
    return {
        "sources": scored[:10],  # Top 10
        "iteration": state["iteration"] + 1
    }

def evaluate_sources(state):
    """Decide if more sources are needed."""
    if state["iteration"] >= state["max_iterations"]:
        return "analyze"
    
    coverage = assess_coverage(state["sources"], state["research_question"])
    
    if coverage > 0.8:
        return "analyze"
    return "search_more"

def analyze_sources(state):
    """Deep analysis of each source."""
    summaries = {}
    findings = []
    
    for source in state["sources"]:
        # Summarize each source
        summary = llm.invoke(f"""
        Summarize this content in relation to: {state['research_question']}
        
        Content: {source.content[:5000]}
        
        Include:
        - Main points
        - Key data/statistics
        - Methodology (if research)
        """)
        
        summaries[source.url] = summary.content
        
        # Extract key findings
        finding = llm.invoke(f"""
        What are the key findings from this source?
        Source: {summary.content}
        
        Return as bullet points.
        """)
        
        findings.append(finding.content)
    
    return {
        "summaries": summaries,
        "key_findings": findings
    }

def synthesize_findings(state):
    """Synthesize all findings into coherent sections."""
    all_findings = "\n".join(state["key_findings"])
    
    synthesis = llm.invoke(f"""
    Research question: {state['research_question']}
    
    Key findings from sources:
    {all_findings}
    
    Synthesize these into:
    1. Main conclusions
    2. Supporting evidence
    3. Contradictions or debates
    4. Gaps in current research
    """)
    
    return {
        "draft_sections": {
            "synthesis": synthesis.content
        }
    }

def draft_report(state):
    """Create final report with citations."""
    report = llm.invoke(f"""
    Create a research report on: {state['research_question']}
    
    Based on:
    {state['draft_sections']}
    
    Include:
    - Executive summary
    - Background
    - Findings
    - Conclusion
    - References
    
    Use proper citations.
    """)
    
    citations = [s.citation for s in state["sources"]]
    
    return {
        "final_report": report.content,
        "citations": citations
    }

# Build graph
graph = StateGraph(ResearchState)

graph.add_node("understand", understand_question)
graph.add_node("plan", plan_research)
graph.add_node("search", search_sources)
graph.add_node("evaluate", lambda s: s)  # Just for routing
graph.add_node("analyze", analyze_sources)
graph.add_node("synthesize", synthesize_findings)
graph.add_node("draft", draft_report)
graph.add_node("finalize", finalize_report)

graph.add_edge(START, "understand")
graph.add_edge("understand", "plan")
graph.add_edge("plan", "search")
graph.add_edge("search", "evaluate")
graph.add_conditional_edges("evaluate", evaluate_sources, {
    "analyze": "analyze",
    "search_more": "plan"  # Generate new queries
})
graph.add_edge("analyze", "synthesize")
graph.add_edge("synthesize", "draft")
graph.add_edge("draft", "finalize")
graph.add_edge("finalize", END)

# Compile with human review point
app = graph.compile(
    checkpointer=PostgresSaver(conn),
    interrupt_before=["finalize"]  # Human reviews before final
)
```

---

## Design Question 3: Multi-Agent Code Review System [HARD]

### Problem Statement

Design a code review system with multiple specialized agents:
- Security reviewer
- Performance reviewer
- Style/best practices reviewer
- A coordinator that synthesizes feedback

### Solution Approach

**1. Architecture:**

```
                    +----------------+
                    |  COORDINATOR   |
                    +-------+--------+
                            |
          +-----------------+-----------------+
          |                 |                 |
    +-----v-----+     +-----v-----+     +-----v-----+
    | SECURITY  |     |PERFORMANCE|     |   STYLE   |
    | REVIEWER  |     | REVIEWER  |     | REVIEWER  |
    +-----------+     +-----------+     +-----------+
          |                 |                 |
          +-----------------+-----------------+
                            |
                    +-------v--------+
                    |   SYNTHESIZER  |
                    +----------------+
```

**2. State Design:**

```python
class ReviewFinding(BaseModel):
    file: str
    line: int
    severity: Literal["critical", "high", "medium", "low", "info"]
    category: str
    message: str
    suggestion: Optional[str]

class CodeReviewState(TypedDict):
    # Input
    pull_request_id: str
    diff: str
    files_changed: list[str]
    
    # Review results (each reviewer adds to these)
    security_findings: Annotated[list[ReviewFinding], add]
    performance_findings: Annotated[list[ReviewFinding], add]
    style_findings: Annotated[list[ReviewFinding], add]
    
    # Coordination
    files_to_review: list[str]
    review_complete: dict[str, bool]
    
    # Output
    summary: Optional[str]
    approval_status: Literal["approved", "changes_requested", "needs_discussion"]
    priority_issues: list[ReviewFinding]
```

**3. Parallel Review Implementation:**

```python
from langgraph.constants import Send

def coordinator(state):
    """Distribute files to specialized reviewers."""
    # Analyze what types of review are needed
    file_types = categorize_files(state["files_changed"])
    
    sends = []
    
    # Security review for all files
    sends.append(Send("security_reviewer", {
        "diff": state["diff"],
        "files": state["files_changed"]
    }))
    
    # Performance review for backend files
    if file_types["backend"]:
        sends.append(Send("performance_reviewer", {
            "diff": state["diff"],
            "files": file_types["backend"]
        }))
    
    # Style review for all files
    sends.append(Send("style_reviewer", {
        "diff": state["diff"],
        "files": state["files_changed"]
    }))
    
    return sends

def security_reviewer(state):
    """Review for security vulnerabilities."""
    system_prompt = """You are a security expert reviewing code.
    Look for:
    - SQL injection
    - XSS vulnerabilities
    - Authentication/authorization issues
    - Sensitive data exposure
    - Insecure dependencies
    - Input validation issues
    """
    
    findings = []
    
    for file in state["files"]:
        file_diff = extract_file_diff(state["diff"], file)
        
        review = security_llm.invoke(
            f"{system_prompt}\n\nReview this diff:\n{file_diff}"
        )
        
        parsed_findings = parse_findings(review.content, "security")
        findings.extend(parsed_findings)
    
    return {"security_findings": findings}

def performance_reviewer(state):
    """Review for performance issues."""
    system_prompt = """You are a performance expert reviewing code.
    Look for:
    - N+1 queries
    - Missing indexes
    - Inefficient algorithms
    - Memory leaks
    - Unnecessary computations
    - Blocking operations
    """
    
    findings = []
    
    for file in state["files"]:
        file_diff = extract_file_diff(state["diff"], file)
        
        review = performance_llm.invoke(
            f"{system_prompt}\n\nReview this diff:\n{file_diff}"
        )
        
        parsed_findings = parse_findings(review.content, "performance")
        findings.extend(parsed_findings)
    
    return {"performance_findings": findings}

def synthesizer(state):
    """Combine all findings into coherent review."""
    all_findings = (
        state["security_findings"] +
        state["performance_findings"] +
        state["style_findings"]
    )
    
    # Prioritize
    critical = [f for f in all_findings if f.severity == "critical"]
    high = [f for f in all_findings if f.severity == "high"]
    
    # Determine approval status
    if critical:
        status = "changes_requested"
    elif len(high) > 3:
        status = "changes_requested"
    elif high:
        status = "needs_discussion"
    else:
        status = "approved"
    
    # Generate summary
    summary = llm.invoke(f"""
    Summarize this code review:
    
    Security issues: {len(state['security_findings'])}
    Performance issues: {len(state['performance_findings'])}
    Style issues: {len(state['style_findings'])}
    
    Critical issues:
    {format_findings(critical)}
    
    Provide:
    1. Overall assessment
    2. Must-fix items
    3. Recommendations
    """)
    
    return {
        "summary": summary.content,
        "approval_status": status,
        "priority_issues": critical + high
    }

# Build graph
graph = StateGraph(CodeReviewState)

graph.add_node("coordinator", coordinator)
graph.add_node("security_reviewer", security_reviewer)
graph.add_node("performance_reviewer", performance_reviewer)
graph.add_node("style_reviewer", style_reviewer)
graph.add_node("synthesizer", synthesizer)

graph.add_edge(START, "coordinator")
# Coordinator uses Send to dispatch to reviewers in parallel
graph.add_edge("security_reviewer", "synthesizer")
graph.add_edge("performance_reviewer", "synthesizer")
graph.add_edge("style_reviewer", "synthesizer")
graph.add_edge("synthesizer", END)
```

---

## Design Question 4: Document Processing Pipeline [MEDIUM]

### Problem Statement

Design a document processing system that:
- Accepts multiple document formats (PDF, DOCX, TXT)
- Extracts and structures information
- Validates extracted data
- Outputs to multiple formats

### Solution Approach

```
+-------+     +--------+     +----------+     +--------+     +--------+
| INPUT |---->| PARSE  |---->| EXTRACT  |---->|VALIDATE|---->| OUTPUT |
| DOCS  |     |        |     |          |     |        |     |        |
+-------+     +--------+     +----------+     +--------+     +--------+
                                  |
                           +------v------+
                           | ENTITY      |
                           | EXTRACTION  |
                           +-------------+
```

**State Design:**

```python
class DocumentState(TypedDict):
    # Input
    input_path: str
    document_type: str
    raw_content: str
    
    # Parsing
    parsed_text: str
    metadata: dict
    pages: list[str]
    
    # Extraction
    entities: dict[str, list[str]]  # {"person": [...], "org": [...]}
    key_values: dict[str, str]
    tables: list[dict]
    
    # Validation
    validation_errors: Annotated[list[str], add]
    confidence_scores: dict[str, float]
    needs_human_review: bool
    
    # Output
    structured_output: dict
    output_format: str
```

---

## Design Question 5: Autonomous Task Executor [HARD]

### Problem Statement

Design an agent that can:
- Accept high-level tasks in natural language
- Break down into subtasks
- Execute subtasks with appropriate tools
- Handle failures and retries
- Report progress

### Solution Approach

**Architecture:**

```
+----------------+
| TASK PLANNER   |
+-------+--------+
        |
+-------v--------+
| TASK QUEUE     |
+-------+--------+
        |
+-------v--------+     +-------------+
| TASK EXECUTOR  |<--->| TOOL SUITE  |
+-------+--------+     +-------------+
        |
+-------v--------+
| RESULT CHECKER |
+-------+--------+
        |
   +----+----+
   |         |
SUCCESS   RETRY
```

**State Design:**

```python
class Task(BaseModel):
    id: str
    description: str
    status: Literal["pending", "in_progress", "completed", "failed"]
    dependencies: list[str]
    result: Optional[str]
    attempts: int
    max_attempts: int = 3

class TaskExecutorState(TypedDict):
    # Input
    original_request: str
    
    # Planning
    tasks: list[Task]
    task_graph: dict[str, list[str]]  # task_id -> dependent_ids
    
    # Execution
    current_task_id: Optional[str]
    completed_tasks: Annotated[list[str], add]
    failed_tasks: list[str]
    
    # Progress
    progress_percent: float
    status_updates: Annotated[list[str], add]
    
    # Output
    final_result: Optional[str]
    execution_log: list[dict]
```

**Key Implementation:**

```python
def task_planner(state):
    """Break down request into tasks."""
    plan = llm.invoke(f"""
    Break down this request into executable subtasks:
    
    Request: {state['original_request']}
    
    For each task provide:
    - ID (task_1, task_2, etc.)
    - Description
    - Dependencies (which tasks must complete first)
    
    Return as JSON.
    """)
    
    tasks = parse_task_plan(plan.content)
    task_graph = build_dependency_graph(tasks)
    
    return {
        "tasks": tasks,
        "task_graph": task_graph,
        "status_updates": [f"Planned {len(tasks)} tasks"]
    }

def task_selector(state):
    """Select next executable task."""
    completed = set(state["completed_tasks"])
    
    for task in state["tasks"]:
        if task.status == "pending":
            # Check if dependencies are met
            deps_met = all(d in completed for d in task.dependencies)
            if deps_met:
                return {"current_task_id": task.id}
    
    # No executable tasks
    if len(completed) == len(state["tasks"]):
        return {"current_task_id": None}  # All done
    
    # Some tasks failed, blocking others
    return {"current_task_id": "blocked"}

def task_executor(state):
    """Execute current task."""
    task = get_task_by_id(state["tasks"], state["current_task_id"])
    
    # Update task status
    task.status = "in_progress"
    task.attempts += 1
    
    try:
        # Execute with appropriate tools
        result = agent_with_tools.invoke({
            "task": task.description,
            "context": get_completed_results(state)
        })
        
        task.status = "completed"
        task.result = result
        
        return {
            "completed_tasks": [task.id],
            "status_updates": [f"Completed: {task.description}"],
            "progress_percent": calculate_progress(state)
        }
        
    except Exception as e:
        if task.attempts >= task.max_attempts:
            task.status = "failed"
            return {
                "failed_tasks": [task.id],
                "status_updates": [f"Failed: {task.description}: {e}"]
            }
        else:
            task.status = "pending"  # Will retry
            return {
                "status_updates": [f"Retrying: {task.description}"]
            }

def route_after_task(state):
    """Determine next step after task execution."""
    if state["current_task_id"] is None:
        return "finalize"
    if state["current_task_id"] == "blocked":
        return "handle_blocked"
    return "select_next"

# Graph with retry loop
graph = StateGraph(TaskExecutorState)

graph.add_node("plan", task_planner)
graph.add_node("select", task_selector)
graph.add_node("execute", task_executor)
graph.add_node("finalize", finalize_results)
graph.add_node("handle_blocked", handle_blocked_tasks)

graph.add_edge(START, "plan")
graph.add_edge("plan", "select")
graph.add_conditional_edges("select", route_after_task)
graph.add_edge("execute", "select")  # Loop back
graph.add_edge("finalize", END)
graph.add_edge("handle_blocked", END)
```

---

## Design Tips for Interviews

### 1. Always Start with Requirements Clarification

- What's the expected load/scale?
- What's the latency requirement?
- What failure modes are acceptable?
- What's the budget for LLM calls?

### 2. Draw the Graph First

Use ASCII art to show:
- Nodes and their purposes
- Edge connections
- Conditional routing
- Cycles if any

### 3. Define State Early

- What data flows through the system?
- Which fields need reducers?
- What's the minimal state needed?

### 4. Consider Production Aspects

- Persistence (checkpointing)
- Streaming
- Error handling
- Monitoring
- Cost control

### 5. Discuss Trade-offs

- Monolithic vs multi-agent
- Latency vs quality
- Cost vs capability
- Simplicity vs flexibility
