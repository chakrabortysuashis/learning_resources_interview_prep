"""
Human-in-the-Loop (HITL) Example in LangGraph
==============================================

This example demonstrates a content approval workflow where:
1. AI generates a draft email response
2. Human reviews and approves/modifies/rejects
3. Workflow continues based on human decision

Real-World Scenario: Customer Support Email Response System
"""

# ============================================================================
# IMPORTS
# ============================================================================
from typing import TypedDict, Literal, Optional, Annotated
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.memory import MemorySaver
from langgraph.types import interrupt, Command
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage
import os

# ============================================================================
# STATE DEFINITION
# ============================================================================

class EmailApprovalState(TypedDict):
    """
    State for the email approval workflow.

    Tracks the customer query, AI-generated draft, human decisions,
    and the final approved email.
    """
    # Input: Customer's original query
    customer_query: str

    # AI-generated draft email
    draft_email: Optional[str]

    # Human review results
    human_decision: Optional[Literal["approve", "edit", "reject"]]
    human_edits: Optional[str]
    human_feedback: Optional[str]

    # Final output
    final_email: Optional[str]
    status: Literal["pending", "approved", "rejected", "sent"]


# ============================================================================
# NODE FUNCTIONS
# ============================================================================

def generate_draft(state: EmailApprovalState) -> dict:
    """
    Generate a draft email response using AI.

    This node uses an LLM to create a professional response
    to the customer's query.

    Flow:
    +-------------------+
    | Customer Query    |
    +--------+----------+
             |
             v
    +-------------------+
    |   LLM Generation  |
    +--------+----------+
             |
             v
    +-------------------+
    |   Draft Email     |
    +-------------------+
    """
    print("\n[Node: generate_draft] Generating email draft...")

    # In production, use actual LLM
    # llm = ChatOpenAI(model="gpt-4")
    # response = llm.invoke([
    #     SystemMessage(content="You are a helpful customer support agent..."),
    #     HumanMessage(content=f"Generate a response to: {state['customer_query']}")
    # ])
    # draft = response.content

    # For demo: Simulated draft
    customer_query = state["customer_query"]
    draft = f"""
Dear Valued Customer,

Thank you for reaching out to us regarding: "{customer_query}"

We understand your concern and want to assure you that we take
all customer feedback seriously. Our team has reviewed your case
and would like to offer the following resolution:

1. We will process your request within 24-48 business hours
2. A dedicated support specialist will follow up with you
3. We're offering a 15% discount on your next purchase as a goodwill gesture

Please don't hesitate to reach out if you have any further questions.

Best regards,
Customer Support Team
    """.strip()

    print(f"[Node: generate_draft] Draft generated ({len(draft)} chars)")

    return {
        "draft_email": draft,
        "status": "pending"
    }


def human_review(state: EmailApprovalState) -> dict:
    """
    Human review node with interrupt.

    This node pauses execution and waits for human input.
    The human can approve, edit, or reject the draft.

    Interrupt Flow:
    +-------------------+
    |   Draft Email     |
    +--------+----------+
             |
             v
    +-------------------+
    |    INTERRUPT      |  <-- Execution pauses here
    |  (Human Review)   |
    +--------+----------+
             |
             v
    +-------------------+
    |  Human Decision:  |
    |  - approve        |
    |  - edit           |
    |  - reject         |
    +-------------------+
    """
    print("\n[Node: human_review] Requesting human review...")
    print("=" * 60)
    print("DRAFT EMAIL FOR REVIEW:")
    print("=" * 60)
    print(state["draft_email"])
    print("=" * 60)

    # ========================================================================
    # INTERRUPT: Pause execution and wait for human input
    # ========================================================================
    # The interrupt() function:
    # 1. Saves current state to checkpoint
    # 2. Returns control to the caller
    # 3. Resumes when Command(resume=...) is provided

    human_response = interrupt({
        "type": "email_review",
        "draft": state["draft_email"],
        "prompt": "Please review this email. Options: approve, edit, reject",
        "required_fields": ["decision"],
        "optional_fields": ["edits", "feedback"]
    })

    # This code runs AFTER human provides input via Command(resume=...)
    print(f"\n[Node: human_review] Human responded: {human_response['decision']}")

    return {
        "human_decision": human_response.get("decision"),
        "human_edits": human_response.get("edits"),
        "human_feedback": human_response.get("feedback")
    }


def process_approval(state: EmailApprovalState) -> dict:
    """
    Process approved email - ready to send.

    +-------------------+
    |  Human: APPROVE   |
    +--------+----------+
             |
             v
    +-------------------+
    |  Mark as Ready    |
    |    to Send        |
    +-------------------+
    """
    print("\n[Node: process_approval] Email approved!")

    return {
        "final_email": state["draft_email"],
        "status": "approved"
    }


def process_edit(state: EmailApprovalState) -> dict:
    """
    Apply human edits to the draft.

    +-------------------+
    |   Human: EDIT     |
    +--------+----------+
             |
             v
    +-------------------+
    |  Apply Edits to   |
    |    Draft Email    |
    +-------------------+
    """
    print("\n[Node: process_edit] Applying human edits...")

    # Use human's edited version
    edited_email = state.get("human_edits", state["draft_email"])

    return {
        "final_email": edited_email,
        "status": "approved"
    }


def process_rejection(state: EmailApprovalState) -> dict:
    """
    Handle rejected draft - may need regeneration.

    +-------------------+
    |  Human: REJECT    |
    +--------+----------+
             |
             v
    +-------------------+
    |   Log Feedback    |
    |  Request New Draft|
    +-------------------+
    """
    print("\n[Node: process_rejection] Email rejected!")
    print(f"Feedback: {state.get('human_feedback', 'No feedback provided')}")

    return {
        "final_email": None,
        "status": "rejected"
    }


def send_email(state: EmailApprovalState) -> dict:
    """
    Send the approved email (simulated).

    +-------------------+
    |  Approved Email   |
    +--------+----------+
             |
             v
    +-------------------+
    |   Send via SMTP   |
    |   (simulated)     |
    +-------------------+
    """
    print("\n[Node: send_email] Sending email...")
    print("=" * 60)
    print("FINAL EMAIL SENT:")
    print("=" * 60)
    print(state["final_email"])
    print("=" * 60)

    return {"status": "sent"}


# ============================================================================
# ROUTING FUNCTION
# ============================================================================

def route_after_review(state: EmailApprovalState) -> str:
    """
    Route to appropriate node based on human decision.

    Conditional Routing:

                    +-------------------+
                    | Human Decision    |
                    +--------+----------+
                             |
           +-----------------+-----------------+
           |                 |                 |
           v                 v                 v
    +------------+    +------------+    +------------+
    |  approve   |    |    edit    |    |   reject   |
    +------------+    +------------+    +------------+
           |                 |                 |
           v                 v                 v
    +------------+    +------------+    +------------+
    | process_   |    | process_   |    | process_   |
    | approval   |    | edit       |    | rejection  |
    +------------+    +------------+    +------------+
    """
    decision = state.get("human_decision")

    if decision == "approve":
        return "process_approval"
    elif decision == "edit":
        return "process_edit"
    else:  # reject
        return "process_rejection"


def route_after_processing(state: EmailApprovalState) -> str:
    """
    Route after processing: send if approved, end if rejected.
    """
    if state["status"] == "approved":
        return "send_email"
    else:
        return END


# ============================================================================
# BUILD THE GRAPH
# ============================================================================

def build_email_approval_graph():
    """
    Build the email approval workflow graph.

    Complete Flow:

    +------------------------------------------------------------------+
    |                    EMAIL APPROVAL WORKFLOW                        |
    +------------------------------------------------------------------+
    |                                                                   |
    |   +-------+     +----------+     +----------+                     |
    |   | START |---->| generate |---->|  human   |                     |
    |   +-------+     |  draft   |     |  review  |                     |
    |                 +----------+     +----+-----+                     |
    |                                       |                           |
    |                     +-----------------+-----------------+         |
    |                     |                 |                 |         |
    |                     v                 v                 v         |
    |              +----------+      +----------+      +----------+     |
    |              | process  |      | process  |      | process  |     |
    |              | approval |      |   edit   |      | rejection|     |
    |              +----+-----+      +----+-----+      +----+-----+     |
    |                   |                 |                 |           |
    |                   v                 v                 v           |
    |              +----------+      +----------+      +-------+        |
    |              |   send   |      |   send   |      |  END  |        |
    |              |  email   |      |  email   |      +-------+        |
    |              +----+-----+      +----+-----+                       |
    |                   |                 |                             |
    |                   v                 v                             |
    |              +-------+         +-------+                          |
    |              |  END  |         |  END  |                          |
    |              +-------+         +-------+                          |
    |                                                                   |
    +------------------------------------------------------------------+
    """
    # Create the graph builder
    builder = StateGraph(EmailApprovalState)

    # Add nodes
    builder.add_node("generate_draft", generate_draft)
    builder.add_node("human_review", human_review)
    builder.add_node("process_approval", process_approval)
    builder.add_node("process_edit", process_edit)
    builder.add_node("process_rejection", process_rejection)
    builder.add_node("send_email", send_email)

    # Add edges
    builder.add_edge(START, "generate_draft")
    builder.add_edge("generate_draft", "human_review")

    # Conditional routing after human review
    builder.add_conditional_edges(
        "human_review",
        route_after_review,
        {
            "process_approval": "process_approval",
            "process_edit": "process_edit",
            "process_rejection": "process_rejection"
        }
    )

    # Routing after processing
    builder.add_conditional_edges(
        "process_approval",
        route_after_processing,
        {"send_email": "send_email", END: END}
    )
    builder.add_conditional_edges(
        "process_edit",
        route_after_processing,
        {"send_email": "send_email", END: END}
    )
    builder.add_edge("process_rejection", END)
    builder.add_edge("send_email", END)

    # Compile with checkpointer (REQUIRED for interrupts)
    checkpointer = MemorySaver()
    graph = builder.compile(checkpointer=checkpointer)

    return graph


# ============================================================================
# DEMONSTRATION
# ============================================================================

def demo_approval_workflow():
    """
    Demonstrate the approval workflow with different human decisions.
    """
    print("\n" + "=" * 70)
    print("HUMAN-IN-THE-LOOP DEMO: Email Approval Workflow")
    print("=" * 70)

    graph = build_email_approval_graph()

    # Configuration with thread_id for persistence
    config = {"configurable": {"thread_id": "email-thread-001"}}

    # ========================================================================
    # STEP 1: Start workflow - will pause at human_review
    # ========================================================================
    print("\n>>> STEP 1: Starting workflow with customer query...")

    initial_state = {
        "customer_query": "I received a damaged product and need a refund",
        "draft_email": None,
        "human_decision": None,
        "human_edits": None,
        "human_feedback": None,
        "final_email": None,
        "status": "pending"
    }

    # This will run until it hits the interrupt in human_review
    result = graph.invoke(initial_state, config)

    # At this point, execution is paused waiting for human input
    print("\n>>> Workflow paused at human review. State saved to checkpoint.")
    print(f">>> Current status: {result.get('status', 'interrupted')}")

    # ========================================================================
    # STEP 2: Simulate human approval
    # ========================================================================
    print("\n>>> STEP 2: Human APPROVES the email...")

    # Resume with approval
    result = graph.invoke(
        Command(resume={
            "decision": "approve",
            "feedback": "Looks professional and addresses the issue well."
        }),
        config
    )

    print(f"\n>>> Final status: {result['status']}")

    # ========================================================================
    # DEMO: Different human decisions
    # ========================================================================

    # Demo: Edit flow
    print("\n" + "=" * 70)
    print("DEMO: Human EDITS the email")
    print("=" * 70)

    config_edit = {"configurable": {"thread_id": "email-thread-002"}}

    # Start workflow
    result = graph.invoke(initial_state, config_edit)

    # Resume with edits
    edited_email = """
Dear Valued Customer,

I sincerely apologize for the damaged product you received.

Here's what we'll do immediately:
1. Process a FULL refund within 24 hours
2. Send a replacement at no extra cost
3. Apply a 20% discount code for your next purchase

You don't need to return the damaged item.

Please accept our apologies for this inconvenience.

Warm regards,
Sarah - Customer Support Manager
    """.strip()

    result = graph.invoke(
        Command(resume={
            "decision": "edit",
            "edits": edited_email,
            "feedback": "Made it more personal and increased the discount."
        }),
        config_edit
    )

    print(f"\n>>> Final status: {result['status']}")

    # Demo: Rejection flow
    print("\n" + "=" * 70)
    print("DEMO: Human REJECTS the email")
    print("=" * 70)

    config_reject = {"configurable": {"thread_id": "email-thread-003"}}

    # Start workflow
    result = graph.invoke(initial_state, config_reject)

    # Resume with rejection
    result = graph.invoke(
        Command(resume={
            "decision": "reject",
            "feedback": "Tone is too generic. Need to acknowledge the specific issue more directly."
        }),
        config_reject
    )

    print(f"\n>>> Final status: {result['status']}")


# ============================================================================
# ALTERNATIVE: Using interrupt_before/interrupt_after
# ============================================================================

def build_graph_with_interrupt_config():
    """
    Alternative approach: Configure interrupts at graph compilation.

    Instead of using interrupt() inside nodes, you can configure
    automatic interrupts before or after specific nodes.
    """

    def simple_generate(state):
        """Generate draft without internal interrupt."""
        return {
            "draft_email": f"Response to: {state['customer_query']}",
            "status": "pending"
        }

    def simple_process(state):
        """Process after human reviews externally."""
        return {
            "final_email": state["draft_email"],
            "status": "approved"
        }

    builder = StateGraph(EmailApprovalState)
    builder.add_node("generate", simple_generate)
    builder.add_node("process", simple_process)

    builder.add_edge(START, "generate")
    builder.add_edge("generate", "process")
    builder.add_edge("process", END)

    checkpointer = MemorySaver()

    # Automatically interrupt AFTER generate node
    # Human reviews externally, then resumes
    graph = builder.compile(
        checkpointer=checkpointer,
        interrupt_after=["generate"]  # Pause after draft generation
    )

    return graph


# ============================================================================
# INTERVIEW TIP
# ============================================================================
"""
+--------------------------------------------------------------------------+
|                              INTERVIEW TIP                                |
+--------------------------------------------------------------------------+
| Q: "How do you handle long-running HITL workflows?"                       |
|                                                                           |
| A: Key strategies:                                                        |
|    1. Use persistent checkpointers (SQLite/PostgreSQL, not memory)        |
|    2. Implement timeout handlers with graceful degradation                |
|    3. Add notification systems (email, Slack) when review needed          |
|    4. Build admin dashboards to track pending reviews                     |
|    5. Consider async patterns for non-blocking workflows                  |
|                                                                           |
| Example timeout handling:                                                 |
|    - If no response in 24h, escalate to manager                           |
|    - If no response in 48h, auto-approve with audit log                   |
|    - Always maintain audit trail of decisions                             |
+--------------------------------------------------------------------------+
"""


# ============================================================================
# MAIN EXECUTION
# ============================================================================

if __name__ == "__main__":
    demo_approval_workflow()

    print("\n" + "=" * 70)
    print("KEY TAKEAWAYS")
    print("=" * 70)
    print("""
    1. Use interrupt() to pause execution and wait for human input
    2. Use Command(resume=...) to provide human input and continue
    3. ALWAYS use a checkpointer - interrupts require state persistence
    4. Use unique thread_id per workflow instance
    5. Configure interrupt_before/interrupt_after for node-level control

    Production Considerations:
    - Replace MemorySaver with SqliteSaver or PostgresSaver
    - Add timeout handling for long-pending reviews
    - Build admin UI for review queue management
    - Log all human decisions for audit trails
    """)
