"""
Time Travel Examples in LangGraph
=================================

This module demonstrates time travel capabilities:
1. Viewing state history
2. Replaying from checkpoints
3. Implementing undo/redo
4. Forking conversations
5. Debugging with time travel

Real-World Scenario: AI Writing Assistant with Edit History
"""

# ============================================================================
# IMPORTS
# ============================================================================
from typing import TypedDict, Optional, List, Annotated
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.memory import MemorySaver
from langchain_core.messages import HumanMessage, AIMessage, BaseMessage
import operator
from datetime import datetime

# ============================================================================
# STATE DEFINITION
# ============================================================================

class WritingState(TypedDict):
    """
    State for the writing assistant.

    Tracks document drafts and revision history.
    """
    # Document content
    title: str
    current_draft: str

    # Revision tracking
    revision_number: int
    revision_notes: Optional[str]

    # Messages for interaction
    messages: Annotated[List[BaseMessage], operator.add]

    # Metadata
    last_action: str


# ============================================================================
# NODE FUNCTIONS
# ============================================================================

def process_instruction(state: WritingState) -> dict:
    """
    Process user's writing instruction.

    +-------------------+
    |  User Instruction |
    +--------+----------+
             |
             v
    +-------------------+
    |  Parse Intent:    |
    |  - Write new      |
    |  - Edit existing  |
    |  - Expand section |
    +-------------------+
    """
    messages = state.get("messages", [])
    latest = messages[-1].content if messages else ""

    # Determine action type
    action = "write"
    if any(word in latest.lower() for word in ["edit", "change", "modify", "fix"]):
        action = "edit"
    elif any(word in latest.lower() for word in ["expand", "more", "detail", "elaborate"]):
        action = "expand"
    elif any(word in latest.lower() for word in ["shorten", "summarize", "condense"]):
        action = "shorten"

    print(f"[process_instruction] Action: {action}")

    return {"last_action": action}


def generate_content(state: WritingState) -> dict:
    """
    Generate or modify document content.

    +-------------------+
    |  Current Draft    |
    |  + Instructions   |
    +--------+----------+
             |
             v
    +-------------------+
    |   LLM Generation  |
    +--------+----------+
             |
             v
    +-------------------+
    |   Updated Draft   |
    +-------------------+
    """
    action = state.get("last_action", "write")
    current_draft = state.get("current_draft", "")
    revision = state.get("revision_number", 0)
    messages = state.get("messages", [])
    latest_instruction = messages[-1].content if messages else "Write something"

    # Simulate content generation (would use LLM in production)
    if action == "write":
        new_draft = f"""
# {state.get('title', 'Untitled Document')}

This is the initial draft based on your request: "{latest_instruction}"

## Introduction
[Generated introduction content]

## Main Section
[Generated main content]

## Conclusion
[Generated conclusion]
        """.strip()

    elif action == "edit":
        new_draft = current_draft + f"\n\n[EDITED based on: {latest_instruction}]"

    elif action == "expand":
        new_draft = current_draft + f"\n\n## Additional Details\n[Expanded content based on: {latest_instruction}]"

    elif action == "shorten":
        # Simulate shortening
        lines = current_draft.split("\n")
        new_draft = "\n".join(lines[:len(lines)//2]) + "\n[Shortened version]"

    else:
        new_draft = current_draft

    # Create AI response
    response = AIMessage(content=f"Done! I've {action}ed the document (Revision {revision + 1})")

    print(f"[generate_content] Created revision {revision + 1}")

    return {
        "current_draft": new_draft,
        "revision_number": revision + 1,
        "revision_notes": f"{action}: {latest_instruction[:50]}...",
        "messages": [response]
    }


# ============================================================================
# BUILD THE GRAPH
# ============================================================================

def build_writing_graph(checkpointer):
    """
    Build the writing assistant graph.

    Flow:
    +-------+     +---------+     +----------+     +-----+
    | START |---->| process |---->| generate |---->| END |
    +-------+     | instr.  |     | content  |     +-----+
                  +---------+     +----------+
    """
    builder = StateGraph(WritingState)

    builder.add_node("process_instruction", process_instruction)
    builder.add_node("generate_content", generate_content)

    builder.add_edge(START, "process_instruction")
    builder.add_edge("process_instruction", "generate_content")
    builder.add_edge("generate_content", END)

    return builder.compile(checkpointer=checkpointer)


# ============================================================================
# DEMO 1: STATE HISTORY
# ============================================================================

def demo_state_history():
    """
    Demonstrate viewing state history.

    Shows how to inspect all checkpoints for a thread.
    """
    print("\n" + "=" * 70)
    print("DEMO 1: Viewing State History")
    print("=" * 70)

    checkpointer = MemorySaver()
    graph = build_writing_graph(checkpointer)
    config = {"configurable": {"thread_id": "doc_001"}}

    # Create initial document
    print("\n--- Creating Document with Multiple Revisions ---")

    # Revision 1: Initial
    graph.invoke({
        "title": "My Research Paper",
        "current_draft": "",
        "revision_number": 0,
        "revision_notes": None,
        "messages": [HumanMessage(content="Write an introduction about AI")],
        "last_action": ""
    }, config)
    print("Revision 1: Initial draft created")

    # Revision 2: Expand
    graph.invoke({
        "messages": [HumanMessage(content="Expand the main section with more details")]
    }, config)
    print("Revision 2: Expanded content")

    # Revision 3: Edit
    graph.invoke({
        "messages": [HumanMessage(content="Edit the conclusion to be more impactful")]
    }, config)
    print("Revision 3: Edited conclusion")

    # Revision 4: Shorten
    graph.invoke({
        "messages": [HumanMessage(content="Shorten the introduction")]
    }, config)
    print("Revision 4: Shortened intro")

    # View complete history
    print("\n--- Complete State History ---")
    print(f"{'Checkpoint':<12} {'Revision':<10} {'Action':<10} {'Draft Length':<12}")
    print("-" * 50)

    for i, state in enumerate(graph.get_state_history(config)):
        revision = state.values.get("revision_number", 0)
        action = state.values.get("last_action", "N/A")
        draft_len = len(state.values.get("current_draft", ""))
        checkpoint_id = state.config["configurable"].get("checkpoint_id", "N/A")[:10]

        print(f"{checkpoint_id:<12} {revision:<10} {action:<10} {draft_len:<12}")

        if i >= 10:
            print("... (more checkpoints)")
            break

    print("\n[State History Demo Complete]")


# ============================================================================
# DEMO 2: REPLAY FROM CHECKPOINT
# ============================================================================

def demo_replay_from_checkpoint():
    """
    Demonstrate replaying from a specific checkpoint.

    Shows how to "time travel" back to a previous state.
    """
    print("\n" + "=" * 70)
    print("DEMO 2: Replay from Checkpoint")
    print("=" * 70)

    checkpointer = MemorySaver()
    graph = build_writing_graph(checkpointer)
    config = {"configurable": {"thread_id": "doc_002"}}

    # Create document with revisions
    print("\n--- Creating Document ---")

    # Initial
    graph.invoke({
        "title": "Product Announcement",
        "current_draft": "",
        "revision_number": 0,
        "revision_notes": None,
        "messages": [HumanMessage(content="Write a product announcement for our new AI feature")],
        "last_action": ""
    }, config)

    # Expand
    graph.invoke({
        "messages": [HumanMessage(content="Expand with technical details")]
    }, config)

    # Edit (let's say this was a mistake)
    graph.invoke({
        "messages": [HumanMessage(content="Edit to remove all technical jargon")]
    }, config)

    print("Created 3 revisions")

    # Get current state
    current = graph.get_state(config)
    print(f"\nCurrent revision: {current.values.get('revision_number')}")
    print(f"Current draft length: {len(current.values.get('current_draft', ''))}")

    # Find the checkpoint before the "mistake" (revision 2)
    print("\n--- Finding Checkpoint to Replay From ---")
    history = list(graph.get_state_history(config))

    target_checkpoint = None
    for state in history:
        if state.values.get("revision_number") == 2:
            target_checkpoint = state
            break

    if target_checkpoint:
        print(f"Found revision 2 checkpoint")

        # Create config to replay from that checkpoint
        replay_config = {
            "configurable": {
                "thread_id": "doc_002_replay",  # New thread for replay
                "checkpoint_id": target_checkpoint.config["configurable"]["checkpoint_id"]
            }
        }

        # Load the old state
        old_state = graph.get_state(replay_config)
        print(f"\nLoaded state from revision {old_state.values.get('revision_number')}")

        # Continue with different instructions
        print("\n--- Continuing with Different Instructions ---")
        result = graph.invoke({
            "messages": [HumanMessage(content="Edit to add customer testimonials instead")]
        }, replay_config)

        print(f"New revision: {result.get('revision_number')}")
        print(f"New action taken: {result.get('last_action')}")

    print("\n[Replay Demo Complete]")


# ============================================================================
# DEMO 3: UNDO/REDO IMPLEMENTATION
# ============================================================================

class UndoRedoManager:
    """
    Manager for undo/redo operations.

    +------------------------------------------------------------------+
    |                    UNDO/REDO STACK                                |
    +------------------------------------------------------------------+
    |                                                                   |
    |   History Stack (checkpoints):                                    |
    |   [CP1] -> [CP2] -> [CP3] -> [CP4*] <- Current                    |
    |                                                                   |
    |   Redo Stack (after undo):                                        |
    |   [CP4] <- Can redo to here                                       |
    |                                                                   |
    +------------------------------------------------------------------+
    """

    def __init__(self, graph, thread_id: str):
        self.graph = graph
        self.thread_id = thread_id
        self.base_config = {"configurable": {"thread_id": thread_id}}
        self.redo_stack = []
        self.current_checkpoint_id = None

    def _update_current(self):
        """Update current checkpoint reference."""
        state = self.graph.get_state(self.base_config)
        self.current_checkpoint_id = state.config["configurable"].get("checkpoint_id")

    def get_current_state(self):
        """Get current state values."""
        return self.graph.get_state(self.base_config)

    def can_undo(self) -> bool:
        """Check if undo is available."""
        history = list(self.graph.get_state_history(self.base_config))
        return len(history) > 1

    def can_redo(self) -> bool:
        """Check if redo is available."""
        return len(self.redo_stack) > 0

    def undo(self):
        """
        Undo the last action.

        +------------------------------------------------------------------+
        |   Before: [CP1] -> [CP2] -> [CP3*]                               |
        |   After:  [CP1] -> [CP2*]    (CP3 in redo stack)                 |
        +------------------------------------------------------------------+
        """
        history = list(self.graph.get_state_history(self.base_config))

        if len(history) < 2:
            print("Nothing to undo")
            return None

        # Current is history[0], previous is history[1]
        current = history[0]
        previous = history[1]

        # Save current to redo stack
        self.redo_stack.append(current)

        # Return previous state
        previous_config = {
            "configurable": {
                "thread_id": self.thread_id,
                "checkpoint_id": previous.config["configurable"]["checkpoint_id"]
            }
        }

        return self.graph.get_state(previous_config)

    def redo(self):
        """
        Redo the last undone action.

        +------------------------------------------------------------------+
        |   Before: [CP1] -> [CP2*]    (CP3 in redo stack)                 |
        |   After:  [CP1] -> [CP2] -> [CP3*]                               |
        +------------------------------------------------------------------+
        """
        if not self.redo_stack:
            print("Nothing to redo")
            return None

        # Pop from redo stack
        redo_state = self.redo_stack.pop()

        redo_config = {
            "configurable": {
                "thread_id": self.thread_id,
                "checkpoint_id": redo_state.config["configurable"]["checkpoint_id"]
            }
        }

        return self.graph.get_state(redo_config)

    def clear_redo_stack(self):
        """Clear redo stack (called when new action is taken)."""
        self.redo_stack = []


def demo_undo_redo():
    """
    Demonstrate undo/redo functionality.
    """
    print("\n" + "=" * 70)
    print("DEMO 3: Undo/Redo Implementation")
    print("=" * 70)

    checkpointer = MemorySaver()
    graph = build_writing_graph(checkpointer)
    thread_id = "doc_003"
    config = {"configurable": {"thread_id": thread_id}}

    # Initialize undo manager
    undo_manager = UndoRedoManager(graph, thread_id)

    # Create document
    print("\n--- Creating Document ---")

    graph.invoke({
        "title": "Team Update",
        "current_draft": "",
        "revision_number": 0,
        "revision_notes": None,
        "messages": [HumanMessage(content="Write a team update email")],
        "last_action": ""
    }, config)
    print("Action 1: Initial draft (revision 1)")

    graph.invoke({
        "messages": [HumanMessage(content="Expand with project milestones")]
    }, config)
    print("Action 2: Expanded (revision 2)")

    graph.invoke({
        "messages": [HumanMessage(content="Edit to add next steps")]
    }, config)
    print("Action 3: Added next steps (revision 3)")

    # Show current state
    current = undo_manager.get_current_state()
    print(f"\nCurrent: Revision {current.values.get('revision_number')}")

    # Perform undo
    print("\n--- Performing UNDO ---")
    previous = undo_manager.undo()
    if previous:
        print(f"After undo: Revision {previous.values.get('revision_number')}")
        print(f"Can undo again: {undo_manager.can_undo()}")
        print(f"Can redo: {undo_manager.can_redo()}")

    # Perform another undo
    print("\n--- Performing Second UNDO ---")
    previous = undo_manager.undo()
    if previous:
        print(f"After undo: Revision {previous.values.get('revision_number')}")

    # Perform redo
    print("\n--- Performing REDO ---")
    restored = undo_manager.redo()
    if restored:
        print(f"After redo: Revision {restored.values.get('revision_number')}")

    # Another redo
    print("\n--- Performing Second REDO ---")
    restored = undo_manager.redo()
    if restored:
        print(f"After redo: Revision {restored.values.get('revision_number')}")

    print("\n[Undo/Redo Demo Complete]")


# ============================================================================
# DEMO 4: FORKING CONVERSATIONS
# ============================================================================

def demo_fork_conversation():
    """
    Demonstrate forking a conversation to explore alternatives.

    +------------------------------------------------------------------+
    |                    CONVERSATION FORK                              |
    +------------------------------------------------------------------+
    |                                                                   |
    |   Original: [CP1]---[CP2]---[CP3]---[CP4]                         |
    |                        |                                          |
    |                        +---> Fork: [CP2']---[CP3']                |
    |                              (Different direction)                |
    |                                                                   |
    +------------------------------------------------------------------+
    """
    print("\n" + "=" * 70)
    print("DEMO 4: Forking Conversations")
    print("=" * 70)

    checkpointer = MemorySaver()
    graph = build_writing_graph(checkpointer)

    # Original thread
    original_config = {"configurable": {"thread_id": "doc_original"}}

    # Create original document
    print("\n--- Creating Original Document ---")

    graph.invoke({
        "title": "Marketing Copy",
        "current_draft": "",
        "revision_number": 0,
        "revision_notes": None,
        "messages": [HumanMessage(content="Write marketing copy for our SaaS product")],
        "last_action": ""
    }, original_config)
    print("Original: Created initial marketing copy")

    graph.invoke({
        "messages": [HumanMessage(content="Make it more professional and B2B focused")]
    }, original_config)
    print("Original: Made it B2B focused")

    # Get checkpoint to fork from (after initial creation)
    history = list(graph.get_state_history(original_config))
    fork_point = None
    for state in history:
        if state.values.get("revision_number") == 1:
            fork_point = state
            break

    print(f"\nForking from revision {fork_point.values.get('revision_number')}")

    # Create fork with different direction
    fork_config = {"configurable": {"thread_id": "doc_fork_casual"}}

    # Copy state from fork point to new thread
    graph.update_state(fork_config, fork_point.values)

    # Continue fork with different instructions
    print("\n--- Creating Alternative Version (Fork) ---")
    result = graph.invoke({
        "messages": [HumanMessage(content="Make it casual and fun, targeting consumers")]
    }, fork_config)
    print("Fork: Made it casual and consumer-focused")

    # Compare the two versions
    print("\n--- Comparing Versions ---")

    original_state = graph.get_state(original_config)
    fork_state = graph.get_state(fork_config)

    print(f"\nOriginal Thread:")
    print(f"  Revision: {original_state.values.get('revision_number')}")
    print(f"  Last action: {original_state.values.get('last_action')}")
    print(f"  Draft preview: {original_state.values.get('current_draft', '')[:100]}...")

    print(f"\nForked Thread:")
    print(f"  Revision: {fork_state.values.get('revision_number')}")
    print(f"  Last action: {fork_state.values.get('last_action')}")
    print(f"  Draft preview: {fork_state.values.get('current_draft', '')[:100]}...")

    print("\n[Fork Demo Complete]")


# ============================================================================
# DEMO 5: DEBUGGING WITH TIME TRAVEL
# ============================================================================

def demo_debugging():
    """
    Demonstrate using time travel for debugging.

    Scenario: Find when a bug was introduced.
    """
    print("\n" + "=" * 70)
    print("DEMO 5: Debugging with Time Travel")
    print("=" * 70)

    checkpointer = MemorySaver()
    graph = build_writing_graph(checkpointer)
    config = {"configurable": {"thread_id": "doc_debug"}}

    # Create document with a "bug" introduced
    print("\n--- Creating Document (Bug Introduced at Revision 3) ---")

    graph.invoke({
        "title": "Bug Report",
        "current_draft": "Initial content - everything fine",
        "revision_number": 0,
        "revision_notes": None,
        "messages": [HumanMessage(content="Write initial report")],
        "last_action": ""
    }, config)
    print("Revision 1: OK")

    graph.invoke({
        "messages": [HumanMessage(content="Add details section")]
    }, config)
    print("Revision 2: OK")

    # Simulate bug introduction
    # (In real scenario, this might be unexpected LLM output)
    current = graph.get_state(config)
    buggy_draft = current.values.get("current_draft", "") + "\n\n[BUG: Incorrect data inserted here]"
    graph.update_state(config, {"current_draft": buggy_draft, "revision_number": 3})
    print("Revision 3: BUG INTRODUCED!")

    graph.invoke({
        "messages": [HumanMessage(content="Finalize document")]
    }, config)
    print("Revision 4: Bug propagated")

    # Debug: Find when bug was introduced
    print("\n--- Debugging: Finding When Bug Was Introduced ---")

    for state in graph.get_state_history(config):
        revision = state.values.get("revision_number", 0)
        draft = state.values.get("current_draft", "")
        has_bug = "[BUG:" in draft

        status = "BUG FOUND!" if has_bug else "Clean"
        print(f"Revision {revision}: {status}")

        if has_bug and revision > 0:
            # Found the bug introduction point
            print(f"\n>>> Bug was introduced at revision {revision}")

            # Get the clean state (revision before)
            history = list(graph.get_state_history(config))
            for s in history:
                if s.values.get("revision_number") == revision - 1:
                    print(f">>> Clean state available at revision {revision - 1}")
                    print(f">>> Can replay from checkpoint: {s.config['configurable']['checkpoint_id'][:20]}...")
                    break
            break

    print("\n[Debugging Demo Complete]")


# ============================================================================
# INTERVIEW TIP
# ============================================================================
"""
+--------------------------------------------------------------------------+
|                              INTERVIEW TIP                                |
+--------------------------------------------------------------------------+
| Q: "How would you implement version control for AI-generated content?"    |
|                                                                           |
| A: Design approach:                                                       |
|                                                                           |
|    1. CHECKPOINT STRATEGY                                                 |
|       - Checkpoint after each meaningful change                           |
|       - Store metadata: timestamp, user, action type                      |
|       - Use persistent checkpointer (PostgreSQL)                          |
|                                                                           |
|    2. VERSION OPERATIONS                                                  |
|       - View history: get_state_history()                                 |
|       - Compare versions: diff between checkpoint states                  |
|       - Rollback: load specific checkpoint, fork to new thread            |
|       - Branch: fork from any checkpoint for A/B testing                  |
|                                                                           |
|    3. UI INTEGRATION                                                      |
|       - Timeline view of document revisions                               |
|       - Side-by-side diff view                                            |
|       - One-click restore with confirmation                               |
|       - Branch management interface                                       |
|                                                                           |
|    4. STORAGE OPTIMIZATION                                                |
|       - Store diffs instead of full state for large documents             |
|       - TTL-based cleanup for old checkpoints                             |
|       - Archive to cold storage after threshold                           |
+--------------------------------------------------------------------------+
"""


# ============================================================================
# MAIN EXECUTION
# ============================================================================

if __name__ == "__main__":
    demo_state_history()
    demo_replay_from_checkpoint()
    demo_undo_redo()
    demo_fork_conversation()
    demo_debugging()

    print("\n" + "=" * 70)
    print("KEY TAKEAWAYS")
    print("=" * 70)
    print("""
    1. STATE HISTORY:
       - get_state_history(config) returns all checkpoints
       - Iterate to find specific states
       - Each checkpoint has unique checkpoint_id

    2. REPLAY:
       - Load checkpoint with specific checkpoint_id
       - Use new thread_id to preserve original timeline
       - Continue execution from any point

    3. UNDO/REDO:
       - Navigate checkpoint chain for undo
       - Maintain redo stack for undone checkpoints
       - Clear redo stack on new user actions

    4. FORKING:
       - Copy state to new thread_id
       - Explore alternative paths
       - Compare different versions

    5. DEBUGGING:
       - Binary search through history
       - Find exact point of issue introduction
       - Replay with fixes to verify
    """)
