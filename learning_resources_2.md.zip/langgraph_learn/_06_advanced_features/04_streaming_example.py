"""
Streaming Examples in LangGraph
===============================

This module demonstrates different streaming modes:
1. Values streaming - Full state after each node
2. Updates streaming - State deltas only
3. Messages streaming - Token-by-token LLM output
4. Events streaming - Detailed operation tracking

Real-World Scenario: AI Research Assistant with Real-time Output
"""

# ============================================================================
# IMPORTS
# ============================================================================
from typing import TypedDict, Optional, List, Annotated
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.memory import MemorySaver
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, AIMessage, AIMessageChunk, BaseMessage
import asyncio
import time
import operator

# ============================================================================
# STATE DEFINITION
# ============================================================================

class ResearchState(TypedDict):
    """
    State for the research assistant workflow.

    Demonstrates streaming with multiple processing stages.
    """
    # Input query
    query: str

    # Research phases
    search_results: Optional[str]
    analysis: Optional[str]
    summary: Optional[str]

    # Messages for LLM interactions (with append reducer)
    messages: Annotated[List[BaseMessage], operator.add]

    # Progress tracking
    current_step: str
    progress_percentage: int


# ============================================================================
# NODE FUNCTIONS
# ============================================================================

def search_node(state: ResearchState) -> dict:
    """
    Simulate web search for research.

    Flow:
    +-------------------+
    |      Query        |
    +--------+----------+
             |
             v
    +-------------------+
    |   Web Search      |
    |   (simulated)     |
    +--------+----------+
             |
             v
    +-------------------+
    |  Search Results   |
    +-------------------+
    """
    print("\n[search_node] Searching the web...")

    # Simulate search delay
    time.sleep(0.5)

    # Simulated search results
    results = f"""
Search Results for: "{state['query']}"

1. [Wikipedia] Overview of the topic with historical context
2. [Research Paper] Recent academic findings and methodology
3. [News Article] Latest developments and industry trends
4. [Tutorial] Step-by-step guide with examples
5. [Forum Discussion] Community insights and best practices
    """.strip()

    print(f"[search_node] Found 5 results")

    return {
        "search_results": results,
        "current_step": "search_complete",
        "progress_percentage": 33
    }


def analyze_node(state: ResearchState) -> dict:
    """
    Analyze search results.

    +-------------------+
    |  Search Results   |
    +--------+----------+
             |
             v
    +-------------------+
    |    Analysis       |
    |    Engine         |
    +--------+----------+
             |
             v
    +-------------------+
    |    Insights       |
    +-------------------+
    """
    print("\n[analyze_node] Analyzing results...")

    # Simulate analysis
    time.sleep(0.5)

    analysis = f"""
Analysis of results for: "{state['query']}"

Key Themes Identified:
- Theme 1: Core concepts and foundations
- Theme 2: Practical applications
- Theme 3: Recent innovations

Credibility Assessment:
- Academic sources: High credibility
- News sources: Medium credibility, check dates
- Forum discussions: Variable, verify claims

Recommended Focus Areas:
1. Start with foundational concepts
2. Review recent research papers
3. Explore practical tutorials
    """.strip()

    print("[analyze_node] Analysis complete")

    return {
        "analysis": analysis,
        "current_step": "analysis_complete",
        "progress_percentage": 66
    }


def summarize_node(state: ResearchState) -> dict:
    """
    Generate final summary.

    This node would typically use an LLM.
    For streaming LLM tokens, see the async example below.

    +-------------------+
    |    Analysis       |
    +--------+----------+
             |
             v
    +-------------------+
    |   LLM Summary     |
    |   Generation      |
    +--------+----------+
             |
             v
    +-------------------+
    |  Final Summary    |
    +-------------------+
    """
    print("\n[summarize_node] Generating summary...")

    # Simulate LLM generation
    time.sleep(0.5)

    summary = f"""
RESEARCH SUMMARY: {state['query']}

Based on comprehensive analysis of 5 sources, here are the key findings:

1. OVERVIEW
   The topic has significant relevance in the current landscape with
   growing interest from both academic and industry perspectives.

2. KEY INSIGHTS
   - Foundational concepts are well-established
   - Recent innovations show promising directions
   - Practical applications are expanding rapidly

3. RECOMMENDATIONS
   - Review academic literature for depth
   - Follow industry news for trends
   - Practice with tutorials for hands-on learning

4. CONFIDENCE LEVEL: High
   Based on credible sources with consistent information.
    """.strip()

    print("[summarize_node] Summary ready")

    return {
        "summary": summary,
        "current_step": "complete",
        "progress_percentage": 100
    }


# ============================================================================
# BUILD THE GRAPH
# ============================================================================

def build_research_graph():
    """
    Build the research assistant graph.

    Complete Flow:
    +-------+     +--------+     +---------+     +-----------+     +-----+
    | START |---->| search |---->| analyze |---->| summarize |---->| END |
    +-------+     +--------+     +---------+     +-----------+     +-----+
    """
    builder = StateGraph(ResearchState)

    # Add nodes
    builder.add_node("search", search_node)
    builder.add_node("analyze", analyze_node)
    builder.add_node("summarize", summarize_node)

    # Add edges
    builder.add_edge(START, "search")
    builder.add_edge("search", "analyze")
    builder.add_edge("analyze", "summarize")
    builder.add_edge("summarize", END)

    # Compile with checkpointer
    checkpointer = MemorySaver()
    graph = builder.compile(checkpointer=checkpointer)

    return graph


# ============================================================================
# STREAMING MODE 1: VALUES
# ============================================================================

def demo_stream_values():
    """
    Demonstrate streaming with mode="values".

    Returns full state after each node execution.

    Output Structure:
    +------------------------------------------------------------------+
    |   After search:   {"query": "...", "search_results": "..."}      |
    |   After analyze:  {"query": "...", "search_results": "...",      |
    |                    "analysis": "..."}                            |
    |   After summarize: {"query": "...", "search_results": "...",     |
    |                     "analysis": "...", "summary": "..."}         |
    +------------------------------------------------------------------+
    """
    print("\n" + "=" * 70)
    print("DEMO: stream_mode='values' - Full State After Each Node")
    print("=" * 70)

    graph = build_research_graph()
    config = {"configurable": {"thread_id": "stream-values-001"}}

    initial_state = {
        "query": "How does machine learning work?",
        "search_results": None,
        "analysis": None,
        "summary": None,
        "messages": [],
        "current_step": "starting",
        "progress_percentage": 0
    }

    print("\nStreaming full state after each node:\n")

    for i, chunk in enumerate(graph.stream(initial_state, config, stream_mode="values")):
        print(f"\n--- State Snapshot {i + 1} ---")
        print(f"Current Step: {chunk.get('current_step', 'unknown')}")
        print(f"Progress: {chunk.get('progress_percentage', 0)}%")

        # Show which fields have data
        has_results = "Yes" if chunk.get("search_results") else "No"
        has_analysis = "Yes" if chunk.get("analysis") else "No"
        has_summary = "Yes" if chunk.get("summary") else "No"

        print(f"Has Search Results: {has_results}")
        print(f"Has Analysis: {has_analysis}")
        print(f"Has Summary: {has_summary}")

    print("\n[Stream complete - full state available at each step]")


# ============================================================================
# STREAMING MODE 2: UPDATES
# ============================================================================

def demo_stream_updates():
    """
    Demonstrate streaming with mode="updates".

    Returns only the changes (deltas) from each node.

    Output Structure:
    +------------------------------------------------------------------+
    |   {"search": {"search_results": "...", "progress": 33}}          |
    |   {"analyze": {"analysis": "...", "progress": 66}}               |
    |   {"summarize": {"summary": "...", "progress": 100}}             |
    +------------------------------------------------------------------+
    """
    print("\n" + "=" * 70)
    print("DEMO: stream_mode='updates' - State Deltas Only")
    print("=" * 70)

    graph = build_research_graph()
    config = {"configurable": {"thread_id": "stream-updates-001"}}

    initial_state = {
        "query": "What is quantum computing?",
        "search_results": None,
        "analysis": None,
        "summary": None,
        "messages": [],
        "current_step": "starting",
        "progress_percentage": 0
    }

    print("\nStreaming only updates from each node:\n")

    for chunk in graph.stream(initial_state, config, stream_mode="updates"):
        # chunk format: {"node_name": {updates}}
        for node_name, updates in chunk.items():
            print(f"\n--- Update from '{node_name}' ---")

            # Show only the keys that were updated
            updated_keys = list(updates.keys())
            print(f"Updated fields: {updated_keys}")

            if "progress_percentage" in updates:
                print(f"Progress: {updates['progress_percentage']}%")

            if "current_step" in updates:
                print(f"Step: {updates['current_step']}")

    print("\n[Stream complete - only deltas transmitted]")


# ============================================================================
# STREAMING MODE 3: MESSAGES (Async with LLM)
# ============================================================================

async def demo_stream_messages():
    """
    Demonstrate streaming with mode="messages".

    Streams individual tokens from LLM calls.
    This example simulates token-by-token output.

    Output:
    +------------------------------------------------------------------+
    |   Token: "The"                                                   |
    |   Token: " key"                                                  |
    |   Token: " concept"                                              |
    |   Token: " is"                                                   |
    |   Token: "..."                                                   |
    +------------------------------------------------------------------+
    """
    print("\n" + "=" * 70)
    print("DEMO: stream_mode='messages' - Token-by-Token Streaming")
    print("=" * 70)

    # For actual LLM streaming, you would use:
    # llm = ChatOpenAI(model="gpt-4", streaming=True)
    # And stream_mode="messages" with graph.astream()

    # Simulated token streaming
    print("\nSimulating token-by-token output:\n")
    print("Assistant: ", end="", flush=True)

    # Simulated tokens
    tokens = [
        "Machine", " learning", " is", " a", " subset", " of",
        " artificial", " intelligence", " that", " enables",
        " computers", " to", " learn", " from", " data",
        " without", " being", " explicitly", " programmed", "."
    ]

    for token in tokens:
        print(token, end="", flush=True)
        await asyncio.sleep(0.05)  # Simulate streaming delay

    print("\n\n[Stream complete - tokens delivered in real-time]")


# ============================================================================
# STREAMING MODE 4: EVENTS (Async)
# ============================================================================

async def demo_stream_events():
    """
    Demonstrate streaming with astream_events().

    Streams detailed events about graph execution.

    Event Types:
    +------------------------------------------------------------------+
    |   on_chain_start  - Graph or node starts                         |
    |   on_chain_end    - Graph or node ends                           |
    |   on_llm_start    - LLM call begins                              |
    |   on_llm_stream   - LLM token generated                          |
    |   on_llm_end      - LLM call completes                           |
    |   on_tool_start   - Tool execution begins                        |
    |   on_tool_end     - Tool execution ends                          |
    +------------------------------------------------------------------+
    """
    print("\n" + "=" * 70)
    print("DEMO: astream_events() - Detailed Event Streaming")
    print("=" * 70)

    graph = build_research_graph()
    config = {"configurable": {"thread_id": "stream-events-001"}}

    initial_state = {
        "query": "Explain neural networks",
        "search_results": None,
        "analysis": None,
        "summary": None,
        "messages": [],
        "current_step": "starting",
        "progress_percentage": 0
    }

    print("\nStreaming detailed events:\n")

    async for event in graph.astream_events(initial_state, config, version="v2"):
        kind = event["event"]
        name = event.get("name", "unknown")

        if kind == "on_chain_start":
            if name in ["search", "analyze", "summarize"]:
                print(f"[START] Node '{name}' beginning execution")

        elif kind == "on_chain_end":
            if name in ["search", "analyze", "summarize"]:
                print(f"[END]   Node '{name}' completed")
                # Could access event["data"]["output"] for node output

        elif kind == "on_llm_start":
            print(f"[LLM]   Starting LLM call in '{name}'")

        elif kind == "on_llm_stream":
            # Would contain token: event["data"]["chunk"].content
            pass

        elif kind == "on_llm_end":
            print(f"[LLM]   LLM call completed in '{name}'")

    print("\n[Event stream complete - all operations tracked]")


# ============================================================================
# COMBINED STREAMING MODES
# ============================================================================

def demo_combined_modes():
    """
    Demonstrate combining multiple streaming modes.

    You can receive both state updates AND messages simultaneously.

    Output:
    +------------------------------------------------------------------+
    |   [State Update] {"search": {...}}                               |
    |   [Token] "The"                                                  |
    |   [Token] " answer"                                              |
    |   [State Update] {"analyze": {...}}                              |
    +------------------------------------------------------------------+
    """
    print("\n" + "=" * 70)
    print("DEMO: Combined Streaming Modes")
    print("=" * 70)

    graph = build_research_graph()
    config = {"configurable": {"thread_id": "stream-combined-001"}}

    initial_state = {
        "query": "What is deep learning?",
        "search_results": None,
        "analysis": None,
        "summary": None,
        "messages": [],
        "current_step": "starting",
        "progress_percentage": 0
    }

    print("\nStreaming with multiple modes (updates + values):\n")
    print("Note: In practice, you'd use ['updates', 'messages'] for chat UIs\n")

    # Stream multiple modes
    for chunk in graph.stream(
        initial_state,
        config,
        stream_mode=["updates", "values"]
    ):
        # chunk is a tuple: (mode, data)
        mode, data = chunk

        if mode == "updates":
            for node_name, updates in data.items():
                print(f"[UPDATE] Node '{node_name}': {list(updates.keys())}")

        elif mode == "values":
            print(f"[VALUES] Progress: {data.get('progress_percentage', 0)}%")

    print("\n[Combined stream complete]")


# ============================================================================
# PRACTICAL: PROGRESS BAR STREAMING
# ============================================================================

def demo_progress_bar():
    """
    Practical example: Real-time progress bar using streaming.

    Shows how to build a user-friendly progress indicator.

    Output:
    +------------------------------------------------------------------+
    |   [===>                    ] 33% - Searching...                  |
    |   [=========>              ] 66% - Analyzing...                  |
    |   [========================] 100% - Complete!                    |
    +------------------------------------------------------------------+
    """
    print("\n" + "=" * 70)
    print("PRACTICAL: Progress Bar with Streaming")
    print("=" * 70)

    graph = build_research_graph()
    config = {"configurable": {"thread_id": "progress-bar-001"}}

    initial_state = {
        "query": "How do neural networks learn?",
        "search_results": None,
        "analysis": None,
        "summary": None,
        "messages": [],
        "current_step": "starting",
        "progress_percentage": 0
    }

    print("\n")

    def render_progress_bar(percentage: int, step: str, width: int = 40):
        """Render a text-based progress bar."""
        filled = int(width * percentage / 100)
        empty = width - filled
        bar = "=" * filled + ">" + " " * empty if percentage < 100 else "=" * width
        step_text = step.replace("_", " ").title()
        print(f"\r[{bar}] {percentage:3d}% - {step_text}      ", end="", flush=True)

    for chunk in graph.stream(initial_state, config, stream_mode="values"):
        progress = chunk.get("progress_percentage", 0)
        step = chunk.get("current_step", "processing")
        render_progress_bar(progress, step)
        time.sleep(0.3)  # Small delay for visual effect

    print("\n\n[Processing complete!]")


# ============================================================================
# INTERVIEW TIP
# ============================================================================
"""
+--------------------------------------------------------------------------+
|                              INTERVIEW TIP                                |
+--------------------------------------------------------------------------+
| Q: "How would you implement streaming for a production chat application?" |
|                                                                           |
| A: Architecture layers:                                                   |
|                                                                           |
|    1. Frontend (React/Vue)                                                |
|       - EventSource for SSE or WebSocket for bidirectional               |
|       - Buffer tokens, update UI on requestAnimationFrame                 |
|       - Show typing indicator while streaming                             |
|                                                                           |
|    2. Backend (FastAPI/Flask)                                             |
|       - StreamingResponse for SSE                                         |
|       - Async generator yielding chunks                                   |
|       - Handle disconnection gracefully                                   |
|                                                                           |
|    3. LangGraph Layer                                                     |
|       - stream_mode="messages" for token streaming                        |
|       - Checkpointer for resume on disconnect                             |
|       - Error handling with graceful degradation                          |
|                                                                           |
| Example FastAPI endpoint:                                                 |
|    @app.get("/chat/stream")                                               |
|    async def stream_chat(query: str):                                     |
|        async def generate():                                              |
|            async for chunk in graph.astream(...):                         |
|                yield f"data: {json.dumps(chunk)}\\n\\n"                   |
|        return StreamingResponse(generate(), media_type="text/event-stream")|
+--------------------------------------------------------------------------+
"""


# ============================================================================
# MAIN EXECUTION
# ============================================================================

async def main():
    """Run all streaming demonstrations."""

    # Sync demos
    demo_stream_values()
    demo_stream_updates()
    demo_combined_modes()
    demo_progress_bar()

    # Async demos
    await demo_stream_messages()
    await demo_stream_events()

    print("\n" + "=" * 70)
    print("KEY TAKEAWAYS")
    print("=" * 70)
    print("""
    1. STREAMING MODES:
       - "values": Full state snapshots (debugging, simple UIs)
       - "updates": State deltas only (efficient, reactive UIs)
       - "messages": Token-by-token (chat interfaces)
       - astream_events(): Detailed operations (monitoring)

    2. CHOOSING THE RIGHT MODE:
       - Chat apps: "messages" for real-time text display
       - Progress UIs: "updates" for efficient updates
       - Debugging: "values" or "events" for full visibility
       - Production: Combine modes as needed

    3. BEST PRACTICES:
       - Use async (astream) for production web servers
       - Implement error handling for stream interruptions
       - Buffer tokens before UI updates (performance)
       - Add heartbeat for long-running streams

    4. PRODUCTION CONSIDERATIONS:
       - SSE for simple one-way streaming
       - WebSockets for bidirectional (user can interrupt)
       - Checkpointers for resume on disconnect
       - Rate limiting to prevent abuse
    """)


if __name__ == "__main__":
    asyncio.run(main())
