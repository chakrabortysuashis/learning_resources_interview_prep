# Time Travel in LangGraph

## What is Time Travel?

Time Travel in LangGraph refers to the ability to replay graph execution from any previously saved checkpoint. This enables debugging, auditing, and implementing undo/redo functionality.

```
+------------------------------------------------------------------+
|                    TIME TRAVEL CONCEPT                            |
+------------------------------------------------------------------+
|                                                                   |
|   Execution Timeline:                                             |
|                                                                   |
|   CP1        CP2        CP3        CP4        CP5                 |
|    |          |          |          |          |                  |
|    v          v          v          v          v                  |
|   [*]---------[*]---------[*]---------[*]---------[*]---> Now     |
|    ^          ^          ^                                        |
|    |          |          |                                        |
|    |          |          +-- Replay from here                     |
|    |          |                                                   |
|    |          +-- Or from here                                    |
|    |                                                              |
|    +-- Or go all the way back                                     |
|                                                                   |
|   Each [*] is a saved checkpoint with complete state              |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Why Use Time Travel?

### 1. Debugging
- Identify exactly when things went wrong
- Replay with modified inputs to test fixes
- Understand state evolution over time

### 2. Auditing & Compliance
- Complete execution history
- Reproduce any decision for review
- Regulatory compliance documentation

### 3. User Experience
- Implement undo/redo functionality
- Allow users to "go back" in conversations
- Fork conversations from any point

### 4. Testing
- Replay edge cases for regression testing
- Compare behavior across versions
- Validate fixes without full re-execution

---

## Checkpoint Structure

```
+------------------------------------------------------------------+
|                    CHECKPOINT ANATOMY                             |
+------------------------------------------------------------------+
|                                                                   |
|   +-----------------------------------------------------------+   |
|   |                    CHECKPOINT                             |   |
|   +-----------------------------------------------------------+   |
|   |                                                           |   |
|   |   thread_id: "user_123_conversation_1"                    |   |
|   |   +-------------------------------------------------+     |   |
|   |   | Identifies the conversation/workflow instance   |     |   |
|   |   +-------------------------------------------------+     |   |
|   |                                                           |   |
|   |   checkpoint_id: "1a2b3c4d-..."                           |   |
|   |   +-------------------------------------------------+     |   |
|   |   | Unique identifier for this specific checkpoint  |     |   |
|   |   +-------------------------------------------------+     |   |
|   |                                                           |   |
|   |   parent_checkpoint_id: "0z9y8x7w-..."                    |   |
|   |   +-------------------------------------------------+     |   |
|   |   | Links to previous checkpoint (enables history)  |     |   |
|   |   +-------------------------------------------------+     |   |
|   |                                                           |   |
|   |   state: {                                                |   |
|   |     messages: [...],                                      |   |
|   |     current_step: "analyze",                              |   |
|   |     data: {...}                                           |   |
|   |   }                                                       |   |
|   |   +-------------------------------------------------+     |   |
|   |   | Complete graph state at this point              |     |   |
|   |   +-------------------------------------------------+     |   |
|   |                                                           |   |
|   |   metadata: {                                             |   |
|   |     created_at: "2024-01-15T10:30:00Z",                   |   |
|   |     source: "node_xyz",                                   |   |
|   |     user_metadata: {...}                                  |   |
|   |   }                                                       |   |
|   |   +-------------------------------------------------+     |   |
|   |   | Additional context and timing information       |     |   |
|   |   +-------------------------------------------------+     |   |
|   |                                                           |   |
|   +-----------------------------------------------------------+   |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Time Travel Operations

### 1. Get State History

Retrieve all checkpoints for a thread:

```python
# Get complete history (reverse chronological)
for state in graph.get_state_history(config):
    print(f"Checkpoint: {state.config['configurable']['checkpoint_id']}")
    print(f"State: {state.values}")
    print(f"Created: {state.created_at}")
    print("---")
```

### 2. Replay from Specific Checkpoint

Resume execution from any checkpoint:

```python
# Get a specific checkpoint config
target_config = {
    "configurable": {
        "thread_id": "my_thread",
        "checkpoint_id": "abc123..."  # Specific checkpoint
    }
}

# Resume from that checkpoint
result = graph.invoke(None, target_config)
```

### 3. Fork from Checkpoint

Create a new branch from a historical state:

```python
# Original conversation
original_config = {"configurable": {"thread_id": "original_thread"}}

# Find checkpoint to fork from
history = list(graph.get_state_history(original_config))
fork_point = history[3]  # 4th checkpoint

# Create new thread forked from that point
new_config = {
    "configurable": {
        "thread_id": "forked_thread",  # New thread ID
        "checkpoint_id": fork_point.config["configurable"]["checkpoint_id"]
    }
}

# Continue with different input
result = graph.invoke({"different": "input"}, new_config)
```

---

## Time Travel Flow Diagrams

### Replay from Past State

```
+------------------------------------------------------------------+
|                    REPLAY OPERATION                               |
+------------------------------------------------------------------+
|                                                                   |
|   Original Timeline:                                              |
|                                                                   |
|   +----+    +----+    +----+    +----+    +----+                  |
|   |CP 1|--->|CP 2|--->|CP 3|--->|CP 4|--->|CP 5|   (Current)      |
|   +----+    +----+    +----+    +----+    +----+                  |
|               ^                                                   |
|               |                                                   |
|               +-- SELECT: "Replay from CP 2"                      |
|                                                                   |
|   Replay Process:                                                 |
|                                                                   |
|   1. Load state from CP 2                                         |
|   2. Execute graph from that state                                |
|   3. New checkpoints created (CP 2.1, CP 2.2, ...)                |
|                                                                   |
|   Result (Forked Timeline):                                       |
|                                                                   |
|   +----+    +----+    +----+    +----+    +----+                  |
|   |CP 1|--->|CP 2|--->|CP 3|--->|CP 4|--->|CP 5|   (Old path)     |
|   +----+    +--+-+    +----+    +----+    +----+                  |
|                |                                                  |
|                +---->+------+    +------+                         |
|                      |CP 2.1|--->|CP 2.2|   (New path)            |
|                      +------+    +------+                         |
|                                                                   |
+------------------------------------------------------------------+
```

### Undo Operation

```
+------------------------------------------------------------------+
|                      UNDO OPERATION                               |
+------------------------------------------------------------------+
|                                                                   |
|   Current State: CP 5                                             |
|                                                                   |
|   User: "Undo last action"                                        |
|                                                                   |
|   Implementation:                                                 |
|                                                                   |
|   1. Get parent of current checkpoint:                            |
|      +----+                                                       |
|      |CP 4| <-- parent_checkpoint_id of CP 5                      |
|      +----+                                                       |
|                                                                   |
|   2. Load state from CP 4                                         |
|                                                                   |
|   3. Update "current" pointer to CP 4                             |
|                                                                   |
|   Result:                                                         |
|                                                                   |
|   Before Undo:                                                    |
|   [CP1]---[CP2]---[CP3]---[CP4]---[CP5*]                          |
|                                     ^                             |
|                                     |                             |
|                                  CURRENT                          |
|                                                                   |
|   After Undo:                                                     |
|   [CP1]---[CP2]---[CP3]---[CP4*]---(CP5)                          |
|                             ^         |                           |
|                             |         |                           |
|                          CURRENT    orphaned                      |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Use Case: Debugging Failed Workflow

```
+------------------------------------------------------------------+
|                    DEBUGGING WORKFLOW                             |
+------------------------------------------------------------------+
|                                                                   |
|   SCENARIO: AI made wrong decision at step 3                      |
|                                                                   |
|   Original Execution:                                             |
|   +------+    +------+    +------+    +------+                    |
|   | Step1|    | Step2|    | Step3|    | Step4|                    |
|   | OK   |--->| OK   |--->| ERROR|--->| Wrong|                    |
|   +------+    +------+    +------+    +------+                    |
|                             ^                                     |
|                             |                                     |
|                   Problem introduced here                         |
|                                                                   |
|   DEBUGGING PROCESS:                                              |
|                                                                   |
|   1. Load state history                                           |
|      for state in graph.get_state_history(config):                |
|          inspect(state)                                           |
|                                                                   |
|   2. Identify problematic checkpoint (CP at Step 2)               |
|                                                                   |
|   3. Replay with corrected input or modified logic:               |
|      config_replay = {"configurable": {                           |
|          "thread_id": "debug_thread",                             |
|          "checkpoint_id": step2_checkpoint_id                     |
|      }}                                                           |
|      result = graph.invoke(corrected_input, config_replay)        |
|                                                                   |
|   4. Verify correct behavior                                      |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Use Case: Audit Trail

```
+------------------------------------------------------------------+
|                    AUDIT TRAIL                                    |
+------------------------------------------------------------------+
|                                                                   |
|   SCENARIO: Compliance audit requires reviewing AI decisions      |
|                                                                   |
|   +------------------------------------------------------------+  |
|   |                    AUDIT LOG                               |  |
|   +------------------------------------------------------------+  |
|   | Timestamp           | Node      | State Change  | User     |  |
|   +---------------------+-----------+---------------+----------+  |
|   | 2024-01-15 10:30:00 | classify  | category: A   | system   |  |
|   | 2024-01-15 10:30:05 | analyze   | risk: low     | system   |  |
|   | 2024-01-15 10:30:10 | review    | [INTERRUPT]   | human    |  |
|   | 2024-01-15 10:35:00 | review    | approved: yes | john_doe |  |
|   | 2024-01-15 10:35:05 | execute   | action: done  | system   |  |
|   +---------------------+-----------+---------------+----------+  |
|                                                                   |
|   For any row, auditor can:                                       |
|   - Load exact state at that point                                |
|   - Replay to verify decision                                     |
|   - Document reasoning chain                                      |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Implementation Patterns

### Pattern 1: Simple Undo/Redo

```python
class UndoRedoManager:
    """
    Manage undo/redo operations for a graph.
    """
    def __init__(self, graph, thread_id):
        self.graph = graph
        self.config = {"configurable": {"thread_id": thread_id}}
        self.redo_stack = []  # Checkpoints we've undone

    def get_current_checkpoint(self):
        """Get the most recent checkpoint."""
        state = self.graph.get_state(self.config)
        return state.config["configurable"]["checkpoint_id"]

    def undo(self):
        """Go back to previous checkpoint."""
        history = list(self.graph.get_state_history(self.config))

        if len(history) < 2:
            print("Nothing to undo")
            return

        # Current is history[0], previous is history[1]
        current = history[0]
        previous = history[1]

        # Save current to redo stack
        self.redo_stack.append(current.config["configurable"]["checkpoint_id"])

        # Load previous state
        return self.graph.get_state({
            "configurable": {
                "thread_id": self.config["configurable"]["thread_id"],
                "checkpoint_id": previous.config["configurable"]["checkpoint_id"]
            }
        })

    def redo(self):
        """Restore previously undone checkpoint."""
        if not self.redo_stack:
            print("Nothing to redo")
            return

        checkpoint_id = self.redo_stack.pop()
        return self.graph.get_state({
            "configurable": {
                "thread_id": self.config["configurable"]["thread_id"],
                "checkpoint_id": checkpoint_id
            }
        })
```

### Pattern 2: Audit Logger

```python
def log_checkpoint_to_audit(state, action="checkpoint"):
    """
    Log checkpoint to audit system.
    """
    audit_entry = {
        "timestamp": datetime.now().isoformat(),
        "thread_id": state.config["configurable"]["thread_id"],
        "checkpoint_id": state.config["configurable"]["checkpoint_id"],
        "action": action,
        "state_summary": {
            "keys": list(state.values.keys()),
            "message_count": len(state.values.get("messages", [])),
        },
        "metadata": state.metadata
    }

    # Log to audit system
    audit_logger.info(json.dumps(audit_entry))
```

### Pattern 3: Branch Manager

```python
def fork_conversation(graph, source_config, fork_name, from_checkpoint_id=None):
    """
    Fork a conversation to explore alternative paths.
    """
    # Get source history
    history = list(graph.get_state_history(source_config))

    # Find fork point
    if from_checkpoint_id:
        fork_point = next(
            (s for s in history
             if s.config["configurable"]["checkpoint_id"] == from_checkpoint_id),
            None
        )
    else:
        fork_point = history[0]  # Fork from current

    if not fork_point:
        raise ValueError("Checkpoint not found")

    # Create new thread config
    fork_config = {
        "configurable": {
            "thread_id": f"{source_config['configurable']['thread_id']}_{fork_name}",
        }
    }

    # Copy state to new thread
    graph.update_state(fork_config, fork_point.values)

    return fork_config
```

---

## State History API

```python
# Get state history (returns iterator)
history = graph.get_state_history(config)

# Each state object contains:
for state in history:
    state.values         # Dict of state values
    state.next           # Tuple of next node(s)
    state.config         # Config with checkpoint_id
    state.created_at     # Timestamp (if available)
    state.parent_config  # Parent checkpoint config
    state.metadata       # Custom metadata
```

---

## Best Practices

### Do's

| Practice | Reason |
|----------|--------|
| Add meaningful metadata | Easier to find specific checkpoints |
| Implement TTL cleanup | Prevent unbounded storage growth |
| Log checkpoint operations | Audit trail |
| Use separate threads for forks | Clear separation of histories |
| Test replay regularly | Ensure checkpoints are usable |

### Don'ts

| Anti-Pattern | Problem |
|--------------|---------|
| Modifying historical checkpoints | Corrupts audit trail |
| Ignoring checkpoint size | Memory/storage issues |
| No cleanup strategy | Unbounded growth |
| Hardcoding checkpoint IDs | Brittle, breaks on schema changes |

---

## Interview Tips

```
+------------------------------------------------------------------+
|                         INTERVIEW TIP                             |
+------------------------------------------------------------------+
| Q: "How would you implement undo functionality in an AI chat?"    |
|                                                                   |
| A: Architecture:                                                  |
|                                                                   |
|    1. STORAGE                                                     |
|       - Use persistent checkpointer (Postgres for production)     |
|       - Each message creates new checkpoint                       |
|       - Maintain parent-child relationships                       |
|                                                                   |
|    2. UNDO OPERATION                                              |
|       - Get state history for thread                              |
|       - Navigate to parent checkpoint                             |
|       - Update UI to reflect previous state                       |
|       - Save current checkpoint_id to redo stack                  |
|                                                                   |
|    3. REDO OPERATION                                              |
|       - Pop from redo stack                                       |
|       - Load that checkpoint                                      |
|       - Clear redo stack on new user action                       |
|                                                                   |
|    4. UI CONSIDERATIONS                                           |
|       - Show "undo available" indicator                           |
|       - Confirm before undoing multiple steps                     |
|       - Preserve redo stack until new action                      |
+------------------------------------------------------------------+
```

```
+------------------------------------------------------------------+
|                         INTERVIEW TIP                             |
+------------------------------------------------------------------+
| Q: "How do you ensure time travel doesn't corrupt production?"    |
|                                                                   |
| A: Safety measures:                                               |
|                                                                   |
|    1. IMMUTABLE CHECKPOINTS                                       |
|       - Never modify existing checkpoints                         |
|       - Create new checkpoints for any changes                    |
|       - Use append-only storage pattern                           |
|                                                                   |
|    2. ISOLATION                                                   |
|       - Fork to new thread_id when replaying                      |
|       - Never overwrite production timeline                       |
|       - Use feature flags for replay capabilities                 |
|                                                                   |
|    3. ACCESS CONTROL                                              |
|       - Limit who can replay in production                        |
|       - Audit all replay operations                               |
|       - Require approval for sensitive replays                    |
|                                                                   |
|    4. VALIDATION                                                  |
|       - Verify checkpoint integrity before replay                 |
|       - Check schema compatibility                                |
|       - Validate state against current graph version              |
+------------------------------------------------------------------+
```

---

## Summary

Time Travel in LangGraph enables:

- **Replay**: Re-execute from any checkpoint
- **Debug**: Identify and fix issues by examining history
- **Audit**: Complete execution trail for compliance
- **Undo/Redo**: User-friendly state navigation
- **Fork**: Explore alternative execution paths

Key APIs:
- `get_state_history(config)`: Retrieve all checkpoints
- `get_state(config_with_checkpoint_id)`: Load specific checkpoint
- `invoke(input, config_with_checkpoint_id)`: Resume from checkpoint

---

Next: See `08_time_travel_example.py` for working implementations.
