"""
Persistence Examples in LangGraph
=================================

This module demonstrates different persistence strategies:
1. MemorySaver - In-memory (development)
2. SqliteSaver - File-based (small production)
3. PostgresSaver - Database (production)

Real-World Scenario: Customer Support Chatbot with Conversation History
"""

# ============================================================================
# IMPORTS
# ============================================================================
from typing import TypedDict, Optional, List, Annotated
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.memory import MemorySaver
from langchain_core.messages import HumanMessage, AIMessage, BaseMessage
import operator
import sqlite3
import os
from datetime import datetime

# ============================================================================
# STATE DEFINITION
# ============================================================================

class ConversationState(TypedDict):
    """
    State for a persistent conversation.

    The messages list uses an append reducer to accumulate
    messages across multiple invocations.
    """
    # Conversation messages (append-only)
    messages: Annotated[List[BaseMessage], operator.add]

    # User context (persisted across sessions)
    user_id: str
    user_name: Optional[str]

    # Conversation metadata
    topic: Optional[str]
    sentiment: Optional[str]

    # Turn counter
    turn_count: int


# ============================================================================
# NODE FUNCTIONS
# ============================================================================

def process_input(state: ConversationState) -> dict:
    """
    Process user input and extract context.

    Flow:
    +-------------------+
    |   User Message    |
    +--------+----------+
             |
             v
    +-------------------+
    | Extract Context   |
    | - Sentiment       |
    | - Topic           |
    +--------+----------+
             |
             v
    +-------------------+
    |  Updated State    |
    +-------------------+
    """
    messages = state.get("messages", [])
    turn_count = state.get("turn_count", 0)

    # Get latest user message
    latest_message = messages[-1] if messages else None

    # Simple sentiment analysis (would use LLM in production)
    sentiment = "neutral"
    if latest_message:
        content = latest_message.content.lower()
        if any(word in content for word in ["help", "problem", "issue", "broken"]):
            sentiment = "needs_help"
        elif any(word in content for word in ["thanks", "great", "awesome", "love"]):
            sentiment = "positive"
        elif any(word in content for word in ["angry", "frustrated", "terrible", "worst"]):
            sentiment = "negative"

    print(f"[process_input] Turn {turn_count + 1}, Sentiment: {sentiment}")

    return {
        "sentiment": sentiment,
        "turn_count": turn_count + 1
    }


def generate_response(state: ConversationState) -> dict:
    """
    Generate AI response based on conversation history.

    The response considers:
    - Full conversation history (persistent)
    - User sentiment
    - Turn count

    +-------------------+
    |  Conversation     |
    |  History          |
    +--------+----------+
             |
             v
    +-------------------+
    |  LLM Generation   |
    |  (with context)   |
    +--------+----------+
             |
             v
    +-------------------+
    |  AI Response      |
    +-------------------+
    """
    messages = state.get("messages", [])
    sentiment = state.get("sentiment", "neutral")
    turn_count = state.get("turn_count", 0)
    user_name = state.get("user_name", "there")

    # Get latest user message
    latest_message = messages[-1].content if messages else "Hello"

    # Generate contextual response (would use LLM in production)
    if sentiment == "needs_help":
        response = f"I understand you need assistance with '{latest_message}'. Let me help you with that right away!"
    elif sentiment == "negative":
        response = f"I'm sorry to hear you're frustrated, {user_name}. Let me make this right for you."
    elif sentiment == "positive":
        response = f"That's wonderful to hear, {user_name}! Is there anything else I can help you with?"
    else:
        response = f"Thanks for your message, {user_name}. Based on our conversation (turn {turn_count}), how can I assist you further?"

    print(f"[generate_response] Generated response for turn {turn_count}")

    # Return new message to append to history
    return {
        "messages": [AIMessage(content=response)]
    }


# ============================================================================
# BUILD THE GRAPH
# ============================================================================

def build_conversation_graph(checkpointer):
    """
    Build a persistent conversation graph.

    Flow:
    +-------+     +---------+     +----------+     +-----+
    | START |---->| process |---->| generate |---->| END |
    +-------+     | input   |     | response |     +-----+
                  +---------+     +----------+
    """
    builder = StateGraph(ConversationState)

    # Add nodes
    builder.add_node("process_input", process_input)
    builder.add_node("generate_response", generate_response)

    # Add edges
    builder.add_edge(START, "process_input")
    builder.add_edge("process_input", "generate_response")
    builder.add_edge("generate_response", END)

    # Compile with provided checkpointer
    graph = builder.compile(checkpointer=checkpointer)

    return graph


# ============================================================================
# DEMO 1: MEMORY SAVER
# ============================================================================

def demo_memory_saver():
    """
    Demonstrate MemorySaver for in-memory persistence.

    Characteristics:
    - Fast, no I/O overhead
    - Lost on process restart
    - Good for development/testing

    +------------------------------------------------------------------+
    |                     MEMORY SAVER DEMO                             |
    +------------------------------------------------------------------+
    |                                                                   |
    |   +----------+     +-----------+     +-----------+                |
    |   | Invoke 1 |---->| Invoke 2  |---->| Invoke 3  |                |
    |   | (Turn 1) |     | (Turn 2)  |     | (Turn 3)  |                |
    |   +----------+     +-----------+     +-----------+                |
    |        |                |                 |                       |
    |        v                v                 v                       |
    |   +------------------------------------------------+              |
    |   |           In-Memory State (RAM)                |              |
    |   |   messages: [msg1, msg2, msg3, msg4, msg5, ...]|              |
    |   +------------------------------------------------+              |
    |                                                                   |
    |   Note: State is lost if process restarts                         |
    |                                                                   |
    +------------------------------------------------------------------+
    """
    print("\n" + "=" * 70)
    print("DEMO 1: MemorySaver (In-Memory Persistence)")
    print("=" * 70)

    # Create memory checkpointer
    checkpointer = MemorySaver()
    graph = build_conversation_graph(checkpointer)

    # Configuration with thread_id
    config = {"configurable": {"thread_id": "user_alice_001"}}

    # Simulate multi-turn conversation
    print("\n--- Starting Conversation ---")

    # Turn 1
    result = graph.invoke({
        "messages": [HumanMessage(content="Hi, I need help with my order")],
        "user_id": "alice",
        "user_name": "Alice",
        "topic": None,
        "sentiment": None,
        "turn_count": 0
    }, config)

    print(f"\nTurn 1 - User: Hi, I need help with my order")
    print(f"Turn 1 - AI: {result['messages'][-1].content}")
    print(f"Total messages in state: {len(result['messages'])}")

    # Turn 2 - Continue same conversation (automatic history)
    result = graph.invoke({
        "messages": [HumanMessage(content="Order #12345 hasn't arrived yet")]
    }, config)

    print(f"\nTurn 2 - User: Order #12345 hasn't arrived yet")
    print(f"Turn 2 - AI: {result['messages'][-1].content}")
    print(f"Total messages in state: {len(result['messages'])}")

    # Turn 3
    result = graph.invoke({
        "messages": [HumanMessage(content="Thanks for your help!")]
    }, config)

    print(f"\nTurn 3 - User: Thanks for your help!")
    print(f"Turn 3 - AI: {result['messages'][-1].content}")
    print(f"Total messages in state: {len(result['messages'])}")

    # Show state history
    print("\n--- State History ---")
    for i, state in enumerate(graph.get_state_history(config)):
        msg_count = len(state.values.get("messages", []))
        turn = state.values.get("turn_count", 0)
        print(f"Checkpoint {i}: Turn {turn}, Messages: {msg_count}")
        if i >= 5:  # Limit output
            print("... (more checkpoints)")
            break

    print("\n[MemorySaver Demo Complete]")


# ============================================================================
# DEMO 2: SQLITE SAVER (Sync)
# ============================================================================

def demo_sqlite_saver():
    """
    Demonstrate SqliteSaver for file-based persistence.

    Characteristics:
    - Persists to local SQLite file
    - Survives process restarts
    - Good for single-server deployments

    +------------------------------------------------------------------+
    |                     SQLITE SAVER DEMO                             |
    +------------------------------------------------------------------+
    |                                                                   |
    |   Session 1:                                                      |
    |   +----------+     +-----------+                                  |
    |   | Invoke 1 |---->| Invoke 2  |                                  |
    |   +----------+     +-----------+                                  |
    |        |                |                                         |
    |        v                v                                         |
    |   +------------------------------------------------+              |
    |   |           SQLite Database (File)               |              |
    |   |   checkpoints.db                               |              |
    |   +------------------------------------------------+              |
    |                         |                                         |
    |   [Process Restart]     |                                         |
    |                         v                                         |
    |   Session 2:                                                      |
    |   +----------+     +-----------+                                  |
    |   | Invoke 3 |---->| Invoke 4  |  <-- Continues from checkpoint   |
    |   +----------+     +-----------+                                  |
    |                                                                   |
    +------------------------------------------------------------------+
    """
    print("\n" + "=" * 70)
    print("DEMO 2: SqliteSaver (File-Based Persistence)")
    print("=" * 70)

    # Import SQLite saver
    from langgraph.checkpoint.sqlite import SqliteSaver

    # Database file path
    db_path = "conversation_checkpoints.db"

    # Clean up previous demo data
    if os.path.exists(db_path):
        os.remove(db_path)
        print(f"[Cleaned up previous database: {db_path}]")

    # Create SQLite checkpointer using context manager
    with SqliteSaver.from_conn_string(db_path) as checkpointer:

        graph = build_conversation_graph(checkpointer)

        # Configuration
        config = {"configurable": {"thread_id": "user_bob_001"}}

        # Session 1: Start conversation
        print("\n--- SESSION 1: Starting Conversation ---")

        result = graph.invoke({
            "messages": [HumanMessage(content="Hello, I have a billing question")],
            "user_id": "bob",
            "user_name": "Bob",
            "topic": "billing",
            "sentiment": None,
            "turn_count": 0
        }, config)

        print(f"\nTurn 1 - User: Hello, I have a billing question")
        print(f"Turn 1 - AI: {result['messages'][-1].content}")

        result = graph.invoke({
            "messages": [HumanMessage(content="I was charged twice for the same item")]
        }, config)

        print(f"\nTurn 2 - User: I was charged twice for the same item")
        print(f"Turn 2 - AI: {result['messages'][-1].content}")

        print("\n[Session 1 Complete - Data persisted to SQLite]")

    # Simulate process restart by creating new checkpointer
    print("\n--- SIMULATING PROCESS RESTART ---")

    with SqliteSaver.from_conn_string(db_path) as checkpointer:

        graph = build_conversation_graph(checkpointer)

        # Same config to resume conversation
        config = {"configurable": {"thread_id": "user_bob_001"}}

        # Session 2: Resume conversation
        print("\n--- SESSION 2: Resuming Conversation ---")

        # Check existing state
        existing_state = graph.get_state(config)
        msg_count = len(existing_state.values.get("messages", []))
        print(f"[Loaded {msg_count} messages from previous session]")

        # Continue conversation
        result = graph.invoke({
            "messages": [HumanMessage(content="Can you refund one of the charges?")]
        }, config)

        print(f"\nTurn 3 - User: Can you refund one of the charges?")
        print(f"Turn 3 - AI: {result['messages'][-1].content}")
        print(f"Total messages across sessions: {len(result['messages'])}")

    # Show database info
    print("\n--- Database Info ---")
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # Count checkpoints
    cursor.execute("SELECT COUNT(*) FROM checkpoints")
    checkpoint_count = cursor.fetchone()[0]
    print(f"Total checkpoints stored: {checkpoint_count}")

    # Get file size
    file_size = os.path.getsize(db_path)
    print(f"Database file size: {file_size:,} bytes")

    conn.close()

    # Cleanup
    if os.path.exists(db_path):
        os.remove(db_path)
        print(f"\n[Cleaned up: {db_path}]")

    print("\n[SqliteSaver Demo Complete]")


# ============================================================================
# DEMO 3: ASYNC SQLITE SAVER
# ============================================================================

async def demo_async_sqlite_saver():
    """
    Demonstrate async SqliteSaver for non-blocking I/O.

    Use this in async web frameworks like FastAPI.
    """
    print("\n" + "=" * 70)
    print("DEMO 3: Async SqliteSaver")
    print("=" * 70)

    from langgraph.checkpoint.sqlite.aio import AsyncSqliteSaver

    db_path = "async_checkpoints.db"

    # Clean up
    if os.path.exists(db_path):
        os.remove(db_path)

    async with AsyncSqliteSaver.from_conn_string(db_path) as checkpointer:

        graph = build_conversation_graph(checkpointer)
        config = {"configurable": {"thread_id": "user_carol_001"}}

        print("\n--- Async Conversation ---")

        # Use ainvoke for async operation
        result = await graph.ainvoke({
            "messages": [HumanMessage(content="Quick async question")],
            "user_id": "carol",
            "user_name": "Carol",
            "topic": None,
            "sentiment": None,
            "turn_count": 0
        }, config)

        print(f"Async Turn 1 - AI: {result['messages'][-1].content}")

        result = await graph.ainvoke({
            "messages": [HumanMessage(content="Thanks for the fast response!")]
        }, config)

        print(f"Async Turn 2 - AI: {result['messages'][-1].content}")

    # Cleanup
    if os.path.exists(db_path):
        os.remove(db_path)

    print("\n[Async SqliteSaver Demo Complete]")


# ============================================================================
# DEMO 4: STATE INSPECTION
# ============================================================================

def demo_state_inspection():
    """
    Demonstrate how to inspect and manipulate persisted state.
    """
    print("\n" + "=" * 70)
    print("DEMO 4: State Inspection and Manipulation")
    print("=" * 70)

    checkpointer = MemorySaver()
    graph = build_conversation_graph(checkpointer)
    config = {"configurable": {"thread_id": "inspection_demo"}}

    # Create some conversation history
    print("\n--- Building Conversation History ---")

    graph.invoke({
        "messages": [HumanMessage(content="First message")],
        "user_id": "demo",
        "user_name": "Demo User",
        "topic": None,
        "sentiment": None,
        "turn_count": 0
    }, config)

    graph.invoke({
        "messages": [HumanMessage(content="Second message")]
    }, config)

    graph.invoke({
        "messages": [HumanMessage(content="Third message")]
    }, config)

    # Inspect current state
    print("\n--- Current State ---")
    current_state = graph.get_state(config)

    print(f"Turn count: {current_state.values.get('turn_count')}")
    print(f"Sentiment: {current_state.values.get('sentiment')}")
    print(f"Message count: {len(current_state.values.get('messages', []))}")
    print(f"Next nodes: {current_state.next}")

    # Inspect state history
    print("\n--- State History (Reverse Chronological) ---")
    for i, state in enumerate(graph.get_state_history(config)):
        turn = state.values.get("turn_count", 0)
        msg_count = len(state.values.get("messages", []))
        config_str = state.config.get("configurable", {}).get("checkpoint_id", "N/A")[:20]
        print(f"  {i}: Turn {turn}, Messages: {msg_count}, Checkpoint: {config_str}...")

        if i >= 10:
            print("  ... (more checkpoints)")
            break

    # Manually update state
    print("\n--- Manual State Update ---")
    print("Injecting a system message into state...")

    from langchain_core.messages import SystemMessage

    graph.update_state(
        config,
        {"messages": [SystemMessage(content="[Admin note: Priority customer]")]},
        as_node="process_input"  # Attribute to this node
    )

    # Check updated state
    updated_state = graph.get_state(config)
    last_msg = updated_state.values.get("messages", [])[-1]
    print(f"Last message type: {type(last_msg).__name__}")
    print(f"Last message content: {last_msg.content}")

    print("\n[State Inspection Demo Complete]")


# ============================================================================
# INTERVIEW TIP
# ============================================================================
"""
+--------------------------------------------------------------------------+
|                              INTERVIEW TIP                                |
+--------------------------------------------------------------------------+
| Q: "How would you migrate from SQLite to PostgreSQL in production?"       |
|                                                                           |
| A: Migration strategy:                                                    |
|                                                                           |
|    1. PARALLEL WRITES (Transition Phase)                                  |
|       - Write to both SQLite and PostgreSQL                               |
|       - Read from SQLite (source of truth)                                |
|       - Verify PostgreSQL data integrity                                  |
|                                                                           |
|    2. DATA MIGRATION                                                      |
|       - Export SQLite checkpoints to JSON                                 |
|       - Import into PostgreSQL with schema mapping                        |
|       - Verify row counts and data integrity                              |
|                                                                           |
|    3. CUTOVER                                                             |
|       - Switch reads to PostgreSQL                                        |
|       - Monitor for issues                                                |
|       - Keep SQLite as backup for rollback                                |
|                                                                           |
|    4. CLEANUP                                                             |
|       - Remove SQLite writes                                              |
|       - Archive SQLite file                                               |
|       - Update documentation                                              |
|                                                                           |
| Key consideration: Minimize downtime with feature flags for checkpointer   |
| selection: `if use_postgres: PostgresSaver(...) else SqliteSaver(...)`    |
+--------------------------------------------------------------------------+
"""


# ============================================================================
# DEMO 5: MULTIPLE THREADS
# ============================================================================

def demo_multiple_threads():
    """
    Demonstrate handling multiple conversations with different thread_ids.
    """
    print("\n" + "=" * 70)
    print("DEMO 5: Multiple Conversation Threads")
    print("=" * 70)

    checkpointer = MemorySaver()
    graph = build_conversation_graph(checkpointer)

    # Thread 1: Alice
    config_alice = {"configurable": {"thread_id": "user_alice_conversation"}}

    # Thread 2: Bob
    config_bob = {"configurable": {"thread_id": "user_bob_conversation"}}

    print("\n--- Interleaved Conversations ---")

    # Alice starts
    result = graph.invoke({
        "messages": [HumanMessage(content="Hi, I'm Alice!")],
        "user_id": "alice",
        "user_name": "Alice",
        "topic": None,
        "sentiment": None,
        "turn_count": 0
    }, config_alice)
    print(f"Alice Thread - AI: {result['messages'][-1].content[:50]}...")

    # Bob starts (separate conversation)
    result = graph.invoke({
        "messages": [HumanMessage(content="Hello, Bob here")],
        "user_id": "bob",
        "user_name": "Bob",
        "topic": None,
        "sentiment": None,
        "turn_count": 0
    }, config_bob)
    print(f"Bob Thread - AI: {result['messages'][-1].content[:50]}...")

    # Alice continues (maintains her history)
    result = graph.invoke({
        "messages": [HumanMessage(content="Following up on my earlier question")]
    }, config_alice)
    print(f"Alice Thread (continued) - AI: {result['messages'][-1].content[:50]}...")

    # Check each thread's state
    print("\n--- Thread States ---")

    alice_state = graph.get_state(config_alice)
    bob_state = graph.get_state(config_bob)

    print(f"Alice's thread: {len(alice_state.values.get('messages', []))} messages")
    print(f"Bob's thread: {len(bob_state.values.get('messages', []))} messages")

    print("\n[Multiple Threads Demo Complete]")


# ============================================================================
# MAIN EXECUTION
# ============================================================================

if __name__ == "__main__":
    import asyncio

    # Run sync demos
    demo_memory_saver()
    demo_sqlite_saver()
    demo_state_inspection()
    demo_multiple_threads()

    # Run async demo
    asyncio.run(demo_async_sqlite_saver())

    print("\n" + "=" * 70)
    print("KEY TAKEAWAYS")
    print("=" * 70)
    print("""
    1. CHECKPOINTER SELECTION:
       - MemorySaver: Development/testing only
       - SqliteSaver: Single-server persistence
       - PostgresSaver: Production, multi-server

    2. THREAD MANAGEMENT:
       - Each thread_id = separate conversation
       - Same thread_id = continuous conversation
       - Use meaningful naming: "user_{id}_chat_{num}"

    3. STATE OPERATIONS:
       - get_state(): Current state
       - get_state_history(): All checkpoints
       - update_state(): Manual state changes

    4. ASYNC SUPPORT:
       - Use AsyncSqliteSaver for async frameworks
       - Use ainvoke() instead of invoke()
       - Better performance in concurrent apps

    5. PRODUCTION CONSIDERATIONS:
       - Connection pooling for PostgreSQL
       - Checkpoint cleanup policies
       - Backup and recovery procedures
    """)
