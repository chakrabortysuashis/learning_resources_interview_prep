# Breakpoints in LangGraph

## What are Breakpoints?

Breakpoints in LangGraph are pause points that halt graph execution, allowing you to inspect state, debug issues, and manually control the execution flow.

```
+------------------------------------------------------------------+
|                    BREAKPOINT CONCEPT                             |
+------------------------------------------------------------------+
|                                                                   |
|   Normal Execution:                                               |
|   +------+    +------+    +------+    +------+                    |
|   |Node A|--->|Node B|--->|Node C|--->|Node D|---> Complete       |
|   +------+    +------+    +------+    +------+                    |
|                              ^                                    |
|                              |                                    |
|   With Breakpoint:           |                                    |
|   +------+    +------+    +--+---+                                 |
|   |Node A|--->|Node B|--->| STOP |  <-- Execution pauses          |
|   +------+    +------+    +------+                                 |
|                              |                                    |
|                              | (Inspect, Debug, Resume)           |
|                              v                                    |
|                           +------+    +------+                    |
|                           |Node C|--->|Node D|---> Complete       |
|                           +------+    +------+                    |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Breakpoint Types

### 1. `interrupt_before` - Pause Before Node

Execution stops BEFORE the specified node runs.

```
+------------------------------------------------------------------+
|                    INTERRUPT_BEFORE                               |
+------------------------------------------------------------------+
|                                                                   |
|   +------+    +------+         +------+    +------+               |
|   |Node A|--->|Node B|---> X   |Node C|--->|Node D|               |
|   +------+    +------+    |    +------+    +------+               |
|                           |         ^                             |
|                           |         |                             |
|                      [PAUSED]  [Resume here]                      |
|                                                                   |
|   interrupt_before=["Node C"]                                     |
|                                                                   |
|   Use When:                                                       |
|   - Need to inspect state BEFORE node processes it                |
|   - Want to approve/modify input to node                          |
|   - Implementing pre-execution validation                         |
|                                                                   |
+------------------------------------------------------------------+
```

### 2. `interrupt_after` - Pause After Node

Execution stops AFTER the specified node completes.

```
+------------------------------------------------------------------+
|                    INTERRUPT_AFTER                                |
+------------------------------------------------------------------+
|                                                                   |
|   +------+    +------+    +------+         +------+               |
|   |Node A|--->|Node B|--->|Node C|---> X   |Node D|               |
|   +------+    +------+    +------+    |    +------+               |
|                                       |         ^                 |
|                                       |         |                 |
|                                  [PAUSED]  [Resume here]          |
|                                                                   |
|   interrupt_after=["Node C"]                                      |
|                                                                   |
|   Use When:                                                       |
|   - Need to review node output before continuing                  |
|   - Implementing post-execution approval                          |
|   - Validating results before next step                           |
|                                                                   |
+------------------------------------------------------------------+
```

### 3. Inline `interrupt()` - Dynamic Pause

Use `interrupt()` function inside a node for conditional pauses.

```
+------------------------------------------------------------------+
|                    INLINE INTERRUPT                               |
+------------------------------------------------------------------+
|                                                                   |
|   def my_node(state):                                             |
|       # Do some processing                                        |
|       result = process(state)                                     |
|                                                                   |
|       # Conditionally interrupt                                   |
|       if needs_review(result):                                    |
|           human_input = interrupt({                               |
|               "question": "Please review this result",            |
|               "data": result                                      |
|           })                                                      |
|           # Resume with human_input                               |
|                                                                   |
|       return {"result": result}                                   |
|                                                                   |
|   Use When:                                                       |
|   - Pause condition depends on runtime state                      |
|   - Need to collect human input mid-node                          |
|   - Implementing conditional breakpoints                          |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Breakpoint Flow Diagram

```
+------------------------------------------------------------------+
|                    BREAKPOINT LIFECYCLE                           |
+------------------------------------------------------------------+
|                                                                   |
|   1. SETUP: Configure breakpoints at compile time                 |
|   +----------------------------------------------------------+    |
|   | graph = builder.compile(                                 |    |
|   |     checkpointer=checkpointer,                           |    |
|   |     interrupt_before=["sensitive_node"],                 |    |
|   |     interrupt_after=["review_node"]                      |    |
|   | )                                                        |    |
|   +----------------------------------------------------------+    |
|                                                                   |
|   2. EXECUTION: Graph runs until breakpoint                       |
|   +------+    +------+    +----------+                            |
|   |Node A|--->|Node B|--->|BREAKPOINT|                            |
|   +------+    +------+    +----+-----+                            |
|                                |                                  |
|                                v                                  |
|   3. PAUSE: State is checkpointed                                 |
|   +----------------------------------------------------------+    |
|   | Checkpoint saved:                                        |    |
|   | - thread_id: "xxx"                                       |    |
|   | - state: {...current state...}                           |    |
|   | - next: ["sensitive_node"]                               |    |
|   +----------------------------------------------------------+    |
|                                |                                  |
|                                v                                  |
|   4. INSPECT: Developer/system reviews state                      |
|   +----------------------------------------------------------+    |
|   | state = graph.get_state(config)                          |    |
|   | print(state.values)  # Inspect                           |    |
|   | print(state.next)    # See pending node                  |    |
|   +----------------------------------------------------------+    |
|                                |                                  |
|                                v                                  |
|   5. RESUME: Continue execution                                   |
|   +----------------------------------------------------------+    |
|   | # Option A: Continue as-is                               |    |
|   | result = graph.invoke(None, config)                      |    |
|   |                                                          |    |
|   | # Option B: Modify state and continue                    |    |
|   | graph.update_state(config, {"key": "new_value"})         |    |
|   | result = graph.invoke(None, config)                      |    |
|   +----------------------------------------------------------+    |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Breakpoint vs Human-in-the-Loop

| Aspect | Breakpoint | Human-in-the-Loop |
|--------|------------|-------------------|
| Purpose | Debugging, inspection | Production approval |
| Trigger | Always (unconditional) | Runtime condition |
| Resume | Code-driven | User input required |
| Environment | Development/staging | Production |
| State modification | Common | Less common |

---

## Use Cases

### Use Case 1: Development Debugging

```
+------------------------------------------------------------------+
|                    DEBUGGING WORKFLOW                             |
+------------------------------------------------------------------+
|                                                                   |
|   Developer wants to debug why Node C produces wrong output       |
|                                                                   |
|   Setup:                                                          |
|   interrupt_before=["Node C"]                                     |
|                                                                   |
|   Debug Session:                                                  |
|   +------+    +------+    +----+                                  |
|   |Node A|--->|Node B|--->|STOP|                                  |
|   +------+    +------+    +----+                                  |
|                              |                                    |
|                              v                                    |
|   +----------------------------------------------------------+    |
|   | >>> state = graph.get_state(config)                      |    |
|   | >>> print(state.values["input_for_C"])                   |    |
|   | {'unexpected': 'data'}  # Found the bug!                 |    |
|   |                                                          |    |
|   | # Fix the issue                                          |    |
|   | >>> graph.update_state(config, {"input_for_C": fixed})   |    |
|   | >>> graph.invoke(None, config)                           |    |
|   +----------------------------------------------------------+    |
|                                                                   |
+------------------------------------------------------------------+
```

### Use Case 2: Step-by-Step Execution

```
+------------------------------------------------------------------+
|                    STEP-BY-STEP EXECUTION                         |
+------------------------------------------------------------------+
|                                                                   |
|   Execute one node at a time for detailed analysis                |
|                                                                   |
|   Setup:                                                          |
|   interrupt_after=["Node A", "Node B", "Node C", "Node D"]        |
|                                                                   |
|   Execution:                                                      |
|   +------+    +------+    +------+    +------+                    |
|   |Node A|-X->|Node B|-X->|Node C|-X->|Node D|                    |
|   +------+ |  +------+ |  +------+ |  +------+                    |
|            |           |           |                              |
|        [PAUSE]     [PAUSE]     [PAUSE]                            |
|            |           |           |                              |
|            v           v           v                              |
|        Inspect     Inspect     Inspect                            |
|        Resume      Resume      Resume                             |
|                                                                   |
+------------------------------------------------------------------+
```

### Use Case 3: Conditional Breakpoint

```python
def analysis_node(state):
    result = analyze(state["data"])
    
    # Only break if result is suspicious
    if result["confidence"] < 0.5:
        human_review = interrupt({
            "reason": "Low confidence result",
            "result": result,
            "action_required": "Please verify or override"
        })
        
        if human_review.get("override"):
            result = human_review["override_value"]
    
    return {"analysis_result": result}
```

---

## Resuming from Breakpoints

### Method 1: Simple Resume

```python
# Graph paused at breakpoint
# Resume from where it left off
result = graph.invoke(None, config)
```

### Method 2: Resume with Modified State

```python
# Inspect current state
state = graph.get_state(config)
print(state.values)  # {'data': 'problematic_value'}

# Modify state before resuming
graph.update_state(config, {'data': 'fixed_value'})

# Resume with fixed state
result = graph.invoke(None, config)
```

### Method 3: Resume with New Input

```python
# Add new data when resuming
result = graph.invoke(
    {'additional_context': 'new_information'},
    config
)
```

### Method 4: Resume with Command (for inline interrupts)

```python
from langgraph.types import Command

# Resume inline interrupt with human response
result = graph.invoke(
    Command(resume={'approved': True, 'feedback': 'Looks good'}),
    config
)
```

---

## State Inspection at Breakpoints

```python
# Get current state at breakpoint
state = graph.get_state(config)

# Available properties
state.values        # Current state values (dict)
state.next          # Tuple of next node(s) to execute
state.config        # Configuration including checkpoint_id
state.created_at    # Timestamp of checkpoint
state.metadata      # Additional metadata
state.parent_config # Config of parent checkpoint

# Example inspection
print("=== BREAKPOINT STATE ===")
print(f"Current values: {state.values}")
print(f"Next node(s): {state.next}")
print(f"Checkpoint ID: {state.config['configurable']['checkpoint_id']}")
```

---

## Best Practices

### Do's

| Practice | Reason |
|----------|--------|
| Use meaningful breakpoint positions | Makes debugging intuitive |
| Remove breakpoints for production | Performance impact |
| Log state at breakpoints | Creates audit trail |
| Combine with time travel | Powerful debugging combo |
| Test resume paths | Ensure recovery works |

### Don'ts

| Anti-Pattern | Problem |
|--------------|---------|
| Breaking at every node | Tedious, impractical |
| Forgetting to resume | Workflows get stuck |
| Modifying critical state carelessly | Can corrupt execution |
| Using breakpoints instead of tests | Wrong tool for the job |

---

## Breakpoint Patterns

### Pattern 1: Gated Deployment

```python
# Pause before deploying to production
graph = builder.compile(
    checkpointer=checkpointer,
    interrupt_before=["deploy_to_production"]
)

# In deployment pipeline:
# 1. Run graph until deploy step
result = graph.invoke(initial_input, config)

# 2. Human reviews deployment plan
state = graph.get_state(config)
print("Deployment plan:", state.values["deployment_plan"])

# 3. After approval, resume
# approval_input = get_human_approval()
graph.invoke(None, config)  # Continues to deploy
```

### Pattern 2: Testing Harness

```python
def test_with_breakpoints():
    """Test individual node outputs."""
    
    graph = builder.compile(
        checkpointer=MemorySaver(),
        interrupt_after=["node_under_test"]
    )
    
    # Run until node completes
    graph.invoke(test_input, config)
    
    # Verify node output
    state = graph.get_state(config)
    assert state.values["expected_field"] == expected_value
    assert "error" not in state.values
```

### Pattern 3: Interactive Debugger

```python
def interactive_debug(graph, config, inputs):
    """Step through graph execution interactively."""
    
    # Start execution
    result = graph.invoke(inputs, config)
    
    while True:
        state = graph.get_state(config)
        
        if not state.next:
            print("Execution complete!")
            break
        
        print(f"\n=== Paused before: {state.next} ===")
        print(f"Current state: {state.values}")
        
        cmd = input("(c)ontinue, (i)nspect, (m)odify, (q)uit: ")
        
        if cmd == 'c':
            result = graph.invoke(None, config)
        elif cmd == 'i':
            print(json.dumps(state.values, indent=2))
        elif cmd == 'm':
            key = input("Key to modify: ")
            value = input("New value: ")
            graph.update_state(config, {key: value})
        elif cmd == 'q':
            break
    
    return result
```

---

## Interview Tips

```
+------------------------------------------------------------------+
|                         INTERVIEW TIP                             |
+------------------------------------------------------------------+
| Q: "How would you debug a non-deterministic AI workflow?"         |
|                                                                   |
| A: Multi-pronged approach:                                        |
|                                                                   |
|    1. BREAKPOINTS                                                 |
|       - Set interrupt_before on suspicious nodes                  |
|       - Inspect state at each step                                |
|       - Log LLM inputs/outputs for analysis                       |
|                                                                   |
|    2. TIME TRAVEL                                                 |
|       - Capture checkpoints with full state                       |
|       - Replay from specific points with same seed                |
|       - Compare state evolution across runs                       |
|                                                                   |
|    3. DETERMINISM                                                 |
|       - Set temperature=0 for reproducibility                     |
|       - Use seeded random generators                              |
|       - Cache LLM responses during debug                          |
|                                                                   |
|    4. OBSERVABILITY                                               |
|       - Structured logging at each node                           |
|       - Trace IDs for request correlation                         |
|       - Metrics on node execution times                           |
+------------------------------------------------------------------+
```

```
+------------------------------------------------------------------+
|                         INTERVIEW TIP                             |
+------------------------------------------------------------------+
| Q: "What's the difference between breakpoints and unit tests?"    |
|                                                                   |
| A: Complementary tools for different purposes:                    |
|                                                                   |
|    BREAKPOINTS:                                                   |
|    - Interactive debugging                                        |
|    - Exploring unknown behavior                                   |
|    - Ad-hoc investigation                                         |
|    - State at specific execution points                           |
|                                                                   |
|    UNIT TESTS:                                                    |
|    - Automated verification                                       |
|    - Regression prevention                                        |
|    - CI/CD integration                                            |
|    - Documented expected behavior                                 |
|                                                                   |
|    Best practice: Use breakpoints to discover issues, then        |
|    write unit tests to prevent regression.                        |
+------------------------------------------------------------------+
```

---

## Summary

Breakpoints in LangGraph enable:

- **Debugging**: Pause and inspect state at any point
- **Step-through**: Execute one node at a time
- **State modification**: Fix issues mid-execution
- **Validation**: Review before critical operations

Key APIs:
- `interrupt_before`: Pause before node executes
- `interrupt_after`: Pause after node completes
- `interrupt()`: Inline conditional pause
- `get_state()`: Inspect state at breakpoint
- `update_state()`: Modify state before resuming

---

Next: See `10_breakpoint_example.py` for working implementations.
