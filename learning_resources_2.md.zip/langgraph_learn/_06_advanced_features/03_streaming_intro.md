# Streaming in LangGraph

## What is Streaming?

Streaming allows you to receive partial outputs from your graph as they're generated, rather than waiting for the entire execution to complete.

```
+------------------------------------------------------------------+
|                    STREAMING vs BATCH                             |
+------------------------------------------------------------------+
|                                                                   |
|   BATCH (Traditional):                                            |
|   +--------+                              +------------------+     |
|   | Input  |------ long wait ----------->| Complete Output  |     |
|   +--------+                              +------------------+     |
|                                                                   |
|   STREAMING:                                                      |
|   +--------+     +---+  +---+  +---+  +---+  +-------------+      |
|   | Input  |---->| T |->| o |->| k |->|...|->| Complete!   |      |
|   +--------+     +---+  +---+  +---+  +---+  +-------------+      |
|                    ^      ^      ^      ^                          |
|                    |      |      |      |                          |
|               Immediate partial outputs                            |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Why Use Streaming?

### 1. Better User Experience
- Users see progress immediately
- Reduces perceived latency
- Enables real-time chat interfaces

### 2. Progress Monitoring
- Track which node is executing
- Monitor long-running workflows
- Debug execution flow

### 3. Early Termination
- Cancel if output is going wrong
- Save resources on bad generations
- Implement timeouts effectively

---

## Streaming Modes in LangGraph

LangGraph supports multiple streaming modes, each serving different use cases:

```
+------------------------------------------------------------------+
|                      STREAMING MODES                              |
+------------------------------------------------------------------+
|                                                                   |
|   +-------------+    +-------------+    +-------------+           |
|   |   VALUES    |    |   UPDATES   |    |  MESSAGES   |           |
|   +-------------+    +-------------+    +-------------+           |
|   | Full state  |    | State deltas|    | LLM message |           |
|   | after each  |    | (changes    |    | chunks      |           |
|   | node        |    |  only)      |    | (tokens)    |           |
|   +-------------+    +-------------+    +-------------+           |
|                                                                   |
|   +-------------+    +-------------+    +-------------+           |
|   |   EVENTS    |    |   DEBUG     |    |   CUSTOM    |           |
|   +-------------+    +-------------+    +-------------+           |
|   | All graph   |    | Detailed    |    | Custom      |           |
|   | events      |    | debug info  |    | channels    |           |
|   | (verbose)   |    |             |    |             |           |
|   +-------------+    +-------------+    +-------------+           |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Mode 1: `values` - Full State Streaming

Streams the complete state after each node execution.

```
+------------------------------------------------------------------+
|                    stream_mode="values"                           |
+------------------------------------------------------------------+
|                                                                   |
|   Node A          Node B          Node C          Node D          |
|   +----+          +----+          +----+          +----+          |
|   |    |          |    |          |    |          |    |          |
|   +--+-+          +--+-+          +--+-+          +--+-+          |
|      |               |               |               |            |
|      v               v               v               v            |
|   +------+        +------+        +------+        +------+        |
|   |State |        |State |        |State |        |State |        |
|   |{a:1} |        |{a:1, |        |{a:1, |        |{a:1, |        |
|   |      |        | b:2} |        | b:2, |        | b:2, |        |
|   |      |        |      |        | c:3} |        | c:3, |        |
|   |      |        |      |        |      |        | d:4} |        |
|   +------+        +------+        +------+        +------+        |
|      |               |               |               |            |
|      +---------------+---------------+---------------+            |
|                           |                                       |
|                           v                                       |
|                    Stream to Client                               |
|                                                                   |
+------------------------------------------------------------------+
```

**Use When**:
- You need complete state snapshots
- Debugging state evolution
- Simple implementations

**Code Example**:
```python
for chunk in graph.stream(inputs, stream_mode="values"):
    print(f"Current state: {chunk}")
```

---

## Mode 2: `updates` - Delta Streaming

Streams only the changes (deltas) from each node.

```
+------------------------------------------------------------------+
|                    stream_mode="updates"                          |
+------------------------------------------------------------------+
|                                                                   |
|   Node A          Node B          Node C          Node D          |
|   +----+          +----+          +----+          +----+          |
|   |    |          |    |          |    |          |    |          |
|   +--+-+          +--+-+          +--+-+          +--+-+          |
|      |               |               |               |            |
|      v               v               v               v            |
|   +------+        +------+        +------+        +------+        |
|   |Delta |        |Delta |        |Delta |        |Delta |        |
|   |{a:1} |        |{b:2} |        |{c:3} |        |{d:4} |        |
|   +------+        +------+        +------+        +------+        |
|      |               |               |               |            |
|      v               v               v               v            |
|                                                                   |
|   Output: {"node_a": {a:1}}                                       |
|   Output: {"node_b": {b:2}}                                       |
|   Output: {"node_c": {c:3}}                                       |
|   Output: {"node_d": {d:4}}                                       |
|                                                                   |
+------------------------------------------------------------------+
```

**Use When**:
- Bandwidth is limited
- Only need to know what changed
- Building reactive UIs

**Code Example**:
```python
for chunk in graph.stream(inputs, stream_mode="updates"):
    node_name = list(chunk.keys())[0]
    updates = chunk[node_name]
    print(f"Node '{node_name}' updated: {updates}")
```

---

## Mode 3: `messages` - LLM Token Streaming

Streams individual tokens from LLM calls within nodes.

```
+------------------------------------------------------------------+
|                    stream_mode="messages"                         |
+------------------------------------------------------------------+
|                                                                   |
|   LLM Call in Node                                                |
|   +------------------------------------------+                    |
|   |                                          |                    |
|   |  "The" -> "quick" -> "brown" -> "fox"    |                    |
|   |    |         |          |         |      |                    |
|   +------------------------------------------+                    |
|         |         |          |         |                          |
|         v         v          v         v                          |
|                                                                   |
|   Stream Output:                                                  |
|   +-----+  +-------+  +-------+  +-----+                          |
|   |"The"|  |"quick"|  |"brown"|  |"fox"|                          |
|   +-----+  +-------+  +-------+  +-----+                          |
|                                                                   |
|   Client sees: "The" -> "The quick" -> "The quick brown" ->       |
|                "The quick brown fox"                              |
|                                                                   |
+------------------------------------------------------------------+
```

**Use When**:
- Building chat interfaces
- Real-time text display
- Token-by-token output required

**Code Example**:
```python
for message, metadata in graph.stream(inputs, stream_mode="messages"):
    if isinstance(message, AIMessageChunk):
        print(message.content, end="", flush=True)
```

---

## Mode 4: `events` - Full Event Streaming

Streams all graph events including internal operations.

```
+------------------------------------------------------------------+
|                    stream_mode="events"                           |
+------------------------------------------------------------------+
|                                                                   |
|   Events Stream (verbose):                                        |
|                                                                   |
|   +------------------+                                            |
|   | on_chain_start   |  Graph execution begins                    |
|   +------------------+                                            |
|            |                                                      |
|            v                                                      |
|   +------------------+                                            |
|   | on_chain_start   |  Node A begins                             |
|   +------------------+                                            |
|            |                                                      |
|            v                                                      |
|   +------------------+                                            |
|   | on_llm_start     |  LLM call begins                           |
|   +------------------+                                            |
|            |                                                      |
|            v                                                      |
|   +------------------+                                            |
|   | on_llm_stream    |  Token 1: "The"                            |
|   +------------------+                                            |
|            |                                                      |
|            v                                                      |
|   +------------------+                                            |
|   | on_llm_stream    |  Token 2: "quick"                          |
|   +------------------+                                            |
|            |                                                      |
|            v                                                      |
|   +------------------+                                            |
|   | on_llm_end       |  LLM call ends                             |
|   +------------------+                                            |
|            |                                                      |
|            v                                                      |
|   +------------------+                                            |
|   | on_chain_end     |  Node A ends                               |
|   +------------------+                                            |
|                                                                   |
+------------------------------------------------------------------+
```

**Use When**:
- Debugging complex workflows
- Detailed logging required
- Building monitoring dashboards

**Code Example**:
```python
async for event in graph.astream_events(inputs, version="v2"):
    kind = event["event"]
    if kind == "on_llm_stream":
        print(event["data"]["chunk"].content, end="")
    elif kind == "on_chain_end":
        print(f"\nNode completed: {event['name']}")
```

---

## Streaming Mode Comparison

| Mode | Granularity | Bandwidth | Use Case |
|------|-------------|-----------|----------|
| `values` | Node-level | High | Debug, full state tracking |
| `updates` | Node-level | Low | Efficient UI updates |
| `messages` | Token-level | Medium | Chat interfaces |
| `events` | Operation-level | Very High | Monitoring, debugging |

---

## Multiple Stream Modes

You can combine multiple streaming modes:

```python
# Stream both state updates AND LLM tokens
for chunk in graph.stream(
    inputs,
    stream_mode=["updates", "messages"]
):
    if isinstance(chunk, tuple):
        # Message chunk: (message, metadata)
        message, metadata = chunk
        print(f"Token: {message.content}")
    else:
        # Update chunk: {node_name: updates}
        print(f"State update: {chunk}")
```

---

## Streaming Architecture

```
+------------------------------------------------------------------+
|                    STREAMING ARCHITECTURE                         |
+------------------------------------------------------------------+
|                                                                   |
|   +------------------+                                            |
|   |   LangGraph      |                                            |
|   |   Engine         |                                            |
|   +--------+---------+                                            |
|            |                                                      |
|            | generates                                            |
|            v                                                      |
|   +------------------+                                            |
|   |  Stream Events   |                                            |
|   |  (Generator)     |                                            |
|   +--------+---------+                                            |
|            |                                                      |
|            | yields                                               |
|            v                                                      |
|   +------------------+     +------------------+                    |
|   |  Application     |---->|   WebSocket      |                    |
|   |  Backend         |     |   Connection     |                    |
|   +------------------+     +--------+---------+                    |
|                                     |                             |
|                                     | pushes                      |
|                                     v                             |
|   +------------------+     +------------------+                    |
|   |    Frontend      |<----|   Real-time      |                    |
|   |    Client        |     |   Updates        |                    |
|   +------------------+     +------------------+                    |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Async vs Sync Streaming

### Synchronous Streaming
```python
# Blocking - runs in main thread
for chunk in graph.stream(inputs, stream_mode="updates"):
    process_chunk(chunk)
```

### Asynchronous Streaming
```python
# Non-blocking - runs in event loop
async for chunk in graph.astream(inputs, stream_mode="updates"):
    await process_chunk_async(chunk)
```

### When to Use Which?

| Scenario | Recommendation |
|----------|----------------|
| CLI tools | Sync |
| Web servers (FastAPI, etc.) | Async |
| Jupyter notebooks | Either |
| High-concurrency applications | Async |
| Simple scripts | Sync |

---

## Stream Filtering

Filter specific events from the stream:

```python
# Only get events from specific nodes
for event in graph.astream_events(
    inputs,
    version="v2",
    include_names=["important_node"],  # Only these nodes
    exclude_names=["verbose_node"]     # Not these nodes
):
    process_event(event)
```

---

## Best Practices

### Do's

| Practice | Reason |
|----------|--------|
| Use `updates` for bandwidth efficiency | Reduces data transfer |
| Use `messages` for chat UIs | Best user experience |
| Implement error handling | Streams can fail mid-way |
| Use async for web servers | Better scalability |
| Buffer before UI update | Avoid excessive re-renders |

### Don'ts

| Anti-Pattern | Problem |
|--------------|---------|
| Using `events` in production UI | Too verbose, noisy |
| Ignoring stream errors | Silent failures |
| Blocking main thread | UI freeze |
| No timeout on streams | Memory leaks |

---

## Interview Tips

```
+------------------------------------------------------------------+
|                         INTERVIEW TIP                             |
+------------------------------------------------------------------+
| Q: "How would you implement real-time streaming in a chat app?"   |
|                                                                   |
| A: Architecture overview:                                         |
|    1. Frontend: WebSocket connection to backend                   |
|    2. Backend: FastAPI with async streaming endpoint              |
|    3. LangGraph: stream_mode="messages" for token-level output    |
|    4. Buffer: Accumulate tokens, flush periodically               |
|                                                                   |
| Key considerations:                                               |
|    - Use Server-Sent Events (SSE) for simpler one-way streaming   |
|    - WebSockets for bidirectional (user can interrupt)            |
|    - Implement heartbeat to detect disconnections                 |
|    - Handle reconnection with checkpoint-based resume             |
+------------------------------------------------------------------+
```

```
+------------------------------------------------------------------+
|                         INTERVIEW TIP                             |
+------------------------------------------------------------------+
| Q: "What's the difference between streaming modes?"               |
|                                                                   |
| A: Quick summary:                                                 |
|    - "values": Full state after each node (debugging)             |
|    - "updates": Only changes from each node (efficient)           |
|    - "messages": LLM tokens as they generate (chat UIs)           |
|    - "events": All internal operations (monitoring)               |
|                                                                   |
| Trade-offs:                                                       |
|    - More granular = more bandwidth but better UX                 |
|    - Less granular = efficient but less responsive                |
|                                                                   |
| Production tip: Use "messages" for user-facing, "events" for      |
| internal monitoring/logging separately.                           |
+------------------------------------------------------------------+
```

---

## Summary

- **Streaming** enables real-time output delivery
- **Multiple modes** serve different use cases
- **`values`** for full state snapshots
- **`updates`** for efficient delta updates
- **`messages`** for token-by-token LLM output
- **`events`** for detailed operation tracking
- **Async streaming** recommended for production
- **Combine modes** when needed for complex UIs

---

Next: See `04_streaming_example.py` for working implementations.
