# Persistence Deep Dive in LangGraph

## What is Persistence?

Persistence in LangGraph refers to saving the state of your graph execution to durable storage, enabling:
- Resume conversations across sessions
- Survive server restarts
- Implement undo/redo functionality
- Enable human-in-the-loop workflows

```
+------------------------------------------------------------------+
|                    PERSISTENCE ARCHITECTURE                       |
+------------------------------------------------------------------+
|                                                                   |
|   +------------------+          +------------------+              |
|   |   LangGraph      |--------->|   Checkpointer   |              |
|   |   Execution      |          |   (Adapter)      |              |
|   +------------------+          +--------+---------+              |
|                                          |                        |
|                    +---------------------+---------------------+   |
|                    |                     |                     |   |
|                    v                     v                     v   |
|             +------------+        +------------+        +------------+
|             |   Memory   |        |   SQLite   |        | PostgreSQL |
|             |   Saver    |        |   Saver    |        |   Saver    |
|             +------------+        +------------+        +------------+
|             | In-process |        | Local file |        | Production |
|             | Dev only   |        | Single node|        | Distributed|
|             +------------+        +------------+        +------------+
|                                                                   |
+------------------------------------------------------------------+
```

---

## Checkpointer Types

### 1. MemorySaver (Development Only)

```
+------------------------------------------------------------------+
|                        MEMORY SAVER                               |
+------------------------------------------------------------------+
|                                                                   |
|   Characteristics:                                                |
|   - Stores state in Python dict (RAM)                             |
|   - Lost on process restart                                       |
|   - No concurrency support                                        |
|   - Zero setup required                                           |
|                                                                   |
|   Use Cases:                                                      |
|   - Local development                                             |
|   - Unit testing                                                  |
|   - Prototyping                                                   |
|   - Learning/tutorials                                            |
|                                                                   |
|   Limitations:                                                    |
|   - NOT for production                                            |
|   - State lost on restart                                         |
|   - Memory grows unbounded                                        |
|                                                                   |
+------------------------------------------------------------------+
```

**Code Example**:
```python
from langgraph.checkpoint.memory import MemorySaver

checkpointer = MemorySaver()
graph = builder.compile(checkpointer=checkpointer)
```

---

### 2. SqliteSaver (Development / Small Production)

```
+------------------------------------------------------------------+
|                        SQLITE SAVER                               |
+------------------------------------------------------------------+
|                                                                   |
|   Characteristics:                                                |
|   - File-based SQLite database                                    |
|   - Survives process restarts                                     |
|   - Single-writer, multiple-reader                                |
|   - Zero external dependencies                                    |
|                                                                   |
|   Use Cases:                                                      |
|   - Development with persistence                                  |
|   - Single-server deployments                                     |
|   - Edge deployments                                              |
|   - Desktop applications                                          |
|                                                                   |
|   Limitations:                                                    |
|   - Single server only (no clustering)                            |
|   - Limited concurrent writes                                     |
|   - File-based (backup complexity)                                |
|                                                                   |
+------------------------------------------------------------------+
```

**Schema Overview**:
```
+------------------------------------------------------------------+
|                    SQLITE SCHEMA                                  |
+------------------------------------------------------------------+
|                                                                   |
|   Table: checkpoints                                              |
|   +------------------+------------------+----------------------+   |
|   | Column           | Type             | Description          |   |
|   +------------------+------------------+----------------------+   |
|   | thread_id        | TEXT             | Conversation ID      |   |
|   | checkpoint_ns    | TEXT             | Namespace            |   |
|   | checkpoint_id    | TEXT             | Unique checkpoint ID |   |
|   | parent_checkpoint| TEXT             | Parent checkpoint    |   |
|   | type             | TEXT             | Checkpoint type      |   |
|   | checkpoint       | BLOB             | Serialized state     |   |
|   | metadata         | BLOB             | Additional metadata  |   |
|   +------------------+------------------+----------------------+   |
|                                                                   |
|   Table: writes                                                   |
|   +------------------+------------------+----------------------+   |
|   | Column           | Type             | Description          |   |
|   +------------------+------------------+----------------------+   |
|   | thread_id        | TEXT             | Conversation ID      |   |
|   | checkpoint_ns    | TEXT             | Namespace            |   |
|   | checkpoint_id    | TEXT             | Checkpoint ID        |   |
|   | task_id          | TEXT             | Task identifier      |   |
|   | idx              | INTEGER          | Write index          |   |
|   | channel          | TEXT             | Channel name         |   |
|   | type             | TEXT             | Value type           |   |
|   | value            | BLOB             | Serialized value     |   |
|   +------------------+------------------+----------------------+   |
|                                                                   |
+------------------------------------------------------------------+
```

**Code Example**:
```python
from langgraph.checkpoint.sqlite import SqliteSaver

# File-based SQLite
checkpointer = SqliteSaver.from_conn_string("checkpoints.db")

# In-memory SQLite (testing)
checkpointer = SqliteSaver.from_conn_string(":memory:")

graph = builder.compile(checkpointer=checkpointer)
```

---

### 3. PostgresSaver (Production)

```
+------------------------------------------------------------------+
|                     POSTGRESQL SAVER                              |
+------------------------------------------------------------------+
|                                                                   |
|   Characteristics:                                                |
|   - External PostgreSQL database                                  |
|   - Full ACID compliance                                          |
|   - Concurrent read/write support                                 |
|   - Horizontal scaling with read replicas                         |
|                                                                   |
|   Use Cases:                                                      |
|   - Production deployments                                        |
|   - Multi-server architectures                                    |
|   - High availability requirements                                |
|   - Enterprise applications                                       |
|                                                                   |
|   Requirements:                                                   |
|   - PostgreSQL 12+                                                |
|   - Network connectivity                                          |
|   - Connection pool management                                    |
|                                                                   |
+------------------------------------------------------------------+
```

**Architecture**:
```
+------------------------------------------------------------------+
|                    PRODUCTION ARCHITECTURE                        |
+------------------------------------------------------------------+
|                                                                   |
|   +--------+     +--------+     +--------+                        |
|   | App    |     | App    |     | App    |                        |
|   | Server |     | Server |     | Server |                        |
|   +---+----+     +---+----+     +---+----+                        |
|       |              |              |                             |
|       v              v              v                             |
|   +------------------------------------------+                    |
|   |          Connection Pool (pgbouncer)     |                    |
|   +------------------------------------------+                    |
|                       |                                           |
|                       v                                           |
|   +------------------------------------------+                    |
|   |          PostgreSQL Primary              |                    |
|   |          (Write operations)              |                    |
|   +------------------------------------------+                    |
|                       |                                           |
|           +-----------+-----------+                               |
|           |                       |                               |
|           v                       v                               |
|   +----------------+     +----------------+                       |
|   | Read Replica 1 |     | Read Replica 2 |                       |
|   +----------------+     +----------------+                       |
|                                                                   |
+------------------------------------------------------------------+
```

**Code Example**:
```python
from langgraph.checkpoint.postgres import PostgresSaver
import psycopg2

# Sync connection
conn = psycopg2.connect(
    host="localhost",
    database="langgraph",
    user="postgres",
    password="password"
)
checkpointer = PostgresSaver(conn)

# Or from connection string
checkpointer = PostgresSaver.from_conn_string(
    "postgresql://user:pass@host:5432/dbname"
)

graph = builder.compile(checkpointer=checkpointer)
```

---

## Checkpointer Comparison

| Feature | MemorySaver | SqliteSaver | PostgresSaver |
|---------|-------------|-------------|---------------|
| Persistence | No | Yes | Yes |
| Multi-process | No | Limited | Yes |
| Clustering | No | No | Yes |
| Setup complexity | None | Low | Medium |
| Performance | Fast | Fast | Network dependent |
| Backup/Recovery | N/A | File copy | Standard DB tools |
| Use case | Development | Dev/Small prod | Production |

---

## Thread Management

Every graph execution requires a `thread_id` for checkpointing:

```
+------------------------------------------------------------------+
|                    THREAD CONCEPT                                 |
+------------------------------------------------------------------+
|                                                                   |
|   thread_id = "user_123_conversation_1"                           |
|   +-----------------------------------------------------------+   |
|   |   Checkpoint 1   -->   Checkpoint 2   -->   Checkpoint 3  |   |
|   |   (User query)         (AI response)       (Follow-up)    |   |
|   +-----------------------------------------------------------+   |
|                                                                   |
|   thread_id = "user_123_conversation_2"                           |
|   +-----------------------------------------------------------+   |
|   |   Checkpoint 1   -->   Checkpoint 2                       |   |
|   |   (New topic)          (AI response)                      |   |
|   +-----------------------------------------------------------+   |
|                                                                   |
|   Different threads = Different conversation histories            |
|   Same thread = Continuous conversation                           |
|                                                                   |
+------------------------------------------------------------------+
```

**Thread ID Best Practices**:
```python
# User-scoped conversation
thread_id = f"user_{user_id}_chat_{conversation_id}"

# Session-based
thread_id = f"session_{session_id}"

# Request-based (one-shot, no history)
thread_id = f"request_{uuid4()}"

# Configuration
config = {"configurable": {"thread_id": thread_id}}
result = graph.invoke(inputs, config)
```

---

## Checkpoint Lifecycle

```
+------------------------------------------------------------------+
|                    CHECKPOINT LIFECYCLE                           |
+------------------------------------------------------------------+
|                                                                   |
|   1. CREATION                                                     |
|   +------------------+                                            |
|   | Graph executes   |                                            |
|   | node A           |                                            |
|   +--------+---------+                                            |
|            |                                                      |
|            v                                                      |
|   +------------------+                                            |
|   | Checkpoint saved |  <-- State after node A                    |
|   | checkpoint_id: 1 |                                            |
|   +------------------+                                            |
|            |                                                      |
|            v                                                      |
|   2. CHAINING                                                     |
|   +------------------+                                            |
|   | Graph executes   |                                            |
|   | node B           |                                            |
|   +--------+---------+                                            |
|            |                                                      |
|            v                                                      |
|   +------------------+                                            |
|   | Checkpoint saved |  <-- State after node B                    |
|   | checkpoint_id: 2 |      parent: checkpoint_id 1               |
|   +------------------+                                            |
|            |                                                      |
|            v                                                      |
|   3. RESUME                                                       |
|   +------------------+                                            |
|   | New invoke()     |                                            |
|   | with same        |                                            |
|   | thread_id        |                                            |
|   +--------+---------+                                            |
|            |                                                      |
|            v                                                      |
|   +------------------+                                            |
|   | Load latest      |  <-- Resumes from checkpoint 2             |
|   | checkpoint       |                                            |
|   +------------------+                                            |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Async Checkpointers

For async applications, use async-compatible checkpointers:

```python
# Async SQLite
from langgraph.checkpoint.sqlite.aio import AsyncSqliteSaver

async with AsyncSqliteSaver.from_conn_string("checkpoints.db") as checkpointer:
    graph = builder.compile(checkpointer=checkpointer)
    result = await graph.ainvoke(inputs, config)

# Async PostgreSQL
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver

async with AsyncPostgresSaver.from_conn_string(connection_string) as checkpointer:
    graph = builder.compile(checkpointer=checkpointer)
    result = await graph.ainvoke(inputs, config)
```

---

## Checkpoint Metadata

Store and retrieve additional metadata with checkpoints:

```python
# When invoking, add metadata
config = {
    "configurable": {
        "thread_id": "thread_123"
    },
    "metadata": {
        "user_id": "user_456",
        "source": "web_chat",
        "timestamp": "2024-01-15T10:30:00Z"
    }
}

result = graph.invoke(inputs, config)

# Retrieve checkpoint with metadata
from langgraph.checkpoint.base import BaseCheckpointSaver

state = graph.get_state(config)
print(state.metadata)  # Access stored metadata
```

---

## State Management Operations

### Get Current State
```python
# Get the latest state for a thread
state = graph.get_state(config)
print(state.values)      # Current state values
print(state.next)        # Next node(s) to execute
print(state.config)      # Configuration used
```

### Get State History
```python
# Get all checkpoints for a thread
for state in graph.get_state_history(config):
    print(f"Checkpoint: {state.config}")
    print(f"Values: {state.values}")
    print(f"Created at: {state.created_at}")
```

### Update State Manually
```python
# Manually update state (use cautiously)
graph.update_state(
    config,
    {"messages": [HumanMessage(content="Injected message")]},
    as_node="human_input"  # Pretend this came from a node
)
```

---

## Production Considerations

### 1. Connection Pooling

```
+------------------------------------------------------------------+
|                    CONNECTION POOLING                             |
+------------------------------------------------------------------+
|                                                                   |
|   WITHOUT POOLING (Bad):                                          |
|   +--------+     +--------+     +--------+                        |
|   | Request|     | Request|     | Request|                        |
|   +---+----+     +---+----+     +---+----+                        |
|       |              |              |                             |
|       v              v              v                             |
|   [New conn]    [New conn]    [New conn]  <-- Connection overhead |
|       |              |              |                             |
|       v              v              v                             |
|   +------------------------------------------+                    |
|   |              PostgreSQL                  |                    |
|   +------------------------------------------+                    |
|                                                                   |
|   WITH POOLING (Good):                                            |
|   +--------+     +--------+     +--------+                        |
|   | Request|     | Request|     | Request|                        |
|   +---+----+     +---+----+     +---+----+                        |
|       |              |              |                             |
|       v              v              v                             |
|   +------------------------------------------+                    |
|   |     Connection Pool (pgbouncer)          |                    |
|   |   [Conn 1] [Conn 2] [Conn 3] [Conn 4]    |                    |
|   +------------------------------------------+                    |
|                       |                                           |
|                       v                                           |
|   +------------------------------------------+                    |
|   |              PostgreSQL                  |                    |
|   +------------------------------------------+                    |
|                                                                   |
+------------------------------------------------------------------+
```

### 2. Checkpoint Cleanup

```python
# Implement TTL-based cleanup
async def cleanup_old_checkpoints(
    checkpointer: PostgresSaver,
    max_age_days: int = 30
):
    """Remove checkpoints older than max_age_days."""
    cutoff = datetime.now() - timedelta(days=max_age_days)
    
    # Implementation depends on checkpointer
    # Custom SQL for PostgreSQL:
    await checkpointer.conn.execute("""
        DELETE FROM checkpoints
        WHERE created_at < $1
    """, cutoff)
```

### 3. Backup Strategy

| Checkpointer | Backup Method |
|--------------|---------------|
| MemorySaver | N/A (not persistent) |
| SqliteSaver | File copy, rsync |
| PostgresSaver | pg_dump, continuous archiving |

---

## When to Use Which Checkpointer

```
+------------------------------------------------------------------+
|                    DECISION FLOWCHART                             |
+------------------------------------------------------------------+
|                                                                   |
|                    +-------------------+                          |
|                    | Need persistence? |                          |
|                    +--------+----------+                          |
|                             |                                     |
|              +--------------+--------------+                      |
|              |                             |                      |
|              v                             v                      |
|         +--------+                    +---------+                 |
|         |   No   |                    |   Yes   |                 |
|         +---+----+                    +----+----+                 |
|             |                              |                      |
|             v                              v                      |
|      +--------------+           +-------------------+             |
|      | MemorySaver  |           | Multi-server?     |             |
|      +--------------+           +--------+----------+             |
|                                          |                        |
|                       +------------------+------------------+      |
|                       |                                     |      |
|                       v                                     v      |
|                  +---------+                          +---------+  |
|                  |   No    |                          |   Yes   |  |
|                  +----+----+                          +----+----+  |
|                       |                                    |       |
|                       v                                    v       |
|               +--------------+                    +--------------+ |
|               | SqliteSaver  |                    |PostgresSaver | |
|               +--------------+                    +--------------+ |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Interview Tips

```
+------------------------------------------------------------------+
|                         INTERVIEW TIP                             |
+------------------------------------------------------------------+
| Q: "How would you handle persistence in a distributed system?"    |
|                                                                   |
| A: Key considerations:                                            |
|    1. Use PostgresSaver for cross-server state access             |
|    2. Implement connection pooling (pgbouncer)                    |
|    3. Use thread_id namespacing to prevent collisions             |
|    4. Add checkpoint TTL for storage management                   |
|    5. Consider read replicas for read-heavy workloads             |
|                                                                   |
| Architecture:                                                     |
|    - Primary DB for writes                                        |
|    - Read replicas for read-heavy operations                      |
|    - Connection pool between app and DB                           |
|    - Regular backup schedule                                      |
+------------------------------------------------------------------+
```

```
+------------------------------------------------------------------+
|                         INTERVIEW TIP                             |
+------------------------------------------------------------------+
| Q: "How do you handle checkpoint storage growth?"                 |
|                                                                   |
| A: Strategies:                                                    |
|    1. TTL-based cleanup (delete old checkpoints)                  |
|    2. Limit checkpoints per thread (keep last N)                  |
|    3. Compress checkpoint data                                    |
|    4. Archive to cold storage (S3)                                |
|    5. Use separate DB for active vs. historical                   |
|                                                                   |
| Example policy:                                                   |
|    - Keep all checkpoints for 7 days                              |
|    - Keep last 10 checkpoints per thread indefinitely             |
|    - Archive conversations > 30 days to S3                        |
+------------------------------------------------------------------+
```

---

## Summary

- **MemorySaver**: Development only, no persistence
- **SqliteSaver**: File-based, single-server persistence
- **PostgresSaver**: Production-grade, multi-server support
- **thread_id**: Unique identifier for conversation continuity
- **Checkpoints**: Automatic state snapshots after each node
- **Async variants**: For high-concurrency applications

**Production Checklist**:
- [ ] Use PostgresSaver for multi-server deployments
- [ ] Implement connection pooling
- [ ] Set up checkpoint cleanup/archival
- [ ] Configure proper backup strategy
- [ ] Use meaningful thread_id naming convention

---

Next: See `06_persistence_example.py` for working implementations.
