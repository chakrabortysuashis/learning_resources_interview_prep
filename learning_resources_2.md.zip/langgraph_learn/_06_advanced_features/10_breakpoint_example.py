"""
Breakpoint Examples in LangGraph
================================

This module demonstrates breakpoint debugging capabilities:
1. interrupt_before - Pause before node execution
2. interrupt_after - Pause after node execution
3. Inline interrupt() - Conditional pauses
4. State inspection and modification
5. Interactive debugging patterns

Real-World Scenario: Data Processing Pipeline with Quality Gates
"""

# ============================================================================
# IMPORTS
# ============================================================================
from typing import TypedDict, Optional, List, Literal
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.memory import MemorySaver
from langgraph.types import interrupt, Command
import json

# ============================================================================
# STATE DEFINITION
# ============================================================================

class PipelineState(TypedDict):
    """
    State for a data processing pipeline.

    Tracks data through multiple processing stages.
    """
    # Input data
    raw_data: dict

    # Processing stages
    validated_data: Optional[dict]
    transformed_data: Optional[dict]
    enriched_data: Optional[dict]

    # Quality metrics
    validation_score: Optional[float]
    quality_issues: List[str]

    # Status tracking
    current_stage: str
    is_approved: bool


# ============================================================================
# NODE FUNCTIONS
# ============================================================================

def ingest_data(state: PipelineState) -> dict:
    """
    Ingest raw data into the pipeline.

    +-------------------+
    |    Raw Input      |
    +--------+----------+
             |
             v
    +-------------------+
    |   Parse & Load    |
    +-------------------+
    """
    print("[ingest_data] Ingesting raw data...")

    raw_data = state.get("raw_data", {})

    return {
        "current_stage": "ingested",
        "quality_issues": []
    }


def validate_data(state: PipelineState) -> dict:
    """
    Validate data quality.

    This node might produce issues we want to inspect.

    +-------------------+
    |  Ingested Data    |
    +--------+----------+
             |
             v
    +-------------------+
    | Validation Rules  |
    | - Schema check    |
    | - Range check     |
    | - Required fields |
    +--------+----------+
             |
             v
    +-------------------+
    | Validation Score  |
    +-------------------+
    """
    print("[validate_data] Running validation...")

    raw_data = state.get("raw_data", {})
    issues = []

    # Simulate validation checks
    if "id" not in raw_data:
        issues.append("Missing required field: id")

    if "value" in raw_data:
        if raw_data["value"] < 0:
            issues.append("Validation error: value cannot be negative")
        if raw_data["value"] > 1000:
            issues.append("Warning: value exceeds normal range")

    if "timestamp" not in raw_data:
        issues.append("Missing required field: timestamp")

    # Calculate validation score
    total_checks = 4
    passed_checks = total_checks - len(issues)
    score = passed_checks / total_checks

    print(f"[validate_data] Score: {score:.2f}, Issues: {len(issues)}")

    return {
        "validated_data": raw_data if score > 0.5 else None,
        "validation_score": score,
        "quality_issues": issues,
        "current_stage": "validated"
    }


def transform_data(state: PipelineState) -> dict:
    """
    Transform data for downstream processing.

    +-------------------+
    |  Validated Data   |
    +--------+----------+
             |
             v
    +-------------------+
    | Transformations:  |
    | - Normalize       |
    | - Calculate       |
    | - Format          |
    +--------+----------+
             |
             v
    +-------------------+
    | Transformed Data  |
    +-------------------+
    """
    print("[transform_data] Transforming data...")

    validated = state.get("validated_data", {})

    # Simulate transformations
    transformed = {
        **validated,
        "processed": True,
        "normalized_value": validated.get("value", 0) / 100,
        "category": "A" if validated.get("value", 0) > 50 else "B"
    }

    return {
        "transformed_data": transformed,
        "current_stage": "transformed"
    }


def enrich_data(state: PipelineState) -> dict:
    """
    Enrich data with additional information.

    +-------------------+
    | Transformed Data  |
    +--------+----------+
             |
             v
    +-------------------+
    | Enrichment:       |
    | - Add metadata    |
    | - Lookup refs     |
    | - Compute derived |
    +--------+----------+
             |
             v
    +-------------------+
    |  Enriched Data    |
    +-------------------+
    """
    print("[enrich_data] Enriching data...")

    transformed = state.get("transformed_data", {})

    # Simulate enrichment
    enriched = {
        **transformed,
        "enriched": True,
        "metadata": {
            "source": "pipeline_v1",
            "quality_score": state.get("validation_score", 0)
        }
    }

    return {
        "enriched_data": enriched,
        "current_stage": "enriched"
    }


def finalize_output(state: PipelineState) -> dict:
    """
    Finalize and output the processed data.

    +-------------------+
    |  Enriched Data    |
    +--------+----------+
             |
             v
    +-------------------+
    | Final Processing  |
    +--------+----------+
             |
             v
    +-------------------+
    |    Output Ready   |
    +-------------------+
    """
    print("[finalize_output] Finalizing output...")

    return {
        "current_stage": "complete",
        "is_approved": True
    }


# ============================================================================
# DEMO 1: INTERRUPT_BEFORE
# ============================================================================

def demo_interrupt_before():
    """
    Demonstrate interrupt_before - pause before a node executes.

    Use case: Inspect data before critical transformation.
    """
    print("\n" + "=" * 70)
    print("DEMO 1: interrupt_before - Pause Before Transformation")
    print("=" * 70)

    checkpointer = MemorySaver()

    # Build graph
    builder = StateGraph(PipelineState)
    builder.add_node("ingest", ingest_data)
    builder.add_node("validate", validate_data)
    builder.add_node("transform", transform_data)
    builder.add_node("enrich", enrich_data)
    builder.add_node("finalize", finalize_output)

    builder.add_edge(START, "ingest")
    builder.add_edge("ingest", "validate")
    builder.add_edge("validate", "transform")
    builder.add_edge("transform", "enrich")
    builder.add_edge("enrich", "finalize")
    builder.add_edge("finalize", END)

    # Compile WITH breakpoint before transform
    graph = builder.compile(
        checkpointer=checkpointer,
        interrupt_before=["transform"]  # Pause before transformation
    )

    config = {"configurable": {"thread_id": "pipeline_001"}}

    # Start pipeline
    print("\n--- Starting Pipeline ---")
    initial_state = {
        "raw_data": {"id": "123", "value": 75, "timestamp": "2024-01-15"},
        "validated_data": None,
        "transformed_data": None,
        "enriched_data": None,
        "validation_score": None,
        "quality_issues": [],
        "current_stage": "start",
        "is_approved": False
    }

    result = graph.invoke(initial_state, config)

    # Execution pauses before "transform" node
    print("\n--- Execution Paused (interrupt_before='transform') ---")

    # Inspect state at breakpoint
    state = graph.get_state(config)
    print(f"\nCurrent stage: {state.values.get('current_stage')}")
    print(f"Next node(s): {state.next}")
    print(f"Validation score: {state.values.get('validation_score')}")
    print(f"Quality issues: {state.values.get('quality_issues')}")

    # Decide whether to continue
    print("\n--- Inspecting State Before Transformation ---")
    validated_data = state.values.get("validated_data")
    print(f"Validated data to transform: {validated_data}")

    # Resume execution
    print("\n--- Resuming Execution ---")
    result = graph.invoke(None, config)

    print(f"\nFinal stage: {result.get('current_stage')}")
    print(f"Pipeline complete: {result.get('is_approved')}")

    print("\n[interrupt_before Demo Complete]")


# ============================================================================
# DEMO 2: INTERRUPT_AFTER
# ============================================================================

def demo_interrupt_after():
    """
    Demonstrate interrupt_after - pause after a node completes.

    Use case: Review validation results before proceeding.
    """
    print("\n" + "=" * 70)
    print("DEMO 2: interrupt_after - Pause After Validation")
    print("=" * 70)

    checkpointer = MemorySaver()

    # Build graph
    builder = StateGraph(PipelineState)
    builder.add_node("ingest", ingest_data)
    builder.add_node("validate", validate_data)
    builder.add_node("transform", transform_data)
    builder.add_node("finalize", finalize_output)

    builder.add_edge(START, "ingest")
    builder.add_edge("ingest", "validate")
    builder.add_edge("validate", "transform")
    builder.add_edge("transform", "finalize")
    builder.add_edge("finalize", END)

    # Compile WITH breakpoint after validate
    graph = builder.compile(
        checkpointer=checkpointer,
        interrupt_after=["validate"]  # Pause after validation
    )

    config = {"configurable": {"thread_id": "pipeline_002"}}

    # Test with problematic data
    print("\n--- Starting Pipeline with Problematic Data ---")
    initial_state = {
        "raw_data": {"value": -50},  # Missing required fields, negative value
        "validated_data": None,
        "transformed_data": None,
        "enriched_data": None,
        "validation_score": None,
        "quality_issues": [],
        "current_stage": "start",
        "is_approved": False
    }

    result = graph.invoke(initial_state, config)

    # Execution pauses after "validate" node
    print("\n--- Execution Paused (interrupt_after='validate') ---")

    # Inspect validation results
    state = graph.get_state(config)
    print(f"\nValidation complete!")
    print(f"Score: {state.values.get('validation_score')}")
    print(f"Issues found: {state.values.get('quality_issues')}")
    print(f"Next node: {state.next}")

    # Option 1: Fix data and continue
    print("\n--- Fixing Data Before Resuming ---")
    graph.update_state(
        config,
        {
            "validated_data": {"id": "fixed_123", "value": 50, "timestamp": "2024-01-15"},
            "validation_score": 1.0,
            "quality_issues": []
        }
    )

    # Resume with fixed data
    print("\n--- Resuming with Fixed Data ---")
    result = graph.invoke(None, config)

    print(f"\nFinal stage: {result.get('current_stage')}")
    print(f"Final data: {result.get('enriched_data', result.get('transformed_data'))}")

    print("\n[interrupt_after Demo Complete]")


# ============================================================================
# DEMO 3: MULTIPLE BREAKPOINTS (Step-by-Step)
# ============================================================================

def demo_step_by_step():
    """
    Demonstrate step-by-step execution with multiple breakpoints.

    Use case: Detailed debugging of entire pipeline.
    """
    print("\n" + "=" * 70)
    print("DEMO 3: Step-by-Step Execution")
    print("=" * 70)

    checkpointer = MemorySaver()

    # Build graph
    builder = StateGraph(PipelineState)
    builder.add_node("ingest", ingest_data)
    builder.add_node("validate", validate_data)
    builder.add_node("transform", transform_data)
    builder.add_node("finalize", finalize_output)

    builder.add_edge(START, "ingest")
    builder.add_edge("ingest", "validate")
    builder.add_edge("validate", "transform")
    builder.add_edge("transform", "finalize")
    builder.add_edge("finalize", END)

    # Breakpoint after EVERY node
    graph = builder.compile(
        checkpointer=checkpointer,
        interrupt_after=["ingest", "validate", "transform", "finalize"]
    )

    config = {"configurable": {"thread_id": "pipeline_003"}}

    initial_state = {
        "raw_data": {"id": "step_001", "value": 100, "timestamp": "2024-01-15"},
        "validated_data": None,
        "transformed_data": None,
        "enriched_data": None,
        "validation_score": None,
        "quality_issues": [],
        "current_stage": "start",
        "is_approved": False
    }

    print("\n--- Step-by-Step Execution ---")

    # Start
    result = graph.invoke(initial_state, config)
    step = 1

    while True:
        state = graph.get_state(config)

        print(f"\n=== Step {step} Complete ===")
        print(f"Stage: {state.values.get('current_stage')}")
        print(f"Next: {state.next if state.next else 'END'}")

        if not state.next:
            print("\nPipeline complete!")
            break

        # In interactive mode, you would prompt user here
        # For demo, we auto-continue
        print("Continuing to next step...")
        result = graph.invoke(None, config)
        step += 1

    print(f"\nFinal result: {result.get('current_stage')}")

    print("\n[Step-by-Step Demo Complete]")


# ============================================================================
# DEMO 4: CONDITIONAL INLINE INTERRUPT
# ============================================================================

def demo_conditional_interrupt():
    """
    Demonstrate inline interrupt() for conditional breakpoints.

    Use case: Only pause when quality issues are detected.
    """
    print("\n" + "=" * 70)
    print("DEMO 4: Conditional Inline Interrupt")
    print("=" * 70)

    def validate_with_conditional_interrupt(state: PipelineState) -> dict:
        """Validation node with conditional interrupt."""
        print("[validate] Running validation with conditional interrupt...")

        raw_data = state.get("raw_data", {})
        issues = []

        # Validation checks
        if "id" not in raw_data:
            issues.append("Missing required field: id")
        if raw_data.get("value", 0) < 0:
            issues.append("Negative value detected")
        if raw_data.get("value", 0) > 1000:
            issues.append("Value exceeds maximum threshold")

        score = max(0, 1 - len(issues) * 0.25)

        # CONDITIONAL INTERRUPT: Only if there are issues
        if issues:
            print(f"[validate] Issues found! Requesting human review...")

            human_response = interrupt({
                "type": "validation_review",
                "issues": issues,
                "score": score,
                "data": raw_data,
                "question": "Data has quality issues. Approve to continue anyway?"
            })

            # Process human response
            if human_response.get("approved"):
                print("[validate] Human approved despite issues")
                issues.append("HUMAN_APPROVED_WITH_ISSUES")
            else:
                print("[validate] Human rejected - will need fixes")
                # Could modify data here based on human input

        return {
            "validated_data": raw_data,
            "validation_score": score,
            "quality_issues": issues,
            "current_stage": "validated"
        }

    checkpointer = MemorySaver()

    builder = StateGraph(PipelineState)
    builder.add_node("ingest", ingest_data)
    builder.add_node("validate", validate_with_conditional_interrupt)
    builder.add_node("transform", transform_data)
    builder.add_node("finalize", finalize_output)

    builder.add_edge(START, "ingest")
    builder.add_edge("ingest", "validate")
    builder.add_edge("validate", "transform")
    builder.add_edge("transform", "finalize")
    builder.add_edge("finalize", END)

    graph = builder.compile(checkpointer=checkpointer)

    # Test 1: Clean data (no interrupt)
    print("\n--- Test 1: Clean Data (No Interrupt) ---")
    config1 = {"configurable": {"thread_id": "cond_001"}}

    result = graph.invoke({
        "raw_data": {"id": "clean_001", "value": 50, "timestamp": "2024-01-15"},
        "validated_data": None,
        "transformed_data": None,
        "enriched_data": None,
        "validation_score": None,
        "quality_issues": [],
        "current_stage": "start",
        "is_approved": False
    }, config1)

    print(f"Result: {result.get('current_stage')} (no interrupt needed)")

    # Test 2: Problematic data (will trigger interrupt)
    print("\n--- Test 2: Problematic Data (Will Interrupt) ---")
    config2 = {"configurable": {"thread_id": "cond_002"}}

    result = graph.invoke({
        "raw_data": {"value": -100},  # Missing id, negative value
        "validated_data": None,
        "transformed_data": None,
        "enriched_data": None,
        "validation_score": None,
        "quality_issues": [],
        "current_stage": "start",
        "is_approved": False
    }, config2)

    # Execution pauses at interrupt
    state = graph.get_state(config2)
    print(f"Paused! Issues: {state.values.get('quality_issues')}")

    # Resume with human approval
    print("\n--- Human Approves Despite Issues ---")
    result = graph.invoke(
        Command(resume={"approved": True, "comment": "Acceptable for testing"}),
        config2
    )

    print(f"Final stage: {result.get('current_stage')}")
    print(f"Final issues: {result.get('quality_issues')}")

    print("\n[Conditional Interrupt Demo Complete]")


# ============================================================================
# DEMO 5: INTERACTIVE DEBUGGER
# ============================================================================

def interactive_debugger(graph, config, initial_state):
    """
    Simple interactive debugger using breakpoints.

    This function provides a REPL-like debugging experience.

    Commands:
    - c: Continue to next breakpoint
    - s: Show current state
    - m: Modify state
    - h: Show history
    - q: Quit
    """
    print("\n=== Interactive Debugger ===")
    print("Commands: (c)ontinue, (s)tate, (m)odify, (h)istory, (q)uit\n")

    # Start execution
    result = graph.invoke(initial_state, config)

    while True:
        state = graph.get_state(config)

        if not state.next:
            print("\n[Execution Complete]")
            print(f"Final state: {json.dumps(state.values, indent=2, default=str)}")
            break

        print(f"\n>>> Breakpoint: Next node = {state.next}")

        # Simulate command input (in real use, would be input())
        # For demo, we'll auto-continue after showing state
        print(f"Current stage: {state.values.get('current_stage')}")

        # Auto-continue for demo
        print("[Auto-continue for demo]")
        result = graph.invoke(None, config)

    return result


def demo_interactive_debugger():
    """
    Demonstrate interactive debugging pattern.
    """
    print("\n" + "=" * 70)
    print("DEMO 5: Interactive Debugger Pattern")
    print("=" * 70)

    checkpointer = MemorySaver()

    builder = StateGraph(PipelineState)
    builder.add_node("ingest", ingest_data)
    builder.add_node("validate", validate_data)
    builder.add_node("transform", transform_data)
    builder.add_node("finalize", finalize_output)

    builder.add_edge(START, "ingest")
    builder.add_edge("ingest", "validate")
    builder.add_edge("validate", "transform")
    builder.add_edge("transform", "finalize")
    builder.add_edge("finalize", END)

    graph = builder.compile(
        checkpointer=checkpointer,
        interrupt_after=["ingest", "validate", "transform"]
    )

    config = {"configurable": {"thread_id": "debug_001"}}

    initial_state = {
        "raw_data": {"id": "debug_test", "value": 75, "timestamp": "2024-01-15"},
        "validated_data": None,
        "transformed_data": None,
        "enriched_data": None,
        "validation_score": None,
        "quality_issues": [],
        "current_stage": "start",
        "is_approved": False
    }

    result = interactive_debugger(graph, config, initial_state)

    print("\n[Interactive Debugger Demo Complete]")


# ============================================================================
# INTERVIEW TIP
# ============================================================================
"""
+--------------------------------------------------------------------------+
|                              INTERVIEW TIP                                |
+--------------------------------------------------------------------------+
| Q: "How would you implement a CI/CD pipeline approval gate using         |
|     LangGraph breakpoints?"                                              |
|                                                                           |
| A: Architecture:                                                          |
|                                                                           |
|    1. PIPELINE DESIGN                                                     |
|       nodes: [build, test, security_scan, deploy_staging,                 |
|               APPROVAL_GATE, deploy_production]                           |
|       interrupt_before=["deploy_production"]                              |
|                                                                           |
|    2. APPROVAL WORKFLOW                                                   |
|       - Pipeline runs through staging automatically                       |
|       - Pauses at production deployment gate                              |
|       - Notifies approvers (Slack/email)                                  |
|       - Approver reviews test results, security scan                      |
|       - Resume with approval or reject                                    |
|                                                                           |
|    3. STATE MANAGEMENT                                                    |
|       - Checkpoint contains all artifacts, test results                   |
|       - Approver can inspect full state                                   |
|       - Audit trail of who approved and when                              |
|                                                                           |
|    4. TIMEOUT HANDLING                                                    |
|       - If no approval in 24h, notify escalation                          |
|       - If no approval in 48h, auto-reject with notification              |
|                                                                           |
| Code snippet:                                                             |
|    graph = builder.compile(                                               |
|        checkpointer=PostgresSaver(...),  # Durable                        |
|        interrupt_before=["deploy_production"]                             |
|    )                                                                      |
+--------------------------------------------------------------------------+
"""


# ============================================================================
# MAIN EXECUTION
# ============================================================================

if __name__ == "__main__":
    demo_interrupt_before()
    demo_interrupt_after()
    demo_step_by_step()
    demo_conditional_interrupt()
    demo_interactive_debugger()

    print("\n" + "=" * 70)
    print("KEY TAKEAWAYS")
    print("=" * 70)
    print("""
    1. BREAKPOINT TYPES:
       - interrupt_before: Pause BEFORE node executes
       - interrupt_after: Pause AFTER node completes
       - interrupt(): Inline conditional pause

    2. STATE INSPECTION:
       - graph.get_state(config): Get current state at breakpoint
       - state.values: Current state dictionary
       - state.next: Tuple of next node(s)

    3. RESUMING:
       - graph.invoke(None, config): Continue as-is
       - graph.update_state(config, updates): Modify then continue
       - graph.invoke(Command(resume=...), config): For inline interrupts

    4. USE CASES:
       - Development debugging
       - Step-by-step execution
       - Quality gates in pipelines
       - Approval workflows

    5. BEST PRACTICES:
       - Use interrupt_before for input inspection
       - Use interrupt_after for output review
       - Use inline interrupt() for conditional pauses
       - Remove breakpoints for production (or use sparingly)
    """)
