# Human-in-the-Loop (HITL) in LangGraph

## What is Human-in-the-Loop?

Human-in-the-Loop (HITL) is a design pattern where AI systems pause execution to request human input, approval, or intervention before proceeding with certain actions.

```
+------------------------------------------------------------------+
|                    HUMAN-IN-THE-LOOP PATTERN                      |
+------------------------------------------------------------------+
|                                                                   |
|    +--------+     +----------+     +--------+     +---------+     |
|    |  AI    |---->| INTERRUPT|---->| HUMAN  |---->|   AI    |     |
|    | Action |     |   POINT  |     | REVIEW |     | Resumes |     |
|    +--------+     +----------+     +--------+     +---------+     |
|                         |               |                         |
|                         |     +---------+---------+               |
|                         |     |                   |               |
|                         v     v                   v               |
|                    +--------+  +--------+    +--------+           |
|                    |APPROVE |  | REJECT |    | MODIFY |           |
|                    +--------+  +--------+    +--------+           |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Why Use HITL?

### 1. Safety and Risk Mitigation
- Prevent costly mistakes (financial transactions, data deletion)
- Validate sensitive operations before execution
- Comply with regulatory requirements

### 2. Quality Assurance
- Review AI-generated content before publishing
- Verify accuracy of critical information
- Catch hallucinations or errors

### 3. Trust Building
- Build user confidence in AI systems
- Provide transparency in AI decision-making
- Allow gradual automation adoption

---

## HITL Patterns in LangGraph

### Pattern 1: Interrupt Before Action

```
+----------+     +------------+     +----------+     +---------+
|  START   |---->|  PREPARE   |---->| INTERRUPT|---->|  HUMAN  |
+----------+     |  ACTION    |     |  BEFORE  |     | REVIEWS |
                 +------------+     +----------+     +---------+
                                                          |
                 +------------+     +----------+          |
                 |  EXECUTE   |<----|  RESUME  |<---------+
                 |  ACTION    |     |   WITH   |     (if approved)
                 +------------+     | APPROVAL |
                                    +----------+
```

**Use When**: You need approval BEFORE an action occurs (e.g., sending email, making payment)

### Pattern 2: Interrupt After Action (Review)

```
+----------+     +------------+     +----------+     +---------+
|  START   |---->|  EXECUTE   |---->| INTERRUPT|---->|  HUMAN  |
+----------+     |  ACTION    |     |  AFTER   |     | REVIEWS |
                 +------------+     +----------+     +---------+
                                                          |
                 +------------+     +----------+          |
                 |  FINALIZE  |<----|  RESUME  |<---------+
                 |            |     |   WITH   |     (modify/approve)
                 +------------+     | FEEDBACK |
                                    +----------+
```

**Use When**: You want to review results AFTER generation (e.g., reviewing draft, validating research)

### Pattern 3: Conditional Interrupt

```
+----------+     +------------+     +----------+
|  START   |---->|  EVALUATE  |---->| THRESHOLD|
+----------+     |  RISK/COST |     |  CHECK   |
                 +------------+     +----+-----+
                                         |
                       +-----------------+-----------------+
                       |                                   |
                       v                                   v
               +---------------+                   +---------------+
               |  HIGH RISK    |                   |   LOW RISK    |
               |  -> INTERRUPT |                   | -> AUTO-PROCEED|
               +---------------+                   +---------------+
```

**Use When**: Only certain conditions require human review (e.g., transactions above threshold)

---

## Core LangGraph HITL Mechanisms

### 1. The `interrupt()` Function

The primary way to pause execution and request human input:

```python
from langgraph.types import interrupt

def review_node(state):
    # Prepare data for human review
    draft = state["draft_content"]
    
    # Interrupt and wait for human input
    human_response = interrupt({
        "type": "review_request",
        "content": draft,
        "question": "Please approve or provide feedback"
    })
    
    # Resume with human response
    if human_response["approved"]:
        return {"status": "approved"}
    else:
        return {"feedback": human_response["feedback"]}
```

### 2. The `Command` Object

Used to provide input when resuming from an interrupt:

```python
from langgraph.types import Command

# When resuming after interrupt
graph.invoke(
    Command(resume={"approved": True, "feedback": "Looks good!"}),
    config={"configurable": {"thread_id": "123"}}
)
```

### 3. Graph-Level Interrupt Configuration

Configure interrupts at node boundaries:

```python
# Interrupt BEFORE a node executes
graph = builder.compile(
    checkpointer=checkpointer,
    interrupt_before=["sensitive_action_node"]
)

# Interrupt AFTER a node executes
graph = builder.compile(
    checkpointer=checkpointer,
    interrupt_after=["draft_generation_node"]
)
```

---

## Interrupt Flow Diagram

```
+------------------------------------------------------------------+
|                      INTERRUPT LIFECYCLE                          |
+------------------------------------------------------------------+
|                                                                   |
|   STEP 1: Graph Runs Until Interrupt                              |
|   +---------+     +---------+     +---------+                     |
|   | Node A  |---->| Node B  |---->| INTERRUPT|                    |
|   +---------+     +---------+     +---------+                     |
|                                        |                          |
|                                        v                          |
|   STEP 2: State is Checkpointed                                   |
|   +--------------------------------------------------+            |
|   |  CHECKPOINT                                      |            |
|   |  - thread_id: "user_123"                         |            |
|   |  - state: {messages: [...], data: {...}}         |            |
|   |  - pending_writes: [{node: "Node C", ...}]       |            |
|   +--------------------------------------------------+            |
|                                        |                          |
|                                        v                          |
|   STEP 3: Human Provides Input                                    |
|   +--------------------------------------------------+            |
|   |  Command(resume={"approved": True})              |            |
|   +--------------------------------------------------+            |
|                                        |                          |
|                                        v                          |
|   STEP 4: Graph Resumes from Checkpoint                           |
|   +---------+     +---------+     +---------+                     |
|   | RESUME  |---->| Node C  |---->|   END   |                     |
|   +---------+     +---------+     +---------+                     |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Real-World HITL Scenarios

### Scenario 1: Content Publishing Workflow

```
+------------------------------------------------------------------+
|                   BLOG POST PUBLISHING WORKFLOW                   |
+------------------------------------------------------------------+
|                                                                   |
|   +----------+     +----------+     +----------+                  |
|   | RESEARCH |---->| GENERATE |---->| HUMAN    |                  |
|   | TOPIC    |     | DRAFT    |     | EDITOR   |                  |
|   +----------+     +----------+     | REVIEW   |                  |
|                                     +----+-----+                  |
|                                          |                        |
|                    +---------------------+---------------------+   |
|                    |                     |                     |   |
|                    v                     v                     v   |
|              +---------+          +---------+           +---------+|
|              | APPROVE |          | REQUEST |           | REJECT  ||
|              | & PUBLISH|         | CHANGES |           | & REDO  ||
|              +---------+          +---------+           +---------+|
|                    |                     |                     |   |
|                    v                     v                     v   |
|              +---------+          +---------+           +---------+|
|              | PUBLISH |          | REVISE  |           | START   ||
|              | TO CMS  |          | DRAFT   |           | OVER    ||
|              +---------+          +---------+           +---------+|
|                                                                   |
+------------------------------------------------------------------+
```

### Scenario 2: Financial Transaction Approval

```
+------------------------------------------------------------------+
|                   PAYMENT PROCESSING WORKFLOW                     |
+------------------------------------------------------------------+
|                                                                   |
|   +----------+     +----------+     +----------+                  |
|   | RECEIVE  |---->| VALIDATE |---->|  CHECK   |                  |
|   | REQUEST  |     | DETAILS  |     |  AMOUNT  |                  |
|   +----------+     +----------+     +----+-----+                  |
|                                          |                        |
|                         +----------------+----------------+        |
|                         |                                 |        |
|                         v                                 v        |
|                  +-----------+                     +-----------+   |
|                  | < $10,000 |                     | >= $10,000|   |
|                  | AUTO-APPROVE|                   | HUMAN REVIEW| |
|                  +-----------+                     +-----------+   |
|                         |                                 |        |
|                         v                                 v        |
|                  +-----------+                     +-----------+   |
|                  | PROCESS   |                     | MANAGER   |   |
|                  | PAYMENT   |                     | APPROVAL  |   |
|                  +-----------+                     +-----------+   |
|                                                                   |
+------------------------------------------------------------------+
```

### Scenario 3: Customer Support Escalation

```
+------------------------------------------------------------------+
|                    SUPPORT TICKET WORKFLOW                        |
+------------------------------------------------------------------+
|                                                                   |
|   +----------+     +----------+     +----------+                  |
|   | CUSTOMER |---->|    AI    |---->| SENTIMENT|                  |
|   | MESSAGE  |     | CLASSIFY |     | ANALYSIS |                  |
|   +----------+     +----------+     +----+-----+                  |
|                                          |                        |
|              +---------------------------+---------------------------+
|              |                           |                           |
|              v                           v                           v
|       +-----------+              +-----------+               +-----------+
|       | POSITIVE/ |              |  NEUTRAL  |               | NEGATIVE/ |
|       |  SIMPLE   |              |  COMPLEX  |               |   ANGRY   |
|       +-----------+              +-----------+               +-----------+
|              |                           |                           |
|              v                           v                           v
|       +-----------+              +-----------+               +-----------+
|       |    AI     |              |   HUMAN   |               |  ESCALATE |
|       | AUTO-REPLY|              |   REVIEW  |               | TO MANAGER|
|       +-----------+              +-----------+               +-----------+
|                                                                   |
+------------------------------------------------------------------+
```

---

## State Management During Interrupts

```python
from typing import TypedDict, Literal, Optional
from langgraph.graph import StateGraph

class HITLState(TypedDict):
    # Original request
    request: str
    
    # AI-generated content awaiting review
    draft: Optional[str]
    
    # Interrupt status
    interrupt_reason: Optional[str]
    
    # Human feedback
    human_decision: Optional[Literal["approve", "reject", "modify"]]
    human_feedback: Optional[str]
    
    # Final output
    final_output: Optional[str]
```

---

## Best Practices

### Do's

| Practice | Reason |
|----------|--------|
| Provide context | Give humans enough info to make decisions |
| Set timeouts | Prevent indefinite waits |
| Log decisions | Maintain audit trail |
| Handle rejections gracefully | Allow retry or alternative paths |
| Batch similar requests | Reduce human fatigue |

### Don'ts

| Anti-Pattern | Problem |
|--------------|---------|
| Interrupt too frequently | Creates bottlenecks, user fatigue |
| Interrupt without context | Humans can't make informed decisions |
| Ignore rejection feedback | Misses learning opportunities |
| No timeout handling | Workflows get stuck |
| Missing persistence | Lose state on restart |

---

## Interview Tips

```
+------------------------------------------------------------------+
|                         INTERVIEW TIP                             |
+------------------------------------------------------------------+
| Q: "When would you NOT use Human-in-the-Loop?"                    |
|                                                                   |
| A: HITL should be avoided when:                                   |
|    1. Speed is critical (real-time recommendations)               |
|    2. Volume is too high (millions of requests/day)               |
|    3. Stakes are low (formatting, simple classifications)         |
|    4. Human expertise isn't needed (routine operations)           |
|                                                                   |
| Key Insight: HITL adds latency and operational cost. Use it       |
| strategically for high-stakes, low-volume, or safety-critical     |
| decisions.                                                        |
+------------------------------------------------------------------+
```

```
+------------------------------------------------------------------+
|                         INTERVIEW TIP                             |
+------------------------------------------------------------------+
| Q: "How do you handle HITL in a distributed system?"              |
|                                                                   |
| A: Key considerations:                                            |
|    1. Persistent checkpoints (database-backed, not in-memory)     |
|    2. Unique thread_id per conversation/workflow                  |
|    3. Idempotent resume operations                                |
|    4. Timeout handling with graceful degradation                  |
|    5. Queue pending reviews for human dashboard                   |
|                                                                   |
| Mention: LangGraph's checkpointers (SQLite/PostgreSQL) handle     |
| persistence automatically, making it production-ready.            |
+------------------------------------------------------------------+
```

---

## Summary

Human-in-the-Loop is essential for building trustworthy AI systems that:
- Maintain human oversight over critical decisions
- Provide transparency and auditability
- Allow graceful handling of edge cases
- Build user confidence in AI capabilities

LangGraph provides first-class support through:
- `interrupt()` function for inline pauses
- `interrupt_before` / `interrupt_after` for node-level control
- `Command(resume=...)` for providing human input
- Persistent checkpointers for durable state management

---

Next: See `02_hitl_example.py` for a working implementation.
