# 01. Tools Overview in LangGraph

## What Are Tools?

**Tools are functions that extend an LLM's capabilities beyond text generation.** They allow the model to interact with the external world - searching databases, calling APIs, running calculations, and more.

```
+------------------------------------------------------------------+
|                        WITHOUT TOOLS                              |
+------------------------------------------------------------------+
|                                                                   |
|  User: "What's the weather in Paris?"                            |
|                                                                   |
|  LLM: "I don't have access to real-time weather data..."         |
|        (Can only use training data)                              |
|                                                                   |
+------------------------------------------------------------------+

+------------------------------------------------------------------+
|                         WITH TOOLS                                |
+------------------------------------------------------------------+
|                                                                   |
|  User: "What's the weather in Paris?"                            |
|                                                                   |
|  LLM:  1. "I should use the weather tool"                        |
|        2. Calls: get_weather("Paris")                            |
|        3. Tool returns: "22C, Partly Cloudy"                     |
|        4. "The weather in Paris is 22C and partly cloudy!"       |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Why Tools Matter

### The Limitations of Standalone LLMs

| Limitation | Description |
|------------|-------------|
| **Knowledge Cutoff** | Training data has a date limit |
| **No Real-Time Data** | Can't access current information |
| **No External Actions** | Can't send emails, update databases |
| **Hallucination Risk** | May make up answers when unsure |

### How Tools Solve These Problems

```
+-----------------+     +------------------+     +-----------------+
|                 |     |                  |     |                 |
|  LLM Reasoning  |---->|  Tool Execution  |---->|  Real Results   |
|  "I need data"  |     |  API/DB/Search   |     |  Factual Info   |
|                 |     |                  |     |                 |
+-----------------+     +------------------+     +-----------------+
```

---

## Tool Anatomy

Every tool in LangGraph has three essential components:

```python
from langchain_core.tools import tool

@tool                                    # 1. Decorator
def calculate_sum(                       # 2. Function name (becomes tool name)
    a: int,                              #    Parameters with types
    b: int
) -> int:                                #    Return type
    """Add two numbers together.         # 3. Docstring (CRITICAL - LLM reads this!)
    
    Use this tool when you need to add
    two numbers and get their sum.
    """
    return a + b                         # 4. Implementation
```

### Component Breakdown

```
+------------------------------------------------------------------+
|                        TOOL STRUCTURE                             |
+------------------------------------------------------------------+
|                                                                   |
|  @tool  <------------------- Marks function as a tool            |
|  |                                                                |
|  def tool_name(          <-- Name LLM uses to call the tool      |
|      param1: Type1,      <-- Input schema (type hints required)  |
|      param2: Type2                                                |
|  ) -> ReturnType:        <-- What the tool returns               |
|      """Description      <-- LLM reads this to decide when to    |
|                              use the tool (MOST IMPORTANT!)      |
|      """                                                          |
|      # Implementation    <-- Actual logic                        |
|      return result                                                |
|                                                                   |
+------------------------------------------------------------------+
```

---

## How Tools Work in LangGraph

### The Tool Execution Cycle

```
+-----------------------------------------------------------------------------+
|                           TOOL EXECUTION CYCLE                               |
+-----------------------------------------------------------------------------+
|                                                                              |
|    1. USER INPUT                                                             |
|    +--------------------+                                                    |
|    | "What's 25 * 47?"  |                                                    |
|    +--------------------+                                                    |
|              |                                                               |
|              v                                                               |
|    2. LLM REASONING                                                          |
|    +--------------------+                                                    |
|    | "I need to use the |                                                    |
|    |  calculator tool"  |                                                    |
|    +--------------------+                                                    |
|              |                                                               |
|              v                                                               |
|    3. TOOL CALL GENERATED                                                    |
|    +--------------------+                                                    |
|    | {                  |                                                    |
|    |   "name": "calc",  |                                                    |
|    |   "args": {        |                                                    |
|    |     "a": 25,       |                                                    |
|    |     "b": 47,       |                                                    |
|    |     "op": "*"      |                                                    |
|    |   }                |                                                    |
|    | }                  |                                                    |
|    +--------------------+                                                    |
|              |                                                               |
|              v                                                               |
|    4. TOOL EXECUTION                                                         |
|    +--------------------+                                                    |
|    | calc(25, 47, "*")  |                                                    |
|    | returns: 1175      |                                                    |
|    +--------------------+                                                    |
|              |                                                               |
|              v                                                               |
|    5. RESULT TO LLM                                                          |
|    +--------------------+                                                    |
|    | Tool returned 1175 |                                                    |
|    +--------------------+                                                    |
|              |                                                               |
|              v                                                               |
|    6. FINAL RESPONSE                                                         |
|    +--------------------+                                                    |
|    | "25 multiplied by  |                                                    |
|    |  47 equals 1175"   |                                                    |
|    +--------------------+                                                    |
|                                                                              |
+-----------------------------------------------------------------------------+
```

---

## Tool Types in LangGraph

### 1. Simple Tools

Basic functions with primitive parameters:

```python
@tool
def get_current_time() -> str:
    """Get the current date and time."""
    from datetime import datetime
    return datetime.now().isoformat()
```

### 2. Parameterized Tools

Tools that accept inputs:

```python
@tool
def search_database(
    query: str,
    limit: int = 10
) -> list[dict]:
    """Search the database for matching records.
    
    Args:
        query: The search query string
        limit: Maximum number of results (default: 10)
    """
    return db.search(query, limit=limit)
```

### 3. Structured Input Tools

Tools with complex input schemas:

```python
from pydantic import BaseModel, Field

class EmailInput(BaseModel):
    """Input schema for sending email."""
    to: str = Field(description="Recipient email address")
    subject: str = Field(description="Email subject line")
    body: str = Field(description="Email body content")

@tool(args_schema=EmailInput)
def send_email(to: str, subject: str, body: str) -> str:
    """Send an email to the specified recipient."""
    # Email sending logic
    return f"Email sent to {to}"
```

### 4. Async Tools

For I/O-bound operations:

```python
@tool
async def fetch_webpage(url: str) -> str:
    """Fetch content from a webpage."""
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as response:
            return await response.text()
```

---

## Tool Categories

```
+------------------------------------------------------------------+
|                      TOOL CATEGORIES                              |
+------------------------------------------------------------------+
|                                                                   |
|  RETRIEVAL TOOLS          |  ACTION TOOLS                        |
|  +-------------------+    |  +-------------------+                |
|  | - Web Search      |    |  | - Send Email      |                |
|  | - Database Query  |    |  | - Create File     |                |
|  | - API Fetch       |    |  | - Update Record   |                |
|  | - File Read       |    |  | - Execute Code    |                |
|  +-------------------+    |  +-------------------+                |
|                           |                                       |
|  COMPUTATION TOOLS        |  INTEGRATION TOOLS                   |
|  +-------------------+    |  +-------------------+                |
|  | - Calculator      |    |  | - Slack Message   |                |
|  | - Data Transform  |    |  | - GitHub PR       |                |
|  | - Code Execution  |    |  | - Jira Update     |                |
|  | - Analysis        |    |  | - Calendar Event  |                |
|  +-------------------+    |  +-------------------+                |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Tools in LangGraph Architecture

```
+------------------------------------------------------------------+
|                     LANGGRAPH WITH TOOLS                          |
+------------------------------------------------------------------+
|                                                                   |
|                         +-------------+                           |
|                         |    START    |                           |
|                         +------+------+                           |
|                                |                                  |
|                                v                                  |
|  +----------------+     +-------------+     +----------------+    |
|  |                |     |             |     |                |    |
|  |  Tool Node     |<----|  LLM Node   |---->|    END         |    |
|  |  (Execution)   |     |  (Reason)   |     |   (Response)   |    |
|  |                |     |             |     |                |    |
|  +----------------+     +-------------+     +----------------+    |
|         |                      ^                                  |
|         |                      |                                  |
|         +----------------------+                                  |
|           (Tool results fed back)                                 |
|                                                                   |
+------------------------------------------------------------------+
```

### State Flow with Tools

```python
# Simplified LangGraph agent with tools
from typing import TypedDict, Annotated
from langgraph.graph import StateGraph, END
from langgraph.prebuilt import ToolNode

class AgentState(TypedDict):
    messages: list  # Conversation history
    
# Define the graph
graph = StateGraph(AgentState)

# Add nodes
graph.add_node("agent", call_model)      # LLM reasoning
graph.add_node("tools", ToolNode(tools)) # Tool execution

# Add edges
graph.add_edge("__start__", "agent")
graph.add_conditional_edges(
    "agent",
    should_continue,  # Check if tools needed
    {
        "continue": "tools",  # Execute tools
        "end": END            # Return response
    }
)
graph.add_edge("tools", "agent")  # Return results to LLM
```

---

## The Docstring is Everything

The docstring is what the LLM reads to decide whether to use a tool:

### Bad Docstring

```python
@tool
def search(q: str) -> str:
    """Search function."""  # Too vague!
    return results
```

### Good Docstring

```python
@tool
def search_products(query: str) -> str:
    """Search the product catalog for items matching the query.
    
    Use this tool when the user wants to:
    - Find products by name or description
    - Look up product availability
    - Compare similar products
    
    Args:
        query: Product name, category, or description keywords
        
    Returns:
        JSON string with matching products including name, price, and availability
    """
    return results
```

---

## Interview Tips

### Common Interview Questions

| Question | Key Points to Cover |
|----------|---------------------|
| "What are tools in LangGraph?" | Functions that extend LLM capabilities; LLM decides when to use them |
| "How does tool selection work?" | LLM reads docstrings, generates tool calls based on context |
| "Sync vs async tools?" | Async for I/O-bound, sync for CPU-bound operations |
| "Tool vs function calling?" | Same concept, different terminology (OpenAI vs Anthropic) |

### Key Concepts to Remember

1. **Tools bridge reasoning and action** - LLMs think, tools do
2. **Docstrings drive selection** - Clear descriptions = better tool use
3. **Type hints are required** - Enable schema generation
4. **Error handling is critical** - Tools can fail, plan for it

---

## Summary

```
+------------------------------------------------------------------+
|                        KEY TAKEAWAYS                              |
+------------------------------------------------------------------+
|                                                                   |
|  1. Tools = Functions that LLMs can call                         |
|                                                                   |
|  2. Three essential parts:                                        |
|     - @tool decorator                                             |
|     - Clear docstring                                             |
|     - Type-hinted parameters                                      |
|                                                                   |
|  3. The LLM decides WHEN to use tools based on:                  |
|     - User request                                                |
|     - Tool descriptions                                           |
|     - Available context                                           |
|                                                                   |
|  4. Tool results feed back into LLM for final response           |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Next Steps

Continue to `02_tool_binding.md` to learn how to bind tools to LLMs for intelligent selection.
