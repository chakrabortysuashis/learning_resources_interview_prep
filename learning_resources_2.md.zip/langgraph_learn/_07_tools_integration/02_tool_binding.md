# 02. Tool Binding in LangGraph

## What is Tool Binding?

**Tool binding** is the process of attaching tools to an LLM so it knows what tools are available and can decide when to use them. Think of it as giving the LLM a "toolbox" it can reach into.

```
+------------------------------------------------------------------+
|                        TOOL BINDING                               |
+------------------------------------------------------------------+
|                                                                   |
|   BEFORE BINDING                    AFTER BINDING                 |
|   +--------------+                  +----------------------+      |
|   |              |                  |                      |      |
|   |    LLM       |     bind_tools   |    LLM               |      |
|   |  (No tools)  |  ------------>>  |  +----------------+  |      |
|   |              |                  |  | Tool: search   |  |      |
|   +--------------+                  |  | Tool: calc     |  |      |
|                                     |  | Tool: weather  |  |      |
|                                     |  +----------------+  |      |
|                                     +----------------------+      |
|                                                                   |
+------------------------------------------------------------------+
```

---

## How Tool Binding Works

### The Binding Process

```
+------------------------------------------------------------------+
|                     TOOL BINDING FLOW                             |
+------------------------------------------------------------------+
|                                                                   |
|  STEP 1: Define Tools                                             |
|  +-----------------------------------------------------------+   |
|  |  @tool                                                     |   |
|  |  def search(query: str) -> str:                           |   |
|  |      """Search the web."""                                 |   |
|  |      return results                                        |   |
|  +-----------------------------------------------------------+   |
|                            |                                      |
|                            v                                      |
|  STEP 2: Create Tool List                                         |
|  +-----------------------------------------------------------+   |
|  |  tools = [search, calculate, get_weather]                  |   |
|  +-----------------------------------------------------------+   |
|                            |                                      |
|                            v                                      |
|  STEP 3: Bind to LLM                                              |
|  +-----------------------------------------------------------+   |
|  |  llm_with_tools = llm.bind_tools(tools)                    |   |
|  +-----------------------------------------------------------+   |
|                            |                                      |
|                            v                                      |
|  STEP 4: LLM Now Has Tool Schema                                  |
|  +-----------------------------------------------------------+   |
|  |  {                                                         |   |
|  |    "tools": [                                              |   |
|  |      {"name": "search", "description": "...", "params":{}},|   |
|  |      {"name": "calculate", "description": "...", ...},     |   |
|  |      {"name": "get_weather", "description": "...", ...}    |   |
|  |    ]                                                       |   |
|  |  }                                                         |   |
|  +-----------------------------------------------------------+   |
|                                                                   |
+------------------------------------------------------------------+
```

---

## The bind_tools Method

### Basic Syntax

```python
from langchain_openai import ChatOpenAI
from langchain_core.tools import tool

# Define tools
@tool
def add(a: int, b: int) -> int:
    """Add two numbers."""
    return a + b

@tool
def multiply(a: int, b: int) -> int:
    """Multiply two numbers."""
    return a * b

# Create LLM
llm = ChatOpenAI(model="gpt-4o")

# Bind tools to LLM
llm_with_tools = llm.bind_tools([add, multiply])
```

### What Happens Internally

```
+------------------------------------------------------------------+
|                    INTERNAL TRANSFORMATION                        |
+------------------------------------------------------------------+
|                                                                   |
|  Your Tool:                        Schema Sent to LLM:            |
|  +---------------------+           +---------------------------+  |
|  | @tool               |           | {                         |  |
|  | def add(            |   --->    |   "type": "function",     |  |
|  |     a: int,         |           |   "function": {           |  |
|  |     b: int          |           |     "name": "add",        |  |
|  | ) -> int:           |           |     "description": "Add   |  |
|  |     """Add two      |           |       two numbers.",      |  |
|  |     numbers."""     |           |     "parameters": {       |  |
|  |     return a + b    |           |       "type": "object",   |  |
|  +---------------------+           |       "properties": {     |  |
|                                    |         "a": {"type":     |  |
|                                    |              "integer"},  |  |
|                                    |         "b": {"type":     |  |
|                                    |              "integer"}   |  |
|                                    |       },                   |  |
|                                    |       "required": ["a","b"]|  |
|                                    |     }                      |  |
|                                    |   }                        |  |
|                                    | }                          |  |
|                                    +---------------------------+  |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Tool Choice Options

When binding tools, you can control how the LLM uses them:

### Option 1: Auto (Default)

LLM decides whether to use tools or respond directly:

```python
llm_with_tools = llm.bind_tools(tools, tool_choice="auto")
```

```
User: "Hello!"
LLM: "Hi there! How can I help?" (No tool used)

User: "What's 5 + 3?"
LLM: [Uses add tool] "5 + 3 = 8"
```

### Option 2: Required

LLM MUST use at least one tool:

```python
llm_with_tools = llm.bind_tools(tools, tool_choice="required")
```

```
User: "Hello!"
LLM: [Forced to pick a tool, might use inappropriately]
```

### Option 3: Specific Tool

Force use of a particular tool:

```python
llm_with_tools = llm.bind_tools(tools, tool_choice="add")
```

```
User: "What's 5 times 3?"
LLM: [Uses add instead of multiply because forced]
```

### Option 4: None

Disable tool use entirely:

```python
llm_with_tools = llm.bind_tools(tools, tool_choice="none")
```

### Comparison Table

| Tool Choice | When to Use | Behavior |
|-------------|-------------|----------|
| `"auto"` | Default, most flexible | LLM decides |
| `"required"` | Always need tool output | Forces tool use |
| `"<tool_name>"` | Specific tool needed | Forces that tool |
| `"none"` | Disable temporarily | No tools used |

---

## Tool Binding with Different LLM Providers

### OpenAI

```python
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(model="gpt-4o")
llm_with_tools = llm.bind_tools(tools)
```

### Anthropic

```python
from langchain_anthropic import ChatAnthropic

llm = ChatAnthropic(model="claude-sonnet-4-20250514")
llm_with_tools = llm.bind_tools(tools)
```

### Google (Gemini)

```python
from langchain_google_genai import ChatGoogleGenerativeAI

llm = ChatGoogleGenerativeAI(model="gemini-pro")
llm_with_tools = llm.bind_tools(tools)
```

---

## Understanding Tool Calls in Responses

When an LLM with bound tools responds, it may include tool calls:

```
+------------------------------------------------------------------+
|                     LLM RESPONSE TYPES                            |
+------------------------------------------------------------------+
|                                                                   |
|  TYPE 1: Direct Response (No Tool)                               |
|  +-----------------------------------------------------------+   |
|  |  AIMessage(                                                |   |
|  |      content="Hello! I'm here to help.",                   |   |
|  |      tool_calls=[]  # Empty - no tools used               |   |
|  |  )                                                         |   |
|  +-----------------------------------------------------------+   |
|                                                                   |
|  TYPE 2: Tool Call Response                                       |
|  +-----------------------------------------------------------+   |
|  |  AIMessage(                                                |   |
|  |      content="",  # Often empty when calling tools        |   |
|  |      tool_calls=[                                          |   |
|  |          {                                                 |   |
|  |              "id": "call_abc123",                          |   |
|  |              "name": "add",                                |   |
|  |              "args": {"a": 5, "b": 3}                      |   |
|  |          }                                                 |   |
|  |      ]                                                     |   |
|  |  )                                                         |   |
|  +-----------------------------------------------------------+   |
|                                                                   |
|  TYPE 3: Multiple Tool Calls (Parallel)                          |
|  +-----------------------------------------------------------+   |
|  |  AIMessage(                                                |   |
|  |      content="",                                           |   |
|  |      tool_calls=[                                          |   |
|  |          {"id": "call_1", "name": "search", "args": {...}},|   |
|  |          {"id": "call_2", "name": "weather", "args": {...}}|   |
|  |      ]                                                     |   |
|  |  )                                                         |   |
|  +-----------------------------------------------------------+   |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Tool Binding in LangGraph Agents

### Using create_react_agent

```python
from langgraph.prebuilt import create_react_agent
from langchain_openai import ChatOpenAI

# Tools are automatically bound when creating the agent
agent = create_react_agent(
    model=ChatOpenAI(model="gpt-4o"),
    tools=[add, multiply, search]
)
```

### Manual Tool Binding in Custom Graphs

```python
from langgraph.graph import StateGraph
from langgraph.prebuilt import ToolNode

# Bind tools to model
model_with_tools = model.bind_tools(tools)

# Create tool node
tool_node = ToolNode(tools)

# Build graph
graph = StateGraph(AgentState)
graph.add_node("agent", lambda state: model_with_tools.invoke(state["messages"]))
graph.add_node("tools", tool_node)
```

---

## Tool Binding Patterns

### Pattern 1: Static Binding

All tools always available:

```python
# Tools bound once at startup
tools = [search, calculate, weather]
llm_with_tools = llm.bind_tools(tools)
```

### Pattern 2: Dynamic Binding

Tools change based on context:

```python
def get_tools_for_user(user_role: str) -> list:
    """Return tools based on user permissions."""
    base_tools = [search, calculate]
    
    if user_role == "admin":
        return base_tools + [delete_record, update_config]
    elif user_role == "analyst":
        return base_tools + [run_query, export_data]
    else:
        return base_tools

# Bind dynamically
user_tools = get_tools_for_user(current_user.role)
llm_with_tools = llm.bind_tools(user_tools)
```

### Pattern 3: Conditional Tool Availability

```python
def agent_node(state: AgentState):
    # Select tools based on state
    if state.get("mode") == "research":
        active_tools = [web_search, academic_search, summarize]
    else:
        active_tools = [calculator, converter]
    
    # Bind and invoke
    model_with_tools = model.bind_tools(active_tools)
    return model_with_tools.invoke(state["messages"])
```

---

## The Complete Flow

```
+------------------------------------------------------------------+
|                   COMPLETE TOOL BINDING FLOW                      |
+------------------------------------------------------------------+
|                                                                   |
|  1. DEFINE                                                        |
|     +------------------+                                          |
|     | @tool            |                                          |
|     | def my_tool(...) |                                          |
|     +------------------+                                          |
|              |                                                    |
|              v                                                    |
|  2. BIND                                                          |
|     +------------------+                                          |
|     | llm.bind_tools() |                                          |
|     +------------------+                                          |
|              |                                                    |
|              v                                                    |
|  3. INVOKE                                                        |
|     +------------------+                                          |
|     | llm.invoke(msg)  |                                          |
|     +------------------+                                          |
|              |                                                    |
|              v                                                    |
|  4. CHECK RESPONSE                                                |
|     +------------------+     +------------------+                 |
|     | Has tool_calls?  |---->| YES: Execute     |                 |
|     |                  |     |     tools        |                 |
|     +------------------+     +------------------+                 |
|              |                       |                            |
|              | NO                    |                            |
|              v                       v                            |
|     +------------------+     +------------------+                 |
|     | Return content   |     | Feed results    |                 |
|     | directly         |     | back to LLM     |                 |
|     +------------------+     +------------------+                 |
|                                      |                            |
|                                      v                            |
|                              +------------------+                 |
|                              | Final response   |                 |
|                              +------------------+                 |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Interview Tips

### Common Questions

| Question | Answer Points |
|----------|---------------|
| "What is tool binding?" | Attaching tools to LLM so it can use them; converts Python functions to JSON schemas |
| "What's the difference between bind_tools and create_react_agent?" | bind_tools just attaches tools; create_react_agent builds full agent with reasoning loop |
| "How does the LLM know which tool to use?" | Reads tool descriptions (docstrings) and matches to user intent |
| "Can you bind tools dynamically?" | Yes, rebind based on user, context, or state |

### Key Points to Remember

1. **bind_tools converts Python to JSON schema** - LLMs understand schemas, not Python
2. **tool_choice controls behavior** - auto, required, specific, or none
3. **Tool calls are in the response** - Check response.tool_calls
4. **Binding is provider-agnostic** - Same API for OpenAI, Anthropic, etc.

---

## Common Mistakes

### Mistake 1: Not Checking for Tool Calls

```python
# WRONG
response = llm_with_tools.invoke(messages)
print(response.content)  # Might be empty if tools were called!

# CORRECT
response = llm_with_tools.invoke(messages)
if response.tool_calls:
    # Handle tool calls
    for tool_call in response.tool_calls:
        result = execute_tool(tool_call)
else:
    print(response.content)
```

### Mistake 2: Forgetting to Execute Tool Calls

```python
# Tool calls don't auto-execute! You must handle them.
response = llm_with_tools.invoke(messages)

# The response contains REQUESTS to use tools
# You must actually run them and feed results back
```

### Mistake 3: Binding Without Type Hints

```python
# WRONG - No type hints
@tool
def search(query):
    """Search the web."""
    return results

# CORRECT - Type hints required
@tool
def search(query: str) -> str:
    """Search the web."""
    return results
```

---

## Summary

```
+------------------------------------------------------------------+
|                        KEY TAKEAWAYS                              |
+------------------------------------------------------------------+
|                                                                   |
|  1. Tool Binding = Attaching tools to LLM                        |
|     - llm.bind_tools([tool1, tool2, ...])                        |
|                                                                   |
|  2. Tool Choice Options:                                          |
|     - "auto" (default) - LLM decides                             |
|     - "required" - Must use a tool                               |
|     - "<name>" - Force specific tool                             |
|     - "none" - Disable tools                                     |
|                                                                   |
|  3. Response Contains tool_calls:                                 |
|     - response.tool_calls (list of tool call requests)           |
|     - response.content (text response, may be empty)             |
|                                                                   |
|  4. Tools Can Be Bound Dynamically:                              |
|     - Based on user permissions                                  |
|     - Based on conversation state                                |
|     - Based on detected intent                                   |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Next Steps

Continue to `03_tool_binding_example.py` to see tool binding in action with working code.
