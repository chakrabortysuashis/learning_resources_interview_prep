# Topic 7: Tools & Integration in LangGraph

## Overview

Tools are the **bridge between AI reasoning and real-world actions**. They transform LLMs from passive text generators into active agents capable of searching the web, querying databases, executing code, and interacting with external systems.

```
+------------------+     +-----------------+     +------------------+
|                  |     |                 |     |                  |
|   LLM (Brain)    |---->|   Tools Layer   |---->|  External World  |
|                  |     |                 |     |                  |
+------------------+     +-----------------+     +------------------+
        ^                       |                        |
        |                       v                        |
        +<------ Tool Results <--------------------------+
```

---

## Learning Objectives

By the end of this module, you will be able to:

| # | Objective | File |
|---|-----------|------|
| 1 | Understand what tools are and why they matter | `01_tools_overview.md` |
| 2 | Bind tools to LLMs for intelligent selection | `02_tool_binding.md`, `03_tool_binding_example.py` |
| 3 | Leverage existing LangChain tools | `04_langchain_tools.md`, `05_langchain_tools_example.py` |
| 4 | Create custom tools with the @tool decorator | `06_custom_tools.md`, `07_custom_tools_example.py` |
| 5 | Handle tool errors gracefully | `08_tool_error_handling.md`, `09_error_handling_example.py` |

---

## Prerequisites

Before starting this module, you should understand:

- Basic LangGraph concepts (nodes, edges, state)
- How agents work in LangGraph
- Python async/await patterns
- Basic LLM interaction concepts

---

## Module Structure

```
_07_tools_integration/
|
|-- README.md                      # This file
|
|-- CONCEPTS
|   |-- 01_tools_overview.md       # What are tools?
|   |-- 02_tool_binding.md         # How tool binding works
|   |-- 04_langchain_tools.md      # Using LangChain tools
|   |-- 06_custom_tools.md         # Creating custom tools
|   |-- 08_tool_error_handling.md  # Error handling strategies
|
|-- EXAMPLES
    |-- 03_tool_binding_example.py
    |-- 05_langchain_tools_example.py
    |-- 07_custom_tools_example.py
    |-- 09_error_handling_example.py
```

---

## Key Concepts at a Glance

### What is a Tool?

A tool is a function that an LLM can call to perform actions:

```python
@tool
def search_web(query: str) -> str:
    """Search the web for information."""
    return search_engine.search(query)
```

### Tool Binding Flow

```
1. Define Tool       2. Bind to LLM       3. LLM Decides       4. Execute
+-------------+     +-------------+      +-------------+      +-------------+
| @tool       |---->| llm.bind_   |----->| Tool call   |----->| Run tool    |
| decorator   |     | tools([...] |      | in response |      | function    |
+-------------+     +-------------+      +-------------+      +-------------+
```

### Types of Tools

| Type | Description | Example |
|------|-------------|---------|
| **Built-in** | Pre-made LangChain tools | Wikipedia, Tavily Search |
| **Custom** | Your own tool functions | Database queries, APIs |
| **Structured** | Tools with complex input schemas | Multi-parameter tools |

---

## Quick Start

```python
from langchain_core.tools import tool
from langgraph.prebuilt import create_react_agent

# 1. Define a tool
@tool
def get_weather(city: str) -> str:
    """Get current weather for a city."""
    return f"Weather in {city}: 72F, Sunny"

# 2. Create agent with tools
tools = [get_weather]
agent = create_react_agent(model, tools)

# 3. Run the agent
result = agent.invoke({
    "messages": [("user", "What's the weather in Tokyo?")]
})
```

---

## Common Patterns

### Pattern 1: Simple Tool Definition

```python
@tool
def my_tool(param: str) -> str:
    """Tool description for LLM."""
    return f"Result: {param}"
```

### Pattern 2: Tool with Error Handling

```python
@tool
def safe_tool(param: str) -> str:
    """Tool with error handling."""
    try:
        return process(param)
    except Exception as e:
        return f"Error: {str(e)}"
```

### Pattern 3: Async Tool

```python
@tool
async def async_tool(param: str) -> str:
    """Async tool for I/O operations."""
    result = await fetch_data(param)
    return result
```

---

## Interview Preparation Topics

| Topic | What to Know |
|-------|--------------|
| Tool Binding | How LLMs select and call tools |
| Function Calling | OpenAI function calling vs tool use |
| Error Handling | Graceful degradation strategies |
| Tool Design | Best practices for tool interfaces |
| Security | Input validation, rate limiting |

---

## Best Practices Checklist

- [ ] Write clear, descriptive tool docstrings
- [ ] Keep tool functions focused (single responsibility)
- [ ] Always handle potential errors
- [ ] Validate inputs before processing
- [ ] Return structured, parseable outputs
- [ ] Use type hints for all parameters
- [ ] Test tools independently before integration

---

## Next Steps

After completing this module:

1. **Practice**: Build a multi-tool agent
2. **Explore**: Try LangChain's tool ecosystem
3. **Create**: Design custom tools for your use case
4. **Integrate**: Connect tools to real APIs

---

## Additional Resources

- [LangGraph Tools Documentation](https://langchain-ai.github.io/langgraph/)
- [LangChain Tools Reference](https://python.langchain.com/docs/modules/tools/)
- [OpenAI Function Calling Guide](https://platform.openai.com/docs/guides/function-calling)

---

Happy Learning! Remember: Tools are what transform LLMs from "chat" to "do".
