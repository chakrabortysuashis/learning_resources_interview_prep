"""
============================================================================
09. Tool Error Handling Example - Robust Error Handling in LangGraph
============================================================================

This file demonstrates comprehensive error handling strategies for tools
in LangGraph agents. We'll cover:
- Input validation
- External service error handling
- Retry logic with backoff
- Graceful degradation
- Structured error responses
- Error handling in workflows

Prerequisites:
    pip install langchain-core langchain-openai langgraph requests

Environment Variables:
    OPENAI_API_KEY=your-key-here
"""

# ============================================================================
# IMPORTS
# ============================================================================

import os
import time
import json
import random
import logging
from datetime import datetime
from typing import TypedDict, Annotated, Literal, Optional
from dotenv import load_dotenv

from langchain_core.tools import tool, ToolException
from langchain_core.messages import HumanMessage, AIMessage, ToolMessage
from langchain_openai import ChatOpenAI

from langgraph.graph import StateGraph, END
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode, create_react_agent

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
logger = logging.getLogger(__name__)

print("=" * 70)
print("TOOL ERROR HANDLING EXAMPLES - LangGraph")
print("=" * 70)


# ============================================================================
# SECTION 1: INPUT VALIDATION
# ============================================================================
"""
Always validate inputs BEFORE processing.
Return clear error messages for invalid inputs.
"""

print("\n" + "-" * 70)
print("Section 1: Input Validation")
print("-" * 70)


@tool
def divide_safely(numerator: float, denominator: float) -> str:
    """Divide two numbers with proper validation.

    Args:
        numerator: The number to divide
        denominator: The number to divide by

    Returns:
        Result or descriptive error message
    """
    # Validate denominator
    if denominator == 0:
        return (
            "Error: Cannot divide by zero. "
            "Please provide a non-zero denominator."
        )

    # Validate for infinity results
    if abs(numerator) > 1e308 and abs(denominator) < 1:
        return (
            "Error: Result would be too large to represent. "
            "Please use smaller numbers."
        )

    result = numerator / denominator
    return f"{numerator} / {denominator} = {result}"


@tool
def validate_and_parse_date(date_string: str) -> dict:
    """Parse and validate a date string.

    Accepts formats: YYYY-MM-DD, MM/DD/YYYY, DD-MM-YYYY

    Args:
        date_string: The date string to parse

    Returns:
        Parsed date info or error message
    """
    from datetime import datetime

    # Remove whitespace
    date_string = date_string.strip()

    if not date_string:
        return {
            "success": False,
            "error": "Empty date string provided",
            "suggestion": "Please provide a date in format YYYY-MM-DD"
        }

    # Try different formats
    formats = [
        ("%Y-%m-%d", "YYYY-MM-DD"),
        ("%m/%d/%Y", "MM/DD/YYYY"),
        ("%d-%m-%Y", "DD-MM-YYYY"),
        ("%B %d, %Y", "Month DD, YYYY")
    ]

    for fmt, fmt_name in formats:
        try:
            parsed = datetime.strptime(date_string, fmt)
            return {
                "success": True,
                "original": date_string,
                "format_detected": fmt_name,
                "year": parsed.year,
                "month": parsed.month,
                "day": parsed.day,
                "day_of_week": parsed.strftime("%A"),
                "iso_format": parsed.isoformat()
            }
        except ValueError:
            continue

    return {
        "success": False,
        "error": f"Could not parse '{date_string}'",
        "attempted_formats": [f[1] for f in formats],
        "suggestion": "Try formats like: 2024-01-15, 01/15/2024, or January 15, 2024"
    }


@tool
def process_email_list(emails: str) -> dict:
    """Process and validate a comma-separated list of emails.

    Args:
        emails: Comma-separated email addresses

    Returns:
        Validation results for each email
    """
    import re
    email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'

    if not emails or not emails.strip():
        return {
            "success": False,
            "error": "No emails provided",
            "suggestion": "Provide comma-separated emails like: a@b.com, c@d.com"
        }

    email_list = [e.strip() for e in emails.split(",")]
    results = {
        "total": len(email_list),
        "valid": [],
        "invalid": [],
        "valid_count": 0,
        "invalid_count": 0
    }

    for email in email_list:
        if re.match(email_pattern, email):
            results["valid"].append(email)
            results["valid_count"] += 1
        else:
            results["invalid"].append({
                "email": email,
                "reason": "Invalid format" if email else "Empty string"
            })
            results["invalid_count"] += 1

    results["success"] = results["invalid_count"] == 0
    return results


def demo_input_validation():
    """Demonstrate input validation."""

    print("\n[*] Input Validation Demo")

    # Division validation
    print("\n    Testing divide_safely...")
    test_cases = [
        (10, 2),    # Normal
        (10, 0),    # Division by zero
        (5, 0.001), # Normal small denominator
    ]

    for num, denom in test_cases:
        result = divide_safely.invoke({"numerator": num, "denominator": denom})
        print(f"      {num} / {denom}: {result[:50]}...")

    # Date validation
    print("\n    Testing validate_and_parse_date...")
    dates = ["2024-01-15", "13/45/2024", "January 15, 2024", ""]

    for date in dates:
        result = validate_and_parse_date.invoke(date)
        status = "Valid" if result.get("success") else "Invalid"
        print(f"      '{date}': {status}")

    # Email validation
    print("\n    Testing process_email_list...")
    result = process_email_list.invoke("valid@email.com, bad-email, another@test.org")
    print(f"      Valid: {result['valid_count']}, Invalid: {result['invalid_count']}")

# Uncomment to run:
# demo_input_validation()


# ============================================================================
# SECTION 2: EXTERNAL SERVICE ERROR HANDLING
# ============================================================================
"""
Handle errors from external APIs and services gracefully.
"""

print("\n" + "-" * 70)
print("Section 2: External Service Error Handling")
print("-" * 70)


# Simulated external service that sometimes fails
class UnreliableService:
    """Simulates an unreliable external service."""

    def __init__(self, failure_rate: float = 0.3):
        self.failure_rate = failure_rate
        self.call_count = 0

    def call(self, endpoint: str) -> dict:
        """Simulate an API call that may fail."""
        self.call_count += 1

        # Simulate different failure types
        roll = random.random()

        if roll < self.failure_rate * 0.3:
            raise ConnectionError("Connection refused")
        elif roll < self.failure_rate * 0.6:
            raise TimeoutError("Request timed out")
        elif roll < self.failure_rate:
            raise Exception("Internal server error")

        return {"status": "success", "data": f"Response from {endpoint}"}


# Create service instances
weather_service = UnreliableService(failure_rate=0.4)
data_service = UnreliableService(failure_rate=0.3)


@tool
def fetch_weather(city: str) -> dict:
    """Fetch weather data with comprehensive error handling.

    Args:
        city: Name of the city

    Returns:
        Weather data or detailed error information
    """
    if not city or not city.strip():
        return {
            "success": False,
            "error_type": "validation_error",
            "message": "City name is required",
            "suggestion": "Provide a city name like 'London' or 'Tokyo'"
        }

    city = city.strip()

    try:
        # Simulate API call
        result = weather_service.call(f"/weather/{city}")

        # Simulate weather data
        return {
            "success": True,
            "city": city,
            "temperature_f": random.randint(32, 100),
            "conditions": random.choice(["Sunny", "Cloudy", "Rainy"]),
            "humidity": random.randint(20, 90)
        }

    except ConnectionError:
        return {
            "success": False,
            "error_type": "connection_error",
            "message": "Could not connect to weather service",
            "suggestion": "The weather service may be down. Try again in a few minutes."
        }

    except TimeoutError:
        return {
            "success": False,
            "error_type": "timeout_error",
            "message": "Weather service took too long to respond",
            "suggestion": "The service is slow. Please try again."
        }

    except Exception as e:
        logger.error(f"Weather fetch failed for {city}: {e}")
        return {
            "success": False,
            "error_type": "unknown_error",
            "message": "An unexpected error occurred",
            "details": str(e)
        }


@tool
def fetch_multiple_cities_weather(cities: str) -> dict:
    """Fetch weather for multiple cities with partial failure handling.

    Args:
        cities: Comma-separated city names

    Returns:
        Weather data for successful fetches, errors for failures
    """
    if not cities:
        return {"success": False, "error": "No cities provided"}

    city_list = [c.strip() for c in cities.split(",") if c.strip()]

    results = {
        "total_requested": len(city_list),
        "successful": [],
        "failed": [],
        "partial_success": False
    }

    for city in city_list:
        weather = fetch_weather.invoke(city)
        if weather.get("success"):
            results["successful"].append(weather)
        else:
            results["failed"].append({"city": city, "error": weather})

    results["success_count"] = len(results["successful"])
    results["failure_count"] = len(results["failed"])
    results["partial_success"] = results["success_count"] > 0

    return results


def demo_external_service_errors():
    """Demonstrate external service error handling."""

    print("\n[*] External Service Error Handling Demo")

    # Single city weather (may succeed or fail)
    print("\n    Testing fetch_weather...")
    for city in ["Tokyo", "London", "Paris", "", "Sydney"]:
        result = fetch_weather.invoke(city)
        status = "Success" if result.get("success") else f"Failed ({result.get('error_type', 'unknown')})"
        print(f"      {city or '(empty)'}: {status}")

    # Multiple cities (partial failures)
    print("\n    Testing fetch_multiple_cities_weather...")
    result = fetch_multiple_cities_weather.invoke("Tokyo, London, Paris, New York, Sydney")
    print(f"      Requested: {result['total_requested']}")
    print(f"      Successful: {result['success_count']}")
    print(f"      Failed: {result['failure_count']}")

# Uncomment to run:
# demo_external_service_errors()


# ============================================================================
# SECTION 3: RETRY LOGIC WITH EXPONENTIAL BACKOFF
# ============================================================================
"""
Implement automatic retries for transient failures.
"""

print("\n" + "-" * 70)
print("Section 3: Retry Logic with Exponential Backoff")
print("-" * 70)


def retry_with_backoff(
    func,
    max_retries: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 30.0,
    exponential_base: float = 2.0
):
    """Execute a function with retry and exponential backoff.

    Args:
        func: Function to execute
        max_retries: Maximum retry attempts
        base_delay: Initial delay in seconds
        max_delay: Maximum delay cap
        exponential_base: Base for exponential increase

    Returns:
        Function result or last exception
    """
    last_exception = None

    for attempt in range(max_retries + 1):
        try:
            return func()
        except Exception as e:
            last_exception = e
            if attempt < max_retries:
                delay = min(base_delay * (exponential_base ** attempt), max_delay)
                logger.info(f"Attempt {attempt + 1} failed, retrying in {delay:.1f}s...")
                time.sleep(delay)

    raise last_exception


@tool
def reliable_data_fetch(resource_id: str, max_retries: int = 3) -> dict:
    """Fetch data with automatic retry on failure.

    Args:
        resource_id: ID of the resource to fetch
        max_retries: Maximum number of retry attempts (default: 3)

    Returns:
        Data or error after all retries exhausted
    """
    if not resource_id:
        return {"success": False, "error": "Resource ID is required"}

    attempts_made = 0
    last_error = None

    for attempt in range(max_retries):
        attempts_made += 1
        try:
            # Simulate API call
            result = data_service.call(f"/data/{resource_id}")
            return {
                "success": True,
                "resource_id": resource_id,
                "data": result["data"],
                "attempts": attempts_made
            }
        except Exception as e:
            last_error = str(e)
            if attempt < max_retries - 1:
                # Calculate backoff delay
                delay = min(1.0 * (2 ** attempt), 10.0)
                time.sleep(delay * 0.1)  # Reduced for demo

    return {
        "success": False,
        "resource_id": resource_id,
        "error": f"Failed after {attempts_made} attempts",
        "last_error": last_error,
        "suggestion": "The service may be experiencing issues. Please try again later."
    }


@tool
def batch_fetch_with_retry(resource_ids: str) -> dict:
    """Fetch multiple resources with individual retry logic.

    Args:
        resource_ids: Comma-separated resource IDs

    Returns:
        Results for each resource
    """
    if not resource_ids:
        return {"success": False, "error": "No resource IDs provided"}

    ids = [id.strip() for id in resource_ids.split(",") if id.strip()]

    results = {
        "total": len(ids),
        "results": [],
        "summary": {"success": 0, "failed": 0, "total_attempts": 0}
    }

    for rid in ids:
        result = reliable_data_fetch.invoke({"resource_id": rid, "max_retries": 3})
        results["results"].append(result)
        results["summary"]["total_attempts"] += result.get("attempts", 1)

        if result.get("success"):
            results["summary"]["success"] += 1
        else:
            results["summary"]["failed"] += 1

    return results


def demo_retry_logic():
    """Demonstrate retry logic."""

    print("\n[*] Retry Logic Demo")

    # Single fetch with retry
    print("\n    Testing reliable_data_fetch...")
    for i in range(5):
        result = reliable_data_fetch.invoke({"resource_id": f"item_{i}", "max_retries": 3})
        status = f"Success (attempts: {result.get('attempts', 'N/A')})" if result.get("success") else "Failed"
        print(f"      item_{i}: {status}")

    # Batch fetch
    print("\n    Testing batch_fetch_with_retry...")
    result = batch_fetch_with_retry.invoke("res_1, res_2, res_3, res_4, res_5")
    print(f"      Total: {result['total']}")
    print(f"      Success: {result['summary']['success']}")
    print(f"      Failed: {result['summary']['failed']}")
    print(f"      Total attempts: {result['summary']['total_attempts']}")

# Uncomment to run:
# demo_retry_logic()


# ============================================================================
# SECTION 4: USING ToolException
# ============================================================================
"""
LangChain's ToolException provides explicit tool failure handling.
"""

print("\n" + "-" * 70)
print("Section 4: Using ToolException")
print("-" * 70)


@tool(handle_tool_error=True)
def strict_age_calculator(birth_year: int) -> str:
    """Calculate age from birth year with strict validation.

    Args:
        birth_year: The year of birth (must be valid)

    Returns:
        Calculated age

    Raises:
        ToolException: If birth year is invalid
    """
    current_year = datetime.now().year

    if birth_year < 1900:
        raise ToolException(
            f"Birth year {birth_year} is too far in the past. "
            "Please provide a year after 1900."
        )

    if birth_year > current_year:
        raise ToolException(
            f"Birth year {birth_year} is in the future. "
            f"Please provide a year up to {current_year}."
        )

    age = current_year - birth_year
    return f"A person born in {birth_year} is approximately {age} years old."


@tool(handle_tool_error="Please provide valid coordinates (latitude: -90 to 90, longitude: -180 to 180)")
def get_location_info(latitude: float, longitude: float) -> dict:
    """Get information about a location by coordinates.

    Args:
        latitude: Latitude (-90 to 90)
        longitude: Longitude (-180 to 180)

    Returns:
        Location information

    Raises:
        ToolException: If coordinates are invalid
    """
    if not -90 <= latitude <= 90:
        raise ToolException(f"Invalid latitude: {latitude}. Must be between -90 and 90.")

    if not -180 <= longitude <= 180:
        raise ToolException(f"Invalid longitude: {longitude}. Must be between -180 and 180.")

    # Simulated location data
    return {
        "latitude": latitude,
        "longitude": longitude,
        "timezone": "UTC+0",  # Simplified
        "region": "Unknown"
    }


def demo_tool_exception():
    """Demonstrate ToolException usage."""

    print("\n[*] ToolException Demo")

    # Age calculator
    print("\n    Testing strict_age_calculator...")
    test_years = [1990, 2000, 1850, 2050]

    for year in test_years:
        try:
            result = strict_age_calculator.invoke(year)
            print(f"      {year}: {result}")
        except Exception as e:
            print(f"      {year}: Error - {e}")

    # Location info
    print("\n    Testing get_location_info...")
    test_coords = [(40.7128, -74.0060), (0, 0), (100, 50)]

    for lat, lon in test_coords:
        try:
            result = get_location_info.invoke({"latitude": lat, "longitude": lon})
            print(f"      ({lat}, {lon}): Success")
        except Exception as e:
            print(f"      ({lat}, {lon}): Error - {str(e)[:50]}...")

# Uncomment to run:
# demo_tool_exception()


# ============================================================================
# SECTION 5: ERROR HANDLING IN LANGGRAPH WORKFLOWS
# ============================================================================
"""
Implement error handling at the workflow level.
"""

print("\n" + "-" * 70)
print("Section 5: Error Handling in LangGraph Workflows")
print("-" * 70)


# Define state with error tracking
class RobustAgentState(TypedDict):
    """State with error tracking."""
    messages: Annotated[list, add_messages]
    error_count: int
    last_error: Optional[str]
    tool_call_count: int


def create_robust_agent():
    """Create an agent with error handling in the workflow."""

    # Tools with various error scenarios
    tools = [
        divide_safely,
        fetch_weather,
        validate_and_parse_date,
        reliable_data_fetch
    ]

    # LLM
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    llm_with_tools = llm.bind_tools(tools)

    # Agent node with error tracking
    def agent_node(state: RobustAgentState):
        """Call LLM and track any errors."""
        try:
            response = llm_with_tools.invoke(state["messages"])
            return {
                "messages": [response],
                "last_error": None
            }
        except Exception as e:
            logger.error(f"Agent node error: {e}")
            return {
                "last_error": str(e),
                "error_count": state.get("error_count", 0) + 1
            }

    # Custom tool node with error handling
    def robust_tool_node(state: RobustAgentState):
        """Execute tools with error handling."""
        last_message = state["messages"][-1]

        if not hasattr(last_message, "tool_calls") or not last_message.tool_calls:
            return {}

        tool_results = []
        tool_map = {t.name: t for t in tools}

        for tool_call in last_message.tool_calls:
            tool_name = tool_call["name"]
            tool_args = tool_call["args"]

            try:
                if tool_name in tool_map:
                    result = tool_map[tool_name].invoke(tool_args)
                    # Convert dict results to string for ToolMessage
                    if isinstance(result, dict):
                        result = json.dumps(result, indent=2)
                else:
                    result = f"Error: Unknown tool '{tool_name}'"
            except Exception as e:
                result = f"Error executing {tool_name}: {str(e)}"
                logger.error(f"Tool execution error: {e}")

            tool_results.append(ToolMessage(
                content=str(result),
                tool_call_id=tool_call["id"]
            ))

        return {
            "messages": tool_results,
            "tool_call_count": state.get("tool_call_count", 0) + len(tool_results)
        }

    # Error recovery node
    def error_recovery_node(state: RobustAgentState):
        """Handle errors and decide on recovery."""
        error_count = state.get("error_count", 0)
        last_error = state.get("last_error", "Unknown error")

        if error_count >= 3:
            # Give up gracefully after too many errors
            return {
                "messages": [AIMessage(content=(
                    "I apologize, but I'm experiencing technical difficulties and "
                    "cannot complete your request at this time. Please try again later."
                ))]
            }

        # Log and continue
        logger.warning(f"Error recovery: {last_error} (count: {error_count})")
        return {
            "last_error": None  # Clear error to retry
        }

    # Routing logic
    def route_after_agent(state: RobustAgentState) -> Literal["tools", "error_recovery", "end"]:
        """Route based on agent output and errors."""

        # Check for errors
        if state.get("last_error"):
            return "error_recovery"

        # Check for tool calls
        last_message = state["messages"][-1]
        if hasattr(last_message, "tool_calls") and last_message.tool_calls:
            return "tools"

        return "end"

    def route_after_recovery(state: RobustAgentState) -> Literal["agent", "end"]:
        """Decide whether to retry or give up."""
        if state.get("error_count", 0) >= 3:
            return "end"
        return "agent"

    # Build graph
    graph = StateGraph(RobustAgentState)

    # Add nodes
    graph.add_node("agent", agent_node)
    graph.add_node("tools", robust_tool_node)
    graph.add_node("error_recovery", error_recovery_node)

    # Set entry
    graph.set_entry_point("agent")

    # Add edges
    graph.add_conditional_edges(
        "agent",
        route_after_agent,
        {"tools": "tools", "error_recovery": "error_recovery", "end": END}
    )
    graph.add_edge("tools", "agent")
    graph.add_conditional_edges(
        "error_recovery",
        route_after_recovery,
        {"agent": "agent", "end": END}
    )

    return graph.compile()


def demo_robust_workflow():
    """Demonstrate robust workflow error handling."""

    print("\n[*] Robust Workflow Demo")

    if not os.getenv("OPENAI_API_KEY"):
        print("    [!] OPENAI_API_KEY not set. Skipping demo.")
        return

    agent = create_robust_agent()

    # Test queries
    queries = [
        "What is 100 divided by 5?",
        "What is 50 divided by 0?",
        "What's the weather in Tokyo?",
        "Parse the date 2024-03-15"
    ]

    for query in queries:
        print(f"\n    Query: '{query}'")
        print("    " + "-" * 40)

        result = agent.invoke({
            "messages": [HumanMessage(content=query)],
            "error_count": 0,
            "last_error": None,
            "tool_call_count": 0
        })

        # Show result
        final = result["messages"][-1]
        print(f"    Tool calls: {result.get('tool_call_count', 0)}")
        print(f"    Response: {final.content[:150]}...")

# Uncomment to run:
# demo_robust_workflow()


# ============================================================================
# SECTION 6: COMPLETE EXAMPLE - PRODUCTION-READY ERROR HANDLING
# ============================================================================
"""
A complete production-ready example combining all patterns.
"""

print("\n" + "-" * 70)
print("Section 6: Production-Ready Error Handling")
print("-" * 70)


class ErrorTracker:
    """Track errors across tool calls."""

    def __init__(self):
        self.errors = []

    def record(self, tool_name: str, error_type: str, message: str):
        self.errors.append({
            "timestamp": datetime.now().isoformat(),
            "tool": tool_name,
            "type": error_type,
            "message": message
        })

    def get_recent(self, count: int = 5):
        return self.errors[-count:]

    def clear(self):
        self.errors = []


error_tracker = ErrorTracker()


@tool
def production_api_call(
    endpoint: str,
    method: str = "GET",
    timeout_seconds: int = 10
) -> dict:
    """Make a production-quality API call with comprehensive error handling.

    Features:
    - Input validation
    - Timeout handling
    - Retry logic
    - Error tracking
    - Detailed error responses

    Args:
        endpoint: API endpoint URL
        method: HTTP method (GET, POST)
        timeout_seconds: Request timeout (default: 10)

    Returns:
        API response or detailed error information
    """
    # Input validation
    if not endpoint:
        return {
            "success": False,
            "error_type": "validation_error",
            "message": "Endpoint URL is required"
        }

    if method not in ["GET", "POST", "PUT", "DELETE"]:
        return {
            "success": False,
            "error_type": "validation_error",
            "message": f"Invalid HTTP method: {method}",
            "valid_methods": ["GET", "POST", "PUT", "DELETE"]
        }

    if timeout_seconds < 1 or timeout_seconds > 60:
        return {
            "success": False,
            "error_type": "validation_error",
            "message": "Timeout must be between 1 and 60 seconds"
        }

    # Simulate API call with various outcomes
    max_retries = 3
    last_error = None

    for attempt in range(max_retries):
        try:
            # Simulate network behavior
            if random.random() < 0.2:
                raise ConnectionError("Connection refused")
            if random.random() < 0.1:
                raise TimeoutError("Request timed out")
            if random.random() < 0.1:
                raise Exception("500 Internal Server Error")

            # Success!
            return {
                "success": True,
                "endpoint": endpoint,
                "method": method,
                "status_code": 200,
                "data": {"message": "Request successful"},
                "attempts": attempt + 1,
                "response_time_ms": random.randint(50, 500)
            }

        except (ConnectionError, TimeoutError) as e:
            last_error = str(e)
            if attempt < max_retries - 1:
                time.sleep(0.1 * (2 ** attempt))  # Backoff

        except Exception as e:
            last_error = str(e)
            error_tracker.record("production_api_call", "server_error", str(e))
            break  # Don't retry server errors

    # All retries failed
    error_tracker.record("production_api_call", "failure", last_error)

    return {
        "success": False,
        "error_type": "request_failed",
        "message": f"Request failed after {max_retries} attempts",
        "last_error": last_error,
        "endpoint": endpoint,
        "suggestions": [
            "Check if the service is available",
            "Verify the endpoint URL",
            "Try again in a few minutes"
        ]
    }


def demo_production_error_handling():
    """Demonstrate production-ready error handling."""

    print("\n[*] Production Error Handling Demo")

    # Clear previous errors
    error_tracker.clear()

    # Make multiple API calls
    print("\n    Making 10 API calls...")
    success_count = 0
    fail_count = 0

    for i in range(10):
        result = production_api_call.invoke({
            "endpoint": f"/api/resource/{i}",
            "method": "GET",
            "timeout_seconds": 10
        })

        if result.get("success"):
            success_count += 1
        else:
            fail_count += 1

    print(f"    Results: {success_count} success, {fail_count} failed")

    # Show tracked errors
    recent_errors = error_tracker.get_recent(5)
    if recent_errors:
        print(f"\n    Recent errors tracked: {len(recent_errors)}")
        for err in recent_errors[:3]:
            print(f"      - {err['type']}: {err['message'][:40]}...")

# Uncomment to run:
# demo_production_error_handling()


# ============================================================================
# SECTION 7: MAIN RUNNER
# ============================================================================

def main():
    """Run all demonstrations."""

    print("\n" + "=" * 70)
    print("RUNNING ERROR HANDLING DEMONSTRATIONS")
    print("=" * 70)

    print("\n[1] Input Validation")
    demo_input_validation()

    print("\n[2] External Service Errors")
    demo_external_service_errors()

    print("\n[3] Retry Logic")
    demo_retry_logic()

    print("\n[4] ToolException")
    demo_tool_exception()

    print("\n[5] Production Error Handling")
    demo_production_error_handling()

    # LLM-based demos
    if os.getenv("OPENAI_API_KEY"):
        print("\n[6] Robust Workflow")
        demo_robust_workflow()
    else:
        print("\n[!] Skipping LLM demos (no OPENAI_API_KEY)")

    print("\n" + "=" * 70)
    print("DEMONSTRATIONS COMPLETE")
    print("=" * 70)


if __name__ == "__main__":
    main()


# ============================================================================
# INTERVIEW TIP BOX
# ============================================================================
"""
+--------------------------------------------------------------------------+
|                           INTERVIEW TIP                                   |
+--------------------------------------------------------------------------+
|                                                                          |
|  Q: "How do you handle tool errors in production LangGraph agents?"     |
|                                                                          |
|  A: "I use a multi-layered approach to error handling:                  |
|                                                                          |
|      1. Input Validation: Check all inputs before processing.            |
|         - Validate types, ranges, formats                                |
|         - Return clear error messages for invalid inputs                 |
|                                                                          |
|      2. Structured Error Responses: Return dictionaries with:            |
|         - success: boolean                                               |
|         - error_type: categorized error                                  |
|         - message: human-readable description                            |
|         - suggestions: how to fix                                        |
|                                                                          |
|      3. Retry Logic: For transient failures                              |
|         - Exponential backoff                                            |
|         - Maximum retry limits                                           |
|         - Different handling for different error types                   |
|                                                                          |
|      4. Workflow-Level Handling: In LangGraph                            |
|         - Error recovery nodes                                           |
|         - Error count tracking in state                                  |
|         - Graceful degradation                                           |
|                                                                          |
|      5. Monitoring: Track errors for debugging                           |
|         - Error logging                                                  |
|         - Error aggregation                                              |
|         - Alerting on error thresholds"                                  |
|                                                                          |
+--------------------------------------------------------------------------+
"""
