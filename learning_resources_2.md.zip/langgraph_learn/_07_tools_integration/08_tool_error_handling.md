# 08. Tool Error Handling in LangGraph

## Why Error Handling Matters

Tools interact with the outside world - APIs, databases, files, networks. Things **will** go wrong. Without proper error handling, a single failed tool call can crash your entire agent.

```
+------------------------------------------------------------------+
|                    WITHOUT ERROR HANDLING                         |
+------------------------------------------------------------------+
|                                                                   |
|  User: "Get weather for 'invalid-city-xyz'"                      |
|                      |                                            |
|                      v                                            |
|  +------------------+                                             |
|  |   Weather API    |                                             |
|  |   Call Failed!   |  ---->  CRASH!  Agent stops working        |
|  +------------------+                                             |
|                                                                   |
+------------------------------------------------------------------+

+------------------------------------------------------------------+
|                     WITH ERROR HANDLING                           |
+------------------------------------------------------------------+
|                                                                   |
|  User: "Get weather for 'invalid-city-xyz'"                      |
|                      |                                            |
|                      v                                            |
|  +------------------+                                             |
|  |   Weather API    |                                             |
|  |   Call Failed!   |                                             |
|  +------------------+                                             |
|           |                                                       |
|           v                                                       |
|  +------------------+                                             |
|  | Error Handler:   |                                             |
|  | "City not found" | ---->  LLM responds gracefully             |
|  +------------------+                                             |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Types of Tool Errors

### 1. Input Validation Errors

```
+------------------------------------------------------------------+
|                   INPUT VALIDATION ERRORS                         |
+------------------------------------------------------------------+
|                                                                   |
|  Error Type          |  Example                                   |
|  --------------------|-------------------------------------------  |
|  Missing parameter   |  divide(10) - missing denominator         |
|  Wrong type          |  calculate("abc") - expected number       |
|  Invalid value       |  get_page(-5) - negative page number      |
|  Out of range        |  set_volume(150) - max is 100            |
|  Invalid format      |  parse_date("13-25-2024") - bad format   |
|                                                                   |
+------------------------------------------------------------------+
```

### 2. External Service Errors

```
+------------------------------------------------------------------+
|                   EXTERNAL SERVICE ERRORS                         |
+------------------------------------------------------------------+
|                                                                   |
|  Error Type          |  Cause                                     |
|  --------------------|-------------------------------------------  |
|  Connection timeout  |  Network issues, server slow              |
|  HTTP 4xx            |  Client error (bad request, not found)    |
|  HTTP 5xx            |  Server error (internal error, overload)  |
|  Rate limiting       |  Too many requests                        |
|  Authentication      |  Invalid/expired API key                  |
|                                                                   |
+------------------------------------------------------------------+
```

### 3. Processing Errors

```
+------------------------------------------------------------------+
|                     PROCESSING ERRORS                             |
+------------------------------------------------------------------+
|                                                                   |
|  Error Type          |  Cause                                     |
|  --------------------|-------------------------------------------  |
|  Division by zero    |  Mathematical impossibility               |
|  Parse error         |  Invalid JSON/XML/data format             |
|  Resource not found  |  File/record doesn't exist                |
|  Permission denied   |  Insufficient access rights               |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Error Handling Strategies

### Strategy 1: Return Error Messages (Recommended)

Return descriptive error messages instead of raising exceptions:

```python
from langchain_core.tools import tool

@tool
def safe_api_call(endpoint: str) -> str:
    """Call an API endpoint safely.

    Args:
        endpoint: The API endpoint to call

    Returns:
        API response or error message
    """
    try:
        response = requests.get(endpoint, timeout=10)
        response.raise_for_status()
        return response.json()
    except requests.Timeout:
        return "Error: Request timed out. The server took too long to respond."
    except requests.HTTPError as e:
        return f"Error: HTTP {e.response.status_code} - {e.response.reason}"
    except requests.ConnectionError:
        return "Error: Could not connect to the server. Check your network."
    except Exception as e:
        return f"Error: Unexpected problem - {str(e)}"
```

### Strategy 2: Structured Error Responses

Return structured dictionaries with error details:

```python
@tool
def fetch_data(resource_id: str) -> dict:
    """Fetch data by resource ID.

    Returns:
        Data or structured error response
    """
    try:
        data = database.get(resource_id)
        if not data:
            return {
                "success": False,
                "error_type": "not_found",
                "message": f"Resource '{resource_id}' does not exist",
                "suggestions": ["Check the ID", "List available resources"]
            }
        return {
            "success": True,
            "data": data
        }
    except DatabaseConnectionError:
        return {
            "success": False,
            "error_type": "connection_error",
            "message": "Database is temporarily unavailable",
            "retry_after": 30
        }
```

### Strategy 3: Using ToolException

LangChain's ToolException for explicit tool failures:

```python
from langchain_core.tools import tool, ToolException

@tool(handle_tool_error=True)
def strict_tool(value: int) -> str:
    """A tool that raises explicit exceptions.

    Args:
        value: Must be positive

    Raises:
        ToolException: If value is not positive
    """
    if value <= 0:
        raise ToolException(
            "Value must be positive. Please provide a number greater than 0."
        )
    return f"Processed: {value}"
```

### Strategy 4: Fallback Tools

Provide alternative paths when primary tool fails:

```python
@tool
def search_with_fallback(query: str) -> str:
    """Search with automatic fallback to alternative sources.

    Args:
        query: Search query

    Returns:
        Search results from primary or fallback source
    """
    # Try primary search
    try:
        result = primary_search_api(query)
        return f"[Primary Source] {result}"
    except Exception as primary_error:
        pass

    # Try secondary search
    try:
        result = secondary_search_api(query)
        return f"[Fallback Source] {result}"
    except Exception as secondary_error:
        pass

    # Both failed
    return f"Error: Search unavailable. Primary: {primary_error}, Fallback: {secondary_error}"
```

---

## Error Handling Patterns

### Pattern 1: Input Validation First

```python
@tool
def calculate_percentage(value: float, total: float) -> str:
    """Calculate what percentage value is of total.

    Args:
        value: The part value
        total: The total value (must be non-zero)

    Returns:
        Percentage or error message
    """
    # Validate BEFORE processing
    if total == 0:
        return "Error: Total cannot be zero (would cause division by zero)"

    if value < 0 or total < 0:
        return "Error: Values must be non-negative"

    percentage = (value / total) * 100
    return f"{value} is {percentage:.2f}% of {total}"
```

### Pattern 2: Retry with Backoff

```python
import time
from langchain_core.tools import tool

@tool
def reliable_api_call(url: str, max_retries: int = 3) -> str:
    """Make an API call with automatic retry.

    Args:
        url: The URL to call
        max_retries: Number of retry attempts (default: 3)

    Returns:
        Response or error after all retries exhausted
    """
    last_error = None

    for attempt in range(max_retries):
        try:
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            return response.text

        except requests.RequestException as e:
            last_error = e
            if attempt < max_retries - 1:
                # Exponential backoff: 1s, 2s, 4s
                wait_time = 2 ** attempt
                time.sleep(wait_time)

    return f"Error: Failed after {max_retries} attempts. Last error: {str(last_error)}"
```

### Pattern 3: Graceful Degradation

```python
@tool
def get_detailed_info(item_id: str) -> dict:
    """Get detailed information about an item.

    If full details aren't available, returns partial information.

    Args:
        item_id: The item identifier

    Returns:
        Available information about the item
    """
    result = {"item_id": item_id}

    # Try to get basic info (required)
    try:
        basic = fetch_basic_info(item_id)
        result["name"] = basic["name"]
        result["status"] = "partial"
    except Exception as e:
        return {"error": f"Item {item_id} not found", "details": str(e)}

    # Try to get extended info (optional)
    try:
        extended = fetch_extended_info(item_id)
        result.update(extended)
        result["status"] = "complete"
    except Exception:
        result["note"] = "Extended information temporarily unavailable"

    # Try to get analytics (optional)
    try:
        analytics = fetch_analytics(item_id)
        result["analytics"] = analytics
    except Exception:
        pass  # Silently skip analytics

    return result
```

### Pattern 4: Error Context Preservation

```python
@tool
def process_file(filepath: str) -> str:
    """Process a file with detailed error context.

    Args:
        filepath: Path to the file

    Returns:
        Processing result or detailed error
    """
    # Check file exists
    if not os.path.exists(filepath):
        return f"Error: File not found at '{filepath}'. Check the path and try again."

    # Check file readable
    if not os.access(filepath, os.R_OK):
        return f"Error: Permission denied. Cannot read '{filepath}'."

    # Check file size
    file_size = os.path.getsize(filepath)
    if file_size > 10_000_000:  # 10MB
        return f"Error: File too large ({file_size} bytes). Maximum is 10MB."

    # Process file
    try:
        with open(filepath, 'r') as f:
            content = f.read()
        # Process content...
        return f"Successfully processed {len(content)} characters"
    except UnicodeDecodeError:
        return "Error: File is not valid text. Try a different encoding or file."
    except Exception as e:
        return f"Error: Failed to process file - {str(e)}"
```

---

## Error Handling in LangGraph Workflows

### Custom Error Handler Node

```python
from langgraph.graph import StateGraph, END
from typing import TypedDict, Annotated, Literal

class AgentState(TypedDict):
    messages: list
    error_count: int
    last_error: str

def error_handler_node(state: AgentState) -> dict:
    """Handle errors in the workflow."""
    error_count = state.get("error_count", 0) + 1
    last_error = state.get("last_error", "Unknown error")

    if error_count >= 3:
        # Too many errors, give up gracefully
        from langchain_core.messages import AIMessage
        return {
            "messages": [AIMessage(content=(
                f"I apologize, but I'm having trouble completing this request. "
                f"Error: {last_error}. Please try rephrasing or try again later."
            ))],
            "error_count": error_count
        }

    # Retry with modified approach
    return {"error_count": error_count}

def should_handle_error(state: AgentState) -> Literal["error_handler", "continue", "end"]:
    """Decide how to handle errors."""
    if state.get("last_error"):
        if state.get("error_count", 0) >= 3:
            return "end"
        return "error_handler"
    return "continue"
```

### Workflow Diagram with Error Handling

```
+------------------------------------------------------------------+
|            LANGGRAPH WORKFLOW WITH ERROR HANDLING                 |
+------------------------------------------------------------------+
|                                                                   |
|                     +-------------+                               |
|                     |    START    |                               |
|                     +------+------+                               |
|                            |                                      |
|                            v                                      |
|                     +-------------+                               |
|            +--------|    AGENT    |--------+                      |
|            |        +-------------+        |                      |
|            |              |                |                      |
|         (error)       (tools)          (done)                    |
|            |              |                |                      |
|            v              v                v                      |
|     +------------+  +----------+    +----------+                 |
|     |   ERROR    |  |  TOOLS   |    |   END    |                 |
|     |  HANDLER   |  +----+-----+    +----------+                 |
|     +------+-----+       |                                        |
|            |             |                                        |
|            +-------------+                                        |
|            |                                                      |
|            v                                                      |
|     (retry or end)                                               |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Best Practices Summary

### Do's

| Practice | Example |
|----------|---------|
| Validate inputs early | Check for null, negative, wrong type |
| Return informative errors | "Email format invalid: missing @" |
| Include suggestions | "Try: check ID, list available items" |
| Log errors for debugging | logger.error(f"Tool failed: {e}") |
| Use timeouts | requests.get(url, timeout=10) |
| Implement retries for transient errors | Network issues, rate limits |

### Don'ts

| Avoid | Why |
|-------|-----|
| Silent failures | LLM won't know something went wrong |
| Generic error messages | "Error occurred" doesn't help |
| Exposing internal details | Don't leak stack traces to users |
| Infinite retries | Could hang the agent forever |
| Swallowing all exceptions | Some errors need to propagate |

---

## Interview Tips

### Common Questions

| Question | Key Points |
|----------|------------|
| "How do you handle tool errors?" | Return descriptive messages; use try-except; validate inputs first |
| "What about transient failures?" | Implement retries with exponential backoff; set max retry limits |
| "How do you prevent crashes?" | Wrap all external calls in try-except; validate before processing |
| "Structured vs string errors?" | Structured for programmatic handling; strings for simple cases |

### Key Points to Remember

1. **Never let tools crash the agent** - Always catch and handle exceptions
2. **Be informative** - Tell the LLM what went wrong and how to fix it
3. **Fail fast on validation** - Check inputs before expensive operations
4. **Graceful degradation** - Return partial results when possible
5. **Retry transient errors** - Network issues often resolve themselves

---

## Error Message Template

```python
def format_error(
    error_type: str,
    message: str,
    suggestions: list = None,
    details: str = None
) -> str:
    """Format a consistent error message.

    Args:
        error_type: Category of error
        message: Human-readable error message
        suggestions: List of things user can try
        details: Technical details (optional)

    Returns:
        Formatted error message
    """
    parts = [f"Error ({error_type}): {message}"]

    if suggestions:
        parts.append("Suggestions:")
        for s in suggestions:
            parts.append(f"  - {s}")

    if details:
        parts.append(f"Details: {details}")

    return "\n".join(parts)
```

---

## Summary

```
+------------------------------------------------------------------+
|                        KEY TAKEAWAYS                              |
+------------------------------------------------------------------+
|                                                                   |
|  1. Always wrap external calls in try-except                     |
|                                                                   |
|  2. Return informative error messages, not exceptions            |
|                                                                   |
|  3. Validate inputs before processing                            |
|                                                                   |
|  4. Implement retries for transient failures                     |
|                                                                   |
|  5. Use structured errors for complex scenarios                  |
|                                                                   |
|  6. Provide suggestions in error messages                        |
|                                                                   |
|  7. Log errors for debugging                                     |
|                                                                   |
|  8. Set reasonable timeouts and retry limits                     |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Next Steps

Continue to `09_error_handling_example.py` for complete working examples of robust tool error handling.
