"""
============================================================================
05. LangChain Tools Example - Using Pre-built Tools with LangGraph
============================================================================

This file demonstrates how to use LangChain's pre-built tools with LangGraph
agents. We'll cover:
- Wikipedia tool
- DuckDuckGo search
- Calculator/Math tools
- Building multi-tool agents

Prerequisites:
    pip install langchain-core langchain-community langchain-openai langgraph
    pip install wikipedia duckduckgo-search numexpr

Environment Variables:
    OPENAI_API_KEY=your-key-here
    TAVILY_API_KEY=your-key-here (optional, for Tavily search)
"""

# ============================================================================
# IMPORTS
# ============================================================================

import os
from typing import TypedDict, Annotated
from dotenv import load_dotenv

from langchain_core.messages import HumanMessage, AIMessage
from langchain_openai import ChatOpenAI

# LangChain Community Tools
from langchain_community.tools import WikipediaQueryRun, DuckDuckGoSearchRun
from langchain_community.utilities import WikipediaAPIWrapper

# LangGraph
from langgraph.prebuilt import create_react_agent
from langgraph.graph import StateGraph, END
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode

# Load environment variables
load_dotenv()

print("=" * 70)
print("LANGCHAIN TOOLS WITH LANGGRAPH - EXAMPLES")
print("=" * 70)


# ============================================================================
# SECTION 1: WIKIPEDIA TOOL
# ============================================================================
"""
Wikipedia is great for:
- Background information
- Historical facts
- Scientific concepts
- Biographical information

It's free, no API key required!
"""

print("\n" + "-" * 70)
print("Section 1: Wikipedia Tool")
print("-" * 70)


def setup_wikipedia_tool():
    """Set up and demonstrate the Wikipedia tool."""

    print("\n[*] Setting up Wikipedia Tool")

    # Configure the API wrapper
    # top_k_results: Number of Wikipedia articles to retrieve
    # doc_content_chars_max: Maximum characters per article
    api_wrapper = WikipediaAPIWrapper(
        top_k_results=2,
        doc_content_chars_max=2000
    )

    # Create the tool
    wiki_tool = WikipediaQueryRun(api_wrapper=api_wrapper)

    print(f"    Tool name: {wiki_tool.name}")
    print(f"    Tool description: {wiki_tool.description[:80]}...")

    return wiki_tool


def demo_wikipedia_standalone():
    """Demonstrate Wikipedia tool standalone usage."""

    print("\n[*] Wikipedia Standalone Demo")

    wiki = setup_wikipedia_tool()

    # Example queries
    queries = [
        "Python programming language",
        "Machine learning",
        "Albert Einstein"
    ]

    for query in queries:
        print(f"\n    Query: '{query}'")
        try:
            result = wiki.run(query)
            # Show first 200 chars of result
            print(f"    Result: {result[:200]}...")
        except Exception as e:
            print(f"    Error: {e}")

# Uncomment to run:
# demo_wikipedia_standalone()


# ============================================================================
# SECTION 2: DUCKDUCKGO SEARCH
# ============================================================================
"""
DuckDuckGo Search is great for:
- Current events and news
- Web content that changes frequently
- Privacy-focused searching
- No API key required!
"""

print("\n" + "-" * 70)
print("Section 2: DuckDuckGo Search Tool")
print("-" * 70)


def setup_duckduckgo_tool():
    """Set up and demonstrate the DuckDuckGo search tool."""

    print("\n[*] Setting up DuckDuckGo Search Tool")

    # Create the tool - no configuration needed!
    search_tool = DuckDuckGoSearchRun()

    print(f"    Tool name: {search_tool.name}")
    print(f"    Tool description: {search_tool.description[:80]}...")

    return search_tool


def demo_duckduckgo_standalone():
    """Demonstrate DuckDuckGo search standalone usage."""

    print("\n[*] DuckDuckGo Standalone Demo")

    search = setup_duckduckgo_tool()

    # Example queries
    queries = [
        "best practices for Python coding",
        "latest AI developments 2024",
        "how to learn programming"
    ]

    for query in queries:
        print(f"\n    Query: '{query}'")
        try:
            result = search.run(query)
            # Show first 300 chars of result
            print(f"    Result: {result[:300]}...")
        except Exception as e:
            print(f"    Error: {e}")

# Uncomment to run:
# demo_duckduckgo_standalone()


# ============================================================================
# SECTION 3: MATH/CALCULATOR TOOL
# ============================================================================
"""
For math operations, we can create a simple calculator tool
or use LangChain's built-in options.
"""

print("\n" + "-" * 70)
print("Section 3: Math/Calculator Tool")
print("-" * 70)

from langchain_core.tools import tool


@tool
def calculator(expression: str) -> str:
    """Evaluate a mathematical expression.

    Use this tool for any mathematical calculations.
    Supports: +, -, *, /, **, sqrt, sin, cos, tan, log, etc.

    Args:
        expression: A mathematical expression like "2 + 2" or "sqrt(16)"

    Returns:
        The result of the calculation as a string

    Examples:
        calculator("2 + 2") -> "4"
        calculator("sqrt(16)") -> "4.0"
        calculator("3.14159 * 5 ** 2") -> "78.53975"
    """
    import math

    # Create a safe namespace for evaluation
    safe_dict = {
        "sqrt": math.sqrt,
        "sin": math.sin,
        "cos": math.cos,
        "tan": math.tan,
        "log": math.log,
        "log10": math.log10,
        "exp": math.exp,
        "pi": math.pi,
        "e": math.e,
        "abs": abs,
        "round": round,
        "pow": pow
    }

    try:
        # Evaluate the expression safely
        result = eval(expression, {"__builtins__": {}}, safe_dict)
        return str(result)
    except Exception as e:
        return f"Error evaluating '{expression}': {str(e)}"


def demo_calculator():
    """Demonstrate the calculator tool."""

    print("\n[*] Calculator Tool Demo")

    expressions = [
        "2 + 2",
        "15 * 7",
        "sqrt(144)",
        "3.14159 * 10 ** 2",
        "sin(pi / 2)",
        "log(e)"
    ]

    for expr in expressions:
        result = calculator.invoke(expr)
        print(f"    {expr} = {result}")

# Uncomment to run:
# demo_calculator()


# ============================================================================
# SECTION 4: COMBINING TOOLS IN A LANGGRAPH AGENT
# ============================================================================
"""
Now let's combine multiple LangChain tools into a single LangGraph agent.
This agent can:
- Search Wikipedia for background information
- Search the web for current information
- Perform calculations
"""

print("\n" + "-" * 70)
print("Section 4: Multi-Tool LangGraph Agent")
print("-" * 70)


def create_multi_tool_agent():
    """Create an agent with multiple LangChain tools."""

    print("\n[*] Creating Multi-Tool Agent")

    # 1. Set up tools
    wiki = WikipediaQueryRun(
        api_wrapper=WikipediaAPIWrapper(
            top_k_results=2,
            doc_content_chars_max=1500
        )
    )

    ddg_search = DuckDuckGoSearchRun()

    tools = [wiki, ddg_search, calculator]

    print(f"    Tools loaded: {[t.name for t in tools]}")

    # 2. Create the LLM
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)

    # 3. Create the agent
    agent = create_react_agent(llm, tools)

    return agent


def demo_multi_tool_agent():
    """Demonstrate the multi-tool agent."""

    print("\n[*] Multi-Tool Agent Demo")

    # Check for API key
    if not os.getenv("OPENAI_API_KEY"):
        print("    [!] OPENAI_API_KEY not set. Skipping demo.")
        return

    agent = create_multi_tool_agent()

    # Test queries that require different tools
    test_queries = [
        # Wikipedia query
        "Who invented Python programming language and when?",

        # Calculator query
        "What is the square root of 1764 plus 15 times 8?",

        # Web search query
        "What are the latest trends in AI for 2024?",

        # Combined query (might use multiple tools)
        "What is the population of Tokyo and what is 10% of that number?"
    ]

    for query in test_queries:
        print(f"\n    Query: '{query}'")
        print("    " + "-" * 50)

        try:
            result = agent.invoke({
                "messages": [HumanMessage(content=query)]
            })

            # Show which tools were used
            for msg in result["messages"]:
                if isinstance(msg, AIMessage) and msg.tool_calls:
                    for tc in msg.tool_calls:
                        print(f"    [Tool Used] {tc['name']}")

            # Show final response
            final_msg = result["messages"][-1]
            print(f"    [Response] {final_msg.content[:300]}...")

        except Exception as e:
            print(f"    [Error] {e}")

# Uncomment to run:
# demo_multi_tool_agent()


# ============================================================================
# SECTION 5: CUSTOM AGENT WITH MANUAL TOOL HANDLING
# ============================================================================
"""
Sometimes you need more control over how tools are used.
This section shows manual tool handling in a LangGraph workflow.
"""

print("\n" + "-" * 70)
print("Section 5: Custom Agent with Manual Tool Handling")
print("-" * 70)


# Define the state
class ResearchState(TypedDict):
    """State for our research agent."""
    messages: Annotated[list, add_messages]
    research_complete: bool


def create_custom_research_agent():
    """Create a custom agent with manual tool handling."""

    # Set up tools
    wiki = WikipediaQueryRun(
        api_wrapper=WikipediaAPIWrapper(
            top_k_results=2,
            doc_content_chars_max=2000
        )
    )
    ddg = DuckDuckGoSearchRun()
    tools = [wiki, ddg, calculator]

    # Create LLM with tools bound
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    llm_with_tools = llm.bind_tools(tools)

    # Define the research node
    def research_node(state: ResearchState):
        """Call LLM to decide on research approach."""
        response = llm_with_tools.invoke(state["messages"])
        return {"messages": [response]}

    # Define routing logic
    def should_continue(state: ResearchState):
        """Check if we should continue to tools or finish."""
        last_message = state["messages"][-1]

        if hasattr(last_message, "tool_calls") and last_message.tool_calls:
            return "tools"
        return "end"

    # Build the graph
    graph = StateGraph(ResearchState)

    # Add nodes
    graph.add_node("researcher", research_node)
    graph.add_node("tools", ToolNode(tools))

    # Set entry point
    graph.set_entry_point("researcher")

    # Add conditional edges
    graph.add_conditional_edges(
        "researcher",
        should_continue,
        {
            "tools": "tools",
            "end": END
        }
    )

    # Tools return to researcher
    graph.add_edge("tools", "researcher")

    return graph.compile()


def demo_custom_research_agent():
    """Demonstrate the custom research agent."""

    print("\n[*] Custom Research Agent Demo")

    if not os.getenv("OPENAI_API_KEY"):
        print("    [!] OPENAI_API_KEY not set. Skipping demo.")
        return

    agent = create_custom_research_agent()

    query = "What is the Fibonacci sequence and what is the 10th Fibonacci number?"

    print(f"\n    Query: '{query}'")
    print("    " + "-" * 50)

    result = agent.invoke({
        "messages": [HumanMessage(content=query)],
        "research_complete": False
    })

    # Show the conversation flow
    print("\n    Conversation Flow:")
    for i, msg in enumerate(result["messages"]):
        msg_type = type(msg).__name__
        if hasattr(msg, 'tool_calls') and msg.tool_calls:
            tools_called = [tc['name'] for tc in msg.tool_calls]
            print(f"    {i+1}. {msg_type}: [Called tools: {tools_called}]")
        elif hasattr(msg, 'content') and msg.content:
            content_preview = msg.content[:100] + "..." if len(msg.content) > 100 else msg.content
            print(f"    {i+1}. {msg_type}: {content_preview}")

# Uncomment to run:
# demo_custom_research_agent()


# ============================================================================
# SECTION 6: TAVILY SEARCH (API KEY REQUIRED)
# ============================================================================
"""
Tavily is an AI-optimized search engine that returns structured results.
It's particularly good for AI applications.

Requires: TAVILY_API_KEY environment variable
"""

print("\n" + "-" * 70)
print("Section 6: Tavily Search (Optional)")
print("-" * 70)


def demo_tavily_search():
    """Demonstrate Tavily search if API key is available."""

    print("\n[*] Tavily Search Demo")

    if not os.getenv("TAVILY_API_KEY"):
        print("    [!] TAVILY_API_KEY not set. Skipping Tavily demo.")
        print("    Get your free API key at: https://tavily.com")
        return

    try:
        from langchain_community.tools.tavily_search import TavilySearchResults

        # Create Tavily search tool
        tavily = TavilySearchResults(max_results=3)

        print(f"    Tool name: {tavily.name}")

        # Test query
        query = "latest developments in large language models 2024"
        print(f"\n    Query: '{query}'")

        results = tavily.invoke(query)

        print(f"    Number of results: {len(results)}")
        for i, result in enumerate(results[:2]):
            print(f"\n    Result {i+1}:")
            print(f"      Title: {result.get('title', 'N/A')[:60]}...")
            print(f"      URL: {result.get('url', 'N/A')}")

    except ImportError:
        print("    [!] tavily-python not installed. Run: pip install tavily-python")
    except Exception as e:
        print(f"    [!] Error: {e}")

# Uncomment to run:
# demo_tavily_search()


# ============================================================================
# SECTION 7: BUILDING A COMPLETE RESEARCH ASSISTANT
# ============================================================================
"""
Let's build a complete research assistant that combines multiple tools
and provides a structured research workflow.
"""

print("\n" + "-" * 70)
print("Section 7: Complete Research Assistant")
print("-" * 70)


class ResearchAssistantState(TypedDict):
    """State for the research assistant."""
    messages: Annotated[list, add_messages]
    topic: str
    sources_checked: list
    final_answer: str


def create_research_assistant():
    """Create a comprehensive research assistant."""

    # Tools
    wiki = WikipediaQueryRun(
        api_wrapper=WikipediaAPIWrapper(
            top_k_results=2,
            doc_content_chars_max=1500
        )
    )
    ddg = DuckDuckGoSearchRun()

    tools = [wiki, ddg, calculator]

    # LLM with system prompt
    system_prompt = """You are a research assistant that helps users find accurate information.

When researching a topic:
1. First check Wikipedia for foundational knowledge
2. Use web search for current/recent information
3. Use calculator for any numerical calculations

Always cite which tools you used to find information.
Be thorough but concise in your responses."""

    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    llm_with_tools = llm.bind_tools(tools)

    def research_node(state: ResearchAssistantState):
        """Main research logic."""
        messages = state["messages"]

        # Add system prompt if not present
        if not any(hasattr(m, 'type') and m.type == 'system' for m in messages):
            from langchain_core.messages import SystemMessage
            messages = [SystemMessage(content=system_prompt)] + messages

        response = llm_with_tools.invoke(messages)
        return {"messages": [response]}

    def should_continue(state: ResearchAssistantState):
        """Check if more research needed."""
        last_message = state["messages"][-1]

        if hasattr(last_message, "tool_calls") and last_message.tool_calls:
            return "tools"
        return "end"

    # Build graph
    graph = StateGraph(ResearchAssistantState)

    graph.add_node("researcher", research_node)
    graph.add_node("tools", ToolNode(tools))

    graph.set_entry_point("researcher")

    graph.add_conditional_edges(
        "researcher",
        should_continue,
        {"tools": "tools", "end": END}
    )

    graph.add_edge("tools", "researcher")

    return graph.compile()


def demo_research_assistant():
    """Demonstrate the research assistant."""

    print("\n[*] Research Assistant Demo")

    if not os.getenv("OPENAI_API_KEY"):
        print("    [!] OPENAI_API_KEY not set. Skipping demo.")
        return

    assistant = create_research_assistant()

    # Research query
    query = """I'm writing a paper about climate change.
    Can you help me find:
    1. The current global average temperature increase
    2. When was the Paris Agreement signed
    3. What is 2 degrees Celsius in Fahrenheit?"""

    print(f"\n    Research Query:")
    print(f"    {query}")
    print("\n    " + "-" * 50)
    print("    Processing...")

    result = assistant.invoke({
        "messages": [HumanMessage(content=query)],
        "topic": "climate change",
        "sources_checked": [],
        "final_answer": ""
    })

    # Count tools used
    tools_used = []
    for msg in result["messages"]:
        if isinstance(msg, AIMessage) and msg.tool_calls:
            tools_used.extend([tc['name'] for tc in msg.tool_calls])

    print(f"\n    Tools used: {list(set(tools_used))}")

    # Final response
    final = result["messages"][-1]
    print(f"\n    Final Response:\n    {final.content[:500]}...")

# Uncomment to run:
# demo_research_assistant()


# ============================================================================
# SECTION 8: MAIN RUNNER
# ============================================================================

def main():
    """Run all demonstrations."""

    print("\n" + "=" * 70)
    print("RUNNING LANGCHAIN TOOLS DEMONSTRATIONS")
    print("=" * 70)

    # Check environment
    has_openai = bool(os.getenv("OPENAI_API_KEY"))
    has_tavily = bool(os.getenv("TAVILY_API_KEY"))

    print(f"\n[Environment Check]")
    print(f"    OPENAI_API_KEY: {'Set' if has_openai else 'Not set'}")
    print(f"    TAVILY_API_KEY: {'Set' if has_tavily else 'Not set'}")

    # Run demos that don't need API keys
    print("\n[1] Wikipedia Tool (No API Key Required)")
    demo_wikipedia_standalone()

    print("\n[2] DuckDuckGo Search (No API Key Required)")
    demo_duckduckgo_standalone()

    print("\n[3] Calculator Tool")
    demo_calculator()

    # Run demos that need OpenAI
    if has_openai:
        print("\n[4] Multi-Tool Agent")
        demo_multi_tool_agent()

        print("\n[5] Custom Research Agent")
        demo_custom_research_agent()

        print("\n[6] Research Assistant")
        demo_research_assistant()
    else:
        print("\n[!] Skipping LLM-based demos (no OPENAI_API_KEY)")

    # Tavily demo
    if has_tavily:
        print("\n[7] Tavily Search")
        demo_tavily_search()

    print("\n" + "=" * 70)
    print("DEMONSTRATIONS COMPLETE")
    print("=" * 70)


if __name__ == "__main__":
    main()


# ============================================================================
# INTERVIEW TIP BOX
# ============================================================================
"""
+--------------------------------------------------------------------------+
|                           INTERVIEW TIP                                   |
+--------------------------------------------------------------------------+
|                                                                          |
|  Q: "What LangChain tools have you used and why?"                       |
|                                                                          |
|  A: "I've used several LangChain tools depending on the use case:       |
|                                                                          |
|      - Wikipedia: For background/foundational information that doesn't  |
|        change often. It's free and doesn't require an API key.          |
|                                                                          |
|      - DuckDuckGo: For current web content when Tavily isn't available. |
|        Good for privacy-conscious applications.                          |
|                                                                          |
|      - Tavily: For AI applications - it returns structured results      |
|        optimized for LLM consumption. Best for production apps.          |
|                                                                          |
|      - PythonREPL: For complex calculations, but always sandboxed       |
|        in production due to security concerns.                           |
|                                                                          |
|      The key is choosing the right tool for the task - Wikipedia for    |
|      facts, search for current events, calculators for math."           |
|                                                                          |
|  Key points to mention:                                                  |
|  1. Tool selection based on use case                                    |
|  2. Security awareness (sandboxing code execution)                      |
|  3. API key requirements                                                |
|  4. Integration with LangGraph agents                                   |
|                                                                          |
+--------------------------------------------------------------------------+
"""
