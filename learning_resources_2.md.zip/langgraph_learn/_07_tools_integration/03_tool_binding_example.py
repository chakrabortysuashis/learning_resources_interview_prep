"""
============================================================================
03. Tool Binding Example - LangGraph Tools & Integration
============================================================================

This file demonstrates how to bind tools to LLMs and use them in LangGraph.
We'll cover:
- Basic tool binding
- Tool choice options
- Handling tool call responses
- Building a simple agent with bound tools

Prerequisites:
    pip install langchain-core langchain-openai langgraph

Environment Variables:
    OPENAI_API_KEY=your-key-here
"""

# ============================================================================
# IMPORTS
# ============================================================================

import os
from typing import TypedDict, Annotated, Literal
from dotenv import load_dotenv

from langchain_core.tools import tool
from langchain_core.messages import HumanMessage, AIMessage, ToolMessage
from langchain_openai import ChatOpenAI

from langgraph.graph import StateGraph, END
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode

# Load environment variables
load_dotenv()

# ============================================================================
# SECTION 1: DEFINING SIMPLE TOOLS
# ============================================================================
"""
Tools are Python functions decorated with @tool.
The docstring is CRITICAL - the LLM reads it to decide when to use the tool.
"""

@tool
def add_numbers(a: int, b: int) -> int:
    """Add two numbers together.

    Use this tool when you need to calculate the sum of two numbers.

    Args:
        a: The first number to add
        b: The second number to add

    Returns:
        The sum of a and b

    Example:
        add_numbers(5, 3) returns 8
    """
    print(f"[Tool Executed] add_numbers({a}, {b})")
    return a + b


@tool
def multiply_numbers(a: int, b: int) -> int:
    """Multiply two numbers together.

    Use this tool when you need to calculate the product of two numbers.

    Args:
        a: The first number to multiply
        b: The second number to multiply

    Returns:
        The product of a and b

    Example:
        multiply_numbers(4, 7) returns 28
    """
    print(f"[Tool Executed] multiply_numbers({a}, {b})")
    return a * b


@tool
def get_weather(city: str) -> str:
    """Get the current weather for a city.

    Use this tool when the user asks about weather conditions in a specific location.

    Args:
        city: The name of the city to get weather for

    Returns:
        A string describing the current weather conditions
    """
    # Simulated weather data (in real app, would call weather API)
    weather_data = {
        "new york": "72°F, Partly Cloudy",
        "london": "58°F, Rainy",
        "tokyo": "68°F, Clear",
        "paris": "65°F, Overcast",
        "sydney": "77°F, Sunny"
    }

    city_lower = city.lower()
    weather = weather_data.get(city_lower, f"Weather data not available for {city}")

    print(f"[Tool Executed] get_weather('{city}')")
    return f"Current weather in {city}: {weather}"


# Create a list of all tools
tools = [add_numbers, multiply_numbers, get_weather]

print("=" * 70)
print("TOOL BINDING EXAMPLES")
print("=" * 70)


# ============================================================================
# SECTION 2: BASIC TOOL BINDING
# ============================================================================
"""
Tool binding attaches tools to an LLM, enabling it to call them.
The LLM receives the tool schemas and can decide when to use them.
"""

print("\n" + "-" * 70)
print("Section 2: Basic Tool Binding")
print("-" * 70)

def demonstrate_basic_binding():
    """Show basic tool binding to an LLM."""

    # Create base LLM
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)

    # Bind tools to the LLM
    # This converts Python functions to JSON schemas the LLM understands
    llm_with_tools = llm.bind_tools(tools)

    print("\n[*] Tools bound to LLM:")
    for t in tools:
        print(f"    - {t.name}: {t.description[:50]}...")

    # Test 1: Query that doesn't need tools
    print("\n[Test 1] Query without tool need:")
    print("    Query: 'Hello, how are you?'")

    response = llm_with_tools.invoke([HumanMessage(content="Hello, how are you?")])

    print(f"    Tool calls: {len(response.tool_calls)}")
    print(f"    Response: {response.content[:100]}...")

    # Test 2: Query that triggers a tool
    print("\n[Test 2] Query requiring a tool:")
    print("    Query: 'What is 25 plus 17?'")

    response = llm_with_tools.invoke([HumanMessage(content="What is 25 plus 17?")])

    print(f"    Tool calls: {len(response.tool_calls)}")
    if response.tool_calls:
        for tc in response.tool_calls:
            print(f"    Tool: {tc['name']}, Args: {tc['args']}")

    return llm_with_tools

# Uncomment to run:
# llm_with_tools = demonstrate_basic_binding()


# ============================================================================
# SECTION 3: TOOL CHOICE OPTIONS
# ============================================================================
"""
Tool choice controls how the LLM uses tools:
- "auto" (default): LLM decides whether to use tools
- "required": LLM must use at least one tool
- "none": Tools are disabled
- "<tool_name>": Force use of a specific tool
"""

print("\n" + "-" * 70)
print("Section 3: Tool Choice Options")
print("-" * 70)

def demonstrate_tool_choice():
    """Demonstrate different tool_choice settings."""

    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    query = "What is 10 times 5?"

    # Option 1: Auto (default)
    print("\n[Option 1] tool_choice='auto'")
    llm_auto = llm.bind_tools(tools, tool_choice="auto")
    response = llm_auto.invoke([HumanMessage(content=query)])
    print(f"    Tool used: {response.tool_calls[0]['name'] if response.tool_calls else 'None'}")

    # Option 2: Required
    print("\n[Option 2] tool_choice='required'")
    llm_required = llm.bind_tools(tools, tool_choice="required")
    response = llm_required.invoke([HumanMessage(content="Hello there!")])
    print(f"    Tool used: {response.tool_calls[0]['name'] if response.tool_calls else 'None'}")
    print("    (Even for a greeting, a tool was forced)")

    # Option 3: Specific tool
    print("\n[Option 3] tool_choice='add_numbers'")
    llm_specific = llm.bind_tools(tools, tool_choice="add_numbers")
    # Note: This forces add even for multiplication!
    response = llm_specific.invoke([HumanMessage(content="What is 10 times 5?")])
    print(f"    Tool used: {response.tool_calls[0]['name'] if response.tool_calls else 'None'}")
    print("    (add_numbers forced even though multiplication was asked)")

# Uncomment to run:
# demonstrate_tool_choice()


# ============================================================================
# SECTION 4: HANDLING TOOL CALL RESPONSES
# ============================================================================
"""
When an LLM calls a tool, you must:
1. Extract the tool call from the response
2. Execute the actual tool function
3. Return the result as a ToolMessage
4. Let the LLM generate a final response

This is the "tool execution loop".
"""

print("\n" + "-" * 70)
print("Section 4: Handling Tool Call Responses")
print("-" * 70)

def execute_tool_call(tool_call: dict, available_tools: list) -> str:
    """Execute a tool call and return the result.

    Args:
        tool_call: The tool call dict from LLM response
        available_tools: List of available tool functions

    Returns:
        The result of the tool execution as a string
    """
    # Find the tool by name
    tool_map = {t.name: t for t in available_tools}
    tool_name = tool_call["name"]
    tool_args = tool_call["args"]

    if tool_name not in tool_map:
        return f"Error: Tool '{tool_name}' not found"

    # Execute the tool
    tool_func = tool_map[tool_name]
    result = tool_func.invoke(tool_args)

    return str(result)


def demonstrate_tool_execution_loop():
    """Show the complete tool call -> execution -> response loop."""

    print("\n[*] Complete Tool Execution Loop")
    print("    Query: 'What is 15 plus 27, and what is the weather in Tokyo?'")

    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    llm_with_tools = llm.bind_tools(tools)

    # Initial message
    messages = [HumanMessage(content="What is 15 plus 27, and what is the weather in Tokyo?")]

    # Step 1: Get LLM response (may contain tool calls)
    print("\n    Step 1: LLM generates tool calls")
    response = llm_with_tools.invoke(messages)
    print(f"    Number of tool calls: {len(response.tool_calls)}")

    # Add AI response to messages
    messages.append(response)

    # Step 2: Execute each tool call
    print("\n    Step 2: Execute tools")
    for tool_call in response.tool_calls:
        print(f"    Executing: {tool_call['name']}({tool_call['args']})")

        # Execute the tool
        result = execute_tool_call(tool_call, tools)
        print(f"    Result: {result}")

        # Add tool result as ToolMessage
        # IMPORTANT: tool_call_id must match the original call
        tool_message = ToolMessage(
            content=str(result),
            tool_call_id=tool_call["id"]
        )
        messages.append(tool_message)

    # Step 3: Get final response from LLM
    print("\n    Step 3: LLM generates final response")
    final_response = llm_with_tools.invoke(messages)
    print(f"    Final response: {final_response.content}")

    return messages

# Uncomment to run:
# messages = demonstrate_tool_execution_loop()


# ============================================================================
# SECTION 5: LANGGRAPH AGENT WITH TOOL BINDING
# ============================================================================
"""
LangGraph provides a cleaner way to handle tool execution with:
- ToolNode: Automatically executes tool calls
- Conditional edges: Route based on whether tools were called
"""

print("\n" + "-" * 70)
print("Section 5: LangGraph Agent with Tool Binding")
print("-" * 70)

# Define state for our agent
class AgentState(TypedDict):
    """State for our tool-using agent."""
    messages: Annotated[list, add_messages]


def create_tool_agent():
    """Create a LangGraph agent with bound tools."""

    # Initialize LLM with tools
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    llm_with_tools = llm.bind_tools(tools)

    # Define the agent node (calls the LLM)
    def agent_node(state: AgentState):
        """Process messages and potentially call tools."""
        response = llm_with_tools.invoke(state["messages"])
        return {"messages": [response]}

    # Define routing logic
    def should_continue(state: AgentState) -> Literal["tools", "end"]:
        """Decide whether to execute tools or end."""
        last_message = state["messages"][-1]

        # If there are tool calls, execute them
        if hasattr(last_message, "tool_calls") and last_message.tool_calls:
            return "tools"

        # Otherwise, end the conversation
        return "end"

    # Build the graph
    graph = StateGraph(AgentState)

    # Add nodes
    graph.add_node("agent", agent_node)
    graph.add_node("tools", ToolNode(tools))  # Automatic tool execution!

    # Set entry point
    graph.set_entry_point("agent")

    # Add edges
    graph.add_conditional_edges(
        "agent",
        should_continue,
        {
            "tools": "tools",
            "end": END
        }
    )

    # Tools always return to agent
    graph.add_edge("tools", "agent")

    # Compile and return
    return graph.compile()


def run_tool_agent():
    """Demonstrate the LangGraph tool agent."""

    print("\n[*] LangGraph Tool Agent Demo")

    agent = create_tool_agent()

    # Test queries
    test_queries = [
        "What is 42 multiplied by 17?",
        "What's the weather like in Paris?",
        "Calculate 100 plus 50, then tell me the weather in London"
    ]

    for query in test_queries:
        print(f"\n    Query: '{query}'")
        print("    " + "-" * 50)

        result = agent.invoke({
            "messages": [HumanMessage(content=query)]
        })

        # Show tool calls that were made
        for msg in result["messages"]:
            if isinstance(msg, AIMessage) and msg.tool_calls:
                for tc in msg.tool_calls:
                    print(f"    [Tool Called] {tc['name']}({tc['args']})")
            elif isinstance(msg, ToolMessage):
                print(f"    [Tool Result] {msg.content}")

        # Show final response
        final = result["messages"][-1]
        print(f"    [Response] {final.content[:150]}...")

# Uncomment to run:
# run_tool_agent()


# ============================================================================
# SECTION 6: PARALLEL TOOL CALLS
# ============================================================================
"""
Modern LLMs can call multiple tools in parallel for efficiency.
LangGraph handles this automatically with ToolNode.
"""

print("\n" + "-" * 70)
print("Section 6: Parallel Tool Calls")
print("-" * 70)

def demonstrate_parallel_calls():
    """Show how parallel tool calls work."""

    print("\n[*] Parallel Tool Execution")
    print("    Query: 'What is 5+3, 10*2, and the weather in Sydney?'")

    agent = create_tool_agent()

    result = agent.invoke({
        "messages": [HumanMessage(
            content="What is 5+3, what is 10*2, and what's the weather in Sydney?"
        )]
    })

    # Count tool calls in the first AI message
    for msg in result["messages"]:
        if isinstance(msg, AIMessage) and msg.tool_calls:
            print(f"\n    Tools called in parallel: {len(msg.tool_calls)}")
            for tc in msg.tool_calls:
                print(f"      - {tc['name']}({tc['args']})")

    print(f"\n    Final Response: {result['messages'][-1].content}")

# Uncomment to run:
# demonstrate_parallel_calls()


# ============================================================================
# SECTION 7: DYNAMIC TOOL BINDING
# ============================================================================
"""
You can bind different tools based on context, user role, or state.
"""

print("\n" + "-" * 70)
print("Section 7: Dynamic Tool Binding")
print("-" * 70)

# Additional tools for demonstration
@tool
def admin_delete(record_id: str) -> str:
    """Delete a record from the database. ADMIN ONLY.

    Args:
        record_id: The ID of the record to delete
    """
    return f"Record {record_id} deleted (simulated)"


@tool
def view_data(query: str) -> str:
    """View data from the database.

    Args:
        query: Search query for the data
    """
    return f"Data for query '{query}': [simulated results]"


def get_tools_for_role(role: str) -> list:
    """Return appropriate tools based on user role.

    Args:
        role: User's role (admin, user, guest)

    Returns:
        List of tools available for that role
    """
    base_tools = [add_numbers, multiply_numbers, get_weather]

    if role == "admin":
        return base_tools + [admin_delete, view_data]
    elif role == "user":
        return base_tools + [view_data]
    else:  # guest
        return [get_weather]  # Limited access


def demonstrate_dynamic_binding():
    """Show dynamic tool binding based on user role."""

    print("\n[*] Dynamic Tool Binding by Role")

    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)

    roles = ["admin", "user", "guest"]

    for role in roles:
        role_tools = get_tools_for_role(role)
        print(f"\n    Role: {role}")
        print(f"    Available tools: {[t.name for t in role_tools]}")

# Uncomment to run:
# demonstrate_dynamic_binding()


# ============================================================================
# SECTION 8: COMPLETE WORKING EXAMPLE
# ============================================================================
"""
A complete, runnable example bringing everything together.
"""

def main():
    """Run all demonstrations."""

    print("\n" + "=" * 70)
    print("RUNNING COMPLETE TOOL BINDING DEMONSTRATION")
    print("=" * 70)

    # Check for API key
    if not os.getenv("OPENAI_API_KEY"):
        print("\n[!] Warning: OPENAI_API_KEY not set")
        print("    Set it in your environment or .env file")
        print("    Example: export OPENAI_API_KEY='your-key-here'")
        return

    # Run demonstrations
    print("\n[1] Basic Tool Binding")
    demonstrate_basic_binding()

    print("\n[2] Tool Choice Options")
    demonstrate_tool_choice()

    print("\n[3] Tool Execution Loop")
    demonstrate_tool_execution_loop()

    print("\n[4] LangGraph Agent")
    run_tool_agent()

    print("\n[5] Parallel Tool Calls")
    demonstrate_parallel_calls()

    print("\n[6] Dynamic Tool Binding")
    demonstrate_dynamic_binding()

    print("\n" + "=" * 70)
    print("DEMONSTRATION COMPLETE")
    print("=" * 70)


if __name__ == "__main__":
    main()


# ============================================================================
# INTERVIEW TIP BOX
# ============================================================================
"""
+--------------------------------------------------------------------------+
|                           INTERVIEW TIP                                   |
+--------------------------------------------------------------------------+
|                                                                          |
|  Q: "How does tool binding work in LangGraph?"                          |
|                                                                          |
|  A: "Tool binding converts Python functions into JSON schemas that the  |
|      LLM understands. When you call llm.bind_tools([tools]), the LLM    |
|      receives metadata about each tool - its name, description from the |
|      docstring, and parameter schemas from type hints. The LLM then     |
|      decides when to call tools based on user queries and tool          |
|      descriptions. Tool calls are returned in the response, which must  |
|      be executed and results fed back as ToolMessages."                 |
|                                                                          |
|  Key points to mention:                                                  |
|  1. Docstrings are critical - LLM reads them to decide tool usage       |
|  2. Type hints generate the parameter schema                            |
|  3. tool_choice parameter controls LLM behavior (auto/required/none)    |
|  4. ToolNode in LangGraph automates tool execution                      |
|  5. Tools can be bound dynamically based on context                     |
|                                                                          |
+--------------------------------------------------------------------------+
"""
