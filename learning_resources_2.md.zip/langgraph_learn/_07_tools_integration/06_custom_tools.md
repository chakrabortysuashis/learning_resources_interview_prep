# 06. Creating Custom Tools in LangGraph

## Overview

While LangChain provides many pre-built tools, you'll often need **custom tools** for your specific use case. Custom tools let you integrate your own APIs, databases, business logic, and external services into your LangGraph agents.

```
+------------------------------------------------------------------+
|                      CUSTOM TOOLS                                 |
+------------------------------------------------------------------+
|                                                                   |
|  Your Business Logic       Your APIs         Your Data           |
|  +-----------------+    +-------------+    +---------------+      |
|  | - Calculations  |    | - REST API  |    | - Database    |      |
|  | - Validations   |    | - GraphQL   |    | - Files       |      |
|  | - Transformations|   | - Webhooks  |    | - Cache       |      |
|  +-----------------+    +-------------+    +---------------+      |
|           |                   |                   |               |
|           +-------------------+-------------------+               |
|                               |                                   |
|                               v                                   |
|                    +-------------------+                          |
|                    |   @tool Decorator |                          |
|                    +-------------------+                          |
|                               |                                   |
|                               v                                   |
|                    +-------------------+                          |
|                    |  LangGraph Agent  |                          |
|                    +-------------------+                          |
|                                                                   |
+------------------------------------------------------------------+
```

---

## The @tool Decorator

The `@tool` decorator is the primary way to create custom tools in LangGraph.

### Basic Syntax

```python
from langchain_core.tools import tool

@tool
def my_tool(param1: str, param2: int) -> str:
    """Tool description - THE LLM READS THIS!

    More detailed explanation of when to use this tool.

    Args:
        param1: Description of first parameter
        param2: Description of second parameter

    Returns:
        Description of what the tool returns
    """
    # Your implementation here
    result = do_something(param1, param2)
    return result
```

### Critical Components

```
+------------------------------------------------------------------+
|                  ANATOMY OF A CUSTOM TOOL                         |
+------------------------------------------------------------------+
|                                                                   |
|  @tool  <---------------------- 1. DECORATOR (Required)          |
|  def tool_name(                                                   |
|      param: str,   <----------- 2. TYPE HINTS (Required)         |
|      option: int = 10                                             |
|  ) -> str:         <----------- 3. RETURN TYPE (Recommended)     |
|      """Short description.  <-- 4. DOCSTRING (Critical!)         |
|                                                                   |
|      Detailed explanation.                                        |
|                                                                   |
|      Args:                                                        |
|          param: What this parameter does                          |
|          option: What this option controls                        |
|                                                                   |
|      Returns:                                                     |
|          What the tool returns                                    |
|      """                                                          |
|      # Implementation    <----- 5. LOGIC                         |
|      return "result"                                              |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Creating Different Types of Tools

### Type 1: Simple Tool (No Parameters)

```python
from langchain_core.tools import tool
from datetime import datetime

@tool
def get_current_time() -> str:
    """Get the current date and time.

    Use this when the user asks about the current time or date.

    Returns:
        Current timestamp in ISO format
    """
    return datetime.now().isoformat()
```

### Type 2: Single Parameter Tool

```python
@tool
def get_word_count(text: str) -> int:
    """Count the number of words in a text.

    Use this when you need to count words in a document or message.

    Args:
        text: The text to count words in

    Returns:
        The number of words
    """
    return len(text.split())
```

### Type 3: Multiple Parameters Tool

```python
@tool
def calculate_discount(
    original_price: float,
    discount_percent: float
) -> dict:
    """Calculate the discounted price and savings.

    Use when user asks about discounts, sales, or price reductions.

    Args:
        original_price: The original price in dollars
        discount_percent: The discount percentage (0-100)

    Returns:
        Dictionary with discount_amount, final_price, and savings
    """
    discount_amount = original_price * (discount_percent / 100)
    final_price = original_price - discount_amount

    return {
        "original_price": original_price,
        "discount_percent": discount_percent,
        "discount_amount": round(discount_amount, 2),
        "final_price": round(final_price, 2)
    }
```

### Type 4: Tool with Optional Parameters

```python
@tool
def search_products(
    query: str,
    category: str = "all",
    max_results: int = 10,
    min_price: float = 0.0
) -> list:
    """Search the product catalog.

    Args:
        query: Search keywords
        category: Product category filter (default: all)
        max_results: Maximum results to return (default: 10)
        min_price: Minimum price filter (default: 0)

    Returns:
        List of matching products
    """
    # Search logic here
    return products[:max_results]
```

### Type 5: Async Tool

```python
import aiohttp

@tool
async def fetch_url(url: str) -> str:
    """Fetch content from a URL asynchronously.

    Use this when you need to retrieve data from a web page or API.

    Args:
        url: The URL to fetch

    Returns:
        The content of the page/response
    """
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as response:
            return await response.text()
```

---

## Structured Input with Pydantic

For complex inputs, use Pydantic models:

```python
from langchain_core.tools import tool
from pydantic import BaseModel, Field

class EmailInput(BaseModel):
    """Input schema for sending emails."""

    to: str = Field(
        description="Recipient email address"
    )
    subject: str = Field(
        description="Email subject line"
    )
    body: str = Field(
        description="Email body content"
    )
    cc: list[str] = Field(
        default=[],
        description="CC recipients (optional)"
    )
    priority: str = Field(
        default="normal",
        description="Priority: low, normal, or high"
    )


@tool(args_schema=EmailInput)
def send_email(to: str, subject: str, body: str, cc: list = [], priority: str = "normal") -> str:
    """Send an email to the specified recipient.

    Use this tool when the user wants to send an email.

    Returns:
        Confirmation message with email details
    """
    # Email sending logic
    return f"Email sent to {to} with subject: {subject}"
```

### Benefits of Pydantic Schemas

```
+------------------------------------------------------------------+
|                 PYDANTIC SCHEMA BENEFITS                          |
+------------------------------------------------------------------+
|                                                                   |
|  1. Validation          - Automatic type checking                |
|  2. Documentation       - Field descriptions for LLM             |
|  3. Defaults            - Built-in default values                |
|  4. Constraints         - min/max values, regex patterns         |
|  5. Nested Structures   - Complex object inputs                  |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Tool Design Best Practices

### 1. Single Responsibility

```python
# BAD: Tool does too many things
@tool
def handle_everything(action: str, data: str) -> str:
    """Do many different things based on action."""
    if action == "search":
        return search(data)
    elif action == "update":
        return update(data)
    elif action == "delete":
        return delete(data)

# GOOD: Separate tools for each action
@tool
def search_records(query: str) -> list:
    """Search for records matching the query."""
    return search(query)

@tool
def update_record(record_id: str, data: dict) -> str:
    """Update a specific record."""
    return update(record_id, data)

@tool
def delete_record(record_id: str) -> str:
    """Delete a specific record."""
    return delete(record_id)
```

### 2. Clear Docstrings

```python
# BAD: Vague docstring
@tool
def process(data: str) -> str:
    """Process the data."""
    return result

# GOOD: Detailed docstring
@tool
def analyze_sentiment(text: str) -> dict:
    """Analyze the sentiment of the given text.

    Use this tool when you need to determine if text is positive,
    negative, or neutral. Good for analyzing reviews, feedback,
    or social media posts.

    Args:
        text: The text to analyze (max 5000 characters)

    Returns:
        Dictionary with:
        - sentiment: "positive", "negative", or "neutral"
        - confidence: Float between 0 and 1
        - keywords: List of sentiment-bearing words found

    Example:
        analyze_sentiment("I love this product!")
        -> {"sentiment": "positive", "confidence": 0.95, ...}
    """
    return analyze(text)
```

### 3. Meaningful Return Values

```python
# BAD: Unclear return
@tool
def check_status(id: str) -> bool:
    """Check status."""
    return True  # What does True mean?

# GOOD: Informative return
@tool
def check_order_status(order_id: str) -> dict:
    """Check the status of an order.

    Returns:
        Dictionary with:
        - order_id: The order ID
        - status: "pending", "processing", "shipped", or "delivered"
        - last_updated: Timestamp of last status change
        - estimated_delivery: Expected delivery date (if shipped)
    """
    return {
        "order_id": order_id,
        "status": "shipped",
        "last_updated": "2024-01-15T10:30:00Z",
        "estimated_delivery": "2024-01-18"
    }
```

### 4. Input Validation

```python
@tool
def divide_numbers(numerator: float, denominator: float) -> str:
    """Divide two numbers safely.

    Args:
        numerator: The number to divide
        denominator: The number to divide by (cannot be zero)

    Returns:
        The result of the division
    """
    # Validate input
    if denominator == 0:
        return "Error: Cannot divide by zero"

    result = numerator / denominator
    return f"{numerator} / {denominator} = {result}"
```

---

## Tool Categories and Patterns

### Category 1: Data Retrieval Tools

```python
@tool
def get_user_profile(user_id: str) -> dict:
    """Retrieve a user's profile information.

    Use when you need user details like name, email, or preferences.

    Args:
        user_id: The unique identifier for the user

    Returns:
        User profile dictionary or error message
    """
    user = database.get_user(user_id)
    if not user:
        return {"error": f"User {user_id} not found"}
    return user.to_dict()
```

### Category 2: Action Tools

```python
@tool
def create_calendar_event(
    title: str,
    date: str,
    time: str,
    duration_minutes: int = 60
) -> str:
    """Create a new calendar event.

    Use when the user wants to schedule a meeting or event.

    Args:
        title: Event title
        date: Date in YYYY-MM-DD format
        time: Time in HH:MM format (24-hour)
        duration_minutes: Event duration (default: 60)

    Returns:
        Confirmation with event ID
    """
    event = calendar.create_event(title, date, time, duration_minutes)
    return f"Event created: {event.id} - {title} on {date} at {time}"
```

### Category 3: Computation Tools

```python
import statistics

@tool
def calculate_statistics(numbers: list[float]) -> dict:
    """Calculate statistical measures for a list of numbers.

    Use when you need mean, median, mode, or standard deviation.

    Args:
        numbers: List of numbers to analyze

    Returns:
        Dictionary with statistical measures
    """
    if len(numbers) < 2:
        return {"error": "Need at least 2 numbers"}

    return {
        "count": len(numbers),
        "mean": statistics.mean(numbers),
        "median": statistics.median(numbers),
        "std_dev": statistics.stdev(numbers),
        "min": min(numbers),
        "max": max(numbers)
    }
```

### Category 4: Integration Tools

```python
import requests

@tool
def call_weather_api(city: str, units: str = "metric") -> dict:
    """Get weather data from external API.

    Use when user asks about weather conditions.

    Args:
        city: City name
        units: "metric" (Celsius) or "imperial" (Fahrenheit)

    Returns:
        Weather data dictionary
    """
    api_key = os.getenv("WEATHER_API_KEY")
    response = requests.get(
        f"https://api.weather.com/v1/current",
        params={"city": city, "units": units, "key": api_key}
    )

    if response.status_code != 200:
        return {"error": f"API error: {response.status_code}"}

    return response.json()
```

---

## Advanced Tool Patterns

### Pattern 1: Tool with Retry Logic

```python
import time
from langchain_core.tools import tool

@tool
def robust_api_call(endpoint: str, max_retries: int = 3) -> dict:
    """Call an API with automatic retry on failure.

    Args:
        endpoint: API endpoint to call
        max_retries: Maximum retry attempts (default: 3)

    Returns:
        API response or error message
    """
    for attempt in range(max_retries):
        try:
            response = requests.get(endpoint, timeout=10)
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            if attempt < max_retries - 1:
                time.sleep(2 ** attempt)  # Exponential backoff
                continue
            return {"error": f"Failed after {max_retries} attempts: {str(e)}"}
```

### Pattern 2: Tool with Caching

```python
from functools import lru_cache

# Cache the actual logic
@lru_cache(maxsize=100)
def _expensive_computation(data: str) -> str:
    # Expensive operation
    return result

@tool
def cached_computation(data: str) -> str:
    """Perform expensive computation with caching.

    Results are cached for repeated queries.

    Args:
        data: Input data to process

    Returns:
        Processed result
    """
    return _expensive_computation(data)
```

### Pattern 3: Tool with Context

```python
from langchain_core.tools import tool
from langchain_core.runnables import RunnableConfig

@tool
def user_aware_search(query: str, config: RunnableConfig) -> list:
    """Search with user context awareness.

    Uses the current user's preferences for personalized results.

    Args:
        query: Search query

    Returns:
        Personalized search results
    """
    # Access user ID from config
    user_id = config.get("configurable", {}).get("user_id")

    if user_id:
        preferences = get_user_preferences(user_id)
        return personalized_search(query, preferences)
    else:
        return generic_search(query)
```

---

## Common Mistakes to Avoid

### Mistake 1: Missing Type Hints

```python
# WRONG: No type hints
@tool
def bad_tool(data):
    """Process data."""
    return result

# CORRECT: Type hints included
@tool
def good_tool(data: str) -> str:
    """Process data."""
    return result
```

### Mistake 2: Poor Docstrings

```python
# WRONG: No docstring
@tool
def mystery_tool(x: int) -> int:
    return x * 2

# CORRECT: Clear docstring
@tool
def double_number(x: int) -> int:
    """Double the input number.

    Use when you need to multiply a number by 2.

    Args:
        x: The number to double

    Returns:
        The input number multiplied by 2
    """
    return x * 2
```

### Mistake 3: Not Handling Errors

```python
# WRONG: Crashes on error
@tool
def risky_tool(url: str) -> str:
    """Fetch URL."""
    return requests.get(url).text  # Could crash!

# CORRECT: Error handling
@tool
def safe_tool(url: str) -> str:
    """Fetch URL safely."""
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        return response.text
    except requests.RequestException as e:
        return f"Error fetching {url}: {str(e)}"
```

---

## Interview Tips

### Common Questions

| Question | Key Points |
|----------|------------|
| "How do you create a custom tool?" | @tool decorator, type hints, clear docstring |
| "What makes a good tool docstring?" | Describes when to use, parameters, return values |
| "How do you handle complex inputs?" | Pydantic models with args_schema parameter |
| "How do you test custom tools?" | Unit tests, invoke() directly, mock external APIs |

### Key Points to Remember

1. **Docstrings are critical** - LLM decides tool usage based on them
2. **Type hints are required** - Enable schema generation
3. **Single responsibility** - One tool, one job
4. **Error handling** - Tools should fail gracefully
5. **Return useful data** - Structured, parseable outputs

---

## Summary

```
+------------------------------------------------------------------+
|                        KEY TAKEAWAYS                              |
+------------------------------------------------------------------+
|                                                                   |
|  1. Use @tool decorator to create custom tools                   |
|                                                                   |
|  2. Essential components:                                         |
|     - Type hints for all parameters                              |
|     - Clear, detailed docstring                                  |
|     - Error handling                                             |
|                                                                   |
|  3. For complex inputs, use Pydantic schemas                     |
|     - @tool(args_schema=MyInputSchema)                           |
|                                                                   |
|  4. Best practices:                                               |
|     - Single responsibility                                       |
|     - Validate inputs                                             |
|     - Return structured data                                      |
|     - Handle all error cases                                      |
|                                                                   |
|  5. Async tools for I/O-bound operations                         |
|     - async def with await                                        |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Next Steps

Continue to `07_custom_tools_example.py` for working code examples of custom tools.
