# 04. Using LangChain Tools with LangGraph

## Overview

LangChain provides a rich ecosystem of **pre-built tools** that work seamlessly with LangGraph. Instead of building everything from scratch, you can leverage existing tools for common tasks like web search, Wikipedia lookup, code execution, and more.

```
+------------------------------------------------------------------+
|                   LANGCHAIN TOOL ECOSYSTEM                        |
+------------------------------------------------------------------+
|                                                                   |
|  +-------------+  +-------------+  +-------------+                |
|  | Web Search  |  | Wikipedia   |  | Calculator  |                |
|  | (Tavily,    |  | (Wikipedia  |  | (Python    |                |
|  |  DuckDuckGo)|  |  API)       |  |  numexpr)  |                |
|  +-------------+  +-------------+  +-------------+                |
|                                                                   |
|  +-------------+  +-------------+  +-------------+                |
|  | File Ops    |  | SQL/DB      |  | API Tools   |                |
|  | (Read/Write)|  | (SQLite,    |  | (Requests,  |                |
|  |             |  |  Postgres)  |  |  REST)      |                |
|  +-------------+  +-------------+  +-------------+                |
|                                                                   |
|  +-------------+  +-------------+  +-------------+                |
|  | Code Exec   |  | Shell       |  | Wolfram     |                |
|  | (Python     |  | (Bash       |  | Alpha       |                |
|  |  REPL)      |  |  commands)  |  |             |                |
|  +-------------+  +-------------+  +-------------+                |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Why Use LangChain Tools?

| Benefit | Description |
|---------|-------------|
| **Battle-tested** | Widely used and debugged by the community |
| **Consistent API** | All tools follow the same interface |
| **Easy Integration** | Drop-in compatible with LangGraph agents |
| **Maintained** | Regular updates and improvements |
| **Documentation** | Well-documented with examples |

---

## Categories of LangChain Tools

### 1. Search Tools

```
+------------------------------------------------------------------+
|                        SEARCH TOOLS                               |
+------------------------------------------------------------------+
|                                                                   |
|  Tool              |  Description           |  Requires          |
|  ------------------|------------------------|-------------------  |
|  TavilySearch      |  AI-optimized search   |  TAVILY_API_KEY    |
|  DuckDuckGoSearch  |  Privacy-focused       |  None              |
|  GoogleSearch      |  Google Custom Search  |  API Key           |
|  BingSearch        |  Microsoft Bing        |  API Key           |
|  WikipediaQuery    |  Wikipedia articles    |  None              |
|  ArxivQuery        |  Academic papers       |  None              |
|                                                                   |
+------------------------------------------------------------------+
```

### 2. Computation Tools

```
+------------------------------------------------------------------+
|                     COMPUTATION TOOLS                             |
+------------------------------------------------------------------+
|                                                                   |
|  Tool              |  Description           |  Use Case          |
|  ------------------|------------------------|-------------------  |
|  Calculator        |  Math expressions      |  Basic math        |
|  PythonREPL        |  Execute Python code   |  Complex calc      |
|  WolframAlpha      |  Computational engine  |  Scientific        |
|  NumExpr           |  Fast math evaluation  |  Performance       |
|                                                                   |
+------------------------------------------------------------------+
```

### 3. Data & File Tools

```
+------------------------------------------------------------------+
|                     DATA & FILE TOOLS                             |
+------------------------------------------------------------------+
|                                                                   |
|  Tool              |  Description           |  Use Case          |
|  ------------------|------------------------|-------------------  |
|  ReadFile          |  Read file contents    |  File analysis     |
|  WriteFile         |  Create/update files   |  File generation   |
|  ListDirectory     |  List directory files  |  File exploration  |
|  SQLDatabase       |  Query SQL databases   |  Data retrieval    |
|  JSONQuery         |  Query JSON data       |  API responses     |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Installing LangChain Tools

### Core Package

```bash
pip install langchain-core langchain-community
```

### Tool-Specific Packages

```bash
# For Tavily Search
pip install langchain-community tavily-python

# For Wikipedia
pip install langchain-community wikipedia

# For DuckDuckGo
pip install langchain-community duckduckgo-search

# For Python REPL
pip install langchain-experimental
```

---

## Using LangChain Tools

### Pattern 1: Direct Import and Use

```python
from langchain_community.tools import WikipediaQueryRun
from langchain_community.utilities import WikipediaAPIWrapper

# Create tool instance
wiki = WikipediaQueryRun(api_wrapper=WikipediaAPIWrapper())

# Use directly
result = wiki.run("Python programming language")
print(result)
```

### Pattern 2: With LangGraph Agent

```python
from langgraph.prebuilt import create_react_agent
from langchain_community.tools import WikipediaQueryRun
from langchain_community.utilities import WikipediaAPIWrapper
from langchain_openai import ChatOpenAI

# Create tools
wiki = WikipediaQueryRun(api_wrapper=WikipediaAPIWrapper())

# Create agent with tool
agent = create_react_agent(
    model=ChatOpenAI(model="gpt-4o"),
    tools=[wiki]
)

# Run agent
result = agent.invoke({
    "messages": [("user", "Tell me about the history of Python")]
})
```

---

## Popular LangChain Tools Deep Dive

### 1. Tavily Search (Recommended for AI)

Tavily is specifically designed for AI applications:

```python
from langchain_community.tools.tavily_search import TavilySearchResults

# Initialize (requires TAVILY_API_KEY env var)
search = TavilySearchResults(max_results=5)

# Search
results = search.invoke("latest developments in AI 2024")
```

**Why Tavily?**
- Optimized for AI/LLM consumption
- Returns structured results
- Includes relevance scoring
- Fast response times

### 2. Wikipedia

```python
from langchain_community.tools import WikipediaQueryRun
from langchain_community.utilities import WikipediaAPIWrapper

# Configure wrapper
api_wrapper = WikipediaAPIWrapper(
    top_k_results=3,      # Number of results
    doc_content_chars_max=4000  # Max chars per result
)

# Create tool
wiki = WikipediaQueryRun(api_wrapper=api_wrapper)

# Query
result = wiki.run("Machine Learning")
```

### 3. DuckDuckGo Search

```python
from langchain_community.tools import DuckDuckGoSearchRun

# Create tool (no API key needed!)
search = DuckDuckGoSearchRun()

# Search
result = search.run("best practices for Python programming")
```

### 4. Python REPL

```python
from langchain_experimental.tools import PythonREPLTool

# Create tool
python_repl = PythonREPLTool()

# Execute code
result = python_repl.run("""
import math
radius = 5
area = math.pi * radius ** 2
print(f"Area: {area:.2f}")
""")
```

**Warning**: PythonREPL executes arbitrary code. Use with caution!

### 5. Shell Tool

```python
from langchain_community.tools import ShellTool

# Create tool
shell = ShellTool()

# Execute command
result = shell.run({"commands": ["ls -la", "pwd"]})
```

**Warning**: Shell access is powerful but dangerous. Restrict in production!

---

## Tool Combinations

### Research Agent (Multiple Search Tools)

```
+------------------------------------------------------------------+
|                     RESEARCH AGENT TOOLS                          |
+------------------------------------------------------------------+
|                                                                   |
|     User Query                                                    |
|         |                                                         |
|         v                                                         |
|  +-------------+                                                  |
|  |    LLM      |                                                  |
|  +------+------+                                                  |
|         |                                                         |
|         +----> Tavily (Current Events)                           |
|         |                                                         |
|         +----> Wikipedia (Background)                            |
|         |                                                         |
|         +----> Arxiv (Academic)                                  |
|         |                                                         |
|         v                                                         |
|  +-------------+                                                  |
|  |  Synthesize |                                                  |
|  |   Answer    |                                                  |
|  +-------------+                                                  |
|                                                                   |
+------------------------------------------------------------------+
```

```python
from langchain_community.tools.tavily_search import TavilySearchResults
from langchain_community.tools import WikipediaQueryRun, ArxivQueryRun
from langchain_community.utilities import WikipediaAPIWrapper, ArxivAPIWrapper

# Create multiple tools
tavily = TavilySearchResults(max_results=3)
wiki = WikipediaQueryRun(api_wrapper=WikipediaAPIWrapper())
arxiv = ArxivQueryRun(api_wrapper=ArxivAPIWrapper())

# Combine for research agent
research_tools = [tavily, wiki, arxiv]
```

### Data Analysis Agent

```python
from langchain_experimental.tools import PythonREPLTool
from langchain_community.tools import ReadFileTool

# Tools for data analysis
python_repl = PythonREPLTool()
file_reader = ReadFileTool()

# Analysis agent can read files and run Python for analysis
analysis_tools = [python_repl, file_reader]
```

---

## Tool Configuration Options

### Common Configuration Patterns

```python
# Pattern 1: Max results
search = TavilySearchResults(max_results=5)

# Pattern 2: Response format
wiki = WikipediaQueryRun(
    api_wrapper=WikipediaAPIWrapper(
        top_k_results=3,
        doc_content_chars_max=1000
    )
)

# Pattern 3: Custom name and description
from langchain_core.tools import Tool

custom_search = Tool(
    name="research_search",
    description="Search for research papers and academic content",
    func=search.run
)
```

### Async Tools

```python
from langchain_community.tools.tavily_search import TavilySearchResults

search = TavilySearchResults()

# Async invocation
result = await search.ainvoke("AI developments 2024")
```

---

## Creating Agents with LangChain Tools

### Basic Pattern

```python
from langgraph.prebuilt import create_react_agent
from langchain_openai import ChatOpenAI
from langchain_community.tools.tavily_search import TavilySearchResults
from langchain_community.tools import WikipediaQueryRun
from langchain_community.utilities import WikipediaAPIWrapper

# 1. Create tools
tools = [
    TavilySearchResults(max_results=3),
    WikipediaQueryRun(api_wrapper=WikipediaAPIWrapper())
]

# 2. Create model
model = ChatOpenAI(model="gpt-4o")

# 3. Create agent
agent = create_react_agent(model, tools)

# 4. Run
result = agent.invoke({
    "messages": [("user", "What is quantum computing and who are the key researchers?")]
})
```

### Agent Execution Flow

```
+------------------------------------------------------------------+
|                     AGENT EXECUTION FLOW                          |
+------------------------------------------------------------------+
|                                                                   |
|  User: "What is quantum computing?"                              |
|                      |                                            |
|                      v                                            |
|  +-------------------+-------------------+                        |
|  |           LLM Reasoning               |                        |
|  | "I should search Wikipedia for        |                        |
|  |  background on quantum computing"     |                        |
|  +-------------------+-------------------+                        |
|                      |                                            |
|                      v                                            |
|  +-------------------+-------------------+                        |
|  |         Tool: Wikipedia               |                        |
|  | query: "quantum computing"            |                        |
|  +-------------------+-------------------+                        |
|                      |                                            |
|                      v                                            |
|  +-------------------+-------------------+                        |
|  |           Tool Result                 |                        |
|  | "Quantum computing is a type of..."   |                        |
|  +-------------------+-------------------+                        |
|                      |                                            |
|                      v                                            |
|  +-------------------+-------------------+                        |
|  |       LLM Final Response              |                        |
|  | "Quantum computing is a revolutionary |                        |
|  |  approach to computation that..."     |                        |
|  +-------------------+-------------------+                        |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Best Practices

### 1. Choose the Right Tool

| Task | Recommended Tool |
|------|-----------------|
| Current events | Tavily, DuckDuckGo |
| Background knowledge | Wikipedia |
| Academic research | Arxiv |
| Calculations | PythonREPL, Calculator |
| File operations | ReadFile, WriteFile |

### 2. Limit Results

```python
# Don't retrieve too much data
search = TavilySearchResults(max_results=3)  # Not 100!
wiki = WikipediaQueryRun(
    api_wrapper=WikipediaAPIWrapper(
        doc_content_chars_max=2000  # Limit content
    )
)
```

### 3. Handle Tool Failures

```python
from langchain_core.tools import ToolException

try:
    result = search.invoke(query)
except ToolException as e:
    result = f"Search failed: {e}"
```

### 4. Use Descriptions Wisely

```python
# Wrap with custom description if needed
from langchain_core.tools import Tool

better_search = Tool(
    name="web_search",
    description="""Search the web for current information.
    Use when you need up-to-date facts, news, or data.
    Returns top 3 relevant results with snippets.""",
    func=search.run
)
```

---

## Interview Tips

### Common Questions

| Question | Key Points |
|----------|------------|
| "What LangChain tools have you used?" | Mention Tavily, Wikipedia, PythonREPL; explain use cases |
| "Why use LangChain tools vs custom?" | Pre-built, tested, maintained, consistent API |
| "How do you handle tool failures?" | Try-except, fallback tools, graceful degradation |
| "Security concerns with tools?" | Code execution risks, input validation, sandboxing |

### Key Points to Remember

1. **LangChain has tools for most common needs** - Don't reinvent the wheel
2. **Tavily is AI-optimized** - Better for LLM applications than generic search
3. **Code execution tools need sandboxing** - Never run in production without safety
4. **Tools can be combined** - Create powerful multi-tool agents

---

## Security Considerations

```
+------------------------------------------------------------------+
|                    SECURITY WARNING                               |
+------------------------------------------------------------------+
|                                                                   |
|  HIGH RISK TOOLS (Require Sandboxing):                           |
|  - PythonREPL: Can execute arbitrary code                        |
|  - ShellTool: Full system access                                 |
|  - WriteFile: Can overwrite system files                         |
|                                                                   |
|  MEDIUM RISK TOOLS:                                               |
|  - ReadFile: Can read sensitive files                            |
|  - SQLDatabase: Potential SQL injection                          |
|                                                                   |
|  LOWER RISK TOOLS:                                                |
|  - Search tools: Generally safe                                  |
|  - Wikipedia: Read-only                                          |
|  - Calculator: Limited scope                                     |
|                                                                   |
|  ALWAYS:                                                          |
|  - Validate inputs                                               |
|  - Limit tool permissions                                        |
|  - Use sandboxed environments for code execution                 |
|  - Log tool usage                                                |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Summary

```
+------------------------------------------------------------------+
|                        KEY TAKEAWAYS                              |
+------------------------------------------------------------------+
|                                                                   |
|  1. LangChain provides pre-built tools for common tasks          |
|     - Search: Tavily, DuckDuckGo, Wikipedia                      |
|     - Compute: PythonREPL, Calculator                            |
|     - Data: ReadFile, SQLDatabase                                |
|                                                                   |
|  2. Tools follow a consistent interface                          |
|     - tool.run(input) or tool.invoke(input)                      |
|     - Async: await tool.ainvoke(input)                           |
|                                                                   |
|  3. Easy integration with LangGraph agents                       |
|     - create_react_agent(model, tools)                           |
|     - ToolNode(tools) for custom graphs                          |
|                                                                   |
|  4. Security matters - sandbox code execution tools              |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Next Steps

Continue to `05_langchain_tools_example.py` to see these tools in action with working code.
