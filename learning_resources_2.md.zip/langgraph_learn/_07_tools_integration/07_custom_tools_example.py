"""
============================================================================
07. Custom Tools Example - Creating Your Own Tools for LangGraph
============================================================================

This file demonstrates how to create custom tools for LangGraph agents.
We'll cover:
- Basic @tool decorator usage
- Different parameter types
- Pydantic schemas for complex inputs
- Async tools
- Tools with validation and error handling
- Real-world tool patterns

Prerequisites:
    pip install langchain-core langchain-openai langgraph pydantic

Environment Variables:
    OPENAI_API_KEY=your-key-here
"""

# ============================================================================
# IMPORTS
# ============================================================================

import os
import json
import asyncio
from datetime import datetime, timedelta
from typing import TypedDict, Annotated, Optional
from dotenv import load_dotenv

from langchain_core.tools import tool
from langchain_core.messages import HumanMessage, AIMessage
from langchain_openai import ChatOpenAI

from pydantic import BaseModel, Field, field_validator

from langgraph.prebuilt import create_react_agent
from langgraph.graph import StateGraph, END
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode

# Load environment variables
load_dotenv()

print("=" * 70)
print("CUSTOM TOOLS EXAMPLES - LangGraph")
print("=" * 70)


# ============================================================================
# SECTION 1: BASIC TOOLS WITH @tool DECORATOR
# ============================================================================
"""
The @tool decorator is the simplest way to create tools.
Key requirements:
- Type hints for parameters
- Docstring (LLM reads this!)
"""

print("\n" + "-" * 70)
print("Section 1: Basic Tools with @tool Decorator")
print("-" * 70)


# Tool 1: No parameters
@tool
def get_current_time() -> str:
    """Get the current date and time.

    Use this tool when the user asks what time or date it is.

    Returns:
        Current timestamp in a human-readable format
    """
    now = datetime.now()
    return now.strftime("%A, %B %d, %Y at %I:%M %p")


# Tool 2: Single parameter
@tool
def reverse_string(text: str) -> str:
    """Reverse a string.

    Use this when the user wants to reverse text or see text backwards.

    Args:
        text: The text to reverse

    Returns:
        The reversed text
    """
    return text[::-1]


# Tool 3: Multiple parameters
@tool
def calculate_tip(
    bill_amount: float,
    tip_percentage: float,
    split_ways: int = 1
) -> dict:
    """Calculate tip amount and split the bill.

    Use when the user wants to calculate a tip at a restaurant or split a bill.

    Args:
        bill_amount: The total bill amount in dollars
        tip_percentage: The tip percentage (e.g., 15, 18, 20)
        split_ways: Number of people to split between (default: 1)

    Returns:
        Dictionary with tip amount, total, and per-person amount
    """
    tip_amount = bill_amount * (tip_percentage / 100)
    total = bill_amount + tip_amount
    per_person = total / split_ways

    return {
        "bill_amount": round(bill_amount, 2),
        "tip_percentage": tip_percentage,
        "tip_amount": round(tip_amount, 2),
        "total": round(total, 2),
        "split_ways": split_ways,
        "per_person": round(per_person, 2)
    }


def demo_basic_tools():
    """Demonstrate basic tool usage."""

    print("\n[*] Basic Tools Demo")

    # Test Tool 1: No parameters
    print("\n    Tool 1: get_current_time()")
    result = get_current_time.invoke({})
    print(f"    Result: {result}")

    # Test Tool 2: Single parameter
    print("\n    Tool 2: reverse_string('Hello World')")
    result = reverse_string.invoke("Hello World")
    print(f"    Result: {result}")

    # Test Tool 3: Multiple parameters
    print("\n    Tool 3: calculate_tip(85.50, 18, 3)")
    result = calculate_tip.invoke({
        "bill_amount": 85.50,
        "tip_percentage": 18,
        "split_ways": 3
    })
    print(f"    Result: {json.dumps(result, indent=6)}")

# Uncomment to run:
# demo_basic_tools()


# ============================================================================
# SECTION 2: TOOLS WITH PYDANTIC SCHEMAS
# ============================================================================
"""
For complex inputs, use Pydantic models.
This provides:
- Input validation
- Better documentation
- Default values
- Field descriptions
"""

print("\n" + "-" * 70)
print("Section 2: Tools with Pydantic Schemas")
print("-" * 70)


# Define Pydantic input schema
class TaskInput(BaseModel):
    """Input schema for creating a task."""

    title: str = Field(
        description="The title of the task"
    )
    description: str = Field(
        default="",
        description="Detailed description of the task"
    )
    priority: str = Field(
        default="medium",
        description="Priority level: low, medium, or high"
    )
    due_date: Optional[str] = Field(
        default=None,
        description="Due date in YYYY-MM-DD format"
    )
    tags: list[str] = Field(
        default=[],
        description="List of tags for the task"
    )

    @field_validator("priority")
    @classmethod
    def validate_priority(cls, v):
        """Ensure priority is valid."""
        valid = ["low", "medium", "high"]
        if v.lower() not in valid:
            raise ValueError(f"Priority must be one of: {valid}")
        return v.lower()


# In-memory task storage for demo
TASKS = []


@tool(args_schema=TaskInput)
def create_task(
    title: str,
    description: str = "",
    priority: str = "medium",
    due_date: str = None,
    tags: list = []
) -> dict:
    """Create a new task in the task management system.

    Use this tool when the user wants to create, add, or schedule a new task.

    Returns:
        The created task with its ID
    """
    task = {
        "id": len(TASKS) + 1,
        "title": title,
        "description": description,
        "priority": priority,
        "due_date": due_date,
        "tags": tags,
        "created_at": datetime.now().isoformat(),
        "status": "pending"
    }
    TASKS.append(task)
    return task


@tool
def list_tasks(status: str = "all") -> list:
    """List all tasks, optionally filtered by status.

    Use when user wants to see their tasks or check task status.

    Args:
        status: Filter by status - "all", "pending", or "completed"

    Returns:
        List of tasks matching the filter
    """
    if status == "all":
        return TASKS
    return [t for t in TASKS if t["status"] == status]


class FlightSearchInput(BaseModel):
    """Input schema for flight search."""

    origin: str = Field(
        description="Origin airport code (e.g., JFK, LAX)"
    )
    destination: str = Field(
        description="Destination airport code (e.g., LHR, CDG)"
    )
    departure_date: str = Field(
        description="Departure date in YYYY-MM-DD format"
    )
    return_date: Optional[str] = Field(
        default=None,
        description="Return date for round trip (optional)"
    )
    passengers: int = Field(
        default=1,
        description="Number of passengers"
    )
    cabin_class: str = Field(
        default="economy",
        description="Cabin class: economy, business, or first"
    )


@tool(args_schema=FlightSearchInput)
def search_flights(
    origin: str,
    destination: str,
    departure_date: str,
    return_date: str = None,
    passengers: int = 1,
    cabin_class: str = "economy"
) -> list:
    """Search for available flights.

    Use when user wants to find flights between two cities.

    Returns:
        List of available flight options
    """
    # Simulated flight data
    flights = [
        {
            "flight_number": "AA123",
            "origin": origin.upper(),
            "destination": destination.upper(),
            "departure": f"{departure_date}T08:00:00",
            "arrival": f"{departure_date}T12:30:00",
            "price_per_person": 450 if cabin_class == "economy" else 1200,
            "cabin_class": cabin_class,
            "available_seats": 15
        },
        {
            "flight_number": "UA456",
            "origin": origin.upper(),
            "destination": destination.upper(),
            "departure": f"{departure_date}T14:30:00",
            "arrival": f"{departure_date}T19:00:00",
            "price_per_person": 380 if cabin_class == "economy" else 1050,
            "cabin_class": cabin_class,
            "available_seats": 8
        }
    ]

    # Add passenger count and total
    for flight in flights:
        flight["passengers"] = passengers
        flight["total_price"] = flight["price_per_person"] * passengers

    return flights


def demo_pydantic_tools():
    """Demonstrate tools with Pydantic schemas."""

    print("\n[*] Pydantic Schema Tools Demo")

    # Create a task
    print("\n    Creating a task...")
    task = create_task.invoke({
        "title": "Review PR #123",
        "description": "Review and approve the pull request",
        "priority": "high",
        "due_date": "2024-02-01",
        "tags": ["code-review", "urgent"]
    })
    print(f"    Created: {json.dumps(task, indent=6)}")

    # List tasks
    print("\n    Listing all tasks...")
    tasks = list_tasks.invoke("all")
    print(f"    Found {len(tasks)} task(s)")

    # Search flights
    print("\n    Searching flights...")
    flights = search_flights.invoke({
        "origin": "JFK",
        "destination": "LHR",
        "departure_date": "2024-03-15",
        "passengers": 2,
        "cabin_class": "business"
    })
    print(f"    Found {len(flights)} flight(s)")
    for f in flights:
        print(f"      - {f['flight_number']}: ${f['total_price']} total")

# Uncomment to run:
# demo_pydantic_tools()


# ============================================================================
# SECTION 3: ASYNC TOOLS
# ============================================================================
"""
Use async tools for I/O-bound operations:
- API calls
- Database queries
- File operations
- Network requests
"""

print("\n" + "-" * 70)
print("Section 3: Async Tools")
print("-" * 70)


@tool
async def async_fetch_weather(city: str) -> dict:
    """Fetch weather data asynchronously (simulated).

    Use when user asks about weather conditions.

    Args:
        city: Name of the city

    Returns:
        Weather data including temperature and conditions
    """
    # Simulate async API call
    await asyncio.sleep(0.5)  # Simulated network delay

    # Simulated weather data
    import random
    weather = {
        "city": city,
        "temperature_f": random.randint(32, 95),
        "conditions": random.choice(["Sunny", "Cloudy", "Rainy", "Partly Cloudy"]),
        "humidity": random.randint(30, 90),
        "wind_mph": random.randint(0, 30),
        "timestamp": datetime.now().isoformat()
    }
    weather["temperature_c"] = round((weather["temperature_f"] - 32) * 5/9, 1)

    return weather


@tool
async def async_check_multiple_services(services: list[str]) -> dict:
    """Check status of multiple services concurrently.

    Use to check if services/APIs are online.

    Args:
        services: List of service names to check

    Returns:
        Status of each service
    """
    async def check_service(name: str) -> tuple:
        # Simulate async service check
        await asyncio.sleep(0.3)
        import random
        status = random.choice(["online", "online", "online", "degraded"])
        return name, status

    # Check all services concurrently
    tasks = [check_service(s) for s in services]
    results = await asyncio.gather(*tasks)

    return {
        "checked_at": datetime.now().isoformat(),
        "services": dict(results),
        "all_online": all(s == "online" for _, s in results)
    }


def demo_async_tools():
    """Demonstrate async tool usage."""

    print("\n[*] Async Tools Demo")

    # Run async tools
    async def run_demos():
        # Async weather fetch
        print("\n    Fetching weather for Tokyo...")
        weather = await async_fetch_weather.ainvoke("Tokyo")
        print(f"    Result: {weather['temperature_f']}F, {weather['conditions']}")

        # Check multiple services
        print("\n    Checking service status...")
        services = ["api-gateway", "database", "cache", "auth-service"]
        status = await async_check_multiple_services.ainvoke(services)
        print(f"    Services checked: {len(status['services'])}")
        print(f"    All online: {status['all_online']}")

    asyncio.run(run_demos())

# Uncomment to run:
# demo_async_tools()


# ============================================================================
# SECTION 4: TOOLS WITH VALIDATION AND ERROR HANDLING
# ============================================================================
"""
Production tools need robust validation and error handling.
"""

print("\n" + "-" * 70)
print("Section 4: Validation and Error Handling")
print("-" * 70)


@tool
def safe_divide(numerator: float, denominator: float) -> str:
    """Safely divide two numbers with error handling.

    Use for any division calculation.

    Args:
        numerator: The number to divide
        denominator: The number to divide by

    Returns:
        Result of division or error message
    """
    # Validate denominator
    if denominator == 0:
        return "Error: Cannot divide by zero. Please provide a non-zero denominator."

    result = numerator / denominator
    return f"{numerator} / {denominator} = {result}"


@tool
def validate_email(email: str) -> dict:
    """Validate an email address format.

    Use when you need to check if an email address is valid.

    Args:
        email: The email address to validate

    Returns:
        Validation result with details
    """
    import re

    result = {
        "email": email,
        "is_valid": False,
        "issues": []
    }

    # Check basic format
    email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'

    if not email:
        result["issues"].append("Email is empty")
    elif len(email) > 254:
        result["issues"].append("Email exceeds maximum length (254 chars)")
    elif not re.match(email_pattern, email):
        result["issues"].append("Invalid email format")
    else:
        result["is_valid"] = True

    return result


@tool
def robust_json_parse(json_string: str) -> dict:
    """Parse a JSON string with comprehensive error handling.

    Use when you need to parse JSON data safely.

    Args:
        json_string: A string containing JSON data

    Returns:
        Parsed JSON or error information
    """
    try:
        # Attempt to parse
        data = json.loads(json_string)
        return {
            "success": True,
            "data": data,
            "type": type(data).__name__
        }
    except json.JSONDecodeError as e:
        return {
            "success": False,
            "error": "Invalid JSON",
            "details": str(e),
            "position": e.pos,
            "line": e.lineno
        }
    except Exception as e:
        return {
            "success": False,
            "error": "Unexpected error",
            "details": str(e)
        }


def demo_validation_tools():
    """Demonstrate validation and error handling."""

    print("\n[*] Validation and Error Handling Demo")

    # Safe division
    print("\n    Testing safe_divide...")
    print(f"      10 / 2: {safe_divide.invoke({'numerator': 10, 'denominator': 2})}")
    print(f"      10 / 0: {safe_divide.invoke({'numerator': 10, 'denominator': 0})}")

    # Email validation
    print("\n    Testing validate_email...")
    emails = ["user@example.com", "invalid-email", "", "test@.com"]
    for email in emails:
        result = validate_email.invoke(email)
        status = "Valid" if result["is_valid"] else "Invalid"
        print(f"      '{email}': {status}")

    # JSON parsing
    print("\n    Testing robust_json_parse...")
    valid_json = '{"name": "John", "age": 30}'
    invalid_json = '{"name": "John", age: 30}'  # Missing quotes
    print(f"      Valid JSON: {robust_json_parse.invoke(valid_json)['success']}")
    print(f"      Invalid JSON: {robust_json_parse.invoke(invalid_json)['success']}")

# Uncomment to run:
# demo_validation_tools()


# ============================================================================
# SECTION 5: REAL-WORLD TOOL PATTERNS
# ============================================================================
"""
Common patterns for production tools.
"""

print("\n" + "-" * 70)
print("Section 5: Real-World Tool Patterns")
print("-" * 70)


# Pattern 1: Database-style CRUD operations
class UserDatabase:
    """Simulated user database."""

    def __init__(self):
        self.users = {}
        self.next_id = 1

    def create(self, name: str, email: str) -> dict:
        user = {"id": self.next_id, "name": name, "email": email}
        self.users[self.next_id] = user
        self.next_id += 1
        return user

    def read(self, user_id: int) -> Optional[dict]:
        return self.users.get(user_id)

    def update(self, user_id: int, **kwargs) -> Optional[dict]:
        if user_id in self.users:
            self.users[user_id].update(kwargs)
            return self.users[user_id]
        return None

    def delete(self, user_id: int) -> bool:
        if user_id in self.users:
            del self.users[user_id]
            return True
        return False


db = UserDatabase()


@tool
def create_user(name: str, email: str) -> dict:
    """Create a new user in the database.

    Args:
        name: User's full name
        email: User's email address

    Returns:
        Created user record with ID
    """
    return db.create(name, email)


@tool
def get_user(user_id: int) -> dict:
    """Retrieve a user by ID.

    Args:
        user_id: The user's ID

    Returns:
        User record or error message
    """
    user = db.read(user_id)
    if user:
        return user
    return {"error": f"User {user_id} not found"}


@tool
def update_user(user_id: int, name: str = None, email: str = None) -> dict:
    """Update a user's information.

    Args:
        user_id: The user's ID
        name: New name (optional)
        email: New email (optional)

    Returns:
        Updated user record or error message
    """
    updates = {}
    if name:
        updates["name"] = name
    if email:
        updates["email"] = email

    if not updates:
        return {"error": "No updates provided"}

    user = db.update(user_id, **updates)
    if user:
        return user
    return {"error": f"User {user_id} not found"}


# Pattern 2: Tool with rate limiting simulation
class RateLimiter:
    """Simple rate limiter."""

    def __init__(self, max_calls: int, period_seconds: int):
        self.max_calls = max_calls
        self.period = period_seconds
        self.calls = []

    def can_call(self) -> bool:
        now = datetime.now()
        cutoff = now - timedelta(seconds=self.period)
        self.calls = [c for c in self.calls if c > cutoff]
        return len(self.calls) < self.max_calls

    def record_call(self):
        self.calls.append(datetime.now())


api_limiter = RateLimiter(max_calls=5, period_seconds=60)


@tool
def rate_limited_api_call(endpoint: str) -> dict:
    """Make a rate-limited API call.

    This tool has a rate limit of 5 calls per minute.

    Args:
        endpoint: API endpoint to call

    Returns:
        API response or rate limit error
    """
    if not api_limiter.can_call():
        return {
            "error": "Rate limit exceeded",
            "message": "Please wait before making more requests",
            "retry_after_seconds": 60
        }

    api_limiter.record_call()

    # Simulated API response
    return {
        "success": True,
        "endpoint": endpoint,
        "data": {"message": "API call successful"},
        "timestamp": datetime.now().isoformat()
    }


def demo_real_world_tools():
    """Demonstrate real-world tool patterns."""

    print("\n[*] Real-World Tool Patterns Demo")

    # CRUD operations
    print("\n    CRUD Operations:")

    # Create
    user = create_user.invoke({"name": "Alice Smith", "email": "alice@example.com"})
    print(f"    Created: {user}")

    # Read
    retrieved = get_user.invoke(user["id"])
    print(f"    Retrieved: {retrieved}")

    # Update
    updated = update_user.invoke({"user_id": user["id"], "email": "alice.smith@example.com"})
    print(f"    Updated: {updated}")

    # Rate limiting
    print("\n    Rate Limiting:")
    for i in range(7):
        result = rate_limited_api_call.invoke("/api/data")
        status = "Success" if result.get("success") else "Rate Limited"
        print(f"    Call {i+1}: {status}")

# Uncomment to run:
# demo_real_world_tools()


# ============================================================================
# SECTION 6: USING CUSTOM TOOLS WITH LANGGRAPH AGENT
# ============================================================================
"""
Combine all our custom tools into a LangGraph agent.
"""

print("\n" + "-" * 70)
print("Section 6: Custom Tools with LangGraph Agent")
print("-" * 70)


def create_custom_tools_agent():
    """Create an agent with our custom tools."""

    # Collect tools
    tools = [
        get_current_time,
        reverse_string,
        calculate_tip,
        create_task,
        list_tasks,
        safe_divide,
        validate_email,
        robust_json_parse
    ]

    # Create LLM
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)

    # Create agent
    agent = create_react_agent(llm, tools)

    return agent


def demo_custom_tools_agent():
    """Demonstrate the custom tools agent."""

    print("\n[*] Custom Tools Agent Demo")

    if not os.getenv("OPENAI_API_KEY"):
        print("    [!] OPENAI_API_KEY not set. Skipping demo.")
        return

    agent = create_custom_tools_agent()

    # Test queries
    test_queries = [
        "What time is it right now?",
        "Reverse the text 'LangGraph is awesome'",
        "I have a $120 bill and want to tip 20%. Split it 4 ways.",
        "Create a task called 'Learn LangGraph' with high priority",
        "Is the email 'john@company.com' valid?",
        "What is 100 divided by 4?"
    ]

    for query in test_queries:
        print(f"\n    Query: '{query}'")
        print("    " + "-" * 50)

        result = agent.invoke({
            "messages": [HumanMessage(content=query)]
        })

        # Show tool usage
        for msg in result["messages"]:
            if isinstance(msg, AIMessage) and msg.tool_calls:
                for tc in msg.tool_calls:
                    print(f"    [Tool] {tc['name']}")

        # Final response
        final = result["messages"][-1]
        response = final.content[:200] + "..." if len(final.content) > 200 else final.content
        print(f"    [Response] {response}")

# Uncomment to run:
# demo_custom_tools_agent()


# ============================================================================
# SECTION 7: MAIN RUNNER
# ============================================================================

def main():
    """Run all demonstrations."""

    print("\n" + "=" * 70)
    print("RUNNING CUSTOM TOOLS DEMONSTRATIONS")
    print("=" * 70)

    print("\n[1] Basic Tools")
    demo_basic_tools()

    print("\n[2] Pydantic Schema Tools")
    demo_pydantic_tools()

    print("\n[3] Async Tools")
    demo_async_tools()

    print("\n[4] Validation and Error Handling")
    demo_validation_tools()

    print("\n[5] Real-World Patterns")
    demo_real_world_tools()

    # LLM-based demos
    if os.getenv("OPENAI_API_KEY"):
        print("\n[6] LangGraph Agent with Custom Tools")
        demo_custom_tools_agent()
    else:
        print("\n[!] Skipping LLM demos (no OPENAI_API_KEY)")

    print("\n" + "=" * 70)
    print("DEMONSTRATIONS COMPLETE")
    print("=" * 70)


if __name__ == "__main__":
    main()


# ============================================================================
# INTERVIEW TIP BOX
# ============================================================================
"""
+--------------------------------------------------------------------------+
|                           INTERVIEW TIP                                   |
+--------------------------------------------------------------------------+
|                                                                          |
|  Q: "How do you design custom tools for LangGraph agents?"              |
|                                                                          |
|  A: "I follow several key principles when designing custom tools:        |
|                                                                          |
|      1. Clear Docstrings: The LLM reads the docstring to decide when    |
|         to use the tool, so I make it descriptive and specific about    |
|         when to use it.                                                  |
|                                                                          |
|      2. Type Hints: Required for schema generation. I always include    |
|         type hints for parameters and return values.                     |
|                                                                          |
|      3. Pydantic Schemas: For complex inputs, I use Pydantic models     |
|         with the args_schema parameter. This provides validation,        |
|         default values, and better documentation.                        |
|                                                                          |
|      4. Error Handling: Tools should fail gracefully and return         |
|         informative error messages rather than crashing.                 |
|                                                                          |
|      5. Single Responsibility: Each tool does one thing well rather     |
|         than trying to handle multiple actions.                          |
|                                                                          |
|      6. Async for I/O: For network calls or database queries, I use     |
|         async tools to avoid blocking."                                  |
|                                                                          |
+--------------------------------------------------------------------------+
"""
