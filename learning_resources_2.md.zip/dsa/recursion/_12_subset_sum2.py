"""Given an integer array nums that may contain duplicates, return all possible subsets (the power set).

The solution set must not contain duplicate subsets. Return the solution in any order.

Example 1:
Input: nums = [1,2,2]
Output: [[],[1],[1,2],[1,2,2],[2],[2,2]]

Example 2:
Input: nums = [0]
Output: [[],[0]]
"""

# =============================================================================
#                         SUBSETS II (LeetCode 90)
#                   Handling Duplicates in Subset Generation
# =============================================================================

"""
================================================================================
SECTION 1: PROBLEM UNDERSTANDING
================================================================================

What is this problem?
---------------------
This is "Subsets I" but with a TWIST: the input array may contain DUPLICATES.

In Subsets I:
    Input:  [1, 2, 3]  (all distinct)
    Output: All 2^3 = 8 subsets

In Subsets II:
    Input:  [1, 2, 2]  (contains duplicate 2s)
    Output: Only UNIQUE subsets (no duplicates allowed in output)

The Challenge:
--------------
For input [1, 2, 2]:
    - Naive approach would generate [2] TWICE (once for each '2')
    - We need EXACTLY ONE of each unique subset

Expected Output for [1, 2, 2]:
    [], [1], [2], [1,2], [2,2], [1,2,2]

    Total: 6 unique subsets (not 8!)

Key Question: How do we avoid generating duplicate subsets?


================================================================================
SECTION 2: WHY DUPLICATES OCCUR - THE PROBLEM
================================================================================

Let's trace what happens with NAIVE take/not-take on [1, 2, 2]:

Array: [1, 2a, 2b]  (labeling the two 2s as 'a' and 'b' for clarity)
        ^   ^   ^
       i=0 i=1 i=2

NAIVE RECURSION TREE:
                                         []
                                       /    \
                                take 1      skip 1
                                  /            \
                                [1]            []
                              /    \         /    \
                         take 2a  skip 2a  take 2a  skip 2a
                           /        \        /         \
                        [1,2]      [1]     [2]         []
                        /   \      / \     / \        /   \
                   take 2b skip  T   S   T   S      T     S
                      /      \
                   [1,2,2] [1,2]   [1,2] [1]  [2,2] [2]  [2]   []
                                    ^          ^         ^
                                    |          |         |
                           These appear     [2] appears TWICE!
                           multiple times!

THE DUPLICATE PROBLEM VISUALIZED:
---------------------------------

Path 1 to get [2]:
    [] -> skip 1 -> [] -> take 2a -> [2] -> skip 2b -> [2]   FINAL: [2]

Path 2 to get [2]:
    [] -> skip 1 -> [] -> skip 2a -> [] -> take 2b -> [2]    FINAL: [2]

BOTH paths produce [2]! This is the duplicate we must eliminate.

Similarly for [1,2]:
    Path 1: take 1 -> take 2a -> skip 2b = [1,2]
    Path 2: take 1 -> skip 2a -> take 2b = [1,2]


================================================================================
SECTION 3: THE KEY INSIGHT - SORT + SKIP DUPLICATES
================================================================================

The solution has TWO parts:

PART 1: SORT THE ARRAY
----------------------
Why? To bring all duplicates TOGETHER (adjacent to each other).

    Before: [2, 1, 2]  ->  After: [1, 2, 2]
                                      ^  ^
                                      Duplicates are now adjacent!

PART 2: SKIP ALL CONSECUTIVE DUPLICATES WHEN WE "SKIP"
------------------------------------------------------
The key insight:
    When we decide NOT to take nums[i], we should skip ALL elements
    that have the same value as nums[i].

Why does this work?
    If we're skipping an element, we're saying "I don't want this value
    in my current subset path." If we later take a duplicate of the same
    value, we'd be contradicting ourselves and creating a duplicate subset.

VISUAL EXPLANATION:
                          Decision Point at index i where nums[i] = 2

                              [2, 2, 2, 3, 4]
                               ^  ^  ^
                              i  i+1 i+2

            TAKE path:                           SKIP path:
            Include this 2                       Don't include any 2
            Move to i+1                          Jump to index where value changes
                |                                         |
                v                                         v
           continue to [2,2,2,3,4]              jump directly to [3,4]
           at index i+1                         at index i+3

This ensures:
    - TAKE path explores: [2], [2,2], [2,2,2], [2,3], [2,2,3], etc.
    - SKIP path explores: [3], [4], [3,4], etc.
    - NO OVERLAP between paths!


THE RULE:
---------
    if we TAKE nums[i]:   move to i + 1
    if we SKIP nums[i]:   move to the next INDEX where value is DIFFERENT


================================================================================
SECTION 4: TWO APPROACHES TO SOLVE THIS
================================================================================

APPROACH 1: TAKE/NOT-TAKE WITH DUPLICATE SKIPPING
-------------------------------------------------
At each index i:

    Option A - TAKE:
        Add nums[i] to current subset
        Recurse with index = i + 1
        Remove nums[i] (backtrack)

    Option B - SKIP:
        Don't add nums[i]
        Skip ALL elements with same value as nums[i]
        Recurse with index = first different element

Pseudocode:
    def solve(idx, current):
        if idx == n:
            result.append(current.copy())
            return

        # TAKE nums[idx]
        current.append(nums[idx])
        solve(idx + 1, current)
        current.pop()

        # SKIP nums[idx] AND all its duplicates
        while idx + 1 < n and nums[idx + 1] == nums[idx]:
            idx += 1
        solve(idx + 1, current)


APPROACH 2: LOOP-BASED WITH "DON'T PICK SAME ELEMENT TWICE AT SAME LEVEL"
-------------------------------------------------------------------------
For each position in the subset, loop through remaining elements:

    for j in range(idx, n):
        # Skip duplicates AT THE SAME DECISION LEVEL
        if j > idx and nums[j] == nums[j-1]:
            continue

        current.append(nums[j])
        solve(j + 1, current)
        current.pop()

Why j > idx?
    - At j == idx, we MUST consider nums[j] (first choice at this level)
    - At j > idx, if nums[j] == nums[j-1], we've already processed this value

Visual of "same decision level":

    At idx=0, we can pick from [1, 2, 2]
                                 ^  ^  ^
                                j=0 j=1 j=2

    j=0: Pick 1, valid
    j=1: Pick 2, valid (first 2 at this level)
    j=2: Pick 2, SKIP! (j > idx AND nums[2]==nums[1])
         We already explored picking '2' at this decision level!


================================================================================
SECTION 5: DETAILED DRY RUN FOR [1, 2, 2]
================================================================================

Using APPROACH 1 (Take/Not-Take with Skip)

Input: nums = [1, 2, 2] (already sorted)
       Index:  0  1  2

Legend:
    T = Take current element
    S = Skip current element (and all its duplicates)

RECURSION TREE:
                                        solve(0, [])
                                       /            \
                                      T              S
                                     /                \
                            solve(1, [1])          solve(1, [])
                           /          \            /          \
                          T            S          T            S (skip to end!)
                         /              \        /              \
                solve(2, [1,2])    solve(3, [1])  solve(2, [2])  solve(3, [])
                   /      \            |             /     \          |
                  T        S         ADD [1]        T       S       ADD []
                 /          \                      /         \
        solve(3,[1,2,2]) solve(3,[1,2])    solve(3,[2,2]) solve(3,[2])
              |                |                |              |
        ADD [1,2,2]       ADD [1,2]         ADD [2,2]       ADD [2]


STEP-BY-STEP TRACE:
-------------------

Call 1: solve(idx=0, current=[])
    TAKE: Add 1, call solve(1, [1])
    SKIP: No duplicates of 1, call solve(1, [])

Call 2: solve(idx=1, current=[1])  (from TAKE path)
    TAKE: Add 2, call solve(2, [1,2])
    SKIP: nums[2]==nums[1], so skip to idx=3, call solve(3, [1])

Call 3: solve(idx=2, current=[1,2])  (from TAKE path)
    TAKE: Add 2, call solve(3, [1,2,2])
    SKIP: No more elements, call solve(3, [1,2])

Call 4: solve(idx=3, current=[1,2,2])
    idx == n, ADD [1,2,2] to result
    RESULT NOW: [[1,2,2]]

Call 5: solve(idx=3, current=[1,2])  (backtracked)
    idx == n, ADD [1,2] to result
    RESULT NOW: [[1,2,2], [1,2]]

Call 6: solve(idx=3, current=[1])  (from SKIP at Call 2)
    idx == n, ADD [1] to result
    RESULT NOW: [[1,2,2], [1,2], [1]]

Call 7: solve(idx=1, current=[])  (from SKIP at Call 1)
    TAKE: Add 2, call solve(2, [2])
    SKIP: nums[2]==nums[1], so skip to idx=3, call solve(3, [])

Call 8: solve(idx=2, current=[2])
    TAKE: Add 2, call solve(3, [2,2])
    SKIP: No more elements, call solve(3, [2])

Call 9: solve(idx=3, current=[2,2])
    idx == n, ADD [2,2] to result
    RESULT NOW: [[1,2,2], [1,2], [1], [2,2]]

Call 10: solve(idx=3, current=[2])
    idx == n, ADD [2] to result
    RESULT NOW: [[1,2,2], [1,2], [1], [2,2], [2]]

Call 11: solve(idx=3, current=[])  (from SKIP at Call 7)
    idx == n, ADD [] to result
    RESULT NOW: [[1,2,2], [1,2], [1], [2,2], [2], []]


FINAL RESULT: [[], [1], [1,2], [1,2,2], [2], [2,2]]
             (6 unique subsets - correct!)


# ================================================================================
#                 RECURSION TREE FOR arr=[1,2,2] (UNIQUE SUBSETS)
# ================================================================================
#
# This comprehensive tree shows EXACTLY how duplicates are avoided.
#
# KEY INSIGHT:
# ------------
# After sorting, when we SKIP an element, we skip ALL consecutive duplicates.
# This ensures each unique subset is generated exactly ONCE.
#
# LEGEND:
# -------
#   T = TAKE current element (move to idx+1)
#   S = SKIP current element AND all consecutive duplicates (jump to next different)
#   [PRUNED] = Branch eliminated by skip-duplicate logic
#   (*) = Subset added to result at this leaf
#
# Input: nums = [1, 2, 2] (sorted)
#        Index:  0  1  2
#
#
#                                    solve(idx=0, current=[])
#                                    Considering: nums[0]=1
#                                   /                         \
#                                  /                           \
#                           TAKE 1                           SKIP 1
#                           add 1 to current                 (no dup of 1, go to idx=1)
#                                /                                 \
#                               /                                   \
#                     solve(idx=1, [1])                       solve(idx=1, [])
#                     Considering: nums[1]=2                  Considering: nums[1]=2
#                      /              \                        /              \
#                     /                \                      /                \
#               TAKE 2              SKIP 2               TAKE 2             SKIP 2
#               add 2              skip to idx=3         add 2              skip to idx=3
#              (go to idx=2)       (nums[2]=nums[1])    (go to idx=2)      (nums[2]=nums[1])
#                  /                    \                  /                     \
#                 /                      \                /                       \
#       solve(idx=2, [1,2])        solve(idx=3, [1])   solve(idx=2, [2])    solve(idx=3, [])
#       Considering: nums[2]=2          |              Considering: nums[2]=2       |
#        /            \              BASE CASE            /          \          BASE CASE
#       /              \                |                /            \             |
#   TAKE 2          SKIP 2         ADD [1] (*)      TAKE 2        SKIP 2       ADD [] (*)
#   add 2           skip to idx=3   to result       add 2         skip to idx=3 to result
#  (go to idx=3)                                   (go to idx=3)
#      |                 \                             |               \
#      |                  \                            |                \
# solve(idx=3,[1,2,2])  solve(idx=3,[1,2])       solve(idx=3,[2,2])  solve(idx=3,[2])
#      |                     |                        |                    |
#   BASE CASE            BASE CASE                 BASE CASE           BASE CASE
#      |                     |                        |                    |
# ADD [1,2,2] (*)       ADD [1,2] (*)            ADD [2,2] (*)        ADD [2] (*)
# to result             to result                to result            to result
#
#
# ================================================================================
#              COLLECTED RESULTS (in order of generation):
# ================================================================================
#
#   1. [1,2,2]  <-- from leftmost path: T(1) -> T(2) -> T(2)
#   2. [1,2]    <-- from path: T(1) -> T(2) -> S(2)
#   3. [1]      <-- from path: T(1) -> S(2,2) [skipped both 2s]
#   4. [2,2]    <-- from path: S(1) -> T(2) -> T(2)
#   5. [2]      <-- from path: S(1) -> T(2) -> S(2)
#   6. []       <-- from path: S(1) -> S(2,2) [skipped both 2s]
#
# TOTAL: 6 unique subsets (No duplicates!)
#
#
# ================================================================================
#           WHY THE SKIP LOGIC PREVENTS DUPLICATES - VISUAL PROOF
# ================================================================================
#
# Consider what would happen WITHOUT skip-duplicate logic for [2, 2]:
#
#  ---- WITHOUT SKIP LOGIC (WRONG - produces duplicates) ----
#
#                        solve(idx=0, [])
#                        /             \
#                       /               \
#                  TAKE 2a            SKIP 2a
#                  (go to idx=1)      (go to idx=1)  <-- only moves 1 step!
#                     /                   \
#                    /                     \
#           solve(idx=1, [2])         solve(idx=1, [])
#            /         \                /         \
#           /           \              /           \
#       TAKE 2b     SKIP 2b      TAKE 2b      SKIP 2b
#          |            |            |             |
#    [2, 2] (*)     [2] (*)       [2] (*)       [] (*)
#                      ^            ^
#                      |            |
#                   DUPLICATE [2] generated from TWO different paths!
#
#    Path 1 to [2]: Take 2a, Skip 2b  -->  [2]
#    Path 2 to [2]: Skip 2a, Take 2b  -->  [2]
#
#
#  ---- WITH SKIP LOGIC (CORRECT - no duplicates) ----
#
#                        solve(idx=0, [])
#                        /             \
#                       /               \
#                  TAKE 2a            SKIP 2a (AND 2b!)
#                  (go to idx=1)      (jump to idx=2, out of bounds)
#                     /                   \
#                    /                     \
#           solve(idx=1, [2])         solve(idx=2, [])
#            /         \                    |
#           /           \               BASE CASE
#       TAKE 2b     SKIP 2b                 |
#          |            |               ADD [] (*)
#    [2, 2] (*)     [2] (*)
#
#    Now [2] appears only ONCE: Take 2a, Skip 2b
#    The path "Skip 2a, Take 2b" is ELIMINATED!
#
#
# THE RULE:
# ---------
# When we SKIP an element, we are saying "I don't want this VALUE in my subset."
# So we must skip ALL occurrences of this value, not just one!
#
#
# ================================================================================
#             RECURSION TREE FOR arr=[1,1,2] (ANOTHER EXAMPLE)
# ================================================================================
#
# Input: nums = [1, 1, 2] (sorted)
#        Index:  0  1  2
#
#                                    solve(idx=0, current=[])
#                                    Considering: nums[0]=1
#                                   /                         \
#                                  /                           \
#                           TAKE 1                          SKIP 1 (AND all 1s!)
#                           add 1 to current                jump to idx=2
#                          (go to idx=1)                    (skip past nums[1]=1)
#                              /                                  \
#                             /                                    \
#                    solve(idx=1, [1])                      solve(idx=2, [])
#                    Considering: nums[1]=1                 Considering: nums[2]=2
#                     /              \                       /              \
#                    /                \                     /                \
#              TAKE 1             SKIP 1 (jump!)      TAKE 2             SKIP 2
#              add 1              skip to idx=2       add 2              (go to idx=3)
#             (go to idx=2)       (no more 1s)       (go to idx=3)
#                 /                    \                 |                   |
#                /                      \                |                   |
#      solve(idx=2, [1,1])        solve(idx=2, [1])   solve(idx=3,[2])  solve(idx=3,[])
#      Considering: nums[2]=2     Considering: nums[2]=2    |               |
#       /           \              /           \        BASE CASE       BASE CASE
#      /             \            /             \           |               |
#  TAKE 2        SKIP 2      TAKE 2         SKIP 2    ADD [2] (*)       ADD [] (*)
#     |             |           |               |      to result        to result
#     |             |           |               |
# solve(idx=3,   solve(idx=3,  solve(idx=3,  solve(idx=3,
#  [1,1,2])       [1,1])        [1,2])         [1])
#     |             |             |              |
# BASE CASE     BASE CASE     BASE CASE      BASE CASE
#     |             |             |              |
# ADD [1,1,2](*) ADD [1,1](*) ADD [1,2](*)   ADD [1](*)
#
#
# COLLECTED RESULTS: [[1,1,2], [1,1], [1,2], [1], [2], []]
# TOTAL: 6 unique subsets
#
#
# ================================================================================
#             RECURSION TREE FOR arr=[2,2,2] (ALL DUPLICATES)
# ================================================================================
#
# Input: nums = [2, 2, 2] (sorted)
#        Index:  0  1  2
#
# This example shows maximum pruning - all elements are the same!
#
#                                    solve(idx=0, current=[])
#                                    Considering: nums[0]=2
#                                   /                         \
#                                  /                           \
#                           TAKE 2                          SKIP 2 (AND all 2s!)
#                           add 2 to current                jump to idx=3 (end!)
#                          (go to idx=1)
#                              /                                  \
#                             /                                    \
#                    solve(idx=1, [2])                      solve(idx=3, [])
#                    Considering: nums[1]=2                       |
#                     /              \                        BASE CASE
#                    /                \                           |
#              TAKE 2             SKIP 2 (jump!)              ADD [] (*)
#              add 2              skip to idx=3               to result
#             (go to idx=2)       (no more diff values)
#                 /                    \
#                /                      \
#      solve(idx=2, [2,2])        solve(idx=3, [2])
#      Considering: nums[2]=2          |
#       /           \               BASE CASE
#      /             \                  |
#  TAKE 2        SKIP 2              ADD [2] (*)
#     |             |                to result
#     |             |
# solve(idx=3,   solve(idx=3,
#  [2,2,2])       [2,2])
#     |             |
# BASE CASE     BASE CASE
#     |             |
# ADD [2,2,2](*) ADD [2,2](*)
#
#
# COLLECTED RESULTS: [[2,2,2], [2,2], [2], []]
# TOTAL: 4 unique subsets
#
# Compare to naive approach without skip logic:
#   Naive would generate 2^3 = 8 subsets
#   But [2] would appear 3 times! (picking any single 2)
#   And [2,2] would appear 3 times! (picking any two 2s)
#   Our skip logic reduces 8 -> 4 unique subsets.
#
#
# ================================================================================
#        COMPARING TAKE/SKIP APPROACH vs LOOP APPROACH - TREE STRUCTURE
# ================================================================================
#
# Both approaches produce the same results but have different tree structures.
#
# ----- TAKE/SKIP APPROACH (used above) -----
#
# At each index, we make exactly 2 choices:
#   - TAKE: include element, go to idx+1
#   - SKIP: exclude element AND duplicates, jump to next different
#
# Tree is a BINARY tree (2 children per node)
# Subsets collected at LEAVES (when idx == n)
#
#
# ----- LOOP APPROACH -----
#
# At each recursion level, we loop through remaining elements:
#   for j in range(idx, n):
#       if j > idx and nums[j] == nums[j-1]: continue  # skip duplicate
#       pick nums[j], recurse with j+1
#
# Tree has VARIABLE branching (0 to n-idx children)
# Subsets collected at EVERY NODE (before the loop)
#
# Loop approach tree for [1, 2, 2]:
#
#                             solve(idx=0, [])
#                            ADD [] to result
#                          /       |        \
#                         /        |         \
#                    pick 1     pick 2     [SKIP: j=2,
#                   (j=0)      (j=1)        nums[2]=nums[1]]
#                      |          |
#                      |          |
#             solve(idx=1, [1])   solve(idx=2, [2])
#             ADD [1] to result   ADD [2] to result
#              /       \               |
#             /         \              |
#        pick 2      [SKIP:j=2]    pick 2
#        (j=1)      nums[2]=nums[1] (j=2)
#           |                          |
#    solve(idx=2, [1,2])         solve(idx=3, [2,2])
#    ADD [1,2] to result         ADD [2,2] to result
#           |
#       pick 2
#       (j=2)
#           |
#    solve(idx=3, [1,2,2])
#    ADD [1,2,2] to result
#
# Results: [[], [1], [1,2], [1,2,2], [2], [2,2]] - Same 6 subsets!
#
#
# ================================================================================
#                    STATE TRACKING TABLE FOR [1, 2, 2]
# ================================================================================
#
# This table tracks the state at each recursive call (Take/Skip approach):
#
# +------+-------+----------+---------+----------------------------------+
# | Call | idx   | current  | Action  | Notes                            |
# +------+-------+----------+---------+----------------------------------+
# |  1   |   0   | []       | START   | Consider nums[0]=1               |
# +------+-------+----------+---------+----------------------------------+
# |  2   |   1   | [1]      | TAKE 1  | Consider nums[1]=2               |
# +------+-------+----------+---------+----------------------------------+
# |  3   |   2   | [1,2]    | TAKE 2  | Consider nums[2]=2               |
# +------+-------+----------+---------+----------------------------------+
# |  4   |   3   | [1,2,2]  | TAKE 2  | BASE CASE -> ADD [1,2,2]         |
# +------+-------+----------+---------+----------------------------------+
# |  5   |   3   | [1,2]    | SKIP 2  | BASE CASE -> ADD [1,2]           |
# +------+-------+----------+---------+----------------------------------+
# |  6   |   3   | [1]      | SKIP 2s | Skipped idx=2 (dup), BASE -> [1] |
# +------+-------+----------+---------+----------------------------------+
# |  7   |   1   | []       | SKIP 1  | Back to idx=0, now SKIP path     |
# +------+-------+----------+---------+----------------------------------+
# |  8   |   2   | [2]      | TAKE 2  | Consider nums[2]=2               |
# +------+-------+----------+---------+----------------------------------+
# |  9   |   3   | [2,2]    | TAKE 2  | BASE CASE -> ADD [2,2]           |
# +------+-------+----------+---------+----------------------------------+
# | 10   |   3   | [2]      | SKIP 2  | BASE CASE -> ADD [2]             |
# +------+-------+----------+---------+----------------------------------+
# | 11   |   3   | []       | SKIP 2s | Skipped idx=2 (dup), BASE -> []  |
# +------+-------+----------+---------+----------------------------------+
#
# FINAL RESULT: [[1,2,2], [1,2], [1], [2,2], [2], []]
#


================================================================================
DRY RUN 2: INPUT [1, 1, 1]
================================================================================

Input: nums = [1, 1, 1] (already sorted)
       Index:  0  1  2

RECURSION TREE:
                                solve(0, [])
                               /            \
                              T              S (skip ALL 1s!)
                             /                \
                    solve(1, [1])          solve(3, [])
                   /          \                 |
                  T            S              ADD []
                 /              \
        solve(2, [1,1])      solve(3, [1])
           /     \               |
          T       S           ADD [1]
         /         \
solve(3,[1,1,1]) solve(3,[1,1])
      |               |
ADD [1,1,1]       ADD [1,1]


TRACE:
------
1. solve(0, [])
   - TAKE 1 -> solve(1, [1])
   - SKIP 1 (skip ALL 1s since nums[1]=nums[0] and nums[2]=nums[1])
     Jump to idx=3 -> solve(3, [])

2. solve(1, [1])
   - TAKE 1 -> solve(2, [1,1])
   - SKIP (jump past remaining 1s) -> solve(3, [1])

3. solve(2, [1,1])
   - TAKE 1 -> solve(3, [1,1,1]) -> ADD [1,1,1]
   - SKIP -> solve(3, [1,1]) -> ADD [1,1]

4. solve(3, [1]) -> ADD [1]

5. solve(3, []) -> ADD []

FINAL RESULT: [[], [1], [1,1], [1,1,1]]
             (4 unique subsets - correct!)


================================================================================
SECTION 6: WHY SKIPPING WORKS - VISUAL PROOF
================================================================================

Let's prove why "skip ALL duplicates" eliminates duplicate subsets.

Consider input [2, 2]:

WITHOUT our skip logic (WRONG):
-------------------------------
                    solve(0, [])
                    /          \
                   T            S
                  /              \
          solve(1, [2])      solve(1, [])
           /      \           /       \
          T        S         T         S
         /          \       /           \
  [2,2]           [2]     [2]           []
                    ^       ^
                    |       |
                   DUPLICATE! Both paths produce [2]

Path to first [2]:  Take 2a, Skip 2b  ->  [2]
Path to second [2]: Skip 2a, Take 2b  ->  [2]


WITH our skip logic (CORRECT):
------------------------------
                    solve(0, [])
                    /          \
                   T            S (skip ALL 2s!)
                  /              \
          solve(1, [2])      solve(2, [])
           /      \               |
          T        S            ADD []
         /          \
    ADD [2,2]     ADD [2]

Now only ONE path leads to [2]: Take 2a, Skip 2b

The path "Skip 2a, Take 2b" is ELIMINATED because when we skip 2a,
we skip ALL consecutive 2s (jump to index 2, which is out of bounds).


KEY INSIGHT:
------------
    "Taking element X at position i" and "Taking element X at position j"
    (where X appears at both i and j) would produce the SAME subset.

    By skipping ALL duplicates when we SKIP, we ensure:
    - If we want X in our subset, we ALWAYS take the FIRST occurrence
    - If we don't want X, we skip ALL occurrences

    This creates a CANONICAL way to form each subset!


================================================================================
SECTION 7: COMPARISON - SUBSETS I vs SUBSETS II
================================================================================

+-------------------+----------------------+---------------------------+
|      Aspect       |     Subsets I        |       Subsets II          |
+-------------------+----------------------+---------------------------+
| Input             | Distinct elements    | May have duplicates       |
+-------------------+----------------------+---------------------------+
| Sorting needed?   | No (optional)        | YES (mandatory!)          |
+-------------------+----------------------+---------------------------+
| Skip logic        | None                 | Skip consecutive          |
|                   |                      | duplicates when skipping  |
+-------------------+----------------------+---------------------------+
| # of subsets      | Always 2^n           | <= 2^n                    |
+-------------------+----------------------+---------------------------+
| Example           | [1,2,3] -> 8 subsets | [1,2,2] -> 6 subsets      |
+-------------------+----------------------+---------------------------+
| Take/Skip         | Always move to i+1   | SKIP: jump past dups      |
|                   |                      | TAKE: move to i+1         |
+-------------------+----------------------+---------------------------+
| Loop approach     | No condition needed  | if j > idx and            |
|                   |                      |    nums[j]==nums[j-1]:    |
|                   |                      |    continue               |
+-------------------+----------------------+---------------------------+

When to use which?
------------------
- If problem says "distinct elements" -> Use Subsets I logic
- If problem says "may contain duplicates" -> Use Subsets II logic
- Interview tip: ALWAYS ASK "Can the input have duplicates?"


================================================================================
SECTION 8: COMPLEXITY ANALYSIS
================================================================================

TIME COMPLEXITY: O(n * 2^n)
---------------------------
- In worst case (all distinct), we generate 2^n subsets
- Each subset can be up to size n
- Copying each subset to result takes O(n)
- Total: O(n * 2^n)

With duplicates:
- Fewer subsets are generated (some branches are pruned)
- But worst case is still O(n * 2^n)

SPACE COMPLEXITY: O(n)
----------------------
- Recursion stack depth: O(n) in worst case
- Current subset storage: O(n)
- Result storage: O(n * 2^n) but typically not counted
- Auxiliary space: O(n)

SORTING: O(n log n)
-------------------
- Dominated by subset generation O(n * 2^n)
- So overall time is still O(n * 2^n)


================================================================================
SECTION 9: IMPLEMENTATIONS
================================================================================
"""

from typing import List


def subsets_with_dup_take_skip(nums: List[int]) -> List[List[int]]:
    """
    Approach 1: Take/Not-Take with Duplicate Skipping

    Strategy:
        1. Sort the array to group duplicates together
        2. At each index, we have two choices:
           - TAKE: Include current element, move to next index
           - SKIP: Exclude current element AND all its consecutive duplicates

    Time Complexity: O(n * 2^n)
    Space Complexity: O(n) for recursion stack
    """
    nums.sort()  # CRUCIAL: Sort to group duplicates together
    n = len(nums)
    result = []

    def solve(idx: int, current: List[int]) -> None:
        """
        Recursive function to generate subsets.

        Args:
            idx: Current index in nums array
            current: Current subset being built
        """
        # Base case: processed all elements
        if idx == n:
            result.append(current.copy())  # Add a COPY of current subset
            return

        # OPTION 1: TAKE nums[idx]
        # Include this element in current subset
        current.append(nums[idx])
        solve(idx + 1, current)
        current.pop()  # Backtrack - remove the element we just added

        # OPTION 2: SKIP nums[idx] AND all consecutive duplicates
        # Find the next index with a different value
        next_different = idx + 1
        while next_different < n and nums[next_different] == nums[idx]:
            next_different += 1

        solve(next_different, current)

    solve(0, [])
    return result


def subsets_with_dup_loop(nums: List[int]) -> List[List[int]]:
    """
    Approach 2: Loop-based with "don't pick same element twice at same level"

    Strategy:
        1. Sort the array to group duplicates together
        2. At each recursion level, iterate through remaining elements
        3. Skip duplicates at the SAME decision level using:
           if j > idx and nums[j] == nums[j-1]: continue

    Time Complexity: O(n * 2^n)
    Space Complexity: O(n) for recursion stack
    """
    nums.sort()  # CRUCIAL: Sort to group duplicates together
    n = len(nums)
    result = []

    def solve(idx: int, current: List[int]) -> None:
        """
        Recursive function using loop-based approach.

        Args:
            idx: Starting index for this decision level
            current: Current subset being built
        """
        # Add current subset to result (we add at every node, not just leaves)
        result.append(current.copy())

        # Try adding each remaining element
        for j in range(idx, n):
            # SKIP DUPLICATES at the same decision level
            # j > idx ensures we don't skip the first element at this level
            # nums[j] == nums[j-1] checks if current is same as previous
            if j > idx and nums[j] == nums[j - 1]:
                continue

            # Include nums[j] and recurse
            current.append(nums[j])
            solve(j + 1, current)  # Move to j+1, not idx+1!
            current.pop()  # Backtrack

    solve(0, [])
    return result


def subsets_with_dup_iterative(nums: List[int]) -> List[List[int]]:
    """
    Bonus: Iterative approach using subset building

    Strategy:
        1. Sort the array
        2. Start with empty subset [[]]
        3. For each number:
           - If it's a duplicate, only add to subsets created in last iteration
           - If it's new, add to ALL existing subsets

    Time Complexity: O(n * 2^n)
    Space Complexity: O(1) auxiliary (excluding result storage)
    """
    nums.sort()
    result = [[]]  # Start with empty subset

    start_idx = 0  # Track where new subsets start for duplicate handling

    for i in range(len(nums)):
        # Determine starting point for adding current number
        if i > 0 and nums[i] == nums[i - 1]:
            # Duplicate: only extend subsets created in previous iteration
            # This avoids creating duplicate subsets
            begin = start_idx
        else:
            # New number: extend ALL existing subsets
            begin = 0

        # Remember where new subsets will start
        start_idx = len(result)

        # Create new subsets by adding current number to existing ones
        new_subsets = []
        for j in range(begin, len(result)):
            new_subsets.append(result[j] + [nums[i]])

        result.extend(new_subsets)

    return result


"""
================================================================================
SECTION 10: COMMON MISTAKES
================================================================================

MISTAKE 1: Forgetting to Sort
-----------------------------
    WRONG:
        def solve(nums):
            # No sorting!
            ...

    WHY IT FAILS:
        Input [2, 1, 2] - duplicates not adjacent
        Can't properly skip consecutive duplicates

    FIX:
        nums.sort()  # Always sort first!


MISTAKE 2: Only Skipping ONE Duplicate
--------------------------------------
    WRONG:
        # Skip only one duplicate
        if idx + 1 < n and nums[idx + 1] == nums[idx]:
            solve(idx + 2, current)  # Only skips one!
        else:
            solve(idx + 1, current)

    WHY IT FAILS:
        For [1, 1, 1], this only skips one 1, not all of them
        Still creates duplicate subsets

    FIX:
        # Skip ALL consecutive duplicates
        next_diff = idx + 1
        while next_diff < n and nums[next_diff] == nums[idx]:
            next_diff += 1
        solve(next_diff, current)


MISTAKE 3: Wrong Skip Condition in Loop Approach
-------------------------------------------------
    WRONG:
        for j in range(idx, n):
            if nums[j] == nums[j-1]:  # Missing j > idx check!
                continue
            ...

    WHY IT FAILS:
        When j == idx and j > 0, nums[j] might equal nums[j-1]
        But nums[j-1] is from PREVIOUS decision level, not current!
        We'd wrongly skip valid choices.

    Example:
        nums = [1, 2, 2]
        At idx=2, j=2: nums[2]==nums[1] (both are 2)
        But nums[1] was chosen at a DIFFERENT level!
        We should NOT skip here.

    FIX:
        if j > idx and nums[j] == nums[j-1]:
            continue


MISTAKE 4: Using idx + 1 Instead of j + 1 in Loop
-------------------------------------------------
    WRONG:
        for j in range(idx, n):
            current.append(nums[j])
            solve(idx + 1, current)  # Should be j + 1!
            current.pop()

    WHY IT FAILS:
        We'd keep processing from same starting point
        Leads to infinite recursion or wrong subsets

    FIX:
        solve(j + 1, current)


MISTAKE 5: Forgetting .copy() When Adding to Result
----------------------------------------------------
    WRONG:
        result.append(current)  # Adding reference, not copy!

    WHY IT FAILS:
        All entries in result point to same list
        When we modify current, all entries change!

    FIX:
        result.append(current.copy())
        # or: result.append(current[:])
        # or: result.append(list(current))


================================================================================
SECTION 11: TEST CASES
================================================================================
"""


def run_tests():
    """Run comprehensive test cases for all implementations."""

    test_cases = [
        # (input, expected_subsets_count, description)
        ([1, 2, 2], 6, "Basic case with one duplicate"),
        ([0], 2, "Single element"),
        ([1, 1, 1], 4, "All same elements"),
        ([1, 2, 3], 8, "No duplicates (same as Subsets I)"),
        ([], 1, "Empty array"),
        ([1, 2, 2, 3], 12, "Multiple elements with duplicates"),
        ([1, 1, 2, 2], 9, "Two pairs of duplicates"),
    ]

    print("=" * 70)
    print("TESTING SUBSETS II IMPLEMENTATIONS")
    print("=" * 70)

    for nums, expected_count, description in test_cases:
        print(f"\nTest: {description}")
        print(f"Input: {nums}")

        # Test all three implementations
        result1 = subsets_with_dup_take_skip(nums.copy())
        result2 = subsets_with_dup_loop(nums.copy())
        result3 = subsets_with_dup_iterative(nums.copy())

        # Sort results for comparison (subsets can be in any order)
        def sort_result(res):
            return sorted([sorted(s) for s in res])

        r1_sorted = sort_result(result1)
        r2_sorted = sort_result(result2)
        r3_sorted = sort_result(result3)

        # Check counts
        count1 = len(result1)
        count2 = len(result2)
        count3 = len(result3)

        # Check for duplicates within each result
        unique1 = len(set(tuple(sorted(s)) for s in result1))
        unique2 = len(set(tuple(sorted(s)) for s in result2))
        unique3 = len(set(tuple(sorted(s)) for s in result3))

        all_pass = (count1 == expected_count and count2 == expected_count and
                   count3 == expected_count and unique1 == count1 and
                   unique2 == count2 and unique3 == count3 and
                   r1_sorted == r2_sorted == r3_sorted)

        status = "PASS" if all_pass else "FAIL"
        print(f"Expected count: {expected_count}")
        print(f"Take/Skip approach: {count1} subsets (unique: {unique1}) {'OK' if count1 == expected_count and unique1 == count1 else 'FAIL'}")
        print(f"Loop approach:      {count2} subsets (unique: {unique2}) {'OK' if count2 == expected_count and unique2 == count2 else 'FAIL'}")
        print(f"Iterative approach: {count3} subsets (unique: {unique3}) {'OK' if count3 == expected_count and unique3 == count3 else 'FAIL'}")
        print(f"Result: {result1}")
        print(f"Status: [{status}]")

    print("\n" + "=" * 70)
    print("DETAILED OUTPUT FOR [1, 2, 2]")
    print("=" * 70)
    result = subsets_with_dup_take_skip([1, 2, 2])
    print(f"Input: [1, 2, 2]")
    print(f"Output ({len(result)} subsets):")
    for i, subset in enumerate(sorted(result, key=lambda x: (len(x), x))):
        print(f"  {i+1}. {subset}")


"""
================================================================================
SECTION 12: KEY TAKEAWAYS
================================================================================

1. SORT TO GROUP DUPLICATES TOGETHER
   ---------------------------------
   Always sort the array first! This brings duplicates adjacent to each other,
   making them easy to detect and skip.

2. "SKIP" MEANS SKIP ALL CONSECUTIVE DUPLICATES
   --------------------------------------------
   When we decide NOT to take an element, we must skip ALL elements with
   the same value. This prevents generating the same subset via different paths.

3. TWO VALID APPROACHES
   --------------------
   - Take/Skip with Jump: When skipping, jump to next different element
   - Loop with j > idx check: Skip duplicates at the same decision level

   Both are correct. Choose based on your preference/interviewer's preference.

4. THE CANONICAL SUBSET PROPERTY
   -----------------------------
   Our approach ensures each unique subset is generated exactly once.
   If we want element X, we ALWAYS take the FIRST occurrence.
   This creates a unique "canonical" way to form each subset.

5. INTERVIEW TIP: ALWAYS ASK ABOUT DUPLICATES!
   -------------------------------------------
   "Can the input array contain duplicate elements?"
   This single question changes the solution significantly:
   - Distinct input: Simple take/not-take
   - Duplicates: Sort + skip consecutive duplicates

6. REMEMBER THE SKIP CONDITION IN LOOP APPROACH
   ---------------------------------------------
   if j > idx and nums[j] == nums[j-1]: continue
         ^^^^^
   The j > idx is CRUCIAL! It ensures we don't skip the first choice
   at each decision level.

7. COMPLEXITY DOESN'T CHANGE MUCH
   ------------------------------
   - Time: Still O(n * 2^n) worst case
   - Space: Still O(n) for recursion
   - Sorting adds O(n log n) but is dominated by subset generation


================================================================================
RELATED PROBLEMS
================================================================================

Once you understand Subsets II, try these:
1. Subsets I (LeetCode 78) - No duplicates version
2. Combination Sum II (LeetCode 40) - Similar duplicate handling
3. Permutations II (LeetCode 47) - Permutations with duplicates
4. 3Sum (LeetCode 15) - Uses similar skip-duplicate logic

================================================================================
"""


if __name__ == "__main__":
    run_tests()

    print("\n" + "=" * 70)
    print("MANUAL VERIFICATION")
    print("=" * 70)

    # Test case from problem
    nums = [1, 2, 2]
    print(f"\nInput: {nums}")
    print(f"Expected: [[],[1],[1,2],[1,2,2],[2],[2,2]]")
    print(f"Output:   {subsets_with_dup_take_skip(nums)}")

    nums = [0]
    print(f"\nInput: {nums}")
    print(f"Expected: [[],[0]]")
    print(f"Output:   {subsets_with_dup_take_skip(nums)}")
