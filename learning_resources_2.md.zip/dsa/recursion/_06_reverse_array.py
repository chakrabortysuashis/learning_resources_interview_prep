"""
Reverse an Array/String Using Recursion
========================================

Problem Statement:
------------------
Given an array (or string), reverse it using recursion.
The reversal should be done IN-PLACE (without using extra space for another array).

Examples:
---------
Input:  [1, 2, 3, 4, 5]
Output: [5, 4, 3, 2, 1]

Input:  "hello"
Output: "olleh"

Input:  [10, 20]
Output: [20, 10]

================================================================================
                           UNDERSTANDING THE PROBLEM
================================================================================

What does "reverse" mean?
- First element becomes last
- Last element becomes first
- Second element becomes second-last
- ... and so on

Visual Understanding:
---------------------

    Original Array:   [1, 2, 3, 4, 5]
                       |           |
                       +-----------+  (swap 1 and 5)

    After 1st swap:   [5, 2, 3, 4, 1]
                          |     |
                          +-----+      (swap 2 and 4)

    After 2nd swap:   [5, 4, 3, 2, 1]
                             |
                          (middle - no swap needed)

    Final Result:     [5, 4, 3, 2, 1]

================================================================================
                         THE TWO-POINTER APPROACH
================================================================================

Key Insight:
------------
To reverse an array, we need to swap elements from BOTH ENDS, moving inward.

    arr = [1, 2, 3, 4, 5]
           ^           ^
          left       right
           |           |
           +-----------+
               SWAP!

After swapping, we move BOTH pointers toward the center:
- left moves RIGHT (left + 1)
- right moves LEFT (right - 1)

This is the "SHRINKING PROBLEM" pattern!
----------------------------------------

    Step 0: [1, 2, 3, 4, 5]    left=0, right=4   --> Problem size = 5
             L           R

    Step 1: [5, 2, 3, 4, 1]    left=1, right=3   --> Problem size = 3
                L     R

    Step 2: [5, 4, 3, 2, 1]    left=2, right=2   --> Problem size = 1
                   LR
                   (STOP! left >= right)

Each recursive call handles a SMALLER portion of the array.
The problem "shrinks" from both ends toward the middle.

================================================================================
                    BASE CASE AND RECURSIVE CASE ANALYSIS
================================================================================

+------------------------------------------------------------------+
|                         BASE CASE                                 |
+------------------------------------------------------------------+
| Condition: left >= right                                          |
|                                                                   |
| When to stop?                                                     |
|   1. left == right: Single element (odd-length array middle)     |
|   2. left > right:  Pointers have crossed (even-length array)    |
|                                                                   |
| Why stop?                                                         |
|   - No more elements to swap                                      |
|   - Array is fully reversed                                       |
|                                                                   |
| Action: Simply return (do nothing)                                |
+------------------------------------------------------------------+

+------------------------------------------------------------------+
|                       RECURSIVE CASE                              |
+------------------------------------------------------------------+
| Condition: left < right                                           |
|                                                                   |
| Steps:                                                            |
|   1. SWAP arr[left] and arr[right]                               |
|   2. RECURSE with (left + 1, right - 1)                          |
|                                                                   |
| The "smaller problem":                                            |
|   - Same array, but we only care about elements between          |
|     the NEW left and right positions                             |
+------------------------------------------------------------------+

================================================================================
                        RECURSION TREE VISUALIZATION
================================================================================

================================================================================
              EXAMPLE 1: COMPREHENSIVE TREE FOR reverse([1,2,3,4,5])
                              (Odd-Length Array)
================================================================================

INITIAL STATE:
    Array: [1, 2, 3, 4, 5]
    Indices: 0  1  2  3  4
    Call: reverse(arr, left=0, right=4)

THE TWO-POINTER SHRINKING PATTERN:
----------------------------------

    Step 0 (Initial):    [ 1 , 2 , 3 , 4 , 5 ]
                           ^               ^
                          left           right
                          (0)             (4)
                           |               |
                           +-------+-------+
                                   |
                                 SWAP!

    Step 1 (After Swap):  [ 5 , 2 , 3 , 4 , 1 ]
                               ^       ^
                              left   right
                              (1)     (3)
                               |       |
                               +---+---+
                                   |
                                 SWAP!

    Step 2 (After Swap):  [ 5 , 4 , 3 , 2 , 1 ]
                                   ^
                                  left
                                  right
                                  (2)=(2)
                                   |
                               BASE CASE!
                            (Pointers Meet)

RECURSION TREE WITH BOX NODES:
------------------------------

    ┌─────────────────────────────────────────────────────────────────────┐
    │                     CALL 1: reverse(arr, 0, 4)                      │
    │                                                                     │
    │  BEFORE:  arr = [ 1 , 2 , 3 , 4 , 5 ]                              │
    │                    ^               ^                                │
    │                  left=0         right=4                             │
    │                                                                     │
    │  CHECK:   left < right?  -->  0 < 4?  -->  YES (Continue)          │
    │                                                                     │
    │  ACTION:  SWAP arr[0] and arr[4]                                   │
    │           arr[0]=1, arr[4]=5  -->  SWAP  -->  arr[0]=5, arr[4]=1   │
    │                                                                     │
    │  AFTER:   arr = [ 5 , 2 , 3 , 4 , 1 ]                              │
    │                    *               *                                │
    │                 swapped         swapped                             │
    │                                                                     │
    │  RECURSE: reverse(arr, left+1, right-1) = reverse(arr, 1, 3)       │
    └─────────────────────────────────────────────────────────────────────┘
                                      │
                                      │ (Recursive Call)
                                      ▼
    ┌─────────────────────────────────────────────────────────────────────┐
    │                     CALL 2: reverse(arr, 1, 3)                      │
    │                                                                     │
    │  BEFORE:  arr = [ 5 , 2 , 3 , 4 , 1 ]                              │
    │                        ^       ^                                    │
    │                      left=1  right=3                                │
    │                                                                     │
    │  CHECK:   left < right?  -->  1 < 3?  -->  YES (Continue)          │
    │                                                                     │
    │  ACTION:  SWAP arr[1] and arr[3]                                   │
    │           arr[1]=2, arr[3]=4  -->  SWAP  -->  arr[1]=4, arr[3]=2   │
    │                                                                     │
    │  AFTER:   arr = [ 5 , 4 , 3 , 2 , 1 ]                              │
    │                        *       *                                    │
    │                     swapped  swapped                                │
    │                                                                     │
    │  RECURSE: reverse(arr, left+1, right-1) = reverse(arr, 2, 2)       │
    └─────────────────────────────────────────────────────────────────────┘
                                      │
                                      │ (Recursive Call)
                                      ▼
    ┌─────────────────────────────────────────────────────────────────────┐
    │                     CALL 3: reverse(arr, 2, 2)                      │
    │                                                                     │
    │  STATE:   arr = [ 5 , 4 , 3 , 2 , 1 ]                              │
    │                            ^                                        │
    │                         left=2                                      │
    │                        right=2                                      │
    │                      (SAME INDEX!)                                  │
    │                                                                     │
    │  CHECK:   left >= right?  -->  2 >= 2?  -->  YES                   │
    │                                                                     │
    │  ┌─────────────────────────────────────────────────────────────┐   │
    │  │                    *** BASE CASE REACHED ***                │   │
    │  │                                                             │   │
    │  │   Pointers have MET (odd-length array)                      │   │
    │  │   Middle element (3) stays in place - no swap needed!       │   │
    │  │   Return immediately - nothing more to do                   │   │
    │  └─────────────────────────────────────────────────────────────┘   │
    │                                                                     │
    │  RETURN:  (no action, just return to caller)                       │
    └─────────────────────────────────────────────────────────────────────┘
                                      │
                                      │ (Return to CALL 2)
                                      ▼
    ┌─────────────────────────────────────────────────────────────────────┐
    │                  RETURNING FROM CALL 2                              │
    │                                                                     │
    │  Recursive call completed. Current arr = [5, 4, 3, 2, 1]           │
    │  No more work to do in this call frame.                            │
    │  Return to caller (CALL 1).                                        │
    └─────────────────────────────────────────────────────────────────────┘
                                      │
                                      │ (Return to CALL 1)
                                      ▼
    ┌─────────────────────────────────────────────────────────────────────┐
    │                  RETURNING FROM CALL 1                              │
    │                                                                     │
    │  Recursive call completed. Current arr = [5, 4, 3, 2, 1]           │
    │  No more work to do in this call frame.                            │
    │  Return to main program.                                           │
    │                                                                     │
    │  ┌─────────────────────────────────────────────────────────────┐   │
    │  │          FINAL RESULT: arr = [5, 4, 3, 2, 1]                │   │
    │  └─────────────────────────────────────────────────────────────┘   │
    └─────────────────────────────────────────────────────────────────────┘


CALL STACK VISUALIZATION (ODD-LENGTH):
--------------------------------------

    PHASE 1: PUSHING CALLS (Going Down)
    ====================================

        |                         |
        |-------------------------|
        |                         |      reverse(2,2) pushed
        |-------------------------|  <-- BASE CASE! Start returning
        |     reverse(1,3)        |
        |-------------------------|
        |     reverse(0,4)        |
        |-------------------------|
        |       (bottom)          |
        +-------------------------+
               Call Stack
              (max depth = 3)

    PHASE 2: POPPING CALLS (Going Up)
    ==================================

        Stack unwinds: reverse(2,2) -> reverse(1,3) -> reverse(0,4)
        Array remains modified: [5, 4, 3, 2, 1]


================================================================================
              EXAMPLE 2: COMPREHENSIVE TREE FOR reverse([10,20,30,40])
                              (Even-Length Array)
================================================================================

INITIAL STATE:
    Array: [10, 20, 30, 40]
    Indices:  0   1   2   3
    Call: reverse(arr, left=0, right=3)

THE TWO-POINTER SHRINKING PATTERN:
----------------------------------

    Step 0 (Initial):    [ 10 , 20 , 30 , 40 ]
                            ^              ^
                          left           right
                          (0)             (3)
                            |              |
                            +------+-------+
                                   |
                                 SWAP!

    Step 1 (After Swap):  [ 40 , 20 , 30 , 10 ]
                                ^      ^
                              left   right
                              (1)     (2)
                                |      |
                                +--+---+
                                   |
                                 SWAP!

    Step 2 (After Swap):  [ 40 , 30 , 20 , 10 ]

                             right  left
                              (1)   (2)

                          left > right
                               |
                           BASE CASE!
                        (Pointers Cross)

RECURSION TREE WITH BOX NODES:
------------------------------

    ┌─────────────────────────────────────────────────────────────────────┐
    │                     CALL 1: reverse(arr, 0, 3)                      │
    │                                                                     │
    │  BEFORE:  arr = [ 10 , 20 , 30 , 40 ]                              │
    │                     ^              ^                                │
    │                   left=0        right=3                             │
    │                                                                     │
    │  CHECK:   left < right?  -->  0 < 3?  -->  YES (Continue)          │
    │                                                                     │
    │  ACTION:  SWAP arr[0] and arr[3]                                   │
    │           arr[0]=10, arr[3]=40 --> SWAP --> arr[0]=40, arr[3]=10   │
    │                                                                     │
    │  AFTER:   arr = [ 40 , 20 , 30 , 10 ]                              │
    │                     *              *                                │
    │                  swapped        swapped                             │
    │                                                                     │
    │  RECURSE: reverse(arr, left+1, right-1) = reverse(arr, 1, 2)       │
    └─────────────────────────────────────────────────────────────────────┘
                                      │
                                      │ (Recursive Call)
                                      ▼
    ┌─────────────────────────────────────────────────────────────────────┐
    │                     CALL 2: reverse(arr, 1, 2)                      │
    │                                                                     │
    │  BEFORE:  arr = [ 40 , 20 , 30 , 10 ]                              │
    │                         ^     ^                                     │
    │                       left=1 right=2                                │
    │                                                                     │
    │  CHECK:   left < right?  -->  1 < 2?  -->  YES (Continue)          │
    │                                                                     │
    │  ACTION:  SWAP arr[1] and arr[2]                                   │
    │           arr[1]=20, arr[2]=30 --> SWAP --> arr[1]=30, arr[2]=20   │
    │                                                                     │
    │  AFTER:   arr = [ 40 , 30 , 20 , 10 ]                              │
    │                         *     *                                     │
    │                      swapped swapped                                │
    │                                                                     │
    │  RECURSE: reverse(arr, left+1, right-1) = reverse(arr, 2, 1)       │
    └─────────────────────────────────────────────────────────────────────┘
                                      │
                                      │ (Recursive Call)
                                      ▼
    ┌─────────────────────────────────────────────────────────────────────┐
    │                     CALL 3: reverse(arr, 2, 1)                      │
    │                                                                     │
    │  STATE:   arr = [ 40 , 30 , 20 , 10 ]                              │
    │                              ^                                      │
    │                           left=2                                    │
    │                          right=1                                    │
    │                                                                     │
    │                        left=2  >  right=1                           │
    │                      (POINTERS CROSSED!)                            │
    │                                                                     │
    │  CHECK:   left >= right?  -->  2 >= 1?  -->  YES                   │
    │                                                                     │
    │  ┌─────────────────────────────────────────────────────────────┐   │
    │  │                    *** BASE CASE REACHED ***                │   │
    │  │                                                             │   │
    │  │   Pointers have CROSSED (even-length array)                 │   │
    │  │   All pairs have been swapped!                              │   │
    │  │   Return immediately - nothing more to do                   │   │
    │  └─────────────────────────────────────────────────────────────┘   │
    │                                                                     │
    │  RETURN:  (no action, just return to caller)                       │
    └─────────────────────────────────────────────────────────────────────┘
                                      │
                                      │ (Returns propagate back up)
                                      ▼
    ┌─────────────────────────────────────────────────────────────────────┐
    │          FINAL RESULT: arr = [40, 30, 20, 10]                      │
    └─────────────────────────────────────────────────────────────────────┘


================================================================================
                 COMPARING ODD vs EVEN LENGTH BASE CASES
================================================================================

    ┌─────────────────────────────────────────────────────────────────────┐
    │                     ODD LENGTH ARRAY (e.g., 5 elements)            │
    │                                                                     │
    │   Array: [1, 2, 3, 4, 5]                                           │
    │                                                                     │
    │   Final recursive call: reverse(arr, 2, 2)                         │
    │                                                                     │
    │   Pointer positions:     [ 5 , 4 , 3 , 2 , 1 ]                     │
    │                                     ^                               │
    │                                  left=2                             │
    │                                  right=2                            │
    │                                  (MEET)                             │
    │                                                                     │
    │   Check: left >= right  -->  2 >= 2  -->  TRUE (BASE CASE)         │
    │                                                                     │
    │   Note: Middle element (3) was never swapped - it stays in place!  │
    └─────────────────────────────────────────────────────────────────────┘

    ┌─────────────────────────────────────────────────────────────────────┐
    │                     EVEN LENGTH ARRAY (e.g., 4 elements)           │
    │                                                                     │
    │   Array: [10, 20, 30, 40]                                          │
    │                                                                     │
    │   Final recursive call: reverse(arr, 2, 1)                         │
    │                                                                     │
    │   Pointer positions:     [ 40 , 30 , 20 , 10 ]                     │
    │                                      ^                              │
    │                                   right=1                           │
    │                                   left=2                            │
    │                                   (CROSSED)                         │
    │                                                                     │
    │   Check: left >= right  -->  2 >= 1  -->  TRUE (BASE CASE)         │
    │                                                                     │
    │   Note: All elements were swapped - no middle element!             │
    └─────────────────────────────────────────────────────────────────────┘


================================================================================
                 VISUAL SWAP ANIMATION FOR [1, 2, 3, 4, 5]
================================================================================

    CALL 1: Swap positions 0 and 4
    ==============================

         Before:  [ 1 , 2 , 3 , 4 , 5 ]
                    ^               ^
                    |               |
                    +-------+-------+
                            |
                          SWAP
                            |
                    +-------+-------+
                    |               |
                    v               v
         After:   [ 5 , 2 , 3 , 4 , 1 ]
                    *               *

    CALL 2: Swap positions 1 and 3
    ==============================

         Before:  [ 5 , 2 , 3 , 4 , 1 ]
                        ^       ^
                        |       |
                        +---+---+
                            |
                          SWAP
                            |
                        +---+---+
                        |       |
                        v       v
         After:   [ 5 , 4 , 3 , 2 , 1 ]
                        *       *

    CALL 3: Base case at position 2
    ================================

         State:   [ 5 , 4 , 3 , 2 , 1 ]
                            ^
                            |
                         left=right
                            |
                        NO SWAP
                      (single element)


================================================================================
              RECURSION DEPTH AND NUMBER OF SWAPS ANALYSIS
================================================================================

    ┌──────────────────┬────────────────┬─────────────────┬──────────────────┐
    │  Array Length    │ Number of      │ Recursion       │ Base Case        │
    │       (n)        │ Swaps          │ Depth           │ Condition        │
    ├──────────────────┼────────────────┼─────────────────┼──────────────────┤
    │       1          │      0         │       1         │ left == right    │
    │       2          │      1         │       2         │ left > right     │
    │       3          │      1         │       2         │ left == right    │
    │       4          │      2         │       3         │ left > right     │
    │       5          │      2         │       3         │ left == right    │
    │       6          │      3         │       4         │ left > right     │
    │       n          │    n/2         │   n/2 + 1       │ left >= right    │
    └──────────────────┴────────────────┴─────────────────┴──────────────────┘

    FORMULA:
        - Number of swaps = floor(n/2)
        - Recursion depth = floor(n/2) + 1
        - Total recursive calls = floor(n/2) + 1


================================================================================
                 STEP-BY-STEP STATE TABLE FOR [1, 2, 3, 4, 5]
================================================================================

    ┌───────┬───────┬────────┬─────────────────────────┬───────────────────────┐
    │ Call  │ left  │ right  │  left < right?          │     Array State       │
    │   #   │       │        │  (Continue?)            │                       │
    ├───────┼───────┼────────┼─────────────────────────┼───────────────────────┤
    │   1   │   0   │   4    │  0 < 4 = YES            │ [1, 2, 3, 4, 5]       │
    │       │       │        │  Swap arr[0] <-> arr[4] │ [5, 2, 3, 4, 1]       │
    │       │       │        │  Call reverse(1, 3)     │                       │
    ├───────┼───────┼────────┼─────────────────────────┼───────────────────────┤
    │   2   │   1   │   3    │  1 < 3 = YES            │ [5, 2, 3, 4, 1]       │
    │       │       │        │  Swap arr[1] <-> arr[3] │ [5, 4, 3, 2, 1]       │
    │       │       │        │  Call reverse(2, 2)     │                       │
    ├───────┼───────┼────────┼─────────────────────────┼───────────────────────┤
    │   3   │   2   │   2    │  2 < 2 = NO (BASE CASE) │ [5, 4, 3, 2, 1]       │
    │       │       │        │  Return (no swap)       │ (unchanged)           │
    └───────┴───────┴────────┴─────────────────────────┴───────────────────────┘

    Return Path: Call 3 -> Call 2 -> Call 1 -> Main
    Final Result: [5, 4, 3, 2, 1]

================================================================================
                              DRY RUN #1
                        Array: [1, 2, 3, 4, 5]
================================================================================

Initial State:
    arr = [1, 2, 3, 4, 5]
    Call: reverse_array(arr, left=0, right=4)

+-------+------+-------+------------------------+------------------------+
| Call# | left | right |     Action             |      Array State       |
+-------+------+-------+------------------------+------------------------+
|   1   |  0   |   4   | 0 < 4? YES             | [1, 2, 3, 4, 5]       |
|       |      |       | Swap arr[0], arr[4]    |                        |
|       |      |       | 1 <-> 5                | [5, 2, 3, 4, 1]       |
|       |      |       | Recurse(1, 3)          |                        |
+-------+------+-------+------------------------+------------------------+
|   2   |  1   |   3   | 1 < 3? YES             | [5, 2, 3, 4, 1]       |
|       |      |       | Swap arr[1], arr[3]    |                        |
|       |      |       | 2 <-> 4                | [5, 4, 3, 2, 1]       |
|       |      |       | Recurse(2, 2)          |                        |
+-------+------+-------+------------------------+------------------------+
|   3   |  2   |   2   | 2 < 2? NO (BASE CASE)  | [5, 4, 3, 2, 1]       |
|       |      |       | Return                 |                        |
+-------+------+-------+------------------------+------------------------+

Call Stack Visualization:
-------------------------

    PUSH                                         POP
    ---->                                        <----

    |                    |     |                    |     |                    |
    |                    |     | reverse(2,2)      |     |                    |
    |                    | --> | reverse(1,3)      | --> | reverse(1,3)      |
    | reverse(0,4)      |     | reverse(0,4)      |     | reverse(0,4)      |
    +--------------------+     +--------------------+     +--------------------+
         Stack #1                  Stack #2                   Stack #3
                                (max depth=3)            (popping begins)

Final Result: [5, 4, 3, 2, 1]

================================================================================
                              DRY RUN #2
                        Array: [10, 20, 30, 40]
                        (Even-length array)
================================================================================

Initial State:
    arr = [10, 20, 30, 40]
    Call: reverse_array(arr, left=0, right=3)

+-------+------+-------+------------------------+---------------------------+
| Call# | left | right |     Action             |       Array State         |
+-------+------+-------+------------------------+---------------------------+
|   1   |  0   |   3   | 0 < 3? YES             | [10, 20, 30, 40]         |
|       |      |       | Swap arr[0], arr[3]    |                           |
|       |      |       | 10 <-> 40              | [40, 20, 30, 10]         |
|       |      |       | Recurse(1, 2)          |                           |
+-------+------+-------+------------------------+---------------------------+
|   2   |  1   |   2   | 1 < 2? YES             | [40, 20, 30, 10]         |
|       |      |       | Swap arr[1], arr[2]    |                           |
|       |      |       | 20 <-> 30              | [40, 30, 20, 10]         |
|       |      |       | Recurse(2, 1)          |                           |
+-------+------+-------+------------------------+---------------------------+
|   3   |  2   |   1   | 2 < 1? NO (BASE CASE)  | [40, 30, 20, 10]         |
|       |      |       | left > right           |                           |
|       |      |       | Return                 |                           |
+-------+------+-------+------------------------+---------------------------+

Notice: For EVEN-length arrays, pointers CROSS (left > right).
        For ODD-length arrays, pointers MEET (left == right).

Final Result: [40, 30, 20, 10]

================================================================================
                              DRY RUN #3
                          String: "hello"
================================================================================

Strings are immutable in Python, so we convert to list first.

Initial State:
    s = "hello" --> char_list = ['h', 'e', 'l', 'l', 'o']
    Call: reverse_array(char_list, left=0, right=4)

+-------+------+-------+------------------------+---------------------------+
| Call# | left | right |     Action             |       List State          |
+-------+------+-------+------------------------+---------------------------+
|   1   |  0   |   4   | 0 < 4? YES             | ['h','e','l','l','o']     |
|       |      |       | Swap [0] and [4]       |                           |
|       |      |       | 'h' <-> 'o'            | ['o','e','l','l','h']     |
|       |      |       | Recurse(1, 3)          |                           |
+-------+------+-------+------------------------+---------------------------+
|   2   |  1   |   3   | 1 < 3? YES             | ['o','e','l','l','h']     |
|       |      |       | Swap [1] and [3]       |                           |
|       |      |       | 'e' <-> 'l'            | ['o','l','l','e','h']     |
|       |      |       | Recurse(2, 2)          |                           |
+-------+------+-------+------------------------+---------------------------+
|   3   |  2   |   2   | 2 < 2? NO (BASE CASE)  | ['o','l','l','e','h']     |
|       |      |       | Middle 'l' stays       |                           |
|       |      |       | Return                 |                           |
+-------+------+-------+------------------------+---------------------------+

Final Result: "olleh"

Visual Trace for String:
------------------------

    "hello"
     ^   ^
     L   R     Swap 'h' and 'o'

    "oellh"
      ^ ^
      L R      Swap 'e' and 'l'

    "olleh"
       ^
      L=R      Stop! (middle character stays in place)

================================================================================
                          IMPLEMENTATION #1
                    Reverse Array (Two-Pointer Recursion)
================================================================================
"""

from typing import List


def reverse_array(arr: List[int], left: int, right: int) -> None:
    """
    Reverse an array in-place using recursion with two pointers.

    Args:
        arr: The array to reverse (modified in-place)
        left: Starting index (initially 0)
        right: Ending index (initially len(arr) - 1)

    Returns:
        None (array is modified in-place)

    Time Complexity: O(n/2) = O(n) - we process n/2 pairs
    Space Complexity: O(n/2) = O(n) - recursion stack depth
    """

    # =====================
    # BASE CASE
    # =====================
    # When pointers meet (odd length) or cross (even length),
    # we have finished reversing - nothing more to do!
    if left >= right:
        return

    # =====================
    # RECURSIVE CASE
    # =====================
    # Step 1: Swap the elements at left and right positions
    # Using Python's tuple unpacking for elegant swap
    arr[left], arr[right] = arr[right], arr[left]

    # Step 2: Recurse on the SMALLER problem
    # Move left pointer right (+1) and right pointer left (-1)
    # This shrinks the problem by 2 elements each time
    reverse_array(arr, left + 1, right - 1)


def reverse_array_wrapper(arr: List[int]) -> List[int]:
    """
    Wrapper function that provides a cleaner interface.
    User doesn't need to specify left and right indices.

    Args:
        arr: The array to reverse

    Returns:
        The same array (reversed in-place)
    """
    if len(arr) <= 1:
        return arr

    reverse_array(arr, 0, len(arr) - 1)
    return arr


"""
================================================================================
                          IMPLEMENTATION #2
                Single Parameter Recursion (Alternative Approach)
================================================================================

Sometimes interviewers ask: "Can you do it with just ONE pointer/index?"

Key Insight:
- If we know 'left', we can compute 'right' as: right = n - 1 - left
- This reduces the number of parameters!

    Index:     0    1    2    3    4
    Array:    [1,   2,   3,   4,   5]
               |                   |
             left               right = 4 - 0 = 4

    If left = 1:  right = 4 - 1 = 3
    If left = 2:  right = 4 - 2 = 2  (they meet!)

Formula: right = (n - 1) - left
================================================================================
"""


def reverse_array_single_param(arr: List[int], left: int = 0) -> None:
    """
    Reverse array using single index parameter.
    The 'right' index is computed dynamically.

    Args:
        arr: The array to reverse (modified in-place)
        left: Current left index (default 0)

    Time Complexity: O(n)
    Space Complexity: O(n) - recursion stack
    """
    n = len(arr)
    right = n - 1 - left  # Compute right from left

    # BASE CASE: pointers meet or cross
    if left >= right:
        return

    # SWAP and RECURSE
    arr[left], arr[right] = arr[right], arr[left]
    reverse_array_single_param(arr, left + 1)


"""
================================================================================
                          IMPLEMENTATION #3
                        Reverse a String Recursively
================================================================================

Challenge: Strings are IMMUTABLE in Python!
- Cannot do s[0] = 'x' (this throws an error)
- Must convert to list, reverse, then join back

Two approaches:
1. Convert to list, use array reversal, convert back
2. Build new string through recursion (less efficient but educational)

================================================================================
"""


def reverse_string_inplace(s: str) -> str:
    """
    Reverse a string using the array reversal technique.

    Args:
        s: The string to reverse

    Returns:
        Reversed string

    Time Complexity: O(n)
    Space Complexity: O(n) - for list conversion + recursion stack
    """
    if len(s) <= 1:
        return s

    # Convert string to list (now mutable)
    char_list = list(s)

    # Use our array reversal function
    reverse_array(char_list, 0, len(char_list) - 1)

    # Join back into string
    return ''.join(char_list)


def reverse_string_recursive(s: str) -> str:
    """
    Reverse string using pure recursion (building new string).

    Approach:
        reverse("hello") = reverse("ello") + "h"
                         = reverse("llo") + "e" + "h"
                         = reverse("lo") + "l" + "e" + "h"
                         = reverse("o") + "l" + "l" + "e" + "h"
                         = "o" + "l" + "l" + "e" + "h"
                         = "olleh"

    The idea:
        - Take the first character
        - Reverse the rest
        - Append the first character at the END

    Args:
        s: The string to reverse

    Returns:
        Reversed string

    Time Complexity: O(n^2) - string concatenation is O(n) in Python
    Space Complexity: O(n) - recursion stack + string copies

    Note: This is less efficient than the list-based approach!
          Use this only for learning purposes.
    """
    # BASE CASE: empty or single character
    if len(s) <= 1:
        return s

    # RECURSIVE CASE:
    # reverse(rest of string) + first character
    return reverse_string_recursive(s[1:]) + s[0]


"""
================================================================================
                    VISUALIZATION: String Recursion Tree
================================================================================

reverse_string_recursive("hello"):

    reverse("hello")
        |
        +---> reverse("ello") + "h"
                  |
                  +---> reverse("llo") + "e"
                            |
                            +---> reverse("lo") + "l"
                                      |
                                      +---> reverse("o") + "l"
                                                |
                                                +---> "o" (BASE CASE)
                                                |
                                            return "o"
                                      |
                                  return "o" + "l" = "ol"
                            |
                        return "ol" + "l" = "oll"
                  |
              return "oll" + "e" = "olle"
        |
    return "olle" + "h" = "olleh"

================================================================================
                          EDGE CASES TABLE
================================================================================

+----------------------+------------------+------------------+----------------+
|      Input           |    Expected      |   Why?           |  # of Swaps    |
+----------------------+------------------+------------------+----------------+
| []                   | []               | Empty array      |       0        |
+----------------------+------------------+------------------+----------------+
| [1]                  | [1]              | Single element   |       0        |
+----------------------+------------------+------------------+----------------+
| [1, 2]               | [2, 1]           | Two elements     |       1        |
+----------------------+------------------+------------------+----------------+
| [1, 1, 1]            | [1, 1, 1]        | All same         |       1        |
+----------------------+------------------+------------------+----------------+
| [1, 2, 3, 4, 5]      | [5, 4, 3, 2, 1]  | Odd length       |       2        |
+----------------------+------------------+------------------+----------------+
| [1, 2, 3, 4]         | [4, 3, 2, 1]     | Even length      |       2        |
+----------------------+------------------+------------------+----------------+
| ""                   | ""               | Empty string     |       0        |
+----------------------+------------------+------------------+----------------+
| "a"                  | "a"              | Single char      |       0        |
+----------------------+------------------+------------------+----------------+
| "ab"                 | "ba"             | Two chars        |       1        |
+----------------------+------------------+------------------+----------------+
| "racecar"            | "racecar"        | Palindrome       |       3        |
+----------------------+------------------+------------------+----------------+

================================================================================
                      COMPLEXITY ANALYSIS
================================================================================

Two-Pointer Recursive Approach:
-------------------------------

TIME COMPLEXITY: O(n)
- We make n/2 recursive calls (pointers move from both ends)
- Each call does O(1) work (one swap)
- Total: O(n/2) = O(n)

SPACE COMPLEXITY: O(n)
- Recursion stack depth = n/2 calls
- Each call uses O(1) space
- Total stack space: O(n/2) = O(n)

    Memory Stack Visualization (for array of size 5):

    |                    |
    | reverse(2, 2)      |  <-- 3rd call (base case)
    | reverse(1, 3)      |  <-- 2nd call
    | reverse(0, 4)      |  <-- 1st call
    +--------------------+

    Stack depth = 3 = ceil(5/2) = O(n/2) = O(n)


Pure String Recursion Approach:
-------------------------------

TIME COMPLEXITY: O(n^2)
- n recursive calls
- Each call creates a new string via slicing s[1:] which is O(n)
- Total: O(n) * O(n) = O(n^2)

SPACE COMPLEXITY: O(n^2)
- Recursion stack: O(n)
- String copies at each level: O(n) + O(n-1) + ... + O(1) = O(n^2)

This is why the list-based approach is preferred!

================================================================================
                    ITERATIVE VS RECURSIVE COMPARISON
================================================================================

+------------------+-------------------+-------------------+
|    Aspect        |    Recursive      |    Iterative      |
+------------------+-------------------+-------------------+
| Time Complexity  |      O(n)         |       O(n)        |
+------------------+-------------------+-------------------+
| Space Complexity |      O(n)         |       O(1)        |
|                  |  (call stack)     |                   |
+------------------+-------------------+-------------------+
| Code Simplicity  |     Elegant       |   Also simple     |
+------------------+-------------------+-------------------+
| Stack Overflow   |  Risk for large n |      No risk      |
|     Risk         |                   |                   |
+------------------+-------------------+-------------------+
| Interview Value  | Shows recursion   | Shows efficiency  |
|                  | understanding     | awareness         |
+------------------+-------------------+-------------------+

Iterative version (for reference):

    def reverse_array_iterative(arr):
        left, right = 0, len(arr) - 1
        while left < right:
            arr[left], arr[right] = arr[right], arr[left]
            left += 1
            right -= 1
        return arr

================================================================================
                          KEY TAKEAWAYS
================================================================================

1. TWO-POINTER TECHNIQUE
   - Perfect for problems involving both ends of an array/string
   - Pointers move toward each other (shrinking the problem)
   - Base case: pointers meet or cross

2. SHRINKING PROBLEM PATTERN
   - Each recursive call works on a SMALLER portion
   - Problem size decreases by 2 each time (both pointers move)
   - Eventually reaches trivial case (0 or 1 element)

3. IN-PLACE MODIFICATION
   - Arrays are mutable in Python - can modify directly
   - Strings are IMMUTABLE - must convert to list first
   - In-place = O(1) extra space (ignoring recursion stack)

4. BASE CASE IDENTIFICATION
   - For two pointers: left >= right
   - Handles BOTH odd (meet) and even (cross) length arrays
   - Single condition covers both cases!

5. RECURSION STACK OVERHEAD
   - Recursive solution uses O(n) stack space
   - Iterative solution uses O(1) space
   - For very large arrays, iterative is safer (no stack overflow)

6. INTERVIEW TIPS
   - Start with the recursive solution (shows recursion skills)
   - Mention the iterative alternative (shows awareness)
   - Discuss trade-offs (space vs. conceptual simplicity)
   - Handle edge cases (empty, single element)

================================================================================
                          RELATED PROBLEMS
================================================================================

After mastering this, try these problems:

1. Rotate Array by K positions (use reverse as a building block!)
2. Reverse Words in a String
3. Reverse Linked List (same two-pointer concept)
4. Check if Array is Palindrome (similar traversal)
5. Reverse only vowels in a string

================================================================================
                              TEST CODE
================================================================================
"""


def test_reverse_functions():
    """Test all reverse implementations."""

    print("=" * 60)
    print("TESTING REVERSE ARRAY FUNCTIONS")
    print("=" * 60)

    # Test 1: Basic odd-length array
    arr1 = [1, 2, 3, 4, 5]
    print(f"\nTest 1: {arr1}")
    reverse_array(arr1, 0, len(arr1) - 1)
    print(f"After reverse_array: {arr1}")
    assert arr1 == [5, 4, 3, 2, 1], "Test 1 Failed!"
    print("PASSED!")

    # Test 2: Even-length array
    arr2 = [10, 20, 30, 40]
    print(f"\nTest 2: {arr2}")
    reverse_array(arr2, 0, len(arr2) - 1)
    print(f"After reverse_array: {arr2}")
    assert arr2 == [40, 30, 20, 10], "Test 2 Failed!"
    print("PASSED!")

    # Test 3: Single element
    arr3 = [42]
    print(f"\nTest 3: {arr3}")
    reverse_array(arr3, 0, len(arr3) - 1)
    print(f"After reverse_array: {arr3}")
    assert arr3 == [42], "Test 3 Failed!"
    print("PASSED!")

    # Test 4: Two elements
    arr4 = [1, 2]
    print(f"\nTest 4: {arr4}")
    reverse_array(arr4, 0, len(arr4) - 1)
    print(f"After reverse_array: {arr4}")
    assert arr4 == [2, 1], "Test 4 Failed!"
    print("PASSED!")

    # Test 5: Empty array
    arr5 = []
    print(f"\nTest 5: {arr5}")
    if len(arr5) > 0:
        reverse_array(arr5, 0, len(arr5) - 1)
    print(f"After reverse_array: {arr5}")
    assert arr5 == [], "Test 5 Failed!"
    print("PASSED!")

    # Test 6: Wrapper function
    arr6 = [1, 2, 3, 4, 5]
    print(f"\nTest 6 (wrapper): {arr6}")
    result6 = reverse_array_wrapper(arr6)
    print(f"After reverse_array_wrapper: {result6}")
    assert result6 == [5, 4, 3, 2, 1], "Test 6 Failed!"
    print("PASSED!")

    # Test 7: Single parameter version
    arr7 = [1, 2, 3, 4, 5]
    print(f"\nTest 7 (single param): {arr7}")
    reverse_array_single_param(arr7)
    print(f"After reverse_array_single_param: {arr7}")
    assert arr7 == [5, 4, 3, 2, 1], "Test 7 Failed!"
    print("PASSED!")

    print("\n" + "=" * 60)
    print("TESTING REVERSE STRING FUNCTIONS")
    print("=" * 60)

    # Test 8: String reversal (in-place method)
    s1 = "hello"
    print(f"\nTest 8: '{s1}'")
    result8 = reverse_string_inplace(s1)
    print(f"After reverse_string_inplace: '{result8}'")
    assert result8 == "olleh", "Test 8 Failed!"
    print("PASSED!")

    # Test 9: String reversal (pure recursion)
    s2 = "world"
    print(f"\nTest 9: '{s2}'")
    result9 = reverse_string_recursive(s2)
    print(f"After reverse_string_recursive: '{result9}'")
    assert result9 == "dlrow", "Test 9 Failed!"
    print("PASSED!")

    # Test 10: Palindrome string
    s3 = "racecar"
    print(f"\nTest 10: '{s3}'")
    result10 = reverse_string_inplace(s3)
    print(f"After reverse_string_inplace: '{result10}'")
    assert result10 == "racecar", "Test 10 Failed!"
    print("PASSED!")

    # Test 11: Empty string
    s4 = ""
    print(f"\nTest 11: '{s4}'")
    result11 = reverse_string_inplace(s4)
    print(f"After reverse_string_inplace: '{result11}'")
    assert result11 == "", "Test 11 Failed!"
    print("PASSED!")

    # Test 12: Single character
    s5 = "x"
    print(f"\nTest 12: '{s5}'")
    result12 = reverse_string_recursive(s5)
    print(f"After reverse_string_recursive: '{result12}'")
    assert result12 == "x", "Test 12 Failed!"
    print("PASSED!")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


if __name__ == "__main__":
    test_reverse_functions()
