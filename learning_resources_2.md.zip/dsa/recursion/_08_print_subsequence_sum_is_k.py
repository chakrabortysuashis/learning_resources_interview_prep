"""
================================================================================
           SUBSEQUENCE SUM PROBLEMS - A COMPREHENSIVE GUIDE
================================================================================

Problems Covered:
1. Print ALL subsequences of an array whose sum equals k
2. Print only the FIRST subsequence of an array whose sum equals k
3. COUNT all subsequences of an array whose sum equals k

These problems demonstrate the fundamental "Take/Not-Take" recursion pattern,
which is one of the most important patterns in DSA interviews.

================================================================================
                    SECTION 1: WHAT IS A SUBSEQUENCE?
================================================================================

DEFINITION:
-----------
A subsequence is a sequence derived from another sequence by deleting some
or no elements WITHOUT changing the ORDER of remaining elements.

Example: arr = [1, 2, 3]

All Subsequences:
    []        - empty (delete all)
    [1]       - keep 1, delete 2,3
    [2]       - keep 2, delete 1,3
    [3]       - keep 3, delete 1,2
    [1, 2]    - keep 1,2, delete 3
    [1, 3]    - keep 1,3, delete 2  (ORDER PRESERVED: 1 comes before 3)
    [2, 3]    - keep 2,3, delete 1
    [1, 2, 3] - keep all


VISUAL: How subsequences maintain order
---------------------------------------
    Original:    [1, 2, 3]
                  |  |  |

    [1, 3]:      [1, _, 3]   <- Valid! Order preserved (1 before 3)

    [3, 1]:      NOT a subsequence! Order violated (3 cannot come before 1)


================================================================================
    SUBSEQUENCE vs SUBARRAY vs SUBSET - KEY DIFFERENCES
================================================================================

For arr = [1, 2, 3]:

    +-------------+------------------+-------------------+------------------+
    |   Type      |    Definition    |     Examples      |      Count       |
    +-------------+------------------+-------------------+------------------+
    | SUBARRAY    | Contiguous       | [1], [1,2],       | n*(n+1)/2 + 1    |
    |             | elements         | [2,3], [1,2,3]    | (including [])   |
    |             |                  | NOT [1,3]         |                  |
    +-------------+------------------+-------------------+------------------+
    | SUBSEQUENCE | Order preserved, | [1], [1,3], [2,3] | 2^n              |
    |             | not necessarily  | [], [1,2,3]       |                  |
    |             | contiguous       | ALL combos OK     |                  |
    +-------------+------------------+-------------------+------------------+
    | SUBSET      | Any combination, | Same as           | 2^n              |
    |             | order doesn't    | subsequence but   | (same count,     |
    |             | matter           | {1,3} == {3,1}    |  different view) |
    +-------------+------------------+-------------------+------------------+

Key Insight:
- Subsequence cares about ORDER (sequence)
- Subset doesn't care about order (set)
- Both have 2^n possibilities


WHY 2^n SUBSEQUENCES?
---------------------
For each element, we have 2 choices: TAKE it or NOT TAKE it

    arr = [1, 2, 3]
           |  |  |
           v  v  v
    Choices: 2  2  2  = 2 * 2 * 2 = 2^3 = 8 subsequences

This "Take/Not-Take" pattern is the CORE of our recursion!


================================================================================
                SECTION 2: THE TAKE/NOT-TAKE PATTERN
================================================================================

This is one of the MOST IMPORTANT recursion patterns in DSA!

CORE IDEA:
----------
At every index, we make a binary decision:
    - TAKE: Include current element in subsequence
    - NOT TAKE: Skip current element

This creates a BINARY TREE structure where:
    - Each level represents an element
    - Left branch = NOT TAKE
    - Right branch = TAKE
    - Leaves = all possible subsequences


VISUAL: Decision Tree for arr = [1, 2, 3]
-----------------------------------------

                                    []
                                  index=0
                                 element=1
                                /          \
                     NOT TAKE /            \ TAKE
                             /              \
                           []              [1]
                         index=1          index=1
                        element=2        element=2
                        /      \          /      \
                       /        \        /        \
                     []        [2]     [1]      [1,2]
                   index=2    index=2  index=2  index=2
                  element=3  element=3 element=3 element=3
                  /    \      /    \    /    \    /     \
                 /      \    /      \  /      \  /       \
               []      [3] [2]   [2,3][1]  [1,3][1,2] [1,2,3]

               ^------------ ALL 8 SUBSEQUENCES (2^3) ------------^


PATTERN TEMPLATE:
-----------------
```
def solve(index, current_subsequence, ...other_params...):
    # BASE CASE: reached end of array
    if index == len(arr):
        # Process the current subsequence
        return

    # CHOICE 1: NOT TAKE current element
    solve(index + 1, current_subsequence, ...other_params...)

    # CHOICE 2: TAKE current element
    current_subsequence.append(arr[index])
    solve(index + 1, current_subsequence, ...other_params...)
    current_subsequence.pop()  # BACKTRACK - remove after exploring
```

The BACKTRACK step (pop) is crucial - it restores state after exploring
the "take" branch so we can explore other branches correctly.


================================================================================
    PROBLEM 1: PRINT ALL SUBSEQUENCES WITH SUM = K
================================================================================

PROBLEM STATEMENT:
------------------
Given an array arr[] and an integer k, print all subsequences whose
elements sum up to exactly k.

Example:
    arr = [1, 2, 1], k = 2

    Output:
        [1, 1]  (indices 0 and 2)
        [2]     (index 1)


APPROACH:
---------
1. Use the Take/Not-Take pattern
2. Track current sum along with current subsequence
3. At base case (index == n), check if sum == k
4. If yes, print the subsequence
5. Explore ALL branches (no early termination)


DECISION TREE FOR arr = [1, 2, 1], k = 2:
-----------------------------------------

Legend: (subsequence, sum)

                                      ([], 0)
                                       idx=0
                                      elem=1
                                    /        \
                         NOT TAKE /          \ TAKE
                                 /            \
                           ([], 0)          ([1], 1)
                            idx=1             idx=1
                           elem=2            elem=2
                          /      \          /       \
                         /        \        /         \
                    ([], 0)    ([2], 2)  ([1], 1)  ([1,2], 3)
                     idx=2      idx=2     idx=2      idx=2
                    elem=1     elem=1    elem=1     elem=1
                   /     \     /    \    /    \     /     \
                  /       \   /      \  /      \   /       \
            ([], 0)  ([1], 1) ([2],2)([2,1],3)([1],1)([1,1],2)([1,2],3)([1,2,1],4)
            sum=0    sum=1   sum=2   sum=3   sum=1   sum=2    sum=3     sum=4
              X        X      YES      X       X      YES       X         X

    Valid subsequences found: [2] and [1, 1]


DRY RUN 1: arr = [1, 2, 1], k = 2
---------------------------------

Call Stack Visualization (depth shown by indentation):

solve(idx=0, subseq=[], sum=0)
|
|-- NOT TAKE arr[0]=1
|   solve(idx=1, subseq=[], sum=0)
|   |
|   |-- NOT TAKE arr[1]=2
|   |   solve(idx=2, subseq=[], sum=0)
|   |   |
|   |   |-- NOT TAKE arr[2]=1
|   |   |   solve(idx=3, subseq=[], sum=0)
|   |   |   BASE CASE: idx==3, sum=0 != k=2, DO NOT PRINT
|   |   |
|   |   |-- TAKE arr[2]=1, subseq=[1]
|   |   |   solve(idx=3, subseq=[1], sum=1)
|   |   |   BASE CASE: idx==3, sum=1 != k=2, DO NOT PRINT
|   |   |   BACKTRACK: pop 1, subseq=[]
|   |
|   |-- TAKE arr[1]=2, subseq=[2]
|       solve(idx=2, subseq=[2], sum=2)
|       |
|       |-- NOT TAKE arr[2]=1
|       |   solve(idx=3, subseq=[2], sum=2)
|       |   BASE CASE: idx==3, sum=2 == k=2, PRINT [2]  <-- FOUND!
|       |
|       |-- TAKE arr[2]=1, subseq=[2,1]
|           solve(idx=3, subseq=[2,1], sum=3)
|           BASE CASE: idx==3, sum=3 != k=2, DO NOT PRINT
|           BACKTRACK: pop 1, subseq=[2]
|       BACKTRACK: pop 2, subseq=[]
|
|-- TAKE arr[0]=1, subseq=[1]
    solve(idx=1, subseq=[1], sum=1)
    |
    |-- NOT TAKE arr[1]=2
    |   solve(idx=2, subseq=[1], sum=1)
    |   |
    |   |-- NOT TAKE arr[2]=1
    |   |   solve(idx=3, subseq=[1], sum=1)
    |   |   BASE CASE: idx==3, sum=1 != k=2, DO NOT PRINT
    |   |
    |   |-- TAKE arr[2]=1, subseq=[1,1]
    |       solve(idx=3, subseq=[1,1], sum=2)
    |       BASE CASE: idx==3, sum=2 == k=2, PRINT [1, 1]  <-- FOUND!
    |       BACKTRACK: pop 1, subseq=[1]
    |
    |-- TAKE arr[1]=2, subseq=[1,2]
        solve(idx=2, subseq=[1,2], sum=3)
        |
        |-- NOT TAKE arr[2]=1
        |   solve(idx=3, subseq=[1,2], sum=3)
        |   BASE CASE: idx==3, sum=3 != k=2, DO NOT PRINT
        |
        |-- TAKE arr[2]=1, subseq=[1,2,1]
            solve(idx=3, subseq=[1,2,1], sum=4)
            BASE CASE: idx==3, sum=4 != k=2, DO NOT PRINT
            BACKTRACK: pop 1, subseq=[1,2]
        BACKTRACK: pop 2, subseq=[1]
    BACKTRACK: pop 1, subseq=[]

RESULT: Printed [2] and [1, 1]


DRY RUN 2: arr = [2, 3, 1], k = 4
---------------------------------

Let's trace more concisely, focusing on successful paths:

All paths explored:
    []         sum=0  X
    [1]        sum=1  X
    [3]        sum=3  X
    [3,1]      sum=4  YES -> PRINT [3, 1]
    [2]        sum=2  X
    [2,1]      sum=3  X
    [2,3]      sum=5  X
    [2,3,1]    sum=6  X

Note: Due to NOT-TAKE first recursion order, [3,1] prints before any [2,...] combo

RESULT: Printed [3, 1]

Wait, let me recalculate. arr = [2, 3, 1]
    []         sum=0  X
    [1]        sum=1  X  (only index 2)
    [3]        sum=3  X  (only index 1)
    [3,1]      sum=4  YES -> PRINT [3, 1]
    [2]        sum=2  X  (only index 0)
    [2,1]      sum=3  X  (indices 0,2)
    [2,3]      sum=5  X  (indices 0,1)
    [2,3,1]    sum=6  X  (all indices)

RESULT: Printed [3, 1]


# ================================================================================
#                    COMPREHENSIVE RECURSION TREE VISUALIZATIONS
# ================================================================================
#
# This section provides detailed ASCII art recursion trees that show:
#   1. The TAKE/NOT-TAKE decision pattern at each node
#   2. (index, current_sum, current_path) state at each node
#   3. PRUNING opportunities when sum exceeds target
#   4. SUCCESS markers for paths that find the target sum
#   5. BACKTRACKING flow when returning from recursive calls
#
# ================================================================================
#             RECURSION TREE 1: arr=[1,2,3], target=3 (COMPLETE TREE)
# ================================================================================
#
# Legend:
#   - Each node shows: (idx, sum, path)
#   - [FOUND!] = Successfully found target sum
#   - [X] = Path did not achieve target
#   - Arrows show TAKE (include element) or NOT TAKE (skip element) decisions
#
#                                        (idx=0, sum=0, [])
#                                         Considering: 1
#                                        /              \
#                            NOT TAKE 1                  TAKE 1
#                                  /                          \
#                     (idx=1, sum=0, [])                (idx=1, sum=1, [1])
#                       Considering: 2                    Considering: 2
#                      /              \                  /              \
#              NOT TAKE 2          TAKE 2        NOT TAKE 2          TAKE 2
#                   /                  \              /                  \
#        (idx=2, sum=0, [])    (idx=2, sum=2, [2])  (idx=2, sum=1, [1])  (idx=2, sum=3, [1,2])
#          Considering: 3        Considering: 3      Considering: 3       Considering: 3
#           /        \            /        \          /        \           /        \
#      NOT TAKE    TAKE 3   NOT TAKE    TAKE 3   NOT TAKE   TAKE 3   NOT TAKE    TAKE 3
#        3                    3                    3                   3
#         |           |        |           |        |          |        |           |
#         v           v        v           v        v          v        v           v
#    (idx=3,     (idx=3,   (idx=3,    (idx=3,   (idx=3,   (idx=3,   (idx=3,    (idx=3,
#     sum=0,      sum=3,    sum=2,     sum=5,    sum=1,    sum=4,    sum=3,     sum=6,
#     [])         [3])      [2])       [2,3])    [1])      [1,3])    [1,2])     [1,2,3])
#       |           |         |          |         |         |         |           |
#      [X]      [FOUND!]     [X]        [X]       [X]       [X]     [FOUND!]       [X]
#    sum!=3     sum==3     sum!=3    sum!=3    sum!=3    sum!=3     sum==3      sum!=3
#
#
# FOUND SUBSEQUENCES WITH SUM = 3:
#   1. [3]   -> Path: NOT TAKE 1 -> NOT TAKE 2 -> TAKE 3
#   2. [1,2] -> Path: TAKE 1 -> TAKE 2 -> NOT TAKE 3
#
# ================================================================================
#
#
# ================================================================================
#         RECURSION TREE 2: arr=[1,2,1], target=2 (WITH BACKTRACKING TRACE)
# ================================================================================
#
# This tree shows the same example from the problem but with explicit
# backtracking annotations to show how the algorithm explores all paths.
#
#                                    (idx=0, sum=0, [])
#                                     element arr[0] = 1
#                                    /                  \
#                        NOT TAKE 1                      TAKE 1
#                        (stay [])                       (add 1 to path)
#                              |                              |
#                              v                              v
#                    (idx=1, sum=0, [])              (idx=1, sum=1, [1])
#                     element arr[1] = 2              element arr[1] = 2
#                    /                \              /                \
#            NOT TAKE 2           TAKE 2      NOT TAKE 2          TAKE 2
#                  |                  |            |                  |
#                  v                  v            v                  v
#          (idx=2,sum=0,[])   (idx=2,sum=2,[2])  (idx=2,sum=1,[1])  (idx=2,sum=3,[1,2])
#          arr[2] = 1          arr[2] = 1        arr[2] = 1         arr[2] = 1
#          /        \          /        \        /        \         /        \
#     NOT TAKE   TAKE 1   NOT TAKE  TAKE 1  NOT TAKE  TAKE 1   NOT TAKE   TAKE 1
#         |         |         |         |       |         |        |          |
#         v         v         v         v       v         v        v          v
#     (sum=0)   (sum=1)   (sum=2)  (sum=3)  (sum=1)   (sum=2)  (sum=3)    (sum=4)
#       []       [1]       [2]     [2,1]     [1]      [1,1]    [1,2]     [1,2,1]
#       [X]      [X]     [FOUND!]   [X]      [X]     [FOUND!]   [X]        [X]
#
#
# EXECUTION ORDER (DFS - Depth First Search):
# -------------------------------------------
# The algorithm explores in this order (NOT TAKE branch first):
#
#   Step 1:  [] -> [] -> [] -> []           sum=0  [X]
#   Step 2:  [] -> [] -> [] -> [1]          sum=1  [X]    (backtrack, pop 1)
#   Step 3:  [] -> [] -> [2] -> [2]         sum=2  [FOUND!] Print: [2]
#   Step 4:  [] -> [] -> [2] -> [2,1]       sum=3  [X]    (backtrack, pop 1)
#                                                          (backtrack, pop 2)
#   Step 5:  [] -> [1] -> [1] -> [1]        sum=1  [X]
#   Step 6:  [] -> [1] -> [1] -> [1,1]      sum=2  [FOUND!] Print: [1,1]
#                                                          (backtrack, pop 1)
#   Step 7:  [] -> [1] -> [1,2] -> [1,2]    sum=3  [X]
#   Step 8:  [] -> [1] -> [1,2] -> [1,2,1]  sum=4  [X]    (backtrack to root)
#
# RESULT: Printed [2] and [1,1]
#
#
# ================================================================================
#         RECURSION TREE 3: arr=[2,5,3], target=5 (SHOWING PRUNING POTENTIAL)
# ================================================================================
#
# Note: Basic algorithm explores all paths. With PRUNING (for positive numbers),
# we can skip branches where sum already exceeds target!
#
#                                    (idx=0, sum=0, [])
#                                     arr[0] = 2
#                                    /              \
#                        NOT TAKE 2                  TAKE 2
#                              |                          |
#                              v                          v
#                    (idx=1, sum=0, [])           (idx=1, sum=2, [2])
#                     arr[1] = 5                    arr[1] = 5
#                    /            \                /            \
#            NOT TAKE 5        TAKE 5      NOT TAKE 5        TAKE 5
#                  |               |             |               |
#                  v               v             v               v
#           (idx=2,sum=0,[])  (idx=2,sum=5,[5]) (idx=2,sum=2,[2]) (idx=2,sum=7,[2,5])
#            arr[2] = 3        arr[2] = 3       arr[2] = 3        arr[2] = 3
#            /       \         /       \        /       \         /       \
#       NOT    TAKE   NOT    TAKE  NOT    TAKE   NOT    TAKE
#       TAKE 3  3    TAKE 3   3   TAKE 3   3    TAKE 3   3
#         |      |     |      |     |      |      |       |
#         v      v     v      v     v      v      v       v
#      (sum=0) (sum=3) (sum=5) (sum=8) (sum=2) (sum=5) (sum=7) (sum=10)
#        []     [3]    [5]    [5,3]   [2]    [2,3]  [2,5]  [2,5,3]
#        [X]    [X]  [FOUND!]  [X]    [X]   [FOUND!] [X]     [X]
#
#
# FOUND SUBSEQUENCES WITH SUM = 5:
#   1. [5]   -> NOT TAKE 2 -> TAKE 5 -> NOT TAKE 3
#   2. [2,3] -> TAKE 2 -> NOT TAKE 5 -> TAKE 3
#
#
# ================================================================================
#         RECURSION TREE 4: arr=[1,2,3,4], target=5 (LARGER EXAMPLE)
# ================================================================================
#
# For larger arrays, we show a condensed tree focusing on SUCCESSFUL paths:
#
#                                    (idx=0, sum=0, [])
#                                    /              \
#                        NOT TAKE 1                  TAKE 1
#                              |                          |
#                    (idx=1, sum=0, [])           (idx=1, sum=1, [1])
#                    /              \              /              \
#            NOT TAKE 2          TAKE 2    NOT TAKE 2          TAKE 2
#                  |                |            |                  |
#           (sum=0,[])        (sum=2,[2])   (sum=1,[1])       (sum=3,[1,2])
#                  :                :            :                  :
#                  :                :            :                  :
#
# (Continuing to show only paths leading to sum=5...)
#
# SUCCESSFUL PATHS (sum = 5):
#
#   PATH 1: [5]
#   ---------
#   (0,[]) --NOT TAKE 1--> (1,[]) --NOT TAKE 2--> (2,[]) --NOT TAKE 3--> (3,[])
#                                                                         |
#                                                              --TAKE 4--> No wait, 4 < 5
#
#   Let me redo with arr=[1,2,3,4], target=5:
#
#   PATH 1: [1,4]
#   -------------
#   (idx=0,[]) --TAKE 1--> (idx=1,[1]) --NOT TAKE 2--> (idx=2,[1]) --NOT TAKE 3-->
#   (idx=3,[1]) --TAKE 4--> (idx=4,[1,4]) sum=5 [FOUND!]
#
#   PATH 2: [2,3]
#   -------------
#   (idx=0,[]) --NOT TAKE 1--> (idx=1,[]) --TAKE 2--> (idx=2,[2]) --TAKE 3-->
#   (idx=3,[2,3]) --NOT TAKE 4--> (idx=4,[2,3]) sum=5 [FOUND!]
#
#   PATH 3: [5]
#   -----------
#   Wait, there's no 5 in [1,2,3,4]. Let me recalculate...
#
#   All paths with sum=5 from arr=[1,2,3,4]:
#     [1,4] = 1+4 = 5  [FOUND!]
#     [2,3] = 2+3 = 5  [FOUND!]
#
#
# ================================================================================
#      RECURSION TREE 5: arr=[3,4,5,2], target=9 (MULTIPLE SOLUTIONS)
# ================================================================================
#
# This example shows how multiple valid paths can exist in the tree.
#
# All subsequences and their sums:
#   []        = 0
#   [3]       = 3
#   [4]       = 4
#   [5]       = 5
#   [2]       = 2
#   [3,4]     = 7
#   [3,5]     = 8
#   [3,2]     = 5
#   [4,5]     = 9  --> [FOUND!]
#   [4,2]     = 6
#   [5,2]     = 7
#   [3,4,5]   = 12
#   [3,4,2]   = 9  --> [FOUND!]
#   [3,5,2]   = 10
#   [4,5,2]   = 11
#   [3,4,5,2] = 14
#
# TREE SHOWING PATHS TO sum=9:
#
#                                (idx=0, sum=0, [])
#                                      arr[0]=3
#                               /                    \
#                   NOT TAKE 3                        TAKE 3
#                        |                                |
#               (idx=1, sum=0, [])                (idx=1, sum=3, [3])
#                    arr[1]=4                          arr[1]=4
#               /              \                  /              \
#       NOT TAKE 4          TAKE 4        NOT TAKE 4          TAKE 4
#            |                  |              |                  |
#     (idx=2,sum=0,[])  (idx=2,sum=4,[4])  (idx=2,sum=3,[3]) (idx=2,sum=7,[3,4])
#         arr[2]=5          arr[2]=5         arr[2]=5          arr[2]=5
#          /    \            /    \           /    \            /    \
#         ..    ..          ..    ..         ..    ..          ..    ..
#                            |                                  |
#                        TAKE 5                             TAKE 2
#                            |                             (at idx=3)
#                            v                                  |
#                   (idx=3,sum=9,[4,5])                        v
#                   [FOUND!] sum=9                    (idx=4,sum=9,[3,4,2])
#                   PRINT: [4,5]                      [FOUND!] sum=9
#                                                     PRINT: [3,4,2]
#
#
# ================================================================================
#           RECURSION TREE WITH PRUNING (OPTIMIZATION FOR POSITIVE NUMBERS)
# ================================================================================
#
# When all array elements are POSITIVE, we can PRUNE branches where:
#   current_sum > target (we've already exceeded, no point continuing)
#
# Example: arr=[3,5,7], target=6
#
# WITHOUT PRUNING (explores all 8 paths):
# ----------------------------------------
#                                (idx=0, sum=0, [])
#                               /                \
#                   NOT TAKE 3                    TAKE 3
#                        |                            |
#               (idx=1,sum=0,[])              (idx=1,sum=3,[3])
#               /            \                /            \
#       NOT TAKE 5       TAKE 5       NOT TAKE 5       TAKE 5
#            |               |             |               |
#     (idx=2,sum=0,[])  (idx=2,sum=5,[5]) (idx=2,sum=3,[3]) (idx=2,sum=8,[3,5])
#       /      \          /      \         /      \          /      \
#     ...     ...       ...     ...      ...     ...       ...     ...
#      |       |         |       |        |       |         |       |
#   sum=0   sum=7     sum=5   sum=12   sum=3   sum=10    sum=8   sum=15
#    [X]     [X]       [X]     [X]      [X]     [X]       [X]     [X]
#
# No valid subsequences! All 8 leaf nodes explored.
#
#
# WITH PRUNING (stops early when sum > target):
# ----------------------------------------------
#                                (idx=0, sum=0, [])
#                               /                \
#                   NOT TAKE 3                    TAKE 3
#                        |                            |
#               (idx=1,sum=0,[])              (idx=1,sum=3,[3])
#               /            \                /            \
#       NOT TAKE 5       TAKE 5       NOT TAKE 5       TAKE 5
#            |               |             |               |
#     (idx=2,sum=0,[])  (idx=2,sum=5,[5]) (idx=2,sum=3,[3]) (idx=2,sum=8,[3,5])
#       /      \          /      \         /      \              |
#     ...     ...       ...     ...      ...     ...         [PRUNED!]
#                                                          sum=8 > target=6
#                                                          Don't explore further!
#
# Pruning saves exploring the subtree under (idx=2,sum=8,[3,5])!
#
#
# ================================================================================
#               KEY INSIGHTS FROM RECURSION TREE ANALYSIS
# ================================================================================
#
# 1. TREE STRUCTURE:
#    - Binary tree with 2^n leaf nodes (all possible subsequences)
#    - Each level represents a decision for one array element
#    - Left branch = NOT TAKE, Right branch = TAKE
#
# 2. STATE AT EACH NODE:
#    - index: Which element we're deciding on
#    - sum: Running sum of elements taken so far
#    - path: List of elements included in current subsequence
#
# 3. BASE CASE (Leaf Nodes):
#    - When index == len(arr), we've made all decisions
#    - Check if sum == target to determine success
#
# 4. BACKTRACKING:
#    - After exploring TAKE branch, we POP the element
#    - This restores state before exploring NOT TAKE branch of parent
#    - Critical for correct exploration of all paths!
#
# 5. PRUNING OPPORTUNITIES:
#    - If sum > target AND all elements are positive, we can stop
#    - Early termination saves exploring entire subtrees
#
# 6. ORDER OF EXPLORATION:
#    - DFS explores NOT TAKE first, then TAKE
#    - This determines the order in which solutions are found
#
# ================================================================================
"""


# ============================================================================
#           IMPLEMENTATION 1: PRINT ALL SUBSEQUENCES WITH SUM = K
# ============================================================================

def print_all_subsequences_with_sum_k(arr: list, k: int) -> None:
    """
    Print all subsequences of arr whose elements sum to exactly k.

    Uses the Take/Not-Take pattern to explore all 2^n subsequences.

    Args:
        arr: Input array of integers
        k: Target sum

    Time Complexity: O(2^n) - we explore all 2^n subsequences
    Space Complexity: O(n) - recursion depth + subsequence storage
    """
    n = len(arr)
    result = []  # To store all valid subsequences (optional, for returning)

    def solve(index: int, current_subseq: list, current_sum: int) -> None:
        """
        Recursive helper function.

        Args:
            index: Current position in array (0 to n)
            current_subseq: Elements picked so far
            current_sum: Sum of elements in current_subseq
        """
        # BASE CASE: We've processed all elements
        if index == n:
            # Check if current subsequence has sum equal to k
            if current_sum == k:
                print(current_subseq.copy())  # Print valid subsequence
                result.append(current_subseq.copy())  # Also store it
            return  # End this branch

        # RECURSIVE CASE: Make a decision for arr[index]

        # CHOICE 1: NOT TAKE - skip arr[index]
        # Don't add to subsequence, don't add to sum, move to next index
        solve(index + 1, current_subseq, current_sum)

        # CHOICE 2: TAKE - include arr[index]
        current_subseq.append(arr[index])      # Add to subsequence
        solve(index + 1, current_subseq, current_sum + arr[index])
        current_subseq.pop()                    # BACKTRACK: remove after exploring

    # Start recursion from index 0, empty subsequence, sum 0
    print(f"Finding all subsequences with sum = {k} in {arr}:")
    print("-" * 50)
    solve(0, [], 0)
    print("-" * 50)
    print(f"Total found: {len(result)}")
    return result


"""
================================================================================
    PROBLEM 2: PRINT ONLY THE FIRST SUBSEQUENCE WITH SUM = K
================================================================================

PROBLEM STATEMENT:
------------------
Given an array arr[] and an integer k, print ONLY THE FIRST subsequence
whose elements sum up to exactly k, then STOP searching.

Example:
    arr = [1, 2, 1], k = 2

    Output: [2]  (just the first one found, stop immediately)


KEY DIFFERENCE FROM PROBLEM 1:
------------------------------
- Problem 1: Explore ALL branches, find ALL valid subsequences
- Problem 2: Stop as soon as we find ONE valid subsequence

To achieve early termination, we use RETURN VALUE:
- Return True if a valid subsequence was found (signal to stop)
- Return False if not found yet (continue searching)


OPTIMIZATION INSIGHT:
---------------------
Without early termination:
    Time = O(2^n) always

With early termination:
    Best case = O(1) if first element equals k
    Worst case = O(2^n) if valid subsequence is last or doesn't exist
    Average = Much better in practice!


DECISION TREE WITH EARLY TERMINATION:
-------------------------------------

For arr = [1, 2, 1], k = 2:

                                      ([], 0)
                                       idx=0
                                    /        \
                         NOT TAKE /          \ TAKE
                                 /            \
                           ([], 0)          ([1], 1)
                            idx=1             idx=1
                          /      \              |
                         /        \             | (this branch NOT explored
                    ([], 0)    ([2], 2)         |  because we found answer)
                     idx=2      idx=2           |
                       |       /    \           |
                       |      /      \          |
                       |  ([2],2)    ...        |
                       |   sum=2                |
                       |   FOUND!               |
                       |   STOP! <--------------+
                       |
                    (still explored because NOT-TAKE comes first)

In our recursion order (NOT-TAKE first), we find [2] and immediately stop.
The entire right subtree of root (TAKE path for index 0) is NEVER explored!


DRY RUN 1: arr = [1, 2, 1], k = 2
---------------------------------

solve(idx=0, subseq=[], sum=0)
|
|-- NOT TAKE arr[0]=1
|   solve(idx=1, subseq=[], sum=0)
|   |
|   |-- NOT TAKE arr[1]=2
|   |   solve(idx=2, subseq=[], sum=0)
|   |   |
|   |   |-- NOT TAKE arr[2]=1
|   |   |   solve(idx=3, subseq=[], sum=0)
|   |   |   BASE: sum=0 != k=2, return False
|   |   |
|   |   |-- (NOT TAKE returned False, try TAKE)
|   |   |   TAKE arr[2]=1, subseq=[1]
|   |   |   solve(idx=3, subseq=[1], sum=1)
|   |   |   BASE: sum=1 != k=2, return False
|   |   |   BACKTRACK
|   |   |
|   |   return False (neither choice found answer)
|   |
|   |-- (NOT TAKE returned False, try TAKE)
|       TAKE arr[1]=2, subseq=[2]
|       solve(idx=2, subseq=[2], sum=2)
|       |
|       |-- NOT TAKE arr[2]=1
|           solve(idx=3, subseq=[2], sum=2)
|           BASE: sum=2 == k=2, PRINT [2], return True  <-- FOUND!
|       |
|       |-- (NOT TAKE returned True, SKIP TAKE branch!)
|       return True (propagate success up)
|   |
|   return True (propagate up)
|
|-- (NOT TAKE returned True, SKIP TAKE branch for index 0!)
return True

RESULT: Printed [2], explored only 6 nodes instead of 15!


DRY RUN 2: arr = [3, 4, 2], k = 10
----------------------------------

solve(idx=0, subseq=[], sum=0)

Path 1: [] -> [] -> [] -> sum=0, False
Path 2: [] -> [] -> [2] -> sum=2, False
Path 3: [] -> [4] -> [4] -> sum=4, False
Path 4: [] -> [4] -> [4,2] -> sum=6, False
Path 5: [3] -> [3] -> [3] -> sum=3, False
Path 6: [3] -> [3] -> [3,2] -> sum=5, False
Path 7: [3] -> [3,4] -> [3,4] -> sum=7, False
Path 8: [3] -> [3,4] -> [3,4,2] -> sum=9, False

All 8 paths explored, no sum=10 found.

RESULT: No valid subsequence exists, return False
"""


# ============================================================================
#        IMPLEMENTATION 2: PRINT FIRST SUBSEQUENCE WITH SUM = K
# ============================================================================

def print_first_subsequence_with_sum_k(arr: list, k: int) -> bool:
    """
    Print ONLY THE FIRST subsequence of arr whose elements sum to k.
    Uses early termination to stop as soon as one is found.

    Args:
        arr: Input array of integers
        k: Target sum

    Returns:
        True if a valid subsequence was found, False otherwise

    Time Complexity: O(2^n) worst case, but often much better due to early stop
    Space Complexity: O(n) - recursion depth
    """
    n = len(arr)

    def solve(index: int, current_subseq: list, current_sum: int) -> bool:
        """
        Recursive helper that returns True if valid subsequence found.

        The return value is KEY for early termination:
        - True = found it, stop searching!
        - False = not found yet, keep trying
        """
        # BASE CASE: We've processed all elements
        if index == n:
            if current_sum == k:
                print(f"First subsequence found: {current_subseq.copy()}")
                return True   # Signal success - stop searching!
            return False      # Not valid - continue searching

        # CHOICE 1: NOT TAKE - skip arr[index]
        if solve(index + 1, current_subseq, current_sum):
            return True  # Found in NOT-TAKE branch, propagate success up!

        # CHOICE 2: TAKE - include arr[index]
        # Only executed if NOT-TAKE didn't find anything
        current_subseq.append(arr[index])
        if solve(index + 1, current_subseq, current_sum + arr[index]):
            return True  # Found in TAKE branch, propagate success up!
        current_subseq.pop()  # BACKTRACK

        return False  # Neither branch found valid subsequence

    print(f"Finding first subsequence with sum = {k} in {arr}:")
    print("-" * 50)
    found = solve(0, [], 0)
    if not found:
        print("No valid subsequence exists!")
    print("-" * 50)
    return found


"""
================================================================================
    PROBLEM 3: COUNT ALL SUBSEQUENCES WITH SUM = K
================================================================================

PROBLEM STATEMENT:
------------------
Given an array arr[] and an integer k, COUNT how many subsequences
have elements that sum up to exactly k.

Example:
    arr = [1, 2, 1], k = 2

    Output: 2  (because [2] and [1,1] both sum to 2)


KEY DIFFERENCE FROM PROBLEMS 1 AND 2:
-------------------------------------
- Problem 1: Print all -> void return, explore all, print when valid
- Problem 2: Print first -> bool return, early termination on True
- Problem 3: Count all -> int return, return counts from branches, add them


THE COUNTING LOGIC:
-------------------
At each node, total count = (count from NOT-TAKE) + (count from TAKE)

At base case:
    - If sum == k: return 1 (this path is valid, count it!)
    - If sum != k: return 0 (this path is invalid, don't count)


VISUAL: Counting in the Decision Tree
--------------------------------------

For arr = [1, 2, 1], k = 2:

                                      ([], 0)
                                      return 2
                                    /          \
                         NOT TAKE /            \ TAKE
                           return 1            return 1
                                 /              \
                           ([], 0)            ([1], 1)
                           return 1           return 1
                          /      \            /      \
                   return 0    return 1  return 1   return 0
                         /        \        /          \
                    ([], 0)    ([2], 2)  ([1], 1)   ([1,2], 3)
                   return 0    return 1  return 1   return 0
                  /     \      /    \    /    \     /     \
                 0       0    1      0  0      1   0       0
               ([], 0) ([1],1)([2],2)([2,1],3)([1],1)([1,1],2)([1,2],3)([1,2,1],4)
               sum=0   sum=1  sum=2  sum=3   sum=1   sum=2    sum=3     sum=4
                 X       X     YES     X       X      YES       X         X


Count propagation:
    - Leaves return 1 if sum==k, else 0
    - Parents return: left_count + right_count
    - Root returns total count: 2


DRY RUN 1: arr = [1, 2, 1], k = 2
---------------------------------

solve(idx=0, sum=0)
|
|-- NOT TAKE: solve(idx=1, sum=0)
|   |
|   |-- NOT TAKE: solve(idx=2, sum=0)
|   |   |
|   |   |-- NOT TAKE: solve(idx=3, sum=0)
|   |   |   BASE: sum=0 != k, return 0
|   |   |
|   |   |-- TAKE: solve(idx=3, sum=1)
|   |   |   BASE: sum=1 != k, return 0
|   |   |
|   |   return 0 + 0 = 0
|   |
|   |-- TAKE: solve(idx=2, sum=2)
|   |   |
|   |   |-- NOT TAKE: solve(idx=3, sum=2)
|   |   |   BASE: sum=2 == k, return 1  <-- COUNTED!
|   |   |
|   |   |-- TAKE: solve(idx=3, sum=3)
|   |   |   BASE: sum=3 != k, return 0
|   |   |
|   |   return 1 + 0 = 1
|   |
|   return 0 + 1 = 1
|
|-- TAKE: solve(idx=1, sum=1)
    |
    |-- NOT TAKE: solve(idx=2, sum=1)
    |   |
    |   |-- NOT TAKE: solve(idx=3, sum=1)
    |   |   BASE: sum=1 != k, return 0
    |   |
    |   |-- TAKE: solve(idx=3, sum=2)
    |   |   BASE: sum=2 == k, return 1  <-- COUNTED!
    |   |
    |   return 0 + 1 = 1
    |
    |-- TAKE: solve(idx=2, sum=3)
    |   |
    |   |-- NOT TAKE: solve(idx=3, sum=3)
    |   |   BASE: sum=3 != k, return 0
    |   |
    |   |-- TAKE: solve(idx=3, sum=4)
    |   |   BASE: sum=4 != k, return 0
    |   |
    |   return 0 + 0 = 0
    |
    return 1 + 0 = 1

FINAL: return 1 + 1 = 2

RESULT: Count = 2


DRY RUN 2: arr = [5, 2, 3, 1], k = 6
------------------------------------

Let's trace the valid paths only (where sum becomes 6):

Path 1: [5, 1] -> indices 0 and 3 -> sum = 5+1 = 6  YES
Path 2: [2, 3, 1] -> indices 1, 2, 3 -> sum = 2+3+1 = 6  YES

Let me verify all 16 subsequences:
    []          sum=0   X
    [1]         sum=1   X
    [3]         sum=3   X
    [3,1]       sum=4   X
    [2]         sum=2   X
    [2,1]       sum=3   X
    [2,3]       sum=5   X
    [2,3,1]     sum=6   YES (count +1)
    [5]         sum=5   X
    [5,1]       sum=6   YES (count +1)
    [5,3]       sum=8   X
    [5,3,1]     sum=9   X
    [5,2]       sum=7   X
    [5,2,1]     sum=8   X
    [5,2,3]     sum=10  X
    [5,2,3,1]   sum=11  X

RESULT: Count = 2
"""


# ============================================================================
#           IMPLEMENTATION 3: COUNT ALL SUBSEQUENCES WITH SUM = K
# ============================================================================

def count_subsequences_with_sum_k(arr: list, k: int) -> int:
    """
    Count how many subsequences of arr have elements summing to exactly k.

    Args:
        arr: Input array of integers
        k: Target sum

    Returns:
        Number of valid subsequences

    Time Complexity: O(2^n) - we must explore all subsequences
    Space Complexity: O(n) - recursion depth
    """
    n = len(arr)

    def solve(index: int, current_sum: int) -> int:
        """
        Recursive helper that returns COUNT of valid subsequences.

        Note: We don't need to track the actual subsequence!
              We only care about the sum and count.

        Args:
            index: Current position in array
            current_sum: Sum of elements taken so far

        Returns:
            Number of valid subsequences from this point onward
        """
        # BASE CASE: We've processed all elements
        if index == n:
            if current_sum == k:
                return 1  # This path formed a valid subsequence!
            return 0      # This path did not form a valid subsequence

        # RECURSIVE CASE: Count from both choices

        # CHOICE 1: NOT TAKE - skip arr[index]
        not_take_count = solve(index + 1, current_sum)

        # CHOICE 2: TAKE - include arr[index]
        take_count = solve(index + 1, current_sum + arr[index])

        # Total count = sum of counts from both branches
        return not_take_count + take_count

    count = solve(0, 0)
    print(f"Number of subsequences with sum = {k} in {arr}: {count}")
    return count


"""
================================================================================
                SECTION 3: COMPARISON OF THE THREE VARIATIONS
================================================================================

SIDE-BY-SIDE CODE COMPARISON:
-----------------------------

+-------------------+------------------------+------------------------+------------------------+
|                   |   PRINT ALL            |   PRINT FIRST          |   COUNT ALL            |
+-------------------+------------------------+------------------------+------------------------+
| Return Type       | void (None)            | bool                   | int                    |
+-------------------+------------------------+------------------------+------------------------+
| Base Case         | if sum==k: print       | if sum==k: print,      | if sum==k: return 1    |
| (when idx == n)   |                        |    return True         | else: return 0         |
+-------------------+------------------------+------------------------+------------------------+
| NOT TAKE call     | solve(...)             | if solve(...):         | not_take = solve(...)  |
|                   |                        |    return True         |                        |
+-------------------+------------------------+------------------------+------------------------+
| TAKE call         | solve(...)             | if solve(...):         | take = solve(...)      |
|                   |                        |    return True         |                        |
+-------------------+------------------------+------------------------+------------------------+
| Final return      | (nothing)              | return False           | return not_take + take |
+-------------------+------------------------+------------------------+------------------------+
| Explores ALL?     | YES                    | NO (stops early)       | YES                    |
+-------------------+------------------------+------------------------+------------------------+
| Time (best)       | O(2^n)                 | O(1)                   | O(2^n)                 |
+-------------------+------------------------+------------------------+------------------------+
| Time (worst)      | O(2^n)                 | O(2^n)                 | O(2^n)                 |
+-------------------+------------------------+------------------------+------------------------+


KEY PATTERN INSIGHT:
--------------------
The core recursion structure (Take/Not-Take) is IDENTICAL!

The only changes are:
1. What we RETURN (nothing, bool, or int)
2. How we COMBINE results (print vs propagate True vs add counts)
3. Whether we STOP EARLY (only in print-first)

This pattern appears in MANY problems:
- Subset Sum
- 0/1 Knapsack
- Partition problems
- Combination Sum
- Power Set generation


================================================================================
                        SECTION 4: EDGE CASES
================================================================================

1. EMPTY ARRAY (arr = [])
   ----------------------
   - For k = 0: Empty subsequence [] has sum 0, so count = 1
   - For k != 0: No valid subsequence, count = 0

2. TARGET K = 0
   -------------
   - Empty subsequence [] always has sum 0
   - So at minimum, count >= 1 (the empty subsequence)
   - Plus any other subsequences summing to 0 (like [1, -1])

3. ALL ELEMENTS EQUAL TO K
   -----------------------
   arr = [2, 2, 2], k = 2
   Valid subsequences: [2] (idx 0), [2] (idx 1), [2] (idx 2)
   Count = 3 (each single element forms a valid subsequence)

4. NO VALID SUBSEQUENCE EXISTS
   ---------------------------
   arr = [3, 5, 7], k = 2
   All elements > k, no subset can sum to k
   Count = 0

5. NEGATIVE NUMBERS
   -----------------
   arr = [2, -1, 3], k = 2
   Valid: [2], [3, -1], etc.
   The algorithm works without modification!

6. SINGLE ELEMENT ARRAY
   --------------------
   arr = [5], k = 5 -> Count = 1, subsequence = [5]
   arr = [5], k = 0 -> Count = 1, subsequence = [] (empty)
   arr = [5], k = 3 -> Count = 0, no valid subsequence
"""


# ============================================================================
#                       EDGE CASE HANDLERS
# ============================================================================

def print_all_with_edge_cases(arr: list, k: int) -> list:
    """
    Print all subsequences with sum k, with proper edge case handling.
    """
    # Edge case: Empty array
    if len(arr) == 0:
        if k == 0:
            print(f"Empty array with k=0: [[]] (empty subsequence)")
            return [[]]
        else:
            print(f"Empty array with k={k}: [] (no valid subsequence)")
            return []

    # Normal case
    return print_all_subsequences_with_sum_k(arr, k)


def count_with_edge_cases(arr: list, k: int) -> int:
    """
    Count subsequences with sum k, with proper edge case handling.

    Note: Empty subsequence has sum 0, so if k=0, we always have at least 1.
    """
    n = len(arr)

    if n == 0:
        return 1 if k == 0 else 0

    def solve(index: int, current_sum: int) -> int:
        if index == n:
            return 1 if current_sum == k else 0

        not_take = solve(index + 1, current_sum)
        take = solve(index + 1, current_sum + arr[index])

        return not_take + take

    return solve(0, 0)


"""
================================================================================
                    SECTION 5: TIME AND SPACE COMPLEXITY
================================================================================

TIME COMPLEXITY ANALYSIS:
-------------------------

For all three problems:
    - We make 2 choices at each element
    - There are n elements
    - Total recursive calls = O(2^n)

    Print All:    O(2^n) always - must explore all paths
    Print First:  O(2^n) worst case, but often much better
    Count All:    O(2^n) always - must explore all paths


SPACE COMPLEXITY ANALYSIS:
--------------------------

1. Recursion Stack Space:
   - Maximum depth = n (one level per element)
   - Space = O(n)

2. Subsequence Storage (Print All only):
   - Current subsequence: O(n) in worst case
   - If storing all results: O(2^n * n) worst case

3. For Count:
   - Only recursion stack: O(n)
   - No subsequence storage needed!


OPTIMIZATIONS (Advanced):
-------------------------

1. MEMOIZATION (for Count problem):
   - State = (index, current_sum)
   - Can reduce from O(2^n) to O(n * total_sum)
   - Only works if array has bounded values

2. PRUNING:
   - If all elements are positive and current_sum > k, stop early
   - If remaining elements can't possibly reach k, stop early

3. DYNAMIC PROGRAMMING:
   - Convert recursion to DP table
   - dp[i][j] = count of subsequences using first i elements with sum j


================================================================================
                        SECTION 6: TEST CASES
================================================================================
"""


def run_all_tests():
    """
    Comprehensive test suite for all three implementations.
    """
    print("=" * 70)
    print("              COMPREHENSIVE TEST SUITE")
    print("=" * 70)

    # Test Case 1: Basic Example
    print("\n" + "=" * 70)
    print("TEST 1: Basic Example - arr = [1, 2, 1], k = 2")
    print("=" * 70)
    print("\n--- Print All ---")
    print_all_subsequences_with_sum_k([1, 2, 1], 2)
    print("\n--- Print First ---")
    print_first_subsequence_with_sum_k([1, 2, 1], 2)
    print("\n--- Count All ---")
    count_subsequences_with_sum_k([1, 2, 1], 2)

    # Test Case 2: No Valid Subsequence
    print("\n" + "=" * 70)
    print("TEST 2: No Valid Subsequence - arr = [3, 5, 7], k = 2")
    print("=" * 70)
    print("\n--- Print All ---")
    print_all_subsequences_with_sum_k([3, 5, 7], 2)
    print("\n--- Print First ---")
    print_first_subsequence_with_sum_k([3, 5, 7], 2)
    print("\n--- Count All ---")
    count_subsequences_with_sum_k([3, 5, 7], 2)

    # Test Case 3: Multiple Valid Subsequences
    print("\n" + "=" * 70)
    print("TEST 3: Multiple Valid - arr = [5, 2, 3, 1], k = 6")
    print("=" * 70)
    print("\n--- Print All ---")
    print_all_subsequences_with_sum_k([5, 2, 3, 1], 6)
    print("\n--- Print First ---")
    print_first_subsequence_with_sum_k([5, 2, 3, 1], 6)
    print("\n--- Count All ---")
    count_subsequences_with_sum_k([5, 2, 3, 1], 6)

    # Test Case 4: k = 0 (Empty Subsequence Valid)
    print("\n" + "=" * 70)
    print("TEST 4: k = 0 - arr = [1, 2, 3], k = 0")
    print("=" * 70)
    print("\n--- Count All (includes empty subsequence) ---")
    count = count_with_edge_cases([1, 2, 3], 0)
    print(f"Count = {count} (the empty subsequence [] has sum 0)")

    # Test Case 5: Single Element
    print("\n" + "=" * 70)
    print("TEST 5: Single Element - arr = [5], k = 5")
    print("=" * 70)
    print("\n--- Print All ---")
    print_all_subsequences_with_sum_k([5], 5)
    print("\n--- Print First ---")
    print_first_subsequence_with_sum_k([5], 5)
    print("\n--- Count All ---")
    count_subsequences_with_sum_k([5], 5)

    # Test Case 6: All Elements Equal to k
    print("\n" + "=" * 70)
    print("TEST 6: All Elements = k - arr = [2, 2, 2], k = 2")
    print("=" * 70)
    print("\n--- Print All (should find 3 single-element subsequences) ---")
    print_all_subsequences_with_sum_k([2, 2, 2], 2)
    print("\n--- Count All ---")
    count_subsequences_with_sum_k([2, 2, 2], 2)

    # Test Case 7: Negative Numbers
    print("\n" + "=" * 70)
    print("TEST 7: Negative Numbers - arr = [2, -1, 3, -2], k = 2")
    print("=" * 70)
    print("\n--- Print All ---")
    print_all_subsequences_with_sum_k([2, -1, 3, -2], 2)
    print("\n--- Count All ---")
    count_subsequences_with_sum_k([2, -1, 3, -2], 2)

    # Test Case 8: Larger Array
    print("\n" + "=" * 70)
    print("TEST 8: Larger Array - arr = [1, 2, 3, 4, 5], k = 10")
    print("=" * 70)
    print("\n--- Print All ---")
    print_all_subsequences_with_sum_k([1, 2, 3, 4, 5], 10)
    print("\n--- Count All ---")
    count_subsequences_with_sum_k([1, 2, 3, 4, 5], 10)

    print("\n" + "=" * 70)
    print("              ALL TESTS COMPLETED!")
    print("=" * 70)


"""
================================================================================
                    SECTION 7: SUMMARY AND KEY TAKEAWAYS
================================================================================

KEY LEARNINGS:
--------------

1. SUBSEQUENCE BASICS:
   - A subsequence maintains order but doesn't need to be contiguous
   - Total subsequences = 2^n (each element: take or not take)

2. THE TAKE/NOT-TAKE PATTERN:
   - Fundamental recursion pattern for subsequence problems
   - Creates a binary tree of choices
   - Left branch = NOT TAKE, Right branch = TAKE

3. THREE PROBLEM VARIATIONS:

   +-------------+------------------+------------------+
   | Problem     | Return Type      | Key Mechanism    |
   +-------------+------------------+------------------+
   | Print All   | void             | Print at base    |
   |             |                  | No early stop    |
   +-------------+------------------+------------------+
   | Print First | bool             | Return True to   |
   |             |                  | stop early       |
   +-------------+------------------+------------------+
   | Count All   | int              | Return 1/0,      |
   |             |                  | add both branches|
   +-------------+------------------+------------------+

4. BACKTRACKING:
   - After exploring TAKE branch, pop the element
   - This restores state for other branches
   - Essential for correct exploration

5. COMPLEXITY:
   - Time: O(2^n) for all three (worst case)
   - Space: O(n) for recursion stack

6. APPLICATIONS:
   - Subset Sum Problem
   - 0/1 Knapsack
   - Partition Problems
   - Combination Sum
   - Power Set Generation


INTERVIEW TIPS:
---------------
1. Always start by explaining the Take/Not-Take pattern
2. Draw the decision tree for small examples
3. Clarify which variation is asked (all, first, or count)
4. Discuss time/space complexity
5. Mention optimization possibilities (memoization, DP)

================================================================================
"""


# Main execution
if __name__ == "__main__":
    run_all_tests()
