"""
Given an array arr of integers, return the sums of all subsets in the list.
Return the sums in any order.

Examples:

Input: arr[] = [2, 3]
Output: [0, 2, 3, 5]
Explanation: When no elements are taken then Sum = 0. When only 2 is taken then Sum = 2.
When only 3 is taken then Sum = 3. When elements 2 and 3 are taken then Sum = 2+3 = 5.
"""

# =============================================================================
# SECTION 1: UNDERSTANDING THE PROBLEM - WHAT ARE SUBSET SUMS?
# =============================================================================
#
# A SUBSET is any collection of elements from an array (including empty set and
# the array itself). The ORDER does not matter, and each element can be picked
# at most once.
#
# For an array of n elements, there are exactly 2^n possible subsets.
# Why? Because for each element, we have 2 choices: INCLUDE it or EXCLUDE it.
#
# Example: arr = [2, 3]
#   - Subset 1: {}        --> Sum = 0  (empty subset)
#   - Subset 2: {2}       --> Sum = 2  (only first element)
#   - Subset 3: {3}       --> Sum = 3  (only second element)
#   - Subset 4: {2, 3}    --> Sum = 5  (both elements)
#
# Total subsets = 2^2 = 4
#
# WHY IS THIS PROBLEM IMPORTANT?
# -----------------------------------------------------------------------------
# 1. Foundation for Dynamic Programming: Subset sum is a classic DP problem
#    that teaches the "pick or not pick" pattern.
#
# 2. Interview Favorite: Frequently asked at Google, Amazon, Microsoft, etc.
#
# 3. Real-world Applications:
#    - Resource allocation (which resources to use)
#    - Knapsack problems (which items to pick)
#    - Partition problems (can we split into equal halves)
#    - Cryptography and security
#
# 4. Building Block: Many complex problems reduce to subset sum variants.
#
# =============================================================================
# SECTION 2: INTUITION BEHIND RECURSION - THE "PICK OR NOT PICK" PATTERN
# =============================================================================
#
# The key insight is that at EACH INDEX, we face a BINARY CHOICE:
#
#     +------------------+
#     |  Current Index   |
#     +------------------+
#            / \
#           /   \
#          /     \
#    PICK IT    DON'T PICK IT
#    (add to     (keep sum
#     sum)        as is)
#
# We make this decision for EVERY element, and when we reach the end of the
# array (base case), we record the accumulated sum.
#
# This creates a BINARY TREE of decisions:
#   - Left branch  = INCLUDE current element
#   - Right branch = EXCLUDE current element
#   - Leaf nodes   = Final sums (when index reaches array length)
#
# The recursion naturally explores ALL possible combinations!
#
# =============================================================================
# SECTION 3: COMPLETE PYTHON IMPLEMENTATION
# =============================================================================

from typing import List


def subset_sums_recursive(arr: List[int]) -> List[int]:
    """
    Find all possible subset sums using recursion.

    Args:
        arr: List of integers

    Returns:
        List of all possible subset sums

    Time Complexity: O(2^n) - we generate 2^n subsets
    Space Complexity: O(n) - recursion stack depth
    """
    result = []

    def solve(index: int, current_sum: int) -> None:
        """
        Recursive helper function using the pick/not-pick pattern.

        Args:
            index: Current position in the array
            current_sum: Sum accumulated so far
        """
        # BASE CASE: We have processed all elements
        # When index reaches the length of array, we have made decisions
        # for all elements. Record the current sum.
        if index == len(arr):
            result.append(current_sum)
            return

        # RECURSIVE CASE - Two choices:

        # Choice 1: PICK the current element (add it to sum)
        # We include arr[index] in our subset
        solve(index + 1, current_sum + arr[index])

        # Choice 2: DON'T PICK the current element (skip it)
        # We exclude arr[index] from our subset
        solve(index + 1, current_sum)

    # Start recursion from index 0 with sum 0
    solve(0, 0)

    return result


def subset_sums_sorted(arr: List[int]) -> List[int]:
    """
    Same as above but returns sorted result.
    Many interview problems expect sorted output.

    Time Complexity: O(2^n * log(2^n)) = O(n * 2^n) for sorting
    Space Complexity: O(2^n) for storing all sums
    """
    result = subset_sums_recursive(arr)
    result.sort()
    return result


# =============================================================================
# SECTION 4: DRY RUN WITH EXAMPLE [2, 3]
# =============================================================================
#
# Let's trace through arr = [2, 3] step by step:
#
# Initial Call: solve(index=0, current_sum=0)
# result = []
#
# ----- STEP-BY-STEP TRACE -----
#
# CALL 1: solve(0, 0)
#   index=0, current_sum=0, arr[0]=2
#   We are at element 2, deciding to pick or not pick
#   |
#   |---> PICK 2: Call solve(1, 0+2=2)
#   |
#   |---> DON'T PICK 2: Call solve(1, 0)
#
# ---------------------------------------------------------------
#
# CALL 2: solve(1, 2)  [We picked 2]
#   index=1, current_sum=2, arr[1]=3
#   We are at element 3, deciding to pick or not pick
#   |
#   |---> PICK 3: Call solve(2, 2+3=5)
#   |
#   |---> DON'T PICK 3: Call solve(2, 2)
#
# CALL 3: solve(2, 5)  [We picked both 2 and 3]
#   index=2 == len(arr)  --> BASE CASE!
#   result.append(5)
#   result = [5]
#   RETURN
#
# CALL 4: solve(2, 2)  [We picked only 2]
#   index=2 == len(arr)  --> BASE CASE!
#   result.append(2)
#   result = [5, 2]
#   RETURN
#
# ---------------------------------------------------------------
#
# CALL 5: solve(1, 0)  [We did NOT pick 2]
#   index=1, current_sum=0, arr[1]=3
#   We are at element 3, deciding to pick or not pick
#   |
#   |---> PICK 3: Call solve(2, 0+3=3)
#   |
#   |---> DON'T PICK 3: Call solve(2, 0)
#
# CALL 6: solve(2, 3)  [We picked only 3]
#   index=2 == len(arr)  --> BASE CASE!
#   result.append(3)
#   result = [5, 2, 3]
#   RETURN
#
# CALL 7: solve(2, 0)  [We picked nothing - empty subset]
#   index=2 == len(arr)  --> BASE CASE!
#   result.append(0)
#   result = [5, 2, 3, 0]
#   RETURN
#
# ---------------------------------------------------------------
#
# FINAL RESULT: [5, 2, 3, 0]
# After sorting: [0, 2, 3, 5]
#
# =============================================================================
# SECTION 5: VISUAL REPRESENTATION OF RECURSION TREE
# =============================================================================
#
#                              solve(0, 0)
#                           arr[0] = 2
#                          /           \
#                    PICK 2           DON'T PICK 2
#                        /                 \
#                 solve(1, 2)            solve(1, 0)
#                arr[1] = 3              arr[1] = 3
#                /       \                /       \
#           PICK 3    DON'T         PICK 3    DON'T
#              /        PICK 3          /       PICK 3
#             /            \           /           \
#      solve(2,5)    solve(2,2)   solve(2,3)   solve(2,0)
#          |              |           |             |
#       BASE           BASE        BASE          BASE
#       CASE           CASE        CASE          CASE
#          |              |           |             |
#     result=5       result=2    result=3      result=0
#
#
# Each leaf node represents one unique subset:
#   - sum=5 --> subset {2, 3}
#   - sum=2 --> subset {2}
#   - sum=3 --> subset {3}
#   - sum=0 --> subset {} (empty)
#
# Total leaf nodes = 2^n = 2^2 = 4 subsets
#
# =============================================================================
# SECTION 6: DRY RUN WITH SECOND EXAMPLE [1, 2, 3]
# =============================================================================
#
# arr = [1, 2, 3], n = 3
# Total subsets = 2^3 = 8
#
# Recursion Tree (abbreviated):
#
#                                   solve(0, 0)
#                                   arr[0] = 1
#                                /              \
#                         PICK 1                DON'T PICK 1
#                              /                       \
#                       solve(1, 1)                 solve(1, 0)
#                      /          \                /          \
#               PICK 2       DON'T PICK 2    PICK 2      DON'T PICK 2
#                  /               \           /              \
#           solve(2,3)        solve(2,1)  solve(2,2)     solve(2,0)
#            /    \            /    \       /    \         /    \
#          P3   D3           P3   D3      P3   D3        P3   D3
#          /     \           /     \      /     \        /     \
#      (2,6)  (2,3)      (2,4) (2,1)  (2,5) (2,2)   (2,3) (2,0)
#        |      |          |     |      |     |       |     |
#       6=     3=         4=    1=     5=    2=      3=    0=
#     {1,2,3}  {1,2}    {1,3}  {1}  {2,3}  {2}     {3}   {}
#
# FINAL RESULT: [6, 3, 4, 1, 5, 2, 3, 0]
# SORTED: [0, 1, 2, 3, 3, 4, 5, 6]
#
# Note: Sum 3 appears twice because {1,2} and {3} both sum to 3!
#
# =============================================================================
# SECTION 7: TIME AND SPACE COMPLEXITY ANALYSIS
# =============================================================================
#
# TIME COMPLEXITY: O(2^n)
# -----------------------
# - At each element, we make 2 recursive calls (pick or not pick)
# - This creates a binary tree of height n
# - Total nodes in tree = 2^0 + 2^1 + 2^2 + ... + 2^n = 2^(n+1) - 1 = O(2^n)
# - Each node does O(1) work
# - Total: O(2^n)
#
# If we sort the result: O(2^n * log(2^n)) = O(n * 2^n)
#
# SPACE COMPLEXITY: O(n) for recursion, O(2^n) for output
# --------------------------------------------------------
# - Recursion Stack Depth: At most n calls deep (one per element)
#   Therefore, stack space = O(n)
#
# - Output Storage: We store 2^n sums in the result list
#   Therefore, output space = O(2^n)
#
# - Auxiliary Space (excluding output): O(n)
#
# =============================================================================
# SECTION 8: EDGE CASES TO CONSIDER
# =============================================================================

def test_edge_cases():
    """Test various edge cases for subset sums."""

    # Edge Case 1: Empty Array
    # Only subset is empty set with sum 0
    assert subset_sums_recursive([]) == [0]
    print("Edge Case 1 (Empty Array): PASSED - Expected [0]")

    # Edge Case 2: Single Element
    # Two subsets: {} with sum 0, {elem} with sum elem
    result = subset_sums_sorted([5])
    assert result == [0, 5]
    print("Edge Case 2 (Single Element [5]): PASSED - Expected [0, 5]")

    # Edge Case 3: Array with Zero
    # Zero doesn't change sum, so some sums repeat
    result = subset_sums_sorted([0, 1])
    assert result == [0, 0, 1, 1]  # {} = 0, {0} = 0, {1} = 1, {0,1} = 1
    print("Edge Case 3 (Array with Zero [0,1]): PASSED - Expected [0, 0, 1, 1]")

    # Edge Case 4: Negative Numbers
    # Works exactly the same way
    result = subset_sums_sorted([-1, 2])
    assert result == [-1, 0, 1, 2]  # {-1}=-1, {}=0, {-1,2}=1, {2}=2
    print("Edge Case 4 (Negative Numbers [-1,2]): PASSED - Expected [-1, 0, 1, 2]")

    # Edge Case 5: All Same Elements
    # Multiple subsets can have same sum
    result = subset_sums_sorted([2, 2])
    assert result == [0, 2, 2, 4]
    print("Edge Case 5 (Duplicates [2,2]): PASSED - Expected [0, 2, 2, 4]")

    # Edge Case 6: Larger Array
    result = subset_sums_sorted([1, 2, 3])
    assert result == [0, 1, 2, 3, 3, 4, 5, 6]
    print("Edge Case 6 (Array [1,2,3]): PASSED - Expected [0, 1, 2, 3, 3, 4, 5, 6]")

    print("\nAll edge cases passed!")


# =============================================================================
# SECTION 9: ALTERNATIVE APPROACHES
# =============================================================================

# APPROACH 1: Iterative using Bit Manipulation
# ---------------------------------------------
# Each subset can be represented by a binary number from 0 to 2^n - 1
# If bit i is set, include arr[i] in the subset

def subset_sums_iterative(arr: List[int]) -> List[int]:
    """
    Find all subset sums using bit manipulation.

    For n elements, we iterate through all numbers from 0 to 2^n - 1.
    Each number represents a unique subset based on its binary representation.

    Example: arr = [2, 3]
    Binary  | Decimal | Subset | Sum
    --------|---------|--------|----
      00    |    0    |   {}   |  0
      01    |    1    |  {2}   |  2   (bit 0 set -> include arr[0])
      10    |    2    |  {3}   |  3   (bit 1 set -> include arr[1])
      11    |    3    | {2,3}  |  5   (bits 0,1 set -> include both)

    Time Complexity: O(n * 2^n) - for each of 2^n subsets, we check n bits
    Space Complexity: O(2^n) for output
    """
    n = len(arr)
    result = []

    # Iterate through all possible subsets (0 to 2^n - 1)
    for mask in range(1 << n):  # 1 << n is same as 2^n
        current_sum = 0

        # Check each bit position
        for i in range(n):
            # If bit i is set in mask, include arr[i]
            if mask & (1 << i):
                current_sum += arr[i]

        result.append(current_sum)

    return result


# APPROACH 2: Using Previous Sums (Iterative DP-like)
# ----------------------------------------------------
# Build up sums iteratively by adding each element to existing sums

def subset_sums_iterative_dp(arr: List[int]) -> List[int]:
    """
    Build subset sums iteratively.

    Idea: Start with sum 0 (empty subset).
    For each new element, create new sums by adding it to all existing sums.

    Example: arr = [2, 3]

    Initial: sums = [0]  (empty subset)

    Process element 2:
      - Keep existing sums: [0]
      - Add 2 to each: [0+2] = [2]
      - Combined: [0, 2]

    Process element 3:
      - Keep existing sums: [0, 2]
      - Add 3 to each: [0+3, 2+3] = [3, 5]
      - Combined: [0, 2, 3, 5]

    Time Complexity: O(2^n) - we process 2^n sums total
    Space Complexity: O(2^n) for storing sums
    """
    sums = [0]  # Start with empty subset sum

    for num in arr:
        # Create new sums by adding current number to all existing sums
        new_sums = [s + num for s in sums]
        # Combine with existing sums
        sums = sums + new_sums

    return sums


# =============================================================================
# SECTION 10: MAIN FUNCTION AND TESTING
# =============================================================================

def main():
    """Main function to demonstrate subset sums."""

    print("=" * 60)
    print("SUBSET SUMS - DEMONSTRATION")
    print("=" * 60)

    # Example 1: Basic case
    arr1 = [2, 3]
    print(f"\nExample 1: arr = {arr1}")
    print(f"Expected subsets: {{}}, {{2}}, {{3}}, {{2,3}}")
    print(f"Expected sums: [0, 2, 3, 5]")

    result_recursive = subset_sums_sorted(arr1)
    result_iterative = sorted(subset_sums_iterative(arr1))
    result_dp = sorted(subset_sums_iterative_dp(arr1))

    print(f"\nRecursive approach: {result_recursive}")
    print(f"Bit manipulation:   {result_iterative}")
    print(f"Iterative DP:       {result_dp}")

    # Example 2: Larger array
    arr2 = [1, 2, 3]
    print(f"\n{'='*60}")
    print(f"\nExample 2: arr = {arr2}")
    print(f"Total subsets: 2^3 = 8")

    result = subset_sums_sorted(arr2)
    print(f"All subset sums (sorted): {result}")

    # Example 3: Array with negative number
    arr3 = [-2, 3, 1]
    print(f"\n{'='*60}")
    print(f"\nExample 3: arr = {arr3} (with negative)")
    result = subset_sums_sorted(arr3)
    print(f"All subset sums (sorted): {result}")

    # Run edge case tests
    print(f"\n{'='*60}")
    print("EDGE CASE TESTS")
    print("=" * 60)
    test_edge_cases()

    print(f"\n{'='*60}")
    print("ALL DEMONSTRATIONS COMPLETE!")
    print("=" * 60)


if __name__ == "__main__":
    main()
