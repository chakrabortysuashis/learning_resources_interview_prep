"""
================================================================================
                            N-QUEENS PROBLEM
================================================================================

PROBLEM STATEMENT:
------------------
Place N chess queens on an N x N chessboard such that no two queens attack
each other.

In chess, a queen can attack:
  - Horizontally (same row)
  - Vertically (same column)
  - Diagonally (both diagonals)

We need to find ALL possible arrangements where N queens can be placed safely.

Example for N=4:
----------------
One valid solution:        Another valid solution:
  . Q . .                    . . Q .
  . . . Q                    Q . . .
  Q . . .                    . . . Q
  . . Q .                    . Q . .

Input: N (size of the board and number of queens)
Output: All valid board configurations

================================================================================
                        INTUITION AND APPROACH
================================================================================

WHY BACKTRACKING?
-----------------
1. We need to explore many possibilities systematically
2. When we hit a dead end (can't place a queen), we need to "undo" and try
   something else
3. The solution space is like a tree - we explore branches and prune invalid ones

KEY INSIGHT: ROW-BY-ROW PLACEMENT
---------------------------------
Since each row can have EXACTLY ONE queen (otherwise they'd attack horizontally),
we can simplify the problem:

- Process one row at a time
- For each row, try placing the queen in each column (0 to N-1)
- If placement is valid (no attacks), move to next row
- If we've placed queens in all rows, we found a solution!
- If no valid column exists, BACKTRACK to previous row and try next column

DETECTING CONFLICTS:
--------------------
When placing a queen at (row, col), check if it conflicts with ANY previously
placed queen. A conflict occurs if:

1. Same Column: Another queen is in the same column

2. Same Diagonal (going down-left to up-right):
   - Cells on this diagonal have the property: row - col = constant
   - Example: (0,1), (1,2), (2,3) all have row-col = -1

3. Same Anti-Diagonal (going down-right to up-left):
   - Cells on this diagonal have the property: row + col = constant
   - Example: (0,2), (1,1), (2,0) all have row+col = 2

VISUAL REPRESENTATION OF DIAGONALS:
-----------------------------------
For a 4x4 board, row-col values:        row+col values:

     0   1   2   3  (columns)              0   1   2   3
   +---+---+---+---+                     +---+---+---+---+
 0 | 0 |-1 |-2 |-3 |                   0 | 0 | 1 | 2 | 3 |
   +---+---+---+---+                     +---+---+---+---+
 1 | 1 | 0 |-1 |-2 |                   1 | 1 | 2 | 3 | 4 |
   +---+---+---+---+                     +---+---+---+---+
 2 | 2 | 1 | 0 |-1 |                   2 | 2 | 3 | 4 | 5 |
   +---+---+---+---+                     +---+---+---+---+
 3 | 3 | 2 | 1 | 0 |                   3 | 3 | 4 | 5 | 6 |
   +---+---+---+---+                     +---+---+---+---+

Cells with same row-col are on same diagonal
Cells with same row+col are on same anti-diagonal

================================================================================
                    APPROACH 1: BASIC BACKTRACKING
================================================================================
Time Complexity: O(N!) - We have N choices for row 0, at most N-1 for row 1, etc.
Space Complexity: O(N^2) for the board + O(N) for recursion stack
"""

from typing import List


def solve_n_queens_basic(n: int) -> List[List[str]]:
    """
    Solve N-Queens using basic backtracking approach.

    We represent the board as a 2D list where:
    - '.' represents an empty cell
    - 'Q' represents a queen

    Args:
        n: Size of the chessboard and number of queens to place

    Returns:
        List of all valid board configurations, each as a list of strings
    """

    def is_safe(board: List[List[str]], row: int, col: int) -> bool:
        """
        Check if it's safe to place a queen at board[row][col].

        We only need to check:
        1. The column above (rows 0 to row-1)
        2. The upper-left diagonal
        3. The upper-right diagonal

        Why only check above? Because we place queens row by row from top,
        so there are no queens below the current row yet!
        """

        # Check column above
        # Go through all rows above current row, same column
        for i in range(row):
            if board[i][col] == 'Q':
                return False

        # Check upper-left diagonal
        # Move diagonally up-left: row decreases, col decreases
        i, j = row - 1, col - 1
        while i >= 0 and j >= 0:
            if board[i][j] == 'Q':
                return False
            i -= 1
            j -= 1

        # Check upper-right diagonal
        # Move diagonally up-right: row decreases, col increases
        i, j = row - 1, col + 1
        while i >= 0 and j < n:
            if board[i][j] == 'Q':
                return False
            i -= 1
            j += 1

        return True  # No conflicts found, position is safe

    def backtrack(board: List[List[str]], row: int):
        """
        Try to place queens starting from the given row.

        Base case: If row == n, we've successfully placed all queens
        Recursive case: Try each column in current row
        """

        # BASE CASE: All queens placed successfully!
        if row == n:
            # Convert board to the required format (list of strings)
            solution = [''.join(r) for r in board]
            results.append(solution)
            return

        # RECURSIVE CASE: Try placing queen in each column of current row
        for col in range(n):
            if is_safe(board, row, col):
                # PLACE the queen (make a choice)
                board[row][col] = 'Q'

                # RECURSE to next row
                backtrack(board, row + 1)

                # BACKTRACK: Remove the queen (undo the choice)
                # This allows us to try other columns
                board[row][col] = '.'

    # Initialize empty board
    board = [['.' for _ in range(n)] for _ in range(n)]
    results = []

    # Start backtracking from row 0
    backtrack(board, 0)

    return results


"""
================================================================================
                APPROACH 2: OPTIMIZED WITH SETS (O(1) CONFLICT CHECK)
================================================================================

OPTIMIZATION INSIGHT:
---------------------
In the basic approach, is_safe() takes O(N) time because we traverse the column
and diagonals. We can reduce this to O(1) using hash sets!

We maintain three sets:
1. cols: columns where queens are placed
2. diag1: diagonals (row - col values) where queens are placed
3. diag2: anti-diagonals (row + col values) where queens are placed

To check if (row, col) is safe:
- Check if col is in cols
- Check if (row - col) is in diag1
- Check if (row + col) is in diag2

If none are true, the position is safe!

Time Complexity: O(N!) - same as before (this is unavoidable)
Space Complexity: O(N) for the sets + O(N) for recursion stack
"""


def solve_n_queens_optimized(n: int) -> List[List[str]]:
    """
    Solve N-Queens with O(1) conflict detection using sets.

    This is the preferred approach for interviews!
    """

    def backtrack(row: int, queens: List[int]):
        """
        Place queens row by row.

        Args:
            row: Current row to process
            queens: List where queens[i] = column of queen in row i
        """

        # BASE CASE: All N queens placed
        if row == n:
            # Build the board representation
            board = []
            for r in range(n):
                row_str = '.' * queens[r] + 'Q' + '.' * (n - queens[r] - 1)
                board.append(row_str)
            results.append(board)
            return

        # Try each column in current row
        for col in range(n):
            # Calculate diagonal identifiers
            diagonal = row - col      # Same value = same diagonal
            anti_diagonal = row + col  # Same value = same anti-diagonal

            # Check if this position is under attack
            if col in cols or diagonal in diag1 or anti_diagonal in diag2:
                continue  # Skip this column, it's not safe

            # PLACE: Add to tracking sets and queens list
            cols.add(col)
            diag1.add(diagonal)
            diag2.add(anti_diagonal)
            queens.append(col)

            # RECURSE to next row
            backtrack(row + 1, queens)

            # BACKTRACK: Remove from tracking sets and queens list
            cols.remove(col)
            diag1.remove(diagonal)
            diag2.remove(anti_diagonal)
            queens.pop()

    # Tracking sets for O(1) lookup
    cols = set()   # Columns with queens
    diag1 = set()  # Diagonals (row - col)
    diag2 = set()  # Anti-diagonals (row + col)
    results = []

    backtrack(0, [])

    return results


"""
================================================================================
                        APPROACH 3: FIND JUST ONE SOLUTION
================================================================================
Sometimes we only need ONE valid configuration, not all of them.
We can stop as soon as we find the first solution.
"""


def solve_n_queens_one_solution(n: int) -> List[str]:
    """
    Find just one valid N-Queens configuration.
    Returns empty list if no solution exists.
    """

    def backtrack(row: int, queens: List[int]) -> bool:
        """Returns True if a solution is found."""

        if row == n:
            return True  # Found a solution!

        for col in range(n):
            diagonal = row - col
            anti_diagonal = row + col

            if col in cols or diagonal in diag1 or anti_diagonal in diag2:
                continue

            cols.add(col)
            diag1.add(diagonal)
            diag2.add(anti_diagonal)
            queens.append(col)

            # If solution found in recursion, stop immediately
            if backtrack(row + 1, queens):
                return True

            cols.remove(col)
            diag1.remove(diagonal)
            diag2.remove(anti_diagonal)
            queens.pop()

        return False  # No valid placement found for this row

    cols = set()
    diag1 = set()
    diag2 = set()
    queens = []

    if backtrack(0, queens):
        # Build and return the board
        board = []
        for r in range(n):
            row_str = '.' * queens[r] + 'Q' + '.' * (n - queens[r] - 1)
            board.append(row_str)
        return board

    return []  # No solution exists


"""
================================================================================
                    APPROACH 4: COUNT SOLUTIONS ONLY
================================================================================
If we only need the count of solutions (not the actual configurations),
we can save memory by not storing the board states.
"""


def count_n_queens_solutions(n: int) -> int:
    """
    Count the total number of valid N-Queens configurations.
    More memory efficient when we don't need actual solutions.
    """

    def backtrack(row: int) -> int:
        """Returns count of solutions from this state."""

        if row == n:
            return 1  # Found one valid configuration

        count = 0
        for col in range(n):
            diagonal = row - col
            anti_diagonal = row + col

            if col in cols or diagonal in diag1 or anti_diagonal in diag2:
                continue

            cols.add(col)
            diag1.add(diagonal)
            diag2.add(anti_diagonal)

            count += backtrack(row + 1)

            cols.remove(col)
            diag1.remove(diagonal)
            diag2.remove(anti_diagonal)

        return count

    cols = set()
    diag1 = set()
    diag2 = set()

    return backtrack(0)


"""
================================================================================
                            DETAILED DRY RUN
================================================================================

Let's trace through the 4-Queens problem step by step.
We'll use the optimized approach with sets.

INITIAL STATE:
--------------
n = 4
cols = {}, diag1 = {}, diag2 = {}
queens = []

Board visualization (empty):
  0 1 2 3
  -------
0| . . . . |
1| . . . . |
2| . . . . |
3| . . . . |
  -------

================================================================================
DRY RUN: FINDING FIRST SOLUTION
================================================================================

CALL: backtrack(row=0, queens=[])

ROW 0: Try col=0
-----------------
  - diagonal = 0-0 = 0
  - anti_diagonal = 0+0 = 0
  - 0 not in cols, 0 not in diag1, 0 not in diag2 --> SAFE!
  - Place queen: cols={0}, diag1={0}, diag2={0}, queens=[0]

  Board:
    0 1 2 3
    -------
  0| Q . . . |   <-- Queen placed at (0,0)
  1| . . . . |
  2| . . . . |
  3| . . . . |
    -------

  RECURSE: backtrack(row=1, queens=[0])

  ROW 1: Try col=0
  -----------------
    - 0 in cols --> SKIP (same column as queen at row 0)

  ROW 1: Try col=1
  -----------------
    - diagonal = 1-1 = 0
    - 0 in diag1 --> SKIP (same diagonal as queen at row 0)

    Visual: Queen at (0,0) attacks (1,1) diagonally
      Q . . .
      . X . .   <-- X marks attacked diagonal
      . . . .
      . . . .

  ROW 1: Try col=2
  -----------------
    - diagonal = 1-2 = -1, anti_diagonal = 1+2 = 3
    - -1 not in diag1, 3 not in diag2, 2 not in cols --> SAFE!
    - Place queen: cols={0,2}, diag1={0,-1}, diag2={0,3}, queens=[0,2]

    Board:
      0 1 2 3
      -------
    0| Q . . . |
    1| . . Q . |   <-- Queen placed at (1,2)
    2| . . . . |
    3| . . . . |
      -------

    RECURSE: backtrack(row=2, queens=[0,2])

    ROW 2: Try col=0
    -----------------
      - 0 in cols --> SKIP

    ROW 2: Try col=1
    -----------------
      - diagonal = 2-1 = 1, anti_diagonal = 2+1 = 3
      - 3 in diag2 --> SKIP (same anti-diagonal as queen at row 1, col 2)

      Visual: (1,2) and (2,1) are on same anti-diagonal (sum = 3)
        Q . . .
        . . Q .
        . X . .   <-- Would be attacked
        . . . .

    ROW 2: Try col=2
    -----------------
      - 2 in cols --> SKIP

    ROW 2: Try col=3
    -----------------
      - diagonal = 2-3 = -1
      - -1 in diag1 --> SKIP (same diagonal as queen at row 1, col 2)

    ROW 2: All columns exhausted, no valid placement!
    BACKTRACK: Return to row 1

    Remove queen from (1,2):
    cols={0}, diag1={0}, diag2={0}, queens=[0]

  ROW 1: Try col=3
  -----------------
    - diagonal = 1-3 = -2, anti_diagonal = 1+3 = 4
    - All clear --> SAFE!
    - Place queen: cols={0,3}, diag1={0,-2}, diag2={0,4}, queens=[0,3]

    Board:
      0 1 2 3
      -------
    0| Q . . . |
    1| . . . Q |   <-- Queen placed at (1,3)
    2| . . . . |
    3| . . . . |
      -------

    RECURSE: backtrack(row=2, queens=[0,3])

    ROW 2: Try col=0
    -----------------
      - 0 in cols --> SKIP

    ROW 2: Try col=1
    -----------------
      - diagonal = 2-1 = 1, anti_diagonal = 2+1 = 3
      - All clear --> SAFE!
      - Place queen: cols={0,1,3}, diag1={0,-2,1}, diag2={0,4,3}, queens=[0,3,1]

      Board:
        0 1 2 3
        -------
      0| Q . . . |
      1| . . . Q |
      2| . Q . . |   <-- Queen placed at (2,1)
      3| . . . . |
        -------

      RECURSE: backtrack(row=3, queens=[0,3,1])

      ROW 3: Try col=0
      -----------------
        - 0 in cols --> SKIP

      ROW 3: Try col=1
      -----------------
        - 1 in cols --> SKIP

      ROW 3: Try col=2
      -----------------
        - diagonal = 3-2 = 1
        - 1 in diag1 --> SKIP (same diagonal as queen at row 2, col 1)

      ROW 3: Try col=3
      -----------------
        - 3 in cols --> SKIP

      ROW 3: All columns exhausted!
      BACKTRACK: Return to row 2

      Remove queen from (2,1)

    ROW 2: Try col=2
    -----------------
      - diagonal = 2-2 = 0
      - 0 in diag1 --> SKIP (same diagonal as queen at row 0, col 0)

    ROW 2: Try col=3
    -----------------
      - 3 in cols --> SKIP

    ROW 2: All columns exhausted!
    BACKTRACK: Return to row 1

    Remove queen from (1,3)

  ROW 1: All columns (0-3) exhausted!
  BACKTRACK: Return to row 0

  Remove queen from (0,0):
  cols={}, diag1={}, diag2={}, queens=[]

ROW 0: Try col=1
-----------------
  - All clear --> SAFE!
  - Place queen: cols={1}, diag1={-1}, diag2={1}, queens=[1]

  Board:
    0 1 2 3
    -------
  0| . Q . . |   <-- Queen placed at (0,1)
  1| . . . . |
  2| . . . . |
  3| . . . . |
    -------

  RECURSE: backtrack(row=1, queens=[1])

  ROW 1: Try col=0
  -----------------
    - diagonal = 1-0 = 1, anti_diagonal = 1+0 = 1
    - 1 in diag2 --> SKIP

  ROW 1: Try col=1
  -----------------
    - 1 in cols --> SKIP

  ROW 1: Try col=2
  -----------------
    - diagonal = 1-2 = -1
    - -1 in diag1 --> SKIP

  ROW 1: Try col=3
  -----------------
    - diagonal = 1-3 = -2, anti_diagonal = 1+3 = 4
    - All clear --> SAFE!
    - Place queen: cols={1,3}, diag1={-1,-2}, diag2={1,4}, queens=[1,3]

    Board:
      0 1 2 3
      -------
    0| . Q . . |
    1| . . . Q |   <-- Queen placed at (1,3)
    2| . . . . |
    3| . . . . |
      -------

    RECURSE: backtrack(row=2, queens=[1,3])

    ROW 2: Try col=0
    -----------------
      - diagonal = 2-0 = 2, anti_diagonal = 2+0 = 2
      - All clear --> SAFE!
      - Place queen: cols={0,1,3}, diag1={-1,-2,2}, diag2={1,4,2}, queens=[1,3,0]

      Board:
        0 1 2 3
        -------
      0| . Q . . |
      1| . . . Q |
      2| Q . . . |   <-- Queen placed at (2,0)
      3| . . . . |
        -------

      RECURSE: backtrack(row=3, queens=[1,3,0])

      ROW 3: Try col=0
      -----------------
        - 0 in cols --> SKIP

      ROW 3: Try col=1
      -----------------
        - 1 in cols --> SKIP

      ROW 3: Try col=2
      -----------------
        - diagonal = 3-2 = 1, anti_diagonal = 3+2 = 5
        - All clear --> SAFE!
        - Place queen: cols={0,1,2,3}, queens=[1,3,0,2]

        Board:
          0 1 2 3
          -------
        0| . Q . . |
        1| . . . Q |
        2| Q . . . |
        3| . . Q . |   <-- Queen placed at (3,2)
          -------

        RECURSE: backtrack(row=4, queens=[1,3,0,2])

        ROW 4: row == n (4 == 4)
        ========================
        FOUND FIRST SOLUTION!

        Solution: [".Q..", "...Q", "Q...", "..Q."]

================================================================================
CONTINUING TO FIND SECOND SOLUTION (abbreviated)
================================================================================

After backtracking from the first solution, the algorithm continues:

- Backtracks from row 3, tries col=3 (skip - in cols)
- Backtracks to row 2, tries col=1 (skip - diagonal conflict)
- Eventually finds second solution starting with queen at (0,2)

SECOND SOLUTION:
  0 1 2 3
  -------
0| . . Q . |
1| Q . . . |
2| . . . Q |
3| . Q . . |
  -------

Solution: ["..Q.", "Q...", "...Q", ".Q.."]

================================================================================
                        COMPLEXITY ANALYSIS
================================================================================

TIME COMPLEXITY: O(N!)
----------------------
- At row 0: we can try N columns
- At row 1: at most N-1 valid columns (one blocked by row 0's queen's column)
- At row 2: at most N-2 valid columns
- ...and so on

This gives us N * (N-1) * (N-2) * ... * 1 = N! possibilities in the worst case.

The actual complexity is tighter because diagonal attacks eliminate even more
choices, but O(N!) is the standard upper bound.

SPACE COMPLEXITY: O(N)
----------------------
1. Recursion stack depth: O(N) - we go at most N levels deep
2. Sets (cols, diag1, diag2): O(N) each - at most N elements
3. queens list: O(N) - stores column for each row
4. Output storage: O(N * number_of_solutions) - but this is output size

If we exclude output storage, space is O(N).

================================================================================
                    EDGE CASES AND SPECIAL VALUES
================================================================================

N = 1: One solution exists
--------------------------
Board: ["Q"]
Only one cell, one queen - trivially valid.

N = 2: NO solution exists
--------------------------
  Q .       . Q
  . .  or   . .

If we place Q at (0,0), both (1,0) and (1,1) are attacked.
If we place Q at (0,1), both (1,0) and (1,1) are attacked.

N = 3: NO solution exists
--------------------------
Similar reasoning - no way to place 3 queens on 3x3 without conflicts.

N = 4: Two solutions exist (shown in dry run above)

N = 8 (Classic Problem): 92 solutions exist

Number of solutions for various N:
----------------------------------
N=1: 1        N=5: 10       N=9: 352
N=2: 0        N=6: 4        N=10: 724
N=3: 0        N=7: 40       N=11: 2680
N=4: 2        N=8: 92       N=12: 14200

================================================================================

================================================================================
                    RECURSION TREE FOR 4-QUEENS
================================================================================

This tree shows the complete backtracking process for N=4.
Each node represents: (row, [queen_columns_so_far])

Legend:
  [X]     = Invalid placement (queen would be attacked)
  [P]     = Pruned subtree (all children invalid)
  [*]     = Valid placement, continue recursion
  [SOL]   = SOLUTION FOUND!
  <--     = Backtrack (undo choice, try next option)

================================================================================
                         COMPLETE RECURSION TREE
================================================================================

                                    solve(row=0, [])
                                          |
            +-----------------------------+-----------------------------+
            |                             |                             |
       Try col=0                     Try col=1                     Try col=2                     Try col=3
            |                             |                             |                             |
       row=0, [0]                    row=0, [1]                    row=0, [2]                    row=0, [3]
       [* valid]                     [* valid]                     [* valid]                     [* valid]
            |                             |                             |                             |
            v                             v                             v                             v
    +-------+-------+             +-------+-------+             +-------+-------+             +-------+-------+
    |   |   |   |   |             |   |   |   |   |             |   |   |   |   |             |   |   |   |   |
   c0  c1  c2  c3  <--           c0  c1  c2  c3  <--           c0  c1  c2  c3  <--           c0  c1  c2  c3
   [X] [X] [*] [*]               [X] [X] [X] [*]               [*] [X] [X] [X]               [*] [*] [X] [X]
        same col  |   |               all fail! |                   |                            |   |
        &diag     |   |                         |                   |                            |   |
                  |   |                         |                   |                            |   |
                  v   v                         v                   v                            v   v

================================================================================
          DETAILED TREE: Starting with Queen at Column 0 (row=0, [0])
================================================================================

                              (row=0, [0])
                                   |
                   +---------------+---------------+---------------+
                   |               |               |               |
              col=0 [X]       col=1 [X]       col=2 [*]       col=3 [*]
              same col       same diag        VALID!           VALID!
                                  |               |               |
                                  |               v               v
                                  |         (row=1, [0,2])  (row=1, [0,3])
                                  |               |               |
                                  |     +---------+-----+   +-----+-----+-----+
                                  |     |    |    |    |   |    |    |    |
                                  |    c0   c1   c2   c3  c0   c1   c2   c3
                                  |    [X]  [X]  [X]  [X] [X]  [*]  [X]  [X]
                                  |    col  anti col  diag col VALID col col
                                  |          diag              |
                                  |                            v
                                  |                      (row=2, [0,3,1])
                                  |                            |
                                  |                  +---------+-----+-----+
                                  |                  |    |    |    |
                                  |                 c0   c1   c2   c3
                                  |                 [X]  [X]  [X]  [X]
                                  |                 col  col  diag col
                                  |
                                  |                 ALL FAIL --> BACKTRACK! <--
                                  |
                              (row=1, [0,2]) has all invalid --> BACKTRACK! <--
                              (row=1, [0,3]) ultimately fails --> BACKTRACK! <--

                              RESULT: No solution with queen at col 0 first!

================================================================================
          DETAILED TREE: Starting with Queen at Column 1 (row=0, [1])
          *** THIS PATH LEADS TO SOLUTION 1 ***
================================================================================

                              (row=0, [1])
                                   |
                   +---------------+---------------+---------------+
                   |               |               |               |
              col=0 [X]       col=1 [X]       col=2 [X]       col=3 [*]
              anti-diag      same col        diag (r-c=-1)    VALID!
              (r+c=1)                                             |
                                                                  v
                                                          (row=1, [1,3])
                                                                  |
                                              +-------------------+-------------------+
                                              |         |         |         |
                                          col=0 [*]  col=1 [X]  col=2 [X]  col=3 [X]
                                          VALID!     same col   anti-diag same col
                                              |
                                              v
                                      (row=2, [1,3,0])
                                              |
                              +---------------+---------------+
                              |       |       |       |
                          col=0 [X] col=1 [X] col=2 [*] col=3 [X]
                          same col same col VALID!   same col
                                              |
                                              v
                                      (row=3, [1,3,0,2])
                                              |
                                       row == n (4)
                                              |
                                      +===============+
                                      |   [SOL 1]    |
                                      |  SOLUTION!   |
                                      | cols=[1,3,0,2]|
                                      +===============+

                              Board visualization:
                              +---+---+---+---+
                              | . | Q | . | . |  row 0, queen at col 1
                              +---+---+---+---+
                              | . | . | . | Q |  row 1, queen at col 3
                              +---+---+---+---+
                              | Q | . | . | . |  row 2, queen at col 0
                              +---+---+---+---+
                              | . | . | Q | . |  row 3, queen at col 2
                              +---+---+---+---+

                              After finding solution, BACKTRACK to explore more! <--

================================================================================
          DETAILED TREE: Starting with Queen at Column 2 (row=0, [2])
          *** THIS PATH LEADS TO SOLUTION 2 ***
================================================================================

                              (row=0, [2])
                                   |
                   +---------------+---------------+---------------+
                   |               |               |               |
              col=0 [*]       col=1 [X]       col=2 [X]       col=3 [X]
              VALID!         diag (r-c=-1)   same col        anti-diag
                  |                                          (r+c=3)
                  v
          (row=1, [2,0])
                  |
      +-----------+-----------+-----------+
      |           |           |           |
  col=0 [X]   col=1 [X]   col=2 [X]   col=3 [*]
  same col    anti-diag   same col    VALID!
              (r+c=2)                     |
                                         v
                                 (row=2, [2,0,3])
                                         |
                         +---------------+---------------+
                         |       |       |       |
                     col=0 [X] col=1 [*] col=2 [X] col=3 [X]
                     same col VALID!   same col same col
                                 |
                                 v
                         (row=3, [2,0,3,1])
                                 |
                          row == n (4)
                                 |
                         +===============+
                         |   [SOL 2]    |
                         |  SOLUTION!   |
                         | cols=[2,0,3,1]|
                         +===============+

                              Board visualization:
                              +---+---+---+---+
                              | . | . | Q | . |  row 0, queen at col 2
                              +---+---+---+---+
                              | Q | . | . | . |  row 1, queen at col 0
                              +---+---+---+---+
                              | . | . | . | Q |  row 2, queen at col 3
                              +---+---+---+---+
                              | . | Q | . | . |  row 3, queen at col 1
                              +---+---+---+---+

================================================================================
          DETAILED TREE: Starting with Queen at Column 3 (row=0, [3])
================================================================================

                              (row=0, [3])
                                   |
                   +---------------+---------------+---------------+
                   |               |               |               |
              col=0 [*]       col=1 [*]       col=2 [X]       col=3 [X]
              VALID!         VALID!          anti-diag       same col
                  |               |           (r+c=3)
                  v               v
          (row=1, [3,0])    (row=1, [3,1])
                  |               |
        (mirrors [0,3])    (mirrors [1,3])
           path above          path above
                  |               |
              DEAD END        DEAD END

              By symmetry, these paths do not lead to new solutions.
              All unique solutions have already been found!

================================================================================
                         SUMMARY: COMPLETE BACKTRACKING FLOW
================================================================================

Call Order (simplified):

  solve(0,[])
      |
      +-- solve(1,[0]) -- solve(2,[0,2]) -- DEAD END, backtrack
      |                -- solve(2,[0,3]) -- solve(3,[0,3,1]) -- DEAD END, backtrack
      |                                                       backtrack
      |                                   backtrack
      |   backtrack
      |
      +-- solve(1,[1]) -- solve(2,[1,3]) -- solve(3,[1,3,0]) -- solve(4,[1,3,0,2])
      |                                                             |
      |                                                       *** SOLUTION 1 ***
      |                                                       [".Q..", "...Q", "Q...", "..Q."]
      |                                                             |
      |                                                        backtrack
      |                                   backtrack
      |   backtrack
      |
      +-- solve(1,[2]) -- solve(2,[2,0]) -- solve(3,[2,0,3]) -- solve(4,[2,0,3,1])
      |                                                             |
      |                                                       *** SOLUTION 2 ***
      |                                                       ["..Q.", "Q...", "...Q", ".Q.."]
      |                                                             |
      |                                                        backtrack
      |                                   backtrack
      |   backtrack
      |
      +-- solve(1,[3]) -- (all paths lead to dead ends, mirror of earlier attempts)
                          backtrack

      DONE! Return 2 solutions.

================================================================================
                         PRUNING STATISTICS FOR N=4
================================================================================

Without pruning (brute force): 4^4 = 256 total placements to check
With backtracking pruning:     Only ~30 recursive calls needed!

Pruned branches by conflict type:
  - Column conflicts:       ~40% of pruned branches
  - Diagonal conflicts:     ~35% of pruned branches
  - Anti-diagonal conflicts: ~25% of pruned branches

This demonstrates the power of backtracking - we eliminate entire subtrees
early rather than exploring invalid configurations to completion.

================================================================================
"""


# ============================================================================
# UTILITY FUNCTIONS FOR VISUALIZATION AND TESTING
# ============================================================================

def print_board(board: List[str]) -> None:
    """Pretty print a board configuration."""
    n = len(board)
    print("  " + " ".join(str(i) for i in range(n)))
    print("  " + "-" * (2 * n - 1))
    for i, row in enumerate(board):
        print(f"{i}|", " ".join(row), "|")
    print("  " + "-" * (2 * n - 1))
    print()


def print_all_solutions(n: int) -> None:
    """Find and print all solutions for N-Queens."""
    solutions = solve_n_queens_optimized(n)
    print(f"\n{'='*50}")
    print(f"N-QUEENS SOLUTIONS FOR N = {n}")
    print(f"{'='*50}")
    print(f"Total solutions found: {len(solutions)}\n")

    for i, solution in enumerate(solutions, 1):
        print(f"Solution {i}:")
        print_board(solution)


# ============================================================================
# MAIN EXECUTION AND TESTING
# ============================================================================

if __name__ == "__main__":

    # Test basic approach
    print("Testing Basic Backtracking Approach:")
    print("-" * 40)
    result_basic = solve_n_queens_basic(4)
    print(f"4-Queens has {len(result_basic)} solutions")
    for sol in result_basic:
        print_board(sol)

    # Test optimized approach
    print("\nTesting Optimized Approach (with sets):")
    print("-" * 40)
    result_optimized = solve_n_queens_optimized(4)
    print(f"4-Queens has {len(result_optimized)} solutions")

    # Test single solution finder
    print("\nTesting Single Solution Finder:")
    print("-" * 40)
    single = solve_n_queens_one_solution(8)
    if single:
        print("One solution for 8-Queens:")
        print_board(single)

    # Test solution counter
    print("\nTesting Solution Counter:")
    print("-" * 40)
    for n in range(1, 11):
        count = count_n_queens_solutions(n)
        print(f"N={n:2d}: {count:5d} solutions")

    # Edge cases
    print("\nEdge Cases:")
    print("-" * 40)
    print(f"N=1 solutions: {solve_n_queens_optimized(1)}")
    print(f"N=2 solutions: {solve_n_queens_optimized(2)} (empty - no solution)")
    print(f"N=3 solutions: {solve_n_queens_optimized(3)} (empty - no solution)")


"""
================================================================================
                        INTERVIEW TIPS
================================================================================

1. CLARIFY THE PROBLEM:
   - Ask: "Do you want all solutions or just one?"
   - Ask: "Should I return the board or just count solutions?"

2. START WITH BRUTE FORCE DISCUSSION:
   - Mention trying all N^N placements (N choices for each of N rows)
   - Explain why backtracking prunes this significantly

3. EXPLAIN YOUR APPROACH BEFORE CODING:
   - "I'll place queens row by row"
   - "I'll use sets to track attacked columns and diagonals"
   - "When I can't place a queen, I'll backtrack"

4. KEY INSIGHT TO MENTION:
   - The row-col and row+col diagonal trick
   - Why we only check upward (queens below don't exist yet)

5. OPTIMIZE STEP BY STEP:
   - Start with O(N) safety check, then mention O(1) with sets
   - This shows depth of understanding

6. HANDLE EDGE CASES:
   - N=0: Return empty list
   - N=1: Return [["Q"]]
   - N=2,3: Return empty list (no solutions)

7. RELATED PROBLEMS:
   - N-Queens II (just count solutions)
   - Sudoku Solver (similar backtracking pattern)
   - Permutations (similar pruning concept)

================================================================================
"""
