"""
================================================================================
                    PALINDROME CHECK USING RECURSION
================================================================================

WHAT IS A PALINDROME?
---------------------
A palindrome is a sequence that reads the SAME forwards and backwards.

Examples of Palindromes:
    - Array:  [1, 2, 3, 2, 1]  --> Read left-to-right: 1,2,3,2,1
                                   Read right-to-left: 1,2,3,2,1  (SAME!)

    - String: "radar"          --> Forward: r-a-d-a-r
                                   Backward: r-a-d-a-r  (SAME!)

    - String: "madam"          --> Forward: m-a-d-a-m
                                   Backward: m-a-d-a-m  (SAME!)

NOT Palindromes:
    - [1, 2, 3, 4, 5]  --> Forward: 1,2,3,4,5  |  Backward: 5,4,3,2,1  (DIFFERENT!)
    - "hello"          --> Forward: h-e-l-l-o  |  Backward: o-l-l-e-h  (DIFFERENT!)


================================================================================
                         THE INTUITION (Think Like a Human!)
================================================================================

Imagine you have a word written on cards:

        +---+---+---+---+---+
        | r | a | d | a | r |
        +---+---+---+---+---+
          ^                 ^
          |                 |
        FIRST             LAST

Step 1: Compare FIRST and LAST
        - Are 'r' and 'r' the same? YES!
        - Move inward...

        +---+---+---+---+---+
        | r | a | d | a | r |
        +---+---+---+---+---+
              ^       ^
              |       |
            FIRST   LAST

Step 2: Compare the NEW FIRST and NEW LAST
        - Are 'a' and 'a' the same? YES!
        - Move inward...

        +---+---+---+---+---+
        | r | a | d | a | r |
        +---+---+---+---+---+
                  ^
                  |
             FIRST=LAST (They crossed or met!)

Step 3: When pointers meet or cross, we've checked everything!
        - RESULT: It's a PALINDROME!


KEY INSIGHT FOR RECURSION:
--------------------------
    "If the FIRST and LAST match,
     then the whole thing is a palindrome
     ONLY IF the INNER PART is also a palindrome"

    is_palindrome("radar") = ('r' == 'r') AND is_palindrome("ada")
    is_palindrome("ada")   = ('a' == 'a') AND is_palindrome("d")
    is_palindrome("d")     = True (single character = always palindrome)


================================================================================
                         THE TWO APPROACHES
================================================================================

APPROACH 1: Using Two Pointers (start, end)
-------------------------------------------
    - Keep track of 'start' and 'end' indices
    - Compare arr[start] with arr[end]
    - Move start forward, end backward
    - Stop when they meet or cross

APPROACH 2: Using String Slicing
--------------------------------
    - Compare first character s[0] with last character s[-1]
    - Recursively check the substring s[1:-1] (excluding first and last)
    - Stop when string length <= 1


================================================================================
                    BASE CASE AND RECURSIVE CASE ANALYSIS
================================================================================

+------------------+-------------------------------------------+
|    SITUATION     |              WHAT IT MEANS                |
+------------------+-------------------------------------------+
|                  |                                           |
|  BASE CASE 1:    |  start >= end                             |
|  (SUCCESS)       |  Pointers have met or crossed.            |
|                  |  All pairs matched! Return TRUE.          |
|                  |                                           |
|  Example:        |  Array: [1,2,1]                           |
|                  |  After checking (1,1) and moving inward,  |
|                  |  start=1, end=1 --> start >= end          |
|                  |  We've verified all pairs!                |
|                  |                                           |
+------------------+-------------------------------------------+
|                  |                                           |
|  BASE CASE 2:    |  arr[start] != arr[end]                   |
|  (FAILURE)       |  First and last don't match.              |
|                  |  NOT a palindrome! Return FALSE.          |
|                  |                                           |
|  Example:        |  Array: [1,2,3]                           |
|                  |  start=0, end=2: arr[0]=1, arr[2]=3       |
|                  |  1 != 3 --> Return FALSE immediately      |
|                  |                                           |
+------------------+-------------------------------------------+
|                  |                                           |
|  RECURSIVE CASE: |  arr[start] == arr[end]                   |
|                  |  First and last match! Good so far.       |
|                  |  But we need to check the INNER part.     |
|                  |  Call: is_palindrome(arr, start+1, end-1) |
|                  |                                           |
+------------------+-------------------------------------------+


================================================================================
                         VISUAL: HOW RECURSION SHRINKS THE PROBLEM
================================================================================

Array: [1, 2, 3, 2, 1]

Call 1:  [1, 2, 3, 2, 1]      start=0, end=4
          ^           ^       arr[0]=1, arr[4]=1  --> MATCH!
          |           |       Check inner part...
        start       end

Call 2:     [2, 3, 2]         start=1, end=3
             ^     ^          arr[1]=2, arr[3]=2  --> MATCH!
             |     |          Check inner part...
           start  end

Call 3:       [3]             start=2, end=2
               ^              start >= end --> BASE CASE!
               |              Return TRUE!
           start=end

The TRUE bubbles back up:
    Call 3 returns TRUE  --> Call 2 returns TRUE  --> Call 1 returns TRUE


================================================================================
"""


def is_palindrome(arr: list, start: int = 0, end: int = None) -> bool:
    """
    Check if an array is a palindrome using recursion.

    TECHNIQUE: Two-Pointer Recursion
    --------------------------------
    We use two pointers (start and end) that move towards each other.
    At each step, we compare the elements at these positions.

    Args:
        arr: The input array to check
        start: Starting index (default 0, meaning leftmost)
        end: Ending index (default len(arr)-1, meaning rightmost)

    Returns:
        True if palindrome, False otherwise

    VISUAL REPRESENTATION:
    ----------------------
        arr = [1, 2, 3, 2, 1]
               ^           ^
               |           |
             start        end
             (0)          (4)

    Compare arr[start] with arr[end]
    If equal, move inward: start+1, end-1
    """

    # Initialize 'end' to last index if not provided
    # This allows calling is_palindrome([1,2,1]) without extra arguments
    if end is None:
        end = len(arr) - 1

    # =========================================================================
    # BASE CASE 1: Pointers have met or crossed
    # =========================================================================
    # When start >= end, we've successfully compared all pairs!
    #
    # TWO SCENARIOS:
    #   1) ODD length array: pointers MEET at middle element
    #      Example: [1,2,3,2,1] --> eventually start=2, end=2
    #
    #   2) EVEN length array: pointers CROSS each other
    #      Example: [1,2,2,1] --> eventually start=2, end=1 (crossed!)
    #
    # In both cases, all pairs have been verified. Return True!
    if start >= end:
        return True

    # =========================================================================
    # BASE CASE 2: Mismatch found - NOT a palindrome
    # =========================================================================
    # If the element at start position doesn't match element at end position,
    # we immediately know this is NOT a palindrome.
    # No need to check further - return False right away!
    #
    # Example: [1, 2, 3, 4, 5]
    #           ^           ^
    #           1    !=     5   --> Return False immediately
    if arr[start] != arr[end]:
        return False

    # =========================================================================
    # RECURSIVE CASE: Current pair matches, check inner portion
    # =========================================================================
    # The current first and last elements match. Great!
    # But the array is palindrome ONLY IF the inner portion is also palindrome.
    #
    # Visual:
    #     [1,  2, 3, 2,  1]
    #      ^             ^
    #    start          end
    #      |             |
    #    MATCH!       MATCH!
    #
    #     Now check: [2, 3, 2]  (inner portion)
    #                 ^     ^
    #             start+1  end-1
    return is_palindrome(arr, start + 1, end - 1)


"""
================================================================================
                    DRY RUN #1: PALINDROME ARRAY [1, 2, 3, 2, 1]
================================================================================

Initial Array: [1, 2, 3, 2, 1]
               (0)(1)(2)(3)(4)  <-- indices

CALL STACK VISUALIZATION:
-------------------------

+------------------------------------------------------------------+
| CALL 1: is_palindrome([1,2,3,2,1], start=0, end=4)               |
|                                                                  |
|   Array:  [ 1 ,  2 ,  3 ,  2 ,  1 ]                              |
|            (0)  (1)  (2)  (3)  (4)                                |
|             ^                   ^                                |
|           start                end                               |
|                                                                  |
|   Check: arr[0] == arr[4]  -->  1 == 1  -->  TRUE!               |
|   Action: MATCH! Call recursively with start+1, end-1            |
|                                                                  |
|   +--------------------------------------------------------------+
|   | CALL 2: is_palindrome([1,2,3,2,1], start=1, end=3)           |
|   |                                                              |
|   |   Array:  [ 1 ,  2 ,  3 ,  2 ,  1 ]                          |
|   |                 (1)  (2)  (3)                                |
|   |                  ^         ^                                 |
|   |                start      end                                |
|   |                                                              |
|   |   Check: arr[1] == arr[3]  -->  2 == 2  -->  TRUE!           |
|   |   Action: MATCH! Call recursively with start+1, end-1        |
|   |                                                              |
|   |   +----------------------------------------------------------+
|   |   | CALL 3: is_palindrome([1,2,3,2,1], start=2, end=2)       |
|   |   |                                                          |
|   |   |   Array:  [ 1 ,  2 ,  3 ,  2 ,  1 ]                      |
|   |   |                      (2)                                 |
|   |   |                       ^                                  |
|   |   |                  start=end                               |
|   |   |                                                          |
|   |   |   Check: start >= end  -->  2 >= 2  -->  TRUE!           |
|   |   |   Action: BASE CASE HIT! Return TRUE                     |
|   |   |                                                          |
|   |   |   RETURNS: True                                          |
|   |   +----------------------------------------------------------+
|   |                                                              |
|   |   RECEIVES: True from Call 3                                 |
|   |   RETURNS: True                                              |
|   +--------------------------------------------------------------+
|                                                                  |
|   RECEIVES: True from Call 2                                     |
|   RETURNS: True                                                  |
+------------------------------------------------------------------+

FINAL RESULT: True (It IS a palindrome!)


RECURSION TREE (ASCII Art):
---------------------------

                    is_palindrome([1,2,3,2,1], 0, 4)
                              |
                        1 == 1? YES
                              |
                              v
                    is_palindrome([1,2,3,2,1], 1, 3)
                              |
                        2 == 2? YES
                              |
                              v
                    is_palindrome([1,2,3,2,1], 2, 2)
                              |
                      start >= end? YES
                              |
                              v
                        Return TRUE
                              |
                              v
                        Return TRUE
                              |
                              v
                        Return TRUE  <-- FINAL ANSWER


================================================================================
                    DRY RUN #2: NON-PALINDROME ARRAY [1, 2, 3, 4, 5]
================================================================================

Initial Array: [1, 2, 3, 4, 5]
               (0)(1)(2)(3)(4)  <-- indices

+------------------------------------------------------------------+
| CALL 1: is_palindrome([1,2,3,4,5], start=0, end=4)               |
|                                                                  |
|   Array:  [ 1 ,  2 ,  3 ,  4 ,  5 ]                              |
|            (0)  (1)  (2)  (3)  (4)                                |
|             ^                   ^                                |
|           start                end                               |
|                                                                  |
|   Check: arr[0] == arr[4]  -->  1 == 5  -->  FALSE!              |
|                                                                  |
|   Action: MISMATCH! Return FALSE immediately.                    |
|           No further recursion needed!                           |
|                                                                  |
|   RETURNS: False                                                 |
+------------------------------------------------------------------+

FINAL RESULT: False (It is NOT a palindrome!)

NOTICE: We detected the mismatch in the FIRST call itself!
        This is the beauty of the approach - we fail FAST.


RECURSION TREE (ASCII Art):
---------------------------

                    is_palindrome([1,2,3,4,5], 0, 4)
                              |
                        1 == 5? NO!
                              |
                              v
                        Return FALSE  <-- FINAL ANSWER (Only 1 call!)


================================================================================
"""


def is_palindrome_string(s: str) -> bool:
    """
    Check if a string is a palindrome using recursion.

    TECHNIQUE: String Slicing Approach
    -----------------------------------
    Instead of tracking indices, we shrink the string itself!
    Compare first char (s[0]) with last char (s[-1])
    Then recursively check the substring without these chars.

    HOW STRING SLICING WORKS:
    -------------------------
        s = "radar"

        s[0]   = 'r'      (first character)
        s[-1]  = 'r'      (last character)
        s[1:-1] = "ada"   (everything EXCEPT first and last)

        Visual:
            "r  a  d  a  r"
             ^           ^
            s[0]       s[-1]

            "   a  d  a   "  <-- s[1:-1] (the inner part)

    PROS OF THIS APPROACH:
        - Cleaner code, no index tracking
        - Very Pythonic (uses Python's powerful slicing)

    CONS OF THIS APPROACH:
        - Creates new string objects at each recursive call
        - Uses more memory than the index-based approach
    """

    # =========================================================================
    # BASE CASE: Empty string or single character
    # =========================================================================
    # An empty string "" is a palindrome (reads same both ways - nothing!)
    # A single character "a" is a palindrome (it's just itself)
    #
    # Examples:
    #   len("")  = 0  --> 0 <= 1  --> True
    #   len("a") = 1  --> 1 <= 1  --> True
    if len(s) <= 1:
        return True

    # =========================================================================
    # BASE CASE: First and last characters don't match
    # =========================================================================
    # If the first character doesn't equal the last character,
    # this string cannot be a palindrome. Return False immediately!
    #
    # Example: "hello"
    #           s[0] = 'h'
    #           s[-1] = 'o'
    #           'h' != 'o'  --> Return False
    if s[0] != s[-1]:
        return False

    # =========================================================================
    # RECURSIVE CASE: Check the inner substring
    # =========================================================================
    # First and last characters match! Good!
    # Now check if the INNER part (excluding first and last) is also palindrome.
    #
    # Example: "radar"
    #           s[0] = 'r', s[-1] = 'r'  --> Match!
    #           s[1:-1] = "ada"          --> Check this next
    return is_palindrome_string(s[1:-1])


"""
================================================================================
                    DRY RUN #3: PALINDROME STRING "radar"
================================================================================

+------------------------------------------------------------------+
| CALL 1: is_palindrome_string("radar")                            |
|                                                                  |
|   String: "r a d a r"                                            |
|            ^       ^                                             |
|          s[0]   s[-1]                                            |
|                                                                  |
|   len("radar") = 5  -->  5 <= 1?  NO, continue                   |
|   Check: s[0] == s[-1]  -->  'r' == 'r'  -->  TRUE!              |
|   Action: Check inner string s[1:-1] = "ada"                     |
|                                                                  |
|   +--------------------------------------------------------------+
|   | CALL 2: is_palindrome_string("ada")                          |
|   |                                                              |
|   |   String: "a d a"                                            |
|   |            ^   ^                                             |
|   |          s[0] s[-1]                                          |
|   |                                                              |
|   |   len("ada") = 3  -->  3 <= 1?  NO, continue                 |
|   |   Check: s[0] == s[-1]  -->  'a' == 'a'  -->  TRUE!          |
|   |   Action: Check inner string s[1:-1] = "d"                   |
|   |                                                              |
|   |   +----------------------------------------------------------+
|   |   | CALL 3: is_palindrome_string("d")                        |
|   |   |                                                          |
|   |   |   String: "d"                                            |
|   |   |                                                          |
|   |   |   len("d") = 1  -->  1 <= 1?  YES!                       |
|   |   |   BASE CASE HIT! Single character is always palindrome. |
|   |   |                                                          |
|   |   |   RETURNS: True                                          |
|   |   +----------------------------------------------------------+
|   |                                                              |
|   |   RECEIVES: True from Call 3                                 |
|   |   RETURNS: True                                              |
|   +--------------------------------------------------------------+
|                                                                  |
|   RECEIVES: True from Call 2                                     |
|   RETURNS: True                                                  |
+------------------------------------------------------------------+

FINAL RESULT: True


STRING SHRINKING VISUALIZATION:
-------------------------------

    Call 1:  "r a d a r"    (length = 5)
              ^       ^
            first   last    --> 'r' == 'r' --> Match!

    Call 2:    "a d a"      (length = 3)
                ^   ^
              first last    --> 'a' == 'a' --> Match!

    Call 3:      "d"        (length = 1)
                  ^
                only        --> Base case! Return True


================================================================================
                    DRY RUN #4: NON-PALINDROME STRING "hello"
================================================================================

+------------------------------------------------------------------+
| CALL 1: is_palindrome_string("hello")                            |
|                                                                  |
|   String: "h e l l o"                                            |
|            ^       ^                                             |
|          s[0]   s[-1]                                            |
|                                                                  |
|   len("hello") = 5  -->  5 <= 1?  NO, continue                   |
|   Check: s[0] == s[-1]  -->  'h' == 'o'  -->  FALSE!             |
|                                                                  |
|   MISMATCH DETECTED! Return False immediately.                   |
|   No further recursive calls needed.                             |
|                                                                  |
|   RETURNS: False                                                 |
+------------------------------------------------------------------+

FINAL RESULT: False

Again, notice the EARLY TERMINATION!
We found the mismatch immediately and stopped.


================================================================================
                         RECURSION TREE DIAGRAMS
================================================================================

FOR "radar" (Palindrome):
-------------------------

                        is_palindrome_string("radar")
                                    |
                              'r' == 'r'? YES
                                    |
                                    v
                        is_palindrome_string("ada")
                                    |
                              'a' == 'a'? YES
                                    |
                                    v
                        is_palindrome_string("d")
                                    |
                              len <= 1? YES
                                    |
                                    v
                              Return TRUE
                                    |
                        +-----------+-----------+
                        |                       |
                        v                       v
                  Return TRUE             Return TRUE


FOR "hello" (Not Palindrome):
-----------------------------

                        is_palindrome_string("hello")
                                    |
                              'h' == 'o'? NO!
                                    |
                                    v
                              Return FALSE  <-- Stops here!


================================================================================
                    TIME AND SPACE COMPLEXITY ANALYSIS
================================================================================

+-------------------+-------------------+-----------------------------------+
|                   |  ARRAY VERSION    |  STRING VERSION                   |
|                   | (Two Pointers)    | (Slicing)                         |
+-------------------+-------------------+-----------------------------------+
|                   |                   |                                   |
|  TIME COMPLEXITY  |     O(n)          |     O(n)                          |
|                   |                   |                                   |
|  WHY?             | We make at most   | We make at most n/2 calls.        |
|                   | n/2 recursive     | Each call does O(1) comparison    |
|                   | calls. Each call  | BUT slicing s[1:-1] creates a     |
|                   | does O(1) work.   | new string of size n-2, n-4, etc. |
|                   |                   | Actually O(n^2) for slicing!      |
|                   | n/2 * O(1) = O(n) |                                   |
|                   |                   | If we count slicing: O(n^2)       |
|                   |                   | If we count just comparisons: O(n)|
|                   |                   |                                   |
+-------------------+-------------------+-----------------------------------+
|                   |                   |                                   |
|  SPACE COMPLEXITY |     O(n)          |     O(n) to O(n^2)                |
|                   |                   |                                   |
|  WHY?             | Recursion depth   | - Recursion depth = O(n/2) = O(n) |
|                   | = n/2 = O(n)      | - Each call stores a new string   |
|                   |                   | - Strings: n-2, n-4, n-6, ...     |
|                   | Each stack frame  | - Total string space: O(n^2)      |
|                   | stores just       |                                   |
|                   | indices (O(1))    | In practice: O(n) stack + O(n^2)  |
|                   |                   | string copies = O(n^2) total      |
|                   |                   |                                   |
+-------------------+-------------------+-----------------------------------+

NOTE ON STRING SLICING:
-----------------------
    s[1:-1] creates a NEW string object in memory!

    Call 1: "radar" exists in memory
    Call 2: "ada" is CREATED (new memory allocation)
    Call 3: "d" is CREATED (another allocation)

    This is why the array version with indices is MORE EFFICIENT!
    The array version just passes indices, never copies the array.


================================================================================
                              EDGE CASES
================================================================================

+---------------------------+------------------+-------------------------------+
|        EDGE CASE          |      INPUT       |          EXPECTED OUTPUT      |
+---------------------------+------------------+-------------------------------+
|                           |                  |                               |
| Empty array               | []               | True (vacuously true)         |
|                           |                  | start=0, end=-1 --> 0 >= -1   |
|                           |                  |                               |
| Single element            | [5]              | True (single elem = palindrome)|
|                           |                  | start=0, end=0 --> 0 >= 0     |
|                           |                  |                               |
| Two same elements         | [1, 1]           | True                          |
|                           |                  | 1 == 1, then start=1, end=0   |
|                           |                  |                               |
| Two different elements    | [1, 2]           | False                         |
|                           |                  | 1 != 2 --> False              |
|                           |                  |                               |
| Empty string              | ""               | True (len=0 <= 1)             |
|                           |                  |                               |
| Single character          | "a"              | True (len=1 <= 1)             |
|                           |                  |                               |
| Even length palindrome    | [1,2,2,1]        | True                          |
|                           |                  |                               |
| Odd length palindrome     | [1,2,3,2,1]      | True                          |
|                           |                  |                               |
| Case sensitivity          | "Radar"          | False! ('R' != 'r')           |
| (strings)                 |                  | Our function is case-sensitive|
|                           |                  |                               |
| Spaces matter             | "a ba"           | False! ('a' != 'a' but has    |
| (strings)                 |                  | spaces that don't match)      |
|                           |                  | Actually: 'a' != ' '          |
|                           |                  |                               |
+---------------------------+------------------+-------------------------------+


================================================================================
                    COMPARISON: RECURSION vs ITERATION
================================================================================

ITERATIVE VERSION (for comparison):
-----------------------------------

    def is_palindrome_iterative(arr):
        left = 0
        right = len(arr) - 1

        while left < right:
            if arr[left] != arr[right]:
                return False
            left += 1
            right -= 1

        return True

COMPARISON:
-----------
    +------------------+-----------------+-----------------+
    |                  |   RECURSIVE     |   ITERATIVE     |
    +------------------+-----------------+-----------------+
    | Time Complexity  |     O(n)        |     O(n)        |
    | Space Complexity |     O(n)        |     O(1)        |
    | Readability      |     High        |     High        |
    | Stack Overflow   |  Risk for large |     No risk     |
    |                  |  inputs         |                 |
    +------------------+-----------------+-----------------+

    For very large arrays (e.g., 1 million elements), iterative is safer!
    Python has a default recursion limit of ~1000.


================================================================================
                         KEY TAKEAWAYS
================================================================================

1. PALINDROME = reads same forwards and backwards

2. RECURSIVE APPROACH = compare outer elements, then solve smaller subproblem

3. BASE CASES are crucial:
   - Pointers meet/cross --> Success! It's a palindrome
   - Elements don't match --> Failure! Not a palindrome

4. TWO POINTERS shrinking inward is the core technique

5. STRING SLICING is elegant but creates copies (memory overhead)

6. ARRAY/INDEX approach is more memory efficient

7. EARLY TERMINATION: We stop as soon as we find a mismatch


================================================================================
"""


if __name__ == "__main__":
    print("=" * 60)
    print("       PALINDROME CHECKER - TEST CASES")
    print("=" * 60)

    # Test cases for array palindrome
    print("\n--- Array Palindrome Tests ---")
    print(f"[1, 2, 3, 2, 1] --> {is_palindrome([1, 2, 3, 2, 1])}")  # True
    print(f"[1, 2, 3, 4, 5] --> {is_palindrome([1, 2, 3, 4, 5])}")  # False
    print(f"[1, 2, 2, 1]    --> {is_palindrome([1, 2, 2, 1])}")     # True (even)
    print(f"[1]             --> {is_palindrome([1])}")              # True (single)
    print(f"[]              --> {is_palindrome([])}")               # True (empty)

    # Test cases for string palindrome
    print("\n--- String Palindrome Tests ---")
    print(f"'radar'  --> {is_palindrome_string('radar')}")   # True
    print(f"'hello'  --> {is_palindrome_string('hello')}")   # False
    print(f"'madam'  --> {is_palindrome_string('madam')}")   # True
    print(f"'a'      --> {is_palindrome_string('a')}")       # True
    print(f"''       --> {is_palindrome_string('')}")        # True (empty)
    print(f"'ab'     --> {is_palindrome_string('ab')}")      # False
    print(f"'aa'     --> {is_palindrome_string('aa')}")      # True

    print("\n" + "=" * 60)
