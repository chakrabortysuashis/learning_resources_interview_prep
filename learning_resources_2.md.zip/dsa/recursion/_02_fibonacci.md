# Fibonacci: Understanding Recursion Trees

## What is the Fibonacci Sequence?

Each number is the sum of the two numbers before it:

```
0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, ...

Position:  0  1  2  3  4  5  6  7   8   9  10
Value:     0  1  1  2  3  5  8  13  21  34 55
```

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   fib(0) = 0                                                │
│   fib(1) = 1                                                │
│   fib(2) = fib(1) + fib(0) = 1 + 0 = 1                     │
│   fib(3) = fib(2) + fib(1) = 1 + 1 = 2                     │
│   fib(4) = fib(3) + fib(2) = 2 + 1 = 3                     │
│   fib(5) = fib(4) + fib(3) = 3 + 2 = 5                     │
│                                                             │
│   Pattern: fib(n) = fib(n-1) + fib(n-2)                    │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## The Recursive Formula

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   BASE CASES (we know these directly):                      │
│   • fib(0) = 0                                              │
│   • fib(1) = 1                                              │
│                                                             │
│   RECURSIVE CASE:                                           │
│   • fib(n) = fib(n-1) + fib(n-2)                           │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## The Code

```python
def fibonacci(n):
    # Base Cases
    if n == 0:
        return 0
    if n == 1:
        return 1
    
    # Recursive Case: sum of two previous
    return fibonacci(n - 1) + fibonacci(n - 2)
```

---

## The Recursion Tree: Here's Where It Gets Cool!

Unlike factorial (which is a straight line), Fibonacci **branches TWO ways** at each step!

### Recursion Tree for fib(5)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│                              fib(5)                                         │
│                             /      \                                        │
│                           /          \                                      │
│                         /              \                                    │
│                    fib(4)              fib(3)                               │
│                   /      \            /      \                              │
│                 /          \        /          \                            │
│            fib(3)        fib(2)  fib(2)       fib(1)                        │
│           /     \        /    \   /    \         |                          │
│          /       \      /      \ /      \        1                          │
│      fib(2)   fib(1) fib(1) fib(0) fib(1) fib(0)                            │
│      /    \      |      |      |      |      |                              │
│   fib(1) fib(0)  1      1      0      1      0                              │
│      |      |                                                               │
│      1      0                                                               │
│                                                                             │
│   To get the answer: Add up ALL the base case values (1s and 0s)            │
│   at the leaves of the tree!                                                │
│                                                                             │
│   fib(5) = 1 + 0 + 1 + 1 + 0 + 1 + 0 + 1 = 5 ✓                             │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Step-by-Step Visualization with Levels

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│  LEVEL 0:                          fib(5)                                   │
│                                   ↙      ↘                                  │
│  LEVEL 1:                  fib(4)          fib(3)                           │
│                           ↙    ↘          ↙     ↘                           │
│  LEVEL 2:           fib(3)   fib(2)    fib(2)   fib(1)                      │
│                     ↙   ↘     ↙   ↘    ↙   ↘       │                        │
│  LEVEL 3:       fib(2) fib(1) f(1) f(0) f(1) f(0)  1                        │
│                 ↙   ↘    │     │    │    │    │                             │
│  LEVEL 4:    fib(1) fib(0) 1   1    0    1    0                             │
│                │      │                                                     │
│  LEVEL 5:      1      0                                                     │
│                                                                             │
│  Total calls: 15 function calls for just fib(5)!                            │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## How the Tree is Built (Animated)

### Phase 1: Going Down (Making Calls)

```
Step 1:  fib(5) calls fib(4) and fib(3)
         
               fib(5) ← "I need fib(4) AND fib(3)"
              /      \
         fib(4)     fib(3)
         waiting    waiting

Step 2:  fib(4) calls fib(3) and fib(2)
         fib(3) calls fib(2) and fib(1)
         
               fib(5)
              /      \
         fib(4)     fib(3)
         /    \     /    \
     fib(3) fib(2) fib(2) fib(1)
     waiting waiting waiting  │
                              1 ← Base case reached!

... this continues until all branches hit base cases (0 or 1)
```

### Phase 2: Going Up (Returning Values)

```
Step A: Base cases return their values
        
                    fib(5)
                   /      \
              fib(4)      fib(3)
             /     \      /     \
         fib(3)  fib(2) fib(2)  [1]
         /    \   /   \  /   \
      fib(2) [1] [1] [0] [1] [0]
      /    \
    [1]   [0]

Step B: fib(2) can now compute: fib(1) + fib(0) = 1 + 0 = 1

                    fib(5)
                   /      \
              fib(4)      fib(3)
             /     \      /     \
         fib(3)  [1]    [1]     [1]
         /    \   
       [1]   [1]  

Step C: fib(3) computes: fib(2) + fib(1) = 1 + 1 = 2

                    fib(5)
                   /      \
              fib(4)      [2]
             /     \      
           [2]    [1]    

Step D: fib(4) computes: fib(3) + fib(2) = 2 + 1 = 3

                    fib(5)
                   /      \
                [3]       [2]

Step E: fib(5) computes: fib(4) + fib(3) = 3 + 2 = 5  ← ANSWER!

                    [5]
```

---

## Why Recursion Trees Matter

### 1. They Show You the Work Being Done

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   Notice something in the fib(5) tree?                                      │
│                                                                             │
│   • fib(3) is calculated 2 times!                                           │
│   • fib(2) is calculated 3 times!                                           │
│   • fib(1) is calculated 5 times!                                           │
│   • fib(0) is calculated 3 times!                                           │
│                                                                             │
│   This is called "OVERLAPPING SUBPROBLEMS"                                  │
│   We're doing the same work over and over!                                  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 2. They Help Calculate Complexity

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   For Fibonacci with naive recursion:                                       │
│                                                                             │
│   • Height of tree: n levels                                                │
│   • Each node has 2 children (branching factor = 2)                         │
│   • Total nodes ≈ 2^n (exponential!)                                        │
│                                                                             │
│   This is why fib(50) would take FOREVER with naive recursion!              │
│                                                                             │
│   n=5:   15 calls                                                           │
│   n=10:  177 calls                                                          │
│   n=20:  21,891 calls                                                       │
│   n=30:  2,692,537 calls                                                    │
│   n=40:  331,160,281 calls (takes several seconds)                          │
│   n=50:  40 BILLION+ calls (takes hours!)                                   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Smaller Example: fib(4) Tree (Detailed)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│                               fib(4)                                        │
│                              /      \                                       │
│                            /          \                                     │
│                          /              \                                   │
│                      fib(3)            fib(2)                               │
│                     /      \          /      \                              │
│                   /          \      /          \                            │
│               fib(2)       fib(1)  fib(1)    fib(0)                         │
│              /      \         |       |         |                           │
│            /          \       1       1         0                           │
│        fib(1)       fib(0)                                                  │
│           |            |                                                    │
│           1            0                                                    │
│                                                                             │
│   Work backwards:                                                           │
│   • fib(2) = fib(1) + fib(0) = 1 + 0 = 1                                   │
│   • fib(3) = fib(2) + fib(1) = 1 + 1 = 2                                   │
│   • fib(2) = fib(1) + fib(0) = 1 + 0 = 1  (calculated again!)              │
│   • fib(4) = fib(3) + fib(2) = 2 + 1 = 3                                   │
│                                                                             │
│   Total: 9 function calls for fib(4)                                        │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Comparison: Linear vs Binary Recursion

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   FACTORIAL (Linear)              FIBONACCI (Binary)                        │
│   ══════════════════              ══════════════════                        │
│                                                                             │
│        f(5)                              f(5)                               │
│         │                               /    \                              │
│        f(4)                          f(4)    f(3)                           │
│         │                           /   \    /   \                          │
│        f(3)                       f(3) f(2) f(2) f(1)                       │
│         │                         /  \  ...  ...                            │
│        f(2)                      ...                                        │
│         │                                                                   │
│        f(1)                                                                 │
│         │                                                                   │
│        f(0)                                                                 │
│                                                                             │
│   Calls: n+1                      Calls: ~2^n                               │
│   Shape: Line                     Shape: Tree                               │
│   Growth: Linear                  Growth: Exponential                       │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## How to Read a Recursion Tree

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   1. ROOT = The original problem (top)                                      │
│                                                                             │
│   2. INTERNAL NODES = Recursive calls (waiting for children)                │
│                                                                             │
│   3. LEAVES = Base cases (return immediately)                               │
│                                                                             │
│   4. EDGES = Function calls (going down) and returns (going up)             │
│                                                                             │
│   5. DEPTH = How many recursive calls deep we are                           │
│                                                                             │
│                        ROOT                                                 │
│                       /    \                                                │
│                      /      \                                               │
│                 INTERNAL  INTERNAL                                          │
│                 /    \       |                                              │
│              LEAF  LEAF    LEAF                                             │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Practice: Draw the Tree for fib(6)

Try drawing it yourself! Here's a start:

```
                              fib(6)
                             /      \
                           /          \
                      fib(5)          fib(4)
                     /      \        /      \
                    ?        ?      ?        ?


Hint: 
- fib(5) branches to fib(4) and fib(3)
- fib(4) branches to fib(3) and fib(2)
- Keep going until you hit fib(0) and fib(1)

Answer: fib(6) = 8
Total calls: 25 function calls
```

---

## Key Takeaways

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   1. Binary recursion creates TREES, not lines                              │
│                                                                             │
│   2. Trees can grow EXPONENTIALLY (very fast!)                              │
│                                                                             │
│   3. Look for REPEATED WORK in your tree                                    │
│      (This is a hint that memoization can help - advanced topic)            │
│                                                                             │
│   4. Tree HEIGHT = deepest recursion level = stack space needed             │
│                                                                             │
│   5. Tree SIZE (total nodes) = total function calls = time needed           │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Summary

| Aspect | Fibonacci Recursion |
|--------|-------------------|
| **Base Cases** | `fib(0) = 0`, `fib(1) = 1` |
| **Recursive Case** | `fib(n) = fib(n-1) + fib(n-2)` |
| **Tree Shape** | Binary tree (2 branches per node) |
| **Complexity** | O(2^n) - Exponential |
| **Key Insight** | Same subproblems solved multiple times |

**Next:** Check out [_03_sum_of_array.md](_03_sum_of_array.md) to see recursion with arrays!
