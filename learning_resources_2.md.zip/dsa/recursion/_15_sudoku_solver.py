"""37. Sudoku Solver

Write a program to solve a Sudoku puzzle by filling the empty cells.

A sudoku solution must satisfy all of the following rules:

Each of the digits 1-9 must occur exactly once in each row.
Each of the digits 1-9 must occur exactly once in each column.
Each of the digits 1-9 must occur exactly once in each of the 9 3x3 sub-boxes of the grid.
The '.' character indicates empty cells.



Example 1:


Input: board = [["5","3",".",".","7",".",".",".","."],["6",".",".","1","9","5",".",".","."],[".","9","8",".",".",".",".","6","."],["8",".",".",".","6",".",".",".","3"],["4",".",".","8",".","3",".",".","1"],["7",".",".",".","2",".",".",".","6"],[".","6",".",".",".",".","2","8","."],[".",".",".","4","1","9",".",".","5"],[".",".",".",".","8",".",".","7","9"]]
Output: [["5","3","4","6","7","8","9","1","2"],["6","7","2","1","9","5","3","4","8"],["1","9","8","3","4","2","5","6","7"],["8","5","9","7","6","1","4","2","3"],["4","2","6","8","5","3","7","9","1"],["7","1","3","9","2","4","8","5","6"],["9","6","1","5","3","7","2","8","4"],["2","8","7","4","1","9","6","3","5"],["3","4","5","2","8","6","1","7","9"]]
Explanation: The input board is shown above and the only valid solution is shown below:




Constraints:

board.length == 9
board[i].length == 9
board[i][j] is a digit or '.'.
It is guaranteed that the input board has only one solution.
"""

# ============================================================================
# PROBLEM UNDERSTANDING
# ============================================================================
#
# We need to fill a 9x9 Sudoku grid where:
#   - Some cells are already filled with digits '1' to '9'
#   - Empty cells are marked with '.'
#   - We must fill all empty cells following Sudoku rules
#
# Sudoku Rules:
#   1. Each row must contain digits 1-9 exactly once
#   2. Each column must contain digits 1-9 exactly once
#   3. Each 3x3 sub-box must contain digits 1-9 exactly once
#
# Input: A 9x9 board (list of lists) with some cells filled
# Output: The same board modified in-place with the solution
#
# ============================================================================
# WHY BACKTRACKING IS THE IDEAL APPROACH
# ============================================================================
#
# This is a classic constraint satisfaction problem (CSP). Here's why
# backtracking works perfectly:
#
# 1. DECISION TREE STRUCTURE:
#    - At each empty cell, we have up to 9 choices (digits 1-9)
#    - We can model this as a tree where each level = one empty cell
#    - Leaves of the tree = complete configurations
#
# 2. CONSTRAINT PROPAGATION:
#    - Most choices are invalid due to Sudoku rules
#    - Backtracking "prunes" invalid branches early
#    - We don't waste time exploring dead-end paths
#
# 3. GUARANTEED SOLUTION:
#    - The problem states exactly one solution exists
#    - Backtracking will find it by exhaustive search
#
# Alternative approaches and why they're worse:
#   - Brute force all permutations: 9^81 possibilities (infeasible)
#   - Dynamic programming: No overlapping subproblems to exploit
#   - Greedy: Can't guarantee valid solution
#
# ============================================================================
# VISUAL REPRESENTATION OF 3x3 SUB-BOX CALCULATION
# ============================================================================
#
# The Sudoku board is divided into 9 sub-boxes (3x3 each):
#
#     Col:  0 1 2   3 4 5   6 7 8
#          +-------+-------+-------+
#   Row 0  | Box 0 | Box 1 | Box 2 |
#   Row 1  |  (0,0)| (0,1) | (0,2) |
#   Row 2  |       |       |       |
#          +-------+-------+-------+
#   Row 3  | Box 3 | Box 4 | Box 5 |
#   Row 4  |  (1,0)| (1,1) | (1,2) |
#   Row 5  |       |       |       |
#          +-------+-------+-------+
#   Row 6  | Box 6 | Box 7 | Box 8 |
#   Row 7  |  (2,0)| (2,1) | (2,2) |
#   Row 8  |       |       |       |
#          +-------+-------+-------+
#
# KEY FORMULA: Given cell at (row, col), find its 3x3 box's top-left corner:
#
#   box_start_row = (row // 3) * 3
#   box_start_col = (col // 3) * 3
#
# Examples:
#   - Cell (0, 0): box_start = (0, 0) -> Box 0
#   - Cell (1, 2): box_start = (0, 0) -> Box 0
#   - Cell (4, 4): box_start = (3, 3) -> Box 4 (center box)
#   - Cell (7, 8): box_start = (6, 6) -> Box 8
#   - Cell (2, 5): box_start = (0, 3) -> Box 1
#
# Detailed breakdown for cell (4, 7):
#   row = 4, col = 7
#   box_start_row = (4 // 3) * 3 = 1 * 3 = 3
#   box_start_col = (7 // 3) * 3 = 2 * 3 = 6
#   This cell belongs to Box 5 (starts at row=3, col=6)
#
# ============================================================================
# ALGORITHM: BACKTRACKING APPROACH
# ============================================================================
#
# High-Level Steps:
#   1. Find the next empty cell (marked with '.')
#   2. If no empty cell exists, puzzle is solved -> return True
#   3. Try placing digits '1' to '9' in the empty cell
#   4. For each digit:
#      a. Check if placement is valid (row, column, box constraints)
#      b. If valid, place the digit and recurse to solve remaining cells
#      c. If recursion succeeds, return True (solution found)
#      d. If recursion fails, remove the digit (backtrack) and try next
#   5. If no digit works, return False (trigger backtracking)
#
# ============================================================================

from typing import List


class Solution:
    """
    Sudoku Solver using Backtracking.

    The algorithm explores all possible digit placements recursively,
    backtracking when a placement leads to an invalid state.

    Time Complexity: O(9^(n*n)) in worst case, where n=9
                     In practice, much faster due to pruning from constraints.
                     For a typical Sudoku with ~20-30 empty cells, the actual
                     runtime is very fast because most branches are pruned early.

    Space Complexity: O(n*n) = O(81) = O(1) for recursion stack
                      The maximum depth of recursion is the number of empty cells.
    """

    def solveSudoku(self, board: List[List[str]]) -> None:
        """
        Solve the Sudoku puzzle in-place.

        Args:
            board: 9x9 grid where '.' represents empty cells

        Returns:
            None (modifies board in-place)
        """
        self._solve(board)

    def _solve(self, board: List[List[str]]) -> bool:
        """
        Recursive backtracking function to solve Sudoku.

        This function:
        1. Finds the first empty cell
        2. Tries digits 1-9 in that cell
        3. Recurses to solve the rest
        4. Backtracks if no valid digit works

        Returns:
            True if puzzle is solved, False if backtracking is needed
        """

        # Step 1: Find the next empty cell
        # We scan row by row, left to right
        for row in range(9):
            for col in range(9):

                # Found an empty cell
                if board[row][col] == '.':

                    # Step 2: Try placing each digit '1' to '9'
                    for digit in '123456789':

                        # Step 3: Check if this digit is valid at (row, col)
                        if self._is_valid(board, row, col, digit):

                            # Step 4: Place the digit (make a choice)
                            board[row][col] = digit

                            # Step 5: Recursively try to solve the rest
                            if self._solve(board):
                                # Solution found! Propagate success upward
                                return True

                            # Step 6: Backtrack - remove the digit
                            # This means our choice didn't lead to a solution
                            board[row][col] = '.'

                    # Step 7: No digit worked for this cell
                    # Return False to trigger backtracking in the caller
                    return False

        # No empty cell found -> puzzle is completely solved!
        return True

    def _is_valid(self, board: List[List[str]], row: int, col: int, digit: str) -> bool:
        """
        Check if placing 'digit' at (row, col) is valid.

        Three constraints must be satisfied:
        1. No duplicate in the same row
        2. No duplicate in the same column
        3. No duplicate in the same 3x3 sub-box

        Args:
            board: Current state of the Sudoku board
            row: Row index (0-8)
            col: Column index (0-8)
            digit: Character '1' to '9' to be placed

        Returns:
            True if placement is valid, False otherwise
        """

        # Constraint 1: Check the entire row
        # Scan all 9 columns in this row
        for c in range(9):
            if board[row][c] == digit:
                return False  # Digit already exists in this row

        # Constraint 2: Check the entire column
        # Scan all 9 rows in this column
        for r in range(9):
            if board[r][col] == digit:
                return False  # Digit already exists in this column

        # Constraint 3: Check the 3x3 sub-box
        # Find the top-left corner of the box containing (row, col)
        box_start_row = (row // 3) * 3  # Integer division then multiply
        box_start_col = (col // 3) * 3

        # Scan all 9 cells in the 3x3 box
        for r in range(box_start_row, box_start_row + 3):
            for c in range(box_start_col, box_start_col + 3):
                if board[r][c] == digit:
                    return False  # Digit already exists in this box

        # All three constraints satisfied
        return True


# ============================================================================
# DRY RUN TRACE
# ============================================================================
#
# Let's trace through a portion of the example to understand the algorithm.
#
# Initial Board (partial view of first 3 rows):
#
#     Col:  0   1   2   3   4   5   6   7   8
#          +---+---+---+---+---+---+---+---+---+
#   Row 0  | 5 | 3 | . | . | 7 | . | . | . | . |
#          +---+---+---+---+---+---+---+---+---+
#   Row 1  | 6 | . | . | 1 | 9 | 5 | . | . | . |
#          +---+---+---+---+---+---+---+---+---+
#   Row 2  | . | 9 | 8 | . | . | . | . | 6 | . |
#          +---+---+---+---+---+---+---+---+---+
#
# -------------------------------------------------------------------------
# STEP 1: _solve() is called
# -------------------------------------------------------------------------
# Scanning for first empty cell...
# Found empty cell at (0, 2)
#
# Try digit '1' at (0, 2):
#   - Row 0 check: No '1' in row -> OK
#   - Col 2 check: Has '8' at (2,2), no '1' -> OK
#   - Box check (0,0)-(2,2): Contains 5,3,6,9,8 -> No '1' -> OK
#   Valid! Place '1' at (0, 2)
#
#   Board now:
#     Row 0: | 5 | 3 | 1 | . | 7 | . | . | . | . |
#
#   Recurse to _solve()...
#
# -------------------------------------------------------------------------
# STEP 2: _solve() called recursively
# -------------------------------------------------------------------------
# Scanning for first empty cell...
# Found empty cell at (0, 3)
#
# Try digit '1' at (0, 3):
#   - Row 0 check: '1' exists at (0,2) -> INVALID
#
# Try digit '2' at (0, 3):
#   - Row 0 check: No '2' -> OK
#   - Col 3 check: Has '1', '8', '4' -> No '2' -> OK
#   - Box check (0,3)-(2,5): Contains 7,1,9,5 -> No '2' -> OK
#   Valid! Place '2' at (0, 3)
#
#   Board now:
#     Row 0: | 5 | 3 | 1 | 2 | 7 | . | . | . | . |
#
#   Recurse to _solve()...
#
# -------------------------------------------------------------------------
# STEP 3: Continue recursion...
# -------------------------------------------------------------------------
# (Many more recursive calls happen here)
#
# Eventually, the algorithm may hit a dead end:
#
# Example Dead End Scenario:
#   At some cell (say row 5, col 4), after many placements,
#   none of digits 1-9 are valid because they all violate some constraint.
#
#   When this happens:
#   1. _is_valid returns False for all digits 1-9
#   2. The for loop completes without finding a valid digit
#   3. Return False to trigger backtracking
#
# -------------------------------------------------------------------------
# BACKTRACKING IN ACTION
# -------------------------------------------------------------------------
#
# When _solve() returns False:
#   1. The calling function catches this False return
#   2. It resets the current cell back to '.'
#   3. It tries the next digit in its loop
#
# For example, if '1' at (0,2) eventually leads to a dead end:
#   - board[0][2] is reset to '.'
#   - We try '2' at (0,2)
#   - Process repeats
#
# This "try, fail, undo, try next" is the essence of backtracking!
#
# -------------------------------------------------------------------------
# FINAL SOLUTION FOUND
# -------------------------------------------------------------------------
#
# Eventually, a path through the decision tree is found where:
#   - All empty cells are filled
#   - All constraints are satisfied
#   - The for loops complete without finding any empty cell
#   - Return True propagates up, ending the algorithm
#
# Final Board:
#     Col:  0   1   2   3   4   5   6   7   8
#          +---+---+---+---+---+---+---+---+---+
#   Row 0  | 5 | 3 | 4 | 6 | 7 | 8 | 9 | 1 | 2 |
#          +---+---+---+---+---+---+---+---+---+
#   Row 1  | 6 | 7 | 2 | 1 | 9 | 5 | 3 | 4 | 8 |
#          +---+---+---+---+---+---+---+---+---+
#   Row 2  | 1 | 9 | 8 | 3 | 4 | 2 | 5 | 6 | 7 |
#          +---+---+---+---+---+---+---+---+---+
#   Row 3  | 8 | 5 | 9 | 7 | 6 | 1 | 4 | 2 | 3 |
#          +---+---+---+---+---+---+---+---+---+
#   Row 4  | 4 | 2 | 6 | 8 | 5 | 3 | 7 | 9 | 1 |
#          +---+---+---+---+---+---+---+---+---+
#   Row 5  | 7 | 1 | 3 | 9 | 2 | 4 | 8 | 5 | 6 |
#          +---+---+---+---+---+---+---+---+---+
#   Row 6  | 9 | 6 | 1 | 5 | 3 | 7 | 2 | 8 | 4 |
#          +---+---+---+---+---+---+---+---+---+
#   Row 7  | 2 | 8 | 7 | 4 | 1 | 9 | 6 | 3 | 5 |
#          +---+---+---+---+---+---+---+---+---+
#   Row 8  | 3 | 4 | 5 | 2 | 8 | 6 | 1 | 7 | 9 |
#          +---+---+---+---+---+---+---+---+---+
#
# ============================================================================
# DRY RUN 2: Detailed Trace of Validation Function
# ============================================================================
#
# Let's verify why '4' is the correct digit for cell (0, 2) in the solution.
#
# Board context for cell (0, 2):
#
#   Row 0: [5, 3, ?, ?, 7, ?, ?, ?, ?] (need to check: 5, 3, 7 present)
#   Col 2: [?, ?, 8, ?, ?, ?, ?, ?, ?] (from partial view: 8 present)
#
# Full Row 0 initially: 5, 3, _, _, 7, _, _, _, _
# Full Col 2 initially: _, _, 8, _, _, _, _, _, _
# Box 0 (rows 0-2, cols 0-2): 5, 3, 6, _, 9, 8
#
# What digits are already used?
#   Row 0: {5, 3, 7}
#   Col 2: {8}
#   Box 0: {5, 3, 6, 9, 8}
#
# Combined used digits: {3, 5, 6, 7, 8, 9}
# Available digits: {1, 2, 4}
#
# The algorithm tries 1, 2, 3, 4... in order.
# - '1' might be tried but leads to dead end later
# - '2' might be tried but leads to dead end later
# - Eventually '4' is found to be the correct choice
#
# This shows how backtracking explores multiple possibilities!
#
# ================================================================================
#                    RECURSION TREE FOR SUDOKU SOLVER
# ================================================================================
#
# The Sudoku backtracking algorithm explores a decision tree where:
#   - Each LEVEL represents an empty cell being filled
#   - Each BRANCH represents trying a digit '1' to '9'
#   - PRUNING happens when a digit violates row/col/box constraints
#   - BACKTRACKING occurs when all digits fail at a cell
#
# ================================================================================
#                    SIMPLIFIED 4x4 SUDOKU EXAMPLE
# ================================================================================
#
# To visualize the recursion tree more clearly, let's use a 4x4 Sudoku
# (digits 1-4, 2x2 sub-boxes) instead of the full 9x9.
#
# Initial 4x4 Board:
#
#     Col:  0   1   2   3
#          +---+---+---+---+
#   Row 0  | 1 | . | . | 4 |
#          +---+---+---+---+
#   Row 1  | . | . | 1 | . |
#          +---+---+---+---+
#   Row 2  | . | 1 | . | . |
#          +---+---+---+---+
#   Row 3  | 4 | . | . | 1 |
#          +---+---+---+---+
#
# Empty cells to fill (in order): (0,1), (0,2), (1,0), (1,1), (1,3), (2,0), (2,2), (2,3), (3,1), (3,2)
#
# Legend for Tree:
#   [V] = Valid placement (constraints satisfied)
#   [X] = Invalid (violates row/column/box constraint)
#   <-- = Backtrack (all digits failed, undo and try next)
#   *** = Solution path
#
# ================================================================================
#                    PARTIAL RECURSION TREE (First 4 Cells)
# ================================================================================
#
#                                    solve()
#                                 First empty: (0,1)
#                                       |
#           +-------------+-------------+-------------+-------------+
#           |             |             |             |
#       try '1'       try '2'       try '3'       try '4'
#           |             |             |             |
#        (0,1)='1'     (0,1)='2'    (0,1)='3'     (0,1)='4'
#           |             |             |             |
#         [X]           [V]           [V]           [X]
#      col 1 has '1'   VALID!       VALID!      row 0 has '4'
#      at (2,1)           |             |
#                         |             |
#                         v             v
#                    solve()        solve()
#                 next: (0,2)     next: (0,2)
#                         |             |
#               +---------+---------+   +---------+---------+
#               |    |    |    |    |   |    |    |    |    |
#              '1'  '2'  '3'  '4'  <--  '1'  '2'  '3'  '4'
#               |    |    |    |        |    |    |    |
#              [X]  [X]  [V]  [X]      [X]  [V]  [X]  [X]
#              row  col  OK   row      row  OK   row  row
#              has  has       has      has       has  has
#              '1'  '2'       '4'      '1'       '3'  '4'
#                        |                  |
#                        v                  v
#                   solve()            solve()
#                 next: (1,0)        next: (1,0)
#                        |                  |
#                   ... continues ...  ... continues ...
#
# ================================================================================
#                    DETAILED TRACE: Following the '2' -> '3' Path
# ================================================================================
#
#   (0,1)='2' [V]  --> Board: | 1 | 2 | . | 4 |
#         |                   | . | . | 1 | . |
#         |                   | . | 1 | . | . |
#         v                   | 4 | . | . | 1 |
#
#   (0,2)='3' [V]  --> Board: | 1 | 2 | 3 | 4 |  <-- Row 0 complete!
#         |                   | . | . | 1 | . |
#         |                   | . | 1 | . | . |
#         v                   | 4 | . | . | 1 |
#
#   (1,0)=? Try digits:
#         '1' [X] - row 1 has '1' at (1,2)
#         '2' [X] - col 0 has... wait, no '2'. Box check: box(0,0) has '1','2'
#                   So '2' is in the box! [X]
#         '3' [V] - VALID! Place '3'
#
#   (1,0)='3' [V]  --> Board: | 1 | 2 | 3 | 4 |
#         |                   | 3 | . | 1 | . |
#         |                   | . | 1 | . | . |
#         v                   | 4 | . | . | 1 |
#
#   (1,1)=? Try digits:
#         '1' [X] - col 1 has '1' at (2,1)
#         '2' [X] - box(0,0) has '1','2','3' already
#         '3' [X] - row 1 has '3' at (1,0)
#         '4' [V] - VALID!
#
#   (1,1)='4' [V]  --> Board: | 1 | 2 | 3 | 4 |
#         |                   | 3 | 4 | 1 | . |
#         |                   | . | 1 | . | . |
#         v                   | 4 | . | . | 1 |
#
#   (1,3)=? Try digits:
#         '1' [X] - row 1 has '1'
#         '2' [V] - VALID!
#
#   ... continues until solution found or backtrack needed ...
#
# ================================================================================
#                    BACKTRACKING SCENARIO
# ================================================================================
#
# Let's say we followed a wrong path earlier. Suppose we tried (0,1)='3':
#
#   (0,1)='3' [V]  --> Board: | 1 | 3 | . | 4 |
#         |                   | . | . | 1 | . |
#         |                   | . | 1 | . | . |
#         v                   | 4 | . | . | 1 |
#
#   (0,2)=? Try digits:
#         '1' [X] - row 0 has '1'
#         '2' [V] - VALID!
#
#   (0,2)='2' [V]  --> Board: | 1 | 3 | 2 | 4 |
#         |                   | . | . | 1 | . |
#         |                   | . | 1 | . | . |
#         v                   | 4 | . | . | 1 |
#
#   (1,0)=? Try digits:
#         '1' [X] - row 1 has '1'
#         '2' [X] - col 0 has... box(0,0) has '1','3'. Col 0 has '1','4'. OK for col.
#                   But box(0,0) = cells (0,0),(0,1),(1,0),(1,1) = '1','3','.','.'
#                   '2' not in box, not in col, not in row --> [V]
#         Actually '2' is VALID!
#
#   (1,0)='2' [V]  --> Board: | 1 | 3 | 2 | 4 |
#         |                   | 2 | . | 1 | . |
#         |                   | . | 1 | . | . |
#         v                   | 4 | . | . | 1 |
#
#   (1,1)=? Try digits:
#         '1' [X] - col 1 has '1' at (2,1)
#         '2' [X] - row 1 has '2'
#         '3' [X] - box(0,0) has '3' at (0,1)
#         '4' [V] - VALID!
#
#   (1,1)='4' [V]  --> Board: | 1 | 3 | 2 | 4 |
#         |                   | 2 | 4 | 1 | . |
#         |                   | . | 1 | . | . |
#         v                   | 4 | . | . | 1 |
#
#   (1,3)=? Try digits:
#         '1' [X] - row 1 has '1'
#         '2' [X] - row 1 has '2'
#         '3' [V] - VALID!
#
#   Continue... eventually may hit a dead end, triggering BACKTRACK:
#
#   (2,0)=? Try digits:
#         '1' [X] - row 2 has '1'
#         '2' [X] - col 0 has '2'
#         '3' [X] - col 0 has... wait col 0 = '1','2','.','4' -> no '3'
#                   box(2,0) = (2,0),(2,1),(3,0),(3,1) = '.','1','4','.'
#                   '3' not in box, not in col, not in row --> [V]
#
#   The algorithm keeps exploring until it either:
#   1. Finds a complete valid solution, OR
#   2. Reaches a cell where NO digit is valid --> BACKTRACK!
#
# ================================================================================
#                    BACKTRACK TRIGGER EXAMPLE
# ================================================================================
#
#   Imagine at some cell (r, c), after trying all digits:
#
#                            solve()
#                          cell: (r, c)
#                               |
#       +-------+-------+-------+-------+-------+-------+-------+-------+-------+
#       |       |       |       |       |       |       |       |       |
#      '1'     '2'     '3'     '4'     '5'     '6'     '7'     '8'     '9'
#       |       |       |       |       |       |       |       |       |
#      [X]     [X]     [X]     [X]     [X]     [X]     [X]     [X]     [X]
#      row     col     box     row     col     box     row     col     box
#
#                         ALL DIGITS INVALID!
#                                |
#                                v
#                        return False
#                                |
#                                v
#                     *** BACKTRACK TO PREVIOUS CELL ***
#                                |
#                                v
#                     Previous cell tries its NEXT digit
#                     (or backtracks further if all tried)
#
# ================================================================================
#                    RECURSION TREE FOR 9x9 SUDOKU (First 3 Empty Cells)
# ================================================================================
#
# Using the actual problem input:
#   Row 0: | 5 | 3 | . | . | 7 | . | . | . | . |
#
# First 3 empty cells: (0,2), (0,3), (0,5)
#
#                                    solve()
#                                 First empty: (0,2)
#                                       |
#       +-------+-------+-------+-------+-------+-------+-------+-------+-------+
#       |       |       |       |       |       |       |       |       |
#      '1'     '2'     '3'     '4'     '5'     '6'     '7'     '8'     '9'
#       |       |       |       |       |       |       |       |       |
#      [V]     [V]     [X]     [V]     [X]     [X]     [X]     [X]     [X]
#       |       |    row has   |    row/col  col    row    box     box
#       |       |    '3' at    |    has '5'  has    has    has     has
#       |       |    (0,1)     |             '6'    '7'    '8'     '9'
#       v       v              v
#   solve()  solve()       solve()
#  (0,3)=?  (0,3)=?       (0,3)=?
#       |       |              |
#   try '1'-'9'   ...      try '1'-'9'
#       |
#   +---+---+---+---+---+---+---+---+---+
#   |   |   |   |   |   |   |   |   |
#  '1' '2' '3' '4' '5' '6' '7' '8' '9'
#   |   |   |   |   |   |   |   |   |
#  [X] [V] [X] [V] [X] [V] [X] [X] [X]
#  row OK  row OK  row OK  row box box
#  '1' --> '3' --> '5' --> '7' '8' '9'
#      |       |       |
#      v       v       v
#  solve() solve() solve()
#  (0,5)=? (0,5)=? (0,5)=?
#      |       ...     ...
#      |
#  +---+---+---+---+---+---+---+---+---+
#  |   |   |   |   |   |   |   |   |
# '1' '2' '3' '4' '5' '6' '7' '8' '9'
#  |   |   |   |   |   |   |   |   |
# [X] [X] [X] [X] [X] [V] [X] [V] [V]
# row (0,2) row row row OK row OK OK
# has has '1' has has has  has     <-- Multiple valid!
# '1'         '3' '4' '5'  '7'          Try '6' first...
#
#                              ...continues deeper...
#
# ================================================================================
#                    COMPLETE BACKTRACKING FLOW SUMMARY
# ================================================================================
#
#                              solve(empty_cells_remaining)
#                                           |
#                                           v
#                              +------------------------+
#                              | Find first empty cell  |
#                              | at position (row, col) |
#                              +------------------------+
#                                           |
#                         +-----------------+-----------------+
#                         |                                   |
#                    No empty cell                      Found empty cell
#                    (all filled)                       at (row, col)
#                         |                                   |
#                         v                                   v
#                  +-----------+                    +------------------+
#                  | return    |                    | for digit in     |
#                  | True      |                    | '1' to '9':      |
#                  | SOLVED!   |                    +------------------+
#                  +-----------+                              |
#                                                             v
#                                               +---------------------------+
#                                               | is_valid(row, col, digit) |
#                                               +---------------------------+
#                                                       |           |
#                                                    True        False
#                                                       |           |
#                                                       v           v
#                                          +----------------+   +----------+
#                                          | Place digit    |   | Try next |
#                                          | board[r][c]=d  |   | digit    |
#                                          +----------------+   +----------+
#                                                    |
#                                                    v
#                                          +------------------+
#                                          | solve() recurse  |
#                                          +------------------+
#                                               |         |
#                                            True      False
#                                               |         |
#                                               v         v
#                                        +---------+  +-------------+
#                                        | return  |  | Backtrack:  |
#                                        | True    |  | board[r][c] |
#                                        | Done!   |  | = '.'       |
#                                        +---------+  | Try next d  |
#                                                     +-------------+
#                                                            |
#                                                            v
#                                                  +-------------------+
#                                                  | All digits tried? |
#                                                  +-------------------+
#                                                       |         |
#                                                      Yes        No
#                                                       |         |
#                                                       v         v
#                                              +-----------+  +----------+
#                                              | return    |  | Continue |
#                                              | False     |  | loop     |
#                                              | BACKTRACK |  +----------+
#                                              +-----------+
#
# ================================================================================
#                    KEY OBSERVATIONS FROM THE RECURSION TREE
# ================================================================================
#
# 1. BRANCHING FACTOR:
#    - At each empty cell, up to 9 branches (digits '1'-'9')
#    - Many branches pruned immediately by is_valid()
#    - Typical effective branching factor is 2-4 (due to constraints)
#
# 2. DEPTH OF TREE:
#    - Equals number of empty cells
#    - For a typical Sudoku puzzle: 40-60 empty cells
#    - Maximum depth: 81 (completely empty board)
#
# 3. PRUNING POWER:
#    - Row constraint eliminates ~1-8 digits per cell
#    - Column constraint eliminates additional digits
#    - Box constraint eliminates remaining conflicts
#    - Combined: Often only 1-3 valid digits per cell
#
# 4. BACKTRACKING FREQUENCY:
#    - Early cells: Less backtracking (more freedom)
#    - Later cells: More constraints, more backtracking
#    - Dead ends propagate back until a cell with untried digits
#
# 5. SOLUTION GUARANTEE:
#    - The problem guarantees exactly one solution exists
#    - Algorithm will find it by exhaustive search with pruning
#    - Backtracking ensures we don't miss any possibilities
#
# ================================================================================

# ============================================================================
# COMPLEXITY ANALYSIS
# ============================================================================
#
# TIME COMPLEXITY: O(9^m) where m = number of empty cells
#
#   Worst Case Analysis:
#   - Each empty cell can potentially have 9 choices
#   - With m empty cells, maximum 9^m combinations
#   - For a completely empty board, m = 81, so O(9^81)
#
#   Practical Analysis:
#   - Sudoku constraints drastically prune the search space
#   - Most branches are cut off early by _is_valid()
#   - Typical puzzles with 20-30 empty cells solve in milliseconds
#   - The effective branching factor is much less than 9
#
# SPACE COMPLEXITY: O(m) where m = number of empty cells
#
#   - Recursion stack depth = number of empty cells
#   - Each recursive call uses O(1) extra space
#   - No additional data structures used
#   - Maximum stack depth = 81 (completely empty board)
#   - Effectively O(1) since board size is fixed at 9x9
#
# ============================================================================
# EDGE CASES AND INTERVIEW TIPS
# ============================================================================
#
# Edge Case 1: Almost Full Board
#   - Only 1-2 empty cells
#   - Algorithm quickly fills them
#   - Almost no backtracking needed
#
# Edge Case 2: Multiple Valid Options Initially
#   - First empty cell has many valid digits
#   - Algorithm may backtrack multiple times
#   - Solution is still found efficiently
#
# Edge Case 3: Invalid Initial Board (not in constraints but good to know)
#   - If the initial board violates Sudoku rules
#   - Algorithm would return False after trying all options
#   - But problem guarantees valid input with unique solution
#
# Interview Tips:
#   1. Start by explaining the problem constraints clearly
#   2. Mention why backtracking is appropriate (decision tree + pruning)
#   3. Draw the 3x3 box calculation - interviewers love visual explanations
#   4. Walk through a small example step by step
#   5. Discuss time complexity honestly (worst case vs practical)
#   6. Mention potential optimizations (see below)
#
# ============================================================================
# OPTIMIZED VERSION: Using Sets for O(1) Lookups
# ============================================================================
#
# The basic solution checks constraints in O(n) time where n=9.
# We can optimize validation to O(1) using pre-computed sets.

class SolutionOptimized:
    """
    Optimized Sudoku Solver using Sets for O(1) constraint checking.

    Instead of scanning rows, columns, and boxes each time,
    we maintain sets of used digits for instant lookup.

    Time Complexity: Same asymptotic complexity, but faster in practice
                     due to O(1) validation instead of O(27).

    Space Complexity: O(n^2) = O(81) for the sets
                      (9 rows + 9 columns + 9 boxes) * up to 9 digits each
    """

    def solveSudoku(self, board: List[List[str]]) -> None:
        """
        Solve Sudoku with optimized constraint tracking.
        """
        # Initialize sets to track used digits
        # Each set contains digits already present in that row/col/box
        rows = [set() for _ in range(9)]      # rows[i] = digits in row i
        cols = [set() for _ in range(9)]      # cols[j] = digits in col j
        boxes = [set() for _ in range(9)]     # boxes[k] = digits in box k

        # Pre-populate sets with existing digits on the board
        for r in range(9):
            for c in range(9):
                if board[r][c] != '.':
                    digit = board[r][c]
                    rows[r].add(digit)
                    cols[c].add(digit)
                    box_idx = (r // 3) * 3 + (c // 3)  # Map (r,c) to box 0-8
                    boxes[box_idx].add(digit)

        def solve() -> bool:
            """Recursive backtracking with O(1) validation."""

            # Find next empty cell
            for r in range(9):
                for c in range(9):
                    if board[r][c] == '.':
                        box_idx = (r // 3) * 3 + (c // 3)

                        # Try each digit
                        for digit in '123456789':
                            # O(1) validation using sets
                            if (digit not in rows[r] and
                                digit not in cols[c] and
                                digit not in boxes[box_idx]):

                                # Place digit and update sets
                                board[r][c] = digit
                                rows[r].add(digit)
                                cols[c].add(digit)
                                boxes[box_idx].add(digit)

                                # Recurse
                                if solve():
                                    return True

                                # Backtrack: remove digit from board and sets
                                board[r][c] = '.'
                                rows[r].remove(digit)
                                cols[c].remove(digit)
                                boxes[box_idx].remove(digit)

                        # No valid digit found
                        return False

            # All cells filled
            return True

        solve()


# ============================================================================
# BOX INDEX CALCULATION VISUALIZATION
# ============================================================================
#
# For the optimized solution, we need to map (row, col) to a box index 0-8.
#
# Formula: box_idx = (row // 3) * 3 + (col // 3)
#
# Visual mapping:
#
#     Col:    0   1   2     3   4   5     6   7   8
#           +---+---+---+ +---+---+---+ +---+---+---+
#   Row 0   |   Box 0   | |   Box 1   | |   Box 2   |
#   Row 1   | idx = 0   | | idx = 1   | | idx = 2   |
#   Row 2   |           | |           | |           |
#           +---+---+---+ +---+---+---+ +---+---+---+
#   Row 3   |   Box 3   | |   Box 4   | |   Box 5   |
#   Row 4   | idx = 3   | | idx = 4   | | idx = 5   |
#   Row 5   |           | |           | |           |
#           +---+---+---+ +---+---+---+ +---+---+---+
#   Row 6   |   Box 6   | |   Box 7   | |   Box 8   |
#   Row 7   | idx = 6   | | idx = 7   | | idx = 8   |
#   Row 8   |           | |           | |           |
#           +---+---+---+ +---+---+---+ +---+---+---+
#
# Examples:
#   (0, 0): (0//3)*3 + (0//3) = 0*3 + 0 = 0
#   (1, 4): (1//3)*3 + (4//3) = 0*3 + 1 = 1
#   (4, 4): (4//3)*3 + (4//3) = 1*3 + 1 = 4  (center box)
#   (7, 7): (7//3)*3 + (7//3) = 2*3 + 2 = 8
#   (5, 2): (5//3)*3 + (2//3) = 1*3 + 0 = 3
#
# ============================================================================
# TEST CODE
# ============================================================================

if __name__ == "__main__":
    # Test with the example from the problem
    board = [
        ["5","3",".",".","7",".",".",".","."],
        ["6",".",".","1","9","5",".",".","."],
        [".","9","8",".",".",".",".","6","."],
        ["8",".",".",".","6",".",".",".","3"],
        ["4",".",".","8",".","3",".",".","1"],
        ["7",".",".",".","2",".",".",".","6"],
        [".","6",".",".",".",".","2","8","."],
        [".",".",".","4","1","9",".",".","5"],
        [".",".",".",".","8",".",".","7","9"]
    ]

    print("Original Board:")
    print("-" * 37)
    for i, row in enumerate(board):
        if i % 3 == 0 and i != 0:
            print("-" * 37)
        row_str = ""
        for j, cell in enumerate(row):
            if j % 3 == 0:
                row_str += "| "
            row_str += (cell if cell != '.' else ' ') + " "
        row_str += "|"
        print(row_str)
    print("-" * 37)

    # Solve using the basic solution
    solver = Solution()
    solver.solveSudoku(board)

    print("\nSolved Board:")
    print("-" * 37)
    for i, row in enumerate(board):
        if i % 3 == 0 and i != 0:
            print("-" * 37)
        row_str = ""
        for j, cell in enumerate(row):
            if j % 3 == 0:
                row_str += "| "
            row_str += cell + " "
        row_str += "|"
        print(row_str)
    print("-" * 37)

    # Verify solution
    print("\nSolution Verification:")
    expected = [
        ["5","3","4","6","7","8","9","1","2"],
        ["6","7","2","1","9","5","3","4","8"],
        ["1","9","8","3","4","2","5","6","7"],
        ["8","5","9","7","6","1","4","2","3"],
        ["4","2","6","8","5","3","7","9","1"],
        ["7","1","3","9","2","4","8","5","6"],
        ["9","6","1","5","3","7","2","8","4"],
        ["2","8","7","4","1","9","6","3","5"],
        ["3","4","5","2","8","6","1","7","9"]
    ]

    if board == expected:
        print("SUCCESS: Solution matches expected output!")
    else:
        print("MISMATCH: Solution differs from expected output.")
