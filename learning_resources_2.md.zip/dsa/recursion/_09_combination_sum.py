"""
================================================================================
                        COMBINATION SUM PROBLEM
                     The "Stay or Move" Pattern
================================================================================

PROBLEM STATEMENT:
-----------------
Given an array of DISTINCT integers 'candidates' and a target integer 'target',
return a list of all UNIQUE combinations of candidates where the chosen numbers
sum to target.

KEY CONSTRAINT: The same number may be chosen UNLIMITED number of times!

Example 1: candidates = [2,3,6,7], target = 7
Output: [[2,2,3], [7]]
Explanation: 2+2+3 = 7, and 7 = 7

Example 2: candidates = [2,3,5], target = 8
Output: [[2,2,2,2], [2,3,3], [3,5]]

Example 3: candidates = [2], target = 1
Output: []  (no way to make 1 from [2])

================================================================================
SECTION 1: WHY IS THIS PROBLEM SPECIAL?
================================================================================

This problem is DIFFERENT from regular Subsequence Sum!

+------------------------------------------------------------------+
|  SUBSEQUENCE SUM (Each element once)    |  COMBINATION SUM       |
|  vs                                     |  (Unlimited usage)     |
+------------------------------------------------------------------+
|  candidates = [2,3], target = 5         |  candidates = [2,3],   |
|                                         |  target = 5            |
|  Can we make 5?                         |  Can we make 5?        |
|  - Take 2, Take 3 = 5 (YES!)            |  - 2+3 = 5 (YES!)      |
|  - That's it! Can't reuse elements      |  - 2+2+... (keep going)|
|                                         |  We CAN reuse elements!|
+------------------------------------------------------------------+

In Subsequence Sum:
    - Each element can be used AT MOST ONCE
    - After taking/not-taking, we always move to next index
    - Pattern: Take and Move, or Skip and Move

In Combination Sum:
    - Each element can be used UNLIMITED times
    - After taking, we STAY at same index (might take again!)
    - After not-taking, we move to next index
    - Pattern: Take and STAY, or Skip and Move

================================================================================
SECTION 2: THE "STAY OR MOVE" PATTERN (THE KEY INSIGHT!)
================================================================================

This is the MOST IMPORTANT concept for this problem!

                    +---------------------------+
                    |     AT INDEX i            |
                    |   with element = arr[i]   |
                    +---------------------------+
                              |
              +---------------+---------------+
              |                               |
              v                               v
    +-------------------+           +-------------------+
    |  TAKE arr[i]      |           |  NOT TAKE arr[i]  |
    |  (Include it)     |           |  (Skip it)        |
    +-------------------+           +-------------------+
              |                               |
              v                               v
    +-------------------+           +-------------------+
    |  STAY at index i  |           |  MOVE to index i+1|
    |  (Can take again!)|           |  (Never use this  |
    |                   |           |   element again)  |
    +-------------------+           +-------------------+

WHY STAY WHEN WE TAKE?
----------------------
Because the problem says we can use each element UNLIMITED times!
If we take 2 and move to next index, we can never take 2 again.
By staying, we give ourselves the option to take 2 multiple times.

WHY MOVE WHEN WE DON'T TAKE?
----------------------------
If we decide NOT to take element at index i, we're saying:
"I don't want this element in my combination AT ALL"
So we move forward and never look back at this element.

================================================================================
SECTION 3: DECISION TREE VISUALIZATION
================================================================================

Let's visualize: candidates = [2, 3], target = 5

Legend:
  - Each node shows: (index, current_sum, path)
  - "TAKE" means include current element, STAY at same index
  - "SKIP" means don't include, MOVE to next index
  - [X] means pruned (sum exceeded target)
  - [V] means VALID combination found!

                                    (idx=0, sum=0, path=[])
                                    candidates[0] = 2
                                           |
                    +----------------------+----------------------+
                    |                                             |
               TAKE 2                                        SKIP 2
            (STAY at idx=0)                               (MOVE to idx=1)
                    |                                             |
                    v                                             v
            (idx=0, sum=2, [2])                         (idx=1, sum=0, [])
            candidates[0] = 2                            candidates[1] = 3
                    |                                             |
         +----------+----------+                       +----------+----------+
         |                     |                       |                     |
    TAKE 2                SKIP 2                  TAKE 3                SKIP 3
   (STAY idx=0)         (MOVE idx=1)            (STAY idx=1)          (MOVE idx=2)
         |                     |                       |                     |
         v                     v                       v                     v
 (idx=0,sum=4,[2,2])  (idx=1,sum=2,[2])       (idx=1,sum=3,[3])      idx=2: OUT OF BOUNDS
 candidates[0]=2       candidates[1]=3         candidates[1]=3        return [] (no solution)
         |                     |                       |
    +----+----+           +----+----+             +----+----+
    |         |           |         |             |         |
 TAKE 2    SKIP 2      TAKE 3   SKIP 3         TAKE 3   SKIP 3
    |         |           |         |             |         |
    v         v           v         v             v         v
sum=6>5   (idx=1,     (idx=1,   idx=2:OUT     sum=6>5   idx=2:OUT
[X]PRUNE  sum=4,[2,2]) sum=5,    return[]     [X]PRUNE  return[]
          cand[1]=3   [2,3])
              |          |
         +----+----+   sum=5=target
         |         |   [V] FOUND! [2,3]
      TAKE 3   SKIP 3
         |         |
         v         v
    sum=7>5    idx=2:OUT
    [X]PRUNE   return[]

Wait! We also need [2,2,3]? Let's trace more carefully from (idx=0, sum=4, [2,2]):

From (idx=0, sum=4, [2,2]):
    - TAKE 2: sum = 6 > 5, PRUNE [X]
    - SKIP 2 (MOVE to idx=1):
            (idx=1, sum=4, [2,2])
            - TAKE 3: sum = 7 > 5, PRUNE [X]
            - SKIP 3: idx=2, OUT OF BOUNDS, return []

Hmm, [2,2,3] sums to 7, not 5. Let me redo this for target=5:
Actually [2,2,3] = 7, so for target=5, valid answers are just [2,3].
My tree is correct for target=5.

================================================================================
SECTION 4: DETAILED DECISION TREE FOR EXAMPLE 1
================================================================================

candidates = [2, 3, 6, 7], target = 7

This tree is large, so let's trace the KEY PATHS that lead to solutions:

PATH TO FIND [2,2,3]:
--------------------

Start: idx=0, sum=0, path=[]
  |
  TAKE 2 (STAY at idx=0)
  |
  v
idx=0, sum=2, path=[2]
  |
  TAKE 2 (STAY at idx=0)
  |
  v
idx=0, sum=4, path=[2,2]
  |
  TAKE 2? sum would be 6, still < 7, let's continue
  |
  v
idx=0, sum=6, path=[2,2,2]
  |
  TAKE 2? sum would be 8 > 7, PRUNE! [X]
  |
  SKIP 2 (MOVE to idx=1)
  |
  v
idx=1, sum=6, path=[2,2,2]
  |
  TAKE 3? sum would be 9 > 7, PRUNE! [X]
  |
  SKIP 3 (MOVE to idx=2)
  |
  v
idx=2, sum=6, path=[2,2,2]
  |
  TAKE 6? sum would be 12 > 7, PRUNE! [X]
  |
  SKIP 6, SKIP 7... eventually OUT OF BOUNDS, return []

Let's try another path from [2,2]:

idx=0, sum=4, path=[2,2]
  |
  SKIP 2 (MOVE to idx=1)  <-- This is the key!
  |
  v
idx=1, sum=4, path=[2,2]
  |
  TAKE 3 (STAY at idx=1)
  |
  v
idx=1, sum=7, path=[2,2,3]
  |
  sum == target!
  [V] FOUND! Add [2,2,3] to result!


PATH TO FIND [7]:
-----------------

Start: idx=0, sum=0, path=[]
  |
  SKIP 2 (MOVE to idx=1)
  |
  v
idx=1, sum=0, path=[]
  |
  SKIP 3 (MOVE to idx=2)
  |
  v
idx=2, sum=0, path=[]
  |
  SKIP 6 (MOVE to idx=3)
  |
  v
idx=3, sum=0, path=[]
  |
  TAKE 7 (STAY at idx=3)
  |
  v
idx=3, sum=7, path=[7]
  |
  sum == target!
  [V] FOUND! Add [7] to result!

================================================================================
SECTION 5: COMPLETE DRY RUN WITH CALL STACK
================================================================================

candidates = [2, 3, 6, 7], target = 7
result = []

I'll use a more compact representation:
    solve(idx, remaining_target, current_path)

Call Stack Trace:
-----------------

solve(0, 7, [])                         # Start
|
+-- TAKE 2: solve(0, 5, [2])            # Stay at idx=0, target reduced by 2
|   |
|   +-- TAKE 2: solve(0, 3, [2,2])      # Stay at idx=0
|   |   |
|   |   +-- TAKE 2: solve(0, 1, [2,2,2])
|   |   |   |
|   |   |   +-- TAKE 2: 2 > 1, PRUNE (can't take, too big)
|   |   |   |
|   |   |   +-- SKIP 2: solve(1, 1, [2,2,2])
|   |   |       |
|   |   |       +-- TAKE 3: 3 > 1, PRUNE
|   |   |       |
|   |   |       +-- SKIP 3: solve(2, 1, [2,2,2])
|   |   |           |
|   |   |           +-- TAKE 6: 6 > 1, PRUNE
|   |   |           +-- SKIP 6: solve(3, 1, [2,2,2])
|   |   |               +-- TAKE 7: 7 > 1, PRUNE
|   |   |               +-- SKIP 7: solve(4, 1, [2,2,2])
|   |   |                   +-- idx=4 out of bounds, return
|   |   |
|   |   +-- SKIP 2: solve(1, 3, [2,2])  # Move to idx=1
|   |       |
|   |       +-- TAKE 3: solve(1, 0, [2,2,3])
|   |       |   |
|   |       |   +-- remaining = 0, FOUND! Add [2,2,3] to result
|   |       |
|   |       +-- SKIP 3: solve(2, 3, [2,2])
|   |           +-- TAKE 6: 6 > 3, PRUNE
|   |           +-- SKIP 6: solve(3, 3, [2,2])
|   |               +-- TAKE 7: 7 > 3, PRUNE
|   |               +-- SKIP 7: idx=4, return
|   |
|   +-- SKIP 2: solve(1, 5, [2])        # Move to idx=1
|       |
|       +-- TAKE 3: solve(1, 2, [2,3])
|       |   +-- TAKE 3: 3 > 2, PRUNE
|       |   +-- SKIP 3: solve(2, 2, [2,3])
|       |       +-- TAKE 6: 6 > 2, PRUNE
|       |       +-- SKIP 6: solve(3, 2, [2,3])
|       |           +-- TAKE 7: 7 > 2, PRUNE
|       |           +-- SKIP 7: idx=4, return
|       |
|       +-- SKIP 3: solve(2, 5, [2])
|           +-- TAKE 6: 6 > 5, PRUNE
|           +-- SKIP 6: solve(3, 5, [2])
|               +-- TAKE 7: 7 > 5, PRUNE
|               +-- SKIP 7: idx=4, return
|
+-- SKIP 2: solve(1, 7, [])             # Move to idx=1
    |
    +-- TAKE 3: solve(1, 4, [3])
    |   +-- TAKE 3: solve(1, 1, [3,3])
    |   |   +-- TAKE 3: 3 > 1, PRUNE
    |   |   +-- SKIP 3: solve(2, 1, [3,3])
    |   |       +-- TAKE 6: 6 > 1, PRUNE
    |   |       +-- SKIP 6: solve(3, 1, [3,3])
    |   |           +-- TAKE 7: 7 > 1, PRUNE
    |   |           +-- SKIP 7: idx=4, return
    |   |
    |   +-- SKIP 3: solve(2, 4, [3])
    |       +-- TAKE 6: 6 > 4, PRUNE
    |       +-- SKIP 6: solve(3, 4, [3])
    |           +-- TAKE 7: 7 > 4, PRUNE
    |           +-- SKIP 7: idx=4, return
    |
    +-- SKIP 3: solve(2, 7, [])
        +-- TAKE 6: solve(2, 1, [6])
        |   +-- TAKE 6: 6 > 1, PRUNE
        |   +-- SKIP 6: solve(3, 1, [6])
        |       +-- TAKE 7: 7 > 1, PRUNE
        |       +-- SKIP 7: idx=4, return
        |
        +-- SKIP 6: solve(3, 7, [])
            +-- TAKE 7: solve(3, 0, [7])
            |   +-- remaining = 0, FOUND! Add [7] to result
            |
            +-- SKIP 7: idx=4, return

FINAL RESULT: [[2,2,3], [7]]

================================================================================
SECTION 6: WHY THIS AVOIDS DUPLICATES
================================================================================

Question: Why don't we get [3,2,2] as a SEPARATE answer from [2,2,3]?

The answer lies in the "SKIP means MOVE FORWARD" rule!

Let's trace what would happen if we tried to form [3,2,2]:

solve(0, 7, [])
|
+-- SKIP 2: solve(1, 7, [])      # We skip 2, move to idx=1
    |
    +-- TAKE 3: solve(1, 4, [3]) # We take 3, stay at idx=1
        |
        +-- SKIP 3: solve(2, 4, [3])  # We skip 3, move to idx=2
            |
            +-- At idx=2, candidates[2] = 6
            +-- At idx=3, candidates[3] = 7
            +-- There is NO WAY to go back to index 0 to get 2!
            +-- Once we moved past index 0, we can NEVER use 2 again!

THE KEY INSIGHT:
---------------
+------------------------------------------------------------------+
|  Once we SKIP an element (move to next index),                   |
|  we can NEVER go back and use that element!                      |
|                                                                  |
|  This ensures we only generate combinations in "sorted order"    |
|  of indices, preventing duplicates like:                         |
|    - [2,2,3] (valid - indices: 0,0,1)                           |
|    - [2,3,2] (impossible - can't go back to idx 0 after idx 1)  |
|    - [3,2,2] (impossible - can't go back to idx 0 after idx 1)  |
+------------------------------------------------------------------+

Visual representation of "only move forward":

candidates = [2, 3, 6, 7]
              ^
             idx=0

When building [2,2,3]:
    Step 1: Take 2 (stay at 0) -> [2]
    Step 2: Take 2 (stay at 0) -> [2,2]
    Step 3: Skip 2 (move to 1) -> Now at idx=1, can NEVER go back to idx=0!
    Step 4: Take 3 (stay at 1) -> [2,2,3]

When trying to build [3,2,2] (IMPOSSIBLE):
    Step 1: Skip 2 (move to 1) -> Now at idx=1, can NEVER use 2!
    Step 2: Take 3 (stay at 1) -> [3]
    Step 3: Want to take 2? IMPOSSIBLE! We're at idx=1, idx=0 is behind us!

================================================================================
SECTION 7: IMPLEMENTATION WITH DETAILED COMMENTS
================================================================================
"""

from typing import List


def combination_sum_basic(candidates: List[int], target: int) -> List[List[int]]:
    """
    Basic implementation of Combination Sum using backtracking.

    The "Stay or Move" Pattern:
    - When we TAKE an element: STAY at same index (can take again)
    - When we SKIP an element: MOVE to next index (never use again)

    Args:
        candidates: List of distinct positive integers
        target: Target sum to achieve

    Returns:
        List of all unique combinations that sum to target
    """
    result = []  # Store all valid combinations

    def backtrack(index: int, current_path: List[int], remaining: int):
        """
        Recursive backtracking function.

        Args:
            index: Current index in candidates array
            current_path: Current combination being built
            remaining: How much more we need to reach target
        """
        # Base Case 1: Found a valid combination!
        if remaining == 0:
            # IMPORTANT: Append a COPY of current_path
            # If we append current_path directly, it will be modified later
            result.append(current_path.copy())
            return

        # Base Case 2: Gone past all candidates
        if index >= len(candidates):
            return

        # Base Case 3: Remaining is negative (overshooting target)
        # This check is implicit in our choices below

        # Current element we're considering
        current_element = candidates[index]

        # -----------------------------------------------------------------
        # CHOICE 1: TAKE current element (if it doesn't exceed remaining)
        # -----------------------------------------------------------------
        if current_element <= remaining:
            # Add to our current combination
            current_path.append(current_element)

            # STAY at the same index! (KEY INSIGHT)
            # We might want to take this element again
            backtrack(index, current_path, remaining - current_element)

            # Backtrack: remove the element we just added
            current_path.pop()

        # -----------------------------------------------------------------
        # CHOICE 2: SKIP current element
        # -----------------------------------------------------------------
        # MOVE to next index! (never use this element again in this path)
        backtrack(index + 1, current_path, remaining)

    # Start recursion from index 0, empty path, full target
    backtrack(0, [], target)

    return result


"""
================================================================================
SECTION 8: OPTIMIZED IMPLEMENTATION WITH PRUNING
================================================================================

PRUNING OPTIMIZATION:
--------------------
If we SORT the candidates array first, we can optimize!

When we iterate through candidates:
- If candidates[i] > remaining, then candidates[i+1], candidates[i+2], ...
  are ALL greater than remaining (since array is sorted)
- We can STOP early instead of checking all remaining elements!

Before sorting: We might check many elements that are too large
After sorting: We can break out of the loop early

Example: candidates = [7, 3, 2, 6], target = 4

    Without sorting: Check 7 (too big), 3 (ok), 2 (ok), 6 (too big)

    With sorting: [2, 3, 6, 7]
                  Check 2 (ok), 3 (ok), 6 (too big) -> STOP!
                  Don't need to check 7
"""


def combination_sum_optimized(candidates: List[int], target: int) -> List[List[int]]:
    """
    Optimized implementation with sorting and early termination.

    Optimization: Sort candidates first, then when current candidate
    exceeds remaining target, we can skip all subsequent candidates.
    """
    result = []

    # Sort for optimization: enables early termination
    candidates.sort()

    def backtrack(index: int, current_path: List[int], remaining: int):
        """
        Optimized recursive backtracking with early termination.
        """
        # Found valid combination
        if remaining == 0:
            result.append(current_path.copy())
            return

        # Try each candidate starting from current index
        for i in range(index, len(candidates)):
            candidate = candidates[i]

            # PRUNING: If current candidate > remaining, all subsequent
            # candidates will also be > remaining (array is sorted)
            if candidate > remaining:
                break  # Early termination!

            # TAKE this candidate (include in combination)
            current_path.append(candidate)

            # Recurse with SAME index i (can reuse this candidate)
            # This is the "STAY" part of Stay or Move!
            backtrack(i, current_path, remaining - candidate)

            # Backtrack (remove candidate, try next option)
            current_path.pop()

            # Note: When the loop increments i, we're implicitly
            # doing the "MOVE" part (trying next candidate,
            # effectively skipping previous ones)

    backtrack(0, [], target)
    return result


"""
================================================================================
SECTION 9: DRY RUN OF OPTIMIZED SOLUTION
================================================================================

candidates = [2, 3, 5], target = 8
After sorting: [2, 3, 5] (already sorted)

Trace using iterative approach:
backtrack(index, path, remaining)

backtrack(0, [], 8)
    i=0, candidate=2, 2 <= 8
        path = [2]
        backtrack(0, [2], 6)
            i=0, candidate=2, 2 <= 6
                path = [2,2]
                backtrack(0, [2,2], 4)
                    i=0, candidate=2, 2 <= 4
                        path = [2,2,2]
                        backtrack(0, [2,2,2], 2)
                            i=0, candidate=2, 2 <= 2
                                path = [2,2,2,2]
                                backtrack(0, [2,2,2,2], 0)
                                    remaining=0, FOUND! result=[[2,2,2,2]]
                                path = [2,2,2]
                            i=1, candidate=3, 3 > 2, BREAK
                        path = [2,2]
                    i=1, candidate=3, 3 <= 4
                        path = [2,2,3]
                        backtrack(1, [2,2,3], 1)
                            i=1, candidate=3, 3 > 1, BREAK
                        path = [2,2]
                    i=2, candidate=5, 5 > 4, BREAK
                path = [2]
            i=1, candidate=3, 3 <= 6
                path = [2,3]
                backtrack(1, [2,3], 3)
                    i=1, candidate=3, 3 <= 3
                        path = [2,3,3]
                        backtrack(1, [2,3,3], 0)
                            remaining=0, FOUND! result=[[2,2,2,2], [2,3,3]]
                        path = [2,3]
                    i=2, candidate=5, 5 > 3, BREAK
                path = [2]
            i=2, candidate=5, 5 <= 6
                path = [2,5]
                backtrack(2, [2,5], 1)
                    i=2, candidate=5, 5 > 1, BREAK
                path = [2]
        path = []
    i=1, candidate=3, 3 <= 8
        path = [3]
        backtrack(1, [3], 5)
            i=1, candidate=3, 3 <= 5
                path = [3,3]
                backtrack(1, [3,3], 2)
                    i=1, candidate=3, 3 > 2, BREAK
                path = [3]
            i=2, candidate=5, 5 <= 5
                path = [3,5]
                backtrack(2, [3,5], 0)
                    remaining=0, FOUND! result=[[2,2,2,2], [2,3,3], [3,5]]
                path = [3]
        path = []
    i=2, candidate=5, 5 <= 8
        path = [5]
        backtrack(2, [5], 3)
            i=2, candidate=5, 5 > 3, BREAK
        path = []

FINAL RESULT: [[2,2,2,2], [2,3,3], [3,5]]

================================================================================
SECTION 10: COMPLEXITY ANALYSIS
================================================================================

TIME COMPLEXITY:
---------------
This is tricky to analyze precisely!

Let's think about it:
- At each position, we can include an element multiple times
- Maximum times we can include smallest element = target / min(candidates)
- The branching is not a simple 2^n like subset problems

Rough upper bound: O(n^(target/min))
Where:
    - n = number of candidates
    - target = target sum
    - min = minimum value in candidates

More precisely: O(n^(target/min + 1))

For each valid combination of length k, we do O(k) work to copy it.
Total combinations can be exponential.

SPACE COMPLEXITY:
----------------
O(target/min) for recursion stack
- Deepest recursion = taking smallest element repeatedly until target

The current_path can have at most target/min elements.

Example: candidates = [1, 2, 3], target = 100
    - Worst case depth = 100/1 = 100
    - current_path could have up to 100 elements

================================================================================
SECTION 11: COMPARISON WITH RELATED PROBLEMS
================================================================================

+----------------------------------------------------------------------------+
|  PROBLEM              |  KEY CHARACTERISTIC     |  PATTERN                 |
+----------------------------------------------------------------------------+
|  Combination Sum I    |  Elements can be used   |  Take and STAY           |
|  (THIS PROBLEM)       |  UNLIMITED times        |  Skip and MOVE           |
|                       |  Input: distinct values |                          |
+----------------------------------------------------------------------------+
|  Combination Sum II   |  Each element used      |  Take and MOVE           |
|                       |  AT MOST ONCE           |  Skip DUPLICATES         |
|                       |  Input: MAY have        |  (skip if same as prev)  |
|                       |  duplicate values       |                          |
+----------------------------------------------------------------------------+
|  Subsequence Sum      |  Each element used      |  Take and MOVE           |
|  (Subset Sum)         |  AT MOST ONCE           |  Skip and MOVE           |
|                       |  Input: distinct values |  (simpler than above)    |
+----------------------------------------------------------------------------+

CODE COMPARISON:
---------------

# Combination Sum I (this problem) - unlimited reuse
def combo_sum_1(idx, remaining):
    if remaining == 0: return found
    if idx >= n: return

    if candidates[idx] <= remaining:
        path.append(candidates[idx])
        combo_sum_1(idx, remaining - candidates[idx])  # STAY at idx!
        path.pop()

    combo_sum_1(idx + 1, remaining)  # MOVE to next

# Combination Sum II - each element once, input may have duplicates
def combo_sum_2(idx, remaining):
    if remaining == 0: return found
    if idx >= n: return

    for i in range(idx, n):
        # Skip duplicates at same level
        if i > idx and candidates[i] == candidates[i-1]:
            continue

        if candidates[i] > remaining:
            break

        path.append(candidates[i])
        combo_sum_2(i + 1, remaining - candidates[i])  # MOVE to next!
        path.pop()

# Subsequence/Subset Sum - each element once, input is distinct
def subset_sum(idx, remaining):
    if remaining == 0: return found
    if idx >= n: return

    # Take
    path.append(nums[idx])
    subset_sum(idx + 1, remaining - nums[idx])  # MOVE
    path.pop()

    # Skip
    subset_sum(idx + 1, remaining)  # MOVE

================================================================================
SECTION 12: VISUAL COMPARISON OF DECISION TREES
================================================================================

For arr = [2, 3], target = 5:

COMBINATION SUM I (Unlimited reuse):
-----------------------------------
                     (idx=0)
                     /    \
              Take 2       Skip 2
             (STAY)        (MOVE)
                |            |
             (idx=0)      (idx=1)
             sum=2         sum=0
             /    \        /    \
        Take 2  Skip 2  Take 3  Skip 3
           |      |        |       |
        (idx=0) (idx=1)  (idx=1) (idx=2)
        sum=4   sum=2    sum=3   END
        ...     ...      ...

Notice: After "Take 2", we're still at idx=0! Can take 2 again.

SUBSEQUENCE SUM (Each element once):
-----------------------------------
                     (idx=0)
                     /    \
              Take 2       Skip 2
             (MOVE)        (MOVE)
                |            |
             (idx=1)      (idx=1)
             sum=2         sum=0
             /    \        /    \
        Take 3  Skip 3  Take 3  Skip 3
           |      |        |       |
        (idx=2) (idx=2)  (idx=2) (idx=2)
        sum=5   sum=2    sum=3   sum=0
         END    END      END     END

Notice: After "Take 2", we MOVE to idx=1! Cannot take 2 again.

================================================================================
SECTION 13: TEST CASES
================================================================================
"""


def test_combination_sum():
    """
    Test both implementations with various test cases.
    """
    print("=" * 60)
    print("TESTING COMBINATION SUM IMPLEMENTATIONS")
    print("=" * 60)

    # Test Case 1: Basic example
    candidates1 = [2, 3, 6, 7]
    target1 = 7
    expected1 = [[2, 2, 3], [7]]

    result1_basic = combination_sum_basic(candidates1, target1)
    result1_optimized = combination_sum_optimized(candidates1, target1)

    print(f"\nTest 1: candidates = {candidates1}, target = {target1}")
    print(f"Expected: {expected1}")
    print(f"Basic result: {result1_basic}")
    print(f"Optimized result: {result1_optimized}")

    # Sort inner lists for comparison
    result1_basic_sorted = sorted([sorted(x) for x in result1_basic])
    expected1_sorted = sorted([sorted(x) for x in expected1])
    print(f"Test 1 PASSED: {result1_basic_sorted == expected1_sorted}")

    # Test Case 2: Multiple combinations
    candidates2 = [2, 3, 5]
    target2 = 8
    expected2 = [[2, 2, 2, 2], [2, 3, 3], [3, 5]]

    result2_basic = combination_sum_basic(candidates2, target2)
    result2_optimized = combination_sum_optimized(candidates2, target2)

    print(f"\nTest 2: candidates = {candidates2}, target = {target2}")
    print(f"Expected: {expected2}")
    print(f"Basic result: {result2_basic}")
    print(f"Optimized result: {result2_optimized}")

    result2_basic_sorted = sorted([sorted(x) for x in result2_basic])
    expected2_sorted = sorted([sorted(x) for x in expected2])
    print(f"Test 2 PASSED: {result2_basic_sorted == expected2_sorted}")

    # Test Case 3: No solution possible
    candidates3 = [2]
    target3 = 1
    expected3 = []

    result3_basic = combination_sum_basic(candidates3, target3)
    result3_optimized = combination_sum_optimized(candidates3, target3)

    print(f"\nTest 3: candidates = {candidates3}, target = {target3}")
    print(f"Expected: {expected3}")
    print(f"Basic result: {result3_basic}")
    print(f"Optimized result: {result3_optimized}")
    print(f"Test 3 PASSED: {result3_basic == expected3}")

    # Test Case 4: Single candidate equals target
    candidates4 = [1]
    target4 = 3
    expected4 = [[1, 1, 1]]

    result4_basic = combination_sum_basic(candidates4, target4)
    result4_optimized = combination_sum_optimized(candidates4, target4)

    print(f"\nTest 4: candidates = {candidates4}, target = {target4}")
    print(f"Expected: {expected4}")
    print(f"Basic result: {result4_basic}")
    print(f"Optimized result: {result4_optimized}")
    print(f"Test 4 PASSED: {result4_basic == expected4}")

    # Test Case 5: Larger example
    candidates5 = [2, 3, 5, 7]
    target5 = 10

    result5_basic = combination_sum_basic(candidates5, target5)
    result5_optimized = combination_sum_optimized(candidates5, target5)

    print(f"\nTest 5: candidates = {candidates5}, target = {target5}")
    print(f"Basic result: {result5_basic}")
    print(f"Optimized result: {result5_optimized}")
    print(f"Number of combinations: {len(result5_basic)}")

    print("\n" + "=" * 60)
    print("ALL TESTS COMPLETED")
    print("=" * 60)


"""
================================================================================
SECTION 14: KEY TAKEAWAYS
================================================================================

1. THE STAY OR MOVE PATTERN:
   - TAKE and STAY: Include element, stay at same index (can reuse)
   - SKIP and MOVE: Don't include, move to next index (never use again)

2. WHY NO DUPLICATES:
   - We only move forward in the index
   - Once we skip an element, we never go back
   - This generates combinations in "index-sorted" order

3. PRUNING OPTIMIZATION:
   - Sort the array first
   - When current element > remaining, break out of loop
   - All subsequent elements will also be too large

4. BACKTRACKING ESSENTIALS:
   - Always make a COPY when adding to result
   - Always UNDO your choice (pop) after recursion

5. RELATED PROBLEMS:
   - Combination Sum I: Unlimited reuse, distinct input
   - Combination Sum II: Each once, duplicate input values
   - Subset Sum: Each once, distinct input

================================================================================
"""


if __name__ == "__main__":
    test_combination_sum()

    # Additional demonstration
    print("\n" + "=" * 60)
    print("STEP-BY-STEP DEMONSTRATION")
    print("=" * 60)

    print("\nFinding combinations for candidates=[2,3,6,7], target=7:")
    print("-" * 50)

    result = combination_sum_optimized([2, 3, 6, 7], 7)

    for i, combo in enumerate(result, 1):
        print(f"Combination {i}: {combo} -> sum = {sum(combo)}")

    print("\n" + "=" * 60)
