"""Print all subsequences of an array using recursion."""

# =============================================================================
# UNDERSTANDING SUBSEQUENCES
# =============================================================================
#
# WHAT IS A SUBSEQUENCE?
# ----------------------
# A subsequence is a sequence derived from another sequence by deleting some
# or no elements WITHOUT changing the order of the remaining elements.
#
# Key property: Elements maintain their RELATIVE ORDER from the original array.
#               They do NOT need to be contiguous (adjacent).
#
# Example: For array [1, 2, 3]
#          Subsequences: [], [1], [2], [3], [1,2], [1,3], [2,3], [1,2,3]
#          Note: [2,1] is NOT a subsequence (order changed)
#                [1,3] IS a subsequence (order maintained, not contiguous)
#
# =============================================================================
# SUBSEQUENCE vs SUBARRAY vs SUBSET
# =============================================================================
#
# 1. SUBARRAY (Contiguous Subsequence):
#    - Elements MUST be contiguous (adjacent)
#    - Maintains relative order
#    - For [1,2,3]: subarrays are [], [1], [2], [3], [1,2], [2,3], [1,2,3]
#    - Count: n*(n+1)/2 + 1 = O(n^2)
#
# 2. SUBSEQUENCE:
#    - Elements do NOT need to be contiguous
#    - MUST maintain relative order
#    - For [1,2,3]: all of above PLUS [1,3]
#    - Count: 2^n (each element can be included or excluded)
#
# 3. SUBSET:
#    - Does NOT need to maintain order
#    - Order does not matter: {1,3} = {3,1}
#    - For sets, subsequence and subset are essentially the same
#    - Count: 2^n
#
# Visual Comparison for [1, 2, 3]:
# --------------------------------
#   Subarray: Must be contiguous    ->  [1], [2], [3], [1,2], [2,3], [1,2,3]
#   Subsequence: Order preserved    ->  All subarrays + [1,3]
#   Subset: Order doesn't matter    ->  Same as subsequence for unique elements
#
# =============================================================================
# THE TAKE/NOT-TAKE (PICK/NOT-PICK) PATTERN
# =============================================================================
#
# Core Idea:
# ----------
# At each index, we have exactly TWO choices:
#   1. TAKE (include) the current element in our subsequence
#   2. NOT-TAKE (exclude) the current element from our subsequence
#
# This creates a binary decision tree where:
#   - Each level represents an index in the array
#   - Left branch = NOT TAKE current element
#   - Right branch = TAKE current element
#
# Recursion Tree for [1, 2, 3]:
# -----------------------------
#
#                              f(0, [])
#                             /        \
#                   NOT TAKE 1          TAKE 1
#                          /              \
#                     f(1, [])          f(1, [1])
#                     /      \          /        \
#              NOT TAKE 2   TAKE 2   NOT TAKE 2   TAKE 2
#                /            \        /             \
#           f(2, [])      f(2, [2])  f(2, [1])    f(2, [1,2])
#           /    \        /    \      /    \        /      \
#       NOT   TAKE    NOT   TAKE  NOT   TAKE   NOT      TAKE
#       TAKE 3  3    TAKE 3  3   TAKE 3  3    TAKE 3     3
#         |     |      |     |     |     |      |        |
#        []    [3]   [2]  [2,3]  [1]  [1,3]  [1,2]   [1,2,3]
#
#       (8 leaf nodes = 2^3 subsequences)
#
# =============================================================================
# TIME AND SPACE COMPLEXITY
# =============================================================================
#
# TIME COMPLEXITY: O(2^n)
# -----------------------
# Why 2^n?
#   - For each of n elements, we make 2 choices (take or not-take)
#   - Total combinations = 2 * 2 * 2 * ... (n times) = 2^n
#   - Each subsequence takes O(n) time to copy/print in worst case
#   - Overall: O(n * 2^n), but commonly stated as O(2^n)
#
# SPACE COMPLEXITY: O(n)
# ----------------------
#   - Recursion stack depth: O(n) - we go n levels deep
#   - Current subsequence storage: O(n) - max n elements
#   - Total auxiliary space: O(n)
#
# Note: If we store all subsequences, space becomes O(n * 2^n)
#
# =============================================================================


from typing import List, Any


def print_subsequences(arr: List[Any]) -> None:
    """
    Print all subsequences of an array using recursion.

    Uses the take/not-take pattern where at each index,
    we either include or exclude the current element.

    Args:
        arr: The input array to generate subsequences from

    Returns:
        None (prints all subsequences)
    """

    def helper(index: int, current_subsequence: List[Any]) -> None:
        """
        Recursive helper function to generate subsequences.

        Args:
            index: Current position in the array we are considering
            current_subsequence: The subsequence built so far

        Base Case:
            When index equals len(arr), we have considered all elements.
            Print the current subsequence (it is complete).

        Recursive Case:
            Make two recursive calls:
            1. NOT TAKE: Move to next index without including current element
            2. TAKE: Include current element, then move to next index
        """

        # BASE CASE: We have processed all elements
        # The current_subsequence is now a complete subsequence
        if index == len(arr):
            print(current_subsequence)
            return

        # RECURSIVE CASE: Two choices for arr[index]

        # Choice 1: NOT TAKE (Exclude current element)
        # Move to next index without adding arr[index] to subsequence
        helper(index + 1, current_subsequence)

        # Choice 2: TAKE (Include current element)
        # Add arr[index] to subsequence, then move to next index
        current_subsequence.append(arr[index])  # Include element
        helper(index + 1, current_subsequence)
        current_subsequence.pop()  # Backtrack: remove element after returning

        # Note: The pop() is crucial for backtracking!
        # After exploring the "take" path, we must restore the state
        # so other branches don't see elements that shouldn't be there.

    # Start recursion from index 0 with an empty subsequence
    helper(0, [])


def get_all_subsequences(arr: List[Any]) -> List[List[Any]]:
    """
    Return all subsequences of an array as a list of lists.

    Same logic as print_subsequences, but stores results instead of printing.

    Args:
        arr: The input array

    Returns:
        List of all subsequences
    """
    result = []

    def helper(index: int, current_subsequence: List[Any]) -> None:
        # Base case: subsequence is complete
        if index == len(arr):
            # Important: append a COPY, not the reference
            result.append(current_subsequence.copy())
            return

        # Not take
        helper(index + 1, current_subsequence)

        # Take
        current_subsequence.append(arr[index])
        helper(index + 1, current_subsequence)
        current_subsequence.pop()  # Backtrack

    helper(0, [])
    return result


# =============================================================================
# DETAILED DRY RUN TRACE
# =============================================================================
#
# Input: arr = [1, 2, 3]
#
# Let's trace every recursive call step by step.
# Notation: helper(index, current_subsequence)
#
# -------------------------------------------------------------------------
# STEP 1: helper(0, [])
#         index=0, considering element arr[0]=1
#         Two choices: NOT TAKE 1 or TAKE 1
#
#         First, go NOT TAKE path...
# -------------------------------------------------------------------------
# STEP 2: helper(1, [])
#         index=1, considering element arr[1]=2
#         current_subsequence=[] (we didn't take 1)
#         Two choices: NOT TAKE 2 or TAKE 2
#
#         First, go NOT TAKE path...
# -------------------------------------------------------------------------
# STEP 3: helper(2, [])
#         index=2, considering element arr[2]=3
#         current_subsequence=[] (we didn't take 1 or 2)
#         Two choices: NOT TAKE 3 or TAKE 3
#
#         First, go NOT TAKE path...
# -------------------------------------------------------------------------
# STEP 4: helper(3, [])
#         index=3, which equals len(arr)=3
#         BASE CASE REACHED!
#         >>> PRINT: []
#         Return to STEP 3
# -------------------------------------------------------------------------
# STEP 5: Back in helper(2, [])
#         Now go TAKE 3 path...
#         Append 3: current_subsequence = [3]
#         Call helper(3, [3])
# -------------------------------------------------------------------------
# STEP 6: helper(3, [3])
#         index=3, which equals len(arr)=3
#         BASE CASE REACHED!
#         >>> PRINT: [3]
#         Return to STEP 5
# -------------------------------------------------------------------------
# STEP 7: Back in helper(2, [3])
#         Pop 3: current_subsequence = []  (backtrack)
#         Return to STEP 2
# -------------------------------------------------------------------------
# STEP 8: Back in helper(1, [])
#         Now go TAKE 2 path...
#         Append 2: current_subsequence = [2]
#         Call helper(2, [2])
# -------------------------------------------------------------------------
# STEP 9: helper(2, [2])
#         index=2, considering element arr[2]=3
#         current_subsequence=[2]
#
#         First, NOT TAKE 3 path...
#         Call helper(3, [2])
# -------------------------------------------------------------------------
# STEP 10: helper(3, [2])
#          BASE CASE REACHED!
#          >>> PRINT: [2]
#          Return to STEP 9
# -------------------------------------------------------------------------
# STEP 11: Back in helper(2, [2])
#          Now TAKE 3 path...
#          Append 3: current_subsequence = [2, 3]
#          Call helper(3, [2, 3])
# -------------------------------------------------------------------------
# STEP 12: helper(3, [2, 3])
#          BASE CASE REACHED!
#          >>> PRINT: [2, 3]
#          Return to STEP 11
# -------------------------------------------------------------------------
# STEP 13: Back in helper(2, [2, 3])
#          Pop 3: current_subsequence = [2]  (backtrack)
#          Return to STEP 8
# -------------------------------------------------------------------------
# STEP 14: Back in helper(1, [2])
#          Pop 2: current_subsequence = []  (backtrack)
#          Return to STEP 1
# -------------------------------------------------------------------------
# STEP 15: Back in helper(0, [])
#          Now go TAKE 1 path...
#          Append 1: current_subsequence = [1]
#          Call helper(1, [1])
# -------------------------------------------------------------------------
# STEP 16: helper(1, [1])
#          index=1, considering element arr[1]=2
#          current_subsequence=[1]
#
#          First, NOT TAKE 2 path...
#          Call helper(2, [1])
# -------------------------------------------------------------------------
# STEP 17: helper(2, [1])
#          index=2, considering element arr[2]=3
#
#          First, NOT TAKE 3 path...
#          Call helper(3, [1])
# -------------------------------------------------------------------------
# STEP 18: helper(3, [1])
#          BASE CASE REACHED!
#          >>> PRINT: [1]
#          Return to STEP 17
# -------------------------------------------------------------------------
# STEP 19: Back in helper(2, [1])
#          Now TAKE 3 path...
#          Append 3: current_subsequence = [1, 3]
#          Call helper(3, [1, 3])
# -------------------------------------------------------------------------
# STEP 20: helper(3, [1, 3])
#          BASE CASE REACHED!
#          >>> PRINT: [1, 3]
#          Return to STEP 19
# -------------------------------------------------------------------------
# STEP 21: Back in helper(2, [1, 3])
#          Pop 3: current_subsequence = [1]  (backtrack)
#          Return to STEP 16
# -------------------------------------------------------------------------
# STEP 22: Back in helper(1, [1])
#          Now TAKE 2 path...
#          Append 2: current_subsequence = [1, 2]
#          Call helper(2, [1, 2])
# -------------------------------------------------------------------------
# STEP 23: helper(2, [1, 2])
#          index=2, considering element arr[2]=3
#
#          First, NOT TAKE 3 path...
#          Call helper(3, [1, 2])
# -------------------------------------------------------------------------
# STEP 24: helper(3, [1, 2])
#          BASE CASE REACHED!
#          >>> PRINT: [1, 2]
#          Return to STEP 23
# -------------------------------------------------------------------------
# STEP 25: Back in helper(2, [1, 2])
#          Now TAKE 3 path...
#          Append 3: current_subsequence = [1, 2, 3]
#          Call helper(3, [1, 2, 3])
# -------------------------------------------------------------------------
# STEP 26: helper(3, [1, 2, 3])
#          BASE CASE REACHED!
#          >>> PRINT: [1, 2, 3]
#          Return to STEP 25
# -------------------------------------------------------------------------
# STEP 27: Back in helper(2, [1, 2, 3])
#          Pop 3: current_subsequence = [1, 2]  (backtrack)
#          Return to STEP 22
# -------------------------------------------------------------------------
# STEP 28: Back in helper(1, [1, 2])
#          Pop 2: current_subsequence = [1]  (backtrack)
#          Return to STEP 15
# -------------------------------------------------------------------------
# STEP 29: Back in helper(0, [1])
#          Pop 1: current_subsequence = []  (backtrack)
#          All recursive calls complete!
# -------------------------------------------------------------------------
#
# FINAL OUTPUT (in order printed):
# [], [3], [2], [2, 3], [1], [1, 3], [1, 2], [1, 2, 3]
#
# Total: 8 subsequences = 2^3 (for array of length 3)
#
# =============================================================================
# DRY RUN 2: arr = [5, 10]
# =============================================================================
#
# Let's trace with a smaller example for clarity.
#
# helper(0, [])
#   |
#   +-- NOT TAKE 5 --> helper(1, [])
#   |                    |
#   |                    +-- NOT TAKE 10 --> helper(2, [])
#   |                    |                      BASE CASE: Print []
#   |                    |
#   |                    +-- TAKE 10 --> helper(2, [10])
#   |                                       BASE CASE: Print [10]
#   |
#   +-- TAKE 5 --> helper(1, [5])
#                    |
#                    +-- NOT TAKE 10 --> helper(2, [5])
#                    |                      BASE CASE: Print [5]
#                    |
#                    +-- TAKE 10 --> helper(2, [5, 10])
#                                       BASE CASE: Print [5, 10]
#
# Output order: [], [10], [5], [5, 10]
# Total: 4 subsequences = 2^2
#
# =============================================================================


# =============================================================================
# EDGE CASES
# =============================================================================

def demonstrate_edge_cases():
    """
    Demonstrate handling of edge cases.
    """

    print("=" * 60)
    print("EDGE CASE 1: Empty Array")
    print("=" * 60)
    # Empty array has exactly one subsequence: the empty subsequence itself
    # 2^0 = 1
    arr_empty = []
    print(f"Input: {arr_empty}")
    print("Subsequences:")
    print_subsequences(arr_empty)
    print("Expected: [[]]  (1 subsequence)")
    print()

    print("=" * 60)
    print("EDGE CASE 2: Single Element Array")
    print("=" * 60)
    # Single element has 2 subsequences: [] and [element]
    # 2^1 = 2
    arr_single = [42]
    print(f"Input: {arr_single}")
    print("Subsequences:")
    print_subsequences(arr_single)
    print("Expected: [[], [42]]  (2 subsequences)")
    print()

    print("=" * 60)
    print("EDGE CASE 3: Array with Duplicates")
    print("=" * 60)
    # Duplicates don't affect the algorithm
    # We still get 2^n subsequences (some may look identical but come from different positions)
    arr_duplicates = [1, 1, 2]
    print(f"Input: {arr_duplicates}")
    print("Subsequences:")
    print_subsequences(arr_duplicates)
    print("Note: [1] appears twice (from index 0 and index 1)")
    print("Note: [1, 2] appears twice (taking first 1 or second 1)")
    print("Total: 8 subsequences = 2^3")
    print()

    print("=" * 60)
    print("RELATIONSHIP TO POWER SET")
    print("=" * 60)
    print("The set of all subsequences forms the POWER SET of the array.")
    print("Power Set: The set of all possible subsets of a set.")
    print()
    print("For an array of n elements:")
    print("  - Number of subsequences = 2^n")
    print("  - Size of power set = 2^n")
    print()
    print("Examples:")
    print("  n=0: 2^0 = 1 subsequence")
    print("  n=1: 2^1 = 2 subsequences")
    print("  n=2: 2^2 = 4 subsequences")
    print("  n=3: 2^3 = 8 subsequences")
    print("  n=10: 2^10 = 1024 subsequences")
    print("  n=20: 2^20 = 1,048,576 subsequences (over 1 million!)")
    print()


# =============================================================================
# VARIATIONS OF SUBSEQUENCE PROBLEMS
# =============================================================================

# -----------------------------------------------------------------------------
# VARIATION 1: Print Subsequences with a Given Sum
# -----------------------------------------------------------------------------

def print_subsequences_with_sum(arr: List[int], target_sum: int) -> None:
    """
    Print all subsequences whose elements sum to target_sum.

    Approach:
    - Same take/not-take pattern
    - Track running sum along with the subsequence
    - At base case, print only if sum equals target

    Time: O(2^n) - still explore all paths
    Space: O(n) - recursion stack
    """

    def helper(index: int, current_subseq: List[int], current_sum: int) -> None:
        # Base case
        if index == len(arr):
            if current_sum == target_sum:
                print(current_subseq)
            return

        # Not take: sum stays same
        helper(index + 1, current_subseq, current_sum)

        # Take: add to sum
        current_subseq.append(arr[index])
        helper(index + 1, current_subseq, current_sum + arr[index])
        current_subseq.pop()  # Backtrack

    print(f"Subsequences of {arr} with sum = {target_sum}:")
    helper(0, [], 0)


# -----------------------------------------------------------------------------
# VARIATION 2: Count Subsequences with a Given Sum
# -----------------------------------------------------------------------------

def count_subsequences_with_sum(arr: List[int], target_sum: int) -> int:
    """
    Count how many subsequences sum to target_sum.

    Approach:
    - Return 1 if sum matches at base case, 0 otherwise
    - Sum up counts from both recursive paths

    Time: O(2^n)
    Space: O(n)
    """

    def helper(index: int, current_sum: int) -> int:
        # Base case
        if index == len(arr):
            return 1 if current_sum == target_sum else 0

        # Count from not-take path
        not_take = helper(index + 1, current_sum)

        # Count from take path
        take = helper(index + 1, current_sum + arr[index])

        return not_take + take

    return helper(0, 0)


# -----------------------------------------------------------------------------
# VARIATION 3: Check if Any Subsequence Exists with Given Sum
# -----------------------------------------------------------------------------

def has_subsequence_with_sum(arr: List[int], target_sum: int) -> bool:
    """
    Check if ANY subsequence with the given sum exists.

    Optimization: Return True as soon as we find one match.
    This prunes the recursion tree early!

    Time: O(2^n) worst case, but often faster due to early termination
    Space: O(n)
    """

    def helper(index: int, current_sum: int) -> bool:
        # Base case
        if index == len(arr):
            return current_sum == target_sum

        # Check not-take path first
        if helper(index + 1, current_sum):
            return True  # Found! Stop searching

        # Check take path
        if helper(index + 1, current_sum + arr[index]):
            return True  # Found! Stop searching

        return False  # No match found in either path

    return helper(0, 0)


# -----------------------------------------------------------------------------
# VARIATION 4: Print Just One Subsequence with Given Sum (Optimized)
# -----------------------------------------------------------------------------

def print_one_subsequence_with_sum(arr: List[int], target_sum: int) -> bool:
    """
    Print just ONE subsequence that sums to target, if it exists.

    Key idea: Once we find and print one valid subsequence, we return True
    and stop all further recursion. This is more efficient than finding all.

    Time: O(2^n) worst case, but average case is much better
    Space: O(n)

    Returns:
        True if a subsequence was found and printed, False otherwise
    """

    def helper(index: int, current_subseq: List[int], current_sum: int) -> bool:
        # Base case
        if index == len(arr):
            if current_sum == target_sum:
                print(f"Found subsequence: {current_subseq}")
                return True
            return False

        # Try take path first
        current_subseq.append(arr[index])
        if helper(index + 1, current_subseq, current_sum + arr[index]):
            return True  # Found! Propagate True upward, stop recursion
        current_subseq.pop()  # Backtrack

        # Try not-take path
        if helper(index + 1, current_subseq, current_sum):
            return True  # Found! Propagate True upward

        return False  # Neither path found a valid subsequence

    print(f"Looking for any subsequence of {arr} with sum = {target_sum}:")
    found = helper(0, [], 0)
    if not found:
        print("No subsequence found with the given sum.")
    return found


# =============================================================================
# MAIN: TEST CASES AND DEMONSTRATIONS
# =============================================================================

if __name__ == "__main__":

    print("=" * 70)
    print("PRINTING ALL SUBSEQUENCES - BASIC EXAMPLE")
    print("=" * 70)

    # Test Case 1: Standard array
    arr1 = [1, 2, 3]
    print(f"\nInput array: {arr1}")
    print(f"Expected number of subsequences: 2^{len(arr1)} = {2**len(arr1)}")
    print("\nAll subsequences:")
    print_subsequences(arr1)

    # Test Case 2: Using the return version
    print("\n" + "=" * 70)
    print("GETTING SUBSEQUENCES AS A LIST")
    print("=" * 70)

    arr2 = ['a', 'b', 'c']
    print(f"\nInput array: {arr2}")
    all_subseqs = get_all_subsequences(arr2)
    print(f"All {len(all_subseqs)} subsequences: {all_subseqs}")

    # Test Case 3: Edge cases
    print("\n" + "=" * 70)
    print("EDGE CASES DEMONSTRATION")
    print("=" * 70)
    print()
    demonstrate_edge_cases()

    # Test Case 4: Variations
    print("=" * 70)
    print("VARIATION DEMONSTRATIONS")
    print("=" * 70)

    # Subsequences with sum
    print("\n--- Subsequences with Given Sum ---")
    arr3 = [1, 2, 3, 4, 5]
    target = 5
    print_subsequences_with_sum(arr3, target)
    # Expected: [5], [1,4], [2,3], [1,2,2]... wait, no 2,2
    # Actually: [5], [1,4], [2,3] only since we need sum=5

    # Count subsequences with sum
    print("\n--- Count Subsequences with Given Sum ---")
    arr4 = [1, 2, 3, 4, 5]
    target = 6
    count = count_subsequences_with_sum(arr4, target)
    print(f"Number of subsequences of {arr4} with sum = {target}: {count}")

    # Check existence
    print("\n--- Check if Subsequence with Sum Exists ---")
    arr5 = [1, 2, 3]
    target_exists = 5
    target_not_exists = 100
    print(f"Array: {arr5}")
    print(f"Subsequence with sum {target_exists} exists: {has_subsequence_with_sum(arr5, target_exists)}")
    print(f"Subsequence with sum {target_not_exists} exists: {has_subsequence_with_sum(arr5, target_not_exists)}")

    # Find one subsequence
    print("\n--- Find One Subsequence with Given Sum ---")
    arr6 = [1, 2, 3, 4, 5]
    target = 9
    print_one_subsequence_with_sum(arr6, target)

    print("\n" + "=" * 70)
    print("SUMMARY")
    print("=" * 70)
    print("""
Key Takeaways:
1. Subsequences maintain relative order but need not be contiguous
2. For n elements, there are exactly 2^n subsequences
3. The take/not-take pattern is the core recursive approach
4. Time: O(2^n), Space: O(n) for recursion stack
5. Backtracking (pop after recursive call) is crucial for correctness
6. This pattern extends to many variations: sum-based, count-based, etc.
""")
