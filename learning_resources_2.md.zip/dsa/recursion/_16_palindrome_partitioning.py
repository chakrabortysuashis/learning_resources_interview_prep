"""131. Palindrome Partitioning

Given a string s, partition s such that every substring of the partition is a palindrome.
Return all possible palindrome partitioning of s.

Example 1:
Input: s = "aab"
Output: [["a","a","b"],["aa","b"]]

Example 2:
Input: s = "a"
Output: [["a"]]

Constraints:
1 <= s.length <= 16
s contains only lowercase English letters.

================================================================================
                            PROBLEM UNDERSTANDING
================================================================================

What is a Partition?
--------------------
A partition of a string means dividing it into contiguous substrings such that:
- Each substring is non-empty
- The concatenation of all substrings gives the original string
- Substrings do not overlap

For example, "aab" can be partitioned as:
- ["a", "a", "b"]  -> "a" + "a" + "b" = "aab"
- ["a", "ab"]      -> "a" + "ab" = "aab"
- ["aa", "b"]      -> "aa" + "b" = "aab"
- ["aab"]          -> "aab" = "aab"

We need to find ALL partitions where EVERY substring is a palindrome.

================================================================================
                          CORE INTUITION: WHY BACKTRACKING?
================================================================================

This problem is a classic example of "generating all valid combinations" which
naturally fits the BACKTRACKING pattern. Here is why:

1. MULTIPLE VALID SOLUTIONS: We need ALL possible valid partitions, not just one.
   This screams "explore all paths" which is what backtracking does.

2. DECISION AT EACH STEP: At any position in the string, we have CHOICES:
   - Take 1 character as a partition
   - Take 2 characters as a partition
   - Take 3 characters as a partition
   - ... and so on until the end of string

   But we only proceed if that partition is a PALINDROME.

3. BUILD AND BACKTRACK: We build a partition incrementally, and if we hit a
   dead end or complete a valid partition, we backtrack to try other options.

================================================================================
                          KEY INSIGHT: THE PARTITIONING LOGIC
================================================================================

Think of it this way:
- We have a pointer 'start' that marks where our current unpartitioned string begins
- At each step, we try all possible "end" positions from 'start' to len(s)-1
- If s[start:end+1] is a palindrome, we:
  1. Add it to our current partition
  2. Recurse with start = end + 1
  3. Remove it (backtrack) to try the next possibility

Base Case: When start == len(s), we have successfully partitioned the entire
string, so we add the current partition to our results.

================================================================================
                    VISUAL DECISION TREE FOR s = "aab"
================================================================================

                                    ""
                                    |
                        start=0, try all palindromic prefixes
                       /            |              \
                    "a"            "aa"            "aab"
                 (is palindrome)  (is palindrome)  (not palindrome, SKIP)
                    |               |
              start=1             start=2
             /       \              |
           "a"       "ab"          "b"
      (palindrome) (not palindrome) (palindrome)
           |           SKIP          |
       start=2                    start=3
           |                        |
          "b"                    DONE!
      (palindrome)              Result: ["aa","b"]
           |
       start=3
           |
        DONE!
    Result: ["a","a","b"]

Final Results: [["a","a","b"], ["aa","b"]]

Notice how:
- We SKIP paths where the substring is not a palindrome ("aab", "ab")
- We only reach DONE (base case) when we have a complete valid partition
- Backtracking allows us to explore all valid paths


================================================================================
           ENHANCED RECURSION TREE WITH BOX DRAWINGS FOR s = "aab"
================================================================================

Below is a comprehensive visualization showing every recursive call, palindrome
check, partition state, and the branching decisions (EXPLORE vs SKIP).

String: s = "aab"   (indices: a=0, a=1, b=2)

+==============================================================================+
|                                                                              |
|                         LEVEL 0: ROOT NODE                                   |
|                                                                              |
| +------------------------------------------------------------------------+   |
| |                    backtrack(start=0, path=[])                         |   |
| |                         remaining: "aab"                               |   |
| +------------------------------------------------------------------------+   |
|                                    |                                         |
|        +---------------------------+---------------------------+             |
|        |                           |                           |             |
|        v                           v                           v             |
| +--------------+           +--------------+           +---------------+      |
| | try s[0:1]   |           | try s[0:2]   |           | try s[0:3]    |      |
| | substr: "a"  |           | substr: "aa" |           | substr: "aab" |      |
| +--------------+           +--------------+           +---------------+      |
|        |                           |                           |             |
|        v                           v                           v             |
| +--------------+           +--------------+           +---------------+      |
| |is_palindrome |           |is_palindrome |           | is_palindrome |      |
| |   ("a")?     |           |   ("aa")?    |           |    ("aab")?   |      |
| |              |           |              |           |               |      |
| | "a" == "a"   |           | "a" == "a"   |           | "a" != "b"    |      |
| |   YES  [✓]   |           |   YES  [✓]   |           |    NO  [✗]    |      |
| +--------------+           +--------------+           +---------------+      |
|        |                           |                           |             |
|        v                           v                           v             |
|   [EXPLORE]                  [EXPLORE]                     [SKIP]            |
|   Add "a"                    Add "aa"                   Do not recurse       |
|   to path                    to path                    Branch pruned!       |
|                                                                              |
+==============================================================================+


+==============================================================================+
|                                                                              |
|                 LEVEL 1 - BRANCH A: After choosing "a"                       |
|                                                                              |
| +------------------------------------------------------------------------+   |
| |              backtrack(start=1, path=["a"])                            |   |
| |                    remaining: "ab"                                     |   |
| +------------------------------------------------------------------------+   |
|                                    |                                         |
|              +---------------------+---------------------+                   |
|              |                                           |                   |
|              v                                           v                   |
|      +--------------+                           +---------------+            |
|      | try s[1:2]   |                           | try s[1:3]    |            |
|      | substr: "a"  |                           | substr: "ab"  |            |
|      +--------------+                           +---------------+            |
|              |                                           |                   |
|              v                                           v                   |
|      +--------------+                           +---------------+            |
|      |is_palindrome |                           | is_palindrome |            |
|      |   ("a")?     |                           |    ("ab")?    |            |
|      |              |                           |               |            |
|      | "a" == "a"   |                           | "a" != "b"    |            |
|      |   YES  [✓]   |                           |    NO  [✗]    |            |
|      +--------------+                           +---------------+            |
|              |                                           |                   |
|              v                                           v                   |
|         [EXPLORE]                                    [SKIP]                  |
|         Add "a"                                 Do not recurse               |
|         to path                                 Branch pruned!               |
|                                                                              |
+==============================================================================+


+==============================================================================+
|                                                                              |
|              LEVEL 2 - BRANCH A.A: After choosing "a", "a"                   |
|                                                                              |
| +------------------------------------------------------------------------+   |
| |              backtrack(start=2, path=["a","a"])                         |   |
| |                       remaining: "b"                                   |   |
| +------------------------------------------------------------------------+   |
|                                    |                                         |
|                                    v                                         |
|                           +--------------+                                   |
|                           | try s[2:3]   |                                   |
|                           | substr: "b"  |                                   |
|                           +--------------+                                   |
|                                    |                                         |
|                                    v                                         |
|                           +--------------+                                   |
|                           |is_palindrome |                                   |
|                           |   ("b")?     |                                   |
|                           |              |                                   |
|                           | "b" == "b"   |                                   |
|                           |   YES  [✓]   |                                   |
|                           +--------------+                                   |
|                                    |                                         |
|                                    v                                         |
|                              [EXPLORE]                                       |
|                              Add "b"                                         |
|                              to path                                         |
|                                                                              |
+==============================================================================+


+==============================================================================+
|                                                                              |
|         LEVEL 3 - BRANCH A.A.B: BASE CASE REACHED! (FIRST SOLUTION)          |
|                                                                              |
| +------------------------------------------------------------------------+   |
| |              backtrack(start=3, path=["a","a","b"])                     |   |
| |                       remaining: ""                                    |   |
| +------------------------------------------------------------------------+   |
|                                    |                                         |
|                                    v                                         |
|          +----------------------------------------------------+              |
|          |                   BASE CASE HIT!                   |              |
|          |                                                    |              |
|          |     start (3) == len(s) (3)   -->   TRUE           |              |
|          |                                                    |              |
|          |     Entire string has been partitioned!            |              |
|          |                                                    |              |
|          |  +----------------------------------------------+  |              |
|          |  |  FOUND VALID PARTITION #1: ["a", "a", "b"]   |  |              |
|          |  +----------------------------------------------+  |              |
|          |                                                    |              |
|          |     Add copy to result list                        |              |
|          |     result = [["a", "a", "b"]]                     |              |
|          |                                                    |              |
|          +----------------------------------------------------+              |
|                                    |                                         |
|                                    v                                         |
|                               [RETURN]                                       |
|                          Begin backtracking...                               |
|                                                                              |
+==============================================================================+


+==============================================================================+
|                                                                              |
|                 LEVEL 1 - BRANCH B: After choosing "aa"                      |
|             (We backtracked from Branch A and now try "aa")                  |
|                                                                              |
| +------------------------------------------------------------------------+   |
| |              backtrack(start=2, path=["aa"])                           |   |
| |                       remaining: "b"                                   |   |
| +------------------------------------------------------------------------+   |
|                                    |                                         |
|                                    v                                         |
|                           +--------------+                                   |
|                           | try s[2:3]   |                                   |
|                           | substr: "b"  |                                   |
|                           +--------------+                                   |
|                                    |                                         |
|                                    v                                         |
|                           +--------------+                                   |
|                           |is_palindrome |                                   |
|                           |   ("b")?     |                                   |
|                           |              |                                   |
|                           | "b" == "b"   |                                   |
|                           |   YES  [✓]   |                                   |
|                           +--------------+                                   |
|                                    |                                         |
|                                    v                                         |
|                              [EXPLORE]                                       |
|                              Add "b"                                         |
|                              to path                                         |
|                                                                              |
+==============================================================================+


+==============================================================================+
|                                                                              |
|          LEVEL 2 - BRANCH B.B: BASE CASE REACHED! (SECOND SOLUTION)          |
|                                                                              |
| +------------------------------------------------------------------------+   |
| |              backtrack(start=3, path=["aa","b"])                        |   |
| |                       remaining: ""                                    |   |
| +------------------------------------------------------------------------+   |
|                                    |                                         |
|                                    v                                         |
|          +----------------------------------------------------+              |
|          |                   BASE CASE HIT!                   |              |
|          |                                                    |              |
|          |     start (3) == len(s) (3)   -->   TRUE           |              |
|          |                                                    |              |
|          |     Entire string has been partitioned!            |              |
|          |                                                    |              |
|          |  +----------------------------------------------+  |              |
|          |  |  FOUND VALID PARTITION #2: ["aa", "b"]       |  |              |
|          |  +----------------------------------------------+  |              |
|          |                                                    |              |
|          |     Add copy to result list                        |              |
|          |     result = [["a","a","b"], ["aa","b"]]           |              |
|          |                                                    |              |
|          +----------------------------------------------------+              |
|                                    |                                         |
|                                    v                                         |
|                               [RETURN]                                       |
|                          All branches explored!                              |
|                                                                              |
+==============================================================================+


================================================================================
                      COMPLETE TREE VISUALIZATION (COMPACT)
================================================================================

This shows the entire recursion tree in one view with all branches:

                    +-------------------------------------+
                    |  backtrack(start=0, path=[])        |
                    |  s = "aab"                          |
                    +-------------------------------------+
                                      |
            +-------------------------+-------------------------+
            |                         |                         |
            v                         v                         v
     +-------------+          +-------------+          +---------------+
     | try "a"     |          | try "aa"    |          | try "aab"     |
     | palindrome? |          | palindrome? |          | palindrome?   |
     | YES [✓]     |          | YES [✓]     |          | NO  [✗]       |
     | EXPLORE     |          | EXPLORE     |          | SKIP          |
     +-------------+          +-------------+          +---------------+
            |                         |
            v                         v
+-------------------------+   +-------------------------+
| backtrack(1, ["a"])     |   | backtrack(2, ["aa"])    |
| remaining: "ab"         |   | remaining: "b"          |
+-------------------------+   +-------------------------+
            |                         |
      +-----+-----+                   v
      |           |           +-------------+
      v           v           | try "b"     |
+----------+ +----------+     | palindrome? |
| try "a"  | | try "ab" |     | YES [✓]     |
| palin?   | | palin?   |     | EXPLORE     |
| YES [✓]  | | NO [✗]   |     +-------------+
| EXPLORE  | | SKIP     |           |
+----------+ +----------+           v
      |                    +-------------------------+
      v                    | backtrack(3, ["aa","b"])|
+-------------------------+| remaining: ""           |
| backtrack(2, ["a","a"]) |+-------------------------+
| remaining: "b"          |         |
+-------------------------+         v
      |                    +-------------------------+
      v                    |      BASE CASE!         |
+-------------+            | start==len(s)           |
| try "b"     |            | FOUND: ["aa", "b"]      |
| palindrome? |            +-------------------------+
| YES [✓]     |
| EXPLORE     |
+-------------+
      |
      v
+-----------------------------+
| backtrack(3, ["a","a","b"]) |
| remaining: ""               |
+-----------------------------+
      |
      v
+-----------------------------+
|        BASE CASE!           |
| start==len(s)               |
| FOUND: ["a", "a", "b"]      |
+-----------------------------+


================================================================================
              SUMMARY: PATHS TO VALID PARTITIONS FOR s = "aab"
================================================================================

+------------------------------------------------------------------------------+
|                                                                              |
|  PATH 1: Root -> "a" -> "a" -> "b" -> BASE CASE                              |
|  ======================================================================      |
|                                                                              |
|  Step 1: start=0, path=[]                                                    |
|          try "a"  -> is_palindrome("a")? YES [✓] -> EXPLORE                  |
|                                                                              |
|  Step 2: start=1, path=["a"]                                                 |
|          try "a"  -> is_palindrome("a")? YES [✓] -> EXPLORE                  |
|                                                                              |
|  Step 3: start=2, path=["a","a"]                                             |
|          try "b"  -> is_palindrome("b")? YES [✓] -> EXPLORE                  |
|                                                                              |
|  Step 4: start=3, path=["a","a","b"]                                         |
|          BASE CASE: start == len(s)                                          |
|          RESULT: ["a", "a", "b"]                                             |
|                                                                              |
+------------------------------------------------------------------------------+

+------------------------------------------------------------------------------+
|                                                                              |
|  PATH 2: Root -> "aa" -> "b" -> BASE CASE                                    |
|  ======================================================================      |
|                                                                              |
|  Step 1: start=0, path=[]                                                    |
|          try "aa" -> is_palindrome("aa")? YES [✓] -> EXPLORE                 |
|          (Note: "aab" was SKIPPED because is_palindrome("aab") = NO [✗])     |
|                                                                              |
|  Step 2: start=2, path=["aa"]                                                |
|          try "b"  -> is_palindrome("b")? YES [✓] -> EXPLORE                  |
|                                                                              |
|  Step 3: start=3, path=["aa","b"]                                            |
|          BASE CASE: start == len(s)                                          |
|          RESULT: ["aa", "b"]                                                 |
|                                                                              |
+------------------------------------------------------------------------------+

+------------------------------------------------------------------------------+
|                                                                              |
|  SKIPPED BRANCHES (Pruned due to non-palindrome substrings)                  |
|  =====================================================================       |
|                                                                              |
|  1. At start=0: "aab" -> is_palindrome? NO [✗] -> SKIP                       |
|     Reason: 'a' (first char) != 'b' (last char)                              |
|                                                                              |
|  2. At start=1 (in path ["a"]): "ab" -> is_palindrome? NO [✗] -> SKIP        |
|     Reason: 'a' (first char) != 'b' (last char)                              |
|                                                                              |
+------------------------------------------------------------------------------+

================================================================================
               FINAL RESULT: [["a", "a", "b"], ["aa", "b"]]
================================================================================

================================================================================
"""

from typing import List


class Solution:
    """
    Solution using Backtracking approach.

    The idea is to explore all possible ways to partition the string,
    but only proceed down a path if the current substring is a palindrome.
    """

    def partition(self, s: str) -> List[List[str]]:
        """
        Main function to find all palindrome partitions of string s.

        Args:
            s: Input string to partition

        Returns:
            List of all valid palindrome partitions
        """
        result = []           # Stores all valid partitions
        current_partition = []  # Stores the current partition being built

        # Start the backtracking from index 0
        self._backtrack(s, 0, current_partition, result)

        return result

    def _is_palindrome(self, s: str, left: int, right: int) -> bool:
        """
        Helper function to check if s[left:right+1] is a palindrome.

        Uses two-pointer technique: compare characters from both ends
        moving towards the center.

        Args:
            s: The string
            left: Starting index (inclusive)
            right: Ending index (inclusive)

        Returns:
            True if the substring is a palindrome, False otherwise
        """
        while left < right:
            if s[left] != s[right]:
                return False  # Mismatch found, not a palindrome
            left += 1
            right -= 1
        return True  # All characters matched, it is a palindrome

    def _backtrack(self, s: str, start: int, current_partition: List[str],
                   result: List[List[str]]) -> None:
        """
        Recursive backtracking function to build all valid partitions.

        Args:
            s: The original string
            start: Current starting index in the string
            current_partition: List of palindromic substrings collected so far
            result: List to store all valid complete partitions
        """
        # BASE CASE: We have processed the entire string
        # This means current_partition contains a valid complete partition
        if start == len(s):
            # Make a COPY of current_partition (important!)
            # If we do not copy, all results will point to the same list
            # which will be empty after all backtracking completes
            result.append(current_partition[:])
            return

        # RECURSIVE CASE: Try all possible end positions
        # end goes from 'start' to 'len(s)-1'
        for end in range(start, len(s)):
            # Check if substring s[start:end+1] is a palindrome
            if self._is_palindrome(s, start, end):
                # CHOOSE: Add this palindrome to our current partition
                current_partition.append(s[start:end + 1])

                # EXPLORE: Recurse to partition the remaining string
                # The remaining string starts at index 'end + 1'
                self._backtrack(s, end + 1, current_partition, result)

                # UNCHOOSE (BACKTRACK): Remove the palindrome to try other options
                # This allows us to explore other partition possibilities
                current_partition.pop()


"""
================================================================================
                    DRY RUN FOR s = "aab"
================================================================================

Let us trace through the execution step by step.

Initial Call: _backtrack(s="aab", start=0, current_partition=[], result=[])

--------------------------------------------------------------------------------
STEP 1: start=0, current_partition=[]
--------------------------------------------------------------------------------
Try all endings from index 0:

  end=0: substring = "a" (s[0:1])
         Is "a" palindrome? YES (single char is always palindrome)
         -> Add "a" to partition: current_partition = ["a"]
         -> Recurse with start=1

--------------------------------------------------------------------------------
STEP 2: start=1, current_partition=["a"]
--------------------------------------------------------------------------------
Try all endings from index 1:

  end=1: substring = "a" (s[1:2])
         Is "a" palindrome? YES
         -> Add "a" to partition: current_partition = ["a", "a"]
         -> Recurse with start=2

--------------------------------------------------------------------------------
STEP 3: start=2, current_partition=["a", "a"]
--------------------------------------------------------------------------------
Try all endings from index 2:

  end=2: substring = "b" (s[2:3])
         Is "b" palindrome? YES
         -> Add "b" to partition: current_partition = ["a", "a", "b"]
         -> Recurse with start=3

--------------------------------------------------------------------------------
STEP 4: start=3, current_partition=["a", "a", "b"]
--------------------------------------------------------------------------------
BASE CASE HIT! start (3) == len(s) (3)
-> Add copy of current_partition to result
-> result = [["a", "a", "b"]]
-> RETURN

--------------------------------------------------------------------------------
BACKTRACK TO STEP 3: current_partition=["a", "a", "b"]
--------------------------------------------------------------------------------
Pop "b": current_partition = ["a", "a"]
No more endings to try at start=2 (end was already at last index)
-> RETURN

--------------------------------------------------------------------------------
BACKTRACK TO STEP 2: current_partition=["a", "a"]
--------------------------------------------------------------------------------
Pop "a": current_partition = ["a"]
Continue with end=2:

  end=2: substring = "ab" (s[1:3])
         Is "ab" palindrome? NO ("a" != "b")
         -> SKIP this path

No more endings to try at start=1
-> RETURN

--------------------------------------------------------------------------------
BACKTRACK TO STEP 1: current_partition=["a"]
--------------------------------------------------------------------------------
Pop "a": current_partition = []
Continue with end=1:

  end=1: substring = "aa" (s[0:2])
         Is "aa" palindrome? YES ("a" == "a")
         -> Add "aa" to partition: current_partition = ["aa"]
         -> Recurse with start=2

--------------------------------------------------------------------------------
STEP 5: start=2, current_partition=["aa"]
--------------------------------------------------------------------------------
Try all endings from index 2:

  end=2: substring = "b" (s[2:3])
         Is "b" palindrome? YES
         -> Add "b" to partition: current_partition = ["aa", "b"]
         -> Recurse with start=3

--------------------------------------------------------------------------------
STEP 6: start=3, current_partition=["aa", "b"]
--------------------------------------------------------------------------------
BASE CASE HIT! start (3) == len(s) (3)
-> Add copy of current_partition to result
-> result = [["a", "a", "b"], ["aa", "b"]]
-> RETURN

--------------------------------------------------------------------------------
BACKTRACK TO STEP 5: current_partition=["aa", "b"]
--------------------------------------------------------------------------------
Pop "b": current_partition = ["aa"]
No more endings to try at start=2
-> RETURN

--------------------------------------------------------------------------------
BACKTRACK TO STEP 1: current_partition=["aa"]
--------------------------------------------------------------------------------
Pop "aa": current_partition = []
Continue with end=2:

  end=2: substring = "aab" (s[0:3])
         Is "aab" palindrome? NO ("a" != "b")
         -> SKIP this path

No more endings to try at start=0
-> RETURN

================================================================================
FINAL RESULT: [["a", "a", "b"], ["aa", "b"]]
================================================================================


================================================================================
                    DRY RUN FOR s = "a" (EDGE CASE)
================================================================================

Initial Call: _backtrack(s="a", start=0, current_partition=[], result=[])

STEP 1: start=0, current_partition=[]
  end=0: substring = "a"
         Is "a" palindrome? YES
         -> Add "a" to partition: current_partition = ["a"]
         -> Recurse with start=1

STEP 2: start=1, current_partition=["a"]
BASE CASE HIT! start (1) == len(s) (1)
-> Add copy to result
-> result = [["a"]]

FINAL RESULT: [["a"]]


================================================================================
                         COMPLEXITY ANALYSIS
================================================================================

TIME COMPLEXITY: O(N * 2^N)
------------------------
Where N is the length of the string.

Why 2^N?
- At each position, we have a choice: either end the current partition here
  or continue to the next character.
- This is like a binary choice at each of N-1 positions between characters.
- So there can be at most 2^(N-1) possible partitions.

Why multiply by N?
- For each partition, we need to:
  1. Check if substrings are palindromes: O(N) in worst case
  2. Copy the partition to result: O(N) in worst case

So overall: O(N * 2^N)

SPACE COMPLEXITY: O(N)
----------------------
- Recursion stack depth: O(N) in the worst case (when each character is
  a separate partition, we have N recursive calls)
- current_partition list: O(N) at most (can hold at most N single-char strings)
- Note: The result storage is not counted as auxiliary space since it is
  part of the output.

If we count output space: O(N * 2^N) for storing all partitions.


================================================================================
                              EDGE CASES
================================================================================

1. SINGLE CHARACTER STRING (s = "a"):
   - A single character is always a palindrome.
   - Output: [["a"]]
   - Only one possible partition.

2. ALL SAME CHARACTERS (s = "aaa"):
   - Every possible substring is a palindrome!
   - Output: [["a","a","a"], ["a","aa"], ["aa","a"], ["aaa"]]
   - Maximum number of valid partitions.
   - This is the worst case for time complexity.

3. ALL DIFFERENT CHARACTERS (s = "abc"):
   - Only single characters are palindromes.
   - Output: [["a","b","c"]]
   - Only one valid partition (each char separate).
   - This is actually the best case in terms of result size.

4. LONGER PALINDROMES (s = "abba"):
   - Multiple ways to partition with longer palindromes.
   - Output: [["a","b","b","a"], ["a","bb","a"], ["abba"]]
   - Notice "abba" itself is a palindrome!

5. EMPTY STRING (s = ""):
   - Not possible per constraints (1 <= s.length).
   - If allowed, output would be [[]] (one partition with no substrings).


================================================================================
                         ALTERNATIVE APPROACHES
================================================================================

1. MEMOIZATION FOR PALINDROME CHECKS:
   - We can precompute a 2D table dp[i][j] that tells if s[i:j+1] is palindrome.
   - This reduces repeated palindrome checks from O(N) to O(1).
   - Preprocessing takes O(N^2) time and space.
   - Useful when the same substrings are checked multiple times.

2. ITERATIVE APPROACH:
   - Can be done using a stack, but more complex and less intuitive.
   - Backtracking with recursion is the natural and cleaner approach.

================================================================================
"""


# Testing the solution
if __name__ == "__main__":
    solution = Solution()

    # Test Case 1
    s1 = "aab"
    print(f"Input: s = \"{s1}\"")
    print(f"Output: {solution.partition(s1)}")
    print(f"Expected: [[\"a\",\"a\",\"b\"],[\"aa\",\"b\"]]")
    print()

    # Test Case 2
    s2 = "a"
    print(f"Input: s = \"{s2}\"")
    print(f"Output: {solution.partition(s2)}")
    print(f"Expected: [[\"a\"]]")
    print()

    # Test Case 3 - All same characters
    s3 = "aaa"
    print(f"Input: s = \"{s3}\"")
    print(f"Output: {solution.partition(s3)}")
    print()

    # Test Case 4 - All different characters
    s4 = "abc"
    print(f"Input: s = \"{s4}\"")
    print(f"Output: {solution.partition(s4)}")
    print()

    # Test Case 5 - Longer palindrome
    s5 = "abba"
    print(f"Input: s = \"{s5}\"")
    print(f"Output: {solution.partition(s5)}")
