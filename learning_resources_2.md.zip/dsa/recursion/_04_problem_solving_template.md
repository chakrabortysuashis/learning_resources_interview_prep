# How to Solve ANY Recursion Problem: The Ultimate Template

## The Master Framework

When you see a problem and wonder "Can I solve this with recursion?", follow this step-by-step framework:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│                    THE 5-STEP RECURSION FRAMEWORK                           │
│                    ═════════════════════════════════                        │
│                                                                             │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │  STEP 1: Can this problem be broken into smaller same-type          │   │
│   │          problems?                                                  │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                              │                                              │
│                              ▼                                              │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │  STEP 2: What is the smallest/simplest version of this problem?    │   │
│   │          (This becomes your BASE CASE)                             │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                              │                                              │
│                              ▼                                              │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │  STEP 3: How do I make the problem smaller?                        │   │
│   │          (This becomes your RECURSIVE CALL)                        │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                              │                                              │
│                              ▼                                              │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │  STEP 4: How do I combine the current piece with the recursive     │   │
│   │          result?                                                   │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                              │                                              │
│                              ▼                                              │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │  STEP 5: Trust the recursion! (Leap of Faith)                      │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## The Universal Code Template

```python
def solve(problem):
    #═══════════════════════════════════════════════════════════════
    # STEP 2: BASE CASE - The simplest version we know the answer to
    #═══════════════════════════════════════════════════════════════
    if problem_is_simplest:
        return known_answer
    
    #═══════════════════════════════════════════════════════════════
    # STEP 3: MAKE IT SMALLER - Break into a smaller piece
    #═══════════════════════════════════════════════════════════════
    smaller_problem = shrink(problem)
    current_piece = extract_current(problem)
    
    #═══════════════════════════════════════════════════════════════
    # STEP 5: TRUST THE MAGIC - Assume recursion solves smaller
    #═══════════════════════════════════════════════════════════════
    recursive_result = solve(smaller_problem)
    
    #═══════════════════════════════════════════════════════════════
    # STEP 4: COMBINE - Put together current piece and recursive result
    #═══════════════════════════════════════════════════════════════
    return combine(current_piece, recursive_result)
```

---

## Worked Example: Reverse a String

### Problem: Write a function to reverse a string

**Input:** `"hello"`  
**Output:** `"olleh"`

### Applying the 5 Steps:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   STEP 1: Can we break it into smaller same-type problems?                  │
│   ────────────────────────────────────────────────────────                  │
│                                                                             │
│   "hello" → reverse("ello") + "h"                                          │
│                                                                             │
│   YES! Reversing "hello" = Reversing "ello" + putting "h" at the end       │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   STEP 2: What's the simplest version? (BASE CASE)                          │
│   ─────────────────────────────────────────────────                         │
│                                                                             │
│   Empty string "" → reverse is ""                                           │
│   OR                                                                        │
│   Single character "a" → reverse is "a"                                     │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   STEP 3: How to make it smaller? (SHRINK)                                  │
│   ─────────────────────────────────────────                                 │
│                                                                             │
│   Take all characters except the first one: s[1:]                           │
│                                                                             │
│   "hello" → "ello" (smaller by 1 character!)                               │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   STEP 4: How to combine?                                                   │
│   ───────────────────────                                                   │
│                                                                             │
│   reverse("ello") gives us "olle"                                          │
│   We need to add "h" at the END                                             │
│                                                                             │
│   result = reverse(s[1:]) + s[0]                                           │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   STEP 5: Trust the magic!                                                  │
│   ────────────────────────                                                  │
│                                                                             │
│   Believe that reverse("ello") will correctly give "olle"                  │
│   Don't worry about HOW it works internally                                 │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### The Code:

```python
def reverse(s):
    # BASE CASE
    if len(s) <= 1:
        return s
    
    # RECURSIVE CASE
    first_char = s[0]
    rest_reversed = reverse(s[1:])  # Trust the magic!
    
    return rest_reversed + first_char
```

### Recursion Tree for reverse("hello"):

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│                     reverse("hello")                                        │
│                           │                                                 │
│                           │ = reverse("ello") + "h"                        │
│                           │                                                 │
│                     reverse("ello")                                         │
│                           │                                                 │
│                           │ = reverse("llo") + "e"                         │
│                           │                                                 │
│                     reverse("llo")                                          │
│                           │                                                 │
│                           │ = reverse("lo") + "l"                          │
│                           │                                                 │
│                     reverse("lo")                                           │
│                           │                                                 │
│                           │ = reverse("o") + "l"                           │
│                           │                                                 │
│                     reverse("o")                                            │
│                           │                                                 │
│                           └──→ "o" (BASE CASE!)                            │
│                                                                             │
│   Now unwind:                                                               │
│   reverse("lo") = "o" + "l" = "ol"                                         │
│   reverse("llo") = "ol" + "l" = "oll"                                      │
│   reverse("ello") = "oll" + "e" = "olle"                                   │
│   reverse("hello") = "olle" + "h" = "olleh" ✓                              │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Another Example: Power Function (x^n)

### Problem: Calculate x raised to power n

### Applying the Framework:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   STEP 1: Break into smaller problems?                                      │
│   ──────────────────────────────────────                                    │
│                                                                             │
│   x^n = x × x^(n-1)                                                        │
│                                                                             │
│   Example: 2^5 = 2 × 2^4                                                   │
│                     ↑                                                       │
│               smaller problem!                                              │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   STEP 2: Base case?                                                        │
│   ──────────────────                                                        │
│                                                                             │
│   x^0 = 1 (anything to power 0 is 1)                                       │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   STEP 3: How to shrink?                                                    │
│   ──────────────────────                                                    │
│                                                                             │
│   Reduce n by 1 each time: power(x, n-1)                                   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   STEP 4: How to combine?                                                   │
│   ───────────────────────                                                   │
│                                                                             │
│   Multiply x with the result of the recursive call                          │
│                                                                             │
│   return x * power(x, n-1)                                                 │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### The Code:

```python
def power(x, n):
    # BASE CASE
    if n == 0:
        return 1
    
    # RECURSIVE CASE
    return x * power(x, n - 1)
```

### Recursion Tree for power(2, 4):

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│                        power(2, 4)                                          │
│                            │                                                │
│                            │ = 2 × power(2, 3)                             │
│                            │                                                │
│                        power(2, 3)                                          │
│                            │                                                │
│                            │ = 2 × power(2, 2)                             │
│                            │                                                │
│                        power(2, 2)                                          │
│                            │                                                │
│                            │ = 2 × power(2, 1)                             │
│                            │                                                │
│                        power(2, 1)                                          │
│                            │                                                │
│                            │ = 2 × power(2, 0)                             │
│                            │                                                │
│                        power(2, 0)                                          │
│                            │                                                │
│                            └──→ 1 (BASE CASE!)                             │
│                                                                             │
│   Unwind:                                                                   │
│   power(2, 1) = 2 × 1 = 2                                                  │
│   power(2, 2) = 2 × 2 = 4                                                  │
│   power(2, 3) = 2 × 4 = 8                                                  │
│   power(2, 4) = 2 × 8 = 16 ✓                                               │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Quick Reference: Common Patterns

### Pattern 1: Process One Element at a Time

```python
def process_list(items):
    if not items:                    # Base: empty
        return base_value
    return combine(items[0], process_list(items[1:]))
```

**Use for:** Sum, product, max, min, count, find, filter

### Pattern 2: Binary Recursion (Two Calls)

```python
def binary_recurse(n):
    if n <= base_threshold:          # Base case
        return base_value
    return combine(binary_recurse(n-1), binary_recurse(n-2))
```

**Use for:** Fibonacci, merge sort, tree traversals

### Pattern 3: Decision Making

```python
def decide(choices, current_state):
    if no_more_choices:              # Base: no choices left
        return evaluate(current_state)
    
    # Try including current choice
    with_choice = decide(rest, updated_state)
    # Try excluding current choice  
    without_choice = decide(rest, current_state)
    
    return best(with_choice, without_choice)
```

**Use for:** Subset problems, combinations, knapsack

---

## The "Leap of Faith" Explained

This is the HARDEST but MOST IMPORTANT part of recursion:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│                         THE LEAP OF FAITH                                   │
│                         ═════════════════                                   │
│                                                                             │
│   When you write:                                                           │
│                                                                             │
│       def factorial(n):                                                     │
│           if n == 0:                                                        │
│               return 1                                                      │
│           return n * factorial(n-1)  ← "TRUST ME, THIS WORKS"               │
│                                                                             │
│   You MUST believe that factorial(n-1) will give you the correct           │
│   answer, WITHOUT tracing through every step mentally.                      │
│                                                                             │
│   ┌─────────────────────────────────────────────────────────────────┐       │
│   │                                                                 │       │
│   │   "If factorial(4) magically gives me 24,                      │       │
│   │    then factorial(5) = 5 × 24 = 120"                           │       │
│   │                                                                 │       │
│   │   I don't need to know HOW factorial(4) gets 24.               │       │
│   │   I just trust that it does.                                   │       │
│   │                                                                 │       │
│   └─────────────────────────────────────────────────────────────────┘       │
│                                                                             │
│   WHY does this work?                                                       │
│   ────────────────────                                                      │
│   • Your base case handles the simplest input correctly                     │
│   • Your recursive case reduces the problem                                 │
│   • Eventually, everything reaches the base case                            │
│   • Answers bubble up correctly through your combine logic                  │
│                                                                             │
│   It's like MATHEMATICAL INDUCTION:                                         │
│   1. Prove it works for n=0 (base case)                                    │
│   2. Prove if it works for n, it works for n+1 (recursive case)           │
│   3. Therefore, it works for all n!                                        │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Debugging Checklist

When your recursion doesn't work, check these:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   □ BASE CASE CHECK                                                         │
│     • Does my base case actually get reached?                               │
│     • Does my base case return the correct value?                           │
│     • Do I have ALL necessary base cases?                                   │
│                                                                             │
│   □ SHRINKING CHECK                                                         │
│     • Am I making the problem smaller in EVERY recursive call?              │
│     • Is the problem definitely moving toward the base case?                │
│                                                                             │
│   □ COMBINE CHECK                                                           │
│     • Am I combining the current piece with the recursive result correctly? │
│     • Is my operation associative (if needed)?                              │
│                                                                             │
│   □ STACK OVERFLOW?                                                         │
│     • Is my recursion going too deep?                                       │
│     • Do I need to convert to iteration or use tail recursion?              │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Practice Problems

Try applying the framework to these:

### Easy
1. **Sum of digits:** `sum_digits(123) = 1 + 2 + 3 = 6`
2. **Count occurrences:** `count('hello', 'l') = 2`
3. **Check palindrome:** `is_palindrome('radar') = True`

### Medium
4. **Flatten nested list:** `flatten([[1,2],[3,[4,5]]]) = [1,2,3,4,5]`
5. **Generate all subsets:** `subsets([1,2]) = [[], [1], [2], [1,2]]`
6. **Binary search:** Find element in sorted array

### Challenge
7. **Tower of Hanoi:** Move disks from one peg to another
8. **Generate permutations:** All orderings of elements
9. **N-Queens:** Place N queens on NxN chessboard

---

## How to Visualize: Drawing Recursion Trees

One of the most powerful tools for understanding recursion is drawing the recursion tree. This section teaches you HOW to draw them for ANY problem.

### General Template for Recursion Trees

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│                    RECURSION TREE FOR [YOUR PROBLEM]                        │
│                    ═════════════════════════════════                        │
│                                                                             │
│                          function(initial_state)                            │
│                                    │                                        │
│                     ┌──────────────┼──────────────┐                         │
│                     │              │              │                         │
│              [choice 1]      [choice 2]    [choice N]                       │
│                   │              │              │                           │
│              sub-state       sub-state      sub-state                       │
│                   │              │              │                           │
│                 ...            ...            ...                           │
│                   │              │              │                           │
│                LEAVES         LEAVES        LEAVES                          │
│             (base cases)   (base cases)  (base cases)                       │
│                                                                             │
│   LEGEND:                                                                   │
│   ────────                                                                  │
│   - ROOT = Original function call with initial parameters                   │
│   - Each node = A function call with its current state                      │
│   - Edges (lines) = Recursive calls from parent to child                    │
│   - Leaves = Base cases (no more recursive calls)                           │
│   - Depth = Number of recursive calls deep                                  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

### What to Include at Each Node

When drawing each node in your recursion tree, include these key elements:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   NODE ANATOMY: What information goes inside each node?                     │
│   ════════════════════════════════════════════════════                      │
│                                                                             │
│   ┌─────────────────────────────────────────────┐                           │
│   │                                             │                           │
│   │   function_name(param1, param2, ...)        │ ← Function call           │
│   │   state: [current_state_description]        │ ← Current state (optional)│
│   │   returns: [value]                          │ ← Return value (optional) │
│   │                                             │                           │
│   └─────────────────────────────────────────────┘                           │
│                                                                             │
│   MINIMUM (Simple Problems):                                                │
│   • Just the function call: factorial(3)                                    │
│                                                                             │
│   DETAILED (Complex Problems):                                              │
│   • Function call + state: solve(index=2, path=[1,2])                       │
│   • Include return values when unwinding                                    │
│                                                                             │
│   FOR BACKTRACKING:                                                         │
│   • Show the "choice" made to reach this node                               │
│   • Show the current accumulated result/path                                │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

### Tree Shapes: Know Your Pattern

Different recursion patterns create different tree shapes. Recognizing the shape helps you understand complexity!

#### Shape 1: LINEAR (Single Branch per Level)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   LINEAR RECURSION - One recursive call per level                           │
│   ═══════════════════════════════════════════════                           │
│                                                                             │
│   Examples: Factorial, Palindrome Check, Array Sum, String Reverse          │
│                                                                             │
│                         f(n)                                                │
│                          │                                                  │
│                         f(n-1)                                              │
│                          │                                                  │
│                         f(n-2)                                              │
│                          │                                                  │
│                         ...                                                 │
│                          │                                                  │
│                         f(1)                                                │
│                          │                                                  │
│                         f(0) ← BASE CASE                                    │
│                                                                             │
│   Complexity:                                                               │
│   • Time: O(n) - n function calls                                           │
│   • Space: O(n) - n stack frames                                            │
│   • Tree height = n                                                         │
│   • Total nodes = n                                                         │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### Shape 2: BINARY (Two Branches per Level)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   BINARY RECURSION - Two recursive calls per level                          │
│   ════════════════════════════════════════════════                          │
│                                                                             │
│   Examples: Fibonacci, Subsets, Binary Tree Traversal, Merge Sort           │
│                                                                             │
│                              f(n)                                           │
│                             /    \                                          │
│                           /        \                                        │
│                       f(n-1)      f(n-2)                                    │
│                       /    \      /    \                                    │
│                     f(n-2) f(n-3) f(n-3) f(n-4)                             │
│                      ...    ...   ...    ...                                │
│                                                                             │
│   Complexity:                                                               │
│   • Time: O(2^n) - exponential (worst case)                                 │
│   • Space: O(n) - max depth of recursion                                    │
│   • Tree height = n                                                         │
│   • Total nodes = up to 2^n                                                 │
│                                                                             │
│   SUBSET PATTERN (Include/Exclude):                                         │
│                                                                             │
│                          f(index=0, current=[])                             │
│                         /                      \                            │
│                  [include]                   [exclude]                      │
│                       │                          │                          │
│             f(1, [elem0])                   f(1, [])                        │
│              /         \                   /       \                        │
│         include     exclude           include    exclude                    │
│             │           │                 │          │                      │
│       f(2,[e0,e1])  f(2,[e0])       f(2,[e1])   f(2,[])                     │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### Shape 3: N-ARY (Multiple Branches per Level)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   N-ARY RECURSION - Multiple (N) recursive calls per level                  │
│   ════════════════════════════════════════════════════════                  │
│                                                                             │
│   Examples: Permutations, N-Queens, Combinations, Word Search               │
│                                                                             │
│                                f(state)                                     │
│                     ┌────────────┼────────────┐                             │
│                     │            │            │                             │
│                 choice_1     choice_2     choice_3                          │
│                   /│\          /│\          /│\                             │
│                  / │ \        / │ \        / │ \                            │
│                 c1 c2 c3     c1 c2 c3     c1 c2 c3                          │
│                 ...          ...          ...                               │
│                                                                             │
│   Complexity:                                                               │
│   • Time: O(n^n) or O(n!) depending on problem                              │
│   • Space: O(n) - max depth                                                 │
│   • Branching factor = number of choices at each step                       │
│                                                                             │
│   PERMUTATION PATTERN:                                                      │
│                                                                             │
│                          permute([1,2,3], [])                               │
│                    ┌────────────┼────────────┐                              │
│                 pick 1       pick 2       pick 3                            │
│                    │            │            │                              │
│           permute([2,3],[1]) permute([1,3],[2]) permute([1,2],[3])          │
│               /      \          /      \          /      \                  │
│           pick 2  pick 3    pick 1  pick 3    pick 1  pick 2                │
│              │       │         │       │         │       │                  │
│           [1,2,3] [1,3,2]   [2,1,3] [2,3,1]   [3,1,2] [3,2,1]               │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

### Tips for Showing Backtracking

Backtracking is when you "undo" a choice and try a different path. Here is how to visualize it:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   BACKTRACKING VISUALIZATION                                                │
│   ══════════════════════════                                                │
│                                                                             │
│   Key Concept: Make a choice → Explore → Undo choice → Try next             │
│                                                                             │
│   Example: Finding paths that sum to target                                 │
│                                                                             │
│                          solve(index=0, sum=0, path=[])                     │
│                                      │                                      │
│                    ┌─────────────────┼─────────────────┐                    │
│                    │                                   │                    │
│               ADD nums[0]                         SKIP nums[0]              │
│               path=[3]                            path=[]                   │
│               sum=3                               sum=0                     │
│                    │                                   │                    │
│           ┌────────┴────────┐                 ┌────────┴────────┐           │
│           │                 │                 │                 │           │
│       ADD nums[1]      SKIP nums[1]      ADD nums[1]      SKIP nums[1]      │
│       path=[3,1]       path=[3]          path=[1]         path=[]           │
│       sum=4            sum=3             sum=1            sum=0             │
│           │                 │                 │                 │           │
│          ...               ...               ...               ...          │
│                                                                             │
│   ──────────────────────────────────────────────────────────────────        │
│                                                                             │
│   BACKTRACKING NOTATION:                                                    │
│                                                                             │
│       ──────→ "Make choice" (going down)                                    │
│       - - -→ "Undo choice / Backtrack" (going up, shown as dashed)          │
│       [X]    "Pruned branch" (invalid, don't explore further)               │
│       [*]    "Valid solution found"                                         │
│                                                                             │
│   Visual Example with Pruning:                                              │
│                                                                             │
│                              f(0)                                           │
│                    ┌──────────┴──────────┐                                  │
│                    │                     │                                  │
│                  f(1)                  f(1)                                  │
│                 /    \                   │                                  │
│              f(2)    [X]               f(2)                                  │
│               │     PRUNED              / \                                 │
│              [*]                     [*]  [X]                               │
│            VALID!                  VALID! PRUNED                            │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

### Step-by-Step Guide: Drawing Your Own Tree

Follow these steps to draw a recursion tree for ANY problem:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   STEP 1: IDENTIFY THE RECURSIVE STRUCTURE                                  │
│   ─────────────────────────────────────────                                 │
│                                                                             │
│   Ask yourself:                                                             │
│   • What parameters change in each recursive call?                          │
│   • How many recursive calls are made per function call?                    │
│   • What is the base case?                                                  │
│                                                                             │
│   Example: subsets([1,2,3])                                                 │
│   • Parameter that changes: index (0, 1, 2, 3)                              │
│   • Recursive calls per function: 2 (include or exclude)                    │
│   • Base case: index == len(array)                                          │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   STEP 2: DRAW THE ROOT NODE                                                │
│   ──────────────────────────                                                │
│                                                                             │
│   Start with the initial function call at the top.                          │
│                                                                             │
│                     subsets(idx=0, current=[])                              │
│                                                                             │
│   Include:                                                                  │
│   • Function name                                                           │
│   • Initial parameter values                                                │
│   • Initial state (if tracking accumulator like path, sum, etc.)            │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   STEP 3: DRAW BRANCHES FOR EACH RECURSIVE CALL                             │
│   ─────────────────────────────────────────────                             │
│                                                                             │
│   For each recursive call, draw a child node.                               │
│   Label the edges with what "choice" was made.                              │
│                                                                             │
│                     subsets(idx=0, current=[])                              │
│                           /              \                                  │
│                    include 1          exclude 1                             │
│                         /                  \                                │
│              subsets(1, [1])          subsets(1, [])                        │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   STEP 4: CONTINUE UNTIL YOU HIT BASE CASES                                 │
│   ─────────────────────────────────────────                                 │
│                                                                             │
│   Keep expanding until each branch reaches a base case (leaf node).         │
│   Mark base cases clearly - these are your leaves!                          │
│                                                                             │
│                     subsets(idx=0, current=[])                              │
│                           /              \                                  │
│                    include 1          exclude 1                             │
│                         /                  \                                │
│              subsets(1, [1])          subsets(1, [])                        │
│                 /       \                /       \                          │
│            inc 2     exc 2           inc 2     exc 2                        │
│              /          \              /          \                         │
│     subs(2,[1,2])  subs(2,[1])  subs(2,[2])  subs(2,[])                     │
│         /   \        /    \        /   \        /    \                      │
│       i3    e3     i3     e3     i3    e3     i3     e3                     │
│       /      \     /       \     /      \     /       \                     │
│   [1,2,3] [1,2] [1,3]   [1]   [2,3]  [2]   [3]     []                       │
│   (base)  (base)(base) (base) (base)(base)(base) (base)                     │
│                                                                             │
│   All 8 subsets found at the leaves!                                        │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   STEP 5: ANNOTATE RETURN VALUES (For Understanding)                        │
│   ──────────────────────────────────────────────────                        │
│                                                                             │
│   Optionally, trace back up showing what each node returns.                 │
│   This helps visualize how answers "bubble up" in recursion.                │
│                                                                             │
│                      factorial(4)                                           │
│                          │                                                  │
│                          │ = 4 * factorial(3)                               │
│                          │       │                                          │
│                          │       │ = 3 * factorial(2)                       │
│                          │       │       │                                  │
│                          │       │       │ = 2 * factorial(1)               │
│                          │       │       │       │                          │
│                          │       │       │       │ = 1 * factorial(0)       │
│                          │       │       │       │       │                  │
│                          │       │       │       │       └──→ returns 1     │
│                          │       │       │       │                          │
│                          │       │       │       └──→ returns 1 * 1 = 1     │
│                          │       │       │                                  │
│                          │       │       └──→ returns 2 * 1 = 2             │
│                          │       │                                          │
│                          │       └──→ returns 3 * 2 = 6                     │
│                          │                                                  │
│                          └──→ returns 4 * 6 = 24   FINAL ANSWER!            │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

### Quick Reference: Tree Drawing Symbols

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   SYMBOLS TO USE IN YOUR TREES                                              │
│   ═══════════════════════════                                               │
│                                                                             │
│   Branching:                                                                │
│   │     Vertical line (going down)                                          │
│   ├──   Branch to child (with siblings below)                               │
│   └──   Branch to child (last sibling)                                      │
│   /  \  Binary split                                                        │
│   ┌──┼──┐  Multiple branches from one point                                 │
│                                                                             │
│   Node States:                                                              │
│   ( )    Normal node - function call                                        │
│   [*]    Solution found / Valid leaf                                        │
│   [X]    Pruned / Invalid / Dead end                                        │
│   [?]    Node being explored                                                │
│   [B]    Base case                                                          │
│                                                                             │
│   Arrows:                                                                   │
│   ──→    Direction of recursive call                                        │
│   --→    Backtrack / return (dashed)                                        │
│   ═══    Emphasize path to solution                                         │
│                                                                             │
│   Annotations:                                                              │
│   "returns X" to show what bubbles up                                       │
│   "choice: ..." to label what decision was made                             │
│   "state: ..." to show accumulated state                                    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

### Complete Example: Subsets with Tree

Here is a full worked example showing all the concepts together:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   PROBLEM: Generate all subsets of [1, 2]                                   │
│   ═══════════════════════════════════════                                   │
│                                                                             │
│   Code Pattern:                                                             │
│   def subsets(nums, index, current, result):                                │
│       if index == len(nums):    # BASE CASE                                 │
│           result.append(current[:])                                         │
│           return                                                            │
│       # Choice 1: Include nums[index]                                       │
│       current.append(nums[index])                                           │
│       subsets(nums, index + 1, current, result)                             │
│       current.pop()  # BACKTRACK                                            │
│       # Choice 2: Exclude nums[index]                                       │
│       subsets(nums, index + 1, current, result)                             │
│                                                                             │
│   RECURSION TREE:                                                           │
│                                                                             │
│                       subsets(idx=0, curr=[])                               │
│                              /          \                                   │
│                       INCLUDE 1       EXCLUDE 1                             │
│                           /                \                                │
│              subsets(1, [1])            subsets(1, [])                      │
│                 /       \                  /       \                        │
│           INC 2       EXC 2           INC 2       EXC 2                     │
│             /           \               /           \                       │
│      subs(2,[1,2])  subs(2,[1])   subs(2,[2])   subs(2,[])                  │
│           │             │             │             │                       │
│       BASE CASE     BASE CASE     BASE CASE     BASE CASE                   │
│       add [1,2]     add [1]       add [2]       add []                      │
│                                                                             │
│   RESULT: [[], [1], [2], [1,2]]                                             │
│                                                                             │
│   Tree Statistics:                                                          │
│   • Height: 3 levels (0, 1, 2)                                              │
│   • Leaves: 4 (= 2^2 subsets)                                               │
│   • Total nodes: 7                                                          │
│   • Pattern: Binary tree                                                    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

### When to Draw a Recursion Tree

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   DRAW A TREE WHEN YOU:                                                     │
│   ══════════════════════                                                    │
│                                                                             │
│   [YES] Are confused about how recursion unfolds                            │
│   [YES] Want to verify your base case is correct                            │
│   [YES] Need to understand time/space complexity                            │
│   [YES] Are debugging why your solution gives wrong answers                 │
│   [YES] Want to see where duplicate work happens (for memoization)          │
│   [YES] Are learning a new recursion pattern                                │
│                                                                             │
│   [SKIP] When the pattern is simple and linear                              │
│   [SKIP] After you've mastered the pattern                                  │
│   [SKIP] When you just need a quick mental trace                            │
│                                                                             │
│   PRO TIP: Start with a SMALL input! Drawing fib(10) is tedious.            │
│            Draw fib(4) or fib(5) to understand the pattern.                 │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Final Summary

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   ╔═══════════════════════════════════════════════════════════════════════╗ │
│   ║                     THE RECURSION MINDSET                             ║ │
│   ╠═══════════════════════════════════════════════════════════════════════╣ │
│   ║                                                                       ║ │
│   ║   1. Find the base case (the exit door)                              ║ │
│   ║                                                                       ║ │
│   ║   2. Shrink the problem (move toward the exit)                       ║ │
│   ║                                                                       ║ │
│   ║   3. Trust the recursive call (leap of faith)                        ║ │
│   ║                                                                       ║ │
│   ║   4. Combine current + recursive result                              ║ │
│   ║                                                                       ║ │
│   ║   5. Draw the tree if confused!                                      ║ │
│   ║                                                                       ║ │
│   ╚═══════════════════════════════════════════════════════════════════════╝ │
│                                                                             │
│   "To understand recursion, you must first understand recursion."           │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

**Go back to:** [overview.md](overview.md) | **Start with:** [_01_factorial.md](_01_factorial.md)
