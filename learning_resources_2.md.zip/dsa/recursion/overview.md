# Recursion: A Beginner's Guide

## What is Recursion? (The Simple Explanation)

Imagine you're standing in a line of people, and you want to know how many people are in front of you.

**Without Recursion (Iterative):** You count each person one by one: 1, 2, 3, 4...

**With Recursion:** You ask the person in front of you: "Hey, how many people are in front of YOU?" Then you just add 1 to their answer!

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   YOU → Person → Person → Person → Person → [END]          │
│    │       │        │        │        │                     │
│    │       │        │        │        └─→ "0 people ahead"  │
│    │       │        │        └──────────→ "1 person ahead"  │
│    │       │        └───────────────────→ "2 people ahead"  │
│    │       └────────────────────────────→ "3 people ahead"  │
│    └────────────────────────────────────→ "4 people ahead"  │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

**That's recursion!** A function that calls itself to solve a smaller version of the same problem.

---

## The Two Golden Rules of Recursion

Every recursive solution MUST have these two things:

### Rule 1: Base Case (The Exit Door)
This is when you STOP calling yourself. Without this, you'll be stuck forever!

```
┌────────────────────────────────────────┐
│          BASE CASE = EXIT DOOR         │
│                                        │
│   "If the problem is small enough,     │
│    just answer it directly!"           │
│                                        │
│   Example: factorial(0) = 1            │
│            (We just know this!)        │
└────────────────────────────────────────┘
```

### Rule 2: Recursive Case (The Shrinking Step)
This is where you call yourself BUT with a SMALLER problem.

```
┌────────────────────────────────────────┐
│     RECURSIVE CASE = SHRINKING STEP    │
│                                        │
│   "Break the big problem into a        │
│    smaller version of itself"          │
│                                        │
│   Example: factorial(5) = 5 × factorial(4)  │
│            (Smaller problem!)          │
└────────────────────────────────────────┘
```

---

## How to Visualize Recursion: The Stack of Plates

Think of recursion like stacking plates:

```
    ┌─────────────────────────────────────────────────────────────┐
    │                   THE CALL STACK                            │
    │                                                             │
    │   GOING DOWN (calling)          GOING UP (returning)        │
    │                                                             │
    │   ┌─────────────┐               ┌─────────────┐            │
    │   │ factorial(5)│ ────────────→ │  5 × 24 = 120 │◄─────┐    │
    │   └─────────────┘               └─────────────┘      │    │
    │         │ calls                        ▲             │    │
    │         ▼                              │ returns     │    │
    │   ┌─────────────┐               ┌─────────────┐      │    │
    │   │ factorial(4)│ ────────────→ │  4 × 6 = 24  │─────┘    │
    │   └─────────────┘               └─────────────┘            │
    │         │ calls                        ▲                   │
    │         ▼                              │ returns           │
    │   ┌─────────────┐               ┌─────────────┐            │
    │   │ factorial(3)│ ────────────→ │  3 × 2 = 6   │───────┘   │
    │   └─────────────┘               └─────────────┘            │
    │         │ calls                        ▲                   │
    │         ▼                              │ returns           │
    │   ┌─────────────┐               ┌─────────────┐            │
    │   │ factorial(2)│ ────────────→ │  2 × 1 = 2   │───────┘   │
    │   └─────────────┘               └─────────────┘            │
    │         │ calls                        ▲                   │
    │         ▼                              │ returns           │
    │   ┌─────────────┐               ┌─────────────┐            │
    │   │ factorial(1)│ ────────────→ │  1 × 1 = 1   │───────┘   │
    │   └─────────────┘               └─────────────┘            │
    │         │ calls                        ▲                   │
    │         ▼                              │ returns           │
    │   ┌─────────────┐               ┌─────────────┐            │
    │   │ factorial(0)│ ────────────→ │      1       │───────┘   │
    │   └─────────────┘  BASE CASE!   └─────────────┘            │
    │                                                             │
    └─────────────────────────────────────────────────────────────┘
```

---

## The 4-Step Recipe to Solve ANY Recursion Problem

When you see a problem and think "Can I use recursion?", follow these steps:

### Step 1: Trust the Magic (Leap of Faith)

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Pretend you already have a magical function that          │
│   solves a SMALLER version of your problem.                 │
│                                                             │
│   "If my friend can solve it for n-1, can I use their       │
│    answer to solve it for n?"                               │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Step 2: Find the Base Case

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   What's the SMALLEST or SIMPLEST version of this problem?  │
│                                                             │
│   Examples:                                                 │
│   • Empty list → return 0 or []                             │
│   • Number is 0 or 1 → return specific value                │
│   • String is empty → return ""                             │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Step 3: Write the Recursive Case

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   How do I combine:                                         │
│   • The CURRENT element/piece                               │
│   • The answer from the SMALLER problem                     │
│                                                             │
│   Example: sum([1,2,3,4]) = 1 + sum([2,3,4])               │
│                             ↑         ↑                     │
│                          current   smaller problem          │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Step 4: Make Sure You're Shrinking!

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   ⚠️ WARNING: Each recursive call MUST get closer to        │
│      the base case!                                         │
│                                                             │
│   Good: f(n) → f(n-1) → f(n-2) → ... → f(0) ✓              │
│   Bad:  f(n) → f(n) → f(n) → ... → INFINITE LOOP ✗         │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Common Recursion Patterns

### Pattern 1: Linear Recursion (One Call)

```
┌─────────────────────────────────────────┐
│                                         │
│   f(n) ──→ f(n-1) ──→ f(n-2) ──→ ...   │
│                                         │
│   Examples: Factorial, Sum of Array     │
│                                         │
└─────────────────────────────────────────┘
```

### Pattern 2: Binary Recursion (Two Calls) - Makes a TREE!

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│                        f(4)                                 │
│                       /    \                                │
│                    f(3)    f(2)                             │
│                   /   \    /   \                            │
│                f(2)  f(1) f(1) f(0)                         │
│               /   \                                         │
│            f(1)  f(0)                                       │
│                                                             │
│   Examples: Fibonacci, Binary Search, Merge Sort            │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Real-World Analogy: Russian Nesting Dolls

```
    ┌──────────────────────────────────────────────────────────┐
    │                                                          │
    │    OPENING THE DOLLS (Recursion Going Down)              │
    │                                                          │
    │    ╔═══════════════════╗                                 │
    │    ║ ╔═══════════════╗ ║                                 │
    │    ║ ║ ╔═══════════╗ ║ ║                                 │
    │    ║ ║ ║ ╔═══════╗ ║ ║ ║                                 │
    │    ║ ║ ║ ║ ╔═══╗ ║ ║ ║ ║                                 │
    │    ║ ║ ║ ║ ║ ● ║ ║ ║ ║ ║  ← Smallest doll (BASE CASE)   │
    │    ║ ║ ║ ║ ╚═══╝ ║ ║ ║ ║                                 │
    │    ║ ║ ║ ╚═══════╝ ║ ║ ║                                 │
    │    ║ ║ ╚═══════════╝ ║ ║                                 │
    │    ║ ╚═══════════════╝ ║                                 │
    │    ╚═══════════════════╝                                 │
    │                                                          │
    │    To count all dolls:                                   │
    │    count(doll) = 1 + count(doll inside)                  │
    │    count(smallest) = 1  ← BASE CASE                      │
    │                                                          │
    └──────────────────────────────────────────────────────────┘
```

---

## Quick Reference: Template Code

```python
def solve_recursively(problem):
    # STEP 1: Base Case - When to stop?
    if problem_is_small_enough:
        return simple_answer
    
    # STEP 2: Recursive Case - Shrink and combine
    smaller_problem = make_problem_smaller(problem)
    answer_from_smaller = solve_recursively(smaller_problem)
    
    # STEP 3: Combine current piece with recursive answer
    return combine(current_piece, answer_from_smaller)
```

---

## What's Next?

Now that you understand the basics, check out these example problems:

1. **[_01_factorial.md](_01_factorial.md)** - The classic first recursion problem
2. **[_02_fibonacci.md](_02_fibonacci.md)** - Learn about recursion trees
3. **[_03_sum_of_array.md](_03_sum_of_array.md)** - Recursion with arrays
4. **[_04_problem_solving_template.md](_04_problem_solving_template.md)** - Master the approach

---

## Remember These Tips!

```
┌─────────────────────────────────────────────────────────────┐
│                      RECURSION CHECKLIST                    │
│                                                             │
│   □ Do I have a BASE CASE? (Exit door)                     │
│   □ Am I SHRINKING the problem each time?                  │
│   □ Am I combining the current piece with recursive answer? │
│   □ Does my base case actually get reached?                │
│   □ Am I trusting the "magic" for smaller problems?        │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

**Happy Recursing!** 🎯
