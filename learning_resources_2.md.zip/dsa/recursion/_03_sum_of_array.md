# Sum of Array: Recursion with Lists

## The Problem

Given an array of numbers, find the sum of all elements.

```
Example: [3, 1, 4, 1, 5]  →  Sum = 14
```

---

## The Key Insight

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   How do you eat an elephant? ONE BITE AT A TIME!                           │
│                                                                             │
│   Array: [3, 1, 4, 1, 5]                                                    │
│                                                                             │
│   Sum of whole array = First element + Sum of the rest                      │
│                      = 3 + sum([1, 4, 1, 5])                                │
│                      = 3 + (1 + sum([4, 1, 5]))                             │
│                      = 3 + (1 + (4 + sum([1, 5])))                          │
│                      = 3 + (1 + (4 + (1 + sum([5]))))                       │
│                      = 3 + (1 + (4 + (1 + (5 + sum([])))))                  │
│                      = 3 + (1 + (4 + (1 + (5 + 0))))                        │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Visual Representation

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   Original Array:                                                           │
│   ┌───┬───┬───┬───┬───┐                                                    │
│   │ 3 │ 1 │ 4 │ 1 │ 5 │                                                    │
│   └───┴───┴───┴───┴───┘                                                    │
│     ↓                                                                       │
│   SPLIT INTO:                                                               │
│     ↓                                                                       │
│   ┌───┐   ┌───┬───┬───┬───┐                                                │
│   │ 3 │ + │ 1 │ 4 │ 1 │ 5 │                                                │
│   └───┘   └───┴───┴───┴───┘                                                │
│   FIRST      REST (smaller problem!)                                        │
│                                                                             │
│   sum([3,1,4,1,5]) = 3 + sum([1,4,1,5])                                    │
│                         ↓                                                   │
│                      1 + sum([4,1,5])                                       │
│                             ↓                                               │
│                          4 + sum([1,5])                                     │
│                                 ↓                                           │
│                              1 + sum([5])                                   │
│                                    ↓                                        │
│                                 5 + sum([])                                 │
│                                       ↓                                     │
│                                       0  ← BASE CASE!                       │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Building the Solution

### Step 1: Define the Base Case

What's the smallest array we can have?

```
┌─────────────────────────────────────────┐
│                                         │
│   EMPTY ARRAY: []                       │
│                                         │
│   Sum of nothing = 0                    │
│                                         │
│   if array is empty:                    │
│       return 0                          │
│                                         │
└─────────────────────────────────────────┘
```

### Step 2: Define the Recursive Case

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   For a non-empty array:                                                    │
│                                                                             │
│   sum(array) = array[0] + sum(array[1:])                                   │
│                   ↑              ↑                                          │
│              first element   rest of array                                  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## The Code

```python
def array_sum(arr):
    # Base Case: empty array
    if len(arr) == 0:
        return 0
    
    # Recursive Case: first + sum of rest
    first = arr[0]
    rest = arr[1:]  # Everything except first element
    
    return first + array_sum(rest)
```

**Shorter version:**
```python
def array_sum(arr):
    if len(arr) == 0:
        return 0
    return arr[0] + array_sum(arr[1:])
```

---

## Recursion Tree for sum([3, 1, 4, 1, 5])

### Complete Recursion Tree with State Tracking

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                     RECURSION TREE FOR array_sum([3,1,4,1,5])               │
│                                                                             │
│   Each node shows:  [current array] --> processing --> returns value       │
│                                                                             │
│   ══════════════════════════════════════════════════════════════════════    │
│                                                                             │
│                        array_sum([3,1,4,1,5])                               │
│                        ┌──────────────────┐                                 │
│                        │ arr = [3,1,4,1,5]│                                 │
│                        │ first = 3        │                                 │
│                        │ rest = [1,4,1,5] │                                 │
│                        └────────┬─────────┘                                 │
│                                 │                                           │
│                                 │ calls array_sum([1,4,1,5])                │
│                                 ▼                                           │
│                        array_sum([1,4,1,5])                                 │
│                        ┌──────────────────┐                                 │
│                        │ arr = [1,4,1,5]  │                                 │
│                        │ first = 1        │                                 │
│                        │ rest = [4,1,5]   │                                 │
│                        └────────┬─────────┘                                 │
│                                 │                                           │
│                                 │ calls array_sum([4,1,5])                  │
│                                 ▼                                           │
│                        array_sum([4,1,5])                                   │
│                        ┌──────────────────┐                                 │
│                        │ arr = [4,1,5]    │                                 │
│                        │ first = 4        │                                 │
│                        │ rest = [1,5]     │                                 │
│                        └────────┬─────────┘                                 │
│                                 │                                           │
│                                 │ calls array_sum([1,5])                    │
│                                 ▼                                           │
│                        array_sum([1,5])                                     │
│                        ┌──────────────────┐                                 │
│                        │ arr = [1,5]      │                                 │
│                        │ first = 1        │                                 │
│                        │ rest = [5]       │                                 │
│                        └────────┬─────────┘                                 │
│                                 │                                           │
│                                 │ calls array_sum([5])                      │
│                                 ▼                                           │
│                        array_sum([5])                                       │
│                        ┌──────────────────┐                                 │
│                        │ arr = [5]        │                                 │
│                        │ first = 5        │                                 │
│                        │ rest = []        │                                 │
│                        └────────┬─────────┘                                 │
│                                 │                                           │
│                                 │ calls array_sum([])                       │
│                                 ▼                                           │
│                        array_sum([])                                        │
│                        ┌──────────────────┐                                 │
│                        │ arr = []         │                                 │
│                        │ len(arr) == 0    │                                 │
│                        │ BASE CASE!       │                                 │
│                        └──────────────────┘                                 │
│                                 │                                           │
│                                 └──────► returns 0                          │
│                                                                             │
│   Shape: Linear recursion (like factorial)                                  │
│   Depth: n (length of array)                                                │
│   Total calls: n + 1                                                        │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

### Unwinding Phase: Values Propagating Back Up

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│            HOW VALUES PROPAGATE BACK UP THE RECURSION TREE                  │
│                                                                             │
│   ══════════════════════════════════════════════════════════════════════    │
│                                                                             │
│   STEP 6: BASE CASE HIT                                                     │
│   ─────────────────────                                                     │
│                        array_sum([])                                        │
│                               │                                             │
│                               └──────► returns 0                            │
│                                                                             │
│   ─────────────────────────────────────────────────────────────────────     │
│                                                                             │
│   STEP 5: UNWIND - First return                                             │
│   ─────────────────────────────                                             │
│                        array_sum([5])                                       │
│                        ┌────────────────────────────────┐                   │
│                        │ first = 5                      │                   │
│                        │ result from child = 0          │                   │
│                        │ return 5 + 0 = 5               │                   │
│                        └────────────────────────────────┘                   │
│                               │                                             │
│                               └──────► returns 5                            │
│                                                                             │
│   ─────────────────────────────────────────────────────────────────────     │
│                                                                             │
│   STEP 4: UNWIND - Second return                                            │
│   ──────────────────────────────                                            │
│                        array_sum([1,5])                                     │
│                        ┌────────────────────────────────┐                   │
│                        │ first = 1                      │                   │
│                        │ result from child = 5          │                   │
│                        │ return 1 + 5 = 6               │                   │
│                        └────────────────────────────────┘                   │
│                               │                                             │
│                               └──────► returns 6                            │
│                                                                             │
│   ─────────────────────────────────────────────────────────────────────     │
│                                                                             │
│   STEP 3: UNWIND - Third return                                             │
│   ─────────────────────────────                                             │
│                        array_sum([4,1,5])                                   │
│                        ┌────────────────────────────────┐                   │
│                        │ first = 4                      │                   │
│                        │ result from child = 6          │                   │
│                        │ return 4 + 6 = 10              │                   │
│                        └────────────────────────────────┘                   │
│                               │                                             │
│                               └──────► returns 10                           │
│                                                                             │
│   ─────────────────────────────────────────────────────────────────────     │
│                                                                             │
│   STEP 2: UNWIND - Fourth return                                            │
│   ──────────────────────────────                                            │
│                        array_sum([1,4,1,5])                                 │
│                        ┌────────────────────────────────┐                   │
│                        │ first = 1                      │                   │
│                        │ result from child = 10         │                   │
│                        │ return 1 + 10 = 11             │                   │
│                        └────────────────────────────────┘                   │
│                               │                                             │
│                               └──────► returns 11                           │
│                                                                             │
│   ─────────────────────────────────────────────────────────────────────     │
│                                                                             │
│   STEP 1: UNWIND - Final return (ANSWER!)                                   │
│   ───────────────────────────────────────                                   │
│                        array_sum([3,1,4,1,5])                               │
│                        ┌────────────────────────────────┐                   │
│                        │ first = 3                      │                   │
│                        │ result from child = 11         │                   │
│                        │ return 3 + 11 = 14             │                   │
│                        └────────────────────────────────┘                   │
│                               │                                             │
│                               └──────► returns 14  <-- FINAL ANSWER!        │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

### Visual Summary: Both Phases Combined

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│    GOING DOWN (Recursive Calls)       │     GOING UP (Returns/Unwinding)    │
│    ════════════════════════════       │     ════════════════════════════    │
│                                       │                                     │
│    sum([3,1,4,1,5])                   │     sum([3,1,4,1,5])                │
│           │                           │            ▲                        │
│           │ extract first=3           │            │ 3 + 11 = 14 ANSWER!   │
│           ▼                           │            │                        │
│    sum([1,4,1,5])                     │     sum([1,4,1,5])                  │
│           │                           │            ▲                        │
│           │ extract first=1           │            │ 1 + 10 = 11           │
│           ▼                           │            │                        │
│    sum([4,1,5])                       │     sum([4,1,5])                    │
│           │                           │            ▲                        │
│           │ extract first=4           │            │ 4 + 6 = 10            │
│           ▼                           │            │                        │
│    sum([1,5])                         │     sum([1,5])                      │
│           │                           │            ▲                        │
│           │ extract first=1           │            │ 1 + 5 = 6             │
│           ▼                           │            │                        │
│    sum([5])                           │     sum([5])                        │
│           │                           │            ▲                        │
│           │ extract first=5           │            │ 5 + 0 = 5             │
│           ▼                           │            │                        │
│    sum([])                            │     sum([])                         │
│           │                           │            │                        │
│           └───► BASE CASE! ───────────┼────────────┘ returns 0             │
│                                       │                                     │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Call Stack Visualization

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   BUILDING THE STACK (Going Down)         UNWINDING (Going Up)              │
│   ═══════════════════════════════         ════════════════════              │
│                                                                             │
│   ┌─────────────────────────────┐         ┌─────────────────────────────┐   │
│   │ sum([3,1,4,1,5])            │         │ sum([3,1,4,1,5])            │   │
│   │ waiting for result...       │         │ = 3 + 11 = 14   ← ANSWER!  │   │
│   ├─────────────────────────────┤         ├─────────────────────────────┤   │
│   │ sum([1,4,1,5])              │         │ sum([1,4,1,5])              │   │
│   │ waiting for result...       │         │ = 1 + 10 = 11               │   │
│   ├─────────────────────────────┤         ├─────────────────────────────┤   │
│   │ sum([4,1,5])                │         │ sum([4,1,5])                │   │
│   │ waiting for result...       │         │ = 4 + 6 = 10                │   │
│   ├─────────────────────────────┤         ├─────────────────────────────┤   │
│   │ sum([1,5])                  │         │ sum([1,5])                  │   │
│   │ waiting for result...       │         │ = 1 + 5 = 6                 │   │
│   ├─────────────────────────────┤         ├─────────────────────────────┤   │
│   │ sum([5])                    │         │ sum([5])                    │   │
│   │ waiting for result...       │         │ = 5 + 0 = 5                 │   │
│   ├─────────────────────────────┤         ├─────────────────────────────┤   │
│   │ sum([])                     │         │ sum([])                     │   │
│   │ BASE CASE! Return 0         │    ──→  │ = 0                         │   │
│   └─────────────────────────────┘         └─────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Step-by-Step Execution Trace

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   Call #   Function Call              Returns      Notes                    │
│   ══════   ═══════════════            ═══════      ═════                    │
│                                                                             │
│   1        sum([3,1,4,1,5])           ?            Calls sum([1,4,1,5])     │
│   2        sum([1,4,1,5])             ?            Calls sum([4,1,5])       │
│   3        sum([4,1,5])               ?            Calls sum([1,5])         │
│   4        sum([1,5])                 ?            Calls sum([5])           │
│   5        sum([5])                   ?            Calls sum([])            │
│   6        sum([])                    0            BASE CASE!               │
│                                                                             │
│   --- Now we unwind ---                                                     │
│                                                                             │
│   5        sum([5])                   5+0=5        Returns 5                │
│   4        sum([1,5])                 1+5=6        Returns 6                │
│   3        sum([4,1,5])               4+6=10       Returns 10               │
│   2        sum([1,4,1,5])             1+10=11      Returns 11               │
│   1        sum([3,1,4,1,5])           3+11=14      Returns 14 ← FINAL!      │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Alternative: Using Indices Instead of Slicing

Sometimes it's more efficient to use an index instead of creating new arrays:

```python
def array_sum(arr, index=0):
    # Base Case: index reached the end
    if index == len(arr):
        return 0
    
    # Recursive Case
    return arr[index] + array_sum(arr, index + 1)
```

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   Visualization with indices:                                               │
│                                                                             │
│   Array: [3, 1, 4, 1, 5]                                                    │
│   Index:  0  1  2  3  4                                                     │
│                                                                             │
│   sum(arr, 0) = arr[0] + sum(arr, 1)                                       │
│               = 3 + sum(arr, 1)                                             │
│               = 3 + (arr[1] + sum(arr, 2))                                  │
│               = 3 + (1 + sum(arr, 2))                                       │
│               = 3 + (1 + (arr[2] + sum(arr, 3)))                            │
│               = 3 + (1 + (4 + sum(arr, 3)))                                 │
│               ... and so on                                                 │
│                                                                             │
│   sum(arr, 5) = 0  ← BASE CASE (index 5 is past the end)                   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

### Recursion Tree for Index-Based Approach: sum([2, 7, 3], 0)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│               RECURSION TREE FOR array_sum([2,7,3], index=0)                │
│                                                                             │
│   Array (constant): [2, 7, 3]    Length: 3                                  │
│   Each node shows: (current index, array element at index)                  │
│                                                                             │
│   ══════════════════════════════════════════════════════════════════════    │
│                                                                             │
│                        array_sum(arr, index=0)                              │
│                        ┌──────────────────────────────┐                     │
│                        │ index = 0                    │                     │
│                        │ arr[0] = 2                   │                     │
│                        │ index < len(arr)? 0 < 3? YES │                     │
│                        │ Compute: 2 + sum(arr, 1)     │                     │
│                        └──────────────┬───────────────┘                     │
│                                       │                                     │
│                                       │ calls sum(arr, 1)                   │
│                                       ▼                                     │
│                        array_sum(arr, index=1)                              │
│                        ┌──────────────────────────────┐                     │
│                        │ index = 1                    │                     │
│                        │ arr[1] = 7                   │                     │
│                        │ index < len(arr)? 1 < 3? YES │                     │
│                        │ Compute: 7 + sum(arr, 2)     │                     │
│                        └──────────────┬───────────────┘                     │
│                                       │                                     │
│                                       │ calls sum(arr, 2)                   │
│                                       ▼                                     │
│                        array_sum(arr, index=2)                              │
│                        ┌──────────────────────────────┐                     │
│                        │ index = 2                    │                     │
│                        │ arr[2] = 3                   │                     │
│                        │ index < len(arr)? 2 < 3? YES │                     │
│                        │ Compute: 3 + sum(arr, 3)     │                     │
│                        └──────────────┬───────────────┘                     │
│                                       │                                     │
│                                       │ calls sum(arr, 3)                   │
│                                       ▼                                     │
│                        array_sum(arr, index=3)                              │
│                        ┌──────────────────────────────┐                     │
│                        │ index = 3                    │                     │
│                        │ index == len(arr)? 3 == 3?   │                     │
│                        │ YES --> BASE CASE!           │                     │
│                        │ return 0                     │                     │
│                        └──────────────────────────────┘                     │
│                                       │                                     │
│                                       └───────► returns 0                   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

### Unwinding Phase for Index-Based Approach

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│          UNWINDING: VALUES FLOW BACK UP WITH RUNNING SUM                    │
│                                                                             │
│   Array: [2, 7, 3]                                                          │
│                                                                             │
│   ══════════════════════════════════════════════════════════════════════    │
│                                                                             │
│   STEP 4: BASE CASE                                                         │
│   ─────────────────                                                         │
│            ┌─────────────────────────────────┐                              │
│            │ sum(arr, 3)                     │                              │
│            │ index=3 reached end of array    │                              │
│            │ returns 0                       │──────────► 0                 │
│            └─────────────────────────────────┘                              │
│                              ▲                                              │
│                              │ passes 0 back up                             │
│   ─────────────────────────────────────────────────────────────────────     │
│                                                                             │
│   STEP 3: FIRST UNWIND                                                      │
│   ────────────────────                                                      │
│            ┌─────────────────────────────────┐                              │
│            │ sum(arr, 2)                     │                              │
│            │ arr[2] = 3                      │                              │
│            │ child returned = 0              │                              │
│            │ computes: 3 + 0 = 3             │──────────► 3                 │
│            └─────────────────────────────────┘                              │
│                              ▲                                              │
│                              │ passes 3 back up                             │
│   ─────────────────────────────────────────────────────────────────────     │
│                                                                             │
│   STEP 2: SECOND UNWIND                                                     │
│   ─────────────────────                                                     │
│            ┌─────────────────────────────────┐                              │
│            │ sum(arr, 1)                     │                              │
│            │ arr[1] = 7                      │                              │
│            │ child returned = 3              │                              │
│            │ computes: 7 + 3 = 10            │──────────► 10                │
│            └─────────────────────────────────┘                              │
│                              ▲                                              │
│                              │ passes 10 back up                            │
│   ─────────────────────────────────────────────────────────────────────     │
│                                                                             │
│   STEP 1: FINAL UNWIND (ANSWER!)                                            │
│   ──────────────────────────────                                            │
│            ┌─────────────────────────────────┐                              │
│            │ sum(arr, 0)                     │                              │
│            │ arr[0] = 2                      │                              │
│            │ child returned = 10             │                              │
│            │ computes: 2 + 10 = 12           │──────────► 12  FINAL ANSWER! │
│            └─────────────────────────────────┘                              │
│                                                                             │
│   ═══════════════════════════════════════════════════════════════════════   │
│   VERIFICATION: 2 + 7 + 3 = 12  (Correct!)                                  │
│   ═══════════════════════════════════════════════════════════════════════   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

### Side-by-Side Comparison: Both Approaches

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   SLICING APPROACH                     INDEX APPROACH                       │
│   ════════════════                     ══════════════                       │
│                                                                             │
│   sum([2,7,3])                         sum(arr, 0)                          │
│       │                                    │                                │
│       │ first=2, rest=[7,3]                │ arr[0]=2, next index=1         │
│       ▼                                    ▼                                │
│   sum([7,3])                           sum(arr, 1)                          │
│       │                                    │                                │
│       │ first=7, rest=[3]                  │ arr[1]=7, next index=2         │
│       ▼                                    ▼                                │
│   sum([3])                             sum(arr, 2)                          │
│       │                                    │                                │
│       │ first=3, rest=[]                   │ arr[2]=3, next index=3         │
│       ▼                                    ▼                                │
│   sum([])                              sum(arr, 3)                          │
│       │                                    │                                │
│       └──► 0 (empty)                       └──► 0 (index == len)            │
│                                                                             │
│   ─────────────────────────────────────────────────────────────────────     │
│   TRADE-OFFS:                                                               │
│   ─────────────────────────────────────────────────────────────────────     │
│                                                                             │
│   Slicing:                             Index:                               │
│   + More intuitive                     + More memory efficient              │
│   + Cleaner code                       + No new arrays created              │
│   - Creates new array each call        + O(1) space per call                │
│   - O(n) space per call                - Slightly more complex              │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## More Array Recursion Examples

### Example 1: Find Maximum

```python
def find_max(arr):
    # Base Case: single element
    if len(arr) == 1:
        return arr[0]
    
    # Recursive Case
    max_of_rest = find_max(arr[1:])
    return arr[0] if arr[0] > max_of_rest else max_of_rest
```

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   find_max([3, 7, 2, 9, 1])                                                │
│                                                                             │
│   = max(3, find_max([7, 2, 9, 1]))                                         │
│   = max(3, max(7, find_max([2, 9, 1])))                                    │
│   = max(3, max(7, max(2, find_max([9, 1]))))                               │
│   = max(3, max(7, max(2, max(9, find_max([1])))))                          │
│   = max(3, max(7, max(2, max(9, 1))))    ← BASE CASE                       │
│   = max(3, max(7, max(2, 9)))                                              │
│   = max(3, max(7, 9))                                                       │
│   = max(3, 9)                                                               │
│   = 9                                                                       │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Example 2: Count Elements

```python
def count(arr):
    # Base Case: empty array
    if len(arr) == 0:
        return 0
    
    # Recursive Case: 1 + count of rest
    return 1 + count(arr[1:])
```

### Example 3: Check if Element Exists

```python
def contains(arr, target):
    # Base Case: empty array
    if len(arr) == 0:
        return False
    
    # Found it!
    if arr[0] == target:
        return True
    
    # Recursive Case: search the rest
    return contains(arr[1:], target)
```

---

## The Pattern for Array Recursion

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   def do_something_with_array(arr):                                         │
│                                                                             │
│       # BASE CASE: Empty array                                              │
│       if len(arr) == 0:                                                     │
│           return base_value  # (0 for sum, [] for collect, etc.)            │
│                                                                             │
│       # RECURSIVE CASE:                                                     │
│       first = arr[0]                    # Take the first element            │
│       rest_result = do_something_with_array(arr[1:])  # Recurse on rest     │
│                                                                             │
│       return combine(first, rest_result)  # Combine them somehow            │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Practice Exercise

Trace through `array_sum([2, 4, 6])`:

```
array_sum([2, 4, 6])
    = 2 + array_sum([4, 6])
    = 2 + (4 + array_sum([6]))
    = 2 + (4 + (6 + array_sum([])))
    = 2 + (4 + (6 + ___))   ← Base case returns what?
    = 2 + (4 + ___)
    = 2 + ___
    = ___

Answer: 12
```

---

## Summary

| Component | Array Sum Solution |
|-----------|-------------------|
| **Base Case** | Empty array `[]` → return `0` |
| **Recursive Case** | `arr[0] + sum(arr[1:])` |
| **What shrinks?** | Array gets smaller by 1 element |
| **How to combine?** | Add first element to sum of rest |

**Next:** Check out [_04_problem_solving_template.md](_04_problem_solving_template.md) for a universal approach to ANY recursion problem!
