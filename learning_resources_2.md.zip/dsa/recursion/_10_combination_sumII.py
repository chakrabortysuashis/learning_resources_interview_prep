"""40. Combination Sum II

Given a collection of candidate numbers (candidates) and a target number (target),
find all unique combinations in candidates where the candidate numbers sum to target.

Each number in candidates may only be used once in the combination.

Note: The solution set must not contain duplicate combinations.

Example 1:
Input: candidates = [10,1,2,7,6,1,5], target = 8
Output: [[1,1,6], [1,2,5], [1,7], [2,6]]

Example 2:
Input: candidates = [2,5,2,1,2], target = 5
Output: [[1,2,2], [5]]

================================================================================
PROBLEM UNDERSTANDING
================================================================================

The Problem:
------------
- We have a collection of numbers (may contain DUPLICATES)
- Find ALL UNIQUE combinations that sum to target
- Each element can be used AT MOST ONCE (based on its index)
- The result must NOT contain duplicate combinations

Key Difference from Related Problems:
-------------------------------------

+----------------------+------------------+-------------------+------------------+
| Problem              | Element Reuse    | Input Duplicates  | Special Rules    |
+----------------------+------------------+-------------------+------------------+
| Combination Sum I    | UNLIMITED        | No duplicates     | Any k elements   |
| (LeetCode 39)        | (same element    | in input          |                  |
|                      | can repeat)      |                   |                  |
+----------------------+------------------+-------------------+------------------+
| Combination Sum II   | ONCE per index   | MAY have          | Handle duplicate |
| (LeetCode 40) - THIS | (each element    | duplicates        | combinations     |
|                      | used once)       |                   |                  |
+----------------------+------------------+-------------------+------------------+
| Combination Sum III  | ONCE             | Numbers 1-9 only  | Exactly k nums   |
| (LeetCode 216)       | (no duplicates   | (no duplicates)   | Must use k       |
|                      | in 1-9)          |                   | elements         |
+----------------------+------------------+-------------------+------------------+
| Subsets II           | ONCE per index   | MAY have          | Find all subsets |
| (LeetCode 90)        |                  | duplicates        | (same dup logic) |
+----------------------+------------------+-------------------+------------------+

================================================================================
THE KEY INSIGHT: SORT + SKIP DUPLICATES AT SAME LEVEL
================================================================================

The Challenge:
--------------
Input [1, 1, 2] with target 3 should give [[1, 2]] NOT [[1, 2], [1, 2]]

If we don't handle duplicates:
- First path: Pick 1 (index 0), then 2 (index 2) -> [1, 2] (sum = 3) VALID
- Second path: Pick 1 (index 1), then 2 (index 2) -> [1, 2] (sum = 3) DUPLICATE!

The Solution: SORT + SKIP DUPLICATES AT SAME RECURSION LEVEL
------------------------------------------------------------

Step 1: SORT the array first
   - Brings all duplicates together: [10,1,2,7,6,1,5] -> [1,1,2,5,6,7,10]
   - Enables early termination (pruning) when element > remaining

Step 2: SKIP DUPLICATES at the same recursion level
   - At each level of recursion, we try elements from index 'start' to end
   - If we see the same value twice at the SAME LEVEL, skip the second one
   - This prevents creating duplicate combinations

The Magic Line:
---------------
    if i > start and candidates[i] == candidates[i-1]:
        continue

Why "i > start" and not just always skip duplicates?
----------------------------------------------------
- When i == start: This is the FIRST element we're considering at this level
  We MUST try it, even if it equals the previous element

- When i > start: We've already tried candidates[i-1] at this same level
  If candidates[i] == candidates[i-1], trying it would create duplicates
  So we SKIP it

Visual Example with [1, 1, 2], target = 3:
------------------------------------------
Sorted: [1, 1, 2]

Level 0 (start=0):
  - i=0: Pick first 1 -> path [1], go deeper
  - i=1: i > start (1 > 0) AND candidates[1] == candidates[0] (1 == 1)
         SKIP! (Don't start another branch with 1)
  - i=2: Pick 2 -> path [2], go deeper

This way, we only have ONE branch starting with 1, avoiding duplicates.

But inside the [1] branch at Level 1 (start=1):
  - i=1: i == start, so we CAN pick the second 1 -> path [1, 1]
  - This is different! We're USING both 1s, not STARTING duplicate branches

================================================================================
                    RECURSION TREE VISUALIZATIONS
================================================================================

This section provides detailed recursion trees showing how Combination Sum II
handles duplicates differently from Combination Sum I.

================================================================================
RECURSION TREE 1: candidates = [1, 1, 2], target = 3
================================================================================

After Sorting: [1, 1, 2]
               [0] [1] [2]  <-- indices

Key notation:
  - solve(start, remaining, path) - our backtrack function
  - [V] FOUND - valid combination found
  - [X] PRUNE - element > remaining, skip rest
  - [SKIP-DUP] - skipped because duplicate at same level

                                    solve(0, 3, [])
                                    "Try each element from index 0"
                                           |
            +------------------------------+------------------------------+
            |                              |                              |
        i=0: TAKE 1                   i=1: candidates[1]=1           i=2: TAKE 2
        (first at level,              i>start (1>0) AND              (not duplicate)
         must try it)                 candidates[1]==candidates[0]        |
            |                         [SKIP-DUP] This prevents            |
            |                         duplicate [1,x] branches!           |
            v                                                             v
    solve(1, 2, [1])                                              solve(3, 1, [2])
    "Try from index 1"                                            remaining=1, index=3
           |                                                      index >= len, return
    +------+------+                                               (no valid combination)
    |             |
i=1: TAKE 1   i=2: TAKE 2
(i==start,    (not duplicate)
can take!)         |
    |              |
    v              v
solve(2,1,[1,1])  solve(3,0,[1,2])
    |              |
    |         remaining=0
    |         [V] FOUND! Add [1,2]
    |
    +------+
    |      |
i=2: TAKE 2   (no more elements)
2 > 1 (remaining)
[X] PRUNE - break!

No valid path from [1,1]

                    +--------------------------------------------------+
                    |  WHY [1,1,2] IS NOT A SOLUTION:                  |
                    |  1 + 1 + 2 = 4, which exceeds target = 3         |
                    |  So [1,1,2] path gets pruned                     |
                    +--------------------------------------------------+

FINAL RESULT: [[1, 2]]

--------------------------------------------------------------------------------
CRITICAL OBSERVATION: Without duplicate skipping, we would get:
--------------------------------------------------------------------------------

If we did NOT skip duplicates:

                                    solve(0, 3, [])
                                           |
            +------------------------------+------------------------------+
            |                              |                              |
        i=0: TAKE 1                   i=1: TAKE 1                    i=2: TAKE 2
            |                         (DUPLICATE!)                        |
            v                              v                              v
    solve(1, 2, [1])              solve(2, 2, [1])                 solve(3, 1, [2])
           |                              |
    ... leads to [1,2]             ... leads to [1,2]  <-- SAME COMBINATION!

Result would be: [[1,2], [1,2]] -- DUPLICATE OUTPUT!

The skip condition "i > start AND candidates[i] == candidates[i-1]" prevents this.

================================================================================
RECURSION TREE 2: candidates = [1, 1, 2, 2], target = 4
================================================================================

After Sorting: [1, 1, 2, 2]
               [0] [1] [2] [3]

This example shows multiple levels of duplicate skipping.

                                        solve(0, 4, [])
                                               |
        +------------------+------------------+------------------+
        |                  |                  |                  |
    i=0: TAKE 1        i=1: [SKIP-DUP]    i=2: TAKE 2        i=3: [SKIP-DUP]
    (start=0)          1>0, arr[1]==arr[0] (start=0)          3>0, arr[3]==arr[2]
        |              Skip 2nd "1"           |               Skip 2nd "2"
        |              at level 0             |
        v                                     v
solve(1, 3, [1])                      solve(3, 2, [2])
        |                                     |
+-------+-------+-------+             +-------+-------+
|       |       |       |             |               |
i=1   i=2     i=3       |          i=3: TAKE 2    (end of array)
TAKE 1 TAKE 2 [SKIP-DUP]|          2 <= 2             |
  |      |     2>1,     |              |              |
  |      |   arr[3]=    |              v              |
  |      |   arr[2]     |      solve(4, 0, [2,2])     |
  |      |              |      remaining=0            |
  v      v              |      [V] FOUND! Add [2,2]   |
solve  solve            |                             |
(2,2,  (3,1,            |                             |
[1,1]) [1,2])           |                             |
  |      |              |                             |
  |      v              |                             |
  |  i=3: TAKE 2        |                             |
  |  2 > 1 (remaining)  |                             |
  |  [X] PRUNE          |                             |
  |                     |                             |
  +-------+             |                             |
  |       |             |                             |
i=2     i=3             |                             |
TAKE 2  [SKIP-DUP]      |                             |
  |                     |                             |
  v                     |                             |
solve(3, 0, [1,1,2])    |                             |
remaining=0             |                             |
[V] FOUND! Add [1,1,2]  |                             |

FINAL RESULT: [[1, 1, 2], [2, 2]]

--------------------------------------------------------------------------------
DETAILED TRACE OF [1,1,2] PATH:
--------------------------------------------------------------------------------

solve(0, 4, [])
  --> i=0, take candidates[0]=1
      --> solve(1, 3, [1])
            --> i=1, i==start, can take candidates[1]=1
                --> solve(2, 2, [1,1])
                      --> i=2, take candidates[2]=2
                          --> solve(3, 0, [1,1,2])
                                --> remaining=0, FOUND [1,1,2]

Notice: Both 1s are used because:
  - First 1 is picked at level 0 (i=0, start=0, i==start OK)
  - Second 1 is picked at level 1 (i=1, start=1, i==start OK)

This is DIFFERENT from skipping duplicates at the same level!

================================================================================
RECURSION TREE 3: CONTRAST WITH COMBINATION SUM I
================================================================================

Same candidates = [1, 2], target = 3

--------------------------------------------------------------------------------
COMBINATION SUM I (Unlimited reuse - each element can repeat)
--------------------------------------------------------------------------------

Key difference: backtrack(i, ...) - STAY at same index after taking!

                                    solve(0, 3, [])
                                           |
                    +----------------------+----------------------+
                    |                                             |
               TAKE 1                                         SKIP 1
             (STAY at i=0)                                  (MOVE to i=1)
                    |                                             |
                    v                                             v
            solve(0, 2, [1])                              solve(1, 3, [])
                    |                                             |
        +-----------+-----------+                     +-----------+-----------+
        |                       |                     |                       |
    TAKE 1                  SKIP 1                 TAKE 2                 SKIP 2
   (STAY i=0)              (MOVE i=1)             (STAY i=1)             (MOVE i=2)
        |                       |                     |                       |
        v                       v                     v                       v
 solve(0,1,[1,1])       solve(1,2,[1])        solve(1,1,[2])           OUT OF BOUNDS
        |                       |                     |                 return []
   +----+----+             +----+----+            +---+----+
   |         |             |         |            |        |
TAKE 1    SKIP 1       TAKE 2    SKIP 2       TAKE 2   SKIP 2
1<=1      MOVE          2==2       MOVE        2>1       MOVE
   |         |             |         |        [X]PRUNE     |
   v         v             v         v                     v
solve(0,0,  solve(1,1,  solve(1,0,  OUT OF              OUT OF
[1,1,1])    [1,1])      [1,2])      BOUNDS              BOUNDS
   |           |           |
remaining=0    |      remaining=0
[V] [1,1,1]    |      [V] [1,2]
               |
          +----+----+
          |         |
       TAKE 2    SKIP 2
        2>1       MOVE
       [X]PRUNE     |
                    v
               OUT OF BOUNDS

COMBINATION SUM I RESULT: [[1,1,1], [1,2], [2]] -- Wait, let me check [2]...
Actually checking solve(1,3,[]) -> TAKE 2 -> solve(1,1,[2]) -> can't make sum, so...

Let me retrace: For target=3 with [1,2]:
- [1,1,1] = 3 (valid)
- [1,2] = 3 (valid)

COMBINATION SUM I RESULT: [[1,1,1], [1,2]]

--------------------------------------------------------------------------------
COMBINATION SUM II (Each element once - with duplicates in input)
--------------------------------------------------------------------------------

Key difference: backtrack(i+1, ...) - MOVE to next index after taking!

Let's use candidates = [1, 1, 2], target = 3 to show duplicate handling.
Sorted: [1, 1, 2]

                                    solve(0, 3, [])
                                           |
            +------------------------------+------------------------------+
            |                              |                              |
        i=0: TAKE 1                   i=1: [SKIP-DUP]                i=2: TAKE 2
       (MOVE to i+1=1)                i>start, arr[1]==arr[0]       (MOVE to i+1=3)
            |                                                             |
            v                                                             v
    solve(1, 2, [1])                                              solve(3, 1, [2])
            |                                                     OUT OF BOUNDS
     +------+------+                                              return []
     |             |
 i=1: TAKE 1   i=2: TAKE 2
(MOVE to i+1=2) (MOVE to i+1=3)
     |              |
     v              v
solve(2,1,[1,1])  solve(3,0,[1,2])
     |              |
 i=2: TAKE 2    remaining=0
 2 > 1         [V] FOUND! [1,2]
 [X] PRUNE

COMBINATION SUM II RESULT: [[1,2]]

--------------------------------------------------------------------------------
SIDE-BY-SIDE CODE COMPARISON:
--------------------------------------------------------------------------------

    +-------------------------------------------------------------------+
    |  COMBINATION SUM I                 |  COMBINATION SUM II          |
    |  (Unlimited reuse)                 |  (Each element once)         |
    +-------------------------------------------------------------------+
    |                                    |                              |
    |  # After taking element at i:      |  # After taking element at i:|
    |  backtrack(i, ...)                 |  backtrack(i + 1, ...)       |
    |            ^                       |                ^             |
    |            |                       |                |             |
    |     STAY at same index             |     MOVE to next index       |
    |     (can take again!)              |     (element used once!)     |
    |                                    |                              |
    +-------------------------------------------------------------------+
    |                                    |                              |
    |  # No duplicate handling needed    |  # Must skip duplicates:     |
    |  # (input has unique elements)     |  if i > start and            |
    |                                    |     candidates[i] ==         |
    |                                    |     candidates[i-1]:         |
    |                                    |       continue               |
    |                                    |                              |
    +-------------------------------------------------------------------+

================================================================================
RECURSION TREE 4: SHOWING PRUNING IN ACTION
================================================================================

candidates = [1, 2, 5, 6], target = 3
Sorted: [1, 2, 5, 6]

This example shows how sorting enables early termination (pruning).

                                    solve(0, 3, [])
                                           |
        +------------------+------------------+------------------+------------------+
        |                  |                  |                  |                  |
    i=0: TAKE 1        i=1: TAKE 2        i=2: 5 > 3         i=3: (not reached)
        |                  |              [X] PRUNE!          BREAK exits loop
        |                  |              5 > remaining
        v                  v              All elements after
solve(1, 2, [1])    solve(2, 1, [2])      are also > 3
        |                  |              (array is sorted!)
+-------+-------+          |
|       |       |     i=2: 5 > 1
i=1   i=2     i=3     [X] PRUNE!
TAKE 2 5>2   (not     BREAK!
  |   [X]    reached)
  |   PRUNE!
  v
solve(2,0,[1,2])
remaining=0
[V] FOUND! [1,2]

                    +--------------------------------------------------+
                    |  PRUNING BENEFIT:                                |
                    |  Without pruning: Would check 5 and 6 at each    |
                    |  level, wasting time.                            |
                    |                                                  |
                    |  With pruning: Once we see element > remaining,  |
                    |  we BREAK (not continue), skipping all larger    |
                    |  elements since array is sorted.                 |
                    +--------------------------------------------------+

FINAL RESULT: [[1, 2]]

================================================================================
RECURSION TREE 5: WHY "i > start" IS CRUCIAL
================================================================================

candidates = [1, 1, 1], target = 2
Sorted: [1, 1, 1]

Without "i > start" check (WRONG - would skip valid paths):

                                    solve(0, 2, [])
                                           |
        +------------------+------------------+------------------+
        |                  |                  |                  |
    i=0: TAKE 1        i=1: SKIP?         i=2: SKIP?
                       arr[1]==arr[0]      arr[2]==arr[1]
                       Would skip!         Would skip!

If we skipped whenever arr[i]==arr[i-1] (without i>start check):
We'd only explore i=0 and skip i=1, i=2
Result: Could never form [1,1] from indices 0 and 1!

--------------------------------------------------------------------------------
With "i > start" check (CORRECT):
--------------------------------------------------------------------------------

                                    solve(0, 2, [])
                                    start=0
                                           |
        +------------------+------------------+------------------+
        |                  |                  |                  |
    i=0: TAKE 1        i=1: SKIP-DUP      i=2: SKIP-DUP
    i==start (0==0)    i>start (1>0)      i>start (2>0)
    MUST TRY!          AND arr[1]==arr[0]  AND arr[2]==arr[1]
        |              SKIP!               SKIP!
        v
solve(1, 1, [1])
start=1
        |
+-------+-------+
|       |       |
i=1   i=2     (end)
TAKE 1 SKIP-DUP
i==start arr[2]==arr[1]
(1==1)  i>start (2>1)
MUST    SKIP!
TRY!
  |
  v
solve(2, 0, [1,1])
remaining=0
[V] FOUND! [1,1]

                    +--------------------------------------------------+
                    |  THE MAGIC OF "i > start":                       |
                    |                                                  |
                    |  - When i == start: This is the FIRST element    |
                    |    we're trying at this recursion level.         |
                    |    We MUST try it, even if it equals previous.   |
                    |                                                  |
                    |  - When i > start: We've already tried the       |
                    |    previous element at this level. If current    |
                    |    equals previous, trying it creates duplicate. |
                    +--------------------------------------------------+

FINAL RESULT: [[1, 1]]

================================================================================
VISUAL SUMMARY: THE DUPLICATE SKIPPING LOGIC
================================================================================

At each recursion level, we have a "start" index:

    candidates = [1, 1, 2, 2, 3]
                  ^
                start (e.g., start=0)

    When iterating from start to end:

    for i in range(start, len(candidates)):
        |
        +-- i == start: First position at this level
        |               ALWAYS try this element
        |               (even if arr[i] == arr[i-1])
        |
        +-- i > start: Not the first position
                       IF arr[i] == arr[i-1], we already tried
                       this VALUE at this level --> SKIP!

    Visual for start=0:

    candidates = [1, 1, 2, 2, 3]
                  ^  ^  ^  ^  ^
                  |  |  |  |  |
                  |  |  |  |  +-- i=4: 3!=2, TRY
                  |  |  |  +---- i=3: i>start AND 2==2, SKIP-DUP
                  |  |  +------- i=2: 2!=1, TRY
                  |  +---------- i=1: i>start AND 1==1, SKIP-DUP
                  +------------- i=0: i==start, MUST TRY

    Elements actually tried at level 0: [1, 2, 3] (unique values only!)

================================================================================
TIME AND SPACE COMPLEXITY
================================================================================

Time Complexity: O(2^n)
-----------------------
- In worst case, we explore all subsets
- Each element has 2 choices: include or exclude
- With n elements, that's 2^n possibilities
- Sorting adds O(n log n) but doesn't change overall complexity

Space Complexity: O(n)
----------------------
- Recursion depth can go up to n (when we include all elements)
- The 'path' array at most holds n elements
- Not counting the output space which can be O(2^n * n)

================================================================================
"""

from typing import List


def combinationSum2(candidates: List[int], target: int) -> List[List[int]]:
    """
    Find all unique combinations in candidates that sum to target.
    Each number can only be used once (by index).

    Args:
        candidates: List of integers (may contain duplicates)
        target: The target sum to achieve

    Returns:
        List of all unique combinations that sum to target
    """

    result = []  # Stores all valid combinations

    # =========================================================================
    # STEP 1: SORT THE ARRAY
    # =========================================================================
    # Sorting is CRUCIAL for two reasons:
    # 1. Groups duplicates together so we can skip them
    # 2. Enables pruning: if current element > remaining, all following are too
    candidates.sort()

    def backtrack(start: int, remaining: int, path: List[int]) -> None:
        """
        Recursive backtracking function to find combinations.

        Args:
            start: Index to start considering elements from
                   (avoids reusing elements and ensures uniqueness)
            remaining: Target sum still needed (target - current sum)
            path: Current combination being built
        """

        # =====================================================================
        # BASE CASE: Found a valid combination
        # =====================================================================
        # If remaining is 0, current path sums to target
        if remaining == 0:
            # IMPORTANT: Append a COPY of path, not path itself
            # (path will be modified later during backtracking)
            result.append(path[:])
            return

        # =====================================================================
        # RECURSIVE CASE: Try each candidate from 'start' index
        # =====================================================================
        for i in range(start, len(candidates)):

            # -----------------------------------------------------------------
            # PRUNING: Early termination
            # -----------------------------------------------------------------
            # Since array is sorted, if current element > remaining,
            # all subsequent elements are also > remaining (no point continuing)
            if candidates[i] > remaining:
                break  # Not 'continue' but 'break' - stop this branch entirely

            # -----------------------------------------------------------------
            # SKIP DUPLICATES AT SAME LEVEL
            # -----------------------------------------------------------------
            # This is THE KEY to avoiding duplicate combinations!
            #
            # Condition: i > start AND candidates[i] == candidates[i-1]
            #
            # - i > start: We're not at the first position of this level
            #              (If i == start, we must try this element)
            #
            # - candidates[i] == candidates[i-1]: Current equals previous
            #              (If they're equal, we'd create duplicate path)
            #
            # Together: Skip if we've already tried this value at this level
            if i > start and candidates[i] == candidates[i - 1]:
                continue

            # -----------------------------------------------------------------
            # CHOOSE: Add current element to path
            # -----------------------------------------------------------------
            path.append(candidates[i])

            # -----------------------------------------------------------------
            # EXPLORE: Recurse with updated parameters
            # -----------------------------------------------------------------
            # - start = i + 1: Move to next index (each element used once)
            # - remaining - candidates[i]: Reduce remaining sum
            # - path: Current path with new element
            backtrack(i + 1, remaining - candidates[i], path)

            # -----------------------------------------------------------------
            # UNCHOOSE: Remove current element (backtrack)
            # -----------------------------------------------------------------
            # This restores state so we can try other elements
            path.pop()

    # Start backtracking from index 0, full target, empty path
    backtrack(0, target, [])

    return result


"""
================================================================================
DRY RUN 1: candidates = [10, 1, 2, 7, 6, 1, 5], target = 8
================================================================================

STEP 1: Sort the array
------------------------
Original: [10, 1, 2, 7, 6, 1, 5]
Sorted:   [1, 1, 2, 5, 6, 7, 10]
           ^  ^  ^  ^  ^  ^  ^
Index:     0  1  2  3  4  5  6

STEP 2: Trace the recursion tree
---------------------------------

backtrack(start=0, remaining=8, path=[])
|
|-- i=0, candidates[0]=1, 1 <= 8
|   |   path = [1]
|   |
|   +-- backtrack(start=1, remaining=7, path=[1])
|       |
|       |-- i=1, candidates[1]=1, 1 <= 7
|       |   |   path = [1, 1]
|       |   |
|       |   +-- backtrack(start=2, remaining=6, path=[1,1])
|       |       |
|       |       |-- i=2, candidates[2]=2, 2 <= 6
|       |       |   |   path = [1, 1, 2]
|       |       |   |
|       |       |   +-- backtrack(start=3, remaining=4, path=[1,1,2])
|       |       |       |
|       |       |       |-- i=3, candidates[3]=5, 5 > 4, BREAK (pruning)
|       |       |       |
|       |       |       (no valid combination here)
|       |       |   |
|       |       |   path = [1, 1] (backtrack)
|       |       |
|       |       |-- i=3, candidates[3]=5, 5 <= 6
|       |       |   |   path = [1, 1, 5]
|       |       |   |
|       |       |   +-- backtrack(start=4, remaining=1, path=[1,1,5])
|       |       |       |
|       |       |       |-- i=4, candidates[4]=6, 6 > 1, BREAK
|       |       |       |
|       |       |   |
|       |       |   path = [1, 1] (backtrack)
|       |       |
|       |       |-- i=4, candidates[4]=6, 6 == 6 (remaining)
|       |       |   |   path = [1, 1, 6]
|       |       |   |
|       |       |   +-- backtrack(start=5, remaining=0, path=[1,1,6])
|       |       |       |
|       |       |       |   remaining == 0, FOUND! result = [[1,1,6]]
|       |       |       |
|       |       |   |
|       |       |   path = [1, 1] (backtrack)
|       |       |
|       |       |-- i=5, candidates[5]=7, 7 > 6, BREAK
|       |       |
|       |   path = [1] (backtrack)
|       |
|       |-- i=2, candidates[2]=2, 2 <= 7
|       |   |   path = [1, 2]
|       |   |
|       |   +-- backtrack(start=3, remaining=5, path=[1,2])
|       |       |
|       |       |-- i=3, candidates[3]=5, 5 == 5 (remaining)
|       |       |   |   path = [1, 2, 5]
|       |       |   |
|       |       |   +-- backtrack(start=4, remaining=0, path=[1,2,5])
|       |       |       |
|       |       |       |   remaining == 0, FOUND! result = [[1,1,6], [1,2,5]]
|       |       |       |
|       |       |   |
|       |       |   path = [1, 2] (backtrack)
|       |       |
|       |       |-- i=4, candidates[4]=6, 6 > 5, BREAK
|       |       |
|       |   path = [1] (backtrack)
|       |
|       |-- i=3, candidates[3]=5, 5 <= 7
|       |   |   path = [1, 5]
|       |   |
|       |   +-- backtrack(start=4, remaining=2, path=[1,5])
|       |       |
|       |       |-- i=4, candidates[4]=6, 6 > 2, BREAK
|       |       |
|       |   path = [1] (backtrack)
|       |
|       |-- i=4, candidates[4]=6, 6 <= 7
|       |   |   path = [1, 6]
|       |   |
|       |   +-- backtrack(start=5, remaining=1, path=[1,6])
|       |       |
|       |       |-- i=5, candidates[5]=7, 7 > 1, BREAK
|       |       |
|       |   path = [1] (backtrack)
|       |
|       |-- i=5, candidates[5]=7, 7 == 7 (remaining)
|       |   |   path = [1, 7]
|       |   |
|       |   +-- backtrack(start=6, remaining=0, path=[1,7])
|       |       |
|       |       |   remaining == 0, FOUND! result = [[1,1,6], [1,2,5], [1,7]]
|       |       |
|       |   path = [1] (backtrack)
|       |
|       |-- i=6, candidates[6]=10, 10 > 7, BREAK
|       |
|   path = [] (backtrack)
|
|-- i=1, candidates[1]=1
|   |   i > start (1 > 0) AND candidates[1] == candidates[0] (1 == 1)
|   |   SKIP DUPLICATE! This prevents creating another [1, x, ...] branch
|
|-- i=2, candidates[2]=2, 2 <= 8
|   |   path = [2]
|   |
|   +-- backtrack(start=3, remaining=6, path=[2])
|       |
|       |-- i=3, candidates[3]=5, 5 <= 6
|       |   |   path = [2, 5]
|       |   |
|       |   +-- backtrack(start=4, remaining=1, path=[2,5])
|       |       |-- i=4, candidates[4]=6, 6 > 1, BREAK
|       |   path = [2] (backtrack)
|       |
|       |-- i=4, candidates[4]=6, 6 == 6
|       |   |   path = [2, 6]
|       |   |
|       |   +-- backtrack(start=5, remaining=0, path=[2,6])
|       |       |
|       |       |   remaining == 0, FOUND! result = [[1,1,6], [1,2,5], [1,7], [2,6]]
|       |       |
|       |   path = [2] (backtrack)
|       |
|       |-- i=5, candidates[5]=7, 7 > 6, BREAK
|   path = [] (backtrack)
|
|-- i=3, candidates[3]=5, 5 <= 8
|   |   path = [5]
|   |   (exploring but no valid combinations found with remaining=3)
|   path = [] (backtrack)
|
|-- i=4, candidates[4]=6, 6 <= 8
|   |   path = [6]
|   |   (exploring but no valid combinations found with remaining=2)
|   path = [] (backtrack)
|
|-- i=5, candidates[5]=7, 7 <= 8
|   |   path = [7]
|   |   (exploring but no valid combinations found with remaining=1)
|   path = [] (backtrack)
|
|-- i=6, candidates[6]=10, 10 > 8, BREAK

FINAL RESULT: [[1, 1, 6], [1, 2, 5], [1, 7], [2, 6]]


================================================================================
DRY RUN 2: candidates = [2, 5, 2, 1, 2], target = 5
================================================================================

STEP 1: Sort the array
------------------------
Original: [2, 5, 2, 1, 2]
Sorted:   [1, 2, 2, 2, 5]
           ^  ^  ^  ^  ^
Index:     0  1  2  3  4

Notice: Three 2s are now adjacent - duplicate handling is crucial!

STEP 2: Trace the recursion tree
---------------------------------

backtrack(start=0, remaining=5, path=[])
|
|-- i=0, candidates[0]=1, 1 <= 5
|   |   path = [1]
|   |
|   +-- backtrack(start=1, remaining=4, path=[1])
|       |
|       |-- i=1, candidates[1]=2, 2 <= 4
|       |   |   path = [1, 2]
|       |   |
|       |   +-- backtrack(start=2, remaining=2, path=[1,2])
|       |       |
|       |       |-- i=2, candidates[2]=2, 2 == 2 (remaining)
|       |       |   |   path = [1, 2, 2]
|       |       |   |
|       |       |   +-- backtrack(start=3, remaining=0, path=[1,2,2])
|       |       |       |
|       |       |       |   remaining == 0, FOUND! result = [[1,2,2]]
|       |       |       |
|       |       |   path = [1, 2] (backtrack)
|       |       |
|       |       |-- i=3, candidates[3]=2
|       |       |   |   i > start (3 > 2) AND candidates[3] == candidates[2] (2 == 2)
|       |       |   |   SKIP DUPLICATE! (Would create another [1,2,2])
|       |       |
|       |       |-- i=4, candidates[4]=5, 5 > 2, BREAK
|       |       |
|       |   path = [1] (backtrack)
|       |
|       |-- i=2, candidates[2]=2
|       |   |   i > start (2 > 1) AND candidates[2] == candidates[1] (2 == 2)
|       |   |   SKIP DUPLICATE! (Would create another [1,2,...] branch)
|       |
|       |-- i=3, candidates[3]=2
|       |   |   i > start (3 > 1) AND candidates[3] == candidates[2] (2 == 2)
|       |   |   SKIP DUPLICATE!
|       |
|       |-- i=4, candidates[4]=5, 5 > 4, BREAK
|       |
|   path = [] (backtrack)
|
|-- i=1, candidates[1]=2, 2 <= 5
|   |   path = [2]
|   |
|   +-- backtrack(start=2, remaining=3, path=[2])
|       |
|       |-- i=2, candidates[2]=2, 2 <= 3
|       |   |   path = [2, 2]
|       |   |
|       |   +-- backtrack(start=3, remaining=1, path=[2,2])
|       |       |
|       |       |-- i=3, candidates[3]=2, 2 > 1, BREAK
|       |       |   (no valid combinations)
|       |   path = [2] (backtrack)
|       |
|       |-- i=3, candidates[3]=2
|       |   |   i > start (3 > 2) AND candidates[3] == candidates[2] (2 == 2)
|       |   |   SKIP DUPLICATE!
|       |
|       |-- i=4, candidates[4]=5, 5 > 3, BREAK
|       |
|   path = [] (backtrack)
|
|-- i=2, candidates[2]=2
|   |   i > start (2 > 0) AND candidates[2] == candidates[1] (2 == 2)
|   |   SKIP DUPLICATE! (Would create another [2,...] branch - already did [2,...])
|
|-- i=3, candidates[3]=2
|   |   i > start (3 > 0) AND candidates[3] == candidates[2] (2 == 2)
|   |   SKIP DUPLICATE!
|
|-- i=4, candidates[4]=5, 5 == 5 (remaining)
|   |   path = [5]
|   |
|   +-- backtrack(start=5, remaining=0, path=[5])
|       |
|       |   remaining == 0, FOUND! result = [[1,2,2], [5]]
|       |
|   path = [] (backtrack)

FINAL RESULT: [[1, 2, 2], [5]]

KEY OBSERVATION:
----------------
Despite having THREE 2s in the input, [1, 2, 2] appears only ONCE!

The duplicate skipping logic prevented:
- Multiple [2, ...] branches at level 0
- Multiple [1, 2, ...] branches at level 1
- Multiple [1, 2, 2, ...] paths at level 2

Without this logic, we would have gotten [1, 2, 2] THREE times!


================================================================================
EDGE CASES
================================================================================

1. Empty candidates array:
   - Input: candidates = [], target = 5
   - Output: []
   - No elements to form any combination

2. Target is 0:
   - Input: candidates = [1, 2, 3], target = 0
   - Output: [[]]
   - Empty combination sums to 0

3. No valid combination exists:
   - Input: candidates = [2, 4, 6], target = 3
   - Output: []
   - No way to sum to target

4. All elements are the same:
   - Input: candidates = [2, 2, 2, 2], target = 4
   - Output: [[2, 2]]
   - Only one unique combination despite four 2s

5. Single element equals target:
   - Input: candidates = [5], target = 5
   - Output: [[5]]
   - Single element forms the combination

6. Single element does not equal target:
   - Input: candidates = [3], target = 5
   - Output: []
   - Cannot reach target


================================================================================
COMPARISON WITH RELATED PROBLEMS
================================================================================

1. COMBINATION SUM I (LeetCode 39)
   ---------------------------------
   - Elements can be reused UNLIMITED times
   - No duplicates in input
   - Key difference: backtrack(i, ...) not backtrack(i+1, ...)

   Code difference:
   # Combination Sum I
   backtrack(i, remaining - candidates[i], path)  # Stay at same index

   # Combination Sum II (this problem)
   backtrack(i + 1, remaining - candidates[i], path)  # Move to next index

2. COMBINATION SUM II (LeetCode 40) - THIS PROBLEM
   -------------------------------------------------
   - Each element used AT MOST ONCE
   - Input MAY contain duplicates
   - Must skip duplicates at same recursion level

   Key line:
   if i > start and candidates[i] == candidates[i-1]:
       continue

3. COMBINATION SUM III (LeetCode 216)
   ------------------------------------
   - Use numbers 1-9 only
   - Each number used at most once
   - Must use EXACTLY k numbers
   - No duplicates in input (1-9 are unique)

   Code difference:
   # Extra constraint: exactly k numbers
   if len(path) == k and remaining == 0:
       result.append(path[:])

4. SUBSETS II (LeetCode 90)
   -------------------------
   - Find ALL subsets, not just those summing to target
   - Same duplicate handling logic as Combination Sum II
   - Every path is a valid result (not just when remaining == 0)

   Code difference:
   def backtrack(start, path):
       result.append(path[:])  # Every path is valid
       for i in range(start, len(nums)):
           if i > start and nums[i] == nums[i-1]:
               continue
           path.append(nums[i])
           backtrack(i + 1, path)
           path.pop()


================================================================================
PATTERN RECOGNITION: When to use which technique?
================================================================================

+---------------------+------------------+------------------+------------------+
| Scenario            | Sort?            | Skip duplicates? | Reuse elements?  |
+---------------------+------------------+------------------+------------------+
| Unique input,       | Optional         | No               | Yes (same i)     |
| unlimited reuse     | (helps prune)    |                  |                  |
+---------------------+------------------+------------------+------------------+
| Duplicate input,    | YES (required)   | YES              | No (use i+1)     |
| single use          |                  | i > start check  |                  |
+---------------------+------------------+------------------+------------------+
| Unique input,       | Optional         | No               | No (use i+1)     |
| single use          | (helps prune)    |                  |                  |
+---------------------+------------------+------------------+------------------+

"""


# =============================================================================
# TEST CASES
# =============================================================================

if __name__ == "__main__":

    print("=" * 70)
    print("COMBINATION SUM II - TEST CASES")
    print("=" * 70)

    # Test Case 1: Standard example with duplicates
    print("\nTest Case 1: candidates = [10,1,2,7,6,1,5], target = 8")
    result1 = combinationSum2([10, 1, 2, 7, 6, 1, 5], 8)
    print(f"Output: {result1}")
    print(f"Expected: [[1,1,6], [1,2,5], [1,7], [2,6]]")

    # Test Case 2: Multiple duplicates of same number
    print("\nTest Case 2: candidates = [2,5,2,1,2], target = 5")
    result2 = combinationSum2([2, 5, 2, 1, 2], 5)
    print(f"Output: {result2}")
    print(f"Expected: [[1,2,2], [5]]")

    # Test Case 3: Empty array
    print("\nTest Case 3: candidates = [], target = 5")
    result3 = combinationSum2([], 5)
    print(f"Output: {result3}")
    print(f"Expected: []")

    # Test Case 4: Target is 0
    print("\nTest Case 4: candidates = [1,2,3], target = 0")
    result4 = combinationSum2([1, 2, 3], 0)
    print(f"Output: {result4}")
    print(f"Expected: [[]] (empty combination)")

    # Test Case 5: No valid combination
    print("\nTest Case 5: candidates = [2,4,6], target = 3")
    result5 = combinationSum2([2, 4, 6], 3)
    print(f"Output: {result5}")
    print(f"Expected: []")

    # Test Case 6: All elements are the same
    print("\nTest Case 6: candidates = [2,2,2,2], target = 4")
    result6 = combinationSum2([2, 2, 2, 2], 4)
    print(f"Output: {result6}")
    print(f"Expected: [[2,2]]")

    # Test Case 7: Single element equals target
    print("\nTest Case 7: candidates = [5], target = 5")
    result7 = combinationSum2([5], 5)
    print(f"Output: {result7}")
    print(f"Expected: [[5]]")

    # Test Case 8: Single element does not equal target
    print("\nTest Case 8: candidates = [3], target = 5")
    result8 = combinationSum2([3], 5)
    print(f"Output: {result8}")
    print(f"Expected: []")

    # Test Case 9: All elements needed
    print("\nTest Case 9: candidates = [1,2,3], target = 6")
    result9 = combinationSum2([1, 2, 3], 6)
    print(f"Output: {result9}")
    print(f"Expected: [[1,2,3]]")

    # Test Case 10: Larger test with many duplicates
    print("\nTest Case 10: candidates = [1,1,1,1,1,1,1,1], target = 3")
    result10 = combinationSum2([1, 1, 1, 1, 1, 1, 1, 1], 3)
    print(f"Output: {result10}")
    print(f"Expected: [[1,1,1]] (only one combination despite 8 ones)")

    print("\n" + "=" * 70)
    print("ALL TESTS COMPLETED")
    print("=" * 70)
