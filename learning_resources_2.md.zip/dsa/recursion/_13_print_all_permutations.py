"""Print all permutations of a given string using recursion.
Use the basic approach and then the most optimal which does not use any map or array
"""

# =============================================================================
#                     PRINT ALL PERMUTATIONS OF A STRING
# =============================================================================
#
# This is a CLASSIC recursion + backtracking problem that appears frequently
# in coding interviews. We will learn TWO approaches:
#   1. Basic Approach: Using a visited/map array to track used elements
#   2. Optimal Approach: Using in-place swaps (no extra space for tracking)
#
# =============================================================================


# =============================================================================
# SECTION 1: PROBLEM UNDERSTANDING
# =============================================================================
"""
WHAT IS A PERMUTATION?
----------------------
A permutation is an arrangement of elements where ORDER MATTERS.

For a string/array of n distinct elements:
  - Total permutations = n! (n factorial)
  - n! = n x (n-1) x (n-2) x ... x 2 x 1

EXAMPLE: For string "ABC" (n=3)
----------------------------------
Total permutations = 3! = 3 x 2 x 1 = 6

All 6 permutations:
  1. ABC
  2. ACB
  3. BAC
  4. BCA
  5. CAB
  6. CBA

Notice: Each permutation uses ALL characters exactly ONCE, just in different orders.

WHY n! PERMUTATIONS?
--------------------
Think of it as filling n positions:
  - Position 1: n choices (any character)
  - Position 2: n-1 choices (remaining characters)
  - Position 3: n-2 choices
  - ...
  - Position n: 1 choice (last remaining character)

Total = n x (n-1) x (n-2) x ... x 1 = n!

VISUAL FOR "ABC":
                    Position 1    Position 2    Position 3
                    (3 choices)   (2 choices)   (1 choice)
                         |             |             |
                         v             v             v
    Permutation 1:       A      ->     B      ->     C     = ABC
    Permutation 2:       A      ->     C      ->     B     = ACB
    Permutation 3:       B      ->     A      ->     C     = BAC
    Permutation 4:       B      ->     C      ->     A     = BCA
    Permutation 5:       C      ->     A      ->     B     = CAB
    Permutation 6:       C      ->     B      ->     A     = CBA
"""


# =============================================================================
# SECTION 2: APPROACH 1 - USING VISITED/MAP ARRAY
# =============================================================================
"""
INTUITION:
----------
Build the permutation CHARACTER BY CHARACTER.

At each step:
  1. Look at all characters in the original string
  2. Pick one that has NOT been used yet (check visited array)
  3. Add it to our current permutation
  4. Mark it as used (visited[i] = True)
  5. Recurse to fill the next position
  6. BACKTRACK: Remove the character, mark as unused (visited[i] = False)

This is the classic BACKTRACKING pattern:
  TRY -> RECURSE -> UNDO

DATA STRUCTURES NEEDED:
-----------------------
  - original: The input string (never modified)
  - current: List/string being built (our current permutation so far)
  - visited: Boolean array where visited[i] = True means original[i] is already used
  - result: List to store all complete permutations

ALGORITHM:
----------
  function permute(current, visited):
      if len(current) == len(original):
          result.append(current)  # Found a complete permutation!
          return

      for i from 0 to len(original)-1:
          if not visited[i]:              # Only pick unused characters
              visited[i] = True           # Mark as used
              permute(current + original[i], visited)  # Recurse
              visited[i] = False          # BACKTRACK: unmark

RECURSION TREE FOR "ABC":
-------------------------
Legend: current = what we've built so far
        visited = [A_used?, B_used?, C_used?]

                                   f("", [F,F,F])
                                   "Start: empty"
                         /              |              \
                    pick A           pick B           pick C
                       |                |                |
                f("A", [T,F,F])   f("B", [F,T,F])   f("C", [F,F,T])
                   /     \           /     \           /     \
              pick B   pick C   pick A   pick C   pick A   pick B
                 |        |        |        |        |        |
        f("AB",[T,T,F]) f("AC",[T,F,T]) f("BA",[T,T,F]) f("BC",[F,T,T]) f("CA",[T,F,T]) f("CB",[F,T,T])
              |             |             |             |             |             |
          pick C        pick B        pick C        pick A        pick B        pick A
              |             |             |             |             |             |
        f("ABC")       f("ACB")       f("BAC")       f("BCA")       f("CAB")       f("CBA")
        len==3!        len==3!        len==3!        len==3!        len==3!        len==3!
        PRINT          PRINT          PRINT          PRINT          PRINT          PRINT

OUTPUT: ABC, ACB, BAC, BCA, CAB, CBA (all 6 permutations!)

TIME COMPLEXITY: O(n! * n)
  - n! recursive leaves (complete permutations)
  - O(n) to copy/print each permutation

SPACE COMPLEXITY: O(n)
  - visited array: O(n)
  - recursion stack depth: O(n)
  - current string: O(n)
"""


# =============================================================================
# SECTION 3: APPROACH 2 - OPTIMAL SWAP METHOD (No extra space)
# =============================================================================
"""
THE KEY INSIGHT FOR INTERVIEWS:
-------------------------------
Instead of building a NEW string and tracking visited elements,
we can MODIFY THE STRING IN-PLACE by swapping characters!

INTUITION:
----------
Think of it as "fixing" one position at a time from LEFT to RIGHT.

At position `idx`:
  1. We need to decide which character should go here
  2. ANY character from position `idx` to `end` can be placed here
  3. To place character at position `j` here, SWAP it with position `idx`
  4. After swap, recurse to fix the next position (idx + 1)
  5. BACKTRACK: Swap back to restore original order (undo the swap)

WHY DOES THIS WORK?
-------------------
  - Characters BEFORE `idx` are already "fixed" - they're part of current permutation
  - Characters FROM `idx` onwards are "available" to be placed at position `idx`
  - By trying each available character at position `idx`, we explore all possibilities

ALGORITHM:
----------
  function permute(s, idx):
      if idx == len(s):
          result.append(s)  # Found a complete permutation!
          return

      for j from idx to len(s)-1:
          swap(s[idx], s[j])        # Try character at position j in position idx
          permute(s, idx + 1)       # Recurse for remaining positions
          swap(s[idx], s[j])        # BACKTRACK: restore original

IMPORTANT NOTE:
---------------
When j == idx, we're swapping a character with itself (no change).
This handles the case where the character at `idx` stays in its original position.

RECURSION TREE FOR "ABC" (Swap Method):
---------------------------------------
Each node shows: current string state, idx value

                            f("ABC", idx=0)
                           "Fix position 0"
                    /            |            \
            swap(0,0)       swap(0,1)       swap(0,2)
            A stays         swap A,B        swap A,C
               |               |               |
        f("ABC", idx=1)  f("BAC", idx=1)  f("CBA", idx=1)
        "Fix position 1"  "Fix position 1"  "Fix position 1"
           /    \            /    \            /    \
      swap(1,1) swap(1,2) swap(1,1) swap(1,2) swap(1,1) swap(1,2)
      B stays   swap B,C  A stays   swap A,C  B stays   swap B,A
         |         |         |         |         |         |
    f("ABC",2) f("ACB",2) f("BAC",2) f("BCA",2) f("CBA",2) f("CAB",2)
       idx==3!   idx==3!    idx==3!    idx==3!    idx==3!    idx==3!
       PRINT     PRINT      PRINT      PRINT      PRINT      PRINT

OUTPUT: ABC, ACB, BAC, BCA, CBA, CAB (all 6 permutations!)

Note: Order might differ from Approach 1, but we still get all n! permutations.

VISUAL: WHAT HAPPENS AT EACH LEVEL
----------------------------------
For "ABC" with idx=0:

  Original:  [A] [B] [C]
              ^
             idx=0

  swap(0,0): [A] [B] [C]  --> A is fixed at position 0, recurse with idx=1
  swap(0,1): [B] [A] [C]  --> B is fixed at position 0, recurse with idx=1
  swap(0,2): [C] [B] [A]  --> C is fixed at position 0, recurse with idx=1

At each level, we're essentially saying:
  "Which character should be at this position? Let me try each one!"

TIME COMPLEXITY: O(n! * n)
  - Same as Approach 1
  - n! permutations, O(n) to copy each

SPACE COMPLEXITY: O(n) - Only recursion stack!
  - No visited array needed
  - No extra string being built
  - Just the recursion stack: O(n) depth
"""


# =============================================================================
# SECTION 4: DRY RUN FOR "AB" (Simpler Example)
# =============================================================================
"""
Let's trace through the SWAP METHOD for s = "AB" (n=2, expect 2! = 2 permutations)

INITIAL CALL: permute("AB", idx=0)
----------------------------------

CALL STACK TRACE:
=================

permute("AB", idx=0)
|
|-- idx=0, not equal to len=2, so enter the loop
|
|   ITERATION 1: j=0
|   |-- swap(s[0], s[0]) --> "AB" stays "AB"
|   |-- CALL: permute("AB", idx=1)
|   |   |
|   |   |-- idx=1, not equal to len=2, so enter the loop
|   |   |
|   |   |   ITERATION: j=1
|   |   |   |-- swap(s[1], s[1]) --> "AB" stays "AB"
|   |   |   |-- CALL: permute("AB", idx=2)
|   |   |   |   |
|   |   |   |   |-- idx=2 == len=2 --> BASE CASE!
|   |   |   |   |-- PRINT/STORE: "AB"  <-- FIRST PERMUTATION
|   |   |   |   |-- RETURN
|   |   |   |
|   |   |   |-- swap back: s[1], s[1] --> "AB" stays "AB"
|   |   |
|   |   |-- j loop ends (j was 1, no more iterations)
|   |   |-- RETURN
|   |
|   |-- swap back: s[0], s[0] --> "AB" stays "AB"
|
|   ITERATION 2: j=1
|   |-- swap(s[0], s[1]) --> "AB" becomes "BA"
|   |-- CALL: permute("BA", idx=1)
|   |   |
|   |   |-- idx=1, not equal to len=2, so enter the loop
|   |   |
|   |   |   ITERATION: j=1
|   |   |   |-- swap(s[1], s[1]) --> "BA" stays "BA"
|   |   |   |-- CALL: permute("BA", idx=2)
|   |   |   |   |
|   |   |   |   |-- idx=2 == len=2 --> BASE CASE!
|   |   |   |   |-- PRINT/STORE: "BA"  <-- SECOND PERMUTATION
|   |   |   |   |-- RETURN
|   |   |   |
|   |   |   |-- swap back: s[1], s[1] --> "BA" stays "BA"
|   |   |
|   |   |-- j loop ends
|   |   |-- RETURN
|   |
|   |-- swap back: s[0], s[1] --> "BA" becomes "AB" (restored!)
|
|-- j loop ends (j=0,1 done)
|-- RETURN (function complete)

RESULT: ["AB", "BA"] - Both permutations found!

STATE TRANSITIONS SUMMARY:
--------------------------
Step | Action              | String | idx | Output
-----|---------------------|--------|-----|--------
  1  | Start               | "AB"   |  0  |
  2  | swap(0,0)           | "AB"   |  0  |
  3  | recurse             | "AB"   |  1  |
  4  | swap(1,1)           | "AB"   |  1  |
  5  | recurse             | "AB"   |  2  | "AB"
  6  | backtrack swap(1,1) | "AB"   |  1  |
  7  | backtrack           | "AB"   |  0  |
  8  | swap back(0,0)      | "AB"   |  0  |
  9  | swap(0,1)           | "BA"   |  0  |
 10  | recurse             | "BA"   |  1  |
 11  | swap(1,1)           | "BA"   |  1  |
 12  | recurse             | "BA"   |  2  | "BA"
 13  | backtrack swap(1,1) | "BA"   |  1  |
 14  | backtrack           | "BA"   |  0  |
 15  | swap back(0,1)      | "AB"   |  0  | (restored!)
 16  | Done                | "AB"   |     |
"""


# =============================================================================
# SECTION 5: DRY RUN FOR "ABC" (Full Trace)
# =============================================================================
"""
Let's trace through the SWAP METHOD for s = "ABC" (n=3, expect 3! = 6 permutations)

This is more complex, so I'll show it in a structured tree format:

EXECUTION TREE:
===============

permute("ABC", 0)
|
+-- j=0: swap(0,0) -> "ABC"
|   |
|   +-- permute("ABC", 1)
|       |
|       +-- j=1: swap(1,1) -> "ABC"
|       |   |
|       |   +-- permute("ABC", 2)
|       |       |
|       |       +-- idx==3 --> OUTPUT: "ABC"  [Permutation 1]
|       |
|       +-- j=2: swap(1,2) -> "ACB"
|           |
|           +-- permute("ACB", 2)
|               |
|               +-- idx==3 --> OUTPUT: "ACB"  [Permutation 2]
|           |
|           +-- swap back(1,2) -> "ABC"
|
+-- j=1: swap(0,1) -> "BAC"
|   |
|   +-- permute("BAC", 1)
|       |
|       +-- j=1: swap(1,1) -> "BAC"
|       |   |
|       |   +-- permute("BAC", 2)
|       |       |
|       |       +-- idx==3 --> OUTPUT: "BAC"  [Permutation 3]
|       |
|       +-- j=2: swap(1,2) -> "BCA"
|           |
|           +-- permute("BCA", 2)
|               |
|               +-- idx==3 --> OUTPUT: "BCA"  [Permutation 4]
|           |
|           +-- swap back(1,2) -> "BAC"
|   |
|   +-- swap back(0,1) -> "ABC"
|
+-- j=2: swap(0,2) -> "CBA"
    |
    +-- permute("CBA", 1)
        |
        +-- j=1: swap(1,1) -> "CBA"
        |   |
        |   +-- permute("CBA", 2)
        |       |
        |       +-- idx==3 --> OUTPUT: "CBA"  [Permutation 5]
        |
        +-- j=2: swap(1,2) -> "CAB"
            |
            +-- permute("CAB", 2)
                |
                +-- idx==3 --> OUTPUT: "CAB"  [Permutation 6]
            |
            +-- swap back(1,2) -> "CBA"
    |
    +-- swap back(0,2) -> "ABC"

FINAL RESULT: ["ABC", "ACB", "BAC", "BCA", "CBA", "CAB"]

All 6 permutations generated!

DETAILED STATE TABLE:
---------------------
Call# | Current String | idx | j   | Action                    | Output
------|----------------|-----|-----|---------------------------|--------
  1   | "ABC"          |  0  |  0  | swap(0,0)                 |
  2   | "ABC"          |  1  |  1  | swap(1,1)                 |
  3   | "ABC"          |  2  |  -  | BASE CASE                 | "ABC"
  4   | "ABC"          |  1  |  2  | swap(1,2) -> "ACB"        |
  5   | "ACB"          |  2  |  -  | BASE CASE                 | "ACB"
  6   | "ACB"          |  1  |  -  | swap back(1,2) -> "ABC"   |
  7   | "ABC"          |  0  |  1  | swap(0,1) -> "BAC"        |
  8   | "BAC"          |  1  |  1  | swap(1,1)                 |
  9   | "BAC"          |  2  |  -  | BASE CASE                 | "BAC"
 10   | "BAC"          |  1  |  2  | swap(1,2) -> "BCA"        |
 11   | "BCA"          |  2  |  -  | BASE CASE                 | "BCA"
 12   | "BCA"          |  1  |  -  | swap back(1,2) -> "BAC"   |
 13   | "BAC"          |  0  |  -  | swap back(0,1) -> "ABC"   |
 14   | "ABC"          |  0  |  2  | swap(0,2) -> "CBA"        |
 15   | "CBA"          |  1  |  1  | swap(1,1)                 |
 16   | "CBA"          |  2  |  -  | BASE CASE                 | "CBA"
 17   | "CBA"          |  1  |  2  | swap(1,2) -> "CAB"        |
 18   | "CAB"          |  2  |  -  | BASE CASE                 | "CAB"
 19   | "CAB"          |  1  |  -  | swap back(1,2) -> "CBA"   |
 20   | "CBA"          |  0  |  -  | swap back(0,2) -> "ABC"   |
 21   | "ABC"          |  -  |  -  | DONE                      |
"""


# =============================================================================
# SECTION 6: COMPREHENSIVE RECURSION TREE FOR permutations([1,2,3])
# =============================================================================
"""
================================================================================
                   RECURSION TREE FOR permutations([1,2,3])
================================================================================

At each level, we FIX one position by swapping and recurse on the remaining.
The key insight: At position `idx`, try placing EACH available character there.

LEGEND:
-------
  - arr = current state of the array
  - idx = current position we are fixing
  - swap(i,j) = swap elements at positions i and j
  - [DONE] = base case reached, permutation complete
  - Arrows show the flow of execution

================================================================================
                            LEVEL 0: Fix position 0
================================================================================

                                 permute(idx=0)
                                 arr = [1, 2, 3]
                                 "Which element at position 0?"
                                        |
           +---------------------------++--------------------------+
           |                            |                          |
      swap(0,0)                    swap(0,1)                  swap(0,2)
      1 stays at pos 0             Swap 1 and 2               Swap 1 and 3
           |                            |                          |
           v                            v                          v
    arr = [1, 2, 3]              arr = [2, 1, 3]            arr = [3, 2, 1]
    "1 fixed at pos 0"           "2 fixed at pos 0"         "3 fixed at pos 0"
           |                            |                          |
           v                            v                          v
    permute(idx=1)               permute(idx=1)             permute(idx=1)
           |                            |                          |
    (see BRANCH A)               (see BRANCH B)             (see BRANCH C)


================================================================================
                BRANCH A: Starting with [1, 2, 3], idx=1
================================================================================

                              permute(idx=1)
                              arr = [1, 2, 3]
                              "Position 0 fixed as 1"
                              "Which element at position 1?"
                                     |
                     +---------------+---------------+
                     |                               |
                swap(1,1)                       swap(1,2)
                2 stays at pos 1                Swap 2 and 3
                     |                               |
                     v                               v
              arr = [1, 2, 3]                 arr = [1, 3, 2]
              "2 fixed at pos 1"             "3 fixed at pos 1"
                     |                               |
                     v                               v
              permute(idx=2)                  permute(idx=2)
                     |                               |
                     v                               v
              idx == len(arr)                 idx == len(arr)
              [DONE!]                         [DONE!]
                     |                               |
                     v                               v
        +---> OUTPUT: [1, 2, 3] <---+   +---> OUTPUT: [1, 3, 2] <---+
        |      PERMUTATION #1       |   |      PERMUTATION #2       |
        +---------------------------+   +---------------------------+
                     |                               |
              (backtrack)                     (backtrack)
              swap(1,1) -> no change          swap(1,2) -> [1, 2, 3]
                     |                               |
                     +---------------+---------------+
                                     |
                              Back to LEVEL 0
                              swap back (0,0) -> no change
                              arr = [1, 2, 3] (restored)


================================================================================
                BRANCH B: Starting with [2, 1, 3], idx=1
================================================================================

                              permute(idx=1)
                              arr = [2, 1, 3]
                              "Position 0 fixed as 2"
                              "Which element at position 1?"
                                     |
                     +---------------+---------------+
                     |                               |
                swap(1,1)                       swap(1,2)
                1 stays at pos 1                Swap 1 and 3
                     |                               |
                     v                               v
              arr = [2, 1, 3]                 arr = [2, 3, 1]
              "1 fixed at pos 1"             "3 fixed at pos 1"
                     |                               |
                     v                               v
              permute(idx=2)                  permute(idx=2)
                     |                               |
                     v                               v
              idx == len(arr)                 idx == len(arr)
              [DONE!]                         [DONE!]
                     |                               |
                     v                               v
        +---> OUTPUT: [2, 1, 3] <---+   +---> OUTPUT: [2, 3, 1] <---+
        |      PERMUTATION #3       |   |      PERMUTATION #4       |
        +---------------------------+   +---------------------------+
                     |                               |
              (backtrack)                     (backtrack)
              swap(1,1) -> no change          swap(1,2) -> [2, 1, 3]
                     |                               |
                     +---------------+---------------+
                                     |
                              Back to LEVEL 0
                              swap back (0,1) -> [1, 2, 3]
                              arr = [1, 2, 3] (restored)


================================================================================
                BRANCH C: Starting with [3, 2, 1], idx=1
================================================================================

                              permute(idx=1)
                              arr = [3, 2, 1]
                              "Position 0 fixed as 3"
                              "Which element at position 1?"
                                     |
                     +---------------+---------------+
                     |                               |
                swap(1,1)                       swap(1,2)
                2 stays at pos 1                Swap 2 and 1
                     |                               |
                     v                               v
              arr = [3, 2, 1]                 arr = [3, 1, 2]
              "2 fixed at pos 1"             "1 fixed at pos 1"
                     |                               |
                     v                               v
              permute(idx=2)                  permute(idx=2)
                     |                               |
                     v                               v
              idx == len(arr)                 idx == len(arr)
              [DONE!]                         [DONE!]
                     |                               |
                     v                               v
        +---> OUTPUT: [3, 2, 1] <---+   +---> OUTPUT: [3, 1, 2] <---+
        |      PERMUTATION #5       |   |      PERMUTATION #6       |
        +---------------------------+   +---------------------------+
                     |                               |
              (backtrack)                     (backtrack)
              swap(1,1) -> no change          swap(1,2) -> [3, 2, 1]
                     |                               |
                     +---------------+---------------+
                                     |
                              Back to LEVEL 0
                              swap back (0,2) -> [1, 2, 3]
                              arr = [1, 2, 3] (restored)


================================================================================
              COMPLETE TREE VIEW (COMPACT VISUALIZATION)
================================================================================

                                   permute(arr=[1,2,3], idx=0)
                                            |
              +-----------------------------+-----------------------------+
              |                             |                             |
         swap(0,0)                     swap(0,1)                     swap(0,2)
         [1,2,3]                       [2,1,3]                       [3,2,1]
         idx=1                         idx=1                         idx=1
              |                             |                             |
       +------+------+              +------+------+              +------+------+
       |             |              |             |              |             |
  swap(1,1)    swap(1,2)       swap(1,1)    swap(1,2)       swap(1,1)    swap(1,2)
  [1,2,3]      [1,3,2]         [2,1,3]      [2,3,1]         [3,2,1]      [3,1,2]
  idx=2        idx=2           idx=2        idx=2           idx=2        idx=2
       |             |              |             |              |             |
    [DONE]       [DONE]          [DONE]       [DONE]          [DONE]       [DONE]
       |             |              |             |              |             |
  PERM #1       PERM #2         PERM #3       PERM #4         PERM #5       PERM #6
  [1,2,3]      [1,3,2]         [2,1,3]      [2,3,1]         [3,2,1]      [3,1,2]


================================================================================
             BACKTRACKING FLOW (SWAP AND UNSWAP VISUALIZATION)
================================================================================

The execution flows DOWN (recursion) and UP (backtracking):

    GOING DOWN (Recursion)              GOING UP (Backtracking)
    ----------------------              -----------------------

    arr = [1,2,3], idx=0                arr = [1,2,3] (restored!)
            |                                   ^
            | swap(0,1): [1,2,3] -> [2,1,3]     | swap(0,1): [2,1,3] -> [1,2,3]
            v                                   |
    arr = [2,1,3], idx=1                arr = [2,1,3] (restored!)
            |                                   ^
            | swap(1,2): [2,1,3] -> [2,3,1]     | swap(1,2): [2,3,1] -> [2,1,3]
            v                                   |
    arr = [2,3,1], idx=2                arr = [2,3,1]
            |                                   ^
            | idx == 3 (BASE CASE)              | RETURN after recording
            v                                   |
    OUTPUT: [2,3,1]  ----------------------->  +


================================================================================
          DETAILED STEP-BY-STEP EXECUTION WITH SWAP TRACKING
================================================================================

Step | Action                    | Array State | idx | Swap Performed | Output
-----|---------------------------|-------------|-----|----------------|--------
  1  | Start                     | [1,2,3]     |  0  | -              |
  2  | swap(0,0)                 | [1,2,3]     |  0  | 1<->1 (no-op)  |
  3  | Enter recursion           | [1,2,3]     |  1  | -              |
  4  | swap(1,1)                 | [1,2,3]     |  1  | 2<->2 (no-op)  |
  5  | Enter recursion           | [1,2,3]     |  2  | -              |
  6  | idx==3, BASE CASE         | [1,2,3]     |  2  | -              | [1,2,3]
  7  | Return, swap back (1,1)   | [1,2,3]     |  1  | no change      |
  8  | swap(1,2)                 | [1,3,2]     |  1  | 2<->3          |
  9  | Enter recursion           | [1,3,2]     |  2  | -              |
 10  | idx==3, BASE CASE         | [1,3,2]     |  2  | -              | [1,3,2]
 11  | Return, swap back (1,2)   | [1,2,3]     |  1  | 3<->2          |
 12  | Return to idx=0           | [1,2,3]     |  0  | -              |
 13  | swap back (0,0)           | [1,2,3]     |  0  | no change      |
 14  | swap(0,1)                 | [2,1,3]     |  0  | 1<->2          |
 15  | Enter recursion           | [2,1,3]     |  1  | -              |
 16  | swap(1,1)                 | [2,1,3]     |  1  | 1<->1 (no-op)  |
 17  | Enter recursion           | [2,1,3]     |  2  | -              |
 18  | idx==3, BASE CASE         | [2,1,3]     |  2  | -              | [2,1,3]
 19  | Return, swap back (1,1)   | [2,1,3]     |  1  | no change      |
 20  | swap(1,2)                 | [2,3,1]     |  1  | 1<->3          |
 21  | Enter recursion           | [2,3,1]     |  2  | -              |
 22  | idx==3, BASE CASE         | [2,3,1]     |  2  | -              | [2,3,1]
 23  | Return, swap back (1,2)   | [2,1,3]     |  1  | 3<->1          |
 24  | Return to idx=0           | [2,1,3]     |  0  | -              |
 25  | swap back (0,1)           | [1,2,3]     |  0  | 2<->1          |
 26  | swap(0,2)                 | [3,2,1]     |  0  | 1<->3          |
 27  | Enter recursion           | [3,2,1]     |  1  | -              |
 28  | swap(1,1)                 | [3,2,1]     |  1  | 2<->2 (no-op)  |
 29  | Enter recursion           | [3,2,1]     |  2  | -              |
 30  | idx==3, BASE CASE         | [3,2,1]     |  2  | -              | [3,2,1]
 31  | Return, swap back (1,1)   | [3,2,1]     |  1  | no change      |
 32  | swap(1,2)                 | [3,1,2]     |  1  | 2<->1          |
 33  | Enter recursion           | [3,1,2]     |  2  | -              |
 34  | idx==3, BASE CASE         | [3,1,2]     |  2  | -              | [3,1,2]
 35  | Return, swap back (1,2)   | [3,2,1]     |  1  | 1<->2          |
 36  | Return to idx=0           | [3,2,1]     |  0  | -              |
 37  | swap back (0,2)           | [1,2,3]     |  0  | 3<->1          |
 38  | DONE!                     | [1,2,3]     |  -  | -              |

FINAL OUTPUT ORDER: [1,2,3], [1,3,2], [2,1,3], [2,3,1], [3,2,1], [3,1,2]
                    (All 6 = 3! permutations generated!)


================================================================================
          WHY THE ARRAY IS ALWAYS RESTORED (BACKTRACKING GUARANTEE)
================================================================================

Visual proof that backtracking restores original state:

    Original: [1, 2, 3]

    Path 1: swap(0,0) -> [1,2,3] -> swap(1,1) -> [1,2,3] -> OUTPUT [1,2,3]
                                 <- swap(1,1) <- [1,2,3]
                                    swap(1,2) -> [1,3,2] -> OUTPUT [1,3,2]
                                 <- swap(1,2) <- [1,2,3]
         <- swap(0,0) <- [1,2,3] (RESTORED!)

    Path 2: swap(0,1) -> [2,1,3] -> swap(1,1) -> [2,1,3] -> OUTPUT [2,1,3]
                                 <- swap(1,1) <- [2,1,3]
                                    swap(1,2) -> [2,3,1] -> OUTPUT [2,3,1]
                                 <- swap(1,2) <- [2,1,3]
         <- swap(0,1) <- [1,2,3] (RESTORED!)

    Path 3: swap(0,2) -> [3,2,1] -> swap(1,1) -> [3,2,1] -> OUTPUT [3,2,1]
                                 <- swap(1,1) <- [3,2,1]
                                    swap(1,2) -> [3,1,2] -> OUTPUT [3,1,2]
                                 <- swap(1,2) <- [3,2,1]
         <- swap(0,2) <- [1,2,3] (RESTORED!)

    Final state: [1, 2, 3] (same as original!)


================================================================================
          RECURSION TREE STRUCTURE SUMMARY
================================================================================

For an array of n elements:

    Level 0: 1 node, n branches (fix position 0)
                  |
                  v
    Level 1: n nodes, each with (n-1) branches (fix position 1)
                  |
                  v
    Level 2: n*(n-1) nodes, each with (n-2) branches (fix position 2)
                  |
                  v
        ...continues...
                  |
                  v
    Level n-1: n! nodes, each with 1 branch (fix last position)
                  |
                  v
    Level n: n! leaf nodes = n! PERMUTATIONS

    For n=3:
        Level 0: 1 node
        Level 1: 3 nodes
        Level 2: 6 nodes
        Level 3: 6 leaf nodes = 6 permutations = 3!
"""


# =============================================================================
# SECTION 7: DRY RUN #2 - SMALLER EXAMPLE [1,2] WITH FULL TRACE
# =============================================================================
"""
================================================================================
             COMPLETE DRY RUN FOR permutations([1,2])
================================================================================

Input: arr = [1, 2]
Expected output: 2! = 2 permutations: [1,2] and [2,1]

RECURSION TREE:
--------------

                         permute(arr=[1,2], idx=0)
                                    |
                    +---------------+---------------+
                    |                               |
               swap(0,0)                       swap(0,1)
               [1,2] (no change)               [2,1]
               idx=1                           idx=1
                    |                               |
             +------+                        +------+
             |                               |
        swap(1,1)                       swap(1,1)
        [1,2] (no change)               [2,1] (no change)
        idx=2                           idx=2
             |                               |
        idx==len(arr)                   idx==len(arr)
        [DONE!]                         [DONE!]
             |                               |
        OUTPUT: [1,2]                   OUTPUT: [2,1]
        PERM #1                         PERM #2


DETAILED CALL STACK TRACE:
-------------------------

CALL 1: permute([1,2], idx=0)
    |
    +-- j=0 (j ranges from idx=0 to len-1=1)
    |   |
    |   +-- swap(arr[0], arr[0]): [1,2] stays [1,2]
    |   |
    |   +-- CALL 2: permute([1,2], idx=1)
    |   |       |
    |   |       +-- j=1 (j ranges from idx=1 to len-1=1)
    |   |       |   |
    |   |       |   +-- swap(arr[1], arr[1]): [1,2] stays [1,2]
    |   |       |   |
    |   |       |   +-- CALL 3: permute([1,2], idx=2)
    |   |       |   |       |
    |   |       |   |       +-- idx=2 == len=2 --> BASE CASE!
    |   |       |   |       +-- APPEND "12" to result
    |   |       |   |       +-- RETURN
    |   |       |   |
    |   |       |   +-- swap back(arr[1], arr[1]): [1,2] stays [1,2]
    |   |       |
    |   |       +-- j loop ends (j was 1, no j=2)
    |   |       +-- RETURN
    |   |
    |   +-- swap back(arr[0], arr[0]): [1,2] stays [1,2]
    |
    +-- j=1
        |
        +-- swap(arr[0], arr[1]): [1,2] becomes [2,1]
        |
        +-- CALL 4: permute([2,1], idx=1)
        |       |
        |       +-- j=1 (j ranges from idx=1 to len-1=1)
        |       |   |
        |       |   +-- swap(arr[1], arr[1]): [2,1] stays [2,1]
        |       |   |
        |       |   +-- CALL 5: permute([2,1], idx=2)
        |       |   |       |
        |       |   |       +-- idx=2 == len=2 --> BASE CASE!
        |       |   |       +-- APPEND "21" to result
        |       |   |       +-- RETURN
        |       |   |
        |       |   +-- swap back(arr[1], arr[1]): [2,1] stays [2,1]
        |       |
        |       +-- j loop ends
        |       +-- RETURN
        |
        +-- swap back(arr[0], arr[1]): [2,1] becomes [1,2] (RESTORED!)

FINAL RESULT: ["12", "21"] = [1,2] and [2,1]


STATE TRANSITION TABLE:
----------------------

Step | Location          | arr    | idx | j | Action              | result
-----|-------------------|--------|-----|---|---------------------|--------
  1  | permute entry     | [1,2]  |  0  | 0 | swap(0,0)           | []
  2  | permute entry     | [1,2]  |  1  | 1 | swap(1,1)           | []
  3  | BASE CASE         | [1,2]  |  2  | - | append              | [[1,2]]
  4  | backtrack         | [1,2]  |  1  | 1 | swap back(1,1)      | [[1,2]]
  5  | backtrack         | [1,2]  |  0  | 0 | swap back(0,0)      | [[1,2]]
  6  | next iteration    | [1,2]  |  0  | 1 | swap(0,1)->[2,1]    | [[1,2]]
  7  | permute entry     | [2,1]  |  1  | 1 | swap(1,1)           | [[1,2]]
  8  | BASE CASE         | [2,1]  |  2  | - | append              | [[1,2],[2,1]]
  9  | backtrack         | [2,1]  |  1  | 1 | swap back(1,1)      | [[1,2],[2,1]]
 10  | backtrack         | [1,2]  |  0  | 1 | swap back(0,1)      | [[1,2],[2,1]]
 11  | DONE              | [1,2]  |  -  | - | -                   | [[1,2],[2,1]]

"""


# =============================================================================
# SECTION 8: WHY SWAP WORKS - DEEP UNDERSTANDING
# =============================================================================
"""
WHY DOESN'T SWAP METHOD PRODUCE DUPLICATES?
--------------------------------------------

Key Insight: At each level (idx), we're deciding which REMAINING element
             goes into position `idx`. Each element gets exactly ONE chance.

Visual for "ABC" at idx=0:
--------------------------
Available positions: [0] [1] [2]
                      A   B   C

We try EACH character at position 0:
  - swap(0,0): A at position 0  (A with itself)
  - swap(0,1): B at position 0  (B swapped to front)
  - swap(0,2): C at position 0  (C swapped to front)

After fixing position 0, we recurse with idx=1.
Now only positions 1 and 2 are "available" for arrangement.

WHY ALL ARRANGEMENTS ARE COVERED?
---------------------------------
Think recursively:
  - Level 0: n choices for position 0
  - Level 1: n-1 choices for position 1 (from remaining)
  - Level 2: n-2 choices for position 2 (from remaining)
  - ...
  - Level n-1: 1 choice for last position

Total leaf nodes = n * (n-1) * (n-2) * ... * 1 = n!

VISUAL PROOF FOR "AB":
----------------------
           f("AB", 0)
          /          \
    swap(0,0)      swap(0,1)
    A at pos 0     B at pos 0
        |              |
   f("AB", 1)     f("BA", 1)
        |              |
   swap(1,1)      swap(1,1)
   B at pos 1     A at pos 1
        |              |
      "AB"           "BA"

2 permutations = 2!  [Correct!]

Each element appears at each position exactly once across all permutations:
  - A at position 0: "AB"
  - A at position 1: "BA"
  - B at position 0: "BA"
  - B at position 1: "AB"

WHY BACKTRACKING (SWAP BACK) IS ESSENTIAL?
------------------------------------------

Without swapping back, subsequent iterations would work on modified strings!

Example (WRONG - without swap back):
  swap(0,1): "AB" -> "BA"
  recurse...
  NOW: swap(0,2) operates on "BA" instead of "AB"!
  This gives WRONG results.

Example (CORRECT - with swap back):
  swap(0,1): "AB" -> "BA"
  recurse...
  swap back(0,1): "BA" -> "AB"  <-- Restore!
  NOW: swap(0,2) operates on "AB" (original)
  Correct results!

ANALOGY: TRYING ON CLOTHES
--------------------------
Imagine trying different shirts at position 0:
  1. Pick shirt A, try it on
  2. Decide the rest of the outfit (recurse)
  3. PUT SHIRT A BACK (backtrack)
  4. Pick shirt B, try it on
  5. Decide the rest of the outfit (recurse)
  6. PUT SHIRT B BACK (backtrack)
  ... and so on

If you don't put shirts back, you can't try other combinations!
"""


# =============================================================================
# SECTION 9: COMPLEXITY ANALYSIS
# =============================================================================
"""
TIME COMPLEXITY ANALYSIS:
-------------------------

For both approaches:

1. Number of permutations = n!
   - Each recursive path from root to leaf produces one permutation

2. Work at each leaf = O(n)
   - Copying the string/list to result takes O(n)

3. Total time = O(n! * n)

More detailed analysis:
- At level 0: 1 node, n loop iterations
- At level 1: n nodes, each with n-1 loop iterations
- At level 2: n*(n-1) nodes, each with n-2 loop iterations
- ...
- At level n-1: n! nodes, 1 loop iteration each

Total recursive calls = 1 + n + n*(n-1) + ... + n!
                      = sum of n!/k! for k from 0 to n
                      ~ e * n! (approximately)
                      = O(n!)

But since we do O(n) work at each leaf: O(n! * n)

SPACE COMPLEXITY ANALYSIS:
--------------------------

Approach 1 (Visited Array):
  - Visited array: O(n)
  - Current permutation string: O(n)
  - Recursion stack depth: O(n)
  - Result storage: O(n! * n) - but usually not counted as auxiliary

  Auxiliary Space = O(n)

Approach 2 (Swap Method):
  - No visited array needed
  - In-place modification (no extra string)
  - Recursion stack depth: O(n)
  - Result storage: O(n! * n) - but usually not counted

  Auxiliary Space = O(n) - just the recursion stack!

COMPARISON:
-----------
Both have same time complexity, but swap method uses less auxiliary space
because it doesn't need a visited array or extra string buffer.
"""


# =============================================================================
# SECTION 10: COMPARISON TABLE
# =============================================================================
"""
+--------------------+------------------------+------------------------+
|      Aspect        |    Visited Array       |     Swap Method        |
+--------------------+------------------------+------------------------+
| Extra Space        | O(n) for visited[]     | O(1) (no extra)        |
|                    | + O(n) for current     |                        |
+--------------------+------------------------+------------------------+
| Intuition          | Build a new string     | Modify string in-place |
|                    | character by character | by swapping            |
+--------------------+------------------------+------------------------+
| String Handling    | Keep original intact   | Modify and restore     |
+--------------------+------------------------+------------------------+
| Code Complexity    | Slightly more code     | Simpler, elegant       |
+--------------------+------------------------+------------------------+
| Interview          | Good starting point    | Better / Optimal       |
| Preference         |                        |                        |
+--------------------+------------------------+------------------------+
| Order of Output    | Lexicographic-ish      | Based on swap order    |
+--------------------+------------------------+------------------------+
| Handling           | Easy with small        | Slightly trickier      |
| Duplicates         | modification           |                        |
+--------------------+------------------------+------------------------+
| When to Use        | Need original intact   | Space is a concern     |
|                    | or clearer logic       | or want optimal        |
+--------------------+------------------------+------------------------+

INTERVIEW TIP:
--------------
1. Start by mentioning both approaches
2. Explain trade-offs
3. Implement the swap method (optimal)
4. If asked about duplicates, explain the sorting + skip technique
"""


# =============================================================================
# SECTION 11: IMPLEMENTATIONS
# =============================================================================

from typing import List


def permutations_with_map(s: str) -> List[str]:
    """
    Approach 1: Generate all permutations using a visited array.

    Algorithm:
    - Use a boolean visited[] array to track which characters are used
    - Build permutation one character at a time
    - At each step, try all unused characters
    - When current permutation length equals input length, we have a complete permutation

    Time Complexity: O(n! * n)
    Space Complexity: O(n) auxiliary space (visited array + recursion stack)

    Args:
        s: Input string to permute

    Returns:
        List of all permutations
    """
    result = []  # Stores all permutations
    n = len(s)

    if n == 0:
        return [""]  # Edge case: empty string has one permutation (itself)

    visited = [False] * n  # Track which characters are used

    def backtrack(current: str):
        """
        Recursive helper function to build permutations.

        Args:
            current: The permutation being built so far
        """
        # BASE CASE: If current has all characters, we found a complete permutation
        if len(current) == n:
            result.append(current)
            return

        # RECURSIVE CASE: Try adding each unused character
        for i in range(n):
            if not visited[i]:  # Only use characters not yet in current permutation
                # CHOOSE: Mark this character as used
                visited[i] = True

                # EXPLORE: Recurse with this character added
                backtrack(current + s[i])

                # UNCHOOSE (BACKTRACK): Unmark to try other possibilities
                visited[i] = False

    # Start with empty permutation
    backtrack("")

    return result


def permutations_swap(s: str) -> List[str]:
    """
    Approach 2: Generate all permutations using in-place swaps (OPTIMAL).

    Algorithm:
    - Convert string to list (strings are immutable in Python)
    - Fix one position at a time from left to right
    - At position idx, try swapping with each position from idx to end
    - After recursion, swap back to restore original state

    Key Insight: At each level, we're deciding which character goes at position idx.
                 By swapping, we bring different characters to position idx.

    Time Complexity: O(n! * n)
    Space Complexity: O(n) for recursion stack only (no extra visited array!)

    Args:
        s: Input string to permute

    Returns:
        List of all permutations
    """
    result = []
    n = len(s)

    if n == 0:
        return [""]  # Edge case: empty string

    # Convert to list since strings are immutable in Python
    chars = list(s)

    def backtrack(idx: int):
        """
        Recursive helper using swap approach.

        Args:
            idx: Current position we're fixing (0 to n-1)
        """
        # BASE CASE: All positions fixed, we have a complete permutation
        if idx == n:
            result.append("".join(chars))  # Convert list back to string
            return

        # RECURSIVE CASE: Try each character at position idx
        for j in range(idx, n):  # j goes from idx to n-1
            # SWAP: Bring character at position j to position idx
            chars[idx], chars[j] = chars[j], chars[idx]

            # EXPLORE: Recurse to fix next position
            backtrack(idx + 1)

            # SWAP BACK (BACKTRACK): Restore original arrangement
            chars[idx], chars[j] = chars[j], chars[idx]

    # Start fixing from position 0
    backtrack(0)

    return result


def permutations_swap_unique(s: str) -> List[str]:
    """
    Approach 3: Generate UNIQUE permutations using swaps (handles duplicates).

    For inputs like "AAB", naive approach generates duplicates:
    - Swap position 0 with position 0 (A): gives permutations starting with A
    - Swap position 0 with position 1 (A): gives SAME permutations starting with A!

    Solution: At each level, don't swap if we've already placed the same character
              at the current position. Use a set to track characters used at each level.

    Time Complexity: O(n! * n) worst case, but better with duplicates
    Space Complexity: O(n) for recursion stack + O(k) for set at each level where k <= 26

    Args:
        s: Input string to permute (may contain duplicates)

    Returns:
        List of all UNIQUE permutations
    """
    result = []
    n = len(s)

    if n == 0:
        return [""]

    chars = list(s)

    def backtrack(idx: int):
        """
        Recursive helper with duplicate handling.

        Args:
            idx: Current position we're fixing
        """
        # BASE CASE
        if idx == n:
            result.append("".join(chars))
            return

        # Set to track which characters we've already placed at position idx
        # This prevents placing the same character at idx multiple times
        used_at_this_level = set()

        for j in range(idx, n):
            # Skip if we've already placed this character at position idx
            if chars[j] in used_at_this_level:
                continue

            # Mark this character as used at this level
            used_at_this_level.add(chars[j])

            # Swap, recurse, swap back
            chars[idx], chars[j] = chars[j], chars[idx]
            backtrack(idx + 1)
            chars[idx], chars[j] = chars[j], chars[idx]

    backtrack(0)

    return result


def permutations_with_sorting(s: str) -> List[str]:
    """
    Alternative approach for unique permutations: Sort first, then skip duplicates.

    This approach uses the visited array method with an additional check:
    - Sort the input string first
    - When iterating, skip a character if it's the same as the previous one
      AND the previous one hasn't been used yet (this prevents duplicates)

    The logic: If we're about to use character at index i, and character at i-1
    is the same but not used, that means we already explored the branch where
    i-1 was used before i. So skip to avoid duplicate permutations.

    Time Complexity: O(n! * n)
    Space Complexity: O(n)

    Args:
        s: Input string (may have duplicates)

    Returns:
        List of unique permutations in sorted order
    """
    result = []
    n = len(s)

    if n == 0:
        return [""]

    # Sort the string to bring duplicates together
    sorted_chars = sorted(s)
    visited = [False] * n

    def backtrack(current: str):
        if len(current) == n:
            result.append(current)
            return

        for i in range(n):
            # Skip if already used
            if visited[i]:
                continue

            # Skip duplicates: if current char equals previous char
            # AND previous char is not used, skip to avoid duplicate permutations
            # This works because if previous is not used, we would have already
            # generated permutations with previous char before current char
            if i > 0 and sorted_chars[i] == sorted_chars[i-1] and not visited[i-1]:
                continue

            visited[i] = True
            backtrack(current + sorted_chars[i])
            visited[i] = False

    backtrack("")

    return result


# =============================================================================
# SECTION 12: HANDLING DUPLICATES - DETAILED EXPLANATION
# =============================================================================
"""
THE DUPLICATE PROBLEM:
----------------------

For input "AAB", naive swap method generates:

Level 0 (idx=0):
  - swap(0,0): 'A' at position 0 -> generates ["AAB", "ABA"]
  - swap(0,1): 'A' at position 0 -> generates ["AAB", "ABA"]  <-- DUPLICATE!
  - swap(0,2): 'B' at position 0 -> generates ["BAA"]

Total without handling: ["AAB", "ABA", "AAB", "ABA", "BAA"] -- has duplicates!
Correct unique permutations: ["AAB", "ABA", "BAA"] -- 3!/2! = 3 unique permutations

WHY DOES THIS HAPPEN?
---------------------
When we have "AAB":
  - Swapping position 0 with position 0 puts 'A' (first A) at position 0
  - Swapping position 0 with position 1 puts 'A' (second A) at position 0

Both result in the SAME character at position 0, leading to identical subtrees!

SOLUTION 1: USE A SET AT EACH LEVEL (Implemented above)
--------------------------------------------------------
At each recursion level, track which CHARACTERS (not indices) we've placed:

  for j in range(idx, n):
      if chars[j] in used_at_this_level:  # Already placed this char here
          continue
      used_at_this_level.add(chars[j])
      # swap, recurse, swap back

This ensures each unique character is placed at each position only once.

SOLUTION 2: SORT + SKIP ADJACENT (Implemented above)
----------------------------------------------------
1. Sort the input: "AAB" -> ['A', 'A', 'B']
2. When building permutation, skip s[i] if:
   - s[i] == s[i-1], AND
   - s[i-1] is not used (visited[i-1] == False)

Why this condition?
  - If previous same character is USED, current is in a valid subtree
  - If previous same character is NOT USED, we'd be starting a duplicate subtree
  - We only want to use the "second A" after the "first A" has been chosen

VISUAL FOR "AAB" WITH SORTING:
------------------------------
Sorted: ['A', 'A', 'B'] at indices [0, 1, 2]

Building permutation:
  - Try index 0 ('A'): OK, use it
  - Try index 1 ('A'): Same as index 0, and index 0 not used?
                       SKIP! (would create duplicate)
  - Try index 2 ('B'): OK, use it

After using index 0:
  - Try index 1 ('A'): Same as index 0, but index 0 IS used. OK!
  - Try index 2 ('B'): OK, use it

This naturally generates only unique permutations.

COMPARISON OF DUPLICATE HANDLING:
---------------------------------
+-------------------+------------------+------------------+
| Method            | Pros             | Cons             |
+-------------------+------------------+------------------+
| Set at each level | Simple logic     | O(k) space per   |
| (swap method)     | Works with swap  | level (k=unique) |
+-------------------+------------------+------------------+
| Sort + Skip       | Classic approach | Requires sorting |
| (visited method)  | Well-known       | O(n log n) init  |
+-------------------+------------------+------------------+
"""


# =============================================================================
# SECTION 13: TEST CASES
# =============================================================================

def test_permutations():
    """
    Comprehensive test cases for all permutation functions.
    """
    print("=" * 60)
    print("TESTING PERMUTATION FUNCTIONS")
    print("=" * 60)

    # Test Case 1: Single character
    print("\nTest 1: Single character 'A'")
    print("-" * 40)
    result = permutations_swap("A")
    print(f"  Input: 'A'")
    print(f"  Expected: ['A']")
    print(f"  Got: {result}")
    print(f"  Count: {len(result)} (expected: 1! = 1)")
    assert result == ["A"], "Test 1 failed!"
    print("  PASSED!")

    # Test Case 2: Two characters
    print("\nTest 2: Two characters 'AB'")
    print("-" * 40)
    result = permutations_swap("AB")
    print(f"  Input: 'AB'")
    print(f"  Expected: ['AB', 'BA'] (in some order)")
    print(f"  Got: {result}")
    print(f"  Count: {len(result)} (expected: 2! = 2)")
    assert len(result) == 2, "Test 2 failed!"
    assert set(result) == {"AB", "BA"}, "Test 2 failed!"
    print("  PASSED!")

    # Test Case 3: Three characters
    print("\nTest 3: Three characters 'ABC'")
    print("-" * 40)
    result = permutations_swap("ABC")
    expected = {"ABC", "ACB", "BAC", "BCA", "CAB", "CBA"}
    print(f"  Input: 'ABC'")
    print(f"  Expected: 6 permutations")
    print(f"  Got: {result}")
    print(f"  Count: {len(result)} (expected: 3! = 6)")
    assert len(result) == 6, "Test 3 failed!"
    assert set(result) == expected, "Test 3 failed!"
    print("  PASSED!")

    # Test Case 4: Empty string
    print("\nTest 4: Empty string ''")
    print("-" * 40)
    result = permutations_swap("")
    print(f"  Input: ''")
    print(f"  Expected: [''] (one empty permutation)")
    print(f"  Got: {result}")
    print(f"  Count: {len(result)} (expected: 1)")
    assert result == [""], "Test 4 failed!"
    print("  PASSED!")

    # Test Case 5: Duplicates - should produce duplicates with basic method
    print("\nTest 5: Duplicates 'AAB' - Testing unique permutation functions")
    print("-" * 40)

    # Basic method produces duplicates
    result_with_dups = permutations_swap("AAB")
    print(f"  Input: 'AAB'")
    print(f"  permutations_swap (has duplicates): {result_with_dups}")
    print(f"  Count: {len(result_with_dups)}")

    # Unique methods should not produce duplicates
    result_unique_1 = permutations_swap_unique("AAB")
    result_unique_2 = permutations_with_sorting("AAB")

    expected_unique = {"AAB", "ABA", "BAA"}
    print(f"  permutations_swap_unique: {result_unique_1}")
    print(f"  permutations_with_sorting: {result_unique_2}")
    print(f"  Expected unique: {expected_unique}")
    print(f"  Unique count: {len(result_unique_1)} (expected: 3!/2! = 3)")

    assert len(result_unique_1) == 3, "Test 5 failed for swap_unique!"
    assert set(result_unique_1) == expected_unique, "Test 5 failed for swap_unique!"
    assert len(result_unique_2) == 3, "Test 5 failed for with_sorting!"
    assert set(result_unique_2) == expected_unique, "Test 5 failed for with_sorting!"
    print("  PASSED!")

    # Test Case 6: Compare both main methods
    print("\nTest 6: Comparing visited array vs swap method for 'XYZ'")
    print("-" * 40)
    result_visited = permutations_with_map("XYZ")
    result_swap = permutations_swap("XYZ")
    print(f"  permutations_with_map: {result_visited}")
    print(f"  permutations_swap: {result_swap}")
    print(f"  Both produce same set: {set(result_visited) == set(result_swap)}")
    assert set(result_visited) == set(result_swap), "Test 6 failed!"
    print("  PASSED!")

    # Test Case 7: Four characters (verify count)
    print("\nTest 7: Four characters 'ABCD'")
    print("-" * 40)
    result = permutations_swap("ABCD")
    print(f"  Input: 'ABCD'")
    print(f"  Count: {len(result)} (expected: 4! = 24)")
    print(f"  First 6: {result[:6]}...")
    assert len(result) == 24, "Test 7 failed!"
    assert len(set(result)) == 24, "Test 7 failed - has duplicates!"
    print("  PASSED!")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


# =============================================================================
# SECTION 14: KEY TAKEAWAYS
# =============================================================================
"""
KEY TAKEAWAYS - MEMORIZE THESE FOR INTERVIEWS:
==============================================

1. TWO APPROACHES TO KNOW:
   -----------------------
   a) Visited Array Method:
      - Build permutation character by character
      - Use visited[] to track used elements
      - Pattern: for each unused char -> mark used -> recurse -> unmark

   b) Swap Method (OPTIMAL):
      - Fix positions from left to right
      - At position i, swap with each position from i to n-1
      - Pattern: swap(i,j) -> recurse(i+1) -> swap back(i,j)

2. SWAP METHOD IS PREFERRED:
   -------------------------
   - Uses O(1) extra space (no visited array)
   - More elegant and concise
   - Same time complexity: O(n! * n)

3. BACKTRACKING IS ESSENTIAL:
   --------------------------
   - Must undo changes after recursion
   - Swap method: swap back to restore string
   - Visited method: unmark visited[i] = False
   - Without backtracking, subsequent iterations fail!

4. HANDLING DUPLICATES:
   --------------------
   - Problem: Same character at different indices leads to duplicate permutations

   - Solution 1 (with swap): Use a set at each level
     if chars[j] in used_at_this_level: continue

   - Solution 2 (with visited): Sort first, skip adjacent duplicates
     if i > 0 and s[i] == s[i-1] and not visited[i-1]: continue

5. COMPLEXITY:
   -----------
   - Time: O(n! * n) for all approaches
     * n! permutations
     * O(n) to copy each permutation to result

   - Space: O(n) for recursion stack
     * Swap method: No extra space beyond stack
     * Visited method: +O(n) for visited array

6. INTERVIEW TIPS:
   ---------------
   a) Always mention both approaches first
   b) Explain why swap is more space-efficient
   c) Code the swap method
   d) If asked about duplicates:
      - Explain the problem (same char at different indices)
      - Show the set-based solution for swap method
      - Mention sorting + skip as alternative
   e) Dry run with a small example ("AB" or "ABC")

7. COMMON MISTAKES TO AVOID:
   -------------------------
   - Forgetting to swap back (backtrack)
   - Off-by-one errors in loop bounds
   - Not handling empty string case
   - Modifying string directly (strings are immutable in Python!)

8. RELATED PROBLEMS:
   -----------------
   - Next Permutation
   - Permutations II (with duplicates)
   - Letter Case Permutation
   - Combination Sum
   - Subsets
   - All variations use similar backtracking patterns!
"""


# =============================================================================
# MAIN EXECUTION
# =============================================================================

if __name__ == "__main__":
    # Run all tests
    test_permutations()

    print("\n")
    print("=" * 60)
    print("DEMONSTRATION: STEP BY STEP")
    print("=" * 60)

    # Demo with visualization
    print("\n1. Basic permutations of 'AB':")
    print("   Using swap method:", permutations_swap("AB"))
    print("   Using visited array:", permutations_with_map("AB"))

    print("\n2. Permutations of 'ABC':")
    result = permutations_swap("ABC")
    print(f"   Total: {len(result)} permutations")
    for i, p in enumerate(result, 1):
        print(f"   {i}. {p}")

    print("\n3. Handling duplicates in 'AAB':")
    print("   Without duplicate handling:", permutations_swap("AAB"))
    print("   With duplicate handling:", permutations_swap_unique("AAB"))

    print("\n4. Permutations of '123':")
    result = permutations_swap("123")
    for p in result:
        print(f"   {p}")
