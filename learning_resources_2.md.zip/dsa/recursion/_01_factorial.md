# Factorial: Your First Recursion Problem

## What is Factorial?

Factorial of a number `n` (written as `n!`) is the product of all positive integers from 1 to n.

```
5! = 5 × 4 × 3 × 2 × 1 = 120
4! = 4 × 3 × 2 × 1 = 24
3! = 3 × 2 × 1 = 6
2! = 2 × 1 = 2
1! = 1
0! = 1 (by definition)
```

---

## The Key Insight: Finding the Pattern

Look at this magic:

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   5! = 5 × 4 × 3 × 2 × 1                                   │
│      = 5 × (4 × 3 × 2 × 1)                                 │
│      = 5 × 4!                                              │
│                                                             │
│   In general:  n! = n × (n-1)!                             │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

**This is the recursive relationship!**

---

## Step-by-Step: Building the Solution

### Step 1: What's the Base Case?

The smallest factorial we know directly:

```
┌──────────────────────────────┐
│                              │
│   0! = 1                     │
│   (or)                       │
│   1! = 1                     │
│                              │
│   These are our EXIT DOORS!  │
│                              │
└──────────────────────────────┘
```

### Step 2: What's the Recursive Case?

```
┌──────────────────────────────────────────┐
│                                          │
│   For any n > 1:                         │
│                                          │
│   factorial(n) = n × factorial(n - 1)    │
│                                          │
└──────────────────────────────────────────┘
```

---

## The Code

```python
def factorial(n):
    # Base Case: We know 0! = 1
    if n == 0:
        return 1
    
    # Recursive Case: n! = n × (n-1)!
    return n * factorial(n - 1)
```

---

## Visualizing the Execution: Call Stack

Let's trace `factorial(5)`:

```
┌─────────────────────────────────────────────────────────────────────┐
│                                                                     │
│   PHASE 1: CALLING (Going Down - Building the Stack)                │
│   ═══════════════════════════════════════════════════               │
│                                                                     │
│   factorial(5)                                                      │
│       │                                                             │
│       │ "I need factorial(4) first, let me call it..."              │
│       ▼                                                             │
│   factorial(4)                                                      │
│       │                                                             │
│       │ "I need factorial(3) first..."                              │
│       ▼                                                             │
│   factorial(3)                                                      │
│       │                                                             │
│       │ "I need factorial(2) first..."                              │
│       ▼                                                             │
│   factorial(2)                                                      │
│       │                                                             │
│       │ "I need factorial(1) first..."                              │
│       ▼                                                             │
│   factorial(1)                                                      │
│       │                                                             │
│       │ "I need factorial(0) first..."                              │
│       ▼                                                             │
│   factorial(0)                                                      │
│       │                                                             │
│       └──→ "I'm the BASE CASE! I return 1 directly!"                │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│                                                                     │
│   PHASE 2: RETURNING (Going Up - Unwinding the Stack)               │
│   ════════════════════════════════════════════════════              │
│                                                                     │
│   factorial(0) ──returns──→  1                                      │
│                              ▲                                      │
│                              │                                      │
│   factorial(1) ──returns──→  1 × 1 = 1                              │
│                              ▲                                      │
│                              │                                      │
│   factorial(2) ──returns──→  2 × 1 = 2                              │
│                              ▲                                      │
│                              │                                      │
│   factorial(3) ──returns──→  3 × 2 = 6                              │
│                              ▲                                      │
│                              │                                      │
│   factorial(4) ──returns──→  4 × 6 = 24                             │
│                              ▲                                      │
│                              │                                      │
│   factorial(5) ──returns──→  5 × 24 = 120   ← FINAL ANSWER!         │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## The Call Stack as a Stack of Papers

```
    ┌─────────────────────────────────────────────────────────────────┐
    │                                                                 │
    │   Think of each function call as a paper on a stack:           │
    │                                                                 │
    │   BUILDING UP                      SOLVING & REMOVING           │
    │   ────────────                     ───────────────────          │
    │                                                                 │
    │                                    ┌─────────────────┐          │
    │   ┌─────────────────┐              │ factorial(0)=1  │ ← POP!   │
    │   │ factorial(0)    │              └─────────────────┘          │
    │   ├─────────────────┤              ┌─────────────────┐          │
    │   │ factorial(1)    │              │ factorial(1)=1  │ ← POP!   │
    │   ├─────────────────┤              └─────────────────┘          │
    │   │ factorial(2)    │              ┌─────────────────┐          │
    │   ├─────────────────┤              │ factorial(2)=2  │ ← POP!   │
    │   │ factorial(3)    │              └─────────────────┘          │
    │   ├─────────────────┤              ┌─────────────────┐          │
    │   │ factorial(4)    │              │ factorial(3)=6  │ ← POP!   │
    │   ├─────────────────┤              └─────────────────┘          │
    │   │ factorial(5)    │              ┌─────────────────┐          │
    │   └─────────────────┘              │ factorial(4)=24 │ ← POP!   │
    │         ▲                          └─────────────────┘          │
    │         │                          ┌─────────────────┐          │
    │    Base of stack                   │factorial(5)=120 │ ← DONE!  │
    │                                    └─────────────────┘          │
    │                                                                 │
    └─────────────────────────────────────────────────────────────────┘
```

---

## Recursion Tree for Factorial

Since factorial only makes ONE recursive call, the tree is just a straight line:

```
┌─────────────────────────────────────────────────────────────────────┐
│                                                                     │
│                    FACTORIAL(5) RECURSION TREE                      │
│                    ═══════════════════════════                      │
│                                                                     │
│                        factorial(5)                                 │
│                            │                                        │
│                            │ returns 5 × 24 = 120                   │
│                            │                                        │
│                        factorial(4)                                 │
│                            │                                        │
│                            │ returns 4 × 6 = 24                     │
│                            │                                        │
│                        factorial(3)                                 │
│                            │                                        │
│                            │ returns 3 × 2 = 6                      │
│                            │                                        │
│                        factorial(2)                                 │
│                            │                                        │
│                            │ returns 2 × 1 = 2                      │
│                            │                                        │
│                        factorial(1)                                 │
│                            │                                        │
│                            │ returns 1 × 1 = 1                      │
│                            │                                        │
│                        factorial(0)                                 │
│                            │                                        │
│                            └──→ returns 1 (BASE CASE)               │
│                                                                     │
│   This is called "LINEAR RECURSION" - one branch only!              │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Understanding with the "Trust the Magic" Approach

```
┌─────────────────────────────────────────────────────────────────────┐
│                                                                     │
│   LEAP OF FAITH METHOD                                              │
│   ════════════════════                                              │
│                                                                     │
│   To find factorial(5):                                             │
│                                                                     │
│   1. ASSUME factorial(4) magically gives us 24                      │
│      (Trust that it works!)                                         │
│                                                                     │
│   2. MY job is just to multiply: 5 × 24 = 120                       │
│                                                                     │
│   3. That's it! I don't need to worry about HOW                     │
│      factorial(4) got its answer.                                   │
│                                                                     │
│   ┌────────────────────────────────────────────┐                    │
│   │  "If you can solve the smaller problem,    │                    │
│   │   I can solve the bigger one!"             │                    │
│   └────────────────────────────────────────────┘                    │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Common Mistakes to Avoid

```
┌─────────────────────────────────────────────────────────────────────┐
│                                                                     │
│   ❌ MISTAKE 1: Forgetting the Base Case                            │
│                                                                     │
│   def factorial(n):                                                 │
│       return n * factorial(n - 1)  # INFINITE LOOP!                 │
│                                                                     │
│   ❌ MISTAKE 2: Wrong Base Case Value                               │
│                                                                     │
│   def factorial(n):                                                 │
│       if n == 0:                                                    │
│           return 0  # Should be 1! This breaks everything.          │
│       return n * factorial(n - 1)                                   │
│                                                                     │
│   ❌ MISTAKE 3: Not Shrinking the Problem                           │
│                                                                     │
│   def factorial(n):                                                 │
│       if n == 0:                                                    │
│           return 1                                                  │
│       return n * factorial(n)  # n stays same! INFINITE LOOP!       │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Practice Exercise

Try tracing `factorial(4)` yourself! Fill in the boxes:

```
factorial(4) = 4 × factorial(3)
             = 4 × (3 × factorial(2))
             = 4 × (3 × (2 × factorial(1)))
             = 4 × (3 × (2 × (1 × factorial(0))))
             = 4 × (3 × (2 × (1 × [___])))
             = 4 × (3 × (2 × [___]))
             = 4 × (3 × [___])
             = 4 × [___]
             = [___]

Answer: 24
```

---

## Summary

| Component | Factorial Solution |
|-----------|-------------------|
| **Base Case** | `if n == 0: return 1` |
| **Recursive Case** | `return n * factorial(n-1)` |
| **What shrinks?** | `n` decreases by 1 each call |
| **How to combine?** | Multiply current `n` with result |

**Next:** Check out [_02_fibonacci.md](_02_fibonacci.md) to see a more complex recursion tree!
