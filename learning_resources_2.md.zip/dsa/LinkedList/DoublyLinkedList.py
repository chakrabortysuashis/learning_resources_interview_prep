"""
Doubly Linked List Implementation in Python

A Doubly Linked List is a linear data structure where each element (node)
contains data and TWO references: one to the next node and one to the previous node.
This allows for bidirectional traversal.

VISUAL STRUCTURE:
=================

    HEAD                                                           TAIL
      │                                                              │
      ▼                                                              ▼
    ┌─────────────┐     ┌─────────────┐     ┌─────────────┐     ┌─────────────┐
    │ prev: None  │     │ prev:   ●───┼─────│ prev:   ●───┼─────│ prev:   ●   │
    │ data: 10    │     │ data: 20    │     │ data: 30    │     │ data: 40    │
    │ next:   ●───┼────►│ next:   ●───┼────►│ next:   ●───┼────►│ next: None  │
    └─────────────┘     └─────────────┘     └─────────────┘     └─────────────┘

    Each node stores:
    - data: The actual value
    - next: Pointer to the next node (or None if last node)
    - prev: Pointer to the previous node (or None if first node)

KEY ADVANTAGES OVER SINGLY LINKED LIST:
=======================================
    1. Bidirectional traversal (can go forward AND backward)
    2. O(1) deletion at tail (no need to find second-to-last node)
    3. Easier deletion when you have a reference to the node

TIME COMPLEXITY:
================
    - Access by index: O(n) - but can start from head OR tail!
    - Search: O(n)
    - Insertion at beginning: O(1)
    - Insertion at end: O(1)
    - Insertion at position: O(n)
    - Deletion at beginning: O(1)
    - Deletion at end: O(1)  ← Better than Singly LL!
    - Deletion at position: O(n)

SPACE COMPLEXITY: O(n) - but more memory per node (extra prev pointer)
"""


class Node:
    """
    A single node in the Doubly Linked List.

    VISUAL:
    =======
        ┌─────────────────────────────────────────┐
        │               NODE                       │
        ├──────────────┬───────────┬──────────────┤
        │     prev     │   data    │     next     │
        │ ◄────────────│    42     │────────────► │
        └──────────────┴───────────┴──────────────┘
              ↑                            ↑
        Points to          Value       Points to
        previous                         next
          node                           node
    """

    def __init__(self, data):
        """
        Initialize a new node with given data.

        Args:
            data: The value to store in this node
        """
        self.data = data
        self.next = None
        self.prev = None


class DoublyLinkedList:
    """
    Doubly Linked List implementation with head and tail pointers.

    VISUAL - Empty List:
    ====================
        head = None
        tail = None
        size = 0

    VISUAL - List with elements [10, 20, 30]:
    =========================================
        head                                     tail
          │                                        │
          ▼                                        ▼
        ┌───────────┐    ┌───────────┐    ┌───────────┐
        │None│10│ ●─┼───►│◄─●│20│ ●─┼───►│◄─●│30│None│
        └───────────┘    └───────────┘    └───────────┘

        Simplified view:
        None ◄── [10] ◄──► [20] ◄──► [30] ──► None

        size = 3
    """

    def __init__(self):
        """
        Initialize an empty Doubly Linked List.

        VISUAL:
        =======
            Before: (nothing exists)
            After:  head ──► None
                    tail ──► None
                    size = 0
        """
        self.head = None
        self.tail = None
        self.size = 0

    def __len__(self):
        """Return the number of elements in the list."""
        return self.size

    def is_empty(self):
        """Check if the list is empty."""
        return self.size == 0

    def append(self, data):
        """
        Add a new node with given data at the END of the list.

        Time Complexity: O(1)

        Args:
            data: The value to add

        VISUAL - Adding 40 to [10, 20, 30]:
        ===================================

        BEFORE:
            head                                     tail
              │                                        │
              ▼                                        ▼
            ┌───────────┐    ┌───────────┐    ┌───────────┐
            │None│10│ ●─┼───►│◄─●│20│ ●─┼───►│◄─●│30│None│
            └───────────┘    └───────────┘    └───────────┘

        STEP 1: Create new node
            new_node = Node(40)
            ┌───────────┐
            │None│40│None│
            └───────────┘

        STEP 2: Link bidirectionally
            new_node.prev = tail      (new node's prev points to 30)
            tail.next = new_node      (30's next points to new node)

            ┌───────────┐    ┌───────────┐    ┌───────────┐    ┌───────────┐
            │None│10│ ●─┼───►│◄─●│20│ ●─┼───►│◄─●│30│ ●─┼───►│◄─●│40│None│
            └───────────┘    └───────────┘    └───────────┘    └───────────┘

        STEP 3: Update tail
            tail = new_node

            head                                                        tail
              │                                                           │
              ▼                                                           ▼
            ┌───────────┐    ┌───────────┐    ┌───────────┐    ┌───────────┐
            │None│10│ ●─┼───►│◄─●│20│ ●─┼───►│◄─●│30│ ●─┼───►│◄─●│40│None│
            └───────────┘    └───────────┘    └───────────┘    └───────────┘
        """
        new_node = Node(data)

        if self.is_empty():
            self.head = new_node
            self.tail = new_node
        else:
            new_node.prev = self.tail
            self.tail.next = new_node
            self.tail = new_node

        self.size += 1

    def prepend(self, data):
        """
        Add a new node with given data at the BEGINNING of the list.

        Time Complexity: O(1)

        Args:
            data: The value to add

        VISUAL - Adding 5 to [10, 20, 30]:
        ==================================

        BEFORE:
            head                                     tail
              │                                        │
              ▼                                        ▼
            ┌───────────┐    ┌───────────┐    ┌───────────┐
            │None│10│ ●─┼───►│◄─●│20│ ●─┼───►│◄─●│30│None│
            └───────────┘    └───────────┘    └───────────┘

        STEP 1: Create new node
            new_node = Node(5)
            ┌───────────┐
            │None│ 5│None│
            └───────────┘

        STEP 2: Link bidirectionally
            new_node.next = head      (new node's next points to 10)
            head.prev = new_node      (10's prev points to new node)

            ┌───────────┐    ┌───────────┐    ┌───────────┐    ┌───────────┐
            │None│ 5│ ●─┼───►│◄─●│10│ ●─┼───►│◄─●│20│ ●─┼───►│◄─●│30│None│
            └───────────┘    └───────────┘    └───────────┘    └───────────┘

        STEP 3: Update head
            head = new_node

            head                                                        tail
              │                                                           │
              ▼                                                           ▼
            ┌───────────┐    ┌───────────┐    ┌───────────┐    ┌───────────┐
            │None│ 5│ ●─┼───►│◄─●│10│ ●─┼───►│◄─●│20│ ●─┼───►│◄─●│30│None│
            └───────────┘    └───────────┘    └───────────┘    └───────────┘
        """
        new_node = Node(data)

        if self.is_empty():
            self.head = new_node
            self.tail = new_node
        else:
            new_node.next = self.head
            self.head.prev = new_node
            self.head = new_node

        self.size += 1

    def insert_at(self, index, data):
        """
        Insert a new node with given data at a specific index.

        Time Complexity: O(n) - But optimized! Starts from closer end.

        Args:
            index: Position to insert (0-indexed)
            data: The value to insert

        Raises:
            IndexError: If index is out of bounds

        VISUAL - Inserting 15 at index 2 in [10, 20, 30, 40]:
        =====================================================

        BEFORE:
            Index:    0            1            2            3
                    ┌───────────┐    ┌───────────┐    ┌───────────┐    ┌───────────┐
                    │None│10│ ●─┼───►│◄─●│20│ ●─┼───►│◄─●│30│ ●─┼───►│◄─●│40│None│
                    └───────────┘    └───────────┘    └───────────┘    └───────────┘

        STEP 1: Navigate to node at index 2 (value 30)
            current = node with data 30

        STEP 2: Create new node and rewire
            new_node = Node(15)

            # Set new node's pointers
            new_node.prev = current.prev    (15's prev → 20)
            new_node.next = current         (15's next → 30)

            # Update surrounding nodes
            current.prev.next = new_node    (20's next → 15)
            current.prev = new_node         (30's prev → 15)

        AFTER:
            Index:    0            1            2            3            4
                    ┌───────────┐  ┌───────────┐  ┌───────────┐  ┌───────────┐  ┌───────────┐
                    │None│10│ ●─┼─►│◄─●│20│ ●─┼─►│◄─●│15│ ●─┼─►│◄─●│30│ ●─┼─►│◄─●│40│None│
                    └───────────┘  └───────────┘  └───────────┘  └───────────┘  └───────────┘
        """
        if index < 0 or index > self.size:
            raise IndexError(f"Index {index} out of bounds for list of size {self.size}")

        if index == 0:
            self.prepend(data)
            return

        if index == self.size:
            self.append(data)
            return

        new_node = Node(data)

        if index <= self.size // 2:
            current = self.head
            for _ in range(index):
                current = current.next
        else:
            current = self.tail
            for _ in range(self.size - 1 - index):
                current = current.prev

        new_node.prev = current.prev
        new_node.next = current
        current.prev.next = new_node
        current.prev = new_node

        self.size += 1

    def delete_at(self, index):
        """
        Delete the node at a specific index.

        Time Complexity: O(n) for middle, O(1) for head/tail

        Args:
            index: Position to delete (0-indexed)

        Returns:
            The data of the deleted node

        Raises:
            IndexError: If index is out of bounds or list is empty

        VISUAL - Deleting node at index 2 in [10, 20, 30, 40]:
        ======================================================

        BEFORE:
            Index:    0            1            2            3
                    ┌───────────┐    ┌───────────┐    ┌───────────┐    ┌───────────┐
                    │None│10│ ●─┼───►│◄─●│20│ ●─┼───►│◄─●│30│ ●─┼───►│◄─●│40│None│
                    └───────────┘    └───────────┘    └───────────┘    └───────────┘

        STEP 1: Navigate to node at index 2 (value 30)
            to_delete = node with data 30

        STEP 2: Rewire surrounding nodes (bypass the node)
            to_delete.prev.next = to_delete.next    (20's next → 40)
            to_delete.next.prev = to_delete.prev    (40's prev → 20)

        VISUAL OF BYPASS:
                           to_delete
                              │
                    ┌─────────▼─────────┐
            ┌───────────┐    ┌───────────┐    ┌───────────┐
            │  │20│  ●──┼────┼───────────┼────►│◄──│40│   │
            └───────────┘    │  │30│     │    └───────────┘
                             └───────────┘
                              (orphaned)

        AFTER:
            Index:    0            1            2
                    ┌───────────┐    ┌───────────┐    ┌───────────┐
                    │None│10│ ●─┼───►│◄─●│20│ ●─┼───►│◄─●│40│None│
                    └───────────┘    └───────────┘    └───────────┘
        """
        if self.is_empty():
            raise IndexError("Cannot delete from an empty list")

        if index < 0 or index >= self.size:
            raise IndexError(f"Index {index} out of bounds for list of size {self.size}")

        if index == 0:
            deleted_data = self.head.data
            self.head = self.head.next
            if self.head is None:
                self.tail = None
            else:
                self.head.prev = None
            self.size -= 1
            return deleted_data

        if index == self.size - 1:
            deleted_data = self.tail.data
            self.tail = self.tail.prev
            self.tail.next = None
            self.size -= 1
            return deleted_data

        if index <= self.size // 2:
            current = self.head
            for _ in range(index):
                current = current.next
        else:
            current = self.tail
            for _ in range(self.size - 1 - index):
                current = current.prev

        deleted_data = current.data
        current.prev.next = current.next
        current.next.prev = current.prev
        self.size -= 1
        return deleted_data

    def pop(self):
        """
        Remove and return the LAST element of the list.

        Time Complexity: O(1) - Unlike Singly LL, we have a prev pointer!

        Returns:
            The data of the removed node

        Raises:
            IndexError: If the list is empty

        VISUAL - Popping from [10, 20, 30]:
        ===================================

        BEFORE:
            head                                     tail
              │                                        │
              ▼                                        ▼
            ┌───────────┐    ┌───────────┐    ┌───────────┐
            │None│10│ ●─┼───►│◄─●│20│ ●─┼───►│◄─●│30│None│
            └───────────┘    └───────────┘    └───────────┘

        STEP 1: Store data to return
            popped_data = tail.data  # 30

        STEP 2: Move tail to previous node
            tail = tail.prev  # tail now points to node 20

        STEP 3: Disconnect old tail
            tail.next = None  # 20's next is now None

        AFTER:
            head              tail
              │                 │
              ▼                 ▼
            ┌───────────┐    ┌───────────┐
            │None│10│ ●─┼───►│◄─●│20│None│
            └───────────┘    └───────────┘

            Returns: 30

        NOTE: This is O(1) because we can access prev directly!
              In Singly LL, this is O(n) because we need to traverse.
        """
        if self.is_empty():
            raise IndexError("Cannot pop from an empty list")

        popped_data = self.tail.data

        if self.size == 1:
            self.head = None
            self.tail = None
        else:
            self.tail = self.tail.prev
            self.tail.next = None

        self.size -= 1
        return popped_data

    def pop_first(self):
        """
        Remove and return the FIRST element of the list.

        Time Complexity: O(1)

        Returns:
            The data of the removed node

        Raises:
            IndexError: If the list is empty
        """
        if self.is_empty():
            raise IndexError("Cannot pop from an empty list")

        popped_data = self.head.data

        if self.size == 1:
            self.head = None
            self.tail = None
        else:
            self.head = self.head.next
            self.head.prev = None

        self.size -= 1
        return popped_data

    def reverse(self):
        """
        Reverse the linked list IN-PLACE.

        Time Complexity: O(n)
        Space Complexity: O(1)

        VISUAL - Reversing [10, 20, 30]:
        ================================

        ALGORITHM: Swap prev and next pointers for each node

        BEFORE:
            head                                     tail
              │                                        │
              ▼                                        ▼
            ┌───────────┐    ┌───────────┐    ┌───────────┐
            │None│10│ ●─┼───►│◄─●│20│ ●─┼───►│◄─●│30│None│
            └───────────┘    └───────────┘    └───────────┘

        FOR EACH NODE: Swap prev and next

        Node 10: prev=None, next=20  →  prev=20, next=None
        Node 20: prev=10, next=30    →  prev=30, next=10
        Node 30: prev=20, next=None  →  prev=None, next=20

        VISUAL AFTER SWAPPING:
            tail                                     head
              │                                        │
              ▼                                        ▼
            ┌───────────┐    ┌───────────┐    ┌───────────┐
            │ ●─│10│None│◄───┼─● │20│ ●─┼────│None│30│ ●─│
            └───────────┘    └───────────┘    └───────────┘

        FINAL: Swap head and tail pointers

        AFTER:
            head                                     tail
              │                                        │
              ▼                                        ▼
            ┌───────────┐    ┌───────────┐    ┌───────────┐
            │None│30│ ●─┼───►│◄─●│20│ ●─┼───►│◄─●│10│None│
            └───────────┘    └───────────┘    └───────────┘
        """
        if self.is_empty() or self.size == 1:
            return

        current = self.head

        while current is not None:
            current.prev, current.next = current.next, current.prev
            current = current.prev

        self.head, self.tail = self.tail, self.head

    def get(self, index):
        """
        Get the data at a specific index.

        Time Complexity: O(n) - but optimized to start from closer end!

        Args:
            index: Position to access (0-indexed)

        Returns:
            The data at the given index

        Raises:
            IndexError: If index is out of bounds

        OPTIMIZATION:
        =============
            If index is in first half → start from head
            If index is in second half → start from tail

            Example: List of size 10
            - index 2: start from head, traverse 2 steps
            - index 8: start from tail, traverse 1 step (10-1-8=1)
        """
        if index < 0 or index >= self.size:
            raise IndexError(f"Index {index} out of bounds for list of size {self.size}")

        if index <= self.size // 2:
            current = self.head
            for _ in range(index):
                current = current.next
        else:
            current = self.tail
            for _ in range(self.size - 1 - index):
                current = current.prev

        return current.data

    def search(self, data):
        """
        Search for a value and return its index.

        Time Complexity: O(n)

        Args:
            data: The value to search for

        Returns:
            Index of the first occurrence, or -1 if not found
        """
        current = self.head
        index = 0
        while current is not None:
            if current.data == data:
                return index
            current = current.next
            index += 1
        return -1

    def display(self):
        """
        Display the linked list in a readable format.

        VISUAL OUTPUT:
        ==============
            None <-> 10 <-> 20 <-> 30 <-> 40 <-> None
        """
        if self.is_empty():
            print("Empty List")
            return

        elements = []
        current = self.head
        while current is not None:
            elements.append(str(current.data))
            current = current.next
        print("None <-> " + " <-> ".join(elements) + " <-> None")

    def display_reverse(self):
        """
        Display the linked list in reverse (from tail to head).

        VISUAL OUTPUT:
        ==============
            None <-> 40 <-> 30 <-> 20 <-> 10 <-> None
        """
        if self.is_empty():
            print("Empty List")
            return

        elements = []
        current = self.tail
        while current is not None:
            elements.append(str(current.data))
            current = current.prev
        print("None <-> " + " <-> ".join(elements) + " <-> None")

    def to_list(self):
        """Convert the linked list to a Python list."""
        result = []
        current = self.head
        while current is not None:
            result.append(current.data)
            current = current.next
        return result

    def __str__(self):
        """String representation of the linked list."""
        if self.is_empty():
            return "DoublyLinkedList: Empty"
        return f"DoublyLinkedList: None <-> {' <-> '.join(map(str, self.to_list()))} <-> None"

    def __repr__(self):
        """Detailed representation of the linked list."""
        return f"DoublyLinkedList(size={self.size}, elements={self.to_list()})"


if __name__ == "__main__":
    print("=" * 60)
    print("        DOUBLY LINKED LIST DEMONSTRATION")
    print("=" * 60)

    dll = DoublyLinkedList()

    print("\n1. Creating list and appending elements [10, 20, 30, 40]:")
    for val in [10, 20, 30, 40]:
        dll.append(val)
    dll.display()

    print("\n2. Prepending 5 at the beginning:")
    dll.prepend(5)
    dll.display()

    print("\n3. Inserting 15 at index 2:")
    dll.insert_at(2, 15)
    dll.display()

    print("\n4. Deleting element at index 3:")
    deleted = dll.delete_at(3)
    print(f"   Deleted value: {deleted}")
    dll.display()

    print("\n5. Popping last element (O(1) in Doubly LL!):")
    popped = dll.pop()
    print(f"   Popped value: {popped}")
    dll.display()

    print("\n6. Popping first element:")
    popped = dll.pop_first()
    print(f"   Popped value: {popped}")
    dll.display()

    print("\n7. Reversing the list:")
    dll.reverse()
    dll.display()

    print("\n8. Displaying in reverse (tail to head):")
    dll.display_reverse()

    print("\n9. Searching for value 15:")
    index = dll.search(15)
    print(f"   Found at index: {index}")

    print("\n10. Getting element at index 1:")
    value = dll.get(1)
    print(f"   Value: {value}")

    print("\n11. List info:")
    print(f"   Size: {len(dll)}")
    print(f"   Is empty: {dll.is_empty()}")
    print(f"   As Python list: {dll.to_list()}")

    print("\n" + "=" * 60)
