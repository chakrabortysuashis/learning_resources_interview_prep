# Linked List - Complete Overview

## What is a Linked List?

A **Linked List** is a linear data structure where elements are stored in **nodes**, and each node points to the next node in the sequence. Unlike arrays, linked list elements are **not stored in contiguous memory locations**.

```
┌─────────────────────────────────────────────────────────────────────┐
│                        ARRAY vs LINKED LIST                         │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ARRAY (Contiguous Memory):                                         │
│  ┌─────┬─────┬─────┬─────┬─────┐                                   │
│  │  10 │  20 │  30 │  40 │  50 │   Memory: [100][101][102][103][104]│
│  └─────┴─────┴─────┴─────┴─────┘                                   │
│                                                                     │
│  LINKED LIST (Non-Contiguous Memory):                               │
│  ┌──────────┐    ┌──────────┐    ┌──────────┐                      │
│  │ 10 | ●──────► │ 20 | ●──────► │ 30 | None│                      │
│  └──────────┘    └──────────┘    └──────────┘                      │
│  Memory: [100]   Memory: [250]   Memory: [400]                      │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Node Structure in Python

```python
class Node:
    def __init__(self, data):
        self.data = data    # Stores the value
        self.next = None    # Pointer to next node (initially None)
```

**Visual Representation of a Node:**
```
┌─────────────────────────┐
│         NODE            │
├───────────┬─────────────┤
│   data    │    next     │
│    42     │     ●───────┼──► (points to next node or None)
└───────────┴─────────────┘
```

---

## Types of Linked Lists

### 1. Singly Linked List
Each node points to the **next** node only. Traversal is **one-directional**.

```
┌─────────────────────────────────────────────────────────────────┐
│                     SINGLY LINKED LIST                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  HEAD                                                    TAIL   │
│   │                                                       │     │
│   ▼                                                       ▼     │
│  ┌────────┐    ┌────────┐    ┌────────┐    ┌────────┐          │
│  │ A | ●──────►│ B | ●──────►│ C | ●──────►│ D |None│          │
│  └────────┘    └────────┘    └────────┘    └────────┘          │
│                                                                 │
│  Direction: ──────────────────────────────────────────────►     │
│              (Can only traverse forward)                        │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 2. Doubly Linked List
Each node points to **both next and previous** nodes. Traversal is **bidirectional**.

```
┌─────────────────────────────────────────────────────────────────┐
│                     DOUBLY LINKED LIST                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  HEAD                                                    TAIL   │
│   │                                                       │     │
│   ▼                                                       ▼     │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐      │
│  │None│ A │ ●───────►│◄── │ B │ ●───────►│◄── │ C │None│      │
│  └──────────────┘    └──────────────┘    └──────────────┘      │
│                                                                 │
│  Direction: ◄─────────────────────────────────────────────►     │
│              (Can traverse both forward and backward)           │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

**Node Structure:**
```
┌─────────────────────────────────────┐
│           DOUBLY NODE               │
├──────────┬───────────┬──────────────┤
│   prev   │   data    │    next      │
│    ◄──── │    42     │ ────►        │
└──────────┴───────────┴──────────────┘
```

### 3. Circular Linked List
The **last node points back to the first node**, forming a circle.

```
┌─────────────────────────────────────────────────────────────────┐
│                    CIRCULAR LINKED LIST                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│         ┌────────────────────────────────────────┐              │
│         │                                        │              │
│         ▼                                        │              │
│        ┌────────┐    ┌────────┐    ┌────────┐   │              │
│        │ A | ●──────►│ B | ●──────►│ C | ●──────┘              │
│        └────────┘    └────────┘    └────────┘                  │
│         ▲                                                       │
│         │                                                       │
│        HEAD                                                     │
│                                                                 │
│  The last node (C) points back to HEAD (A)                     │
│  There is NO None/NULL - it's a continuous loop!               │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Time Complexity Comparison

```
┌──────────────────────────────────────────────────────────────────────┐
│                      TIME COMPLEXITY TABLE                            │
├─────────────────────┬─────────────┬──────────────┬───────────────────┤
│     Operation       │    Array    │ Linked List  │      Notes        │
├─────────────────────┼─────────────┼──────────────┼───────────────────┤
│ Access by Index     │    O(1)     │     O(n)     │ LL needs traversal│
│ Search              │    O(n)     │     O(n)     │ Both need scan    │
│ Insert at Beginning │    O(n)     │     O(1)     │ LL wins! No shift │
│ Insert at End       │    O(1)*    │     O(1)**   │ *Amortized        │
│ Insert at Middle    │    O(n)     │     O(n)     │ LL: O(1) if at pos│
│ Delete at Beginning │    O(n)     │     O(1)     │ LL wins! No shift │
│ Delete at End       │    O(1)     │     O(n)***  │ ***O(1) if doubly │
│ Delete at Middle    │    O(n)     │     O(n)     │ Similar complexity│
└─────────────────────┴─────────────┴──────────────┴───────────────────┘

** O(1) if we maintain a tail pointer
*** Singly LL needs O(n) to find the second-to-last node
```

---

## Space Complexity

```
┌────────────────────────────────────────────────────────────────┐
│                     SPACE COMPLEXITY                            │
├────────────────────────────────────────────────────────────────┤
│                                                                │
│  ARRAY:                                                        │
│  Space = n × size_of_element                                   │
│  Extra overhead: Minimal                                       │
│                                                                │
│  LINKED LIST:                                                  │
│  Space = n × (size_of_element + size_of_pointer(s))           │
│  Extra overhead: Each node stores pointer(s)                   │
│                                                                │
│  ┌─────────────────────────────────────────────────────────┐  │
│  │  Singly LL:  1 pointer per node  (next)                 │  │
│  │  Doubly LL:  2 pointers per node (next + prev)          │  │
│  │  In Python:  Each reference is ~8 bytes (64-bit)        │  │
│  └─────────────────────────────────────────────────────────┘  │
│                                                                │
└────────────────────────────────────────────────────────────────┘
```

---

## When to Use Linked Lists?

### ✅ USE Linked List When:
```
┌────────────────────────────────────────────────────────────────┐
│  1. Frequent insertions/deletions at the BEGINNING            │
│  2. You don't know the size in advance (dynamic size)         │
│  3. No need for random access by index                        │
│  4. Memory is fragmented (non-contiguous allocation OK)       │
│  5. Implementing stacks, queues, or graphs                    │
└────────────────────────────────────────────────────────────────┘
```

### ❌ AVOID Linked List When:
```
┌────────────────────────────────────────────────────────────────┐
│  1. Need frequent random access by index                      │
│  2. Memory is a constraint (pointers add overhead)            │
│  3. Cache performance is critical (arrays are cache-friendly) │
│  4. Simple iteration without modifications                    │
└────────────────────────────────────────────────────────────────┘
```

---

## Common Interview Questions

### Easy Level:
1. Reverse a linked list
2. Find the middle element
3. Detect if linked list has a cycle
4. Merge two sorted linked lists
5. Remove duplicates from sorted list

### Medium Level:
1. Add two numbers represented as linked lists
2. Remove Nth node from end
3. Intersection of two linked lists
4. Flatten a multilevel linked list
5. Copy list with random pointer

### Hard Level:
1. Merge K sorted linked lists
2. Reverse nodes in K-group
3. LRU Cache implementation

---

## Key Interview Tips

```
┌─────────────────────────────────────────────────────────────────┐
│                    INTERVIEW CHEAT SHEET                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  🔑 COMMON TECHNIQUES:                                          │
│  ├── Two Pointers (slow/fast for cycle detection, middle)      │
│  ├── Dummy Node (simplifies edge cases at head)                │
│  ├── Recursion (for reversal, merging)                         │
│  └── Hash Map (for cycle detection, intersection)              │
│                                                                 │
│  ⚠️  EDGE CASES TO ALWAYS CHECK:                                │
│  ├── Empty list (head is None)                                 │
│  ├── Single node list                                          │
│  ├── Two node list                                             │
│  └── Operations at head/tail                                   │
│                                                                 │
│  📝 BEFORE CODING:                                              │
│  ├── Clarify: Singly or Doubly linked?                         │
│  ├── Clarify: Do we have a tail pointer?                       │
│  ├── Clarify: Are there duplicates?                            │
│  └── Draw it out! Visual helps avoid pointer mistakes          │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Floyd's Cycle Detection (Tortoise and Hare)

This is a **must-know** algorithm for interviews!

```
┌─────────────────────────────────────────────────────────────────┐
│              FLOYD'S CYCLE DETECTION ALGORITHM                  │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Use TWO POINTERS:                                              │
│  • Slow pointer: moves 1 step at a time                        │
│  • Fast pointer: moves 2 steps at a time                       │
│                                                                 │
│  If there's a cycle, they WILL meet!                           │
│                                                                 │
│  Step 1:        Step 2:        Step 3:        Step 4:          │
│  S              S              S              S                 │
│  F              F                             F                 │
│  ↓              ↓              ↓              ↓                 │
│  A → B → C → D  A → B → C → D  A → B → C → D  A → B → C → D    │
│      ↑     ↓        ↑     ↓        ↑     ↓        ↑     ↓      │
│      └─────┘        └─────┘        └─────┘        └─────┘      │
│                                                                 │
│  slow = A       slow = B       slow = C       slow = D         │
│  fast = A       fast = C       fast = C       fast = D (MEET!) │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

```python
def has_cycle(head):
    slow = fast = head
    while fast and fast.next:
        slow = slow.next
        fast = fast.next.next
        if slow == fast:
            return True
    return False
```

---

## Dummy Node Technique

```
┌─────────────────────────────────────────────────────────────────┐
│                    DUMMY NODE PATTERN                           │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Problem: Operations at head require special handling          │
│                                                                 │
│  Without Dummy:                                                 │
│  ┌────────┐    ┌────────┐    ┌────────┐                        │
│  │ 1 | ●──────►│ 2 | ●──────►│ 3 |None│                        │
│  └────────┘    └────────┘    └────────┘                        │
│   ▲ HEAD (special case when deleting!)                         │
│                                                                 │
│  With Dummy:                                                    │
│  ┌────────┐    ┌────────┐    ┌────────┐    ┌────────┐          │
│  │ # | ●──────►│ 1 | ●──────►│ 2 | ●──────►│ 3 |None│          │
│  └────────┘    └────────┘    └────────┘    └────────┘          │
│   ▲ DUMMY      ▲ Now all nodes can be treated uniformly!       │
│                                                                 │
│  return dummy.next  # Returns actual head                       │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Files in This Directory

| File | Description |
|------|-------------|
| `SinglyLinkedList.py` | Complete implementation of Singly Linked List |
| `DoublyLinkedList.py` | Complete implementation of Doubly Linked List |
| `CircularLinkedList.py` | Complete implementation of Circular Linked List |

Each file contains a fully documented class with visual explanations in docstrings!

---

## Quick Reference - Python Implementation

```python
# Creating a linked list
from SinglyLinkedList import SinglyLinkedList

ll = SinglyLinkedList()
ll.append(10)           # Add to end
ll.append(20)
ll.prepend(5)           # Add to beginning
ll.insert_at(1, 7)      # Insert 7 at index 1
ll.delete_at(2)         # Delete node at index 2
ll.pop()                # Remove and return last element
ll.reverse()            # Reverse the list
ll.display()            # Print the list
```

---

**Happy Coding! 🚀**
