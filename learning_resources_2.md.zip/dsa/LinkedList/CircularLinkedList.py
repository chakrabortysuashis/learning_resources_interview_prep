"""
Circular Linked List Implementation in Python

A Circular Linked List is a variation where the last node points back to the
first node instead of pointing to None, forming a circle/loop.

VISUAL STRUCTURE:
=================

    SINGLY CIRCULAR LINKED LIST:

            ┌────────────────────────────────────────────┐
            │                                            │
            ▼                                            │
          ┌─────────┐     ┌─────────┐     ┌─────────┐   │
          │ data: 10│     │ data: 20│     │ data: 30│   │
          │ next: ●─┼────►│ next: ●─┼────►│ next: ●─┼───┘
          └─────────┘     └─────────┘     └─────────┘
            ▲
            │
           HEAD

    Key difference from regular linked list:
    - The LAST node's next points to HEAD (not None)
    - There is NO None/NULL in the chain
    - You can traverse infinitely in a loop!

WHY USE CIRCULAR LINKED LIST?
=============================
    1. Round-robin scheduling (OS process scheduling)
    2. Circular buffers
    3. Multiplayer games (turn rotation)
    4. Music/video playlist (repeat mode)
    5. Carousel/slideshow implementation

TIME COMPLEXITY:
================
    - Access by index: O(n)
    - Search: O(n)
    - Insertion at beginning: O(1) with tail pointer
    - Insertion at end: O(1) with tail pointer
    - Insertion at position: O(n)
    - Deletion at beginning: O(1) with tail pointer
    - Deletion at end: O(n) - need to find second-to-last
    - Deletion at position: O(n)

SPACE COMPLEXITY: O(n) where n is the number of nodes

IMPORTANT CONSIDERATION:
========================
    We maintain a TAIL pointer instead of HEAD because:
    - tail.next gives us HEAD in O(1)
    - Insertion at both ends becomes O(1)
    - head alone would make insertion at end O(n)
"""


class Node:
    """
    A single node in the Circular Linked List.

    VISUAL:
    =======
        ┌───────────────────────┐
        │        NODE           │
        ├───────────┬───────────┤
        │   data    │   next    │
        │    42     │    ●──────┼──► (next node, NEVER None in circular!)
        └───────────┴───────────┘
    """

    def __init__(self, data):
        """
        Initialize a new node with given data.

        Args:
            data: The value to store in this node
        """
        self.data = data
        self.next = None


class CircularLinkedList:
    """
    Circular Linked List implementation with a tail pointer.

    WHY TAIL POINTER?
    =================
        Using tail pointer gives us O(1) access to both ends:
        - HEAD = tail.next (first element)
        - TAIL = tail (last element)

        If we only had head, appending would be O(n)!

    VISUAL - Empty List:
    ====================
        tail = None
        size = 0

    VISUAL - List with elements [10, 20, 30]:
    =========================================

              ┌────────────────────────────────┐
              │                                │
              ▼                                │
            ┌───────┐    ┌───────┐    ┌───────┐
            │10 | ●─┼───►│20 | ●─┼───►│30 | ●─┼─┘
            └───────┘    └───────┘    └───────┘
              ▲                         ▲
              │                         │
            HEAD                      TAIL
          (tail.next)

        size = 3

    VISUAL - Single element [10]:
    =============================

              ┌─────┐
              │     │
              ▼     │
            ┌───────┐
            │10 | ●─┼─┘ (points to itself!)
            └───────┘
              ▲
              │
           HEAD/TAIL
    """

    def __init__(self):
        """
        Initialize an empty Circular Linked List.

        VISUAL:
        =======
            Before: (nothing exists)
            After:  tail ──► None
                    size = 0
        """
        self.tail = None
        self.size = 0

    def __len__(self):
        """Return the number of elements in the list."""
        return self.size

    def is_empty(self):
        """Check if the list is empty."""
        return self.size == 0

    def _get_head(self):
        """
        Internal method to get the head node.

        Returns:
            The head node, or None if list is empty
        """
        if self.tail is None:
            return None
        return self.tail.next

    def append(self, data):
        """
        Add a new node with given data at the END of the list.

        Time Complexity: O(1) - We have a tail pointer!

        Args:
            data: The value to add

        VISUAL - Adding 40 to [10, 20, 30]:
        ===================================

        BEFORE:
              ┌────────────────────────────────┐
              │                                │
              ▼                                │
            ┌───────┐    ┌───────┐    ┌───────┐
            │10 | ●─┼───►│20 | ●─┼───►│30 | ●─┼─┘
            └───────┘    └───────┘    └───────┘
            HEAD                       TAIL

        STEP 1: Create new node
            new_node = Node(40)
            ┌───────┐
            │40|None│  (temporarily None)
            └───────┘

        STEP 2: Insert new node between tail and head
            new_node.next = tail.next     (40 points to head, which is 10)
            tail.next = new_node          (30 points to 40)

            ┌─────────────────────────────────────────────┐
            │                                             │
            ▼                                             │
            ┌───────┐    ┌───────┐    ┌───────┐    ┌───────┐
            │10 | ●─┼───►│20 | ●─┼───►│30 | ●─┼───►│40 | ●─┼─┘
            └───────┘    └───────┘    └───────┘    └───────┘

        STEP 3: Update tail to new node
            tail = new_node

            ┌─────────────────────────────────────────────┐
            │                                             │
            ▼                                             │
            ┌───────┐    ┌───────┐    ┌───────┐    ┌───────┐
            │10 | ●─┼───►│20 | ●─┼───►│30 | ●─┼───►│40 | ●─┼─┘
            └───────┘    └───────┘    └───────┘    └───────┘
            HEAD                                   TAIL(new)
        """
        new_node = Node(data)

        if self.is_empty():
            new_node.next = new_node
            self.tail = new_node
        else:
            new_node.next = self.tail.next
            self.tail.next = new_node
            self.tail = new_node

        self.size += 1

    def prepend(self, data):
        """
        Add a new node with given data at the BEGINNING of the list.

        Time Complexity: O(1)

        Args:
            data: The value to add

        VISUAL - Adding 5 to [10, 20, 30]:
        ==================================

        BEFORE:
              ┌────────────────────────────────┐
              │                                │
              ▼                                │
            ┌───────┐    ┌───────┐    ┌───────┐
            │10 | ●─┼───►│20 | ●─┼───►│30 | ●─┼─┘
            └───────┘    └───────┘    └───────┘
            HEAD                       TAIL

        STEP 1: Create new node
            new_node = Node(5)

        STEP 2: Insert between tail and current head
            new_node.next = tail.next     (5 points to 10)
            tail.next = new_node          (30 points to 5)

        NOTE: Unlike append, we DON'T update tail!
              The new node becomes HEAD, not TAIL.

        AFTER:
              ┌─────────────────────────────────────────────┐
              │                                             │
              ▼                                             │
            ┌───────┐    ┌───────┐    ┌───────┐    ┌───────┐
            │ 5 | ●─┼───►│10 | ●─┼───►│20 | ●─┼───►│30 | ●─┼─┘
            └───────┘    └───────┘    └───────┘    └───────┘
            HEAD(new)                              TAIL
        """
        new_node = Node(data)

        if self.is_empty():
            new_node.next = new_node
            self.tail = new_node
        else:
            new_node.next = self.tail.next
            self.tail.next = new_node

        self.size += 1

    def insert_at(self, index, data):
        """
        Insert a new node with given data at a specific index.

        Time Complexity: O(n) - Need to traverse to the position

        Args:
            index: Position to insert (0-indexed)
            data: The value to insert

        Raises:
            IndexError: If index is out of bounds

        VISUAL - Inserting 15 at index 2 in [10, 20, 30, 40]:
        =====================================================

        BEFORE:
            Index:    0         1         2         3
              ┌─────────────────────────────────────────────┐
              │                                             │
              ▼                                             │
            ┌───────┐    ┌───────┐    ┌───────┐    ┌───────┐
            │10 | ●─┼───►│20 | ●─┼───►│30 | ●─┼───►│40 | ●─┼─┘
            └───────┘    └───────┘    └───────┘    └───────┘

        STEP 1: Traverse to node at index-1 (index 1, value 20)
            current = node with data 20

        STEP 2: Create and link new node
            new_node = Node(15)
            new_node.next = current.next    (15 points to 30)
            current.next = new_node         (20 points to 15)

        AFTER:
            Index:    0         1         2         3         4
              ┌──────────────────────────────────────────────────────┐
              │                                                      │
              ▼                                                      │
            ┌───────┐  ┌───────┐  ┌───────┐  ┌───────┐  ┌───────┐   │
            │10 | ●─┼─►│20 | ●─┼─►│15 | ●─┼─►│30 | ●─┼─►│40 | ●─┼───┘
            └───────┘  └───────┘  └───────┘  └───────┘  └───────┘
        """
        if index < 0 or index > self.size:
            raise IndexError(f"Index {index} out of bounds for list of size {self.size}")

        if index == 0:
            self.prepend(data)
            return

        if index == self.size:
            self.append(data)
            return

        new_node = Node(data)
        current = self.tail.next

        for _ in range(index - 1):
            current = current.next

        new_node.next = current.next
        current.next = new_node
        self.size += 1

    def delete_at(self, index):
        """
        Delete the node at a specific index.

        Time Complexity: O(n) - Need to traverse to find previous node

        Args:
            index: Position to delete (0-indexed)

        Returns:
            The data of the deleted node

        Raises:
            IndexError: If index is out of bounds or list is empty

        VISUAL - Deleting node at index 2 in [10, 20, 30, 40]:
        ======================================================

        BEFORE:
            Index:    0         1         2         3
              ┌─────────────────────────────────────────────┐
              │                                             │
              ▼                                             │
            ┌───────┐    ┌───────┐    ┌───────┐    ┌───────┐
            │10 | ●─┼───►│20 | ●─┼───►│30 | ●─┼───►│40 | ●─┼─┘
            └───────┘    └───────┘    └───────┘    └───────┘

        STEP 1: Traverse to node at index-1 (value 20)
            prev = node with data 20
            to_delete = prev.next (node with data 30)

        STEP 2: Bypass the node
            prev.next = to_delete.next    (20 now points to 40)

        AFTER:
            Index:    0         1         2
              ┌────────────────────────────────┐
              │                                │
              ▼                                │
            ┌───────┐    ┌───────┐    ┌───────┐
            │10 | ●─┼───►│20 | ●─┼───►│40 | ●─┼─┘
            └───────┘    └───────┘    └───────┘
        """
        if self.is_empty():
            raise IndexError("Cannot delete from an empty list")

        if index < 0 or index >= self.size:
            raise IndexError(f"Index {index} out of bounds for list of size {self.size}")

        if self.size == 1:
            deleted_data = self.tail.data
            self.tail = None
            self.size = 0
            return deleted_data

        if index == 0:
            deleted_data = self.tail.next.data
            self.tail.next = self.tail.next.next
            self.size -= 1
            return deleted_data

        current = self.tail.next
        for _ in range(index - 1):
            current = current.next

        deleted_data = current.next.data

        if current.next == self.tail:
            self.tail = current

        current.next = current.next.next
        self.size -= 1
        return deleted_data

    def pop(self):
        """
        Remove and return the LAST element of the list.

        Time Complexity: O(n) - Need to find second-to-last node

        Returns:
            The data of the removed node

        Raises:
            IndexError: If the list is empty

        VISUAL - Popping from [10, 20, 30]:
        ===================================

        BEFORE:
              ┌────────────────────────────────┐
              │                                │
              ▼                                │
            ┌───────┐    ┌───────┐    ┌───────┐
            │10 | ●─┼───►│20 | ●─┼───►│30 | ●─┼─┘
            └───────┘    └───────┘    └───────┘
            HEAD                       TAIL

        STEP 1: Find second-to-last node
            current = head (10)
            while current.next != tail:
                current = current.next
            # current is now at node 20

        STEP 2: Store data and update pointers
            popped_data = tail.data    # 30
            current.next = head        # 20 now points to 10
            tail = current             # tail now points to 20

        AFTER:
              ┌───────────────────┐
              │                   │
              ▼                   │
            ┌───────┐    ┌───────┐
            │10 | ●─┼───►│20 | ●─┼─┘
            └───────┘    └───────┘
            HEAD          TAIL

            Returns: 30
        """
        if self.is_empty():
            raise IndexError("Cannot pop from an empty list")

        popped_data = self.tail.data

        if self.size == 1:
            self.tail = None
            self.size = 0
            return popped_data

        current = self.tail.next
        while current.next != self.tail:
            current = current.next

        current.next = self.tail.next
        self.tail = current
        self.size -= 1
        return popped_data

    def pop_first(self):
        """
        Remove and return the FIRST element of the list.

        Time Complexity: O(1)

        Returns:
            The data of the removed node

        Raises:
            IndexError: If the list is empty
        """
        if self.is_empty():
            raise IndexError("Cannot pop from an empty list")

        popped_data = self.tail.next.data

        if self.size == 1:
            self.tail = None
        else:
            self.tail.next = self.tail.next.next

        self.size -= 1
        return popped_data

    def reverse(self):
        """
        Reverse the circular linked list IN-PLACE.

        Time Complexity: O(n)
        Space Complexity: O(1)

        VISUAL - Reversing [10, 20, 30]:
        ================================

        ALGORITHM: Similar to singly LL, but handle the circular nature

        BEFORE:
              ┌────────────────────────────────┐
              │                                │
              ▼                                │
            ┌───────┐    ┌───────┐    ┌───────┐
            │10 | ●─┼───►│20 | ●─┼───►│30 | ●─┼─┘
            └───────┘    └───────┘    └───────┘
            HEAD                       TAIL

        STEP 1: Store original head
            original_head = tail.next  (node 10)

        STEP 2: Reverse using three pointers (like singly LL)
            - Start from head
            - Reverse links one by one
            - Stop when we've processed all nodes (count = size)

        STEP 3: Fix the circular link
            - Original head (10) becomes new tail
            - Original tail (30) becomes new head
            - New tail (10) must point to new head (30)

        AFTER:
              ┌────────────────────────────────┐
              │                                │
              ▼                                │
            ┌───────┐    ┌───────┐    ┌───────┐
            │30 | ●─┼───►│20 | ●─┼───►│10 | ●─┼─┘
            └───────┘    └───────┘    └───────┘
            HEAD                       TAIL(was HEAD)
        """
        if self.is_empty() or self.size == 1:
            return

        original_head = self.tail.next

        prev = self.tail
        current = self.tail.next

        for _ in range(self.size):
            next_node = current.next
            current.next = prev
            prev = current
            current = next_node

        self.tail = original_head

    def get(self, index):
        """
        Get the data at a specific index.

        Time Complexity: O(n)

        Args:
            index: Position to access (0-indexed)

        Returns:
            The data at the given index

        Raises:
            IndexError: If index is out of bounds
        """
        if index < 0 or index >= self.size:
            raise IndexError(f"Index {index} out of bounds for list of size {self.size}")

        current = self.tail.next
        for _ in range(index):
            current = current.next
        return current.data

    def search(self, data):
        """
        Search for a value and return its index.

        Time Complexity: O(n)

        Args:
            data: The value to search for

        Returns:
            Index of the first occurrence, or -1 if not found

        IMPORTANT: Must track count to avoid infinite loop!
        """
        if self.is_empty():
            return -1

        current = self.tail.next
        for i in range(self.size):
            if current.data == data:
                return i
            current = current.next
        return -1

    def traverse(self, times=1):
        """
        Traverse the circular list multiple times.

        Args:
            times: Number of complete rotations (default 1)

        Returns:
            List of all values encountered during traversal

        VISUAL - Traverse [10, 20, 30] twice:
        =====================================
            Result: [10, 20, 30, 10, 20, 30]
        """
        if self.is_empty():
            return []

        result = []
        current = self.tail.next
        total_nodes = self.size * times

        for _ in range(total_nodes):
            result.append(current.data)
            current = current.next

        return result

    def rotate(self, k):
        """
        Rotate the list by k positions.

        Time Complexity: O(k)

        Args:
            k: Number of positions to rotate (positive = right, negative = left)

        VISUAL - Rotate [10, 20, 30, 40] by 1 (right):
        ==============================================

        BEFORE:
            HEAD                              TAIL
            10 ──► 20 ──► 30 ──► 40 ──┐
             ▲                        │
             └────────────────────────┘

        AFTER (rotate right by 1, move tail back):
            HEAD                              TAIL
            40 ──► 10 ──► 20 ──► 30 ──┐
             ▲                        │
             └────────────────────────┘

        Rotating right means: tail moves BACKWARD
        Rotating left means: tail moves FORWARD
        """
        if self.is_empty() or self.size == 1 or k == 0:
            return

        k = k % self.size
        if k == 0:
            return

        if k < 0:
            k = self.size + k

        steps_back = self.size - k

        new_tail = self.tail.next
        for _ in range(steps_back - 1):
            new_tail = new_tail.next

        self.tail = new_tail

    def display(self):
        """
        Display the circular linked list in a readable format.

        VISUAL OUTPUT:
        ==============
            10 -> 20 -> 30 -> (back to 10)
        """
        if self.is_empty():
            print("Empty List")
            return

        elements = []
        current = self.tail.next
        for _ in range(self.size):
            elements.append(str(current.data))
            current = current.next

        head_val = self.tail.next.data
        print(" -> ".join(elements) + f" -> (back to {head_val})")

    def to_list(self):
        """Convert the circular linked list to a Python list."""
        if self.is_empty():
            return []

        result = []
        current = self.tail.next
        for _ in range(self.size):
            result.append(current.data)
            current = current.next
        return result

    def __str__(self):
        """String representation of the circular linked list."""
        if self.is_empty():
            return "CircularLinkedList: Empty"
        elements = self.to_list()
        return f"CircularLinkedList: {' -> '.join(map(str, elements))} -> (back to {elements[0]})"

    def __repr__(self):
        """Detailed representation of the circular linked list."""
        return f"CircularLinkedList(size={self.size}, elements={self.to_list()})"


if __name__ == "__main__":
    print("=" * 60)
    print("       CIRCULAR LINKED LIST DEMONSTRATION")
    print("=" * 60)

    cll = CircularLinkedList()

    print("\n1. Creating list and appending elements [10, 20, 30, 40]:")
    for val in [10, 20, 30, 40]:
        cll.append(val)
    cll.display()

    print("\n2. Prepending 5 at the beginning:")
    cll.prepend(5)
    cll.display()

    print("\n3. Inserting 15 at index 2:")
    cll.insert_at(2, 15)
    cll.display()

    print("\n4. Deleting element at index 3:")
    deleted = cll.delete_at(3)
    print(f"   Deleted value: {deleted}")
    cll.display()

    print("\n5. Popping last element:")
    popped = cll.pop()
    print(f"   Popped value: {popped}")
    cll.display()

    print("\n6. Popping first element:")
    popped = cll.pop_first()
    print(f"   Popped value: {popped}")
    cll.display()

    print("\n7. Reversing the list:")
    cll.reverse()
    cll.display()

    print("\n8. Traversing the list 2 times:")
    result = cll.traverse(2)
    print(f"   Result: {result}")

    print("\n9. Rotating right by 1 position:")
    cll.rotate(1)
    cll.display()

    print("\n10. Searching for value 15:")
    index = cll.search(15)
    print(f"   Found at index: {index}")

    print("\n11. Getting element at index 1:")
    value = cll.get(1)
    print(f"   Value: {value}")

    print("\n12. List info:")
    print(f"   Size: {len(cll)}")
    print(f"   Is empty: {cll.is_empty()}")
    print(f"   As Python list: {cll.to_list()}")

    print("\n" + "=" * 60)
    print("          USE CASE: Round-Robin Scheduling")
    print("=" * 60)

    print("\nSimulating process scheduling with [P1, P2, P3]:")
    scheduler = CircularLinkedList()
    for p in ["P1", "P2", "P3"]:
        scheduler.append(p)

    print("Executing 6 time slices:")
    result = scheduler.traverse(2)
    for i, process in enumerate(result):
        print(f"   Time slice {i+1}: Executing {process}")

    print("\n" + "=" * 60)
