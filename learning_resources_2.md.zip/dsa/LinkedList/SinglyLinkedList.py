"""
Singly Linked List Implementation in Python

A Singly Linked List is a linear data structure where each element (node)
contains data and a reference (pointer) to the next node in the sequence.

VISUAL STRUCTURE:
=================

    HEAD                                               TAIL
      │                                                  │
      ▼                                                  ▼
    ┌─────────┐     ┌─────────┐     ┌─────────┐     ┌─────────┐
    │ data: 10│     │ data: 20│     │ data: 30│     │ data: 40│
    │ next: ●─┼────►│ next: ●─┼────►│ next: ●─┼────►│ next:None│
    └─────────┘     └─────────┘     └─────────┘     └─────────┘

    Each node stores:
    - data: The actual value
    - next: Pointer to the next node (or None if last node)

TIME COMPLEXITY:
================
    - Access by index: O(n)
    - Search: O(n)
    - Insertion at beginning: O(1)
    - Insertion at end: O(1) with tail pointer, O(n) without
    - Insertion at position: O(n)
    - Deletion at beginning: O(1)
    - Deletion at end: O(n) - need to find second-to-last
    - Deletion at position: O(n)

SPACE COMPLEXITY: O(n) where n is the number of nodes
"""


class Node:
    """
    A single node in the Singly Linked List.

    VISUAL:
    =======
        ┌───────────────────────┐
        │        NODE           │
        ├───────────┬───────────┤
        │   data    │   next    │
        │    42     │    ●──────┼──► (next node or None)
        └───────────┴───────────┘
    """

    def __init__(self, data):
        """
        Initialize a new node with given data.

        Args:
            data: The value to store in this node
        """
        self.data = data
        self.next = None


class SinglyLinkedList:
    """
    Singly Linked List implementation with head and tail pointers.

    VISUAL - Empty List:
    ====================
        head = None
        tail = None
        size = 0

    VISUAL - List with elements [10, 20, 30]:
    =========================================
        head                              tail
          │                                 │
          ▼                                 ▼
        ┌───────┐    ┌───────┐    ┌───────┐
        │10 | ●─┼───►│20 | ●─┼───►│30|None│
        └───────┘    └───────┘    └───────┘

        size = 3
    """

    def __init__(self):
        """
        Initialize an empty Singly Linked List.

        VISUAL:
        =======
            Before: (nothing exists)
            After:  head ──► None
                    tail ──► None
                    size = 0
        """
        self.head = None
        self.tail = None
        self.size = 0

    def __len__(self):
        """Return the number of elements in the list."""
        return self.size

    def is_empty(self):
        """Check if the list is empty."""
        return self.size == 0

    def append(self, data):
        """
        Add a new node with given data at the END of the list.

        Time Complexity: O(1) - We have a tail pointer!

        Args:
            data: The value to add

        VISUAL - Adding 40 to [10, 20, 30]:
        ===================================

        BEFORE:
            head                              tail
              │                                 │
              ▼                                 ▼
            ┌───────┐    ┌───────┐    ┌───────┐
            │10 | ●─┼───►│20 | ●─┼───►│30|None│
            └───────┘    └───────┘    └───────┘

        STEP 1: Create new node
            new_node = Node(40)
            ┌───────┐
            │40|None│
            └───────┘

        STEP 2: Link current tail to new node
            tail.next = new_node

            head                              tail
              │                                 │
              ▼                                 ▼
            ┌───────┐    ┌───────┐    ┌───────┐    ┌───────┐
            │10 | ●─┼───►│20 | ●─┼───►│30 | ●─┼───►│40|None│
            └───────┘    └───────┘    └───────┘    └───────┘

        STEP 3: Update tail to new node
            tail = new_node

            head                                         tail
              │                                            │
              ▼                                            ▼
            ┌───────┐    ┌───────┐    ┌───────┐    ┌───────┐
            │10 | ●─┼───►│20 | ●─┼───►│30 | ●─┼───►│40|None│
            └───────┘    └───────┘    └───────┘    └───────┘
        """
        new_node = Node(data)

        if self.is_empty():
            self.head = new_node
            self.tail = new_node
        else:
            self.tail.next = new_node
            self.tail = new_node

        self.size += 1

    def prepend(self, data):
        """
        Add a new node with given data at the BEGINNING of the list.

        Time Complexity: O(1)

        Args:
            data: The value to add

        VISUAL - Adding 5 to [10, 20, 30]:
        ==================================

        BEFORE:
            head                              tail
              │                                 │
              ▼                                 ▼
            ┌───────┐    ┌───────┐    ┌───────┐
            │10 | ●─┼───►│20 | ●─┼───►│30|None│
            └───────┘    └───────┘    └───────┘

        STEP 1: Create new node
            new_node = Node(5)
            ┌───────┐
            │ 5|None│
            └───────┘

        STEP 2: Point new node's next to current head
            new_node.next = head

            ┌───────┐    ┌───────┐    ┌───────┐    ┌───────┐
            │ 5 | ●─┼───►│10 | ●─┼───►│20 | ●─┼───►│30|None│
            └───────┘    └───────┘    └───────┘    └───────┘
                         ▲                                ▲
                         │                                │
                        head                             tail

        STEP 3: Update head to new node
            head = new_node

            head                                         tail
              │                                            │
              ▼                                            ▼
            ┌───────┐    ┌───────┐    ┌───────┐    ┌───────┐
            │ 5 | ●─┼───►│10 | ●─┼───►│20 | ●─┼───►│30|None│
            └───────┘    └───────┘    └───────┘    └───────┘
        """
        new_node = Node(data)

        if self.is_empty():
            self.head = new_node
            self.tail = new_node
        else:
            new_node.next = self.head
            self.head = new_node

        self.size += 1

    def insert_at(self, index, data):
        """
        Insert a new node with given data at a specific index.

        Time Complexity: O(n) - Need to traverse to the position

        Args:
            index: Position to insert (0-indexed)
            data: The value to insert

        Raises:
            IndexError: If index is out of bounds

        VISUAL - Inserting 15 at index 2 in [10, 20, 30, 40]:
        =====================================================

        BEFORE:
            Index:    0         1         2         3
            head                                         tail
              │                                            │
              ▼                                            ▼
            ┌───────┐    ┌───────┐    ┌───────┐    ┌───────┐
            │10 | ●─┼───►│20 | ●─┼───►│30 | ●─┼───►│40|None│
            └───────┘    └───────┘    └───────┘    └───────┘

        STEP 1: Traverse to node at index-1 (index 1)
            current = node with data 20

        STEP 2: Create new node
            new_node = Node(15)

        STEP 3: Rewire pointers
            new_node.next = current.next  (new_node points to 30)
            current.next = new_node       (20 points to new_node)

        AFTER:
            Index:    0         1         2         3         4
            head                                                   tail
              │                                                      │
              ▼                                                      ▼
            ┌───────┐    ┌───────┐    ┌───────┐    ┌───────┐    ┌───────┐
            │10 | ●─┼───►│20 | ●─┼───►│15 | ●─┼───►│30 | ●─┼───►│40|None│
            └───────┘    └───────┘    └───────┘    └───────┘    └───────┘
        """
        if index < 0 or index > self.size:
            raise IndexError(f"Index {index} out of bounds for list of size {self.size}")

        if index == 0:
            self.prepend(data)
            return

        if index == self.size:
            self.append(data)
            return

        new_node = Node(data)
        current = self.head

        for _ in range(index - 1):
            current = current.next

        new_node.next = current.next
        current.next = new_node
        self.size += 1

    def delete_at(self, index):
        """
        Delete the node at a specific index.

        Time Complexity: O(n) - Need to traverse to the position

        Args:
            index: Position to delete (0-indexed)

        Returns:
            The data of the deleted node

        Raises:
            IndexError: If index is out of bounds or list is empty

        VISUAL - Deleting node at index 2 in [10, 20, 30, 40]:
        ======================================================

        BEFORE:
            Index:    0         1         2         3
            head                                         tail
              │                                            │
              ▼                                            ▼
            ┌───────┐    ┌───────┐    ┌───────┐    ┌───────┐
            │10 | ●─┼───►│20 | ●─┼───►│30 | ●─┼───►│40|None│
            └───────┘    └───────┘    └───────┘    └───────┘

        STEP 1: Traverse to node at index-1 (index 1)
            prev = node with data 20
            to_delete = prev.next (node with data 30)

        STEP 2: Bypass the node to delete
            prev.next = to_delete.next

            ┌───────┐    ┌───────┐                 ┌───────┐
            │10 | ●─┼───►│20 | ●─┼─────────────────►│40|None│
            └───────┘    └───────┘                 └───────┘
                                      ┌───────┐
                                      │30 | ●─┼───► (orphaned, garbage collected)
                                      └───────┘

        AFTER:
            Index:    0         1         2
            head                              tail
              │                                 │
              ▼                                 ▼
            ┌───────┐    ┌───────┐    ┌───────┐
            │10 | ●─┼───►│20 | ●─┼───►│40|None│
            └───────┘    └───────┘    └───────┘
        """
        if self.is_empty():
            raise IndexError("Cannot delete from an empty list")

        if index < 0 or index >= self.size:
            raise IndexError(f"Index {index} out of bounds for list of size {self.size}")

        if index == 0:
            deleted_data = self.head.data
            self.head = self.head.next
            if self.head is None:
                self.tail = None
            self.size -= 1
            return deleted_data

        current = self.head
        for _ in range(index - 1):
            current = current.next

        deleted_data = current.next.data

        if current.next == self.tail:
            self.tail = current

        current.next = current.next.next
        self.size -= 1
        return deleted_data

    def pop(self):
        """
        Remove and return the LAST element of the list.

        Time Complexity: O(n) - Need to find the second-to-last node

        Returns:
            The data of the removed node

        Raises:
            IndexError: If the list is empty

        VISUAL - Popping from [10, 20, 30]:
        ===================================

        BEFORE:
            head                              tail
              │                                 │
              ▼                                 ▼
            ┌───────┐    ┌───────┐    ┌───────┐
            │10 | ●─┼───►│20 | ●─┼───►│30|None│
            └───────┘    └───────┘    └───────┘

        STEP 1: Find the second-to-last node
            current = head
            while current.next != tail:
                current = current.next
            # current is now at node 20

        STEP 2: Store data to return
            popped_data = tail.data  # 30

        STEP 3: Update tail and disconnect old tail
            tail = current           # tail now points to node 20
            tail.next = None         # disconnect node 30

        AFTER:
            head              tail
              │                 │
              ▼                 ▼
            ┌───────┐    ┌───────┐
            │10 | ●─┼───►│20|None│
            └───────┘    └───────┘

            Returns: 30
        """
        if self.is_empty():
            raise IndexError("Cannot pop from an empty list")

        if self.size == 1:
            popped_data = self.head.data
            self.head = None
            self.tail = None
            self.size = 0
            return popped_data

        current = self.head
        while current.next != self.tail:
            current = current.next

        popped_data = self.tail.data
        self.tail = current
        self.tail.next = None
        self.size -= 1
        return popped_data

    def reverse(self):
        """
        Reverse the linked list IN-PLACE.

        Time Complexity: O(n)
        Space Complexity: O(1)

        VISUAL - Reversing [10, 20, 30]:
        ================================

        ALGORITHM: Use three pointers (prev, current, next_node)

        INITIAL STATE:
            prev = None
            current = head

            prev     current
              │         │
              ▼         ▼
            None      ┌───────┐    ┌───────┐    ┌───────┐
                      │10 | ●─┼───►│20 | ●─┼───►│30|None│
                      └───────┘    └───────┘    └───────┘

        ITERATION 1:
            next_node = current.next  # Save reference to 20
            current.next = prev       # 10 now points to None
            prev = current            # prev moves to 10
            current = next_node       # current moves to 20

                     prev    current
                       │        │
                       ▼        ▼
            ┌───────┐    ┌───────┐    ┌───────┐
            │10|None│    │20 | ●─┼───►│30|None│
            └───────┘    └───────┘    └───────┘

        ITERATION 2:
            next_node = current.next  # Save reference to 30
            current.next = prev       # 20 now points to 10
            prev = current            # prev moves to 20
            current = next_node       # current moves to 30

            ┌───────┐    ┌───────┐           prev    current
            │10|None│◄───┼─● | 20│             │        │
            └───────┘    └───────┘             ▼        ▼
                                         ┌───────┐    ┌───────┐
                                         │20 | ●─┼───►│30|None│
                                         └───────┘    └───────┘

        ITERATION 3:
            next_node = current.next  # Save None
            current.next = prev       # 30 now points to 20
            prev = current            # prev moves to 30
            current = next_node       # current becomes None

        FINAL: Update head and tail
            old_head = self.head
            self.head = prev (which is 30)
            self.tail = old_head (which is 10)

        AFTER:
            head                              tail
              │                                 │
              ▼                                 ▼
            ┌───────┐    ┌───────┐    ┌───────┐
            │30 | ●─┼───►│20 | ●─┼───►│10|None│
            └───────┘    └───────┘    └───────┘
        """
        if self.is_empty() or self.size == 1:
            return

        prev = None
        current = self.head
        self.tail = self.head

        while current is not None:
            next_node = current.next
            current.next = prev
            prev = current
            current = next_node

        self.head = prev

    def get(self, index):
        """
        Get the data at a specific index.

        Time Complexity: O(n)

        Args:
            index: Position to access (0-indexed)

        Returns:
            The data at the given index

        Raises:
            IndexError: If index is out of bounds
        """
        if index < 0 or index >= self.size:
            raise IndexError(f"Index {index} out of bounds for list of size {self.size}")

        current = self.head
        for _ in range(index):
            current = current.next
        return current.data

    def search(self, data):
        """
        Search for a value and return its index.

        Time Complexity: O(n)

        Args:
            data: The value to search for

        Returns:
            Index of the first occurrence, or -1 if not found
        """
        current = self.head
        index = 0
        while current is not None:
            if current.data == data:
                return index
            current = current.next
            index += 1
        return -1

    def display(self):
        """
        Display the linked list in a readable format.

        VISUAL OUTPUT:
        ==============
            10 -> 20 -> 30 -> 40 -> None
        """
        if self.is_empty():
            print("Empty List")
            return

        elements = []
        current = self.head
        while current is not None:
            elements.append(str(current.data))
            current = current.next
        print(" -> ".join(elements) + " -> None")

    def to_list(self):
        """Convert the linked list to a Python list."""
        result = []
        current = self.head
        while current is not None:
            result.append(current.data)
            current = current.next
        return result

    def __str__(self):
        """String representation of the linked list."""
        if self.is_empty():
            return "SinglyLinkedList: Empty"
        return f"SinglyLinkedList: {' -> '.join(map(str, self.to_list()))} -> None"

    def __repr__(self):
        """Detailed representation of the linked list."""
        return f"SinglyLinkedList(size={self.size}, elements={self.to_list()})"


if __name__ == "__main__":
    print("=" * 60)
    print("        SINGLY LINKED LIST DEMONSTRATION")
    print("=" * 60)

    ll = SinglyLinkedList()

    print("\n1. Creating list and appending elements [10, 20, 30, 40]:")
    for val in [10, 20, 30, 40]:
        ll.append(val)
    ll.display()

    print("\n2. Prepending 5 at the beginning:")
    ll.prepend(5)
    ll.display()

    print("\n3. Inserting 15 at index 2:")
    ll.insert_at(2, 15)
    ll.display()

    print("\n4. Deleting element at index 3:")
    deleted = ll.delete_at(3)
    print(f"   Deleted value: {deleted}")
    ll.display()

    print("\n5. Popping last element:")
    popped = ll.pop()
    print(f"   Popped value: {popped}")
    ll.display()

    print("\n6. Reversing the list:")
    ll.reverse()
    ll.display()

    print("\n7. Searching for value 15:")
    index = ll.search(15)
    print(f"   Found at index: {index}")

    print("\n8. Getting element at index 1:")
    value = ll.get(1)
    print(f"   Value: {value}")

    print("\n9. List info:")
    print(f"   Size: {len(ll)}")
    print(f"   Is empty: {ll.is_empty()}")
    print(f"   As Python list: {ll.to_list()}")

    print("\n" + "=" * 60)
