"""
424. Longest Repeating Character Replacement

Problem (simple words)
----------------------
Given a string `s` (uppercase letters) and an integer `k`, we may replace at most
`k` characters in any substring so that all characters in that substring become the same.
Return the maximum possible length of such a substring.

Examples:
- s = "ABAB", k = 2  -> 4
- s = "AABABBA", k = 1 -> 4


1) Brute-force idea
-------------------
Try every substring `s[i:j+1]`.
For each substring:
- Count frequency of each letter/character.
- Let `max_freq` = character having highest frequency in that substring.
- Replacements needed = substring_length - max_freq 
-->
we subtract because we need to minimize the number of character changes to bring all
the characters to the same character/letter.It is wise to choose the character with the highest frequency
as the target character to minimize the number of replacements needed.
- If needed <= k, this substring is valid.
Track the maximum valid length.

Why this works:
- For a substring, best target letter is the most frequent one in that substring.
- We only need to change all other letters.

Complexity:
- O(n^2 * 26) if we maintain freq while expanding `j` for each `i`
- Too slow for n up to 10^5.


2) Optimization thinking
------------------------
Bottleneck in brute force:
- Re-checking too many substrings.

Sliding-window insight:
- Keep a window [left, right].
- Maintain counts of letters in the window.
- Let `max_freq` be the highest count of a single letter seen in this window growth [left,right].
- the window size for current substring is right-left+1
- Replacements needed = substring_length - max_freq = (right - left + 1) - max_freq or 
window_size - max_freq
- If window_size - max_freq > k, window is invalid (need too many changes),
  so move `left` to shrink.

Key formula:
- Replacements needed ->
= window_size of cur substring - character with max freq in current substring
=(right - left + 1) - max_freq

Important note:
- We don't decrease `max_freq` when shrinking.
- This is still correct and keeps O(n) performance because `max_freq` is a
  historical upper bound; it may delay shrinking but never breaks correctness
  of final maximum.

Why NOT decreasing `max_freq` is safe (step-by-step, intuitive)
-----------------------------------------------------------------
1. `max_freq` = the highest single-character count ever seen so far
   (a historical high-water mark), NOT the true max of the current
   window. It only ever goes up, never down.

2. Because it's a historical high, `max_freq` is always >= the true
   max frequency in the current (possibly shrunk) window. So the
   "needed" we compute (window_size - max_freq) is always <= the true
   needed. This means our check is "optimistic": it may accept a
   window as valid slightly too early/too easily, but it can never
   reject a window that is actually valid.

3. Whenever `max_freq` increases to some new value M, it's because we
   just genuinely counted a character M times in the window at that
   moment — and the while-loop already guaranteed size - M <= k right
   then. So `best` gets updated with a length that is 100% truly valid
   at the moment M was set.

4. Later, even if `max_freq` becomes stale (window shrank but M wasn't
   lowered), any window length that still passes the check is never
   bigger than that earlier truly-valid length. To beat the current
   `best`, the window must grow on the right, and growth only happens
   alongside `max_freq` genuinely increasing again (point 3). So a
   stale check can at most re-confirm a length we already proved
   valid — it can't invent a new, larger, impossible length.

5. Net effect: staleness can only delay shrinking (harmless, still
   O(n) since left/right each move forward at most n times total). It
   never lets `best` record a length longer than what was genuinely
   achievable.

Example walkthrough: s = "AABABBA", k = 1
--------------------------------------------
- right=4, window "AABAB" (left=0): freq={'A':3,'B':2}, max_freq=3
  window_size=5, needed = 5-3 = 2 > 1 -> shrink once.
- After shrink, window = "ABAB" (left=1..4): true freq={'A':2,'B':2},
  true max is really 2, but stored max_freq is still 3 (stale).
  - Stale check: needed = 4 - 3 = 1 <= k -> looks "valid", best = 4.
  - True check: needed = 4 - 2 = 2 > k -> actually NOT valid.
- So the stale value wrongly calls "ABAB" valid. But `best = 4` is
  still correct, because "AABA" (seen at right=3) was already a
  genuinely valid window of size 4 (needed = 4-3 = 1 <= k). The
  algorithm just re-confirms a length (4) that was already truly
  achievable — it never claims a length bigger than that.

In short: keeping `max_freq` monotonic (never decreasing it) trades a
small amount of "optimistic looseness" during shrinking for O(1) work
per step, and this looseness never causes `best` to overshoot the true
answer.


3) Optimal algorithm (step-by-step)

-----------------------------------
1. left = 0, max_freq = 0, best = 0
2. For each right in [0..n-1]:
   - Add s[right] to frequency map.
   - Update max_freq = max(max_freq, freq[s[right]])
   - While window_size - max_freq > k:
       remove s[left] from frequency map
       left += 1
   - Update best = max(best, window_size)
3. Return best.


Dry run 1 (step-by-step): s = "ABAB", k = 2
------------------------------------------------
Initialize:
- left = 0, max_freq = 0, best = 0, freq = {}

Step 1: right = 0, s[right] = 'A'
- freq = {'A': 1}
- max_freq = 1
- window = "A" (size = 1)
- needed = 1 - 1 = 0 <= 2 (valid)
- best = 1

Step 2: right = 1, s[right] = 'B'
- freq = {'A': 1, 'B': 1}
- max_freq = 1
- window = "AB" (size = 2)
- needed = 2 - 1 = 1 <= 2 (valid)
- best = 2

Step 3: right = 2, s[right] = 'A'
- freq = {'A': 2, 'B': 1}
- max_freq = 2
- window = "ABA" (size = 3)
- needed = 3 - 2 = 1 <= 2 (valid)
- best = 3

Step 4: right = 3, s[right] = 'B'
- freq = {'A': 2, 'B': 2}
- max_freq = 2
- window = "ABAB" (size = 4)
- needed = 4 - 2 = 2 <= 2 (valid)
- best = 4

Final answer = 4


Dry run 2 (step-by-step): s = "AABABBA", k = 1
-------------------------------------------------
Initialize:
- left = 0, max_freq = 0, best = 0, freq = {}

Step 1: right = 0, char = 'A'
- freq = {'A': 1}, max_freq = 1
- window = "A" (size 1), needed = 0 (valid)
- best = 1

Step 2: right = 1, char = 'A'
- freq = {'A': 2}, max_freq = 2
- window = "AA" (size 2), needed = 0 (valid)
- best = 2

Step 3: right = 2, char = 'B'
- freq = {'A': 2, 'B': 1}, max_freq = 2
- window = "AAB" (size 3), needed = 1 (valid)
- best = 3

Step 4: right = 3, char = 'A'
- freq = {'A': 3, 'B': 1}, max_freq = 3
- window = "AABA" (size 4), needed = 1 (valid)
- best = 4

Step 5: right = 4, char = 'B'
- freq = {'A': 3, 'B': 2}, max_freq = 3
- window = "AABAB" (size 5), needed = 2 (>1, invalid)
- shrink from left:
  - remove s[left] = 'A' -> freq = {'A': 2, 'B': 2}, left = 1
- new window = "ABAB" (size 4), needed = 4 - 3 = 1 (valid)
- best = 4

Step 6: right = 5, char = 'B'
- freq = {'A': 2, 'B': 3}, max_freq = 3
- window = "ABABB" (left=1..5, size 5), needed = 2 (>1)
- shrink from left:
  - remove s[left] = 'A' -> freq = {'A': 1, 'B': 3}, left = 2
- new window = "BABB" (size 4), needed = 1 (valid)
- best = 4

Step 7: right = 6, char = 'A'
- freq = {'A': 2, 'B': 3}, max_freq = 3
- window = "BABBA" (left=2..6, size 5), needed = 2 (>1)
- shrink from left:
  - remove s[left] = 'B' -> freq = {'A': 2, 'B': 2}, left = 3
- new window = "ABBA" (size 4), needed = 1 (valid)
- best = 4

Final answer = 4


Complexities (optimal)
----------------------
- Time: O(n)
  Each character enters the window once (right pointer) and leaves at most once
  (left pointer).
- Space: O(1)
  Frequency table stores at most 26 uppercase English letters.
"""


class Solution:
    def characterReplacement(self, s: str, k: int) -> int:
        """Return max length of a valid window using sliding window + frequency counts."""
        freq = {}  # char -> frequency inside current window
        left = 0
        max_freq = 0  # highest single-char frequency seen during expansion
        best = 0

        for right, ch in enumerate(s):
            # Expand window by including current character.
            freq[ch] = freq.get(ch, 0) + 1

            # Update highest frequency in current growth history.
            max_freq = max(max_freq, freq[ch])

            # If replacements needed exceed k, shrink from the left.
            # Note: max_freq is intentionally NOT decreased while shrinking.
            # It is a historical upper bound that keeps this algorithm O(n).
            while (right - left + 1) - max_freq > k:

                left_char = s[left]
                freq[left_char] -= 1
                left += 1
                # we could have calculate new max_freq here for the new substring [left..right], 
                # but we don't need cause if [left..right] is valid, 
                # then [left+1..right] is also valid, 
                # and we are only interested in the max length of valid substring.
                # now if we increase right and then if the new window is invalid,
                # we already have the best length so far.Our objective is to find the max length 
                # of valid substring, so why we want to shrink left and keep right as is
                # in order to get a valid result.
                # So we can remove the while loop also if needed.
                # Same if [left..right] is invalid, we will shrink until it becomes valid,

            # Current window is valid; update answer.
            best = max(best, right - left + 1)

        return best


# Optional quick sanity checks:
# print(Solution().characterReplacement("ABAB", 2))      # 4
# print(Solution().characterReplacement("AABABBA", 1))   # 4
# print(Solution().characterReplacement("AAAA", 2))      # 4
# print(Solution().characterReplacement("ABCDE", 1))     # 2


"""
4) Improved variant: dropping the `while` loop (using `if` instead)
=====================================================================

The user-provided solution replaces the inner `while` loop with a single
`if`. Below we (a) break down the approach step by step, and (b) do an
extensive, point-wise dry run to build intuition for why this still works.

Approach, step by step
-----------------------
1. Use a fixed-size array `freq_count` of length 26 (one slot per
   uppercase letter) instead of a dict — same idea, just O(1) indexed
   access via `ord(char) - ord('A')`.
2. Track `cur_max_freq` exactly like `max_freq` before: a running,
   monotonic (non-decreasing) historical high of any single letter's
   count seen so far.
3. For every `right`:
   a. Add `s[right]` into `freq_count`, update `cur_max_freq`.
   b. Compute `length_of_cur_substring = right - left + 1` and
      `min_changes = length_of_cur_substring - cur_max_freq`.
   c. If `min_changes > k` (window invalid): remove `s[left]` from
      `freq_count` and advance `left` by 1 — just ONE shrink step,
      no loop. Crucially, do NOT update `max_len` in this branch.
   d. Else (window valid): update `max_len = max(max_len, length_of_cur_substring)`.
4. Return `max_len`.

Why a single `if` (one shrink) is enough instead of a `while` (possibly
many shrinks)
--------------------------------------------------------------------------
- The window size `right - left + 1` can only ever grow by at most 1 per
  iteration (only `right` advances it) and only ever shrink by at most 1
  per iteration (only one `left += 1` happens per iteration, inside the
  `if`). So the window size changes by at most ±1 between consecutive
  iterations of the outer loop.
- Because of that, once the window was valid (or size 0) before this
  iteration, adding one new character can push `min_changes` above `k`
  by at most 1 unit's worth of imbalance — a SINGLE `left += 1` is always
  sufficient to bring it back to "no worse than before". A `while` loop
  would try to shrink further, but there is never a need to, because the
  window never becomes "doubly invalid" in one step.
- In other words: the window size is kept "hovering" at its best-known
  valid size or one more; we never need to collapse it further. This is
  why the `while` degrades safely into an `if`.

Why skipping `max_len` update on the invalid branch is correct
------------------------------------------------------------------
- When `min_changes > k`, this exact window (before the shrink) is not
  valid, so it must not be counted towards `max_len`.
- After shrinking by one on the `left`, the code does NOT recompute
  `length_of_cur_substring` or re-check validity for the shrunk window
  in this same iteration (those two lines are commented out /
  intentionally skipped) — it simply moves on to the next `right`.
- This is safe because `max_len` never needs to shrink: once we've
  recorded some valid length L, we only care about ever finding
  something >= L + 1 later. Whether the immediately-shrunk window is
  valid or not doesn't matter — we'll re-evaluate validity fully on the
  very next iteration when `right` advances again anyway.


Dry run (point-wise, extensive): s = "AABABBA", k = 1
--------------------------------------------------------
Initial: freq_count = [0]*26, cur_max_freq = 0, max_len = 0, left = 0

Iteration right=0, char='A'
- freq_count['A'] = 1
- cur_max_freq = max(0, 1) = 1
- length_of_cur_substring = 0 - 0 + 1 = 1
- min_changes = 1 - 1 = 0
- 0 > k(=1)? No -> valid branch: max_len = max(0, 1) = 1
- right becomes 1

Iteration right=1, char='A'
- freq_count['A'] = 2
- cur_max_freq = max(1, 2) = 2
- length_of_cur_substring = 1 - 0 + 1 = 2
- min_changes = 2 - 2 = 0
- 0 > 1? No -> valid: max_len = max(1, 2) = 2
- right becomes 2

Iteration right=2, char='B'
- freq_count['B'] = 1
- cur_max_freq = max(2, 1) = 2   (unchanged, 'A' is still the historical max)
- length_of_cur_substring = 2 - 0 + 1 = 3
- min_changes = 3 - 2 = 1
- 1 > 1? No -> valid: max_len = max(2, 3) = 3
- right becomes 3

Iteration right=3, char='A'
- freq_count['A'] = 3
- cur_max_freq = max(2, 3) = 3
- length_of_cur_substring = 3 - 0 + 1 = 4
- min_changes = 4 - 3 = 1
- 1 > 1? No -> valid: max_len = max(3, 4) = 4
- right becomes 4

Iteration right=4, char='B'
- freq_count['B'] = 2
- cur_max_freq = max(3, 2) = 3   (stays 3, historical high from 'A')
- length_of_cur_substring = 4 - 0 + 1 = 5
- min_changes = 5 - 3 = 2
- 2 > 1? Yes -> INVALID branch (single shrink, no max_len update):
  - char = s[left] = s[0] = 'A'
  - freq_count['A'] -= 1  ->  freq_count['A'] = 2
  - left += 1  ->  left = 1
  - (length_of_cur_substring and min_changes are NOT recomputed here)
- right becomes 5
- Note: max_len stays at 4 (not updated this iteration, as expected,
  since the pre-shrink window "AABAB" was genuinely invalid)

Iteration right=5, char='B'
- freq_count['B'] = 3
- cur_max_freq = max(3, 3) = 3
- length_of_cur_substring = 5 - 1 + 1 = 5   (left is now 1)
- min_changes = 5 - 3 = 2
- 2 > 1? Yes -> INVALID branch (single shrink):
  - char = s[left] = s[1] = 'A'
  - freq_count['A'] -= 1  ->  freq_count['A'] = 1
  - left += 1  ->  left = 2
- right becomes 6
- max_len still 4

Iteration right=6, char='A'
- freq_count['A'] = 2
- cur_max_freq = max(3, 2) = 3
- length_of_cur_substring = 6 - 2 + 1 = 5   (left is now 2)
- min_changes = 5 - 3 = 2
- 2 > 1? Yes -> INVALID branch (single shrink):
  - char = s[left] = s[2] = 'B'
  - freq_count['B'] -= 1  ->  freq_count['B'] = 2
  - left += 1  ->  left = 3
- right becomes 7 -> loop ends (right == len(s) == 7)
- max_len still 4

Final answer = max_len = 4  (matches the earlier `while`-based solution)

Key intuition recap
--------------------
- The window size grows by exactly 1 each time `right` advances and
  shrinks by exactly 1 each time we take the invalid branch — so it
  never needs more than one shrink step to "catch up".
- `cur_max_freq` is still monotonic/historical (never decreased), same
  trick as before — it's what makes a single shrink sufficient rather
  than an exact recomputation.
- `max_len` is only ever updated on the "valid" branch, so it never
  records a length that failed the (optimistic) check at the time of
  recording — same safety argument as the `while`-based version, just
  applied with only one shrink per step instead of a loop of shrinks.
"""


class SolutionNoWhileLoop(object):
    def characterReplacement(self, s, k):
        """
        Same algorithm as `Solution.characterReplacement`, but uses a
        26-slot frequency array and replaces the inner `while` loop with
        a single `if` (at most one shrink per outer iteration).

        :type s: str
        :type k: int
        :rtype: int
        """
        freq_count = [0] * 26
        cur_max_freq = max_len = left = right = length_of_cur_substring = 0

        while right < len(s):
            freq_count[ord(s[right]) - ord('A')] += 1
            cur_max_freq = max(cur_max_freq, freq_count[ord(s[right]) - ord('A')])
            length_of_cur_substring = right - left + 1
            min_changes = length_of_cur_substring - cur_max_freq

            # replace the while with if cause in a given window [left..right] beacomes invalid
            # after addition of s[right], this means all the windows after this 
            # window will also be invalid, so we need to shrink the window by one from left
            # and the reason we dont keep on shrinking left cause prior to invalid before
            # adding the new char we might have got the valid window
            # and then we computed the max_len, our target is to get the maimum length if
            # we keep on shrinking left and keeping right fixed that will never gurantee
            # in getting max len
            if min_changes > k:
                char = s[left]
                freq_count[ord(char) - ord('A')] -= 1
                # We intentionally do NOT recompute cur_max_freq by scanning
                # freq_count here, and we do NOT update max_len in this
                # branch — the window shrinks by exactly one character and
                # will be re-evaluated fully on the next iteration.
                left += 1
            else:
                max_len = max(max_len, length_of_cur_substring)
            right += 1

        return max_len


# Optional quick sanity checks:
# print(SolutionNoWhileLoop().characterReplacement("ABAB", 2))      # 4
# print(SolutionNoWhileLoop().characterReplacement("AABABBA", 1))   # 4
# print(SolutionNoWhileLoop().characterReplacement("AAAA", 2))      # 4
# print(SolutionNoWhileLoop().characterReplacement("ABCDE", 1))     # 2


# End of file


