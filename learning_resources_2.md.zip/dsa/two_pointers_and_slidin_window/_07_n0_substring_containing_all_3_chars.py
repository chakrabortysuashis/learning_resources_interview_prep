"""
LeetCode 1358. Number of Substrings Containing All Three Characters

Problem in simple words
-----------------------
We are given a string `s` made of only 'a', 'b', and 'c'.
We must count how many substrings contain at least one 'a', one 'b', and one 'c'.

Examples
--------
1) s = "abcabc" -> 10
2) s = "aaacb"   -> 3
3) s = "abc"     -> 1

Constraint insight
------------------
`len(s)` can be up to 5 * 10^4, so an O(n^2) or O(n^3) approach is too slow.
We need close to O(n).


Brute-force idea (for understanding)
------------------------------------
Generate all substrings and check if each has all three chars.

Pseudo-thought:
- for i in [0..n-1]:
    for j in [i..n-1]:
        substring = s[i:j+1]
        if contains 'a' and 'b' and 'c':
            count += 1

Why it works:
- It checks every possible substring, so nothing is missed.

Complexity:
- O(n^3) if substring check is O(n)
- O(n^2) with rolling frequency per fixed i, still too slow for 5*10^4.


Optimal idea (Sliding Window counting trick)
-------------------------------------------
Key observation:
When window s[left:right] already contains all 3 chars,
then ANY extension ending at right, right+1, ..., n-1 is valid.

So if current right is fixed and window [left..right] is valid,
then number of valid substrings starting at `left` is:
    n - right
because end index can be right to n-1.

Then we move left forward to find next valid start.

Algorithm:
1) Expand right pointer, add s[right] to freq.
2) While freq has at least one of each 'a','b','c':
   - Add (n - right) to answer.
   - Remove s[left] from freq and move left += 1.
3) Continue until right reaches end.

This counts each valid substring exactly once by its starting boundary
as we shrink from the left.


Dry run 1: s = "abcabc"
-------------------------
n = 6

Notation: [l..r], freq(a,b,c), add, total

r=0 'a': freq=(1,0,0), not valid
r=1 'b': freq=(1,1,0), not valid
r=2 'c': freq=(1,1,1), valid
  - add n-r = 6-2 = 4, total=4   ("abc", "abca", "abcab", "abcabc")
  - remove s[l]='a', l=1, freq=(0,1,1), stop valid loop

r=3 'a': freq=(1,1,1), valid
  - add 6-3=3, total=7           ("bca", "bcab", "bcabc")
  - remove s[l]='b', l=2, freq=(1,0,1), stop

r=4 'b': freq=(1,1,1), valid
  - add 6-4=2, total=9           ("cab", "cabc")
  - remove s[l]='c', l=3, freq=(1,1,0), stop

r=5 'c': freq=(1,1,1), valid
  - add 6-5=1, total=10          ("abc")
  - remove s[l]='a', l=4, freq=(0,1,1), stop

Final answer = 10


Dry run 2: s = "aaacb"
-----------------------
n = 5

r=0 'a': freq=(1,0,0), not valid
r=1 'a': freq=(2,0,0), not valid
r=2 'a': freq=(3,0,0), not valid
r=3 'c': freq=(3,0,1), not valid
r=4 'b': freq=(3,1,1), valid now
  while valid:
  - l=0: add 5-4=1, total=1 ("aaacb")
         remove s[0]='a' -> freq=(2,1,1), l=1, still valid
  - l=1: add 1, total=2 ("aacb")
         remove s[1]='a' -> freq=(1,1,1), l=2, still valid
  - l=2: add 1, total=3 ("acb")
         remove s[2]='a' -> freq=(0,1,1), l=3, invalid stop

Final answer = 3


Time and Space Complexity
-------------------------
- Time: O(n)
  Each character enters window once (right moves n times)
  and leaves window once (left moves at most n times).
- Space: O(1)
  We store counts of only 3 fixed characters.
"""


class Solution:
    def numberOfSubstrings(self, s: str) -> int:
        """
        Returns number of substrings containing at least one 'a', 'b', and 'c'.
        Sliding window + counting trick: whenever window is valid,
        add (n - right) and shrink left.
        """
        n = len(s)
        freq = {"a": 0, "b": 0, "c": 0}
        left = 0
        ans = 0

        for right, ch in enumerate(s):
            freq[ch] += 1

            # Try to shrink window while it still contains all 3 chars.
            while freq["a"] > 0 and freq["b"] > 0 and freq["c"] > 0:
                # All substrings from current left to any end >= right are valid.
                ans += n - right

                # Shrink from left to discover next valid/invalid boundary.
                freq[s[left]] -= 1
                left += 1

        return ans


# Optional brute-force reference (not used in final submission)
def number_of_substrings_bruteforce(s: str) -> int:
    """
    Educational-only brute-force helper.
    O(n^2) using incremental counts for each start index.
    Still too slow for the given max constraint in Python.
    """
    n = len(s)
    ans = 0

    for i in range(n):
        freq = {"a": 0, "b": 0, "c": 0}
        for j in range(i, n):
            freq[s[j]] += 1
            if freq["a"] > 0 and freq["b"] > 0 and freq["c"] > 0:
                ans += 1

    return ans


if __name__ == "__main__":
    solver = Solution()
    print(solver.numberOfSubstrings("abcabc"))  # 10
    print(solver.numberOfSubstrings("aaacb"))   # 3
    print(solver.numberOfSubstrings("abc"))     # 1
    print(number_of_substrings_bruteforce("abc"))  # 1


"""
Summary
-------
- Brute force checks all substrings (easy, but slow).
- Sliding window counts valid endings in bulk using (n - right).
- This gives an optimal O(n) solution.
"""


"""
Further optimized O(n) idea (No inner while loop)
==================================================
We keep the previous solutions exactly as-is and add one more equally optimal method.

Thinking process to discover this approach
------------------------------------------
We now count substrings by END index.
Suppose we are at index `i` and want number of valid substrings that end at `i`.

Question: For an end index i, how many starts `0..i` make s[start..i] contain a,b,c?

If we know the last seen positions:
- last seen 'a' = la
- last seen 'b' = lb
- last seen 'c' = lc

Then the earliest among them, `m = min(la, lb, lc)`, controls valid starts:
- Any start <= m will include all three chars in s[start..i].
- Any start > m misses whichever char has last seen index = m.

So, number of valid starts for this i is:
    m + 1
(Starts are 0..m)

Important condition:
If any of la/lb/lc is -1, it means one char has not appeared yet,
so contribution for this i is 0.

This completely avoids the inner while loop.


Dry run 1 (step-by-step): s = "abcabc"
----------------------------------------
Initialize:
- last_seen = [-1, -1, -1]  # [last_a, last_b, last_c]
- count = 0

Step 1: i = 0, s[i] = 'a'
- Update last_a -> 0, so last_seen = [0, -1, -1]
- Not all chars seen yet (b and c missing), add 0
- count = 0

Step 2: i = 1, s[i] = 'b'
- Update last_b -> 1, so last_seen = [0, 1, -1]
- c still missing, add 0
- count = 0

Step 3: i = 2, s[i] = 'c'
- Update last_c -> 2, so last_seen = [0, 1, 2]
- All seen now. min_last = min(0, 1, 2) = 0
- Add min_last + 1 = 1 (valid start is only index 0)
- count = 1

Step 4: i = 3, s[i] = 'a'
- Update last_a -> 3, so last_seen = [3, 1, 2]
- min_last = min(3, 1, 2) = 1
- Add 1 + 1 = 2 (valid starts: 0, 1)
- count = 3

Step 5: i = 4, s[i] = 'b'
- Update last_b -> 4, so last_seen = [3, 4, 2]
- min_last = min(3, 4, 2) = 2
- Add 2 + 1 = 3 (valid starts: 0, 1, 2)
- count = 6

Step 6: i = 5, s[i] = 'c'
- Update last_c -> 5, so last_seen = [3, 4, 5]
- min_last = min(3, 4, 5) = 3
- Add 3 + 1 = 4 (valid starts: 0, 1, 2, 3)
- count = 10

Final answer = 10


Dry run 2 (step-by-step): s = "aaacb"
---------------------------------------
Initialize:
- last_seen = [-1, -1, -1]
- count = 0

Step 1: i = 0, s[i] = 'a'
- last_seen = [0, -1, -1]
- Missing b and c, add 0
- count = 0

Step 2: i = 1, s[i] = 'a'
- last_seen = [1, -1, -1]
- Missing b and c, add 0
- count = 0

Step 3: i = 2, s[i] = 'a'
- last_seen = [2, -1, -1]
- Missing b and c, add 0
- count = 0

Step 4: i = 3, s[i] = 'c'
- last_seen = [2, -1, 3]
- Missing b, add 0
- count = 0

Step 5: i = 4, s[i] = 'b'
- last_seen = [2, 4, 3]
- All seen now. min_last = min(2, 4, 3) = 2
- Add 2 + 1 = 3 (valid starts: 0, 1, 2)
- count = 3

Final answer = 3


Complexity
----------
- Time: O(n), one left-to-right pass.
- Space: O(1), only 3 last-seen indexes.
"""


def number_of_substrings_last_seen(s: str) -> int:
    """
    Optimized counting by tracking last seen indexes of 'a', 'b', 'c'.

    For each position i (substring end), contribution is:
    min(last_a, last_b, last_c) + 1, if all are seen.
    """
    cur_index = 0
    count = 0

    # last_seen[0] -> last index of 'a'
    # last_seen[1] -> last index of 'b'
    # last_seen[2] -> last index of 'c'
    # -1 means that character has not appeared yet.
    last_seen = [-1] * 3

    while cur_index < len(s):
        # Update last seen index for current character.
        # ord('a') -> 97, ord('b') -> 98, ord('c') -> 99.
        # So we map: 'a'->0, 'b'->1, 'c'->2.
        last_seen[ord(s[cur_index]) - ord("a")] = cur_index

        # If all three characters have appeared at least once,
        # we can count how many starts create valid substrings ending at cur_index.
        if last_seen[0] != -1 and last_seen[1] != -1 and last_seen[2] != -1:
            # Earliest last-seen index decides max allowed start.
            # Starts from 0..min_last are valid -> count = min_last + 1.
            count += min(last_seen[0], last_seen[1], last_seen[2]) + 1

        cur_index += 1

    return count


# Optional class-style wrapper for parity with LeetCode signature
class SolutionLastSeen:
    def numberOfSubstrings(self, s: str) -> int:
        return number_of_substrings_last_seen(s)




