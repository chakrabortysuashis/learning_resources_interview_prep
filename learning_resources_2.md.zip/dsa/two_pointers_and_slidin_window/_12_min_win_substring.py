"""
76. Minimum Window Substring

Given two strings s and t of lengths m and n respectively, return the minimum window substring of s such that every character in t (including duplicates) is included in the window. If there is no such substring, return the empty string "".

The testcases will be generated such that the answer is unique.



Example 1:

Input: s = "ADOBECODEBANC", t = "ABC"
Output: "BANC"
Explanation: The minimum window substring "BANC" includes 'A', 'B', and 'C' from string t.
Example 2:

Input: s = "a", t = "a"
Output: "a"
Explanation: The entire string s is the minimum window.
Example 3:

Input: s = "a", t = "aa"
Output: ""
Explanation: Both 'a's from t must be included in the window.
Since the largest window of s only has one 'a', return empty string.


Constraints:

m == s.length
n == t.length
1 <= m, n <= 105
s and t consist of uppercase and lowercase English letters.


Follow up: Could you find an algorithm that runs in O(m + n) time?

link:https://leetcode.com/problems/minimum-window-substring/description/
"""

import sys


# =============================================================================
# PROBLEM UNDERSTANDING
# =============================================================================
#
# WHAT WE NEED TO FIND:
# ---------------------
# Given two strings 's' (source) and 't' (target), find the SMALLEST substring
# in 's' that contains ALL characters from 't', including duplicates.
#
# KEY OBSERVATIONS:
# 1. We need to track character FREQUENCIES, not just presence
#    - If t = "AAB", we need at least 2 A's and 1 B in our window
#
# 2. Order does NOT matter
#    - Characters in the window can appear in any order
#
# 3. We want the MINIMUM length window
#    - If multiple valid windows exist, return the smallest one
#
# 4. Return empty string if no valid window exists
#
# EXAMPLES:
# ---------
# s = "ADOBECODEBANC", t = "ABC"
# - We need: 1 'A', 1 'B', 1 'C'
# - "ADOBEC" contains all (length 6)
# - "BANC" also contains all (length 4) <- ANSWER (smallest)
#
# s = "a", t = "aa"
# - We need: 2 'a's
# - s only has 1 'a'
# - Return "" (impossible)
#
# =============================================================================


# =============================================================================
# BRUTE FORCE APPROACH
# =============================================================================
#
# INTUITION:
# ----------
# The most straightforward approach is to check every possible substring of s
# and see if it contains all characters of t.
#
# KEY IDEA - SAME ARRAY TECHNIQUE AS OPTIMAL:
# Instead of using a hashmap, we use the SAME t_list[256] technique:
# - For each starting position i, initialize t_list with t's frequencies
# - Expand j from i to end of s
# - Track count of matched characters
# - When count == len(t), we found a valid window -> break (no need for longer)
#
# WHY BREAK EARLY?
# - Once we find a valid window starting at i, any longer window from i
#   would be larger, so no point checking further
# - But we still need to try all starting positions
#
# ALGORITHM:
# 1. For each starting position i:
#    a. Re-initialize t_list with frequencies from t
#    b. Reset count to 0
#    c. Expand j from i to end of s:
#       - If t_list[s[j]] > 0, increment count (found a needed char)
#       - Decrement t_list[s[j]] (consumed this char)
#       - If count == len(t): valid window found, update min, break
# 2. Return minimum window found
#
# WHY IT'S SLOWER THAN OPTIMAL:
# - We re-initialize t_list for EVERY starting position
# - We don't reuse work from previous windows
# - The optimal solution uses sliding window to avoid this
#
# =============================================================================

def brute_force(s: str, t: str) -> str:
    """
    Brute Force Solution: Check all substrings using single array technique.

    For each starting position, re-initialize the frequency array and
    expand until a valid window is found.

    Args:
        s: Source string to search in
        t: Target string containing required characters

    Returns:
        Minimum window substring or "" if not found
    """
    len_t = len(t)
    cur_len = 0
    start_index = 0
    min_win = sys.maxsize
    output = ""

    # Try each starting position
    for i in range(len(s)):

        count = 0  # Reset matched count for each starting position

        # Re-initialize t_list for each starting position
        # This is the KEY difference from optimal - we redo this work!
        t_list = [0] * 256
        for k, char in enumerate(t):
            t_list[ord(char)] += 1

        # Expand from position i to end of string
        for j in range(i, len(s)):

            # If this character is still needed (t_list > 0)
            if t_list[ord(s[j])] > 0:
                count += 1  # Found a needed character

            # Consume this character (decrement requirement)
            t_list[ord(s[j])] -= 1

            # Check if we have a valid window
            if count == len_t:
                cur_len = j - i + 1

                # Update minimum if this window is smaller
                if min_win > cur_len:
                    output = s[i:j + 1]
                    min_win = cur_len

                # Break - no need to check longer windows from this start
                break

    return output


# =============================================================================
# BRUTE FORCE DRY RUN: s = "ADOBECODEBANC", t = "ABC"
# =============================================================================
#
# len_t = 3, min_win = sys.maxsize, output = ""
#
# -----------------------------------------------------------------------------
# i = 0: Starting from 'A'
# -----------------------------------------------------------------------------
#   Initialize: count = 0, t_list['A']=1, ['B']=1, ['C']=1 (others = 0)
#
#   j=0, s[j]='A':
#     t_list['A']=1 > 0 ? YES -> count = 1
#     t_list['A'] = 1 - 1 = 0
#     count(1) != len_t(3) -> continue
#
#   j=1, s[j]='D':
#     t_list['D']=0 > 0 ? NO -> count stays 1
#     t_list['D'] = 0 - 1 = -1
#     count(1) != len_t(3) -> continue
#
#   j=2, s[j]='O':
#     t_list['O']=0 > 0 ? NO -> count stays 1
#     t_list['O'] = -1
#     count(1) != len_t(3) -> continue
#
#   j=3, s[j]='B':
#     t_list['B']=1 > 0 ? YES -> count = 2
#     t_list['B'] = 0
#     count(2) != len_t(3) -> continue
#
#   j=4, s[j]='E':
#     t_list['E']=0 > 0 ? NO -> count stays 2
#     t_list['E'] = -1
#     count(2) != len_t(3) -> continue
#
#   j=5, s[j]='C':
#     t_list['C']=1 > 0 ? YES -> count = 3
#     t_list['C'] = 0
#     count(3) == len_t(3) -> VALID WINDOW!
#     cur_len = 5 - 0 + 1 = 6
#     min_win(maxsize) > 6 ? YES -> output = "ADOBEC", min_win = 6
#     BREAK inner loop
#
#   Window found: "ADOBEC" (length 6)
#
# -----------------------------------------------------------------------------
# i = 1: Starting from 'D'
# -----------------------------------------------------------------------------
#   Initialize: count = 0, t_list['A']=1, ['B']=1, ['C']=1
#
#   j=1, s[j]='D': t_list['D']=0, count stays 0
#   j=2, s[j]='O': t_list['O']=0, count stays 0
#   j=3, s[j]='B': t_list['B']=1>0, count = 1
#   j=4, s[j]='E': t_list['E']=0, count stays 1
#   j=5, s[j]='C': t_list['C']=1>0, count = 2
#   j=6, s[j]='O': count stays 2
#   j=7, s[j]='D': count stays 2
#   j=8, s[j]='E': count stays 2
#   j=9, s[j]='B': t_list['B']=0 (already used), count stays 2
#   j=10, s[j]='A': t_list['A']=1>0, count = 3 -> VALID!
#   cur_len = 10 - 1 + 1 = 10
#   min_win(6) > 10 ? NO -> output stays "ADOBEC"
#   BREAK
#
#   Window found: "DOBECODEBA" (length 10) - not smaller, ignored
#
# -----------------------------------------------------------------------------
# i = 2 to 8: Similar process, no smaller window found
# -----------------------------------------------------------------------------
#
# -----------------------------------------------------------------------------
# i = 9: Starting from 'B'
# -----------------------------------------------------------------------------
#   Initialize: count = 0, t_list['A']=1, ['B']=1, ['C']=1
#
#   j=9, s[j]='B':
#     t_list['B']=1 > 0 ? YES -> count = 1
#     t_list['B'] = 0
#
#   j=10, s[j]='A':
#     t_list['A']=1 > 0 ? YES -> count = 2
#     t_list['A'] = 0
#
#   j=11, s[j]='N':
#     t_list['N']=0 > 0 ? NO -> count stays 2
#     t_list['N'] = -1
#
#   j=12, s[j]='C':
#     t_list['C']=1 > 0 ? YES -> count = 3
#     t_list['C'] = 0
#     count(3) == len_t(3) -> VALID WINDOW!
#     cur_len = 12 - 9 + 1 = 4
#     min_win(6) > 4 ? YES -> output = "BANC", min_win = 4
#     BREAK
#
#   Window found: "BANC" (length 4) - NEW MINIMUM!
#
# -----------------------------------------------------------------------------
# i = 10, 11, 12: Cannot form valid window (not enough characters left)
# -----------------------------------------------------------------------------
#
# FINAL RESULT: "BANC"
#
# -----------------------------------------------------------------------------
# TIME COMPLEXITY: O(m^2 + m*n) ≈ O(m^2) where m = len(s), n = len(t)
# -----------------------------------------------------------------------------
#   - Outer loop: O(m) iterations
#   - For each i:
#     - Initialize t_list from t: O(n)
#     - Inner loop: O(m) in worst case
#   - Total: O(m * (n + m)) = O(m*n + m^2)
#   - Since typically m >= n: O(m^2)
#
#   Note: This is BETTER than O(m^3) because we don't rebuild frequency
#   maps for each substring - we incrementally update t_list!
#
# -----------------------------------------------------------------------------
# SPACE COMPLEXITY: O(256) = O(1)
# -----------------------------------------------------------------------------
#   - t_list array: O(256) = O(1) (fixed size)
#   - Variables: O(1)
#   - Output string: O(m) in worst case
#
# =============================================================================


# =============================================================================
# OPTIMAL APPROACH: SINGLE ARRAY TECHNIQUE
# =============================================================================
#
# KEY INSIGHT - WHY THIS APPROACH IS ELEGANT:
# -------------------------------------------
# Instead of using TWO hashmaps (one for "need" and one for "have"), we use
# a SINGLE array of size 256 (for all ASCII characters).
#
# THE BRILLIANT IDEA:
# - Initialize the array with character counts from t
# - POSITIVE values mean "we still NEED this many of this character"
# - ZERO means "we have exactly enough"
# - NEGATIVE means "we have EXTRA of this character"
#
# SINGLE COUNTER 'c':
# - Tracks the TOTAL number of characters from t that are matched
# - NOT the number of unique characters!
# - When c == len(t), ALL characters are matched (including duplicates)
#
# HOW IT WORKS:
# -------------
#
# INITIALIZATION:
#   t_list[256] = all zeros
#   For each char in t: t_list[ord(char)] += 1
#
#   Example: t = "ABC"
#   t_list['A'(65)] = 1  (we NEED 1 'A')
#   t_list['B'(66)] = 1  (we NEED 1 'B')
#   t_list['C'(67)] = 1  (we NEED 1 'C')
#   All other indices = 0 (we don't need them)
#
# EXPANDING WINDOW (moving right pointer):
#   1. Check if t_list[s[r]] > 0 (we still need this character)
#      - If yes, increment matched count 'c'
#   2. Always decrement t_list[s[r]] (we're adding it to window)
#      - If it goes negative, we have extras
#
# CONTRACTING WINDOW (moving left pointer):
#   1. Increment t_list[s[l]] (we're removing it from window)
#   2. If t_list[s[l]] > 0 after incrementing, we lost a needed char
#      - Decrement matched count 'c'
#
# WHY c == len(t) MEANS VALID WINDOW:
# -----------------------------------
# - c only increases when we add a NEEDED character (t_list > 0)
# - t_list[char] > 0 means we haven't filled the quota for that char
# - Once quota is filled, t_list becomes 0 or negative
# - c increases exactly once for each character in t that gets matched
# - When c == len(t), all len(t) characters have been matched!
#
# VISUAL EXAMPLE: t = "ABC", s = "ADOBEC"
# ----------------------------------------
#
# Initial: t_list['A']=1, t_list['B']=1, t_list['C']=1, c=0
#
# Add 'A': t_list['A']=1>0, so c=1, then t_list['A']=0
# Add 'D': t_list['D']=0, c stays 1, then t_list['D']=-1
# Add 'O': t_list['O']=0, c stays 1, then t_list['O']=-1
# Add 'B': t_list['B']=1>0, so c=2, then t_list['B']=0
# Add 'E': t_list['E']=0, c stays 2, then t_list['E']=-1
# Add 'C': t_list['C']=1>0, so c=3, then t_list['C']=0
#
# Now c=3 == len(t)=3 -> VALID WINDOW!
#
# =============================================================================
# STEP-BY-STEP ALGORITHM
# =============================================================================
#
# 1. INITIALIZE:
#    - t_list[256] array, populate with frequencies from t
#    - l = r = c = 0 (left pointer, right pointer, matched count)
#    - min_len = infinity, output = ""
#
# 2. EXPAND (while r < len(s)):
#    a. If t_list[s[r]] > 0:
#       - This character is needed, increment c
#    b. Decrement t_list[s[r]]
#       - Mark that we've added this char to window
#
# 3. CONTRACT (while c == len(t)):
#    a. Update minimum if current window is smaller
#    b. Increment t_list[s[l]]
#       - Removing char from window
#    c. If t_list[s[l]] > 0 after increment:
#       - We lost a needed character, decrement c
#    d. Move left pointer: l += 1
#
# 4. Move right pointer: r += 1
#
# 5. Return output
#
# =============================================================================
# VISUAL REPRESENTATION OF SLIDING WINDOW
# =============================================================================
#
#     s = "A D O B E C O D E B A N C"
#          0 1 2 3 4 5 6 7 8 9 10 11 12
#
#     t = "ABC" -> t_list['A']=1, ['B']=1, ['C']=1
#
#     Phase 1: EXPAND until c == 3
#     ----------------------------
#          A D O B E C O D E B A  N  C
#          L         R                    Window: "ADOBEC"
#          ^---------^                    c = 3 (Valid!)
#
#     Phase 2: CONTRACT to minimize
#     ----------------------------
#          A D O B E C O D E B A  N  C
#            L       R                    Window: "DOBEC"
#            ^-------^                    c = 2 (Invalid - lost A)
#
#     Phase 3: EXPAND again
#     ----------------------------
#          A D O B E C O D E B A  N  C
#            L                 R          Window: "DOBECODEBA"
#            ^-----------------^          c = 3 (Valid!)
#
#     Phase 4: CONTRACT to minimize
#     ----------------------------
#          ... keep contracting ...
#
#          A D O B E C O D E B A  N  C
#                              L      R   Window: "BANC"
#                              ^------^   c = 3 (Valid!)
#                                         length = 4 (MINIMUM!)
#
# =============================================================================


class Solution:
    def minWindow(self, s: str, t: str) -> str:
        """
        Find the minimum window substring of s containing all characters of t.

        Uses the SINGLE ARRAY technique:
        - One array t_list[256] tracks character requirements
        - Positive = need, Zero/Negative = have enough or extra
        - Single counter c tracks total matched characters

        Args:
            s: The source string to search in
            t: The target string containing required characters

        Returns:
            The minimum window substring, or "" if no valid window exists
        """

        # =====================================================================
        # EDGE CASES
        # =====================================================================
        if not t or not s:
            return ""

        if len(t) > len(s):
            return ""

        # =====================================================================
        # STEP 1: INITIALIZE VARIABLES
        # =====================================================================

        # Two pointers for sliding window
        l = 0  # Left pointer (start of window)
        r = 0  # Right pointer (end of window)

        # Matched character count
        # When c == len(t), all characters are matched
        c = 0

        # Track minimum window
        min_len = sys.maxsize  # Start with maximum possible value
        output = ''            # Store the result substring

        # =====================================================================
        # STEP 2: BUILD THE REQUIREMENT ARRAY
        # =====================================================================
        # Single array of size 256 (for all ASCII characters)
        # - Initialize with zeros
        # - Increment for each character in t
        # - Positive values = "we NEED this many"
        # - Zero = "we don't need this character"

        t_list = [0] * 256

        for char in t:
            t_list[ord(char)] += 1

        # Store length of t for comparison
        t_len = len(t)

        # =====================================================================
        # STEP 3: SLIDE THE WINDOW
        # =====================================================================

        while r < len(s):

            # -----------------------------------------------------------------
            # EXPAND: Process character at right pointer
            # -----------------------------------------------------------------

            # If t_list[s[r]] > 0, this character is still NEEDED
            # We haven't collected enough of this character yet
            if t_list[ord(s[r])] > 0:
                c += 1  # One more character matched!

            # Decrement the requirement for this character
            # - If it becomes 0: we have exactly enough
            # - If it becomes negative: we have extras
            t_list[ord(s[r])] -= 1

            # -----------------------------------------------------------------
            # CONTRACT: While window is valid, try to shrink from left
            # -----------------------------------------------------------------

            # c == t_len means ALL characters from t are matched
            while c == t_len:

                # Update minimum window if current is smaller
                if min_len > r - l + 1:
                    min_len = r - l + 1
                    output = s[l:r + 1]

                # Try to remove character at left pointer
                # First, add it back to requirements
                t_list[ord(s[l])] += 1

                # If t_list[s[l]] > 0 after incrementing:
                # - We removed a character that was NEEDED
                # - The window is no longer valid
                if t_list[ord(s[l])] > 0:
                    c -= 1  # Lost a matched character

                # Move left pointer to shrink window
                l += 1

            # Move right pointer to expand window
            r += 1

        # =====================================================================
        # STEP 4: RETURN RESULT
        # =====================================================================
        return output


# =============================================================================
# DETAILED DRY RUN 1: s = "ADOBECODEBANC", t = "ABC"
# =============================================================================
#
# INITIALIZATION:
# ---------------
# l = 0, r = 0, c = 0
# min_len = sys.maxsize, output = ""
# t_len = 3
#
# t_list (showing only relevant indices):
# Index:  65('A')  66('B')  67('C')  68('D')  69('E')  78('N')  79('O')
# Value:     1        1        1        0        0        0        0
#           NEED     NEED     NEED   no need  no need  no need  no need
#
# -----------------------------------------------------------------------------
# r = 0, s[0] = 'A'
# -----------------------------------------------------------------------------
#   Check: t_list[65] = 1 > 0 ? YES -> c = 0 + 1 = 1 (need A, got it!)
#   Update: t_list[65] = 1 - 1 = 0 (now have enough A's)
#
#   t_list: ['A']=0, ['B']=1, ['C']=1
#   c = 1, t_len = 3, c != t_len -> no contraction
#
#   Window: [A]DOBECODEBANC
#            ^
#   r = 1
#
# -----------------------------------------------------------------------------
# r = 1, s[1] = 'D'
# -----------------------------------------------------------------------------
#   Check: t_list[68] = 0 > 0 ? NO -> c stays 1 (don't need D)
#   Update: t_list[68] = 0 - 1 = -1 (have extra D)
#
#   t_list: ['A']=0, ['B']=1, ['C']=1, ['D']=-1
#   c = 1, c != t_len -> no contraction
#
#   Window: [AD]OBECODEBANC
#            ^^
#   r = 2
#
# -----------------------------------------------------------------------------
# r = 2, s[2] = 'O'
# -----------------------------------------------------------------------------
#   Check: t_list[79] = 0 > 0 ? NO -> c stays 1 (don't need O)
#   Update: t_list[79] = 0 - 1 = -1 (have extra O)
#
#   t_list: ['A']=0, ['B']=1, ['C']=1, ['D']=-1, ['O']=-1
#   c = 1, c != t_len -> no contraction
#
#   Window: [ADO]BECODEBANC
#            ^^^
#   r = 3
#
# -----------------------------------------------------------------------------
# r = 3, s[3] = 'B'
# -----------------------------------------------------------------------------
#   Check: t_list[66] = 1 > 0 ? YES -> c = 1 + 1 = 2 (need B, got it!)
#   Update: t_list[66] = 1 - 1 = 0 (now have enough B's)
#
#   t_list: ['A']=0, ['B']=0, ['C']=1, ['D']=-1, ['O']=-1
#   c = 2, c != t_len -> no contraction
#
#   Window: [ADOB]ECODEBANC
#            ^^^^
#   r = 4
#
# -----------------------------------------------------------------------------
# r = 4, s[4] = 'E'
# -----------------------------------------------------------------------------
#   Check: t_list[69] = 0 > 0 ? NO -> c stays 2 (don't need E)
#   Update: t_list[69] = 0 - 1 = -1 (have extra E)
#
#   t_list: ['A']=0, ['B']=0, ['C']=1, ['D']=-1, ['E']=-1, ['O']=-1
#   c = 2, c != t_len -> no contraction
#
#   Window: [ADOBE]CODEBANC
#            ^^^^^
#   r = 5
#
# -----------------------------------------------------------------------------
# r = 5, s[5] = 'C'
# -----------------------------------------------------------------------------
#   Check: t_list[67] = 1 > 0 ? YES -> c = 2 + 1 = 3 (need C, got it!)
#   Update: t_list[67] = 1 - 1 = 0 (now have enough C's)
#
#   t_list: ['A']=0, ['B']=0, ['C']=0, ['D']=-1, ['E']=-1, ['O']=-1
#   c = 3, t_len = 3, c == t_len -> VALID WINDOW! Start contracting.
#
#   Window: [ADOBEC]ODEBANC  <- First valid window!
#            ^^^^^^
#
#   --- CONTRACTION PHASE ---
#
#   Iteration 1 (l=0):
#     window_len = 5 - 0 + 1 = 6 < sys.maxsize
#     min_len = 6, output = "ADOBEC"
#
#     Restore: t_list[65] = 0 + 1 = 1 (removing A, need it again!)
#     Check: t_list[65] = 1 > 0 ? YES -> c = 3 - 1 = 2 (lost needed char)
#     l = 1
#
#     c = 2, c != t_len -> exit contraction
#
#   Window: A[DOBEC]ODEBANC
#             ^^^^^
#   t_list: ['A']=1, ['B']=0, ['C']=0, ['D']=-1, ['E']=-1, ['O']=-1
#           NEED again!
#
#   r = 6
#
# -----------------------------------------------------------------------------
# r = 6, s[6] = 'O'
# -----------------------------------------------------------------------------
#   Check: t_list[79] = -1 > 0 ? NO -> c stays 2 (already have extra O)
#   Update: t_list[79] = -1 - 1 = -2 (even more extra O)
#
#   t_list: ['A']=1, ['B']=0, ['C']=0, ['O']=-2
#   c = 2, c != t_len -> no contraction
#
#   Window: A[DOBECO]DEBANC
#             ^^^^^^
#   r = 7
#
# -----------------------------------------------------------------------------
# r = 7, s[7] = 'D'
# -----------------------------------------------------------------------------
#   Check: t_list[68] = -1 > 0 ? NO -> c stays 2
#   Update: t_list[68] = -1 - 1 = -2
#
#   t_list: ['A']=1, ['B']=0, ['C']=0, ['D']=-2, ['O']=-2
#   c = 2, c != t_len -> no contraction
#
#   Window: A[DOBECOD]EBANC
#             ^^^^^^^
#   r = 8
#
# -----------------------------------------------------------------------------
# r = 8, s[8] = 'E'
# -----------------------------------------------------------------------------
#   Check: t_list[69] = -1 > 0 ? NO -> c stays 2
#   Update: t_list[69] = -1 - 1 = -2
#
#   t_list: ['A']=1, ['B']=0, ['C']=0, ['D']=-2, ['E']=-2, ['O']=-2
#   c = 2, c != t_len -> no contraction
#
#   Window: A[DOBECODE]BANC
#             ^^^^^^^^
#   r = 9
#
# -----------------------------------------------------------------------------
# r = 9, s[9] = 'B'
# -----------------------------------------------------------------------------
#   Check: t_list[66] = 0 > 0 ? NO -> c stays 2 (already have enough B)
#   Update: t_list[66] = 0 - 1 = -1 (now have extra B)
#
#   t_list: ['A']=1, ['B']=-1, ['C']=0, ['D']=-2, ['E']=-2, ['O']=-2
#   c = 2, c != t_len -> no contraction
#
#   Window: A[DOBECODEB]ANC
#             ^^^^^^^^^
#   r = 10
#
# -----------------------------------------------------------------------------
# r = 10, s[10] = 'A'
# -----------------------------------------------------------------------------
#   Check: t_list[65] = 1 > 0 ? YES -> c = 2 + 1 = 3 (need A, got it!)
#   Update: t_list[65] = 1 - 1 = 0
#
#   t_list: ['A']=0, ['B']=-1, ['C']=0, ['D']=-2, ['E']=-2, ['O']=-2
#   c = 3, t_len = 3, c == t_len -> VALID WINDOW! Start contracting.
#
#   Window: A[DOBECODEBA]NC  <- Valid!
#             ^^^^^^^^^^
#
#   --- CONTRACTION PHASE ---
#
#   Iteration 1 (l=1):
#     window_len = 10 - 1 + 1 = 10 > 6 -> min_len stays 6
#
#     Restore: t_list[68] = -2 + 1 = -1 (removing D)
#     Check: t_list[68] = -1 > 0 ? NO -> c stays 3 (D not needed)
#     l = 2
#
#   Iteration 2 (l=2):
#     window_len = 10 - 2 + 1 = 9 > 6 -> min_len stays 6
#
#     Restore: t_list[79] = -2 + 1 = -1 (removing O)
#     Check: t_list[79] = -1 > 0 ? NO -> c stays 3 (O not needed)
#     l = 3
#
#   Iteration 3 (l=3):
#     window_len = 10 - 3 + 1 = 8 > 6 -> min_len stays 6
#
#     Restore: t_list[66] = -1 + 1 = 0 (removing B)
#     Check: t_list[66] = 0 > 0 ? NO -> c stays 3 (still have enough B)
#     l = 4
#
#   Iteration 4 (l=4):
#     window_len = 10 - 4 + 1 = 7 > 6 -> min_len stays 6
#
#     Restore: t_list[69] = -2 + 1 = -1 (removing E)
#     Check: t_list[69] = -1 > 0 ? NO -> c stays 3 (E not needed)
#     l = 5
#
#   Iteration 5 (l=5):
#     window_len = 10 - 5 + 1 = 6 = 6 -> min_len stays 6
#
#     Restore: t_list[67] = 0 + 1 = 1 (removing C, need it again!)
#     Check: t_list[67] = 1 > 0 ? YES -> c = 3 - 1 = 2 (lost needed char)
#     l = 6
#
#     c = 2, c != t_len -> exit contraction
#
#   Window: ADOBE[CODEBA]NC
#                 ^^^^^^
#   t_list: ['A']=0, ['B']=0, ['C']=1, ['D']=-1, ['E']=-1, ['O']=-1
#                             NEED C again!
#
#   r = 11
#
# -----------------------------------------------------------------------------
# r = 11, s[11] = 'N'
# -----------------------------------------------------------------------------
#   Check: t_list[78] = 0 > 0 ? NO -> c stays 2 (don't need N)
#   Update: t_list[78] = 0 - 1 = -1
#
#   t_list: ['C']=1, ['N']=-1
#   c = 2, c != t_len -> no contraction
#
#   Window: ADOBE[ODEBAN]C
#                 ^^^^^^
#   r = 12
#
# -----------------------------------------------------------------------------
# r = 12, s[12] = 'C'
# -----------------------------------------------------------------------------
#   Check: t_list[67] = 1 > 0 ? YES -> c = 2 + 1 = 3 (need C, got it!)
#   Update: t_list[67] = 1 - 1 = 0
#
#   t_list: ['A']=0, ['B']=0, ['C']=0, ['N']=-1, etc.
#   c = 3, t_len = 3, c == t_len -> VALID WINDOW! Start contracting.
#
#   Window: ADOBE[ODEBANC]  <- Valid!
#                 ^^^^^^^
#
#   --- CONTRACTION PHASE ---
#
#   Iteration 1 (l=6):
#     window_len = 12 - 6 + 1 = 7 > 6 -> min_len stays 6
#
#     Restore: t_list[79] = -1 + 1 = 0 (removing O)
#     Check: t_list[79] = 0 > 0 ? NO -> c stays 3
#     l = 7
#
#   Iteration 2 (l=7):
#     window_len = 12 - 7 + 1 = 6 = 6 -> min_len stays 6
#
#     Restore: t_list[68] = -1 + 1 = 0 (removing D)
#     Check: t_list[68] = 0 > 0 ? NO -> c stays 3
#     l = 8
#
#   Iteration 3 (l=8):
#     window_len = 12 - 8 + 1 = 5 < 6
#     min_len = 5, output = "EBANC"
#
#     Restore: t_list[69] = -1 + 1 = 0 (removing E)
#     Check: t_list[69] = 0 > 0 ? NO -> c stays 3
#     l = 9
#
#   Iteration 4 (l=9):
#     window_len = 12 - 9 + 1 = 4 < 5
#     min_len = 4, output = "BANC"
#
#     Restore: t_list[66] = 0 + 1 = 1 (removing B, need it again!)
#     Check: t_list[66] = 1 > 0 ? YES -> c = 3 - 1 = 2 (lost needed char)
#     l = 10
#
#     c = 2, c != t_len -> exit contraction
#
#   Window: ADOBECODE[BANC]
#                     ^^^^
#
# -----------------------------------------------------------------------------
# END OF STRING (r = 13, loop exits)
# -----------------------------------------------------------------------------
#
# FINAL RESULT: output = "BANC"
#
# =============================================================================


# =============================================================================
# DETAILED DRY RUN 2: s = "a", t = "aa"
# =============================================================================
#
# This is an EDGE CASE where the window cannot be formed because s doesn't
# have enough characters.
#
# INITIALIZATION:
# ---------------
# l = 0, r = 0, c = 0
# min_len = sys.maxsize, output = ""
# t_len = 2 (need TWO 'a's)
#
# t_list (showing relevant index):
# Index:  97('a')
# Value:     2       <- We NEED 2 'a's
#
# -----------------------------------------------------------------------------
# r = 0, s[0] = 'a'
# -----------------------------------------------------------------------------
#   Check: t_list[97] = 2 > 0 ? YES -> c = 0 + 1 = 1 (need a, got one!)
#   Update: t_list[97] = 2 - 1 = 1 (still need 1 more 'a')
#
#   t_list: ['a']=1   <- Still NEED 1 more 'a'!
#   c = 1, t_len = 2, c != t_len -> no contraction
#
#   Window: [a]
#            ^
#   r = 1
#
# -----------------------------------------------------------------------------
# END OF STRING (r = 1, loop exits)
# -----------------------------------------------------------------------------
#
# c never reached t_len (2)
# output is still "" (empty string)
#
# FINAL RESULT: "" (empty string)
#
# EXPLANATION:
# - We needed 2 'a's (t = "aa")
# - We only found 1 'a' in s
# - The counter c only reached 1, never 2
# - So no valid window was ever found
#
# This shows why c == t_len is the correct validity check:
# - c only increments when we find a NEEDED character
# - t_list[char] > 0 means we still need more of that character
# - If t = "aa", t_list['a'] starts at 2
# - First 'a' found: c becomes 1, t_list['a'] becomes 1 (still > 0)
# - If second 'a' found: c becomes 2, t_list['a'] becomes 0
# - Only then c == t_len
#
# =============================================================================


# =============================================================================
# ADDITIONAL DRY RUN: s = "aa", t = "aa"
# =============================================================================
#
# INITIALIZATION:
# ---------------
# l = 0, r = 0, c = 0
# min_len = sys.maxsize, output = ""
# t_len = 2
#
# t_list: ['a']=2 (need 2 'a's)
#
# -----------------------------------------------------------------------------
# r = 0, s[0] = 'a'
# -----------------------------------------------------------------------------
#   Check: t_list[97] = 2 > 0 ? YES -> c = 1
#   Update: t_list[97] = 1
#
#   t_list: ['a']=1 (still need 1 more)
#   c = 1, c != t_len -> no contraction
#
#   Window: [a]a
#            ^
#   r = 1
#
# -----------------------------------------------------------------------------
# r = 1, s[1] = 'a'
# -----------------------------------------------------------------------------
#   Check: t_list[97] = 1 > 0 ? YES -> c = 2
#   Update: t_list[97] = 0 (have exactly enough)
#
#   t_list: ['a']=0
#   c = 2, t_len = 2, c == t_len -> VALID WINDOW!
#
#   Window: [aa]  <- Valid!
#            ^^
#
#   --- CONTRACTION PHASE ---
#
#   Iteration 1 (l=0):
#     window_len = 1 - 0 + 1 = 2 < sys.maxsize
#     min_len = 2, output = "aa"
#
#     Restore: t_list[97] = 0 + 1 = 1 (removing a, need it again!)
#     Check: t_list[97] = 1 > 0 ? YES -> c = 2 - 1 = 1
#     l = 1
#
#     c = 1, c != t_len -> exit contraction
#
# -----------------------------------------------------------------------------
# END OF STRING (r = 2, loop exits)
# -----------------------------------------------------------------------------
#
# FINAL RESULT: output = "aa"
#
# =============================================================================


# =============================================================================
# EDGE CASES ANALYSIS
# =============================================================================
#
# 1. EMPTY STRINGS:
#    - t is empty: Return "" (no characters needed)
#    - s is empty: Return "" (can't form any window)
#    Example: s = "abc", t = "" -> ""
#
# 2. t LONGER THAN s:
#    - Impossible to contain all characters
#    Example: s = "a", t = "abc" -> ""
#
# 3. DUPLICATE CHARACTERS IN t:
#    - Must have enough copies in window
#    - t_list tracks exact counts needed
#    Example: s = "aa", t = "aa" -> "aa"
#    Example: s = "a", t = "aa" -> "" (not enough a's)
#
# 4. CHARACTERS NOT IN s:
#    - Can never satisfy requirement
#    - c will never reach t_len
#    Example: s = "abc", t = "xyz" -> ""
#
# 5. s AND t IDENTICAL:
#    - Return s itself
#    Example: s = "abc", t = "abc" -> "abc"
#
# 6. SINGLE CHARACTER:
#    - Simple case
#    Example: s = "a", t = "a" -> "a"
#
# 7. WINDOW AT END OF STRING:
#    - Algorithm handles correctly
#    Example: s = "ADOBECODEBANC", t = "ABC" -> "BANC" (at the end)
#
# 8. CASE SENSITIVITY:
#    - 'A' and 'a' are different (different ASCII values)
#    - t_list[65] for 'A', t_list[97] for 'a'
#    Example: s = "Aa", t = "aA" -> "Aa"
#
# =============================================================================


# =============================================================================
# COMPLEXITY ANALYSIS
# =============================================================================
#
# TIME COMPLEXITY: O(m + n)
# -------------------------
# Where m = len(s), n = len(t)
#
# 1. Building t_list from t: O(n)
#    - Single pass through t
#
# 2. Sliding window through s: O(m)
#    - Right pointer visits each character once: O(m)
#    - Left pointer visits each character at most once: O(m)
#    - Total: O(2m) = O(m)
#    - Each pointer move involves O(1) operations:
#      * Array access: O(1)
#      * Integer comparison: O(1)
#      * String slicing for result: O(window_size) but only when updating minimum
#
# 3. Total: O(n + m) = O(m + n)
#
# Note: String slicing s[l:r+1] is O(window_size), but this happens at most m
# times and the total work is bounded by O(m) across all updates.
#
# SPACE COMPLEXITY: O(1) or O(128)
# --------------------------------
#
# 1. t_list array: O(256) = O(1)
#    - Fixed size, independent of input
#    - Only uses ASCII characters (256 possible values)
#
# 2. Variables (l, r, c, min_len): O(1)
#    - Constant number of integer variables
#
# 3. Output string: O(m) in worst case
#    - Could be the entire string s
#
# Total: O(1) for auxiliary space (excluding output)
#
# COMPARISON WITH HASHMAP APPROACH:
# ---------------------------------
# Hashmap approach: O(m + n) space for two hashmaps
# Array approach: O(256) = O(1) space
#
# The array approach is more space-efficient when the character set is known
# and bounded (like ASCII).
#
# =============================================================================


# =============================================================================
# KEY INSIGHTS SUMMARY - WHY SINGLE ARRAY IS ELEGANT
# =============================================================================
#
# 1. SINGLE SOURCE OF TRUTH:
#    - One array tracks both "what we need" AND "what we have"
#    - Positive = deficit (need more)
#    - Zero/Negative = surplus (have enough or extra)
#
# 2. SIMPLE VALIDITY CHECK:
#    - Instead of checking all character frequencies
#    - Just check if c == t_len
#    - O(1) instead of O(k) where k = unique characters
#
# 3. UNIFIED COUNTING:
#    - c counts TOTAL matched characters, not unique ones
#    - Handles duplicates naturally
#    - If t = "AAB", c reaches 3 when we have 2 A's and 1 B
#
# 4. INTUITIVE STATE TRANSITIONS:
#    - Adding char: decrement t_list (we got one, need one less)
#    - Removing char: increment t_list (we lost one, need one more)
#    - c only changes when crossing the zero boundary
#
# 5. NO EXTRA DATA STRUCTURES:
#    - No Counter, no defaultdict, no second hashmap
#    - Just a simple array and a counter
#    - Memory-efficient and cache-friendly
#
# 6. CONSTANT TIME OPERATIONS:
#    - Array indexing is O(1)
#    - Comparison is O(1)
#    - No hash function computation overhead
#
# COMPARISON:
# -----------
# Two Hashmap Approach:
#   - need = Counter(t)
#   - window = defaultdict(int)
#   - formed = count of unique chars satisfied
#   - Check: if char in need and window[char] == need[char]: formed += 1
#
# Single Array Approach:
#   - t_list = [0] * 256
#   - c = total matched count
#   - Check: if t_list[ord(char)] > 0: c += 1
#
# The single array approach is cleaner, faster, and uses less memory!
#
# =============================================================================


# Test the solution
if __name__ == "__main__":
    solution = Solution()

    print("=" * 70)
    print("MINIMUM WINDOW SUBSTRING - TEST CASES")
    print("=" * 70)
    print()

    # Test Case 1: Standard case
    s1, t1 = "ADOBECODEBANC", "ABC"
    result1 = solution.minWindow(s1, t1)
    print(f"Test 1: s = '{s1}', t = '{t1}'")
    print(f"Result: '{result1}'")
    print(f"Expected: 'BANC'")
    print(f"Pass: {result1 == 'BANC'}")
    print()

    # Test Case 2: Single character match
    s2, t2 = "a", "a"
    result2 = solution.minWindow(s2, t2)
    print(f"Test 2: s = '{s2}', t = '{t2}'")
    print(f"Result: '{result2}'")
    print(f"Expected: 'a'")
    print(f"Pass: {result2 == 'a'}")
    print()

    # Test Case 3: Not enough characters
    s3, t3 = "a", "aa"
    result3 = solution.minWindow(s3, t3)
    print(f"Test 3: s = '{s3}', t = '{t3}'")
    print(f"Result: '{result3}'")
    print(f"Expected: ''")
    print(f"Pass: {result3 == ''}")
    print()

    # Test Case 4: Exact match with duplicates
    s4, t4 = "aa", "aa"
    result4 = solution.minWindow(s4, t4)
    print(f"Test 4: s = '{s4}', t = '{t4}'")
    print(f"Result: '{result4}'")
    print(f"Expected: 'aa'")
    print(f"Pass: {result4 == 'aa'}")
    print()

    # Test Case 5: Empty t
    s5, t5 = "abc", ""
    result5 = solution.minWindow(s5, t5)
    print(f"Test 5: s = '{s5}', t = '{t5}'")
    print(f"Result: '{result5}'")
    print(f"Expected: ''")
    print(f"Pass: {result5 == ''}")
    print()

    # Test Case 6: t longer than s
    s6, t6 = "a", "abc"
    result6 = solution.minWindow(s6, t6)
    print(f"Test 6: s = '{s6}', t = '{t6}'")
    print(f"Result: '{result6}'")
    print(f"Expected: ''")
    print(f"Pass: {result6 == ''}")
    print()

    # Test Case 7: Characters not in s
    s7, t7 = "abc", "xyz"
    result7 = solution.minWindow(s7, t7)
    print(f"Test 7: s = '{s7}', t = '{t7}'")
    print(f"Result: '{result7}'")
    print(f"Expected: ''")
    print(f"Pass: {result7 == ''}")
    print()

    # Test Case 8: Mixed case
    s8, t8 = "AbCdEfBaC", "ABC"
    result8 = solution.minWindow(s8, t8)
    print(f"Test 8: s = '{s8}', t = '{t8}'")
    print(f"Result: '{result8}'")
    print(f"Expected: 'BaC'")
    print(f"Pass: {result8 == 'BaC'}")
    print()

    print("=" * 70)
    print("BRUTE FORCE COMPARISON")
    print("=" * 70)
    print()

    # Compare brute force with optimal for smaller inputs
    s_bf, t_bf = "ADOBECODEBANC", "ABC"
    bf_result = brute_force(s_bf, t_bf)
    opt_result = solution.minWindow(s_bf, t_bf)
    print(f"s = '{s_bf}', t = '{t_bf}'")
    print(f"Brute Force Result: '{bf_result}'")
    print(f"Optimal Result: '{opt_result}'")
    print(f"Match: {bf_result == opt_result}")
