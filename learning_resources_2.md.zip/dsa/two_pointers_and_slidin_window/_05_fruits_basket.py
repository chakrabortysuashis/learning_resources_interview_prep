# Question
"""
904. Fruit Into Baskets

You are visiting a farm that has a single row of fruit trees arranged from left to right. The trees are represented by an integer array fruits where fruits[i] is the type of fruit the ith tree produces.

You want to collect as much fruit as possible. However, the owner has some strict rules that you must follow:

You only have two baskets, and each basket can only hold a single type of fruit. There is no limit on the amount of fruit each basket can hold.
Starting from any tree of your choice, you must pick exactly one fruit from every tree (including the start tree) while moving to the right. The picked fruits must fit in one of your baskets.
Once you reach a tree with fruit that cannot fit in your baskets, you must stop.
Given the integer array fruits, return the maximum number of fruits you can pick.

 

Example 1:

Input: fruits = [1,2,1]
Output: 3
Explanation: We can pick from all 3 trees.
Example 2:

Input: fruits = [0,1,2,2]
Output: 3
Explanation: We can pick from trees [1,2,2].
If we had started at the first tree, we would only pick from trees [0,1].
Example 3:

Input: fruits = [1,2,3,2,2]
Output: 4
Explanation: We can pick from trees [2,3,2,2].
If we had started at the first tree, we would only pick from trees [1,2].
 

Constraints:

1 <= fruits.length <= 105
0 <= fruits[i] < fruits.length
 """
 
 
class Solution(object):
    """
    Problem intuition
    -----------------
    We need the longest contiguous segment that contains at most 2 distinct values.
    Why contiguous? Because we must pick from a starting tree and keep moving right
    without skipping any tree.

    Equivalent DSA view:
    - Find the length of the longest subarray with <= 2 distinct numbers.

    ---------------------------------------------------------------------------
    1) Brute-force idea (for learning)
    ---------------------------------------------------------------------------
    Start at every index i, keep extending j to the right, track distinct fruit
    types in that subarray, and stop when types become > 2.

    Time complexity (brute force):
    - O(n^2) in worst case, because for each start index we may scan far right.
    Space complexity (brute force):
    - O(1) to O(k), here k <= 3 while checking validity, effectively constant.

    ---------------------------------------------------------------------------
    2) Optimal idea: Sliding Window + Frequency Map
    ---------------------------------------------------------------------------
    Keep a window [left, right] that is always valid (<= 2 types).

    - Expand right to include new fruit.
    - If window becomes invalid (> 2 types), shrink from left until valid.
    - Record maximum valid window length.

    Each index enters and exits window at most once -> O(n) time.

    ---------------------------------------------------------------------------
    Mandatory dry runs (2 examples)
    ---------------------------------------------------------------------------
    Example A: fruits = [1, 2, 1]

    | step | right fruit | basket after add | left after fix | valid window | len | max |
    |------|-------------|------------------|----------------|--------------|-----|-----|
    | 1    | 1           | {1:1}            | 0              | [1]          | 1   | 1   |
    | 2    | 2           | {1:1,2:1}        | 0              | [1,2]        | 2   | 2   |
    | 3    | 1           | {1:2,2:1}        | 0              | [1,2,1]      | 3   | 3   |

    Answer = 3

    Example B: fruits = [1, 2, 3, 2, 2]

    | step | right fruit | basket after add | action if invalid                     | left | valid window   | len | max |
    |------|-------------|------------------|----------------------------------------|------|----------------|-----|-----|
    | 1    | 1           | {1:1}            | valid                                  | 0    | [1]            | 1   | 1   |
    | 2    | 2           | {1:1,2:1}        | valid                                  | 0    | [1,2]          | 2   | 2   |
    | 3    | 3           | {1:1,2:1,3:1}    | remove fruits[left]=1 -> {2:1,3:1}     | 1    | [2,3]          | 2   | 2   |
    | 4    | 2           | {2:2,3:1}        | valid                                  | 1    | [2,3,2]        | 3   | 3   |
    | 5    | 2           | {2:3,3:1}        | valid                                  | 1    | [2,3,2,2]      | 4   | 4   |

    Answer = 4
    """

    def totalFruit_TwoPointers(self, fruits):
        """
        Sliding window with full shrinking (canonical version).

        :type fruits: List[int]
        :rtype: int

        Time Complexity:
            O(n) -> each index is processed by right pointer once and removed by
            left pointer at most once.

        Space Complexity:
            O(1) practical (at most 3 keys temporarily during correction),
            or O(k) in generic form where k = max allowed distinct types.
        """

        left = right = max_len = 0

        # basket[fruit_type] = count inside current window [left, right]
        basket = {}
        max_type_allowed = 2

        while right < len(fruits):
            # Expand window by including fruits[right]
            basket[fruits[right]] = basket.get(fruits[right], 0) + 1

            # If invalid (> 2 types), keep shrinking until valid
            while len(basket) > max_type_allowed:
                basket[fruits[left]] -= 1
                if basket[fruits[left]] == 0:
                    del basket[fruits[left]]
                left += 1

            # Now window is valid, so update answer
            max_len = max(max_len, right - left + 1)
            right += 1

        return max_len

    def totalFruit(self, fruits):
        """
        Slightly optimized style of the same idea.

        Difference from canonical version:
        - Instead of a while-loop shrink, it performs one shrink step whenever
          invalid. Across iterations, this still converges and remains O(n).

        Time Complexity:
            O(n)
        Space Complexity:
            O(1) practical (map holds very small number of types)
        """

        left = right = max_len = 0
        max_allowed_type = 2
        basket = {}

        while right < len(fruits):
            basket[fruits[right]] = basket.get(fruits[right], 0) + 1

            # If invalid, shrink from left by one step.
            if len(basket) > max_allowed_type:
                basket[fruits[left]] -= 1
                if basket[fruits[left]] == 0:
                    del basket[fruits[left]]
                left += 1
            else:
                # Update only when valid.
                max_len = max(max_len, right - left + 1)

            right += 1

        return max_len


# Note:
# In interviews, prefer totalFruit_TwoPointers (canonical window repair with while)
# because the validity invariant is explicit and easiest to reason about.






            