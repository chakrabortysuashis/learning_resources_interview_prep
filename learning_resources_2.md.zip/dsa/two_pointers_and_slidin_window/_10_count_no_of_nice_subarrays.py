"""
================================================================================
PROBLEM: Count Number of Nice Subarrays (LeetCode 1248)
================================================================================

Given an array of integers nums and an integer k. A continuous subarray is
called "nice" if there are exactly k odd numbers in it.

Return the number of nice sub-arrays.

Example 1:
    Input: nums = [1,1,2,1,1], k = 3
    Output: 2
    Explanation: The only sub-arrays with 3 odd numbers are [1,1,2,1] and [1,2,1,1]

Example 2:
    Input: nums = [2,4,6], k = 1
    Output: 0
    Explanation: There are no odd numbers in the array.

Example 3:
    Input: nums = [2,2,2,1,2,2,1,2,2,2], k = 2
    Output: 16

Constraints:
    1 <= nums.length <= 50000
    1 <= nums[i] <= 10^5
    1 <= k <= nums.length

Link: https://leetcode.com/problems/count-number-of-nice-subarrays/description/


================================================================================
                    HOW TO CONNECT THIS TO A KNOWN PROBLEM
================================================================================

When you see a new problem, ask yourself:
    "Have I seen something similar before?"

Let's analyze what this problem is REALLY asking:

    NICE SUBARRAYS:                      BINARY SUBARRAYS WITH SUM:
    ─────────────────                    ─────────────────────────
    Count subarrays with                 Count subarrays with
    EXACTLY k ODD numbers                EXACTLY goal SUM (of 1s)

    Array: any integers                  Array: only 0s and 1s

    Odd numbers "contribute" 1           1s "contribute" 1
    Even numbers "contribute" 0          0s "contribute" 0


    THE KEY INSIGHT:
    ════════════════════════════════════════════════════════════════════════

    If we TRANSFORM each number to:
        - 1 if it's ODD
        - 0 if it's EVEN

    Then counting "subarrays with k odd numbers" becomes
         counting "subarrays with sum = k" in a BINARY array!

    THIS IS EXACTLY THE SAME AS PROBLEM #09 (Binary Subarrays With Sum)!
    ════════════════════════════════════════════════════════════════════════


================================================================================
                    STEP-BY-STEP: HOW TO APPROACH THIS PROBLEM
================================================================================

Step 1: RECOGNIZE THE PATTERN
─────────────────────────────
    - "Count subarrays with exactly K of something"
    - This screams: atMost(K) - atMost(K-1) technique!

Step 2: IDENTIFY WHAT WE'RE COUNTING
────────────────────────────────────
    - We're counting ODD numbers (not summing values)
    - Odd number → contributes 1 to count
    - Even number → contributes 0 to count

Step 3: REALIZE THE TRANSFORMATION
──────────────────────────────────
    Original:  [1,  1,  2,  1,  1]
                ↓   ↓   ↓   ↓   ↓
    Binary:    [1,  1,  0,  1,  1]  (odd=1, even=0)

    Now: "count of odd numbers" = "sum of binary array"

Step 4: APPLY THE KNOWN SOLUTION
────────────────────────────────
    We don't even need to CREATE a new array!
    Just use (num % 2) to check if odd:
        - num % 2 == 1 → odd → add 1 to sum
        - num % 2 == 0 → even → add 0 to sum


================================================================================
            VISUAL TRANSFORMATION: Nice Subarrays → Binary Subarrays
================================================================================

Example: nums = [1, 1, 2, 1, 1], k = 3

Step 1: Mark odd/even

    Index:     0    1    2    3    4
    Original: [1,   1,   2,   1,   1]
               ↓    ↓    ↓    ↓    ↓
    Is Odd?   YES  YES  NO   YES  YES
               ↓    ↓    ↓    ↓    ↓
    Binary:   [1,   1,   0,   1,   1]

Step 2: Now we need subarrays with sum = 3 (exactly 3 ones = exactly 3 odd numbers)

Step 3: Apply atMost(k) - atMost(k-1) technique from Problem #09!


================================================================================
                    SOLUTION 1: SLIDING WINDOW (atMost Technique)
================================================================================
"""

from typing import List
from collections import defaultdict


class Solution:
    def numberOfSubarrays(self, nums: List[int], k: int) -> int:
        """
        Count subarrays with exactly k odd numbers.

        TRANSFORMATION: Instead of summing values, count odd numbers.
        This is equivalent to Binary Subarrays with Sum where:
            - odd number → 1
            - even number → 0

        Formula: exactly(k) = atMost(k) - atMost(k-1)
        """

        def count_at_most(k: int) -> int:
            """
            Count subarrays with AT MOST k odd numbers.

            Same logic as Binary Subarrays problem, but we count odd numbers
            instead of summing 1s.
            """
            if k < 0:
                return 0

            left = 0
            odd_count = 0  # Count of odd numbers in current window
            result = 0

            for right in range(len(nums)):
                # Add current element: increment odd_count if number is odd
                # nums[right] % 2 gives 1 for odd, 0 for even
                odd_count += nums[right] % 2

                # Shrink window if we have MORE than k odd numbers
                while odd_count > k:
                    # Remove left element: decrement if it was odd
                    odd_count -= nums[left] % 2
                    left += 1

                # Count all valid subarrays ending at 'right'
                # Same as Binary Subarrays: (right - left + 1)
                result += (right - left + 1)

            return result

        # THE MAGIC FORMULA (same as Problem #09):
        # Subarrays with EXACTLY k odd numbers = atMost(k) - atMost(k-1)
        return count_at_most(k) - count_at_most(k - 1)


"""
================================================================================
        DRY RUN 1: nums = [1, 1, 2, 1, 1], k = 3
================================================================================

First, let's visualize the transformation:

    Index:     0    1    2    3    4
    Original: [1,   1,   2,   1,   1]
    Is Odd?:  [1,   1,   0,   1,   1]  (conceptually, we count odds)

We need subarrays with EXACTLY 3 odd numbers.

────────────────────────────────────────────────────────────────────────────────
PART 1: Calculate atMost(3) - subarrays with at most 3 odd numbers
────────────────────────────────────────────────────────────────────────────────

Initial: left=0, odd_count=0, result=0

right=0, nums[0]=1 (ODD):
    odd_count = 0 + (1 % 2) = 0 + 1 = 1
    1 <= 3? YES, no shrinking
    result += (0 - 0 + 1) = 1
    result = 1
    Window: [1]  Odd count: 1

right=1, nums[1]=1 (ODD):
    odd_count = 1 + (1 % 2) = 1 + 1 = 2
    2 <= 3? YES, no shrinking
    result += (1 - 0 + 1) = 2
    result = 3
    Window: [1,1]  Odd count: 2
    Valid subarrays ending here: [1], [1,1]

right=2, nums[2]=2 (EVEN):
    odd_count = 2 + (2 % 2) = 2 + 0 = 2
    2 <= 3? YES, no shrinking
    result += (2 - 0 + 1) = 3
    result = 6
    Window: [1,1,2]  Odd count: 2
    Valid subarrays ending here: [2], [1,2], [1,1,2]

right=3, nums[3]=1 (ODD):
    odd_count = 2 + (1 % 2) = 2 + 1 = 3
    3 <= 3? YES, no shrinking
    result += (3 - 0 + 1) = 4
    result = 10
    Window: [1,1,2,1]  Odd count: 3
    Valid subarrays ending here: [1], [2,1], [1,2,1], [1,1,2,1]

right=4, nums[4]=1 (ODD):
    odd_count = 3 + (1 % 2) = 3 + 1 = 4
    4 <= 3? NO! Need to shrink

    SHRINK:
        odd_count -= nums[0] % 2 = 4 - 1 = 3, left = 1
        3 <= 3? YES, stop shrinking

    result += (4 - 1 + 1) = 4
    result = 14
    Window: [1,2,1,1]  Odd count: 3
    Valid subarrays ending here: [1], [1,1], [2,1,1], [1,2,1,1]

atMost(3) = 14

────────────────────────────────────────────────────────────────────────────────
PART 2: Calculate atMost(2) - subarrays with at most 2 odd numbers
────────────────────────────────────────────────────────────────────────────────

Initial: left=0, odd_count=0, result=0

right=0, nums[0]=1 (ODD):
    odd_count = 0 + 1 = 1
    1 <= 2? YES
    result += 1
    result = 1

right=1, nums[1]=1 (ODD):
    odd_count = 1 + 1 = 2
    2 <= 2? YES
    result += 2
    result = 3

right=2, nums[2]=2 (EVEN):
    odd_count = 2 + 0 = 2
    2 <= 2? YES
    result += 3
    result = 6

right=3, nums[3]=1 (ODD):
    odd_count = 2 + 1 = 3
    3 <= 2? NO! Shrink

    SHRINK:
        odd_count -= nums[0] % 2 = 3 - 1 = 2, left = 1
        2 <= 2? YES, stop

    result += (3 - 1 + 1) = 3
    result = 9
    Window: [1,2,1]

right=4, nums[4]=1 (ODD):
    odd_count = 2 + 1 = 3
    3 <= 2? NO! Shrink

    SHRINK:
        odd_count -= nums[1] % 2 = 3 - 1 = 2, left = 2
        2 <= 2? YES, stop

    result += (4 - 2 + 1) = 3
    result = 12
    Window: [2,1,1]

atMost(2) = 12

────────────────────────────────────────────────────────────────────────────────
FINAL ANSWER: atMost(3) - atMost(2) = 14 - 12 = 2
────────────────────────────────────────────────────────────────────────────────

The 2 subarrays with EXACTLY 3 odd numbers:
1. [1, 1, 2, 1]  indices [0, 3]  odd numbers: 1, 1, 1 = 3 odds
2. [1, 2, 1, 1]  indices [1, 4]  odd numbers: 1, 1, 1 = 3 odds


================================================================================
        DRY RUN 2: nums = [2, 2, 2, 1, 2, 2, 1, 2, 2, 2], k = 2
================================================================================

Transformation (mark odds):
    Index:      0   1   2   3   4   5   6   7   8   9
    Original:  [2,  2,  2,  1,  2,  2,  1,  2,  2,  2]
    Is Odd?:   [0,  0,  0,  1,  0,  0,  1,  0,  0,  0]

Only indices 3 and 6 have odd numbers.
We need exactly 2 odd numbers in subarray.

Key insight: Any subarray containing BOTH index 3 AND index 6 has exactly 2 odds!

The flexibility comes from how many EVEN numbers we include on left/right:
- Left side of index 3: can include 0, 1, 2, or 3 evens (indices 0,1,2)
  → 4 choices (include none, just 2, or 2+2, or 2+2+2)

- Right side of index 6: can include 0, 1, 2, or 3 evens (indices 7,8,9)
  → 4 choices

Total combinations: 4 × 4 = 16 ✓

Let's verify with our algorithm:

atMost(2) counts ALL subarrays with 0, 1, or 2 odd numbers
atMost(1) counts ALL subarrays with 0 or 1 odd number

atMost(2) - atMost(1) = subarrays with EXACTLY 2 odd numbers = 16


================================================================================
        SOLUTION 2: PREFIX SUM WITH HASHMAP
================================================================================

Same technique as Problem #09, but count odd numbers instead of summing 1s.
"""


def numberOfSubarrays_PrefixSum(nums: List[int], k: int) -> int:
    """
    Count subarrays with exactly k odd numbers using prefix sum + hashmap.

    prefix_sum here = count of odd numbers from start to current position

    Same logic as Binary Subarrays:
    - If prefix_sum[j] - prefix_sum[i] = k, then subarray [i+1, j] has k odds
    """

    # Count of each prefix sum (number of odds seen so far)
    prefix_count = defaultdict(int)
    prefix_count[0] = 1  # Empty prefix has 0 odd numbers

    odd_count = 0  # Running count of odd numbers (prefix sum)
    result = 0

    for num in nums:
        # Add 1 to odd_count if current number is odd
        odd_count += num % 2

        # How many previous positions had (odd_count - k) odds?
        # Each such position is a valid starting point!
        target = odd_count - k
        result += prefix_count[target]

        # Record current prefix sum for future elements
        prefix_count[odd_count] += 1

    return result


"""
================================================================================
    DRY RUN (PREFIX SUM): nums = [1, 1, 2, 1, 1], k = 3
================================================================================

Initial State:
    prefix_count = {0: 1}  (empty prefix has 0 odds)
    odd_count = 0
    result = 0

┌─────────────────────────────────────────────────────────────────────────────┐
│ ITERATION 1: num = 1 (index 0) - ODD                                        │
├─────────────────────────────────────────────────────────────────────────────┤
│   odd_count = 0 + (1 % 2) = 0 + 1 = 1                                       │
│   target = odd_count - k = 1 - 3 = -2                                       │
│   prefix_count[-2] = 0 (not found)                                          │
│   result += 0  →  result = 0                                                │
│   prefix_count[1] = 1                                                       │
│   prefix_count = {0: 1, 1: 1}                                               │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ ITERATION 2: num = 1 (index 1) - ODD                                        │
├─────────────────────────────────────────────────────────────────────────────┤
│   odd_count = 1 + 1 = 2                                                     │
│   target = 2 - 3 = -1                                                       │
│   prefix_count[-1] = 0 (not found)                                          │
│   result += 0  →  result = 0                                                │
│   prefix_count[2] = 1                                                       │
│   prefix_count = {0: 1, 1: 1, 2: 1}                                         │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ ITERATION 3: num = 2 (index 2) - EVEN                                       │
├─────────────────────────────────────────────────────────────────────────────┤
│   odd_count = 2 + (2 % 2) = 2 + 0 = 2                                       │
│   target = 2 - 3 = -1                                                       │
│   prefix_count[-1] = 0 (not found)                                          │
│   result += 0  →  result = 0                                                │
│   prefix_count[2] = 2                                                       │
│   prefix_count = {0: 1, 1: 1, 2: 2}                                         │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ ITERATION 4: num = 1 (index 3) - ODD                                        │
├─────────────────────────────────────────────────────────────────────────────┤
│   odd_count = 2 + 1 = 3                                                     │
│   target = 3 - 3 = 0                                                        │
│   prefix_count[0] = 1  ← FOUND!                                             │
│   result += 1  →  result = 1                                                │
│                                                                             │
│   What subarray? From start (empty prefix) to index 3                       │
│   [1, 1, 2, 1] has 3 odd numbers ✓                                          │
│                                                                             │
│   prefix_count[3] = 1                                                       │
│   prefix_count = {0: 1, 1: 1, 2: 2, 3: 1}                                   │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ ITERATION 5: num = 1 (index 4) - ODD                                        │
├─────────────────────────────────────────────────────────────────────────────┤
│   odd_count = 3 + 1 = 4                                                     │
│   target = 4 - 3 = 1                                                        │
│   prefix_count[1] = 1  ← FOUND!                                             │
│   result += 1  →  result = 2                                                │
│                                                                             │
│   What subarray? From position with prefix_sum=1 (after index 0) to index 4 │
│   [1, 2, 1, 1] (indices 1-4) has 3 odd numbers ✓                            │
│                                                                             │
│   prefix_count[4] = 1                                                       │
│   prefix_count = {0: 1, 1: 1, 2: 2, 3: 1, 4: 1}                             │
└─────────────────────────────────────────────────────────────────────────────┘

FINAL ANSWER: result = 2 ✓


================================================================================
                    CONNECTING THE TWO PROBLEMS
================================================================================

┌─────────────────────────────────────────────────────────────────────────────┐
│              BINARY SUBARRAYS WITH SUM          NICE SUBARRAYS              │
│              (Problem #09)                      (Problem #10)               │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  Array type:   Binary (0s and 1s)               Any integers                │
│                                                                             │
│  Goal:         Subarrays with sum = goal        Subarrays with k odd nums   │
│                                                                             │
│  What we count: 1s in subarray                  Odd numbers in subarray     │
│                                                                             │
│  Contribution:  1 contributes 1                 Odd contributes 1           │
│                 0 contributes 0                 Even contributes 0          │
│                                                                             │
│  Check:         if nums[i] == 1                 if nums[i] % 2 == 1         │
│                                                                             │
│  Formula:       atMost(goal) - atMost(goal-1)   atMost(k) - atMost(k-1)     │
│                                                                             │
│  Complexity:    O(n) time, O(1) space           O(n) time, O(1) space       │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

THE PATTERN:
═══════════════════════════════════════════════════════════════════════════════
Both problems are asking:
    "Count subarrays where the count of CERTAIN ELEMENTS equals K"

In Binary Subarrays:  "certain elements" = 1s
In Nice Subarrays:    "certain elements" = odd numbers

The SAME sliding window technique works because:
1. We're counting occurrences (not summing arbitrary values)
2. Each element contributes 0 or 1 to the count
3. This makes the count NON-DECREASING as we expand the window
4. So we can use atMost(k) - atMost(k-1) to get exactly(k)
═══════════════════════════════════════════════════════════════════════════════


================================================================================
                    TIME AND SPACE COMPLEXITY
================================================================================

SLIDING WINDOW (atMost Technique):
──────────────────────────────────
Time Complexity: O(n)
    - count_at_most() is called twice: O(n) + O(n) = O(2n) = O(n)
    - Each element is visited at most twice (once by right, once by left)
    - The % 2 operation is O(1)

Space Complexity: O(1)
    - Only using a constant number of variables
    - No additional data structures

PREFIX SUM + HASHMAP:
─────────────────────
Time Complexity: O(n)
    - Single pass through array
    - Each hashmap operation is O(1) average

Space Complexity: O(n)
    - Hashmap stores up to n+1 distinct prefix sums
    - In worst case (all odd numbers), prefix sums are 0, 1, 2, ..., n


================================================================================
                    PATTERN RECOGNITION GUIDE
================================================================================

When you see a problem asking to count subarrays with EXACTLY K of something:

┌─────────────────────────────────────────────────────────────────────────────┐
│ STEP 1: Identify what you're counting                                       │
│         - Sum of elements? → Use element values                             │
│         - Count of 1s? → Add 1 for each 1                                   │
│         - Count of odds? → Add (num % 2) for each element                   │
│         - Count of elements > x? → Add 1 if element > x                     │
├─────────────────────────────────────────────────────────────────────────────┤
│ STEP 2: Check if each element contributes 0 or 1                            │
│         - If YES → atMost(k) - atMost(k-1) works with O(1) space           │
│         - If NO (arbitrary values/negatives) → Use prefix sum + hashmap     │
├─────────────────────────────────────────────────────────────────────────────┤
│ STEP 3: Apply the technique                                                 │
│         - Sliding window: count (right - left + 1) at each position        │
│         - Prefix sum: count prefix_count[current - goal] at each position  │
└─────────────────────────────────────────────────────────────────────────────┘


================================================================================
                    MORE SIMILAR PROBLEMS
================================================================================

These problems ALL use the same pattern:

1. Binary Subarrays with Sum (LC 930)
   - Count subarrays with sum = goal in binary array

2. Count Number of Nice Subarrays (LC 1248) - THIS PROBLEM
   - Count subarrays with exactly k odd numbers

3. Subarrays with K Different Integers (LC 992)
   - Count subarrays with exactly k distinct integers
   - Uses same atMost(k) - atMost(k-1) pattern!

4. Count Vowel Substrings (LC 2062)
   - Count substrings with exactly 5 vowels

5. Number of Substrings Containing All Three Characters (LC 1358)
   - Uses similar counting technique

Master ONE of these problems deeply, and you've mastered them ALL!

================================================================================
"""


# Test the solutions
if __name__ == "__main__":
    sol = Solution()

    test_cases = [
        ([1, 1, 2, 1, 1], 3, 2),           # Example 1
        ([2, 4, 6], 1, 0),                  # Example 2 (no odds)
        ([2, 2, 2, 1, 2, 2, 1, 2, 2, 2], 2, 16),  # Example 3
        ([1], 1, 1),                        # Single odd
        ([2], 1, 0),                        # Single even, need 1 odd
        ([1, 1, 1, 1, 1], 1, 5),            # All odds, need 1
        ([1, 1, 1, 1, 1], 5, 1),            # All odds, need all
    ]

    print("=" * 70)
    print("TESTING NICE SUBARRAYS - BOTH APPROACHES")
    print("=" * 70)

    for i, (nums, k, expected) in enumerate(test_cases, 1):
        # Test Sliding Window approach
        result_sw = sol.numberOfSubarrays(nums, k)

        # Test Prefix Sum approach
        result_ps = numberOfSubarrays_PrefixSum(nums, k)

        status = "PASS" if result_sw == result_ps == expected else "FAIL"

        print(f"\nTest {i}: nums={nums}, k={k}")
        print(f"  Sliding Window: {result_sw}")
        print(f"  Prefix Sum:     {result_ps}")
        print(f"  Expected:       {expected}")
        print(f"  Status: {status}")

    print("\n" + "=" * 70)
    print("All tests completed!")
    print("=" * 70)
