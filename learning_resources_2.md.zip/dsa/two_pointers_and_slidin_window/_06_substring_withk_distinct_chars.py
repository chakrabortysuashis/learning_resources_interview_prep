"""Longest Substring with At Most K Distinct Characters

Problem Statement
-----------------
Given a string ``s`` and an integer ``k``, return the length of the
longest substring that contains **at most k distinct characters**.

Examples
--------
1) Input : s = "aababbcaacc", k = 2
   Output: 6
   Reason: longest valid substring is "aababb" (2 distinct chars: a, b)

2) Input : s = "abcddefg", k = 3
   Output: 4
   Reason: longest valid substring is "bcdd" (3 distinct chars: b, c, d)

===============================================================================
1) Understand the problem in simple words
===============================================================================
We need a continuous part of the string (substring), not scattered characters.
Among all possible substrings, pick the longest one such that the number of
unique characters inside it is <= k.

If k = 0, no non-empty substring is valid, so answer is 0.

===============================================================================
2) Brute-force approach
===============================================================================
Idea:
- Start every substring from each index i.
- Extend to j (i..n-1), track distinct characters using a set.
- If distinct count exceeds k, stop extending from this i.
- Otherwise, update maximum length.

Why it works:
- It checks every possible starting position.
- For each start, it grows rightward until condition breaks.
- So we never miss any valid substring.

Complexity:
- Time: O(n^2) in worst case.
- Space: O(k) to O(alphabet_size) for tracking distinct characters.

===============================================================================
3) Optimized approach (Sliding Window + Hash Map)
===============================================================================
Bottleneck in brute force:
- We repeatedly rebuild information for overlapping substrings.

Optimization idea:
- Use two pointers: left and right, representing a current window s[left:right+1].
- Expand right step-by-step.
- Keep frequency map of chars in current window.
- If distinct chars > k, shrink from left until valid again.
- At every valid step, update max length.

Why this is optimal:
- Every character enters window once (when right moves).
- Every character leaves window at most once (when left moves).
- Total pointer movement is linear.

Complexity:
- Time: O(n)
- Space: O(k) average (or O(alphabet_size) worst-case bounded by charset)

===============================================================================
4) Dry Runs (mandatory)
===============================================================================
A) s = "aababbcaacc", k = 2

Window notation: [left..right]

Step | right char | freq map after add            | distinct | left moves?                     | window      | best
-----+------------+-------------------------------+----------+---------------------------------+-------------+-----
0    | a          | {a:1}                         | 1        | no                              | "a"         | 1
1    | a          | {a:2}                         | 1        | no                              | "aa"        | 2
2    | b          | {a:2,b:1}                     | 2        | no                              | "aab"       | 3
3    | a          | {a:3,b:1}                     | 2        | no                              | "aaba"      | 4
4    | b          | {a:3,b:2}                     | 2        | no                              | "aabab"     | 5
5    | b          | {a:3,b:3}                     | 2        | no                              | "aababb"    | 6
6    | c          | {a:3,b:3,c:1}                 | 3        | yes, move left until distinct=2 | "bb c" part | 6
     |            | after shrinking -> {b:2,c:1}  | 2        | left becomes 4                  | "bbc"       | 6
7    | a          | {b:2,c:1,a:1}                 | 3        | shrink -> {c:1,a:1}             | "ca"        | 6
8    | a          | {c:1,a:2}                     | 2        | no                              | "caa"       | 6
9    | c          | {c:2,a:2}                     | 2        | no                              | "caac"      | 6
10   | c          | {c:3,a:2}                     | 2        | no                              | "caacc"     | 6

Final answer = 6

B) s = "abcddefg", k = 3

Step | right char | freq map after add            | distinct | left moves?                     | window   | best
-----+------------+-------------------------------+----------+---------------------------------+----------+-----
0    | a          | {a:1}                         | 1        | no                              | "a"      | 1
1    | b          | {a:1,b:1}                     | 2        | no                              | "ab"     | 2
2    | c          | {a:1,b:1,c:1}                 | 3        | no                              | "abc"    | 3
3    | d          | {a:1,b:1,c:1,d:1}             | 4        | shrink -> remove a              | "bcd"    | 3
4    | d          | {b:1,c:1,d:2}                 | 3        | no                              | "bcdd"   | 4
5    | e          | {b:1,c:1,d:2,e:1}             | 4        | shrink until 3 distinct         | "dde"    | 4
6    | f          | {d:2,e:1,f:1} after shrink    | 3        | yes (once)                      | "ddef"   | 4
7    | g          | {d:1,e:1,f:1,g:1}             | 4        | shrink -> {e:1,f:1,g:1}         | "efg"    | 4

Final answer = 4
"""


def longest_substring_at_most_k_distinct_bruteforce(s: str, k: int) -> int:
    """Return answer using brute force (O(n^2))."""
    if k <= 0 or not s:
        return 0

    n = len(s)
    best = 0

    # Try every starting index i
    for i in range(n):
        seen = set()

        # Extend end index j from i to n-1
        for j in range(i, n):
            seen.add(s[j])

            # If distinct chars became more than k, no need to continue this i
            if len(seen) > k:
                break

            best = max(best, j - i + 1)

    return best


def longest_substring_at_most_k_distinct(s: str, k: int) -> int:
    """Return answer using optimal sliding window (O(n))."""
    if k <= 0 or not s:
        return 0

    left = 0
    best = 0
    freq = {}

    for right, ch in enumerate(s):
        # Include current character in the window
        freq[ch] = freq.get(ch, 0) + 1

        # If window becomes invalid (> k distinct), shrink from left until valid.
        while len(freq) > k:
            left_ch = s[left]
            freq[left_ch] -= 1
            if freq[left_ch] == 0:
                del freq[left_ch]
            left += 1

        # Current window [left..right] is valid
        best = max(best, right - left + 1)

    return best

def optimal_longest_substring_at_most_k_distinct(s: str, k: int) -> int:
    """Return answer using optimal sliding window (O(n))."""
    if k <= 0 or not s:
        return 0

    left = 0
    best = 0
    freq = {}
    # iterate over the string with right pointer and keep expanding the subarray using right.
    for right, ch in enumerate(s):
        # Include current character in the window
        freq[ch] = freq.get(ch, 0) + 1

        # If window becomes invalid (> k distinct), shrink one from left
        if len(freq) > k:
            left_ch = s[left]
            freq[left_ch] -= 1
            if freq[left_ch] == 0:
                del freq[left_ch]
            left += 1
        else:

            # Current window [left..right] is valid
            best = max(best, right - left + 1)

    return best


if __name__ == "__main__":
    print(optimal_longest_substring_at_most_k_distinct("aababbcaacc", 2))  # 6
    print(optimal_longest_substring_at_most_k_distinct("abcddefg", 3))     # 4
    print(longest_substring_at_most_k_distinct_bruteforce("aababbcaacc", 2))  # 6
    print(longest_substring_at_most_k_distinct_bruteforce("abcddefg", 3))     # 4

    # Edge cases
    print(optimal_longest_substring_at_most_k_distinct("", 2))   # 0
    print(optimal_longest_substring_at_most_k_distinct("abc", 0))  # 0
    print(optimal_longest_substring_at_most_k_distinct("aaaa", 1))  # 4

    # Optional sanity check: both methods should match
    test_s, test_k = "eceba", 2
    print(optimal_longest_substring_at_most_k_distinct(test_s, test_k))
    print(longest_substring_at_most_k_distinct_bruteforce(test_s, test_k))

# Time Complexity Summary:
# - Brute force: O(n^2)
# - Optimal sliding window: O(n)
#
# Space Complexity Summary:
# - Brute force: O(min(n, alphabet_size)) for set in inner loop.
# - Optimal: O(min(n, alphabet_size)) for frequency map (usually represented as O(k)
#   for a valid window, though temporary growth is bounded by charset and shrink loop).

# In interviews, use the optimal sliding-window function.
