# ============================================================================
# PROBLEM: Subarrays with K Different Integers (LeetCode 992 - Hard)
# ============================================================================
#
# PROBLEM UNDERSTANDING:
# ----------------------
# We need to count subarrays that have EXACTLY k different integers.
# A subarray is a contiguous part of the array.
#
# For nums = [1,2,1,2,3] and k = 2:
# Valid subarrays with exactly 2 distinct elements:
#   [1,2], [2,1], [1,2], [2,3], [1,2,1], [2,1,2], [1,2,1,2]
#   Total = 7
#
# ============================================================================
# APPROACH 1: BRUTE FORCE (Not Optimal)
# ============================================================================
#
# Idea: Check every possible subarray and count distinct elements.
#
# def brute_force(nums, k):
#     count = 0
#     n = len(nums)
#     for i in range(n):                    # Start of subarray
#         for j in range(i, n):             # End of subarray
#             distinct = len(set(nums[i:j+1]))
#             if distinct == k:
#                 count += 1
#     return count
#
# Time Complexity: O(n^3) - Two loops for subarrays, one for counting distinct
# Space Complexity: O(n) - For the set
#
# This is too slow for n = 20,000!
#
# ============================================================================
# WHY DIRECT SLIDING WINDOW FAILS FOR "EXACTLY K"
# ============================================================================
#
# With sliding window, we typically:
# - Expand right pointer to include more elements
# - Shrink left pointer when a condition is violated
#
# For "AT MOST K distinct" - this works perfectly:
# - When distinct count exceeds K, shrink from left
# - At each position, we can count valid subarrays
#
# For "EXACTLY K distinct" - this is tricky:
# - When we have exactly K, we cannot simply shrink (we might go below K)
# - When we have less than K, we cannot simply expand (we might overshoot)
# - The window boundaries are not well-defined
#
# ============================================================================
# THE BRILLIANT TRICK: exactly(K) = atMost(K) - atMost(K-1)
# ============================================================================
#
# Key Insight:
# - atMost(K) counts subarrays with 1, 2, 3, ..., or K distinct elements
# - atMost(K-1) counts subarrays with 1, 2, 3, ..., or K-1 distinct elements
# - The difference gives us subarrays with EXACTLY K distinct elements!
#
# Visual Representation:
#
#   atMost(K):     [1 distinct] + [2 distinct] + ... + [K-1 distinct] + [K distinct]
#   atMost(K-1):   [1 distinct] + [2 distinct] + ... + [K-1 distinct]
#   ---------------------------------------------------------------------------------
#   Difference:                                                         [K distinct]
#
# This is a very common pattern for "exactly K" problems!
#
# ============================================================================
# HOW atMost(K) SLIDING WINDOW WORKS
# ============================================================================
#
# For each right pointer position, we want to count:
# "How many subarrays ENDING at 'right' have at most K distinct elements?"
#
# Answer: All subarrays from index left to right, i.e., (right - left + 1) subarrays
#
# Why (right - left + 1)?
# If window is [left...right], valid subarrays ending at right are:
#   [left, right], [left+1, right], [left+2, right], ..., [right, right]
#   That's (right - left + 1) subarrays!
#
# Algorithm:
# 1. Use a hashmap to track frequency of elements in current window
# 2. Expand right pointer, add element to hashmap
# 3. While distinct count > K, shrink from left (remove elements)
# 4. Add (right - left + 1) to total count
#
# ============================================================================

"""Given an integer array nums and an integer k, return the number of good subarrays of nums.

A good array is an array where the number of different integers in that array is exactly k.

For example, [1,2,3,1,2] has 3 different integers: 1, 2, and 3.
A subarray is a contiguous part of an array.



Example 1:

Input: nums = [1,2,1,2,3], k = 2
Output: 7
Explanation: Subarrays formed with exactly 2 different integers: [1,2], [2,1], [1,2], [2,3], [1,2,1], [2,1,2], [1,2,1,2]
Example 2:

Input: nums = [1,2,1,3,4], k = 3
Output: 3
Explanation: Subarrays formed with exactly 3 different integers: [1,2,1,3], [2,1,3], [1,3,4].


Constraints:

1 <= nums.length <= 2 * 104
1 <= nums[i], k <= nums.length
 """

from collections import defaultdict


def atMostKDistinct(nums, k):
    """
    Helper function: Count subarrays with AT MOST k distinct integers.

    This uses the sliding window technique where:
    - We maintain a window [left, right] with at most k distinct elements
    - For each right position, we count all valid subarrays ending at right

    Args:
        nums: List of integers
        k: Maximum number of distinct integers allowed

    Returns:
        Total count of subarrays with at most k distinct integers
    """

    # Edge case: if k is 0, no valid subarrays exist
    if k == 0:
        return 0

    n = len(nums)

    # freq_map: Maps each element to its frequency in current window
    # Key = element value, Value = count of that element in window
    freq_map = defaultdict(int)

    # left: Left boundary of sliding window (inclusive)
    left = 0

    # total_count: Accumulator for total valid subarrays
    total_count = 0

    # Iterate with right pointer through the array
    for right in range(n):
        # ----------------------------------------------------------
        # STEP 1: Expand window - include nums[right] in window
        # ----------------------------------------------------------
        freq_map[nums[right]] += 1

        # ----------------------------------------------------------
        # STEP 2: Shrink window if we have more than k distinct
        # ----------------------------------------------------------
        # len(freq_map) gives us count of distinct elements
        # We shrink until we have at most k distinct elements
        while len(freq_map) > k:
            # Remove leftmost element from window
            freq_map[nums[left]] -= 1

            # If frequency becomes 0, remove from map entirely
            # This is crucial! We use len(freq_map) to count distinct elements
            if freq_map[nums[left]] == 0:
                del freq_map[nums[left]]

            # Move left pointer forward
            left += 1

        # ----------------------------------------------------------
        # STEP 3: Count valid subarrays ending at 'right'
        # ----------------------------------------------------------
        # Current window is [left, right] with at most k distinct
        # All subarrays ending at 'right' with start in [left, right] are valid
        # Number of such subarrays = right - left + 1
        #
        # Example: window = [1,2,1] at indices [0,1,2]
        # Subarrays ending at index 2: [1,2,1], [2,1], [1]
        # Count = 2 - 0 + 1 = 3
        total_count += (right - left + 1)

    return total_count


def subarraysWithKDistinct(nums, k):
    """
    Main function: Count subarrays with EXACTLY k distinct integers.

    Uses the formula: exactly(K) = atMost(K) - atMost(K-1)

    Why does this work?
    - atMost(K) includes all subarrays with 1,2,3,...,K distinct elements
    - atMost(K-1) includes all subarrays with 1,2,3,...,K-1 distinct elements
    - Subtracting removes the overlap, leaving only "exactly K" subarrays

    Args:
        nums: List of integers
        k: Exact number of distinct integers required

    Returns:
        Count of subarrays with exactly k distinct integers
    """

    # Calculate atMost(K) and atMost(K-1), then find their difference
    at_most_k = atMostKDistinct(nums, k)
    at_most_k_minus_1 = atMostKDistinct(nums, k - 1)

    # The difference gives us exactly K distinct
    return at_most_k - at_most_k_minus_1


# ============================================================================
# DRY RUN: Example 1 - nums = [1,2,1,2,3], k = 2
# ============================================================================
#
# We need: atMost(2) - atMost(1)
#
# --------------------------------------
# DRY RUN for atMost(2):
# --------------------------------------
#
# Initial: left=0, total_count=0, freq_map={}
#
# right=0, nums[right]=1:
#   freq_map = {1:1}, distinct=1 (<=2, no shrink)
#   Window: [1] at indices [0,0]
#   Subarrays ending at 0: [1]
#   total_count += (0-0+1) = 1
#   total_count = 1
#
# right=1, nums[right]=2:
#   freq_map = {1:1, 2:1}, distinct=2 (<=2, no shrink)
#   Window: [1,2] at indices [0,1]
#   Subarrays ending at 1: [1,2], [2]
#   total_count += (1-0+1) = 2
#   total_count = 3
#
# right=2, nums[right]=1:
#   freq_map = {1:2, 2:1}, distinct=2 (<=2, no shrink)
#   Window: [1,2,1] at indices [0,2]
#   Subarrays ending at 2: [1,2,1], [2,1], [1]
#   total_count += (2-0+1) = 3
#   total_count = 6
#
# right=3, nums[right]=2:
#   freq_map = {1:2, 2:2}, distinct=2 (<=2, no shrink)
#   Window: [1,2,1,2] at indices [0,3]
#   Subarrays ending at 3: [1,2,1,2], [2,1,2], [1,2], [2]
#   total_count += (3-0+1) = 4
#   total_count = 10
#
# right=4, nums[right]=3:
#   freq_map = {1:2, 2:2, 3:1}, distinct=3 (>2, need to shrink!)
#
#   Shrink iteration 1:
#     Remove nums[0]=1: freq_map = {1:1, 2:2, 3:1}, distinct=3
#     left = 1
#
#   Shrink iteration 2:
#     Remove nums[1]=2: freq_map = {1:1, 2:1, 3:1}, distinct=3
#     left = 2
#
#   Shrink iteration 3:
#     Remove nums[2]=1: freq_map = {2:1, 3:1}, distinct=2 (<=2, stop!)
#     left = 3
#
#   Window: [2,3] at indices [3,4]
#   Subarrays ending at 4: [2,3], [3]
#   total_count += (4-3+1) = 2
#   total_count = 12
#
# atMost(2) = 12
#
# --------------------------------------
# DRY RUN for atMost(1):
# --------------------------------------
#
# Initial: left=0, total_count=0, freq_map={}
#
# right=0, nums[right]=1:
#   freq_map = {1:1}, distinct=1 (<=1, no shrink)
#   Window: [1]
#   total_count += 1 = 1
#
# right=1, nums[right]=2:
#   freq_map = {1:1, 2:1}, distinct=2 (>1, shrink!)
#   Remove 1: freq_map = {2:1}, left=1
#   Window: [2]
#   total_count += 1 = 2
#
# right=2, nums[right]=1:
#   freq_map = {2:1, 1:1}, distinct=2 (>1, shrink!)
#   Remove 2: freq_map = {1:1}, left=2
#   Window: [1]
#   total_count += 1 = 3
#
# right=3, nums[right]=2:
#   freq_map = {1:1, 2:1}, distinct=2 (>1, shrink!)
#   Remove 1: freq_map = {2:1}, left=3
#   Window: [2]
#   total_count += 1 = 4
#
# right=4, nums[right]=3:
#   freq_map = {2:1, 3:1}, distinct=2 (>1, shrink!)
#   Remove 2: freq_map = {3:1}, left=4
#   Window: [3]
#   total_count += 1 = 5
#
# atMost(1) = 5
#
# --------------------------------------
# FINAL ANSWER:
# --------------------------------------
# exactly(2) = atMost(2) - atMost(1) = 12 - 5 = 7
#
# Let's verify the 7 subarrays manually:
# [1,2] (indices 0-1) - 2 distinct
# [2,1] (indices 1-2) - 2 distinct
# [1,2] (indices 2-3) - 2 distinct
# [2,3] (indices 3-4) - 2 distinct
# [1,2,1] (indices 0-2) - 2 distinct
# [2,1,2] (indices 1-3) - 2 distinct
# [1,2,1,2] (indices 0-3) - 2 distinct
# Total = 7  (Matches!)
#
# ============================================================================
# DRY RUN: Example 2 - nums = [1,2,1,3,4], k = 3
# ============================================================================
#
# atMost(3):
#   right=0: window=[1], count+=1, total=1
#   right=1: window=[1,2], count+=2, total=3
#   right=2: window=[1,2,1], count+=3, total=6
#   right=3: window=[1,2,1,3], count+=4, total=10
#   right=4: distinct becomes 4, shrink until [1,3,4], count+=3, total=13
# atMost(3) = 13
#
# atMost(2):
#   right=0: window=[1], count+=1, total=1
#   right=1: window=[1,2], count+=2, total=3
#   right=2: window=[1,2,1], count+=3, total=6
#   right=3: shrink to [1,3], count+=2, total=8
#   right=4: shrink to [3,4], count+=2, total=10
# atMost(2) = 10
#
# exactly(3) = 13 - 10 = 3
#
# The 3 subarrays: [1,2,1,3], [2,1,3], [1,3,4]  (Matches!)
#
# ============================================================================
# COMPLEXITY ANALYSIS
# ============================================================================
#
# Time Complexity: O(n)
# - We call atMostKDistinct twice, each taking O(n)
# - In each call, both left and right pointers move at most n times
# - Each element is added to hashmap once, removed at most once
# - Total: O(n) + O(n) = O(n)
#
# Space Complexity: O(k)
# - The hashmap stores at most k+1 distinct elements at any time
# - In worst case, this is O(min(n, k))
# - Since k <= n (given in constraints), it's O(k)
#
# ============================================================================
# EDGE CASES
# ============================================================================
#
# 1. k = 1: Looking for subarrays with only one distinct element
#    Example: [1,1,1,2,2] with k=1 -> [1], [1,1], [1,1,1], [2], [2,2] = 5
#
# 2. k = n (all elements distinct): Only one valid subarray - entire array
#    Example: [1,2,3] with k=3 -> [1,2,3] = 1
#
# 3. k > number of distinct elements: No valid subarrays exist
#    Example: [1,1,1] with k=2 -> 0
#
# 4. All elements same: Only k=1 gives valid subarrays
#    Example: [5,5,5,5] with k=1 -> all subarrays valid = n*(n+1)/2 = 10
#
# 5. Single element array:
#    [1] with k=1 -> 1 (the element itself)
#    [1] with k=2 -> 0 (impossible)
#
# ============================================================================
# ALTERNATIVE APPROACH: Single Pass with Two Pointers (Advanced)
# ============================================================================
#
# There exists a more space-efficient single-pass approach using two left
# pointers, but the atMost trick is more intuitive and commonly used in
# interviews. The single-pass approach maintains two windows to track the
# range where exactly k distinct elements exist.
#
# ============================================================================


# Testing the solution
if __name__ == "__main__":
    # Example 1
    nums1 = [1, 2, 1, 2, 3]
    k1 = 2
    result1 = subarraysWithKDistinct(nums1, k1)
    print(f"Example 1: nums={nums1}, k={k1}")
    print(f"Output: {result1}")  # Expected: 7
    print()

    # Example 2
    nums2 = [1, 2, 1, 3, 4]
    k2 = 3
    result2 = subarraysWithKDistinct(nums2, k2)
    print(f"Example 2: nums={nums2}, k={k2}")
    print(f"Output: {result2}")  # Expected: 3
    print()

    # Edge case: k = 1
    nums3 = [1, 1, 1, 2, 2]
    k3 = 1
    result3 = subarraysWithKDistinct(nums3, k3)
    print(f"Edge case (k=1): nums={nums3}, k={k3}")
    print(f"Output: {result3}")  # Expected: 6 (three [1]s, one [1,1], one [1,1,1], one [2], one [2,2])
    # Actually: [1], [1], [1], [1,1], [1,1], [1,1,1], [2], [2,2] = indices matter
    # Subarrays: [0:0], [1:1], [2:2], [0:1], [1:2], [0:2], [3:3], [4:4], [3:4] = 9
