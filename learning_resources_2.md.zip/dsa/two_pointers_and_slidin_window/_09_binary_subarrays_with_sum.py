"""
================================================================================
PROBLEM: Binary Subarrays With Sum (LeetCode 930)
================================================================================

Given a binary array nums and an integer goal, return the number of non-empty
subarrays with a sum equal to goal.

A subarray is a contiguous part of the array.

Example 1:
    Input: nums = [1,0,1,0,1], goal = 2
    Output: 4
    Explanation: The 4 subarrays are:
    [1,0,1,0,1]  -> indices [0,2] sum = 2
    [1,0,1,0,1]  -> indices [0,3] sum = 2
    [1,0,1,0,1]  -> indices [1,3] sum = 2 (includes leading 0)
    [1,0,1,0,1]  -> indices [2,4] sum = 2

Example 2:
    Input: nums = [0,0,0,0,0], goal = 0
    Output: 15

Constraints:
    1 <= nums.length <= 3 * 10^4
    nums[i] is either 0 or 1.
    0 <= goal <= nums.length

Link: https://leetcode.com/problems/binary-subarrays-with-sum/description/

================================================================================
UNDERSTANDING THE PROBLEM
================================================================================

We need to COUNT how many contiguous subarrays have a sum EXACTLY equal to goal.

Key observations:
- Array contains only 0s and 1s (binary array)
- Sum of subarray = count of 1s in that subarray
- We need EXACT sum, not "at most" or "at least"

================================================================================
APPROACH 1: BRUTE FORCE
================================================================================

Idea: Check every possible subarray and count those with sum = goal

def brute_force(nums, goal):
    n = len(nums)
    count = 0
    for i in range(n):           # Start of subarray
        current_sum = 0
        for j in range(i, n):    # End of subarray
            current_sum += nums[j]
            if current_sum == goal:
                count += 1
    return count

Time Complexity: O(n^2) - Two nested loops
Space Complexity: O(1)

This works but is too slow for large inputs!

================================================================================
WHY STANDARD SLIDING WINDOW DOESN'T WORK DIRECTLY
================================================================================

Normally, for "count subarrays with sum <= k", we use sliding window:
- Expand right pointer to add elements
- Shrink left pointer when sum exceeds k
- Count subarrays ending at right

BUT for "sum == k" (EXACTLY k), standard sliding window fails!

Why? Consider nums = [1,0,1,0,1], goal = 2

When window [1,0,1] has sum = 2:
- We found ONE valid subarray
- But [1,0,1,0] also has sum = 2!
- The trailing 0s create MULTIPLE valid subarrays with same sum

The problem: When we have exact sum, we cannot simply shrink the window.
Shrinking might skip valid subarrays that include trailing 0s.

================================================================================
THE KEY INSIGHT: atMost(k) - atMost(k-1) TECHNIQUE
================================================================================

This is a BRILLIANT trick for counting subarrays with EXACT sum:

    count(sum == k) = count(sum <= k) - count(sum <= k-1)

Visualization:

    All subarrays with sum <= k:     {sum=0, sum=1, sum=2, ..., sum=k}
    All subarrays with sum <= k-1:   {sum=0, sum=1, sum=2, ..., sum=k-1}

    Subtracting gives us:            {sum=k}  <-- EXACTLY what we want!

Why this works:
- atMost(k) counts ALL subarrays with sum 0, 1, 2, ..., k
- atMost(k-1) counts ALL subarrays with sum 0, 1, 2, ..., k-1
- The difference = subarrays with sum EXACTLY k

And counting "atMost(k)" IS solvable with standard sliding window!

================================================================================
HOW atMost(k) SLIDING WINDOW WORKS
================================================================================

For counting subarrays with sum <= k:

1. Use two pointers: left and right
2. Expand right to add elements to window
3. If sum > k, shrink from left until sum <= k
4. At each position of right, count valid subarrays ending at right
   - All subarrays from [left, right], [left+1, right], ..., [right, right]
   - Count = right - left + 1

Why (right - left + 1)?
    If window is [left...right] with valid sum <= k, then:
    - [right, right] is valid
    - [right-1, right] is valid (sum can only decrease or stay same)
    - ...
    - [left, right] is valid
    Total = (right - left + 1) subarrays ending at index 'right'

================================================================================
SOLUTION CODE WITH DETAILED COMMENTS
================================================================================
"""

from typing import List


class Solution:
    def numSubarraysWithSum(self, nums: List[int], goal: int) -> int:
        """
        Count subarrays with sum exactly equal to goal.
        Uses the formula: exactly(k) = atMost(k) - atMost(k-1)

        Args:
            nums: Binary array (contains only 0s and 1s)
            goal: Target sum we want

        Returns:
            Number of subarrays with sum exactly equal to goal
        """

        def count_at_most(k: int) -> int:
            """
            Count all subarrays with sum <= k using sliding window.

            Key idea: For each right endpoint, count how many valid
            subarrays END at that position.
            """
            # Edge case: if k < 0, no valid subarrays exist
            # This happens when goal = 0 and we call atMost(-1)
            if k < 0:
                return 0

            left = 0           # Left boundary of window
            current_sum = 0    # Sum of elements in current window
            count = 0          # Total count of valid subarrays

            # Expand window by moving right pointer
            for right in range(len(nums)):
                # Add current element to window sum
                current_sum += nums[right]

                # SHRINK window from left if sum exceeds k
                # We need sum <= k for valid subarrays
                while current_sum > k:
                    current_sum -= nums[left]
                    left += 1

                # COUNT: All subarrays ending at 'right' with sum <= k
                # These are: [left,right], [left+1,right], ..., [right,right]
                # Total count = right - left + 1
                count += (right - left + 1)

            return count

        # THE MAGIC FORMULA:
        # Subarrays with sum == goal = atMost(goal) - atMost(goal - 1)
        return count_at_most(goal) - count_at_most(goal - 1)


"""
================================================================================
DRY RUN 1: nums = [1, 0, 1, 0, 1], goal = 2
================================================================================

Step 1: Calculate atMost(2) - count subarrays with sum <= 2
------------------------------------------------------------------------

Initial: left=0, current_sum=0, count=0

right=0, nums[0]=1:
    current_sum = 0 + 1 = 1
    1 <= 2? YES, no shrinking needed
    count += (0 - 0 + 1) = 1
    Valid subarrays: [1]
    count = 1

right=1, nums[1]=0:
    current_sum = 1 + 0 = 1
    1 <= 2? YES, no shrinking needed
    count += (1 - 0 + 1) = 2
    Valid subarrays: [1,0], [0]
    count = 3

right=2, nums[2]=1:
    current_sum = 1 + 1 = 2
    2 <= 2? YES, no shrinking needed
    count += (2 - 0 + 1) = 3
    Valid subarrays: [1,0,1], [0,1], [1]
    count = 6

right=3, nums[3]=0:
    current_sum = 2 + 0 = 2
    2 <= 2? YES, no shrinking needed
    count += (3 - 0 + 1) = 4
    Valid subarrays: [1,0,1,0], [0,1,0], [1,0], [0]
    count = 10

right=4, nums[4]=1:
    current_sum = 2 + 1 = 3
    3 <= 2? NO! Need to shrink

    Shrinking:
        current_sum -= nums[0] = 3 - 1 = 2, left = 1
        2 <= 2? YES, stop shrinking

    count += (4 - 1 + 1) = 4
    Valid subarrays: [0,1,0,1], [1,0,1], [0,1], [1]
    count = 14

atMost(2) = 14

------------------------------------------------------------------------
Step 2: Calculate atMost(1) - count subarrays with sum <= 1
------------------------------------------------------------------------

Initial: left=0, current_sum=0, count=0

right=0, nums[0]=1:
    current_sum = 0 + 1 = 1
    1 <= 1? YES
    count += (0 - 0 + 1) = 1
    count = 1

right=1, nums[1]=0:
    current_sum = 1 + 0 = 1
    1 <= 1? YES
    count += (1 - 0 + 1) = 2
    count = 3

right=2, nums[2]=1:
    current_sum = 1 + 1 = 2
    2 <= 1? NO! Shrink

    Shrinking:
        current_sum -= nums[0] = 2 - 1 = 1, left = 1
        1 <= 1? YES, stop

    count += (2 - 1 + 1) = 2
    Valid subarrays: [0,1], [1]
    count = 5

right=3, nums[3]=0:
    current_sum = 1 + 0 = 1
    1 <= 1? YES
    count += (3 - 1 + 1) = 3
    Valid subarrays: [0,1,0], [1,0], [0]
    count = 8

right=4, nums[4]=1:
    current_sum = 1 + 1 = 2
    2 <= 1? NO! Shrink

    Shrinking:
        current_sum -= nums[1] = 2 - 0 = 2, left = 2
        2 <= 1? NO! Continue shrinking
        current_sum -= nums[2] = 2 - 1 = 1, left = 3
        1 <= 1? YES, stop

    count += (4 - 3 + 1) = 2
    Valid subarrays: [0,1], [1]
    count = 10

atMost(1) = 10

------------------------------------------------------------------------
Final Answer: atMost(2) - atMost(1) = 14 - 10 = 4
------------------------------------------------------------------------

The 4 subarrays with sum EXACTLY 2:
1. [1,0,1]     -> indices [0,2]
2. [1,0,1,0]   -> indices [0,3]
3. [0,1,0,1]   -> indices [1,4]
4. [1,0,1]     -> indices [2,4]


================================================================================
DRY RUN 2: nums = [0, 0, 0, 0, 0], goal = 0
================================================================================

This is an interesting edge case where goal = 0!

Step 1: Calculate atMost(0)
------------------------------------------------------------------------

All subarrays have sum 0 (no 1s in array), so ALL subarrays are valid.

For array of length n=5:
    Subarrays of length 1: 5
    Subarrays of length 2: 4
    Subarrays of length 3: 3
    Subarrays of length 4: 2
    Subarrays of length 5: 1
    Total = 5 + 4 + 3 + 2 + 1 = 15

Let's verify with sliding window:
    right=0: count += 1,  count = 1
    right=1: count += 2,  count = 3
    right=2: count += 3,  count = 6
    right=3: count += 4,  count = 10
    right=4: count += 5,  count = 15

atMost(0) = 15

Step 2: Calculate atMost(-1)
------------------------------------------------------------------------

k = -1 < 0, so we return 0 immediately (no subarray can have negative sum)

atMost(-1) = 0

------------------------------------------------------------------------
Final Answer: atMost(0) - atMost(-1) = 15 - 0 = 15
------------------------------------------------------------------------

All 15 subarrays have sum exactly 0!


================================================================================
EDGE CASES ANALYSIS
================================================================================

1. goal = 0:
   - We need atMost(0) - atMost(-1)
   - atMost(-1) returns 0 (handled by if k < 0 check)
   - Answer = count of subarrays with all 0s

2. All zeros array:
   - Every subarray has sum 0
   - Total subarrays = n*(n+1)/2
   - If goal = 0, answer = n*(n+1)/2
   - If goal > 0, answer = 0

3. All ones array:
   - Subarray of length L has sum L
   - Subarrays with sum = goal have length exactly 'goal'
   - Number of such subarrays = n - goal + 1 (if goal <= n)

4. goal > number of 1s in array:
   - No valid subarrays exist
   - Answer = 0

5. Single element array:
   - nums = [1], goal = 1 -> Answer = 1
   - nums = [0], goal = 0 -> Answer = 1
   - nums = [1], goal = 0 -> Answer = 0


================================================================================
TIME AND SPACE COMPLEXITY
================================================================================

Time Complexity: O(n)
    - We call atMost() twice
    - Each call iterates through the array once: O(n)
    - The left pointer only moves forward, never backward
    - Total: O(n) + O(n) = O(2n) = O(n)

Space Complexity: O(1)
    - We only use a constant number of variables
    - No extra data structures needed


================================================================================
ALTERNATIVE APPROACH: PREFIX SUM WITH HASHMAP (DETAILED EXPLANATION)
================================================================================

This approach uses a completely different technique based on PREFIX SUMS.

--------------------------------------------------------------------------------
WHAT IS A PREFIX SUM?
--------------------------------------------------------------------------------

A prefix sum at index i is the sum of all elements from index 0 to i.

For array: nums = [1, 0, 1, 0, 1]

    Index:          0    1    2    3    4
    Array:          1    0    1    0    1
    Prefix Sum:     1    1    2    2    3
                    ^    ^    ^    ^    ^
                    |    |    |    |    |
                sum[0:1] |    |    |  sum[0:5]
                      sum[0:2] |  sum[0:4]
                            sum[0:3]

We also consider prefix_sum = 0 for the "empty prefix" (before index 0).

--------------------------------------------------------------------------------
THE KEY INSIGHT: SUBARRAY SUM FROM PREFIX SUMS
--------------------------------------------------------------------------------

If we know prefix sums, we can calculate ANY subarray sum in O(1):

    sum(nums[i:j+1]) = prefix_sum[j] - prefix_sum[i-1]

Example: sum of subarray [1, 0, 1] (indices 0 to 2)
    = prefix_sum[2] - prefix_sum[-1]
    = 2 - 0 (empty prefix)
    = 2 ✓

Example: sum of subarray [0, 1, 0] (indices 1 to 3)
    = prefix_sum[3] - prefix_sum[0]
    = 2 - 1
    = 1 ✓

--------------------------------------------------------------------------------
HOW DOES THIS HELP US COUNT SUBARRAYS WITH SUM = GOAL?
--------------------------------------------------------------------------------

We want to count subarrays where:
    prefix_sum[j] - prefix_sum[i] = goal

Rearranging:
    prefix_sum[i] = prefix_sum[j] - goal

This means: For each position j, we need to count how many previous
positions i have a prefix sum equal to (current_prefix_sum - goal).

If we have a hashmap storing counts of all previous prefix sums,
we can answer this in O(1)!

--------------------------------------------------------------------------------
THE ALGORITHM STEP BY STEP
--------------------------------------------------------------------------------

1. Initialize a hashmap to store frequency of each prefix sum
2. Start with prefix_count[0] = 1 (empty prefix with sum 0)
3. For each element in array:
   a. Update current_sum (running prefix sum)
   b. Look for (current_sum - goal) in hashmap
      - If found, those are all valid starting points!
      - Add that count to our answer
   c. Add current_sum to hashmap (for future elements to find)

Why prefix_count[0] = 1?
    - If current_sum == goal at some point, we need a "starting point"
      with prefix_sum = 0 (the empty prefix before index 0)
    - This represents taking the subarray from the very beginning

--------------------------------------------------------------------------------
THE CODE WITH DETAILED COMMENTS
--------------------------------------------------------------------------------
"""

from collections import defaultdict


def numSubarraysWithSumPrefixSum(nums: list, goal: int) -> int:
    """
    Count subarrays with sum exactly equal to goal using prefix sum + hashmap.

    Args:
        nums: Binary array (contains only 0s and 1s)
        goal: Target sum we want

    Returns:
        Number of subarrays with sum exactly equal to goal
    """

    # Hashmap: stores how many times each prefix sum has occurred
    # Key = prefix_sum value, Value = count of occurrences
    prefix_count = defaultdict(int)

    # CRUCIAL: Initialize with empty prefix (sum = 0, count = 1)
    # This handles subarrays starting from index 0
    prefix_count[0] = 1

    current_sum = 0  # Running prefix sum
    count = 0        # Total count of valid subarrays

    for num in nums:
        # Step 1: Extend prefix sum to include current element
        current_sum += num

        # Step 2: How many previous prefix sums equal (current_sum - goal)?
        # Each such prefix sum represents a valid starting point!
        #
        # If prefix_sum[i] = current_sum - goal, then:
        #    subarray sum from i+1 to current position
        #    = current_sum - prefix_sum[i]
        #    = current_sum - (current_sum - goal)
        #    = goal  ✓

        target = current_sum - goal
        count += prefix_count[target]

        # Step 3: Record current prefix sum for future elements
        prefix_count[current_sum] += 1

    return count


"""
--------------------------------------------------------------------------------
DRY RUN: nums = [1, 0, 1, 0, 1], goal = 2
--------------------------------------------------------------------------------

Initial State:
    prefix_count = {0: 1}  (empty prefix)
    current_sum = 0
    count = 0

Let's trace through each element:

┌─────────────────────────────────────────────────────────────────────────────┐
│ ITERATION 1: num = 1 (index 0)                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   current_sum = 0 + 1 = 1                                                   │
│                                                                             │
│   target = current_sum - goal = 1 - 2 = -1                                  │
│                                                                             │
│   prefix_count[-1] = 0 (not found)                                          │
│   count += 0  →  count = 0                                                  │
│                                                                             │
│   Add current_sum to map: prefix_count[1] = 1                               │
│                                                                             │
│   prefix_count = {0: 1, 1: 1}                                               │
│                                                                             │
│   Meaning: No subarray ending at index 0 has sum = 2                        │
│   (The only subarray is [1] with sum 1)                                     │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ ITERATION 2: num = 0 (index 1)                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   current_sum = 1 + 0 = 1                                                   │
│                                                                             │
│   target = current_sum - goal = 1 - 2 = -1                                  │
│                                                                             │
│   prefix_count[-1] = 0 (not found)                                          │
│   count += 0  →  count = 0                                                  │
│                                                                             │
│   Add current_sum to map: prefix_count[1] = 2                               │
│                                                                             │
│   prefix_count = {0: 1, 1: 2}                                               │
│                                                                             │
│   Meaning: No subarray ending at index 1 has sum = 2                        │
│   (Subarrays: [0] sum=0, [1,0] sum=1)                                       │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ ITERATION 3: num = 1 (index 2)                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   current_sum = 1 + 1 = 2                                                   │
│                                                                             │
│   target = current_sum - goal = 2 - 2 = 0                                   │
│                                                                             │
│   prefix_count[0] = 1  ← FOUND!                                             │
│   count += 1  →  count = 1                                                  │
│                                                                             │
│   What does this mean?                                                      │
│   - We found 1 previous position with prefix_sum = 0                        │
│   - That's the "empty prefix" (before index 0)                              │
│   - Subarray from index 0 to 2 = [1, 0, 1] has sum = 2 ✓                    │
│                                                                             │
│   Add current_sum to map: prefix_count[2] = 1                               │
│                                                                             │
│   prefix_count = {0: 1, 1: 2, 2: 1}                                         │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ ITERATION 4: num = 0 (index 3)                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   current_sum = 2 + 0 = 2                                                   │
│                                                                             │
│   target = current_sum - goal = 2 - 2 = 0                                   │
│                                                                             │
│   prefix_count[0] = 1  ← FOUND!                                             │
│   count += 1  →  count = 2                                                  │
│                                                                             │
│   What does this mean?                                                      │
│   - Again found the "empty prefix"                                          │
│   - Subarray from index 0 to 3 = [1, 0, 1, 0] has sum = 2 ✓                 │
│                                                                             │
│   Add current_sum to map: prefix_count[2] = 2                               │
│                                                                             │
│   prefix_count = {0: 1, 1: 2, 2: 2}                                         │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ ITERATION 5: num = 1 (index 4)                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   current_sum = 2 + 1 = 3                                                   │
│                                                                             │
│   target = current_sum - goal = 3 - 2 = 1                                   │
│                                                                             │
│   prefix_count[1] = 2  ← FOUND 2 MATCHES!                                   │
│   count += 2  →  count = 4                                                  │
│                                                                             │
│   What does this mean?                                                      │
│   - Found 2 previous positions with prefix_sum = 1                          │
│   - Position after index 0: prefix_sum = 1                                  │
│     → Subarray from index 1 to 4 = [0, 1, 0, 1] has sum = 2 ✓               │
│   - Position after index 1: prefix_sum = 1                                  │
│     → Subarray from index 2 to 4 = [1, 0, 1] has sum = 2 ✓                  │
│                                                                             │
│   Add current_sum to map: prefix_count[3] = 1                               │
│                                                                             │
│   prefix_count = {0: 1, 1: 2, 2: 2, 3: 1}                                   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

FINAL ANSWER: count = 4

--------------------------------------------------------------------------------
VERIFICATION: The 4 subarrays with sum = 2
--------------------------------------------------------------------------------

    Index:    0    1    2    3    4
    Array:   [1,   0,   1,   0,   1]

    1. [1, 0, 1]       indices [0, 2]   sum = 1+0+1 = 2 ✓
    2. [1, 0, 1, 0]    indices [0, 3]   sum = 1+0+1+0 = 2 ✓
    3. [0, 1, 0, 1]    indices [1, 4]   sum = 0+1+0+1 = 2 ✓
    4. [1, 0, 1]       indices [2, 4]   sum = 1+0+1 = 2 ✓


--------------------------------------------------------------------------------
DRY RUN 2: nums = [0, 0, 0, 0, 0], goal = 0 (Edge Case)
--------------------------------------------------------------------------------

Initial State:
    prefix_count = {0: 1}
    current_sum = 0
    count = 0

ITERATION 1: num = 0 (index 0)
    current_sum = 0 + 0 = 0
    target = 0 - 0 = 0
    prefix_count[0] = 1  ← Found!
    count += 1  →  count = 1
    prefix_count[0] = 2

    Valid subarray: [0] (from beginning to index 0)

ITERATION 2: num = 0 (index 1)
    current_sum = 0 + 0 = 0
    target = 0 - 0 = 0
    prefix_count[0] = 2  ← Found 2!
    count += 2  →  count = 3
    prefix_count[0] = 3

    Valid subarrays: [0] (index 1), [0,0] (indices 0-1)

ITERATION 3: num = 0 (index 2)
    current_sum = 0 + 0 = 0
    target = 0 - 0 = 0
    prefix_count[0] = 3  ← Found 3!
    count += 3  →  count = 6
    prefix_count[0] = 4

    Valid subarrays: [0], [0,0], [0,0,0]

ITERATION 4: num = 0 (index 3)
    current_sum = 0
    target = 0
    prefix_count[0] = 4  ← Found 4!
    count += 4  →  count = 10
    prefix_count[0] = 5

ITERATION 5: num = 0 (index 4)
    current_sum = 0
    target = 0
    prefix_count[0] = 5  ← Found 5!
    count += 5  →  count = 15
    prefix_count[0] = 6

FINAL ANSWER: count = 15 ✓

This matches our expectation: n*(n+1)/2 = 5*6/2 = 15 subarrays


--------------------------------------------------------------------------------
VISUAL COMPARISON: SLIDING WINDOW vs PREFIX SUM
--------------------------------------------------------------------------------

┌─────────────────────────────────────────────────────────────────────────────┐
│                    SLIDING WINDOW (atMost technique)                        │
├─────────────────────────────────────────────────────────────────────────────┤
│  Approach:     Subtract atMost(k-1) from atMost(k)                          │
│  Time:         O(n) - two passes through array                              │
│  Space:        O(1) - only pointers and counters                            │
│  Pros:         Constant space, intuitive window shrinking                   │
│  Cons:         Requires understanding the atMost subtraction trick          │
│  Best for:     When space is critical                                       │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                    PREFIX SUM + HASHMAP                                     │
├─────────────────────────────────────────────────────────────────────────────┤
│  Approach:     Track prefix sums, find complementary sums                   │
│  Time:         O(n) - single pass through array                             │
│  Space:        O(n) - hashmap stores up to n prefix sums                    │
│  Pros:         Single pass, directly counts exact sums                      │
│  Cons:         Extra space for hashmap                                      │
│  Best for:     When code simplicity matters, general subarray sum problems  │
└─────────────────────────────────────────────────────────────────────────────┘


--------------------------------------------------------------------------------
WHEN TO USE EACH APPROACH
--------------------------------------------------------------------------------

Use SLIDING WINDOW (atMost technique) when:
- Space is critical (O(1) vs O(n))
- Array has special properties (like binary array)
- You need to count "at most K" anyway

Use PREFIX SUM + HASHMAP when:
- You need "exactly K" directly
- Array has negative numbers (sliding window won't work!)
- The problem involves arbitrary integers (not just 0/1)
- Code simplicity is more important than space

IMPORTANT: The prefix sum approach works for ANY array (including negatives),
while the sliding window atMost technique only works when array elements
are non-negative (like our binary array case).


--------------------------------------------------------------------------------
COMPLEXITY ANALYSIS
--------------------------------------------------------------------------------

Time Complexity: O(n)
    - Single pass through the array
    - Each hashmap lookup and insert is O(1) average
    - Total: O(n)

Space Complexity: O(n)
    - Hashmap can store up to n+1 distinct prefix sums
    - In worst case (all unique prefix sums), we store n entries
    - For binary array: at most (n+1) distinct values (0 to n)

The sliding window approach is preferred for this specific problem
as it uses O(1) space, but prefix sum is more generalizable!


================================================================================
SUMMARY
================================================================================

Key Takeaways:
1. "Exactly K" problems often transform to "atMost(K) - atMost(K-1)"
2. This technique works because subtraction removes overlap
3. atMost(K) is efficiently solvable with sliding window
4. For binary arrays, sum = count of 1s
5. Always handle edge case when k < 0 in atMost function

Pattern Recognition:
- See "count subarrays with exact sum/property" -> Think atMost technique
- See binary array -> Sum equals count of 1s
- See sliding window -> Think about what property allows shrinking

================================================================================
"""


# Test the solution
if __name__ == "__main__":
    sol = Solution()

    # Test Case 1
    nums1 = [1, 0, 1, 0, 1]
    goal1 = 2
    result1 = sol.numSubarraysWithSum(nums1, goal1)
    print(f"Test 1: nums={nums1}, goal={goal1}")
    print(f"Result: {result1}, Expected: 4")
    print()

    # Test Case 2
    nums2 = [0, 0, 0, 0, 0]
    goal2 = 0
    result2 = sol.numSubarraysWithSum(nums2, goal2)
    print(f"Test 2: nums={nums2}, goal={goal2}")
    print(f"Result: {result2}, Expected: 15")
    print()

    # Test Case 3: All ones
    nums3 = [1, 1, 1, 1]
    goal3 = 2
    result3 = sol.numSubarraysWithSum(nums3, goal3)
    print(f"Test 3: nums={nums3}, goal={goal3}")
    print(f"Result: {result3}, Expected: 3")
    print()

    # Test Case 4: Edge case - single element
    nums4 = [1]
    goal4 = 1
    result4 = sol.numSubarraysWithSum(nums4, goal4)
    print(f"Test 4: nums={nums4}, goal={goal4}")
    print(f"Result: {result4}, Expected: 1")
