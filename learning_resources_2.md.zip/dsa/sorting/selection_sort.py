
"""
Selection Sort - Concept, Visual Explanation, and Dry Run
=========================================================

Algorithm Idea
--------------
Selection Sort repeatedly selects the minimum element from the unsorted part
of the array and places it at the current index.

At each pass:
1) Assume current index i holds the minimum.
2) Scan the remaining elements to find the real minimum.
3) Swap the found minimum with index i.

This grows the sorted part from left to right.

Visual Explanation (for [64, 25, 12, 22, 11])
----------------------------------------------
Pass 1 (i=0):
[64, 25, 12, 22, 11]
 ^
 Find minimum in full range -> 11
 Swap 64 <-> 11
[11, 25, 12, 22, 64]

Pass 2 (i=1):
[11, 25, 12, 22, 64]
     ^
 Find minimum in [25, 12, 22, 64] -> 12
 Swap 25 <-> 12
[11, 12, 25, 22, 64]

Pass 3 (i=2):
[11, 12, 25, 22, 64]
         ^
 Find minimum in [25, 22, 64] -> 22
 Swap 25 <-> 22
[11, 12, 22, 25, 64]

Pass 4 (i=3):
[11, 12, 22, 25, 64]
             ^
 Find minimum in [25, 64] -> 25
 Swap 25 <-> 25 (no change)
[11, 12, 22, 25, 64]

Dry Run Table
-------------
+------+---+--------------------------+---------+-------------------------+
| Pass | i | Unsorted Part            | Min Val | Array After Swap        |
+------+---+--------------------------+---------+-------------------------+
| 1    | 0 | [64, 25, 12, 22, 11]     | 11      | [11, 25, 12, 22, 64]    |
| 2    | 1 | [25, 12, 22, 64]         | 12      | [11, 12, 25, 22, 64]    |
| 3    | 2 | [25, 22, 64]             | 22      | [11, 12, 22, 25, 64]    |
| 4    | 3 | [25, 64]                 | 25      | [11, 12, 22, 25, 64]    |
+------+---+--------------------------+---------+-------------------------+

Complexity
----------
Time: O(n^2)
Space: O(1)
"""


def selection_sort(arr):
    """Sort the list in ascending order using Selection Sort (in-place)."""
    for i in range(len(arr) - 1):
        min_index = i
        for j in range(i + 1, len(arr)):
            if arr[j] < arr[min_index]:
                min_index = j
        arr[i], arr[min_index] = arr[min_index], arr[i]


def selection_sort_with_trace(arr):
    """
    Sort with step-by-step trace so learners can see exactly what changes
    at each pass.
    """
    print("Step-by-step trace:")
    print(f"Start: {arr}")
    print("-" * 60)

    for i in range(len(arr) - 1):
        min_index = i
        for j in range(i + 1, len(arr)):
            if arr[j] < arr[min_index]:
                min_index = j

        print(
            f"Pass {i + 1}: i={i}, min={arr[min_index]} at index {min_index}, "
            f"swap arr[{i}]={arr[i]} with arr[{min_index}]={arr[min_index]}"
        )

        arr[i], arr[min_index] = arr[min_index], arr[i]
        print(f"After pass {i + 1}: {arr}")
        print("-" * 60)


def main():
    arr = [64, 25, 12, 22, 11]

    print("Original array:", arr)
    print("=" * 60)

    # Make a copy so both functions can be demonstrated clearly.
    trace_arr = arr.copy()
    selection_sort_with_trace(trace_arr)

    print("Final sorted array (trace run):", trace_arr)


if __name__ == "__main__":
    main()