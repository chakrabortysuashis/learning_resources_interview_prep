"""
================================================================================
                              MERGE SORT ALGORITHM
================================================================================

WHAT IS MERGE SORT?
-------------------
Merge Sort is a classic "Divide and Conquer" sorting algorithm invented by
John von Neumann in 1945. It works by recursively breaking down the problem
into smaller subproblems until they become simple enough to solve directly,
then combines the solutions to get the final sorted result.

HOW IT WORKS CONCEPTUALLY:
--------------------------
The algorithm follows three main steps:

1. DIVIDE: Split the array into two halves from the middle
2. CONQUER: Recursively sort both halves
3. COMBINE: Merge the two sorted halves into one sorted array

Visual representation:
                        [38, 27, 43, 3, 9, 82, 10]
                                    |
                    ----------------+----------------
                    |                               |
            [38, 27, 43, 3]                 [9, 82, 10]
                    |                               |
            --------+--------               --------+--------
            |               |               |               |
        [38, 27]        [43, 3]         [9, 82]          [10]
            |               |               |               |
        ----+----       ----+----       ----+----           |
        |       |       |       |       |       |           |
      [38]    [27]    [43]     [3]     [9]    [82]        [10]
        |       |       |       |       |       |           |
        +---+---+       +---+---+       +---+---+           |
            |               |               |               |
        [27, 38]        [3, 43]         [9, 82]          [10]
            |               |               |               |
            +-------+-------+               +-------+-------+
                    |                               |
            [3, 27, 38, 43]                   [9, 10, 82]
                    |                               |
                    +---------------+---------------+
                                    |
                    [3, 9, 10, 27, 38, 43, 82]

TIME COMPLEXITY:
----------------
- Best Case:    O(n log n)  - Even if array is sorted, we still divide and merge
- Average Case: O(n log n)  - Consistent performance regardless of input
- Worst Case:   O(n log n)  - No worst case degradation like QuickSort

Why O(n log n)?
- We divide the array log(n) times (each division halves the array)
- At each level, we do O(n) work to merge all elements
- Total: O(n) * O(log n) = O(n log n)

SPACE COMPLEXITY:
-----------------
- O(n) auxiliary space for the temporary arrays during merging
- O(log n) space for the recursion call stack
- Total: O(n) - dominated by the temporary arrays

WHEN TO USE MERGE SORT:
-----------------------
USE Merge Sort when:
    - You need guaranteed O(n log n) performance (no worst-case degradation)
    - You're sorting linked lists (can be done in O(1) extra space)
    - Stability is required (equal elements maintain their relative order)
    - External sorting (sorting data that doesn't fit in memory)
    - Parallel processing is available (easily parallelizable)

AVOID Merge Sort when:
    - Memory is limited (QuickSort uses O(log n) space with in-place partitioning)
    - Working with small arrays (insertion sort is faster for n < 50)
    - Cache performance is critical (QuickSort has better cache locality)

COMPARISON WITH OTHER SORTING ALGORITHMS:
-----------------------------------------
| Algorithm      | Best      | Average   | Worst     | Space   | Stable |
|----------------|-----------|-----------|-----------|---------|--------|
| Merge Sort     | O(n log n)| O(n log n)| O(n log n)| O(n)    | Yes    |
| Quick Sort     | O(n log n)| O(n log n)| O(n^2)    | O(log n)| No     |
| Heap Sort      | O(n log n)| O(n log n)| O(n log n)| O(1)    | No     |
| Insertion Sort | O(n)      | O(n^2)    | O(n^2)    | O(1)    | Yes    |
| Bubble Sort    | O(n)      | O(n^2)    | O(n^2)    | O(1)    | Yes    |

================================================================================
"""


def merge(left_half, right_half):
    """
    Merges two sorted arrays into one sorted array.

    This is the "Combine" step of the divide and conquer approach.
    We use a two-pointer technique to efficiently merge the arrays.

    Args:
        left_half: First sorted array
        right_half: Second sorted array

    Returns:
        A new sorted array containing all elements from both halves

    Time Complexity: O(n) where n = len(left_half) + len(right_half)
    Space Complexity: O(n) for the result array
    """

    # Result array to store merged elements
    result = []

    # Two pointers - one for each half
    # i tracks position in left_half
    # j tracks position in right_half
    i = 0  # Pointer for left_half
    j = 0  # Pointer for right_half

    # Compare elements from both halves and add smaller one to result
    # Continue until we exhaust one of the halves
    while i < len(left_half) and j < len(right_half):

        # Compare current elements from both halves
        if left_half[i] <= right_half[j]:
            # Left element is smaller or equal, add it to result
            # Using <= ensures stability (equal elements maintain original order)
            result.append(left_half[i])
            i += 1  # Move left pointer forward
        else:
            # Right element is smaller, add it to result
            result.append(right_half[j])
            j += 1  # Move right pointer forward

    # At this point, one of the halves is exhausted
    # The remaining elements in the other half are already sorted
    # and are all greater than elements in result, so we can just append them

    # Add remaining elements from left_half (if any)
    while i < len(left_half):
        result.append(left_half[i])
        i += 1

    # Add remaining elements from right_half (if any)
    while j < len(right_half):
        result.append(right_half[j])
        j += 1

    return result


def merge_sort(arr):
    """
    Sorts an array using the Merge Sort algorithm.

    This function implements the "Divide" and "Conquer" steps:
    - Divide: Split array into two halves
    - Conquer: Recursively sort each half
    - Combine: Merge the sorted halves (done by merge() function)

    Args:
        arr: The array to be sorted

    Returns:
        A new sorted array

    Time Complexity: O(n log n)
    Space Complexity: O(n)
    """

    # BASE CASE: Arrays with 0 or 1 element are already sorted
    # This is the termination condition for our recursion
    if len(arr) <= 1:
        return arr

    # DIVIDE STEP: Find the middle index to split the array
    # Using integer division to get the floor value
    mid = len(arr) // 2

    # Split array into two halves
    # left_half contains elements from index 0 to mid-1
    # right_half contains elements from index mid to end
    left_half = arr[:mid]      # Elements before middle
    right_half = arr[mid:]     # Elements from middle to end

    # CONQUER STEP: Recursively sort both halves
    # Each recursive call will further divide until we hit the base case
    sorted_left = merge_sort(left_half)    # Sort the left half
    sorted_right = merge_sort(right_half)  # Sort the right half

    # COMBINE STEP: Merge the two sorted halves
    # The merge function takes two sorted arrays and combines them
    return merge(sorted_left, sorted_right)


"""
================================================================================
                              DRY RUN / TRACE
================================================================================

Let's trace through the algorithm with the example: [38, 27, 43, 3, 9, 82, 10]

--------------------------------------------------------------------------------
EXAMPLE 1: arr = [38, 27, 43, 3, 9, 82, 10]
--------------------------------------------------------------------------------

PHASE 1: DIVIDING (Top-Down Recursion)
--------------------------------------

Call 1: merge_sort([38, 27, 43, 3, 9, 82, 10])
    - len = 7, mid = 3
    - left_half = [38, 27, 43]
    - right_half = [3, 9, 82, 10]
    - Recursively sort both halves...

    Call 2: merge_sort([38, 27, 43])
        - len = 3, mid = 1
        - left_half = [38]
        - right_half = [27, 43]
        - Recursively sort both halves...

        Call 3: merge_sort([38])
            - len = 1 <= 1, BASE CASE
            - Return [38]

        Call 4: merge_sort([27, 43])
            - len = 2, mid = 1
            - left_half = [27]
            - right_half = [43]

            Call 5: merge_sort([27])
                - len = 1 <= 1, BASE CASE
                - Return [27]

            Call 6: merge_sort([43])
                - len = 1 <= 1, BASE CASE
                - Return [43]

            - merge([27], [43]):
                i=0, j=0: 27 < 43, result=[27], i=1
                j=0: append 43, result=[27, 43]
            - Return [27, 43]

        - merge([38], [27, 43]):
            i=0, j=0: 38 > 27, result=[27], j=1
            i=0, j=1: 38 < 43, result=[27, 38], i=1
            j=1: append 43, result=[27, 38, 43]
        - Return [27, 38, 43]

    Call 7: merge_sort([3, 9, 82, 10])
        - len = 4, mid = 2
        - left_half = [3, 9]
        - right_half = [82, 10]

        Call 8: merge_sort([3, 9])
            - len = 2, mid = 1
            - left_half = [3]
            - right_half = [9]

            Call 9: merge_sort([3])
                - len = 1 <= 1, BASE CASE
                - Return [3]

            Call 10: merge_sort([9])
                - len = 1 <= 1, BASE CASE
                - Return [9]

            - merge([3], [9]):
                i=0, j=0: 3 < 9, result=[3], i=1
                j=0: append 9, result=[3, 9]
            - Return [3, 9]

        Call 11: merge_sort([82, 10])
            - len = 2, mid = 1
            - left_half = [82]
            - right_half = [10]

            Call 12: merge_sort([82])
                - len = 1 <= 1, BASE CASE
                - Return [82]

            Call 13: merge_sort([10])
                - len = 1 <= 1, BASE CASE
                - Return [10]

            - merge([82], [10]):
                i=0, j=0: 82 > 10, result=[10], j=1
                i=0: append 82, result=[10, 82]
            - Return [10, 82]

        - merge([3, 9], [10, 82]):
            i=0, j=0: 3 < 10, result=[3], i=1
            i=1, j=0: 9 < 10, result=[3, 9], i=2
            j=0: append 10, result=[3, 9, 10]
            j=1: append 82, result=[3, 9, 10, 82]
        - Return [3, 9, 10, 82]

    - merge([27, 38, 43], [3, 9, 10, 82]):
        i=0, j=0: 27 > 3,  result=[3], j=1
        i=0, j=1: 27 > 9,  result=[3, 9], j=2
        i=0, j=2: 27 > 10, result=[3, 9, 10], j=3
        i=0, j=3: 27 < 82, result=[3, 9, 10, 27], i=1
        i=1, j=3: 38 < 82, result=[3, 9, 10, 27, 38], i=2
        i=2, j=3: 43 < 82, result=[3, 9, 10, 27, 38, 43], i=3
        j=3: append 82, result=[3, 9, 10, 27, 38, 43, 82]
    - Return [3, 9, 10, 27, 38, 43, 82]

FINAL RESULT: [3, 9, 10, 27, 38, 43, 82]


--------------------------------------------------------------------------------
EXAMPLE 2: arr = [5, 2, 8, 1]
--------------------------------------------------------------------------------

Call 1: merge_sort([5, 2, 8, 1])
    - len = 4, mid = 2
    - left_half = [5, 2]
    - right_half = [8, 1]

    Call 2: merge_sort([5, 2])
        - len = 2, mid = 1
        - left_half = [5]
        - right_half = [2]

        Call 3: merge_sort([5]) -> returns [5] (base case)
        Call 4: merge_sort([2]) -> returns [2] (base case)

        - merge([5], [2]):
            Step 1: i=0, j=0
                    Compare: 5 > 2
                    result = [2], j=1
            Step 2: i=0, left remaining
                    Append 5
                    result = [2, 5]
        - Return [2, 5]

    Call 5: merge_sort([8, 1])
        - len = 2, mid = 1
        - left_half = [8]
        - right_half = [1]

        Call 6: merge_sort([8]) -> returns [8] (base case)
        Call 7: merge_sort([1]) -> returns [1] (base case)

        - merge([8], [1]):
            Step 1: i=0, j=0
                    Compare: 8 > 1
                    result = [1], j=1
            Step 2: i=0, left remaining
                    Append 8
                    result = [1, 8]
        - Return [1, 8]

    - merge([2, 5], [1, 8]):
        Step 1: i=0, j=0
                Compare: 2 > 1
                result = [1], j=1
        Step 2: i=0, j=1
                Compare: 2 < 8
                result = [1, 2], i=1
        Step 3: i=1, j=1
                Compare: 5 < 8
                result = [1, 2, 5], i=2
        Step 4: j=1, right remaining
                Append 8
                result = [1, 2, 5, 8]
    - Return [1, 2, 5, 8]

FINAL RESULT: [1, 2, 5, 8]

================================================================================
"""


"""
================================================================================
                              EDGE CASES
================================================================================

1. EMPTY ARRAY: []
   - Base case handles this: len([]) = 0 <= 1, returns []
   - No division or merging needed
   - Result: []

2. SINGLE ELEMENT: [42]
   - Base case handles this: len([42]) = 1 <= 1, returns [42]
   - Array with one element is already sorted
   - Result: [42]

3. ALREADY SORTED ARRAY: [1, 2, 3, 4, 5]
   - Algorithm still divides and merges (no optimization for this case)
   - Time complexity remains O(n log n)
   - During merge: left elements are always smaller, added first
   - Result: [1, 2, 3, 4, 5]

   Note: This is a "disadvantage" compared to algorithms like Insertion Sort
   which can detect sorted arrays and run in O(n).

4. REVERSE SORTED ARRAY: [5, 4, 3, 2, 1]
   - Same process as any other array
   - During merge: right elements are often smaller
   - Still O(n log n) - no worst case degradation like QuickSort
   - Result: [1, 2, 3, 4, 5]

5. ARRAY WITH DUPLICATES: [3, 1, 4, 1, 5, 9, 2, 6, 5, 3]
   - Merge sort is STABLE: equal elements maintain relative order
   - The <= comparison in merge() ensures stability
   - Example: If we have [3a, 3b], after sorting: [3a, 3b] (order preserved)
   - Result: [1, 1, 2, 3, 3, 4, 5, 5, 6, 9]

6. TWO ELEMENTS: [2, 1]
   - Divides into [2] and [1]
   - Both base cases, returns as-is
   - Merge compares 2 > 1, so result = [1, 2]
   - Result: [1, 2]

7. ALL SAME ELEMENTS: [7, 7, 7, 7]
   - All comparisons result in equality
   - Left elements added first (stability)
   - Result: [7, 7, 7, 7]

================================================================================
"""


# ==============================================================================
#                              MAIN SECTION - TEST CASES
# ==============================================================================

if __name__ == "__main__":

    print("=" * 70)
    print("                    MERGE SORT - TEST CASES")
    print("=" * 70)

    # Test Case 1: Standard unsorted array
    print("\nTest 1: Standard unsorted array")
    print("-" * 40)
    arr1 = [38, 27, 43, 3, 9, 82, 10]
    print(f"Input:  {arr1}")
    result1 = merge_sort(arr1)
    print(f"Output: {result1}")
    assert result1 == [3, 9, 10, 27, 38, 43, 82], "Test 1 Failed!"
    print("Status: PASSED")

    # Test Case 2: Empty array
    print("\nTest 2: Empty array")
    print("-" * 40)
    arr2 = []
    print(f"Input:  {arr2}")
    result2 = merge_sort(arr2)
    print(f"Output: {result2}")
    assert result2 == [], "Test 2 Failed!"
    print("Status: PASSED")

    # Test Case 3: Single element
    print("\nTest 3: Single element")
    print("-" * 40)
    arr3 = [42]
    print(f"Input:  {arr3}")
    result3 = merge_sort(arr3)
    print(f"Output: {result3}")
    assert result3 == [42], "Test 3 Failed!"
    print("Status: PASSED")

    # Test Case 4: Already sorted array
    print("\nTest 4: Already sorted array")
    print("-" * 40)
    arr4 = [1, 2, 3, 4, 5]
    print(f"Input:  {arr4}")
    result4 = merge_sort(arr4)
    print(f"Output: {result4}")
    assert result4 == [1, 2, 3, 4, 5], "Test 4 Failed!"
    print("Status: PASSED")

    # Test Case 5: Reverse sorted array
    print("\nTest 5: Reverse sorted array")
    print("-" * 40)
    arr5 = [5, 4, 3, 2, 1]
    print(f"Input:  {arr5}")
    result5 = merge_sort(arr5)
    print(f"Output: {result5}")
    assert result5 == [1, 2, 3, 4, 5], "Test 5 Failed!"
    print("Status: PASSED")

    # Test Case 6: Array with duplicates
    print("\nTest 6: Array with duplicates")
    print("-" * 40)
    arr6 = [3, 1, 4, 1, 5, 9, 2, 6, 5, 3]
    print(f"Input:  {arr6}")
    result6 = merge_sort(arr6)
    print(f"Output: {result6}")
    assert result6 == [1, 1, 2, 3, 3, 4, 5, 5, 6, 9], "Test 6 Failed!"
    print("Status: PASSED")

    # Test Case 7: Two elements (swap needed)
    print("\nTest 7: Two elements (swap needed)")
    print("-" * 40)
    arr7 = [2, 1]
    print(f"Input:  {arr7}")
    result7 = merge_sort(arr7)
    print(f"Output: {result7}")
    assert result7 == [1, 2], "Test 7 Failed!"
    print("Status: PASSED")

    # Test Case 8: Two elements (no swap needed)
    print("\nTest 8: Two elements (no swap needed)")
    print("-" * 40)
    arr8 = [1, 2]
    print(f"Input:  {arr8}")
    result8 = merge_sort(arr8)
    print(f"Output: {result8}")
    assert result8 == [1, 2], "Test 8 Failed!"
    print("Status: PASSED")

    # Test Case 9: All same elements
    print("\nTest 9: All same elements")
    print("-" * 40)
    arr9 = [7, 7, 7, 7]
    print(f"Input:  {arr9}")
    result9 = merge_sort(arr9)
    print(f"Output: {result9}")
    assert result9 == [7, 7, 7, 7], "Test 9 Failed!"
    print("Status: PASSED")

    # Test Case 10: Negative numbers
    print("\nTest 10: Negative numbers")
    print("-" * 40)
    arr10 = [-5, 3, -2, 0, 8, -1, 4]
    print(f"Input:  {arr10}")
    result10 = merge_sort(arr10)
    print(f"Output: {result10}")
    assert result10 == [-5, -2, -1, 0, 3, 4, 8], "Test 10 Failed!"
    print("Status: PASSED")

    # Test Case 11: Large numbers
    print("\nTest 11: Large numbers")
    print("-" * 40)
    arr11 = [1000000, 500000, 750000, 250000]
    print(f"Input:  {arr11}")
    result11 = merge_sort(arr11)
    print(f"Output: {result11}")
    assert result11 == [250000, 500000, 750000, 1000000], "Test 11 Failed!"
    print("Status: PASSED")

    print("\n" + "=" * 70)
    print("                    ALL TESTS PASSED!")
    print("=" * 70)

    # Demonstration of stability
    print("\n" + "=" * 70)
    print("                STABILITY DEMONSTRATION")
    print("=" * 70)
    print("""
    Merge Sort is STABLE - equal elements maintain their relative order.

    Consider sorting tuples by their first element:
    Input:  [(3, 'first'), (1, 'x'), (3, 'second'), (2, 'y')]

    After stable sort:
    Output: [(1, 'x'), (2, 'y'), (3, 'first'), (3, 'second')]

    Notice: (3, 'first') comes before (3, 'second') - original order preserved!
    """)

    print("=" * 70)
    print("                    COMPLEXITY SUMMARY")
    print("=" * 70)
    print("""
    Time Complexity:
        - Best Case:    O(n log n)
        - Average Case: O(n log n)
        - Worst Case:   O(n log n)

    Space Complexity: O(n)
        - Temporary arrays during merging: O(n)
        - Recursion stack depth: O(log n)
        - Total: O(n) [dominated by temporary arrays]

    Key Properties:
        - Stable: Yes
        - In-place: No (requires O(n) extra space)
        - Adaptive: No (does not benefit from partially sorted input)
    """)
    print("=" * 70)
