"""
================================================================================
                        CUSTOM SORTING IN PYTHON
================================================================================

This module covers comprehensive custom sorting techniques in Python, focusing on:

1. Sorting objects of a custom class (Student) by multiple attributes
2. Sorting a list of dictionaries by multiple keys

PROBLEMS COVERED:
-----------------
Problem 1: Sort Student objects by:
           - First by marks (descending - highest first)
           - Then by name (ascending - alphabetical)
           - Finally by roll number (ascending)

Problem 2: Sort dictionaries by:
           - First by age (ascending)
           - Then by name (ascending)

KEY CONCEPTS COVERED:
---------------------
- Custom comparators using `key` parameter
- Multiple key sorting with tuples
- The `__lt__` method for class comparison
- `functools.cmp_to_key` for complex comparisons
- `operator.attrgetter` and `operator.itemgetter`
- Stable sorting behavior in Python (Timsort)

================================================================================
"""

from functools import cmp_to_key
from operator import attrgetter, itemgetter
from typing import List, Dict, Any


# ==============================================================================
#                    UNDERSTANDING PYTHON'S SORTING
# ==============================================================================
"""
PYTHON'S TIMSORT ALGORITHM:
---------------------------
Python uses Timsort, a hybrid stable sorting algorithm derived from merge sort
and insertion sort.

Key Properties:
- Time Complexity: O(n log n) average and worst case
- Space Complexity: O(n)
- STABLE: Equal elements maintain their relative order

WHY STABILITY MATTERS:
----------------------
When sorting by multiple keys, stability allows us to sort by secondary keys
first, then primary keys. The secondary ordering is preserved for equal
primary keys.

Example: Sorting students by marks, then by name
- First sort by name (secondary key)
- Then sort by marks (primary key)
- Students with same marks will remain sorted by name!

However, the TUPLE KEY approach is cleaner and recommended.
"""


# ==============================================================================
#                    PROBLEM 1: SORTING STUDENT OBJECTS
# ==============================================================================
"""
PROBLEM STATEMENT:
------------------
Sort a list of Student objects where each student has:
- roll_no (int): Student's roll number
- name (str): Student's name
- marks (int): Student's marks

SORTING CRITERIA (in order of priority):
1. marks (DESCENDING - highest marks first)
2. name (ASCENDING - alphabetical order)
3. roll_no (ASCENDING - lower roll number first)

VISUAL REPRESENTATION:
----------------------
Given Students:
+--------+--------+-------+
| roll_no|  name  | marks |
+--------+--------+-------+
|   1    | Alice  |  85   |
|   2    | Bob    |  90   |
|   3    | Charlie|  85   |
|   4    | Alice  |  85   |
|   5    | Diana  |  90   |
+--------+--------+-------+

After Sorting:
+--------+--------+-------+
| roll_no|  name  | marks |
+--------+--------+-------+
|   2    | Bob    |  90   | <- Highest marks (90), Bob < Diana alphabetically
|   5    | Diana  |  90   | <- Same marks (90), Diana comes after Bob
|   1    | Alice  |  85   | <- marks=85, name=Alice, roll=1 (smaller roll)
|   4    | Alice  |  85   | <- marks=85, name=Alice, roll=4 (larger roll)
|   3    | Charlie|  85   | <- marks=85, name=Charlie (after Alice)
+--------+--------+-------+
"""


# ------------------------------------------------------------------------------
#                    APPROACH 1: Using __lt__ (Less Than) Method
# ------------------------------------------------------------------------------
"""
CONCEPT:
--------
Python's sort() and sorted() use the < operator to compare elements.
By defining __lt__ in our class, we control how objects are compared.

When Python needs to determine if object A < object B:
- It calls A.__lt__(B)
- If True, A comes before B in ascending sort

For multiple criteria, we compare in priority order:
1. Compare primary key first
2. If equal, compare secondary key
3. If still equal, compare tertiary key
"""


class StudentWithLt:
    """
    Student class with custom __lt__ method for sorting.

    This approach makes the class inherently sortable.
    Pros: Clean, objects are always sortable
    Cons: Only ONE default sorting order per class
    """

    def __init__(self, roll_no: int, name: str, marks: int):
        self.roll_no = roll_no
        self.name = name
        self.marks = marks

    def __repr__(self) -> str:
        """String representation for easy debugging and display."""
        return f"Student(roll={self.roll_no}, name='{self.name}', marks={self.marks})"

    def __lt__(self, other: 'StudentWithLt') -> bool:
        """
        Define the "less than" comparison for sorting.

        Sorting Priority:
        1. marks (DESCENDING) - Use > for descending
        2. name (ASCENDING) - Use < for ascending
        3. roll_no (ASCENDING) - Use < for ascending

        LOGIC EXPLANATION:
        ------------------
        self < other should return True if self should come BEFORE other.

        For marks (descending - higher first):
            - If self.marks > other.marks: self should come first -> return True
            - If self.marks < other.marks: self should come after -> return False

        For name/roll_no (ascending):
            - If self.name < other.name: self should come first -> return True
        """
        # Compare marks first (descending: higher marks come first)
        if self.marks != other.marks:
            return self.marks > other.marks  # Note: > for descending order

        # Marks are equal, compare names (ascending: alphabetical)
        if self.name != other.name:
            return self.name < other.name  # < for ascending order

        # Marks and names are equal, compare roll numbers (ascending)
        return self.roll_no < other.roll_no  # < for ascending order


def demo_approach1_lt_method():
    """
    Demonstrate sorting using __lt__ method.
    """
    print("=" * 70)
    print("APPROACH 1: Using __lt__ Method")
    print("=" * 70)

    # Create sample students
    students = [
        StudentWithLt(1, "Alice", 85),
        StudentWithLt(2, "Bob", 90),
        StudentWithLt(3, "Charlie", 85),
        StudentWithLt(4, "Alice", 85),
        StudentWithLt(5, "Diana", 90),
    ]

    print("\nOriginal List:")
    for s in students:
        print(f"  {s}")

    # Sort using built-in sorted() - uses __lt__ automatically
    sorted_students = sorted(students)

    print("\nSorted List:")
    for s in sorted_students:
        print(f"  {s}")

    # DRY RUN TRACE
    print("\n" + "-" * 70)
    print("DRY RUN TRACE:")
    print("-" * 70)
    print("""
    Initial: [Alice(85), Bob(90), Charlie(85), Alice(85), Diana(90)]

    Timsort performs comparisons using __lt__:

    Comparison 1: Bob(90) vs Alice(85)
        - Bob.marks(90) != Alice.marks(85)
        - Bob.marks(90) > Alice.marks(85) -> Bob < Alice is True
        - Bob comes BEFORE Alice

    Comparison 2: Diana(90) vs Bob(90)
        - Diana.marks(90) == Bob.marks(90), check name
        - Diana.name('Diana') != Bob.name('Bob')
        - 'Diana' < 'Bob' is False (D > B alphabetically)
        - Diana < Bob is False -> Diana comes AFTER Bob

    Comparison 3: Alice(85,roll=1) vs Alice(85,roll=4)
        - marks equal (85 == 85), check name
        - name equal ('Alice' == 'Alice'), check roll_no
        - 1 < 4 is True
        - Alice(roll=1) < Alice(roll=4) is True -> roll=1 comes first

    Final Order: Bob(90), Diana(90), Alice(85,roll=1), Alice(85,roll=4), Charlie(85)
    """)

    return sorted_students


# ------------------------------------------------------------------------------
#                    APPROACH 2: Using Tuple Key (RECOMMENDED)
# ------------------------------------------------------------------------------
"""
CONCEPT:
--------
Python compares tuples element by element:
- (1, 2) < (1, 3) because at index 1: 2 < 3
- (1, 2) < (2, 1) because at index 0: 1 < 2

We create a tuple from each object's attributes for comparison.

For DESCENDING order on numeric fields, use NEGATIVE value.
For DESCENDING order on strings, we need different approaches.

KEY INSIGHT:
------------
sorted(list, key=lambda x: (x.a, x.b, x.c))

This creates tuples for comparison. Tuples compare lexicographically:
1. Compare first elements
2. If equal, compare second elements
3. And so on...
"""


class Student:
    """Basic Student class without comparison methods."""

    def __init__(self, roll_no: int, name: str, marks: int):
        self.roll_no = roll_no
        self.name = name
        self.marks = marks

    def __repr__(self) -> str:
        return f"Student(roll={self.roll_no}, name='{self.name}', marks={self.marks})"


def demo_approach2_tuple_key():
    """
    Demonstrate sorting using tuple keys with lambda.

    This is the MOST RECOMMENDED approach for most use cases.
    """
    print("\n" + "=" * 70)
    print("APPROACH 2: Using Tuple Key (RECOMMENDED)")
    print("=" * 70)

    students = [
        Student(1, "Alice", 85),
        Student(2, "Bob", 90),
        Student(3, "Charlie", 85),
        Student(4, "Alice", 85),
        Student(5, "Diana", 90),
    ]

    print("\nOriginal List:")
    for s in students:
        print(f"  {s}")

    # Sort using tuple key
    # -marks for descending (negative reverses order for numbers)
    # name for ascending
    # roll_no for ascending
    sorted_students = sorted(
        students,
        key=lambda s: (-s.marks, s.name, s.roll_no)
    )

    print("\nSorted List:")
    for s in sorted_students:
        print(f"  {s}")

    # DRY RUN TRACE
    print("\n" + "-" * 70)
    print("DRY RUN TRACE - Key Generation:")
    print("-" * 70)
    print("""
    For each student, the key function generates a tuple:

    Student(roll=1, Alice, 85)   -> key: (-85, 'Alice', 1)
    Student(roll=2, Bob, 90)     -> key: (-90, 'Bob', 2)
    Student(roll=3, Charlie, 85) -> key: (-85, 'Charlie', 3)
    Student(roll=4, Alice, 85)   -> key: (-85, 'Alice', 4)
    Student(roll=5, Diana, 90)   -> key: (-90, 'Diana', 5)

    Sorting these tuples:

    Step 1: Compare by first element (negative marks)
        -90 < -85 (90 > 85, so -90 < -85)
        Students with marks=90 come first

    Step 2: Among marks=90, compare names
        (-90, 'Bob', 2) vs (-90, 'Diana', 5)
        'Bob' < 'Diana' (B < D alphabetically)
        Bob comes before Diana

    Step 3: Among marks=85 and name='Alice'
        (-85, 'Alice', 1) vs (-85, 'Alice', 4)
        Compare roll: 1 < 4
        roll=1 comes before roll=4

    Sorted Keys:
        (-90, 'Bob', 2)      -> Bob(90)
        (-90, 'Diana', 5)    -> Diana(90)
        (-85, 'Alice', 1)    -> Alice(85, roll=1)
        (-85, 'Alice', 4)    -> Alice(85, roll=4)
        (-85, 'Charlie', 3)  -> Charlie(85)
    """)

    # VISUAL: Show the key generation
    print("\nKey values for each student:")
    for s in students:
        key = (-s.marks, s.name, s.roll_no)
        print(f"  {s} -> Key: {key}")

    return sorted_students


# ------------------------------------------------------------------------------
#                    APPROACH 3: Using operator.attrgetter
# ------------------------------------------------------------------------------
"""
CONCEPT:
--------
operator.attrgetter('attr1', 'attr2') returns a callable that extracts
attributes as a tuple.

attrgetter('name', 'age') is equivalent to lambda x: (x.name, x.age)

ADVANTAGES:
- Slightly faster than lambda (implemented in C)
- More readable for simple attribute access
- Can handle nested attributes: attrgetter('address.city')

LIMITATIONS:
- Cannot negate values for descending order directly
- For mixed ascending/descending, combine with reverse or use lambda
"""


def demo_approach3_attrgetter():
    """
    Demonstrate sorting using operator.attrgetter.
    """
    print("\n" + "=" * 70)
    print("APPROACH 3: Using operator.attrgetter")
    print("=" * 70)

    students = [
        Student(1, "Alice", 85),
        Student(2, "Bob", 90),
        Student(3, "Charlie", 85),
        Student(4, "Alice", 85),
        Student(5, "Diana", 90),
    ]

    print("\nOriginal List:")
    for s in students:
        print(f"  {s}")

    # For simple ascending sort on multiple keys:
    # This sorts by name first, then roll_no (both ascending)
    simple_sorted = sorted(students, key=attrgetter('name', 'roll_no'))

    print("\nSorted by (name ASC, roll_no ASC) using attrgetter:")
    for s in simple_sorted:
        print(f"  {s}")

    # For descending marks, we need to use reverse=True
    # But this reverses ALL criteria, so it's limited

    # WORKAROUND: Two-phase sorting (using stability)
    # Phase 1: Sort by secondary and tertiary keys (ascending)
    # Phase 2: Sort by primary key (descending)

    # This works because Python's sort is STABLE!

    print("\n" + "-" * 50)
    print("Two-Phase Sort (leveraging stability):")
    print("-" * 50)

    # Phase 1: Sort by name, then roll_no (ascending)
    phase1 = sorted(students, key=attrgetter('name', 'roll_no'))
    print("\nAfter Phase 1 (sort by name, roll_no):")
    for s in phase1:
        print(f"  {s}")

    # Phase 2: Sort by marks (descending)
    phase2 = sorted(phase1, key=attrgetter('marks'), reverse=True)
    print("\nAfter Phase 2 (sort by marks DESC) - FINAL:")
    for s in phase2:
        print(f"  {s}")

    # DRY RUN TRACE
    print("\n" + "-" * 70)
    print("DRY RUN TRACE - Two-Phase Sorting:")
    print("-" * 70)
    print("""
    PHASE 1: Sort by (name, roll_no) ascending
    -------------------------------------------
    Original order with keys:
        Alice(85,r=1)   -> ('Alice', 1)
        Bob(90,r=2)     -> ('Bob', 2)
        Charlie(85,r=3) -> ('Charlie', 3)
        Alice(85,r=4)   -> ('Alice', 4)
        Diana(90,r=5)   -> ('Diana', 5)

    After Phase 1:
        Alice(85,r=1)   <- 'Alice' smallest, roll=1 < roll=4
        Alice(85,r=4)
        Bob(90,r=2)
        Charlie(85,r=3)
        Diana(90,r=5)

    PHASE 2: Sort by marks (descending) - STABLE SORT
    --------------------------------------------------
    The key insight: Equal elements KEEP their relative order!

    Students with marks=90: Bob, Diana (this order preserved from Phase 1)
    Students with marks=85: Alice(r=1), Alice(r=4), Charlie (order preserved)

    Final Result:
        Bob(90)         <- marks=90, Bob before Diana (preserved)
        Diana(90)       <- marks=90
        Alice(85,r=1)   <- marks=85, order from Phase 1 preserved
        Alice(85,r=4)
        Charlie(85)

    WHY STABILITY MATTERS:
    ----------------------
    Without stability, Phase 2 might scramble the name/roll ordering
    we established in Phase 1. Stability guarantees the secondary
    sort order is preserved when primary keys are equal.
    """)

    return phase2


# ------------------------------------------------------------------------------
#                    APPROACH 4: Using functools.cmp_to_key
# ------------------------------------------------------------------------------
"""
CONCEPT:
--------
In Python 2, sort() had a cmp parameter for custom comparison functions.
Python 3 removed this, but functools.cmp_to_key provides compatibility.

A comparison function takes two arguments (a, b) and returns:
- Negative number if a < b (a comes first)
- Zero if a == b
- Positive number if a > b (b comes first)

WHEN TO USE:
- Complex comparison logic that's hard to express as a key
- When migrating Python 2 code
- When comparison depends on BOTH elements being compared

PERFORMANCE NOTE:
- Slower than key-based sorting (O(n log n) comparisons vs O(n) key computations)
- Use only when necessary
"""


def student_comparator(s1: Student, s2: Student) -> int:
    """
    Custom comparison function for Student objects.

    Returns:
        < 0 if s1 should come before s2
        = 0 if s1 and s2 are equal
        > 0 if s1 should come after s2

    Comparison order:
    1. marks (descending) - higher marks come first
    2. name (ascending) - alphabetical order
    3. roll_no (ascending) - smaller roll first
    """
    # Compare marks (descending - higher first)
    # If s1.marks > s2.marks, s1 should come first -> return negative
    if s1.marks != s2.marks:
        return s2.marks - s1.marks  # Note: s2 - s1 for descending

    # Marks equal, compare names (ascending)
    # Use string comparison
    if s1.name != s2.name:
        if s1.name < s2.name:
            return -1  # s1 comes first
        else:
            return 1   # s2 comes first

    # Marks and names equal, compare roll_no (ascending)
    return s1.roll_no - s2.roll_no  # s1 - s2 for ascending


def demo_approach4_cmp_to_key():
    """
    Demonstrate sorting using functools.cmp_to_key.
    """
    print("\n" + "=" * 70)
    print("APPROACH 4: Using functools.cmp_to_key")
    print("=" * 70)

    students = [
        Student(1, "Alice", 85),
        Student(2, "Bob", 90),
        Student(3, "Charlie", 85),
        Student(4, "Alice", 85),
        Student(5, "Diana", 90),
    ]

    print("\nOriginal List:")
    for s in students:
        print(f"  {s}")

    # Sort using cmp_to_key
    sorted_students = sorted(students, key=cmp_to_key(student_comparator))

    print("\nSorted List:")
    for s in sorted_students:
        print(f"  {s}")

    # DRY RUN TRACE
    print("\n" + "-" * 70)
    print("DRY RUN TRACE - Comparator Calls:")
    print("-" * 70)
    print("""
    The comparator is called for pairs of elements during sorting:

    Example Comparisons:

    1. student_comparator(Alice(85), Bob(90)):
       - s1.marks(85) != s2.marks(90)
       - return s2.marks - s1.marks = 90 - 85 = 5 (positive)
       - Positive means s1 comes AFTER s2
       - Result: Bob comes before Alice

    2. student_comparator(Bob(90), Diana(90)):
       - s1.marks(90) == s2.marks(90), check names
       - s1.name('Bob') != s2.name('Diana')
       - 'Bob' < 'Diana' is True
       - return -1 (negative means s1 comes first)
       - Result: Bob comes before Diana

    3. student_comparator(Alice(85,r=1), Alice(85,r=4)):
       - marks equal, names equal
       - return s1.roll_no - s2.roll_no = 1 - 4 = -3 (negative)
       - Negative means s1 comes first
       - Result: roll=1 comes before roll=4

    HOW cmp_to_key WORKS INTERNALLY:
    --------------------------------
    It wraps each element in a class that defines __lt__ using the comparator:

    class K:
        def __init__(self, obj):
            self.obj = obj
        def __lt__(self, other):
            return comparator(self.obj, other.obj) < 0

    This converts the old-style comparator to new-style key function.
    """)

    return sorted_students


# ==============================================================================
#                    PROBLEM 2: SORTING LIST OF DICTIONARIES
# ==============================================================================
"""
PROBLEM STATEMENT:
------------------
Sort a list of dictionaries where each dictionary represents a person with:
- name (str): Person's name
- age (int): Person's age
- salary (int): Person's salary

SORTING CRITERIA:
1. age (ASCENDING - younger first)
2. name (ASCENDING - alphabetical)

VISUAL REPRESENTATION:
----------------------
Given List:
+--------+-----+--------+
|  name  | age | salary |
+--------+-----+--------+
| Alice  | 30  | 70000  |
| Bob    | 25  | 60000  |
| Charlie| 25  | 80000  |
| Diana  | 30  | 65000  |
| Eve    | 25  | 55000  |
+--------+-----+--------+

After Sorting (by age ASC, then name ASC):
+--------+-----+--------+
|  name  | age | salary |
+--------+-----+--------+
| Bob    | 25  | 60000  | <- age=25, 'Bob' comes first
| Charlie| 25  | 80000  | <- age=25, 'Charlie' after 'Bob'
| Eve    | 25  | 55000  | <- age=25, 'Eve' after 'Charlie'
| Alice  | 30  | 70000  | <- age=30, 'Alice' comes first
| Diana  | 30  | 65000  | <- age=30, 'Diana' after 'Alice'
+--------+-----+--------+
"""


# ------------------------------------------------------------------------------
#                    APPROACH 1: Using Lambda with Tuple Key
# ------------------------------------------------------------------------------

def demo_dict_approach1_lambda_tuple():
    """
    Sort dictionaries using lambda with tuple key.
    """
    print("\n" + "=" * 70)
    print("DICTIONARY SORTING - APPROACH 1: Lambda with Tuple")
    print("=" * 70)

    people = [
        {"name": "Alice", "age": 30, "salary": 70000},
        {"name": "Bob", "age": 25, "salary": 60000},
        {"name": "Charlie", "age": 25, "salary": 80000},
        {"name": "Diana", "age": 30, "salary": 65000},
        {"name": "Eve", "age": 25, "salary": 55000},
    ]

    print("\nOriginal List:")
    for p in people:
        print(f"  {p}")

    # Sort by age (ascending), then name (ascending)
    sorted_people = sorted(
        people,
        key=lambda p: (p['age'], p['name'])
    )

    print("\nSorted by (age ASC, name ASC):")
    for p in sorted_people:
        print(f"  {p}")

    # DRY RUN
    print("\n" + "-" * 70)
    print("DRY RUN TRACE:")
    print("-" * 70)
    print("""
    Key generation for each person:

    Alice   -> (30, 'Alice')
    Bob     -> (25, 'Bob')
    Charlie -> (25, 'Charlie')
    Diana   -> (30, 'Diana')
    Eve     -> (25, 'Eve')

    Tuple comparison (lexicographic):

    (25, 'Bob') < (25, 'Charlie') < (25, 'Eve') < (30, 'Alice') < (30, 'Diana')
      |             |                |              |              |
      v             v                v              v              v
     Bob         Charlie           Eve           Alice          Diana
    """)

    # Example with descending age
    print("\n" + "-" * 50)
    print("Sorting by (age DESC, name ASC):")
    print("-" * 50)

    sorted_desc_age = sorted(
        people,
        key=lambda p: (-p['age'], p['name'])  # Negative for descending
    )

    for p in sorted_desc_age:
        print(f"  {p}")

    return sorted_people


# ------------------------------------------------------------------------------
#                    APPROACH 2: Using operator.itemgetter
# ------------------------------------------------------------------------------
"""
CONCEPT:
--------
operator.itemgetter('key1', 'key2') returns a callable that extracts
values from a dictionary (or sequence) as a tuple.

itemgetter('age', 'name') is equivalent to lambda x: (x['age'], x['name'])

ADVANTAGES:
- Faster than lambda (implemented in C)
- Cleaner syntax for simple key extraction
- Works with both dicts and sequences (lists/tuples)

LIMITATIONS:
- Cannot modify values (e.g., negate for descending)
- For complex transformations, use lambda
"""


def demo_dict_approach2_itemgetter():
    """
    Sort dictionaries using operator.itemgetter.
    """
    print("\n" + "=" * 70)
    print("DICTIONARY SORTING - APPROACH 2: operator.itemgetter")
    print("=" * 70)

    people = [
        {"name": "Alice", "age": 30, "salary": 70000},
        {"name": "Bob", "age": 25, "salary": 60000},
        {"name": "Charlie", "age": 25, "salary": 80000},
        {"name": "Diana", "age": 30, "salary": 65000},
        {"name": "Eve", "age": 25, "salary": 55000},
    ]

    print("\nOriginal List:")
    for p in people:
        print(f"  {p}")

    # Sort by age, then name (both ascending)
    sorted_people = sorted(people, key=itemgetter('age', 'name'))

    print("\nSorted by (age, name) using itemgetter:")
    for p in sorted_people:
        print(f"  {p}")

    # itemgetter also works with indices for lists/tuples
    print("\n" + "-" * 50)
    print("itemgetter with indices (for list of tuples):")
    print("-" * 50)

    tuple_data = [
        ("Alice", 30, 70000),
        ("Bob", 25, 60000),
        ("Charlie", 25, 80000),
    ]

    # Sort by index 1 (age), then index 0 (name)
    sorted_tuples = sorted(tuple_data, key=itemgetter(1, 0))

    print("\nOriginal tuples: (name, age, salary)")
    for t in tuple_data:
        print(f"  {t}")

    print("\nSorted by (age, name):")
    for t in sorted_tuples:
        print(f"  {t}")

    return sorted_people


# ------------------------------------------------------------------------------
#                    APPROACH 3: Using cmp_to_key for Dictionaries
# ------------------------------------------------------------------------------

def dict_comparator(d1: Dict, d2: Dict) -> int:
    """
    Compare two dictionaries by age (ascending), then name (ascending).

    Returns:
        < 0 if d1 should come before d2
        = 0 if equal
        > 0 if d1 should come after d2
    """
    # Compare age first (ascending)
    if d1['age'] != d2['age']:
        return d1['age'] - d2['age']  # d1 - d2 for ascending

    # Ages equal, compare names (ascending)
    if d1['name'] < d2['name']:
        return -1
    elif d1['name'] > d2['name']:
        return 1
    return 0


def demo_dict_approach3_cmp_to_key():
    """
    Sort dictionaries using functools.cmp_to_key.
    """
    print("\n" + "=" * 70)
    print("DICTIONARY SORTING - APPROACH 3: cmp_to_key")
    print("=" * 70)

    people = [
        {"name": "Alice", "age": 30, "salary": 70000},
        {"name": "Bob", "age": 25, "salary": 60000},
        {"name": "Charlie", "age": 25, "salary": 80000},
        {"name": "Diana", "age": 30, "salary": 65000},
        {"name": "Eve", "age": 25, "salary": 55000},
    ]

    print("\nOriginal List:")
    for p in people:
        print(f"  {p}")

    sorted_people = sorted(people, key=cmp_to_key(dict_comparator))

    print("\nSorted using cmp_to_key:")
    for p in sorted_people:
        print(f"  {p}")

    return sorted_people


# ==============================================================================
#                    EDGE CASES AND SPECIAL SCENARIOS
# ==============================================================================

def demo_edge_cases():
    """
    Demonstrate handling of edge cases in custom sorting.
    """
    print("\n" + "=" * 70)
    print("EDGE CASES AND SPECIAL SCENARIOS")
    print("=" * 70)

    # Edge Case 1: Empty list
    print("\n1. Empty List:")
    empty_list = []
    print(f"   sorted([]) = {sorted(empty_list)}")

    # Edge Case 2: Single element
    print("\n2. Single Element:")
    single = [Student(1, "Alice", 85)]
    print(f"   sorted([Alice]) = {sorted(single, key=lambda s: s.marks)}")

    # Edge Case 3: All elements equal
    print("\n3. All Elements Equal (tests stability):")
    same_marks = [
        Student(1, "Alice", 85),
        Student(2, "Bob", 85),
        Student(3, "Charlie", 85),
    ]
    print("   Original order: Alice, Bob, Charlie")
    result = sorted(same_marks, key=lambda s: s.marks)
    print(f"   After sort by marks: {[s.name for s in result]}")
    print("   Note: Order preserved due to stable sort!")

    # Edge Case 4: None values
    print("\n4. Handling None Values:")
    people_with_none = [
        {"name": "Alice", "age": 30},
        {"name": "Bob", "age": None},
        {"name": "Charlie", "age": 25},
    ]

    # Method: Use a default value for None
    def safe_age_key(p):
        age = p['age']
        # Put None values at the end (use infinity)
        return (age is None, age if age is not None else 0)

    sorted_with_none = sorted(people_with_none, key=safe_age_key)
    print("   Original: Alice(30), Bob(None), Charlie(25)")
    print(f"   Sorted (None at end): {[p['name'] for p in sorted_with_none]}")

    # Edge Case 5: Case-insensitive string sorting
    print("\n5. Case-Insensitive String Sorting:")
    names = ["alice", "Bob", "CHARLIE", "diana"]

    # Default (case-sensitive): uppercase < lowercase
    print(f"   Case-sensitive: {sorted(names)}")

    # Case-insensitive
    print(f"   Case-insensitive: {sorted(names, key=str.lower)}")

    # Edge Case 6: Descending string sort
    print("\n6. Descending String Sort (without reverse=True):")
    names = ["Alice", "Bob", "Charlie"]

    # Method: Use negative ord values or reverse
    # For strings, it's easier to use reverse=True or sort in two phases
    print(f"   Original: {names}")
    print(f"   Descending (reverse=True): {sorted(names, reverse=True)}")


# ==============================================================================
#                    COMPLEXITY ANALYSIS
# ==============================================================================
"""
TIME AND SPACE COMPLEXITY ANALYSIS
==================================

All approaches use Python's Timsort algorithm:
- Time Complexity: O(n log n) comparisons
- Space Complexity: O(n) for the sorting algorithm itself

ADDITIONAL OVERHEAD BY APPROACH:

1. __lt__ Method:
   - Key computation: O(1) per comparison (no key precomputation)
   - Total comparisons: O(n log n)
   - Total time: O(n log n)
   - Additional space: O(1)

2. Tuple Key (lambda/attrgetter/itemgetter):
   - Key computation: O(n) to generate all keys upfront
   - Keys are cached, so only ONE key call per element
   - Total time: O(n) + O(n log n) = O(n log n)
   - Additional space: O(n) for storing keys

3. cmp_to_key:
   - Creates wrapper objects for each element
   - Comparator called O(n log n) times
   - Total time: O(n log n) with higher constant factor
   - Additional space: O(n) for wrapper objects

PERFORMANCE RANKING (fastest to slowest):
1. operator.attrgetter / operator.itemgetter (C implementation)
2. Lambda tuple key
3. __lt__ method
4. cmp_to_key (highest overhead)

RECOMMENDATION:
- For simple key extraction: Use attrgetter/itemgetter
- For transformations (like negation): Use lambda tuple
- For inherent object ordering: Use __lt__
- For complex comparisons: Use cmp_to_key as last resort
"""


# ==============================================================================
#                    INTERVIEW TIPS
# ==============================================================================
"""
COMMON INTERVIEW QUESTIONS:

Q1: How do you sort by multiple criteria in Python?
A1: Use a tuple key: sorted(list, key=lambda x: (x.a, x.b, x.c))
    Tuples compare lexicographically, element by element.

Q2: How do you sort in descending order for one field?
A2: For numeric fields, use negative: key=lambda x: (-x.marks, x.name)
    For all fields, use reverse=True
    For mixed, use two-phase sorting with stable sort

Q3: What is stable sorting and why does it matter?
A3: Stable sorting preserves the relative order of equal elements.
    Python's sort is stable (Timsort). This allows multi-phase sorting
    where secondary sort order is preserved after primary sort.

Q4: What's the difference between sort() and sorted()?
A4: sort() is an in-place method on lists (returns None)
    sorted() creates a new sorted list (works on any iterable)

Q5: How do you make a custom class sortable?
A5: Define __lt__ method, or use key parameter with sorted()
    For full comparison support, use @functools.total_ordering
    with __lt__ and __eq__

Q6: When would you use cmp_to_key?
A6: When the comparison logic is complex and depends on both elements,
    or when migrating Python 2 code. Generally, prefer key functions.
"""


# ==============================================================================
#                    ALTERNATIVE IMPLEMENTATION: @total_ordering
# ==============================================================================

from functools import total_ordering


@total_ordering
class StudentComplete:
    """
    Student class with complete comparison support using @total_ordering.

    @total_ordering decorator automatically generates:
    - __le__ (<=)
    - __gt__ (>)
    - __ge__ (>=)

    from just __eq__ and __lt__.

    This is useful when you need all comparison operators,
    not just for sorting.
    """

    def __init__(self, roll_no: int, name: str, marks: int):
        self.roll_no = roll_no
        self.name = name
        self.marks = marks

    def __repr__(self) -> str:
        return f"Student(roll={self.roll_no}, name='{self.name}', marks={self.marks})"

    def __eq__(self, other: 'StudentComplete') -> bool:
        """Two students are equal if all fields match."""
        if not isinstance(other, StudentComplete):
            return NotImplemented
        return (self.marks, self.name, self.roll_no) == (other.marks, other.name, other.roll_no)

    def __lt__(self, other: 'StudentComplete') -> bool:
        """Less than comparison for sorting."""
        if not isinstance(other, StudentComplete):
            return NotImplemented
        # Descending marks, ascending name, ascending roll
        return (-self.marks, self.name, self.roll_no) < (-other.marks, other.name, other.roll_no)


def demo_total_ordering():
    """
    Demonstrate @total_ordering decorator.
    """
    print("\n" + "=" * 70)
    print("BONUS: Using @total_ordering Decorator")
    print("=" * 70)

    s1 = StudentComplete(1, "Alice", 85)
    s2 = StudentComplete(2, "Bob", 90)

    print(f"\ns1 = {s1}")
    print(f"s2 = {s2}")
    print(f"\nComparison operators (auto-generated by @total_ordering):")
    print(f"  s1 < s2:  {s1 < s2}")
    print(f"  s1 <= s2: {s1 <= s2}")
    print(f"  s1 > s2:  {s1 > s2}")
    print(f"  s1 >= s2: {s1 >= s2}")
    print(f"  s1 == s2: {s1 == s2}")

    students = [
        StudentComplete(1, "Alice", 85),
        StudentComplete(2, "Bob", 90),
        StudentComplete(3, "Charlie", 85),
    ]

    print("\nSorted list:")
    for s in sorted(students):
        print(f"  {s}")


# ==============================================================================
#                    MAIN EXECUTION
# ==============================================================================

def main():
    """
    Run all demonstrations.
    """
    print("\n" + "#" * 70)
    print("#" + " " * 20 + "CUSTOM SORTING IN PYTHON" + " " * 22 + "#")
    print("#" * 70)

    # Problem 1: Student Object Sorting
    print("\n" + "=" * 70)
    print("                 PROBLEM 1: SORTING STUDENT OBJECTS")
    print("=" * 70)

    demo_approach1_lt_method()
    demo_approach2_tuple_key()
    demo_approach3_attrgetter()
    demo_approach4_cmp_to_key()

    # Problem 2: Dictionary Sorting
    print("\n" + "=" * 70)
    print("               PROBLEM 2: SORTING LIST OF DICTIONARIES")
    print("=" * 70)

    demo_dict_approach1_lambda_tuple()
    demo_dict_approach2_itemgetter()
    demo_dict_approach3_cmp_to_key()

    # Edge Cases
    demo_edge_cases()

    # Bonus: total_ordering
    demo_total_ordering()

    # Summary
    print("\n" + "=" * 70)
    print("                           SUMMARY")
    print("=" * 70)
    print("""
    APPROACHES COVERED:

    1. __lt__ Method:
       - Define comparison logic in class
       - Objects become inherently sortable
       - Best for: Classes with one natural ordering

    2. Tuple Key (RECOMMENDED):
       - sorted(list, key=lambda x: (x.a, -x.b, x.c))
       - Use negative for descending numeric fields
       - Best for: Most use cases, flexible and readable

    3. operator.attrgetter / itemgetter:
       - Faster than lambda (C implementation)
       - Limited to simple attribute/key extraction
       - Best for: Performance-critical, simple extractions

    4. functools.cmp_to_key:
       - Old-style comparator converted to key function
       - Higher overhead
       - Best for: Complex comparisons, legacy code migration

    5. @total_ordering:
       - Auto-generates all comparison operators
       - Needs only __eq__ and __lt__
       - Best for: Classes needing full comparison support

    KEY TAKEAWAYS:
    - Python's sort is STABLE (preserves order of equal elements)
    - Use tuple keys for multiple criteria
    - Negate numeric values for descending order
    - attrgetter/itemgetter are fastest for simple cases
    """)


if __name__ == "__main__":
    main()
