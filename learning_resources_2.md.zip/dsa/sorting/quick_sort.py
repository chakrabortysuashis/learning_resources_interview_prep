"""
================================================================================
                              QUICK SORT ALGORITHM
================================================================================

WHAT IS QUICK SORT?
-------------------
Quick Sort is a highly efficient, comparison-based sorting algorithm that uses
the "Divide and Conquer" strategy. Unlike Merge Sort which divides first and
merges later, Quick Sort does the heavy lifting during the DIVIDE phase through
a process called PARTITIONING.

Key Idea: Pick a "pivot" element, rearrange the array so that:
  - All elements SMALLER than pivot go to its LEFT
  - All elements GREATER than pivot go to its RIGHT
  - The pivot is now in its FINAL sorted position
Then recursively sort the left and right subarrays.


HOW IT WORKS CONCEPTUALLY:
--------------------------
Step 1: Choose a PIVOT element from the array
Step 2: PARTITION the array around the pivot
        - Elements < pivot move to left side
        - Elements > pivot move to right side
        - Pivot lands in its correct final position
Step 3: RECURSIVELY apply steps 1-2 to left subarray
Step 4: RECURSIVELY apply steps 1-2 to right subarray
Step 5: Array is sorted! (No merge step needed)

Visual Example:
    [10, 7, 8, 9, 1, 5]  <- pivot = 5
           |
    Partition around 5
           |
    [1] [5] [10, 7, 8, 9]  <- 5 is now in correct position!
     |           |
   sorted    Recurse on this part


TIME COMPLEXITY:
----------------
Best Case:    O(n log n) - When pivot always divides array into equal halves
Average Case: O(n log n) - Random data, pivot divides reasonably well
Worst Case:   O(n^2)     - When pivot is always smallest or largest element

WHY O(n log n) in Best/Average Case?
  - Each partition takes O(n) time to scan all elements
  - If we divide in half each time, we get log(n) levels of recursion
  - Total: O(n) * O(log n) = O(n log n)

WHY O(n^2) in Worst Case?
  - If pivot is always the smallest/largest, one partition has (n-1) elements
  - This creates n levels of recursion instead of log(n)
  - Example: Already sorted array [1,2,3,4,5] with last element as pivot
    Level 1: pivot=5, left=[1,2,3,4], right=[]     -> n operations
    Level 2: pivot=4, left=[1,2,3], right=[]       -> n-1 operations
    Level 3: pivot=3, left=[1,2], right=[]         -> n-2 operations
    ...and so on = n + (n-1) + (n-2) + ... + 1 = O(n^2)


SPACE COMPLEXITY:
-----------------
O(log n) average - for the recursion call stack
O(n) worst case  - when recursion depth is n (unbalanced partitions)

Note: Quick Sort is an IN-PLACE algorithm! It doesn't need extra arrays
like Merge Sort. The space is only for recursion stack frames.


COMPARISON WITH MERGE SORT:
---------------------------
+------------------+-------------------+-------------------+
|    Aspect        |    Quick Sort     |    Merge Sort     |
+------------------+-------------------+-------------------+
| Average Time     | O(n log n)        | O(n log n)        |
| Worst Time       | O(n^2)            | O(n log n)        |
| Space            | O(log n) in-place | O(n) extra array  |
| Stable?          | NO                | YES               |
| Cache Friendly?  | YES (better)      | NO (scattered)    |
+------------------+-------------------+-------------------+

When to use Quick Sort:
  - When average-case performance matters (usually faster in practice)
  - When memory is limited (in-place sorting)
  - When stability is not required
  - Arrays (better cache locality)

When to use Merge Sort:
  - When worst-case guarantee is needed
  - When stability is required (equal elements maintain order)
  - Linked Lists (no random access penalty)
  - External sorting (large files on disk)


================================================================================
"""

import random
from typing import List


# ==============================================================================
# IMPLEMENTATION 1: LOMUTO PARTITION SCHEME
# ==============================================================================
# The Lomuto scheme is simpler to understand and implement.
# It uses the LAST element as the pivot.
# ==============================================================================

def partition_lomuto(arr: List[int], low: int, high: int) -> int:
    """
    Lomuto Partition Scheme
    -----------------------
    Partitions the array around the last element (pivot).

    How it works:
    - Choose last element as pivot
    - Maintain index 'i' for the "boundary" of smaller elements
    - Scan through array with index 'j'
    - When we find element smaller than pivot, swap it to the boundary
    - Finally, place pivot at the boundary position

    Parameters:
        arr: The array to partition
        low: Starting index of the partition range
        high: Ending index of the partition range (pivot position)

    Returns:
        The final position of the pivot (its correct sorted position)

    Visual walkthrough for arr = [10, 7, 8, 9, 1, 5], low=0, high=5:

    pivot = 5 (arr[high])
    i = -1 (boundary starts before array)

    j=0: arr[0]=10 > 5? Yes, do nothing.     i=-1
    j=1: arr[1]=7 > 5? Yes, do nothing.      i=-1
    j=2: arr[2]=8 > 5? Yes, do nothing.      i=-1
    j=3: arr[3]=9 > 5? Yes, do nothing.      i=-1
    j=4: arr[4]=1 < 5? YES! i=0, swap arr[0] with arr[4]
         Array becomes: [1, 7, 8, 9, 10, 5]

    Loop ends. Place pivot at i+1:
    Swap arr[1] with arr[5]: [1, 5, 8, 9, 10, 7]

    Return pivot_index = 1
    """
    # Step 1: Choose the last element as pivot
    pivot = arr[high]

    # Step 2: Initialize boundary pointer
    # 'i' tracks the position where next smaller element should go
    # All elements from low to i are <= pivot
    i = low - 1

    # Step 3: Scan through array (excluding pivot)
    for j in range(low, high):
        # If current element is smaller than or equal to pivot
        if arr[j] <= pivot:
            # Move boundary one step right
            i += 1
            # Swap current element to the "smaller" section
            arr[i], arr[j] = arr[j], arr[i]

    # Step 4: Place pivot in its correct position
    # All elements before i+1 are smaller, all after are larger
    arr[i + 1], arr[high] = arr[high], arr[i + 1]

    # Step 5: Return pivot's final position
    return i + 1


def quick_sort(arr: List[int], low: int, high: int) -> None:
    """
    Quick Sort using Lomuto Partition Scheme
    -----------------------------------------
    Recursively sorts the array in-place.

    Parameters:
        arr: The array to sort
        low: Starting index of the range to sort
        high: Ending index of the range to sort

    Base Case: When low >= high, the subarray has 0 or 1 element (already sorted)

    Recursive Case:
        1. Partition the array and get pivot's position
        2. Recursively sort left subarray (elements before pivot)
        3. Recursively sort right subarray (elements after pivot)
    """
    # Base case: subarray has 0 or 1 elements
    if low < high:
        # Partition and get pivot's final position
        pivot_index = partition_lomuto(arr, low, high)

        # Recursively sort left subarray (before pivot)
        # Note: pivot_index - 1, because pivot is already in place
        quick_sort(arr, low, pivot_index - 1)

        # Recursively sort right subarray (after pivot)
        quick_sort(arr, pivot_index + 1, high)


# ==============================================================================
# IMPLEMENTATION 2: HOARE PARTITION SCHEME
# ==============================================================================
# The Hoare scheme is the original partitioning method by Tony Hoare.
# It uses TWO pointers that move towards each other.
# Generally more efficient (fewer swaps) but harder to understand.
# ==============================================================================

def partition_hoare(arr: List[int], low: int, high: int) -> int:
    """
    Hoare Partition Scheme
    ----------------------
    Uses two pointers moving towards each other.

    How it works:
    - Choose first element as pivot
    - Left pointer starts from low, moves right looking for element > pivot
    - Right pointer starts from high, moves left looking for element < pivot
    - When both find their targets, swap them
    - Continue until pointers cross

    Key Difference from Lomuto:
    - Hoare does NOT place pivot in its final position!
    - It just ensures elements left of return value are <= pivot
    - And elements right of return value are >= pivot
    - The pivot itself could be anywhere in the left partition

    This means the recursive calls are slightly different:
    - quick_sort(arr, low, pivot_index)      <- includes pivot_index
    - quick_sort(arr, pivot_index + 1, high)

    Parameters:
        arr: The array to partition
        low: Starting index
        high: Ending index

    Returns:
        Partition index (not necessarily pivot's final position)
    """
    # Choose first element as pivot
    pivot = arr[low]

    # Initialize two pointers
    # i starts one position left of low (will be incremented first)
    # j starts one position right of high (will be decremented first)
    i = low - 1
    j = high + 1

    while True:
        # Move i right until we find element >= pivot
        i += 1
        while arr[i] < pivot:
            i += 1

        # Move j left until we find element <= pivot
        j -= 1
        while arr[j] > pivot:
            j -= 1

        # If pointers crossed, partitioning is done
        if i >= j:
            return j

        # Swap elements at i and j
        # This puts smaller element on left, larger on right
        arr[i], arr[j] = arr[j], arr[i]


def quick_sort_hoare(arr: List[int], low: int, high: int) -> None:
    """
    Quick Sort using Hoare Partition Scheme
    ---------------------------------------
    Note the subtle difference in recursive calls compared to Lomuto:
    - Left partition includes pivot_index (not pivot_index - 1)
    - This is because Hoare doesn't place pivot in final position
    """
    if low < high:
        # Partition and get dividing index
        pivot_index = partition_hoare(arr, low, high)

        # Recursively sort left partition (includes pivot_index)
        quick_sort_hoare(arr, low, pivot_index)

        # Recursively sort right partition
        quick_sort_hoare(arr, pivot_index + 1, high)


# ==============================================================================
# IMPLEMENTATION 3: RANDOMIZED QUICK SORT
# ==============================================================================
# Randomized pivot selection avoids worst-case O(n^2) for sorted arrays.
# By choosing a random pivot, we get O(n log n) expected time.
# ==============================================================================

def partition_randomized(arr: List[int], low: int, high: int) -> int:
    """
    Randomized Partition
    --------------------
    Randomly selects a pivot and then uses Lomuto partitioning.

    Why randomize?
    - For sorted/reverse-sorted arrays, fixed pivot (first/last) gives O(n^2)
    - Random pivot makes worst-case extremely unlikely
    - Expected time complexity becomes O(n log n) regardless of input

    How it works:
    1. Pick a random index between low and high
    2. Swap that element with the last element (so Lomuto can use it as pivot)
    3. Proceed with normal Lomuto partition
    """
    # Step 1: Generate random pivot index
    random_index = random.randint(low, high)

    # Step 2: Move random pivot to the end (for Lomuto scheme)
    arr[random_index], arr[high] = arr[high], arr[random_index]

    # Step 3: Use standard Lomuto partition
    return partition_lomuto(arr, low, high)


def quick_sort_randomized(arr: List[int], low: int, high: int) -> None:
    """
    Randomized Quick Sort
    ---------------------
    Same structure as regular quick sort, but uses randomized partitioning.

    Benefits:
    - O(n log n) expected time for ANY input
    - No adversarial input can cause worst-case behavior
    - Preferred in practice for general-purpose sorting
    """
    if low < high:
        # Partition with random pivot
        pivot_index = partition_randomized(arr, low, high)

        # Recursively sort both halves
        quick_sort_randomized(arr, low, pivot_index - 1)
        quick_sort_randomized(arr, pivot_index + 1, high)


# ==============================================================================
# IMPLEMENTATION 4: MEDIAN-OF-THREE QUICK SORT
# ==============================================================================
# Another strategy to avoid worst-case: choose median of first, middle, last
# ==============================================================================

def median_of_three(arr: List[int], low: int, high: int) -> int:
    """
    Find index of median among first, middle, and last elements.
    This is a deterministic way to choose a good pivot.

    Why median of three?
    - Avoids worst case for sorted/reverse-sorted arrays
    - Deterministic (unlike random)
    - Simple to compute
    - Often picks a reasonable pivot
    """
    mid = (low + high) // 2

    # Sort the three elements and return the middle one's index
    # We want: arr[low] <= arr[mid] <= arr[high]
    if arr[low] > arr[mid]:
        arr[low], arr[mid] = arr[mid], arr[low]
    if arr[low] > arr[high]:
        arr[low], arr[high] = arr[high], arr[low]
    if arr[mid] > arr[high]:
        arr[mid], arr[high] = arr[high], arr[mid]

    # Now arr[mid] is the median value
    # Move it to high position for partitioning (Lomuto variant)
    arr[mid], arr[high] = arr[high], arr[mid]

    return high  # pivot is now at high


def quick_sort_median_of_three(arr: List[int], low: int, high: int) -> None:
    """
    Quick Sort with Median-of-Three Pivot Selection
    ------------------------------------------------
    Uses median of first, middle, last as pivot.
    Good balance between simplicity and avoiding worst-case.
    """
    if low < high:
        if high - low + 1 > 2:  # Only use median-of-three for arrays > 2 elements
            median_of_three(arr, low, high)

        pivot_index = partition_lomuto(arr, low, high)
        quick_sort_median_of_three(arr, low, pivot_index - 1)
        quick_sort_median_of_three(arr, pivot_index + 1, high)


# ==============================================================================
#                         DETAILED DRY RUN TRACE
# ==============================================================================
"""
================================================================================
DRY RUN 1: Array [10, 7, 8, 9, 1, 5] using Lomuto Partition
================================================================================

Initial Array: [10, 7, 8, 9, 1, 5]
Indices:         0  1  2  3  4  5

Call: quick_sort(arr, 0, 5)

--------------------------------------------------------------------------------
LEVEL 1: quick_sort(arr, 0, 5)
--------------------------------------------------------------------------------
low=0, high=5
Since low < high, we partition.

PARTITION(arr, 0, 5):
    pivot = arr[5] = 5
    i = low - 1 = -1

    Scanning j from 0 to 4:

    j=0: arr[0]=10, is 10 <= 5? NO
         Array: [10, 7, 8, 9, 1, 5]
         i = -1 (unchanged)

    j=1: arr[1]=7, is 7 <= 5? NO
         Array: [10, 7, 8, 9, 1, 5]
         i = -1 (unchanged)

    j=2: arr[2]=8, is 8 <= 5? NO
         Array: [10, 7, 8, 9, 1, 5]
         i = -1 (unchanged)

    j=3: arr[3]=9, is 9 <= 5? NO
         Array: [10, 7, 8, 9, 1, 5]
         i = -1 (unchanged)

    j=4: arr[4]=1, is 1 <= 5? YES!
         i = i + 1 = 0
         Swap arr[0] with arr[4]: swap 10 and 1
         Array: [1, 7, 8, 9, 10, 5]
                 ^           ^
                i=0         j=4

    Loop ends. Place pivot at i+1:
    Swap arr[1] with arr[5]: swap 7 and 5
    Array: [1, 5, 8, 9, 10, 7]
              ^
           pivot in final position (index 1)

    Return pivot_index = 1

After partition: [1, 5, 8, 9, 10, 7]
                  |  |  |________|
                  |  |     |
              smaller pivot  larger (unsorted)
              than 5   (sorted)

Recursive calls:
- quick_sort(arr, 0, 0)  -> left of pivot
- quick_sort(arr, 2, 5)  -> right of pivot

--------------------------------------------------------------------------------
LEVEL 2a: quick_sort(arr, 0, 0) - LEFT SUBARRAY
--------------------------------------------------------------------------------
low=0, high=0
Since low >= high, this is BASE CASE. Return immediately.
Subarray [1] is sorted (single element).

--------------------------------------------------------------------------------
LEVEL 2b: quick_sort(arr, 2, 5) - RIGHT SUBARRAY
--------------------------------------------------------------------------------
low=2, high=5
Current subarray: [8, 9, 10, 7] (indices 2-5)
Since low < high, we partition.

PARTITION(arr, 2, 5):
    pivot = arr[5] = 7
    i = low - 1 = 1

    j=2: arr[2]=8, is 8 <= 7? NO
         Array: [1, 5, 8, 9, 10, 7]
         i = 1 (unchanged)

    j=3: arr[3]=9, is 9 <= 7? NO
         Array: [1, 5, 8, 9, 10, 7]
         i = 1 (unchanged)

    j=4: arr[4]=10, is 10 <= 7? NO
         Array: [1, 5, 8, 9, 10, 7]
         i = 1 (unchanged)

    Loop ends. Place pivot at i+1:
    Swap arr[2] with arr[5]: swap 8 and 7
    Array: [1, 5, 7, 9, 10, 8]
                 ^
              pivot at index 2

    Return pivot_index = 2

After partition: [1, 5, 7, 9, 10, 8]
                        |  |_____|
                     pivot  larger (unsorted)
                     No elements smaller than 7 in range [2,5]

Recursive calls:
- quick_sort(arr, 2, 1)  -> left of pivot (empty, low > high)
- quick_sort(arr, 3, 5)  -> right of pivot

--------------------------------------------------------------------------------
LEVEL 3a: quick_sort(arr, 2, 1) - EMPTY SUBARRAY
--------------------------------------------------------------------------------
low=2, high=1
Since low >= high, BASE CASE. Return immediately.

--------------------------------------------------------------------------------
LEVEL 3b: quick_sort(arr, 3, 5) - SUBARRAY [9, 10, 8]
--------------------------------------------------------------------------------
low=3, high=5
Current subarray: [9, 10, 8] (indices 3-5)

PARTITION(arr, 3, 5):
    pivot = arr[5] = 8
    i = low - 1 = 2

    j=3: arr[3]=9, is 9 <= 8? NO
         Array: [1, 5, 7, 9, 10, 8]
         i = 2 (unchanged)

    j=4: arr[4]=10, is 10 <= 8? NO
         Array: [1, 5, 7, 9, 10, 8]
         i = 2 (unchanged)

    Loop ends. Place pivot at i+1:
    Swap arr[3] with arr[5]: swap 9 and 8
    Array: [1, 5, 7, 8, 10, 9]
                    ^
                 pivot at index 3

    Return pivot_index = 3

Recursive calls:
- quick_sort(arr, 3, 2)  -> empty
- quick_sort(arr, 4, 5)  -> [10, 9]

--------------------------------------------------------------------------------
LEVEL 4a: quick_sort(arr, 3, 2) - EMPTY SUBARRAY
--------------------------------------------------------------------------------
BASE CASE. Return.

--------------------------------------------------------------------------------
LEVEL 4b: quick_sort(arr, 4, 5) - SUBARRAY [10, 9]
--------------------------------------------------------------------------------
low=4, high=5
Current subarray: [10, 9]

PARTITION(arr, 4, 5):
    pivot = arr[5] = 9
    i = low - 1 = 3

    j=4: arr[4]=10, is 10 <= 9? NO
         Array: [1, 5, 7, 8, 10, 9]
         i = 3 (unchanged)

    Loop ends. Place pivot at i+1:
    Swap arr[4] with arr[5]: swap 10 and 9
    Array: [1, 5, 7, 8, 9, 10]
                       ^
                    pivot at index 4

    Return pivot_index = 4

Recursive calls:
- quick_sort(arr, 4, 3)  -> empty
- quick_sort(arr, 5, 5)  -> single element [10]

Both are BASE CASES. Return.

--------------------------------------------------------------------------------
FINAL SORTED ARRAY: [1, 5, 7, 8, 9, 10]
--------------------------------------------------------------------------------

RECURSION TREE VISUALIZATION:
                      [10, 7, 8, 9, 1, 5]
                      pivot=5, partition
                             |
             +---------------+---------------+
             |                               |
           [1]                        [8, 9, 10, 7]
         (sorted)                     pivot=7, partition
                                            |
                              +-------------+-------------+
                              |                           |
                           (empty)                    [9, 10, 8]
                                                    pivot=8, partition
                                                          |
                                            +-------------+-------------+
                                            |                           |
                                         (empty)                     [10, 9]
                                                                   pivot=9, partition
                                                                        |
                                                          +-------------+-------------+
                                                          |                           |
                                                       (empty)                      [10]
                                                                                  (sorted)


================================================================================
DRY RUN 2: Array [3, 1, 4, 1, 5, 9, 2, 6] using Lomuto Partition
================================================================================

Initial Array: [3, 1, 4, 1, 5, 9, 2, 6]
Indices:         0  1  2  3  4  5  6  7

This example shows handling of DUPLICATE elements (two 1s).

--------------------------------------------------------------------------------
LEVEL 1: quick_sort(arr, 0, 7)
--------------------------------------------------------------------------------
pivot = arr[7] = 6
i = -1

j=0: arr[0]=3 <= 6? YES. i=0, swap arr[0] with arr[0] (no change)
     [3, 1, 4, 1, 5, 9, 2, 6]

j=1: arr[1]=1 <= 6? YES. i=1, swap arr[1] with arr[1] (no change)
     [3, 1, 4, 1, 5, 9, 2, 6]

j=2: arr[2]=4 <= 6? YES. i=2, swap arr[2] with arr[2] (no change)
     [3, 1, 4, 1, 5, 9, 2, 6]

j=3: arr[3]=1 <= 6? YES. i=3, swap arr[3] with arr[3] (no change)
     [3, 1, 4, 1, 5, 9, 2, 6]

j=4: arr[4]=5 <= 6? YES. i=4, swap arr[4] with arr[4] (no change)
     [3, 1, 4, 1, 5, 9, 2, 6]

j=5: arr[5]=9 <= 6? NO. Skip.
     [3, 1, 4, 1, 5, 9, 2, 6], i=4

j=6: arr[6]=2 <= 6? YES. i=5, swap arr[5] with arr[6]
     [3, 1, 4, 1, 5, 2, 9, 6]
                    ^     ^
                   i=5   j=6

Place pivot: swap arr[6] with arr[7]
[3, 1, 4, 1, 5, 2, 6, 9]
                   ^
                pivot at index 6

Recursive calls:
- quick_sort(arr, 0, 5)  -> [3, 1, 4, 1, 5, 2]
- quick_sort(arr, 7, 7)  -> [9] (base case)

--------------------------------------------------------------------------------
LEVEL 2: quick_sort(arr, 0, 5) - [3, 1, 4, 1, 5, 2]
--------------------------------------------------------------------------------
pivot = arr[5] = 2
i = -1

j=0: 3 <= 2? NO. i=-1
j=1: 1 <= 2? YES. i=0, swap arr[0] with arr[1] -> [1, 3, 4, 1, 5, 2]
j=2: 4 <= 2? NO. i=0
j=3: 1 <= 2? YES. i=1, swap arr[1] with arr[3] -> [1, 1, 4, 3, 5, 2]
j=4: 5 <= 2? NO. i=1

Place pivot: swap arr[2] with arr[5]
[1, 1, 2, 3, 5, 4, 6, 9]
       ^
    pivot at index 2

Notice: Both 1s are now to the left of pivot 2. Duplicates handled correctly!

Recursive calls:
- quick_sort(arr, 0, 1)  -> [1, 1]
- quick_sort(arr, 3, 5)  -> [3, 5, 4]

--------------------------------------------------------------------------------
LEVEL 3a: quick_sort(arr, 0, 1) - [1, 1]
--------------------------------------------------------------------------------
pivot = arr[1] = 1
i = -1

j=0: 1 <= 1? YES. i=0, swap arr[0] with arr[0] (no change)

Place pivot: swap arr[1] with arr[1] (no change)
[1, 1, 2, 3, 5, 4, 6, 9]
    ^
 pivot at index 1

Recursive calls:
- quick_sort(arr, 0, 0)  -> [1] (base case)
- quick_sort(arr, 2, 1)  -> empty (base case)

--------------------------------------------------------------------------------
LEVEL 3b: quick_sort(arr, 3, 5) - [3, 5, 4]
--------------------------------------------------------------------------------
pivot = arr[5] = 4
i = 2

j=3: 3 <= 4? YES. i=3, swap arr[3] with arr[3] (no change)
j=4: 5 <= 4? NO. i=3

Place pivot: swap arr[4] with arr[5]
[1, 1, 2, 3, 4, 5, 6, 9]
             ^
          pivot at index 4

Recursive calls:
- quick_sort(arr, 3, 3)  -> [3] (base case)
- quick_sort(arr, 5, 5)  -> [5] (base case)

--------------------------------------------------------------------------------
FINAL SORTED ARRAY: [1, 1, 2, 3, 4, 5, 6, 9]
--------------------------------------------------------------------------------

================================================================================
"""


# ==============================================================================
#                           EDGE CASES SECTION
# ==============================================================================
"""
================================================================================
                              EDGE CASES
================================================================================

EDGE CASE 1: EMPTY ARRAY []
---------------------------
quick_sort([], 0, -1)
Since low (0) > high (-1), immediately returns.
Result: [] (correct)

EDGE CASE 2: SINGLE ELEMENT [42]
--------------------------------
quick_sort([42], 0, 0)
Since low (0) == high (0), condition low < high is False.
Immediately returns.
Result: [42] (correct - single element is always sorted)

EDGE CASE 3: ALREADY SORTED ARRAY [1, 2, 3, 4, 5]
-------------------------------------------------
This is the WORST CASE for Lomuto partition (last element as pivot)!

Step 1: pivot=5, all elements are smaller
        [1, 2, 3, 4, 5] -> partition returns 4
        Left: [1, 2, 3, 4], Right: []

Step 2: pivot=4, all elements are smaller
        [1, 2, 3, 4] -> partition returns 3
        Left: [1, 2, 3], Right: []

Step 3: pivot=3...
        And so on.

Each partition only removes ONE element (the pivot).
This creates n-1 recursive calls, making it O(n^2).

SOLUTION: Use randomized or median-of-three pivot selection!

EDGE CASE 4: REVERSE SORTED ARRAY [5, 4, 3, 2, 1]
-------------------------------------------------
Also WORST CASE for Lomuto.

pivot = arr[4] = 1
i = -1

j=0: 5 <= 1? NO
j=1: 4 <= 1? NO
j=2: 3 <= 1? NO
j=3: 2 <= 1? NO

i still = -1
Swap arr[i+1]=arr[0] with arr[4]
[1, 4, 3, 2, 5]
 ^
pivot at index 0

Left: [] (empty)
Right: [4, 3, 2, 5]

This continues with always having empty left partition.
Still O(n^2) because each step only reduces problem by 1.

EDGE CASE 5: ALL SAME ELEMENTS [7, 7, 7, 7, 7]
----------------------------------------------
pivot = 7
All elements equal to pivot, so all go to "left" section.

j=0: 7 <= 7? YES. i=0, swap (no change)
j=1: 7 <= 7? YES. i=1, swap (no change)
j=2: 7 <= 7? YES. i=2, swap (no change)
j=3: 7 <= 7? YES. i=3, swap (no change)

Swap arr[4] with arr[4] (no change)
pivot_index = 4

Left: [7, 7, 7, 7] (indices 0-3)
Right: [] (empty)

This is similar to sorted array case - still O(n^2)!

SOLUTION: Three-way partitioning (Dutch National Flag) handles this better.

EDGE CASE 6: ARRAY WITH DUPLICATES [4, 2, 4, 1, 4, 3]
-----------------------------------------------------
Lomuto handles duplicates correctly - elements equal to pivot
go to the left partition (<=). See Dry Run 2 above.

After sorting: [1, 2, 3, 4, 4, 4]

Note: Quick Sort is NOT stable! The relative order of equal elements
may not be preserved.

================================================================================
"""


# ==============================================================================
#                      PIVOT SELECTION STRATEGIES
# ==============================================================================
"""
================================================================================
                         PIVOT SELECTION STRATEGIES
================================================================================

The choice of pivot dramatically affects Quick Sort performance!

1. LAST ELEMENT (Lomuto Scheme)
-------------------------------
   Pros:
   - Simple to implement
   - Easy to understand

   Cons:
   - O(n^2) for sorted/reverse-sorted arrays
   - Predictable (can be exploited by adversarial input)

   When to use: Learning, when input is known to be random

2. FIRST ELEMENT
----------------
   Similar pros/cons to last element.
   Same O(n^2) worst case for sorted arrays.

   Implementation:
   def partition_first(arr, low, high):
       # Swap first with last, then use Lomuto
       arr[low], arr[high] = arr[high], arr[low]
       return partition_lomuto(arr, low, high)

3. RANDOM ELEMENT
-----------------
   Pros:
   - Expected O(n log n) for ANY input
   - No adversarial input can cause worst case
   - Simple to implement

   Cons:
   - Requires random number generator
   - Not deterministic (different runs may differ slightly)

   When to use: General-purpose sorting, when input pattern is unknown

   This is the RECOMMENDED approach for production code!

4. MEDIAN OF THREE
------------------
   Choose median of { arr[low], arr[mid], arr[high] }

   Pros:
   - Deterministic
   - Avoids worst case for sorted/reverse-sorted
   - Often picks a good pivot

   Cons:
   - Slightly more complex
   - Can still be O(n^2) with crafted adversarial input

   When to use: When deterministic behavior is preferred

5. MEDIAN OF MEDIANS (Guaranteed O(n log n))
--------------------------------------------
   - Divide array into groups of 5
   - Find median of each group
   - Recursively find median of medians
   - Use that as pivot

   Guarantees worst-case O(n log n), but overhead makes it slower
   in practice. Rarely used for sorting (used in selection algorithms).

================================================================================
WHY PIVOT SELECTION MATTERS:
================================================================================

Consider array: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

With LAST element pivot:          With RANDOM pivot (example):
--------------------------        ----------------------------
Level 1: pivot=10                 Level 1: pivot=5 (random)
         [1-9], []                         [1,2,3,4], [6,7,8,9,10]

Level 2: pivot=9                  Level 2: pivot=2, pivot=8
         [1-8], []                         [1], [3,4], [6,7], [9,10]

Level 3: pivot=8                  Level 3: All small subarrays
         [1-7], []

...                               Depth: ~log(n) = 3-4 levels
Level 9: pivot=2
         [1], []

Depth: n-1 = 9 levels             Operations: O(n log n)
Operations: O(n^2)

The difference: O(n^2) vs O(n log n) can be HUGE for large arrays!
For n = 1,000,000:
- O(n^2) = 1,000,000,000,000 operations (1 trillion!)
- O(n log n) = 20,000,000 operations (20 million)

That's 50,000x difference!

================================================================================
"""


# ==============================================================================
#                     HELPER FUNCTION FOR TESTING
# ==============================================================================

def quick_sort_wrapper(arr: List[int], method: str = "lomuto") -> List[int]:
    """
    Wrapper function that sorts a copy of the array and returns it.
    This allows testing without modifying the original array.

    Parameters:
        arr: Array to sort
        method: "lomuto", "hoare", "randomized", or "median"

    Returns:
        Sorted copy of the array
    """
    if len(arr) <= 1:
        return arr.copy()

    result = arr.copy()

    if method == "lomuto":
        quick_sort(result, 0, len(result) - 1)
    elif method == "hoare":
        quick_sort_hoare(result, 0, len(result) - 1)
    elif method == "randomized":
        quick_sort_randomized(result, 0, len(result) - 1)
    elif method == "median":
        quick_sort_median_of_three(result, 0, len(result) - 1)
    else:
        raise ValueError(f"Unknown method: {method}")

    return result


# ==============================================================================
#                           MAIN / TEST SECTION
# ==============================================================================

if __name__ == "__main__":
    print("=" * 70)
    print("                     QUICK SORT DEMONSTRATION")
    print("=" * 70)

    # Test Case 1: Example from dry run
    print("\n[Test 1] Standard array from dry run")
    arr1 = [10, 7, 8, 9, 1, 5]
    print(f"  Original:  {arr1}")
    sorted1 = quick_sort_wrapper(arr1, "lomuto")
    print(f"  Sorted:    {sorted1}")
    print(f"  Correct:   {sorted1 == sorted(arr1)}")

    # Test Case 2: Array with duplicates
    print("\n[Test 2] Array with duplicates")
    arr2 = [3, 1, 4, 1, 5, 9, 2, 6]
    print(f"  Original:  {arr2}")
    sorted2 = quick_sort_wrapper(arr2, "lomuto")
    print(f"  Sorted:    {sorted2}")
    print(f"  Correct:   {sorted2 == sorted(arr2)}")

    # Test Case 3: Empty array
    print("\n[Test 3] Empty array")
    arr3 = []
    print(f"  Original:  {arr3}")
    sorted3 = quick_sort_wrapper(arr3, "lomuto")
    print(f"  Sorted:    {sorted3}")
    print(f"  Correct:   {sorted3 == []}")

    # Test Case 4: Single element
    print("\n[Test 4] Single element")
    arr4 = [42]
    print(f"  Original:  {arr4}")
    sorted4 = quick_sort_wrapper(arr4, "lomuto")
    print(f"  Sorted:    {sorted4}")
    print(f"  Correct:   {sorted4 == [42]}")

    # Test Case 5: Already sorted (worst case for naive pivot)
    print("\n[Test 5] Already sorted array (worst case)")
    arr5 = [1, 2, 3, 4, 5]
    print(f"  Original:  {arr5}")
    sorted5 = quick_sort_wrapper(arr5, "lomuto")
    print(f"  Sorted:    {sorted5}")
    print(f"  Correct:   {sorted5 == [1, 2, 3, 4, 5]}")

    # Test Case 6: Reverse sorted (also worst case)
    print("\n[Test 6] Reverse sorted array (worst case)")
    arr6 = [5, 4, 3, 2, 1]
    print(f"  Original:  {arr6}")
    sorted6 = quick_sort_wrapper(arr6, "lomuto")
    print(f"  Sorted:    {sorted6}")
    print(f"  Correct:   {sorted6 == [1, 2, 3, 4, 5]}")

    # Test Case 7: All same elements
    print("\n[Test 7] All same elements")
    arr7 = [7, 7, 7, 7, 7]
    print(f"  Original:  {arr7}")
    sorted7 = quick_sort_wrapper(arr7, "lomuto")
    print(f"  Sorted:    {sorted7}")
    print(f"  Correct:   {sorted7 == [7, 7, 7, 7, 7]}")

    # Test Case 8: Negative numbers
    print("\n[Test 8] Array with negative numbers")
    arr8 = [-5, 3, -1, 0, 2, -8, 7]
    print(f"  Original:  {arr8}")
    sorted8 = quick_sort_wrapper(arr8, "lomuto")
    print(f"  Sorted:    {sorted8}")
    print(f"  Correct:   {sorted8 == sorted(arr8)}")

    # Test Case 9: Two elements
    print("\n[Test 9] Two elements")
    arr9 = [2, 1]
    print(f"  Original:  {arr9}")
    sorted9 = quick_sort_wrapper(arr9, "lomuto")
    print(f"  Sorted:    {sorted9}")
    print(f"  Correct:   {sorted9 == [1, 2]}")

    # Test Case 10: Large random array
    print("\n[Test 10] Large random array (n=20)")
    random.seed(42)  # For reproducibility
    arr10 = [random.randint(1, 100) for _ in range(20)]
    print(f"  Original:  {arr10}")
    sorted10 = quick_sort_wrapper(arr10, "lomuto")
    print(f"  Sorted:    {sorted10}")
    print(f"  Correct:   {sorted10 == sorted(arr10)}")

    print("\n" + "=" * 70)
    print("           COMPARING DIFFERENT PARTITION METHODS")
    print("=" * 70)

    test_arr = [64, 34, 25, 12, 22, 11, 90]
    print(f"\nTest array: {test_arr}")

    print(f"\n  Lomuto:     {quick_sort_wrapper(test_arr, 'lomuto')}")
    print(f"  Hoare:      {quick_sort_wrapper(test_arr, 'hoare')}")
    print(f"  Randomized: {quick_sort_wrapper(test_arr, 'randomized')}")
    print(f"  Median-3:   {quick_sort_wrapper(test_arr, 'median')}")

    print("\n" + "=" * 70)
    print("                      ALL TESTS COMPLETED!")
    print("=" * 70)

    # Summary
    print("""
    QUICK SORT SUMMARY:
    -------------------
    Time Complexity:  O(n log n) average, O(n^2) worst case
    Space Complexity: O(log n) for recursion stack

    Key Properties:
    - In-place sorting (no extra array needed)
    - Not stable (equal elements may be reordered)
    - Cache-friendly (good locality of reference)
    - Preferred for arrays over linked lists

    Best Practices:
    - Use randomized pivot for general-purpose sorting
    - Consider Insertion Sort for small subarrays (n < 10-20)
    - For guaranteed O(n log n), use Merge Sort or Heap Sort instead
    """)
