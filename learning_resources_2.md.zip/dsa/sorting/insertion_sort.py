
"""
Insertion Sort - Complete Explanation + Dry Run
==============================================

1) Is the given code correct?
-----------------------------
Yes, the original code is CORRECT.
It correctly implements insertion sort in ascending order.

Why it is correct:
- It starts from index 1, treating index 0 as an already sorted part.
- For each element `key`, it shifts all larger elements in the sorted part one
  position to the right.
- Then it inserts `key` in the correct position.
- After each pass, the left part of the array becomes sorted.

2) Core idea of Insertion Sort
------------------------------
Think of sorting playing cards in your hand:
- Pick one card (current element).
- Compare with cards on the left.
- Shift bigger cards right.
- Insert the picked card at correct place.

Main Idea:
=============
->In insertion sort , the array is divided into 2 parts the sorted and the unsorted the 
i in the iteration represents the boundary between the sorted and unsorted parts.Initially the sorted part contains only the first element (index 0), and the unsorted part contains the rest of the array.
-> The key element is compared with elements in the sorted part (left part) and inserted at the correct position by moving elements (greater than key) to right, ensuring the sorted part grows by one element each pass.After each pass i, subarray arr[0...i] is sorted.
-> This process continues until the entire array is sorted.
-> The j loop iterates over the left / sorted part to find the correct position for the key.

3) Step-by-step algorithm
-------------------------
Given array A of size n:
1. For i from 1 to n-1:
2.     key = A[i]
3.     j = i - 1
4.     While j >= 0 and A[j] > key:
5.         A[j + 1] = A[j]   (shift right)
6.         j = j - 1
7.     A[j + 1] = key         (insert key)

4) Visual explanation (for input [64, 25, 12, 22, 11])
------------------------------------------------------
Initial:
[64 | 25, 12, 22, 11]
 ^sorted  ^unsorted

Pass 1 (key=25):
[64] and key 25 -> 64 > 25, shift 64 right, insert 25
Result: [25, 64 | 12, 22, 11]

Pass 2 (key=12):
[25, 64] and key 12 -> shift 64, shift 25, insert 12
Result: [12, 25, 64 | 22, 11]

Pass 3 (key=22):
[12, 25, 64] and key 22 -> shift 64, shift 25, insert 22
Result: [12, 22, 25, 64 | 11]

Pass 4 (key=11):
[12, 22, 25, 64] and key 11 -> shift 64, 25, 22, 12, insert 11
Result: [11, 12, 22, 25, 64]

Final sorted array: [11, 12, 22, 25, 64]

5) Dry Run Table
----------------
+------+-----+-----+----------------------+----------------------------+
| Pass |  i  | key | Shifts performed     | Array after pass           |
+------+-----+-----+----------------------+----------------------------+
|  1   |  1  | 25  | 64 shifted           | [25, 64, 12, 22, 11]       |
|  2   |  2  | 12  | 64, 25 shifted       | [12, 25, 64, 22, 11]       |
|  3   |  3  | 22  | 64, 25 shifted       | [12, 22, 25, 64, 11]       |
|  4   |  4  | 11  | 64, 25, 22, 12 shifted| [11, 12, 22, 25, 64]      |
+------+-----+-----+----------------------+----------------------------+

Complexity:
- Best case: O(n)      (already sorted)
- Average case: O(n^2)
- Worst case: O(n^2)   (reverse sorted)
- Space: O(1) (in-place)
"""


def insertion_sort(arr):
    """
    Sorts the list in ascending order using Insertion Sort.

    Correctness note:
    After each pass i, subarray arr[0...i] is sorted.
    """
    for i in range(1, len(arr)):
        key = arr[i]
        j = i - 1

        # Shift elements greater than key to one position ahead
        while j >= 0 and arr[j] > key:
            arr[j + 1] = arr[j]
            j -= 1

        # Insert key at its correct position
        arr[j + 1] = key


def insertion_sort_with_passes(arr):
    """
    Helper function for educational output:
    Prints each pass, shifts, and updated array state.
    """
    print("Original array:", arr)
    print("-" * 60)

    for i in range(1, len(arr)):
        key = arr[i]
        j = i - 1
        shifts = []

        while j >= 0 and arr[j] > key:
            shifts.append(arr[j])
            arr[j + 1] = arr[j]
            j -= 1

        arr[j + 1] = key

        shift_text = ", ".join(map(str, shifts)) if shifts else "No shift"
        print(f"Pass {i}: key={key}, shifted={shift_text}")
        print(f"Array after pass {i}: {arr}")
        print("-" * 60)


def main():
    arr = [64, 25, 12, 22, 11]

    # Demonstration run (step-by-step)
    demo_arr = arr.copy()
    insertion_sort_with_passes(demo_arr)

    # Final verification using the core function
    arr_to_sort = arr.copy()
    insertion_sort(arr_to_sort)
    print("Final sorted array:", arr_to_sort)


if __name__ == "__main__":
    main()