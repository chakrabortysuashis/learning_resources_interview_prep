# Introduction to Dapr (Distributed Application Runtime)

## What is Dapr?

**Dapr** stands for **Distributed Application Runtime**. It's an open-source project that makes building microservices easier.

Think of Dapr as a **helper layer** that sits between your application and all the complex distributed systems stuff (databases, message queues, other services, etc.).

```
Without Dapr:
Your code needs to know HOW to talk to Redis, Kafka, Azure Service Bus, etc.

With Dapr:
Your code just says "save this state" or "publish this message"
Dapr figures out the HOW part.
```

---

## Why Dapr? The Problem It Solves

Building microservices is hard because you need to:

1. **Call other services** - Handle retries, timeouts, service discovery
2. **Manage state** - Connect to Redis, Cosmos DB, or other databases
3. **Send messages** - Set up Kafka, RabbitMQ, or Azure Service Bus
4. **Handle secrets** - Securely access passwords and API keys
5. **Connect to external systems** - Integrate with various APIs and services

**The Traditional Way:**
```
Your App
   |
   +---> Redis SDK
   +---> Kafka SDK  
   +---> Azure Service Bus SDK
   +---> AWS S3 SDK
   +---> HashiCorp Vault SDK
   ... (many more SDKs and connection code)
```

**The Dapr Way:**
```
Your App
   |
   +---> Dapr (one simple API)
            |
            +---> Redis / Cosmos DB / PostgreSQL
            +---> Kafka / RabbitMQ / Azure Service Bus
            +---> AWS S3 / Azure Blob / GCS
            +---> Azure Key Vault / HashiCorp Vault
```

---

## Analogy: Dapr is Like a Swiss Army Knife for Microservices

Imagine you're camping and need various tools:

**Without a Swiss Army Knife:**
- Carry a separate knife
- Carry a separate screwdriver
- Carry a separate bottle opener
- Carry a separate scissors
- ... your backpack is heavy!

**With a Swiss Army Knife:**
- One tool, many functions
- Same interface (pull out the tool you need)
- Easy to carry and use

**Dapr is your microservices Swiss Army Knife:**
- One API for many distributed systems capabilities
- Same HTTP/gRPC interface for everything
- Easy to use, regardless of the underlying technology

---

## Core Concepts

### 1. Building Blocks

Dapr provides **building blocks** - pre-built capabilities for common microservice patterns:

```
+--------------------------------------------------+
|                 DAPR BUILDING BLOCKS             |
+--------------------------------------------------+
|                                                  |
|  +-------------+  +-------------+  +-----------+ |
|  |   Service   |  |    State    |  |  Pub/Sub  | |
|  |  Invocation |  | Management  |  | Messaging | |
|  +-------------+  +-------------+  +-----------+ |
|                                                  |
|  +-------------+  +-------------+  +-----------+ |
|  |   Bindings  |  |   Secrets   |  |   Actors  | |
|  |  (In/Out)   |  | Management  |  |  (coming) | |
|  +-------------+  +-------------+  +-----------+ |
|                                                  |
|  +-------------+  +-------------+               |
|  | Observabil- |  | Configur-   |               |
|  |    ity      |  |   ation     |               |
|  +-------------+  +-------------+               |
|                                                  |
+--------------------------------------------------+
```

### 2. The Sidecar Pattern

This is **crucial** to understand!

Dapr runs as a **sidecar** - a separate container that runs alongside your application container.

```
+------------------------------------------+
|              KUBERNETES POD              |
|                                          |
|  +----------------+  +----------------+  |
|  |                |  |                |  |
|  |   Your App    |  |  Dapr Sidecar  |  |
|  |   Container   |  |   Container    |  |
|  |               |  |                |  |
|  |  Port: 8080   |  |  Port: 3500   |  |
|  |               |  |   (HTTP)       |  |
|  |               |  |  Port: 50001  |  |
|  |               |  |   (gRPC)       |  |
|  +-------+-------+  +-------+--------+  |
|          |                  |           |
|          +---> localhost <--+           |
|                                          |
+------------------------------------------+
```

**How it works:**
1. Your app and the Dapr sidecar run in the same pod
2. They communicate over localhost (very fast!)
3. Your app talks to Dapr via simple HTTP or gRPC calls
4. Dapr handles all the complex external communication

---

## How Your App Talks to Dapr (and the World)

```
                          INSIDE THE POD
+------------------------------------------------------------------+
|                                                                  |
|   +--------------+         +--------------+                      |
|   |              |  HTTP   |              |                      |
|   |   Your App   |-------->|    Dapr      |                      |
|   |              | :3500   |   Sidecar    |                      |
|   |              |         |              |                      |
|   +--------------+         +------+-------+                      |
|                                   |                              |
+-----------------------------------|------------------------------+
                                    |
                                    | Dapr handles the complex stuff
                                    |
         +------+------+------+-----+-----+------+------+
         |      |      |      |           |      |      |
         v      v      v      v           v      v      v
      +-----+ +-----+ +-----+ +-----+ +------+ +-----+ +-----+
      |Redis| |Kafka| |Azure| |Other| |Azure | | S3  | |Vault|
      |     | |     | | SB  | |Svcs | |Cosmos| |     | |     |
      +-----+ +-----+ +-----+ +-----+ +------+ +-----+ +-----+
```

**Your app just needs to know:**
- Dapr is at `localhost:3500`
- The Dapr API endpoints (like `/v1.0/invoke`, `/v1.0/state`, `/v1.0/publish`)

**Your app does NOT need to know:**
- What database is being used (Redis? Cosmos DB? PostgreSQL?)
- What message broker is running (Kafka? RabbitMQ?)
- Connection strings, authentication, retry logic...

---

## How Dapr Integrates with Kubernetes

In Kubernetes, Dapr uses **annotations** to inject the sidecar automatically:

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: my-app
spec:
  template:
    metadata:
      annotations:
        dapr.io/enabled: "true"          # Enable Dapr for this pod
        dapr.io/app-id: "my-app"         # Unique ID for your app
        dapr.io/app-port: "8080"         # Port your app listens on
    spec:
      containers:
      - name: my-app
        image: my-app:latest
        ports:
        - containerPort: 8080
```

**What happens when you deploy this:**

```
1. You apply the deployment YAML
            |
            v
2. Kubernetes schedules the pod
            |
            v
3. Dapr's "sidecar injector" sees the annotations
            |
            v
4. Dapr automatically adds its sidecar container to your pod
            |
            v
5. Your pod now has TWO containers:
   - Your app
   - Dapr sidecar (added automatically!)
```

---

## Dapr Components

Dapr uses **components** to connect to external services. These are configured via Kubernetes CRDs (Custom Resource Definitions):

```yaml
# Example: Redis state store component
apiVersion: dapr.io/v1alpha1
kind: Component
metadata:
  name: statestore
spec:
  type: state.redis
  version: v1
  metadata:
  - name: redisHost
    value: "redis:6379"
  - name: redisPassword
    secretKeyRef:
      name: redis-secret
      key: password
```

**Your app doesn't know this is Redis!** It just calls:
```
POST http://localhost:3500/v1.0/state/statestore
```

The platform team can swap Redis for Cosmos DB later - your code doesn't change!

---

## Quick Summary

| Concept | What It Is |
|---------|------------|
| **Dapr** | Runtime that simplifies building microservices |
| **Building Blocks** | Pre-built capabilities (state, pub/sub, service calls, etc.) |
| **Sidecar** | Dapr container that runs alongside your app |
| **Components** | Configuration that tells Dapr which services to use |
| **Annotations** | Kubernetes metadata that enables Dapr for your pod |

---

## What's Next?

In the next section, we'll dive deeper into each **building block** and see how to actually use them in your code!

---

## Key Takeaways

1. **Dapr simplifies microservices** by handling distributed systems complexity for you
2. **Sidecar pattern** means Dapr runs alongside your app, not inside it
3. **Building blocks** provide common capabilities through simple APIs
4. **Components** are configured separately - your code stays infrastructure-agnostic
5. **In Kubernetes**, Dapr is injected automatically via annotations
