# Helm Charts - Package Manager for Kubernetes

## What is Helm?

**Helm** is a package manager for Kubernetes. If you've used:
- `apt install nginx` (Debian/Ubuntu)
- `npm install express` (Node.js)
- `pip install flask` (Python)

Then Helm is the equivalent for Kubernetes!

```
+------------------------------------------------------------------+
|                        HELM ANALOGY                              |
+------------------------------------------------------------------+
|                                                                  |
|   apt/yum for Linux    =    Helm for Kubernetes                  |
|                                                                  |
|   +----------------+         +----------------+                  |
|   |    Package     |         |     Chart      |                  |
|   | (nginx.deb)    |         | (nginx chart)  |                  |
|   +----------------+         +----------------+                  |
|          |                          |                            |
|          v                          v                            |
|   +----------------+         +----------------+                  |
|   |  apt install   |         |  helm install  |                  |
|   +----------------+         +----------------+                  |
|          |                          |                            |
|          v                          v                            |
|   +----------------+         +----------------+                  |
|   | Nginx running  |         | Nginx pods,    |                  |
|   | on your server |         | services,      |                  |
|   |                |         | configmaps...  |                  |
|   +----------------+         +----------------+                  |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Why Helm? The Problem It Solves

### Without Helm

To deploy an app, you might need:

```
+------------------------------------------------------------------+
|              DEPLOYING AN APP WITHOUT HELM                       |
+------------------------------------------------------------------+
|                                                                  |
|   deployment.yaml                                                |
|   service.yaml                                                   |
|   configmap.yaml                                                 |
|   secret.yaml                                                    |
|   ingress.yaml                                                   |
|   hpa.yaml (autoscaling)                                         |
|   pdb.yaml (pod disruption budget)                               |
|   serviceaccount.yaml                                            |
|   networkpolicy.yaml                                             |
|   ...maybe more!                                                 |
|                                                                  |
|   Commands:                                                      |
|   kubectl apply -f deployment.yaml                               |
|   kubectl apply -f service.yaml                                  |
|   kubectl apply -f configmap.yaml                                |
|   ... (repeat for each file)                                     |
|                                                                  |
|   Problems:                                                      |
|   - Many files to manage                                         |
|   - Hard to version as a unit                                    |
|   - No easy rollback                                             |
|   - Duplication between environments                             |
|                                                                  |
+------------------------------------------------------------------+
```

### With Helm

```
+------------------------------------------------------------------+
|               DEPLOYING AN APP WITH HELM                         |
+------------------------------------------------------------------+
|                                                                  |
|   Command:                                                       |
|   helm install my-app ./my-chart -f values-prod.yaml             |
|                                                                  |
|   That's it! Helm:                                               |
|   - Deploys ALL resources as a single unit                       |
|   - Tracks version history                                       |
|   - Allows easy rollback                                         |
|   - Supports templating (reuse across environments)              |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Core Concepts

### 1. Chart

A **Chart** is a Helm package. It contains all the Kubernetes manifests needed to run an application.

```
+------------------------------------------------------------------+
|                       HELM CHART                                 |
+------------------------------------------------------------------+
|                                                                  |
|   my-app-chart/                                                  |
|   |                                                              |
|   +-- Chart.yaml          # Metadata (name, version, etc.)       |
|   |                                                              |
|   +-- values.yaml         # Default configuration values         |
|   |                                                              |
|   +-- templates/          # Kubernetes manifest templates        |
|   |   +-- deployment.yaml                                        |
|   |   +-- service.yaml                                           |
|   |   +-- configmap.yaml                                         |
|   |   +-- ingress.yaml                                           |
|   |   +-- _helpers.tpl    # Template helpers                     |
|   |                                                              |
|   +-- charts/             # Dependencies (sub-charts)            |
|                                                                  |
+------------------------------------------------------------------+
```

### 2. Release

A **Release** is an instance of a Chart running in a cluster.

```
+------------------------------------------------------------------+
|                    CHART vs RELEASE                              |
+------------------------------------------------------------------+
|                                                                  |
|   Chart (Template)              Releases (Instances)             |
|                                                                  |
|   +----------------+            +----------------+               |
|   |                |            |  my-app-dev    |               |
|   |   my-app       | ---------> |  (Release 1)   |               |
|   |   Chart        |            +----------------+               |
|   |                |                                             |
|   |  (blueprint)   |            +----------------+               |
|   |                | ---------> |  my-app-prod   |               |
|   |                |            |  (Release 2)   |               |
|   +----------------+            +----------------+               |
|                                                                  |
|   Same chart can be installed multiple times with different      |
|   names and configurations!                                      |
|                                                                  |
+------------------------------------------------------------------+
```

### 3. Repository

A **Repository** is where Charts are stored and shared.

```
+------------------------------------------------------------------+
|                    HELM REPOSITORIES                             |
+------------------------------------------------------------------+
|                                                                  |
|   Public Repos:                                                  |
|   +--------------------------------------------------+          |
|   | Artifact Hub (https://artifacthub.io)            |          |
|   | - nginx-ingress                                  |          |
|   | - prometheus                                     |          |
|   | - grafana                                        |          |
|   | - redis                                          |          |
|   | - ... thousands more!                            |          |
|   +--------------------------------------------------+          |
|                                                                  |
|   Private Repos (your company):                                  |
|   +--------------------------------------------------+          |
|   | Azure Container Registry (ACR)                   |          |
|   | - your-app-chart                                 |          |
|   | - another-service-chart                          |          |
|   +--------------------------------------------------+          |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Why Teams Use Helm

### 1. Templating

Instead of hardcoding values, use templates:

```yaml
# WITHOUT templating (deployment.yaml for dev)
containers:
- name: my-app
  image: myapp:1.0.0
  replicas: 1
  resources:
    memory: "256Mi"

# WITHOUT templating (deployment.yaml for prod)
containers:
- name: my-app
  image: myapp:1.0.0
  replicas: 5         # Different!
  resources:
    memory: "1Gi"     # Different!

# WITH Helm templating (one file for all environments!)
containers:
- name: my-app
  image: {{ .Values.image.repository }}:{{ .Values.image.tag }}
  replicas: {{ .Values.replicaCount }}
  resources:
    memory: {{ .Values.resources.memory }}
```

Then configure per environment:

```yaml
# values-dev.yaml
replicaCount: 1
resources:
  memory: "256Mi"

# values-prod.yaml
replicaCount: 5
resources:
  memory: "1Gi"
```

### 2. Versioning

```
+------------------------------------------------------------------+
|                      CHART VERSIONING                            |
+------------------------------------------------------------------+
|                                                                  |
|   my-app-chart                                                   |
|   |                                                              |
|   +-- version 1.0.0  (initial release)                           |
|   +-- version 1.1.0  (added health checks)                       |
|   +-- version 1.2.0  (added HPA)                                 |
|   +-- version 2.0.0  (breaking: new config format)               |
|                                                                  |
|   You can install specific versions:                             |
|   helm install my-app my-repo/my-app --version 1.2.0             |
|                                                                  |
+------------------------------------------------------------------+
```

### 3. Rollback

```
+------------------------------------------------------------------+
|                    HELM ROLLBACK                                 |
+------------------------------------------------------------------+
|                                                                  |
|   Release History:                                               |
|                                                                  |
|   REVISION    STATUS       DESCRIPTION                           |
|   1           superseded   Initial install                       |
|   2           superseded   Upgraded to 1.1.0                     |
|   3           deployed     Upgraded to 1.2.0  <-- Current        |
|                                                                  |
|   Oh no, 1.2.0 has a bug!                                        |
|                                                                  |
|   $ helm rollback my-app 2                                       |
|                                                                  |
|   REVISION    STATUS       DESCRIPTION                           |
|   1           superseded   Initial install                       |
|   2           superseded   Upgraded to 1.1.0                     |
|   3           superseded   Upgraded to 1.2.0                     |
|   4           deployed     Rollback to 2  <-- Back to safety!    |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Basic Helm Commands

### Installing a Chart

```bash
# Install from a repository
helm install my-release bitnami/nginx

# Install from a local chart
helm install my-release ./my-chart

# Install with custom values
helm install my-release ./my-chart -f values-prod.yaml

# Install with inline value overrides
helm install my-release ./my-chart --set replicaCount=3
```

### Upgrading a Release

```bash
# Upgrade to new chart version or values
helm upgrade my-release ./my-chart -f values-prod.yaml

# Upgrade with --install (install if doesn't exist)
helm upgrade --install my-release ./my-chart
```

### Rolling Back

```bash
# See release history
helm history my-release

# Rollback to previous revision
helm rollback my-release

# Rollback to specific revision
helm rollback my-release 2
```

### Listing and Inspecting

```bash
# List all releases
helm list

# List releases in all namespaces
helm list -A

# Get details about a release
helm get values my-release
helm get manifest my-release

# See what would be deployed (dry run)
helm install my-release ./my-chart --dry-run
```

### Uninstalling

```bash
# Remove a release
helm uninstall my-release
```

---

## Simple Chart Structure Example

Here's a minimal chart for a web application:

```
my-web-app/
|
+-- Chart.yaml
+-- values.yaml
+-- templates/
    +-- deployment.yaml
    +-- service.yaml
```

### Chart.yaml

```yaml
apiVersion: v2
name: my-web-app
description: A simple web application
version: 1.0.0        # Chart version
appVersion: "2.1.0"   # App version
```

### values.yaml

```yaml
# Default values
replicaCount: 1

image:
  repository: myapp
  tag: "latest"
  pullPolicy: IfNotPresent

service:
  type: ClusterIP
  port: 80

resources:
  limits:
    memory: "256Mi"
    cpu: "200m"
```

### templates/deployment.yaml

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ .Release.Name }}-deployment
  labels:
    app: {{ .Chart.Name }}
spec:
  replicas: {{ .Values.replicaCount }}
  selector:
    matchLabels:
      app: {{ .Chart.Name }}
  template:
    metadata:
      labels:
        app: {{ .Chart.Name }}
    spec:
      containers:
      - name: {{ .Chart.Name }}
        image: "{{ .Values.image.repository }}:{{ .Values.image.tag }}"
        imagePullPolicy: {{ .Values.image.pullPolicy }}
        ports:
        - containerPort: 80
        resources:
          limits:
            memory: {{ .Values.resources.limits.memory }}
            cpu: {{ .Values.resources.limits.cpu }}
```

### templates/service.yaml

```yaml
apiVersion: v1
kind: Service
metadata:
  name: {{ .Release.Name }}-service
spec:
  type: {{ .Values.service.type }}
  ports:
  - port: {{ .Values.service.port }}
    targetPort: 80
  selector:
    app: {{ .Chart.Name }}
```

---

## Template Variables Explained

```
+------------------------------------------------------------------+
|                   HELM TEMPLATE VARIABLES                        |
+------------------------------------------------------------------+
|                                                                  |
|   {{ .Values.xxx }}     - Values from values.yaml or overrides   |
|   {{ .Release.Name }}   - Name of the release                    |
|   {{ .Release.Namespace }} - Namespace being deployed to         |
|   {{ .Chart.Name }}     - Chart name from Chart.yaml             |
|   {{ .Chart.Version }}  - Chart version from Chart.yaml          |
|                                                                  |
|   Example:                                                       |
|                                                                  |
|   values.yaml:           Template:         Rendered:             |
|   +--------------+       +-------------+   +------------------+  |
|   | replicaCount:|       | replicas:   |   | replicas: 3      |  |
|   |   3          |  -->  | {{ .Values. |-->|                  |  |
|   |              |       | replicaCount|   |                  |  |
|   +--------------+       | }}          |   +------------------+  |
|                          +-------------+                         |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Helm in Your Project

In most Azure/AKS projects, you'll see:

```
+------------------------------------------------------------------+
|                 TYPICAL PROJECT STRUCTURE                        |
+------------------------------------------------------------------+
|                                                                  |
|   /project-repo                                                  |
|   |                                                              |
|   +-- /src                    # Application source code          |
|   |                                                              |
|   +-- /helm                   # Helm charts                      |
|   |   +-- /my-app-chart                                          |
|   |       +-- Chart.yaml                                         |
|   |       +-- values.yaml                                        |
|   |       +-- /templates                                         |
|   |                                                              |
|   +-- /environments           # Per-environment values           |
|       +-- values-dev.yaml                                        |
|       +-- values-qa.yaml                                         |
|       +-- values-prod.yaml                                       |
|                                                                  |
+------------------------------------------------------------------+
```

**CI/CD Pipeline typically does:**

```
1. Build Docker image
        |
        v
2. Push to ACR (Azure Container Registry)
        |
        v
3. helm upgrade --install my-app ./helm/my-app-chart \
       -f ./environments/values-${ENV}.yaml \
       --set image.tag=${BUILD_NUMBER}
```

---

## Helm Commands Cheat Sheet

```
+------------------------------------------------------------------+
|                    HELM COMMANDS CHEAT SHEET                     |
+------------------------------------------------------------------+
|                                                                  |
|  ACTION                    | COMMAND                             |
|  --------------------------|-------------------------------------|
|  Add a repository          | helm repo add bitnami               |
|                            |   https://charts.bitnami.com/bitnami|
|  Update repositories       | helm repo update                    |
|  Search for charts         | helm search repo nginx              |
|  Install a chart           | helm install NAME CHART             |
|  Install with values file  | helm install NAME CHART -f vals.yaml|
|  Install with set values   | helm install NAME CHART             |
|                            |   --set key=value                   |
|  Upgrade a release         | helm upgrade NAME CHART             |
|  Upgrade or install        | helm upgrade --install NAME CHART   |
|  List releases             | helm list                           |
|  List all namespaces       | helm list -A                        |
|  Get release status        | helm status NAME                    |
|  Get release values        | helm get values NAME                |
|  See release history       | helm history NAME                   |
|  Rollback to revision      | helm rollback NAME REVISION         |
|  Uninstall release         | helm uninstall NAME                 |
|  Dry run (preview)         | helm install NAME CHART --dry-run   |
|  Template locally          | helm template NAME CHART            |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Key Takeaways

1. **Helm = Package manager for K8s** - Like apt/npm but for Kubernetes
2. **Charts = Packages** - Contains all K8s manifests for an app
3. **Releases = Instances** - A chart installed in your cluster
4. **Templating** - One chart, multiple environments via values files
5. **Versioning + Rollback** - Track changes, easily revert if needed
6. **`helm upgrade --install`** - The command you'll use most often
