# Dapr Building Blocks - Deep Dive

In this section, we'll explore the main Dapr building blocks you'll encounter as a backend developer. Each building block solves a common microservices problem.

---

## Overview of Building Blocks

```
+------------------------------------------------------------------+
|                     DAPR BUILDING BLOCKS                         |
+------------------------------------------------------------------+
|                                                                  |
|    +------------------+    +------------------+                  |
|    |     Service      |    |      State       |                  |
|    |    Invocation    |    |   Management     |                  |
|    |                  |    |                  |                  |
|    | "Call Service B" |    | "Save/Get Data"  |                  |
|    +------------------+    +------------------+                  |
|                                                                  |
|    +------------------+    +------------------+                  |
|    |    Pub/Sub       |    |     Bindings     |                  |
|    |    Messaging     |    |    (In/Out)      |                  |
|    |                  |    |                  |                  |
|    | "Publish Events" |    | "External APIs"  |                  |
|    +------------------+    +------------------+                  |
|                                                                  |
|    +------------------+                                          |
|    |     Secrets      |                                          |
|    |   Management     |                                          |
|    |                  |                                          |
|    | "Get API Keys"   |                                          |
|    +------------------+                                          |
|                                                                  |
+------------------------------------------------------------------+
```

---

## 1. Service-to-Service Invocation

### The Problem
How does Service A call Service B in a microservices environment?

**Without Dapr:**
- You need to know Service B's URL/IP
- Handle service discovery
- Implement retries, timeouts, circuit breakers
- Deal with load balancing

**With Dapr:**
- Just call the Dapr sidecar with the target app ID
- Dapr handles everything else!

### How It Works

```
+-------------------+         +-------------------+
|     SERVICE A     |         |     SERVICE B     |
|                   |         |                   |
|  +-------------+  |         |  +-------------+  |
|  |   Your App  |  |         |  |   Your App  |  |
|  |   (app-a)   |  |         |  |   (app-b)   |  |
|  +------+------+  |         |  +------+------+  |
|         |         |         |         ^         |
|    1. HTTP POST   |         |    4. Forward     |
|         |         |         |         |         |
|  +------v------+  |         |  +------+------+  |
|  |    Dapr     |  | 2. Find |  |    Dapr     |  |
|  |   Sidecar   +-------------->   Sidecar   |  |
|  |             |  | 3. Call |  |             |  |
|  +-------------+  |         |  +-------------+  |
+-------------------+         +-------------------+
```

### Code Example

**Calling another service (from Service A):**

```python
# Without Dapr - you need to know the URL
import requests
response = requests.get("http://service-b.default.svc.cluster.local:8080/api/users/123")

# With Dapr - just use the app-id
import requests
# Call through Dapr sidecar
response = requests.get("http://localhost:3500/v1.0/invoke/app-b/method/api/users/123")
```

**Or using Dapr HTTP headers:**

```python
import requests

# Alternative: Use Dapr invoke API
response = requests.post(
    "http://localhost:3500/v1.0/invoke/order-service/method/orders",
    json={"item": "pizza", "quantity": 2}
)
```

### Key Points

```
+--------------------------------------------------+
|          SERVICE INVOCATION BENEFITS             |
+--------------------------------------------------+
|                                                  |
|  [x] Automatic service discovery                 |
|  [x] Built-in retries with backoff              |
|  [x] Mutual TLS (mTLS) encryption               |
|  [x] Distributed tracing                        |
|  [x] Load balancing                             |
|  [x] Access control policies                    |
|                                                  |
+--------------------------------------------------+
```

---

## 2. State Management

### The Problem
Your microservice needs to save and retrieve data. But connecting to databases means:
- Managing connection strings
- Handling connection pools
- Different SDKs for different databases
- If you switch databases, rewrite your code!

### How It Works

```
+------------------------------------------------------------------+
|                     YOUR APPLICATION                             |
+------------------------------------------------------------------+
|                                                                  |
|   "Save order #123"                    "Get order #123"          |
|         |                                    |                   |
|         v                                    v                   |
|   POST /v1.0/state/statestore         GET /v1.0/state/statestore |
|         |                                    |                   |
+---------|------------------------------------|--------------------|
          |                                    |
          v                                    v
+------------------------------------------------------------------+
|                       DAPR SIDECAR                               |
+------------------------------------------------------------------+
|                                                                  |
|   Knows which state store component to use                       |
|   Handles serialization, connection, retries                     |
|                                                                  |
+----------------------------+-------------------------------------+
                             |
                             v
              +-----------------------------+
              |    Configured State Store   |
              +-----------------------------+
              |  Could be:                  |
              |  - Redis                    |
              |  - Azure Cosmos DB          |
              |  - PostgreSQL               |
              |  - MongoDB                  |
              |  - AWS DynamoDB             |
              +-----------------------------+
```

### Code Example

**Saving state:**

```python
import requests
import json

# Save state
state_data = [
    {
        "key": "order-123",
        "value": {
            "orderId": "123",
            "customer": "John",
            "items": ["pizza", "coke"],
            "total": 25.99
        }
    }
]

response = requests.post(
    "http://localhost:3500/v1.0/state/statestore",
    json=state_data
)
```

**Retrieving state:**

```python
# Get state
response = requests.get(
    "http://localhost:3500/v1.0/state/statestore/order-123"
)
order = response.json()
print(order)  # {"orderId": "123", "customer": "John", ...}
```

**Deleting state:**

```python
# Delete state
response = requests.delete(
    "http://localhost:3500/v1.0/state/statestore/order-123"
)
```

### Component Configuration

```yaml
# The platform team sets this up
apiVersion: dapr.io/v1alpha1
kind: Component
metadata:
  name: statestore
spec:
  type: state.redis          # Can change to state.azure.cosmosdb
  version: v1
  metadata:
  - name: redisHost
    value: "redis:6379"
```

---

## 3. Publish/Subscribe (Pub/Sub) Messaging

### The Problem
You need event-driven communication between services:
- Order Service publishes "OrderCreated" event
- Inventory Service, Email Service, Analytics Service all need to react

### How It Works

```
+------------------+
|   Order Service  |
|                  |
|  "OrderCreated"  |
+--------+---------+
         |
         | 1. POST /v1.0/publish/pubsub/orders
         v
+------------------+
|   Dapr Sidecar   |
+--------+---------+
         |
         | 2. Publish to message broker
         v
+--------------------------------------------------+
|              MESSAGE BROKER                      |
|     (Kafka / RabbitMQ / Azure Service Bus)       |
+--------------------------------------------------+
         |
         | 3. Deliver to subscribers
         |
    +----+----+--------------------+
    |         |                    |
    v         v                    v
+-------+ +-------+          +---------+
| Dapr  | | Dapr  |          |  Dapr   |
+---+---+ +---+---+          +----+----+
    |         |                   |
    v         v                   v
+-------+ +-------+          +---------+
|Invent-| |Email  |          |Analytics|
| ory   | |Service|          | Service |
+-------+ +-------+          +---------+
```

### Code Example

**Publishing an event:**

```python
import requests
import json

# Publish an event
event = {
    "orderId": "123",
    "customer": "John",
    "total": 25.99
}

response = requests.post(
    "http://localhost:3500/v1.0/publish/pubsub/orders",  # topic name: orders
    json=event
)
```

**Subscribing to events (your app receives HTTP POST):**

```python
from flask import Flask, request

app = Flask(__name__)

# Dapr will call this endpoint when events arrive
@app.route('/orders', methods=['POST'])
def handle_order_event():
    event = request.json
    print(f"Received order: {event['data']['orderId']}")
    
    # Process the order...
    
    return '', 200  # Return 200 to acknowledge

# Tell Dapr what topics we subscribe to
@app.route('/dapr/subscribe', methods=['GET'])
def subscribe():
    return json.dumps([
        {
            "pubsubname": "pubsub",
            "topic": "orders",
            "route": "/orders"
        }
    ])
```

### Pub/Sub Flow Diagram

```
PUBLISHER                    BROKER                    SUBSCRIBER
    |                          |                           |
    |  1. Publish "OrderCreated"                           |
    |------------------------->|                           |
    |                          |                           |
    |                          |  2. Store message         |
    |                          |  in topic "orders"        |
    |                          |                           |
    |                          |  3. Deliver to all        |
    |                          |  subscribers              |
    |                          |-------------------------->|
    |                          |                           |
    |                          |        4. Process         |
    |                          |        event              |
    |                          |                           |
    |                          |  5. Acknowledge           |
    |                          |<--------------------------|
    |                          |                           |
```

---

## 4. Bindings (Input and Output)

### The Problem
You need to connect to external systems:
- Read from an Azure Storage Queue
- Write to an Azure Blob Storage
- Trigger on a cron schedule
- Send to a Twilio SMS API

### How It Works

**Input Bindings:** External systems trigger your app
**Output Bindings:** Your app sends to external systems

```
+------------------------------------------------------------------+
|                         BINDINGS                                 |
+------------------------------------------------------------------+
|                                                                  |
|   INPUT BINDINGS                    OUTPUT BINDINGS              |
|   (trigger your app)                (send data out)              |
|                                                                  |
|   +-------------+                   +-------------+              |
|   | Azure Queue |                   | Azure Blob  |              |
|   +------+------+                   +------+------+              |
|          |                                 ^                     |
|          v                                 |                     |
|   +------+------+                   +------+------+              |
|   |    Dapr     |                   |    Dapr     |              |
|   +------+------+                   +------+------+              |
|          |                                 ^                     |
|          v                                 |                     |
|   +------+------+                   +------+------+              |
|   |   Your App  | ----------------> |   Your App  |              |
|   | (triggered) |                   |  (sending)  |              |
|   +-------------+                   +-------------+              |
|                                                                  |
+------------------------------------------------------------------+
```

### Code Example

**Output Binding (sending data):**

```python
import requests
import json

# Send to an output binding (e.g., Azure Blob Storage)
data = {
    "operation": "create",
    "data": {
        "content": "Hello from my app!",
        "filename": "greeting.txt"
    }
}

response = requests.post(
    "http://localhost:3500/v1.0/bindings/storage-binding",
    json=data
)
```

**Input Binding (receiving triggers):**

```python
from flask import Flask, request

app = Flask(__name__)

# Dapr calls this when the binding triggers
@app.route('/cron-binding', methods=['POST'])
def handle_cron():
    print("Cron job triggered!")
    # Do scheduled work...
    return '', 200
```

### Common Binding Types

```
+--------------------------------------------------+
|              INPUT BINDINGS (Triggers)           |
+--------------------------------------------------+
| - Azure Storage Queues                           |
| - Kafka                                          |
| - RabbitMQ                                       |
| - Cron (scheduled jobs)                          |
| - Twitter                                        |
+--------------------------------------------------+

+--------------------------------------------------+
|             OUTPUT BINDINGS (Sinks)              |
+--------------------------------------------------+
| - Azure Blob Storage                             |
| - Azure Event Hubs                               |
| - AWS S3                                         |
| - SMTP (email)                                   |
| - Twilio SMS                                     |
| - HTTP endpoints                                 |
+--------------------------------------------------+
```

---

## 5. Secrets Management

### The Problem
Your app needs secrets (passwords, API keys, connection strings), but you shouldn't:
- Hardcode them in your code
- Store them in plain text config files
- Have different code for different secret stores

### How It Works

```
+------------------------------------------------------------------+
|                     YOUR APPLICATION                             |
+------------------------------------------------------------------+
|                                                                  |
|   Need: "database-password"                                      |
|                                                                  |
|   GET /v1.0/secrets/my-secrets/database-password                 |
|         |                                                        |
+---------|---------------------------------------------------------+
          |
          v
+------------------------------------------------------------------+
|                       DAPR SIDECAR                               |
+------------------------------------------------------------------+
|                                                                  |
|   Fetches from configured secret store                           |
|                                                                  |
+---------------------------------+--------------------------------+
                                  |
                                  v
               +----------------------------------+
               |     SECRET STORE                 |
               +----------------------------------+
               |  Could be:                       |
               |  - Kubernetes Secrets            |
               |  - Azure Key Vault               |
               |  - HashiCorp Vault               |
               |  - AWS Secrets Manager           |
               +----------------------------------+
```

### Code Example

**Getting a secret:**

```python
import requests

# Get a specific secret
response = requests.get(
    "http://localhost:3500/v1.0/secrets/my-secrets/database-password"
)

secrets = response.json()
password = secrets["database-password"]
```

**Getting multiple secrets:**

```python
# Get all secrets from a store
response = requests.get(
    "http://localhost:3500/v1.0/secrets/my-secrets/bulk"
)

all_secrets = response.json()
```

### Component Configuration

```yaml
# Kubernetes Secrets store
apiVersion: dapr.io/v1alpha1
kind: Component
metadata:
  name: my-secrets
spec:
  type: secretstores.kubernetes
  version: v1

---
# Or Azure Key Vault
apiVersion: dapr.io/v1alpha1
kind: Component
metadata:
  name: my-secrets
spec:
  type: secretstores.azure.keyvault
  version: v1
  metadata:
  - name: vaultName
    value: "my-keyvault"
```

---

## Building Blocks Summary

```
+------------------------------------------------------------------+
|                    BUILDING BLOCKS CHEAT SHEET                   |
+------------------------------------------------------------------+
|                                                                  |
|  BUILDING BLOCK     | API ENDPOINT           | USE CASE         |
|  -------------------|------------------------|------------------|
|  Service Invocation | /v1.0/invoke/{app}/    | Call other       |
|                     | method/{method}        | services         |
|  -------------------|------------------------|------------------|
|  State Management   | /v1.0/state/{store}    | Save/get data    |
|  -------------------|------------------------|------------------|
|  Pub/Sub            | /v1.0/publish/{pubsub} | Event messaging  |
|                     | /{topic}               |                  |
|  -------------------|------------------------|------------------|
|  Bindings           | /v1.0/bindings/        | External system  |
|                     | {binding}              | integration      |
|  -------------------|------------------------|------------------|
|  Secrets            | /v1.0/secrets/{store}  | Get secrets      |
|                     | /{key}                 |                  |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Putting It Together - A Real Example

Here's how a typical request might use multiple building blocks:

```
1. User places order
        |
        v
+------------------+
|  Order Service   |
+------------------+
        |
        | 2. Get payment API key
        |    GET /v1.0/secrets/vault/payment-api-key
        |
        | 3. Save order to state
        |    POST /v1.0/state/statestore
        |
        | 4. Call inventory service
        |    POST /v1.0/invoke/inventory/method/reserve
        |
        | 5. Publish "OrderCreated" event
        |    POST /v1.0/publish/pubsub/orders
        |
        | 6. Send to payment binding
        |    POST /v1.0/bindings/payment-gateway
        |
        v
    Order Complete!
```

---

## Key Takeaways

1. **Building blocks are APIs** - Simple HTTP calls to localhost:3500
2. **Infrastructure agnostic** - Your code doesn't know what's behind Dapr
3. **Consistent patterns** - Same API structure across all building blocks
4. **Configured separately** - Platform team manages components, you write business logic
5. **Production-ready features** - Retries, tracing, encryption built-in
