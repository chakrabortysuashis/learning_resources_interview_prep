# Azure Kubernetes Service (AKS)

## What is AKS?

**AKS** stands for **Azure Kubernetes Service**. It's Azure's managed Kubernetes offering.

Think of it this way:

```
+------------------------------------------------------------------+
|                                                                  |
|   Regular Kubernetes:        AKS (Managed Kubernetes):           |
|   You manage EVERYTHING      Azure manages the hard parts        |
|                                                                  |
|   +------------------+       +------------------+                 |
|   | Control Plane    | YOU   | Control Plane    | AZURE          |
|   +------------------+       +------------------+                 |
|   | Worker Nodes     | YOU   | Worker Nodes     | YOU (mostly)   |
|   +------------------+       +------------------+                 |
|   | Networking       | YOU   | Networking       | AZURE helps    |
|   +------------------+       +------------------+                 |
|   | Upgrades         | YOU   | Upgrades         | AZURE helps    |
|   +------------------+       +------------------+                 |
|   | Security patches | YOU   | Security patches | AZURE          |
|   +------------------+       +------------------+                 |
|                                                                  |
+------------------------------------------------------------------+
```

---

## What Azure Manages For You

### 1. The Control Plane (FREE!)

```
+------------------------------------------------------------------+
|                     AKS CONTROL PLANE                            |
|                  (Managed by Azure - FREE)                       |
+------------------------------------------------------------------+
|                                                                  |
|   +----------------+  +----------------+  +------------------+   |
|   |   API Server   |  |    etcd        |  | Controller       |   |
|   |                |  | (data store)   |  | Manager          |   |
|   +----------------+  +----------------+  +------------------+   |
|                                                                  |
|   +----------------+  +----------------+                         |
|   |   Scheduler    |  | Cloud          |                         |
|   |                |  | Controller     |                         |
|   +----------------+  +----------------+                         |
|                                                                  |
|   You don't see these. You don't manage these.                   |
|   Azure handles: high availability, upgrades, patches            |
|                                                                  |
+------------------------------------------------------------------+
```

**What this means for you:**
- No control plane VMs to maintain
- No etcd backups to worry about
- Azure ensures 99.95% SLA (with Availability Zones)
- You just pay for worker nodes!

### 2. Node Management (Partially)

```
+------------------------------------------------------------------+
|                      WORKER NODES                                |
+------------------------------------------------------------------+
|                                                                  |
|   What Azure does:                                               |
|   - Provisions VMs automatically                                 |
|   - Installs Kubernetes components                               |
|   - Security patches (with node image upgrades)                  |
|   - Integration with Azure VM Scale Sets                         |
|                                                                  |
|   What you configure:                                            |
|   - Node size (VM SKU)                                           |
|   - Number of nodes (or autoscaling rules)                       |
|   - Node pools (different VM types for different workloads)      |
|                                                                  |
+------------------------------------------------------------------+
```

### 3. Kubernetes Upgrades

```
+------------------------------------------------------------------+
|                    UPGRADE PROCESS                               |
+------------------------------------------------------------------+
|                                                                  |
|   Traditional K8s:           AKS:                                |
|                                                                  |
|   1. Download binaries       1. az aks upgrade --kubernetes-     |
|   2. Drain nodes                version 1.28.0                   |
|   3. Update kubelets                                             |
|   4. Update API server       That's it. Azure handles:           |
|   5. Update etcd             - Cordon/drain nodes                |
|   6. Test everything         - Update one node at a time         |
|   7. Pray nothing breaks     - Validate health between nodes     |
|                                                                  |
+------------------------------------------------------------------+
```

---

## AKS-Specific Features

### 1. Azure AD Integration

```
+------------------------------------------------------------------+
|              AZURE AD + AKS INTEGRATION                          |
+------------------------------------------------------------------+
|                                                                  |
|   Developer                                                      |
|      |                                                           |
|      | 1. az login (Azure AD auth)                               |
|      v                                                           |
|   +------------------+                                           |
|   |    Azure AD      |                                           |
|   +--------+---------+                                           |
|            |                                                     |
|            | 2. Token issued                                     |
|            v                                                     |
|   +------------------+                                           |
|   |  AKS API Server  |                                           |
|   +--------+---------+                                           |
|            |                                                     |
|            | 3. RBAC check: Can this user access this namespace? |
|            v                                                     |
|   +------------------+                                           |
|   |   Your Cluster   |                                           |
|   +------------------+                                           |
|                                                                  |
|   Benefits:                                                      |
|   - Use your company's Azure AD for K8s access                   |
|   - No separate K8s user management                              |
|   - Integrates with Conditional Access policies                  |
|   - Audit logs in Azure                                          |
|                                                                  |
+------------------------------------------------------------------+
```

### 2. Azure CNI Networking

```
+------------------------------------------------------------------+
|                    NETWORKING OPTIONS                            |
+------------------------------------------------------------------+
|                                                                  |
|   KUBENET (Basic):             AZURE CNI (Advanced):             |
|                                                                  |
|   - Pods get internal IPs      - Pods get VNet IPs               |
|   - NAT for external traffic   - Direct VNet connectivity        |
|   - Simpler, fewer IPs needed  - Better for enterprise           |
|                                                                  |
+------------------------------------------------------------------+

Azure CNI Visual:

+------------------------------------------------------------------+
|                     AZURE VIRTUAL NETWORK                        |
|                        10.0.0.0/8                                 |
+------------------------------------------------------------------+
|                                                                  |
|   +------------------+     +------------------+                  |
|   |    AKS Subnet    |     |   Other Subnet   |                  |
|   |   10.0.1.0/24    |     |   10.0.2.0/24    |                  |
|   +------------------+     +------------------+                  |
|   |                  |     |                  |                  |
|   |  Node: 10.0.1.4  |     |  VM: 10.0.2.10   |                  |
|   |  Pod:  10.0.1.5  |     |                  |                  |
|   |  Pod:  10.0.1.6  |     |  Can directly    |                  |
|   |  Pod:  10.0.1.7  |<--->|  talk to pods!   |                  |
|   |                  |     |                  |                  |
|   +------------------+     +------------------+                  |
|                                                                  |
+------------------------------------------------------------------+
```

### 3. Azure Monitor Integration

```
+------------------------------------------------------------------+
|                    MONITORING STACK                              |
+------------------------------------------------------------------+
|                                                                  |
|   +------------------+                                           |
|   |   Your AKS      |                                            |
|   |   Cluster       |                                            |
|   +--------+--------+                                            |
|            |                                                     |
|            | Metrics & Logs                                      |
|            v                                                     |
|   +------------------+     +------------------+                  |
|   | Azure Monitor    |     | Log Analytics    |                  |
|   | for Containers   |     | Workspace        |                  |
|   +--------+--------+     +--------+---------+                  |
|            |                       |                             |
|            v                       v                             |
|   +--------------------------------------------------+          |
|   |              Azure Portal Dashboards              |          |
|   +--------------------------------------------------+          |
|   |  - Live container logs                           |          |
|   |  - Node & pod metrics                            |          |
|   |  - Recommended alerts                            |          |
|   |  - Workbook visualizations                       |          |
|   +--------------------------------------------------+          |
|                                                                  |
+------------------------------------------------------------------+
```

---

## How Your Project Likely Uses AKS

If you're working on an Azure-based project, here's what's probably set up:

```
+------------------------------------------------------------------+
|                YOUR PROJECT'S AKS SETUP                          |
+------------------------------------------------------------------+
|                                                                  |
|   ENVIRONMENTS:                                                  |
|   +----------+  +----------+  +----------+  +----------+         |
|   |   Dev    |  |   QA     |  | Staging  |  |   Prod   |         |
|   | Cluster  |  | Cluster  |  | Cluster  |  | Cluster  |         |
|   +----------+  +----------+  +----------+  +----------+         |
|                                                                  |
|   COMMON SETUP:                                                  |
|   - Azure AD authentication enabled                              |
|   - Azure CNI networking                                         |
|   - Azure Container Registry (ACR) for images                    |
|   - Azure Key Vault for secrets                                  |
|   - Azure Monitor for logging                                    |
|   - Dapr sidecar injection enabled                               |
|   - NGINX Ingress Controller                                     |
|   - cert-manager for TLS certificates                            |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Working with AKS: Essential Commands

### Azure CLI Commands

```bash
# Login to Azure
az login

# Set your subscription
az account set --subscription "My Subscription"

# Get AKS credentials (configures kubectl)
az aks get-credentials --resource-group my-rg --name my-aks-cluster

# After this, kubectl commands work against your AKS cluster!
```

### Checking Your Context

```bash
# See all configured clusters
kubectl config get-contexts

# Example output:
# CURRENT   NAME                 CLUSTER              AUTHINFO
# *         my-aks-dev           my-aks-dev           clusterUser_rg_dev
#           my-aks-prod          my-aks-prod          clusterUser_rg_prod

# Switch between clusters
kubectl config use-context my-aks-prod

# Verify you're connected
kubectl get nodes
```

### Common AKS Operations

```bash
# View cluster info
az aks show --resource-group my-rg --name my-aks-cluster

# Scale node pool
az aks scale --resource-group my-rg --name my-aks-cluster --node-count 5

# Upgrade cluster
az aks upgrade --resource-group my-rg --name my-aks-cluster --kubernetes-version 1.28.0

# View available upgrades
az aks get-upgrades --resource-group my-rg --name my-aks-cluster
```

---

## AKS Architecture Diagram

```
+------------------------------------------------------------------+
|                        AZURE CLOUD                               |
+------------------------------------------------------------------+
|                                                                  |
|   +----------------------------------------------------------+  |
|   |                    AZURE SUBSCRIPTION                     |  |
|   +----------------------------------------------------------+  |
|   |                                                          |  |
|   |   +--------------------------------------------------+   |  |
|   |   |              RESOURCE GROUP                       |   |  |
|   |   +--------------------------------------------------+   |  |
|   |   |                                                  |   |  |
|   |   |   +------------------+  +------------------+     |   |  |
|   |   |   |   AKS Cluster    |  |   Azure          |     |   |  |
|   |   |   |                  |  |   Container      |     |   |  |
|   |   |   |  +------------+  |  |   Registry       |     |   |  |
|   |   |   |  |Control     |  |  |   (ACR)          |     |   |  |
|   |   |   |  |Plane      |  |  +------------------+     |   |  |
|   |   |   |  |(Managed)   |  |                          |   |  |
|   |   |   |  +------------+  |  +------------------+     |   |  |
|   |   |   |                  |  |   Azure          |     |   |  |
|   |   |   |  +------------+  |  |   Key Vault      |     |   |  |
|   |   |   |  |Node Pool 1 |  |  |   (Secrets)      |     |   |  |
|   |   |   |  |(System)    |  |  +------------------+     |   |  |
|   |   |   |  +------------+  |                          |   |  |
|   |   |   |                  |  +------------------+     |   |  |
|   |   |   |  +------------+  |  |   Azure          |     |   |  |
|   |   |   |  |Node Pool 2 |  |  |   Monitor        |     |   |  |
|   |   |   |  |(User Apps) |  |  |   (Logging)      |     |   |  |
|   |   |   |  +------------+  |  +------------------+     |   |  |
|   |   |   |                  |                          |   |  |
|   |   |   +------------------+                          |   |  |
|   |   |                                                  |   |  |
|   |   +--------------------------------------------------+   |  |
|   |                                                          |  |
|   +----------------------------------------------------------+  |
|                                                                  |
+------------------------------------------------------------------+
```

---

## AKS vs Other Managed Kubernetes

```
+------------------------------------------------------------------+
|                 MANAGED KUBERNETES COMPARISON                    |
+------------------------------------------------------------------+
|                                                                  |
|   Feature          | AKS (Azure) | EKS (AWS)  | GKE (Google)     |
|   -----------------|-------------|------------|------------------|
|   Control Plane    | FREE        | $0.10/hr   | FREE (Autopilot) |
|   Cost             |             | (~$72/mo)  | or $0.10/hr      |
|   -----------------|-------------|------------|------------------|
|   Identity         | Azure AD    | IAM        | Google IAM       |
|   Integration      | native      | + OIDC     | native           |
|   -----------------|-------------|------------|------------------|
|   Networking       | Azure CNI,  | VPC CNI    | VPC-native       |
|                    | Kubenet     |            |                  |
|   -----------------|-------------|------------|------------------|
|   Unique           | AAD Pod     | Fargate    | Autopilot,       |
|   Features         | Identity,   | (serverless| GKE Sandbox      |
|                    | Virtual     | pods)      |                  |
|                    | Nodes       |            |                  |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Key Takeaways

1. **AKS = Managed Kubernetes** - Azure handles the control plane, you manage workloads
2. **Control plane is FREE** - You only pay for worker node VMs
3. **Azure AD integration** - Use your company login for cluster access
4. **Azure CNI** - Pods can have VNet IPs for better enterprise connectivity
5. **`az aks get-credentials`** - The command you'll use to connect to clusters
6. **Multiple environments** - Dev, QA, Staging, Prod are usually separate clusters

---

## Common Commands Cheat Sheet

```
+------------------------------------------------------------------+
|                    AKS COMMANDS CHEAT SHEET                      |
+------------------------------------------------------------------+
|                                                                  |
|  ACTION                        | COMMAND                         |
|  ------------------------------|--------------------------------|
|  Login to Azure                | az login                        |
|  Get cluster credentials       | az aks get-credentials -g RG    |
|                                |    -n CLUSTER                   |
|  List clusters                 | az aks list -o table            |
|  Show cluster details          | az aks show -g RG -n CLUSTER    |
|  Scale nodes                   | az aks scale -g RG -n CLUSTER   |
|                                |    --node-count 5               |
|  Upgrade cluster               | az aks upgrade -g RG -n CLUSTER |
|                                |    --kubernetes-version X.XX    |
|  See current context           | kubectl config current-context  |
|  Switch context                | kubectl config use-context NAME |
|                                                                  |
+------------------------------------------------------------------+
```
