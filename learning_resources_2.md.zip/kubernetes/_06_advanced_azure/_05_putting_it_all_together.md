# Putting It All Together

Now that you understand the individual pieces, let's see how they work together in a real Azure/AKS project.

---

## The Complete Picture

```
+------------------------------------------------------------------+
|                    THE FULL STACK                                |
+------------------------------------------------------------------+
|                                                                  |
|   +----------------------------------------------------------+   |
|   |                       HELM                               |   |
|   |   "Packages and deploys all the Kubernetes resources"    |   |
|   +---------------------------+------------------------------+   |
|                               |                                  |
|                               v                                  |
|   +----------------------------------------------------------+   |
|   |                        AKS                                |   |
|   |   "Runs your Kubernetes cluster on Azure"                |   |
|   +---------------------------+------------------------------+   |
|                               |                                  |
|                               v                                  |
|   +----------------------------------------------------------+   |
|   |                   KUBERNETES                              |   |
|   |   "Orchestrates your containers"                         |   |
|   +---------------------------+------------------------------+   |
|                               |                                  |
|                               v                                  |
|   +----------------------------------------------------------+   |
|   |                       DAPR                                |   |
|   |   "Simplifies microservice communication"                |   |
|   +----------------------------------------------------------+   |
|                                                                  |
+------------------------------------------------------------------+
```

---

## A Typical Request Flow

Let's trace a real request through all the layers:

```
+------------------------------------------------------------------+
|              COMPLETE REQUEST FLOW DIAGRAM                       |
+------------------------------------------------------------------+

User (Browser/Mobile)
         |
         | 1. HTTPS request
         v
+------------------+
|   Azure Load     |    Azure manages this automatically
|   Balancer       |    with AKS
+--------+---------+
         |
         | 2. Routes to cluster
         v
+------------------+
|   Ingress        |    NGINX Ingress Controller
|   Controller     |    (deployed via Helm)
+--------+---------+
         |
         | 3. Routes to service based on path/host
         v
+------------------+
|   Kubernetes     |    ClusterIP Service
|   Service        |
+--------+---------+
         |
         | 4. Load balances to pods
         v
+------------------------------------------------------------------+
|                         POD                                      |
+------------------------------------------------------------------+
|                                                                  |
|   +------------------+         +------------------+              |
|   |   Your App       |  HTTP   |   Dapr Sidecar   |              |
|   |   Container      +-------->|   Container      |              |
|   |                  | :3500   |                  |              |
|   +------------------+         +--------+---------+              |
|                                         |                        |
+------------------------------------------------------------------+
                                          |
         +--------------------------------+--------------------------------+
         |                                |                                |
         v                                v                                v
+------------------+           +------------------+            +------------------+
|   Other Service  |           |   State Store    |            |   Message Queue  |
|   (via Dapr)     |           |   (Redis/Cosmos) |            |   (Service Bus)  |
+------------------+           +------------------+            +------------------+
```

---

## Step-by-Step: What Happens When You Deploy

```
+------------------------------------------------------------------+
|                    DEPLOYMENT FLOW                               |
+------------------------------------------------------------------+

Step 1: Developer pushes code
         |
         v
+------------------+
|   Git Repository |
|   (Azure DevOps/ |
|    GitHub)       |
+--------+---------+
         |
         | Triggers CI/CD pipeline
         v
Step 2: Build and Push
+------------------+
|   CI Pipeline    |
|                  |
|   - Build image  |
|   - Run tests    |
|   - Push to ACR  |
+--------+---------+
         |
         v
+------------------+
|   Azure          |
|   Container      |
|   Registry (ACR) |
+--------+---------+
         |
         v
Step 3: Deploy with Helm
+------------------+
|   CD Pipeline    |
|                  |
|   helm upgrade   |
|   --install      |
|   my-app         |
|   ./charts/app   |
|   -f values.yaml |
+--------+---------+
         |
         v
Step 4: Kubernetes creates resources
+------------------------------------------------------------------+
|   AKS CLUSTER                                                    |
+------------------------------------------------------------------+
|                                                                  |
|   Created by Helm:                                               |
|   +-------------+  +-------------+  +-------------+              |
|   | Deployment  |  | Service     |  | ConfigMap   |              |
|   +-------------+  +-------------+  +-------------+              |
|   +-------------+  +-------------+  +-------------+              |
|   | Ingress     |  | HPA         |  | Secrets     |              |
|   +-------------+  +-------------+  +-------------+              |
|                                                                  |
|   Kubernetes then:                                               |
|   - Pulls image from ACR                                         |
|   - Creates pods                                                 |
|   - Dapr injects sidecars (automatically!)                       |
|   - Configures networking                                        |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Who Handles What?

Understanding responsibilities helps you know where to look when things go wrong:

```
+------------------------------------------------------------------+
|                  RESPONSIBILITY MATRIX                           |
+------------------------------------------------------------------+
|                                                                  |
|   PLATFORM/INFRA TEAM                 YOU (BACKEND DEVELOPER)    |
|   ----------------------------        --------------------------  |
|                                                                  |
|   +------------------------+          +------------------------+ |
|   | AKS Cluster Setup      |          | Application Code       | |
|   | - Node pools           |          | - Business logic       | |
|   | - Networking           |          | - API endpoints        | |
|   | - Azure AD integration |          | - Error handling       | |
|   +------------------------+          +------------------------+ |
|                                                                  |
|   +------------------------+          +------------------------+ |
|   | Dapr Installation      |          | Dapr Usage             | |
|   | - Dapr runtime         |          | - Call Dapr APIs       | |
|   | - Component configs    |          | - Add annotations      | |
|   | - Secrets stores       |          | - Handle events        | |
|   +------------------------+          +------------------------+ |
|                                                                  |
|   +------------------------+          +------------------------+ |
|   | Helm Chart Templates   |          | values.yaml            | |
|   | - Base structure       |          | - App config           | |
|   | - Security policies    |          | - Replicas             | |
|   | - Resource defaults    |          | - Environment vars     | |
|   +------------------------+          +------------------------+ |
|                                                                  |
|   +------------------------+          +------------------------+ |
|   | CI/CD Pipeline         |          | Dockerfile             | |
|   | - Build steps          |          | - App dependencies     | |
|   | - Deploy stages        |          | - Build instructions   | |
|   | - Approvals            |          |                        | |
|   +------------------------+          +------------------------+ |
|                                                                  |
|   +------------------------+          +------------------------+ |
|   | Monitoring Setup       |          | Logging/Metrics        | |
|   | - Azure Monitor        |          | - Log meaningful data  | |
|   | - Dashboards           |          | - Add trace IDs        | |
|   | - Alerts               |          | - Custom metrics       | |
|   +------------------------+          +------------------------+ |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Real Example: Order Service

Here's how all the pieces fit for a typical microservice:

```
+------------------------------------------------------------------+
|                  ORDER SERVICE EXAMPLE                           |
+------------------------------------------------------------------+

Your Code (Python/Node/C#):
+------------------------------------------------------------------+
|                                                                  |
|   @app.route('/orders', methods=['POST'])                        |
|   def create_order(order_data):                                  |
|       # 1. Get payment API key from secrets (via Dapr)           |
|       secrets = dapr.get_secret('vault', 'payment-api-key')      |
|                                                                  |
|       # 2. Save order to state store (via Dapr)                  |
|       dapr.save_state('statestore', order_id, order_data)        |
|                                                                  |
|       # 3. Call inventory service (via Dapr)                     |
|       dapr.invoke('inventory-service', 'reserve', items)         |
|                                                                  |
|       # 4. Publish OrderCreated event (via Dapr)                 |
|       dapr.publish('pubsub', 'orders', event)                    |
|                                                                  |
|       return {"status": "created", "orderId": order_id}          |
|                                                                  |
+------------------------------------------------------------------+

Your Kubernetes Manifest (via Helm):
+------------------------------------------------------------------+
|                                                                  |
|   # templates/deployment.yaml                                    |
|   metadata:                                                      |
|     annotations:                                                 |
|       dapr.io/enabled: "true"                                    |
|       dapr.io/app-id: "order-service"                            |
|       dapr.io/app-port: "8080"                                   |
|                                                                  |
+------------------------------------------------------------------+

Your values.yaml:
+------------------------------------------------------------------+
|                                                                  |
|   replicaCount: 3                                                |
|   image:                                                         |
|     repository: myacr.azurecr.io/order-service                   |
|     tag: "1.2.3"                                                 |
|   resources:                                                     |
|     limits:                                                      |
|       memory: "512Mi"                                            |
|                                                                  |
+------------------------------------------------------------------+

What gets created in AKS:
+------------------------------------------------------------------+
|                                                                  |
|   +-------------------+                                          |
|   |      Pod 1        |                                          |
|   | +---------------+ |                                          |
|   | |order-service  | |                                          |
|   | |container      | |                                          |
|   | +---------------+ |                                          |
|   | +---------------+ |                                          |
|   | |dapr-sidecar   | |  <-- Injected automatically!             |
|   | +---------------+ |                                          |
|   +-------------------+                                          |
|                                                                  |
|   +-------------------+  +-------------------+                   |
|   |      Pod 2        |  |      Pod 3        |                   |
|   |    (same setup)   |  |    (same setup)   |                   |
|   +-------------------+  +-------------------+                   |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Debugging Flow: Where to Look

When something goes wrong:

```
+------------------------------------------------------------------+
|                    DEBUGGING GUIDE                               |
+------------------------------------------------------------------+
|                                                                  |
|   SYMPTOM                          WHERE TO LOOK                 |
|   -------------------------------- ------------------------------ |
|                                                                  |
|   "Can't reach the app externally" |                             |
|                                    v                             |
|   +----------------------------------------------------------+  |
|   | 1. Check Ingress: kubectl get ingress                    |  |
|   | 2. Check Service: kubectl get svc                        |  |
|   | 3. Check Azure LB: Azure Portal > Load Balancers         |  |
|   +----------------------------------------------------------+  |
|                                                                  |
|   "Pods not starting"              |                             |
|                                    v                             |
|   +----------------------------------------------------------+  |
|   | 1. kubectl get pods (check status)                       |  |
|   | 2. kubectl describe pod <name> (see events)              |  |
|   | 3. kubectl logs <pod> (application logs)                 |  |
|   | 4. Check ACR access (image pull errors?)                 |  |
|   +----------------------------------------------------------+  |
|                                                                  |
|   "Dapr not working"               |                             |
|                                    v                             |
|   +----------------------------------------------------------+  |
|   | 1. Check annotations are correct                         |  |
|   | 2. kubectl logs <pod> -c daprd (Dapr sidecar logs)       |  |
|   | 3. Check Dapr components: kubectl get components.dapr.io |  |
|   +----------------------------------------------------------+  |
|                                                                  |
|   "App deployed but old version"   |                             |
|                                    v                             |
|   +----------------------------------------------------------+  |
|   | 1. helm list (check release version)                     |  |
|   | 2. kubectl get deploy -o yaml | grep image (check tag)   |  |
|   | 3. Check CI/CD pipeline logs                             |  |
|   +----------------------------------------------------------+  |
|                                                                  |
|   "Config not applied"             |                             |
|                                    v                             |
|   +----------------------------------------------------------+  |
|   | 1. helm get values <release> (see deployed values)       |  |
|   | 2. kubectl get configmap (check configmap content)       |  |
|   | 3. Compare with values.yaml in repo                      |  |
|   +----------------------------------------------------------+  |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Tips for Junior Developers

### 1. Start Small

```
+------------------------------------------------------------------+
|   Don't try to understand everything at once!                    |
|                                                                  |
|   Week 1: Focus on your app code                                 |
|           - Understand the business logic                        |
|           - Learn how to read logs                               |
|                                                                  |
|   Week 2: Learn basic kubectl                                    |
|           - kubectl get pods                                     |
|           - kubectl logs <pod>                                   |
|           - kubectl describe pod <pod>                           |
|                                                                  |
|   Week 3: Understand your app's Helm values                      |
|           - What can you configure?                              |
|           - How to change replicas, resources?                   |
|                                                                  |
|   Week 4: Explore Dapr                                           |
|           - How does your app use Dapr?                          |
|           - What building blocks are used?                       |
+------------------------------------------------------------------+
```

### 2. Essential Commands to Memorize

```bash
# See what's running
kubectl get pods
kubectl get pods -w        # Watch for changes

# Check pod status
kubectl describe pod <pod-name>

# Read logs
kubectl logs <pod-name>
kubectl logs <pod-name> -f  # Follow logs
kubectl logs <pod-name> -c daprd  # Dapr sidecar logs

# Get into a pod
kubectl exec -it <pod-name> -- /bin/sh

# Check your Helm releases
helm list
helm status <release-name>
helm history <release-name>

# Check your cluster context
kubectl config current-context
```

### 3. When in Doubt, Ask

```
+------------------------------------------------------------------+
|   Questions to ask your platform/senior team:                    |
|                                                                  |
|   - "What namespace should I deploy to?"                         |
|   - "How do I access the dev/staging cluster?"                   |
|   - "What's the process for deploying to production?"            |
|   - "Where can I see logs and monitoring?"                       |
|   - "Who do I contact for infrastructure issues?"                |
|   - "What Dapr components are available?"                        |
|   - "How do secrets work in our project?"                        |
+------------------------------------------------------------------+
```

### 4. Common Gotchas

```
+------------------------------------------------------------------+
|                    COMMON GOTCHAS                                |
+------------------------------------------------------------------+
|                                                                  |
|   1. Wrong context                                               |
|      - Always check: kubectl config current-context              |
|      - Don't accidentally deploy to prod!                        |
|                                                                  |
|   2. Image not updated                                           |
|      - Using "latest" tag? K8s might not pull new version        |
|      - Use specific tags (v1.2.3) in production                  |
|                                                                  |
|   3. Dapr not starting                                           |
|      - Missing annotations? Check dapr.io/enabled: "true"        |
|      - Wrong port? Check dapr.io/app-port matches your app       |
|                                                                  |
|   4. ConfigMap not applied                                       |
|      - Pods don't auto-reload on ConfigMap change                |
|      - Need to restart pods or use reloader                      |
|                                                                  |
|   5. Resource limits too low                                     |
|      - OOMKilled? Increase memory limits                         |
|      - CPU throttling? Check resource.requests.cpu               |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Quick Reference Card

```
+------------------------------------------------------------------+
|                   QUICK REFERENCE CARD                           |
+------------------------------------------------------------------+
|                                                                  |
|  TECHNOLOGY    | WHAT IT DOES              | KEY COMMAND        |
|  --------------|---------------------------|--------------------| 
|  AKS           | Managed K8s cluster       | az aks             |
|                |                           | get-credentials    |
|  --------------|---------------------------|--------------------| 
|  kubectl       | Interact with K8s         | kubectl get pods   |
|  --------------|---------------------------|--------------------| 
|  Helm          | Deploy apps to K8s        | helm upgrade       |
|                |                           | --install          |
|  --------------|---------------------------|--------------------| 
|  Dapr          | Microservice runtime      | Call localhost:3500|
|                |                           |                    |
|  --------------|---------------------------|--------------------| 
|  ACR           | Docker image registry     | docker push        |
|                |                           | myacr.azurecr.io/  |
|  --------------|---------------------------|--------------------| 
|  Azure Monitor | Logs and metrics          | Azure Portal       |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Summary: The Journey of a Request

```
+------------------------------------------------------------------+
|            COMPLETE FLOW - ONE PAGE SUMMARY                      |
+------------------------------------------------------------------+

   USER
    |
    | 1. HTTPS Request (api.myapp.com/orders)
    v
+----------+
| Azure LB |  <-- Managed by AKS, you don't configure
+----+-----+
     |
     | 2. Routes to Kubernetes cluster
     v
+----------+
| Ingress  |  <-- Deployed via Helm, routes by path/host
+----+-----+
     |
     | 3. Matches path, routes to Service
     v
+----------+
| Service  |  <-- ClusterIP, load balances to healthy pods
+----+-----+
     |
     | 4. Routes to one of the pods
     v
+------------------------------------------------------------------+
|                            POD                                   |
|  +-------------------+      +-------------------+                |
|  |                   |      |                   |                |
|  |   Your App        | ---> |   Dapr Sidecar    |                |
|  |   (order-service) | 3500 |   (handles the    |                |
|  |                   |      |    hard parts)    |                |
|  +-------------------+      +--------+----------+                |
+------------------------------------------------------------------+
                                       |
     +---------------------------------+---------------------------------+
     |                                 |                                 |
     v                                 v                                 v
+----------+                    +----------+                      +----------+
| Secrets  |                    | State    |                      | Other    |
| (KeyVault)|                   | (Redis)  |                      | Services |
+----------+                    +----------+                      +----------+

All of this deployed and managed via HELM!
All running on AKS (managed by Azure)!
```

---

## Final Thoughts

```
+------------------------------------------------------------------+
|                     KEY TAKEAWAYS                                |
+------------------------------------------------------------------+
|                                                                  |
|  1. AKS handles the infrastructure so you can focus on code      |
|                                                                  |
|  2. Dapr handles the distributed systems complexity              |
|                                                                  |
|  3. Helm handles the deployment packaging and versioning         |
|                                                                  |
|  4. Kubernetes orchestrates everything together                  |
|                                                                  |
|  5. You write business logic, the platform handles the rest!     |
|                                                                  |
+------------------------------------------------------------------+

You don't need to be an expert in all these technologies to be
productive. Focus on understanding:

- How your code runs (containers, pods)
- How to debug issues (logs, events)
- How to configure your app (values.yaml)
- Who to ask when you're stuck (your team!)

The rest will come with experience.

Good luck with your Kubernetes journey!
```
