# Deployments - Managing Application Updates

## What is a Deployment?

A **Deployment** is a higher-level resource that manages ReplicaSets and provides declarative updates for Pods. It's like a **smart wrapper** around ReplicaSets that adds:

- Rolling updates (update Pods gradually without downtime)
- Rollback capability (undo bad updates)
- Update history (track what changed)

### The Hierarchy

```
+--------------------------------------------------+
|                   DEPLOYMENT                      |
|         "I manage the update strategy"            |
+--------------------------------------------------+
                        |
                        | creates & manages
                        v
+--------------------------------------------------+
|                   REPLICASET                      |
|         "I maintain the replica count"            |
+--------------------------------------------------+
                        |
                        | creates & manages
                        v
+--------+    +--------+    +--------+    +--------+
|  Pod   |    |  Pod   |    |  Pod   |    |  Pod   |
+--------+    +--------+    +--------+    +--------+
```

---

## Why Use Deployment Over ReplicaSet Directly?

| Scenario | ReplicaSet | Deployment |
|----------|------------|------------|
| Keep 3 Pods running | Can do this | Can do this |
| Update app from v1 to v2 | Must manually delete/create | Handles automatically |
| v2 is broken, go back to v1 | Hope you saved the old YAML | `kubectl rollout undo` |
| See update history | Not tracked | Built-in history |
| Gradual rollout | DIY orchestration | Built-in strategies |

---

## Rolling Updates Explained

A rolling update replaces Pods **one by one** (or in small batches) so your application stays available during updates.

### Without Rolling Update (Bad)

```
Step 1: Delete all old Pods
+------+  +------+  +------+
| v1 X |  | v1 X |  | v1 X |    <-- All Pods deleted
+------+  +------+  +------+
                                 DOWNTIME! No Pods serving traffic!
Step 2: Create new Pods
+------+  +------+  +------+
|  v2  |  |  v2  |  |  v2  |    <-- New Pods starting
+------+  +------+  +------+
```

### With Rolling Update (Good)

```
Step 1: Start                    Step 2: Replace first Pod
+------+  +------+  +------+     +------+  +------+  +------+
|  v1  |  |  v1  |  |  v1  |     |  v2  |  |  v1  |  |  v1  |
+------+  +------+  +------+     +------+  +------+  +------+
                                     ^
                                  New Pod created, old one terminated

Step 3: Replace second Pod       Step 4: Replace last Pod
+------+  +------+  +------+     +------+  +------+  +------+
|  v2  |  |  v2  |  |  v1  |     |  v2  |  |  v2  |  |  v2  |
+------+  +------+  +------+     +------+  +------+  +------+
                                     
At every step, at least 2 Pods are serving traffic - NO DOWNTIME!
```

---

## How Deployments Handle Updates

When you update a Deployment, it creates a **new ReplicaSet** and gradually shifts traffic:

```
BEFORE UPDATE
+------------------------------------------+
|              DEPLOYMENT                   |
|              nginx-deploy                 |
+------------------------------------------+
                    |
                    v
        +----------------------+
        |    ReplicaSet-A      |
        |    (nginx:1.20)      |
        |    replicas: 3       |
        +----------------------+
                    |
        +-----------+-----------+
        v           v           v
    +------+    +------+    +------+
    |Pod v1|    |Pod v1|    |Pod v1|
    +------+    +------+    +------+


DURING UPDATE (Rolling)
+------------------------------------------+
|              DEPLOYMENT                   |
|              nginx-deploy                 |
+------------------------------------------+
          |                    |
          v                    v
+------------------+    +------------------+
|  ReplicaSet-A    |    |  ReplicaSet-B    |
|  (nginx:1.20)    |    |  (nginx:1.21)    |
|  replicas: 2     |    |  replicas: 1     |
|  SCALING DOWN    |    |  SCALING UP      |
+------------------+    +------------------+
        |                       |
    +---+---+                   v
    v       v               +------+
+------+ +------+           |Pod v2|
|Pod v1| |Pod v1|           +------+
+------+ +------+


AFTER UPDATE
+------------------------------------------+
|              DEPLOYMENT                   |
|              nginx-deploy                 |
+------------------------------------------+
          |                    |
          v                    v
+------------------+    +------------------+
|  ReplicaSet-A    |    |  ReplicaSet-B    |
|  (nginx:1.20)    |    |  (nginx:1.21)    |
|  replicas: 0     |    |  replicas: 3     |
|  KEPT FOR        |    |  ACTIVE          |
|  ROLLBACK        |    |                  |
+------------------+    +------------------+
                                |
                    +-----------+-----------+
                    v           v           v
                +------+    +------+    +------+
                |Pod v2|    |Pod v2|    |Pod v2|
                +------+    +------+    +------+
```

---

## Deployment YAML Example

```yaml
apiVersion: apps/v1          # Deployments are in 'apps' API group
kind: Deployment             # Resource type
metadata:
  name: nginx-deployment     # Deployment name
  labels:
    app: nginx
spec:
  replicas: 3                # Desired number of Pods
  
  selector:                  # How to find Pods this Deployment manages
    matchLabels:
      app: nginx
  
  # UPDATE STRATEGY
  strategy:
    type: RollingUpdate      # Options: RollingUpdate or Recreate
    rollingUpdate:
      maxUnavailable: 1      # Max Pods that can be unavailable during update
      maxSurge: 1            # Max extra Pods that can be created during update
  
  # POD TEMPLATE
  template:
    metadata:
      labels:
        app: nginx           # Must match selector.matchLabels
    spec:
      containers:
      - name: nginx
        image: nginx:1.21    # Change this to trigger a rolling update
        ports:
        - containerPort: 80
        resources:
          requests:
            cpu: "100m"
            memory: "128Mi"
          limits:
            cpu: "200m"
            memory: "256Mi"
        # Readiness probe - when is Pod ready to receive traffic?
        readinessProbe:
          httpGet:
            path: /
            port: 80
          initialDelaySeconds: 5
          periodSeconds: 5
        # Liveness probe - is the Pod still alive?
        livenessProbe:
          httpGet:
            path: /
            port: 80
          initialDelaySeconds: 15
          periodSeconds: 10
```

---

## Update Strategies

### 1. RollingUpdate (Default)

Gradually replaces Pods. Best for zero-downtime deployments.

```yaml
strategy:
  type: RollingUpdate
  rollingUpdate:
    maxUnavailable: 25%   # Or absolute number like 1
    maxSurge: 25%         # Or absolute number like 1
```

| Parameter | Meaning | Example |
|-----------|---------|---------|
| `maxUnavailable` | Max Pods that can be down during update | `1` or `25%` |
| `maxSurge` | Max extra Pods during update | `1` or `25%` |

### 2. Recreate

Kills all old Pods before creating new ones. Causes downtime but simpler.

```yaml
strategy:
  type: Recreate
```

Use when:
- Your app can't run multiple versions simultaneously
- You have database migrations that aren't backward compatible

---

## Mermaid Diagram: Rolling Update Process

```mermaid
flowchart TD
    A[Update Deployment YAML] --> B[Deployment Controller detects change]
    B --> C[Create new ReplicaSet with new Pod template]
    C --> D[Scale up new ReplicaSet by 1]
    D --> E{New Pod ready?}
    E -->|No| F[Wait and check readiness probe]
    F --> E
    E -->|Yes| G[Scale down old ReplicaSet by 1]
    G --> H{All Pods updated?}
    H -->|No| D
    H -->|Yes| I[Rollout complete!]
    
    style A fill:#e3f2fd
    style I fill:#c8e6c9
```

---

## Rollback Capability

If an update goes wrong, you can quickly roll back:

```bash
# See rollout history
kubectl rollout history deployment nginx-deployment

# Output:
# REVISION  CHANGE-CAUSE
# 1         <none>
# 2         <none>
# 3         <none>

# Rollback to previous version
kubectl rollout undo deployment nginx-deployment

# Rollback to specific revision
kubectl rollout undo deployment nginx-deployment --to-revision=1
```

### Visual: Rollback Process

```
CURRENT STATE (v3 is broken)
+---------------+     +---------------+     +---------------+
| ReplicaSet-1  |     | ReplicaSet-2  |     | ReplicaSet-3  |
|   v1          |     |   v2          |     |   v3 (BAD)    |
|   replicas: 0 |     |   replicas: 0 |     |   replicas: 3 |
+---------------+     +---------------+     +---------------+

AFTER: kubectl rollout undo

+---------------+     +---------------+     +---------------+
| ReplicaSet-1  |     | ReplicaSet-2  |     | ReplicaSet-3  |
|   v1          |     |   v2 (GOOD)   |     |   v3 (BAD)    |
|   replicas: 0 |     |   replicas: 3 |     |   replicas: 0 |
+---------------+     +---------------+     +---------------+
                             ^
                      Back to v2!
```

---

## Common kubectl Commands for Deployments

```bash
# Create Deployment
kubectl apply -f deployment.yaml

# List Deployments
kubectl get deployments
kubectl get deploy          # Short form

# See detailed info
kubectl describe deployment nginx-deployment

# Scale Deployment
kubectl scale deployment nginx-deployment --replicas=5

# Update image (triggers rolling update)
kubectl set image deployment/nginx-deployment nginx=nginx:1.22

# Check rollout status
kubectl rollout status deployment nginx-deployment

# Pause rollout (for manual control)
kubectl rollout pause deployment nginx-deployment

# Resume rollout
kubectl rollout resume deployment nginx-deployment

# View rollout history
kubectl rollout history deployment nginx-deployment

# Rollback to previous version
kubectl rollout undo deployment nginx-deployment

# Rollback to specific revision
kubectl rollout undo deployment nginx-deployment --to-revision=2

# Delete Deployment (also deletes ReplicaSets and Pods)
kubectl delete deployment nginx-deployment
```

---

## ASCII Diagram: Complete Hierarchy

```
+===========================================================================+
|                              DEPLOYMENT                                   |
|   name: nginx-deployment                                                  |
|   replicas: 3                                                             |
|   strategy: RollingUpdate                                                 |
|   selector: app=nginx                                                     |
+===========================================================================+
        |                                        |
        | manages (current)                      | manages (old, for rollback)
        v                                        v
+------------------------+              +------------------------+
|      REPLICASET        |              |      REPLICASET        |
| nginx-deployment-abc123|              | nginx-deployment-xyz789|
| image: nginx:1.22      |              | image: nginx:1.21      |
| replicas: 3            |              | replicas: 0            |
| selector: app=nginx    |              | selector: app=nginx    |
+------------------------+              +------------------------+
        |
        | creates & manages
        v
+-------+-------+-------+
|       |       |       |
v       v       v       v
+---+  +---+  +---+  +---+
|Pod|  |Pod|  |Pod|  |Pod|
|1.22  |1.22  |1.22  | X |  (if one dies, RS creates new one)
+---+  +---+  +---+  +---+
```

---

## Key Takeaways

1. **Use Deployments, not ReplicaSets** - Deployments give you updates + rollbacks for free
2. **Rolling updates = zero downtime** - Pods replaced gradually, traffic always served
3. **Rollback is easy** - Kubernetes keeps old ReplicaSets for quick rollback
4. **Declarative updates** - Just change the YAML, Kubernetes handles the rest
5. **Health checks matter** - Use readiness probes so updates wait for healthy Pods
