# ReplicaSets - Ensuring Pod Availability

## What is a ReplicaSet?

A **ReplicaSet** ensures that a specified number of identical Pod copies (replicas) are running at all times. If a Pod dies, the ReplicaSet automatically creates a new one to replace it.

### The Manager Analogy

Think of a ReplicaSet like a **store manager** who ensures there are always 3 cashiers at checkout:

```
+------------------------------------------------------------------+
|                        STORE (Cluster)                           |
|                                                                  |
|   MANAGER (ReplicaSet)                                           |
|   "I need exactly 3 cashiers!"                                   |
|                                                                  |
|   Checkout Lane 1    Checkout Lane 2    Checkout Lane 3          |
|   +------------+     +------------+     +------------+           |
|   |  Cashier   |     |  Cashier   |     |  Cashier   |           |
|   |   (Pod)    |     |   (Pod)    |     |   (Pod)    |           |
|   +------------+     +------------+     +------------+           |
|                                                                  |
|   If Cashier 2 goes on break (Pod dies):                         |
|   Manager immediately hires a replacement!                        |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Why Do We Need ReplicaSets?

| Problem | How ReplicaSet Helps |
|---------|---------------------|
| Pod crashes | Automatically creates a replacement Pod |
| Node fails | Schedules Pods on other available nodes |
| Need more capacity | Scale up by increasing replica count |
| Too much capacity | Scale down by decreasing replica count |

---

## How ReplicaSets Work: Labels and Selectors

ReplicaSets use a **matching system** to know which Pods they own:

```
+--------------------------------------------+
|              ReplicaSet                    |
|                                            |
|  Selector: app=webserver                   |
|  "I manage all Pods with app=webserver"    |
|                                            |
+--------------------+-----------------------+
                     |
                     | Looks for matching labels
                     v
     +---------------+---------------+
     |               |               |
     v               v               v
+---------+    +---------+    +---------+
|   Pod   |    |   Pod   |    |   Pod   |
| Labels: |    | Labels: |    | Labels: |
| app=    |    | app=    |    | app=    |
| webserver    | webserver    | webserver
+---------+    +---------+    +---------+
   MATCH!         MATCH!         MATCH!
```

### The Matching Rules:

1. **ReplicaSet has a `selector`** - defines what labels to look for
2. **Pods have `labels`** - key-value pairs attached to Pods
3. **ReplicaSet counts Pods** - that match its selector
4. **Creates/deletes Pods** - to maintain the desired replica count

---

## ReplicaSet YAML Example

```yaml
apiVersion: apps/v1       # ReplicaSets are in the 'apps' API group
kind: ReplicaSet          # Resource type
metadata:
  name: nginx-replicaset  # Name of this ReplicaSet
  labels:
    app: nginx            # Labels for the ReplicaSet itself
spec:
  replicas: 3             # DESIRED STATE: always have 3 Pods running
  
  selector:               # HOW to find Pods this ReplicaSet manages
    matchLabels:          # Simple equality matching
      app: nginx          # "Find Pods where app=nginx"
  
  template:               # POD TEMPLATE - blueprint for creating Pods
    metadata:
      labels:
        app: nginx        # Labels for Pods (MUST match selector!)
    spec:
      containers:
      - name: nginx
        image: nginx:1.21
        ports:
        - containerPort: 80
        resources:
          requests:
            cpu: "100m"
            memory: "128Mi"
          limits:
            cpu: "200m"
            memory: "256Mi"
```

### Important Notes:
- `selector.matchLabels` must match `template.metadata.labels`
- The `template` section is essentially a Pod spec (without `apiVersion` and `kind`)
- Changing `replicas` will scale up or down automatically

---

## ASCII Diagram: ReplicaSet in Action

```
+=========================================================================+
|                           REPLICASET                                    |
|   Name: nginx-rs                                                        |
|   Desired Replicas: 3                                                   |
|   Selector: app=nginx                                                   |
+=========================================================================+
        |
        | Creates and manages
        |
        +------------------+-------------------+-------------------+
        |                  |                   |                   |
        v                  v                   v                   v
  +----------+       +----------+       +----------+         +----------+
  |   Pod    |       |   Pod    |       |   Pod    |         |   Pod    |
  | nginx-rs |       | nginx-rs |       | nginx-rs |    ?    | nginx-rs |
  |  -abc123 |       |  -def456 |       |  -ghi789 |         |  -jkl012 |
  | app=nginx|       | app=nginx|       | app=nginx|         | app=nginx|
  | Running  |       | Running  |       | Failed X |         | Pending  |
  +----------+       +----------+       +----------+         +----------+
       |                  |                   |                   |
       |                  |                   |                   |
       +------------------+-------------------+-------------------+
                          |
                          v
              +------------------------+
              | Current State: 2 Ready |
              | Desired State: 3       |
              | Action: Creating Pod 4 |
              +------------------------+
```

---

## Mermaid Diagram: ReplicaSet Control Loop

```mermaid
flowchart TD
    A[ReplicaSet Controller] --> B{Count Pods matching selector}
    B --> C{Current == Desired?}
    C -->|Yes| D[Do nothing - state is correct]
    C -->|Current < Desired| E[Create new Pod from template]
    C -->|Current > Desired| F[Delete excess Pod]
    E --> G[Wait for Pod to be scheduled]
    F --> G
    G --> A
    D --> H[Sleep briefly]
    H --> A
    
    style A fill:#fff3e0
    style D fill:#c8e6c9
    style E fill:#e3f2fd
    style F fill:#ffcdd2
```

---

## Selector Types

ReplicaSets support two types of selectors:

### 1. matchLabels (Simple Equality)

```yaml
selector:
  matchLabels:
    app: nginx        # Pod must have app=nginx
    tier: frontend    # AND tier=frontend
```

### 2. matchExpressions (Advanced)

```yaml
selector:
  matchExpressions:
  - key: app
    operator: In              # Operators: In, NotIn, Exists, DoesNotExist
    values:
    - nginx
    - apache
  - key: environment
    operator: NotIn
    values:
    - production
```

| Operator | Meaning |
|----------|---------|
| `In` | Value must be one of the listed values |
| `NotIn` | Value must NOT be one of the listed values |
| `Exists` | Label key must exist (value doesn't matter) |
| `DoesNotExist` | Label key must NOT exist |

---

## Common kubectl Commands for ReplicaSets

```bash
# Create ReplicaSet from YAML
kubectl apply -f replicaset.yaml

# List all ReplicaSets
kubectl get replicasets
kubectl get rs              # Short form

# See detailed info
kubectl describe rs nginx-replicaset

# Scale ReplicaSet (change replica count)
kubectl scale rs nginx-replicaset --replicas=5

# Delete ReplicaSet (also deletes its Pods)
kubectl delete rs nginx-replicaset

# Delete ReplicaSet but keep Pods (orphan them)
kubectl delete rs nginx-replicaset --cascade=orphan
```

---

## Scaling Behavior

```
BEFORE SCALE (replicas: 3)
+-----------+  +-----------+  +-----------+
|   Pod 1   |  |   Pod 2   |  |   Pod 3   |
+-----------+  +-----------+  +-----------+

AFTER: kubectl scale rs nginx-rs --replicas=5

+-----------+  +-----------+  +-----------+  +-----------+  +-----------+
|   Pod 1   |  |   Pod 2   |  |   Pod 3   |  |   Pod 4   |  |   Pod 5   |
| (existing)|  | (existing)|  | (existing)|  |   (NEW)   |  |   (NEW)   |
+-----------+  +-----------+  +-----------+  +-----------+  +-----------+
```

---

## Important: ReplicaSet vs Deployment

While ReplicaSets are powerful, **you should almost always use Deployments instead**:

| Feature | ReplicaSet | Deployment |
|---------|------------|------------|
| Maintain replica count | Yes | Yes |
| Rolling updates | No | Yes |
| Rollback | No | Yes |
| Update history | No | Yes |

> **Best Practice**: Use Deployments, which create and manage ReplicaSets for you. Only use ReplicaSets directly if you need custom update orchestration.

---

## Key Takeaways

1. **ReplicaSets maintain Pod count** - Always ensures desired number of Pods are running
2. **Uses labels/selectors** - Matching system to identify which Pods it manages
3. **Self-healing** - Automatically replaces failed Pods
4. **Declarative** - You specify desired state, Kubernetes makes it happen
5. **Use Deployments instead** - Deployments provide ReplicaSet + rolling updates
