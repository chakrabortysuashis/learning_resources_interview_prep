# Services - Stable Network Endpoints for Pods

## What is a Service?

A **Service** is a stable network endpoint that provides a consistent way to access a set of Pods. It solves the fundamental problem: **How do I reliably connect to Pods that can appear and disappear at any time?**

### The Problem

```
WITHOUT SERVICES:

Client wants to reach "my-app"
         |
         v
    Which IP??
         
Pod IPs keep changing!
+--------+     +--------+     +--------+
|  Pod   |     |  Pod   |     |  Pod   |
|10.0.1.5|     |10.0.1.9|     |10.0.2.3|
|  DIED  |     |  NEW   |     |  NEW   |
+--------+     +--------+     +--------+
     X              ?              ?

Client was pointing to 10.0.1.5... now what?
```

### The Solution: Services

```
WITH SERVICES:

Client connects to Service (stable IP/DNS)
         |
         v
+-------------------+
|      SERVICE      |
|   my-app-service  |
|   IP: 10.96.0.1   |  <-- This IP NEVER changes
|   DNS: my-app     |  <-- This name NEVER changes
+-------------------+
         |
         | Routes traffic to healthy Pods
         v
+--------+  +--------+  +--------+
|  Pod   |  |  Pod   |  |  Pod   |
|10.0.1.9|  |10.0.2.3|  |10.0.2.7|
+--------+  +--------+  +--------+

Pods can come and go - Service handles it!
```

---

## How Services Find Pods: Labels and Selectors

Services use the **same label/selector system** as ReplicaSets:

```
+----------------------------------------+
|              SERVICE                   |
|                                        |
|  selector:                             |
|    app: webserver                      |
|    tier: frontend                      |
|                                        |
|  "Send traffic to Pods matching        |
|   BOTH labels"                         |
+----------------------------------------+
         |
         | Matches Pods with app=webserver AND tier=frontend
         |
    +----+----+----+
    |         |    |
    v         v    v
+-------+  +-------+  +-------+
|  Pod  |  |  Pod  |  |  Pod  |
| app=  |  | app=  |  | app=  |
|webserver |webserver |database|  <-- NOT matched (wrong app)
| tier= |  | tier= |  | tier= |
|frontend  |frontend  |backend |
+-------+  +-------+  +-------+
  MATCH!     MATCH!     NO
```

---

## Service Types Overview

```
+================================================================+
|                      SERVICE TYPES                              |
+================================================================+

1. ClusterIP (Default) - Internal only
+------------------+
| Outside World    |
|        X         |  Cannot reach
+------------------+
        |
+------------------+
|    CLUSTER       |
|  +------------+  |
|  | ClusterIP  |  |  Only accessible within cluster
|  |  Service   |  |
|  +------------+  |
|        |         |
|    +---+---+     |
|    v   v   v     |
|  +---+---+---+   |
|  |Pod|Pod|Pod|   |
|  +---+---+---+   |
+------------------+

2. NodePort - External via Node's port
+------------------+
| Outside World    |
|        |         |
|  NodeIP:30080    |  Access via any Node's IP + port
+------------------+
        |
+------------------+
|    CLUSTER       |
|  +------------+  |
|  |  NodePort  |  |  Opens same port on ALL nodes
|  |  Service   |  |
|  | port:30080 |  |
|  +------------+  |
|        |         |
|    +---+---+     |
|    v   v   v     |
|  +---+---+---+   |
|  |Pod|Pod|Pod|   |
|  +---+---+---+   |
+------------------+

3. LoadBalancer - External via cloud load balancer
+------------------+
| Outside World    |
|        |         |
|   Internet       |
+------------------+
        |
+------------------+
| CLOUD PROVIDER   |
| +-------------+  |
| | External LB |  |  Cloud provider creates real LB
| | 34.56.78.90 |  |  (AWS ELB, GCP LB, Azure LB)
| +-------------+  |
+------------------+
        |
+------------------+
|    CLUSTER       |
|  +------------+  |
|  |LoadBalancer|  |
|  |  Service   |  |
|  +------------+  |
|        |         |
|    +---+---+     |
|    v   v   v     |
|  +---+---+---+   |
|  |Pod|Pod|Pod|   |
|  +---+---+---+   |
+------------------+
```

---

## Service Type Comparison

| Type | Accessible From | Use Case | Cost |
|------|-----------------|----------|------|
| **ClusterIP** | Inside cluster only | Internal services (databases, caches) | Free |
| **NodePort** | Outside via Node IP:Port | Development, when LB not available | Free |
| **LoadBalancer** | Internet via public IP | Production web services | Cloud LB costs |
| **ExternalName** | Maps to external DNS | Connect to external services | Free |

---

## Service YAML Examples

### ClusterIP Service (Default)

```yaml
apiVersion: v1
kind: Service
metadata:
  name: my-internal-service   # Service name (used for DNS)
spec:
  type: ClusterIP             # Default - internal only
  
  selector:                   # Which Pods to send traffic to
    app: my-app               # Pods with label app=my-app
  
  ports:
  - port: 80                  # Port the Service listens on
    targetPort: 8080          # Port the Pods are listening on
    protocol: TCP             # TCP or UDP (default: TCP)
```

**Accessing this service:**
- From inside cluster: `http://my-internal-service:80`
- Or: `http://my-internal-service.default.svc.cluster.local:80`

### NodePort Service

```yaml
apiVersion: v1
kind: Service
metadata:
  name: my-nodeport-service
spec:
  type: NodePort
  
  selector:
    app: my-app
  
  ports:
  - port: 80                  # Internal cluster port
    targetPort: 8080          # Pod port
    nodePort: 30080           # External port (30000-32767)
                              # If omitted, Kubernetes picks one
```

**Accessing this service:**
- From outside: `http://<any-node-ip>:30080`
- From inside: `http://my-nodeport-service:80`

### LoadBalancer Service

```yaml
apiVersion: v1
kind: Service
metadata:
  name: my-loadbalancer-service
spec:
  type: LoadBalancer
  
  selector:
    app: my-app
  
  ports:
  - port: 80                  # External LB port
    targetPort: 8080          # Pod port
```

**Accessing this service:**
- From internet: `http://<external-ip>:80` (assigned by cloud provider)

---

## Mermaid Diagram: Service Discovery Flow

```mermaid
flowchart TD
    A[Pod A wants to reach 'backend' service] --> B[DNS Query: backend.default.svc.cluster.local]
    B --> C[CoreDNS returns Service ClusterIP]
    C --> D[Pod A sends request to ClusterIP]
    D --> E[kube-proxy intercepts traffic]
    E --> F[kube-proxy selects healthy Pod]
    F --> G[Traffic forwarded to Pod]
    G --> H[Response sent back to Pod A]
    
    style A fill:#e3f2fd
    style H fill:#c8e6c9
```

---

## Port Mapping Explained

```
+--------------------------------------------------+
|                                                  |
|  CLIENT (inside cluster)                         |
|      |                                           |
|      | Connects to service-name:80               |
|      v                                           |
|  +-------------------+                           |
|  |     SERVICE       |   port: 80                |
|  |   ClusterIP:      |   (what clients use)      |
|  |   10.96.0.100     |                           |
|  +-------------------+                           |
|           |                                      |
|           | Forwards to targetPort               |
|           v                                      |
|  +-------------------+                           |
|  |       POD         |   targetPort: 8080        |
|  |  Container runs   |   (what container listens |
|  |  on port 8080     |    on)                    |
|  +-------------------+                           |
|                                                  |
+--------------------------------------------------+
```

---

## DNS Names for Services

Kubernetes automatically creates DNS entries for Services:

```
<service-name>.<namespace>.svc.cluster.local

Examples:
- my-service.default.svc.cluster.local      (full name)
- my-service.default.svc                    (short form)
- my-service.default                        (shorter)
- my-service                                (same namespace only)
```

### Within Same Namespace

```yaml
# Pod in 'default' namespace can reach:
- my-service           # Works!
- my-service:80        # With port
```

### Across Namespaces

```yaml
# Pod in 'frontend' namespace reaching service in 'backend' namespace:
- my-service.backend               # Need namespace
- my-service.backend.svc           # Also works
- my-service.backend.svc.cluster.local  # Full DNS
```

---

## Multiple Ports

A Service can expose multiple ports:

```yaml
apiVersion: v1
kind: Service
metadata:
  name: my-multi-port-service
spec:
  selector:
    app: my-app
  ports:
  - name: http        # Name required when multiple ports
    port: 80
    targetPort: 8080
  - name: https
    port: 443
    targetPort: 8443
  - name: metrics
    port: 9090
    targetPort: 9090
```

---

## ASCII Diagram: Complete Service Architecture

```
+=======================================================================+
|                         KUBERNETES CLUSTER                            |
|                                                                       |
|   EXTERNAL                                                            |
|   TRAFFIC                                                             |
|      |                                                                |
|      v                                                                |
|  +------------------+                                                 |
|  | LoadBalancer     |  External IP: 34.56.78.90                       |
|  | Service          |                                                 |
|  | (frontend-lb)    |                                                 |
|  +--------+---------+                                                 |
|           |                                                           |
|           v                                                           |
|  +------------------+     +------------------+                        |
|  |   Frontend Pod   |     |   Frontend Pod   |                        |
|  |   (React App)    |     |   (React App)    |                        |
|  +--------+---------+     +--------+---------+                        |
|           |                        |                                  |
|           +----------+-------------+                                  |
|                      |                                                |
|                      v                                                |
|            +------------------+                                       |
|            |    ClusterIP     |  DNS: backend-api                     |
|            |    Service       |  ClusterIP: 10.96.0.50                |
|            |  (backend-api)   |                                       |
|            +--------+---------+                                       |
|                     |                                                 |
|           +---------+---------+                                       |
|           |         |         |                                       |
|           v         v         v                                       |
|       +-------+ +-------+ +-------+                                   |
|       |Backend| |Backend| |Backend|                                   |
|       | Pod 1 | | Pod 2 | | Pod 3 |                                   |
|       +---+---+ +---+---+ +---+---+                                   |
|           |         |         |                                       |
|           +----+----+---------+                                       |
|                |                                                      |
|                v                                                      |
|       +------------------+                                            |
|       |    ClusterIP     |  DNS: database                             |
|       |    Service       |                                            |
|       |   (database)     |                                            |
|       +--------+---------+                                            |
|                |                                                      |
|                v                                                      |
|          +----------+                                                 |
|          | Database |                                                 |
|          |   Pod    |                                                 |
|          +----------+                                                 |
|                                                                       |
+=======================================================================+
```

---

## Common kubectl Commands for Services

```bash
# Create Service from YAML
kubectl apply -f service.yaml

# List all Services
kubectl get services
kubectl get svc              # Short form

# See detailed info
kubectl describe svc my-service

# Get Service with external IP (for LoadBalancer)
kubectl get svc -o wide

# Expose a Deployment as a Service (quick way)
kubectl expose deployment my-deployment --port=80 --target-port=8080

# Create NodePort Service quickly
kubectl expose deployment my-deployment --type=NodePort --port=80

# Delete Service
kubectl delete svc my-service

# Get endpoints (which Pods the Service routes to)
kubectl get endpoints my-service
```

---

## Mermaid Diagram: Service Types Decision Tree

```mermaid
flowchart TD
    A[Need to expose Pods?] --> B{Who needs access?}
    B -->|Only other Pods in cluster| C[ClusterIP]
    B -->|External access needed| D{Have cloud provider?}
    D -->|Yes - AWS/GCP/Azure| E[LoadBalancer]
    D -->|No - bare metal/local| F[NodePort]
    
    C --> G["Internal: http://service-name:port"]
    E --> H["External: http://public-ip:port"]
    F --> I["External: http://node-ip:30000+"]
    
    style C fill:#e8f5e9
    style E fill:#e3f2fd
    style F fill:#fff3e0
```

---

## Key Takeaways

1. **Services provide stable endpoints** - Pods change, Service IP/DNS stays the same
2. **Uses labels/selectors** - Service finds Pods by matching labels
3. **ClusterIP is default** - Good for internal communication
4. **NodePort for simple external access** - Opens port on all nodes
5. **LoadBalancer for production** - Gets real external IP from cloud provider
6. **DNS is automatic** - Access services by name, not IP
