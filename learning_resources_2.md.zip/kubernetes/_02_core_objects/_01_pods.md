# Pods - The Smallest Deployable Unit in Kubernetes

## What is a Pod?

A **Pod** is the smallest thing you can deploy in Kubernetes. Think of it like an **apartment for your containers** - it provides a shared living space where one or more containers can run together.

```
+------------------------------------------+
|              POD (Apartment)             |
|  +-------------+    +-------------+      |
|  | Container 1 |    | Container 2 |      |
|  | (Bedroom 1) |    | (Bedroom 2) |      |
|  +-------------+    +-------------+      |
|                                          |
|  Shared Resources:                       |
|  - Same IP address (shared address)      |
|  - Same storage volumes (shared closet)  |
|  - Same network namespace (same wifi)    |
+------------------------------------------+
```

### Key Points:
- Containers in a Pod share the same network (they can talk via `localhost`)
- Containers in a Pod can share storage volumes
- A Pod runs on a single node (never split across machines)
- Pods are ephemeral - they can be created and destroyed at any time

---

## Single Container vs Multi-Container Pods

### Single Container Pod (Most Common)
One Pod = One Container. This is the typical pattern.

```
+---------------------+
|        POD          |
|  +--------------+   |
|  |   nginx      |   |
|  |  container   |   |
|  +--------------+   |
+---------------------+
```

### Multi-Container Pod
Multiple containers that need to work closely together.

```
+----------------------------------------+
|                  POD                   |
|  +--------------+   +--------------+   |
|  |    Main      |   |   Sidecar    |   |
|  |    App       |   |   (logs)     |   |
|  +--------------+   +--------------+   |
|         |                  |           |
|         +------ shared ----+           |
|                volume                  |
+----------------------------------------+
```

**Common Multi-Container Patterns:**

| Pattern | Description | Example |
|---------|-------------|---------|
| **Sidecar** | Helper container that enhances main container | Log shipper, config reloader |
| **Ambassador** | Proxy for external connections | Database proxy |
| **Adapter** | Transforms output of main container | Log format converter |

---

## Pod Lifecycle

A Pod goes through several phases during its lifetime:

```
                    +-------------+
                    |   Pending   |  Pod accepted, waiting for
                    |             |  containers to start
                    +------+------+
                           |
                           v
                    +-------------+
                    |   Running   |  At least one container
                    |             |  is running
                    +------+------+
                           |
              +------------+------------+
              |                         |
              v                         v
       +-------------+           +-------------+
       |  Succeeded  |           |   Failed    |
       | (exit 0)    |           | (exit != 0) |
       +-------------+           +-------------+
```

### Pod Phases Explained:

| Phase | What's Happening |
|-------|------------------|
| **Pending** | Pod is accepted by Kubernetes, but containers aren't running yet. Maybe downloading images or waiting for resources. |
| **Running** | Pod is bound to a node, all containers created, at least one is running. |
| **Succeeded** | All containers finished successfully (exit code 0). Common for Jobs. |
| **Failed** | All containers terminated, at least one failed (exit code != 0). |
| **Unknown** | Pod state cannot be determined. Usually a communication error. |

---

## Pod YAML Example with Explanations

```yaml
# Every Kubernetes resource starts with these 4 fields
apiVersion: v1          # API version - 'v1' is the core/stable API
kind: Pod               # What type of resource this is
metadata:               # Information ABOUT the resource
  name: my-first-pod    # Unique name for this Pod (required)
  labels:               # Key-value pairs for organizing/selecting Pods
    app: webserver      # Label: app=webserver
    environment: dev    # Label: environment=dev
spec:                   # The DESIRED STATE - what you want
  containers:           # List of containers in this Pod
  - name: nginx         # Container name (must be unique in Pod)
    image: nginx:1.21   # Docker image to use (image:tag format)
    ports:
    - containerPort: 80 # Port the container listens on (documentation)
    resources:          # Resource requests and limits
      requests:         # Minimum resources needed
        memory: "64Mi"  # 64 Megabytes of RAM
        cpu: "250m"     # 250 millicpu (0.25 CPU cores)
      limits:           # Maximum resources allowed
        memory: "128Mi" # Cap at 128 MB RAM
        cpu: "500m"     # Cap at 0.5 CPU cores
    env:                # Environment variables
    - name: MY_VAR      # Variable name
      value: "hello"    # Variable value
```

### Understanding Resource Units:
- **Memory**: Mi (Mebibytes), Gi (Gibibytes)
- **CPU**: 1000m = 1 CPU core, 500m = 0.5 cores, 250m = 0.25 cores

---

## ASCII Diagram: Pod Architecture

```
+================================================================+
|                         KUBERNETES NODE                         |
|                                                                 |
|   +---------------------------+   +---------------------------+ |
|   |          POD A            |   |          POD B            | |
|   |  IP: 10.244.0.5           |   |  IP: 10.244.0.6           | |
|   |                           |   |                           | |
|   |  +---------------------+  |   |  +----------+ +--------+  | |
|   |  |     Container       |  |   |  |Container1| |Container2| | |
|   |  |     (nginx)         |  |   |  | (app)    | | (redis) | | |
|   |  |     Port: 80        |  |   |  +----------+ +--------+  | |
|   |  +---------------------+  |   |        |           |      | |
|   |                           |   |        +-localhost-+      | |
|   |  +---------------------+  |   |                           | |
|   |  |   Shared Volume     |  |   |  +---------------------+  | |
|   |  |   /data             |  |   |  |   Shared Volume     |  | |
|   |  +---------------------+  |   |  +---------------------+  | |
|   +---------------------------+   +---------------------------+ |
|                                                                 |
+================================================================+
```

---

## Mermaid Diagram: Pod Creation Flow

```mermaid
flowchart TD
    A[User runs: kubectl apply -f pod.yaml] --> B[API Server receives request]
    B --> C[Pod stored in etcd]
    C --> D[Scheduler assigns Pod to Node]
    D --> E[Kubelet on Node receives Pod spec]
    E --> F[Kubelet tells Container Runtime to pull image]
    F --> G[Container Runtime creates containers]
    G --> H[Pod is Running!]
    
    style A fill:#e1f5fe
    style H fill:#c8e6c9
```

---

## Common kubectl Commands for Pods

```bash
# Create a Pod from YAML
kubectl apply -f pod.yaml

# List all Pods
kubectl get pods

# List Pods with more details (IP, Node)
kubectl get pods -o wide

# Describe a Pod (detailed info, events)
kubectl describe pod my-first-pod

# View Pod logs
kubectl logs my-first-pod

# View logs for specific container in multi-container Pod
kubectl logs my-first-pod -c nginx

# Execute a command inside a Pod
kubectl exec -it my-first-pod -- /bin/bash

# Delete a Pod
kubectl delete pod my-first-pod
```

---

## Quick Reference

| Concept | Description |
|---------|-------------|
| **Pod** | Smallest deployable unit, wrapper around container(s) |
| **Single-container Pod** | Most common, one container per Pod |
| **Multi-container Pod** | Tightly coupled containers that share resources |
| **Pod IP** | Each Pod gets its own IP address |
| **Ephemeral** | Pods can die and be replaced anytime |

---

## Key Takeaways

1. **Pods are the atomic unit** - You don't deploy containers directly, you deploy Pods
2. **Pods are ephemeral** - They can be killed and recreated at any time
3. **One Pod = One instance** - Don't put multiple replicas in one Pod
4. **Shared resources** - Containers in a Pod share network and can share storage
5. **Usually one container** - Multi-container Pods are for special cases only
