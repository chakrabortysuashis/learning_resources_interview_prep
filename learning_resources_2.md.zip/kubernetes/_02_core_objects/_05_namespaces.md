# Namespaces - Virtual Clusters Within a Cluster

## What are Namespaces?

**Namespaces** are a way to divide a single Kubernetes cluster into multiple virtual clusters. They provide isolation and organization for resources.

### The Office Building Analogy

Think of your Kubernetes cluster as a **large office building**, and namespaces as **different departments** or **floors**:

```
+================================================================+
|                    OFFICE BUILDING (Cluster)                    |
|                                                                 |
|  +---------------------------+  +---------------------------+   |
|  |    FLOOR 3: Marketing     |  |   FLOOR 4: Engineering    |   |
|  |    (namespace: marketing) |  |   (namespace: engineering)|   |
|  |                           |  |                           |   |
|  |  +-----+ +-----+ +-----+  |  |  +-----+ +-----+ +-----+  |   |
|  |  |Desk1| |Desk2| |Desk3|  |  |  |Desk1| |Desk2| |Desk3|  |   |
|  |  |(Pod)| |(Pod)| |(Pod)|  |  |  |(Pod)| |(Pod)| |(Pod)|  |   |
|  |  +-----+ +-----+ +-----+  |  |  +-----+ +-----+ +-----+  |   |
|  |                           |  |                           |   |
|  |  Both floors can have     |  |  Each floor manages its   |   |
|  |  "Desk1" - no conflict!   |  |  own resources            |   |
|  +---------------------------+  +---------------------------+   |
|                                                                 |
|  +---------------------------+  +---------------------------+   |
|  |    FLOOR 1: Finance       |  |   FLOOR 2: HR             |   |
|  |    (namespace: finance)   |  |   (namespace: hr)         |   |
|  +---------------------------+  +---------------------------+   |
|                                                                 |
|  SHARED RESOURCES (Building-wide):                              |
|  - Elevator (Nodes)                                             |
|  - Security System (RBAC)                                       |
|  - Building Address (Cluster IP range)                          |
+================================================================+
```

---

## Why Use Namespaces?

| Use Case | How Namespaces Help |
|----------|---------------------|
| **Team Isolation** | Each team gets their own namespace |
| **Environment Separation** | dev, staging, production in same cluster |
| **Resource Quotas** | Limit CPU/memory per namespace |
| **Access Control** | Different permissions per namespace |
| **Name Organization** | Same resource names in different namespaces |

---

## Default Namespaces

Every Kubernetes cluster comes with these namespaces pre-created:

```
+-------------------------------------------------------------------+
|                      DEFAULT NAMESPACES                            |
+-------------------------------------------------------------------+

1. default
+---------------------------+
|        default            |  Where your stuff goes if you don't
|                           |  specify a namespace
|  Your Pods, Services,     |
|  Deployments...           |  kubectl commands use this by default
+---------------------------+

2. kube-system
+---------------------------+
|       kube-system         |  Kubernetes system components
|                           |
|  - kube-dns/coredns       |  DO NOT put your apps here!
|  - kube-proxy             |  DO NOT delete things from here!
|  - metrics-server         |
+---------------------------+

3. kube-public
+---------------------------+
|       kube-public         |  Readable by everyone (even
|                           |  unauthenticated users)
|  Mostly empty, used for   |
|  cluster info             |  Rarely used in practice
+---------------------------+

4. kube-node-lease
+---------------------------+
|    kube-node-lease        |  Node heartbeat/lease objects
|                           |
|  Used internally by       |  Don't worry about this one
|  Kubernetes               |
+---------------------------+
```

---

## Namespace YAML Example

```yaml
# Creating a namespace
apiVersion: v1
kind: Namespace
metadata:
  name: development        # Namespace name
  labels:                  # Optional labels
    environment: dev
    team: backend
```

Or simply:

```yaml
apiVersion: v1
kind: Namespace
metadata:
  name: production
```

---

## Working with Namespaces

### Creating Resources in a Namespace

**Method 1: In the YAML file**

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: my-pod
  namespace: development    # Specify namespace here
spec:
  containers:
  - name: nginx
    image: nginx
```

**Method 2: Using -n flag**

```bash
# Create in specific namespace
kubectl apply -f pod.yaml -n development

# List Pods in specific namespace
kubectl get pods -n development

# List Pods in ALL namespaces
kubectl get pods --all-namespaces
kubectl get pods -A                    # Short form
```

---

## Visual: Resources Across Namespaces

```
+================================================================+
|                       KUBERNETES CLUSTER                        |
|                                                                 |
|  +-------------------------+  +-------------------------+       |
|  |  Namespace: development |  |  Namespace: production  |       |
|  |                         |  |                         |       |
|  |  Deployments:           |  |  Deployments:           |       |
|  |  - frontend (3 pods)    |  |  - frontend (10 pods)   |       |
|  |  - backend (2 pods)     |  |  - backend (5 pods)     |       |
|  |                         |  |                         |       |
|  |  Services:              |  |  Services:              |       |
|  |  - frontend-svc         |  |  - frontend-svc         |       |
|  |  - backend-svc          |  |  - backend-svc          |       |
|  |                         |  |                         |       |
|  |  ConfigMaps:            |  |  ConfigMaps:            |       |
|  |  - app-config (DEV)     |  |  - app-config (PROD)    |       |
|  |                         |  |                         |       |
|  |  Resource Quota:        |  |  Resource Quota:        |       |
|  |  - 4 CPU, 8Gi memory    |  |  - 16 CPU, 32Gi memory  |       |
|  +-------------------------+  +-------------------------+       |
|                                                                 |
|  Same names (frontend, backend-svc) - different namespaces!     |
|                                                                 |
+================================================================+
```

---

## Cross-Namespace Communication

Pods can communicate across namespaces using the full DNS name:

```
+-------------------------+     +-------------------------+
|  Namespace: frontend    |     |  Namespace: backend     |
|                         |     |                         |
|  +------------------+   |     |  +------------------+   |
|  |    Web Pod       |   |     |  |    API Service   |   |
|  |                  |------>--|  |    api-svc       |   |
|  +------------------+   |     |  +------------------+   |
|                         |     |                         |
+-------------------------+     +-------------------------+

Web Pod connects to:
  api-svc.backend.svc.cluster.local
  
  Format: <service>.<namespace>.svc.cluster.local
```

### DNS Name Examples:

```
# Within same namespace (can use short name)
my-service
my-service:80

# Across namespaces (need full name)
my-service.other-namespace
my-service.other-namespace.svc
my-service.other-namespace.svc.cluster.local
```

---

## When to Use Namespaces

### Good Use Cases

```
+------------------------------------------------------------+
|  RECOMMENDED USES                                           |
+------------------------------------------------------------+
|                                                             |
|  1. Environment Separation                                  |
|     +--------+  +--------+  +--------+                      |
|     |  dev   |  |staging |  |  prod  |                      |
|     +--------+  +--------+  +--------+                      |
|                                                             |
|  2. Team/Project Isolation                                  |
|     +--------+  +--------+  +--------+                      |
|     | team-a |  | team-b |  | team-c |                      |
|     +--------+  +--------+  +--------+                      |
|                                                             |
|  3. Multi-tenant Clusters                                   |
|     +----------+  +----------+  +----------+                |
|     | customer1|  | customer2|  | customer3|                |
|     +----------+  +----------+  +----------+                |
|                                                             |
+------------------------------------------------------------+
```

### When NOT to Use Namespaces

```
+------------------------------------------------------------+
|  PROBABLY DON'T NEED NAMESPACES                             |
+------------------------------------------------------------+
|                                                             |
|  - Small team / few applications                            |
|    (just use 'default')                                     |
|                                                             |
|  - Slightly different versions of same app                  |
|    (use labels instead)                                     |
|                                                             |
|  - Strong isolation requirements                            |
|    (use separate clusters instead)                          |
|                                                             |
+------------------------------------------------------------+
```

---

## Mermaid Diagram: Namespace Resource Organization

```mermaid
flowchart TD
    subgraph Cluster
        subgraph ns-dev[Namespace: development]
            D1[Deployment: api]
            D2[Service: api-svc]
            D3[ConfigMap: config]
        end
        
        subgraph ns-prod[Namespace: production]
            P1[Deployment: api]
            P2[Service: api-svc]
            P3[ConfigMap: config]
        end
        
        subgraph ns-system[Namespace: kube-system]
            S1[CoreDNS]
            S2[kube-proxy]
        end
    end
    
    D1 --> D2
    P1 --> P2
    
    style ns-dev fill:#e8f5e9
    style ns-prod fill:#e3f2fd
    style ns-system fill:#fff3e0
```

---

## Resource Quotas per Namespace

You can limit resources for each namespace:

```yaml
apiVersion: v1
kind: ResourceQuota
metadata:
  name: dev-quota
  namespace: development
spec:
  hard:
    requests.cpu: "4"           # Max 4 CPU cores requested
    requests.memory: 8Gi        # Max 8 GB memory requested
    limits.cpu: "8"             # Max 8 CPU cores limit
    limits.memory: 16Gi         # Max 16 GB memory limit
    pods: "20"                  # Max 20 Pods
    services: "10"              # Max 10 Services
    secrets: "20"               # Max 20 Secrets
    configmaps: "20"            # Max 20 ConfigMaps
```

---

## Common kubectl Commands for Namespaces

```bash
# List all namespaces
kubectl get namespaces
kubectl get ns                   # Short form

# Create namespace
kubectl create namespace development

# Create from YAML
kubectl apply -f namespace.yaml

# Delete namespace (WARNING: deletes everything in it!)
kubectl delete namespace development

# Set default namespace for kubectl commands
kubectl config set-context --current --namespace=development

# View current namespace
kubectl config view --minify | grep namespace:

# List resources in specific namespace
kubectl get all -n development

# List resources in all namespaces
kubectl get pods -A
kubectl get all -A

# Describe namespace
kubectl describe namespace development
```

---

## What Lives in Namespaces vs Cluster-Wide?

```
+----------------------------------+----------------------------------+
|      NAMESPACED RESOURCES        |     CLUSTER-WIDE RESOURCES       |
|      (exist in a namespace)      |     (shared across cluster)      |
+----------------------------------+----------------------------------+
|                                  |                                  |
|  - Pods                          |  - Nodes                         |
|  - Deployments                   |  - Namespaces themselves         |
|  - ReplicaSets                   |  - PersistentVolumes             |
|  - Services                      |  - ClusterRoles                  |
|  - ConfigMaps                    |  - ClusterRoleBindings           |
|  - Secrets                       |  - StorageClasses                |
|  - ServiceAccounts               |  - IngressClasses                |
|  - Roles                         |  - PriorityClasses               |
|  - RoleBindings                  |                                  |
|  - PersistentVolumeClaims        |                                  |
|                                  |                                  |
+----------------------------------+----------------------------------+

To see which resources are namespaced:
kubectl api-resources --namespaced=true

To see cluster-wide resources:
kubectl api-resources --namespaced=false
```

---

## Example: Multi-Environment Setup

```yaml
# namespaces.yaml - Create all environments
---
apiVersion: v1
kind: Namespace
metadata:
  name: development
  labels:
    environment: dev
---
apiVersion: v1
kind: Namespace
metadata:
  name: staging
  labels:
    environment: staging
---
apiVersion: v1
kind: Namespace
metadata:
  name: production
  labels:
    environment: prod
```

```bash
# Apply all namespaces
kubectl apply -f namespaces.yaml

# Deploy same app to different environments
kubectl apply -f app.yaml -n development
kubectl apply -f app.yaml -n staging
kubectl apply -f app.yaml -n production

# Each environment can have different configurations via ConfigMaps
```

---

## Key Takeaways

1. **Namespaces are virtual clusters** - Divide one cluster into isolated sections
2. **Don't touch kube-system** - System components live there
3. **Cross-namespace = full DNS** - Use `service.namespace.svc.cluster.local`
4. **Resource quotas** - Limit CPU/memory per namespace
5. **Use for environments or teams** - dev/staging/prod or team-a/team-b
6. **Small setups don't need them** - `default` namespace is fine for simple cases
