# Secrets in Kubernetes

## What is a Secret?

A **Secret** is like a ConfigMap's security-conscious sibling. It's designed to store **sensitive data** such as:
- Passwords
- API keys and tokens
- SSH keys
- TLS certificates
- Database credentials

### Real-World Analogy

```
Think of your house:
- ConfigMap = Address and directions (okay to share publicly)
- Secret = House key and alarm code (keep private!)

You wouldn't put your house key in a public directory,
and you shouldn't put your database password in a ConfigMap!
```

---

## ConfigMap vs Secret: Key Differences

```
+------------------+----------------------+----------------------+
|     Feature      |     ConfigMap        |       Secret         |
+------------------+----------------------+----------------------+
| Data Type        | Non-sensitive        | Sensitive            |
| Storage          | Plain text           | Base64 encoded       |
| Example Data     | App settings,        | Passwords, API       |
|                  | feature flags        | keys, certificates   |
| Size Limit       | 1 MB                 | 1 MB                 |
| Mounted as       | Files readable by    | Files with           |
|                  | anyone               | restricted perms     |
+------------------+----------------------+----------------------+

          IMPORTANT SECURITY NOTE!
+--------------------------------------------------+
|  Base64 encoding is NOT encryption!              |
|                                                  |
|  Base64 is just a way to represent binary        |
|  data as text. Anyone can decode it easily:      |
|                                                  |
|  echo "cGFzc3dvcmQxMjM=" | base64 --decode       |
|  Output: password123                             |
|                                                  |
|  Secrets provide separation of concerns and      |
|  access control, but NOT strong encryption       |
|  by default. Use external secret managers        |
|  for production!                                 |
+--------------------------------------------------+
```

---

## Types of Secrets

Kubernetes has several built-in Secret types:

```
+---------------------+------------------------------------------+
|     Secret Type     |              Use Case                    |
+---------------------+------------------------------------------+
| Opaque              | Generic secrets (default type)           |
|                     | Passwords, API keys, any custom data     |
+---------------------+------------------------------------------+
| kubernetes.io/      | Docker registry credentials              |
| dockerconfigjson    | For pulling private images               |
+---------------------+------------------------------------------+
| kubernetes.io/tls   | TLS certificates and keys                |
|                     | For HTTPS endpoints                      |
+---------------------+------------------------------------------+
| kubernetes.io/      | Basic authentication credentials         |
| basic-auth          | Username and password                    |
+---------------------+------------------------------------------+
| kubernetes.io/      | SSH private keys                         |
| ssh-auth            | For Git cloning, server access           |
+---------------------+------------------------------------------+
| kubernetes.io/      | Service account tokens                   |
| service-account-    | Auto-created by Kubernetes               |
| token               |                                          |
+---------------------+------------------------------------------+
```

---

## How Secrets Work

```
                            Kubernetes Cluster
+------------------------------------------------------------------------+
|                                                                         |
|   1. You create                2. Stored in etcd              3. Pods  |
|      a Secret                     (encrypted at rest*)        use it   |
|                                                                         |
|   +------------+              +------------------+          +---------+ |
|   | kubectl    |  ------>    |      etcd        |  <------ |   Pod   | |
|   | create     |              | +------------+  |          |         | |
|   | secret     |              | | my-secret  |  |          | Reads   | |
|   +------------+              | | [encoded]  |  |          | secret  | |
|                               | +------------+  |          +---------+ |
|                               +------------------+                      |
|                                                                         |
+------------------------------------------------------------------------+
          ^
          |
    *Only if you enable encryption at rest (recommended!)
```

---

## How to Create Secrets

### Method 1: From Command Line (Quick & Easy)

```bash
# Create a generic (Opaque) secret with username and password
kubectl create secret generic db-credentials \
  --from-literal=username=admin \
  --from-literal=password=supersecret123

# Create from a file (like a private key)
kubectl create secret generic ssh-key \
  --from-file=id_rsa=/path/to/private/key

# Create TLS secret from certificate files
kubectl create secret tls my-tls-secret \
  --cert=path/to/tls.crt \
  --key=path/to/tls.key

# Create Docker registry secret
kubectl create secret docker-registry my-registry-secret \
  --docker-server=myregistry.azurecr.io \
  --docker-username=myuser \
  --docker-password=mypassword \
  --docker-email=myemail@example.com
```

### Method 2: From YAML (For Version Control)

```yaml
# secret.yaml
apiVersion: v1                      # Kubernetes API version
kind: Secret                        # Resource type
metadata:
  name: my-app-secrets              # Name to reference this secret
  namespace: default
type: Opaque                        # Generic secret type (most common)
data:
  # Values MUST be base64 encoded!
  # To encode: echo -n 'mypassword' | base64
  # To decode: echo 'bXlwYXNzd29yZA==' | base64 --decode
  
  username: YWRtaW4=                # base64 of "admin"
  password: c3VwZXJzZWNyZXQxMjM=    # base64 of "supersecret123"
  api-key: YWJjMTIzZGVmNDU2         # base64 of "abc123def456"
```

**Easier alternative using `stringData`** (Kubernetes encodes for you):

```yaml
# secret-stringdata.yaml
apiVersion: v1
kind: Secret
metadata:
  name: my-app-secrets
type: Opaque
stringData:                          # Use stringData instead of data
  # Plain text values - Kubernetes will encode them automatically!
  username: admin                    # No base64 needed!
  password: supersecret123
  api-key: abc123def456
  
  # You can even include multi-line files
  config.json: |
    {
      "database": {
        "host": "db.example.com",
        "port": 5432
      }
    }
```

```bash
# Apply the secret
kubectl apply -f secret.yaml
```

---

## How to Use Secrets in Pods

### Option 1: As Environment Variables

```yaml
# pod-secret-env.yaml
apiVersion: v1
kind: Pod
metadata:
  name: my-app
spec:
  containers:
  - name: my-app
    image: my-app:1.0
    
    env:
    # Load specific keys as environment variables
    - name: DB_USERNAME                   # Env var name in container
      valueFrom:
        secretKeyRef:
          name: my-app-secrets            # Secret name
          key: username                   # Key in the secret
    
    - name: DB_PASSWORD
      valueFrom:
        secretKeyRef:
          name: my-app-secrets
          key: password
    
    # Or load ALL keys from a secret as env vars
    envFrom:
    - secretRef:
        name: my-app-secrets              # All keys become env vars
```

### Option 2: Mount as Files (Volume)

```yaml
# pod-secret-volume.yaml
apiVersion: v1
kind: Pod
metadata:
  name: my-app
spec:
  containers:
  - name: my-app
    image: my-app:1.0
    
    volumeMounts:
    - name: secret-volume
      mountPath: /etc/secrets              # Where files appear
      readOnly: true                       # Always make secrets read-only!
  
  volumes:
  - name: secret-volume
    secret:
      secretName: my-app-secrets
      defaultMode: 0400                    # File permissions (read-only for owner)
      # Optional: mount only specific keys
      items:
      - key: password
        path: db-password                  # Creates /etc/secrets/db-password
```

**Result inside container:**
```
/etc/secrets/
├── username        # Contains: admin (decoded automatically!)
├── password        # Contains: supersecret123
└── api-key         # Contains: abc123def456
```

---

## Complete Working Examples

### Example 1: Database Credentials

```yaml
# database-secret-example.yaml
---
apiVersion: v1
kind: Secret
metadata:
  name: postgres-credentials
type: Opaque
stringData:
  POSTGRES_USER: myapp_user
  POSTGRES_PASSWORD: "P@ssw0rd!Secure#2024"
  POSTGRES_DB: myapp_database
  # Connection string for the app
  DATABASE_URL: "postgresql://myapp_user:P@ssw0rd!Secure#2024@postgres-service:5432/myapp_database"

---
apiVersion: v1
kind: Pod
metadata:
  name: webapp
spec:
  containers:
  - name: webapp
    image: mywebapp:1.0
    envFrom:
    - secretRef:
        name: postgres-credentials
    ports:
    - containerPort: 8080
```

### Example 2: TLS Certificate for HTTPS

```yaml
# tls-secret-example.yaml
---
apiVersion: v1
kind: Secret
metadata:
  name: tls-certificate
type: kubernetes.io/tls
data:
  # These would be your actual base64-encoded cert and key
  tls.crt: LS0tLS1CRUdJTi...      # base64 encoded certificate
  tls.key: LS0tLS1CRUdJTi...      # base64 encoded private key

---
# Using with an Ingress
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: my-ingress
spec:
  tls:
  - hosts:
    - myapp.example.com
    secretName: tls-certificate          # Reference the TLS secret
  rules:
  - host: myapp.example.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: my-service
            port:
              number: 80
```

### Example 3: Docker Registry Secret

```yaml
# docker-registry-secret.yaml
---
apiVersion: v1
kind: Secret
metadata:
  name: acr-credentials
type: kubernetes.io/dockerconfigjson
data:
  # This is base64-encoded Docker config JSON
  .dockerconfigjson: eyJhdXRocyI6eyJteXJlZ2lzdHJ5LmF6dXJlY3IuaW8iOnsidXNlcm5hbWUiOiJteXVzZXIiLCJwYXNzd29yZCI6Im15cGFzc3dvcmQifX19

---
# Pod that pulls from private registry
apiVersion: v1
kind: Pod
metadata:
  name: private-app
spec:
  containers:
  - name: app
    image: myregistry.azurecr.io/myapp:latest
  imagePullSecrets:                        # Tell Kubernetes to use this secret
  - name: acr-credentials                  # for pulling the image
```

---

## Mermaid Diagram: Secret Lifecycle

```mermaid
flowchart TD
    A[Developer has sensitive data] --> B{How to create?}
    
    B -->|Command Line| C[kubectl create secret]
    B -->|YAML File| D[Write YAML with stringData]
    
    C --> E[Secret created in cluster]
    D --> F[kubectl apply -f secret.yaml]
    F --> E
    
    E --> G[Stored in etcd]
    G --> H{How does Pod use it?}
    
    H -->|Environment Variables| I[secretKeyRef in env]
    H -->|Volume Mount| J[secret volume type]
    
    I --> K[Container reads from ENV]
    J --> L[Container reads from files]
    
    K --> M[Application uses credentials]
    L --> M
    
    style A fill:#ffcdd2
    style E fill:#fff3e0
    style G fill:#e8f5e9
    style M fill:#c8e6c9
```

---

## Best Practices for Secret Management

### DO's

```yaml
# 1. Use RBAC to limit who can read secrets
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: secret-reader
rules:
- apiGroups: [""]
  resources: ["secrets"]
  resourceNames: ["my-app-secrets"]      # Only specific secrets
  verbs: ["get"]                         # Only read, not list or create
```

```bash
# 2. Enable encryption at rest in your cluster
# This encrypts secrets in etcd

# 3. Use namespaces to isolate secrets
kubectl create secret generic db-creds -n production
kubectl create secret generic db-creds -n staging

# 4. Rotate secrets regularly
# Update the secret, then restart pods to pick up new values

# 5. Don't log secrets!
# Avoid: echo $DB_PASSWORD in your app
```

### DON'Ts

```bash
# DON'T put secrets in Git (even base64 encoded!)
# Base64 is NOT encryption - anyone can decode it

# DON'T hardcode secrets in container images

# DON'T use kubectl get secret -o yaml in scripts
# (outputs decoded secrets to console/logs)

# DON'T give broad secret access
# Avoid: resources: ["secrets"] verbs: ["*"]
```

---

## External Secret Management (Production Best Practice)

For production, consider external secret managers:

```
+------------------+     +------------------+     +----------------+
|   External       |     |   Kubernetes     |     |     Pod        |
|   Secret Store   | --> |   Operator/CSI   | --> |   Container    |
+------------------+     +------------------+     +----------------+

Options:
- Azure Key Vault (with CSI driver)
- HashiCorp Vault
- AWS Secrets Manager
- Google Secret Manager
```

### Azure Key Vault Example (CSI Driver)

```yaml
# Using Azure Key Vault with CSI driver
apiVersion: v1
kind: Pod
metadata:
  name: my-app
spec:
  containers:
  - name: my-app
    image: my-app:1.0
    volumeMounts:
    - name: secrets-store
      mountPath: /mnt/secrets
      readOnly: true
  volumes:
  - name: secrets-store
    csi:
      driver: secrets-store.csi.k8s.io
      readOnly: true
      volumeAttributes:
        secretProviderClass: azure-keyvault-secrets
```

---

## Quick Reference Commands

```bash
# Create secrets
kubectl create secret generic NAME --from-literal=key=value
kubectl create secret generic NAME --from-file=key=/path/to/file
kubectl create secret tls NAME --cert=tls.crt --key=tls.key
kubectl create secret docker-registry NAME --docker-server=... 

# List secrets
kubectl get secrets

# View secret (shows base64 encoded)
kubectl get secret NAME -o yaml

# Decode a secret value
kubectl get secret NAME -o jsonpath='{.data.password}' | base64 --decode

# Describe (shows keys, not values)
kubectl describe secret NAME

# Delete secret
kubectl delete secret NAME

# Edit secret
kubectl edit secret NAME
```

---

## Security Checklist

| Item | Status | Notes |
|------|--------|-------|
| Encryption at rest enabled | [ ] | Check cluster config |
| RBAC rules configured | [ ] | Limit who can read secrets |
| Secrets not in Git | [ ] | Use .gitignore |
| External secret manager | [ ] | For production |
| Regular rotation | [ ] | Set up a schedule |
| Audit logging enabled | [ ] | Track secret access |

---

## Summary

| Aspect | Details |
|--------|---------|
| **What** | Secure storage for sensitive data |
| **Why** | Keep passwords/keys separate from code |
| **Types** | Opaque, TLS, docker-registry, basic-auth |
| **Create** | kubectl or YAML with stringData |
| **Use** | Environment variables or volume mounts |
| **Important** | Base64 != Encryption! Use external managers in production |

**Next up**: Learn about Volumes and Storage for persistent data!
