# ConfigMaps in Kubernetes

## What is a ConfigMap?

A **ConfigMap** is like a settings file for your application that lives outside your container. It stores **non-sensitive** configuration data as key-value pairs.

Think of it this way: Instead of hardcoding settings like "database host = localhost" inside your app, you put them in a ConfigMap. This way, you can change settings without rebuilding your container!

### Real-World Analogy

```
Imagine you have a TV remote (your app).
The remote needs to know which channel numbers map to which TV stations.
Instead of printing channel numbers directly on the remote buttons,
you have a separate channel guide (ConfigMap) that tells the remote:
  - Button 1 = HBO
  - Button 2 = Netflix
  - Button 3 = Disney+

If channels change, you just update the guide, not the remote!
```

---

## Why Use ConfigMaps?

```
+---------------------------+
|   WITHOUT ConfigMap       |
+---------------------------+
|                           |
|  Container Image          |
|  +---------------------+  |
|  | App Code            |  |
|  | DATABASE=localhost  | <-- Settings baked in!
|  | PORT=3000           |     Must rebuild image
|  | DEBUG=false         |     to change anything
|  +---------------------+  |
|                           |
+---------------------------+

+---------------------------+
|   WITH ConfigMap          |
+---------------------------+
|                           |
|  Container Image          |    ConfigMap
|  +------------------+     |    +------------------+
|  | App Code         |<----+--->| DATABASE=proddb  |
|  | (reads settings  |     |    | PORT=8080        |
|  |  at runtime)     |     |    | DEBUG=true       |
|  +------------------+     |    +------------------+
|                           |         ^
+---------------------------+         |
                              Easy to update!
```

---

## How ConfigMap Gets Injected into a Pod

```
                    +-------------------+
                    |    ConfigMap      |
                    |   "app-config"    |
                    +-------------------+
                    | DATABASE_URL=...  |
                    | LOG_LEVEL=info    |
                    | MAX_RETRIES=3     |
                    +---------+---------+
                              |
          +-------------------+-------------------+
          |                                       |
          v                                       v
   +------+------+                       +--------+--------+
   | As ENV Vars |                       | As Volume Files |
   +------+------+                       +--------+--------+
          |                                       |
          v                                       v
+-------------------+                   +-------------------+
|       Pod         |                   |       Pod         |
| +---------------+ |                   | +---------------+ |
| |   Container   | |                   | |   Container   | |
| | DATABASE_URL  | |                   | | /config/      | |
| | LOG_LEVEL     | |                   | |   db-url.txt  | |
| | MAX_RETRIES   | |                   | |   log.txt     | |
| +---------------+ |                   | +---------------+ |
+-------------------+                   +-------------------+
```

---

## How to Create ConfigMaps

### Method 1: From Literal Values (Command Line)

```bash
# Create a ConfigMap with key-value pairs directly
kubectl create configmap my-config \
  --from-literal=DATABASE_HOST=mysql.example.com \
  --from-literal=DATABASE_PORT=3306 \
  --from-literal=LOG_LEVEL=info
```

### Method 2: From a File

```bash
# If you have a config file like app.properties:
# DATABASE_HOST=mysql.example.com
# DATABASE_PORT=3306

kubectl create configmap my-config --from-file=app.properties
```

### Method 3: From YAML (Recommended for Production)

```yaml
# configmap.yaml
apiVersion: v1                    # Kubernetes API version
kind: ConfigMap                   # Type of resource we're creating
metadata:
  name: my-app-config             # Name of the ConfigMap (use this to reference it)
  namespace: default              # Namespace where it lives (default if not specified)
  labels:
    app: my-application           # Labels help organize and select resources
data:                             # This section contains your actual config data
  # Simple key-value pairs
  DATABASE_HOST: "mysql.example.com"   # Host for database connection
  DATABASE_PORT: "3306"                # Port (note: always strings in ConfigMaps!)
  LOG_LEVEL: "info"                    # Logging verbosity
  
  # You can also store entire config files
  app.properties: |                    # The | means multi-line string follows
    server.port=8080
    server.timeout=30
    feature.flag.newUI=true
  
  nginx.conf: |                        # Store an entire nginx config
    server {
        listen 80;
        server_name localhost;
        location / {
            proxy_pass http://backend:8080;
        }
    }
```

```bash
# Apply the ConfigMap to your cluster
kubectl apply -f configmap.yaml
```

---

## How to Use ConfigMaps in Pods

### Option 1: Inject as Environment Variables

```yaml
# pod-with-env-vars.yaml
apiVersion: v1
kind: Pod
metadata:
  name: my-app-pod
spec:
  containers:
  - name: my-app
    image: my-app:1.0
    
    # Method A: Load specific keys as environment variables
    env:
    - name: DB_HOST                    # Name of env var in container
      valueFrom:
        configMapKeyRef:
          name: my-app-config          # Name of the ConfigMap
          key: DATABASE_HOST           # Key to read from ConfigMap
    
    - name: DB_PORT
      valueFrom:
        configMapKeyRef:
          name: my-app-config
          key: DATABASE_PORT
    
    # Method B: Load ALL keys from ConfigMap as env vars
    envFrom:
    - configMapRef:
        name: my-app-config            # All keys become env vars automatically!
```

**How your app sees it:**
```bash
# Inside the container
echo $DB_HOST        # Output: mysql.example.com
echo $DATABASE_HOST  # Output: mysql.example.com (if using envFrom)
```

### Option 2: Mount as Files (Volume)

```yaml
# pod-with-volume.yaml
apiVersion: v1
kind: Pod
metadata:
  name: my-app-pod
spec:
  containers:
  - name: my-app
    image: my-app:1.0
    
    volumeMounts:
    - name: config-volume              # Must match volume name below
      mountPath: /etc/config           # Where files appear in container
      readOnly: true                   # Good practice: don't let app modify config
  
  volumes:
  - name: config-volume                # Name this volume
    configMap:
      name: my-app-config              # ConfigMap to mount
      # Optional: mount only specific keys
      items:
      - key: nginx.conf                # Key from ConfigMap
        path: nginx.conf               # Filename in the mounted directory
```

**Result inside container:**
```
/etc/config/
├── DATABASE_HOST      # Contains: mysql.example.com
├── DATABASE_PORT      # Contains: 3306
├── LOG_LEVEL          # Contains: info
├── app.properties     # Contains the multi-line properties
└── nginx.conf         # Contains the nginx configuration
```

---

## Complete Working Example

Let's create a web app that reads config from a ConfigMap:

```yaml
# complete-example.yaml

# Step 1: Create the ConfigMap
---
apiVersion: v1
kind: ConfigMap
metadata:
  name: webapp-config
data:
  # App settings
  APP_NAME: "My Awesome App"
  APP_VERSION: "2.1.0"
  ENVIRONMENT: "production"
  
  # Feature flags
  ENABLE_DARK_MODE: "true"
  ENABLE_NOTIFICATIONS: "false"
  
  # A config file
  settings.json: |
    {
      "maxUsers": 1000,
      "sessionTimeout": 3600,
      "allowRegistration": true
    }

---
# Step 2: Create a Pod that uses it
apiVersion: v1
kind: Pod
metadata:
  name: webapp
  labels:
    app: webapp
spec:
  containers:
  - name: webapp
    image: nginx:alpine              # Using nginx as example
    ports:
    - containerPort: 80
    
    # Load environment variables from ConfigMap
    envFrom:
    - configMapRef:
        name: webapp-config
    
    # Also mount as files
    volumeMounts:
    - name: config-files
      mountPath: /usr/share/nginx/html/config
      readOnly: true
  
  volumes:
  - name: config-files
    configMap:
      name: webapp-config
      items:
      - key: settings.json
        path: settings.json
```

```bash
# Apply everything
kubectl apply -f complete-example.yaml

# Verify ConfigMap was created
kubectl get configmap webapp-config

# See the contents
kubectl describe configmap webapp-config

# Check environment variables in the pod
kubectl exec webapp -- env | grep -E 'APP_|ENABLE_'

# Check mounted file
kubectl exec webapp -- cat /usr/share/nginx/html/config/settings.json
```

---

## Mermaid Diagram: ConfigMap Lifecycle

```mermaid
flowchart TD
    A[Developer creates ConfigMap YAML] --> B[kubectl apply]
    B --> C[ConfigMap stored in etcd]
    C --> D{How to use?}
    
    D -->|Environment Variables| E[Pod reads ENV at startup]
    D -->|Volume Mount| F[Pod reads files from mount path]
    
    E --> G[Container runs with config]
    F --> G
    
    H[Update ConfigMap] --> C
    H -.->|ENV vars| I[Requires Pod restart]
    H -.->|Volume mount| J[Auto-updates! No restart needed*]
    
    style A fill:#e1f5fe
    style C fill:#fff3e0
    style G fill:#e8f5e9
    style J fill:#c8e6c9
    style I fill:#ffcdd2
```

*Note: Volume-mounted ConfigMaps update automatically (may take up to 1 minute), but your app needs to watch for file changes to pick up new values.

---

## Quick Reference Commands

```bash
# Create ConfigMap from literals
kubectl create configmap NAME --from-literal=key=value

# Create from file
kubectl create configmap NAME --from-file=path/to/file

# Create from directory (each file becomes a key)
kubectl create configmap NAME --from-file=path/to/dir/

# List all ConfigMaps
kubectl get configmaps
kubectl get cm                    # Short form

# View ConfigMap details
kubectl describe configmap NAME

# Get ConfigMap as YAML
kubectl get configmap NAME -o yaml

# Edit ConfigMap directly
kubectl edit configmap NAME

# Delete ConfigMap
kubectl delete configmap NAME
```

---

## Important Notes

1. **ConfigMaps are for NON-SENSITIVE data only** - Use Secrets for passwords, API keys, etc.

2. **Size limit**: ConfigMaps can't exceed 1 MB

3. **Pod restart behavior**:
   - Environment variables: Pod must restart to see changes
   - Volume mounts: Updates automatically (with slight delay)

4. **Namespace-bound**: ConfigMaps exist in a namespace and can only be used by Pods in the same namespace

---

## Summary

| Feature | Description |
|---------|-------------|
| **What** | Key-value store for configuration |
| **Why** | Separate config from code |
| **When** | Non-sensitive settings, feature flags, config files |
| **How** | Environment variables or volume mounts |
| **Where** | Stored in etcd, accessed by Pods |

**Next up**: Learn about Secrets for storing sensitive data like passwords!
