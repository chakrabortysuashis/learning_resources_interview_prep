# Volumes and Storage in Kubernetes

## Why Do We Need Volumes?

Containers are **ephemeral** (temporary) by nature. When a container crashes or restarts, all data inside it is **lost forever**!

### The Problem

```
Container Lifecycle (Without Volumes):

Time 0:          Time 1:          Time 2:
+----------+     +----------+     +----------+
| Container|     | Container|     | Container|
|          |     |          |     |          |
| data.txt |     | data.txt |     |          | <-- Data gone!
| user.db  |     | user.db  |     |          |
+----------+     +----------+     +----------+
   Running        Crashes!         Restarts
                   |
                   v
              All data lost!
```

### Real-World Analogy

```
Think of containers like a whiteboard:
- You can write anything on it (store data)
- When you erase and start fresh (container restart), everything is gone!

A Volume is like a notebook:
- You write in it
- Even if you switch whiteboards, the notebook stays
- Your notes survive!

More technical analogy:
- Container = Computer's RAM (temporary, cleared on restart)
- Volume = USB Drive (survives computer restart, can be moved between computers)
```

---

## Volume Types Overview

```
+------------------------------------------------------------------+
|                     Kubernetes Volume Types                       |
+------------------------------------------------------------------+
|                                                                   |
|  TEMPORARY                    PERSISTENT                          |
|  +---------+                  +----------------------------------+|
|  |emptyDir |                  | PersistentVolume (PV)            ||
|  +---------+                  |   - Azure Disk                   ||
|       |                       |   - Azure Files                  ||
|       v                       |   - AWS EBS                      ||
|  Lives as long as             |   - GCE Persistent Disk          ||
|  Pod lives                    |   - NFS                          ||
|                               +----------------------------------+|
|                                                                   |
|  NODE-SPECIFIC                NETWORK-BASED                       |
|  +----------+                 +---------------------------------+ |
|  | hostPath |                 | NFS, iSCSI, Ceph, GlusterFS     | |
|  +----------+                 +---------------------------------+ |
|       |                                                           |
|       v                                                           |
|  Tied to specific node                                            |
|  (NOT recommended for                                             |
|  production!)                                                     |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Type 1: emptyDir (Temporary Storage)

An `emptyDir` volume is created when a Pod starts and exists as long as the Pod is running. Perfect for:
- Scratch space
- Sharing data between containers in the same Pod
- Caching

```yaml
# emptydir-example.yaml
apiVersion: v1
kind: Pod
metadata:
  name: cache-pod
spec:
  containers:
  - name: app
    image: nginx
    volumeMounts:
    - name: cache-volume           # Mount the volume here
      mountPath: /cache            # This directory in the container
  
  - name: sidecar                  # Second container in same Pod
    image: busybox
    command: ['sh', '-c', 'while true; do date >> /shared/time.log; sleep 5; done']
    volumeMounts:
    - name: cache-volume           # Same volume name = shared!
      mountPath: /shared           # Different path in this container
  
  volumes:
  - name: cache-volume
    emptyDir: {}                   # Creates empty directory when Pod starts
    # emptyDir:
    #   sizeLimit: 500Mi          # Optional: limit size
    #   medium: Memory            # Optional: use RAM (faster but limited)
```

```
+--------------------Pod--------------------+
|                                           |
|  +-------------+     +-------------+      |
|  | Container 1 |     | Container 2 |      |
|  | /cache      |<--->| /shared     |      |
|  +------+------+     +------+------+      |
|         |                   |             |
|         +-------+   +-------+             |
|                 |   |                     |
|            +----v---v----+                |
|            |  emptyDir   |                |
|            | (shared     |                |
|            |  storage)   |                |
|            +-------------+                |
|                                           |
+-------------------------------------------+
          Lives only while Pod lives!
```

---

## Type 2: hostPath (Node-Local Storage)

`hostPath` mounts a file or directory from the host node's filesystem. **Use with caution!**

```yaml
# hostpath-example.yaml
apiVersion: v1
kind: Pod
metadata:
  name: hostpath-pod
spec:
  containers:
  - name: app
    image: nginx
    volumeMounts:
    - name: host-data
      mountPath: /data             # Path in container
  
  volumes:
  - name: host-data
    hostPath:
      path: /mnt/data              # Path on the host machine
      type: DirectoryOrCreate      # Create if doesn't exist
      # Types:
      # - Directory: must exist
      # - DirectoryOrCreate: create if missing
      # - File: must exist
      # - FileOrCreate: create if missing
```

```
        Node 1                          Node 2
+-------------------+            +-------------------+
| Host Filesystem   |            | Host Filesystem   |
| /mnt/data [DATA]  |            | /mnt/data [EMPTY] |
+--------+----------+            +-------------------+
         |
         | hostPath mount
         v
+--------+--------+
|      Pod        |
| /data [sees     |
|  /mnt/data from |
|  Node 1]        |
+-----------------+

WARNING: If Pod moves to Node 2, it loses access to Node 1's data!
Use only for special cases like accessing Docker socket or node logs.
```

---

## Type 3: PersistentVolume and PersistentVolumeClaim

This is the **production-ready** way to handle storage!

### The Three Players

```
+------------------------------------------------------------------+
|                    Storage Architecture                           |
+------------------------------------------------------------------+
|                                                                   |
|    DEVELOPER                   ADMIN                    CLOUD     |
|    (You)                       (Cluster Admin)          PROVIDER  |
|                                                                   |
|  +--------+                  +---------------+      +----------+  |
|  |  Pod   |                  | Persistent    |      | Actual   |  |
|  |        |                  | Volume (PV)   |      | Storage  |  |
|  +---+----+                  +-------+-------+      | (Disk)   |  |
|      |                               |              +-----+----+  |
|      | "I need                       | Connects           |       |
|      |  10GB of                      | to actual          |       |
|      |  storage"                     | storage            |       |
|      |                               |                    |       |
|      v                               |                    |       |
|  +---+----------------+              |                    |       |
|  | PersistentVolume   |              |                    |       |
|  | Claim (PVC)        +--------------+--------------------+       |
|  | "Requesting 10GB"  |                                           |
|  +--------------------+                                           |
|                                                                   |
+------------------------------------------------------------------+

Think of it like renting an apartment:
- PV = The actual apartment (created by building owner/admin)
- PVC = Your rental application (I need 2 bedrooms, downtown)
- Binding = Lease agreement (this apartment matches your request!)
- Pod = You moving in and using the apartment
```

---

## Understanding PV, PVC, and StorageClass

### Step-by-Step Flow

```
       1. Admin creates PV          2. Developer creates PVC
      (or dynamic provisioning)

    +------------------+          +------------------+
    | PersistentVolume |          | PersistentVolume |
    | Name: pv-azure   |          | Claim            |
    | Size: 100Gi      |          | Name: my-claim   |
    | Type: Azure Disk |          | Size: 50Gi       |
    +--------+---------+          | Type: any        |
             |                    +--------+---------+
             |                             |
             |    3. Kubernetes            |
             |       BINDS them            |
             +------------+----------------+
                          |
                          v
                   +--------------+
                   | Bound State  |
                   | PVC -> PV    |
                   +--------------+
                          |
                          | 4. Pod mounts PVC
                          v
                   +------+------+
                   |    Pod      |
                   | /data mount |
                   +-------------+
```

---

## YAML Examples

### Manual PV and PVC

```yaml
# 1-persistent-volume.yaml
# Usually created by cluster admin
apiVersion: v1
kind: PersistentVolume
metadata:
  name: my-pv                          # Name of the PV
  labels:
    type: local                        # Labels for selection
spec:
  capacity:
    storage: 10Gi                      # Total size available
  
  accessModes:
    - ReadWriteOnce                    # RWO: single node read/write
    # - ReadOnlyMany                   # ROX: multiple nodes read-only
    # - ReadWriteMany                  # RWX: multiple nodes read/write
  
  persistentVolumeReclaimPolicy: Retain  # What happens when PVC is deleted
    # Retain: keep data (manual cleanup)
    # Delete: delete the storage
    # Recycle: deprecated, don't use
  
  storageClassName: manual             # Must match PVC's storageClassName
  
  # For local testing (hostPath)
  hostPath:
    path: /mnt/data
  
  # For Azure Disk (production)
  # azureDisk:
  #   diskName: myAKSDisk
  #   diskURI: /subscriptions/.../myAKSDisk
```

```yaml
# 2-persistent-volume-claim.yaml
# Created by developers
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: my-pvc                         # Name to use in Pod
spec:
  accessModes:
    - ReadWriteOnce                    # Must match or be subset of PV
  
  resources:
    requests:
      storage: 5Gi                     # How much you need (must be <= PV size)
  
  storageClassName: manual             # Must match PV's storageClassName
  
  # Optional: select specific PV by label
  selector:
    matchLabels:
      type: local
```

```yaml
# 3-pod-with-pvc.yaml
apiVersion: v1
kind: Pod
metadata:
  name: my-app
spec:
  containers:
  - name: app
    image: nginx
    volumeMounts:
    - name: storage                    # Must match volume name below
      mountPath: /usr/share/nginx/html # Where to mount in container
  
  volumes:
  - name: storage
    persistentVolumeClaim:
      claimName: my-pvc                # Reference to your PVC
```

---

## StorageClass: Dynamic Provisioning

Instead of manually creating PVs, use StorageClass to **automatically** create them!

```yaml
# storageclass-azure.yaml
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: azure-standard                 # Name to reference in PVC
provisioner: kubernetes.io/azure-disk  # Who provisions storage
parameters:
  storageaccounttype: Standard_LRS     # Standard HDD
  kind: Managed                        # Azure Managed Disk
reclaimPolicy: Delete                  # Delete disk when PVC deleted
volumeBindingMode: WaitForFirstConsumer # Wait until Pod needs it
allowVolumeExpansion: true             # Allow resizing later
```

```yaml
# pvc-dynamic.yaml
# Just create PVC, PV is auto-created!
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: dynamic-pvc
spec:
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 20Gi
  storageClassName: azure-standard     # Reference StorageClass
  # Kubernetes automatically creates a 20Gi Azure Disk!
```

---

## Complete Flow Diagram

```
+----------------------------------------------------------------------+
|                    Dynamic Storage Provisioning                       |
+----------------------------------------------------------------------+
|                                                                       |
|   1. StorageClass         2. PVC Created       3. PV Auto-Created    |
|   (already exists)                                                    |
|                                                                       |
|   +---------------+       +---------------+     +-----------------+   |
|   | StorageClass  |       | PVC           |     | PV (dynamic)    |   |
|   | azure-premium |<------| storageClass: |---->| Created by      |   |
|   | provisioner:  |       |   azure-prem  |     | Azure/K8s       |   |
|   | azure-disk    |       | size: 100Gi   |     | size: 100Gi     |   |
|   +---------------+       +-------+-------+     +--------+--------+   |
|                                   |                      |            |
|                                   | 4. Bound             |            |
|                                   +----------------------+            |
|                                             |                         |
|                                             v                         |
|                                   +---------+----------+              |
|                                   |        Pod         |              |
|                                   | volumeMounts:      |              |
|                                   |   - name: data     |              |
|                                   |     mountPath:     |              |
|                                   |       /var/data    |              |
|                                   +--------------------+              |
|                                             |                         |
|                                             v                         |
|                                   +--------------------+              |
|                                   |    Azure Disk      |              |
|                                   |    (actual         |              |
|                                   |     storage)       |              |
|                                   +--------------------+              |
|                                                                       |
+----------------------------------------------------------------------+
```

---

## Azure-Specific Storage Options

### Azure Disk

```yaml
# Best for: Single pod, high performance
# Access Mode: ReadWriteOnce only

apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: azure-disk-premium
provisioner: disk.csi.azure.com        # CSI driver (modern)
parameters:
  skuName: Premium_LRS                 # Premium SSD
  # Options: Standard_LRS, Premium_LRS, StandardSSD_LRS, UltraSSD_LRS
volumeBindingMode: WaitForFirstConsumer
allowVolumeExpansion: true
```

### Azure Files

```yaml
# Best for: Shared access across multiple pods
# Access Mode: ReadWriteMany supported!

apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: azure-files-standard
provisioner: file.csi.azure.com
parameters:
  skuName: Standard_LRS
  # Options: Standard_LRS, Standard_GRS, Premium_LRS
mountOptions:
  - dir_mode=0777
  - file_mode=0777
  - uid=1000
  - gid=1000
```

### When to Use What?

```
+-------------------+------------------+------------------+
|     Feature       |   Azure Disk     |   Azure Files    |
+-------------------+------------------+------------------+
| Access Mode       | ReadWriteOnce    | ReadWriteMany    |
| Performance       | Higher (SSD)     | Lower (network)  |
| Multi-pod access  | No               | Yes!             |
| Use case          | Databases        | Shared content   |
|                   | Single workloads | Multiple replicas|
| Protocol          | Block storage    | SMB/NFS          |
+-------------------+------------------+------------------+
```

---

## Mermaid Diagram: Storage Architecture

```mermaid
flowchart TB
    subgraph "Developer's World"
        POD[Pod<br/>needs storage]
        PVC[PersistentVolumeClaim<br/>Request: 50Gi]
    end
    
    subgraph "Kubernetes Control"
        SC[StorageClass<br/>azure-premium]
        PV[PersistentVolume<br/>Dynamically Created]
    end
    
    subgraph "Azure Cloud"
        AD[Azure Disk<br/>or Azure Files]
    end
    
    POD -->|mounts| PVC
    PVC -->|uses| SC
    SC -->|provisions| PV
    PV -->|binds to| PVC
    PV -->|represents| AD
    
    style POD fill:#e3f2fd
    style PVC fill:#fff3e0
    style SC fill:#f3e5f5
    style PV fill:#e8f5e9
    style AD fill:#fce4ec
```

---

## Complete Working Example

```yaml
# complete-storage-example.yaml
---
# StorageClass (usually pre-configured in AKS)
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: fast-storage
provisioner: disk.csi.azure.com
parameters:
  skuName: Premium_LRS
allowVolumeExpansion: true
volumeBindingMode: WaitForFirstConsumer

---
# PVC requesting storage
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: database-storage
spec:
  accessModes:
    - ReadWriteOnce
  storageClassName: fast-storage
  resources:
    requests:
      storage: 50Gi

---
# StatefulSet using the storage
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: postgres
spec:
  serviceName: postgres
  replicas: 1
  selector:
    matchLabels:
      app: postgres
  template:
    metadata:
      labels:
        app: postgres
    spec:
      containers:
      - name: postgres
        image: postgres:15
        env:
        - name: POSTGRES_PASSWORD
          valueFrom:
            secretKeyRef:
              name: postgres-secret
              key: password
        - name: PGDATA
          value: /var/lib/postgresql/data/pgdata
        ports:
        - containerPort: 5432
        volumeMounts:
        - name: postgres-data
          mountPath: /var/lib/postgresql/data
      volumes:
      - name: postgres-data
        persistentVolumeClaim:
          claimName: database-storage

---
# Service for accessing Postgres
apiVersion: v1
kind: Service
metadata:
  name: postgres
spec:
  ports:
  - port: 5432
  selector:
    app: postgres
```

---

## Access Modes Explained

```
+------------------------------------------------------------------+
|                        Access Modes                               |
+------------------------------------------------------------------+
|                                                                   |
|  ReadWriteOnce (RWO)                                             |
|  +----------+                                                     |
|  |   Node   |     Only ONE node can mount for read/write         |
|  | +------+ |     Most common, used for databases                |
|  | | Pod  | |                                                     |
|  | |  RW  | |                                                     |
|  | +------+ |                                                     |
|  +----------+                                                     |
|                                                                   |
|  ReadOnlyMany (ROX)                                              |
|  +--------+  +--------+  +--------+                              |
|  | Node 1 |  | Node 2 |  | Node 3 |  Many nodes read-only       |
|  | +----+ |  | +----+ |  | +----+ |  Good for shared configs    |
|  | | RO | |  | | RO | |  | | RO | |                              |
|  | +----+ |  | +----+ |  | +----+ |                              |
|  +--------+  +--------+  +--------+                              |
|                                                                   |
|  ReadWriteMany (RWX)                                             |
|  +--------+  +--------+  +--------+                              |
|  | Node 1 |  | Node 2 |  | Node 3 |  Many nodes read/write      |
|  | +----+ |  | +----+ |  | +----+ |  Requires special storage   |
|  | | RW | |  | | RW | |  | | RW | |  (NFS, Azure Files)         |
|  | +----+ |  | +----+ |  | +----+ |                              |
|  +--------+  +--------+  +--------+                              |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Quick Reference Commands

```bash
# PersistentVolumes
kubectl get pv                         # List all PVs
kubectl describe pv PV_NAME            # Details of a PV
kubectl delete pv PV_NAME              # Delete a PV

# PersistentVolumeClaims
kubectl get pvc                        # List all PVCs
kubectl describe pvc PVC_NAME          # Details of a PVC
kubectl delete pvc PVC_NAME            # Delete a PVC

# StorageClasses
kubectl get storageclass               # List StorageClasses
kubectl get sc                         # Short form
kubectl describe sc CLASSNAME          # Details

# Check what's mounted in a pod
kubectl exec POD_NAME -- df -h         # Shows mounted volumes
kubectl exec POD_NAME -- ls -la /path  # List files in mount

# Troubleshooting
kubectl get events --sort-by=.metadata.creationTimestamp
kubectl describe pod POD_NAME | grep -A 10 "Volumes:"
```

---

## Common Issues and Solutions

| Problem | Cause | Solution |
|---------|-------|----------|
| PVC stuck in `Pending` | No matching PV | Check StorageClass exists, check PV labels |
| Pod stuck in `Pending` | PVC not bound | Wait for PV provisioning or create PV manually |
| "Multi-attach error" | RWO volume on multiple nodes | Use RWX storage or single replica |
| Permission denied | Wrong file permissions | Set `fsGroup` in securityContext |
| Disk resize failed | `allowVolumeExpansion: false` | Update StorageClass |

---

## Summary

| Concept | Description |
|---------|-------------|
| **Volume** | Way to persist data beyond container lifecycle |
| **emptyDir** | Temporary, pod-level storage |
| **hostPath** | Node-local, not portable (avoid in prod) |
| **PersistentVolume (PV)** | Actual storage resource in cluster |
| **PersistentVolumeClaim (PVC)** | Request for storage by developer |
| **StorageClass** | Template for dynamic PV provisioning |
| **Azure Disk** | High performance, single-pod access |
| **Azure Files** | Shared access across multiple pods |

```
Your Data Journey:
  
  [App writes data] 
        |
        v
  [Container filesystem - TEMPORARY!]
        |
        v (mount volume)
  [PVC - Your request]
        |
        v (bound)
  [PV - Kubernetes abstraction]
        |
        v (backed by)
  [Azure Disk/Files - PERSISTENT!]
        
  Even if container restarts, your data survives!
```

**Congratulations!** You now understand how Kubernetes handles configuration and storage!
