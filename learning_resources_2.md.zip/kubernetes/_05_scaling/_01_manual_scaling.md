# Manual Scaling in Kubernetes

## What is Manual Scaling?

Manual scaling means YOU decide when to add or remove pod replicas. You run a command, and Kubernetes adjusts the number of pods accordingly.

Think of it like a restaurant manager who manually calls in more waiters when they SEE the restaurant getting busy, rather than having an automated system do it.

```
BEFORE SCALING (2 replicas):
+------------------+
|   Deployment     |
|   "my-app"       |
+------------------+
        |
        v
   +---------+    +---------+
   |  Pod 1  |    |  Pod 2  |
   +---------+    +---------+

AFTER SCALING (5 replicas):
+------------------+
|   Deployment     |
|   "my-app"       |
+------------------+
        |
        v
+---------+ +---------+ +---------+ +---------+ +---------+
|  Pod 1  | |  Pod 2  | |  Pod 3  | |  Pod 4  | |  Pod 5  |
+---------+ +---------+ +---------+ +---------+ +---------+
```

---

## How to Manually Scale

### Using kubectl scale Command

The most common way to scale manually:

```bash
# Scale deployment to 5 replicas
kubectl scale deployment my-app --replicas=5

# Scale deployment in a specific namespace
kubectl scale deployment my-app --replicas=5 -n production

# Scale multiple deployments at once
kubectl scale deployment app1 app2 app3 --replicas=3
```

### Using kubectl edit

You can also edit the deployment directly:

```bash
kubectl edit deployment my-app
```

Then change the `replicas` field in the YAML that opens.

### Using kubectl patch

For scripting or automation:

```bash
kubectl patch deployment my-app -p '{"spec":{"replicas":5}}'
```

### Using kubectl apply

If you have a YAML file, just change the replicas and apply:

```yaml
# my-app-deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: my-app
spec:
  replicas: 5    # Changed from 2 to 5
  selector:
    matchLabels:
      app: my-app
  template:
    metadata:
      labels:
        app: my-app
    spec:
      containers:
      - name: my-app
        image: my-app:1.0
```

```bash
kubectl apply -f my-app-deployment.yaml
```

---

## Verifying the Scale Operation

```bash
# Check deployment status
kubectl get deployment my-app

# Watch pods come up in real-time
kubectl get pods -l app=my-app -w

# Get detailed deployment info
kubectl describe deployment my-app
```

Example output:

```
NAME     READY   UP-TO-DATE   AVAILABLE   AGE
my-app   5/5     5            5           10m
```

---

## When is Manual Scaling Appropriate?

### Good Use Cases

```
+--------------------------------------------------+
|           WHEN MANUAL SCALING WORKS              |
+--------------------------------------------------+
|                                                  |
|  [x] Predictable traffic patterns                |
|      - You KNOW Black Friday is coming           |
|      - You KNOW a marketing email goes out at 9am|
|                                                  |
|  [x] One-time events                             |
|      - Product launch day                        |
|      - Live streaming event                      |
|                                                  |
|  [x] Development/Testing environments            |
|      - Scale down at night to save costs         |
|      - Scale up for load testing                 |
|                                                  |
|  [x] Small teams with simple apps                |
|      - Few services to manage                    |
|      - Traffic patterns are well understood      |
|                                                  |
|  [x] Cost-sensitive scenarios                    |
|      - You want explicit control over resources  |
|      - Autoscaling might scale too aggressively  |
|                                                  |
+--------------------------------------------------+
```

### Real-World Example

```
Monday 9am: Marketing sends email blast
           You KNOW traffic will spike

Timeline:
---------
8:45am  ->  kubectl scale deployment api --replicas=10
9:00am  ->  Email sent, traffic spikes
10:30am ->  Traffic normalizes
11:00am ->  kubectl scale deployment api --replicas=3
```

---

## Limitations of Manual Scaling

```
+--------------------------------------------------+
|        PROBLEMS WITH MANUAL SCALING              |
+--------------------------------------------------+
|                                                  |
|  [!] Reactive, not proactive                     |
|      - By the time you notice, users are         |
|        already experiencing slowness             |
|                                                  |
|  [!] Requires human intervention                 |
|      - What if spike happens at 3am?             |
|      - What if you're on vacation?               |
|                                                  |
|  [!] Slow response time                          |
|      - Human notices problem -> runs command     |
|        -> pods start -> pods become ready        |
|      - Could be 5-10 minutes of degraded service |
|                                                  |
|  [!] Risk of over/under provisioning             |
|      - Scale too little = poor performance       |
|      - Scale too much = wasted money             |
|                                                  |
|  [!] Doesn't scale well (ironically)             |
|      - Managing 5 services manually = OK         |
|      - Managing 50 services manually = nightmare |
|                                                  |
+--------------------------------------------------+
```

### The 3am Problem

```
            Manual Scaling Timeline
            
    USER EXPERIENCE DURING A TRAFFIC SPIKE
    
Time:     3:00am     3:05am     3:15am     3:25am     3:35am
          |          |          |          |          |
          v          v          v          v          v
Traffic:  ******     *********  **************       ****
          Normal     Spike!     Still High           Normal

Pods:     [2]        [2]        [2]        [5]       [5]
          
Status:   OK         SLOW!      SLOW!      OK        OK (but costly)
                     ^          ^          ^
                     |          |          |
              No one notices    On-call    Finally
                               wakes up    scaled!
                               
Result: 20+ minutes of poor user experience
```

---

## Scaling Down Considerations

When scaling DOWN, be careful:

```
SCALING DOWN FROM 5 TO 2 PODS
=============================

Kubernetes will terminate 3 pods.

But what if those pods are:
- Processing a request?
- Holding a database connection?
- In the middle of a transaction?

SOLUTION: Use proper pod lifecycle hooks

spec:
  containers:
  - name: my-app
    lifecycle:
      preStop:
        exec:
          command: ["/bin/sh", "-c", "sleep 10"]
    # Also set terminationGracePeriodSeconds
  terminationGracePeriodSeconds: 30
```

---

## Quick Reference

```
+----------------------------------------------------------+
|              MANUAL SCALING CHEAT SHEET                  |
+----------------------------------------------------------+
| ACTION                    | COMMAND                      |
+----------------------------------------------------------+
| Scale to N replicas       | kubectl scale deploy X       |
|                           |   --replicas=N               |
+----------------------------------------------------------+
| Scale to 0 (stop app)     | kubectl scale deploy X       |
|                           |   --replicas=0               |
+----------------------------------------------------------+
| Check current replicas    | kubectl get deploy X         |
+----------------------------------------------------------+
| Watch scaling progress    | kubectl get pods -w          |
+----------------------------------------------------------+
| Scale in namespace        | kubectl scale deploy X       |
|                           |   --replicas=N -n NAMESPACE  |
+----------------------------------------------------------+
```

---

## When to Move Beyond Manual Scaling

Consider autoscaling (HPA, VPA, or KEDA) when:

1. **Traffic is unpredictable** - You can't anticipate spikes
2. **24/7 availability matters** - No one can watch it constantly  
3. **Cost optimization is important** - Auto scale-down saves money
4. **You have many services** - Manual management becomes impossible
5. **Response time matters** - Autoscaler reacts in seconds, humans in minutes

---

## Summary

```
MANUAL SCALING
==============
Pros:                          Cons:
+ Simple to understand         - Reactive, not proactive
+ Full control                 - Requires human intervention  
+ No additional setup          - Slow response to spikes
+ Good for predictable loads   - Doesn't scale to many services
+ Works everywhere             - Risk of over/under provisioning
```

**Next up:** Learn about Horizontal Pod Autoscaler (HPA) which automatically scales your pods based on metrics!
