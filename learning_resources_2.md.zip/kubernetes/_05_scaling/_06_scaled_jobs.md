# ScaledJob: KEDA Resource for Scaling Jobs

## What is a ScaledJob?

A **ScaledJob** is a KEDA custom resource that creates and manages Kubernetes **Jobs** based on events. Unlike ScaledObject (which scales long-running Deployments), ScaledJob creates short-lived Jobs to process work.

```
KEY DIFFERENCE:
===============

ScaledObject                          ScaledJob
------------                          ---------
Scales: Deployments                   Creates: Jobs
Pods: Long-running                    Pods: Run-to-completion
Workers: Stay alive                   Workers: Process & exit
Best for: Continuous services         Best for: Batch processing


ANALOGY:
========

ScaledObject = Restaurant Staff
- Waiters come to work and stay all day
- Handle multiple customers over time
- Shift ends, they go home (scale down)

ScaledJob = Food Delivery Drivers  
- Get assigned ONE delivery
- Complete the delivery
- Done. Job finished. Driver "disappears"
- New delivery = new driver created
```

---

## When to Use ScaledJob vs ScaledObject

```
+------------------------------------------------------------------+
|              SCALEDOBJECT VS SCALEDJOB DECISION                  |
+------------------------------------------------------------------+

USE SCALEDOBJECT WHEN:
----------------------
[x] Application runs continuously
[x] Processes multiple items over time
[x] Maintains connections (DB, cache, etc.)
[x] Has startup overhead you want to avoid

Examples:
- Web API server
- Message consumer that processes forever
- Real-time data processor


USE SCALEDJOB WHEN:
-------------------
[x] Each task is independent
[x] Task has clear start and end
[x] Want isolation between task executions
[x] Don't need to maintain state between tasks

Examples:
- Video encoding
- Report generation
- Data migration tasks
- Image processing
- One-off calculations

+------------------------------------------------------------------+
```

### Visual Comparison

```
SCALEDOBJECT: Long-Running Workers
==================================

Time:     |----1----|----2----|----3----|----4----|
Messages: M1 M2 M3   M4 M5     M6        (empty)

Pod 1:    [=== processing M1, M2 ===][=== M4, M5 ===][ idle ]
Pod 2:    [=== processing M3 ========][=== M6 ======][ idle ]

- Same pods handle multiple messages
- Pods stay alive between messages
- Scale by adding/removing pods


SCALEDJOB: One Job Per Task
===========================

Time:     |----1----|----2----|----3----|----4----|
Messages: M1 M2 M3   M4 M5     M6        (empty)

Job 1:    [M1 done]
Job 2:    [M2 done]
Job 3:    [===== M3 done ====]
Job 4:              [M4 done]
Job 5:              [M5 done]
Job 6:                        [M6 done]

- New Job created for each message
- Job completes and terminates
- No idle pods (cost efficient!)
```

---

## How ScaledJob Works

```
SCALEDJOB FLOW
==============

1. DETECT EVENTS
+------------------+
| Azure Service Bus|
| Queue: 5 messages|
+------------------+
        |
        v
2. KEDA CALCULATES
+------------------+
| ScaledJob        |
| "Need 5 jobs"    |
+------------------+
        |
        v
3. CREATE JOBS
+------------------+
| Kubernetes API   |
| Create Job 1     |
| Create Job 2     |
| Create Job 3     |
| Create Job 4     |
| Create Job 5     |
+------------------+
        |
        v
4. JOBS RUN
+------+ +------+ +------+ +------+ +------+
| Job1 | | Job2 | | Job3 | | Job4 | | Job5 |
| Pod  | | Pod  | | Pod  | | Pod  | | Pod  |
+------+ +------+ +------+ +------+ +------+
    |        |        |        |        |
    v        v        v        v        v
5. PROCESS & COMPLETE
[done]   [done]   [done]   [done]   [done]

Jobs finish, pods terminate, queue is empty!
```

---

## ScaledJob Architecture

```
+------------------------------------------------------------------+
|                   SCALEDJOB ARCHITECTURE                         |
+------------------------------------------------------------------+

         Queue / Event Source
         +------------------+
         | 10 messages      |
         +--------+---------+
                  |
                  | KEDA polls
                  v
         +------------------+
         | ScaledJob        |  <-- You define this
         | Config:          |
         | - maxJobs: 5     |
         | - trigger: queue |
         +--------+---------+
                  |
                  | KEDA creates Jobs
                  v
    +------+ +------+ +------+ +------+ +------+
    | Job1 | | Job2 | | Job3 | | Job4 | | Job5 |
    | Pod  | | Pod  | | Pod  | | Pod  | | Pod  |
    +------+ +------+ +------+ +------+ +------+
         \      \       |       /      /
          \      \      |      /      /
           v      v     v     v      v
         +---------------------------+
         | Each Job processes 2 msgs |
         | (10 msgs / 5 jobs = 2)    |
         +---------------------------+
                  |
                  v
         +------------------+
         | Jobs complete    |
         | Pods terminate   |
         | Queue is empty   |
         +------------------+

+------------------------------------------------------------------+
```

### Mermaid Flowchart

```mermaid
flowchart TB
    subgraph "Event Source"
        Q[Queue with Messages]
    end
    
    subgraph "KEDA"
        SJ[ScaledJob]
        KO[KEDA Operator]
    end
    
    subgraph "Kubernetes"
        J1[Job 1]
        J2[Job 2]
        J3[Job 3]
        P1[Pod 1]
        P2[Pod 2]
        P3[Pod 3]
    end
    
    Q --> KO
    SJ --> KO
    KO --> J1
    KO --> J2
    KO --> J3
    J1 --> P1
    J2 --> P2
    J3 --> P3
    P1 --> |"Process & Exit"| Q
    P2 --> |"Process & Exit"| Q
    P3 --> |"Process & Exit"| Q
```

---

## Basic ScaledJob Example

```yaml
# video-processor-scaledjob.yaml
apiVersion: keda.sh/v1alpha1
kind: ScaledJob
metadata:
  name: video-processor
  namespace: production
spec:
  # ============================================================
  # JOB TEMPLATE - What Job should KEDA create?
  # ============================================================
  jobTargetRef:
    parallelism: 1                    # Pods per Job
    completions: 1                    # How many completions = Job done
    backoffLimit: 3                   # Retry failed Jobs 3 times
    template:
      metadata:
        labels:
          app: video-processor
      spec:
        restartPolicy: Never          # Required for Jobs
        containers:
        - name: processor
          image: myregistry/video-processor:1.0
          env:
          - name: QUEUE_CONNECTION
            valueFrom:
              secretKeyRef:
                name: queue-secret
                key: connectionString
          resources:
            requests:
              cpu: "500m"
              memory: "512Mi"
            limits:
              cpu: "2"
              memory: "4Gi"
  
  # ============================================================
  # SCALING CONFIGURATION
  # ============================================================
  pollingInterval: 10                 # Check queue every 10 seconds
  minReplicaCount: 0                  # No Jobs when queue is empty
  maxReplicaCount: 20                 # Maximum concurrent Jobs
  
  # ============================================================
  # JOB LIFECYCLE
  # ============================================================
  successfulJobsHistoryLimit: 5       # Keep 5 successful Jobs for debugging
  failedJobsHistoryLimit: 5           # Keep 5 failed Jobs for debugging
  
  # ============================================================
  # TRIGGERS - What creates Jobs?
  # ============================================================
  triggers:
  - type: azure-servicebus
    metadata:
      queueName: video-jobs
      namespace: my-servicebus
      messageCount: "1"               # 1 Job per message
      connectionFromEnv: QUEUE_CONNECTION
```

---

## Detailed YAML with Annotations

```yaml
apiVersion: keda.sh/v1alpha1
kind: ScaledJob
metadata:
  name: order-processor-job
  namespace: production
spec:
  # ============================================================
  # JOB TARGET REF - Defines the Job that KEDA will create
  # ============================================================
  jobTargetRef:
    # How many pods run in parallel within ONE Job
    parallelism: 1                    
    
    # How many successful pod completions = Job "complete"
    completions: 1
    
    # How many times to retry if pod fails
    backoffLimit: 3
    
    # Optional: Delete Job after this many seconds
    ttlSecondsAfterFinished: 600      # Clean up after 10 minutes
    
    # Pod template - what runs
    template:
      metadata:
        labels:
          app: order-processor
        annotations:
          prometheus.io/scrape: "true"
      spec:
        restartPolicy: Never          # MUST be Never or OnFailure for Jobs
        
        # Optional: Run on specific nodes
        nodeSelector:
          workload-type: batch
        
        containers:
        - name: processor
          image: myregistry/order-processor:2.0
          
          # Environment variables
          env:
          - name: QUEUE_NAME
            value: "orders"
          - name: CONNECTION_STRING
            valueFrom:
              secretKeyRef:
                name: servicebus-secret
                key: connectionString
          
          # Resource allocation
          resources:
            requests:
              cpu: "250m"
              memory: "256Mi"
            limits:
              cpu: "1"
              memory: "1Gi"
          
          # Volume mounts if needed
          volumeMounts:
          - name: temp-storage
            mountPath: /tmp/work
        
        volumes:
        - name: temp-storage
          emptyDir:
            sizeLimit: 1Gi
  
  # ============================================================
  # SCALING PARAMETERS
  # ============================================================
  
  # How often KEDA checks for new events
  pollingInterval: 15                 # Every 15 seconds
  
  # Minimum Jobs (usually 0 for ScaledJob)
  minReplicaCount: 0
  
  # Maximum concurrent Jobs
  maxReplicaCount: 50
  
  # Optional: Scaling strategy
  scalingStrategy:
    strategy: "default"               # Or "custom", "accurate"
    # For "custom":
    # customScalingQueueLengthDeduction: 1
    # customScalingRunningJobPercentage: "0.5"
  
  # ============================================================
  # JOB HISTORY - How many completed Jobs to keep
  # ============================================================
  successfulJobsHistoryLimit: 10      # Keep last 10 successful
  failedJobsHistoryLimit: 10          # Keep last 10 failed
  
  # ============================================================
  # TRIGGERS
  # ============================================================
  triggers:
  - type: azure-servicebus
    metadata:
      queueName: orders
      namespace: myservicebus
      messageCount: "1"               # 1 Job per message
    authenticationRef:
      name: servicebus-auth           # Reference TriggerAuthentication
  
  # ============================================================
  # ADVANCED: Rollout strategy for Job template updates
  # ============================================================
  rollout:
    strategy: gradual                 # Or "default"
    propagationPolicy: Foreground     # Wait for old Jobs to complete
```

---

## Scaling Strategies Explained

```
SCALEDJOB SCALING STRATEGIES
============================

1. DEFAULT STRATEGY
-------------------
desiredJobs = ceil(queueLength / messageCount)

Queue: 10 messages, messageCount: 1
Result: 10 Jobs created

Simple and straightforward.


2. ACCURATE STRATEGY
--------------------
desiredJobs = ceil(queueLength / messageCount) - runningJobs

Queue: 10 messages, messageCount: 1, 3 Jobs already running
Result: 7 new Jobs created (10 - 3 = 7)

Accounts for Jobs already processing.


3. CUSTOM STRATEGY
------------------
desiredJobs = ceil((queueLength - queueLengthDeduction) * runningJobPercentage)

More control for specific scenarios.


VISUAL EXAMPLE:
===============

Queue has 15 messages, messageCount: 1, 5 Jobs running

DEFAULT:   ceil(15/1) = 15 Jobs total    (may over-provision)
ACCURATE:  ceil(15/1) - 5 = 10 new Jobs  (smarter)
```

---

## ScaledJob vs ScaledObject: Side by Side

```yaml
# SCALEDOBJECT (for Deployments)
apiVersion: keda.sh/v1alpha1
kind: ScaledObject
metadata:
  name: my-scaledobject
spec:
  scaleTargetRef:              # Points to existing Deployment
    name: my-deployment
  minReplicaCount: 0
  maxReplicaCount: 10
  triggers:
  - type: azure-servicebus
    metadata:
      queueName: myqueue
      messageCount: "5"
---
# SCALEDJOB (creates Jobs)
apiVersion: keda.sh/v1alpha1
kind: ScaledJob
metadata:
  name: my-scaledjob
spec:
  jobTargetRef:                # Defines Job template (inline)
    parallelism: 1
    completions: 1
    template:
      spec:
        containers:
        - name: worker
          image: my-worker:1.0
        restartPolicy: Never
  minReplicaCount: 0
  maxReplicaCount: 10
  triggers:
  - type: azure-servicebus
    metadata:
      queueName: myqueue
      messageCount: "1"
```

```
KEY DIFFERENCES:
================
+------------------------+-------------------+-------------------+
|        Aspect          |   ScaledObject    |    ScaledJob      |
+------------------------+-------------------+-------------------+
| What it scales         | Deployment/       | Creates new       |
|                        | StatefulSet       | Job instances     |
+------------------------+-------------------+-------------------+
| Config location        | scaleTargetRef    | jobTargetRef      |
|                        | (references       | (contains full    |
|                        | existing resource)| Job template)     |
+------------------------+-------------------+-------------------+
| Pod lifecycle          | Long-running      | Run-to-completion |
+------------------------+-------------------+-------------------+
| messageCount meaning   | Messages per pod  | Messages per Job  |
+------------------------+-------------------+-------------------+
| Idle state             | minReplicaCount   | 0 Jobs running    |
|                        | pods running      |                   |
+------------------------+-------------------+-------------------+
```

---

## Real-World Use Case: Image Processing Pipeline

```
IMAGE PROCESSING WITH SCALEDJOB
===============================

User uploads image
        |
        v
+------------------+
| Azure Blob       |
| Storage          |
+------------------+
        |
        | Event Grid triggers
        v
+------------------+
| Azure Service Bus|
| Queue: images    |
+------------------+
        |
        | KEDA detects messages
        v
+------------------+
| ScaledJob        |
| "image-processor"|
+------------------+
        |
        | Creates Jobs
        v
+------+ +------+ +------+
| Job1 | | Job2 | | Job3 |  <-- Each processes 1 image
+------+ +------+ +------+
   |        |        |
   v        v        v
[resize] [resize] [resize]
[filter] [filter] [filter]
[upload] [upload] [upload]
   |        |        |
   v        v        v
[done]   [done]   [done]    <-- Jobs complete and terminate

Result: Images processed, no idle pods!
```

```yaml
# image-processor-scaledjob.yaml
apiVersion: keda.sh/v1alpha1
kind: ScaledJob
metadata:
  name: image-processor
spec:
  jobTargetRef:
    parallelism: 1
    completions: 1
    backoffLimit: 2
    ttlSecondsAfterFinished: 300
    template:
      spec:
        restartPolicy: Never
        containers:
        - name: processor
          image: myregistry/image-processor:1.0
          env:
          - name: QUEUE_CONNECTION
            valueFrom:
              secretKeyRef:
                name: queue-secret
                key: connection
          - name: BLOB_CONNECTION
            valueFrom:
              secretKeyRef:
                name: blob-secret
                key: connection
          resources:
            requests:
              cpu: "1"
              memory: "2Gi"
            limits:
              cpu: "2"
              memory: "4Gi"
  
  pollingInterval: 5
  minReplicaCount: 0
  maxReplicaCount: 100
  successfulJobsHistoryLimit: 10
  failedJobsHistoryLimit: 10
  
  triggers:
  - type: azure-servicebus
    metadata:
      queueName: images-to-process
      namespace: my-servicebus
      messageCount: "1"
    authenticationRef:
      name: servicebus-auth
```

---

## Debugging ScaledJobs

```bash
# List ScaledJobs
kubectl get scaledjob

# Get ScaledJob details
kubectl describe scaledjob my-scaledjob

# List Jobs created by KEDA
kubectl get jobs -l scaledjob.keda.sh/name=my-scaledjob

# Check Job status
kubectl describe job <job-name>

# View pod logs from a Job
kubectl logs job/<job-name>

# Common Issues:

# 1. Jobs not being created
#    - Check KEDA operator logs
#    - Verify trigger authentication
#    - Check queue actually has messages

# 2. Jobs failing repeatedly
#    - Check backoffLimit
#    - Look at pod logs for errors
#    - Verify container image is correct

# 3. Too many Jobs created
#    - Check maxReplicaCount
#    - Verify messageCount threshold
#    - Consider using 'accurate' scaling strategy
```

---

## Best Practices

```
+------------------------------------------------------------------+
|                  SCALEDJOB BEST PRACTICES                        |
+------------------------------------------------------------------+

1. SET APPROPRIATE TTL
   - ttlSecondsAfterFinished cleans up completed Jobs
   - Without it, Jobs pile up forever
   - Balance between debugging needs and cluster cleanliness

2. USE HISTORY LIMITS
   - successfulJobsHistoryLimit: Keep some for debugging
   - failedJobsHistoryLimit: Keep failed for investigation
   - Typical: 5-20 each

3. SET BACKOFF LIMITS
   - backoffLimit prevents infinite retries
   - Consider what happens if a Job keeps failing
   - Usually 2-5 is reasonable

4. RESOURCE REQUESTS ARE CRITICAL
   - Jobs compete for cluster resources
   - Without requests, scheduler may overcommit
   - Set realistic CPU/memory requests

5. USE NODE SELECTORS/TOLERATIONS
   - Batch Jobs can use different node pools
   - Spot instances for cost savings
   - Dedicated nodes for predictable performance

6. MONITOR JOB QUEUE DEPTH
   - If Jobs pile up, maxReplicaCount may be too low
   - Or processing time is too long
   - Set up alerts for queue depth

+------------------------------------------------------------------+
```

---

## Summary

```
SCALEDJOB: KEDA'S JOB SCALER
============================

WHAT IT DOES:
- Creates Kubernetes Jobs based on events
- Each Job processes work and terminates
- Perfect for batch/event-driven workloads

KEY DIFFERENCES FROM SCALEDOBJECT:
+------------------+-------------------+--------------------+
|                  | ScaledObject      | ScaledJob          |
+------------------+-------------------+--------------------+
| Scales           | Deployments       | Creates Jobs       |
| Pod lifecycle    | Long-running      | Run-to-completion  |
| Best for         | Continuous work   | Batch processing   |
| Config           | scaleTargetRef    | jobTargetRef       |
+------------------+-------------------+--------------------+

WHEN TO USE:
- Video/image processing
- Data migration tasks
- Report generation
- Any task with clear start/end

YAML STRUCTURE:
spec:
  jobTargetRef:           # Job template (inline)
    parallelism: 1
    completions: 1
    template: ...
  minReplicaCount: 0      # Usually 0
  maxReplicaCount: N      # Concurrent Jobs limit
  triggers: [...]         # Event sources

SCALING FLOW:
Event -> KEDA -> Create Job -> Pod Runs -> Completes -> Done!
```

---

## Module Summary: Kubernetes Scaling

```
+------------------------------------------------------------------+
|              KUBERNETES SCALING RECAP                            |
+------------------------------------------------------------------+

MANUAL SCALING
- kubectl scale deployment X --replicas=N
- Good for: Predictable, scheduled changes

HPA (Horizontal Pod Autoscaler)
- Scales pods based on CPU/memory
- Built into Kubernetes
- Good for: Traffic-based scaling

VPA (Vertical Pod Autoscaler)
- Adjusts pod CPU/memory requests
- Makes pods bigger, not more
- Good for: Unknown resource requirements

KEDA (Event-Driven Autoscaling)
- Scales based on ANY event source
- Can scale to zero
- Extends HPA with 50+ scalers

SCALEDOBJECT
- KEDA resource for Deployments
- Long-running pods
- Good for: API servers, consumers

SCALEDJOB
- KEDA resource for Jobs
- Run-to-completion pods
- Good for: Batch processing

DECISION GUIDE:
+-----------------+------------------+
| If you need...  | Use...           |
+-----------------+------------------+
| CPU-based scale | HPA              |
| Queue-based     | KEDA + ScaledObj |
| Batch jobs      | KEDA + ScaledJob |
| Scale to zero   | KEDA             |
| Right-size pods | VPA              |
+-----------------+------------------+
+------------------------------------------------------------------+
```

Congratulations! You now understand the complete Kubernetes scaling landscape!
