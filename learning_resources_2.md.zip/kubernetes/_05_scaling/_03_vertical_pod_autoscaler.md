# Vertical Pod Autoscaler (VPA)

## What is VPA?

**Vertical Pod Autoscaler (VPA)** automatically adjusts the CPU and memory **requests** (and optionally limits) for containers in a pod.

**Key word: VERTICAL** = Making pods BIGGER (scaling UP), not adding more pods.

```
VERTICAL SCALING (VPA does this)
================================
Make existing pods bigger when they need more resources:

Before:   +----------+
          | Pod      |
          | CPU: 100m|
          | Mem: 128M|
          +----------+

After:    +------------------+
          | Pod              |
          | CPU: 500m        |  <-- VPA increased resources
          | Mem: 512M        |
          +------------------+


HORIZONTAL SCALING (HPA does this)
==================================
Add more pods:

Before:   [Pod 1]

After:    [Pod 1] [Pod 2] [Pod 3]
```

---

## VPA vs HPA: The Restaurant Analogy

```
RESTAURANT ANALOGY
==================

HPA (Horizontal Scaling):
+------------------------------------------+
| Restaurant is busy                       |
| Solution: HIRE MORE WAITERS              |
|                                          |
|   [Waiter 1] [Waiter 2] [Waiter 3]       |
|                                          |
| Each waiter handles same number of tables|
+------------------------------------------+

VPA (Vertical Scaling):
+------------------------------------------+
| Waiter is overwhelmed                    |
| Solution: GIVE WAITER A CART + ASSISTANT |
|                                          |
|   [Super-Powered Waiter]                 |
|    - Bigger serving tray                 |
|    - Faster shoes                        |
|    - Better memory for orders            |
|                                          |
| Same waiter, but more capable            |
+------------------------------------------+
```

---

## How VPA Works

```
VPA ARCHITECTURE
================

+------------------------------------------------------------------+
|                                                                  |
|   +------------------+                                           |
|   |   VPA Recommender|  <-- Watches pod resource usage           |
|   |                  |      Calculates optimal requests          |
|   +--------+---------+                                           |
|            |                                                     |
|            | Recommendations                                     |
|            v                                                     |
|   +------------------+                                           |
|   |    VPA Updater   |  <-- Evicts pods that need resizing       |
|   |                  |      (only in "Auto" mode)                |
|   +--------+---------+                                           |
|            |                                                     |
|            | Pod eviction                                        |
|            v                                                     |
|   +------------------+                                           |
|   | VPA Admission    |  <-- Mutates new pods with                |
|   | Controller       |      recommended resources                |
|   +--------+---------+                                           |
|            |                                                     |
|            v                                                     |
|   +------------------+                                           |
|   | Pod (recreated   |  <-- Starts with new resource requests    |
|   | with new values) |                                           |
|   +------------------+                                           |
|                                                                  |
+------------------------------------------------------------------+
```

### The VPA Process

```
1. OBSERVE
   VPA watches pods over time
   "Pod A uses 80m CPU on average, peaks at 200m"
   "Pod A uses 100Mi memory on average"

2. RECOMMEND  
   VPA calculates optimal requests
   "Pod A should request 150m CPU, 150Mi memory"

3. UPDATE (if mode = Auto)
   VPA evicts the pod
   When pod restarts, admission controller sets new values

IMPORTANT: VPA restarts pods to apply changes!
           This causes brief downtime for that pod.
```

---

## VPA Modes

```
+------------------------------------------------------------------+
|                        VPA MODES                                 |
+------------------------------------------------------------------+

MODE: "Off"
-----------
- VPA only calculates recommendations
- Does NOT apply them
- You can view recommendations manually
- Useful for: Testing, seeing what VPA would do

MODE: "Initial"  
---------------
- VPA sets resources only when pod is CREATED
- Does NOT update running pods
- Useful for: Setting good initial values for new pods

MODE: "Auto" (previously "Recreate")
------------------------------------
- VPA actively manages pod resources
- Evicts and recreates pods to apply new values
- Useful for: Fully automated resource management

+------------------------------------------------------------------+

RECOMMENDATION:
Start with "Off" mode to see recommendations
Move to "Auto" when you trust the recommendations
```

---

## Basic VPA Example

```yaml
# vpa-example.yaml
apiVersion: autoscaling.k8s.io/v1
kind: VerticalPodAutoscaler
metadata:
  name: my-app-vpa
spec:
  targetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: my-app
  
  updatePolicy:
    updateMode: "Auto"           # Can be: Off, Initial, Auto
  
  resourcePolicy:
    containerPolicies:
    - containerName: "*"         # Apply to all containers
      minAllowed:                # Never go below these values
        cpu: "50m"
        memory: "64Mi"
      maxAllowed:                # Never exceed these values
        cpu: "2"
        memory: "4Gi"
      controlledResources:
        - cpu
        - memory
```

---

## When to Use VPA vs HPA

```
+------------------------------------------------------------------+
|                    VPA vs HPA DECISION GUIDE                     |
+------------------------------------------------------------------+

USE HPA WHEN:
-------------
[x] Traffic varies significantly
[x] App scales well horizontally (stateless)
[x] You need quick response to load spikes
[x] You want high availability (multiple pods)

Example: Web API servers, microservices


USE VPA WHEN:
-------------
[x] App doesn't scale horizontally well
[x] Single pod needs to grow with data/load
[x] You don't know correct resource requests
[x] App is stateful with complex coordination

Example: Databases, ML training, batch processors


USE BOTH WHEN:
--------------
[x] You want HPA for horizontal scaling
[x] You want VPA to optimize resource requests
[!] BUT: Don't use both on CPU/memory at same time!
    - VPA changes requests
    - HPA uses requests to calculate utilization
    - They will fight each other!

SOLUTION: Use VPA in "Off" mode with HPA
         VPA provides recommendations
         You manually apply them
         HPA does the actual scaling

+------------------------------------------------------------------+
```

### Visual Comparison

```
SCENARIO: Increasing load on your application

HPA APPROACH:
=============
Load:  |-------|-------|-------|
       Low     Med     High    Very High

Pods:  [Pod]   [Pod]   [Pod]   [Pod]
               [Pod]   [Pod]   [Pod]
                       [Pod]   [Pod]
                               [Pod]

Result: 1 pod -> 2 pods -> 3 pods -> 4 pods
        Each pod stays same size


VPA APPROACH:
=============
Load:  |-------|-------|-------|
       Low     Med     High    Very High

Pods:  [Small] [Medium] [Large] [X-Large]
       100m    200m     400m    800m CPU

Result: 1 pod that keeps getting bigger
        Pod restarts when resources change
```

---

## VPA Limitations

```
+------------------------------------------------------------------+
|                      VPA LIMITATIONS                             |
+------------------------------------------------------------------+

1. POD RESTARTS REQUIRED
   - VPA can't update a running pod's resources
   - Must evict and recreate the pod
   - Causes brief disruption

2. CONFLICTS WITH HPA
   - Don't use both on same resource (CPU/memory)
   - They will interfere with each other

3. NOT INSTANT
   - VPA needs time to observe usage patterns
   - Recommendations improve over time

4. REQUIRES VPA COMPONENTS
   - VPA is NOT built into Kubernetes
   - Must install: Recommender, Updater, Admission Controller

5. JVM/INTERPRETED LANGUAGES
   - Apps with fixed memory (JVM heap) need special handling
   - VPA might recommend less than JVM needs

+------------------------------------------------------------------+
```

---

## Installing VPA

VPA is not included in Kubernetes by default. You need to install it:

```bash
# Clone VPA repository
git clone https://github.com/kubernetes/autoscaler.git

# Navigate to VPA directory
cd autoscaler/vertical-pod-autoscaler

# Install VPA components
./hack/vpa-up.sh

# Verify installation
kubectl get pods -n kube-system | grep vpa
```

---

## Checking VPA Recommendations

```bash
# Get VPA status
kubectl describe vpa my-app-vpa

# Look for the "Recommendation" section:

Status:
  Recommendation:
    Container Recommendations:
    - Container Name: my-app
      Lower Bound:           # Minimum recommended
        Cpu:     25m
        Memory:  64Mi
      Target:                # Recommended value
        Cpu:     100m
        Memory:  128Mi
      Uncapped Target:       # What VPA would recommend without limits
        Cpu:     100m
        Memory:  128Mi
      Upper Bound:           # Maximum recommended
        Cpu:     200m
        Memory:  256Mi
```

---

## VPA Best Practices

```
+------------------------------------------------------------------+
|                    VPA BEST PRACTICES                            |
+------------------------------------------------------------------+

1. START WITH "OFF" MODE
   - See recommendations before applying
   - Build trust in VPA's suggestions

2. SET MIN/MAX BOUNDARIES
   - Prevent VPA from setting too low (crashes)
   - Prevent VPA from setting too high (resource waste)

3. DON'T MIX WITH HPA ON SAME METRICS
   - If using HPA on CPU, don't use VPA on CPU
   - Use VPA for memory only, or vice versa

4. ENSURE MULTIPLE REPLICAS
   - VPA evicts pods to update them
   - Multiple replicas = no downtime during update

5. USE POD DISRUPTION BUDGETS
   - Protect against too many pods being evicted
   - Ensures availability during VPA updates

+------------------------------------------------------------------+
```

---

## Summary

```
VERTICAL POD AUTOSCALER (VPA)
=============================

WHAT IT DOES:
- Adjusts CPU/memory requests for pods
- Makes pods bigger (vertical scaling)
- Based on actual resource usage over time

HOW IT WORKS:
+------------+     +----------+     +------------+     +------+
| Recommender| --> | Updater  | --> | Admission  | --> | Pod  |
| (observes) |     | (evicts) |     | Controller |     |(new) |
+------------+     +----------+     +------------+     +------+

MODES:
- Off: Only recommends, doesn't apply
- Initial: Sets values for new pods only
- Auto: Actively manages (evicts + recreates)

KEY DIFFERENCES FROM HPA:
+----------------+------------------------+
|      HPA       |          VPA           |
+----------------+------------------------+
| More pods      | Bigger pods            |
| Scales OUT     | Scales UP              |
| No restart     | Requires restart       |
| Built-in       | Addon (must install)   |
| Fast reaction  | Slower (observes time) |
+----------------+------------------------+

WHEN TO USE:
- Apps that don't scale horizontally
- Unknown resource requirements
- Single-instance stateful apps
```

**Next up:** Learn about KEDA - Kubernetes Event-Driven Autoscaling for even more powerful scaling!
