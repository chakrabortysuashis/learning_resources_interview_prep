# ScaledObject: KEDA Resource for Scaling Deployments

## What is a ScaledObject?

A **ScaledObject** is a KEDA custom resource that tells KEDA how to scale a Deployment, StatefulSet, or any resource that implements the `/scale` subresource.

Think of ScaledObject as a **recipe** that tells KEDA:
- WHAT to scale (your deployment)
- WHEN to scale (triggers/events)
- HOW MUCH to scale (min/max replicas)

```
ScaledObject = Instructions for KEDA
====================================

"Dear KEDA,

Please watch the 'orders' queue in Azure Service Bus.
When there are messages:
  - Scale up my 'order-processor' deployment
  - Add 1 pod for every 5 messages
  - Never go above 10 pods
  - When the queue is empty, scale to 0

Thanks!"

That's what a ScaledObject defines!
```

---

## How ScaledObject Works Under the Hood

```
+------------------------------------------------------------------+
|             ScaledObject -> HPA MAPPING                          |
+------------------------------------------------------------------+

When you create a ScaledObject:

    +-------------------+
    |   ScaledObject    |  <-- You create this
    |   "order-scaler"  |
    +-------------------+
            |
            | KEDA reads it
            v
    +-------------------+
    |   KEDA Operator   |  <-- Creates and manages HPA
    +-------------------+
            |
            | Auto-creates
            v
    +-------------------+
    |       HPA         |  <-- You DON'T create this
    | "keda-hpa-order-  |      KEDA does it for you
    |  scaler"          |
    +-------------------+
            |
            | Scales
            v
    +-------------------+
    |    Deployment     |
    | "order-processor" |
    +-------------------+


KEDA acts as a "translator":
- You speak in "events" (queue length, HTTP requests)
- KEDA translates to "metrics" that HPA understands
```

### Mermaid Flowchart

```mermaid
flowchart LR
    subgraph "You Create"
        SO[ScaledObject]
        TA[TriggerAuthentication]
    end
    
    subgraph "KEDA Creates"
        HPA[HPA]
    end
    
    subgraph "External"
        ASB[Azure Service Bus]
    end
    
    subgraph "Your Workload"
        DEP[Deployment]
        P1[Pod 1]
        P2[Pod 2]
        P3[Pod 3]
    end
    
    SO --> |"KEDA reads"| HPA
    TA --> |"credentials"| SO
    ASB --> |"queue length"| SO
    HPA --> DEP
    DEP --> P1
    DEP --> P2
    DEP --> P3
```

---

## ScaledObject Anatomy

```yaml
apiVersion: keda.sh/v1alpha1
kind: ScaledObject
metadata:
  name: my-scaledobject          # Name of this ScaledObject
  namespace: default              # Must be same namespace as target
spec:
  scaleTargetRef:                 # WHAT to scale
    name: my-deployment
    kind: Deployment              # Optional, defaults to Deployment
  
  pollingInterval: 30             # How often to check triggers (seconds)
  cooldownPeriod: 300             # Wait time before scaling to 0
  
  minReplicaCount: 0              # Minimum pods (can be 0!)
  maxReplicaCount: 100            # Maximum pods
  
  triggers:                       # WHEN to scale (event sources)
  - type: <scaler-type>
    metadata:
      <scaler-specific-config>
```

---

## Detailed YAML Example: Azure Service Bus

```yaml
# order-processor-scaledobject.yaml
apiVersion: keda.sh/v1alpha1
kind: ScaledObject
metadata:
  name: order-processor-scaler
  namespace: production
  labels:
    app: order-processor
spec:
  # ============================================================
  # SCALE TARGET - What Deployment/StatefulSet should KEDA scale?
  # ============================================================
  scaleTargetRef:
    apiVersion: apps/v1           # Optional, defaults to apps/v1
    kind: Deployment              # Can also be: StatefulSet
    name: order-processor         # Must match your deployment name
  
  # ============================================================
  # POLLING & COOLDOWN - How responsive should scaling be?
  # ============================================================
  pollingInterval: 15             # Check queue every 15 seconds
                                  # Lower = more responsive
                                  # Higher = less API calls to Azure
  
  cooldownPeriod: 300             # Wait 5 minutes of inactivity
                                  # before scaling to 0
                                  # Prevents rapid scale up/down
  
  # ============================================================
  # REPLICA BOUNDS - Safety limits
  # ============================================================
  minReplicaCount: 0              # Scale to ZERO when no messages!
                                  # This is KEDA's superpower
                                  
  maxReplicaCount: 20             # Never exceed 20 pods
                                  # Prevents runaway scaling
  
  # ============================================================
  # IDLE REPLICA COUNT - Pods when "idle" but not zero
  # ============================================================
  idleReplicaCount: 1             # Optional: Keep 1 pod when nearly idle
                                  # Helps with faster response
                                  # If not set, scales directly to 0
  
  # ============================================================
  # TRIGGERS - What events drive the scaling?
  # ============================================================
  triggers:
  
  # --- Primary trigger: Azure Service Bus Queue ---
  - type: azure-servicebus
    metadata:
      # Queue configuration
      queueName: orders           # Name of the queue to monitor
      namespace: my-servicebus    # Service Bus namespace name
      
      # Scaling threshold
      messageCount: "5"           # Target: 5 messages per pod
                                  # 10 messages = 2 pods
                                  # 50 messages = 10 pods
      
      # Authentication (option 1: from environment)
      connectionFromEnv: SERVICEBUS_CONNECTION_STRING
      
    # Authentication (option 2: using TriggerAuthentication)
    authenticationRef:
      name: azure-servicebus-auth
  
  # --- Optional: Add another trigger ---
  # Multiple triggers = scale based on MAXIMUM of all triggers
  - type: cron
    metadata:
      timezone: America/New_York
      start: 0 8 * * 1-5          # 8 AM Mon-Fri
      end: 0 18 * * 1-5           # 6 PM Mon-Fri
      desiredReplicas: "3"        # Always have 3 during business hours
  
  # ============================================================
  # ADVANCED: Custom HPA behavior
  # ============================================================
  advanced:
    horizontalPodAutoscalerConfig:
      behavior:
        scaleDown:
          stabilizationWindowSeconds: 300
          policies:
          - type: Percent
            value: 25
            periodSeconds: 60
```

---

## Trigger Authentication

For security, keep credentials separate from ScaledObject:

```yaml
# trigger-authentication.yaml
apiVersion: keda.sh/v1alpha1
kind: TriggerAuthentication
metadata:
  name: azure-servicebus-auth
  namespace: production
spec:
  # Option 1: From Kubernetes Secret
  secretTargetRef:
  - parameter: connection         # Parameter name KEDA expects
    name: servicebus-secret       # Kubernetes secret name
    key: connectionString         # Key within the secret
  
  # Option 2: From Pod Identity (Azure)
  # podIdentity:
  #   provider: azure
  
  # Option 3: From Environment
  # env:
  # - parameter: connection
  #   name: SERVICEBUS_CONNECTION_STRING
```

```yaml
# The secret it references
apiVersion: v1
kind: Secret
metadata:
  name: servicebus-secret
  namespace: production
type: Opaque
stringData:
  connectionString: "Endpoint=sb://my-ns.servicebus.windows.net/;SharedAccessKeyName=..."
```

---

## Architecture Diagram: Complete Flow

```
COMPLETE SCALING FLOW
=====================

+------------------------------------------------------------------+
|                                                                  |
|   AZURE SERVICE BUS                                              |
|   +--------------------+                                         |
|   | Queue: "orders"    |                                         |
|   | Messages: 25       |  <-- External event source              |
|   +--------------------+                                         |
|            |                                                     |
|            | KEDA polls queue length                             |
|            v                                                     |
|   +--------------------+                                         |
|   | TriggerAuth        |  <-- Provides credentials               |
|   | (connection string)|                                         |
|   +--------------------+                                         |
|            |                                                     |
|            v                                                     |
|   +--------------------+                                         |
|   | ScaledObject       |  <-- Your configuration                 |
|   | - messageCount: 5  |      "Scale 1 pod per 5 messages"       |
|   | - min: 0, max: 20  |                                         |
|   +--------------------+                                         |
|            |                                                     |
|            | KEDA Operator processes                             |
|            v                                                     |
|   +--------------------+                                         |
|   | HPA (auto-created) |  <-- KEDA creates this                  |
|   | target: 5 msgs/pod |      25 msgs / 5 = 5 pods needed        |
|   +--------------------+                                         |
|            |                                                     |
|            | Scales deployment                                   |
|            v                                                     |
|   +--------------------+                                         |
|   | Deployment         |                                         |
|   | order-processor    |                                         |
|   +--------------------+                                         |
|            |                                                     |
|            | Creates pods                                        |
|            v                                                     |
|   +------+------+------+------+------+                           |
|   | Pod  | Pod  | Pod  | Pod  | Pod  |  <-- 5 pods running       |
|   +------+------+------+------+------+                           |
|                                                                  |
+------------------------------------------------------------------+
```

### Mermaid Sequence Diagram

```mermaid
sequenceDiagram
    participant ASB as Azure Service Bus
    participant KEDA as KEDA Operator
    participant HPA as HPA
    participant DEP as Deployment
    
    loop Every pollingInterval
        KEDA->>ASB: How many messages?
        ASB-->>KEDA: 25 messages
        KEDA->>KEDA: Calculate: 25/5 = 5 pods needed
        KEDA->>HPA: Update external metric
        HPA->>DEP: Scale to 5 replicas
        DEP->>DEP: Create/delete pods
    end
```

---

## Common Trigger Types

### Azure Service Bus (Queue)

```yaml
triggers:
- type: azure-servicebus
  metadata:
    queueName: myqueue
    namespace: my-servicebus-namespace
    messageCount: "5"
    connectionFromEnv: SERVICEBUS_CONNECTION
```

### Azure Service Bus (Topic)

```yaml
triggers:
- type: azure-servicebus
  metadata:
    topicName: mytopic
    subscriptionName: mysubscription
    namespace: my-servicebus-namespace
    messageCount: "10"
    connectionFromEnv: SERVICEBUS_CONNECTION
```

### Kafka

```yaml
triggers:
- type: kafka
  metadata:
    bootstrapServers: kafka-broker:9092
    consumerGroup: my-consumer-group
    topic: my-topic
    lagThreshold: "100"           # Scale when lag > 100 messages
```

### Prometheus

```yaml
triggers:
- type: prometheus
  metadata:
    serverAddress: http://prometheus:9090
    metricName: http_requests_total
    threshold: "100"
    query: sum(rate(http_requests_total{app="myapp"}[2m]))
```

### Cron (Schedule-based)

```yaml
triggers:
- type: cron
  metadata:
    timezone: UTC
    start: 0 8 * * *              # 8:00 AM every day
    end: 0 20 * * *               # 8:00 PM every day
    desiredReplicas: "5"          # 5 pods during this window
```

### HTTP (Request-based)

```yaml
triggers:
- type: metrics-api
  metadata:
    targetValue: "100"
    url: "http://my-metrics-service/api/requests-per-second"
    valueLocation: "value"
```

---

## Scaling Math

```
HOW KEDA CALCULATES REPLICAS
============================

Formula: desiredReplicas = ceil(currentMetricValue / threshold)

EXAMPLE 1: Azure Service Bus
----------------------------
Queue messages: 23
messageCount threshold: 5

desiredReplicas = ceil(23 / 5) = ceil(4.6) = 5 pods


EXAMPLE 2: Kafka Lag
--------------------
Current lag: 1500 messages
lagThreshold: 100

desiredReplicas = ceil(1500 / 100) = ceil(15) = 15 pods


EXAMPLE 3: Empty Queue
----------------------
Queue messages: 0
messageCount threshold: 5

desiredReplicas = ceil(0 / 5) = ceil(0) = 0 pods

(This is how scale-to-zero works!)


MULTIPLE TRIGGERS:
------------------
When you have multiple triggers, KEDA uses the MAXIMUM:

Trigger 1 (Service Bus): needs 5 pods
Trigger 2 (Cron): needs 3 pods

Result: 5 pods (maximum wins)
```

---

## ScaledObject Lifecycle

```
SCALEDOBJECT STATES
===================

1. CREATED
   - You apply the ScaledObject YAML
   - KEDA picks it up
   - Status: "New"

2. ACTIVE
   - KEDA successfully connects to trigger
   - HPA is created and working
   - Status: "Active"
   - Pods are running

3. IDLE (cooldownPeriod)
   - Metric drops to 0
   - KEDA waits for cooldownPeriod
   - Prevents premature scale-down

4. PAUSED (idleReplicaCount)
   - Metric is 0 and cooldown passed
   - If idleReplicaCount is set: keeps that many pods
   - If not: scales to 0

5. ZERO REPLICAS
   - minReplicaCount: 0
   - No events/messages
   - Deployment scaled to 0 pods
   - Cost savings!

6. SCALING UP FROM ZERO
   - New message arrives
   - KEDA detects it (pollingInterval)
   - Creates pod(s) immediately
```

---

## Common Patterns

### Pattern 1: Scale to Zero for Batch Processing

```yaml
apiVersion: keda.sh/v1alpha1
kind: ScaledObject
metadata:
  name: batch-processor
spec:
  scaleTargetRef:
    name: batch-worker
  minReplicaCount: 0              # Zero when no work
  maxReplicaCount: 50             # Handle big batches
  cooldownPeriod: 60              # Scale down quickly
  triggers:
  - type: azure-servicebus
    metadata:
      queueName: batch-jobs
      messageCount: "1"           # 1 pod per message
```

### Pattern 2: Always-On with Burst Capacity

```yaml
apiVersion: keda.sh/v1alpha1
kind: ScaledObject
metadata:
  name: api-server
spec:
  scaleTargetRef:
    name: api-deployment
  minReplicaCount: 2              # Always have 2 for HA
  maxReplicaCount: 20             # Burst up to 20
  triggers:
  - type: prometheus
    metadata:
      serverAddress: http://prometheus:9090
      query: sum(rate(http_requests_total[1m]))
      threshold: "100"            # Scale up at 100 req/s
```

### Pattern 3: Business Hours Scaling

```yaml
apiVersion: keda.sh/v1alpha1
kind: ScaledObject
metadata:
  name: business-hours-app
spec:
  scaleTargetRef:
    name: my-app
  minReplicaCount: 1
  maxReplicaCount: 10
  triggers:
  # Business hours: more pods
  - type: cron
    metadata:
      timezone: America/New_York
      start: 0 9 * * 1-5          # 9 AM Mon-Fri
      end: 0 17 * * 1-5           # 5 PM Mon-Fri
      desiredReplicas: "5"
  # Also scale on actual load
  - type: prometheus
    metadata:
      query: avg(cpu_usage)
      threshold: "50"
```

---

## Debugging ScaledObjects

```bash
# Check ScaledObject status
kubectl get scaledobject

# Detailed info
kubectl describe scaledobject my-scaledobject

# Check the auto-created HPA
kubectl get hpa

# Look for KEDA operator logs
kubectl logs -n keda -l app=keda-operator

# Common issues:

# 1. ScaledObject shows "Unknown" status
#    -> Check trigger authentication
#    -> Verify credentials are correct

# 2. Not scaling to zero
#    -> Check cooldownPeriod hasn't elapsed
#    -> Verify minReplicaCount is 0

# 3. Not scaling up
#    -> Check pollingInterval
#    -> Verify trigger is receiving events
#    -> Check HPA: kubectl describe hpa
```

---

## Summary

```
SCALEDOBJECT: KEDA'S CORE RESOURCE
==================================

WHAT IT DOES:
- Defines how KEDA should scale your Deployment
- KEDA reads it and creates an HPA automatically
- Connects to external event sources (triggers)

KEY FIELDS:
+----------------------+------------------------------------------+
| scaleTargetRef       | What to scale (Deployment name)          |
| minReplicaCount      | Minimum pods (can be 0!)                 |
| maxReplicaCount      | Maximum pods                             |
| pollingInterval      | How often to check triggers              |
| cooldownPeriod       | Wait before scaling to zero              |
| triggers             | Event sources (Service Bus, Kafka, etc.) |
+----------------------+------------------------------------------+

SCALING FLOW:
+----------+     +-----------+     +-----+     +--------+     +------+
| External | --> | Scaled    | --> |KEDA | --> |  HPA   | --> | Pods |
| Event    |     | Object    |     |     |     |        |     |      |
+----------+     +-----------+     +-----+     +--------+     +------+

BEST PRACTICES:
- Use TriggerAuthentication for credentials (security)
- Set reasonable pollingInterval (15-30s typical)
- Set cooldownPeriod to prevent thrashing
- Start with higher minReplicaCount, then enable scale-to-zero
```

**Next up:** Learn about ScaledJob - KEDA's resource for scaling Kubernetes Jobs!
