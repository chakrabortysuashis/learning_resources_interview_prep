# KEDA: Kubernetes Event-Driven Autoscaling

## What is KEDA?

**KEDA (Kubernetes Event-Driven Autoscaling)** is a lightweight component that extends Kubernetes to provide event-driven autoscaling for any workload.

Think of KEDA as **HPA on steroids** - it can scale based on events from almost ANY source, not just CPU and memory.

```
TRADITIONAL HPA:
================
Can scale based on:
- CPU usage
- Memory usage
- (Custom metrics with extra setup)

That's it!


KEDA:
=====
Can scale based on:
- Azure Service Bus queue length
- Kafka topic lag
- RabbitMQ queue depth
- AWS SQS messages
- Prometheus metrics
- Cron schedules
- HTTP request rate
- PostgreSQL query results
- Redis list length
- And 50+ more scalers!
```

---

## The Problem KEDA Solves

### Why Do We Need KEDA When We Have HPA?

```
SCENARIO: Processing Messages from a Queue
==========================================

You have:
- Azure Service Bus queue receiving orders
- Kubernetes deployment processing orders

PROBLEM WITH HPA:
-----------------
                Queue                    Processors
          +---------------+          +---------------+
          | Order 1       |    ?     | Processor Pod |
          | Order 2       |   ---    |   (Idle)      |
          | Order 3       |          +---------------+
          | ...           |          
          | Order 1000    |          How does HPA know
          +---------------+          about the queue?
          
HPA only sees: "CPU is 10%, memory is 20%"
HPA thinks: "Everything is fine! No scaling needed."
Reality: 1000 orders waiting to be processed!

SOLUTION WITH KEDA:
-------------------
          Queue                    Processors
          +---------------+          +---------------+
          | Order 1       |          | Processor Pod |
          | Order 2       |  KEDA    | Processor Pod |
          | Order 3       |   -->    | Processor Pod |
          | ...           |          | Processor Pod |
          | Order 1000    |          | Processor Pod |
          +---------------+          +---------------+
          
KEDA sees: "Queue has 1000 messages!"
KEDA does: "Scale to 5 pods to process them faster!"
```

---

## KEDA Architecture

```
+------------------------------------------------------------------+
|                      KEDA ARCHITECTURE                           |
+------------------------------------------------------------------+

                     External Event Sources
     +----------+  +----------+  +----------+  +----------+
     | Azure    |  | Kafka    |  | AWS      |  | Prom-    |
     | Service  |  | Topic    |  | SQS      |  | etheus   |
     | Bus      |  |          |  |          |  |          |
     +----+-----+  +----+-----+  +----+-----+  +----+-----+
          |             |             |             |
          +-------------+-------------+-------------+
                              |
                              v
+------------------------------------------------------------------+
|                    KEDA Components                               |
|                                                                  |
|   +------------------+    +------------------+                   |
|   |  KEDA Operator   |    | Metrics Adapter  |                   |
|   |                  |    |                  |                   |
|   | - Watches        |    | - Exposes        |                   |
|   |   ScaledObjects  |    |   external       |                   |
|   | - Manages HPA    |    |   metrics to     |                   |
|   | - Creates Jobs   |    |   Kubernetes     |                   |
|   +--------+---------+    +--------+---------+                   |
|            |                       |                             |
|            +-----------+-----------+                             |
|                        |                                         |
|                        v                                         |
|            +-----------------------+                             |
|            |     Kubernetes HPA    |  <-- KEDA creates/manages   |
|            |  (autoscaling/v2)     |      HPA automatically      |
|            +-----------+-----------+                             |
|                        |                                         |
+------------------------------------------------------------------+
                         |
                         v
              +----------+-----------+
              |      Deployment      |
              |  (your application)  |
              +----------+-----------+
                         |
                         v
              +------+------+------+
              | Pod  | Pod  | Pod  |
              +------+------+------+
```

### Mermaid Diagram

```mermaid
flowchart TB
    subgraph "External Sources"
        ASB[Azure Service Bus]
        KAFKA[Kafka]
        SQS[AWS SQS]
        PROM[Prometheus]
    end
    
    subgraph "KEDA"
        OP[KEDA Operator]
        MA[Metrics Adapter]
    end
    
    subgraph "Kubernetes Native"
        HPA[HPA]
        DEP[Deployment]
        PODS[Pods]
    end
    
    ASB --> OP
    KAFKA --> OP
    SQS --> OP
    PROM --> OP
    
    OP --> HPA
    MA --> HPA
    HPA --> DEP
    DEP --> PODS
```

---

## How KEDA Extends HPA

KEDA doesn't replace HPA - it **works with it**.

```
WITHOUT KEDA:
=============
You -> HPA -> Deployment -> Pods

HPA can only see: CPU, Memory, basic custom metrics


WITH KEDA:
==========
You -> ScaledObject -> KEDA -> HPA -> Deployment -> Pods
                         |
                         +-> Metrics from anywhere!

KEDA:
1. Reads your ScaledObject configuration
2. Connects to external systems (queues, databases, etc.)
3. Gets the current metric value
4. Creates and manages an HPA for you
5. HPA scales your deployment based on KEDA's metrics

It's like giving HPA superpowers!
```

```
KEDA AS AN HPA FACTORY
======================

         ScaledObject                      HPA (auto-created)
    +--------------------+           +------------------------+
    | scaleTargetRef:    |           | scaleTargetRef:        |
    |   name: my-app     |    -->    |   name: my-app         |
    | triggers:          |   KEDA    | metrics:               |
    |   - type: azure-sb |  creates  |   - type: External     |
    |     queueLength: 5 |           |     name: azure-sb-... |
    +--------------------+           +------------------------+

You write the ScaledObject.
KEDA creates and manages the HPA automatically.
```

---

## Common KEDA Scalers

KEDA has 50+ built-in scalers. Here are the most common:

```
+------------------------------------------------------------------+
|                     POPULAR KEDA SCALERS                         |
+------------------------------------------------------------------+

MESSAGE QUEUES:
---------------
[x] Azure Service Bus    - Scale based on queue/topic length
[x] Azure Queue Storage  - Scale based on queue messages
[x] Kafka               - Scale based on consumer lag
[x] RabbitMQ            - Scale based on queue depth
[x] AWS SQS             - Scale based on queue messages
[x] Google Pub/Sub      - Scale based on subscription messages

DATABASES:
----------
[x] PostgreSQL          - Scale based on query results
[x] MySQL               - Scale based on query results
[x] MongoDB             - Scale based on collection count
[x] Redis               - Scale based on list/stream length

METRICS:
--------
[x] Prometheus          - Scale based on any Prometheus metric
[x] Azure Monitor       - Scale based on Azure metrics
[x] Datadog             - Scale based on Datadog metrics
[x] New Relic           - Scale based on New Relic metrics

SCHEDULE:
---------
[x] Cron                - Scale based on schedule
                          (e.g., more pods during business hours)

HTTP:
-----
[x] HTTP                - Scale based on incoming request rate

+------------------------------------------------------------------+
```

---

## KEDA vs Native HPA

```
+------------------------------------------------------------------+
|                    KEDA VS NATIVE HPA                            |
+------------------------------------------------------------------+
|     Feature           |    Native HPA    |       KEDA           |
+------------------------------------------------------------------+
| CPU/Memory scaling    |       Yes        |        Yes           |
| Custom metrics        |   Complex setup  |     Built-in         |
| Queue-based scaling   |       No         |        Yes           |
| Event-driven          |       No         |        Yes           |
| Scale to zero         |       No         |        Yes*          |
| Cron-based scaling    |       No         |        Yes           |
| 50+ integrations      |       No         |        Yes           |
| Ease of setup         |      Easy        |       Easy           |
| Additional component  |       No         |   Yes (KEDA pods)    |
+------------------------------------------------------------------+

* Scale to zero is a HUGE advantage!
  
Native HPA: minReplicas must be >= 1
            You always pay for at least 1 pod

KEDA: Can scale to 0 pods when no events
      Zero cost when idle!
```

---

## Scale to Zero: KEDA's Superpower

```
SCALE TO ZERO EXPLAINED
=======================

Scenario: Batch job processor that runs occasionally

WITHOUT KEDA (HPA):
-------------------
Time:   12am    6am     12pm    6pm     12am
Work:   None    None    Burst   None    None
Pods:   [1]     [1]     [5]     [1]     [1]
Cost:   $$$     $$$     $$$$$   $$$     $$$

You ALWAYS have at least 1 pod running.
Paying 24/7 for something used 2 hours/day.


WITH KEDA:
----------
Time:   12am    6am     12pm    6pm     12am
Work:   None    None    Burst   None    None
Pods:   [0]     [0]     [5]     [0]     [0]
Cost:   $0      $0      $$$$$   $0      $0

KEDA scales to ZERO when no work.
Only pay when actually processing!


HOW IT WORKS:
-------------
1. Queue is empty
2. KEDA sees: "No messages"
3. KEDA scales deployment to 0 replicas
4. Message arrives in queue
5. KEDA sees: "1 message!"
6. KEDA scales deployment to 1 replica
7. Pod starts and processes message
8. Queue empty again -> back to 0
```

---

## Installing KEDA

```bash
# Using Helm (recommended)
helm repo add kedacore https://kedacore.github.io/charts
helm repo update
helm install keda kedacore/keda --namespace keda --create-namespace

# Using kubectl (YAML manifests)
kubectl apply -f https://github.com/kedacore/keda/releases/download/v2.12.0/keda-2.12.0.yaml

# Verify installation
kubectl get pods -n keda
```

Expected output:
```
NAME                                      READY   STATUS    RESTARTS   AGE
keda-metrics-apiserver-5d9b7b7b7b-xxxxx   1/1     Running   0          1m
keda-operator-7c7c7c7c7c-xxxxx            1/1     Running   0          1m
```

---

## KEDA Key Concepts

```
KEDA TERMINOLOGY
================

ScaledObject
------------
- Defines HOW to scale a Deployment/StatefulSet
- Specifies triggers (where to get metrics from)
- KEDA creates an HPA based on this

ScaledJob
---------
- Defines HOW to scale Kubernetes Jobs
- Creates new Job instances based on events
- Good for: one-off processing tasks

Trigger
-------
- The event source that drives scaling
- Examples: queue length, cron schedule, HTTP requests
- Each ScaledObject can have multiple triggers

TriggerAuthentication
---------------------
- Credentials for connecting to external systems
- Keeps secrets separate from ScaledObject
- Can be reused across multiple ScaledObjects
```

---

## Quick Example: Azure Service Bus

```yaml
# ScaledObject for Azure Service Bus
apiVersion: keda.sh/v1alpha1
kind: ScaledObject
metadata:
  name: order-processor
spec:
  scaleTargetRef:
    name: order-processor-deployment
  minReplicaCount: 0              # Scale to zero!
  maxReplicaCount: 10
  triggers:
  - type: azure-servicebus
    metadata:
      queueName: orders
      messageCount: "5"           # 1 pod per 5 messages
      connectionFromEnv: AzureServiceBusConnection
```

This tells KEDA:
- Watch the "orders" queue in Azure Service Bus
- For every 5 messages, add 1 pod
- Scale between 0 and 10 pods
- Connect using the connection string in environment variable

---

## Summary

```
KEDA: KUBERNETES EVENT-DRIVEN AUTOSCALING
=========================================

WHAT IT IS:
- Extension to Kubernetes for event-driven scaling
- Works WITH HPA, not against it
- Supports 50+ event sources (scalers)

WHY USE IT:
- Scale based on queue length, not just CPU
- Scale to zero (save money)
- Event-driven architecture support
- Simple to configure

KEY COMPONENTS:
+-------------+     +------------+     +-----+     +------+
| External    | --> | KEDA       | --> | HPA | --> | Pods |
| Events      |     | Operator   |     |     |     |      |
+-------------+     +------------+     +-----+     +------+

KEDA RESOURCES:
- ScaledObject: For Deployments (continuous workloads)
- ScaledJob: For Jobs (one-off tasks)
- TriggerAuthentication: For credentials

POPULAR SCALERS:
- Azure Service Bus, Kafka, RabbitMQ, AWS SQS
- Prometheus, Cron, HTTP, PostgreSQL, Redis
```

**Next up:** Deep dive into ScaledObject - how to configure KEDA for your deployments!
