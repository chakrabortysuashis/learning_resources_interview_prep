# Horizontal Pod Autoscaler (HPA)

## What is HPA?

**Horizontal Pod Autoscaler (HPA)** automatically scales the number of pod replicas based on observed metrics like CPU utilization, memory usage, or custom metrics.

**Key word: HORIZONTAL** = Adding MORE pods (scaling OUT), not making pods bigger.

```
HORIZONTAL SCALING (HPA does this)
==================================
Add more pods when load increases:

Low Load:     [Pod 1] [Pod 2]
              
High Load:    [Pod 1] [Pod 2] [Pod 3] [Pod 4] [Pod 5]


VERTICAL SCALING (HPA does NOT do this)
=======================================
Make existing pods bigger:

Low Load:     [Small Pod]

High Load:    [  BIGGER POD  ]

(VPA does vertical scaling - covered in next section)
```

---

## The Cashier Analogy

Think of HPA like a smart store manager:

```
GROCERY STORE ANALOGY
=====================

Situation: Monday morning, few customers
+------------------------------------------+
|  STORE                                   |
|                                          |
|  Register 1: [Cashier]  <-- 2 customers  |
|  Register 2: [Cashier]  <-- 1 customer   |
|  Register 3: [CLOSED]                    |
|  Register 4: [CLOSED]                    |
|                                          |
|  Queue length: SHORT (2-3 people)        |
|  Manager thinks: "2 cashiers is enough"  |
+------------------------------------------+

Situation: Saturday afternoon, BUSY!
+------------------------------------------+
|  STORE                                   |
|                                          |
|  Register 1: [Cashier]  <-- 5 customers  |
|  Register 2: [Cashier]  <-- 5 customers  |
|  Register 3: [Cashier]  <-- 4 customers  |  <-- Opened!
|  Register 4: [Cashier]  <-- 4 customers  |  <-- Opened!
|                                          |
|  Queue length: LONG (detected!)          |
|  Manager thinks: "Need more cashiers!"   |
+------------------------------------------+

HPA is the smart manager who:
- Watches the queue length (CPU/memory metrics)
- Opens more registers (creates more pods) when busy
- Closes registers (removes pods) when quiet
- Never opens more than max registers (maxReplicas)
- Never closes below minimum (minReplicas)
```

---

## How HPA Works

```
+------------------------------------------------------------------+
|                    HPA CONTROL LOOP                              |
+------------------------------------------------------------------+

Every 15 seconds (default), HPA does this:

    +----------------+
    | Metrics Server |  <-- Collects CPU/memory from all pods
    +----------------+
           |
           | "Pod A: 80% CPU, Pod B: 70% CPU"
           v
    +----------------+
    |      HPA       |  <-- Calculates: avg CPU = 75%
    |                |      Target is 50%
    |                |      75% > 50% = NEED MORE PODS!
    +----------------+
           |
           | "Scale to 4 replicas"
           v
    +----------------+
    |   Deployment   |  <-- Updates replica count
    +----------------+
           |
           v
    +------+------+------+------+
    | Pod1 | Pod2 | Pod3 | Pod4 |  <-- New pods created
    +------+------+------+------+

```

### The Math Behind Scaling

```
HPA uses this formula:

desiredReplicas = ceil(currentReplicas * (currentMetricValue / desiredMetricValue))

EXAMPLE:
--------
Current replicas: 2
Current CPU: 80%
Target CPU: 50%

desiredReplicas = ceil(2 * (80 / 50))
                = ceil(2 * 1.6)
                = ceil(3.2)
                = 4 replicas

So HPA will scale from 2 to 4 pods!
```

---

## Architecture Diagram

```
+------------------------------------------------------------------+
|                     HPA ARCHITECTURE                             |
+------------------------------------------------------------------+

                          Kubernetes Cluster
+------------------------------------------------------------------+
|                                                                  |
|   +------------------+                                           |
|   |  Metrics Server  |  <-- Installed separately (addon)         |
|   |                  |      Collects metrics from kubelets       |
|   +--------+---------+                                           |
|            |                                                     |
|            | Metrics (CPU, Memory)                               |
|            v                                                     |
|   +------------------+                                           |
|   |       HPA        |  <-- Kubernetes native resource           |
|   | (my-app-hpa)     |      Runs in control plane                |
|   +--------+---------+                                           |
|            |                                                     |
|            | Scale commands                                      |
|            v                                                     |
|   +------------------+                                           |
|   |   Deployment     |                                           |
|   |   (my-app)       |                                           |
|   +--------+---------+                                           |
|            |                                                     |
|            | Creates/Deletes                                     |
|            v                                                     |
|   +------+------+------+------+------+                           |
|   | Pod  | Pod  | Pod  | Pod  | Pod  |                           |
|   +------+------+------+------+------+                           |
|                                                                  |
+------------------------------------------------------------------+
```

### Mermaid Flowchart

```mermaid
flowchart TB
    subgraph "Control Plane"
        MS[Metrics Server]
        HPA[Horizontal Pod Autoscaler]
        API[API Server]
    end
    
    subgraph "Workloads"
        DEP[Deployment]
        RS[ReplicaSet]
        P1[Pod 1]
        P2[Pod 2]
        P3[Pod 3]
    end
    
    P1 -->|CPU/Memory metrics| MS
    P2 -->|CPU/Memory metrics| MS
    P3 -->|CPU/Memory metrics| MS
    MS -->|Aggregated metrics| HPA
    HPA -->|"Scale decision"| API
    API -->|Update replicas| DEP
    DEP --> RS
    RS --> P1
    RS --> P2
    RS --> P3
```

---

## Prerequisites: Metrics Server

HPA needs a **Metrics Server** to work. Without it, HPA has no metrics to look at!

```bash
# Check if metrics-server is installed
kubectl get deployment metrics-server -n kube-system

# If not installed, install it (for most clusters):
kubectl apply -f https://github.com/kubernetes-sigs/metrics-server/releases/latest/download/components.yaml

# For local clusters (minikube, kind), you might need:
# minikube addons enable metrics-server

# Verify it's working
kubectl top nodes
kubectl top pods
```

---

## Basic HPA Example

### Step 1: Create a Deployment with Resource Requests

```yaml
# my-app-deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: my-app
spec:
  replicas: 2                    # Starting with 2 pods
  selector:
    matchLabels:
      app: my-app
  template:
    metadata:
      labels:
        app: my-app
    spec:
      containers:
      - name: my-app
        image: my-app:1.0
        resources:
          requests:              # REQUIRED for HPA to work!
            cpu: "100m"          # Request 100 millicores (0.1 CPU)
            memory: "128Mi"      # Request 128 MiB memory
          limits:
            cpu: "500m"          # Max 500 millicores (0.5 CPU)
            memory: "512Mi"      # Max 512 MiB memory
        ports:
        - containerPort: 8080
```

**IMPORTANT:** HPA calculates CPU percentage based on `requests`, not `limits`!

```
If request = 100m and pod uses 80m:
CPU utilization = 80m / 100m = 80%

If request = 100m and pod uses 150m:
CPU utilization = 150m / 100m = 150%
```

### Step 2: Create the HPA

```yaml
# my-app-hpa.yaml
apiVersion: autoscaling/v2           # Use v2 for more features
kind: HorizontalPodAutoscaler
metadata:
  name: my-app-hpa
spec:
  scaleTargetRef:                    # What to scale
    apiVersion: apps/v1
    kind: Deployment
    name: my-app                     # Must match deployment name
  
  minReplicas: 2                     # Never go below 2 pods
  maxReplicas: 10                    # Never exceed 10 pods
  
  metrics:                           # What metrics to use
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 50       # Target 50% CPU usage
```

### Using kubectl Command (Alternative)

```bash
# Create HPA with one command
kubectl autoscale deployment my-app \
  --min=2 \
  --max=10 \
  --cpu-percent=50
```

---

## Detailed HPA YAML with Annotations

```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: my-app-hpa
  namespace: production
  labels:
    app: my-app
spec:
  # ============================================================
  # SCALE TARGET - What resource should HPA scale?
  # ============================================================
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment              # Can also be: StatefulSet, ReplicaSet
    name: my-app
  
  # ============================================================
  # REPLICA BOUNDS - Safety limits
  # ============================================================
  minReplicas: 2                  # Minimum pods (for high availability)
  maxReplicas: 20                 # Maximum pods (cost/resource limit)
  
  # ============================================================
  # METRICS - What triggers scaling?
  # ============================================================
  metrics:
  
  # --- CPU-based scaling ---
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 50    # Scale when avg CPU > 50%
  
  # --- Memory-based scaling ---
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 70    # Scale when avg memory > 70%
  
  # ============================================================
  # SCALING BEHAVIOR - How fast to scale up/down?
  # ============================================================
  behavior:
    # --- Scale UP behavior ---
    scaleUp:
      stabilizationWindowSeconds: 0      # React immediately
      policies:
      - type: Percent
        value: 100                       # Can double pods
        periodSeconds: 15                # Every 15 seconds
      - type: Pods
        value: 4                         # Or add up to 4 pods
        periodSeconds: 15
      selectPolicy: Max                  # Use whichever adds more
    
    # --- Scale DOWN behavior ---
    scaleDown:
      stabilizationWindowSeconds: 300    # Wait 5 min before scaling down
      policies:
      - type: Percent
        value: 10                        # Remove max 10% of pods
        periodSeconds: 60                # Per minute
      selectPolicy: Max
```

---

## Understanding Scaling Behavior

### Scale Up vs Scale Down

```
WHY DIFFERENT BEHAVIORS?
========================

SCALE UP: Should be FAST
- Users are waiting!
- Requests are timing out!
- We need pods NOW!

   Traffic spike detected
          |
          v (0 seconds stabilization)
   [Add pods immediately]


SCALE DOWN: Should be SLOW
- Don't want to scale down too fast
- What if traffic comes back?
- Premature scale-down = scale-up again = thrashing

   Traffic drop detected
          |
          v (wait 5 minutes)
   [If still low, remove pods]
```

### Stabilization Window

```
STABILIZATION WINDOW EXPLAINED
==============================

Scenario: Traffic is fluctuating

Time:   0s     30s    60s    90s    120s
Load:   High   Low    High   Low    High
        ^      ^      ^      ^      ^
        |      |      |      |      |
        
Without stabilization (window = 0):
Pods:   10     5      10     5      10
Result: Constant scaling = BAD!

With stabilization (window = 300s):
Pods:   10     10     10     10     10
Result: HPA looks at highest value in last 5 min
        Stays at 10 pods, stable!
```

### Policies Explained

```yaml
policies:
- type: Percent
  value: 100              # Can scale by 100% (double)
  periodSeconds: 15       # Every 15 seconds
- type: Pods  
  value: 4                # Or by 4 pods
  periodSeconds: 15       # Every 15 seconds
selectPolicy: Max         # Use whichever allows more scaling
```

```
EXAMPLE: Currently have 3 pods, need to scale up

Policy 1 (Percent): 100% of 3 = 3 more pods = 6 total
Policy 2 (Pods): 4 more pods = 7 total

selectPolicy: Max = Use Policy 2 = 7 pods


EXAMPLE: Currently have 10 pods, need to scale up

Policy 1 (Percent): 100% of 10 = 10 more pods = 20 total
Policy 2 (Pods): 4 more pods = 14 total

selectPolicy: Max = Use Policy 1 = 20 pods
```

---

## Multiple Metrics

HPA can use multiple metrics. It calculates desired replicas for EACH metric and uses the HIGHEST value.

```yaml
metrics:
- type: Resource
  resource:
    name: cpu
    target:
      type: Utilization
      averageUtilization: 50
- type: Resource
  resource:
    name: memory
    target:
      type: Utilization
      averageUtilization: 70
```

```
EXAMPLE WITH MULTIPLE METRICS
=============================

Current state: 3 pods

CPU calculation:
  Current avg CPU: 60%
  Target: 50%
  Desired = ceil(3 * 60/50) = ceil(3.6) = 4 pods

Memory calculation:
  Current avg memory: 90%
  Target: 70%
  Desired = ceil(3 * 90/70) = ceil(3.86) = 4 pods

Final decision: MAX(4, 4) = 4 pods

What if memory was 140%?
  Desired = ceil(3 * 140/70) = ceil(6) = 6 pods
  Final: MAX(4, 6) = 6 pods (memory drives scaling)
```

---

## Common Commands

```bash
# Create HPA from YAML
kubectl apply -f my-app-hpa.yaml

# Create HPA with kubectl
kubectl autoscale deployment my-app --min=2 --max=10 --cpu-percent=50

# List all HPAs
kubectl get hpa

# Get detailed HPA info
kubectl describe hpa my-app-hpa

# Watch HPA in real-time
kubectl get hpa my-app-hpa -w

# Delete HPA
kubectl delete hpa my-app-hpa
```

### Example Output

```bash
$ kubectl get hpa
NAME         REFERENCE           TARGETS   MINPODS   MAXPODS   REPLICAS   AGE
my-app-hpa   Deployment/my-app   45%/50%   2         10        3          5m

# TARGETS shows: current/target
# 45%/50% means current CPU is 45%, target is 50%
# Since 45% < 50%, no scaling needed
```

---

## Troubleshooting HPA

### Common Issues

```
ISSUE: HPA shows <unknown>/50%
==============================
$ kubectl get hpa
NAME         TARGETS         MINPODS   MAXPODS   REPLICAS
my-app-hpa   <unknown>/50%   2         10        2

CAUSES:
1. Metrics server not installed
   -> kubectl get deployment metrics-server -n kube-system
   
2. Pod has no resource requests
   -> Add requests.cpu to container spec
   
3. Metrics server needs time
   -> Wait 1-2 minutes after pod starts


ISSUE: HPA not scaling up
=========================
CHECKLIST:
[ ] Is current metric above target?
[ ] Have you reached maxReplicas?
[ ] Are pods actually starting successfully?
[ ] Check events: kubectl describe hpa my-app-hpa


ISSUE: HPA scaling too aggressively  
===================================
SOLUTION: Adjust behavior

behavior:
  scaleUp:
    stabilizationWindowSeconds: 60    # Wait before scaling up
  scaleDown:
    stabilizationWindowSeconds: 300   # Wait before scaling down
```

---

## HPA Best Practices

```
+------------------------------------------------------------------+
|                    HPA BEST PRACTICES                            |
+------------------------------------------------------------------+

1. ALWAYS SET RESOURCE REQUESTS
   - HPA needs requests to calculate utilization
   - No requests = HPA shows <unknown>

2. SET REALISTIC TARGETS
   - 50% CPU is common starting point
   - Too low = always scaling = expensive
   - Too high = slow to react = poor performance

3. USE APPROPRIATE MIN/MAX
   - minReplicas >= 2 for high availability
   - maxReplicas based on budget/cluster capacity

4. CONFIGURE SCALE-DOWN CAREFULLY
   - stabilizationWindowSeconds: 300 (5 min) is good default
   - Prevents thrashing

5. TEST UNDER LOAD
   - Verify HPA behaves as expected
   - Use tools like k6, hey, or Apache Bench

6. MONITOR HPA EVENTS
   - kubectl describe hpa <name>
   - Watch for ScalingLimited or other warnings

+------------------------------------------------------------------+
```

---

## Summary

```
HORIZONTAL POD AUTOSCALER (HPA)
===============================

WHAT IT DOES:
- Automatically adjusts number of pod replicas
- Based on CPU, memory, or custom metrics
- Scales OUT (more pods), not UP (bigger pods)

KEY COMPONENTS:
+---------------+     +-----+     +------------+     +------+
| Metrics Server| --> | HPA | --> | Deployment | --> | Pods |
+---------------+     +-----+     +------------+     +------+

IMPORTANT SETTINGS:
- minReplicas: Safety floor (usually 2+)
- maxReplicas: Cost ceiling
- targetUtilization: When to scale (e.g., 50% CPU)
- behavior: How fast to scale up/down

REQUIREMENTS:
- Metrics Server must be installed
- Pods must have resource requests defined
```

**Next up:** Learn about Vertical Pod Autoscaler (VPA) which makes pods bigger instead of adding more!
