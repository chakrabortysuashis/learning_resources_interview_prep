# Control Plane Components

## What is the Control Plane?

The **Control Plane** is the brain of your Kubernetes cluster. It makes all the important decisions and never runs your actual applications (that's the worker nodes' job).

Think of it as the **corporate headquarters** of a company - it manages, coordinates, and makes decisions, but the actual work happens in the branch offices (worker nodes).

```
+===========================================================================+
|                          CONTROL PLANE                                     |
|                    "The Brain of Kubernetes"                               |
+===========================================================================+
|                                                                            |
|   +------------------+          +------------------+                       |
|   |    API SERVER    |          |       etcd       |                       |
|   |                  |          |                  |                       |
|   |   The           |          |    The           |                       |
|   |   Receptionist  |<-------->|    Database      |                       |
|   |                  |          |                  |                       |
|   +--------+---------+          +------------------+                       |
|            |                                                               |
|            | communicates with                                             |
|            |                                                               |
|   +--------+---------+          +------------------+                       |
|   |    SCHEDULER     |          |    CONTROLLER    |                       |
|   |                  |          |     MANAGER      |                       |
|   |   The Task       |          |                  |                       |
|   |   Assigner       |          |   The Supervisor |                       |
|   |                  |          |                  |                       |
|   +------------------+          +------------------+                       |
|                                                                            |
+===========================================================================+
```

---

## 1. API Server - The Receptionist

### What It Does

The API Server is the **front door** of your Kubernetes cluster. Every single request - whether from you, other components, or external services - goes through the API Server first.

```
+==========================================================================+
|                           API SERVER                                      |
|                      "The Receptionist"                                   |
+==========================================================================+

                    ALL VISITORS MUST CHECK IN HERE!
                    
    kubectl --------+
                    |
    Dashboard ------+
                    |------> [API SERVER] ------> Rest of Cluster
    Other apps -----+              |
                    |              v
    Kubelet --------+         "Who are you?"
                              "What do you want?"
                              "Are you allowed to do that?"

+==========================================================================+
```

### Main Responsibilities

```
+-------------------------------------------------------------------------+
|                    API SERVER RESPONSIBILITIES                           |
+-------------------------------------------------------------------------+
|                                                                          |
|  1. AUTHENTICATION - "Who are you?"                                     |
|     +-------------------------------------------------------------+     |
|     |  Request comes in --> Check credentials --> Valid? Proceed  |     |
|     +-------------------------------------------------------------+     |
|                                                                          |
|  2. AUTHORIZATION - "What are you allowed to do?"                       |
|     +-------------------------------------------------------------+     |
|     |  User identified --> Check permissions --> Can create pods? |     |
|     +-------------------------------------------------------------+     |
|                                                                          |
|  3. VALIDATION - "Is your request correct?"                             |
|     +-------------------------------------------------------------+     |
|     |  Request format --> Check YAML/JSON --> All fields valid?   |     |
|     +-------------------------------------------------------------+     |
|                                                                          |
|  4. ROUTING - "Let me send this to the right place"                     |
|     +-------------------------------------------------------------+     |
|     |  Valid request --> Send to etcd, Scheduler, or Controller   |     |
|     +-------------------------------------------------------------+     |
|                                                                          |
+-------------------------------------------------------------------------+
```

### Analogy: The Receptionist at a Corporate Office

```
Real World Receptionist              API Server
=======================              ==========

Visitor arrives at front desk   -->  Request arrives at API
                |                            |
                v                            v
"May I see your ID?"            -->  Check authentication token
                |                            |
                v                            v
"Are you on the visitor list?"  -->  Check RBAC permissions
                |                            |
                v                            v
"Please fill this form"         -->  Validate request format
                |                            |
                v                            v
"I'll direct you to Room 205"   -->  Route to appropriate handler
```

---

## 2. etcd - The Database

### What It Does

**etcd** (pronounced "et-see-dee") is a distributed key-value database that stores ALL the cluster's configuration and state. It's the single source of truth for your entire cluster.

```
+==========================================================================+
|                              etcd                                         |
|                    "The Company Database"                                 |
+==========================================================================+

  etcd stores EVERYTHING:
  
  +----------------------------------------------------------------------+
  |                                                                       |
  |  Key                              Value                               |
  |  ===                              =====                               |
  |                                                                       |
  |  /nodes/node-1                    {status: "Ready", cpu: "4 cores"}  |
  |  /nodes/node-2                    {status: "Ready", cpu: "8 cores"}  |
  |                                                                       |
  |  /pods/web-app-xyz                {image: "nginx", replicas: 3}      |
  |  /pods/database-abc               {image: "postgres", replicas: 1}   |
  |                                                                       |
  |  /services/frontend               {port: 80, type: "LoadBalancer"}   |
  |  /services/backend                {port: 8080, type: "ClusterIP"}    |
  |                                                                       |
  |  /secrets/db-password             {data: "encrypted..."}             |
  |  /configmaps/app-config           {data: "key=value..."}             |
  |                                                                       |
  +----------------------------------------------------------------------+

+==========================================================================+
```

### Why etcd is Critical

```
              IF etcd DIES, YOUR CLUSTER IS BLIND!
              
  +----------------+         +----------------+
  |  Healthy etcd  |         |   Dead etcd    |
  +----------------+         +----------------+
         |                          |
         v                          v
  Cluster knows:             Cluster knows:
  - What pods exist          - NOTHING!
  - Where they run           - Can't schedule
  - Their health             - Can't recover
  - All configs              - Complete chaos

  That's why production clusters have 3, 5, or 7 etcd nodes!
  (Always odd numbers for voting/consensus)
```

### Analogy: The Filing Cabinet

```
+==========================================================================+
|                    etcd = THE FILING CABINET                              |
+==========================================================================+
|                                                                           |
|  Imagine a company's filing cabinet that stores:                         |
|                                                                           |
|  +-------------------+  +-------------------+  +-------------------+      |
|  |  EMPLOYEE FILES   |  |  PROJECT FILES    |  |   POLICY FILES    |      |
|  |                   |  |                   |  |                   |      |
|  | - John's records  |  | - Project Alpha   |  | - Security rules  |      |
|  | - Jane's records  |  | - Project Beta    |  | - Access policies |      |
|  | - Bob's records   |  | - Project Gamma   |  | - Company configs |      |
|  +-------------------+  +-------------------+  +-------------------+      |
|                                                                           |
|  In Kubernetes:                                                          |
|                                                                           |
|  +-------------------+  +-------------------+  +-------------------+      |
|  |    NODE INFO      |  |    POD INFO       |  |   CONFIG INFO     |      |
|  |                   |  |                   |  |                   |      |
|  | - Node 1 status   |  | - Pod A details   |  | - Secrets         |      |
|  | - Node 2 status   |  | - Pod B details   |  | - ConfigMaps      |      |
|  | - Node 3 status   |  | - Pod C details   |  | - Policies        |      |
|  +-------------------+  +-------------------+  +-------------------+      |
|                                                                           |
+==========================================================================+
```

---

## 3. Scheduler - The Task Assigner

### What It Does

The **Scheduler** watches for newly created Pods that don't have an assigned node, and selects the best node for them to run on.

```
+==========================================================================+
|                           SCHEDULER                                       |
|                    "The Task Assignment Manager"                          |
+==========================================================================+

  New pod created --> Scheduler picks the best node

  +-----------------------------------------------------------------------+
  |                                                                        |
  |   SCHEDULER's DECISION PROCESS:                                       |
  |                                                                        |
  |   New Pod: "I need 2 CPU and 4GB RAM"                                 |
  |                                                                        |
  |   +-----------+    +-----------+    +-----------+                     |
  |   |  Node 1   |    |  Node 2   |    |  Node 3   |                     |
  |   |           |    |           |    |           |                     |
  |   | Free:     |    | Free:     |    | Free:     |                     |
  |   | 1 CPU     |    | 4 CPU     |    | 2 CPU     |                     |
  |   | 2 GB RAM  |    | 8 GB RAM  |    | 4 GB RAM  |                     |
  |   |           |    |           |    |           |                     |
  |   | REJECTED  |    | SELECTED! |    | POSSIBLE  |                     |
  |   | (not      |    | (best     |    | (fits     |                     |
  |   |  enough)  |    |  fit!)    |    |  barely)  |                     |
  |   +-----------+    +-----------+    +-----------+                     |
  |                          |                                            |
  |                          v                                            |
  |                    Pod scheduled to Node 2                            |
  |                                                                        |
  +-----------------------------------------------------------------------+

+==========================================================================+
```

### Scheduler's Criteria

```
+--------------------------------------------------------------------------+
|                    HOW THE SCHEDULER DECIDES                              |
+--------------------------------------------------------------------------+
|                                                                           |
|  STEP 1: FILTERING - "Which nodes CAN run this pod?"                     |
|  ====================================================                    |
|                                                                           |
|    Checks:                                                               |
|    [X] Does node have enough CPU?                                        |
|    [X] Does node have enough memory?                                     |
|    [X] Does node have required ports available?                          |
|    [X] Does node match pod's node selector labels?                       |
|    [X] Does node satisfy pod's affinity rules?                           |
|                                                                           |
|    Result: List of FEASIBLE nodes                                        |
|                                                                           |
+--------------------------------------------------------------------------+
|                                                                           |
|  STEP 2: SCORING - "Which node is BEST?"                                 |
|  ========================================                                 |
|                                                                           |
|    Scores each feasible node on:                                         |
|    - Resource availability (more free = better)                          |
|    - Pod spreading (avoid putting all eggs in one basket)                |
|    - Affinity preferences (user-defined preferences)                     |
|                                                                           |
|    Example:                                                              |
|    +-------+-------+-------+                                             |
|    | Node  | Score | Rank  |                                             |
|    +-------+-------+-------+                                             |
|    | A     |  75   |  2nd  |                                             |
|    | B     |  92   |  1st  | <-- WINNER!                                 |
|    | C     |  68   |  3rd  |                                             |
|    +-------+-------+-------+                                             |
|                                                                           |
+--------------------------------------------------------------------------+
```

### Analogy: Manager Assigning Tasks

```
Real World Manager                    Kubernetes Scheduler
==================                    ====================

New project comes in          -->    New Pod needs to be created
       |                                      |
       v                                      v
"Who has availability?"       -->    "Which nodes have resources?"
       |                                      |
       v                                      v
Check team members' workload  -->    Check node CPU/memory usage
       |                                      |
       v                                      v
"John has light workload      -->    "Node 2 has most free resources
 and skills match"                    and matches pod requirements"
       |                                      |
       v                                      v
Assign project to John        -->    Schedule pod to Node 2
```

---

## 4. Controller Manager - The Supervisor

### What It Does

The **Controller Manager** runs controllers that watch the cluster state and work to move the ACTUAL state towards the DESIRED state.

```
+==========================================================================+
|                       CONTROLLER MANAGER                                  |
|                    "The Supervisor / Watchdog"                            |
+==========================================================================+

  Controller Manager = Collection of Control Loops

  +-----------------------------------------------------------------------+
  |                                                                        |
  |  DESIRED STATE (what you want)     ACTUAL STATE (what really exists)  |
  |         |                                    |                        |
  |         v                                    v                        |
  |  +--------------+                   +--------------+                  |
  |  |  3 replicas  |                   |  2 replicas  |                  |
  |  |  of web app  |                   |  of web app  |                  |
  |  +--------------+                   +--------------+                  |
  |         |                                    |                        |
  |         +----------------+-------------------+                        |
  |                          |                                            |
  |                          v                                            |
  |                  +---------------+                                    |
  |                  |  CONTROLLER   |                                    |
  |                  |    MANAGER    |                                    |
  |                  +---------------+                                    |
  |                          |                                            |
  |                          v                                            |
  |                  "MISMATCH DETECTED!                                  |
  |                   Desired: 3 pods                                     |
  |                   Actual: 2 pods                                      |
  |                   Action: Create 1 more pod"                          |
  |                                                                        |
  +-----------------------------------------------------------------------+

+==========================================================================+
```

### Types of Controllers

```
+--------------------------------------------------------------------------+
|                    CONTROLLERS INSIDE CONTROLLER MANAGER                  |
+--------------------------------------------------------------------------+

  1. REPLICATION CONTROLLER
  =========================
  
     Ensures correct number of pod replicas are running
     
     Desired: [Pod][Pod][Pod]  (3 pods)
     Actual:  [Pod][Pod]       (2 pods)
                    |
                    v
     Action: Create [Pod]      (now 3 pods!)


  2. NODE CONTROLLER
  ==================
  
     Monitors node health, responds when nodes go down
     
     +------+  +------+  +------+
     |Node 1|  |Node 2|  |Node 3|
     |  OK  |  | DEAD |  |  OK  |
     +------+  +------+  +------+
                  |
                  v
     Action: Mark Node 2 as "NotReady"
             Reschedule its pods to other nodes


  3. ENDPOINT CONTROLLER
  ======================
  
     Connects Services to Pods
     
     Service: "frontend"
          |
          v
     Finds all pods with label "app=frontend"
          |
          v
     Creates endpoints: pod1-ip, pod2-ip, pod3-ip


  4. SERVICE ACCOUNT CONTROLLER
  =============================
  
     Creates default accounts for new namespaces
     
     New Namespace: "production"
          |
          v
     Create: "default" service account

+--------------------------------------------------------------------------+
```

### Analogy: The Supervisor

```
+==========================================================================+
|                   CONTROLLER MANAGER = THE SUPERVISOR                     |
+==========================================================================+
|                                                                           |
|  Imagine a supervisor who constantly walks the factory floor:            |
|                                                                           |
|  +-------------------------------------------------------------------+   |
|  |                                                                    |   |
|  |  SUPERVISOR'S CHECKLIST:                                          |   |
|  |                                                                    |   |
|  |  [ ] Assembly Line 1: Should have 5 workers                       |   |
|  |      --> Currently has 5 workers                                  |   |
|  |      --> Status: OK                                               |   |
|  |                                                                    |   |
|  |  [ ] Assembly Line 2: Should have 3 workers                       |   |
|  |      --> Currently has 2 workers (1 called in sick)               |   |
|  |      --> Status: MISMATCH!                                        |   |
|  |      --> Action: Call in a replacement worker                     |   |
|  |                                                                    |   |
|  |  [ ] Machine Status: All machines should be operational           |   |
|  |      --> Machine A: Working                                       |   |
|  |      --> Machine B: Broken!                                       |   |
|  |      --> Action: Move work to Machine A, call maintenance         |   |
|  |                                                                    |   |
|  +-------------------------------------------------------------------+   |
|                                                                           |
|  The supervisor NEVER stops checking. This is the control loop.          |
|                                                                           |
+==========================================================================+
```

---

## How Control Plane Components Interact

```
+==========================================================================+
|              CONTROL PLANE COMPONENT INTERACTION                          |
+==========================================================================+

                         +---------------------------+
                         |       USER / kubectl      |
                         +---------------------------+
                                      |
                                      | 1. "Create 3 nginx pods"
                                      v
   +-----------------------------------------------------------------------+
   |                                                                        |
   |  +------------------+                           +------------------+   |
   |  |                  |   2. Validate & Store     |                  |   |
   |  |    API SERVER    | -----------------------> |      etcd        |   |
   |  |                  |                           |                  |   |
   |  |  (Receptionist)  | <----------------------- | (Database)       |   |
   |  |                  |   3. "Stored!"            |                  |   |
   |  +--------+---------+                           +------------------+   |
   |           |                                                            |
   |           | 4. "New pods need scheduling"                             |
   |           v                                                            |
   |  +------------------+                                                  |
   |  |                  |                                                  |
   |  |    SCHEDULER     |  5. Evaluates nodes, picks best ones            |
   |  |                  |                                                  |
   |  |  (Task Assigner) |  6. "Assign pod1->Node2, pod2->Node3..."       |
   |  |                  |                                                  |
   |  +--------+---------+                                                  |
   |           |                                                            |
   |           | 7. Update etcd with assignments                           |
   |           v                                                            |
   |  +------------------+                           +------------------+   |
   |  |                  |                           |                  |   |
   |  |    API SERVER    | -----------------------> |      etcd        |   |
   |  |                  |                           |                  |   |
   |  +--------+---------+                           +------------------+   |
   |           |                                                            |
   |           |                                                            |
   |  +------------------+                                                  |
   |  |                  |                                                  |
   |  |   CONTROLLER     |  8. Constantly watches:                         |
   |  |    MANAGER       |     "Are 3 pods running?"                       |
   |  |                  |     "If not, fix it!"                           |
   |  |  (Supervisor)    |                                                  |
   |  |                  |                                                  |
   |  +------------------+                                                  |
   |                                                                        |
   +-----------------------------------------------------------------------+
                                      |
                                      | 9. Instructions sent to worker nodes
                                      v
                         +---------------------------+
                         |      WORKER NODES         |
                         |    (Actually run pods)    |
                         +---------------------------+
```

---

## Mermaid Diagram: Control Plane Flow

```mermaid
flowchart TB
    subgraph ControlPlane["Control Plane"]
        API["API Server<br/>(Receptionist)"]
        ETCD["etcd<br/>(Database)"]
        SCHED["Scheduler<br/>(Task Assigner)"]
        CM["Controller Manager<br/>(Supervisor)"]
    end

    USER["User / kubectl"]
    
    USER -->|"1. Create deployment"| API
    API -->|"2. Store state"| ETCD
    ETCD -->|"3. Confirm"| API
    
    SCHED -->|"4. Watch for unscheduled pods"| API
    API -->|"5. Here are new pods"| SCHED
    SCHED -->|"6. Assign to nodes"| API
    API -->|"7. Update assignments"| ETCD
    
    CM -->|"8. Watch desired vs actual"| API
    API -->|"9. Current state"| CM
    CM -->|"10. Fix any differences"| API
    
    style API fill:#e1f5fe
    style ETCD fill:#fff3e0
    style SCHED fill:#e8f5e9
    style CM fill:#fce4ec
```

---

## Summary Table

| Component | Role | Analogy | Talks To |
|-----------|------|---------|----------|
| **API Server** | Gateway for all operations | Receptionist | Everything |
| **etcd** | Stores all cluster data | Company Database | Only API Server |
| **Scheduler** | Assigns pods to nodes | Task Assignment Manager | API Server |
| **Controller Manager** | Maintains desired state | Supervisor | API Server |

---

## Key Takeaways

```
+-----------------------------------------------------------------------+
|                         KEY TAKEAWAYS                                  |
+-----------------------------------------------------------------------+
|                                                                        |
|  1. API SERVER = Single entry point (all roads lead here)             |
|                                                                        |
|  2. etcd = The memory of the cluster (lose it, lose everything)       |
|                                                                        |
|  3. SCHEDULER = Decides WHERE pods run (not IF they run)              |
|                                                                        |
|  4. CONTROLLER MANAGER = Makes sure reality matches expectations      |
|                                                                        |
|  5. These components work TOGETHER as a team                          |
|     - API Server coordinates                                          |
|     - etcd remembers                                                   |
|     - Scheduler places                                                 |
|     - Controller Manager maintains                                     |
|                                                                        |
+-----------------------------------------------------------------------+
```

---

## What's Next?

Now let's look at the **Worker Node Components** - the parts that actually run your applications!
