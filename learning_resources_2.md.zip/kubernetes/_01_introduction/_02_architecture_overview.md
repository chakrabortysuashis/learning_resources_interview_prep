# Kubernetes Architecture Overview

## The Big Picture

Think of a Kubernetes cluster like a **company**. Every company has two main parts:

1. **Management/HQ (Control Plane)** - Makes decisions, gives orders, keeps track of everything
2. **Workers (Worker Nodes)** - Do the actual work, follow instructions from management

```
+============================================================================+
|                        KUBERNETES CLUSTER                                   |
|                     (Think of it as a Company)                             |
+============================================================================+
|                                                                             |
|  +---------------------------------------------------------------------+   |
|  |                      CONTROL PLANE (HQ/Management)                   |   |
|  |                                                                      |   |
|  |   "We make decisions, you follow them"                              |   |
|  |                                                                      |   |
|  |   +----------+  +---------+  +-----------+  +------------------+    |   |
|  |   |   API    |  |  etcd   |  | Scheduler |  |    Controller    |    |   |
|  |   |  Server  |  |         |  |           |  |     Manager      |    |   |
|  |   +----------+  +---------+  +-----------+  +------------------+    |   |
|  |                                                                      |   |
|  +---------------------------------------------------------------------+   |
|                                    |                                        |
|                                    | (Communication)                        |
|                                    |                                        |
|  +---------------------------------------------------------------------+   |
|  |                        WORKER NODES (The Workers)                    |   |
|  |                                                                      |   |
|  |   "We run the applications and report back"                         |   |
|  |                                                                      |   |
|  |   +-----------------+  +-----------------+  +-----------------+      |   |
|  |   |   Worker Node   |  |   Worker Node   |  |   Worker Node   |      |   |
|  |   |       #1        |  |       #2        |  |       #3        |      |   |
|  |   |   +--------+    |  |   +--------+    |  |   +--------+    |      |   |
|  |   |   |  Pod   |    |  |   |  Pod   |    |  |   |  Pod   |    |      |   |
|  |   |   +--------+    |  |   +--------+    |  |   +--------+    |      |   |
|  |   |   +--------+    |  |   +--------+    |  |   +--------+    |      |   |
|  |   |   |  Pod   |    |  |   |  Pod   |    |  |   |  Pod   |    |      |   |
|  |   |   +--------+    |  |   +--------+    |  |   +--------+    |      |   |
|  |   +-----------------+  +-----------------+  +-----------------+      |   |
|  |                                                                      |   |
|  +---------------------------------------------------------------------+   |
|                                                                             |
+============================================================================+
```

---

## The Company Analogy

Let's understand Kubernetes architecture using a company analogy:

```
+=========================================================================+
|                    KUBERNETES = A COMPANY                                |
+=========================================================================+
|                                                                          |
|  CONTROL PLANE = CORPORATE HEADQUARTERS                                  |
|  =========================================                               |
|                                                                          |
|  +----------------+     +----------------+     +----------------+        |
|  |  API SERVER    |     |     etcd       |     |   SCHEDULER    |        |
|  |                |     |                |     |                |        |
|  |  Receptionist  |     |   Database/    |     |    Manager     |        |
|  |  & Front Desk  |     |   File Room    |     |  who assigns   |        |
|  |                |     |                |     |    tasks       |        |
|  |  All visitors  |     |  Stores all    |     |                |        |
|  |  go through    |     |  company       |     |  "John, you    |        |
|  |  reception     |     |  records       |     |  work on       |        |
|  |                |     |                |     |  Project X"    |        |
|  +----------------+     +----------------+     +----------------+        |
|                                                                          |
|  +------------------------------------------------------------------+   |
|  |                    CONTROLLER MANAGER                             |   |
|  |                                                                   |   |
|  |    The Supervisor who ensures everything runs as expected         |   |
|  |                                                                   |   |
|  |    "We need 5 workers? Let me check... we only have 4.           |   |
|  |     I'll hire one more to match what was requested."             |   |
|  |                                                                   |   |
|  +------------------------------------------------------------------+   |
|                                                                          |
+=========================================================================+
|                                                                          |
|  WORKER NODES = COMPANY BRANCHES/OFFICES                                 |
|  =========================================                               |
|                                                                          |
|  +--------------------+  +--------------------+  +--------------------+  |
|  |  WORKER NODE #1    |  |  WORKER NODE #2    |  |  WORKER NODE #3    |  |
|  |  (Branch Office)   |  |  (Branch Office)   |  |  (Branch Office)   |  |
|  |                    |  |                    |  |                    |  |
|  |  Has employees     |  |  Has employees     |  |  Has employees     |  |
|  |  (Pods) doing      |  |  (Pods) doing      |  |  (Pods) doing      |  |
|  |  actual work       |  |  actual work       |  |  actual work       |  |
|  |                    |  |                    |  |                    |  |
|  |  Branch Manager:   |  |  Branch Manager:   |  |  Branch Manager:   |  |
|  |  Kubelet           |  |  Kubelet           |  |  Kubelet           |  |
|  +--------------------+  +--------------------+  +--------------------+  |
|                                                                          |
+=========================================================================+
```

---

## How Communication Works

Here's the flow of how you (the user) interact with Kubernetes:

```
+============================================================================+
|                     HOW YOU TALK TO KUBERNETES                              |
+============================================================================+

     YOU (Developer/Admin)
         |
         | "Hey Kubernetes, run 3 copies of my web app"
         |
         v
   +-----------+
   |  kubectl  |  <-- Command Line Tool (like sending an email to the company)
   +-----------+
         |
         | (Your request goes to...)
         |
         v
+============================================================================+
|                           CONTROL PLANE                                     |
+============================================================================+
|        |                                                                    |
|        v                                                                    |
|  +------------+                                                             |
|  | API SERVER |  <-- Step 1: Receptionist receives your request            |
|  +------------+                                                             |
|        |                                                                    |
|        |  "Let me save this request and check who can do it"               |
|        |                                                                    |
|        +----------------------+                                             |
|        |                      |                                             |
|        v                      v                                             |
|  +-----------+         +------------+                                       |
|  |   etcd    |         | SCHEDULER  |                                       |
|  +-----------+         +------------+                                       |
|   Step 2: Save          Step 3: Find                                        |
|   the request           best worker                                         |
|                              |                                              |
|                              | "Node #2 has the most free space"            |
|                              |                                              |
+============================================================================+
                               |
                               v
+============================================================================+
|                           WORKER NODE #2                                    |
+============================================================================+
|                                                                             |
|    +---------+                                                              |
|    | KUBELET |  <-- Step 4: Branch manager receives orders                  |
|    +---------+                                                              |
|         |                                                                   |
|         | "Got it! I'll create those containers now"                       |
|         |                                                                   |
|         v                                                                   |
|    +-------------------+                                                    |
|    | CONTAINER RUNTIME |  <-- Step 5: Actually creates and runs containers |
|    | (Docker/containerd)|                                                   |
|    +-------------------+                                                    |
|         |                                                                   |
|         v                                                                   |
|    +-------+  +-------+  +-------+                                          |
|    | Pod 1 |  | Pod 2 |  | Pod 3 |  <-- Step 6: Your app is running!       |
|    +-------+  +-------+  +-------+                                          |
|                                                                             |
+============================================================================+
```

---

## Mermaid Diagram: Request Flow

```mermaid
sequenceDiagram
    participant U as User
    participant K as kubectl
    participant A as API Server
    participant E as etcd
    participant S as Scheduler
    participant C as Controller Manager
    participant N as Worker Node (Kubelet)
    participant R as Container Runtime
    participant P as Pods

    U->>K: kubectl create deployment
    K->>A: HTTP Request (REST API)
    A->>E: Store desired state
    E-->>A: Confirmed
    A-->>K: Deployment created
    
    Note over S: Scheduler watches for unscheduled pods
    S->>A: Query: Any pods need scheduling?
    A-->>S: Yes, 3 pods need nodes
    S->>A: Assign pods to Node #2
    
    Note over C: Controller ensures desired = actual
    
    Note over N: Kubelet watches for assigned pods
    N->>A: Query: Any pods for me?
    A-->>N: Yes, run these 3 pods
    N->>R: Create containers
    R->>P: Containers started
    P-->>N: Running
    N->>A: Report: Pods running
```

---

## Simple Flow Diagram

```
+===========================================================================+
|                    THE KUBERNETES WORKFLOW                                 |
+===========================================================================+

  STEP 1: You give a command
  ===========================
  
      +------+                    +---------+
      | USER | ---- kubectl ----> | CLUSTER |
      +------+    "Run my app"    +---------+


  STEP 2: API Server receives it
  ==============================
  
      kubectl -----> [API SERVER] -----> "Request validated!"
                          |
                          v
                       [etcd]
                    "State saved!"


  STEP 3: Scheduler finds a home
  ==============================
  
      [SCHEDULER]: "Hmm, which node has space?"
           |
           |-- Node 1: 80% full  --> Too busy
           |-- Node 2: 30% full  --> Perfect!
           |-- Node 3: 60% full  --> Okay but not best
           |
           v
      Decision: "Send to Node 2!"


  STEP 4: Kubelet does the work
  =============================
  
      [API SERVER] -----> [KUBELET on Node 2]
                               |
                               v
                    [CONTAINER RUNTIME]
                               |
                               v
                    +-----+  +-----+  +-----+
                    |Pod 1|  |Pod 2|  |Pod 3|
                    +-----+  +-----+  +-----+


  STEP 5: Controller keeps watching
  =================================
  
      [CONTROLLER MANAGER]
            |
            | Continuously checks:
            | "User wants 3 pods"
            | "Currently running: 3 pods"
            | "All good!"
            |
            | If a pod crashes:
            | "User wants 3 pods"
            | "Currently running: 2 pods"
            | "MISMATCH! Creating 1 more pod..."

+===========================================================================+
```

---

## Components Summary Table

| Component | Lives In | Analogy | Main Job |
|-----------|----------|---------|----------|
| **API Server** | Control Plane | Receptionist | Handles ALL communication |
| **etcd** | Control Plane | Database/Filing Cabinet | Stores cluster state |
| **Scheduler** | Control Plane | Task Assignment Manager | Decides WHERE pods run |
| **Controller Manager** | Control Plane | Supervisor | Ensures desired state |
| **Kubelet** | Worker Node | Branch Manager | Manages pods on node |
| **Container Runtime** | Worker Node | Factory Floor | Actually runs containers |
| **Kube-proxy** | Worker Node | Network Admin | Handles networking |

---

## Visual: What Lives Where

```
+=======================================================================+
||                         CONTROL PLANE                                ||
||                                                                      ||
||   +--------------+    +--------+    +-----------+    +------------+ ||
||   |  API Server  |    |  etcd  |    | Scheduler |    | Controller | ||
||   |              |    |        |    |           |    |  Manager   | ||
||   +--------------+    +--------+    +-----------+    +------------+ ||
||                                                                      ||
+=======================================================================+
                                   |
                                   | Network
                                   |
         +-------------------------+-------------------------+
         |                         |                         |
         v                         v                         v
+==================+    +==================+    +==================+
||  WORKER NODE 1  ||    ||  WORKER NODE 2  ||    ||  WORKER NODE 3  ||
||                 ||    ||                 ||    ||                 ||
||  +----------+   ||    ||  +----------+   ||    ||  +----------+   ||
||  |  Kubelet |   ||    ||  |  Kubelet |   ||    ||  |  Kubelet |   ||
||  +----------+   ||    ||  +----------+   ||    ||  +----------+   ||
||                 ||    ||                 ||    ||                 ||
||  +----------+   ||    ||  +----------+   ||    ||  +----------+   ||
||  | Container|   ||    ||  | Container|   ||    ||  | Container|   ||
||  | Runtime  |   ||    ||  | Runtime  |   ||    ||  | Runtime  |   ||
||  +----------+   ||    ||  +----------+   ||    ||  +----------+   ||
||                 ||    ||                 ||    ||                 ||
||  +----------+   ||    ||  +----------+   ||    ||  +----------+   ||
||  |kube-proxy|   ||    ||  |kube-proxy|   ||    ||  |kube-proxy|   ||
||  +----------+   ||    ||  +----------+   ||    ||  +----------+   ||
||                 ||    ||                 ||    ||                 ||
||  +-----------+  ||    ||  +-----------+  ||    ||  +-----------+  ||
||  |   PODS    |  ||    ||  |   PODS    |  ||    ||  |   PODS    |  ||
||  | (Your App)|  ||    ||  | (Your App)|  ||    ||  | (Your App)|  ||
||  +-----------+  ||    ||  +-----------+  ||    ||  +-----------+  ||
||                 ||    ||                 ||    ||                 ||
+==================+    +==================+    +==================+
```

---

## Key Concepts to Remember

```
+-----------------------------------------------------------------------+
|                         KEY TAKEAWAYS                                  |
+-----------------------------------------------------------------------+
|                                                                        |
|  1. CLUSTER = Control Plane + Worker Nodes                            |
|                                                                        |
|  2. CONTROL PLANE = The Brain                                         |
|     - Makes all decisions                                             |
|     - Stores all state                                                |
|     - Never runs your apps                                            |
|                                                                        |
|  3. WORKER NODES = The Muscles                                        |
|     - Run your actual applications                                    |
|     - Report back to control plane                                    |
|     - Can be added/removed as needed                                  |
|                                                                        |
|  4. ALL communication goes through the API Server                     |
|     - kubectl -> API Server                                           |
|     - Kubelet -> API Server                                           |
|     - Scheduler -> API Server                                         |
|                                                                        |
+-----------------------------------------------------------------------+
```

---

## What's Next?

Now that you understand the big picture, let's dive deeper into:
- **Lesson 3**: Control Plane Components (The Management Team)
- **Lesson 4**: Worker Node Components (The Workers)
