# Worker Node Components

## What is a Worker Node?

A **Worker Node** (also just called "Node") is a machine that runs your actual applications. While the Control Plane makes decisions, Worker Nodes do the heavy lifting - they're where your containers actually run.

Think of Worker Nodes as the **branch offices** or **factory floors** of your company - this is where the real work gets done!

```
+==========================================================================+
|                           WORKER NODE                                     |
|                   "Where Your Apps Actually Run"                          |
+==========================================================================+
|                                                                           |
|   +-------------------------------------------------------------------+  |
|   |                         WORKER NODE                                |  |
|   |                                                                    |  |
|   |   +---------------+    +-------------------+    +---------------+  |  |
|   |   |    KUBELET    |    | CONTAINER RUNTIME |    |  KUBE-PROXY   |  |  |
|   |   |               |    |                   |    |               |  |  |
|   |   |  Team Lead    |    |  Factory Floor    |    |  Network Guy  |  |  |
|   |   |  (manages     |    |  (runs the        |    |  (handles     |  |  |
|   |   |   this node)  |    |   containers)     |    |   networking) |  |  |
|   |   +---------------+    +-------------------+    +---------------+  |  |
|   |                                                                    |  |
|   |   +-----------------------------------------------------------+   |  |
|   |   |                         PODS                               |   |  |
|   |   |                                                            |   |  |
|   |   |   +--------+   +--------+   +--------+   +--------+       |   |  |
|   |   |   | Pod 1  |   | Pod 2  |   | Pod 3  |   | Pod 4  |       |   |  |
|   |   |   |        |   |        |   |        |   |        |       |   |  |
|   |   |   | nginx  |   | redis  |   |  app   |   |  api   |       |   |  |
|   |   |   +--------+   +--------+   +--------+   +--------+       |   |  |
|   |   |                                                            |   |  |
|   |   +-----------------------------------------------------------+   |  |
|   |                                                                    |  |
|   +-------------------------------------------------------------------+  |
|                                                                           |
+==========================================================================+
```

---

## 1. Kubelet - The Team Lead

### What It Does

The **Kubelet** is an agent that runs on every worker node. It's responsible for making sure that containers are running in Pods as expected.

```
+==========================================================================+
|                              KUBELET                                      |
|                      "The Team Lead on Each Node"                         |
+==========================================================================+

  The Kubelet is the Control Plane's "person on the ground" at each node.
  
  +-----------------------------------------------------------------------+
  |                                                                        |
  |   CONTROL PLANE                          WORKER NODE                   |
  |   =============                          ===========                   |
  |                                                                        |
  |   +-------------+                        +---------------+             |
  |   | API Server  | ----"Run these pods"-->|    KUBELET    |             |
  |   +-------------+                        +-------+-------+             |
  |                                                  |                     |
  |                                                  | Manages             |
  |                                                  v                     |
  |                                          +---------------+             |
  |                                          |     PODS      |             |
  |                                          | [C1] [C2] [C3]|             |
  |                                          +---------------+             |
  |                                                  |                     |
  |   +-------------+ <--"Here's the status"--+------+                     |
  |   | API Server  |                                                      |
  |   +-------------+                                                      |
  |                                                                        |
  +-----------------------------------------------------------------------+

+==========================================================================+
```

### Kubelet's Responsibilities

```
+--------------------------------------------------------------------------+
|                       KUBELET RESPONSIBILITIES                            |
+--------------------------------------------------------------------------+
|                                                                           |
|  1. RECEIVES POD SPECIFICATIONS                                          |
|     ============================                                         |
|                                                                           |
|     API Server: "Hey Kubelet, run this Pod"                              |
|           |                                                               |
|           v                                                               |
|     +----------------+                                                    |
|     | Pod Spec (YAML)|                                                   |
|     | - Image: nginx |                                                   |
|     | - Port: 80     |                                                   |
|     | - Memory: 512M |                                                   |
|     +----------------+                                                    |
|           |                                                               |
|           v                                                               |
|     Kubelet: "Got it! I'll make it happen."                              |
|                                                                           |
+--------------------------------------------------------------------------+
|                                                                           |
|  2. TALKS TO CONTAINER RUNTIME                                           |
|     ===========================                                          |
|                                                                           |
|     Kubelet ---> Container Runtime (Docker/containerd)                   |
|                        |                                                  |
|                        v                                                  |
|                 "Pull image nginx:latest"                                |
|                 "Create container"                                        |
|                 "Start container"                                         |
|                                                                           |
+--------------------------------------------------------------------------+
|                                                                           |
|  3. MONITORS CONTAINER HEALTH                                            |
|     ==========================                                           |
|                                                                           |
|     Every few seconds:                                                   |
|                                                                           |
|     Kubelet: "Hey container, are you alive?"                             |
|                                                                           |
|     Container: "Yes!"  --> Kubelet: "Good, report healthy"               |
|     Container: "..."   --> Kubelet: "No response! Restart it!"           |
|                                                                           |
+--------------------------------------------------------------------------+
|                                                                           |
|  4. REPORTS STATUS TO API SERVER                                         |
|     =============================                                        |
|                                                                           |
|     Kubelet --> API Server                                               |
|                                                                           |
|     "Node Status:                                                        |
|      - CPU: 45% used                                                     |
|      - Memory: 60% used                                                  |
|      - Pods running: 12                                                  |
|      - All pods healthy"                                                 |
|                                                                           |
+--------------------------------------------------------------------------+
```

### Analogy: Branch Manager

```
+==========================================================================+
|                      KUBELET = BRANCH MANAGER                             |
+==========================================================================+
|                                                                           |
|   Corporate HQ (Control Plane)        Branch Office (Worker Node)        |
|   ============================        ===========================        |
|                                                                           |
|   "Open 3 new customer                                                   |
|    service desks"                                                        |
|         |                                                                 |
|         |                             +------------------+                |
|         +-------------------------->  |  BRANCH MANAGER  |                |
|                                       |    (Kubelet)     |                |
|                                       +--------+---------+                |
|                                                |                          |
|                                                v                          |
|                                       "I'll set up those desks"          |
|                                                |                          |
|                                                v                          |
|                                       +------------------+                |
|                                       |   EMPLOYEES      |                |
|                                       | (Containers)     |                |
|                                       |                  |                |
|                                       | [Desk1] [Desk2]  |                |
|                                       | [Desk3]          |                |
|                                       +------------------+                |
|                                                |                          |
|                                                v                          |
|         <------------------------------  "3 desks operational,           |
|         Status Report                     all employees working"         |
|                                                                           |
+==========================================================================+
```

---

## 2. Container Runtime - The Engine

### What It Does

The **Container Runtime** is the software that actually runs your containers. Kubernetes doesn't run containers directly - it tells the container runtime to do it.

```
+==========================================================================+
|                         CONTAINER RUNTIME                                 |
|                    "The Engine That Runs Containers"                      |
+==========================================================================+

  POPULAR CONTAINER RUNTIMES:
  ===========================
  
  +-------------------+  +-------------------+  +-------------------+
  |      Docker       |  |    containerd     |  |      CRI-O        |
  |                   |  |                   |  |                   |
  |  (Most popular,   |  |  (Lightweight,    |  |  (Made for        |
  |   but heavier)    |  |   industry std)   |  |   Kubernetes)     |
  +-------------------+  +-------------------+  +-------------------+

+==========================================================================+
```

### How It Works

```
+--------------------------------------------------------------------------+
|                    CONTAINER RUNTIME FLOW                                 |
+--------------------------------------------------------------------------+

  1. KUBELET GIVES INSTRUCTIONS
     ==========================
  
     +----------+                      +-------------------+
     |  Kubelet | --"Run nginx:1.21"-->| Container Runtime |
     +----------+                      +-------------------+


  2. CONTAINER RUNTIME PULLS IMAGE
     =============================
  
     +-------------------+          +------------------+
     | Container Runtime | -------> | Container        |
     |                   |          | Registry         |
     |                   | <------- | (Docker Hub etc) |
     |  "Got nginx:1.21" |          |                  |
     +-------------------+          +------------------+


  3. CONTAINER RUNTIME CREATES AND STARTS CONTAINER
     ==============================================
  
     +-------------------+
     | Container Runtime |
     |                   |
     |  1. Create container from image                 
     |  2. Set up networking (get IP)                  
     |  3. Mount volumes                               
     |  4. Start the process                           
     |                   |
     +-------------------+
              |
              v
     +-------------------+
     |    Container      |
     |   +-----------+   |
     |   |   nginx   |   |  <-- Your app is now running!
     |   +-----------+   |
     +-------------------+


  4. CONTAINER RUNTIME MANAGES LIFECYCLE
     ===================================
  
     Start  -->  Running  -->  Stop/Restart/Delete
                    |
                    v
              Monitor logs
              Track resources
              Report status

+--------------------------------------------------------------------------+
```

### Analogy: The Factory Floor

```
+==========================================================================+
|                  CONTAINER RUNTIME = FACTORY FLOOR                        |
+==========================================================================+
|                                                                           |
|   Kubelet = Manager                  Container Runtime = Factory Floor   |
|   ================                   =================================   |
|                                                                           |
|   Manager says:                      Factory Floor:                      |
|   "Build 100 widgets"                                                    |
|         |                            +---------------------------+       |
|         |                            |                           |       |
|         +------------------------->  |  1. Get materials         |       |
|                                      |     (Pull image)          |       |
|                                      |                           |       |
|                                      |  2. Set up assembly line  |       |
|                                      |     (Create container)    |       |
|                                      |                           |       |
|                                      |  3. Start production      |       |
|                                      |     (Start container)     |       |
|                                      |                           |       |
|                                      |  4. Quality control       |       |
|                                      |     (Health checks)       |       |
|                                      |                           |       |
|                                      +---------------------------+       |
|                                                                           |
|   The manager (Kubelet) doesn't build widgets directly.                  |
|   The factory floor (Container Runtime) does the actual work!            |
|                                                                           |
+==========================================================================+
```

### CRI (Container Runtime Interface)

```
+--------------------------------------------------------------------------+
|                    CRI - THE STANDARD INTERFACE                           |
+--------------------------------------------------------------------------+
|                                                                           |
|   Kubernetes uses CRI (Container Runtime Interface) to talk to           |
|   any container runtime. This means you can swap runtimes!               |
|                                                                           |
|                     +------------+                                        |
|                     |   Kubelet  |                                        |
|                     +------+-----+                                        |
|                            |                                              |
|                            | CRI (Standard API)                          |
|                            |                                              |
|              +-------------+-------------+                                |
|              |             |             |                                |
|              v             v             v                                |
|        +---------+   +-----------+   +-------+                           |
|        |  Docker |   | containerd|   | CRI-O |                           |
|        +---------+   +-----------+   +-------+                           |
|                                                                           |
|   Like USB - you can plug in different devices as long as they           |
|   follow the USB standard. Same with container runtimes and CRI!         |
|                                                                           |
+--------------------------------------------------------------------------+
```

---

## 3. Kube-proxy - The Network Guy

### What It Does

**Kube-proxy** runs on each node and is responsible for network rules that allow communication to your Pods from inside or outside the cluster.

```
+==========================================================================+
|                            KUBE-PROXY                                     |
|                    "The Network Administrator"                            |
+==========================================================================+

  Kube-proxy makes sure network traffic gets to the right place.

  +-----------------------------------------------------------------------+
  |                                                                        |
  |   EXTERNAL TRAFFIC                    INTERNAL TRAFFIC                 |
  |   ================                    ================                 |
  |                                                                        |
  |   Internet User                       Pod A wants to                   |
  |        |                              talk to Pod B                    |
  |        |                                   |                           |
  |        v                                   v                           |
  |   +-----------+                       +-----------+                    |
  |   |KUBE-PROXY |                       |KUBE-PROXY |                    |
  |   +-----------+                       +-----------+                    |
  |        |                                   |                           |
  |        | "Route to correct Pod"            | "Find Pod B's IP"        |
  |        |                                   |                           |
  |        v                                   v                           |
  |   +--------+                          +--------+                       |
  |   | Pod    |                          | Pod B  |                       |
  |   +--------+                          +--------+                       |
  |                                                                        |
  +-----------------------------------------------------------------------+

+==========================================================================+
```

### Kube-proxy's Main Jobs

```
+--------------------------------------------------------------------------+
|                       KUBE-PROXY RESPONSIBILITIES                         |
+--------------------------------------------------------------------------+

  1. SERVICE DISCOVERY
     =================
  
     When you create a Service, kube-proxy sets up rules so traffic
     to that Service reaches the right Pods.
  
     +-------------+         +-----------+         +--------+
     |   Service   | ------> |KUBE-PROXY | ------> |  Pod   |
     | frontend:80 |         | (routes)  |         | :8080  |
     +-------------+         +-----------+         +--------+
  
  
  2. LOAD BALANCING
     ==============
  
     Distributes traffic across multiple Pods
  
                        Traffic to "frontend"
                               |
                               v
                        +-----------+
                        |KUBE-PROXY |
                        +-----------+
                         /    |    \
                        /     |     \
                       v      v      v
                    [Pod1] [Pod2] [Pod3]
                     33%    33%    33%
  
  
  3. NETWORK RULES
     =============
  
     Uses iptables or IPVS to create network rules
  
     +--------------------------------------------------+
     |  iptables rules (simplified)                      |
     |                                                   |
     |  Traffic to 10.0.0.1:80 --> Route to Pod IPs:    |
     |    - 10.244.1.5:8080 (Pod 1)                     |
     |    - 10.244.2.8:8080 (Pod 2)                     |
     |    - 10.244.3.2:8080 (Pod 3)                     |
     +--------------------------------------------------+

+--------------------------------------------------------------------------+
```

### Analogy: The Receptionist + Mail Room

```
+==========================================================================+
|              KUBE-PROXY = RECEPTIONIST + MAIL ROOM                        |
+==========================================================================+
|                                                                           |
|   Imagine a company building with many offices:                          |
|                                                                           |
|   Visitor: "I need to see the Sales Team"                                |
|                |                                                          |
|                v                                                          |
|   +------------------------+                                              |
|   |    RECEPTIONIST        |                                              |
|   |    (Kube-proxy)        |                                              |
|   +------------------------+                                              |
|                |                                                          |
|                v                                                          |
|   "Sales Team is in rooms 201, 202, and 203.                             |
|    Room 201 is free, I'll send you there."                               |
|                |                                                          |
|                v                                                          |
|   +------------------------+                                              |
|   |     Room 201 (Pod)     |                                              |
|   +------------------------+                                              |
|                                                                           |
|   -------------------------------------------------------------------    |
|                                                                           |
|   Mail arrives: "To: Finance Department"                                 |
|                |                                                          |
|                v                                                          |
|   +------------------------+                                              |
|   |      MAIL ROOM         |                                              |
|   |    (Kube-proxy)        |                                              |
|   +------------------------+                                              |
|                |                                                          |
|                v                                                          |
|   "Finance Department has 3 people.                                      |
|    I'll distribute mail to all of them."                                 |
|                |                                                          |
|        +-------+-------+                                                  |
|        |       |       |                                                  |
|        v       v       v                                                  |
|     [John]  [Jane]  [Bob]  (Pods)                                        |
|                                                                           |
+==========================================================================+
```

---

## Complete Worker Node Diagram

```
+==========================================================================+
|                    COMPLETE WORKER NODE ARCHITECTURE                      |
+==========================================================================+
|                                                                           |
|   FROM CONTROL PLANE                                                     |
|         |                                                                 |
|         | "Run these Pods, here are the specs"                           |
|         v                                                                 |
|   +===================================================================+  |
|   ||                        WORKER NODE                               ||  |
|   ||                                                                  ||  |
|   ||  +-----------------------------------------------------------+  ||  |
|   ||  |                        KUBELET                             |  ||  |
|   ||  |                    (Node Manager)                          |  ||  |
|   ||  |                                                            |  ||  |
|   ||  |  - Receives Pod specs from API Server                      |  ||  |
|   ||  |  - Tells Container Runtime what to do                      |  ||  |
|   ||  |  - Monitors Pod health                                     |  ||  |
|   ||  |  - Reports status back                                     |  ||  |
|   ||  +----------------------------+------------------------------+  ||  |
|   ||                               |                                  ||  |
|   ||                               v                                  ||  |
|   ||  +-----------------------------------------------------------+  ||  |
|   ||  |                   CONTAINER RUNTIME                        |  ||  |
|   ||  |              (Docker / containerd / CRI-O)                 |  ||  |
|   ||  |                                                            |  ||  |
|   ||  |  - Pulls container images                                  |  ||  |
|   ||  |  - Creates containers                                      |  ||  |
|   ||  |  - Starts/stops containers                                 |  ||  |
|   ||  |  - Manages container lifecycle                             |  ||  |
|   ||  +----------------------------+------------------------------+  ||  |
|   ||                               |                                  ||  |
|   ||                               v                                  ||  |
|   ||  +-----------------------------------------------------------+  ||  |
|   ||  |                         PODS                               |  ||  |
|   ||  |                                                            |  ||  |
|   ||  |   +-------------+  +-------------+  +-------------+        |  ||  |
|   ||  |   |    POD 1    |  |    POD 2    |  |    POD 3    |        |  ||  |
|   ||  |   |  +-------+  |  |  +-------+  |  |  +-------+  |        |  ||  |
|   ||  |   |  | nginx |  |  |  | redis |  |  |  |  app  |  |        |  ||  |
|   ||  |   |  +-------+  |  |  +-------+  |  |  +-------+  |        |  ||  |
|   ||  |   | IP:10.1.1.1|  | IP:10.1.1.2|  | IP:10.1.1.3|        |  ||  |
|   ||  |   +-------------+  +-------------+  +-------------+        |  ||  |
|   ||  |                                                            |  ||  |
|   ||  +-----------------------------------------------------------+  ||  |
|   ||                               ^                                  ||  |
|   ||                               |                                  ||  |
|   ||  +-----------------------------------------------------------+  ||  |
|   ||  |                       KUBE-PROXY                           |  ||  |
|   ||  |                   (Network Manager)                        |  ||  |
|   ||  |                                                            |  ||  |
|   ||  |  - Routes traffic to correct Pods                          |  ||  |
|   ||  |  - Load balances across Pods                               |  ||  |
|   ||  |  - Manages iptables/IPVS rules                             |  ||  |
|   ||  +-----------------------------------------------------------+  ||  |
|   ||                               ^                                  ||  |
|   ||                               |                                  ||  |
|   +===================================================================+  |
|                                    |                                      |
|                                    v                                      |
|                        NETWORK TRAFFIC (in/out)                          |
|                                                                           |
+==========================================================================+
```

---

## Mermaid Diagram: Worker Node Components

```mermaid
flowchart TB
    subgraph ControlPlane["Control Plane"]
        API["API Server"]
    end
    
    subgraph WorkerNode["Worker Node"]
        KUBELET["Kubelet<br/>(Node Manager)"]
        CR["Container Runtime<br/>(Docker/containerd)"]
        KP["Kube-proxy<br/>(Network Manager)"]
        
        subgraph Pods["Pods"]
            P1["Pod 1<br/>nginx"]
            P2["Pod 2<br/>redis"]
            P3["Pod 3<br/>app"]
        end
    end
    
    API <-->|"Pod specs & status"| KUBELET
    KUBELET -->|"Create/manage"| CR
    CR -->|"Run"| Pods
    KP -->|"Route traffic"| Pods
    
    TRAFFIC["External Traffic"] --> KP
    
    style KUBELET fill:#e3f2fd
    style CR fill:#fff3e0
    style KP fill:#e8f5e9
    style Pods fill:#fce4ec
```

---

## How They Work Together

```
+--------------------------------------------------------------------------+
|                  WORKER NODE COMPONENTS IN ACTION                         |
+--------------------------------------------------------------------------+

  SCENARIO: User creates a web application deployment
  
  +------------------------------------------------------------------------+
  |                                                                         |
  |  STEP 1: API Server tells Kubelet about new Pod                        |
  |  ==============================================                        |
  |                                                                         |
  |     API Server --> Kubelet: "Run nginx Pod with these specs"           |
  |                                                                         |
  +------------------------------------------------------------------------+
  |                                                                         |
  |  STEP 2: Kubelet tells Container Runtime to create container           |
  |  ============================================================          |
  |                                                                         |
  |     Kubelet --> Container Runtime:                                     |
  |       "1. Pull nginx:latest image"                                     |
  |       "2. Create container"                                            |
  |       "3. Start container"                                             |
  |       "4. Assign IP 10.244.1.5"                                        |
  |                                                                         |
  +------------------------------------------------------------------------+
  |                                                                         |
  |  STEP 3: Kube-proxy sets up networking rules                           |
  |  ============================================                          |
  |                                                                         |
  |     Kube-proxy:                                                        |
  |       "Traffic to Service 'web' should go to:"                         |
  |       "  - 10.244.1.5:80 (this new Pod)"                               |
  |       "  - 10.244.2.3:80 (existing Pod)"                               |
  |                                                                         |
  +------------------------------------------------------------------------+
  |                                                                         |
  |  STEP 4: Kubelet continuously monitors                                 |
  |  =====================================                                 |
  |                                                                         |
  |     Every 10 seconds:                                                  |
  |     Kubelet: "Container still running? Health check passed?"           |
  |              "Yes. Report healthy status to API Server."               |
  |                                                                         |
  +------------------------------------------------------------------------+
  |                                                                         |
  |  STEP 5: Traffic flows through kube-proxy                              |
  |  =========================================                             |
  |                                                                         |
  |     User Request --> Kube-proxy --> Pod (nginx) --> Response           |
  |                                                                         |
  +------------------------------------------------------------------------+
```

---

## Summary Comparison Table

| Component | Purpose | Analogy | Communicates With |
|-----------|---------|---------|-------------------|
| **Kubelet** | Manages Pods on the node | Branch Manager | API Server, Container Runtime |
| **Container Runtime** | Runs containers | Factory Floor | Kubelet |
| **Kube-proxy** | Network routing | Mail Room / Receptionist | Network, Pods |

---

## Key Takeaways

```
+-----------------------------------------------------------------------+
|                         KEY TAKEAWAYS                                  |
+-----------------------------------------------------------------------+
|                                                                        |
|  1. KUBELET = The boss on each node                                   |
|     - Takes orders from Control Plane                                 |
|     - Makes sure Pods run as expected                                 |
|     - Reports status back                                             |
|                                                                        |
|  2. CONTAINER RUNTIME = The actual engine                             |
|     - Pulls images, creates containers                                |
|     - Docker, containerd, or CRI-O                                    |
|     - Kubelet talks to it via CRI                                     |
|                                                                        |
|  3. KUBE-PROXY = The network plumber                                  |
|     - Routes traffic to correct Pods                                  |
|     - Enables Service discovery                                       |
|     - Load balances requests                                          |
|                                                                        |
|  4. Every Worker Node has ALL THREE components                        |
|     - They work together as a team                                    |
|     - No Kubelet = Node can't receive instructions                    |
|     - No Container Runtime = Can't run containers                     |
|     - No Kube-proxy = Network traffic can't reach Pods                |
|                                                                        |
+-----------------------------------------------------------------------+
```

---

## Full Picture: Control Plane + Worker Nodes

```
+==========================================================================+
|                        KUBERNETES CLUSTER                                 |
+==========================================================================+
|                                                                           |
|  +--------------------------------------------------------------------+  |
|  |                        CONTROL PLANE                                |  |
|  |                                                                     |  |
|  |   +------------+  +-------+  +-----------+  +------------------+   |  |
|  |   | API Server |  | etcd  |  | Scheduler |  |Controller Manager|   |  |
|  |   +------------+  +-------+  +-----------+  +------------------+   |  |
|  |                                                                     |  |
|  +--------------------------------------------------------------------+  |
|                                     |                                     |
|                                     | Network                             |
|                                     |                                     |
|  +--------------------------------------------------------------------+  |
|  |                        WORKER NODES                                 |  |
|  |                                                                     |  |
|  |  +------------------+  +------------------+  +------------------+   |  |
|  |  |   Worker Node 1  |  |   Worker Node 2  |  |   Worker Node 3  |   |  |
|  |  |                  |  |                  |  |                  |   |  |
|  |  | - Kubelet        |  | - Kubelet        |  | - Kubelet        |   |  |
|  |  | - Container RT   |  | - Container RT   |  | - Container RT   |   |  |
|  |  | - Kube-proxy     |  | - Kube-proxy     |  | - Kube-proxy     |   |  |
|  |  | - [Pods...]      |  | - [Pods...]      |  | - [Pods...]      |   |  |
|  |  |                  |  |                  |  |                  |   |  |
|  |  +------------------+  +------------------+  +------------------+   |  |
|  |                                                                     |  |
|  +--------------------------------------------------------------------+  |
|                                                                           |
+==========================================================================+
```

---

## What's Next?

Congratulations! You now understand the complete Kubernetes architecture:
- What Kubernetes is and why we need it
- The Control Plane (API Server, etcd, Scheduler, Controller Manager)
- The Worker Nodes (Kubelet, Container Runtime, Kube-proxy)

In the next module, we'll start working with the core objects in Kubernetes: **Pods, Deployments, Services, and more!**
