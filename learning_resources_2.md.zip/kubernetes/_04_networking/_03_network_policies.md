# Kubernetes Network Policies

## What are Network Policies?

**Network Policies** are firewall rules for your Pods. They control which Pods can talk to which other Pods, and which external endpoints Pods can reach.

```
Think of Network Policies as:

+------------------------------------------------------------------+
|                         WITHOUT Network Policies                  |
|                         (Default: ALLOW ALL)                      |
|                                                                   |
|   +-----+     +-----+     +-----+     +-----+     +-----+        |
|   |Pod A|<--->|Pod B|<--->|Pod C|<--->|Pod D|<--->|Pod E|        |
|   +-----+     +-----+     +-----+     +-----+     +-----+        |
|       ^           ^           ^           ^           ^          |
|       |           |           |           |           |          |
|       +-----------+-----------+-----------+-----------+          |
|                    Everyone can talk to everyone!                |
+------------------------------------------------------------------+

+------------------------------------------------------------------+
|                         WITH Network Policies                     |
|                         (Locked Down)                             |
|                                                                   |
|   +-----+     +-----+     +-----+     +-----+     +-----+        |
|   |Pod A|---->|Pod B|---->|Pod C|  X  |Pod D|  X  |Pod E|        |
|   +-----+     +-----+     +-----+     +-----+     +-----+        |
|                              |                                    |
|                              v                                    |
|                         +--------+                                |
|                         |Database|                                |
|                         +--------+                                |
|                                                                   |
|   Only allowed paths work. Everything else is BLOCKED.           |
+------------------------------------------------------------------+
```

---

## Why Do You Need Network Policies?

### The Security Problem

By default, Kubernetes allows ALL Pods to communicate with ALL other Pods. This is convenient but dangerous:

```
                    DEFAULT KUBERNETES NETWORKING
                    
+----------------+      +----------------+      +----------------+
|   Namespace:   |      |   Namespace:   |      |   Namespace:   |
|   frontend     |      |   backend      |      |   database     |
|                |      |                |      |                |
|   +--------+   |      |   +--------+   |      |   +--------+   |
|   | web-ui |<-------->|   |  api   |<-------->|   |postgres|   |
|   +--------+   |      |   +--------+   |      |   +--------+   |
|                |      |                |      |                |
+----------------+      +----------------+      +----------------+
        |                                               ^
        |                                               |
        +-----------------------------------------------+
                    web-ui can directly access postgres!
                    (This should NOT be allowed!)
```

### With Network Policies

```
                    WITH NETWORK POLICIES
                    
+----------------+      +----------------+      +----------------+
|   Namespace:   |      |   Namespace:   |      |   Namespace:   |
|   frontend     |      |   backend      |      |   database     |
|                |      |                |      |                |
|   +--------+   |      |   +--------+   |      |   +--------+   |
|   | web-ui |--------->|   |  api   |--------->|   |postgres|   |
|   +--------+   |      |   +--------+   |      |   +--------+   |
|                |      |                |      |                |
+----------------+      +----------------+      +----------------+
        |                                               ^
        X BLOCKED                                       |
        +-----------------------------------------------+
                    web-ui CANNOT directly access postgres!
                    Must go through api service.
```

---

## Key Concepts

### 1. Ingress vs Egress (Traffic Direction)

```
                         +--------+
                         |  Pod   |
                         +--------+
                              |
            +-----------------+-----------------+
            |                                   |
            v                                   v
    +---------------+                   +---------------+
    |   INGRESS     |                   |   EGRESS      |
    | (incoming to  |                   | (outgoing from|
    |  this Pod)    |                   |  this Pod)    |
    +---------------+                   +---------------+
    
    Example:                            Example:
    - API calls to this Pod             - This Pod calling database
    - Health checks                     - External API calls
    - Requests from other Pods          - DNS queries
```

### 2. Default Behavior

| Scenario | Default | With ANY NetworkPolicy targeting Pod |
|----------|---------|--------------------------------------|
| No NetworkPolicy exists | All traffic allowed | N/A |
| Ingress policy exists | N/A | All ingress DENIED except what's allowed |
| Egress policy exists | N/A | All egress DENIED except what's allowed |

**Important:** The moment you apply ANY NetworkPolicy that selects a Pod, that Pod's traffic in that direction becomes "deny by default" - only explicitly allowed traffic gets through.

### 3. Label Selectors

Network Policies use labels to select Pods:

```
NetworkPolicy says:                    Matches these Pods:
"Allow traffic from                    
 Pods with label                       +-----+ app=frontend
 app=frontend"                         |Pod A| role=web
                                       +-----+     
     |                                     
     +-----------------------------------> ALLOWED
     
                                       +-----+ app=backend
                                       |Pod B| role=api
                                       +-----+
     |
     X---------------------------------> BLOCKED (no app=frontend label)
```

---

## Basic Network Policy Structure

```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: my-network-policy
  namespace: default
spec:
  # 1. Which Pods does this policy apply to?
  podSelector:
    matchLabels:
      app: database           # Applies to Pods with app=database
  
  # 2. What type of traffic are we controlling?
  policyTypes:
    - Ingress                 # Control incoming traffic
    - Egress                  # Control outgoing traffic
  
  # 3. What traffic is ALLOWED for incoming?
  ingress:
    - from:
        - podSelector:
            matchLabels:
              app: api        # Allow from Pods with app=api
      ports:
        - protocol: TCP
          port: 5432          # Only on port 5432
  
  # 4. What traffic is ALLOWED for outgoing?
  egress:
    - to:
        - podSelector:
            matchLabels:
              app: monitoring
      ports:
        - protocol: TCP
          port: 9090
```

---

## Common Network Policy Examples

### Example 1: Deny All Ingress (Default Deny)

Start with "deny all" and then add specific allow rules:

```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: default-deny-ingress
  namespace: production
spec:
  podSelector: {}          # Empty = applies to ALL Pods in namespace
  policyTypes:
    - Ingress              # Only control ingress
  # No 'ingress' field = no traffic allowed
```

```
                    BEFORE                           AFTER
                    
+----------------+                      +----------------+
|   production   |                      |   production   |
|   namespace    |                      |   namespace    |
|                |                      |                |
|  +---+  +---+  |                      |  +---+  +---+  |
|  |Pod|<>|Pod|  |                      |  |Pod|X |Pod|  |
|  +---+  +---+  |                      |  +---+  +---+  |
|     ^     ^    |                      |     X     X    |
+-----|-----|----+                      +-----|-----|----+
      |     |                                 |     |
    From outside                            From outside
    
All traffic allowed                     All ingress BLOCKED
```

### Example 2: Allow Only Specific Pods

Allow database to receive traffic only from API Pods:

```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: database-allow-api-only
  namespace: production
spec:
  podSelector:
    matchLabels:
      app: database          # Applies to database Pods
  policyTypes:
    - Ingress
  ingress:
    - from:
        - podSelector:
            matchLabels:
              app: api       # Only allow from api Pods
      ports:
        - protocol: TCP
          port: 5432         # PostgreSQL port
```

```
+------------------------------------------------------------------+
|                        production namespace                       |
|                                                                   |
|   +--------+                        +----------+                  |
|   |frontend|                        | database |                  |
|   |app=web |-------- X BLOCKED ---->|app=      |                  |
|   +--------+                        |database  |                  |
|                                     +----^-----+                  |
|   +--------+                             |                        |
|   |  api   |                             |                        |
|   |app=api |-------- ALLOWED ------------+                        |
|   +--------+                       (port 5432 only)               |
|                                                                   |
+------------------------------------------------------------------+
```

### Example 3: Allow from Specific Namespace

Allow traffic from Pods in the 'monitoring' namespace:

```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: allow-monitoring
  namespace: production
spec:
  podSelector:
    matchLabels:
      app: api
  policyTypes:
    - Ingress
  ingress:
    - from:
        - namespaceSelector:
            matchLabels:
              purpose: monitoring    # Namespace must have this label
          podSelector:
            matchLabels:
              app: prometheus        # AND Pod must have this label
      ports:
        - protocol: TCP
          port: 8080
```

**Note:** You must label the namespace first:
```bash
kubectl label namespace monitoring purpose=monitoring
```

```
+------------------+                    +------------------+
| monitoring ns    |                    | production ns    |
| (labeled)        |                    |                  |
|                  |                    |                  |
| +------------+   |     ALLOWED        | +------------+   |
| | prometheus |---|------------------->| |    api     |   |
| | app=prom   |   |    (port 8080)     | | app=api    |   |
| +------------+   |                    | +------------+   |
|                  |                    |                  |
+------------------+                    +------------------+

+------------------+                    
| other ns         |                    
| (not labeled)    |       BLOCKED      
|                  |----------X-------->
| +------------+   |                    
| |  hacker    |   |                    
| +------------+   |                    
+------------------+                    
```

### Example 4: Allow External Traffic (Egress)

Allow Pods to access external APIs:

```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: allow-external-api
  namespace: production
spec:
  podSelector:
    matchLabels:
      app: api
  policyTypes:
    - Egress
  egress:
    # Allow DNS (required for name resolution)
    - to:
        - namespaceSelector: {}
          podSelector:
            matchLabels:
              k8s-app: kube-dns
      ports:
        - protocol: UDP
          port: 53
    # Allow external HTTPS
    - to:
        - ipBlock:
            cidr: 0.0.0.0/0          # Any external IP
            except:
              - 10.0.0.0/8           # Except internal ranges
              - 172.16.0.0/12
              - 192.168.0.0/16
      ports:
        - protocol: TCP
          port: 443                   # HTTPS only
```

### Example 5: Complete Isolation (Deny All)

Lock down a namespace completely:

```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: deny-all
  namespace: secure-zone
spec:
  podSelector: {}          # All Pods
  policyTypes:
    - Ingress
    - Egress
  # No ingress or egress rules = nothing allowed
```

**Warning:** This blocks DNS too! Pods won't resolve hostnames. Add DNS egress:

```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: allow-dns
  namespace: secure-zone
spec:
  podSelector: {}
  policyTypes:
    - Egress
  egress:
    - to:
        - namespaceSelector: {}
          podSelector:
            matchLabels:
              k8s-app: kube-dns
      ports:
        - protocol: UDP
          port: 53
        - protocol: TCP
          port: 53
```

---

## Mermaid Diagram: Network Policy Flow

```mermaid
flowchart TB
    subgraph Cluster
        subgraph ns_frontend[Namespace: frontend]
            FE[web-ui Pod\napp=frontend]
        end
        
        subgraph ns_backend[Namespace: backend]
            API[api Pod\napp=api]
            NP1[NetworkPolicy:\nallow-frontend-only]
        end
        
        subgraph ns_database[Namespace: database]
            DB[(postgres Pod\napp=database)]
            NP2[NetworkPolicy:\nallow-api-only]
        end
    end
    
    Internet((Internet))
    
    Internet -->|1. User request| FE
    FE -->|2. Allowed by NP1| API
    API -->|3. Allowed by NP2| DB
    FE -.->|BLOCKED by NP2| DB
    
    style NP1 fill:#f9f,stroke:#333
    style NP2 fill:#f9f,stroke:#333
```

---

## Visual: How Policies Stack

Multiple Network Policies are **additive** (OR logic):

```
Policy A allows:                 Policy B allows:
  from app=frontend                from app=monitoring

                    RESULT
                    
Both are allowed! (A OR B)

+----------+     +------------+
| frontend |---->|            |
+----------+     |  Target    |
                 |   Pod      |
+----------+     |            |
|monitoring|---->|            |
+----------+     +------------+
```

Within a single policy, selectors are **AND**:

```yaml
ingress:
  - from:
      - podSelector:           # AND
          matchLabels:
            app: api
        namespaceSelector:     # Must match BOTH
          matchLabels:
            env: production
```

---

## Common Patterns

### Pattern 1: Three-Tier Application

```
+-------------------------------------------------------------------+
|                                                                    |
|   INTERNET                                                         |
|       |                                                            |
|       v                                                            |
|   +--------+     +--------+     +----------+                       |
|   |Frontend| --> |  API   | --> | Database |                       |
|   |        |     |        |     |          |                       |
|   +--------+     +--------+     +----------+                       |
|                                                                    |
|   Policy:        Policy:        Policy:                            |
|   Allow from     Allow from     Allow from                         |
|   Ingress        Frontend       API only                           |
|   Controller     only           on port 5432                       |
|                                                                    |
+-------------------------------------------------------------------+
```

```yaml
# Frontend policy - allow from Ingress Controller
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: frontend-policy
spec:
  podSelector:
    matchLabels:
      tier: frontend
  policyTypes:
    - Ingress
  ingress:
    - from:
        - namespaceSelector:
            matchLabels:
              app.kubernetes.io/name: ingress-nginx
      ports:
        - protocol: TCP
          port: 80
---
# API policy - allow from Frontend
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: api-policy
spec:
  podSelector:
    matchLabels:
      tier: api
  policyTypes:
    - Ingress
  ingress:
    - from:
        - podSelector:
            matchLabels:
              tier: frontend
      ports:
        - protocol: TCP
          port: 8080
---
# Database policy - allow from API only
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: database-policy
spec:
  podSelector:
    matchLabels:
      tier: database
  policyTypes:
    - Ingress
  ingress:
    - from:
        - podSelector:
            matchLabels:
              tier: api
      ports:
        - protocol: TCP
          port: 5432
```

### Pattern 2: Namespace Isolation

Isolate namespaces from each other but allow within:

```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: namespace-isolation
  namespace: team-a
spec:
  podSelector: {}
  policyTypes:
    - Ingress
  ingress:
    - from:
        - podSelector: {}      # Any Pod in same namespace
```

```
+------------------+                +------------------+
|    team-a ns     |                |    team-b ns     |
|                  |                |                  |
|  +---+    +---+  |                |  +---+    +---+  |
|  |Pod|<-->|Pod|  |      X         |  |Pod|<-->|Pod|  |
|  +---+    +---+  |  <-------->    |  +---+    +---+  |
|                  |   BLOCKED      |                  |
|  Internal comm   |                |  Internal comm   |
|    ALLOWED       |                |    ALLOWED       |
+------------------+                +------------------+
```

---

## Network Policy Requirements

**Important:** Network Policies only work if your CNI (Container Network Interface) supports them!

| CNI Plugin | Network Policy Support |
|------------|----------------------|
| Calico | Yes (full support) |
| Cilium | Yes (enhanced with L7) |
| Azure CNI | Yes |
| Weave Net | Yes |
| Flannel | NO (basic, no policies) |
| AWS VPC CNI | Partial (need add-on) |

Check if your cluster supports Network Policies:
```bash
# Create a test policy and see if it's enforced
kubectl apply -f test-policy.yaml
# If traffic isn't blocked, your CNI doesn't support policies
```

---

## Debugging Network Policies

```bash
# List all network policies
kubectl get networkpolicies -A

# Describe a specific policy
kubectl describe networkpolicy database-policy -n production

# Check Pod labels (policies select by label)
kubectl get pods --show-labels

# Check namespace labels
kubectl get namespaces --show-labels

# Test connectivity from a Pod
kubectl exec -it test-pod -- wget -qO- --timeout=2 http://target-service

# Use nicolaka/netshoot for network debugging
kubectl run netshoot --rm -i --tty --image=nicolaka/netshoot -- /bin/bash
```

---

## Common Mistakes

### Mistake 1: Forgetting DNS

```yaml
# This blocks ALL egress, including DNS!
spec:
  podSelector: {}
  policyTypes:
    - Egress
  # No egress rules = no DNS = nothing works
```

**Fix:** Always allow DNS:
```yaml
egress:
  - to:
      - namespaceSelector: {}
        podSelector:
          matchLabels:
            k8s-app: kube-dns
    ports:
      - protocol: UDP
        port: 53
```

### Mistake 2: Wrong Label

```yaml
# Policy for app=database
podSelector:
  matchLabels:
    app: database

# But Pod has:
# labels:
#   application: database    <-- Wrong label name!
```

**Fix:** Verify labels match exactly.

### Mistake 3: Namespace Not Labeled

```yaml
# Policy requires namespace label
namespaceSelector:
  matchLabels:
    env: production

# But namespace doesn't have the label!
```

**Fix:** Label the namespace:
```bash
kubectl label namespace backend env=production
```

---

## Mermaid: Network Policy Decision Flow

```mermaid
flowchart TD
    A[Traffic arrives at Pod] --> B{Any NetworkPolicy\nselects this Pod?}
    
    B -->|No| C[ALLOW\nDefault behavior]
    B -->|Yes| D{Policy type matches\ntraffic direction?}
    
    D -->|Ingress policy,\negress traffic| E[Not controlled\nby this policy]
    D -->|Matches| F{Traffic matches\nany rule?}
    
    F -->|Yes| G[ALLOW]
    F -->|No| H[DENY]
    
    E --> I{Other policies\nselect Pod?}
    I -->|Yes| D
    I -->|No| C
```

---

## Summary: Network Policy Cheat Sheet

| Want to... | Use |
|------------|-----|
| Block all ingress to namespace | `podSelector: {}` with no ingress rules |
| Allow from specific Pod | `podSelector.matchLabels` |
| Allow from specific namespace | `namespaceSelector.matchLabels` |
| Allow from IP range | `ipBlock.cidr` |
| Block specific IPs | `ipBlock.except` |
| Allow specific port | `ports[].port` |
| Control outgoing traffic | `policyTypes: [Egress]` |

---

## Key Takeaways

1. **Default = ALLOW ALL** - Kubernetes has no network isolation by default
2. **Once a policy selects a Pod** - That direction becomes deny-by-default
3. **Policies are additive** - Multiple policies = union of allowed traffic
4. **Don't forget DNS** - Always allow port 53 UDP for egress policies
5. **Labels must match exactly** - Use `kubectl get pods --show-labels` to verify
6. **CNI must support policies** - Flannel doesn't, Calico/Cilium do
7. **Start with default deny** - Then add specific allow rules

---

## Practice Exercise

Create Network Policies for this scenario:

```
Requirements:
1. Database Pods should only receive traffic from API Pods
2. API Pods should only receive traffic from Frontend Pods
3. Frontend Pods should receive traffic from Ingress Controller
4. All Pods should be able to make DNS queries
5. API Pods should be able to call external APIs (HTTPS only)
```

Try writing the policies before looking at the solution!

<details>
<summary>Click for Solution</summary>

```yaml
# 1. Default deny all ingress
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: default-deny-ingress
spec:
  podSelector: {}
  policyTypes:
    - Ingress
---
# 2. Allow DNS for all Pods
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: allow-dns
spec:
  podSelector: {}
  policyTypes:
    - Egress
  egress:
    - to:
        - namespaceSelector: {}
          podSelector:
            matchLabels:
              k8s-app: kube-dns
      ports:
        - protocol: UDP
          port: 53
---
# 3. Frontend receives from Ingress
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: frontend-ingress
spec:
  podSelector:
    matchLabels:
      tier: frontend
  policyTypes:
    - Ingress
  ingress:
    - from:
        - namespaceSelector:
            matchLabels:
              app.kubernetes.io/name: ingress-nginx
---
# 4. API receives from Frontend
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: api-ingress
spec:
  podSelector:
    matchLabels:
      tier: api
  policyTypes:
    - Ingress
  ingress:
    - from:
        - podSelector:
            matchLabels:
              tier: frontend
---
# 5. Database receives from API
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: database-ingress
spec:
  podSelector:
    matchLabels:
      tier: database
  policyTypes:
    - Ingress
  ingress:
    - from:
        - podSelector:
            matchLabels:
              tier: api
      ports:
        - protocol: TCP
          port: 5432
---
# 6. API can call external HTTPS
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: api-external-egress
spec:
  podSelector:
    matchLabels:
      tier: api
  policyTypes:
    - Egress
  egress:
    - to:
        - ipBlock:
            cidr: 0.0.0.0/0
            except:
              - 10.0.0.0/8
              - 172.16.0.0/12
              - 192.168.0.0/16
      ports:
        - protocol: TCP
          port: 443
```
</details>

---

## What's Next?

You've learned the core networking concepts in Kubernetes:
- **Services** - Stable endpoints for Pods
- **Ingress** - Smart HTTP routing
- **Network Policies** - Firewall rules for Pods

Next modules will cover **scaling** and **advanced Azure-specific features**!
