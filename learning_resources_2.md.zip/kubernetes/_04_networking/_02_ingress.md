# Kubernetes Ingress

## The Problem: LoadBalancer Per Service = Expensive

Imagine you have 10 microservices that need external access:

```
                           The Expensive Way (10 LoadBalancers!)
                           
    Internet
       |
       +----> LoadBalancer ($$$) ----> api-service
       |
       +----> LoadBalancer ($$$) ----> web-service
       |
       +----> LoadBalancer ($$$) ----> auth-service
       |
       +----> LoadBalancer ($$$) ----> payment-service
       |
       +----> LoadBalancer ($$$) ----> notification-service
       |
       ... and 5 more ...
       
    10 services x $20/month = $200/month just for load balancers!
    Plus: 10 different IP addresses to manage
    Plus: 10 different SSL certificates
```

---

## The Solution: Ingress

**Ingress** is a single entry point that routes HTTP/HTTPS traffic to multiple services based on URL path or hostname.

```
                           The Smart Way (1 Ingress!)
                           
    Internet
       |
       v
 +-------------+
 |  Ingress    |  <-- Single Load Balancer, Single IP, Single SSL Cert
 | (smart      |
 |  router)    |
 +------+------+
        |
        +---> /api/*      ----> api-service
        |
        +---> /web/*      ----> web-service
        |
        +---> /auth/*     ----> auth-service
        |
        +---> api.example.com  ----> api-service
        |
        +---> web.example.com  ----> web-service
        
    1 Ingress = 1 Load Balancer = ~$20/month
    + Smart HTTP routing based on paths and hostnames!
```

---

## Analogy: The Smart Receptionist

Think of Ingress like a **smart receptionist** at a company's front desk:

```
    Visitor arrives at Company HQ (single address)
                    |
                    v
            +---------------+
            |  Receptionist |  <-- The Ingress
            | "How can I    |
            |  help you?"   |
            +-------+-------+
                    |
    "I need..."     |
                    |
    +---------------+---------------+---------------+
    |               |               |               |
    v               v               v               v
"Sales"         "Support"       "HR"           "Engineering"
    |               |               |               |
    v               v               v               v
+-------+       +-------+       +-------+       +-------+
| Sales |       |Support|       |  HR   |       | Eng   |
| Dept  |       | Dept  |       | Dept  |       | Dept  |
+-------+       +-------+       +-------+       +-------+
(service)       (service)       (service)       (service)

The receptionist (Ingress) knows WHERE to route each visitor
based on WHAT they need (URL path or hostname)
```

---

## Two Components: Controller + Resource

### 1. Ingress Controller

The **Ingress Controller** is the actual software that processes the rules. Kubernetes doesn't include one by default - you must install it.

Popular Ingress Controllers:
- **NGINX Ingress Controller** (most popular, open source)
- **Azure Application Gateway Ingress Controller (AGIC)** (Azure-native)
- **Traefik** (auto-discovery, Let's Encrypt)
- **HAProxy** (high performance)
- **Istio Gateway** (service mesh)

### 2. Ingress Resource

The **Ingress Resource** is a YAML configuration that defines the routing rules.

```
+-------------------+     reads      +------------------+
| Ingress Resource  | ------------> | Ingress          |
| (YAML rules)      |               | Controller       |
|                   |               | (NGINX/AGIC)     |
| - path: /api      |               |                  |
|   service: api    |    configures | Actual routing   |
| - path: /web      | ------------> | logic runs here  |
|   service: web    |               |                  |
+-------------------+               +------------------+
```

---

## Complete Traffic Flow

```
                            [Internet User]
                                  |
                                  | https://myapp.example.com/api/users
                                  v
                         +----------------+
                         | Cloud Load     |
                         | Balancer       |
                         | (created by    |
                         | Ingress Ctrl)  |
                         +-------+--------+
                                 |
+--------------------------------|----------------------------------+
|                                v               KUBERNETES CLUSTER  |
|                       +----------------+                          |
|                       | Ingress        |                          |
|                       | Controller     |                          |
|                       | (NGINX Pod)    |                          |
|                       +-------+--------+                          |
|                               |                                   |
|                               | Reads Ingress Resource            |
|                               | Routes based on path/host         |
|                               |                                   |
|         +---------------------+---------------------+             |
|         |                     |                     |             |
|         | /api/*              | /web/*              | /auth/*     |
|         v                     v                     v             |
|   +-----------+        +-----------+        +-----------+         |
|   | api-svc   |        | web-svc   |        | auth-svc  |         |
|   | ClusterIP |        | ClusterIP |        | ClusterIP |         |
|   +-----+-----+        +-----+-----+        +-----+-----+         |
|         |                    |                    |               |
|    +----+----+          +----+----+          +----+----+          |
|    v    v    v          v    v    v          v    v    v          |
|  +---+ +---+ +---+    +---+ +---+ +---+    +---+ +---+ +---+      |
|  |Pod| |Pod| |Pod|    |Pod| |Pod| |Pod|    |Pod| |Pod| |Pod|      |
|  +---+ +---+ +---+    +---+ +---+ +---+    +---+ +---+ +---+      |
|                                                                   |
+-------------------------------------------------------------------+
```

---

## Path-Based Routing

Route different URL paths to different services:

```
          https://myapp.com
                  |
    +-------------+-------------+
    |             |             |
  /api/*       /web/*       /static/*
    |             |             |
    v             v             v
+-------+    +--------+    +--------+
| api   |    | web    |    | static |
| svc   |    | svc    |    | svc    |
+-------+    +--------+    +--------+

Example URLs:
- myapp.com/api/users    --> api-service
- myapp.com/web/home     --> web-service
- myapp.com/static/logo  --> static-service
```

### YAML Example: Path-Based Routing

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: path-based-ingress
  annotations:
    # For NGINX Ingress Controller
    nginx.ingress.kubernetes.io/rewrite-target: /
spec:
  ingressClassName: nginx    # Which Ingress Controller to use
  rules:
  - host: myapp.example.com  # Optional - if omitted, matches any host
    http:
      paths:
      - path: /api
        pathType: Prefix     # Matches /api, /api/, /api/anything
        backend:
          service:
            name: api-service
            port:
              number: 80
      - path: /web
        pathType: Prefix
        backend:
          service:
            name: web-service
            port:
              number: 80
      - path: /
        pathType: Prefix     # Default catch-all
        backend:
          service:
            name: frontend-service
            port:
              number: 80
```

---

## Host-Based Routing

Route different hostnames to different services:

```
                   Internet
                      |
    +-----------------+-----------------+
    |                 |                 |
api.example.com   web.example.com   admin.example.com
    |                 |                 |
    v                 v                 v
+-------+        +--------+        +--------+
| api   |        | web    |        | admin  |
| svc   |        | svc    |        | svc    |
+-------+        +--------+        +--------+

All three domains can point to the SAME Ingress IP!
```

### YAML Example: Host-Based Routing

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: host-based-ingress
spec:
  ingressClassName: nginx
  rules:
  - host: api.example.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: api-service
            port:
              number: 80
  - host: web.example.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: web-service
            port:
              number: 80
  - host: admin.example.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: admin-service
            port:
              number: 80
```

---

## TLS/SSL Termination

Ingress can handle HTTPS, decrypting traffic before passing to services:

```
    Client (HTTPS)
         |
         | Encrypted traffic
         v
   +------------+
   |  Ingress   |
   | Controller |  <-- TLS Termination happens here
   |            |      (uses certificate from Secret)
   +-----+------+
         |
         | Unencrypted (HTTP) to internal services
         v
   +------------+
   |  Services  |
   +------------+

Benefits:
- Services don't need to handle certificates
- Central certificate management
- Easier certificate renewal
```

### YAML Example: TLS Configuration

```yaml
# First, create a Secret with your TLS certificate
apiVersion: v1
kind: Secret
metadata:
  name: myapp-tls-secret
type: kubernetes.io/tls
data:
  tls.crt: <base64-encoded-certificate>
  tls.key: <base64-encoded-private-key>
---
# Then reference it in Ingress
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: tls-ingress
  annotations:
    # Redirect HTTP to HTTPS
    nginx.ingress.kubernetes.io/ssl-redirect: "true"
spec:
  ingressClassName: nginx
  tls:
  - hosts:
    - myapp.example.com
    - api.example.com
    secretName: myapp-tls-secret    # Reference to the Secret
  rules:
  - host: myapp.example.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: web-service
            port:
              number: 80
  - host: api.example.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: api-service
            port:
              number: 80
```

---

## Mermaid Diagram: Complete Ingress Flow

```mermaid
flowchart TB
    subgraph Internet
        User[User Browser]
    end
    
    subgraph DNS
        DNS_Record[DNS Record\napi.example.com -> Ingress IP]
    end
    
    subgraph Cloud Provider
        LB[Cloud Load Balancer\nPublic IP: 52.x.x.x]
    end
    
    subgraph Kubernetes Cluster
        IC[Ingress Controller\nNGINX Pod]
        IR[Ingress Resource\nRouting Rules]
        
        subgraph Services
            API[api-service\nClusterIP]
            WEB[web-service\nClusterIP]
            AUTH[auth-service\nClusterIP]
        end
        
        subgraph Pods
            API_POD1[API Pod 1]
            API_POD2[API Pod 2]
            WEB_POD1[Web Pod 1]
            WEB_POD2[Web Pod 2]
            AUTH_POD1[Auth Pod 1]
        end
    end
    
    User -->|HTTPS Request| DNS_Record
    DNS_Record -->|Resolves to| LB
    LB -->|Forwards to| IC
    IC -->|Reads rules from| IR
    IC -->|/api/*| API
    IC -->|/web/*| WEB
    IC -->|/auth/*| AUTH
    API --> API_POD1
    API --> API_POD2
    WEB --> WEB_POD1
    WEB --> WEB_POD2
    AUTH --> AUTH_POD1
```

---

## Installing Ingress Controllers

### NGINX Ingress Controller (Generic)

```bash
# Using Helm (recommended)
helm repo add ingress-nginx https://kubernetes.github.io/ingress-nginx
helm repo update
helm install ingress-nginx ingress-nginx/ingress-nginx \
  --namespace ingress-nginx \
  --create-namespace

# Or using kubectl
kubectl apply -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/controller-v1.8.0/deploy/static/provider/cloud/deploy.yaml
```

### Azure Application Gateway Ingress Controller (AGIC)

```bash
# Enable AGIC add-on for AKS
az aks enable-addons \
  --resource-group myResourceGroup \
  --name myAKSCluster \
  --addons ingress-appgw \
  --appgw-name myApplicationGateway \
  --appgw-subnet-cidr "10.2.0.0/16"
```

When using AGIC, use `ingressClassName: azure-application-gateway`

---

## Common Annotations

Annotations customize Ingress Controller behavior:

### NGINX Ingress Annotations

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: annotated-ingress
  annotations:
    # Rewrite /api/users to /users before sending to backend
    nginx.ingress.kubernetes.io/rewrite-target: /$2
    
    # Enable CORS
    nginx.ingress.kubernetes.io/enable-cors: "true"
    
    # Set proxy timeouts
    nginx.ingress.kubernetes.io/proxy-read-timeout: "3600"
    nginx.ingress.kubernetes.io/proxy-send-timeout: "3600"
    
    # Rate limiting
    nginx.ingress.kubernetes.io/limit-rps: "10"
    
    # Force SSL redirect
    nginx.ingress.kubernetes.io/ssl-redirect: "true"
    
    # Custom max body size (file uploads)
    nginx.ingress.kubernetes.io/proxy-body-size: "50m"
    
    # WebSocket support
    nginx.ingress.kubernetes.io/proxy-read-timeout: "3600"
    nginx.ingress.kubernetes.io/proxy-send-timeout: "3600"
spec:
  ingressClassName: nginx
  rules:
  - host: myapp.example.com
    http:
      paths:
      - path: /api(/|$)(.*)
        pathType: Prefix
        backend:
          service:
            name: api-service
            port:
              number: 80
```

### Azure Application Gateway Annotations

```yaml
metadata:
  annotations:
    # Health probe path
    appgw.ingress.kubernetes.io/health-probe-path: "/health"
    
    # Backend protocol
    appgw.ingress.kubernetes.io/backend-protocol: "https"
    
    # Cookie-based affinity
    appgw.ingress.kubernetes.io/cookie-based-affinity: "true"
    
    # Connection draining
    appgw.ingress.kubernetes.io/connection-draining: "true"
    appgw.ingress.kubernetes.io/connection-draining-timeout: "30"
```

---

## Complete Example: Multi-Service Application

```yaml
# Namespace
apiVersion: v1
kind: Namespace
metadata:
  name: myapp
---
# Frontend Deployment
apiVersion: apps/v1
kind: Deployment
metadata:
  name: frontend
  namespace: myapp
spec:
  replicas: 2
  selector:
    matchLabels:
      app: frontend
  template:
    metadata:
      labels:
        app: frontend
    spec:
      containers:
      - name: frontend
        image: nginx:latest
        ports:
        - containerPort: 80
---
# Frontend Service
apiVersion: v1
kind: Service
metadata:
  name: frontend-service
  namespace: myapp
spec:
  selector:
    app: frontend
  ports:
  - port: 80
    targetPort: 80
---
# API Deployment
apiVersion: apps/v1
kind: Deployment
metadata:
  name: api
  namespace: myapp
spec:
  replicas: 3
  selector:
    matchLabels:
      app: api
  template:
    metadata:
      labels:
        app: api
    spec:
      containers:
      - name: api
        image: hashicorp/http-echo
        args:
        - "-text=Hello from API"
        ports:
        - containerPort: 5678
---
# API Service
apiVersion: v1
kind: Service
metadata:
  name: api-service
  namespace: myapp
spec:
  selector:
    app: api
  ports:
  - port: 80
    targetPort: 5678
---
# Ingress with both path and TLS
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: myapp-ingress
  namespace: myapp
  annotations:
    nginx.ingress.kubernetes.io/ssl-redirect: "true"
    nginx.ingress.kubernetes.io/rewrite-target: /
spec:
  ingressClassName: nginx
  tls:
  - hosts:
    - myapp.example.com
    secretName: myapp-tls
  rules:
  - host: myapp.example.com
    http:
      paths:
      - path: /api
        pathType: Prefix
        backend:
          service:
            name: api-service
            port:
              number: 80
      - path: /
        pathType: Prefix
        backend:
          service:
            name: frontend-service
            port:
              number: 80
```

---

## Ingress vs LoadBalancer: When to Use What?

```
+------------------+------------------------+------------------------+
|                  | LoadBalancer Service   | Ingress                |
+------------------+------------------------+------------------------+
| Layer            | L4 (TCP/UDP)           | L7 (HTTP/HTTPS)        |
+------------------+------------------------+------------------------+
| Routing          | IP + Port only         | Path, Host, Headers    |
+------------------+------------------------+------------------------+
| Cost             | $$$ (one per service)  | $ (one for all)        |
+------------------+------------------------+------------------------+
| SSL Termination  | At LB (limited)        | Yes, with Secrets      |
+------------------+------------------------+------------------------+
| WebSocket        | Yes                    | Yes (with annotations) |
+------------------+------------------------+------------------------+
| Non-HTTP         | Yes (any TCP/UDP)      | No (HTTP/HTTPS only)   |
+------------------+------------------------+------------------------+
| Use When         | - Database access      | - Web applications     |
|                  | - Non-HTTP protocols   | - REST APIs            |
|                  | - Single service       | - Multiple services    |
|                  |   exposure             | - Need path routing    |
+------------------+------------------------+------------------------+
```

---

## Mermaid Diagram: Decision Tree

```mermaid
flowchart TD
    A[Need external access to services?] --> B{What type of traffic?}
    
    B -->|HTTP/HTTPS| C{Multiple services?}
    B -->|TCP/UDP Non-HTTP| D[Use LoadBalancer Service]
    
    C -->|Yes| E{Need path/host routing?}
    C -->|No - Single service| F{Cost sensitive?}
    
    E -->|Yes| G[Use Ingress]
    E -->|No| H[Can use either\nIngress recommended]
    
    F -->|Yes| I[Use Ingress\neven for single service]
    F -->|No| J[Use LoadBalancer\nSimpler setup]
    
    G --> K[Choose Ingress Controller:\n- NGINX for flexibility\n- AGIC for Azure-native]
```

---

## Troubleshooting Ingress

Common issues and how to debug:

```bash
# Check Ingress resource
kubectl get ingress -n myapp
kubectl describe ingress myapp-ingress -n myapp

# Check Ingress Controller pods
kubectl get pods -n ingress-nginx
kubectl logs -n ingress-nginx <nginx-pod-name>

# Check if services have endpoints
kubectl get endpoints -n myapp

# Test from inside cluster
kubectl run tmp --rm -i --tty --image=curlimages/curl -- \
  curl -H "Host: myapp.example.com" http://ingress-nginx-controller.ingress-nginx

# Check Ingress Controller service (should have external IP)
kubectl get svc -n ingress-nginx
```

Common problems:

| Symptom | Likely Cause | Solution |
|---------|--------------|----------|
| No external IP | LoadBalancer pending | Check cloud provider config |
| 404 errors | Wrong path/host | Verify Ingress rules match requests |
| 502/503 errors | Backend unavailable | Check service endpoints exist |
| SSL errors | Wrong/missing cert | Verify TLS secret exists and is valid |

---

## Key Takeaways

1. **Ingress = Smart HTTP Router** - Routes by path/host, not just IP:port
2. **Ingress Controller Required** - Kubernetes only defines the spec, you install the implementation
3. **Cost Efficient** - One load balancer for many services
4. **TLS Made Easy** - Central certificate management
5. **NGINX is Most Popular** - But AGIC is great for Azure
6. **Use LoadBalancer for Non-HTTP** - Ingress is HTTP-only

---

## Next Up

[_03_network_policies.md](./_03_network_policies.md) - Learn how to control which Pods can talk to which with Network Policies!
