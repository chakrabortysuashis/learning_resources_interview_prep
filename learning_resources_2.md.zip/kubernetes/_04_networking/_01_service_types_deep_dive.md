# Kubernetes Service Types Deep Dive

## What is a Service?

A **Service** is an abstraction that defines a logical set of Pods and a policy to access them. Think of it as a **stable front door** to your application - even when Pods come and go, the Service IP stays the same.

```
Without Service:                    With Service:
                                    
+--------+                          +--------+
| Client |                          | Client |
+--------+                          +--------+
    |                                   |
    | Which Pod IP?                     | Service IP (stable)
    | They keep changing!               v
    v                              +---------+
+-------+  +-------+  +-------+    | Service |  <-- Stable endpoint
| Pod A |  | Pod B |  | Pod C |    +---------+
| (IP?) |  | (IP?) |  | (IP?) |         |
+-------+  +-------+  +-------+         | Load balances to healthy Pods
                                        v
                               +-------+  +-------+  +-------+
                               | Pod A |  | Pod B |  | Pod C |
                               +-------+  +-------+  +-------+
```

---

## The Four Service Types

Kubernetes provides four types of Services, each with different exposure levels:

```
                    EXPOSURE LEVEL
    
    Internal Only          External Access           External DNS
    (ClusterIP)            (NodePort/LoadBalancer)   (ExternalName)
         |                        |                        |
         v                        v                        v
    +----------+           +------------+           +--------------+
    | Only     |           | Accessible |           | Maps to      |
    | inside   |           | from       |           | external     |
    | cluster  |           | outside    |           | service      |
    +----------+           +------------+           +--------------+
```

---

## 1. ClusterIP (Default)

**What it does:** Exposes the Service on an internal IP address. Only accessible from **within the cluster**.

**Use case:** Internal microservices communication (e.g., frontend talking to backend API).

### Traffic Flow Diagram

```
+----------------------------------------------------------+
|                    KUBERNETES CLUSTER                     |
|                                                          |
|   +--------+         +-----------+         +---------+   |
|   | Pod A  |-------->| ClusterIP |-------->| Pod X   |   |
|   | (app)  |         | Service   |    +--->| Pod Y   |   |
|   +--------+         | 10.0.0.50 |    |    | Pod Z   |   |
|                      +-----------+----+    +---------+   |
|                           |                (backend)     |
|                      Only reachable                      |
|                      from inside cluster                 |
|                                                          |
+----------------------------------------------------------+
      |
      X  Cannot reach from outside
      |
  [Internet/External User]
```

### YAML Example

```yaml
apiVersion: v1
kind: Service
metadata:
  name: backend-service
spec:
  type: ClusterIP        # Default - can be omitted
  selector:
    app: backend         # Selects Pods with label app=backend
  ports:
    - port: 80           # Port the Service listens on
      targetPort: 8080   # Port on the Pod
      protocol: TCP
```

### When to Use ClusterIP

- Internal databases (PostgreSQL, MySQL, Redis)
- Internal APIs that only other services need
- Message queues (RabbitMQ, Kafka)
- Any service that should NOT be exposed externally

---

## 2. NodePort

**What it does:** Exposes the Service on **each Node's IP** at a static port (30000-32767). Creates a ClusterIP automatically.

**Use case:** Development/testing, simple external access without a load balancer.

### Traffic Flow Diagram

```
                     [Internet/External User]
                              |
                              | Request to NodeIP:30080
                              v
+------------------------------------------------------------------+
|                     KUBERNETES CLUSTER                            |
|                                                                   |
|  +------------+      +------------+      +------------+           |
|  |   Node 1   |      |   Node 2   |      |   Node 3   |           |
|  | IP: 10.0.1 |      | IP: 10.0.2 |      | IP: 10.0.3 |           |
|  |            |      |            |      |            |           |
|  | Port:30080 |      | Port:30080 |      | Port:30080 |           |
|  +-----+------+      +-----+------+      +-----+------+           |
|        |                   |                   |                  |
|        +-------------------+-------------------+                  |
|                            |                                      |
|                     +------v------+                               |
|                     |  ClusterIP  |                               |
|                     |  (internal) |                               |
|                     +------+------+                               |
|                            |                                      |
|              +-------------+-------------+                        |
|              v             v             v                        |
|         +-------+     +-------+     +-------+                     |
|         | Pod A |     | Pod B |     | Pod C |                     |
|         +-------+     +-------+     +-------+                     |
|                                                                   |
+------------------------------------------------------------------+

Access via ANY node:
  - http://10.0.1:30080
  - http://10.0.2:30080
  - http://10.0.3:30080
  
All route to the same set of Pods!
```

### YAML Example

```yaml
apiVersion: v1
kind: Service
metadata:
  name: web-nodeport
spec:
  type: NodePort
  selector:
    app: web
  ports:
    - port: 80           # ClusterIP port (internal)
      targetPort: 8080   # Pod port
      nodePort: 30080    # External port (optional, auto-assigned if omitted)
      protocol: TCP
```

### When to Use NodePort

- Quick development/testing access
- When you don't have a cloud load balancer
- On-premises clusters with external load balancer handling node IPs
- Simple demos

### Limitations

- Port range restricted to 30000-32767
- Need to know a Node IP (what if nodes change?)
- No automatic load balancing across nodes from outside

---

## 3. LoadBalancer

**What it does:** Provisions a **cloud load balancer** (Azure Load Balancer, AWS ELB, GCP Load Balancer) that routes to the Service.

**Use case:** Production external access in cloud environments.

### Traffic Flow Diagram

```
                     [Internet/External User]
                              |
                              | Request to 52.123.45.67 (Public IP)
                              v
                    +-------------------+
                    |   Cloud Provider  |
                    |   Load Balancer   |
                    |   (Azure/AWS/GCP) |
                    |   IP: 52.123.45.67|
                    +--------+----------+
                             |
                             | Distributes across Nodes
                             v
+------------------------------------------------------------------+
|                     KUBERNETES CLUSTER                            |
|                                                                   |
|  +------------+      +------------+      +------------+           |
|  |   Node 1   |      |   Node 2   |      |   Node 3   |           |
|  +-----+------+      +-----+------+      +-----+------+           |
|        |                   |                   |                  |
|        +-------------------+-------------------+                  |
|                            |                                      |
|                     +------v------+                               |
|                     |  NodePort   |                               |
|                     +------+------+                               |
|                            |                                      |
|                     +------v------+                               |
|                     |  ClusterIP  |                               |
|                     +------+------+                               |
|                            |                                      |
|              +-------------+-------------+                        |
|              v             v             v                        |
|         +-------+     +-------+     +-------+                     |
|         | Pod A |     | Pod B |     | Pod C |                     |
|         +-------+     +-------+     +-------+                     |
|                                                                   |
+------------------------------------------------------------------+

LoadBalancer = ClusterIP + NodePort + Cloud Load Balancer
(It creates all three!)
```

### YAML Example

```yaml
apiVersion: v1
kind: Service
metadata:
  name: web-loadbalancer
  annotations:
    # Azure-specific annotation for internal LB
    # service.beta.kubernetes.io/azure-load-balancer-internal: "true"
spec:
  type: LoadBalancer
  selector:
    app: web
  ports:
    - port: 80
      targetPort: 8080
      protocol: TCP
```

### Azure-Specific Example (Internal Load Balancer)

```yaml
apiVersion: v1
kind: Service
metadata:
  name: internal-app
  annotations:
    service.beta.kubernetes.io/azure-load-balancer-internal: "true"
spec:
  type: LoadBalancer
  selector:
    app: internal-app
  ports:
    - port: 80
      targetPort: 8080
```

### When to Use LoadBalancer

- Production applications that need external access
- When you need a stable public IP
- Cloud environments (AKS, EKS, GKE)
- Simple external exposure without Ingress complexity

### Limitations

- **Cost**: Each LoadBalancer service = separate cloud load balancer = $$
- One IP per service (can't share)
- Layer 4 only (TCP/UDP) - no HTTP path-based routing
- Cloud-provider dependent

---

## 4. ExternalName

**What it does:** Maps a Service to an **external DNS name**. No proxying, just DNS CNAME record.

**Use case:** Accessing external services (databases, APIs) through Kubernetes DNS.

### Traffic Flow Diagram

```
+----------------------------------------------------------+
|                    KUBERNETES CLUSTER                     |
|                                                          |
|   +--------+                                             |
|   | Pod A  |                                             |
|   +---+----+                                             |
|       |                                                  |
|       | DNS lookup: my-database.default.svc.cluster.local|
|       v                                                  |
|   +--------------+                                       |
|   | ExternalName |                                       |
|   | Service      |                                       |
|   +--------------+                                       |
|       |                                                  |
|       | Returns CNAME: database.example.com              |
|       |                                                  |
+----------------------------------------------------------+
        |
        | DNS resolves to actual IP
        v
+------------------+
| External Database|
| database.example |
| .com             |
| (outside cluster)|
+------------------+

No proxying! Just DNS redirection.
```

### YAML Example

```yaml
apiVersion: v1
kind: Service
metadata:
  name: my-database
spec:
  type: ExternalName
  externalName: database.example.com    # External DNS name
  # Note: No selector or ports needed!
```

### When to Use ExternalName

- Accessing external databases (RDS, Azure SQL)
- Third-party APIs
- Migrating services gradually (point to external, then internal)
- Creating a stable internal name for external resources

### Limitations

- No port remapping
- DNS only (no IP address)
- Some apps don't handle CNAME records well

---

## Comparison Chart

```
+---------------+-------------+----------------+------------------+---------------+
|  Service Type |  Scope      | External Access| Load Balancer    | Use Case      |
+---------------+-------------+----------------+------------------+---------------+
| ClusterIP     | Internal    | No             | Internal kube-   | Microservices |
| (default)     | only        |                | proxy            | communication |
+---------------+-------------+----------------+------------------+---------------+
| NodePort      | Node IPs    | Yes (Node IP   | None (manual)    | Dev/Test,     |
|               |             | + port)        |                  | simple access |
+---------------+-------------+----------------+------------------+---------------+
| LoadBalancer  | External IP | Yes (single    | Cloud provider   | Production    |
|               |             | stable IP)     | (costs money)    | apps          |
+---------------+-------------+----------------+------------------+---------------+
| ExternalName  | External    | N/A (points    | N/A              | External      |
|               | DNS         | outside)       |                  | services      |
+---------------+-------------+----------------+------------------+---------------+
```

---

## Mermaid Diagram: Service Type Decision Tree

```mermaid
flowchart TD
    A[Need to expose a Service?] --> B{Where is traffic coming from?}
    
    B -->|Inside Cluster Only| C[ClusterIP]
    B -->|External Access Needed| D{Do you have cloud provider?}
    B -->|Need to reach external service| E[ExternalName]
    
    D -->|Yes - AKS/EKS/GKE| F{Need advanced HTTP routing?}
    D -->|No - On-premises| G[NodePort + External LB]
    
    F -->|Yes - Path/Host routing| H[Use Ingress instead]
    F -->|No - Simple L4 exposure| I[LoadBalancer]
    
    C --> J[Internal microservices,\ndatabases, caches]
    E --> K[External databases,\nthird-party APIs]
    G --> L[Works but manual LB\nconfiguration needed]
    H --> M[See _02_ingress.md]
    I --> N[One LoadBalancer per service\n$$ but simple]
```

---

## Quick Reference: Service Type Selection

| Scenario | Recommended Service Type |
|----------|-------------------------|
| Backend API used only by frontend Pods | ClusterIP |
| Redis/PostgreSQL database | ClusterIP |
| Quick testing access to app | NodePort |
| Production web app in Azure/AWS | LoadBalancer or Ingress |
| Multiple apps sharing single IP | Ingress (see next module) |
| Accessing external database | ExternalName |
| On-premises cluster | NodePort + external F5/HAProxy |

---

## Hands-On Exercise

Try creating different service types for the same deployment:

```yaml
# 1. Create a simple deployment
apiVersion: apps/v1
kind: Deployment
metadata:
  name: nginx-test
spec:
  replicas: 3
  selector:
    matchLabels:
      app: nginx-test
  template:
    metadata:
      labels:
        app: nginx-test
    spec:
      containers:
      - name: nginx
        image: nginx:latest
        ports:
        - containerPort: 80
---
# 2. ClusterIP Service
apiVersion: v1
kind: Service
metadata:
  name: nginx-clusterip
spec:
  type: ClusterIP
  selector:
    app: nginx-test
  ports:
  - port: 80
    targetPort: 80
---
# 3. NodePort Service
apiVersion: v1
kind: Service
metadata:
  name: nginx-nodeport
spec:
  type: NodePort
  selector:
    app: nginx-test
  ports:
  - port: 80
    targetPort: 80
    nodePort: 30080
---
# 4. LoadBalancer Service (cloud only)
apiVersion: v1
kind: Service
metadata:
  name: nginx-loadbalancer
spec:
  type: LoadBalancer
  selector:
    app: nginx-test
  ports:
  - port: 80
    targetPort: 80
```

Commands to explore:

```bash
# Apply the manifests
kubectl apply -f services.yaml

# View all services
kubectl get svc

# Get detailed info
kubectl describe svc nginx-loadbalancer

# Test ClusterIP from within a Pod
kubectl run tmp-shell --rm -i --tty --image=busybox -- wget -qO- nginx-clusterip

# See endpoints (Pod IPs) behind a service
kubectl get endpoints nginx-clusterip
```

---

## Key Takeaways

1. **ClusterIP** is the default - use it for internal communication
2. **NodePort** opens a port on every node - good for development
3. **LoadBalancer** provisions cloud infrastructure - costs money but simple
4. **ExternalName** is just DNS aliasing - no actual proxying
5. For HTTP apps needing smart routing, consider **Ingress** (next topic!)

---

## Next Up

[_02_ingress.md](./_02_ingress.md) - Learn how to route multiple services through a single entry point with Ingress!
