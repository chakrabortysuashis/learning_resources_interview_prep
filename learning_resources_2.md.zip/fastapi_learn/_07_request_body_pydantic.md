# Topic 07: Request Body and Pydantic

## What is Pydantic?

Think of **Pydantic** as a **security guard** for your data. Before anyone enters a building (your API), the security guard checks:
- Do they have the right ID? (correct data type)
- Is their information complete? (required fields)
- Is everything in order? (validation rules)

```
                        YOUR API IS LIKE A BUILDING
    
    ┌─────────────────────────────────────────────────────────────┐
    │                        YOUR API                              │
    │  ┌─────────────────────────────────────────────────────────┐ │
    │  │                                                         │ │
    │  │   "Welcome! Your data looks good.                       │ │
    │  │    Come on in!"                                         │ │
    │  │                                                         │ │
    │  └─────────────────────────────────────────────────────────┘ │
    └─────────────────────────────────────────────────────────────┘
                              ▲
                              │ ALLOWED
                              │
    ┌─────────────────────────┴─────────────────────────────────┐
    │                   PYDANTIC (Security Guard)               │
    │                                                           │
    │    "Let me check your data..."                           │
    │                                                           │
    │    [x] Name is a string?     --> YES                     │
    │    [x] Age is a number?      --> YES                     │
    │    [x] Email format valid?   --> YES                     │
    │                                                           │
    │    "All checks passed!"                                  │
    └─────────────────────────┬─────────────────────────────────┘
                              │
                              │ INCOMING REQUEST
                              │
    ┌─────────────────────────┴─────────────────────────────────┐
    │                   INCOMING DATA                           │
    │   {                                                       │
    │       "name": "John",                                     │
    │       "age": 25,                                          │
    │       "email": "john@example.com"                         │
    │   }                                                       │
    └───────────────────────────────────────────────────────────┘
```

## Why Do We Need Pydantic?

Imagine you're building a registration form. Without validation, bad things can happen:

```
    WITHOUT PYDANTIC (Chaos!)               WITH PYDANTIC (Order!)
    ─────────────────────────               ───────────────────────
    
    User sends:                             User sends:
    {                                       {
      "age": "twenty-five"  <-- OOPS!        "age": "twenty-five"
    }                                       }
           │                                       │
           ▼                                       ▼
    Your code crashes when                  Pydantic catches it:
    you try: age + 5                        "Error: age must be
                                            an integer!"
           │                                       │
           ▼                                       ▼
    😱 Server Error 500                    👍 Clear error message
    User is confused                        User knows what to fix
```

## Creating Your First Pydantic Model

A **model** is like a **blueprint** that describes what data should look like:

```python
from pydantic import BaseModel

# This is a Pydantic model (the blueprint)
class User(BaseModel):
    name: str          # name must be a string (text)
    age: int           # age must be an integer (whole number)
    email: str         # email must be a string
```

```
    THE BLUEPRINT (Pydantic Model)
    
    ┌─────────────────────────────────────────┐
    │             class User                  │
    ├─────────────────────────────────────────┤
    │                                         │
    │   name: str      "Text goes here"       │
    │   ─────────      ───────────────        │
    │                                         │
    │   age: int       "Numbers only!"        │
    │   ────────       ──────────────         │
    │                                         │
    │   email: str     "Text goes here"       │
    │   ──────────     ───────────────        │
    │                                         │
    └─────────────────────────────────────────┘
    
    
    VALID DATA (Matches Blueprint)           INVALID DATA (Does NOT Match)
    
    ┌───────────────────────────┐           ┌───────────────────────────┐
    │ {                         │           │ {                         │
    │   "name": "Alice",   ✓    │           │   "name": 12345,     ✗    │
    │   "age": 30,         ✓    │           │   "age": "thirty",   ✗    │
    │   "email": "a@b.com" ✓    │           │   "email": true      ✗    │
    │ }                         │           │ }                         │
    └───────────────────────────┘           └───────────────────────────┘
```

## How Pydantic Works with FastAPI

When you use Pydantic models in FastAPI, the validation happens **automatically**:

```
    THE COMPLETE FLOW
    
    Step 1: Client Sends JSON
    ─────────────────────────
    POST /users
    {
        "name": "Bob",
        "age": 25,
        "email": "bob@mail.com"
    }
            │
            ▼
    Step 2: FastAPI Receives Request
    ─────────────────────────────────
    ┌─────────────────────────────────┐
    │  @app.post("/users")            │
    │  def create_user(user: User):   │  <-- Pydantic model as parameter
    └─────────────────────────────────┘
            │
            ▼
    Step 3: Pydantic Validates (Automatic!)
    ───────────────────────────────────────
    ┌─────────────────────────────────────┐
    │  Checking...                        │
    │                                     │
    │  name: "Bob"    --> str? YES ✓     │
    │  age: 25        --> int? YES ✓     │
    │  email: "bob@" --> str? YES ✓      │
    │                                     │
    │  ALL CHECKS PASSED!                 │
    └─────────────────────────────────────┘
            │
            ▼
    Step 4: Your Code Runs
    ──────────────────────
    Now you can safely use:
    user.name  --> "Bob"
    user.age   --> 25
    user.email --> "bob@mail.com"
```

## Field Types in Pydantic

Pydantic supports many data types:

```
    COMMON PYDANTIC TYPES
    
    ┌──────────────┬────────────────────┬──────────────────────────┐
    │ Type         │ What it means      │ Example                  │
    ├──────────────┼────────────────────┼──────────────────────────┤
    │ str          │ Text/String        │ "Hello World"            │
    │ int          │ Whole number       │ 42, -7, 0                │
    │ float        │ Decimal number     │ 3.14, -2.5               │
    │ bool         │ True or False      │ True, False              │
    │ list         │ Array of items     │ [1, 2, 3]                │
    │ dict         │ Key-value pairs    │ {"key": "value"}         │
    │ Optional[X]  │ X or None          │ "hello" or None          │
    │ List[str]    │ List of strings    │ ["a", "b", "c"]          │
    │ datetime     │ Date and time      │ "2024-01-15T10:30:00"    │
    └──────────────┴────────────────────┴──────────────────────────┘
```

## Optional vs Required Fields

```python
from typing import Optional
from pydantic import BaseModel

class Product(BaseModel):
    name: str                      # REQUIRED - must provide
    price: float                   # REQUIRED - must provide
    description: Optional[str] = None    # OPTIONAL - can skip
    in_stock: bool = True          # OPTIONAL - has default value
```

```
    REQUIRED vs OPTIONAL FIELDS
    
    ┌─────────────────────────────────────────────────────────────────┐
    │                         Product Model                           │
    ├─────────────────────────────────────────────────────────────────┤
    │                                                                 │
    │   REQUIRED FIELDS (Must provide!)                               │
    │   ┌─────────────────────────────────────────────────────────┐  │
    │   │  name: str       --> "You MUST tell me the name!"       │  │
    │   │  price: float    --> "You MUST tell me the price!"      │  │
    │   └─────────────────────────────────────────────────────────┘  │
    │                                                                 │
    │   OPTIONAL FIELDS (Can skip, has defaults)                      │
    │   ┌─────────────────────────────────────────────────────────┐  │
    │   │  description: Optional[str] = None                      │  │
    │   │       --> "If you don't provide, I'll use None"         │  │
    │   │                                                         │  │
    │   │  in_stock: bool = True                                  │  │
    │   │       --> "If you don't provide, I'll assume True"      │  │
    │   └─────────────────────────────────────────────────────────┘  │
    │                                                                 │
    └─────────────────────────────────────────────────────────────────┘
    
    
    EXAMPLE REQUESTS:
    
    ✓ VALID (all required + some optional)
    {
        "name": "Laptop",
        "price": 999.99,
        "description": "A great laptop"
    }
    
    ✓ VALID (only required fields)
    {
        "name": "Phone",
        "price": 599.99
    }
    
    ✗ INVALID (missing required field)
    {
        "name": "Tablet"
        // ERROR: "price" is missing!
    }
```

## Nested Models (Models inside Models)

Sometimes data is more complex. You can put models inside other models:

```python
class Address(BaseModel):
    street: str
    city: str
    country: str

class Person(BaseModel):
    name: str
    age: int
    address: Address    # <-- Another model inside!
```

```
    NESTED MODELS VISUALIZATION
    
    ┌─────────────────────────────────────────────────────────────────┐
    │                        Person Model                             │
    │  ┌───────────────────────────────────────────────────────────┐  │
    │  │                                                           │  │
    │  │   name: str  ───────────────────────>  "John Doe"        │  │
    │  │   age: int   ───────────────────────>  30                │  │
    │  │                                                           │  │
    │  │   address: Address  ─────────┐                           │  │
    │  │                              │                            │  │
    │  │                              ▼                            │  │
    │  │            ┌─────────────────────────────────────┐       │  │
    │  │            │         Address Model               │       │  │
    │  │            │                                     │       │  │
    │  │            │  street: str  ──>  "123 Main St"   │       │  │
    │  │            │  city: str    ──>  "New York"      │       │  │
    │  │            │  country: str ──>  "USA"           │       │  │
    │  │            │                                     │       │  │
    │  │            └─────────────────────────────────────┘       │  │
    │  │                                                           │  │
    │  └───────────────────────────────────────────────────────────┘  │
    └─────────────────────────────────────────────────────────────────┘
    
    
    THE JSON FOR THIS:
    {
        "name": "John Doe",
        "age": 30,
        "address": {                    <-- Nested object
            "street": "123 Main St",
            "city": "New York",
            "country": "USA"
        }
    }
```

## Field Validation with `Field()`

You can add extra rules to your fields:

```python
from pydantic import BaseModel, Field

class Student(BaseModel):
    name: str = Field(min_length=2, max_length=50)
    age: int = Field(ge=5, le=100)  # ge = greater or equal, le = less or equal
    grade: float = Field(ge=0, le=100)
```

```
    FIELD VALIDATION RULES
    
    ┌──────────────────────────────────────────────────────────────────┐
    │                       Student Model                              │
    ├──────────────────────────────────────────────────────────────────┤
    │                                                                  │
    │   name: str                                                      │
    │   ├── min_length=2   "At least 2 characters"                    │
    │   └── max_length=50  "At most 50 characters"                    │
    │                                                                  │
    │       "Jo" ✓     "A" ✗ (too short)    "Abc...xyz" ✗ (too long) │
    │                                                                  │
    │   ─────────────────────────────────────────────────────────────  │
    │                                                                  │
    │   age: int                                                       │
    │   ├── ge=5    "Greater than or Equal to 5"                      │
    │   └── le=100  "Less than or Equal to 100"                       │
    │                                                                  │
    │       5 ✓    50 ✓    4 ✗ (too young)    101 ✗ (too old)        │
    │                                                                  │
    │   ─────────────────────────────────────────────────────────────  │
    │                                                                  │
    │   grade: float                                                   │
    │   ├── ge=0    "No negative grades"                              │
    │   └── le=100  "Max grade is 100"                                │
    │                                                                  │
    │       0 ✓    85.5 ✓    -1 ✗ (negative)    105 ✗ (too high)     │
    │                                                                  │
    └──────────────────────────────────────────────────────────────────┘
    
    
    COMMON FIELD CONSTRAINTS:
    
    For STRINGS:
    ┌────────────────┬───────────────────────────────────┐
    │ min_length     │ Minimum number of characters      │
    │ max_length     │ Maximum number of characters      │
    │ pattern        │ Must match regex pattern          │
    └────────────────┴───────────────────────────────────┘
    
    For NUMBERS:
    ┌────────────────┬───────────────────────────────────┐
    │ gt             │ Greater Than (>)                  │
    │ ge             │ Greater than or Equal (>=)        │
    │ lt             │ Less Than (<)                     │
    │ le             │ Less than or Equal (<=)           │
    └────────────────┴───────────────────────────────────┘
```

## Automatic JSON Parsing

One of the coolest features: **Pydantic automatically converts JSON to Python objects!**

```
    AUTOMATIC CONVERSION
    
    
    RAW JSON (What client sends)          PYTHON OBJECT (What you get)
    ────────────────────────              ────────────────────────────
    
    {                                     user.name  --> "Alice"
        "name": "Alice",          ───>    user.age   --> 25
        "age": 25,                        user.email --> "alice@mail.com"
        "email": "alice@mail.com"         
    }                                     # You can do:
                                          # user.age + 5 = 30
                                          # user.name.upper() = "ALICE"
    
    
    ALSO WORKS WITH TYPE COERCION (Smart Conversion):
    
    JSON Input              What Pydantic Does              Result
    ──────────              ──────────────────              ──────
    
    "age": "25"      -->    Converts string to int    -->   age = 25
    "price": 10      -->    Converts int to float     -->   price = 10.0
    "active": 1      -->    Converts 1 to True        -->   active = True
```

## Complete Example Flow

```
    FULL REQUEST-RESPONSE CYCLE
    
    
    CLIENT                          SERVER (FastAPI + Pydantic)
    ──────                          ───────────────────────────
    
       │                                      │
       │  POST /api/users                     │
       │  ───────────────────────────────────>│
       │  {                                   │
       │    "name": "Emma",                   │
       │    "age": 28,                        │
       │    "email": "emma@test.com"          │
       │  }                                   │
       │                                      │
       │                            ┌─────────┴─────────┐
       │                            │ Pydantic Checks:  │
       │                            │                   │
       │                            │ name: str? ✓      │
       │                            │ age: int?  ✓      │
       │                            │ email: str? ✓     │
       │                            │                   │
       │                            │ ALL VALID!        │
       │                            └─────────┬─────────┘
       │                                      │
       │                            Your function runs:
       │                            def create_user(user: User):
       │                                # user is now a Python object
       │                                # with validated data!
       │                                return {"id": 1, "name": user.name}
       │                                      │
       │  <───────────────────────────────────│
       │  {"id": 1, "name": "Emma"}           │
       │                                      │
    
    
    IF VALIDATION FAILS:
    
       │  POST /api/users                     │
       │  ───────────────────────────────────>│
       │  {                                   │
       │    "name": "Emma",                   │
       │    "age": "not-a-number"   <-- BAD!  │
       │  }                                   │
       │                                      │
       │                            ┌─────────┴─────────┐
       │                            │ Pydantic Checks:  │
       │                            │                   │
       │                            │ name: str? ✓      │
       │                            │ age: int?  ✗      │
       │                            │                   │
       │                            │ VALIDATION ERROR! │
       │                            └─────────┬─────────┘
       │                                      │
       │  <───────────────────────────────────│
       │  HTTP 422 Unprocessable Entity       │
       │  {                                   │
       │    "detail": [                       │
       │      {                               │
       │        "loc": ["body", "age"],       │
       │        "msg": "value is not a        │
       │               valid integer",        │
       │        "type": "type_error.integer"  │
       │      }                               │
       │    ]                                 │
       │  }                                   │
```

## Key Takeaways

```
    SUMMARY: What Pydantic Does For You
    
    ┌─────────────────────────────────────────────────────────────────┐
    │                                                                 │
    │   1. VALIDATES DATA                                             │
    │      Checks if data matches your model (types, constraints)     │
    │                                                                 │
    │   2. CONVERTS TYPES                                             │
    │      Automatically converts "25" to 25 when needed              │
    │                                                                 │
    │   3. PROVIDES CLEAR ERRORS                                      │
    │      Tells users exactly what's wrong with their data           │
    │                                                                 │
    │   4. CREATES DOCUMENTATION                                      │
    │      FastAPI uses your models to generate API docs              │
    │                                                                 │
    │   5. GIVES AUTOCOMPLETE                                         │
    │      Your IDE knows what fields exist (user.name, user.age)     │
    │                                                                 │
    └─────────────────────────────────────────────────────────────────┘
```

## What's Next?

Now that you understand Pydantic, check out:
- `_07_pydantic_example.py` - See all these concepts in working code!
- Topic 08 - Learn how to handle errors gracefully

---
*Remember: Pydantic is your data's security guard - let it do the hard work of validation for you!*
