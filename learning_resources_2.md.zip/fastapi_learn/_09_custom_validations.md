# Topic 09: Custom Errors and Validations

## Introduction

In the previous topics, we learned about basic Pydantic validation and error handling. Now let's take it to the next level with **custom validators** and **custom exception classes**.

Think of it like this:

```
    VALIDATION LEVELS
    
    
    Level 1: Basic Type Checking (Built-in)
    ───────────────────────────────────────
    "Is this a string? Is this a number?"
    
    age: int    <-- Pydantic checks if it's really an integer
    
    
    Level 2: Field Constraints (Built-in)
    ─────────────────────────────────────
    "Is this number in the right range?"
    
    age: int = Field(ge=0, le=150)    <-- Must be 0-150
    
    
    Level 3: Custom Validators (YOU create these!)
    ───────────────────────────────────────────────
    "Does this follow MY special rules?"
    
    @field_validator('email')
    def validate_email(cls, v):
        if not v.endswith('@company.com'):
            raise ValueError('Must be company email!')
        return v
```

## Custom Field Validators

A **field validator** is a function that checks ONE specific field:

```python
from pydantic import BaseModel, field_validator

class User(BaseModel):
    username: str
    email: str
    
    @field_validator('username')
    @classmethod
    def username_must_be_lowercase(cls, v):
        if v != v.lower():
            raise ValueError('Username must be lowercase')
        return v
```

```
    HOW FIELD VALIDATORS WORK
    
    
    Input Data                       Field Validator                Result
    ──────────                       ───────────────                ──────
    
    {"username": "JohnDoe"}    -->   Check: Is it lowercase?   -->  ERROR!
                                      "JohnDoe" != "johndoe"
                                      
    {"username": "johndoe"}    -->   Check: Is it lowercase?   -->  OK!
                                      "johndoe" == "johndoe"
    
    
    THE VALIDATION FLOW:
    
    ┌─────────────────────────────────────────────────────────────┐
    │                        INCOMING DATA                        │
    │                   {"username": "JohnDoe"}                   │
    └─────────────────────────────┬───────────────────────────────┘
                                  │
                                  ▼
    ┌─────────────────────────────────────────────────────────────┐
    │                   Step 1: TYPE CHECKING                     │
    │                                                             │
    │   Is "username" a string?                                   │
    │   YES ✓                                                     │
    └─────────────────────────────┬───────────────────────────────┘
                                  │
                                  ▼
    ┌─────────────────────────────────────────────────────────────┐
    │               Step 2: FIELD VALIDATOR                       │
    │                                                             │
    │   @field_validator('username')                              │
    │   def username_must_be_lowercase(cls, v):                   │
    │       if v != v.lower():           <-- "JohnDoe" != "johndoe"
    │           raise ValueError(...)     <-- ERROR RAISED!       │
    │       return v                                              │
    └─────────────────────────────┬───────────────────────────────┘
                                  │
                                  ▼
    ┌─────────────────────────────────────────────────────────────┐
    │                      VALIDATION ERROR                       │
    │                                                             │
    │   {                                                         │
    │     "detail": [{                                            │
    │       "loc": ["body", "username"],                          │
    │       "msg": "Username must be lowercase"                   │
    │     }]                                                      │
    │   }                                                         │
    └─────────────────────────────────────────────────────────────┘
```

## Validator Modes: Before vs After

Validators can run BEFORE or AFTER Pydantic's type conversion:

```
    VALIDATION MODES
    
    
    mode='before'                        mode='after' (default)
    ─────────────                        ─────────────────────
    
    Runs BEFORE type conversion          Runs AFTER type conversion
    
    Input: "  hello  "                   Input: "  hello  "
           │                                    │
           ▼                                    ▼
    ┌─────────────────┐                 ┌─────────────────┐
    │ YOUR VALIDATOR  │                 │ TYPE CONVERSION │
    │ (raw input)     │                 │ str -> str      │
    └────────┬────────┘                 └────────┬────────┘
           │                                    │
           ▼                                    ▼
    ┌─────────────────┐                 ┌─────────────────┐
    │ TYPE CONVERSION │                 │ YOUR VALIDATOR  │
    └────────┬────────┘                 │ (typed value)   │
           │                            └────────┬────────┘
           ▼                                    │
         Result                                 ▼
                                              Result
    
    
    USE 'before' WHEN:                   USE 'after' WHEN:
    - Cleaning up raw input              - Working with typed values
    - Handling multiple input types      - Doing final validation
    - Pre-processing strings             - Most common case
```

### Example: Before vs After

```python
from pydantic import BaseModel, field_validator

class Example(BaseModel):
    # This field will have both before and after validators
    data: str
    
    @field_validator('data', mode='before')
    @classmethod
    def strip_whitespace(cls, v):
        """Runs BEFORE type conversion - clean up the input."""
        if isinstance(v, str):
            return v.strip()  # Remove leading/trailing spaces
        return v
    
    @field_validator('data', mode='after')
    @classmethod
    def must_not_be_empty(cls, v):
        """Runs AFTER - validate the cleaned, typed value."""
        if not v:
            raise ValueError('Data cannot be empty')
        return v
```

## Model Validators (Validate Multiple Fields)

Sometimes you need to validate fields **together**. Use `@model_validator`:

```python
from pydantic import BaseModel, model_validator

class DateRange(BaseModel):
    start_date: str
    end_date: str
    
    @model_validator(mode='after')
    def end_must_be_after_start(self):
        if self.end_date < self.start_date:
            raise ValueError('end_date must be after start_date')
        return self
```

```
    MODEL VALIDATOR FLOW
    
    
    ┌─────────────────────────────────────────────────────────────┐
    │                        INCOMING DATA                        │
    │            {"start_date": "2024-01-15",                     │
    │             "end_date": "2024-01-10"}                       │
    └─────────────────────────────┬───────────────────────────────┘
                                  │
                                  ▼
    ┌─────────────────────────────────────────────────────────────┐
    │                  FIELD-LEVEL VALIDATION                     │
    │                                                             │
    │   start_date: str ✓   (valid string)                       │
    │   end_date: str ✓     (valid string)                       │
    │                                                             │
    │   Individual fields are OK!                                 │
    └─────────────────────────────┬───────────────────────────────┘
                                  │
                                  ▼
    ┌─────────────────────────────────────────────────────────────┐
    │                  MODEL-LEVEL VALIDATION                     │
    │                                                             │
    │   @model_validator(mode='after')                            │
    │   def end_must_be_after_start(self):                        │
    │       "2024-01-10" < "2024-01-15"?                          │
    │       YES! End is BEFORE start!                             │
    │       raise ValueError(...)                                 │
    │                                                             │
    └─────────────────────────────┬───────────────────────────────┘
                                  │
                                  ▼
    ┌─────────────────────────────────────────────────────────────┐
    │                      VALIDATION ERROR                       │
    │                                                             │
    │   "end_date must be after start_date"                       │
    └─────────────────────────────────────────────────────────────┘
```

## Custom Exception Classes

Create your own exception types for cleaner code:

```python
class UserNotFoundError(Exception):
    """Raised when a user is not found in the database."""
    def __init__(self, user_id: int):
        self.user_id = user_id
        self.message = f"User with ID {user_id} not found"
        super().__init__(self.message)


class InvalidAgeError(Exception):
    """Raised when age is invalid for the operation."""
    def __init__(self, age: int, min_age: int):
        self.age = age
        self.min_age = min_age
        self.message = f"Age {age} is below minimum required age {min_age}"
        super().__init__(self.message)
```

```
    CUSTOM EXCEPTION HIERARCHY
    
    
                    BaseException
                         │
                         ▼
                    Exception
                         │
            ┌────────────┼────────────┐
            │            │            │
            ▼            ▼            ▼
    UserNotFoundError  InvalidAgeError  InsufficientFundsError
         │                  │                   │
         ├── user_id        ├── age             ├── balance
         ├── message        ├── min_age         ├── required
         └── ...            └── message         └── message
    
    
    WHY CREATE CUSTOM EXCEPTIONS?
    
    ┌─────────────────────────────────────────────────────────────┐
    │                                                             │
    │  1. CLARITY                                                 │
    │     Instead of: raise Exception("User not found")          │
    │     Use:        raise UserNotFoundError(user_id=42)        │
    │                                                             │
    │  2. INFORMATION                                             │
    │     Custom exceptions can carry extra data:                 │
    │     - error.user_id = 42                                   │
    │     - error.min_age = 18                                   │
    │     - error.balance = 50.00                                │
    │                                                             │
    │  3. HANDLING                                                │
    │     You can catch specific exceptions:                      │
    │     @app.exception_handler(UserNotFoundError)              │
    │                                                             │
    └─────────────────────────────────────────────────────────────┘
```

## Complete Validation Flowchart

```
    COMPLETE VALIDATION FLOW IN FASTAPI + PYDANTIC
    
    
    ┌─────────────────────────────────────────────────────────────────────┐
    │                         CLIENT REQUEST                              │
    │                                                                     │
    │    POST /users                                                      │
    │    {                                                                │
    │        "username": "  JohnDoe  ",                                   │
    │        "age": 15,                                                   │
    │        "email": "john@gmail.com"                                    │
    │    }                                                                │
    └───────────────────────────────┬─────────────────────────────────────┘
                                    │
                                    ▼
    ┌───────────────────────────────────────────────────────────────────┐
    │                    STEP 1: BEFORE VALIDATORS                       │
    │                                                                    │
    │    @field_validator('username', mode='before')                     │
    │    def strip_whitespace(cls, v):                                   │
    │        return v.strip()                                            │
    │                                                                    │
    │    "  JohnDoe  " --> "JohnDoe"                                    │
    └───────────────────────────────┬───────────────────────────────────┘
                                    │
                                    ▼
    ┌───────────────────────────────────────────────────────────────────┐
    │                    STEP 2: TYPE CONVERSION                         │
    │                                                                    │
    │    username: str   --> "JohnDoe" (string) ✓                       │
    │    age: int        --> 15 (integer) ✓                             │
    │    email: str      --> "john@gmail.com" (string) ✓                │
    └───────────────────────────────┬───────────────────────────────────┘
                                    │
                                    ▼
    ┌───────────────────────────────────────────────────────────────────┐
    │                    STEP 3: FIELD CONSTRAINTS                       │
    │                                                                    │
    │    username: Field(min_length=3) --> len("JohnDoe")=7 ✓          │
    │    age: Field(ge=0, le=150)      --> 0 <= 15 <= 150 ✓            │
    └───────────────────────────────┬───────────────────────────────────┘
                                    │
                                    ▼
    ┌───────────────────────────────────────────────────────────────────┐
    │                    STEP 4: AFTER VALIDATORS                        │
    │                                                                    │
    │    @field_validator('username', mode='after')                      │
    │    def must_be_lowercase(cls, v):                                  │
    │        if v != v.lower():                                          │
    │            raise ValueError("must be lowercase")                   │
    │                                                                    │
    │    "JohnDoe" != "johndoe" --> ERROR!                              │
    └───────────────────────────────┬───────────────────────────────────┘
                                    │
            ┌───────────────────────┴───────────────────────┐
            │                                               │
            ▼ (if no field errors)                         ▼ (if field error)
    ┌───────────────────────┐                      ┌───────────────────────┐
    │  STEP 5: MODEL        │                      │  RETURN ERROR         │
    │  VALIDATORS           │                      │                       │
    │                       │                      │  422 Unprocessable    │
    │  Check fields         │                      │  {                    │
    │  together             │                      │    "detail": [...]    │
    │                       │                      │  }                    │
    └───────────┬───────────┘                      └───────────────────────┘
                │
                ▼
    ┌───────────────────────────────────────────────────────────────────┐
    │                    STEP 6: YOUR ENDPOINT CODE                      │
    │                                                                    │
    │    @app.post("/users")                                            │
    │    def create_user(user: User):                                    │
    │        # Now you have clean, validated data!                       │
    │        # But you might still have business logic errors...         │
    │                                                                    │
    │        if user.email not in allowed_domains:                       │
    │            raise HTTPException(400, "Email domain not allowed")    │
    │                                                                    │
    │        # Or raise custom exceptions                                │
    │        if user.age < 18:                                          │
    │            raise MinimumAgeError(user.age, 18)                     │
    └───────────────────────────────┬───────────────────────────────────┘
                                    │
            ┌───────────────────────┴───────────────────────┐
            │                                               │
            ▼ (no errors)                                  ▼ (error raised)
    ┌───────────────────────┐                      ┌───────────────────────┐
    │  SUCCESS RESPONSE     │                      │  EXCEPTION HANDLERS   │
    │                       │                      │                       │
    │  200 OK               │                      │  @app.exception_      │
    │  {"id": 1, ...}       │                      │  handler(...)         │
    └───────────────────────┘                      │                       │
                                                   │  Returns error        │
                                                   │  response             │
                                                   └───────────────────────┘
```

## Common Custom Validator Patterns

### Pattern 1: Password Strength Validator

```python
import re
from pydantic import BaseModel, field_validator

class UserRegistration(BaseModel):
    username: str
    password: str
    
    @field_validator('password')
    @classmethod
    def password_strength(cls, v):
        """Ensure password meets security requirements."""
        errors = []
        
        if len(v) < 8:
            errors.append("at least 8 characters")
        if not re.search(r'[A-Z]', v):
            errors.append("at least one uppercase letter")
        if not re.search(r'[a-z]', v):
            errors.append("at least one lowercase letter")
        if not re.search(r'\d', v):
            errors.append("at least one digit")
        if not re.search(r'[!@#$%^&*(),.?":{}|<>]', v):
            errors.append("at least one special character")
        
        if errors:
            raise ValueError(f"Password must contain: {', '.join(errors)}")
        
        return v
```

### Pattern 2: Cross-Field Validation

```python
from pydantic import BaseModel, model_validator

class PasswordChange(BaseModel):
    old_password: str
    new_password: str
    confirm_password: str
    
    @model_validator(mode='after')
    def validate_passwords(self):
        """Validate password change logic."""
        if self.new_password != self.confirm_password:
            raise ValueError("New password and confirmation don't match")
        
        if self.new_password == self.old_password:
            raise ValueError("New password must be different from old password")
        
        return self
```

### Pattern 3: Conditional Validation

```python
from pydantic import BaseModel, model_validator
from typing import Optional

class PaymentInfo(BaseModel):
    payment_type: str  # "card" or "bank"
    card_number: Optional[str] = None
    bank_account: Optional[str] = None
    
    @model_validator(mode='after')
    def validate_payment_info(self):
        """Require different fields based on payment type."""
        if self.payment_type == "card" and not self.card_number:
            raise ValueError("Card number required for card payments")
        
        if self.payment_type == "bank" and not self.bank_account:
            raise ValueError("Bank account required for bank payments")
        
        return self
```

## Custom Error Messages

Make your error messages helpful and friendly:

```
    GOOD VS BAD ERROR MESSAGES
    
    
    BAD ERROR MESSAGES:
    ┌────────────────────────────────────────────────────┐
    │  "Invalid input"                                   │ <-- What's invalid?
    │  "Validation failed"                               │ <-- Why?
    │  "Error"                                           │ <-- Useless!
    └────────────────────────────────────────────────────┘
    
    
    GOOD ERROR MESSAGES:
    ┌────────────────────────────────────────────────────────────────┐
    │  "Password must be at least 8 characters (you provided 5)"    │
    │  "Email must end with @company.com"                           │
    │  "Start date (2024-01-15) cannot be after end date           │
    │   (2024-01-10)"                                               │
    └────────────────────────────────────────────────────────────────┘
    
    
    ELEMENTS OF A GOOD ERROR MESSAGE:
    
    1. WHAT is wrong
       "Password is too short"
    
    2. WHY it's wrong (the rule)
       "must be at least 8 characters"
    
    3. WHAT they provided (context)
       "you provided 5 characters"
    
    4. HOW to fix it (optional but helpful)
       "try adding more characters"
```

## Summary

```
    KEY CONCEPTS SUMMARY
    
    ┌─────────────────────────────────────────────────────────────────┐
    │                                                                 │
    │  FIELD VALIDATORS (@field_validator)                            │
    │  ───────────────────────────────────                            │
    │  - Validate ONE field at a time                                 │
    │  - Use mode='before' for preprocessing                          │
    │  - Use mode='after' (default) for final validation              │
    │                                                                 │
    │  MODEL VALIDATORS (@model_validator)                            │
    │  ──────────────────────────────────                             │
    │  - Validate MULTIPLE fields together                            │
    │  - Check relationships between fields                           │
    │  - Run after all field validators                               │
    │                                                                 │
    │  CUSTOM EXCEPTIONS                                              │
    │  ─────────────────                                              │
    │  - Create specific exception classes                            │
    │  - Include helpful data in exceptions                           │
    │  - Register handlers with @app.exception_handler                │
    │                                                                 │
    │  BEST PRACTICES                                                 │
    │  ──────────────                                                 │
    │  - Write clear error messages                                   │
    │  - Include context (what user provided)                         │
    │  - Suggest how to fix the error                                 │
    │  - Keep validation logic in the model when possible             │
    │                                                                 │
    └─────────────────────────────────────────────────────────────────┘
```

## Next Steps

- Study `_09_custom_validation.py` for working code examples
- Practice creating your own validators
- Move on to Topic 10 to learn about background tasks

---
*Remember: Good validation makes your API robust and user-friendly!*
