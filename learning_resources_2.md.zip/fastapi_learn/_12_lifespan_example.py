"""
Topic 12: Lifespan Events - Code Examples
=========================================

Lifespan events let you run code when your app STARTS and STOPS.
Perfect for setting up database connections, loading ML models, etc.

Run this file:
    uvicorn _12_lifespan_example:app --reload

Watch the terminal - you'll see startup messages when server starts
and shutdown messages when you press Ctrl+C!
"""

from contextlib import asynccontextmanager
from fastapi import FastAPI, Request, Depends, HTTPException
from typing import Optional
import asyncio
from datetime import datetime


# =============================================================================
# SIMULATED RESOURCES (In real apps, these would be actual connections)
# =============================================================================

class FakeDatabase:
    """
    Simulates a database connection.
    In real apps, you'd use:
    - SQLAlchemy async (databases + SQLAlchemy)
    - asyncpg (PostgreSQL)
    - motor (MongoDB)
    - aiosqlite (SQLite)
    """

    def __init__(self):
        self.connected = False
        self.data = {}  # In-memory storage

    async def connect(self):
        """Simulate connecting to database"""
        print("DATABASE: Connecting...")
        await asyncio.sleep(0.5)  # Simulate connection time
        self.connected = True
        # Pre-populate with some data
        self.data = {
            "users": [
                {"id": 1, "name": "Alice", "email": "alice@example.com"},
                {"id": 2, "name": "Bob", "email": "bob@example.com"},
            ],
            "items": [
                {"id": 1, "name": "Widget", "price": 9.99},
                {"id": 2, "name": "Gadget", "price": 19.99},
            ]
        }
        print("DATABASE: Connected!")

    async def disconnect(self):
        """Simulate disconnecting from database"""
        print("DATABASE: Disconnecting...")
        await asyncio.sleep(0.2)
        self.connected = False
        print("DATABASE: Disconnected!")

    async def get_users(self):
        """Get all users"""
        if not self.connected:
            raise Exception("Database not connected!")
        return self.data["users"]

    async def get_items(self):
        """Get all items"""
        if not self.connected:
            raise Exception("Database not connected!")
        return self.data["items"]


class FakeRedisCache:
    """
    Simulates a Redis cache connection.
    In real apps, you'd use:
    - aioredis or redis-py (async)
    """

    def __init__(self):
        self.connected = False
        self.cache = {}

    async def connect(self):
        """Simulate connecting to Redis"""
        print("CACHE: Connecting to Redis...")
        await asyncio.sleep(0.3)
        self.connected = True
        print("CACHE: Connected!")

    async def disconnect(self):
        """Simulate disconnecting from Redis"""
        print("CACHE: Disconnecting from Redis...")
        await asyncio.sleep(0.1)
        self.connected = False
        print("CACHE: Disconnected!")

    async def get(self, key: str) -> Optional[str]:
        """Get value from cache"""
        return self.cache.get(key)

    async def set(self, key: str, value: str, ttl: int = 300):
        """Set value in cache"""
        self.cache[key] = value


class FakeMLModel:
    """
    Simulates loading a machine learning model.
    In real apps, you'd use:
    - scikit-learn
    - TensorFlow/Keras
    - PyTorch
    - transformers (Hugging Face)
    """

    def __init__(self):
        self.loaded = False
        self.model_name = "sentiment-analyzer-v1"

    def load(self):
        """
        Simulate loading a model (this can take a LONG time in real apps!)
        This is why we do it in lifespan - only once at startup.
        """
        print(f"ML MODEL: Loading {self.model_name}...")
        # In real apps, this might take minutes!
        import time
        time.sleep(1)  # Simulate loading time
        self.loaded = True
        print(f"ML MODEL: {self.model_name} loaded!")

    def predict(self, text: str) -> dict:
        """Make a prediction"""
        if not self.loaded:
            raise Exception("Model not loaded!")

        # Fake prediction
        sentiment = "positive" if "good" in text.lower() else "negative"
        confidence = 0.85

        return {
            "text": text,
            "sentiment": sentiment,
            "confidence": confidence,
            "model": self.model_name
        }

    def unload(self):
        """Unload model to free memory"""
        print(f"ML MODEL: Unloading {self.model_name}...")
        self.loaded = False
        print(f"ML MODEL: Unloaded!")


# =============================================================================
# APPLICATION STATE CONTAINER
# =============================================================================

class AppState:
    """
    Container for all application state/resources.
    This makes it easier to manage and type-hint.
    """
    db: FakeDatabase
    cache: FakeRedisCache
    model: FakeMLModel
    start_time: datetime


# =============================================================================
# LIFESPAN CONTEXT MANAGER
# =============================================================================

@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Lifespan context manager for the application.

    STARTUP (before yield):
    - Connect to database
    - Connect to cache
    - Load ML model
    - Initialize any other resources

    SHUTDOWN (after yield):
    - Disconnect from database
    - Disconnect from cache
    - Unload ML model
    - Clean up resources
    """

    print("\n" + "=" * 60)
    print("STARTUP SEQUENCE INITIATED")
    print("=" * 60)

    # Track startup time
    startup_start = datetime.now()

    # =========================================================================
    # STARTUP: Initialize all resources
    # =========================================================================

    try:
        # 1. Initialize and connect to database
        print("\n[1/3] Initializing Database...")
        db = FakeDatabase()
        await db.connect()
        app.state.db = db

        # 2. Initialize and connect to cache
        print("\n[2/3] Initializing Cache...")
        cache = FakeRedisCache()
        await cache.connect()
        app.state.cache = cache

        # 3. Load ML model
        print("\n[3/3] Loading ML Model...")
        model = FakeMLModel()
        model.load()
        app.state.model = model

        # Store startup time
        app.state.start_time = datetime.now()

        startup_time = (datetime.now() - startup_start).total_seconds()

        print("\n" + "=" * 60)
        print(f"STARTUP COMPLETE in {startup_time:.2f} seconds")
        print("Server is ready to accept requests!")
        print("=" * 60 + "\n")

        # =====================================================================
        # YIELD: App runs here, handling requests
        # =====================================================================
        yield

    except Exception as e:
        print(f"\nSTARTUP ERROR: {e}")
        raise

    finally:
        # =====================================================================
        # SHUTDOWN: Clean up all resources
        # =====================================================================

        print("\n" + "=" * 60)
        print("SHUTDOWN SEQUENCE INITIATED")
        print("=" * 60)

        # 1. Unload ML model (free memory first)
        print("\n[1/3] Unloading ML Model...")
        if hasattr(app.state, 'model'):
            app.state.model.unload()

        # 2. Disconnect from cache
        print("\n[2/3] Disconnecting Cache...")
        if hasattr(app.state, 'cache'):
            await app.state.cache.disconnect()

        # 3. Disconnect from database
        print("\n[3/3] Disconnecting Database...")
        if hasattr(app.state, 'db'):
            await app.state.db.disconnect()

        # Calculate uptime
        if hasattr(app.state, 'start_time'):
            uptime = datetime.now() - app.state.start_time
            print(f"\nServer uptime: {uptime}")

        print("\n" + "=" * 60)
        print("SHUTDOWN COMPLETE")
        print("Goodbye!")
        print("=" * 60 + "\n")


# =============================================================================
# CREATE THE APP WITH LIFESPAN
# =============================================================================

app = FastAPI(
    title="Lifespan Events Demo",
    description="Learn how lifespan events work in FastAPI",
    lifespan=lifespan  # <-- This is the key!
)


# =============================================================================
# DEPENDENCY FUNCTIONS
# =============================================================================

async def get_db(request: Request) -> FakeDatabase:
    """Dependency to get database connection"""
    return request.app.state.db


async def get_cache(request: Request) -> FakeRedisCache:
    """Dependency to get cache connection"""
    return request.app.state.cache


async def get_model(request: Request) -> FakeMLModel:
    """Dependency to get ML model"""
    return request.app.state.model


# =============================================================================
# ENDPOINTS
# =============================================================================

@app.get("/", tags=["Info"])
async def root(request: Request):
    """
    Root endpoint showing app status.
    """
    uptime = datetime.now() - request.app.state.start_time

    return {
        "message": "Lifespan Events Demo",
        "status": "running",
        "uptime_seconds": uptime.total_seconds(),
        "resources": {
            "database": "connected" if request.app.state.db.connected else "disconnected",
            "cache": "connected" if request.app.state.cache.connected else "disconnected",
            "model": "loaded" if request.app.state.model.loaded else "unloaded"
        }
    }


@app.get("/health", tags=["Info"])
async def health_check(request: Request):
    """
    Health check endpoint - useful for load balancers and monitoring.
    """
    db_ok = request.app.state.db.connected
    cache_ok = request.app.state.cache.connected
    model_ok = request.app.state.model.loaded

    all_ok = db_ok and cache_ok and model_ok

    return {
        "status": "healthy" if all_ok else "unhealthy",
        "checks": {
            "database": "ok" if db_ok else "error",
            "cache": "ok" if cache_ok else "error",
            "model": "ok" if model_ok else "error"
        }
    }


@app.get("/users", tags=["Database"])
async def get_users(db: FakeDatabase = Depends(get_db)):
    """
    Get all users from database.

    Notice how we use the database connection from lifespan!
    We don't create a new connection for each request.
    """
    users = await db.get_users()
    return {"users": users}


@app.get("/items", tags=["Database"])
async def get_items(db: FakeDatabase = Depends(get_db)):
    """
    Get all items from database.
    """
    items = await db.get_items()
    return {"items": items}


@app.get("/predict", tags=["ML Model"])
async def predict_sentiment(
    text: str = "This is a good product!",
    model: FakeMLModel = Depends(get_model)
):
    """
    Make a sentiment prediction using the ML model.

    The model was loaded ONCE at startup (in lifespan).
    We don't reload it for each request!

    Try:
        /predict?text=This is great!
        /predict?text=This is terrible!
    """
    prediction = model.predict(text)
    return prediction


@app.get("/cached/{key}", tags=["Cache"])
async def get_cached(
    key: str,
    cache: FakeRedisCache = Depends(get_cache)
):
    """
    Get a value from cache.
    """
    value = await cache.get(key)
    if value is None:
        raise HTTPException(status_code=404, detail=f"Key '{key}' not found in cache")
    return {"key": key, "value": value}


@app.post("/cache/{key}", tags=["Cache"])
async def set_cached(
    key: str,
    value: str,
    cache: FakeRedisCache = Depends(get_cache)
):
    """
    Set a value in cache.
    """
    await cache.set(key, value)
    return {"message": "Cached successfully", "key": key, "value": value}


# =============================================================================
# ALTERNATIVE: Accessing state directly via request
# =============================================================================

@app.get("/direct-access", tags=["Alternative Access"])
async def direct_state_access(request: Request):
    """
    Shows how to access app state directly without dependencies.

    Both approaches work:
    - Using Depends() is cleaner and more testable
    - Direct access is simpler for quick uses
    """
    # Direct access via request.app.state
    db = request.app.state.db
    cache = request.app.state.cache
    model = request.app.state.model

    return {
        "message": "Direct state access works too!",
        "db_connected": db.connected,
        "cache_connected": cache.connected,
        "model_loaded": model.loaded
    }


# =============================================================================
# DOCUMENTATION
# =============================================================================

@app.get("/docs-info", tags=["Documentation"])
async def docs_info():
    """
    Information about this demo.
    """
    return {
        "title": "Lifespan Events Demo",
        "what_happens_at_startup": [
            "1. Database connection is established",
            "2. Redis cache connection is established",
            "3. ML model is loaded into memory"
        ],
        "what_happens_at_shutdown": [
            "1. ML model is unloaded (frees memory)",
            "2. Cache connection is closed",
            "3. Database connection is closed"
        ],
        "endpoints": {
            "/": "Show app status and uptime",
            "/health": "Health check for monitoring",
            "/users": "Get users from database",
            "/items": "Get items from database",
            "/predict": "Make ML prediction",
            "/cached/{key}": "Get value from cache",
            "/cache/{key}": "Set value in cache"
        },
        "try_this": [
            "1. Start the server and watch startup messages",
            "2. Visit /health to see resource status",
            "3. Visit /predict?text=This is awesome!",
            "4. Press Ctrl+C and watch shutdown messages"
        ]
    }


# =============================================================================
# EXAMPLE: Multiple lifespans for complex apps
# =============================================================================
"""
For very complex apps, you might want to separate concerns:

async def setup_database(app: FastAPI):
    db = Database()
    await db.connect()
    app.state.db = db
    return db

async def setup_cache(app: FastAPI):
    cache = Redis()
    await cache.connect()
    app.state.cache = cache
    return cache

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Setup
    db = await setup_database(app)
    cache = await setup_cache(app)

    yield

    # Cleanup
    await cache.disconnect()
    await db.disconnect()
"""


# =============================================================================
# EXAMPLE: Lifespan with configuration
# =============================================================================
"""
You can create a factory function for configurable lifespan:

def create_lifespan(db_url: str, redis_url: str):
    @asynccontextmanager
    async def lifespan(app: FastAPI):
        # Use db_url and redis_url from closure
        app.state.db = await connect(db_url)
        app.state.cache = await connect(redis_url)
        yield
        await app.state.db.close()
        await app.state.cache.close()

    return lifespan

# Usage:
app = FastAPI(
    lifespan=create_lifespan(
        db_url="postgresql://...",
        redis_url="redis://..."
    )
)
"""


# =============================================================================
# RUN THE SERVER
# =============================================================================

if __name__ == "__main__":
    import uvicorn

    print("""
    ==========================================
    Lifespan Events Demo
    ==========================================

    Watch this terminal carefully!

    When the server STARTS, you'll see:
    - Database connecting
    - Cache connecting
    - ML model loading

    When you press Ctrl+C, you'll see:
    - Model unloading
    - Cache disconnecting
    - Database disconnecting

    This demonstrates proper resource management!

    ==========================================
    """)

    uvicorn.run(app, host="0.0.0.0", port=8000)
