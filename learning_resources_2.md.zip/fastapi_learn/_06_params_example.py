"""
Topic 06: Path and Query Parameters in FastAPI
==============================================

This file demonstrates all types of parameters:
- Path parameters (required, in the URL path)
- Query parameters (optional, after the ?)
- Validation with Path() and Query()
- Type conversion
- Default values

Run this file:
    uvicorn _06_params_example:app --reload

Then open: http://localhost:8000/docs
"""

from fastapi import FastAPI, Path, Query, HTTPException
from typing import Optional
from enum import Enum
from pydantic import BaseModel

# Create our FastAPI application
app = FastAPI(
    title="Path & Query Parameters Tutorial",
    description="Learn how to use path and query parameters in FastAPI!"
)


# ============================================================
# SAMPLE DATA - In-memory "database"
# ============================================================

products_db = [
    {"id": 1, "name": "Laptop", "category": "electronics", "price": 999.99, "in_stock": True},
    {"id": 2, "name": "Headphones", "category": "electronics", "price": 149.99, "in_stock": True},
    {"id": 3, "name": "Python Book", "category": "books", "price": 39.99, "in_stock": True},
    {"id": 4, "name": "Desk Chair", "category": "furniture", "price": 249.99, "in_stock": False},
    {"id": 5, "name": "Coffee Mug", "category": "kitchen", "price": 12.99, "in_stock": True},
    {"id": 6, "name": "Backpack", "category": "accessories", "price": 79.99, "in_stock": True},
    {"id": 7, "name": "Monitor", "category": "electronics", "price": 299.99, "in_stock": False},
    {"id": 8, "name": "FastAPI Guide", "category": "books", "price": 29.99, "in_stock": True},
]


# ============================================================
# BASIC PATH PARAMETERS
# ============================================================

@app.get(
    "/products/{product_id}",
    summary="Get product by ID (path parameter)",
    tags=["Path Parameters"]
)
def get_product(product_id: int):
    """
    **Basic Path Parameter Example**

    The `{product_id}` in the URL is a path parameter.
    FastAPI automatically:
    - Extracts it from the URL
    - Converts it to an integer (because we typed it as `int`)
    - Validates it's a valid integer

    **Try these:**
    - `/products/1` - Get product with ID 1
    - `/products/5` - Get product with ID 5
    - `/products/abc` - Error! Not a valid integer
    """
    # Find the product
    for product in products_db:
        if product["id"] == product_id:
            return product

    # Not found
    raise HTTPException(status_code=404, detail=f"Product {product_id} not found")


# ============================================================
# PATH PARAMETERS WITH VALIDATION
# ============================================================

@app.get(
    "/products/{product_id}/reviews/{review_id}",
    summary="Get specific review for a product",
    tags=["Path Parameters"]
)
def get_product_review(
    product_id: int = Path(
        ...,  # ... means required (path params are always required anyway)
        gt=0,  # Must be greater than 0
        le=1000,  # Must be less than or equal to 1000
        title="Product ID",
        description="The unique identifier of the product",
        examples=[1]
    ),
    review_id: int = Path(
        ...,
        gt=0,
        title="Review ID",
        description="The unique identifier of the review",
        examples=[101]
    )
):
    """
    **Multiple Path Parameters with Validation**

    This endpoint has TWO path parameters, both with validation.

    URL pattern: `/products/{product_id}/reviews/{review_id}`

    **Validation rules:**
    - product_id must be > 0 and <= 1000
    - review_id must be > 0

    **Try these:**
    - `/products/1/reviews/101` - Valid
    - `/products/0/reviews/101` - Error! product_id must be > 0
    - `/products/1001/reviews/101` - Error! product_id must be <= 1000
    """
    return {
        "product_id": product_id,
        "review_id": review_id,
        "message": f"Fetching review {review_id} for product {product_id}"
    }


# ============================================================
# BASIC QUERY PARAMETERS
# ============================================================

@app.get(
    "/search",
    summary="Search products (query parameters)",
    tags=["Query Parameters"]
)
def search_products(
    q: str,  # Required query parameter (no default value)
    limit: int = 10  # Optional with default value
):
    """
    **Basic Query Parameters**

    Query parameters come after the `?` in the URL.

    - `q` is **required** (no default value)
    - `limit` is **optional** (defaults to 10)

    **Try these:**
    - `/search?q=laptop` - Search for "laptop"
    - `/search?q=book&limit=5` - Search with custom limit
    - `/search` - Error! Missing required parameter 'q'
    """
    # Simple search - find products containing the query
    results = [
        p for p in products_db
        if q.lower() in p["name"].lower() or q.lower() in p["category"].lower()
    ]

    return {
        "query": q,
        "limit": limit,
        "results_count": len(results[:limit]),
        "results": results[:limit]
    }


# ============================================================
# OPTIONAL QUERY PARAMETERS
# ============================================================

@app.get(
    "/products",
    summary="List products with optional filters",
    tags=["Query Parameters"]
)
def list_products(
    category: Optional[str] = None,  # Optional, no default
    min_price: Optional[float] = None,
    max_price: Optional[float] = None,
    in_stock: Optional[bool] = None,
    limit: int = 10,
    offset: int = 0
):
    """
    **Optional Query Parameters for Filtering**

    All parameters are optional. Use them to filter results.

    **Parameters:**
    - `category` - Filter by category (electronics, books, etc.)
    - `min_price` - Minimum price filter
    - `max_price` - Maximum price filter
    - `in_stock` - Only show items in stock (true/false)
    - `limit` - Number of results (default: 10)
    - `offset` - Skip this many results (for pagination)

    **Try these:**
    - `/products` - Get all products
    - `/products?category=electronics` - Only electronics
    - `/products?min_price=50&max_price=200` - Price range
    - `/products?in_stock=true` - Only in-stock items
    - `/products?category=electronics&in_stock=true&limit=5`
    """
    results = products_db.copy()

    # Apply filters if provided
    if category:
        results = [p for p in results if p["category"].lower() == category.lower()]

    if min_price is not None:
        results = [p for p in results if p["price"] >= min_price]

    if max_price is not None:
        results = [p for p in results if p["price"] <= max_price]

    if in_stock is not None:
        results = [p for p in results if p["in_stock"] == in_stock]

    # Pagination
    total = len(results)
    results = results[offset:offset + limit]

    return {
        "filters": {
            "category": category,
            "min_price": min_price,
            "max_price": max_price,
            "in_stock": in_stock
        },
        "pagination": {
            "limit": limit,
            "offset": offset,
            "total": total,
            "returned": len(results)
        },
        "products": results
    }


# ============================================================
# QUERY PARAMETERS WITH VALIDATION
# ============================================================

@app.get(
    "/validated-search",
    summary="Search with validated parameters",
    tags=["Query Parameters"]
)
def validated_search(
    q: str = Query(
        ...,  # Required
        min_length=2,  # At least 2 characters
        max_length=50,  # At most 50 characters
        title="Search Query",
        description="The search term (2-50 characters)",
        examples=["laptop"]
    ),
    page: int = Query(
        default=1,
        ge=1,  # Page must be >= 1
        le=100,  # Max page 100
        description="Page number for pagination"
    ),
    size: int = Query(
        default=10,
        ge=1,  # At least 1 item
        le=50,  # At most 50 items per page
        description="Items per page (1-50)"
    )
):
    """
    **Query Parameters with Validation Rules**

    This endpoint validates query parameters:

    - `q`: Must be 2-50 characters
    - `page`: Must be between 1 and 100
    - `size`: Must be between 1 and 50

    **Try these:**
    - `/validated-search?q=laptop` - Valid search
    - `/validated-search?q=a` - Error! Too short
    - `/validated-search?q=laptop&page=0` - Error! Page must be >= 1
    - `/validated-search?q=laptop&size=100` - Error! Size must be <= 50
    """
    # Calculate pagination
    skip = (page - 1) * size

    # Search
    results = [
        p for p in products_db
        if q.lower() in p["name"].lower() or q.lower() in p["category"].lower()
    ]

    total = len(results)
    results = results[skip:skip + size]

    return {
        "query": q,
        "page": page,
        "size": size,
        "total_results": total,
        "results": results
    }


# ============================================================
# ENUM FOR PREDEFINED VALUES
# ============================================================

class SortOrder(str, Enum):
    """Enum for sort order options."""
    asc = "asc"
    desc = "desc"


class ProductCategory(str, Enum):
    """Enum for product categories."""
    electronics = "electronics"
    books = "books"
    furniture = "furniture"
    kitchen = "kitchen"
    accessories = "accessories"


@app.get(
    "/sorted-products",
    summary="Get sorted products with enum parameters",
    tags=["Enum Parameters"]
)
def get_sorted_products(
    category: Optional[ProductCategory] = None,
    sort_by: str = Query(
        default="name",
        description="Field to sort by",
        examples=["name", "price"]
    ),
    order: SortOrder = SortOrder.asc
):
    """
    **Enum Parameters for Predefined Values**

    Using enums restricts parameters to valid values only!

    **Parameters:**
    - `category`: Must be one of: electronics, books, furniture, kitchen, accessories
    - `order`: Must be "asc" or "desc"

    **Try these:**
    - `/sorted-products?category=electronics&order=desc`
    - `/sorted-products?sort_by=price&order=desc`
    - `/sorted-products?category=invalid` - Error! Not a valid category
    """
    results = products_db.copy()

    # Filter by category
    if category:
        results = [p for p in results if p["category"] == category.value]

    # Sort
    reverse = (order == SortOrder.desc)
    if sort_by in ["name", "price", "category"]:
        results.sort(key=lambda x: x[sort_by], reverse=reverse)

    return {
        "category": category.value if category else "all",
        "sort_by": sort_by,
        "order": order.value,
        "count": len(results),
        "products": results
    }


# ============================================================
# COMBINING PATH AND QUERY PARAMETERS
# ============================================================

@app.get(
    "/users/{user_id}/orders",
    summary="Get user orders with filters",
    tags=["Combined Parameters"]
)
def get_user_orders(
    # Path parameter
    user_id: int = Path(
        ...,
        gt=0,
        description="User ID",
        examples=[1]
    ),
    # Query parameters
    status: Optional[str] = Query(
        None,
        description="Filter by order status (pending, shipped, delivered)"
    ),
    min_amount: Optional[float] = Query(
        None,
        ge=0,
        description="Minimum order amount"
    ),
    page: int = Query(1, ge=1),
    limit: int = Query(10, ge=1, le=50)
):
    """
    **Combining Path and Query Parameters**

    URL: `/users/{user_id}/orders?status=shipped&page=1`

    - `user_id` is a PATH parameter (identifies which user)
    - `status`, `min_amount`, `page`, `limit` are QUERY parameters (filters)

    **Try these:**
    - `/users/1/orders` - All orders for user 1
    - `/users/42/orders?status=shipped` - Shipped orders for user 42
    - `/users/1/orders?min_amount=100&limit=5` - Expensive orders
    """
    # Simulated order data
    orders = [
        {"id": 101, "user_id": user_id, "amount": 59.99, "status": "delivered"},
        {"id": 102, "user_id": user_id, "amount": 129.99, "status": "shipped"},
        {"id": 103, "user_id": user_id, "amount": 24.99, "status": "pending"},
        {"id": 104, "user_id": user_id, "amount": 199.99, "status": "delivered"},
    ]

    # Apply filters
    if status:
        orders = [o for o in orders if o["status"] == status]
    if min_amount is not None:
        orders = [o for o in orders if o["amount"] >= min_amount]

    # Pagination
    total = len(orders)
    start = (page - 1) * limit
    orders = orders[start:start + limit]

    return {
        "user_id": user_id,
        "filters": {"status": status, "min_amount": min_amount},
        "pagination": {"page": page, "limit": limit, "total": total},
        "orders": orders
    }


# ============================================================
# MULTIPLE VALUES (List of Query Parameters)
# ============================================================

@app.get(
    "/filter-by-ids",
    summary="Get products by multiple IDs",
    tags=["Advanced Parameters"]
)
def get_products_by_ids(
    ids: list[int] = Query(
        default=[],
        description="List of product IDs to retrieve",
        examples=[[1, 2, 3]]
    )
):
    """
    **Multiple Values for Same Parameter**

    You can pass the same parameter multiple times!

    **URL format:** `/filter-by-ids?ids=1&ids=2&ids=3`

    FastAPI collects all values into a list.

    **Try these:**
    - `/filter-by-ids?ids=1&ids=2&ids=3` - Get products 1, 2, 3
    - `/filter-by-ids?ids=5` - Get just product 5
    - `/filter-by-ids` - Empty list (returns no products)
    """
    if not ids:
        return {"message": "No IDs provided", "products": []}

    results = [p for p in products_db if p["id"] in ids]

    return {
        "requested_ids": ids,
        "found_count": len(results),
        "products": results
    }


@app.get(
    "/filter-by-categories",
    summary="Get products in multiple categories",
    tags=["Advanced Parameters"]
)
def get_products_by_categories(
    categories: list[str] = Query(
        default=[],
        description="Categories to include"
    )
):
    """
    **Multiple String Values**

    **URL format:** `/filter-by-categories?categories=electronics&categories=books`

    **Try:** `/filter-by-categories?categories=electronics&categories=books`
    """
    if not categories:
        return {"categories": [], "products": products_db}

    # Convert to lowercase for comparison
    categories_lower = [c.lower() for c in categories]
    results = [p for p in products_db if p["category"].lower() in categories_lower]

    return {
        "categories": categories,
        "found_count": len(results),
        "products": results
    }


# ============================================================
# TYPE CONVERSION DEMONSTRATION
# ============================================================

@app.get(
    "/type-demo",
    summary="Demonstrate automatic type conversion",
    tags=["Type Conversion"]
)
def type_conversion_demo(
    integer_param: int = Query(default=0, description="Will be converted to int"),
    float_param: float = Query(default=0.0, description="Will be converted to float"),
    bool_param: bool = Query(default=False, description="Will be converted to bool"),
    string_param: str = Query(default="", description="Stays as string")
):
    """
    **Automatic Type Conversion**

    FastAPI automatically converts URL strings to Python types!

    **Try these:**
    - `/type-demo?integer_param=42` - "42" becomes 42
    - `/type-demo?float_param=3.14` - "3.14" becomes 3.14
    - `/type-demo?bool_param=true` - "true" becomes True
    - `/type-demo?bool_param=1` - "1" becomes True
    - `/type-demo?bool_param=false` - "false" becomes False
    - `/type-demo?integer_param=abc` - Error! Can't convert to int

    **Boolean accepts:** true/True/1/yes/on for True; false/False/0/no/off for False
    """
    return {
        "integer_param": {"value": integer_param, "type": str(type(integer_param).__name__)},
        "float_param": {"value": float_param, "type": str(type(float_param).__name__)},
        "bool_param": {"value": bool_param, "type": str(type(bool_param).__name__)},
        "string_param": {"value": string_param, "type": str(type(string_param).__name__)}
    }


# ============================================================
# ROOT ENDPOINT
# ============================================================

@app.get("/", tags=["Info"])
def root():
    """
    Welcome page with parameter examples guide.
    """
    return {
        "message": "Welcome to the Path & Query Parameters Tutorial!",
        "examples": {
            "path_params": {
                "basic": "/products/1",
                "multiple": "/products/1/reviews/101"
            },
            "query_params": {
                "required": "/search?q=laptop",
                "optional": "/products?category=electronics&in_stock=true",
                "validated": "/validated-search?q=book&page=1&size=5",
                "enum": "/sorted-products?category=electronics&order=desc"
            },
            "combined": "/users/1/orders?status=shipped&page=1",
            "list": "/filter-by-ids?ids=1&ids=2&ids=3",
            "type_demo": "/type-demo?integer_param=42&bool_param=true"
        },
        "tips": [
            "Path parameters: Part of the URL, always required",
            "Query parameters: After ?, usually optional",
            "Use Path() and Query() for validation",
            "Enums restrict values to predefined options",
            "FastAPI auto-converts types (str to int, bool, etc.)"
        ],
        "docs": "Visit /docs for interactive API documentation"
    }


# ============================================================
# Run with: uvicorn _06_params_example:app --reload
# ============================================================

if __name__ == "__main__":
    import uvicorn
    print("\n" + "="*60)
    print("  Path & Query Parameters Tutorial Server")
    print("="*60)
    print("\n  PATH PARAMS:  /products/{id}")
    print("  QUERY PARAMS: /search?q=laptop&limit=10")
    print("  COMBINED:     /users/{id}/orders?status=shipped")
    print("\n  Open your browser to: http://localhost:8000/docs")
    print("  Press Ctrl+C to stop the server\n")
    uvicorn.run(app, host="127.0.0.1", port=8000)
