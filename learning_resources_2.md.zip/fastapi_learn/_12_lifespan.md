# Topic 12: Lifespan Events in FastAPI

## What Are Lifespan Events?

Think of lifespan events like **opening and closing a restaurant**:

```
RESTAURANT ANALOGY                    YOUR FASTAPI APP
===================                   =================

  OPENING (Morning)                    STARTUP
  - Turn on lights                     - Connect to database
  - Heat up ovens                      - Load ML model
  - Stock ingredients                  - Initialize cache
  - Brief the staff                    - Start background jobs
  
        |                                    |
        v                                    v
  
  SERVING CUSTOMERS                    HANDLING REQUESTS
  (All day)                            (While app runs)
  
        |                                    |
        v                                    v
  
  CLOSING (Night)                      SHUTDOWN
  - Clean kitchen                      - Close DB connections
  - Turn off ovens                     - Save state to disk
  - Lock the doors                     - Cancel background jobs
  - Set alarm                          - Clean up resources
```

**Lifespan events = Code that runs when your app STARTS and STOPS**

---

## The Application Lifecycle

```
                      APPLICATION LIFECYCLE
    
    +----------------------------------------------------------+
    |                                                          |
    |   STARTUP PHASE                                          |
    |   =============                                          |
    |   Server starts                                          |
    |        |                                                 |
    |        v                                                 |
    |   +----------------+                                     |
    |   | Lifespan START |  <-- Your startup code runs here   |
    |   | - DB connect   |                                     |
    |   | - Load models  |                                     |
    |   | - Init cache   |                                     |
    |   +----------------+                                     |
    |        |                                                 |
    |        v                                                 |
    |   App ready to serve!                                    |
    |                                                          |
    +----------------------------------------------------------+
    |                                                          |
    |   RUNNING PHASE                                          |
    |   =============                                          |
    |        |                                                 |
    |        v                                                 |
    |   +----------------+                                     |
    |   | Handle Request |                                     |
    |   | Handle Request |  <-- Normal operation               |
    |   | Handle Request |                                     |
    |   | ...            |                                     |
    |   +----------------+                                     |
    |        |                                                 |
    |        v                                                 |
    |   Server receives shutdown signal (Ctrl+C)               |
    |                                                          |
    +----------------------------------------------------------+
    |                                                          |
    |   SHUTDOWN PHASE                                         |
    |   ==============                                         |
    |        |                                                 |
    |        v                                                 |
    |   +----------------+                                     |
    |   | Lifespan STOP  |  <-- Your cleanup code runs here   |
    |   | - Close DB     |                                     |
    |   | - Free memory  |                                     |
    |   | - Save state   |                                     |
    |   +----------------+                                     |
    |        |                                                 |
    |        v                                                 |
    |   Server stopped                                         |
    |                                                          |
    +----------------------------------------------------------+
```

---

## Why Use Lifespan Events?

### Without Lifespan Events (Bad):

```python
# BAD: Creating connection on every request
@app.get("/users")
async def get_users():
    db = connect_to_database()  # Slow! Creates new connection each time
    users = db.get_users()
    db.close()                   # Wasteful!
    return users
```

### With Lifespan Events (Good):

```python
# GOOD: Connection created once at startup
@asynccontextmanager
async def lifespan(app):
    # Startup: connect once
    app.state.db = connect_to_database()
    yield
    # Shutdown: close once
    app.state.db.close()

@app.get("/users")
async def get_users(request: Request):
    # Reuse existing connection (fast!)
    users = request.app.state.db.get_users()
    return users
```

---

## The Lifespan Context Manager

Modern FastAPI uses the `lifespan` context manager pattern:

```python
from contextlib import asynccontextmanager
from fastapi import FastAPI

@asynccontextmanager
async def lifespan(app: FastAPI):
    # ========================================
    # STARTUP: Code before 'yield' runs first
    # ========================================
    print("Starting up...")
    # Connect to database
    # Load ML models
    # Initialize cache
    
    yield  # <-- App runs here (handles requests)
    
    # ========================================
    # SHUTDOWN: Code after 'yield' runs last
    # ========================================
    print("Shutting down...")
    # Close database connections
    # Free resources
    # Save state

app = FastAPI(lifespan=lifespan)
```

### Visual Explanation:

```
@asynccontextmanager
async def lifespan(app: FastAPI):
    
    +----------------------------------+
    |     CODE BEFORE YIELD            |
    |     (STARTUP)                    |
    |                                  |
    |     Runs ONCE when server starts |
    +----------------------------------+
                    |
                    v
    
               yield
                    
                    |
                    v
    +----------------------------------+
    |     APP HANDLES REQUESTS         |
    |     (RUNNING)                    |
    |                                  |
    |     Your endpoints work here     |
    +----------------------------------+
                    |
                    v
    
    +----------------------------------+
    |     CODE AFTER YIELD             |
    |     (SHUTDOWN)                   |
    |                                  |
    |     Runs ONCE when server stops  |
    +----------------------------------+
```

---

## Common Use Cases

### 1. Database Connection

```python
@asynccontextmanager
async def lifespan(app: FastAPI):
    # STARTUP: Create connection pool
    app.state.db_pool = await create_db_pool(
        host="localhost",
        database="myapp"
    )
    print("Database connected!")
    
    yield
    
    # SHUTDOWN: Close all connections
    await app.state.db_pool.close()
    print("Database disconnected!")
```

### 2. Loading ML Models

```python
@asynccontextmanager
async def lifespan(app: FastAPI):
    # STARTUP: Load model (can take minutes!)
    print("Loading ML model...")
    app.state.model = load_model("path/to/model.pkl")
    print("Model loaded!")
    
    yield
    
    # SHUTDOWN: Free memory
    del app.state.model
    print("Model unloaded!")
```

### 3. Redis Cache Connection

```python
@asynccontextmanager
async def lifespan(app: FastAPI):
    # STARTUP: Connect to Redis
    app.state.redis = await aioredis.from_url("redis://localhost")
    print("Redis connected!")
    
    yield
    
    # SHUTDOWN: Close Redis connection
    await app.state.redis.close()
    print("Redis disconnected!")
```

### 4. Background Task Scheduler

```python
@asynccontextmanager
async def lifespan(app: FastAPI):
    # STARTUP: Start scheduler
    scheduler = AsyncIOScheduler()
    scheduler.add_job(cleanup_old_files, 'interval', hours=1)
    scheduler.start()
    app.state.scheduler = scheduler
    
    yield
    
    # SHUTDOWN: Stop scheduler
    app.state.scheduler.shutdown()
```

---

## Accessing Lifespan Resources in Endpoints

Store resources in `app.state`:

```python
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Store in app.state
    app.state.db = await connect_to_database()
    app.state.cache = await connect_to_redis()
    
    yield
    
    await app.state.db.close()
    await app.state.cache.close()

app = FastAPI(lifespan=lifespan)

# Access via request.app.state
@app.get("/users")
async def get_users(request: Request):
    db = request.app.state.db
    users = await db.fetch_all("SELECT * FROM users")
    return users

# Or create a dependency
async def get_db(request: Request):
    return request.app.state.db

@app.get("/items")
async def get_items(db = Depends(get_db)):
    return await db.fetch_all("SELECT * FROM items")
```

---

## Old Way vs New Way

### Old Way (Deprecated):

```python
# Don't use this anymore!
@app.on_event("startup")
async def startup():
    # Startup code

@app.on_event("shutdown")
async def shutdown():
    # Shutdown code
```

### New Way (Recommended):

```python
# Use this!
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup code
    yield
    # Shutdown code

app = FastAPI(lifespan=lifespan)
```

**Why the new way is better:**
- Resources are properly scoped
- Easier to test
- Cleaner error handling
- Better type hints

---

## Complete Example Structure

```python
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request, Depends

# Database connection (fake for example)
class Database:
    async def connect(self):
        print("Connecting to database...")
    
    async def disconnect(self):
        print("Disconnecting from database...")

# ML Model (fake for example)
class MLModel:
    def load(self):
        print("Loading ML model...")
    
    def predict(self, data):
        return {"prediction": "result"}

# Lifespan manager
@asynccontextmanager
async def lifespan(app: FastAPI):
    # ===== STARTUP =====
    print("=" * 50)
    print("STARTING UP...")
    print("=" * 50)
    
    # Initialize database
    db = Database()
    await db.connect()
    app.state.db = db
    
    # Load ML model
    model = MLModel()
    model.load()
    app.state.model = model
    
    print("App is ready!")
    print("=" * 50)
    
    yield  # App runs here
    
    # ===== SHUTDOWN =====
    print("=" * 50)
    print("SHUTTING DOWN...")
    print("=" * 50)
    
    # Cleanup
    await app.state.db.disconnect()
    del app.state.model
    
    print("Cleanup complete!")
    print("=" * 50)

# Create app with lifespan
app = FastAPI(lifespan=lifespan)

# Use resources in endpoints
@app.get("/predict")
async def predict(request: Request):
    model = request.app.state.model
    return model.predict({"data": "test"})
```

---

## Error Handling in Lifespan

```python
@asynccontextmanager
async def lifespan(app: FastAPI):
    try:
        # STARTUP
        app.state.db = await connect_to_database()
        yield
    except Exception as e:
        # Handle errors during startup/running
        print(f"Error: {e}")
        raise
    finally:
        # SHUTDOWN - always runs, even if there's an error
        if hasattr(app.state, 'db'):
            await app.state.db.close()
```

---

## Timeline Visualization

```
TIME ------->

Server        Lifespan       App            Lifespan       Server
Start         START          RUNNING        STOP           Stop
  |             |              |              |              |
  v             v              v              v              v
[===]       [======]    [================]  [======]      [===]
  |             |              |              |              |
  |             |              |              |              |
  |         Connect DB    Handle Requests  Close DB         |
  |         Load Model    Handle Requests  Free Memory      |
  |         Init Cache    Handle Requests  Save State       |
  |             |              |              |              |
  +-------------+--------------+--------------+--------------+
                               
                Ctrl+C pressed here
                      or
                Server restart
```

---

## Key Points Summary

```
+----------------------------------------------------------+
|              LIFESPAN EVENTS KEY POINTS                   |
+----------------------------------------------------------+
|                                                          |
| 1. Use @asynccontextmanager for lifespan                 |
|                                                          |
| 2. Code BEFORE yield = STARTUP (runs once)               |
|                                                          |
| 3. Code AFTER yield = SHUTDOWN (runs once)               |
|                                                          |
| 4. Store resources in app.state                          |
|                                                          |
| 5. Access via request.app.state in endpoints             |
|                                                          |
| 6. Use for:                                              |
|    - Database connections                                |
|    - ML model loading                                    |
|    - Cache initialization                                |
|    - Background job setup                                |
|                                                          |
| 7. Always clean up resources in shutdown!                |
|                                                          |
| 8. Use try/finally for guaranteed cleanup                |
|                                                          |
+----------------------------------------------------------+
```

---

## What's Next?

In the next topic, we'll put EVERYTHING together in a **Complete Todo API** 
project! We'll combine:
- CRUD operations
- Pydantic validation
- Error handling
- Middleware
- Background tasks
- Lifespan events

See `_12_lifespan_example.py` for working code examples!
