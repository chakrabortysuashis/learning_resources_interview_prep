# Topic 02: Uvicorn - The Engine Behind FastAPI

## What is Uvicorn?

Remember our restaurant analogy? If FastAPI is the waiter, then **Uvicorn is the 
restaurant building itself** - the doors, lights, tables, and everything that 
needs to be running for the waiter to do their job!

```
    +----------------------------------------------------------+
    |                     UVICORN (The Building)               |
    |  +----------------------------------------------------+  |
    |  |                                                    |  |
    |  |   Internet                    FastAPI              |  |
    |  |   Requests    =====>         (Waiter)              |  |
    |  |     (Door)                      |                  |  |
    |  |                                 v                  |  |
    |  |                           Your Python Code         |  |
    |  |                              (Kitchen)             |  |
    |  |                                                    |  |
    |  +----------------------------------------------------+  |
    |                                                          |
    |   Port: 8000  |  Workers: 1  |  Hot Reload: ON           |
    +----------------------------------------------------------+
```

**Uvicorn** is an **ASGI server**. It's the program that:
1. Listens for incoming web requests
2. Passes them to your FastAPI app
3. Sends responses back to users


## WSGI vs ASGI: The Old Way vs The New Way

Before we dive deeper, let's understand a key concept:

### WSGI (Web Server Gateway Interface) - The Old Way
```
    Request 1: ----[Processing]----[Done]
    Request 2:                     ----[Processing]----[Done]
    Request 3:                                         ----[Processing]----[Done]
    
    Each request must WAIT for the previous one to finish!
    Like a single-lane road with traffic lights.
```

**WSGI** was designed when Python web apps were simple. It handles ONE request 
at a time (synchronous).

Examples: Gunicorn, uWSGI (used with Flask/Django)


### ASGI (Asynchronous Server Gateway Interface) - The New Way
```
    Request 1: ----[Start]----[Waiting for DB]----[Done]
    Request 2:      ----[Start]----[Done]
    Request 3:           ----[Start]----[Waiting for API]----[Done]
    
    Multiple requests can be handled at the SAME TIME!
    Like a multi-lane highway.
```

**ASGI** is the modern standard. It can handle MANY requests at once (asynchronous).

Examples: Uvicorn, Hypercorn, Daphne


### Comparison Chart
```
+-------------------+------------------+------------------+
|     Feature       |      WSGI        |      ASGI        |
+-------------------+------------------+------------------+
| Speed             | Good             | Excellent        |
| Async Support     | No               | Yes              |
| WebSockets        | No               | Yes              |
| HTTP/2            | Limited          | Yes              |
| Best For          | Traditional apps | Modern APIs      |
| Example Servers   | Gunicorn, uWSGI  | Uvicorn, Hypercorn|
+-------------------+------------------+------------------+
```


## Why Uvicorn?

Uvicorn is the most popular ASGI server because:

1. **Super Fast** - Built on `uvloop` (written in C for speed)
2. **Simple** - Easy to use and configure
3. **Reliable** - Battle-tested in production
4. **Recommended** - FastAPI's official recommendation

```
    Speed Comparison (requests per second)
    
    Uvicorn     ██████████████████████████████  30,000+
    Hypercorn   █████████████████████           20,000
    Daphne      ██████████████                  15,000
    
    * Numbers are approximate and depend on hardware
```


## How Uvicorn Works: Server Lifecycle

```
    UVICORN SERVER LIFECYCLE
    ========================
    
    1. STARTUP
    +--------------------------------------------------------+
    |  $ uvicorn main:app --reload                           |
    |                                                        |
    |  [Loading]     main.py                                 |
    |  [Creating]    Application instance                    |
    |  [Starting]    Server on port 8000                     |
    |  [Ready]       Listening for connections...            |
    +--------------------------------------------------------+
           |
           v
    2. RUNNING (Waiting for requests)
    +--------------------------------------------------------+
    |                                                        |
    |    Uvicorn is now LISTENING on port 8000               |
    |                                                        |
    |    +----------+       +----------+       +----------+  |
    |    | Request  | ----> | Process  | ----> | Response |  |
    |    +----------+       +----------+       +----------+  |
    |         ^                                     |        |
    |         |                                     |        |
    |         +------------- Loop -----------------+         |
    |                                                        |
    +--------------------------------------------------------+
           |
           v
    3. SHUTDOWN (Ctrl+C)
    +--------------------------------------------------------+
    |  [Signal]      Ctrl+C received                         |
    |  [Cleaning]    Closing connections                     |
    |  [Stopping]    Server shutdown                         |
    |  [Done]        Goodbye!                                |
    +--------------------------------------------------------+
```


## Installing Uvicorn

```bash
# Basic installation
pip install uvicorn

# With extra speed (recommended for production)
pip install uvicorn[standard]
```

The `[standard]` version includes:
- `uvloop` - Faster event loop (not available on Windows)
- `httptools` - Faster HTTP parsing
- `websockets` - WebSocket support


## Running Uvicorn: The Basic Command

```bash
uvicorn main:app
```

Let's break this down:
```
    uvicorn  main  :  app
       |       |   |   |
       |       |   |   +----> Variable name of your FastAPI app
       |       |   +--------> Separator
       |       +------------> Python file name (without .py)
       +--------------------> The command itself
```

So `uvicorn main:app` means:
> "Run Uvicorn, import the file `main.py`, and use the variable `app`"


## Common Uvicorn Flags (Options)

### 1. `--reload` (Development Mode)
```bash
uvicorn main:app --reload
```
**What it does:** Automatically restarts when you save code changes.
**When to use:** ONLY during development. Never in production!

```
    Without --reload:
    
    [Edit code] --> [Save] --> [Stop server] --> [Start server] --> [See changes]
    
    With --reload:
    
    [Edit code] --> [Save] --> [See changes immediately!]
```


### 2. `--host` (IP Address)
```bash
uvicorn main:app --host 0.0.0.0
```
**What it does:** Sets which IP address to listen on.
**Default:** `127.0.0.1` (only your computer can access)
**Common values:**
- `127.0.0.1` - Only you (localhost)
- `0.0.0.0` - Anyone on your network can access

```
    --host 127.0.0.1 (default)         --host 0.0.0.0
    
    +-------------+                    +-------------+
    |  Your PC    |                    |  Your PC    |
    |    [OK]     |                    |    [OK]     |
    +-------------+                    +-------------+
                                       
    +-------------+                    +-------------+
    | Other PC    |                    | Other PC    |
    |    [X]      |                    |    [OK]     |
    +-------------+                    +-------------+
```


### 3. `--port` (Port Number)
```bash
uvicorn main:app --port 3000
```
**What it does:** Sets which port to listen on.
**Default:** `8000`

```
    Think of ports like apartment numbers:
    
    +-----------------------------------+
    |     Your Computer                 |
    |                                   |
    |   Port 8000: FastAPI lives here   |
    |   Port 3000: Another app          |
    |   Port 5432: PostgreSQL database  |
    |   Port 80:   Regular websites     |
    +-----------------------------------+
```


### 4. `--workers` (Multiple Processes)
```bash
uvicorn main:app --workers 4
```
**What it does:** Runs multiple copies of your app for handling more requests.
**Default:** `1`
**Use:** Production only (doesn't work with `--reload`)

```
    --workers 1 (default)              --workers 4
    
    +-------------+                    +-------------+
    |   Worker    |                    |  Worker 1   |
    |      1      |                    +-------------+
    +-------------+                    |  Worker 2   |
                                       +-------------+
    Handles requests                   |  Worker 3   |
    one at a time                      +-------------+
                                       |  Worker 4   |
                                       +-------------+
                                       
                                       4x the capacity!
```


### 5. `--log-level` (Logging Verbosity)
```bash
uvicorn main:app --log-level debug
```
**Options:** `critical`, `error`, `warning`, `info`, `debug`, `trace`
**Default:** `info`

```
    Log Levels (most to least verbose):
    
    trace    ████████████████████  Everything (very noisy)
    debug    ████████████████      Detailed debugging info
    info     ████████████          Normal operation (default)
    warning  ████████              Only warnings and errors
    error    ████                  Only errors
    critical ██                    Only critical errors
```


### 6. `--reload-dir` (Watch Specific Folders)
```bash
uvicorn main:app --reload --reload-dir ./src
```
**What it does:** Only watches specific folders for changes.
**Use:** When you have a large project and want faster reloads.


## Common Command Combinations

```bash
# Development (most common for learning)
uvicorn main:app --reload

# Development with custom port
uvicorn main:app --reload --port 3000

# Development accessible from other devices on network
uvicorn main:app --reload --host 0.0.0.0

# Production (simple)
uvicorn main:app --host 0.0.0.0 --port 80

# Production (with multiple workers)
uvicorn main:app --host 0.0.0.0 --port 80 --workers 4
```


## Running Uvicorn from Python Code

Instead of using the command line, you can run Uvicorn from your Python file:

```python
# main.py
from fastapi import FastAPI
import uvicorn

app = FastAPI()

@app.get("/")
def home():
    return {"message": "Hello!"}

# This runs Uvicorn when you execute: python main.py
if __name__ == "__main__":
    uvicorn.run(
        "main:app",     # Your app
        host="0.0.0.0", # IP address
        port=8000,      # Port number
        reload=True     # Auto-reload
    )
```

Then just run:
```bash
python main.py
```


## Troubleshooting Common Issues

### Issue 1: "Address already in use"
```
ERROR: [Errno 48] Address already in use
```
**Solution:** Another program is using that port. Either:
- Stop the other program
- Use a different port: `uvicorn main:app --port 8001`


### Issue 2: "Module not found"
```
ERROR: Error loading ASGI app. Could not import module "main".
```
**Solution:** Make sure you're in the right directory:
```bash
cd /path/to/your/project
uvicorn main:app --reload
```


### Issue 3: "app not found in main"
```
ERROR: Error loading ASGI app. Attribute "app" not found in module "main".
```
**Solution:** Make sure your FastAPI instance is named `app`:
```python
app = FastAPI()  # Must be called "app"
```


## Try It Yourself!

1. **Basic run:**
   ```bash
   uvicorn main:app --reload
   ```
   Visit: http://localhost:8000

2. **Change the port:**
   ```bash
   uvicorn main:app --reload --port 5000
   ```
   Visit: http://localhost:5000

3. **See more logs:**
   ```bash
   uvicorn main:app --reload --log-level debug
   ```
   Watch all the extra information!

4. **Access from your phone** (same WiFi):
   ```bash
   uvicorn main:app --reload --host 0.0.0.0
   ```
   Find your computer's IP address and visit from phone!


## Summary

```
    UVICORN CHEAT SHEET
    ===================
    
    Basic Command:
    uvicorn <file>:<app> [options]
    
    Common Options:
    +------------------+--------------------------------+
    | --reload         | Auto-restart on code changes   |
    | --host 0.0.0.0   | Allow external connections     |
    | --port 3000      | Use port 3000                  |
    | --workers 4      | Run 4 worker processes         |
    | --log-level debug| Show detailed logs             |
    +------------------+--------------------------------+
    
    Most Common Command for Development:
    uvicorn main:app --reload
    
    Production Command:
    uvicorn main:app --host 0.0.0.0 --workers 4
```

Next up: Learn about GET requests - the most common way to get data!
