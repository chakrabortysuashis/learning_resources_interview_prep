"""
Topic 11: Middleware - Code Examples
====================================

Middleware is code that runs BEFORE and AFTER every request.
Think of it like security checkpoints at an airport!

Run this file:
    uvicorn _11_middleware_example:app --reload

Test:
    curl http://localhost:8000/
    curl http://localhost:8000/items
    curl -H "X-API-Key: secret123" http://localhost:8000/secure
"""

from fastapi import FastAPI, Request, Response
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from typing import Callable
import time
import uuid
from datetime import datetime

# =============================================================================
# Create the FastAPI app
# =============================================================================

app = FastAPI(
    title="Middleware Demo",
    description="Learn how middleware works in FastAPI"
)


# =============================================================================
# EXAMPLE 1: Simple Timing Middleware (using decorator)
# =============================================================================

@app.middleware("http")
async def timing_middleware(request: Request, call_next: Callable):
    """
    Measures how long each request takes to process.

    FLOW:
    1. Record start time
    2. Process request (call_next)
    3. Record end time
    4. Add processing time to response headers

    Check the response headers - you'll see X-Process-Time!
    """
    # ===== BEFORE REQUEST =====
    start_time = time.time()

    # Process the request (this calls the next middleware or endpoint)
    response = await call_next(request)

    # ===== AFTER RESPONSE =====
    process_time = time.time() - start_time

    # Add custom header to response
    response.headers["X-Process-Time"] = f"{process_time:.4f} seconds"

    return response


# =============================================================================
# EXAMPLE 2: Logging Middleware (using decorator)
# =============================================================================

@app.middleware("http")
async def logging_middleware(request: Request, call_next: Callable):
    """
    Logs every request and response.

    This creates a simple access log like:
    [2024-01-15 10:30:45] GET /api/users -> 200 (0.045s)
    """
    # ===== BEFORE REQUEST =====
    # Generate unique request ID for tracking
    request_id = str(uuid.uuid4())[:8]
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Log incoming request
    print(f"\n[{timestamp}] REQUEST {request_id}")
    print(f"  Method: {request.method}")
    print(f"  Path: {request.url.path}")
    print(f"  Client: {request.client.host if request.client else 'unknown'}")

    # Start timer
    start_time = time.time()

    # Process request
    response = await call_next(request)

    # ===== AFTER RESPONSE =====
    process_time = time.time() - start_time

    # Log response
    print(f"[{timestamp}] RESPONSE {request_id}")
    print(f"  Status: {response.status_code}")
    print(f"  Time: {process_time:.4f}s")

    # Add request ID to response headers (useful for debugging)
    response.headers["X-Request-ID"] = request_id

    return response


# =============================================================================
# EXAMPLE 3: Request ID Middleware (using class)
# =============================================================================

class RequestIDMiddleware(BaseHTTPMiddleware):
    """
    Adds a unique ID to every request.

    This is useful for:
    - Tracking requests across services
    - Debugging issues
    - Log correlation

    Using a class gives you more flexibility than the decorator approach.
    """

    async def dispatch(self, request: Request, call_next: Callable):
        # Generate or get request ID
        request_id = request.headers.get("X-Request-ID")
        if not request_id:
            request_id = str(uuid.uuid4())

        # Store in request state (accessible in endpoints)
        request.state.request_id = request_id

        # Process request
        response = await call_next(request)

        # Add to response
        response.headers["X-Request-ID"] = request_id

        return response


# Add the class-based middleware
app.add_middleware(RequestIDMiddleware)


# =============================================================================
# EXAMPLE 4: API Key Authentication Middleware
# =============================================================================

# List of valid API keys (in real app, store in database)
VALID_API_KEYS = {"secret123", "myapikey", "testkey"}

# Paths that don't require authentication
PUBLIC_PATHS = {"/", "/docs", "/openapi.json", "/redoc", "/public"}


class APIKeyMiddleware(BaseHTTPMiddleware):
    """
    Checks for valid API key in request headers.

    Blocks requests to protected endpoints if:
    - No X-API-Key header is present
    - API key is invalid

    Allows public paths without authentication.
    """

    async def dispatch(self, request: Request, call_next: Callable):
        # Check if path is public (no auth needed)
        if request.url.path in PUBLIC_PATHS:
            return await call_next(request)

        # Check for API key header
        api_key = request.headers.get("X-API-Key")

        if not api_key:
            # No API key provided - BLOCK the request
            return JSONResponse(
                status_code=401,
                content={
                    "error": "Missing API Key",
                    "message": "Please provide X-API-Key header",
                    "hint": "Try: curl -H 'X-API-Key: secret123' <url>"
                }
            )

        if api_key not in VALID_API_KEYS:
            # Invalid API key - BLOCK the request
            return JSONResponse(
                status_code=403,
                content={
                    "error": "Invalid API Key",
                    "message": "The provided API key is not valid"
                }
            )

        # Valid API key - allow request to proceed
        response = await call_next(request)
        return response


# Add API key middleware
app.add_middleware(APIKeyMiddleware)


# =============================================================================
# EXAMPLE 5: Security Headers Middleware
# =============================================================================

@app.middleware("http")
async def security_headers_middleware(request: Request, call_next: Callable):
    """
    Adds security headers to every response.

    These headers help protect against common web vulnerabilities:
    - XSS (Cross-Site Scripting)
    - Clickjacking
    - MIME type sniffing
    """
    response = await call_next(request)

    # Security headers
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"

    return response


# =============================================================================
# EXAMPLE 6: Error Handling Middleware
# =============================================================================

class ErrorHandlingMiddleware(BaseHTTPMiddleware):
    """
    Catches any unhandled exceptions and returns a nice error response.

    Without this, unhandled errors would return ugly 500 responses.
    """

    async def dispatch(self, request: Request, call_next: Callable):
        try:
            response = await call_next(request)
            return response
        except Exception as e:
            # Log the error (in real app, send to error tracking service)
            print(f"ERROR: {type(e).__name__}: {str(e)}")

            # Return nice error response
            return JSONResponse(
                status_code=500,
                content={
                    "error": "Internal Server Error",
                    "message": "Something went wrong on our end",
                    "type": type(e).__name__
                }
            )


# Add error handling middleware (should be one of the first to catch all errors)
app.add_middleware(ErrorHandlingMiddleware)


# =============================================================================
# EXAMPLE 7: Rate Limiting Middleware (Simple version)
# =============================================================================

from collections import defaultdict

# Store request counts per IP
request_counts: dict = defaultdict(list)
RATE_LIMIT = 10  # requests
RATE_WINDOW = 60  # seconds


class RateLimitMiddleware(BaseHTTPMiddleware):
    """
    Simple rate limiting based on IP address.

    Limits each IP to 10 requests per minute.

    Note: In production, use a proper rate limiting library like
    slowapi or store counts in Redis for distributed systems.
    """

    async def dispatch(self, request: Request, call_next: Callable):
        # Get client IP
        client_ip = request.client.host if request.client else "unknown"

        # Get current time
        current_time = time.time()

        # Clean old requests (older than window)
        request_counts[client_ip] = [
            t for t in request_counts[client_ip]
            if current_time - t < RATE_WINDOW
        ]

        # Check if over limit
        if len(request_counts[client_ip]) >= RATE_LIMIT:
            return JSONResponse(
                status_code=429,
                content={
                    "error": "Too Many Requests",
                    "message": f"Rate limit exceeded. Max {RATE_LIMIT} requests per {RATE_WINDOW} seconds.",
                    "retry_after": RATE_WINDOW
                }
            )

        # Record this request
        request_counts[client_ip].append(current_time)

        # Process request
        response = await call_next(request)

        # Add rate limit headers
        response.headers["X-Rate-Limit-Limit"] = str(RATE_LIMIT)
        response.headers["X-Rate-Limit-Remaining"] = str(
            RATE_LIMIT - len(request_counts[client_ip])
        )

        return response


# Uncomment to enable rate limiting:
# app.add_middleware(RateLimitMiddleware)


# =============================================================================
# TEST ENDPOINTS
# =============================================================================

@app.get("/", tags=["Public"])
def root():
    """
    Public endpoint - no API key required.
    Check response headers for middleware data!
    """
    return {
        "message": "Welcome to the Middleware Demo!",
        "tip": "Check the response headers to see middleware in action",
        "headers_to_look_for": [
            "X-Process-Time",
            "X-Request-ID",
            "X-Content-Type-Options"
        ]
    }


@app.get("/public", tags=["Public"])
def public_endpoint():
    """
    Another public endpoint.
    """
    return {"message": "This is a public endpoint - no API key needed"}


@app.get("/items", tags=["Protected"])
def get_items():
    """
    Protected endpoint - requires API key.

    Try:
        curl http://localhost:8000/items
        -> 401 Unauthorized

        curl -H "X-API-Key: secret123" http://localhost:8000/items
        -> Success!
    """
    return {
        "items": [
            {"id": 1, "name": "Widget"},
            {"id": 2, "name": "Gadget"},
            {"id": 3, "name": "Gizmo"}
        ]
    }


@app.get("/secure", tags=["Protected"])
def secure_endpoint(request: Request):
    """
    Protected endpoint that shows request info.

    Try:
        curl -H "X-API-Key: secret123" http://localhost:8000/secure
    """
    return {
        "message": "You accessed a secure endpoint!",
        "request_id": getattr(request.state, "request_id", "unknown"),
        "your_ip": request.client.host if request.client else "unknown"
    }


@app.get("/slow", tags=["Testing"])
async def slow_endpoint():
    """
    Intentionally slow endpoint to test timing middleware.

    Check X-Process-Time header - it should show ~2 seconds.
    """
    import asyncio
    await asyncio.sleep(2)  # Simulate slow operation
    return {"message": "This was a slow response", "delay": "2 seconds"}


@app.get("/error", tags=["Testing"])
def error_endpoint():
    """
    Endpoint that raises an error to test error handling middleware.
    """
    raise ValueError("This is a test error!")


@app.get("/headers", tags=["Testing"])
def show_headers(request: Request):
    """
    Shows all request headers - useful for debugging middleware.
    """
    return {
        "headers": dict(request.headers),
        "request_id": getattr(request.state, "request_id", "not set")
    }


# =============================================================================
# EXAMPLE: CORS Middleware (Built-in)
# =============================================================================

# Uncomment to enable CORS for frontend applications:
"""
from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",     # React dev server
        "http://localhost:5173",     # Vite dev server
        "https://myapp.com"          # Production frontend
    ],
    allow_credentials=True,
    allow_methods=["*"],             # Allow all HTTP methods
    allow_headers=["*"],             # Allow all headers
)
"""


# =============================================================================
# EXAMPLE: GZip Compression Middleware (Built-in)
# =============================================================================

# Uncomment to enable response compression:
"""
from fastapi.middleware.gzip import GZipMiddleware

# Compress responses larger than 500 bytes
app.add_middleware(GZipMiddleware, minimum_size=500)
"""


# =============================================================================
# DOCUMENTATION
# =============================================================================

@app.get("/docs-info", tags=["Documentation"])
def docs_info():
    """
    Information about this demo.
    """
    return {
        "title": "Middleware Demo",
        "active_middleware": [
            "TimingMiddleware - Adds X-Process-Time header",
            "LoggingMiddleware - Logs requests to console",
            "RequestIDMiddleware - Adds X-Request-ID header",
            "APIKeyMiddleware - Protects non-public endpoints",
            "SecurityHeadersMiddleware - Adds security headers",
            "ErrorHandlingMiddleware - Catches unhandled errors"
        ],
        "test_endpoints": {
            "/": "Public - no auth needed",
            "/public": "Public - no auth needed",
            "/items": "Protected - needs X-API-Key header",
            "/secure": "Protected - shows request info",
            "/slow": "Test timing middleware (2s delay)",
            "/error": "Test error handling middleware",
            "/headers": "Show all request headers"
        },
        "valid_api_keys": ["secret123", "myapikey", "testkey"],
        "try_this": "curl -H 'X-API-Key: secret123' http://localhost:8000/items"
    }


# =============================================================================
# MIDDLEWARE ORDER VISUALIZATION
# =============================================================================
"""
MIDDLEWARE EXECUTION ORDER
==========================

The middleware runs in this order (last added = first executed):

REQUEST FLOW:
    Client Request
         |
         v
    [ErrorHandlingMiddleware]  <-- Catches all errors
         |
         v
    [APIKeyMiddleware]         <-- Checks authentication
         |
         v
    [RequestIDMiddleware]      <-- Adds request ID
         |
         v
    [security_headers]         <-- Adds security headers
         |
         v
    [logging_middleware]       <-- Logs request
         |
         v
    [timing_middleware]        <-- Starts timer
         |
         v
    === ENDPOINT ===           <-- Your code runs here
         |
         v
    [timing_middleware]        <-- Stops timer, adds header
         |
         v
    [logging_middleware]       <-- Logs response
         |
         v
    [security_headers]         <-- Headers already added
         |
         v
    [RequestIDMiddleware]      <-- ID already added
         |
         v
    [APIKeyMiddleware]         <-- Passes through
         |
         v
    [ErrorHandlingMiddleware]  <-- Passes through (or catches error)
         |
         v
    Client Response

Remember: Middleware wraps around the endpoint like an onion!
"""


# =============================================================================
# RUN THE SERVER
# =============================================================================

if __name__ == "__main__":
    import uvicorn

    print("""
    ==========================================
    Middleware Demo Server
    ==========================================

    Starting server at http://localhost:8000

    Public endpoints (no API key):
    - GET /
    - GET /public
    - GET /docs

    Protected endpoints (need X-API-Key header):
    - GET /items
    - GET /secure

    Test endpoints:
    - GET /slow     (test timing middleware)
    - GET /error    (test error handling)
    - GET /headers  (see all headers)

    Valid API keys: secret123, myapikey, testkey

    Example:
        curl -H "X-API-Key: secret123" http://localhost:8000/items

    ==========================================
    """)

    uvicorn.run(app, host="0.0.0.0", port=8000)
