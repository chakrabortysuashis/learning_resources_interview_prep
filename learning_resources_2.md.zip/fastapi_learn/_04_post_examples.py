"""
Topic 04: POST Request Examples in FastAPI
==========================================

This file demonstrates how to create POST endpoints that receive data
from clients. We'll use Pydantic models for data validation.

Run this file:
    uvicorn _04_post_examples:app --reload

Then open: http://localhost:8000/docs
"""

from fastapi import FastAPI, status
from pydantic import BaseModel, Field, EmailStr
from typing import Optional
from datetime import datetime

# Create our FastAPI application
app = FastAPI(
    title="POST Requests Tutorial",
    description="Learn how POST requests work in FastAPI!"
)

# ============================================================
# PYDANTIC MODELS - Define the structure of data we expect
# ============================================================

class StudentCreate(BaseModel):
    """
    This model defines what data we expect when creating a student.
    Think of it as a form that must be filled out correctly!

    The Field() function lets us add extra validation and descriptions.
    """
    name: str = Field(
        ...,  # ... means required (no default value)
        min_length=1,
        max_length=100,
        description="The student's full name",
        examples=["Alice Johnson"]
    )
    age: int = Field(
        ...,
        ge=5,    # ge = greater than or equal to
        le=100,  # le = less than or equal to
        description="Student's age (must be between 5 and 100)",
        examples=[16]
    )
    grade: str = Field(
        ...,
        description="Current grade level",
        examples=["10th Grade"]
    )
    email: Optional[str] = Field(
        None,  # None means optional with no default
        description="Student's email address (optional)",
        examples=["alice@school.edu"]
    )


class StudentResponse(BaseModel):
    """
    This model defines what we send BACK after creating a student.
    Notice it has extra fields like 'id' and 'created_at' that we add.
    """
    id: int
    name: str
    age: int
    grade: str
    email: Optional[str]
    created_at: str
    message: str


# In-memory "database" (just a list for this example)
# In real apps, you'd use a real database!
students_db: list[dict] = []
student_id_counter = 0


# ============================================================
# BASIC POST ENDPOINT
# ============================================================

@app.post(
    "/students/",
    response_model=StudentResponse,
    status_code=status.HTTP_201_CREATED,  # 201 = Created
    summary="Create a new student",
    tags=["Students"]
)
def create_student(student: StudentCreate):
    """
    Create a new student record.

    This endpoint:
    1. Receives student data in the request body
    2. Validates it against our StudentCreate model
    3. Adds it to our "database"
    4. Returns the created student with an ID

    **Example request body:**
    ```json
    {
        "name": "Alice Johnson",
        "age": 16,
        "grade": "10th Grade",
        "email": "alice@school.edu"
    }
    ```
    """
    global student_id_counter

    # Generate a new ID
    student_id_counter += 1

    # Create the student record
    new_student = {
        "id": student_id_counter,
        "name": student.name,
        "age": student.age,
        "grade": student.grade,
        "email": student.email,
        "created_at": datetime.now().isoformat()
    }

    # Add to our "database"
    students_db.append(new_student)

    # Return response with success message
    return {
        **new_student,
        "message": f"Student '{student.name}' created successfully!"
    }


# ============================================================
# POST WITH MULTIPLE MODELS
# ============================================================

class BookCreate(BaseModel):
    """Model for creating a new book."""
    title: str = Field(..., min_length=1, max_length=200, examples=["Harry Potter"])
    author: str = Field(..., min_length=1, max_length=100, examples=["J.K. Rowling"])
    year: int = Field(..., ge=1000, le=2100, examples=[1997])
    isbn: Optional[str] = Field(None, examples=["978-0747532699"])


class BookResponse(BaseModel):
    """Model for book response."""
    id: int
    title: str
    author: str
    year: int
    isbn: Optional[str]
    available: bool
    message: str


# In-memory book storage
books_db: list[dict] = []
book_id_counter = 0


@app.post(
    "/books/",
    response_model=BookResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Add a new book to the library",
    tags=["Books"]
)
def create_book(book: BookCreate):
    """
    Add a new book to the library catalog.

    The book will be marked as 'available' by default.
    """
    global book_id_counter

    book_id_counter += 1

    new_book = {
        "id": book_id_counter,
        "title": book.title,
        "author": book.author,
        "year": book.year,
        "isbn": book.isbn,
        "available": True  # New books are available by default
    }

    books_db.append(new_book)

    return {
        **new_book,
        "message": f"Book '{book.title}' added to library!"
    }


# ============================================================
# POST WITH NESTED MODELS
# ============================================================

class Address(BaseModel):
    """Nested model for address information."""
    street: str = Field(..., examples=["123 Main St"])
    city: str = Field(..., examples=["Springfield"])
    zip_code: str = Field(..., examples=["12345"])


class TeacherCreate(BaseModel):
    """
    Model with a nested model inside it!
    The 'address' field uses another Pydantic model.
    """
    name: str = Field(..., examples=["Mr. Smith"])
    subject: str = Field(..., examples=["Mathematics"])
    years_experience: int = Field(..., ge=0, examples=[10])
    address: Address  # This is a nested model!


class TeacherResponse(BaseModel):
    """Response model for teacher."""
    id: int
    name: str
    subject: str
    years_experience: int
    address: Address
    message: str


teachers_db: list[dict] = []
teacher_id_counter = 0


@app.post(
    "/teachers/",
    response_model=TeacherResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Register a new teacher",
    tags=["Teachers"]
)
def create_teacher(teacher: TeacherCreate):
    """
    Register a new teacher with their address.

    Notice how the address is a nested object:
    ```json
    {
        "name": "Mr. Smith",
        "subject": "Mathematics",
        "years_experience": 10,
        "address": {
            "street": "123 Main St",
            "city": "Springfield",
            "zip_code": "12345"
        }
    }
    ```
    """
    global teacher_id_counter

    teacher_id_counter += 1

    new_teacher = {
        "id": teacher_id_counter,
        "name": teacher.name,
        "subject": teacher.subject,
        "years_experience": teacher.years_experience,
        "address": teacher.address.model_dump()  # Convert nested model to dict
    }

    teachers_db.append(new_teacher)

    return {
        **new_teacher,
        "address": teacher.address,  # Return as model for proper serialization
        "message": f"Teacher '{teacher.name}' registered!"
    }


# ============================================================
# POST WITH LIST OF ITEMS
# ============================================================

class OrderItem(BaseModel):
    """Single item in an order."""
    product_name: str = Field(..., examples=["Notebook"])
    quantity: int = Field(..., ge=1, examples=[2])
    price: float = Field(..., gt=0, examples=[5.99])


class OrderCreate(BaseModel):
    """
    Order with multiple items.
    The 'items' field is a LIST of OrderItem models!
    """
    customer_name: str = Field(..., examples=["John Doe"])
    items: list[OrderItem]  # List of nested models!


class OrderResponse(BaseModel):
    """Response for created order."""
    id: int
    customer_name: str
    items: list[OrderItem]
    total: float
    item_count: int
    message: str


orders_db: list[dict] = []
order_id_counter = 0


@app.post(
    "/orders/",
    response_model=OrderResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Place a new order",
    tags=["Orders"]
)
def create_order(order: OrderCreate):
    """
    Place a new order with multiple items.

    Example with multiple items:
    ```json
    {
        "customer_name": "John Doe",
        "items": [
            {"product_name": "Notebook", "quantity": 2, "price": 5.99},
            {"product_name": "Pen", "quantity": 5, "price": 1.50}
        ]
    }
    ```
    """
    global order_id_counter

    order_id_counter += 1

    # Calculate total
    total = sum(item.quantity * item.price for item in order.items)
    item_count = sum(item.quantity for item in order.items)

    new_order = {
        "id": order_id_counter,
        "customer_name": order.customer_name,
        "items": [item.model_dump() for item in order.items],
        "total": round(total, 2),
        "item_count": item_count
    }

    orders_db.append(new_order)

    return {
        **new_order,
        "items": order.items,  # Return as models
        "message": f"Order #{order_id_counter} placed! Total: ${total:.2f}"
    }


# ============================================================
# GET ENDPOINTS TO SEE OUR DATA
# ============================================================

@app.get("/students/", tags=["Students"], summary="List all students")
def list_students():
    """Get all students that have been created."""
    return {"students": students_db, "count": len(students_db)}


@app.get("/books/", tags=["Books"], summary="List all books")
def list_books():
    """Get all books in the library."""
    return {"books": books_db, "count": len(books_db)}


@app.get("/teachers/", tags=["Teachers"], summary="List all teachers")
def list_teachers():
    """Get all registered teachers."""
    return {"teachers": teachers_db, "count": len(teachers_db)}


@app.get("/orders/", tags=["Orders"], summary="List all orders")
def list_orders():
    """Get all placed orders."""
    return {"orders": orders_db, "count": len(orders_db)}


# ============================================================
# ROOT ENDPOINT - Welcome message
# ============================================================

@app.get("/", tags=["Info"])
def root():
    """
    Welcome page with instructions.
    """
    return {
        "message": "Welcome to the POST Requests Tutorial!",
        "instructions": [
            "1. Go to /docs to see the interactive API documentation",
            "2. Try the POST endpoints to create new records",
            "3. Use the GET endpoints to see what you've created",
            "4. Experiment with invalid data to see validation errors!"
        ],
        "endpoints": {
            "students": "POST /students/ - Create a student",
            "books": "POST /books/ - Add a book",
            "teachers": "POST /teachers/ - Register a teacher (with nested address)",
            "orders": "POST /orders/ - Place an order (with list of items)"
        }
    }


# ============================================================
# Run with: uvicorn _04_post_examples:app --reload
# Then visit: http://localhost:8000/docs
# ============================================================

if __name__ == "__main__":
    import uvicorn
    print("\n" + "="*60)
    print("  POST Requests Tutorial Server")
    print("="*60)
    print("\n  Open your browser to: http://localhost:8000/docs")
    print("  Press Ctrl+C to stop the server\n")
    uvicorn.run(app, host="127.0.0.1", port=8000)
