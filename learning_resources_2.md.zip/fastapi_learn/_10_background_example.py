"""
Topic 10: Background Tasks - Code Examples
==========================================

Background tasks let your API respond quickly while doing
extra work (like sending emails) AFTER the response is sent.

Run this file:
    uvicorn _10_background_example:app --reload

Test endpoints:
    POST http://localhost:8000/signup?email=test@example.com
    POST http://localhost:8000/upload-report
    POST http://localhost:8000/order
"""

from fastapi import FastAPI, BackgroundTasks, UploadFile, File
from pydantic import BaseModel, EmailStr
from datetime import datetime
import time

app = FastAPI(
    title="Background Tasks Demo",
    description="Learn how background tasks work in FastAPI"
)


# =============================================================================
# HELPER FUNCTIONS (These simulate real work)
# =============================================================================

def write_log(message: str):
    """
    Simulates writing to a log file.
    In real apps, this might write to a file or database.
    """
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_entry = f"[{timestamp}] {message}"
    print(f"LOG: {log_entry}")
    # In real app: write to file or send to logging service


def send_email(to_email: str, subject: str, body: str):
    """
    Simulates sending an email.
    In real apps, use libraries like:
    - smtplib (built-in Python)
    - SendGrid
    - AWS SES
    - Mailgun
    """
    print(f"SENDING EMAIL...")
    print(f"  To: {to_email}")
    print(f"  Subject: {subject}")
    print(f"  Body: {body}")

    # Simulate email taking 2 seconds to send
    time.sleep(2)

    print(f"EMAIL SENT to {to_email}!")


def process_file(filename: str, content: bytes):
    """
    Simulates processing a file (like resizing an image or parsing CSV).
    """
    print(f"PROCESSING FILE: {filename}")
    print(f"  Size: {len(content)} bytes")

    # Simulate processing taking 3 seconds
    time.sleep(3)

    print(f"FILE PROCESSED: {filename}")


def notify_admin(event: str, details: str):
    """
    Simulates sending a notification to admin.
    """
    print(f"ADMIN NOTIFICATION:")
    print(f"  Event: {event}")
    print(f"  Details: {details}")


def update_analytics(event_type: str, user_email: str):
    """
    Simulates updating analytics/metrics.
    """
    print(f"ANALYTICS UPDATE: {event_type} by {user_email}")


# =============================================================================
# EXAMPLE 1: Simple Background Task - Email on Signup
# =============================================================================

class UserSignup(BaseModel):
    """User signup data"""
    email: EmailStr
    name: str


@app.post("/signup", tags=["Email Example"])
def signup_user(
    email: str,
    name: str = "New User",
    background_tasks: BackgroundTasks = None
):
    """
    User signup endpoint that sends a welcome email in the background.

    FLOW:
    1. User sends signup request
    2. Server validates data
    3. Server responds "Signup successful!" (INSTANT)
    4. Email sends in BACKGROUND (user doesn't wait)

    Try it:
        curl -X POST "http://localhost:8000/signup?email=test@example.com&name=John"

    Watch your terminal - you'll see the email send AFTER you get the response!
    """
    # This returns IMMEDIATELY
    # The email sends AFTER this response is sent to the user

    if background_tasks:
        # Add email task to background
        background_tasks.add_task(
            send_email,                          # Function to call
            email,                               # First argument: to_email
            "Welcome to Our App!",               # Second argument: subject
            f"Hi {name}, thanks for signing up!" # Third argument: body
        )

        # Also log this event in background
        background_tasks.add_task(
            write_log,
            f"New user signup: {email}"
        )

    # User gets this response IMMEDIATELY
    # They don't wait for email to send!
    return {
        "message": "Signup successful!",
        "email": email,
        "note": "Check your email for a welcome message (sending in background)"
    }


# =============================================================================
# EXAMPLE 2: Multiple Background Tasks
# =============================================================================

class OrderCreate(BaseModel):
    """Order creation data"""
    product: str
    quantity: int
    customer_email: str


@app.post("/order", tags=["Multiple Tasks Example"])
def create_order(
    product: str = "Widget",
    quantity: int = 1,
    customer_email: str = "customer@example.com",
    background_tasks: BackgroundTasks = None
):
    """
    Create an order with MULTIPLE background tasks.

    After responding, the server will:
    1. Send confirmation email
    2. Notify admin
    3. Update analytics
    4. Write to log

    All these happen IN ORDER after the response is sent.

    Try it:
        curl -X POST "http://localhost:8000/order?product=Laptop&quantity=2"
    """
    order_id = f"ORD-{datetime.now().strftime('%Y%m%d%H%M%S')}"

    if background_tasks:
        # Task 1: Send confirmation email to customer
        background_tasks.add_task(
            send_email,
            customer_email,
            f"Order Confirmed: {order_id}",
            f"Your order for {quantity}x {product} has been placed!"
        )

        # Task 2: Notify admin about new order
        background_tasks.add_task(
            notify_admin,
            "NEW_ORDER",
            f"Order {order_id}: {quantity}x {product}"
        )

        # Task 3: Update analytics
        background_tasks.add_task(
            update_analytics,
            "order_placed",
            customer_email
        )

        # Task 4: Log the order
        background_tasks.add_task(
            write_log,
            f"Order created: {order_id} - {quantity}x {product}"
        )

    # Response is sent IMMEDIATELY
    # All 4 tasks run in sequence AFTER this
    return {
        "order_id": order_id,
        "product": product,
        "quantity": quantity,
        "status": "confirmed",
        "message": "Order placed! Confirmation email on its way."
    }


# =============================================================================
# EXAMPLE 3: File Processing in Background
# =============================================================================

@app.post("/upload-report", tags=["File Processing Example"])
async def upload_report(
    background_tasks: BackgroundTasks
):
    """
    Simulates uploading a report file and processing it in background.

    Real-world uses:
    - Resizing uploaded images
    - Parsing CSV/Excel files
    - Generating thumbnails
    - Converting file formats

    The user gets "Upload received!" immediately while
    the file processes in the background.
    """
    # Simulate file content (in real app, this comes from UploadFile)
    fake_filename = "quarterly_report.pdf"
    fake_content = b"This is simulated file content..." * 100

    # Add file processing to background
    background_tasks.add_task(
        process_file,
        fake_filename,
        fake_content
    )

    # Notify admin about new upload
    background_tasks.add_task(
        notify_admin,
        "FILE_UPLOAD",
        f"New file uploaded: {fake_filename}"
    )

    # Log the upload
    background_tasks.add_task(
        write_log,
        f"File uploaded: {fake_filename} ({len(fake_content)} bytes)"
    )

    # User gets response immediately!
    return {
        "message": "Upload received!",
        "filename": fake_filename,
        "status": "processing",
        "note": "File is being processed in background. You'll be notified when done."
    }


# =============================================================================
# EXAMPLE 4: Background Task with Function Parameters
# =============================================================================

def send_notification(
    user_id: int,
    message: str,
    notification_type: str = "info",
    priority: int = 1
):
    """
    Simulates sending a notification with various parameters.
    Shows how to pass different types of arguments to background tasks.
    """
    print(f"NOTIFICATION for User {user_id}:")
    print(f"  Type: {notification_type}")
    print(f"  Priority: {priority}")
    print(f"  Message: {message}")

    # Simulate sending
    time.sleep(1)

    print(f"Notification sent to user {user_id}!")


@app.post("/notify/{user_id}", tags=["Parameters Example"])
def notify_user(
    user_id: int,
    message: str = "Hello!",
    priority: int = 1,
    background_tasks: BackgroundTasks = None
):
    """
    Shows how to pass different types of arguments to background tasks.

    You can pass:
    - Positional arguments (in order)
    - Keyword arguments (by name)

    Try it:
        curl -X POST "http://localhost:8000/notify/42?message=Hello&priority=5"
    """
    if background_tasks:
        # Mix of positional and keyword arguments
        background_tasks.add_task(
            send_notification,
            user_id,                        # positional arg 1
            message,                        # positional arg 2
            notification_type="alert",      # keyword arg
            priority=priority               # keyword arg
        )

    return {
        "message": "Notification queued!",
        "user_id": user_id,
        "note": "User will receive notification shortly"
    }


# =============================================================================
# EXAMPLE 5: Async Background Task
# =============================================================================

import asyncio

async def async_send_email(to_email: str, content: str):
    """
    An ASYNC background task.
    Use async tasks when your task involves async operations
    like async database calls or async HTTP requests.
    """
    print(f"ASYNC: Starting to send email to {to_email}")

    # Simulate async operation (like async HTTP request)
    await asyncio.sleep(2)

    print(f"ASYNC: Email sent to {to_email}: {content}")


async def async_update_database(data: dict):
    """
    Simulates an async database update.
    """
    print(f"ASYNC: Updating database with {data}")
    await asyncio.sleep(1)
    print(f"ASYNC: Database updated!")


@app.post("/async-action", tags=["Async Example"])
async def perform_async_action(
    email: str = "user@example.com",
    background_tasks: BackgroundTasks = None
):
    """
    Demonstrates async background tasks.

    Async tasks are useful when your background work involves:
    - Async database calls (SQLAlchemy async, motor for MongoDB)
    - Async HTTP requests (httpx, aiohttp)
    - Any await-able operations

    FastAPI handles both sync and async background tasks automatically!
    """
    if background_tasks:
        # Async background task
        background_tasks.add_task(
            async_send_email,
            email,
            "This is an async email!"
        )

        # Another async task
        background_tasks.add_task(
            async_update_database,
            {"action": "email_sent", "to": email}
        )

    return {
        "message": "Async action initiated!",
        "email": email,
        "note": "Background tasks running asynchronously"
    }


# =============================================================================
# EXAMPLE 6: Practical Use Case - User Registration Flow
# =============================================================================

class FullUserRegistration(BaseModel):
    """Complete user registration data"""
    email: str
    username: str
    full_name: str


def create_user_in_db(user_data: dict):
    """Simulates creating user in database (this would be sync in real app too)"""
    print(f"DB: Creating user {user_data['username']}")
    # In real app: database.users.insert(user_data)


def send_verification_email(email: str, token: str):
    """Send email verification link"""
    print(f"VERIFICATION: Sending to {email}")
    print(f"  Link: https://myapp.com/verify?token={token}")
    time.sleep(2)
    print(f"VERIFICATION: Email sent!")


def create_default_settings(user_id: str):
    """Create default user settings"""
    print(f"SETTINGS: Creating defaults for user {user_id}")
    # In real app: database.settings.insert({user_id: user_id, theme: "light", ...})


def send_admin_notification(event: str):
    """Notify admins of new registration"""
    print(f"ADMIN: New event - {event}")


@app.post("/register", tags=["Practical Example"])
def register_user(
    email: str = "newuser@example.com",
    username: str = "newuser",
    full_name: str = "New User",
    background_tasks: BackgroundTasks = None
):
    """
    A realistic user registration flow.

    SYNCHRONOUS (user waits):
    - Validate data
    - Check if email/username taken
    - Create user in database

    BACKGROUND (user doesn't wait):
    - Send verification email
    - Create default settings
    - Notify admins
    - Update analytics
    - Write audit log

    This pattern keeps registration FAST while still doing all necessary work!
    """
    # Generate fake user ID and verification token
    user_id = f"user_{username}_{datetime.now().strftime('%H%M%S')}"
    verification_token = f"verify_{user_id}_token"

    # ===== SYNCHRONOUS PART (User waits for this) =====
    # In real app: check database for existing email/username
    print(f"Checking if {email} is available...")

    # Create user (this should be fast)
    user_data = {
        "id": user_id,
        "email": email,
        "username": username,
        "full_name": full_name,
        "created_at": datetime.now().isoformat()
    }
    create_user_in_db(user_data)

    # ===== BACKGROUND PART (User doesn't wait) =====
    if background_tasks:
        # Send verification email (takes time, user shouldn't wait)
        background_tasks.add_task(
            send_verification_email,
            email,
            verification_token
        )

        # Create default user settings
        background_tasks.add_task(
            create_default_settings,
            user_id
        )

        # Notify admins
        background_tasks.add_task(
            send_admin_notification,
            f"New user registered: {username} ({email})"
        )

        # Update analytics
        background_tasks.add_task(
            update_analytics,
            "user_registered",
            email
        )

        # Audit log
        background_tasks.add_task(
            write_log,
            f"REGISTRATION: {username} ({email}) registered successfully"
        )

    # User gets this response FAST!
    return {
        "message": "Registration successful!",
        "user_id": user_id,
        "username": username,
        "email": email,
        "next_steps": [
            "Check your email for verification link",
            "Complete your profile",
            "Start exploring!"
        ]
    }


# =============================================================================
# DOCUMENTATION ENDPOINT
# =============================================================================

@app.get("/", tags=["Documentation"])
def root():
    """
    Welcome endpoint with documentation.
    """
    return {
        "title": "Background Tasks Demo",
        "description": "Learn how FastAPI background tasks work",
        "endpoints": {
            "/signup": "Simple email background task",
            "/order": "Multiple background tasks",
            "/upload-report": "File processing in background",
            "/notify/{user_id}": "Background task with parameters",
            "/async-action": "Async background tasks",
            "/register": "Complete registration flow"
        },
        "tip": "Watch your terminal to see background tasks execute AFTER responses!",
        "docs": "Visit /docs for interactive API documentation"
    }


# =============================================================================
# RUN THE SERVER
# =============================================================================

if __name__ == "__main__":
    import uvicorn

    print("""
    ==========================================
    Background Tasks Demo Server
    ==========================================

    Starting server at http://localhost:8000

    Try these endpoints:
    - POST /signup?email=test@example.com
    - POST /order?product=Laptop
    - POST /upload-report
    - POST /register?username=john&email=john@example.com

    Watch this terminal to see background tasks
    execute AFTER you receive responses!

    API docs at: http://localhost:8000/docs
    ==========================================
    """)

    uvicorn.run(app, host="0.0.0.0", port=8000)
