# Topic 11: Middleware in FastAPI

## What is Middleware?

Think of middleware like **security checkpoints at an airport**:

```
YOU (Traveler)                         YOUR API
    |                                     |
    v                                     v
+-------------------+              +-------------------+
|   Check Ticket    |              |  Check Request    |
|   (Validation)    |              |  (Validation)     |
+-------------------+              +-------------------+
    |                                     |
    v                                     v
+-------------------+              +-------------------+
|   Security Scan   |              |  Log Request      |
|   (Safety Check)  |              |  (Logging)        |
+-------------------+              +-------------------+
    |                                     |
    v                                     v
+-------------------+              +-------------------+
|   Passport Check  |              |  Verify Auth      |
|   (Identity)      |              |  (Authentication) |
+-------------------+              +-------------------+
    |                                     |
    v                                     v
  GATE                                ENDPOINT
  (Destination)                       (Your Code)
```

**Middleware = Code that runs BEFORE and/or AFTER every request**

---

## The Request-Response Lifecycle

```
                    YOUR FASTAPI APP
    +--------------------------------------------------+
    |                                                  |
    |  REQUEST                                         |
    |     |                                            |
    |     v                                            |
    |  +------------------+                            |
    |  | Middleware 1     |--+                         |
    |  | (e.g., Logging)  |  |                         |
    |  +------------------+  |                         |
    |     |                  |                         |
    |     v                  |                         |
    |  +------------------+  |                         |
    |  | Middleware 2     |--+                         |
    |  | (e.g., Auth)     |  |  PROCESSING            |
    |  +------------------+  |  REQUEST               |
    |     |                  |                         |
    |     v                  |                         |
    |  +------------------+  |                         |
    |  | Middleware 3     |--+                         |
    |  | (e.g., CORS)     |  |                         |
    |  +------------------+  |                         |
    |     |                  |                         |
    |     v                  v                         |
    |  +------------------+                            |
    |  |    ENDPOINT      |  <-- Your actual code     |
    |  |    /users/{id}   |                           |
    |  +------------------+                            |
    |     |                  ^                         |
    |     v                  |                         |
    |  +------------------+  |                         |
    |  | Middleware 3     |--+                         |
    |  +------------------+  |                         |
    |     |                  |                         |
    |     v                  |                         |
    |  +------------------+  |                         |
    |  | Middleware 2     |--+  PROCESSING            |
    |  +------------------+  |  RESPONSE              |
    |     |                  |                         |
    |     v                  |                         |
    |  +------------------+  |                         |
    |  | Middleware 1     |--+                         |
    |  +------------------+                            |
    |     |                                            |
    |     v                                            |
    |  RESPONSE                                        |
    |                                                  |
    +--------------------------------------------------+
```

**Key Point:** Middleware wraps around your endpoint like layers of an onion!

---

## The "Onion" Model

```
           REQUEST COMES IN
                 |
                 v
    +---------------------------+
    |      Middleware 1         |
    |  +---------------------+  |
    |  |    Middleware 2     |  |
    |  |  +---------------+  |  |
    |  |  | Middleware 3  |  |  |
    |  |  |  +---------+  |  |  |
    |  |  |  |ENDPOINT |  |  |  |
    |  |  |  +---------+  |  |  |
    |  |  +---------------+  |  |
    |  +---------------------+  |
    +---------------------------+
                 |
                 v
          RESPONSE GOES OUT
```

Each middleware:
1. Receives the request
2. Can modify the request
3. Passes to next layer (or blocks it!)
4. Receives the response
5. Can modify the response
6. Passes response back

---

## Common Use Cases for Middleware

```
+-------------------+----------------------------------------+
| USE CASE          | WHAT IT DOES                           |
+-------------------+----------------------------------------+
| Logging           | Log every request/response             |
| Timing            | Measure how long requests take         |
| Authentication    | Check if user is logged in             |
| CORS              | Handle cross-origin requests           |
| Rate Limiting     | Block too many requests                |
| Error Handling    | Catch and format all errors            |
| Compression       | Compress large responses               |
| Security Headers  | Add security headers to responses      |
+-------------------+----------------------------------------+
```

---

## Creating Custom Middleware

### Method 1: Using @app.middleware Decorator

```python
from fastapi import FastAPI, Request
import time

app = FastAPI()

@app.middleware("http")
async def timing_middleware(request: Request, call_next):
    # ===== BEFORE REQUEST =====
    start_time = time.time()
    
    # Process the request (call the next middleware or endpoint)
    response = await call_next(request)
    
    # ===== AFTER RESPONSE =====
    process_time = time.time() - start_time
    response.headers["X-Process-Time"] = str(process_time)
    
    return response
```

### The Flow:

```
@app.middleware("http")
async def my_middleware(request: Request, call_next):
    
    # 1. CODE HERE RUNS BEFORE THE REQUEST
    #    - Log the request
    #    - Check authentication
    #    - Modify request data
    
    response = await call_next(request)  # <-- Goes to next layer
    
    # 2. CODE HERE RUNS AFTER THE RESPONSE
    #    - Log the response
    #    - Add headers
    #    - Modify response data
    
    return response
```

---

## Method 2: Using BaseHTTPMiddleware Class

For more complex middleware, use a class:

```python
from starlette.middleware.base import BaseHTTPMiddleware
from fastapi import Request

class LoggingMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        # Before
        print(f"Request: {request.method} {request.url}")
        
        # Process
        response = await call_next(request)
        
        # After
        print(f"Response: {response.status_code}")
        
        return response

# Add to app
app.add_middleware(LoggingMiddleware)
```

---

## Middleware Order Matters!

```python
# Added LAST, runs FIRST (outermost layer)
app.add_middleware(AuthMiddleware)

# Added SECOND, runs SECOND
app.add_middleware(LoggingMiddleware)  

# Added FIRST, runs LAST (closest to endpoint)
app.add_middleware(TimingMiddleware)
```

Visual:
```
Request --> Auth --> Logging --> Timing --> ENDPOINT
Response <-- Auth <-- Logging <-- Timing <--
```

**Think of it like putting on clothes:**
- You put on shirt first (added first to middleware)
- Then jacket (added second)
- Jacket is the OUTER layer (executes first on request)

---

## Built-in Middleware

FastAPI/Starlette comes with useful middleware:

### CORS Middleware
```python
from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],  # Frontend URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

### GZip Compression
```python
from fastapi.middleware.gzip import GZipMiddleware

app.add_middleware(GZipMiddleware, minimum_size=1000)
```

### Trusted Host
```python
from fastapi.middleware.trustedhost import TrustedHostMiddleware

app.add_middleware(
    TrustedHostMiddleware, 
    allowed_hosts=["example.com", "*.example.com"]
)
```

---

## Practical Example: Complete Logging Middleware

```
+----------------------------------------------------------+
|                  LOGGING MIDDLEWARE                       |
+----------------------------------------------------------+
|                                                          |
|  REQUEST IN:                                             |
|  +------------------------+                              |
|  | Method: POST           |                              |
|  | URL: /api/users        |                              |
|  | Time: 2024-01-15 10:30 |                              |
|  | IP: 192.168.1.1        |                              |
|  +------------------------+                              |
|                 |                                        |
|                 v                                        |
|           [ENDPOINT]                                     |
|                 |                                        |
|                 v                                        |
|  RESPONSE OUT:                                           |
|  +------------------------+                              |
|  | Status: 201            |                              |
|  | Time: 0.045s           |                              |
|  +------------------------+                              |
|                                                          |
+----------------------------------------------------------+
```

---

## Middleware vs Dependencies

When to use which?

```
+------------------+------------------+------------------------+
| Feature          | Middleware       | Dependencies           |
+------------------+------------------+------------------------+
| Scope            | ALL requests     | Specific endpoints     |
| Access to        | Raw request      | Parsed data, params    |
| Return value     | Must return      | Can return values      |
|                  | response         | to endpoint            |
| Best for         | Cross-cutting    | Endpoint-specific      |
|                  | concerns         | logic                  |
+------------------+------------------+------------------------+

MIDDLEWARE for:              DEPENDENCIES for:
- Logging all requests       - Getting current user
- Timing all requests        - Database session
- CORS for all endpoints     - Validation logic
- Security headers           - Permission checks
```

---

## Request Object - What You Can Access

```python
@app.middleware("http")
async def example_middleware(request: Request, call_next):
    # Available on request:
    request.method      # "GET", "POST", etc.
    request.url         # Full URL
    request.url.path    # Just the path: "/api/users"
    request.headers     # All headers
    request.query_params  # Query parameters
    request.path_params   # Path parameters (if available)
    request.client.host   # Client IP address
    request.cookies     # Cookies
    
    # For body (careful - can only read once!)
    body = await request.body()
    
    response = await call_next(request)
    return response
```

---

## Modifying Response

```python
@app.middleware("http")
async def add_headers_middleware(request: Request, call_next):
    response = await call_next(request)
    
    # Add custom headers to EVERY response
    response.headers["X-Custom-Header"] = "Hello!"
    response.headers["X-Server-Time"] = str(time.time())
    
    return response
```

---

## Blocking Requests in Middleware

You can reject requests before they reach your endpoint:

```python
from fastapi import Response

@app.middleware("http")
async def check_api_key(request: Request, call_next):
    # Check for API key in headers
    api_key = request.headers.get("X-API-Key")
    
    if not api_key:
        # BLOCK the request - don't call endpoint
        return Response(
            content="Missing API Key",
            status_code=401
        )
    
    # API key exists - continue to endpoint
    response = await call_next(request)
    return response
```

```
Without API Key:
Request --> Middleware --> BLOCKED! (401 response)
                          (Never reaches endpoint)

With API Key:
Request --> Middleware --> Endpoint --> Response
```

---

## Error Handling in Middleware

```python
@app.middleware("http")
async def error_handling_middleware(request: Request, call_next):
    try:
        response = await call_next(request)
        return response
    except Exception as e:
        # Catch ANY error and return nice response
        return Response(
            content=f"Internal error: {str(e)}",
            status_code=500
        )
```

---

## Key Points Summary

```
+----------------------------------------------------------+
|               MIDDLEWARE KEY POINTS                       |
+----------------------------------------------------------+
|                                                          |
| 1. Runs on EVERY request (before and after)              |
|                                                          |
| 2. Order matters: last added = first to run              |
|                                                          |
| 3. Can modify request and response                       |
|                                                          |
| 4. Can block requests (return early)                     |
|                                                          |
| 5. Must always return a response                         |
|                                                          |
| 6. Use for cross-cutting concerns:                       |
|    - Logging, timing, auth, CORS, compression            |
|                                                          |
| 7. Two ways to create:                                   |
|    - @app.middleware("http") decorator                   |
|    - BaseHTTPMiddleware class                            |
|                                                          |
+----------------------------------------------------------+
```

---

## What's Next?

In the next topic, we'll learn about **Lifespan Events** - code that runs 
when your app STARTS and STOPS. Perfect for setting up database 
connections, loading ML models, and cleanup tasks!

---

## Practice Exercise

Create middleware that:
1. Logs every request (method, path, time)
2. Measures request processing time
3. Adds the processing time as a response header
4. Blocks requests without an "X-API-Key" header (except for /docs)

See `_11_middleware_example.py` for the complete solution!
