# Topic 03: GET Requests - Fetching Data

## What is a GET Request?

A **GET request** is the most common way to ask for data from a server. 
It's like going to a library and asking: "Can I SEE this book?"

```
    YOU: "I want to see the menu"      WAITER: "Here's the menu!"
    
    +----------+                       +----------+
    |  Client  |  --- GET /menu --->   |  Server  |
    | (Browser)|                       | (FastAPI)|
    |          |  <-- Menu data ---    |          |
    +----------+                       +----------+
    
    You LOOK at data, you don't change anything.
```

**Key Point:** GET requests only FETCH data. They don't create, update, or delete 
anything. It's a "read-only" operation.


## HTTP Methods Overview

Before diving deeper into GET, let's see where it fits:

```
    HTTP METHODS - Like Different Actions at a Restaurant
    
    +--------+----------------+--------------------------------+
    | Method | Restaurant     | Web Example                    |
    +--------+----------------+--------------------------------+
    | GET    | Look at menu   | Get user profile               |
    | POST   | Place an order | Create a new account           |
    | PUT    | Change order   | Update your profile            |
    | DELETE | Cancel order   | Delete your account            |
    +--------+----------------+--------------------------------+
    
    This lesson focuses on GET - the most common method!
```


## Anatomy of a GET Request

When you type a URL in your browser, here's what's happening:

```
    URL: http://localhost:8000/users/42?include_email=true
    
    Let's break it down:
    
    http://localhost:8000/users/42?include_email=true
    |_____|  |________|  |__| |_____| |______________|
       |         |        |      |           |
    Protocol   Host     Port   Path    Query String
    
    
    Protocol: http or https (how to communicate)
    Host:     localhost (which computer)
    Port:     8000 (which door on that computer)
    Path:     /users/42 (what resource you want)
    Query:    ?include_email=true (extra options)
```


## Path Parameters vs Query Parameters

FastAPI gives you TWO ways to pass information in GET requests:

### Path Parameters (Part of the URL)
```
    /users/42          <- 42 is a path parameter
    /products/laptop   <- laptop is a path parameter
    /countries/usa     <- usa is a path parameter
    
    Use when: The parameter IDENTIFIES a specific resource
    Like: Room number in a hotel
```

### Query Parameters (After the ?)
```
    /users?page=1&limit=10     <- page=1 and limit=10 are query parameters
    /products?category=electronics&sort=price
    /search?q=python&lang=en
    
    Use when: The parameter FILTERS or MODIFIES the result
    Like: "I want a room with ocean view" (preference, not room number)
```

### Visual Comparison
```
    Path Parameter (WHAT you want)
    ==============================
    
    /books/123                    "Give me book #123"
           |
           +-> Identifies ONE specific book
    
    
    Query Parameter (HOW you want it)
    ==================================
    
    /books?author=tolkien&sort=date    "Give me Tolkien's books, sorted by date"
                |              |
                +-> Filter     +-> Modify
    
    
    Combined (Very Common!)
    =======================
    
    /users/42/posts?limit=5&sort=newest
           |    |         |         |
           |    |         |         +-> Query: how to sort
           |    |         +-> Query: how many
           |    +-> Path: which resource (posts)
           +-> Path: which user (42)
```


## How FastAPI Handles GET Requests

```
    REQUEST FLOW DIAGRAM
    ====================
    
    1. Browser sends GET request
    
    GET /products/laptop?color=silver HTTP/1.1
    Host: localhost:8000
           |
           v
    2. Uvicorn receives it
           |
           v
    3. FastAPI matches the route
       
       @app.get("/products/{product_id}")
       def get_product(product_id: str, color: str = None):
                            |                |
                            |                +-> Query parameter
                            +-> Path parameter
           |
           v
    4. FastAPI extracts parameters:
       
       product_id = "laptop"  (from path)
       color = "silver"       (from query)
           |
           v
    5. Your function runs with these values
           |
           v
    6. Response sent back to browser
    
       {"product": "laptop", "color": "silver"}
```


## Path Parameters in FastAPI

### Basic Path Parameter
```python
@app.get("/users/{user_id}")
def get_user(user_id):
    return {"user_id": user_id}

# /users/42 -> {"user_id": "42"}
# /users/alice -> {"user_id": "alice"}
```

### Path Parameter with Type Validation
```python
@app.get("/users/{user_id}")
def get_user(user_id: int):  # Must be an integer!
    return {"user_id": user_id}

# /users/42 -> {"user_id": 42}       (Works!)
# /users/alice -> Error! (alice is not a number)
```

### Multiple Path Parameters
```python
@app.get("/users/{user_id}/posts/{post_id}")
def get_user_post(user_id: int, post_id: int):
    return {
        "user_id": user_id,
        "post_id": post_id
    }

# /users/42/posts/7 -> {"user_id": 42, "post_id": 7}
```


## Query Parameters in FastAPI

### Basic Query Parameter
```python
@app.get("/items")
def get_items(skip: int = 0, limit: int = 10):
    return {"skip": skip, "limit": limit}

# /items -> {"skip": 0, "limit": 10}
# /items?skip=5 -> {"skip": 5, "limit": 10}
# /items?skip=5&limit=20 -> {"skip": 5, "limit": 20}
```

### Required vs Optional Query Parameters
```python
@app.get("/search")
def search(
    q: str,              # REQUIRED - no default value
    page: int = 1,       # OPTIONAL - has default value
    limit: int = 10      # OPTIONAL - has default value
):
    return {"query": q, "page": page, "limit": limit}

# /search?q=python -> Works! (page=1, limit=10 by default)
# /search -> Error! (q is required)
# /search?q=python&page=2 -> {"query": "python", "page": 2, "limit": 10}
```

### Optional with None
```python
from typing import Optional

@app.get("/items")
def get_items(
    category: Optional[str] = None,  # Optional, defaults to None
    in_stock: Optional[bool] = None
):
    filters = {}
    if category:
        filters["category"] = category
    if in_stock is not None:
        filters["in_stock"] = in_stock
    return {"filters": filters}

# /items -> {"filters": {}}
# /items?category=books -> {"filters": {"category": "books"}}
# /items?in_stock=true -> {"filters": {"in_stock": true}}
```


## Combining Path and Query Parameters

This is VERY common in real APIs:

```python
@app.get("/users/{user_id}/posts")
def get_user_posts(
    user_id: int,           # Path parameter
    page: int = 1,          # Query parameter
    limit: int = 10,        # Query parameter
    sort: str = "newest"    # Query parameter
):
    return {
        "user_id": user_id,
        "page": page,
        "limit": limit,
        "sort": sort
    }

# /users/42/posts
#   -> {"user_id": 42, "page": 1, "limit": 10, "sort": "newest"}

# /users/42/posts?page=2&limit=5
#   -> {"user_id": 42, "page": 2, "limit": 5, "sort": "newest"}

# /users/42/posts?sort=oldest&limit=20
#   -> {"user_id": 42, "page": 1, "limit": 20, "sort": "oldest"}
```


## Real-World Example: Building a Product API

Let's build something that looks like a real API:

```
    PRODUCT API DESIGN
    ==================
    
    +----------------------------+----------------------------------+
    | Endpoint                   | Description                      |
    +----------------------------+----------------------------------+
    | GET /products              | List all products                |
    | GET /products/{id}         | Get one product                  |
    | GET /products/search       | Search products                  |
    | GET /categories            | List categories                  |
    | GET /categories/{name}     | Get products in category         |
    +----------------------------+----------------------------------+
    
    Query Parameters:
    - page: Which page of results
    - limit: How many per page
    - sort: How to sort (price, name, newest)
    - min_price / max_price: Price filters
```


## Request/Response Flow Diagram

```
    COMPLETE GET REQUEST LIFECYCLE
    ==============================
    
    Step 1: User types URL or clicks link
    +------------------------------------------+
    | Browser: http://localhost:8000/users/42  |
    +------------------------------------------+
                        |
                        v
    Step 2: Browser creates HTTP Request
    +------------------------------------------+
    | GET /users/42 HTTP/1.1                   |
    | Host: localhost:8000                     |
    | Accept: application/json                 |
    | User-Agent: Chrome/...                   |
    +------------------------------------------+
                        |
                        v
    Step 3: Request travels over network to port 8000
    
    ~~~~ Internet / Network ~~~~
                        |
                        v
    Step 4: Uvicorn receives request
    +------------------------------------------+
    | Uvicorn: "New request on port 8000!"     |
    | Passing to FastAPI...                    |
    +------------------------------------------+
                        |
                        v
    Step 5: FastAPI routes to correct function
    +------------------------------------------+
    | FastAPI: Looking for GET /users/{user_id}|
    | Found: get_user() function               |
    | Extracting: user_id = 42                 |
    +------------------------------------------+
                        |
                        v
    Step 6: Your function executes
    +------------------------------------------+
    | def get_user(user_id: int):              |
    |     # user_id is 42                      |
    |     return {"id": 42, "name": "Alice"}   |
    +------------------------------------------+
                        |
                        v
    Step 7: FastAPI creates HTTP Response
    +------------------------------------------+
    | HTTP/1.1 200 OK                          |
    | Content-Type: application/json           |
    |                                          |
    | {"id": 42, "name": "Alice"}              |
    +------------------------------------------+
                        |
                        v
    Step 8: Response travels back
    
    ~~~~ Internet / Network ~~~~
                        |
                        v
    Step 9: Browser displays result
    +------------------------------------------+
    | {"id": 42, "name": "Alice"}              |
    +------------------------------------------+
```


## HTTP Status Codes for GET Requests

```
    Common Status Codes You'll See
    ==============================
    
    200 OK          - Success! Here's your data.
    
    404 Not Found   - That resource doesn't exist.
                      Example: GET /users/99999 (no such user)
    
    400 Bad Request - Your request is malformed.
                      Example: GET /users/abc (expected number)
    
    401 Unauthorized - You need to log in first.
    
    500 Server Error - Something broke on our end.
    
    
    Visual:
    +-------+------------------+------------------------+
    | Code  | Meaning          | When it happens        |
    +-------+------------------+------------------------+
    | 2XX   | Success!         | Everything worked      |
    | 4XX   | Client Error     | YOU did something wrong|
    | 5XX   | Server Error     | SERVER has a problem   |
    +-------+------------------+------------------------+
```


## Testing GET Requests

### Method 1: Browser
Just type the URL in your browser!
```
http://localhost:8000/users/42
```

### Method 2: curl (Command Line)
```bash
curl http://localhost:8000/users/42
curl "http://localhost:8000/items?page=2&limit=5"
```

### Method 3: FastAPI Docs (Best for learning!)
1. Go to `http://localhost:8000/docs`
2. Click on any endpoint
3. Click "Try it out"
4. Fill in parameters
5. Click "Execute"


## Try It Yourself!

1. **Create a simple GET endpoint:**
   ```python
   @app.get("/hello/{name}")
   def say_hello(name: str):
       return {"message": f"Hello, {name}!"}
   ```

2. **Add query parameters:**
   ```python
   @app.get("/greet/{name}")
   def greet(name: str, formal: bool = False):
       if formal:
           return {"greeting": f"Good day, {name}."}
       return {"greeting": f"Hey {name}!"}
   ```

3. **Build a mini search:**
   ```python
   @app.get("/search")
   def search(q: str, limit: int = 10):
       # In real life, you'd search a database
       return {"searching_for": q, "max_results": limit}
   ```


## Common Mistakes to Avoid

```
    MISTAKE 1: Forgetting the type hint
    -----------------------------------
    
    # Bad - user_id is a string "42", not number 42
    @app.get("/users/{user_id}")
    def get_user(user_id):  
        return user_id + 1  # Error! Can't add 1 to string
    
    # Good - user_id is validated as integer
    @app.get("/users/{user_id}")
    def get_user(user_id: int):
        return user_id + 1  # Works! 43
    
    
    MISTAKE 2: Order of path parameters matters
    -------------------------------------------
    
    # This causes problems!
    @app.get("/users/{user_id}")  # Matches /users/me too!
    def get_user(user_id: int):
        ...
    
    @app.get("/users/me")  # Never reached because {user_id} catches "me"
    def get_current_user():
        ...
    
    # Solution: Put specific routes FIRST
    @app.get("/users/me")  # Check this first
    def get_current_user():
        ...
    
    @app.get("/users/{user_id}")  # Then check this
    def get_user(user_id: int):
        ...
```


## Summary

```
    GET REQUESTS CHEAT SHEET
    ========================
    
    Path Parameters (in the URL path):
    @app.get("/users/{user_id}")
    def get_user(user_id: int):
        ...
    
    Query Parameters (after the ?):
    @app.get("/items")
    def get_items(page: int = 1, limit: int = 10):
        ...
    
    Both Together:
    @app.get("/users/{user_id}/posts")
    def get_posts(user_id: int, page: int = 1):
        ...
    
    
    When to Use What:
    +-------------------+----------------------+
    | Path Parameters   | Identify a resource  |
    | Query Parameters  | Filter/modify result |
    +-------------------+----------------------+
    
    Example:
    /users/42/posts?limit=5&sort=date
           |          |        |
           |          |        +-> Query: how to sort
           |          +-> Query: how many
           +-> Path: which user
```

Next up: Learn about POST requests - creating new data!
