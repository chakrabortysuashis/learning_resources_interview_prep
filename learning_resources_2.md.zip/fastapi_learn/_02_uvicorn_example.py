"""
=============================================================================
TOPIC 02: Uvicorn Configuration Examples
=============================================================================

This file demonstrates different ways to configure and run Uvicorn.

There are TWO ways to run this file:

    METHOD 1: Command Line (recommended for learning)
    -------------------------------------------------
    uvicorn _02_uvicorn_example:app --reload

    METHOD 2: Python Script
    -----------------------
    python _02_uvicorn_example.py

=============================================================================
"""

from fastapi import FastAPI
import uvicorn

# =============================================================================
# Create our FastAPI application
# =============================================================================
app = FastAPI(
    title="Uvicorn Learning App",
    description="Demonstrating different Uvicorn configurations",
    version="1.0.0"
)


# =============================================================================
# Basic Routes for Testing
# =============================================================================

@app.get("/")
def home():
    """
    Home page - confirms the server is running
    """
    return {
        "message": "Uvicorn is running!",
        "tip": "Try visiting /info or /docs"
    }


@app.get("/info")
def server_info():
    """
    Returns information about how to run Uvicorn with different options
    """
    return {
        "common_commands": {
            "basic": "uvicorn _02_uvicorn_example:app",
            "with_reload": "uvicorn _02_uvicorn_example:app --reload",
            "custom_port": "uvicorn _02_uvicorn_example:app --port 3000",
            "network_access": "uvicorn _02_uvicorn_example:app --host 0.0.0.0",
            "production": "uvicorn _02_uvicorn_example:app --host 0.0.0.0 --workers 4"
        },
        "current_server": "This response came from Uvicorn!"
    }


@app.get("/health")
def health_check():
    """
    Health check endpoint - common in production apps
    """
    return {"status": "healthy", "server": "uvicorn"}


@app.get("/slow")
async def slow_endpoint():
    """
    A slow endpoint to demonstrate async behavior.

    Try opening two browser tabs to this URL at the same time.
    With async, both requests can be handled together!
    """
    import asyncio
    await asyncio.sleep(3)  # Wait 3 seconds
    return {"message": "This took 3 seconds!", "tip": "But other requests weren't blocked"}


# =============================================================================
# CONFIGURATION EXAMPLES (for running from Python)
# =============================================================================

# Configuration 1: Basic Development
# -----------------------------------
# This is what you use most of the time when learning
DEVELOPMENT_CONFIG = {
    "app": "_02_uvicorn_example:app",
    "host": "127.0.0.1",
    "port": 8000,
    "reload": True,
    "log_level": "info"
}

# Configuration 2: Debug Mode
# ---------------------------
# Use this when you need to see more detailed logs
DEBUG_CONFIG = {
    "app": "_02_uvicorn_example:app",
    "host": "127.0.0.1",
    "port": 8000,
    "reload": True,
    "log_level": "debug"  # More verbose logging
}

# Configuration 3: Network Access
# -------------------------------
# Use this when you want to access from other devices (like your phone)
NETWORK_CONFIG = {
    "app": "_02_uvicorn_example:app",
    "host": "0.0.0.0",  # Allow connections from any IP
    "port": 8000,
    "reload": True,
    "log_level": "info"
}

# Configuration 4: Production (Simple)
# ------------------------------------
# Use this for deploying your app
PRODUCTION_CONFIG = {
    "app": "_02_uvicorn_example:app",
    "host": "0.0.0.0",
    "port": 8000,
    "reload": False,     # Never use reload in production!
    "workers": 4,        # Multiple workers for handling more requests
    "log_level": "warning"  # Less verbose in production
}

# Configuration 5: Custom Port
# ----------------------------
# When port 8000 is already taken
CUSTOM_PORT_CONFIG = {
    "app": "_02_uvicorn_example:app",
    "host": "127.0.0.1",
    "port": 3000,  # Different port
    "reload": True,
    "log_level": "info"
}


# =============================================================================
# Main entry point - runs when you execute: python _02_uvicorn_example.py
# =============================================================================

if __name__ == "__main__":
    """
    This block only runs when you execute this file directly:
        python _02_uvicorn_example.py

    It does NOT run when you use:
        uvicorn _02_uvicorn_example:app --reload
    """

    print("""
    =============================================================
    UVICORN CONFIGURATION DEMO
    =============================================================

    Choose a configuration to run:

    1. Development (default) - Basic setup with reload
    2. Debug - More verbose logging
    3. Network - Accessible from other devices
    4. Custom Port - Run on port 3000

    Press Enter for default (Development), or enter 1-4:
    """)

    choice = input("Your choice: ").strip() or "1"

    configs = {
        "1": ("Development", DEVELOPMENT_CONFIG),
        "2": ("Debug", DEBUG_CONFIG),
        "3": ("Network", NETWORK_CONFIG),
        "4": ("Custom Port", CUSTOM_PORT_CONFIG)
    }

    config_name, config = configs.get(choice, ("Development", DEVELOPMENT_CONFIG))

    print(f"""
    =============================================================
    Starting Uvicorn with {config_name} Configuration
    =============================================================

    Configuration:
    - Host: {config['host']}
    - Port: {config['port']}
    - Reload: {config['reload']}
    - Log Level: {config['log_level']}

    Open your browser to: http://{config['host']}:{config['port']}
    Press Ctrl+C to stop the server

    =============================================================
    """)

    # Start Uvicorn with the selected configuration
    uvicorn.run(**config)


# =============================================================================
# ALTERNATIVE: Simple one-liner for main.py
# =============================================================================
"""
If you just want a simple main.py that runs Uvicorn, use this pattern:

    from fastapi import FastAPI
    import uvicorn

    app = FastAPI()

    @app.get("/")
    def home():
        return {"message": "Hello!"}

    if __name__ == "__main__":
        uvicorn.run("main:app", reload=True)

Then just run: python main.py
"""


# =============================================================================
# COMMAND LINE EQUIVALENTS
# =============================================================================
"""
Here are the command line equivalents for each configuration:

1. Development:
   uvicorn _02_uvicorn_example:app --reload

2. Debug:
   uvicorn _02_uvicorn_example:app --reload --log-level debug

3. Network:
   uvicorn _02_uvicorn_example:app --reload --host 0.0.0.0

4. Custom Port:
   uvicorn _02_uvicorn_example:app --reload --port 3000

5. Production (with workers):
   uvicorn _02_uvicorn_example:app --host 0.0.0.0 --workers 4


ASCII DIAGRAM: Uvicorn Configuration Flow
==========================================

    +------------------+
    |  Your Terminal   |
    +--------+---------+
             |
             v
    +------------------+
    |  uvicorn command |
    |  OR              |
    |  python main.py  |
    +--------+---------+
             |
             v
    +------------------+     +---------------------------+
    |  Read Config     | --> | host, port, reload, etc.  |
    +--------+---------+     +---------------------------+
             |
             v
    +------------------+
    |  Start Server    |
    +--------+---------+
             |
             v
    +------------------+
    |  Listen on Port  |  <-- Your app is now running!
    +--------+---------+
             |
             v
    +------------------+
    |  Handle Requests |
    |  Until Ctrl+C    |
    +------------------+
"""
