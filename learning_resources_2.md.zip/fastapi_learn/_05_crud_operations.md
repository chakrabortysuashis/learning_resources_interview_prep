# Topic 05: CRUD Operations in FastAPI

## What is CRUD?

CRUD is an acronym for the four basic operations you can do with data:

```
+-----------------------------------------------------------+
|                      C R U D                               |
+-----------------------------------------------------------+
|                                                           |
|    C = CREATE    ->  Make something new                   |
|    R = READ      ->  Look at something                    |
|    U = UPDATE    ->  Change something                     |
|    D = DELETE    ->  Remove something                     |
|                                                           |
+-----------------------------------------------------------+
```

Almost EVERY app you use does CRUD operations:
- Instagram: Create posts, Read feed, Update bio, Delete photos
- Netflix: Create profile, Read movies, Update preferences, Delete account
- School system: Create students, Read grades, Update info, Delete records

---

## The Library Analogy

Imagine you're a librarian managing books:

```
+------------------------------------------------------------------+
|                     LIBRARY CRUD OPERATIONS                       |
+------------------------------------------------------------------+
|                                                                  |
|  CREATE = "I want to add a new book to the library"              |
|           +------+                                               |
|           | Book | --> [Library Shelf]                           |
|           +------+                                               |
|                                                                  |
|  READ   = "I want to see what books we have"                     |
|           [Library Shelf] --> "Here's the catalog!"              |
|                                                                  |
|  UPDATE = "I need to fix the author's name on this book"         |
|           [Book] --> [Modified Book]                             |
|                                                                  |
|  DELETE = "This book is damaged, remove it"                      |
|           [Library Shelf] - [Book] = [Updated Shelf]             |
|                                                                  |
+------------------------------------------------------------------+
```

---

## HTTP Methods for CRUD

Each CRUD operation maps to an HTTP method:

```
+----------+----------+------------------+------------------------+
| CRUD     | HTTP     | What it does     | Example URL            |
+----------+----------+------------------+------------------------+
| CREATE   | POST     | Add new data     | POST /books            |
| READ     | GET      | Retrieve data    | GET /books or GET /books/1 |
| UPDATE   | PUT      | Replace all data | PUT /books/1           |
| UPDATE   | PATCH    | Change some data | PATCH /books/1         |
| DELETE   | DELETE   | Remove data      | DELETE /books/1        |
+----------+----------+------------------+------------------------+
```

### Visual Flow:

```
Client                                          Server (Database)
  |                                                    |
  |  POST /books {"title": "New Book"}                 |
  |  =============================================>    |
  |                     CREATE                         | [+Book]
  |  <=============================================    |
  |  201 Created {"id": 1, "title": "New Book"}        |
  |                                                    |
  |  GET /books                                        |
  |  =============================================>    |
  |                      READ                          | [See All]
  |  <=============================================    |
  |  200 OK [{"id": 1, "title": "New Book"}]           |
  |                                                    |
  |  PUT /books/1 {"title": "Updated Book"}            |
  |  =============================================>    |
  |                     UPDATE                         | [Modify]
  |  <=============================================    |
  |  200 OK {"id": 1, "title": "Updated Book"}         |
  |                                                    |
  |  DELETE /books/1                                   |
  |  =============================================>    |
  |                     DELETE                         | [-Book]
  |  <=============================================    |
  |  200 OK {"message": "Deleted"}                     |
```

---

## PUT vs PATCH: What's the Difference?

This confuses many beginners! Here's the simple explanation:

### PUT = Replace EVERYTHING

```
Original Book:
+--------------------------------+
| id: 1                          |
| title: "Harry Potter"          |
| author: "J.K. Rowling"         |
| year: 1997                     |
| pages: 309                     |
+--------------------------------+

PUT /books/1 with {"title": "New Title", "author": "New Author"}

Result (REPLACES entire object):
+--------------------------------+
| id: 1                          |
| title: "New Title"             |
| author: "New Author"           |
| year: null   <-- LOST!         |
| pages: null  <-- LOST!         |
+--------------------------------+

PUT is like giving someone a completely new form to fill out.
Everything you don't include gets erased!
```

### PATCH = Update ONLY What You Send

```
Original Book:
+--------------------------------+
| id: 1                          |
| title: "Harry Potter"          |
| author: "J.K. Rowling"         |
| year: 1997                     |
| pages: 309                     |
+--------------------------------+

PATCH /books/1 with {"title": "Harry Potter and the Sorcerer's Stone"}

Result (UPDATES only specified fields):
+--------------------------------+
| id: 1                          |
| title: "Harry Potter and..."   | <-- Changed!
| author: "J.K. Rowling"         | <-- Kept!
| year: 1997                     | <-- Kept!
| pages: 309                     | <-- Kept!
+--------------------------------+

PATCH is like using white-out on specific words.
Everything else stays the same!
```

### Quick Rule:

```
+------------------------------------------------------------+
|  PUT   = "Here's the complete new version"                 |
|  PATCH = "Just change these specific things"               |
+------------------------------------------------------------+
```

---

## Complete HTTP Methods Comparison

```
+--------+------------+----------------+------------+------------------+
| Method | CRUD       | Request Body   | Idempotent | Description      |
+--------+------------+----------------+------------+------------------+
| GET    | Read       | No             | Yes        | Get data         |
| POST   | Create     | Yes            | No         | Create new data  |
| PUT    | Update     | Yes            | Yes        | Replace all data |
| PATCH  | Update     | Yes            | No*        | Update some data |
| DELETE | Delete     | Usually No     | Yes        | Remove data      |
+--------+------------+----------------+------------+------------------+

* Idempotent = Running it multiple times gives same result
  - GET /books/1 ten times -> Same book returned each time (Idempotent)
  - POST /books ten times -> 10 NEW books created! (NOT Idempotent)
  - DELETE /books/1 ten times -> Book deleted first time, then "not found"
```

---

## Status Codes for CRUD Operations

```
+-------------------+-------+----------------------------------------+
| Operation         | Code  | Meaning                                |
+-------------------+-------+----------------------------------------+
| CREATE Success    | 201   | Created - New resource was made        |
| READ Success      | 200   | OK - Here's your data                  |
| UPDATE Success    | 200   | OK - Resource was updated              |
| DELETE Success    | 200   | OK - Resource was deleted              |
| DELETE Success    | 204   | No Content - Deleted (no response body)|
| Not Found         | 404   | The resource doesn't exist             |
| Validation Error  | 422   | Data format is wrong                   |
+-------------------+-------+----------------------------------------+
```

---

## CRUD Endpoints Pattern

Here's the standard pattern you'll see in most REST APIs:

```
+------------------------------------------------------------------+
|  Resource: /books                                                 |
+------------------------------------------------------------------+
|                                                                  |
|  GET    /books          -> List all books (READ many)            |
|  GET    /books/{id}     -> Get one book (READ one)               |
|  POST   /books          -> Create a book (CREATE)                |
|  PUT    /books/{id}     -> Replace a book (UPDATE - full)        |
|  PATCH  /books/{id}     -> Update a book (UPDATE - partial)      |
|  DELETE /books/{id}     -> Delete a book (DELETE)                |
|                                                                  |
+------------------------------------------------------------------+

The {id} is called a PATH PARAMETER - it identifies WHICH book
```

---

## Real-World Example: Todo App

```
Todo List Application CRUD:

CREATE - Add a new todo
+-------------------------------------------+
| POST /todos                               |
| Body: {"task": "Do homework", "done": false} |
| Response: {"id": 1, "task": "Do homework", "done": false} |
+-------------------------------------------+

READ - See all todos
+-------------------------------------------+
| GET /todos                                |
| Response: [                               |
|   {"id": 1, "task": "Do homework", "done": false},
|   {"id": 2, "task": "Clean room", "done": true}
| ]                                         |
+-------------------------------------------+

READ - See one todo
+-------------------------------------------+
| GET /todos/1                              |
| Response: {"id": 1, "task": "Do homework", "done": false} |
+-------------------------------------------+

UPDATE - Mark todo as complete
+-------------------------------------------+
| PATCH /todos/1                            |
| Body: {"done": true}                      |
| Response: {"id": 1, "task": "Do homework", "done": true} |
+-------------------------------------------+

DELETE - Remove a todo
+-------------------------------------------+
| DELETE /todos/1                           |
| Response: {"message": "Todo deleted"}     |
+-------------------------------------------+
```

---

## Common Mistakes to Avoid

```
+------------------------------------------------------------------+
|                    CRUD COMMON MISTAKES                           |
+------------------------------------------------------------------+
|                                                                  |
| X  Using GET to delete things                                    |
|    GET /books/1/delete   <- BAD! GET shouldn't change data       |
|                                                                  |
| X  Using POST for everything                                     |
|    POST /books/update/1  <- BAD! Use PUT or PATCH instead        |
|                                                                  |
| X  Forgetting to handle "not found"                              |
|    Always check if the resource exists before UPDATE/DELETE      |
|                                                                  |
| X  Not returning the updated resource                            |
|    After PUT/PATCH, return the new state so client knows it worked |
|                                                                  |
| X  Using PUT when you mean PATCH                                 |
|    PUT replaces EVERYTHING - use PATCH for partial updates       |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Summary Diagram

```
+------------------------------------------------------------------+
|                    CRUD OPERATIONS SUMMARY                        |
+------------------------------------------------------------------+
|                                                                  |
|   +----------+    +----------+    +----------+    +----------+   |
|   |          |    |          |    |          |    |          |   |
|   |  CREATE  |    |   READ   |    |  UPDATE  |    |  DELETE  |   |
|   |          |    |          |    |          |    |          |   |
|   +----+-----+    +----+-----+    +----+-----+    +----+-----+   |
|        |              |              |    |              |       |
|        v              v              v    v              v       |
|   +----------+    +----------+    +----+ +----+    +----------+  |
|   |   POST   |    |   GET    |    |PUT | |PATCH|   |  DELETE  |  |
|   +----------+    +----------+    +----+ +----+    +----------+  |
|        |              |              |    |              |       |
|        v              v              v    v              v       |
|   +----------+    +----------+    +----------+    +----------+   |
|   | 201      |    | 200      |    | 200      |    | 200/204  |   |
|   | Created  |    | OK       |    | OK       |    | OK/None  |   |
|   +----------+    +----------+    +----------+    +----------+   |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Try It Yourself!

1. Run `_05_crud_example.py` 
2. Open `http://localhost:8000/docs`
3. Try this sequence:
   - POST a new item (Create)
   - GET all items (Read all)
   - GET one item by ID (Read one)
   - PUT to replace an item (Update full)
   - PATCH to change one field (Update partial)
   - DELETE an item (Delete)
   - GET all items again to see the changes

```
Challenge Questions:
  1. What happens if you try to DELETE an item that doesn't exist?
  2. What's the difference when you PUT vs PATCH the same item?
  3. Can you add a "search" endpoint that filters items by name?
```

---

Next up: Topic 06 - Path and Query Parameters!
