"""
=============================================================================
TOPIC 03: GET Request Examples
=============================================================================

This file contains multiple GET endpoint examples with detailed explanations.
Each example builds on the previous one to teach you different concepts.

HOW TO RUN:
    uvicorn _03_get_examples:app --reload

THEN TEST AT:
    http://localhost:8000/docs  (Interactive documentation)
    http://localhost:8000       (Home page)

=============================================================================
"""

from fastapi import FastAPI, HTTPException
from typing import Optional, List
from enum import Enum

# =============================================================================
# Create the FastAPI application
# =============================================================================
app = FastAPI(
    title="GET Requests Tutorial",
    description="Learn all about GET requests with these examples!",
    version="1.0.0"
)


# =============================================================================
# SAMPLE DATA (In real apps, this would come from a database)
# =============================================================================
# This is fake data to make our examples work. In a real application,
# you would fetch this from a database like PostgreSQL, MongoDB, etc.

USERS = {
    1: {"id": 1, "name": "Alice", "email": "alice@example.com", "age": 28},
    2: {"id": 2, "name": "Bob", "email": "bob@example.com", "age": 34},
    3: {"id": 3, "name": "Charlie", "email": "charlie@example.com", "age": 22},
    4: {"id": 4, "name": "Diana", "email": "diana@example.com", "age": 31},
    5: {"id": 5, "name": "Eve", "email": "eve@example.com", "age": 26},
}

PRODUCTS = [
    {"id": 1, "name": "Laptop", "price": 999.99, "category": "electronics", "in_stock": True},
    {"id": 2, "name": "Headphones", "price": 149.99, "category": "electronics", "in_stock": True},
    {"id": 3, "name": "Coffee Mug", "price": 12.99, "category": "kitchen", "in_stock": False},
    {"id": 4, "name": "Notebook", "price": 5.99, "category": "office", "in_stock": True},
    {"id": 5, "name": "Desk Lamp", "price": 34.99, "category": "office", "in_stock": True},
    {"id": 6, "name": "Water Bottle", "price": 24.99, "category": "kitchen", "in_stock": True},
    {"id": 7, "name": "Keyboard", "price": 79.99, "category": "electronics", "in_stock": False},
    {"id": 8, "name": "Mouse", "price": 29.99, "category": "electronics", "in_stock": True},
]

POSTS = [
    {"id": 1, "user_id": 1, "title": "My First Post", "likes": 42},
    {"id": 2, "user_id": 1, "title": "Learning FastAPI", "likes": 128},
    {"id": 3, "user_id": 2, "title": "Hello World", "likes": 15},
    {"id": 4, "user_id": 3, "title": "Python Tips", "likes": 256},
    {"id": 5, "user_id": 1, "title": "API Design", "likes": 89},
]


# =============================================================================
# EXAMPLE 1: Simple GET - No Parameters
# =============================================================================
# The simplest possible GET endpoint. Returns the same thing every time.

@app.get("/")
def home():
    """
    Home page - Welcome message

    Try it: http://localhost:8000/
    """
    return {
        "message": "Welcome to the GET Requests Tutorial!",
        "tip": "Visit /docs for interactive documentation"
    }


@app.get("/about")
def about():
    """
    About page - Information about this API

    Try it: http://localhost:8000/about
    """
    return {
        "name": "GET Requests Tutorial API",
        "version": "1.0.0",
        "author": "FastAPI Learner",
        "purpose": "Teaching GET request concepts"
    }


# =============================================================================
# EXAMPLE 2: Path Parameters (Basic)
# =============================================================================
# Path parameters are parts of the URL that can change.
# They're defined using {parameter_name} in the route.

@app.get("/hello/{name}")
def hello_name(name: str):
    """
    Say hello to someone!

    The {name} in the URL becomes a variable.

    Try it:
        http://localhost:8000/hello/Alice
        http://localhost:8000/hello/World
        http://localhost:8000/hello/FastAPI

    Args:
        name: The name to greet (from the URL path)
    """
    return {"message": f"Hello, {name}!"}


@app.get("/users/{user_id}")
def get_user(user_id: int):
    """
    Get a specific user by ID

    The user_id must be an integer. FastAPI validates this automatically!

    Try it:
        http://localhost:8000/users/1      (Works!)
        http://localhost:8000/users/2      (Works!)
        http://localhost:8000/users/abc    (Error - not a number!)

    Args:
        user_id: The user's ID number
    """
    if user_id not in USERS:
        # Return 404 error if user doesn't exist
        raise HTTPException(status_code=404, detail=f"User {user_id} not found")

    return USERS[user_id]


# =============================================================================
# EXAMPLE 3: Multiple Path Parameters
# =============================================================================
# You can have multiple path parameters in one route

@app.get("/users/{user_id}/posts/{post_id}")
def get_user_post(user_id: int, post_id: int):
    """
    Get a specific post from a specific user

    This uses TWO path parameters: user_id and post_id

    Try it:
        http://localhost:8000/users/1/posts/1
        http://localhost:8000/users/1/posts/2

    Args:
        user_id: The user's ID
        post_id: The post's ID
    """
    # Find the post
    for post in POSTS:
        if post["id"] == post_id and post["user_id"] == user_id:
            return post

    raise HTTPException(
        status_code=404,
        detail=f"Post {post_id} not found for user {user_id}"
    )


# =============================================================================
# EXAMPLE 4: Query Parameters (Basic)
# =============================================================================
# Query parameters come after ? in the URL
# Example: /items?skip=0&limit=10

@app.get("/products")
def get_products(skip: int = 0, limit: int = 10):
    """
    Get a list of products with pagination

    Query parameters are used for filtering and pagination.

    Try it:
        http://localhost:8000/products              (default: skip=0, limit=10)
        http://localhost:8000/products?limit=3      (only 3 products)
        http://localhost:8000/products?skip=2       (skip first 2)
        http://localhost:8000/products?skip=2&limit=3   (skip 2, show 3)

    Args:
        skip: Number of items to skip (for pagination)
        limit: Maximum number of items to return
    """
    # Apply skip and limit to our products list
    return {
        "skip": skip,
        "limit": limit,
        "total": len(PRODUCTS),
        "products": PRODUCTS[skip:skip + limit]
    }


# =============================================================================
# EXAMPLE 5: Required Query Parameters
# =============================================================================
# If a query parameter has NO default value, it's REQUIRED

@app.get("/search")
def search(q: str, limit: int = 10):
    """
    Search for products by name

    The 'q' parameter is REQUIRED (no default value).
    The 'limit' parameter is OPTIONAL (has default value).

    Try it:
        http://localhost:8000/search?q=laptop           (Works!)
        http://localhost:8000/search?q=desk&limit=5     (Works!)
        http://localhost:8000/search                    (Error - q is required!)

    Args:
        q: Search query (REQUIRED)
        limit: Maximum results to return (default: 10)
    """
    # Search products by name (case-insensitive)
    results = [
        p for p in PRODUCTS
        if q.lower() in p["name"].lower()
    ]

    return {
        "query": q,
        "limit": limit,
        "found": len(results),
        "results": results[:limit]
    }


# =============================================================================
# EXAMPLE 6: Optional Query Parameters
# =============================================================================
# Use Optional[type] for parameters that can be None

@app.get("/products/filter")
def filter_products(
    category: Optional[str] = None,
    min_price: Optional[float] = None,
    max_price: Optional[float] = None,
    in_stock: Optional[bool] = None
):
    """
    Filter products with multiple optional criteria

    All parameters are optional - you can use any combination!

    Try it:
        http://localhost:8000/products/filter
        http://localhost:8000/products/filter?category=electronics
        http://localhost:8000/products/filter?in_stock=true
        http://localhost:8000/products/filter?min_price=10&max_price=50
        http://localhost:8000/products/filter?category=electronics&in_stock=true

    Args:
        category: Filter by category name
        min_price: Minimum price
        max_price: Maximum price
        in_stock: Only show items in stock (true/false)
    """
    # Start with all products
    results = PRODUCTS.copy()

    # Apply filters if provided
    if category is not None:
        results = [p for p in results if p["category"] == category]

    if min_price is not None:
        results = [p for p in results if p["price"] >= min_price]

    if max_price is not None:
        results = [p for p in results if p["price"] <= max_price]

    if in_stock is not None:
        results = [p for p in results if p["in_stock"] == in_stock]

    return {
        "filters_applied": {
            "category": category,
            "min_price": min_price,
            "max_price": max_price,
            "in_stock": in_stock
        },
        "count": len(results),
        "products": results
    }


# =============================================================================
# EXAMPLE 7: Enum for Limited Choices
# =============================================================================
# Use Enum when a parameter should only accept specific values

class SortOrder(str, Enum):
    """Allowed sort options"""
    price_asc = "price_asc"
    price_desc = "price_desc"
    name = "name"
    newest = "newest"


@app.get("/products/sorted")
def get_sorted_products(sort: SortOrder = SortOrder.name):
    """
    Get products sorted in a specific way

    The 'sort' parameter can ONLY be one of the allowed values.
    FastAPI will reject any other value automatically!

    Try it:
        http://localhost:8000/products/sorted?sort=price_asc
        http://localhost:8000/products/sorted?sort=price_desc
        http://localhost:8000/products/sorted?sort=name
        http://localhost:8000/products/sorted?sort=invalid   (Error!)

    Args:
        sort: How to sort - must be one of: price_asc, price_desc, name, newest
    """
    products = PRODUCTS.copy()

    if sort == SortOrder.price_asc:
        products.sort(key=lambda x: x["price"])
    elif sort == SortOrder.price_desc:
        products.sort(key=lambda x: x["price"], reverse=True)
    elif sort == SortOrder.name:
        products.sort(key=lambda x: x["name"])
    # newest would sort by date if we had dates

    return {"sorted_by": sort.value, "products": products}


# =============================================================================
# EXAMPLE 8: Combining Path and Query Parameters
# =============================================================================
# This is VERY common in real APIs!

@app.get("/users/{user_id}/posts")
def get_user_posts(
    user_id: int,
    skip: int = 0,
    limit: int = 10,
    min_likes: Optional[int] = None
):
    """
    Get posts from a specific user

    Combines:
    - Path parameter (user_id) - identifies WHICH user
    - Query parameters (skip, limit, min_likes) - filters/pagination

    Try it:
        http://localhost:8000/users/1/posts
        http://localhost:8000/users/1/posts?limit=2
        http://localhost:8000/users/1/posts?min_likes=50

    Args:
        user_id: The user's ID (from path)
        skip: Number of posts to skip
        limit: Maximum posts to return
        min_likes: Only show posts with at least this many likes
    """
    # Check if user exists
    if user_id not in USERS:
        raise HTTPException(status_code=404, detail=f"User {user_id} not found")

    # Get user's posts
    user_posts = [p for p in POSTS if p["user_id"] == user_id]

    # Apply min_likes filter if provided
    if min_likes is not None:
        user_posts = [p for p in user_posts if p["likes"] >= min_likes]

    # Apply pagination
    user_posts = user_posts[skip:skip + limit]

    return {
        "user_id": user_id,
        "user_name": USERS[user_id]["name"],
        "skip": skip,
        "limit": limit,
        "min_likes": min_likes,
        "post_count": len(user_posts),
        "posts": user_posts
    }


# =============================================================================
# EXAMPLE 9: Getting Statistics / Summaries
# =============================================================================
# GET endpoints are great for retrieving aggregated data

@app.get("/stats")
def get_statistics():
    """
    Get overall statistics about our data

    This shows how GET endpoints can return computed/aggregated data,
    not just raw database records.

    Try it: http://localhost:8000/stats
    """
    total_products = len(PRODUCTS)
    in_stock_count = sum(1 for p in PRODUCTS if p["in_stock"])
    total_value = sum(p["price"] for p in PRODUCTS)
    avg_price = total_value / total_products if total_products > 0 else 0

    categories = {}
    for p in PRODUCTS:
        cat = p["category"]
        categories[cat] = categories.get(cat, 0) + 1

    return {
        "products": {
            "total": total_products,
            "in_stock": in_stock_count,
            "out_of_stock": total_products - in_stock_count,
            "total_value": round(total_value, 2),
            "average_price": round(avg_price, 2)
        },
        "categories": categories,
        "users": {
            "total": len(USERS)
        },
        "posts": {
            "total": len(POSTS),
            "total_likes": sum(p["likes"] for p in POSTS)
        }
    }


# =============================================================================
# EXAMPLE 10: Returning Lists
# =============================================================================
# Sometimes you just want to return a simple list

@app.get("/categories")
def get_categories():
    """
    Get all available categories

    Returns a simple list of category names.

    Try it: http://localhost:8000/categories
    """
    # Get unique categories
    categories = list(set(p["category"] for p in PRODUCTS))
    categories.sort()  # Alphabetical order

    return {"categories": categories}


@app.get("/users/all")
def get_all_users():
    """
    Get all users (just names and IDs)

    Note: We put this BEFORE /users/{user_id} in the code,
    but FastAPI is smart enough to match specific paths first.
    However, we use /users/all instead of /users to avoid conflicts.

    Try it: http://localhost:8000/users/all
    """
    user_list = [
        {"id": user["id"], "name": user["name"]}
        for user in USERS.values()
    ]
    return {"users": user_list}


# =============================================================================
# BONUS: Health Check Endpoint
# =============================================================================
# Every good API has a health check endpoint!

@app.get("/health")
def health_check():
    """
    Health check - is the server running?

    This is a standard pattern in production APIs.
    Monitoring tools ping this endpoint to check if your server is alive.

    Try it: http://localhost:8000/health
    """
    return {"status": "healthy", "api_version": "1.0.0"}


# =============================================================================
# SUMMARY: What We Learned
# =============================================================================
"""
This file demonstrated:

1. SIMPLE GET (no parameters)
   @app.get("/")
   def home():
       return {"message": "Hello"}

2. PATH PARAMETERS (part of URL)
   @app.get("/users/{user_id}")
   def get_user(user_id: int):
       ...

3. MULTIPLE PATH PARAMETERS
   @app.get("/users/{user_id}/posts/{post_id}")
   def get_post(user_id: int, post_id: int):
       ...

4. QUERY PARAMETERS (after ?)
   @app.get("/items")
   def get_items(skip: int = 0, limit: int = 10):
       ...

5. REQUIRED QUERY PARAMETERS (no default)
   @app.get("/search")
   def search(q: str):  # q is required!
       ...

6. OPTIONAL QUERY PARAMETERS (with None)
   @app.get("/items")
   def get_items(category: Optional[str] = None):
       ...

7. ENUM FOR LIMITED CHOICES
   class SortOrder(str, Enum):
       asc = "asc"
       desc = "desc"

   @app.get("/items")
   def get_items(sort: SortOrder = SortOrder.asc):
       ...

8. COMBINED (path + query)
   @app.get("/users/{user_id}/posts")
   def get_posts(user_id: int, page: int = 1):
       ...


TRY IT YOURSELF:
    1. Add a new endpoint: GET /products/{product_id}
    2. Add filtering to /users/all (by age range)
    3. Create GET /posts with pagination
    4. Add a /categories/{name} endpoint
"""


# =============================================================================
# ASCII DIAGRAM: All Our Endpoints
# =============================================================================
"""
    ENDPOINT MAP
    ============

    GET /                         Home page
    GET /about                    About info
    GET /health                   Health check
    GET /stats                    Statistics

    GET /hello/{name}             Say hello

    GET /users/all                List all users
    GET /users/{id}               Get one user
    GET /users/{id}/posts         User's posts
    GET /users/{id}/posts/{id}    One specific post

    GET /products                 List products (paginated)
    GET /products/filter          Filter products
    GET /products/sorted          Sorted products

    GET /search?q=...             Search products
    GET /categories               List categories


    PARAMETER TYPES USED:

    +-------------------+---------------------------+
    | Type              | Example                   |
    +-------------------+---------------------------+
    | Path (required)   | /users/{user_id}          |
    | Query (optional)  | ?limit=10                 |
    | Query (required)  | ?q=searchterm             |
    | Enum (choices)    | ?sort=price_asc           |
    +-------------------+---------------------------+
"""
