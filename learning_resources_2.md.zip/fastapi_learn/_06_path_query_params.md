# Topic 06: Path and Query Parameters in FastAPI

## What Are Parameters?

Parameters are ways to pass information to your API. Think of them like filling out a form or giving instructions to someone.

```
+------------------------------------------------------------------+
|                    TWO TYPES OF PARAMETERS                        |
+------------------------------------------------------------------+
|                                                                  |
|  PATH Parameters   = Part of the URL itself (required)           |
|                      /users/123  <- 123 is a path parameter      |
|                                                                  |
|  QUERY Parameters  = After the ? in the URL (usually optional)   |
|                      /users?age=25&city=NYC <- age, city are query|
|                                                                  |
+------------------------------------------------------------------+
```

---

## Visual Breakdown of a URL

Let's break down this URL piece by piece:

```
https://api.example.com/users/42/posts?sort=newest&limit=10

+--------------------------------------------------------------------+
|  https://api.example.com/users/42/posts?sort=newest&limit=10       |
+--------------------------------------------------------------------+
     |          |              |  |     |        |          |
     |          |              |  |     |        |          |
  Protocol    Domain         Path Params Query   Query      Query
                             ~~~~  ~~~~  Start   Param 1    Param 2
                               |     |     |        |          |
                            "users" "42" "?"   sort=newest  limit=10
                                    ^
                                    |
                              PATH PARAMETER
                              (identifies WHICH user)
```

### Another View:

```
/users/42/posts?sort=newest&limit=10
|     |  |     |    |       |
|     |  |     |    |       +-- Query param: limit=10
|     |  |     |    +---------- Query param: sort=newest  
|     |  |     +--------------- Query separator: ?
|     |  +--------------------- Path segment: posts
|     +------------------------ Path param: 42 (user ID)
+------------------------------ Path segment: users

```

---

## Path Parameters: The "Which One" Identifier

Path parameters identify WHICH specific resource you want.

```
/students/5      <- Which student? #5
/books/978-123   <- Which book? ISBN 978-123
/orders/ORD-001  <- Which order? ORD-001
```

### Path Parameter Analogy: File System

```
Think of path parameters like navigating folders on your computer:

/Users/Alice/Documents/homework.txt
       |       |         |
       |       |         +-- Specific file
       |       +------------ Folder
       +-------------------- Username (path parameter!)

API equivalent:
/users/alice/documents/homework
       |         |        |
       |         |        +-- Resource: homework
       |         +---------- Collection: documents
       +-------------------- Path param: alice
```

### In FastAPI:

```python
@app.get("/students/{student_id}")
def get_student(student_id: int):
    # student_id is automatically extracted from the URL
    return {"student_id": student_id}
```

```
Request: GET /students/42
         student_id = 42 (automatically converted to int!)
```

---

## Query Parameters: The "How/Filter" Modifiers

Query parameters modify or filter your request.

```
/products?category=electronics&min_price=100&sort=price

This says: "Get products WHERE:
  - category is electronics
  - price is at least 100
  - sorted by price"
```

### Query Parameter Analogy: Restaurant Order

```
"I'll have a burger..."                <- The resource (path)
   "...with no onions"                 <- Query param: onions=false
   "...extra cheese"                   <- Query param: cheese=extra
   "...medium-well"                    <- Query param: doneness=medium-well

API equivalent:
/order/burger?onions=false&cheese=extra&doneness=medium-well
```

### In FastAPI:

```python
@app.get("/products")
def get_products(category: str = None, min_price: float = 0):
    # Query params are function arguments with defaults
    return {"category": category, "min_price": min_price}
```

```
Request: GET /products?category=electronics&min_price=100
         category = "electronics"
         min_price = 100.0
```

---

## Path vs Query: When to Use Each?

```
+------------------------------------------------------------------+
|                    WHEN TO USE WHICH                              |
+------------------------------------------------------------------+
|                                                                  |
|  USE PATH PARAMETERS WHEN:                                       |
|  +---------------------------------------------------------+    |
|  | - You need to identify a SPECIFIC resource              |    |
|  | - The parameter is REQUIRED                             |    |
|  | - It's a unique identifier (ID, username, slug)         |    |
|  |                                                         |    |
|  | Examples:                                               |    |
|  |   /users/{user_id}      <- Which user?                  |    |
|  |   /posts/{slug}         <- Which post?                  |    |
|  |   /orders/{order_num}   <- Which order?                 |    |
|  +---------------------------------------------------------+    |
|                                                                  |
|  USE QUERY PARAMETERS WHEN:                                      |
|  +---------------------------------------------------------+    |
|  | - You want to FILTER or SORT results                    |    |
|  | - The parameter is OPTIONAL                             |    |
|  | - You're searching or paginating                        |    |
|  |                                                         |    |
|  | Examples:                                               |    |
|  |   /users?status=active     <- Filter by status          |    |
|  |   /posts?page=2&limit=10   <- Pagination                |    |
|  |   /products?search=laptop  <- Search                    |    |
|  +---------------------------------------------------------+    |
|                                                                  |
+------------------------------------------------------------------+
```

### Quick Decision Chart:

```
Is the parameter...
       |
       v
  [Required to identify the resource?]
       |
      YES                    NO
       |                      |
       v                      v
  PATH PARAMETER        QUERY PARAMETER
  /users/{id}           /users?active=true
```

---

## Type Conversion: Automatic Magic!

FastAPI automatically converts parameters to the type you specify:

```
+------------------------------------------------------------------+
|                    TYPE CONVERSION                                |
+------------------------------------------------------------------+
|                                                                  |
|  URL: /items/42?price=19.99&active=true&tags=a,b,c               |
|                                                                  |
|  Your code:                                                      |
|    def get_item(                                                 |
|        item_id: int,       <- "42" becomes 42 (integer)          |
|        price: float,       <- "19.99" becomes 19.99 (float)      |
|        active: bool,       <- "true" becomes True (boolean)      |
|        tags: str           <- "a,b,c" stays as string            |
|    ):                                                            |
|                                                                  |
+------------------------------------------------------------------+

Boolean conversion accepts:
  True:  true, True, 1, yes, on
  False: false, False, 0, no, off
```

### What Happens With Wrong Types?

```
URL: /items/abc    (but you expect int)

+------------------------------------------+
|  FastAPI Response (422 Error):           |
|                                          |
|  {                                       |
|    "detail": [{                          |
|      "loc": ["path", "item_id"],         |
|      "msg": "value is not a valid int",  |
|      "type": "type_error.integer"        |
|    }]                                    |
|  }                                       |
+------------------------------------------+

FastAPI automatically validates and returns helpful errors!
```

---

## Optional Parameters and Default Values

```
+------------------------------------------------------------------+
|                REQUIRED vs OPTIONAL                               |
+------------------------------------------------------------------+
|                                                                  |
|  REQUIRED - No default value:                                    |
|    def search(query: str):          # MUST provide query         |
|                                                                  |
|  OPTIONAL - Has default value:                                   |
|    def search(query: str = None):   # Can omit query             |
|    def search(limit: int = 10):     # Defaults to 10 if omitted  |
|                                                                  |
+------------------------------------------------------------------+

Examples in practice:

/search?query=python           <- query="python"
/search                        <- ERROR! query is required

/products?limit=20             <- limit=20
/products                      <- limit=10 (default)

```

### Visual Example:

```python
@app.get("/search")
def search(
    query: str,              # Required - no default
    category: str = None,    # Optional - defaults to None
    limit: int = 10,         # Optional - defaults to 10
    offset: int = 0          # Optional - defaults to 0
):
    pass
```

```
Valid URLs:
  /search?query=python                      <- Works! Uses defaults
  /search?query=python&limit=5              <- Works! Override limit
  /search?query=python&category=books&limit=5&offset=10  <- All params

Invalid:
  /search                                   <- ERROR! Missing 'query'
  /search?category=books                    <- ERROR! Missing 'query'
```

---

## Combining Path and Query Parameters

You can (and often will) use both together!

```
/users/{user_id}/posts?status=published&sort=date

Path:  user_id = identifies which user
Query: status = filter to only published posts
       sort = order by date
```

### In Code:

```python
@app.get("/users/{user_id}/posts")
def get_user_posts(
    user_id: int,                    # Path parameter
    status: str = None,              # Query parameter
    sort: str = "date",              # Query parameter with default
    limit: int = 10                  # Query parameter with default
):
    return {
        "user_id": user_id,
        "filter": {"status": status},
        "sort": sort,
        "limit": limit
    }
```

---

## Parameter Validation with Field()

FastAPI lets you add extra validation:

```python
from fastapi import Query, Path

@app.get("/items/{item_id}")
def get_item(
    # Path parameter with validation
    item_id: int = Path(
        ...,                      # ... means required
        gt=0,                     # Must be greater than 0
        description="The item ID"
    ),
    
    # Query parameter with validation
    quantity: int = Query(
        default=1,                # Default value
        ge=1,                     # Greater than or equal to 1
        le=100,                   # Less than or equal to 100
        description="How many items"
    )
):
    return {"item_id": item_id, "quantity": quantity}
```

### Validation Options:

```
+------------------------------------------------------------------+
|                   VALIDATION OPTIONS                              |
+------------------------------------------------------------------+
|                                                                  |
|  For Numbers (int, float):                                       |
|    gt   = greater than           (x > value)                     |
|    ge   = greater than or equal  (x >= value)                    |
|    lt   = less than              (x < value)                     |
|    le   = less than or equal     (x <= value)                    |
|                                                                  |
|  For Strings:                                                    |
|    min_length = minimum characters                               |
|    max_length = maximum characters                               |
|    regex      = must match pattern                               |
|                                                                  |
|  For All:                                                        |
|    description = API documentation text                          |
|    example     = Example value for docs                          |
|    deprecated  = Mark as deprecated in docs                      |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Common Patterns

### Pattern 1: Pagination

```
/items?page=2&limit=20

page  = which page of results (default: 1)
limit = how many per page (default: 10)
```

```python
@app.get("/items")
def list_items(page: int = 1, limit: int = 10):
    skip = (page - 1) * limit
    return {"page": page, "limit": limit, "skip": skip}
```

### Pattern 2: Filtering

```
/products?category=electronics&min_price=100&max_price=500&in_stock=true
```

```python
@app.get("/products")
def list_products(
    category: str = None,
    min_price: float = None,
    max_price: float = None,
    in_stock: bool = None
):
    # Build filters based on provided parameters
    filters = {}
    if category:
        filters["category"] = category
    if min_price is not None:
        filters["min_price"] = min_price
    # ... etc
    return {"filters": filters}
```

### Pattern 3: Sorting

```
/posts?sort_by=date&order=desc
```

```python
from enum import Enum

class SortOrder(str, Enum):
    asc = "asc"
    desc = "desc"

@app.get("/posts")
def list_posts(sort_by: str = "created_at", order: SortOrder = SortOrder.desc):
    return {"sort_by": sort_by, "order": order}
```

---

## Summary Diagram

```
+------------------------------------------------------------------+
|                    URL ANATOMY                                    |
+------------------------------------------------------------------+

    https://api.store.com/products/electronics/laptops?brand=Dell&maxPrice=1000
    |_____|  |____________||______|_|_________||______|  |_______________|
       |          |           |    |     |        |            |
    Protocol   Domain      Path  Path   Path   Query       Query
                         segment param segment  Start     Parameters
                                  |
                          "electronics"
                          (category ID)

+------------------------------------------------------------------+
|                   QUICK REFERENCE                                 |
+------------------------------------------------------------------+

  PATH PARAMETERS:
    - In the URL path: /users/{user_id}
    - Usually required
    - Identifies specific resource
    - Use for: IDs, usernames, slugs

  QUERY PARAMETERS:
    - After the ?: /users?active=true
    - Usually optional
    - Filters/modifies request
    - Use for: filtering, sorting, pagination, search

+------------------------------------------------------------------+
```

---

## Try It Yourself!

1. Run `_06_params_example.py`
2. Open `http://localhost:8000/docs`
3. Experiment with different parameter combinations:
   - Try `/products/123` vs `/products/abc`
   - Try `/search?q=laptop` with different filters
   - Try pagination with `?page=2&limit=5`

```
Challenge Questions:
  1. What happens if you omit a required path parameter?
  2. How do you make a query parameter required (not optional)?
  3. Can you create an endpoint that combines 3 path params and 3 query params?
```

---

Congratulations! You've completed Topics 04-06 of FastAPI basics!
