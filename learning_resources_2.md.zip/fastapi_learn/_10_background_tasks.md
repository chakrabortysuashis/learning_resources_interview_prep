# Topic 10: Background Tasks in FastAPI

## What Are Background Tasks?

Imagine you're at a restaurant. You order food, and the waiter says "Got it!" and 
immediately comes back with your drinks. Meanwhile, the kitchen is cooking your food 
in the BACKGROUND. You don't have to wait at the counter until your food is ready!

**Background tasks work the same way:**
- Your API responds quickly to the user: "Got it!"
- The heavy work happens AFTER the response is sent
- The user doesn't have to wait

```
WITHOUT Background Tasks:            WITH Background Tasks:
=========================            ======================

User Request                         User Request
    |                                    |
    v                                    v
[Send Email - 3 sec]                 [Return "OK!" - instant]
    |                                    |
    v                                    v
[Process File - 5 sec]               User gets response!
    |                                    |
    v                                    v
User waits 8 seconds...              [Email sends in background]
    |                                    |
    v                                    v
Finally gets response                [File processes in background]
```

---

## When Should You Use Background Tasks?

### Perfect For:
1. **Sending Emails** - User signs up, you respond "Welcome!", email sends in background
2. **Sending Notifications** - Push notifications, SMS alerts
3. **Writing Logs** - Recording events to files or databases
4. **Processing Files** - Resizing images, generating reports
5. **Cleanup Tasks** - Deleting temporary files

### NOT Good For:
1. Tasks that take MORE than a few seconds
2. Tasks that need to survive server restarts
3. Tasks that need to be scheduled for later
4. Heavy processing (use Celery instead)

---

## How Background Tasks Work

```
+------------------+     +------------------+     +------------------+
|                  |     |                  |     |                  |
|  1. REQUEST      |---->|  2. PROCESS &    |---->|  3. BACKGROUND   |
|     ARRIVES      |     |     RESPOND      |     |     TASK RUNS    |
|                  |     |                  |     |                  |
+------------------+     +------------------+     +------------------+
                                  |
                                  v
                         [Response sent to user]
                         [User is FREE to continue]
                                  
                                  |
                                  v
                         [Background task starts]
                         [User doesn't wait for this]
```

### The Timeline:

```
TIME ------>

Request    Response      Background Task
Received   Sent          Completes
   |         |              |
   v         v              v
   [=========]              
   ^ Fast!   [==============]
             ^ User done    ^ Server finishes silently
```

---

## Basic Syntax

```python
from fastapi import FastAPI, BackgroundTasks

app = FastAPI()

# This is your background task function
def send_email(email: str, message: str):
    # Pretend this takes time
    print(f"Sending email to {email}: {message}")

@app.post("/signup")
def signup(email: str, background_tasks: BackgroundTasks):
    # Add the task to run in background
    background_tasks.add_task(send_email, email, "Welcome!")
    
    # This returns IMMEDIATELY
    return {"message": "Signed up successfully!"}
```

### How `add_task` Works:

```
background_tasks.add_task(function_name, arg1, arg2, kwarg1=value)
                          ^^^^^^^^^^^^  ^^^^^^^^^^  ^^^^^^^^^^^^
                          |             |           |
                          |             |           +-- keyword arguments
                          |             +-- positional arguments  
                          +-- the function to run (no parentheses!)
```

---

## Multiple Background Tasks

You can add multiple tasks - they run in ORDER:

```python
@app.post("/order")
def create_order(background_tasks: BackgroundTasks):
    # These run in sequence after response
    background_tasks.add_task(send_confirmation_email)
    background_tasks.add_task(update_inventory)
    background_tasks.add_task(notify_shipping)
    
    return {"order": "created"}
```

```
Response sent
     |
     v
[send_confirmation_email]
     |
     v
[update_inventory]
     |
     v
[notify_shipping]
```

---

## Background Tasks vs Celery Workers

Think of it like this:

```
BACKGROUND TASKS (FastAPI)          CELERY WORKERS
==========================          ==============

  Like a waiter who cleans          Like a separate cleaning
  the table after you leave         crew that works night shifts
  
  - Quick tasks (seconds)           - Long tasks (minutes/hours)
  - Same server                     - Separate workers
  - Dies if server restarts         - Survives restarts
  - No scheduling                   - Can schedule for later
  - Simple setup                    - Complex setup (Redis/RabbitMQ)
  
  Good for:                         Good for:
  - Emails                          - Video processing
  - Notifications                   - ML model training
  - Logging                         - Large file processing
  - Cache updates                   - Scheduled reports
```

### Visual Comparison:

```
BACKGROUND TASKS:                   CELERY:
                                    
+-------------+                     +-------------+
|   FastAPI   |                     |   FastAPI   |
|   Server    |                     |   Server    |
|             |                     |             |
| [bg task]   |                     +------+------+
| [bg task]   |                            |
+-------------+                            v
                                    +-------------+
Same process!                       |   Message   |
                                    |   Queue     |
                                    | (Redis)     |
                                    +------+------+
                                           |
                                           v
                                    +-------------+
                                    |   Celery    |
                                    |   Worker    |
                                    |   Process   |
                                    +-------------+
                                    
                                    Separate process!
```

---

## Async Background Tasks

If your task involves async operations (like async database calls), 
make your function async:

```python
async def send_email_async(email: str):
    # Async operations work too!
    await some_async_email_library.send(email)

@app.post("/signup")
async def signup(email: str, background_tasks: BackgroundTasks):
    background_tasks.add_task(send_email_async, email)
    return {"message": "Welcome!"}
```

---

## Using Background Tasks with Dependencies

You can get `BackgroundTasks` in dependencies too:

```python
from fastapi import Depends

def log_request(background_tasks: BackgroundTasks):
    def write_log(message: str):
        with open("log.txt", "a") as f:
            f.write(f"{message}\n")
    
    background_tasks.add_task(write_log, "Request received")

@app.get("/items", dependencies=[Depends(log_request)])
def get_items():
    return {"items": ["apple", "banana"]}
```

---

## Common Patterns

### Pattern 1: Email After Signup
```python
@app.post("/users")
def create_user(user: User, background_tasks: BackgroundTasks):
    # Save user first (important!)
    save_to_database(user)
    
    # Email can wait
    background_tasks.add_task(send_welcome_email, user.email)
    
    return {"user": user}
```

### Pattern 2: Logging
```python
@app.post("/api/action")
def do_action(background_tasks: BackgroundTasks):
    result = perform_action()
    
    # Log in background - don't slow down response
    background_tasks.add_task(log_to_file, "action performed")
    
    return result
```

### Pattern 3: Cleanup
```python
@app.post("/upload")
def upload_file(file: UploadFile, background_tasks: BackgroundTasks):
    temp_path = save_temporarily(file)
    process_file(temp_path)
    
    # Clean up temp file in background
    background_tasks.add_task(delete_file, temp_path)
    
    return {"status": "processed"}
```

---

## Key Points to Remember

```
+-----------------------------------------------------------+
|                    BACKGROUND TASKS                        |
+-----------------------------------------------------------+
|                                                           |
|  1. Import: from fastapi import BackgroundTasks           |
|                                                           |
|  2. Add parameter: background_tasks: BackgroundTasks      |
|                                                           |
|  3. Add task: background_tasks.add_task(func, args)       |
|                                                           |
|  4. Response returns BEFORE task completes                |
|                                                           |
|  5. Tasks run IN ORDER (first added = first run)          |
|                                                           |
|  6. Use for QUICK tasks only (< 30 seconds)               |
|                                                           |
|  7. For heavy tasks, use Celery or similar                |
|                                                           |
+-----------------------------------------------------------+
```

---

## What's Next?

In the next topic, we'll learn about **Middleware** - code that runs 
BEFORE every request and AFTER every response. Think of it like 
security checkpoints at an airport!

---

## Practice Exercise

Try creating an endpoint that:
1. Accepts a user registration
2. Returns immediately with "Registration successful!"
3. In the background:
   - Sends a welcome email
   - Creates a log entry
   - Sends a notification to admin

See `_10_background_example.py` for the complete solution!
