# Topic 13: Complete Project - Todo API

## Putting Everything Together!

This is the grand finale! We'll build a complete Todo API that uses 
ALL the concepts we've learned:

```
+----------------------------------------------------------+
|                    TODO API PROJECT                       |
|                                                          |
|  CONCEPTS USED:                                          |
|  +---------------------------------------------------+   |
|  | - FastAPI basics (routes, methods)                |   |
|  | - Path and query parameters                       |   |
|  | - Pydantic models (validation)                    |   |
|  | - CRUD operations                                 |   |
|  | - Error handling (HTTPException)                  |   |
|  | - Dependencies                                    |   |
|  | - Background tasks                                |   |
|  | - Middleware (logging, timing)                    |   |
|  | - Lifespan events (database setup)                |   |
|  +---------------------------------------------------+   |
|                                                          |
+----------------------------------------------------------+
```

---

## Project Architecture

```
                         TODO API ARCHITECTURE
    
    +----------------------------------------------------------+
    |                      CLIENT REQUEST                       |
    +----------------------------------------------------------+
                              |
                              v
    +----------------------------------------------------------+
    |                       MIDDLEWARE                          |
    |  +------------------+  +------------------+               |
    |  | Logging          |  | Timing           |               |
    |  | Middleware       |  | Middleware       |               |
    |  +------------------+  +------------------+               |
    +----------------------------------------------------------+
                              |
                              v
    +----------------------------------------------------------+
    |                       ENDPOINTS                           |
    |                                                          |
    |   GET /todos              - List all todos               |
    |   POST /todos             - Create a todo                |
    |   GET /todos/{id}         - Get one todo                 |
    |   PUT /todos/{id}         - Update a todo                |
    |   DELETE /todos/{id}      - Delete a todo                |
    |   POST /todos/{id}/complete - Mark complete              |
    |                                                          |
    +----------------------------------------------------------+
                              |
                              v
    +----------------------------------------------------------+
    |                    DEPENDENCIES                           |
    |  +------------------+  +------------------+               |
    |  | Get Database     |  | Get Current      |               |
    |  | Connection       |  | User (optional)  |               |
    |  +------------------+  +------------------+               |
    +----------------------------------------------------------+
                              |
                              v
    +----------------------------------------------------------+
    |                      DATABASE                             |
    |  (In-memory for demo, would be PostgreSQL/MongoDB)       |
    +----------------------------------------------------------+
                              |
                              v
    +----------------------------------------------------------+
    |                  BACKGROUND TASKS                         |
    |  +------------------+  +------------------+               |
    |  | Send Email       |  | Write Audit      |               |
    |  | Notification     |  | Log              |               |
    |  +------------------+  +------------------+               |
    +----------------------------------------------------------+
```

---

## API Endpoints Overview

```
+--------+------------------------+--------------------------------+
| Method | Endpoint               | Description                    |
+--------+------------------------+--------------------------------+
| GET    | /                      | API info and links             |
| GET    | /health                | Health check                   |
+--------+------------------------+--------------------------------+
| GET    | /todos                 | List all todos                 |
|        |                        | ?completed=true/false (filter) |
|        |                        | ?search=keyword (search)       |
|        |                        | ?skip=0&limit=10 (pagination)  |
+--------+------------------------+--------------------------------+
| POST   | /todos                 | Create a new todo              |
+--------+------------------------+--------------------------------+
| GET    | /todos/{id}            | Get a specific todo            |
+--------+------------------------+--------------------------------+
| PUT    | /todos/{id}            | Update a todo                  |
+--------+------------------------+--------------------------------+
| DELETE | /todos/{id}            | Delete a todo                  |
+--------+------------------------+--------------------------------+
| POST   | /todos/{id}/complete   | Mark todo as complete          |
+--------+------------------------+--------------------------------+
| GET    | /todos/stats           | Get todo statistics            |
+--------+------------------------+--------------------------------+
```

---

## Data Models

### Todo Model:

```
+------------------+----------+----------------------------------+
| Field            | Type     | Description                      |
+------------------+----------+----------------------------------+
| id               | int      | Unique identifier (auto)         |
| title            | string   | Todo title (required)            |
| description      | string   | Detailed description (optional)  |
| completed        | boolean  | Completion status (default: no)  |
| priority         | int      | Priority 1-5 (default: 3)        |
| created_at       | datetime | When created (auto)              |
| updated_at       | datetime | Last update (auto)               |
+------------------+----------+----------------------------------+
```

### Request/Response Flow:

```
CREATE TODO:
============

Request Body (TodoCreate):           Response (TodoResponse):
{                                    {
  "title": "Buy groceries",            "id": 1,
  "description": "Milk, eggs",         "title": "Buy groceries",
  "priority": 2                        "description": "Milk, eggs",
}                                      "completed": false,
                                       "priority": 2,
                                       "created_at": "2024-01-15T10:30:00",
                                       "updated_at": "2024-01-15T10:30:00"
                                     }
```

---

## Middleware Pipeline

```
REQUEST FLOW:
=============

    Client Request
         |
         v
    +------------------+
    | Timing           |  Start timer
    | Middleware       |
    +------------------+
         |
         v
    +------------------+
    | Logging          |  Log: "POST /todos"
    | Middleware       |
    +------------------+
         |
         v
    +------------------+
    | Request ID       |  Add unique ID
    | Middleware       |
    +------------------+
         |
         v
    === ENDPOINT ===      Your code
         |
         v
    +------------------+
    | Request ID       |  Add ID to response
    | Middleware       |
    +------------------+
         |
         v
    +------------------+
    | Logging          |  Log: "Response 201"
    | Middleware       |
    +------------------+
         |
         v
    +------------------+
    | Timing           |  Add X-Process-Time
    | Middleware       |
    +------------------+
         |
         v
    Client Response
```

---

## Background Tasks in Action

```
POST /todos - Create Todo
=========================

SYNCHRONOUS (User waits):
  1. Validate input data
  2. Create todo in database
  3. Return response to user (FAST!)

BACKGROUND (User doesn't wait):
  4. Send email notification
  5. Write audit log
  6. Update statistics cache

Timeline:
---------
    |--User waits--|
    [validate][create][respond]
                      |--Background--|
                      [email][audit][cache]
```

---

## Lifespan Events

```
SERVER STARTUP:
===============
    
    Server Process Starts
           |
           v
    +------------------+
    | Initialize       |
    | Database         |  Create connection pool
    +------------------+
           |
           v
    +------------------+
    | Load Initial     |
    | Data             |  Load sample todos
    +------------------+
           |
           v
    +------------------+
    | Start Stats      |
    | Calculator       |  Initialize counters
    +------------------+
           |
           v
    Server Ready!


SERVER SHUTDOWN (Ctrl+C):
=========================

    Shutdown Signal
           |
           v
    +------------------+
    | Save State       |
    | to Disk          |  Persist important data
    +------------------+
           |
           v
    +------------------+
    | Close Database   |
    | Connections      |  Clean disconnect
    +------------------+
           |
           v
    +------------------+
    | Cleanup Temp     |
    | Files            |  Remove temporary data
    +------------------+
           |
           v
    Server Stopped
```

---

## Error Handling Strategy

```
ERROR HANDLING FLOW:
====================

    Request arrives
         |
         v
    +------------------+
    | Validation Error |  -> 422: Invalid data format
    +------------------+
         |
         v
    +------------------+
    | Not Found Error  |  -> 404: Todo doesn't exist
    +------------------+
         |
         v
    +------------------+
    | Business Logic   |  -> 400: Can't complete
    | Error            |      (already completed)
    +------------------+
         |
         v
    +------------------+
    | Unexpected Error |  -> 500: Server error
    +------------------+


ERROR RESPONSE FORMAT:
======================

{
  "detail": "Todo with ID 999 not found",
  "error_code": "TODO_NOT_FOUND",
  "timestamp": "2024-01-15T10:30:00"
}
```

---

## File Structure

```
fastapi_learn/
    |
    +-- _13_project_todo_api.md    <-- This documentation
    |
    +-- _13_todo_api.py            <-- The complete API code
    
    
In a real project, you might have:

todo_api/
    |
    +-- main.py           # FastAPI app and lifespan
    |
    +-- models/
    |   +-- todo.py       # Pydantic models
    |
    +-- routers/
    |   +-- todos.py      # Todo endpoints
    |
    +-- middleware/
    |   +-- logging.py    # Logging middleware
    |   +-- timing.py     # Timing middleware
    |
    +-- services/
    |   +-- todo_service.py   # Business logic
    |   +-- notification.py   # Email notifications
    |
    +-- database/
    |   +-- connection.py # Database setup
    |   +-- crud.py       # CRUD operations
    |
    +-- tests/
        +-- test_todos.py # Unit tests
```

---

## How to Test the API

### Using curl:

```bash
# List all todos
curl http://localhost:8000/todos

# Create a todo
curl -X POST http://localhost:8000/todos \
  -H "Content-Type: application/json" \
  -d '{"title": "Learn FastAPI", "priority": 1}'

# Get specific todo
curl http://localhost:8000/todos/1

# Update a todo
curl -X PUT http://localhost:8000/todos/1 \
  -H "Content-Type: application/json" \
  -d '{"title": "Learn FastAPI Advanced"}'

# Mark as complete
curl -X POST http://localhost:8000/todos/1/complete

# Delete a todo
curl -X DELETE http://localhost:8000/todos/1

# Filter completed todos
curl "http://localhost:8000/todos?completed=true"

# Search todos
curl "http://localhost:8000/todos?search=learn"

# Pagination
curl "http://localhost:8000/todos?skip=0&limit=5"
```

### Using the Interactive Docs:

1. Start the server: `uvicorn _13_todo_api:app --reload`
2. Open browser: `http://localhost:8000/docs`
3. Click on any endpoint
4. Click "Try it out"
5. Fill in parameters and click "Execute"

---

## What You'll Learn

By studying this project, you'll understand:

1. **How to structure a real API** - organizing endpoints logically
2. **How middleware wraps requests** - see timing and logging in action
3. **How lifespan manages resources** - database setup and cleanup
4. **How background tasks work** - notifications sent after response
5. **How to validate data** - Pydantic models in action
6. **How to handle errors** - proper error responses
7. **How dependencies inject resources** - database access pattern

---

## Next Steps

After understanding this project:

1. **Add authentication** - Implement JWT tokens
2. **Use a real database** - PostgreSQL with SQLAlchemy
3. **Add tests** - pytest with TestClient
4. **Deploy** - Docker, Kubernetes, or cloud services
5. **Add more features** - Tags, due dates, user assignments

---

## Run the Project!

```bash
# Navigate to the folder
cd fastapi_learn

# Install dependencies (if needed)
pip install fastapi uvicorn pydantic

# Run the server
uvicorn _13_todo_api:app --reload

# Open in browser
# http://localhost:8000/docs
```

Enjoy building with FastAPI!
