# 🚀 FastAPI Complete Learning Course

Welcome to the FastAPI learning journey! This course will take you from zero to hero in building modern, fast APIs with Python.

## 📚 Course Structure

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        FASTAPI LEARNING PATH                            │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│   BEGINNER                    INTERMEDIATE              ADVANCED        │
│   ────────                    ────────────              ────────        │
│                                                                         │
│   ┌──────────┐               ┌──────────────┐          ┌────────────┐  │
│   │ 01. What │               │ 06. Path &   │          │ 10. Back-  │  │
│   │ is       │──────────────▶│ Query Params │─────────▶│ ground     │  │
│   │ FastAPI? │               │              │          │ Tasks      │  │
│   └──────────┘               └──────────────┘          └────────────┘  │
│        │                            │                        │         │
│        ▼                            ▼                        ▼         │
│   ┌──────────┐               ┌──────────────┐          ┌────────────┐  │
│   │ 02.      │               │ 07. Request  │          │ 11.        │  │
│   │ Uvicorn  │               │ Body &       │          │ Middleware │  │
│   │ Server   │               │ Pydantic     │          │            │  │
│   └──────────┘               └──────────────┘          └────────────┘  │
│        │                            │                        │         │
│        ▼                            ▼                        ▼         │
│   ┌──────────┐               ┌──────────────┐          ┌────────────┐  │
│   │ 03. GET  │               │ 08. Error    │          │ 12.        │  │
│   │ Requests │               │ Handling     │          │ Lifespan   │  │
│   └──────────┘               └──────────────┘          └────────────┘  │
│        │                            │                        │         │
│        ▼                            ▼                        ▼         │
│   ┌──────────┐               ┌──────────────┐          ┌────────────┐  │
│   │ 04. POST │               │ 09. Custom   │          │ 13. Full   │  │
│   │ Requests │               │ Validations  │          │ Project    │  │
│   └──────────┘               └──────────────┘          └────────────┘  │
│        │                                                               │
│        ▼                                                               │
│   ┌──────────┐                                                         │
│   │ 05. CRUD │                                                         │
│   │ Methods  │                                                         │
│   └──────────┘                                                         │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

## 📋 Topics Covered

| # | Topic | Description | Files |
|---|-------|-------------|-------|
| 01 | What is FastAPI? | Introduction to FastAPI framework | `_01_what_is_fastapi.md`, `_01_hello_world.py` |
| 02 | Uvicorn Server | Understanding ASGI and Uvicorn | `_02_uvicorn_explained.md`, `_02_uvicorn_example.py` |
| 03 | GET Requests | Fetching data from APIs | `_03_get_requests.md`, `_03_get_examples.py` |
| 04 | POST Requests | Creating new resources | `_04_post_requests.md`, `_04_post_examples.py` |
| 05 | CRUD Operations | PUT, DELETE, PATCH methods | `_05_crud_operations.md`, `_05_crud_example.py` |
| 06 | Path & Query Params | URL parameters explained | `_06_path_query_params.md`, `_06_params_example.py` |
| 07 | Request Body & Pydantic | Data validation with Pydantic | `_07_request_body_pydantic.md`, `_07_pydantic_example.py` |
| 08 | Error Handling | Centralized error management | `_08_error_handling.md`, `_08_error_examples.py` |
| 09 | Custom Validations | Custom errors & validators | `_09_custom_validations.md`, `_09_custom_validation.py` |
| 10 | Background Tasks | Async background processing | `_10_background_tasks.md`, `_10_background_example.py` |
| 11 | Middleware | Request/Response interceptors | `_11_middleware.md`, `_11_middleware_example.py` |
| 12 | Lifespan Events | Startup & shutdown events | `_12_lifespan.md`, `_12_lifespan_example.py` |
| 13 | Complete Project | Todo API - putting it all together | `_13_project_todo_api.md`, `_13_todo_api.py` |

## 🛠️ Prerequisites

Before starting, make sure you have:
- Python 3.8+ installed
- Basic Python knowledge
- A code editor (VS Code recommended)

## 📦 Installation

```bash
# Create a virtual environment
python -m venv venv

# Activate it (Windows)
venv\Scripts\activate

# Activate it (Mac/Linux)
source venv/bin/activate

# Install FastAPI and Uvicorn
pip install fastapi uvicorn[standard]
```

## 🎯 How to Use This Course

1. **Read the `.md` files** - They explain concepts with diagrams
2. **Study the `.py` files** - They contain working code examples
3. **Run the examples** - Use `uvicorn filename:app --reload`
4. **Experiment!** - Modify the code and see what happens

## 🔥 Let's Begin!

Start with `_01_what_is_fastapi.md` and work your way through!

---
*Happy Learning! 🎉*
