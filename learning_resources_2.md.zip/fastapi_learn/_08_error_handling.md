# Topic 08: Error Handling in FastAPI

## Why Error Handling Matters

Imagine you're using an ATM, and something goes wrong. Would you rather see:

```
    BAD ERROR MESSAGE                    GOOD ERROR MESSAGE
    ─────────────────                    ──────────────────
    
    ┌──────────────────────┐            ┌──────────────────────┐
    │                      │            │                      │
    │   ERROR: 0x8F4A2    │            │   Sorry! Insufficient │
    │   SYSTEM FAILURE     │            │   funds in account.   │
    │                      │            │                      │
    │   ???               │            │   Balance: $50.00     │
    │                      │            │   Requested: $100.00  │
    │                      │            │                      │
    │   [OK]               │            │   [Try Again] [Cancel]│
    └──────────────────────┘            └──────────────────────┘
    
    User: "What does this mean?!"       User: "Oh, I need more money!"
```

Good error handling:
1. Tells users WHAT went wrong
2. Tells users WHY it went wrong
3. Suggests HOW to fix it

## HTTP Status Codes - The Language of Errors

HTTP status codes are like traffic lights for the web:

```
    HTTP STATUS CODES TRAFFIC LIGHT
    
    
        ┌─────┐
        │ 2XX │   GREEN LIGHT - SUCCESS!
        │ ● ● │   "Everything went well"
        └─────┘
           │
           │    200 = OK (success)
           │    201 = Created (new resource made)
           │    204 = No Content (success, nothing to return)
           │
        ┌─────┐
        │ 4XX │   YELLOW LIGHT - CLIENT ERROR
        │ ● ● │   "YOU made a mistake"
        └─────┘
           │
           │    400 = Bad Request (invalid data)
           │    401 = Unauthorized (need to log in)
           │    403 = Forbidden (not allowed)
           │    404 = Not Found (doesn't exist)
           │    422 = Unprocessable (validation failed)
           │
        ┌─────┐
        │ 5XX │   RED LIGHT - SERVER ERROR
        │ ● ● │   "WE made a mistake"
        └─────┘
           │
           │    500 = Internal Server Error (something broke)
           │    502 = Bad Gateway (upstream problem)
           │    503 = Service Unavailable (server overloaded)
```

## Complete HTTP Status Code Reference

```
    ┌────────┬───────────────────────────┬────────────────────────────────────────┐
    │ Code   │ Name                      │ When to Use                            │
    ├────────┼───────────────────────────┼────────────────────────────────────────┤
    │        │    SUCCESS (2XX)          │                                        │
    ├────────┼───────────────────────────┼────────────────────────────────────────┤
    │ 200    │ OK                        │ Request succeeded (GET, PUT, PATCH)    │
    │ 201    │ Created                   │ New resource created (POST)            │
    │ 204    │ No Content                │ Success but nothing to return (DELETE) │
    ├────────┼───────────────────────────┼────────────────────────────────────────┤
    │        │    CLIENT ERRORS (4XX)    │                                        │
    ├────────┼───────────────────────────┼────────────────────────────────────────┤
    │ 400    │ Bad Request               │ Invalid syntax or parameters           │
    │ 401    │ Unauthorized              │ Authentication required                │
    │ 403    │ Forbidden                 │ Authenticated but not permitted        │
    │ 404    │ Not Found                 │ Resource doesn't exist                 │
    │ 405    │ Method Not Allowed        │ Wrong HTTP method for endpoint         │
    │ 409    │ Conflict                  │ Resource state conflict                │
    │ 422    │ Unprocessable Entity      │ Validation error (Pydantic default)    │
    │ 429    │ Too Many Requests         │ Rate limit exceeded                    │
    ├────────┼───────────────────────────┼────────────────────────────────────────┤
    │        │    SERVER ERRORS (5XX)    │                                        │
    ├────────┼───────────────────────────┼────────────────────────────────────────┤
    │ 500    │ Internal Server Error     │ Unexpected server problem              │
    │ 502    │ Bad Gateway               │ Upstream service failed                │
    │ 503    │ Service Unavailable       │ Server temporarily overloaded          │
    │ 504    │ Gateway Timeout           │ Upstream service took too long         │
    └────────┴───────────────────────────┴────────────────────────────────────────┘
```

## HTTPException - The Main Error Tool

FastAPI's `HTTPException` is your main tool for raising errors:

```python
from fastapi import FastAPI, HTTPException

app = FastAPI()

@app.get("/users/{user_id}")
def get_user(user_id: int):
    # Simulated database lookup
    users = {1: "Alice", 2: "Bob"}
    
    if user_id not in users:
        # Raise an HTTP error!
        raise HTTPException(
            status_code=404,
            detail="User not found"
        )
    
    return {"user": users[user_id]}
```

```
    HTTPException FLOW
    
    
    Request: GET /users/99
    
           │
           ▼
    ┌──────────────────────────────────────────┐
    │  def get_user(user_id: int):             │
    │                                          │
    │      if user_id not in users:            │
    │          raise HTTPException(            │ ◄── STOP HERE!
    │              status_code=404,            │     Don't continue
    │              detail="User not found"     │     the function
    │          )                               │
    │                                          │
    │      return {"user": users[user_id]}     │ ◄── Never reaches
    │                                          │     this line
    └──────────────────────────────────────────┘
           │
           │ HTTPException raised
           ▼
    ┌──────────────────────────────────────────┐
    │  FastAPI catches it and returns:         │
    │                                          │
    │  HTTP/1.1 404 Not Found                  │
    │  {                                       │
    │      "detail": "User not found"          │
    │  }                                       │
    └──────────────────────────────────────────┘
```

## HTTPException with Headers

Sometimes you need to include extra information in the response headers:

```python
@app.get("/protected-resource")
def get_protected():
    raise HTTPException(
        status_code=401,
        detail="Not authenticated",
        headers={"WWW-Authenticate": "Bearer"}  # Tell client how to authenticate
    )
```

```
    RESPONSE WITH CUSTOM HEADERS
    
    ┌─────────────────────────────────────────────────────────┐
    │  HTTP/1.1 401 Unauthorized                              │
    │                                                         │
    │  HEADERS:                                               │
    │  ┌─────────────────────────────────────────────────┐   │
    │  │  Content-Type: application/json                 │   │
    │  │  WWW-Authenticate: Bearer    <-- Custom header! │   │
    │  └─────────────────────────────────────────────────┘   │
    │                                                         │
    │  BODY:                                                  │
    │  {                                                      │
    │      "detail": "Not authenticated"                      │
    │  }                                                      │
    └─────────────────────────────────────────────────────────┘
```

## Common Error Patterns

Here are the most common situations where you need to handle errors:

### Pattern 1: Resource Not Found (404)

```python
@app.get("/items/{item_id}")
def get_item(item_id: int):
    item = database.get(item_id)  # Returns None if not found
    
    if item is None:
        raise HTTPException(
            status_code=404,
            detail=f"Item with id {item_id} not found"
        )
    
    return item
```

### Pattern 2: Invalid Input (400)

```python
@app.post("/calculate-age")
def calculate_age(birth_year: int):
    current_year = 2024
    
    if birth_year > current_year:
        raise HTTPException(
            status_code=400,
            detail="Birth year cannot be in the future"
        )
    
    if birth_year < 1900:
        raise HTTPException(
            status_code=400,
            detail="Birth year must be after 1900"
        )
    
    return {"age": current_year - birth_year}
```

### Pattern 3: Authentication Required (401)

```python
@app.get("/secret-data")
def get_secret(token: str = None):
    if token is None:
        raise HTTPException(
            status_code=401,
            detail="Authentication token required"
        )
    
    if token != "valid-token":
        raise HTTPException(
            status_code=401,
            detail="Invalid authentication token"
        )
    
    return {"secret": "The answer is 42"}
```

### Pattern 4: Permission Denied (403)

```python
@app.delete("/admin/users/{user_id}")
def delete_user(user_id: int, role: str):
    if role != "admin":
        raise HTTPException(
            status_code=403,
            detail="Only admins can delete users"
        )
    
    # Delete the user...
    return {"message": f"User {user_id} deleted"}
```

### Pattern 5: Conflict (409)

```python
@app.post("/users/")
def create_user(username: str):
    existing_users = ["alice", "bob", "charlie"]
    
    if username.lower() in existing_users:
        raise HTTPException(
            status_code=409,
            detail=f"Username '{username}' already exists"
        )
    
    return {"message": f"User '{username}' created"}
```

## Centralized Exception Handlers

Instead of handling errors in every endpoint, you can create **centralized handlers**:

```
    CENTRALIZED ERROR HANDLING
    
    
                         ALL REQUESTS
                              │
                              ▼
    ┌─────────────────────────────────────────────────────────┐
    │                     FASTAPI APP                         │
    │                                                         │
    │   ┌─────────────────────────────────────────────────┐  │
    │   │           EXCEPTION HANDLERS                    │  │
    │   │                                                 │  │
    │   │   @app.exception_handler(ValueError)           │  │
    │   │   @app.exception_handler(CustomException)      │  │
    │   │   @app.exception_handler(Exception)            │  │
    │   │                                                 │  │
    │   │         These catch errors from ANY endpoint!  │  │
    │   └─────────────────────────────────────────────────┘  │
    │                          │                             │
    │                          ▼                             │
    │   ┌──────────┐  ┌──────────┐  ┌──────────┐           │
    │   │ Endpoint │  │ Endpoint │  │ Endpoint │           │
    │   │    /a    │  │    /b    │  │    /c    │           │
    │   └──────────┘  └──────────┘  └──────────┘           │
    │                                                         │
    └─────────────────────────────────────────────────────────┘
    
    
    If ANY endpoint raises an error, the exception handler catches it!
```

### Creating Exception Handlers

```python
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

app = FastAPI()

# Handler for a specific exception type
@app.exception_handler(ValueError)
async def value_error_handler(request: Request, exc: ValueError):
    return JSONResponse(
        status_code=400,
        content={
            "error": "Invalid value",
            "message": str(exc),
            "path": str(request.url)
        }
    )

# Now ANY endpoint that raises ValueError will be caught
@app.get("/divide/{a}/{b}")
def divide(a: int, b: int):
    if b == 0:
        raise ValueError("Cannot divide by zero!")
    return {"result": a / b}
```

## The Error Response Structure

A well-structured error response helps developers (and users) understand what went wrong:

```
    GOOD ERROR RESPONSE STRUCTURE
    
    {
        "error": {
            "code": "USER_NOT_FOUND",      <-- Machine-readable code
            "message": "User not found",   <-- Human-readable message
            "details": {                   <-- Additional context
                "user_id": 999,
                "suggestion": "Check if the user ID is correct"
            },
            "timestamp": "2024-01-15T10:30:00Z",
            "path": "/users/999"
        }
    }
    
    
    VS POOR ERROR RESPONSE:
    
    {
        "error": "Something went wrong"    <-- Useless! What went wrong?
    }
```

## Error Handling Flow Diagram

```
    COMPLETE ERROR HANDLING FLOW
    
    
    CLIENT                              SERVER
    ──────                              ──────
    
       │    POST /users
       │    {"name": "", "age": -5}
       │──────────────────────────────────────>│
       │                                       │
       │                            ┌──────────┴──────────┐
       │                            │                     │
       │                            │  1. PYDANTIC        │
       │                            │     VALIDATION      │
       │                            │                     │
       │                            │  age >= 0? NO ✗     │
       │                            │                     │
       │                            └──────────┬──────────┘
       │                                       │
       │                                       ▼
       │                            ┌─────────────────────┐
       │                            │ 422 Validation Error│
       │<──────────────────────────│                     │
       │                            │ {                   │
       │                            │   "detail": [...],  │
       │                            │   "errors": [...]   │
       │                            │ }                   │
       │                            └─────────────────────┘
       │
       │
       │    POST /users
       │    {"name": "John", "age": 25}
       │──────────────────────────────────────>│
       │                                       │
       │                            ┌──────────┴──────────┐
       │                            │                     │
       │                            │  1. PYDANTIC        │
       │                            │     VALIDATION      │
       │                            │                     │
       │                            │  All fields OK ✓    │
       │                            │                     │
       │                            └──────────┬──────────┘
       │                                       │
       │                                       ▼
       │                            ┌─────────────────────┐
       │                            │                     │
       │                            │  2. YOUR CODE       │
       │                            │     RUNS            │
       │                            │                     │
       │                            │  Check: does user   │
       │                            │  already exist?     │
       │                            │                     │
       │                            │  YES! Duplicate!    │
       │                            │                     │
       │                            └──────────┬──────────┘
       │                                       │
       │                                       ▼
       │                            ┌─────────────────────┐
       │                            │                     │
       │                            │  raise HTTPException│
       │                            │    status=409       │
       │                            │                     │
       │                            └──────────┬──────────┘
       │                                       │
       │                                       ▼
       │                            ┌─────────────────────┐
       │                            │                     │
       │                            │  3. EXCEPTION       │
       │                            │     HANDLER         │
       │                            │     (if defined)    │
       │                            │                     │
       │                            └──────────┬──────────┘
       │                                       │
       │                                       ▼
       │<──────────────────────────────────────│
       │  409 Conflict                         │
       │  {"detail": "User already exists"}    │
       │                                       │
```

## Best Practices for Error Handling

```
    ERROR HANDLING BEST PRACTICES
    
    ┌─────────────────────────────────────────────────────────────────┐
    │                                                                 │
    │  1. USE THE RIGHT STATUS CODE                                   │
    │     ─────────────────────────                                   │
    │     404 for "not found", 401 for "need login", etc.            │
    │     Don't use 500 for everything!                              │
    │                                                                 │
    │  2. PROVIDE HELPFUL MESSAGES                                    │
    │     ────────────────────────                                    │
    │     BAD:  "Error occurred"                                      │
    │     GOOD: "User with email 'x@y.com' already exists"           │
    │                                                                 │
    │  3. DON'T EXPOSE SENSITIVE INFO                                 │
    │     ───────────────────────────                                 │
    │     BAD:  "Database error: password='secret123'"               │
    │     GOOD: "Unable to process request. Please try again."       │
    │                                                                 │
    │  4. LOG ERRORS ON THE SERVER                                    │
    │     ────────────────────────                                    │
    │     Log detailed errors for debugging, but return              │
    │     simplified messages to users.                              │
    │                                                                 │
    │  5. USE CONSISTENT ERROR FORMAT                                 │
    │     ─────────────────────────────                               │
    │     All errors should have the same structure so clients       │
    │     can parse them easily.                                     │
    │                                                                 │
    │  6. HANDLE UNEXPECTED ERRORS                                    │
    │     ───────────────────────────                                 │
    │     Have a catch-all handler for unexpected exceptions         │
    │     so your API never crashes unexpectedly.                    │
    │                                                                 │
    └─────────────────────────────────────────────────────────────────┘
```

## Summary

```
    KEY TAKEAWAYS
    
    ┌─────────────────────────────────────────────────────────────────┐
    │                                                                 │
    │  HTTPException                                                  │
    │  ─────────────                                                  │
    │  Use raise HTTPException(status_code=X, detail="message")      │
    │  to return errors from your endpoints.                         │
    │                                                                 │
    │  Status Codes                                                   │
    │  ────────────                                                   │
    │  - 2XX: Success                                                 │
    │  - 4XX: Client made a mistake                                   │
    │  - 5XX: Server made a mistake                                   │
    │                                                                 │
    │  Exception Handlers                                             │
    │  ──────────────────                                             │
    │  Use @app.exception_handler(ExceptionType) to handle           │
    │  specific exception types globally.                            │
    │                                                                 │
    │  Good Error Messages                                            │
    │  ───────────────────                                            │
    │  Tell users WHAT went wrong, WHY, and HOW to fix it.           │
    │                                                                 │
    └─────────────────────────────────────────────────────────────────┘
```

## Next Steps

- Check out `_08_error_examples.py` for working code examples
- Move on to Topic 09 to learn about custom validations and error classes

---
*Remember: Good error handling makes your API user-friendly and easier to debug!*
