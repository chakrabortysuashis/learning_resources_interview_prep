"""
Topic 08: Error Handling Examples for FastAPI
==============================================

This file demonstrates different ways to handle errors in FastAPI.
Run with: uvicorn _08_error_examples:app --reload

Visit http://127.0.0.1:8000/docs to test the API!
"""

from fastapi import FastAPI, HTTPException, Request, status
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime

# Create the FastAPI application
app = FastAPI(
    title="Error Handling Examples",
    description="Learn how to handle errors properly in FastAPI",
    version="1.0.0"
)


# =============================================================================
# FAKE DATABASE - Simulating data storage
# =============================================================================
# This simulates a database. In real apps, you'd use a real database.

fake_users_db = {
    1: {"id": 1, "name": "Alice", "email": "alice@example.com", "role": "admin"},
    2: {"id": 2, "name": "Bob", "email": "bob@example.com", "role": "user"},
    3: {"id": 3, "name": "Charlie", "email": "charlie@example.com", "role": "user"},
}

fake_items_db = {
    "laptop": {"name": "Laptop", "price": 999.99, "stock": 10},
    "phone": {"name": "Phone", "price": 599.99, "stock": 0},  # Out of stock!
    "headphones": {"name": "Headphones", "price": 199.99, "stock": 25},
}


# =============================================================================
# PYDANTIC MODELS
# =============================================================================

class UserCreate(BaseModel):
    """Model for creating a new user."""
    name: str = Field(min_length=2, max_length=50)
    email: str
    role: str = "user"


class OrderCreate(BaseModel):
    """Model for creating an order."""
    item_id: str
    quantity: int = Field(gt=0, description="Must order at least 1 item")


# =============================================================================
# EXAMPLE 1: Basic HTTPException (404 Not Found)
# =============================================================================

@app.get("/users/{user_id}", tags=["1. Basic HTTPException"])
def get_user(user_id: int):
    """
    Get a user by ID.

    Try:
    - GET /users/1  --> Returns Alice (success)
    - GET /users/99 --> Returns 404 error (user not found)

    This is the most common error pattern: checking if a resource exists.
    """
    # Check if user exists in our "database"
    if user_id not in fake_users_db:
        # User not found! Raise a 404 error
        raise HTTPException(
            status_code=404,  # HTTP 404 = Not Found
            detail=f"User with ID {user_id} not found"
        )

    # User found, return their data
    return fake_users_db[user_id]


# =============================================================================
# EXAMPLE 2: Different Status Codes
# =============================================================================

@app.post("/users/", tags=["2. Different Status Codes"])
def create_user(user: UserCreate):
    """
    Create a new user.

    This demonstrates different error codes:
    - 409 Conflict: If email already exists
    - 400 Bad Request: If email format is invalid

    Try creating a user with email "alice@example.com" - it will fail!
    """
    # Check for duplicate email (409 Conflict)
    for existing_user in fake_users_db.values():
        if existing_user["email"].lower() == user.email.lower():
            raise HTTPException(
                status_code=409,  # HTTP 409 = Conflict
                detail={
                    "error": "EMAIL_EXISTS",
                    "message": f"A user with email '{user.email}' already exists",
                    "suggestion": "Try using a different email address"
                }
            )

    # Check email format (simple check - in real apps use email-validator)
    if "@" not in user.email or "." not in user.email:
        raise HTTPException(
            status_code=400,  # HTTP 400 = Bad Request
            detail={
                "error": "INVALID_EMAIL",
                "message": "Email must contain @ and a domain",
                "provided": user.email
            }
        )

    # Create the user
    new_id = max(fake_users_db.keys()) + 1
    new_user = {"id": new_id, **user.model_dump()}
    fake_users_db[new_id] = new_user

    return {"message": "User created successfully!", "user": new_user}


# =============================================================================
# EXAMPLE 3: Authentication Errors (401 Unauthorized)
# =============================================================================

@app.get("/secret-data", tags=["3. Authentication Errors"])
def get_secret_data(token: Optional[str] = None):
    """
    Access secret data with authentication.

    Try:
    - No token: 401 "Authentication required"
    - Wrong token: 401 "Invalid token"
    - Correct token (use "secret-token-123"): Success!

    Add ?token=secret-token-123 to the URL.
    """
    VALID_TOKEN = "secret-token-123"

    # No token provided
    if token is None:
        raise HTTPException(
            status_code=401,  # HTTP 401 = Unauthorized
            detail="Authentication required. Please provide a token.",
            headers={"WWW-Authenticate": "Bearer"}  # Standard header for auth errors
        )

    # Invalid token
    if token != VALID_TOKEN:
        raise HTTPException(
            status_code=401,
            detail="Invalid or expired token",
            headers={"WWW-Authenticate": "Bearer"}
        )

    # Valid token - return secret data
    return {
        "secret": "The answer to life, the universe, and everything is 42",
        "authenticated_at": datetime.now().isoformat()
    }


# =============================================================================
# EXAMPLE 4: Permission Errors (403 Forbidden)
# =============================================================================

@app.delete("/users/{user_id}", tags=["4. Permission Errors"])
def delete_user(user_id: int, requester_id: int):
    """
    Delete a user (admin only).

    Try:
    - requester_id=1 (Alice is admin): Can delete users
    - requester_id=2 (Bob is regular user): Gets 403 Forbidden

    Note: 401 = "Who are you?" / 403 = "I know who you are, but you can't do this"
    """
    # First, check if the user to delete exists
    if user_id not in fake_users_db:
        raise HTTPException(
            status_code=404,
            detail=f"User with ID {user_id} not found"
        )

    # Check if the requester exists
    if requester_id not in fake_users_db:
        raise HTTPException(
            status_code=401,
            detail="Invalid requester ID"
        )

    # Check if the requester is an admin
    requester = fake_users_db[requester_id]
    if requester["role"] != "admin":
        raise HTTPException(
            status_code=403,  # HTTP 403 = Forbidden
            detail={
                "error": "PERMISSION_DENIED",
                "message": "Only administrators can delete users",
                "your_role": requester["role"],
                "required_role": "admin"
            }
        )

    # Cannot delete yourself
    if user_id == requester_id:
        raise HTTPException(
            status_code=400,
            detail="You cannot delete your own account"
        )

    # Delete the user
    deleted_user = fake_users_db.pop(user_id)
    return {"message": f"User '{deleted_user['name']}' has been deleted"}


# =============================================================================
# EXAMPLE 5: Business Logic Errors
# =============================================================================

@app.post("/orders/", tags=["5. Business Logic Errors"])
def create_order(order: OrderCreate):
    """
    Create an order for an item.

    Try:
    - item_id="laptop", quantity=5: Success (has 10 in stock)
    - item_id="phone", quantity=1: Fails - out of stock!
    - item_id="headphones", quantity=100: Fails - not enough stock
    - item_id="invalid", quantity=1: Fails - item not found

    This shows how to handle business logic errors.
    """
    # Check if item exists
    if order.item_id not in fake_items_db:
        raise HTTPException(
            status_code=404,
            detail={
                "error": "ITEM_NOT_FOUND",
                "message": f"Item '{order.item_id}' does not exist",
                "available_items": list(fake_items_db.keys())
            }
        )

    item = fake_items_db[order.item_id]

    # Check if item is in stock
    if item["stock"] == 0:
        raise HTTPException(
            status_code=400,
            detail={
                "error": "OUT_OF_STOCK",
                "message": f"'{item['name']}' is currently out of stock",
                "suggestion": "Check back later or choose a different item"
            }
        )

    # Check if we have enough quantity
    if order.quantity > item["stock"]:
        raise HTTPException(
            status_code=400,
            detail={
                "error": "INSUFFICIENT_STOCK",
                "message": f"Only {item['stock']} units available, but you requested {order.quantity}",
                "available_quantity": item["stock"],
                "requested_quantity": order.quantity
            }
        )

    # Process the order
    total_price = item["price"] * order.quantity
    fake_items_db[order.item_id]["stock"] -= order.quantity

    return {
        "message": "Order placed successfully!",
        "order_details": {
            "item": item["name"],
            "quantity": order.quantity,
            "unit_price": item["price"],
            "total_price": round(total_price, 2),
            "remaining_stock": fake_items_db[order.item_id]["stock"]
        }
    }


# =============================================================================
# EXAMPLE 6: Using Status Code Constants
# =============================================================================

@app.get("/items/{item_id}/check-stock", tags=["6. Status Constants"])
def check_stock(item_id: str, minimum_required: int = 1):
    """
    Check if an item has enough stock.

    Instead of using numbers like 404, 400, we can use status constants.
    This makes the code more readable!

    status.HTTP_404_NOT_FOUND is the same as 404, but clearer.
    """
    # Using status.HTTP_404_NOT_FOUND instead of just 404
    if item_id not in fake_items_db:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,  # Same as 404, but readable!
            detail=f"Item '{item_id}' not found"
        )

    item = fake_items_db[item_id]

    # Check minimum stock requirement
    if item["stock"] < minimum_required:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,  # Same as 400
            detail={
                "error": "BELOW_MINIMUM",
                "message": f"Stock ({item['stock']}) is below minimum required ({minimum_required})",
                "current_stock": item["stock"],
                "minimum_required": minimum_required
            }
        )

    return {
        "item": item["name"],
        "current_stock": item["stock"],
        "minimum_required": minimum_required,
        "status": "OK - Sufficient stock"
    }


# =============================================================================
# EXAMPLE 7: Global Exception Handler
# =============================================================================
# This catches ALL unhandled exceptions and returns a consistent error response.

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """
    Catch-all handler for any unhandled exceptions.

    This ensures that even unexpected errors return a proper JSON response
    instead of crashing the server or showing ugly error pages.

    In production, you would log these errors for debugging!
    """
    # In a real app, you would LOG this error here for debugging
    # logger.error(f"Unexpected error: {exc}")

    return JSONResponse(
        status_code=500,
        content={
            "error": "INTERNAL_ERROR",
            "message": "An unexpected error occurred",
            "detail": str(exc),  # In production, you might hide this
            "path": str(request.url),
            "timestamp": datetime.now().isoformat()
        }
    )


# Endpoint to test the global exception handler
@app.get("/trigger-error", tags=["7. Global Handler"])
def trigger_error():
    """
    This endpoint intentionally raises an error to test the global handler.

    The error will be caught by the global exception handler above.
    """
    # This will raise a ZeroDivisionError
    result = 1 / 0  # Oops! Division by zero!
    return {"result": result}


# =============================================================================
# EXAMPLE 8: Custom Exception Handler for Specific Types
# =============================================================================

class InsufficientFundsError(Exception):
    """Custom exception for payment-related errors."""
    def __init__(self, balance: float, required: float):
        self.balance = balance
        self.required = required
        self.shortage = required - balance


# Register a handler for our custom exception
@app.exception_handler(InsufficientFundsError)
async def insufficient_funds_handler(request: Request, exc: InsufficientFundsError):
    """
    Handle InsufficientFundsError exceptions specifically.

    When any endpoint raises InsufficientFundsError, this handler will catch it
    and return a nicely formatted error response.
    """
    return JSONResponse(
        status_code=402,  # HTTP 402 = Payment Required
        content={
            "error": "INSUFFICIENT_FUNDS",
            "message": "Your account balance is too low for this transaction",
            "details": {
                "current_balance": exc.balance,
                "amount_required": exc.required,
                "shortage": round(exc.shortage, 2)
            },
            "suggestion": "Please add funds to your account and try again"
        }
    )


# Fake wallet balance for demonstration
user_wallet = {"balance": 50.00}


@app.post("/purchase/{item_id}", tags=["8. Custom Exception Handler"])
def purchase_item(item_id: str):
    """
    Purchase an item using your wallet balance.

    Current balance: $50.00

    Try:
    - item_id="headphones" (price: $199.99): Insufficient funds!
    - item_id="laptop" (price: $999.99): Insufficient funds!
    - item_id="phone" (price: $599.99, but out of stock): Out of stock error first

    Note: This demonstrates how custom exceptions can simplify error handling.
    """
    if item_id not in fake_items_db:
        raise HTTPException(status_code=404, detail=f"Item '{item_id}' not found")

    item = fake_items_db[item_id]

    if item["stock"] == 0:
        raise HTTPException(status_code=400, detail=f"'{item['name']}' is out of stock")

    # Check if user has enough money
    if user_wallet["balance"] < item["price"]:
        # Raise our custom exception - it will be caught by the handler above!
        raise InsufficientFundsError(
            balance=user_wallet["balance"],
            required=item["price"]
        )

    # Process purchase
    user_wallet["balance"] -= item["price"]
    fake_items_db[item_id]["stock"] -= 1

    return {
        "message": "Purchase successful!",
        "item": item["name"],
        "price": item["price"],
        "remaining_balance": round(user_wallet["balance"], 2)
    }


# =============================================================================
# EXAMPLE 9: Override Validation Error Handler
# =============================================================================
# Customize how Pydantic validation errors are displayed.

@app.exception_handler(RequestValidationError)
async def validation_error_handler(request: Request, exc: RequestValidationError):
    """
    Custom handler for Pydantic validation errors.

    Instead of the default complex error format, we return a simpler,
    more user-friendly error message.
    """
    errors = []
    for error in exc.errors():
        # Extract field name and error message
        field = " -> ".join(str(loc) for loc in error["loc"])
        message = error["msg"]
        errors.append({
            "field": field,
            "message": message,
            "your_input": error.get("input", "N/A")
        })

    return JSONResponse(
        status_code=422,
        content={
            "error": "VALIDATION_ERROR",
            "message": "The data you provided is invalid",
            "errors": errors,
            "hint": "Please check the errors above and fix your request"
        }
    )


class StrictUser(BaseModel):
    """A user model with strict validation for testing."""
    name: str = Field(min_length=3, max_length=20)
    age: int = Field(ge=0, le=150)
    email: str


@app.post("/strict-user/", tags=["9. Custom Validation Handler"])
def create_strict_user(user: StrictUser):
    """
    Create a user with strict validation.

    Try sending invalid data to see the custom validation error format:
    - {"name": "A", "age": 25, "email": "test@test.com"}  <-- name too short
    - {"name": "Alice", "age": -5, "email": "test@test.com"}  <-- negative age
    - {"name": "Alice", "age": 200, "email": "test@test.com"}  <-- age too high
    """
    return {"message": "User is valid!", "user": user.model_dump()}


# =============================================================================
# EXAMPLE 10: Error with Multiple Issues
# =============================================================================

@app.post("/validate-all", tags=["10. Multiple Errors"])
def validate_everything(
    username: str,
    password: str,
    age: int,
    email: str
):
    """
    Validate multiple fields and report ALL errors at once.

    Instead of stopping at the first error, we collect all errors
    and return them together. This is more user-friendly!

    Try: ?username=a&password=123&age=5&email=invalid
    """
    errors = []

    # Check username
    if len(username) < 3:
        errors.append({
            "field": "username",
            "error": "Username must be at least 3 characters",
            "provided": username
        })
    if not username.isalnum():
        errors.append({
            "field": "username",
            "error": "Username can only contain letters and numbers",
            "provided": username
        })

    # Check password
    if len(password) < 8:
        errors.append({
            "field": "password",
            "error": "Password must be at least 8 characters",
            "length": len(password)
        })
    if not any(c.isupper() for c in password):
        errors.append({
            "field": "password",
            "error": "Password must contain at least one uppercase letter"
        })
    if not any(c.isdigit() for c in password):
        errors.append({
            "field": "password",
            "error": "Password must contain at least one number"
        })

    # Check age
    if age < 13:
        errors.append({
            "field": "age",
            "error": "Must be at least 13 years old to register",
            "provided": age
        })

    # Check email
    if "@" not in email or "." not in email:
        errors.append({
            "field": "email",
            "error": "Please provide a valid email address",
            "provided": email
        })

    # If there are any errors, return them all
    if errors:
        raise HTTPException(
            status_code=400,
            detail={
                "error": "VALIDATION_FAILED",
                "message": f"Found {len(errors)} validation error(s)",
                "errors": errors
            }
        )

    return {
        "message": "All validations passed!",
        "user": {
            "username": username,
            "email": email,
            "age": age
        }
    }


# =============================================================================
# ROOT ENDPOINT
# =============================================================================

@app.get("/", tags=["Home"])
def home():
    """
    Welcome to the Error Handling Examples API!

    Visit /docs to see all endpoints and experiment with errors.
    """
    return {
        "message": "Welcome to the Error Handling Examples API!",
        "documentation": "/docs",
        "examples": {
            "404 Not Found": "GET /users/99",
            "409 Conflict": "POST /users/ with existing email",
            "401 Unauthorized": "GET /secret-data",
            "403 Forbidden": "DELETE /users/2?requester_id=2",
            "Business Logic": "POST /orders/ with out-of-stock item",
            "Global Handler": "GET /trigger-error",
            "Custom Handler": "POST /purchase/laptop",
            "Validation Handler": "POST /strict-user/ with invalid data",
            "Multiple Errors": "POST /validate-all with bad data"
        },
        "tips": [
            "Try valid and invalid inputs to see different error responses",
            "Notice how error messages are clear and helpful",
            "Check the HTTP status codes in the responses"
        ]
    }


# =============================================================================
# HOW TO RUN
# =============================================================================
"""
To run this example:

1. Install requirements:
   pip install fastapi uvicorn[standard]

2. Run the server:
   uvicorn _08_error_examples:app --reload

3. Open browser:
   http://127.0.0.1:8000/docs

4. Experiment!
   - Try each endpoint with valid and invalid inputs
   - Notice the different status codes
   - See how error messages are structured

KEY CONCEPTS DEMONSTRATED:
- HTTPException with different status codes
- Custom error details (dict vs string)
- Authentication (401) vs Authorization (403)
- Global exception handlers
- Custom exception classes and handlers
- Overriding validation error format
- Collecting multiple errors at once
"""
