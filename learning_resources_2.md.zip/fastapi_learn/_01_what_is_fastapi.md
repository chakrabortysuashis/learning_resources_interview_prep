# Topic 01: What is FastAPI?

## The Restaurant Analogy

Imagine a restaurant. You (the customer) want food. But you can't just walk into 
the kitchen and make it yourself. You need a **waiter** to:

1. Take your order (receive your request)
2. Tell the kitchen what you want (process the request)
3. Bring back your food (send the response)

```
    YOU (Customer)                    RESTAURANT
    +-----------+                    +------------------+
    |           |    "I want pizza" |                  |
    |  Browser  | ----------------> |     WAITER       |
    |   or      |                   |    (FastAPI)     |
    |   App     |                   |                  |
    |           | <---------------- |   Here's your    |
    +-----------+    Pizza data     |     pizza!       |
                                    +------------------+
                                           |
                                           v
                                    +------------------+
                                    |     KITCHEN      |
                                    |   (Your Code)    |
                                    +------------------+
```

**FastAPI is that waiter!** It's a tool (framework) that helps your Python code 
talk to the internet.


## What Exactly is FastAPI?

FastAPI is a **web framework** for building APIs in Python.

Breaking it down:
- **Web**: It works with the internet
- **Framework**: A collection of pre-written code that makes your job easier
- **API**: Application Programming Interface (a way for programs to talk to each other)

Think of it like LEGO blocks - instead of making every piece from scratch, 
you get ready-made pieces to build faster!


## Why is it Called "FAST" API?

FastAPI is fast in TWO ways:

### 1. Fast to RUN (Performance)
```
    Speed Comparison (requests per second - higher is better)
    
    FastAPI     ████████████████████████████████████  ~15,000+
    Flask       ████████████                          ~5,000
    Django      ██████████                            ~4,000
    
    FastAPI is built on modern Python features that make it ZOOM!
```

### 2. Fast to WRITE (Developer Speed)
- Less code needed
- Fewer bugs
- Automatic documentation

```python
# Flask way (old school) - More code needed
from flask import Flask, request
app = Flask(__name__)

@app.route('/user/<user_id>')
def get_user(user_id):
    user_id = int(user_id)  # Manual conversion
    if not isinstance(user_id, int):  # Manual validation
        return {"error": "Invalid ID"}, 400
    return {"user_id": user_id}

# FastAPI way (modern) - Clean and simple!
from fastapi import FastAPI
app = FastAPI()

@app.get('/user/{user_id}')
def get_user(user_id: int):  # Type hint does validation automatically!
    return {"user_id": user_id}
```


## Key Features of FastAPI

### Feature 1: Type Hints (Python's Labels)

Type hints are like labels on boxes - they tell you what's inside!

```python
# Without type hints - confusing!
def greet(name):
    return f"Hello {name}"

# With type hints - crystal clear!
def greet(name: str) -> str:
    return f"Hello {name}"
    #       ^^^^^ This tells us name should be text (string)
    #                    ^^^^^ This tells us the function returns text
```

FastAPI uses these hints to:
- Validate data automatically
- Generate documentation
- Provide autocomplete in your code editor


### Feature 2: Automatic Documentation

When you run FastAPI, you get FREE interactive documentation!

```
    Your FastAPI App
    ================
    
    http://localhost:8000/docs     <- Swagger UI (interactive!)
    http://localhost:8000/redoc    <- ReDoc (beautiful docs!)
    
    +--------------------------------------------------+
    |  [GET] /users         List all users             |
    |  [GET] /users/{id}    Get one user               |
    |  [POST] /users        Create a user              |
    |                                                  |
    |  [ Try it out! ]  <-- You can test right here!   |
    +--------------------------------------------------+
```

No extra work needed - FastAPI creates this FOR YOU!


### Feature 3: Async Support (Handling Many Requests)

Imagine a waiter who can only serve ONE table at a time vs. one who can 
juggle multiple tables:

```
    SYNCHRONOUS (One at a time)          ASYNC (Multiple at once)
    
    Table 1: Order -> Wait -> Serve      Table 1: Order ----+
    Table 2: ..... waiting .....         Table 2: Order --+ |
    Table 3: ..... waiting .....         Table 3: Order   | |
                                                    |     | |
    Total time: 30 minutes               All served | <---+ |
                                         together!  | <-----+
                                         
                                         Total time: 10 minutes
```

```python
# Synchronous function
@app.get("/slow")
def slow_operation():
    time.sleep(5)  # Blocks everything for 5 seconds!
    return {"message": "Done"}

# Async function (FastAPI style)
@app.get("/fast")
async def fast_operation():
    await asyncio.sleep(5)  # Other requests can be handled meanwhile!
    return {"message": "Done"}
```


## FastAPI vs Flask vs Django

```
+-------------+------------------+------------------+------------------+
|   Feature   |     FastAPI      |      Flask       |      Django      |
+-------------+------------------+------------------+------------------+
| Speed       | Very Fast        | Medium           | Medium           |
| Learning    | Easy             | Very Easy        | Hard             |
| Best For    | APIs, Modern     | Small apps,      | Big websites,    |
|             | apps             | Learning         | Admin panels     |
| Auto Docs   | YES (built-in)   | No (need plugin) | No (need plugin) |
| Type Hints  | Required & Used  | Optional         | Optional         |
| Async       | Native support   | Limited          | Limited          |
| Batteries   | Medium           | Minimal          | Everything       |
+-------------+------------------+------------------+------------------+

Batteries = Built-in features (like database, admin, etc.)
```

### Simple Analogy:
- **Flask** = Bicycle (simple, lightweight, manual everything)
- **Django** = Tour Bus (everything included, but heavy)
- **FastAPI** = Electric Scooter (fast, modern, just what you need)


## When Should You Use FastAPI?

### USE FastAPI when:
- Building REST APIs
- Need high performance
- Working with modern Python (3.7+)
- Want automatic documentation
- Building microservices
- Need async capabilities

### Maybe DON'T use FastAPI when:
- Building a traditional website with HTML pages (use Django)
- Just learning web basics (start with Flask)
- Need admin panel out of the box (use Django)


## How Does a Web Request Work?

Let's trace a request from your browser to FastAPI and back:

```
    STEP-BY-STEP: Getting User Data
    ================================
    
    1. You type in browser: http://localhost:8000/users/42
    
    2. Browser creates HTTP Request:
       +------------------------------------------+
       | GET /users/42 HTTP/1.1                   |
       | Host: localhost:8000                     |
       | Accept: application/json                 |
       +------------------------------------------+
    
    3. Request travels to your computer's port 8000
    
    4. Uvicorn (server) receives it
       |
       v
    5. FastAPI finds matching route: @app.get("/users/{user_id}")
       |
       v
    6. Your function runs:
       +------------------------------------------+
       | def get_user(user_id: int):              |
       |     return {"id": 42, "name": "Alice"}   |
       +------------------------------------------+
       |
       v
    7. FastAPI creates HTTP Response:
       +------------------------------------------+
       | HTTP/1.1 200 OK                          |
       | Content-Type: application/json           |
       |                                          |
       | {"id": 42, "name": "Alice"}              |
       +------------------------------------------+
       |
       v
    8. Response goes back to your browser
    
    9. You see: {"id": 42, "name": "Alice"}
```


## Installing FastAPI

Open your terminal and run:

```bash
# Install FastAPI
pip install fastapi

# Install Uvicorn (the server that runs FastAPI)
pip install uvicorn

# Or install both at once
pip install fastapi uvicorn
```


## Your First FastAPI App

```python
# main.py
from fastapi import FastAPI

# Create the app (like hiring the waiter)
app = FastAPI()

# Create a route (teach the waiter what to do when someone asks for "/")
@app.get("/")
def home():
    return {"message": "Welcome to FastAPI!"}
```

Run it:
```bash
uvicorn main:app --reload
```

Visit: `http://localhost:8000` - You'll see your message!


## Try It Yourself!

1. Install FastAPI and Uvicorn
2. Create a file called `main.py`
3. Copy the "Your First FastAPI App" code
4. Run it with `uvicorn main:app --reload`
5. Open your browser to `http://localhost:8000`
6. Try `http://localhost:8000/docs` to see the magic documentation!


## Key Terms Glossary

| Term | Simple Explanation |
|------|-------------------|
| **API** | A way for programs to talk to each other |
| **Framework** | Pre-written code that makes your job easier |
| **Route/Endpoint** | A URL path that does something (like `/users`) |
| **HTTP** | The language browsers and servers use to talk |
| **Request** | Asking for something (like ordering food) |
| **Response** | Getting something back (like receiving food) |
| **Async** | Doing multiple things without waiting |
| **Type Hint** | Labels telling Python what type of data to expect |


## Summary

```
    FastAPI = Fast + Modern + Easy + Automatic Docs
    
    +--------------------------------------------------+
    |                                                  |
    |   1. Write Python code with type hints           |
    |   2. Add @app.get() or @app.post() decorators    |
    |   3. Run with Uvicorn                            |
    |   4. Get free documentation at /docs             |
    |   5. Enjoy fast, validated, documented APIs!     |
    |                                                  |
    +--------------------------------------------------+
```

Next up: Learn about Uvicorn - the engine that runs your FastAPI app!
