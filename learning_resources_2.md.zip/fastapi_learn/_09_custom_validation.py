"""
Topic 09: Custom Validations and Error Classes
==============================================

This file demonstrates custom validators, model validators, and custom exception classes.
Run with: uvicorn _09_custom_validation:app --reload

Visit http://127.0.0.1:8000/docs to test the API!
"""

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field, field_validator, model_validator, EmailStr
from typing import Optional, List
from datetime import date, datetime
from enum import Enum
import re

# Create the FastAPI application
app = FastAPI(
    title="Custom Validations API",
    description="Learn custom validators and exception handling in FastAPI",
    version="1.0.0"
)


# =============================================================================
# CUSTOM EXCEPTION CLASSES
# =============================================================================
# Creating your own exception types makes error handling cleaner and more specific.

class UserNotFoundError(Exception):
    """Raised when a user is not found in the database."""
    def __init__(self, user_id: int):
        self.user_id = user_id
        self.message = f"User with ID {user_id} not found"
        super().__init__(self.message)


class DuplicateEmailError(Exception):
    """Raised when trying to register with an existing email."""
    def __init__(self, email: str):
        self.email = email
        self.message = f"Email '{email}' is already registered"
        super().__init__(self.message)


class MinimumAgeError(Exception):
    """Raised when user doesn't meet age requirements."""
    def __init__(self, provided_age: int, minimum_age: int, action: str = "register"):
        self.provided_age = provided_age
        self.minimum_age = minimum_age
        self.action = action
        self.message = f"Must be at least {minimum_age} years old to {action}"
        super().__init__(self.message)


class InvalidDateRangeError(Exception):
    """Raised when date range is invalid."""
    def __init__(self, start_date: str, end_date: str):
        self.start_date = start_date
        self.end_date = end_date
        self.message = f"Start date ({start_date}) must be before end date ({end_date})"
        super().__init__(self.message)


class PasswordStrengthError(Exception):
    """Raised when password doesn't meet strength requirements."""
    def __init__(self, missing_requirements: List[str]):
        self.missing_requirements = missing_requirements
        self.message = f"Password must have: {', '.join(missing_requirements)}"
        super().__init__(self.message)


# =============================================================================
# EXCEPTION HANDLERS
# =============================================================================
# Register handlers for our custom exceptions.

@app.exception_handler(UserNotFoundError)
async def user_not_found_handler(request: Request, exc: UserNotFoundError):
    """Handle UserNotFoundError with a friendly response."""
    return JSONResponse(
        status_code=404,
        content={
            "error": "USER_NOT_FOUND",
            "message": exc.message,
            "user_id": exc.user_id,
            "suggestion": "Please verify the user ID and try again"
        }
    )


@app.exception_handler(DuplicateEmailError)
async def duplicate_email_handler(request: Request, exc: DuplicateEmailError):
    """Handle DuplicateEmailError."""
    return JSONResponse(
        status_code=409,
        content={
            "error": "DUPLICATE_EMAIL",
            "message": exc.message,
            "email": exc.email,
            "suggestion": "Try logging in or use a different email"
        }
    )


@app.exception_handler(MinimumAgeError)
async def minimum_age_handler(request: Request, exc: MinimumAgeError):
    """Handle MinimumAgeError."""
    return JSONResponse(
        status_code=400,
        content={
            "error": "MINIMUM_AGE_NOT_MET",
            "message": exc.message,
            "your_age": exc.provided_age,
            "required_age": exc.minimum_age,
            "action": exc.action
        }
    )


@app.exception_handler(InvalidDateRangeError)
async def invalid_date_range_handler(request: Request, exc: InvalidDateRangeError):
    """Handle InvalidDateRangeError."""
    return JSONResponse(
        status_code=400,
        content={
            "error": "INVALID_DATE_RANGE",
            "message": exc.message,
            "start_date": exc.start_date,
            "end_date": exc.end_date
        }
    )


@app.exception_handler(PasswordStrengthError)
async def password_strength_handler(request: Request, exc: PasswordStrengthError):
    """Handle PasswordStrengthError."""
    return JSONResponse(
        status_code=400,
        content={
            "error": "WEAK_PASSWORD",
            "message": "Password does not meet security requirements",
            "missing_requirements": exc.missing_requirements,
            "requirements": [
                "At least 8 characters",
                "At least one uppercase letter (A-Z)",
                "At least one lowercase letter (a-z)",
                "At least one digit (0-9)",
                "At least one special character (!@#$%^&*)"
            ]
        }
    )


# =============================================================================
# EXAMPLE 1: Basic Field Validator
# =============================================================================

class BasicUser(BaseModel):
    """
    A user model with basic field validators.

    Field validators check individual fields after type conversion.
    """
    username: str = Field(min_length=3, max_length=20)
    email: str

    @field_validator('username')
    @classmethod
    def username_must_be_lowercase(cls, v: str) -> str:
        """
        Ensure username is lowercase.

        This validator runs AFTER type conversion.
        The value 'v' is already confirmed to be a string.
        """
        if v != v.lower():
            raise ValueError(
                f"Username must be lowercase. Got '{v}', expected '{v.lower()}'"
            )
        return v

    @field_validator('username')
    @classmethod
    def username_no_special_chars(cls, v: str) -> str:
        """
        Ensure username only contains alphanumeric characters and underscores.

        Multiple validators can be applied to the same field.
        They run in the order they're defined.
        """
        if not re.match(r'^[a-z0-9_]+$', v):
            raise ValueError(
                "Username can only contain lowercase letters, numbers, and underscores"
            )
        return v

    @field_validator('email')
    @classmethod
    def email_must_be_valid(cls, v: str) -> str:
        """Basic email validation."""
        if '@' not in v or '.' not in v.split('@')[-1]:
            raise ValueError("Invalid email format")
        return v.lower()  # Normalize to lowercase


@app.post("/basic-user/", tags=["1. Basic Field Validators"])
def create_basic_user(user: BasicUser):
    """
    Create a user with basic validation.

    Try these inputs:
    - Valid: {"username": "john_doe", "email": "john@example.com"}
    - Invalid username (uppercase): {"username": "JohnDoe", "email": "j@e.com"}
    - Invalid username (special chars): {"username": "john@doe", "email": "j@e.com"}
    - Invalid email: {"username": "john", "email": "notanemail"}
    """
    return {
        "message": "User created with basic validation!",
        "user": user.model_dump()
    }


# =============================================================================
# EXAMPLE 2: Before Mode Validators (Preprocessing)
# =============================================================================

class PreprocessedUser(BaseModel):
    """
    A user model with 'before' mode validators for preprocessing.

    'before' validators run BEFORE type conversion, allowing you to
    clean or transform raw input data.
    """
    username: str
    display_name: str
    tags: List[str] = []

    @field_validator('username', mode='before')
    @classmethod
    def strip_and_lowercase_username(cls, v):
        """
        Clean up username before validation.

        mode='before' means this runs on the RAW input,
        before Pydantic converts it to the expected type.
        """
        if isinstance(v, str):
            # Remove whitespace and convert to lowercase
            return v.strip().lower()
        return v

    @field_validator('display_name', mode='before')
    @classmethod
    def normalize_display_name(cls, v):
        """Remove extra whitespace and capitalize properly."""
        if isinstance(v, str):
            # Strip, collapse multiple spaces, and title case
            cleaned = ' '.join(v.split())
            return cleaned.title()
        return v

    @field_validator('tags', mode='before')
    @classmethod
    def process_tags(cls, v):
        """
        Handle tags as either a list or comma-separated string.

        This allows flexible input:
        - ["python", "fastapi"] (list)
        - "python,fastapi" (comma-separated string)
        - "python, fastapi" (with spaces)
        """
        if isinstance(v, str):
            # Split comma-separated string into list
            return [tag.strip().lower() for tag in v.split(',') if tag.strip()]
        elif isinstance(v, list):
            # Clean up list items
            return [str(tag).strip().lower() for tag in v if str(tag).strip()]
        return v


@app.post("/preprocessed-user/", tags=["2. Before Mode Validators"])
def create_preprocessed_user(user: PreprocessedUser):
    """
    Create a user with preprocessing validators.

    The validators will clean up your input automatically!

    Try these:
    - {"username": "  JOHN_DOE  ", "display_name": "john   smith", "tags": "Python, FastAPI, API"}
    - {"username": "alice", "display_name": "alice wonderland", "tags": ["PYTHON", " FastAPI "]}

    Notice how the output is cleaned and normalized.
    """
    return {
        "message": "User created with preprocessing!",
        "user": user.model_dump(),
        "note": "Notice how username, display_name, and tags were normalized"
    }


# =============================================================================
# EXAMPLE 3: Password Strength Validator
# =============================================================================

class UserRegistration(BaseModel):
    """User registration with password strength validation."""
    username: str = Field(min_length=3, max_length=20)
    email: str
    password: str = Field(min_length=8)

    @field_validator('password')
    @classmethod
    def validate_password_strength(cls, v: str) -> str:
        """
        Check that password meets security requirements.

        Requirements:
        - At least 8 characters (handled by Field)
        - At least one uppercase letter
        - At least one lowercase letter
        - At least one digit
        - At least one special character
        """
        missing = []

        if not re.search(r'[A-Z]', v):
            missing.append("at least one uppercase letter (A-Z)")

        if not re.search(r'[a-z]', v):
            missing.append("at least one lowercase letter (a-z)")

        if not re.search(r'\d', v):
            missing.append("at least one digit (0-9)")

        if not re.search(r'[!@#$%^&*(),.?":{}|<>]', v):
            missing.append("at least one special character (!@#$%^&*)")

        if missing:
            raise ValueError(f"Password must contain: {', '.join(missing)}")

        return v


@app.post("/register/", tags=["3. Password Strength"])
def register_user(user: UserRegistration):
    """
    Register a new user with strong password requirements.

    Good password: "MyP@ssw0rd!"
    Bad passwords:
    - "password" (no uppercase, digit, or special char)
    - "PASSWORD123" (no lowercase or special char)
    - "Pass123" (too short, no special char)
    """
    return {
        "message": "Registration successful!",
        "user": {
            "username": user.username,
            "email": user.email,
            # Never return the actual password!
            "password": "********"
        }
    }


# =============================================================================
# EXAMPLE 4: Model Validators (Cross-Field Validation)
# =============================================================================

class PasswordChange(BaseModel):
    """Model for changing password - demonstrates cross-field validation."""
    old_password: str
    new_password: str = Field(min_length=8)
    confirm_password: str

    @model_validator(mode='after')
    def validate_passwords(self):
        """
        Validate password change logic.

        Model validators run AFTER all field validators,
        so you can access and compare multiple fields.
        """
        # Check that new password matches confirmation
        if self.new_password != self.confirm_password:
            raise ValueError("New password and confirmation do not match")

        # Check that new password is different from old
        if self.new_password == self.old_password:
            raise ValueError("New password must be different from old password")

        return self


@app.post("/change-password/", tags=["4. Model Validators"])
def change_password(data: PasswordChange):
    """
    Change password with cross-field validation.

    Valid:
    {
        "old_password": "OldP@ss1",
        "new_password": "NewP@ss2",
        "confirm_password": "NewP@ss2"
    }

    Invalid (passwords don't match):
    {
        "old_password": "OldP@ss1",
        "new_password": "NewP@ss2",
        "confirm_password": "Different"
    }

    Invalid (same as old):
    {
        "old_password": "SameP@ss1",
        "new_password": "SameP@ss1",
        "confirm_password": "SameP@ss1"
    }
    """
    return {
        "message": "Password changed successfully!",
        "note": "In a real app, you would verify old_password against database"
    }


# =============================================================================
# EXAMPLE 5: Date Range Validation
# =============================================================================

class DateRangeModel(BaseModel):
    """Model for date ranges with validation."""
    start_date: date
    end_date: date
    description: Optional[str] = None

    @model_validator(mode='after')
    def validate_date_range(self):
        """Ensure end_date is not before start_date."""
        if self.end_date < self.start_date:
            raise ValueError(
                f"End date ({self.end_date}) cannot be before "
                f"start date ({self.start_date})"
            )
        return self

    @model_validator(mode='after')
    def validate_not_in_past(self):
        """Ensure dates are not in the past (for bookings, etc.)."""
        today = date.today()
        if self.start_date < today:
            raise ValueError(
                f"Start date ({self.start_date}) cannot be in the past. "
                f"Today is {today}"
            )
        return self


@app.post("/book-dates/", tags=["5. Date Range Validation"])
def book_dates(dates: DateRangeModel):
    """
    Book a date range (e.g., for reservations).

    Valid (assuming today or later):
    {
        "start_date": "2025-01-15",
        "end_date": "2025-01-20",
        "description": "Vacation booking"
    }

    Invalid (end before start):
    {
        "start_date": "2025-01-20",
        "end_date": "2025-01-15"
    }

    Invalid (in the past):
    {
        "start_date": "2020-01-01",
        "end_date": "2020-01-05"
    }
    """
    duration = (dates.end_date - dates.start_date).days
    return {
        "message": "Dates booked successfully!",
        "booking": {
            "start": str(dates.start_date),
            "end": str(dates.end_date),
            "duration_days": duration,
            "description": dates.description
        }
    }


# =============================================================================
# EXAMPLE 6: Conditional Validation
# =============================================================================

class PaymentType(str, Enum):
    CARD = "card"
    BANK = "bank"
    PAYPAL = "paypal"


class PaymentInfo(BaseModel):
    """Payment info with conditional validation based on payment type."""
    payment_type: PaymentType
    amount: float = Field(gt=0)

    # Card fields (optional - required only for card payments)
    card_number: Optional[str] = None
    card_expiry: Optional[str] = None
    card_cvv: Optional[str] = None

    # Bank fields (optional - required only for bank payments)
    bank_account: Optional[str] = None
    bank_routing: Optional[str] = None

    # PayPal fields (optional - required only for PayPal)
    paypal_email: Optional[str] = None

    @model_validator(mode='after')
    def validate_payment_fields(self):
        """Require different fields based on payment type."""
        if self.payment_type == PaymentType.CARD:
            missing = []
            if not self.card_number:
                missing.append("card_number")
            if not self.card_expiry:
                missing.append("card_expiry")
            if not self.card_cvv:
                missing.append("card_cvv")
            if missing:
                raise ValueError(
                    f"Card payment requires: {', '.join(missing)}"
                )

        elif self.payment_type == PaymentType.BANK:
            missing = []
            if not self.bank_account:
                missing.append("bank_account")
            if not self.bank_routing:
                missing.append("bank_routing")
            if missing:
                raise ValueError(
                    f"Bank payment requires: {', '.join(missing)}"
                )

        elif self.payment_type == PaymentType.PAYPAL:
            if not self.paypal_email:
                raise ValueError("PayPal payment requires: paypal_email")

        return self

    @field_validator('card_number')
    @classmethod
    def validate_card_number(cls, v):
        """Basic card number validation (if provided)."""
        if v is not None:
            # Remove spaces and dashes
            cleaned = v.replace(' ', '').replace('-', '')
            if not cleaned.isdigit():
                raise ValueError("Card number must contain only digits")
            if len(cleaned) < 13 or len(cleaned) > 19:
                raise ValueError("Card number must be 13-19 digits")
            return cleaned
        return v


@app.post("/payment/", tags=["6. Conditional Validation"])
def process_payment(payment: PaymentInfo):
    """
    Process a payment with conditional validation.

    For card payment:
    {
        "payment_type": "card",
        "amount": 99.99,
        "card_number": "4111111111111111",
        "card_expiry": "12/25",
        "card_cvv": "123"
    }

    For bank payment:
    {
        "payment_type": "bank",
        "amount": 99.99,
        "bank_account": "123456789",
        "bank_routing": "987654321"
    }

    For PayPal:
    {
        "payment_type": "paypal",
        "amount": 99.99,
        "paypal_email": "user@example.com"
    }

    Missing required fields will cause validation errors!
    """
    return {
        "message": "Payment processed!",
        "payment_type": payment.payment_type.value,
        "amount": payment.amount,
        "status": "SUCCESS"
    }


# =============================================================================
# EXAMPLE 7: Using Custom Exceptions in Endpoints
# =============================================================================

# Fake database for demonstration
fake_users_db = {
    1: {"id": 1, "name": "Alice", "email": "alice@example.com", "age": 25},
    2: {"id": 2, "name": "Bob", "email": "bob@example.com", "age": 17},
}


@app.get("/users/{user_id}", tags=["7. Custom Exceptions"])
def get_user(user_id: int):
    """
    Get a user by ID using custom exception.

    Try:
    - /users/1 - Returns Alice
    - /users/99 - Raises UserNotFoundError
    """
    if user_id not in fake_users_db:
        raise UserNotFoundError(user_id)

    return fake_users_db[user_id]


@app.post("/adult-content/access", tags=["7. Custom Exceptions"])
def access_adult_content(user_id: int):
    """
    Access age-restricted content.

    Try:
    - user_id=1 (Alice, age 25) - Success
    - user_id=2 (Bob, age 17) - MinimumAgeError
    - user_id=99 - UserNotFoundError
    """
    if user_id not in fake_users_db:
        raise UserNotFoundError(user_id)

    user = fake_users_db[user_id]

    if user["age"] < 18:
        raise MinimumAgeError(
            provided_age=user["age"],
            minimum_age=18,
            action="access adult content"
        )

    return {
        "message": f"Access granted for {user['name']}",
        "content": "Here is the age-restricted content..."
    }


class NewUserModel(BaseModel):
    """Model for creating new users."""
    name: str = Field(min_length=2)
    email: str
    age: int = Field(ge=0, le=150)


@app.post("/users/", tags=["7. Custom Exceptions"])
def create_user(user: NewUserModel):
    """
    Create a new user.

    Try creating with existing email "alice@example.com" to see DuplicateEmailError.
    """
    # Check for duplicate email
    for existing_user in fake_users_db.values():
        if existing_user["email"].lower() == user.email.lower():
            raise DuplicateEmailError(user.email)

    # Create user
    new_id = max(fake_users_db.keys()) + 1
    fake_users_db[new_id] = {
        "id": new_id,
        "name": user.name,
        "email": user.email.lower(),
        "age": user.age
    }

    return {
        "message": "User created!",
        "user": fake_users_db[new_id]
    }


# =============================================================================
# EXAMPLE 8: Complex Nested Validation
# =============================================================================

class AddressModel(BaseModel):
    """Address with validation."""
    street: str = Field(min_length=5)
    city: str = Field(min_length=2)
    zip_code: str
    country: str = "USA"

    @field_validator('zip_code')
    @classmethod
    def validate_zip_code(cls, v):
        """Validate US zip code format."""
        # US zip: 12345 or 12345-6789
        if not re.match(r'^\d{5}(-\d{4})?$', v):
            raise ValueError(
                "Invalid zip code format. Expected: 12345 or 12345-6789"
            )
        return v


class OrderItemModel(BaseModel):
    """Order item with validation."""
    product_id: str
    quantity: int = Field(gt=0)
    unit_price: float = Field(gt=0)

    @property
    def total(self) -> float:
        return self.quantity * self.unit_price


class CompleteOrder(BaseModel):
    """Complete order with nested validation."""
    customer_name: str = Field(min_length=2)
    customer_email: str
    shipping_address: AddressModel  # Nested model
    billing_address: Optional[AddressModel] = None  # Optional nested
    items: List[OrderItemModel] = Field(min_length=1)  # Must have at least 1 item
    discount_percent: float = Field(ge=0, le=100, default=0)

    @model_validator(mode='after')
    def use_shipping_as_billing_if_not_provided(self):
        """Default billing address to shipping if not provided."""
        if self.billing_address is None:
            self.billing_address = self.shipping_address
        return self

    @property
    def subtotal(self) -> float:
        return sum(item.quantity * item.unit_price for item in self.items)

    @property
    def total_after_discount(self) -> float:
        discount = self.subtotal * (self.discount_percent / 100)
        return self.subtotal - discount


@app.post("/orders/", tags=["8. Nested Validation"])
def create_order(order: CompleteOrder):
    """
    Create a complete order with nested validation.

    Example:
    {
        "customer_name": "John Doe",
        "customer_email": "john@example.com",
        "shipping_address": {
            "street": "123 Main Street",
            "city": "New York",
            "zip_code": "10001"
        },
        "items": [
            {"product_id": "PROD-001", "quantity": 2, "unit_price": 29.99},
            {"product_id": "PROD-002", "quantity": 1, "unit_price": 49.99}
        ],
        "discount_percent": 10
    }

    Invalid zip code:
    "zip_code": "abc123"  <-- Will fail validation

    No items:
    "items": []  <-- Will fail (min_length=1)
    """
    return {
        "message": "Order created!",
        "order_summary": {
            "customer": order.customer_name,
            "items_count": len(order.items),
            "subtotal": round(order.subtotal, 2),
            "discount": f"{order.discount_percent}%",
            "total": round(order.total_after_discount, 2),
            "shipping_city": order.shipping_address.city
        }
    }


# =============================================================================
# EXAMPLE 9: Validator that Modifies Values
# =============================================================================

class ArticleModel(BaseModel):
    """Article with validators that transform data."""
    title: str
    content: str
    slug: Optional[str] = None
    tags: List[str] = []

    @field_validator('title', mode='after')
    @classmethod
    def capitalize_title(cls, v: str) -> str:
        """Ensure title is properly capitalized."""
        return v.strip().title()

    @field_validator('tags', mode='after')
    @classmethod
    def normalize_tags(cls, v: List[str]) -> List[str]:
        """Normalize tags: lowercase, remove duplicates, sort."""
        # Convert to lowercase and remove duplicates using set
        unique_tags = list(set(tag.lower().strip() for tag in v))
        # Sort alphabetically
        return sorted(unique_tags)

    @model_validator(mode='after')
    def generate_slug_if_missing(self):
        """Auto-generate slug from title if not provided."""
        if self.slug is None:
            # Convert title to URL-friendly slug
            slug = self.title.lower()
            slug = re.sub(r'[^a-z0-9\s-]', '', slug)  # Remove special chars
            slug = re.sub(r'[\s_]+', '-', slug)       # Replace spaces with hyphens
            slug = re.sub(r'-+', '-', slug)           # Remove multiple hyphens
            self.slug = slug.strip('-')
        return self


@app.post("/articles/", tags=["9. Value Transformation"])
def create_article(article: ArticleModel):
    """
    Create an article - validators transform the data.

    Input:
    {
        "title": "  my AWESOME article  ",
        "content": "Article content here...",
        "tags": ["Python", "PYTHON", "fastapi", "FastAPI", "api"]
    }

    Output will have:
    - title: "My Awesome Article" (capitalized, trimmed)
    - slug: "my-awesome-article" (auto-generated)
    - tags: ["api", "fastapi", "python"] (lowercased, deduped, sorted)
    """
    return {
        "message": "Article created!",
        "article": article.model_dump(),
        "note": "Notice how title, slug, and tags were automatically normalized"
    }


# =============================================================================
# ROOT ENDPOINT
# =============================================================================

@app.get("/", tags=["Home"])
def home():
    """
    Welcome to the Custom Validations API!

    This API demonstrates:
    - Field validators (@field_validator)
    - Model validators (@model_validator)
    - Before/After validation modes
    - Custom exception classes
    - Conditional validation
    - Value transformation
    """
    return {
        "message": "Welcome to the Custom Validations API!",
        "documentation": "/docs",
        "examples": [
            "POST /basic-user/ - Basic field validators",
            "POST /preprocessed-user/ - Before mode (preprocessing)",
            "POST /register/ - Password strength validation",
            "POST /change-password/ - Cross-field validation",
            "POST /book-dates/ - Date range validation",
            "POST /payment/ - Conditional validation",
            "GET /users/{id} - Custom exceptions",
            "POST /orders/ - Nested validation",
            "POST /articles/ - Value transformation"
        ]
    }


# =============================================================================
# HOW TO RUN
# =============================================================================
"""
To run this example:

1. Install requirements:
   pip install fastapi uvicorn[standard] pydantic email-validator

2. Run the server:
   uvicorn _09_custom_validation:app --reload

3. Open browser:
   http://127.0.0.1:8000/docs

4. Experiment with each endpoint!

KEY CONCEPTS:
- @field_validator: Validate individual fields
- @model_validator: Validate multiple fields together
- mode='before': Run before type conversion (preprocessing)
- mode='after': Run after type conversion (default)
- Custom exceptions: Create specific error types
- Exception handlers: Convert exceptions to HTTP responses
- Value transformation: Validators can modify/normalize values
"""
