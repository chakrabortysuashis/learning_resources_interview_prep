"""
Topic 05: Complete CRUD Operations Example in FastAPI
=====================================================

This file demonstrates all CRUD operations:
- CREATE (POST)   - Add new items
- READ   (GET)    - Retrieve items
- UPDATE (PUT)    - Replace entire item
- UPDATE (PATCH)  - Modify specific fields
- DELETE (DELETE) - Remove items

Run this file:
    uvicorn _05_crud_example:app --reload

Then open: http://localhost:8000/docs
"""

from fastapi import FastAPI, HTTPException, status
from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime

# Create our FastAPI application
app = FastAPI(
    title="CRUD Operations Tutorial",
    description="Learn all CRUD operations with a simple item management system!"
)


# ============================================================
# PYDANTIC MODELS
# ============================================================

class ItemCreate(BaseModel):
    """
    Model for CREATING a new item.
    Used with POST requests.
    All fields except description are required.
    """
    name: str = Field(
        ...,
        min_length=1,
        max_length=100,
        description="Name of the item",
        examples=["Laptop"]
    )
    price: float = Field(
        ...,
        gt=0,  # Must be greater than 0
        description="Price in dollars",
        examples=[999.99]
    )
    quantity: int = Field(
        ...,
        ge=0,  # Can be 0 (out of stock)
        description="Number in stock",
        examples=[10]
    )
    description: Optional[str] = Field(
        None,
        max_length=500,
        description="Optional description",
        examples=["A powerful laptop for coding"]
    )


class ItemUpdate(BaseModel):
    """
    Model for FULL UPDATE (PUT).
    Same as ItemCreate - you must provide ALL fields.
    """
    name: str = Field(..., min_length=1, max_length=100)
    price: float = Field(..., gt=0)
    quantity: int = Field(..., ge=0)
    description: Optional[str] = Field(None, max_length=500)


class ItemPatch(BaseModel):
    """
    Model for PARTIAL UPDATE (PATCH).
    All fields are OPTIONAL - only update what you send!
    """
    name: Optional[str] = Field(None, min_length=1, max_length=100)
    price: Optional[float] = Field(None, gt=0)
    quantity: Optional[int] = Field(None, ge=0)
    description: Optional[str] = Field(None, max_length=500)


class ItemResponse(BaseModel):
    """
    Model for item responses.
    Includes the auto-generated ID and timestamps.
    """
    id: int
    name: str
    price: float
    quantity: int
    description: Optional[str]
    created_at: str
    updated_at: str


# ============================================================
# IN-MEMORY DATABASE
# ============================================================

# This simulates a database using a simple list
# In real applications, you'd use a real database (PostgreSQL, MongoDB, etc.)

items_db: list[dict] = []
item_id_counter = 0


def get_item_by_id(item_id: int) -> dict | None:
    """Helper function to find an item by ID."""
    for item in items_db:
        if item["id"] == item_id:
            return item
    return None


def get_item_index(item_id: int) -> int | None:
    """Helper function to find item index by ID."""
    for index, item in enumerate(items_db):
        if item["id"] == item_id:
            return index
    return None


# ============================================================
# CREATE - POST
# ============================================================

@app.post(
    "/items/",
    response_model=ItemResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create a new item",
    tags=["CRUD Operations"]
)
def create_item(item: ItemCreate):
    """
    **CREATE** - Add a new item to the inventory.

    This is the **C** in CRUD!

    - Receives item data in the request body
    - Assigns a unique ID automatically
    - Adds timestamps for tracking
    - Returns the created item

    **Example:**
    ```json
    {
        "name": "Laptop",
        "price": 999.99,
        "quantity": 10,
        "description": "A powerful laptop"
    }
    ```
    """
    global item_id_counter

    # Generate new ID
    item_id_counter += 1
    current_time = datetime.now().isoformat()

    # Create the item record
    new_item = {
        "id": item_id_counter,
        "name": item.name,
        "price": item.price,
        "quantity": item.quantity,
        "description": item.description,
        "created_at": current_time,
        "updated_at": current_time
    }

    # Add to database
    items_db.append(new_item)

    return new_item


# ============================================================
# READ - GET (All items)
# ============================================================

@app.get(
    "/items/",
    response_model=list[ItemResponse],
    summary="Get all items",
    tags=["CRUD Operations"]
)
def read_items():
    """
    **READ ALL** - Get a list of all items.

    This is the **R** in CRUD (reading multiple)!

    Returns all items in the inventory.
    """
    return items_db


# ============================================================
# READ - GET (Single item)
# ============================================================

@app.get(
    "/items/{item_id}",
    response_model=ItemResponse,
    summary="Get one item by ID",
    tags=["CRUD Operations"]
)
def read_item(item_id: int):
    """
    **READ ONE** - Get a specific item by its ID.

    This is the **R** in CRUD (reading one)!

    - The item_id in the URL path identifies which item to get
    - Returns 404 if item doesn't exist
    """
    item = get_item_by_id(item_id)

    if item is None:
        # Item not found - return 404 error
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Item with ID {item_id} not found"
        )

    return item


# ============================================================
# UPDATE - PUT (Full replacement)
# ============================================================

@app.put(
    "/items/{item_id}",
    response_model=ItemResponse,
    summary="Replace an item completely (PUT)",
    tags=["CRUD Operations"]
)
def update_item_put(item_id: int, item: ItemUpdate):
    """
    **UPDATE (FULL)** - Replace an entire item with new data.

    This is the **U** in CRUD using PUT!

    **IMPORTANT:** PUT replaces the ENTIRE item!
    - You must provide ALL fields
    - Any field not provided becomes null/default
    - Think of it as "delete and recreate"

    Use PUT when you want to replace everything about an item.

    **Example:**
    ```json
    {
        "name": "Gaming Laptop",
        "price": 1499.99,
        "quantity": 5,
        "description": "High-performance gaming laptop"
    }
    ```
    """
    # Find the item
    index = get_item_index(item_id)

    if index is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Item with ID {item_id} not found"
        )

    # Get existing item to preserve created_at
    existing_item = items_db[index]

    # Replace with new data (keeping id and created_at)
    updated_item = {
        "id": item_id,
        "name": item.name,
        "price": item.price,
        "quantity": item.quantity,
        "description": item.description,
        "created_at": existing_item["created_at"],  # Keep original
        "updated_at": datetime.now().isoformat()     # Update timestamp
    }

    # Replace in database
    items_db[index] = updated_item

    return updated_item


# ============================================================
# UPDATE - PATCH (Partial update)
# ============================================================

@app.patch(
    "/items/{item_id}",
    response_model=ItemResponse,
    summary="Update specific fields (PATCH)",
    tags=["CRUD Operations"]
)
def update_item_patch(item_id: int, item: ItemPatch):
    """
    **UPDATE (PARTIAL)** - Update only specific fields of an item.

    This is the **U** in CRUD using PATCH!

    **IMPORTANT:** PATCH only updates what you send!
    - Fields not included are NOT changed
    - Perfect for small updates
    - More efficient than PUT for single-field changes

    Use PATCH when you only want to change one or two fields.

    **Examples:**

    Just update price:
    ```json
    {"price": 899.99}
    ```

    Update name and quantity:
    ```json
    {"name": "New Name", "quantity": 20}
    ```
    """
    # Find the item
    index = get_item_index(item_id)

    if index is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Item with ID {item_id} not found"
        )

    # Get existing item
    existing_item = items_db[index]

    # Only update fields that were actually provided (not None)
    # This is the key difference from PUT!
    update_data = item.model_dump(exclude_unset=True)

    # Apply updates to existing item
    for field, value in update_data.items():
        existing_item[field] = value

    # Update the timestamp
    existing_item["updated_at"] = datetime.now().isoformat()

    return existing_item


# ============================================================
# DELETE
# ============================================================

@app.delete(
    "/items/{item_id}",
    summary="Delete an item",
    tags=["CRUD Operations"]
)
def delete_item(item_id: int):
    """
    **DELETE** - Remove an item from the inventory.

    This is the **D** in CRUD!

    - Permanently removes the item
    - Returns 404 if item doesn't exist
    - Returns confirmation message on success

    **Warning:** This action cannot be undone!
    """
    # Find the item
    index = get_item_index(item_id)

    if index is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Item with ID {item_id} not found"
        )

    # Remove from database
    deleted_item = items_db.pop(index)

    return {
        "message": f"Item '{deleted_item['name']}' (ID: {item_id}) deleted successfully",
        "deleted_item": deleted_item
    }


# ============================================================
# BONUS: Additional helpful endpoints
# ============================================================

@app.get(
    "/items/count/total",
    summary="Get total item count",
    tags=["Statistics"]
)
def get_item_count():
    """Get the total number of items in inventory."""
    return {
        "total_items": len(items_db),
        "total_quantity": sum(item["quantity"] for item in items_db)
    }


@app.delete(
    "/items/",
    summary="Delete all items (reset)",
    tags=["Danger Zone"]
)
def delete_all_items():
    """
    Delete ALL items from the inventory.

    **WARNING:** This removes everything!
    Useful for testing/resetting.
    """
    global items_db, item_id_counter
    count = len(items_db)
    items_db = []
    item_id_counter = 0
    return {
        "message": f"All {count} items have been deleted",
        "items_remaining": 0
    }


# ============================================================
# SEED DATA - Add some initial items
# ============================================================

@app.post(
    "/items/seed",
    summary="Add sample items",
    tags=["Setup"]
)
def seed_items():
    """
    Add some sample items to the database for testing.

    Great for getting started quickly!
    """
    global item_id_counter

    sample_items = [
        {"name": "Laptop", "price": 999.99, "quantity": 10, "description": "Powerful coding laptop"},
        {"name": "Mouse", "price": 29.99, "quantity": 50, "description": "Wireless ergonomic mouse"},
        {"name": "Keyboard", "price": 79.99, "quantity": 30, "description": "Mechanical keyboard"},
        {"name": "Monitor", "price": 299.99, "quantity": 15, "description": "27-inch 4K display"},
        {"name": "Headphones", "price": 149.99, "quantity": 25, "description": "Noise-canceling headphones"},
    ]

    created_items = []
    current_time = datetime.now().isoformat()

    for item_data in sample_items:
        item_id_counter += 1
        new_item = {
            "id": item_id_counter,
            **item_data,
            "created_at": current_time,
            "updated_at": current_time
        }
        items_db.append(new_item)
        created_items.append(new_item)

    return {
        "message": f"Added {len(created_items)} sample items",
        "items": created_items
    }


# ============================================================
# ROOT ENDPOINT
# ============================================================

@app.get("/", tags=["Info"])
def root():
    """
    Welcome page with CRUD operation guide.
    """
    return {
        "message": "Welcome to the CRUD Operations Tutorial!",
        "crud_guide": {
            "C - CREATE": "POST /items/         - Add a new item",
            "R - READ":   "GET /items/          - Get all items",
            "R - READ":   "GET /items/{id}      - Get one item",
            "U - UPDATE": "PUT /items/{id}      - Replace entire item",
            "U - UPDATE": "PATCH /items/{id}    - Update specific fields",
            "D - DELETE": "DELETE /items/{id}   - Remove an item"
        },
        "tips": [
            "Start with POST /items/seed to add sample data",
            "Use PUT when replacing everything, PATCH for partial updates",
            "Check the response codes: 201=Created, 200=OK, 404=Not Found"
        ],
        "docs": "Visit /docs for interactive API documentation"
    }


# ============================================================
# Run with: uvicorn _05_crud_example:app --reload
# ============================================================

if __name__ == "__main__":
    import uvicorn
    print("\n" + "="*60)
    print("  CRUD Operations Tutorial Server")
    print("="*60)
    print("\n  C = CREATE -> POST /items/")
    print("  R = READ   -> GET /items/ or GET /items/{id}")
    print("  U = UPDATE -> PUT /items/{id} or PATCH /items/{id}")
    print("  D = DELETE -> DELETE /items/{id}")
    print("\n  Open your browser to: http://localhost:8000/docs")
    print("  Press Ctrl+C to stop the server\n")
    uvicorn.run(app, host="127.0.0.1", port=8000)
