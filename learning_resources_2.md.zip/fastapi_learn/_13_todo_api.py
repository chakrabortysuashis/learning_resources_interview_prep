"""
Topic 13: Complete Todo API Project
===================================

This is a COMPLETE Todo API that demonstrates ALL FastAPI concepts:
- CRUD operations (Create, Read, Update, Delete)
- Pydantic validation
- Error handling with HTTPException
- Dependencies
- Background tasks
- Middleware (logging, timing, request ID)
- Lifespan events (startup/shutdown)

Run this file:
    uvicorn _13_todo_api:app --reload

Then visit:
    http://localhost:8000/docs  (Interactive API documentation)
"""

from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException, Depends, BackgroundTasks, Request, Query
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime
from enum import Enum
import uuid
import time


# =============================================================================
# PYDANTIC MODELS (Data Validation)
# =============================================================================

class Priority(int, Enum):
    """Priority levels for todos"""
    LOW = 1
    MEDIUM = 2
    NORMAL = 3
    HIGH = 4
    URGENT = 5


class TodoCreate(BaseModel):
    """
    Schema for creating a new todo.
    Used for POST /todos
    """
    title: str = Field(
        ...,  # Required field
        min_length=1,
        max_length=100,
        description="The title of the todo item",
        examples=["Buy groceries"]
    )
    description: Optional[str] = Field(
        None,
        max_length=500,
        description="Optional detailed description",
        examples=["Milk, eggs, bread, butter"]
    )
    priority: int = Field(
        default=3,
        ge=1,  # greater than or equal to 1
        le=5,  # less than or equal to 5
        description="Priority level (1=low, 5=urgent)"
    )

    model_config = {
        "json_schema_extra": {
            "examples": [
                {
                    "title": "Learn FastAPI",
                    "description": "Complete all tutorial topics",
                    "priority": 4
                }
            ]
        }
    }


class TodoUpdate(BaseModel):
    """
    Schema for updating an existing todo.
    All fields are optional - only update what's provided.
    """
    title: Optional[str] = Field(None, min_length=1, max_length=100)
    description: Optional[str] = Field(None, max_length=500)
    priority: Optional[int] = Field(None, ge=1, le=5)
    completed: Optional[bool] = None


class TodoResponse(BaseModel):
    """
    Schema for todo responses.
    This is what the API returns.
    """
    id: int
    title: str
    description: Optional[str]
    completed: bool
    priority: int
    created_at: datetime
    updated_at: datetime

    model_config = {
        "from_attributes": True  # Allow creating from ORM objects
    }


class TodoStats(BaseModel):
    """Statistics about todos"""
    total: int
    completed: int
    pending: int
    by_priority: dict


# =============================================================================
# SIMULATED DATABASE
# =============================================================================

class InMemoryDatabase:
    """
    Simple in-memory database for demonstration.
    In a real app, you'd use PostgreSQL, MongoDB, etc.
    """

    def __init__(self):
        self.todos: dict = {}
        self.next_id: int = 1
        self.connected: bool = False

    async def connect(self):
        """Simulate database connection"""
        print("DATABASE: Connecting...")
        await self._simulate_delay(0.3)
        self.connected = True
        print("DATABASE: Connected!")

    async def disconnect(self):
        """Simulate database disconnection"""
        print("DATABASE: Disconnecting...")
        await self._simulate_delay(0.2)
        self.connected = False
        print("DATABASE: Disconnected!")

    async def _simulate_delay(self, seconds: float):
        """Simulate network delay"""
        import asyncio
        await asyncio.sleep(seconds)

    def create(self, todo_data: dict) -> dict:
        """Create a new todo"""
        todo_id = self.next_id
        self.next_id += 1

        now = datetime.now()
        todo = {
            "id": todo_id,
            "title": todo_data["title"],
            "description": todo_data.get("description"),
            "completed": False,
            "priority": todo_data.get("priority", 3),
            "created_at": now,
            "updated_at": now
        }
        self.todos[todo_id] = todo
        return todo

    def get(self, todo_id: int) -> Optional[dict]:
        """Get a todo by ID"""
        return self.todos.get(todo_id)

    def get_all(
        self,
        completed: Optional[bool] = None,
        search: Optional[str] = None,
        skip: int = 0,
        limit: int = 100
    ) -> List[dict]:
        """Get all todos with filtering and pagination"""
        todos = list(self.todos.values())

        # Filter by completed status
        if completed is not None:
            todos = [t for t in todos if t["completed"] == completed]

        # Search in title and description
        if search:
            search_lower = search.lower()
            todos = [
                t for t in todos
                if search_lower in t["title"].lower() or
                   (t["description"] and search_lower in t["description"].lower())
            ]

        # Sort by priority (highest first), then by created date
        todos.sort(key=lambda t: (-t["priority"], t["created_at"]))

        # Pagination
        return todos[skip:skip + limit]

    def update(self, todo_id: int, update_data: dict) -> Optional[dict]:
        """Update a todo"""
        if todo_id not in self.todos:
            return None

        todo = self.todos[todo_id]
        for key, value in update_data.items():
            if value is not None:
                todo[key] = value
        todo["updated_at"] = datetime.now()
        return todo

    def delete(self, todo_id: int) -> bool:
        """Delete a todo"""
        if todo_id in self.todos:
            del self.todos[todo_id]
            return True
        return False

    def get_stats(self) -> dict:
        """Get statistics about todos"""
        todos = list(self.todos.values())
        completed = sum(1 for t in todos if t["completed"])

        by_priority = {i: 0 for i in range(1, 6)}
        for t in todos:
            by_priority[t["priority"]] += 1

        return {
            "total": len(todos),
            "completed": completed,
            "pending": len(todos) - completed,
            "by_priority": by_priority
        }


# Global database instance (will be initialized in lifespan)
db = InMemoryDatabase()


# =============================================================================
# BACKGROUND TASK FUNCTIONS
# =============================================================================

def send_notification(event: str, todo_title: str):
    """
    Simulates sending a notification (email, push, etc.)
    In real apps, use SendGrid, AWS SES, Firebase, etc.
    """
    print(f"\n[BACKGROUND] NOTIFICATION:")
    print(f"  Event: {event}")
    print(f"  Todo: {todo_title}")
    print(f"  Time: {datetime.now().strftime('%H:%M:%S')}")

    # Simulate sending delay
    time.sleep(0.5)

    print(f"[BACKGROUND] Notification sent!\n")


def write_audit_log(action: str, todo_id: int, details: str):
    """
    Writes to audit log for tracking changes.
    In real apps, write to file, database, or log service.
    """
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_entry = f"[{timestamp}] {action} | Todo #{todo_id} | {details}"
    print(f"[BACKGROUND] AUDIT LOG: {log_entry}")


def update_stats_cache():
    """
    Updates cached statistics.
    In real apps, update Redis cache or similar.
    """
    print("[BACKGROUND] Updating statistics cache...")
    # In real app: cache.set("todo_stats", db.get_stats())
    print("[BACKGROUND] Stats cache updated!")


# =============================================================================
# LIFESPAN EVENTS
# =============================================================================

@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Lifespan context manager handles startup and shutdown.

    STARTUP:
    - Connect to database
    - Load sample data
    - Initialize any services

    SHUTDOWN:
    - Close database connection
    - Clean up resources
    """

    # =========================================================================
    # STARTUP
    # =========================================================================
    print("\n" + "=" * 60)
    print("TODO API - STARTING UP")
    print("=" * 60)

    # Connect to database
    await db.connect()

    # Load sample data
    print("\nLoading sample todos...")
    sample_todos = [
        {"title": "Learn FastAPI basics", "description": "Complete topics 1-5", "priority": 4},
        {"title": "Build a REST API", "description": "Create CRUD endpoints", "priority": 3},
        {"title": "Add authentication", "description": "Implement JWT tokens", "priority": 5},
        {"title": "Write tests", "description": "Add pytest test cases", "priority": 2},
        {"title": "Deploy to cloud", "description": "Use Docker and Kubernetes", "priority": 1},
    ]
    for todo_data in sample_todos:
        db.create(todo_data)
    print(f"Loaded {len(sample_todos)} sample todos!")

    # Store startup time in app state
    app.state.start_time = datetime.now()
    app.state.request_count = 0

    print("\n" + "=" * 60)
    print("TODO API - READY!")
    print("Visit: http://localhost:8000/docs")
    print("=" * 60 + "\n")

    yield  # App runs here

    # =========================================================================
    # SHUTDOWN
    # =========================================================================
    print("\n" + "=" * 60)
    print("TODO API - SHUTTING DOWN")
    print("=" * 60)

    # Calculate uptime
    uptime = datetime.now() - app.state.start_time
    print(f"\nServer uptime: {uptime}")
    print(f"Total requests handled: {app.state.request_count}")

    # Disconnect from database
    await db.disconnect()

    print("\n" + "=" * 60)
    print("TODO API - GOODBYE!")
    print("=" * 60 + "\n")


# =============================================================================
# CREATE FASTAPI APP
# =============================================================================

app = FastAPI(
    title="Todo API",
    description="""
    A complete Todo API demonstrating all FastAPI concepts:

    * **CRUD Operations** - Create, Read, Update, Delete todos
    * **Validation** - Pydantic models for data validation
    * **Error Handling** - Proper HTTP error responses
    * **Background Tasks** - Notifications and logging
    * **Middleware** - Logging, timing, request tracking
    * **Lifespan Events** - Database setup and cleanup
    """,
    version="1.0.0",
    lifespan=lifespan
)


# =============================================================================
# MIDDLEWARE
# =============================================================================

@app.middleware("http")
async def timing_middleware(request: Request, call_next):
    """Measures and logs request processing time"""
    start_time = time.time()

    response = await call_next(request)

    process_time = time.time() - start_time
    response.headers["X-Process-Time"] = f"{process_time:.4f}s"

    return response


@app.middleware("http")
async def logging_middleware(request: Request, call_next):
    """Logs all requests and responses"""
    # Generate request ID
    request_id = str(uuid.uuid4())[:8]

    # Log request
    print(f"[{request_id}] --> {request.method} {request.url.path}")

    # Increment request counter
    if hasattr(request.app.state, 'request_count'):
        request.app.state.request_count += 1

    # Process request
    response = await call_next(request)

    # Add request ID to response
    response.headers["X-Request-ID"] = request_id

    # Log response
    print(f"[{request_id}] <-- {response.status_code}")

    return response


# =============================================================================
# DEPENDENCIES
# =============================================================================

def get_db() -> InMemoryDatabase:
    """
    Dependency that provides database access.
    In real apps, this would provide a database session.
    """
    if not db.connected:
        raise HTTPException(status_code=503, detail="Database not available")
    return db


def get_todo_or_404(
    todo_id: int,
    database: InMemoryDatabase = Depends(get_db)
) -> dict:
    """
    Dependency that gets a todo by ID or raises 404.
    Reusable across multiple endpoints.
    """
    todo = database.get(todo_id)
    if not todo:
        raise HTTPException(
            status_code=404,
            detail=f"Todo with ID {todo_id} not found"
        )
    return todo


# =============================================================================
# API ENDPOINTS
# =============================================================================

# -----------------------------------------------------------------------------
# Root and Health
# -----------------------------------------------------------------------------

@app.get("/", tags=["Info"])
async def root(request: Request):
    """
    API root - returns welcome message and useful links.
    """
    uptime = datetime.now() - request.app.state.start_time

    return {
        "message": "Welcome to the Todo API!",
        "version": "1.0.0",
        "uptime_seconds": round(uptime.total_seconds(), 2),
        "documentation": "/docs",
        "endpoints": {
            "list_todos": "GET /todos",
            "create_todo": "POST /todos",
            "get_todo": "GET /todos/{id}",
            "update_todo": "PUT /todos/{id}",
            "delete_todo": "DELETE /todos/{id}",
            "complete_todo": "POST /todos/{id}/complete",
            "todo_stats": "GET /todos/stats"
        }
    }


@app.get("/health", tags=["Info"])
async def health_check():
    """
    Health check endpoint for monitoring and load balancers.
    """
    return {
        "status": "healthy",
        "database": "connected" if db.connected else "disconnected",
        "timestamp": datetime.now().isoformat()
    }


# -----------------------------------------------------------------------------
# Todo CRUD Operations
# -----------------------------------------------------------------------------

@app.get("/todos", response_model=List[TodoResponse], tags=["Todos"])
async def list_todos(
    completed: Optional[bool] = Query(
        None,
        description="Filter by completion status"
    ),
    search: Optional[str] = Query(
        None,
        min_length=1,
        max_length=50,
        description="Search in title and description"
    ),
    skip: int = Query(
        0,
        ge=0,
        description="Number of items to skip (pagination)"
    ),
    limit: int = Query(
        10,
        ge=1,
        le=100,
        description="Maximum number of items to return"
    ),
    database: InMemoryDatabase = Depends(get_db)
):
    """
    List all todos with optional filtering and pagination.

    **Query Parameters:**
    - `completed`: Filter by completion status (true/false)
    - `search`: Search in title and description
    - `skip`: Skip N items (for pagination)
    - `limit`: Return at most N items

    **Examples:**
    - `/todos` - Get all todos
    - `/todos?completed=false` - Get pending todos
    - `/todos?search=learn` - Search for "learn"
    - `/todos?skip=0&limit=5` - First 5 todos
    """
    todos = database.get_all(
        completed=completed,
        search=search,
        skip=skip,
        limit=limit
    )
    return todos


@app.post("/todos", response_model=TodoResponse, status_code=201, tags=["Todos"])
async def create_todo(
    todo_data: TodoCreate,
    background_tasks: BackgroundTasks,
    database: InMemoryDatabase = Depends(get_db)
):
    """
    Create a new todo item.

    **Request Body:**
    - `title` (required): The todo title (1-100 chars)
    - `description` (optional): Detailed description (max 500 chars)
    - `priority` (optional): 1-5, where 5 is highest (default: 3)

    **Background Tasks:**
    - Sends notification about new todo
    - Writes to audit log
    - Updates statistics cache
    """
    # Create the todo
    todo = database.create(todo_data.model_dump())

    # Add background tasks
    background_tasks.add_task(
        send_notification,
        "TODO_CREATED",
        todo["title"]
    )
    background_tasks.add_task(
        write_audit_log,
        "CREATE",
        todo["id"],
        f"Created: {todo['title']}"
    )
    background_tasks.add_task(update_stats_cache)

    return todo


@app.get("/todos/stats", response_model=TodoStats, tags=["Todos"])
async def get_todo_stats(database: InMemoryDatabase = Depends(get_db)):
    """
    Get statistics about all todos.

    Returns:
    - Total count
    - Completed count
    - Pending count
    - Count by priority level
    """
    return database.get_stats()


@app.get("/todos/{todo_id}", response_model=TodoResponse, tags=["Todos"])
async def get_todo(todo: dict = Depends(get_todo_or_404)):
    """
    Get a specific todo by ID.

    **Path Parameters:**
    - `todo_id`: The unique ID of the todo

    **Errors:**
    - 404: Todo not found
    """
    return todo


@app.put("/todos/{todo_id}", response_model=TodoResponse, tags=["Todos"])
async def update_todo(
    todo_id: int,
    update_data: TodoUpdate,
    background_tasks: BackgroundTasks,
    database: InMemoryDatabase = Depends(get_db),
    existing_todo: dict = Depends(get_todo_or_404)
):
    """
    Update an existing todo.

    **Path Parameters:**
    - `todo_id`: The unique ID of the todo

    **Request Body (all optional):**
    - `title`: New title
    - `description`: New description
    - `priority`: New priority (1-5)
    - `completed`: Completion status

    Only provided fields will be updated.
    """
    # Get non-None values from update data
    update_dict = {k: v for k, v in update_data.model_dump().items() if v is not None}

    if not update_dict:
        raise HTTPException(
            status_code=400,
            detail="No fields to update provided"
        )

    # Update the todo
    updated_todo = database.update(todo_id, update_dict)

    # Background tasks
    background_tasks.add_task(
        write_audit_log,
        "UPDATE",
        todo_id,
        f"Updated fields: {list(update_dict.keys())}"
    )

    return updated_todo


@app.delete("/todos/{todo_id}", status_code=204, tags=["Todos"])
async def delete_todo(
    todo_id: int,
    background_tasks: BackgroundTasks,
    database: InMemoryDatabase = Depends(get_db),
    existing_todo: dict = Depends(get_todo_or_404)
):
    """
    Delete a todo.

    **Path Parameters:**
    - `todo_id`: The unique ID of the todo

    **Returns:**
    - 204 No Content on success
    - 404 if todo not found
    """
    # Store title before deletion for logging
    todo_title = existing_todo["title"]

    # Delete the todo
    database.delete(todo_id)

    # Background tasks
    background_tasks.add_task(
        send_notification,
        "TODO_DELETED",
        todo_title
    )
    background_tasks.add_task(
        write_audit_log,
        "DELETE",
        todo_id,
        f"Deleted: {todo_title}"
    )
    background_tasks.add_task(update_stats_cache)

    # Return None for 204 status code
    return None


@app.post("/todos/{todo_id}/complete", response_model=TodoResponse, tags=["Todos"])
async def mark_todo_complete(
    todo_id: int,
    background_tasks: BackgroundTasks,
    database: InMemoryDatabase = Depends(get_db),
    existing_todo: dict = Depends(get_todo_or_404)
):
    """
    Mark a todo as completed.

    **Path Parameters:**
    - `todo_id`: The unique ID of the todo

    **Errors:**
    - 404: Todo not found
    - 400: Todo is already completed
    """
    # Check if already completed
    if existing_todo["completed"]:
        raise HTTPException(
            status_code=400,
            detail="Todo is already marked as completed"
        )

    # Mark as completed
    updated_todo = database.update(todo_id, {"completed": True})

    # Background tasks
    background_tasks.add_task(
        send_notification,
        "TODO_COMPLETED",
        existing_todo["title"]
    )
    background_tasks.add_task(
        write_audit_log,
        "COMPLETE",
        todo_id,
        f"Completed: {existing_todo['title']}"
    )
    background_tasks.add_task(update_stats_cache)

    return updated_todo


# =============================================================================
# CUSTOM ERROR HANDLERS
# =============================================================================

@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    """
    Custom handler for HTTP exceptions.
    Adds timestamp and request path to error response.
    """
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": True,
            "status_code": exc.status_code,
            "detail": exc.detail,
            "path": str(request.url.path),
            "timestamp": datetime.now().isoformat()
        }
    )


@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    """
    Catch-all handler for unexpected errors.
    Logs the error and returns a generic message.
    """
    print(f"UNEXPECTED ERROR: {type(exc).__name__}: {str(exc)}")

    return JSONResponse(
        status_code=500,
        content={
            "error": True,
            "status_code": 500,
            "detail": "An unexpected error occurred",
            "path": str(request.url.path),
            "timestamp": datetime.now().isoformat()
        }
    )


# =============================================================================
# RUN THE SERVER
# =============================================================================

if __name__ == "__main__":
    import uvicorn

    print("""
    ============================================================
                        TODO API PROJECT
    ============================================================

    This is a COMPLETE FastAPI application demonstrating:

    - CRUD Operations (Create, Read, Update, Delete)
    - Pydantic Validation
    - Error Handling
    - Dependencies
    - Background Tasks
    - Middleware (Logging, Timing)
    - Lifespan Events (Database Setup/Cleanup)

    Starting server...

    ============================================================
    """)

    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8000,
        log_level="info"
    )
