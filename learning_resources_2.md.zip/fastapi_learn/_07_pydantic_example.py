"""
Topic 07: Pydantic Examples for FastAPI
=======================================

This file contains comprehensive examples of using Pydantic with FastAPI.
Run this file with: uvicorn _07_pydantic_example:app --reload

Then visit: http://127.0.0.1:8000/docs to test the API interactively!
"""

from fastapi import FastAPI
from pydantic import BaseModel, Field, EmailStr
from typing import Optional, List
from datetime import datetime
from enum import Enum

# Create the FastAPI application
app = FastAPI(
    title="Pydantic Learning API",
    description="Learn how to use Pydantic models with FastAPI",
    version="1.0.0"
)


# =============================================================================
# EXAMPLE 1: Basic Pydantic Model
# =============================================================================
# This is the simplest form of a Pydantic model.
# It defines what fields are required and their types.

class BasicUser(BaseModel):
    """
    A simple user model with basic fields.

    Think of this as a form with required fields:
    - name: The user's name (text)
    - age: The user's age (whole number)
    - email: The user's email (text)
    """
    name: str       # Required: must be a string (text)
    age: int        # Required: must be an integer (whole number)
    email: str      # Required: must be a string (text)


@app.post("/basic-user/", tags=["1. Basic Models"])
def create_basic_user(user: BasicUser):
    """
    Create a user with basic validation.

    Try sending:
    {
        "name": "John Doe",
        "age": 25,
        "email": "john@example.com"
    }

    This endpoint will:
    1. Automatically parse the JSON
    2. Validate all fields have correct types
    3. Return an error if validation fails
    """
    return {
        "message": "User created successfully!",
        "user_data": {
            "name": user.name,
            "age": user.age,
            "email": user.email,
            "age_next_year": user.age + 1  # We can safely do math because age is validated as int!
        }
    }


# =============================================================================
# EXAMPLE 2: Optional Fields and Default Values
# =============================================================================
# Not all fields need to be required. Some can be optional.

class ProductModel(BaseModel):
    """
    A product with required and optional fields.

    Required fields MUST be provided.
    Optional fields can be skipped (will use default value).
    """
    # REQUIRED FIELDS (no default value)
    name: str                                # Must provide a name
    price: float                             # Must provide a price

    # OPTIONAL FIELDS (have default values)
    description: Optional[str] = None        # Can be skipped, defaults to None
    in_stock: bool = True                    # Can be skipped, defaults to True
    quantity: int = 0                        # Can be skipped, defaults to 0
    tags: List[str] = []                     # Can be skipped, defaults to empty list


@app.post("/product/", tags=["2. Optional Fields"])
def create_product(product: ProductModel):
    """
    Create a product - notice some fields are optional!

    Minimal request (only required fields):
    {
        "name": "Laptop",
        "price": 999.99
    }

    Full request (all fields):
    {
        "name": "Laptop",
        "price": 999.99,
        "description": "A powerful laptop",
        "in_stock": true,
        "quantity": 50,
        "tags": ["electronics", "computers"]
    }
    """
    return {
        "message": "Product created!",
        "product": product.model_dump()  # Converts Pydantic model to dictionary
    }


# =============================================================================
# EXAMPLE 3: Field Validation with Constraints
# =============================================================================
# Use Field() to add validation rules beyond just type checking.

class StudentModel(BaseModel):
    """
    A student model with field constraints.

    Field() allows you to set rules like:
    - min_length / max_length for strings
    - ge (>=), le (<=), gt (>), lt (<) for numbers
    - pattern for regex matching
    """
    # Name must be between 2 and 50 characters
    name: str = Field(
        min_length=2,
        max_length=50,
        description="Student's full name"
    )

    # Age must be between 5 and 100
    age: int = Field(
        ge=5,       # greater than or equal to 5
        le=100,     # less than or equal to 100
        description="Student's age (5-100)"
    )

    # Grade must be between 0.0 and 100.0
    grade: float = Field(
        ge=0.0,
        le=100.0,
        description="Grade percentage (0-100)"
    )

    # Student ID must be exactly 8 characters
    student_id: str = Field(
        min_length=8,
        max_length=8,
        description="8-character student ID"
    )


@app.post("/student/", tags=["3. Field Validation"])
def create_student(student: StudentModel):
    """
    Create a student with validated fields.

    Valid request:
    {
        "name": "Alice Smith",
        "age": 16,
        "grade": 85.5,
        "student_id": "STU12345"
    }

    Invalid requests (will fail):
    - {"name": "A", ...}           <-- name too short
    - {"age": 3, ...}              <-- age below 5
    - {"grade": 150, ...}          <-- grade above 100
    - {"student_id": "ABC", ...}   <-- ID not 8 characters
    """
    # Determine grade letter
    grade_letter = "A" if student.grade >= 90 else \
                   "B" if student.grade >= 80 else \
                   "C" if student.grade >= 70 else \
                   "D" if student.grade >= 60 else "F"

    return {
        "message": "Student registered!",
        "student": student.model_dump(),
        "grade_letter": grade_letter,
        "passing": student.grade >= 60
    }


# =============================================================================
# EXAMPLE 4: Nested Models
# =============================================================================
# Models can contain other models for complex data structures.

class AddressModel(BaseModel):
    """A model for address information."""
    street: str
    city: str
    state: str
    zip_code: str
    country: str = "USA"  # Default to USA


class CompanyModel(BaseModel):
    """A model for company information."""
    name: str
    industry: str


class EmployeeModel(BaseModel):
    """
    An employee with nested address and company models.

    This shows how to create complex, nested data structures.
    """
    name: str
    email: str
    age: int

    # Nested models - these are separate Pydantic models
    address: AddressModel          # Required nested model
    company: CompanyModel          # Required nested model

    # Optional nested model
    emergency_contact: Optional[AddressModel] = None


@app.post("/employee/", tags=["4. Nested Models"])
def create_employee(employee: EmployeeModel):
    """
    Create an employee with nested address and company data.

    Example request:
    {
        "name": "Bob Johnson",
        "email": "bob@company.com",
        "age": 30,
        "address": {
            "street": "123 Main St",
            "city": "New York",
            "state": "NY",
            "zip_code": "10001"
        },
        "company": {
            "name": "Tech Corp",
            "industry": "Technology"
        }
    }
    """
    return {
        "message": "Employee created!",
        "employee_summary": f"{employee.name} works at {employee.company.name}",
        "location": f"{employee.address.city}, {employee.address.state}",
        "full_data": employee.model_dump()
    }


# =============================================================================
# EXAMPLE 5: Enums for Limited Choices
# =============================================================================
# Use Enums when a field can only have specific values.

class OrderStatus(str, Enum):
    """
    An Enum represents a fixed set of choices.

    This ensures users can only choose from these specific values:
    - pending
    - processing
    - shipped
    - delivered
    - cancelled
    """
    PENDING = "pending"
    PROCESSING = "processing"
    SHIPPED = "shipped"
    DELIVERED = "delivered"
    CANCELLED = "cancelled"


class Priority(str, Enum):
    """Priority levels for orders."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class OrderModel(BaseModel):
    """An order with enum fields for status and priority."""
    order_id: str
    customer_name: str
    total_amount: float = Field(gt=0, description="Must be greater than 0")
    status: OrderStatus = OrderStatus.PENDING  # Default to pending
    priority: Priority = Priority.MEDIUM       # Default to medium


@app.post("/order/", tags=["5. Enums"])
def create_order(order: OrderModel):
    """
    Create an order with status and priority enums.

    Status can only be: "pending", "processing", "shipped", "delivered", "cancelled"
    Priority can only be: "low", "medium", "high"

    Example:
    {
        "order_id": "ORD-001",
        "customer_name": "Jane Doe",
        "total_amount": 99.99,
        "status": "processing",
        "priority": "high"
    }

    Invalid (will fail):
    {
        "status": "unknown"  <-- Not a valid enum value!
    }
    """
    return {
        "message": "Order created!",
        "order": order.model_dump(),
        "status_value": order.status.value,  # Get the string value
        "is_urgent": order.priority == Priority.HIGH
    }


# =============================================================================
# EXAMPLE 6: Lists and Complex Types
# =============================================================================
# Models can contain lists of primitive types or other models.

class TagModel(BaseModel):
    """A simple tag with name and color."""
    name: str
    color: str = "blue"


class BlogPostModel(BaseModel):
    """
    A blog post with various list types.

    Shows how to use:
    - List[str] for a list of strings
    - List[TagModel] for a list of Pydantic models
    """
    title: str = Field(min_length=5, max_length=200)
    content: str = Field(min_length=10)
    author: str

    # List of strings
    categories: List[str] = []

    # List of Pydantic models
    tags: List[TagModel] = []

    # Optional timestamp
    published_at: Optional[datetime] = None


@app.post("/blog-post/", tags=["6. Lists"])
def create_blog_post(post: BlogPostModel):
    """
    Create a blog post with lists of tags and categories.

    Example:
    {
        "title": "Learning FastAPI",
        "content": "FastAPI is an amazing framework for building APIs...",
        "author": "John Developer",
        "categories": ["programming", "python", "web"],
        "tags": [
            {"name": "fastapi", "color": "green"},
            {"name": "tutorial", "color": "blue"}
        ]
    }
    """
    return {
        "message": "Blog post created!",
        "post_summary": {
            "title": post.title,
            "author": post.author,
            "word_count": len(post.content.split()),
            "category_count": len(post.categories),
            "tag_count": len(post.tags),
            "tag_names": [tag.name for tag in post.tags]
        }
    }


# =============================================================================
# EXAMPLE 7: Email Validation (Special Type)
# =============================================================================
# Pydantic has special types for common patterns like emails.
# Note: You need to install 'email-validator': pip install email-validator

class UserWithEmail(BaseModel):
    """
    A user model with proper email validation.

    EmailStr validates that the string is a proper email format.
    This catches invalid emails like:
    - "not-an-email"
    - "missing@domain"
    - "@nodomain.com"
    """
    username: str = Field(min_length=3, max_length=20)
    email: EmailStr  # Special type that validates email format
    full_name: Optional[str] = None


@app.post("/user-email/", tags=["7. Email Validation"])
def create_user_with_email(user: UserWithEmail):
    """
    Create a user with email validation.

    Valid emails:
    - "user@example.com"
    - "john.doe@company.org"

    Invalid emails (will fail):
    - "not-an-email"
    - "missing@"
    - "@nodomain.com"

    Example:
    {
        "username": "johndoe",
        "email": "john@example.com",
        "full_name": "John Doe"
    }
    """
    return {
        "message": "User created with valid email!",
        "user": user.model_dump(),
        "email_domain": user.email.split("@")[1]  # Extract domain from email
    }


# =============================================================================
# EXAMPLE 8: Model with Example Values
# =============================================================================
# You can provide example values that appear in the API documentation.

class BookModel(BaseModel):
    """
    A book model with example values for documentation.

    The model_config with json_schema_extra provides examples
    that appear in the interactive API docs.
    """
    title: str = Field(description="The title of the book")
    author: str = Field(description="The author's name")
    isbn: str = Field(min_length=10, max_length=13, description="ISBN number")
    pages: int = Field(gt=0, description="Number of pages")
    price: float = Field(gt=0, description="Price in dollars")
    genres: List[str] = Field(default=[], description="List of genres")

    # Provide example values for the documentation
    model_config = {
        "json_schema_extra": {
            "examples": [
                {
                    "title": "The Python Handbook",
                    "author": "Jane Smith",
                    "isbn": "1234567890",
                    "pages": 350,
                    "price": 29.99,
                    "genres": ["programming", "education"]
                }
            ]
        }
    }


@app.post("/book/", tags=["8. Examples in Docs"])
def create_book(book: BookModel):
    """
    Create a book - check the docs for example values!

    Click "Try it out" in the docs and see the pre-filled example.
    """
    return {
        "message": "Book added to library!",
        "book": book.model_dump(),
        "price_with_tax": round(book.price * 1.08, 2)  # 8% tax
    }


# =============================================================================
# EXAMPLE 9: Request Body + Path/Query Parameters Combined
# =============================================================================
# You can use Pydantic models alongside path and query parameters.

class UpdateUserModel(BaseModel):
    """Model for updating user information."""
    name: Optional[str] = None
    email: Optional[str] = None
    bio: Optional[str] = None


@app.put("/users/{user_id}", tags=["9. Combined Parameters"])
def update_user(
    user_id: int,                           # Path parameter
    notify: bool = False,                   # Query parameter
    user_data: UpdateUserModel = None       # Request body (Pydantic model)
):
    """
    Update a user - combines path, query, and body parameters.

    - user_id: Comes from the URL path (e.g., /users/42)
    - notify: Comes from query string (e.g., ?notify=true)
    - user_data: Comes from the JSON request body

    Example URL: PUT /users/42?notify=true
    Example Body:
    {
        "name": "Updated Name",
        "email": "newemail@example.com"
    }
    """
    result = {
        "message": f"User {user_id} updated!",
        "user_id": user_id,
        "notification_sent": notify,
    }

    if user_data:
        # Only include fields that were actually provided
        updates = {k: v for k, v in user_data.model_dump().items() if v is not None}
        result["updates_applied"] = updates

    return result


# =============================================================================
# EXAMPLE 10: Response Model (Controlling Output)
# =============================================================================
# You can use Pydantic models to control what data is returned.

class UserInput(BaseModel):
    """What the user sends to create an account."""
    username: str
    password: str  # We receive the password...
    email: str


class UserOutput(BaseModel):
    """What we send back - notice password is NOT included!"""
    id: int
    username: str
    email: str
    # NO password field - we don't want to send it back!


# Fake database for demonstration
fake_users_db = {}
user_id_counter = 1


@app.post("/signup/", response_model=UserOutput, tags=["10. Response Models"])
def signup(user: UserInput):
    """
    Sign up a new user.

    Notice: We receive the password but DON'T return it!
    The response_model=UserOutput ensures only safe fields are returned.

    Send:
    {
        "username": "newuser",
        "password": "secret123",
        "email": "new@example.com"
    }

    Receive (password excluded!):
    {
        "id": 1,
        "username": "newuser",
        "email": "new@example.com"
    }
    """
    global user_id_counter

    # In real app, you would hash the password!
    new_user = {
        "id": user_id_counter,
        "username": user.username,
        "password": user.password,  # Stored but not returned
        "email": user.email
    }

    fake_users_db[user_id_counter] = new_user
    user_id_counter += 1

    # Even though we return the full dict, FastAPI will filter it
    # based on the response_model=UserOutput
    return new_user


# =============================================================================
# ROOT ENDPOINT - Welcome Message
# =============================================================================

@app.get("/", tags=["Home"])
def home():
    """
    Welcome to the Pydantic Examples API!

    Visit /docs to see all endpoints and try them interactively.
    """
    return {
        "message": "Welcome to the Pydantic Examples API!",
        "documentation": "Visit /docs to explore all examples",
        "examples": [
            "POST /basic-user/ - Basic Pydantic model",
            "POST /product/ - Optional fields",
            "POST /student/ - Field validation",
            "POST /employee/ - Nested models",
            "POST /order/ - Enums",
            "POST /blog-post/ - Lists",
            "POST /user-email/ - Email validation",
            "POST /book/ - Example values",
            "PUT /users/{id} - Combined parameters",
            "POST /signup/ - Response models"
        ]
    }


# =============================================================================
# HOW TO RUN THIS FILE
# =============================================================================
"""
To run this example:

1. Make sure you have FastAPI and Uvicorn installed:
   pip install fastapi uvicorn[standard] email-validator

2. Run the server:
   uvicorn _07_pydantic_example:app --reload

3. Open your browser and go to:
   http://127.0.0.1:8000/docs

4. Try each endpoint! Click "Try it out", modify the JSON, and see what happens.

THINGS TO EXPERIMENT WITH:
- Try sending invalid data (wrong types, missing fields)
- See how Pydantic gives clear error messages
- Notice how optional fields work
- Try the enum fields with invalid values
- Check how response models filter sensitive data
"""
