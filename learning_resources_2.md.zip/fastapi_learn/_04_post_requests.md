# Topic 04: POST Requests in FastAPI

## What is a POST Request?

Think of HTTP requests like sending mail:

- **GET Request** = Reading a letter (you're just looking at information)
- **POST Request** = Sending a package (you're delivering something new)

When you use POST, you're **sending data TO the server** to create something new!

```
+------------------+                              +------------------+
|                  |   POST /students             |                  |
|     CLIENT       |   Body: {"name": "Alice"}    |     SERVER       |
|   (Your App)     |  =========================>  |   (FastAPI)      |
|                  |                              |                  |
|                  |   201 Created                |                  |
|                  |   {"id": 1, "name": "Alice"} |                  |
|                  |  <==========================  |                  |
+------------------+                              +------------------+
```

---

## GET vs POST: The Key Differences

| Feature | GET | POST |
|---------|-----|------|
| Purpose | Retrieve/read data | Create/send data |
| Data Location | In the URL | In the request body |
| Visibility | Everyone can see it | Hidden in the body |
| Bookmarkable? | Yes | No |
| Data Size | Limited (~2000 chars) | Virtually unlimited |
| Safe to repeat? | Yes | No (creates duplicates!) |

### Real-World Analogy: The Library

```
GET Request = "Can I see the book catalog?"
              (Just reading, nothing changes)

POST Request = "I want to donate a new book!"
               (Adding something new to the library)
```

---

## When to Use POST?

Use POST when you want to:

1. **Create new resources** (new user, new order, new comment)
2. **Submit forms** (login forms, registration forms)
3. **Send sensitive data** (passwords, credit cards)
4. **Upload files** (images, documents)

```
+-----------------------------------------------------------+
|                    WHEN TO USE POST                        |
+-----------------------------------------------------------+
|                                                           |
|   [x] Creating a new account                              |
|   [x] Submitting a contact form                           |
|   [x] Placing an order                                    |
|   [x] Uploading a profile picture                         |
|   [x] Logging in with username/password                   |
|                                                           |
+-----------------------------------------------------------+
```

---

## How POST Requests Work (Step by Step)

```
STEP 1: Client prepares data
+--------------------------------+
|  {                             |
|    "name": "Alice",            |
|    "email": "alice@email.com", |
|    "age": 16                   |
|  }                             |
+--------------------------------+
        |
        | Package into JSON
        v
STEP 2: Send POST request
+--------------------------------+
|  POST /api/students HTTP/1.1   |
|  Content-Type: application/json|
|                                |
|  {"name":"Alice",...}          |
+--------------------------------+
        |
        | Internet magic!
        v
STEP 3: Server receives & processes
+--------------------------------+
|  FastAPI:                      |
|  1. Receives the data          |
|  2. Validates it (Pydantic!)   |
|  3. Saves to database          |
|  4. Returns response           |
+--------------------------------+
        |
        v
STEP 4: Client gets response
+--------------------------------+
|  Status: 201 Created           |
|  {                             |
|    "id": 1,                    |
|    "name": "Alice",            |
|    "message": "Student added!" |
|  }                             |
+--------------------------------+
```

---

## The Request Body

The **body** is where POST data lives. It's like a hidden compartment in your package:

```
+--------------------------------------------------+
|                   HTTP REQUEST                    |
+--------------------------------------------------+
|  POST /students HTTP/1.1       <- Method & URL   |
|  Host: localhost:8000          <- Headers start  |
|  Content-Type: application/json                  |
|  Content-Length: 45                              |
|                                 <- Empty line    |
|  {"name": "Alice", "age": 16}  <- BODY (hidden!) |
+--------------------------------------------------+

Compare to GET:
+--------------------------------------------------+
|                   HTTP REQUEST                    |
+--------------------------------------------------+
|  GET /students?name=Alice&age=16  <- ALL in URL! |
|  Host: localhost:8000                            |
|                                                  |
|  (no body - everything visible in URL!)          |
+--------------------------------------------------+
```

---

## Pydantic Models: Your Data Bodyguard

FastAPI uses **Pydantic models** to validate POST data. Think of Pydantic as a strict security guard:

```
                    Incoming Data
                          |
                          v
              +---------------------+
              |   PYDANTIC GUARD    |
              |                     |
              |  "Let me check..."  |
              |                     |
              |  [x] name is string?|
              |  [x] age is number? |
              |  [x] email valid?   |
              +---------------------+
                    /         \
                   /           \
            VALID!            INVALID!
               |                  |
               v                  v
        +----------+       +------------+
        | Continue |       | 422 Error  |
        | to API   |       | "Bad data!"|
        +----------+       +------------+
```

### Why Pydantic is Awesome:

1. **Auto-validation**: Checks data types automatically
2. **Clear errors**: Tells users exactly what's wrong
3. **Documentation**: Auto-generates API docs
4. **Type hints**: Your IDE helps you code

---

## Status Codes for POST

```
+-------+-------------------+--------------------------------+
| Code  | Name              | Meaning                        |
+-------+-------------------+--------------------------------+
| 200   | OK                | Success (general)              |
| 201   | Created           | New resource was created!      |
| 400   | Bad Request       | Client sent garbage data       |
| 422   | Unprocessable     | Valid JSON but wrong format    |
+-------+-------------------+--------------------------------+

Most common for POST:
  - 201 Created  -> "Yay! Your thing was made!"
  - 422 Error    -> "Your data doesn't match what I need"
```

---

## Security Note: Why POST for Sensitive Data?

```
GET with password (BAD!):
+----------------------------------------------------------+
| Browser URL: https://site.com/login?password=secret123   |
|                                                          |
| Problems:                                                |
|   - Visible in browser history                           |
|   - Saved in server logs                                 |
|   - Can be seen by anyone looking at screen              |
|   - Shared if you share the URL                          |
+----------------------------------------------------------+

POST with password (GOOD!):
+----------------------------------------------------------+
| Browser URL: https://site.com/login                      |
| Body: {"password": "secret123"}  <- Hidden!              |
|                                                          |
| Benefits:                                                |
|   - Not in browser history                               |
|   - Not in URL (harder to see)                           |
|   - More secure (when combined with HTTPS)               |
+----------------------------------------------------------+
```

---

## Quick Summary

```
+----------------------------------------------------------+
|                    POST REQUESTS                          |
+----------------------------------------------------------+
|                                                          |
|  WHAT:    Sends data TO the server                       |
|                                                          |
|  WHERE:   Data goes in the request BODY                  |
|                                                          |
|  WHEN:    Creating new things, submitting forms          |
|                                                          |
|  HOW:     Use Pydantic models to define data structure   |
|                                                          |
|  RESULT:  Usually returns 201 Created on success         |
|                                                          |
+----------------------------------------------------------+
```

---

## Try It Yourself!

1. Run the `_04_post_examples.py` file
2. Open `http://localhost:8000/docs` in your browser
3. Click on a POST endpoint
4. Click "Try it out"
5. Modify the JSON data and click "Execute"
6. Watch the response!

```
Challenge Questions:
  1. What happens if you send a POST without a required field?
  2. What if you send "age": "sixteen" instead of "age": 16?
  3. Can you create a POST endpoint for a new "Book" model?
```

---

Next up: Topic 05 - CRUD Operations (PUT, DELETE, PATCH)!
