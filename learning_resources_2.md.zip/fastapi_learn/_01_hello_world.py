"""
=============================================================================
TOPIC 01: Hello World with FastAPI
=============================================================================

This is your FIRST FastAPI application!

Think of this like learning to say "Hello" in a new language -
it's the simplest thing you can do, but it teaches you the basics.

HOW TO RUN THIS FILE:
    1. Open terminal/command prompt
    2. Navigate to this folder
    3. Run: uvicorn _01_hello_world:app --reload
    4. Open browser: http://localhost:8000

=============================================================================
"""

# =============================================================================
# STEP 1: Import FastAPI
# =============================================================================
# This is like getting your toolbox ready before starting work.
# FastAPI is the main tool we need.

from fastapi import FastAPI


# =============================================================================
# STEP 2: Create the Application
# =============================================================================
# This creates our FastAPI "app" - think of it as opening a new restaurant.
# The app will handle all incoming requests (customers).

app = FastAPI(
    title="My First FastAPI App",           # Name shown in documentation
    description="Learning FastAPI basics",   # Description in documentation
    version="1.0.0"                          # Version number
)

# You can also create a simple app without any parameters:
# app = FastAPI()


# =============================================================================
# STEP 3: Create Your First Route (Endpoint)
# =============================================================================
# A "route" is like a menu item in a restaurant.
# When someone visits a specific URL, they get a specific response.

# The @app.get("/") is a "decorator" - it tells FastAPI:
# "When someone visits the home page (/), run the function below"

@app.get("/")
def home():
    """
    The Home Page

    This function runs when someone visits: http://localhost:8000/

    Returns a simple welcome message in JSON format.
    """
    return {"message": "Hello, World! Welcome to FastAPI!"}


# =============================================================================
# STEP 4: Add More Routes
# =============================================================================
# Let's add a few more routes to practice!

@app.get("/about")
def about():
    """
    About Page

    Visit: http://localhost:8000/about
    """
    return {
        "app_name": "FastAPI Learning",
        "author": "A Beginner",
        "purpose": "Learning how FastAPI works"
    }


@app.get("/greet")
def greet():
    """
    Simple Greeting

    Visit: http://localhost:8000/greet
    """
    return {"greeting": "Hi there! Nice to meet you!"}


# =============================================================================
# STEP 5: Route with a Path Parameter
# =============================================================================
# Sometimes we want to include a variable in the URL.
# For example: /hello/Alice or /hello/Bob
# The {name} part is a "path parameter" - it changes based on what you type!

@app.get("/hello/{name}")
def hello_name(name: str):
    """
    Personalized Hello

    The {name} in the route becomes a variable!

    Examples:
        - http://localhost:8000/hello/Alice  -> "Hello, Alice!"
        - http://localhost:8000/hello/Bob    -> "Hello, Bob!"
        - http://localhost:8000/hello/World  -> "Hello, World!"

    Args:
        name (str): The name to greet (comes from the URL)
    """
    return {"message": f"Hello, {name}!"}


# =============================================================================
# STEP 6: Route with Type Validation
# =============================================================================
# FastAPI can automatically check if the input is the right type!
# If you say the parameter should be an integer (int), FastAPI validates it.

@app.get("/square/{number}")
def square_number(number: int):
    """
    Square a Number

    This route takes a NUMBER, not just any text.
    FastAPI will automatically:
        1. Check if it's a valid integer
        2. Return an error if it's not
        3. Convert the string from URL to an actual integer

    Examples:
        - http://localhost:8000/square/5   -> {"number": 5, "square": 25}
        - http://localhost:8000/square/10  -> {"number": 10, "square": 100}
        - http://localhost:8000/square/abc -> ERROR! (not a number)

    Args:
        number (int): The number to square (FastAPI validates this!)
    """
    result = number * number
    return {
        "number": number,
        "square": result
    }


# =============================================================================
# BONUS: Multiple Routes for the Same Function
# =============================================================================
# You can have multiple URLs point to the same function!

@app.get("/ping")
@app.get("/health")
@app.get("/status")
def health_check():
    """
    Health Check Endpoint

    This is a common pattern - APIs often have a "health check" endpoint
    that tells you if the server is running.

    Visit any of these:
        - http://localhost:8000/ping
        - http://localhost:8000/health
        - http://localhost:8000/status
    """
    return {"status": "OK", "message": "Server is running!"}


# =============================================================================
# WHAT YOU LEARNED
# =============================================================================
"""
After running this file, you've learned:

1. How to import and create a FastAPI app
2. How to create routes using @app.get("/path")
3. How to return JSON data (just return a dictionary!)
4. How to use path parameters like {name}
5. How to add type hints for automatic validation

NEXT STEPS - Try these experiments:

    1. Change the welcome message in the home() function

    2. Add a new route called "/goodbye/{name}" that says goodbye

    3. Create a route "/add/{a}/{b}" that adds two numbers
       Hint: def add(a: int, b: int): return {"sum": a + b}

    4. Visit http://localhost:8000/docs to see automatic documentation!

    5. Try going to http://localhost:8000/square/hello
       and see how FastAPI handles the error!

REMEMBER:
    - Run with: uvicorn _01_hello_world:app --reload
    - The --reload flag means it auto-restarts when you save changes
    - Check http://localhost:8000/docs for interactive documentation
"""


# =============================================================================
# ASCII DIAGRAM: How This File Works
# =============================================================================
"""
    Your Code                         What Happens
    =========                         ============

    @app.get("/")         ------>     Register route "/" in FastAPI
    def home():
        return {...}      ------>     When visited, return this JSON


    When Someone Visits http://localhost:8000/hello/Alice:

    +-------------+     +-----------+     +------------+     +-------------+
    |   Browser   | --> |  Uvicorn  | --> |  FastAPI   | --> | Your        |
    |   Request   |     |  Server   |     |  Router    |     | Function    |
    +-------------+     +-----------+     +------------+     +-------------+
          |                                     |                   |
          |                                     |    name = "Alice" |
          |                                     v                   v
          |                              Find matching        Execute:
          |                              route: /hello/{name}  hello_name("Alice")
          |                                     |                   |
          |                                     v                   v
          |                              +---------------------------------+
          |                              | {"message": "Hello, Alice!"}    |
          |                              +---------------------------------+
          |                                          |
          v                                          v
    +-------------+     <--------------------     Response sent
    |   Browser   |        JSON Response          back to user
    |   Display   |
    +-------------+
"""
