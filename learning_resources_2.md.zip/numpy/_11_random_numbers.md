# Random Numbers in NumPy

## The np.random Module

NumPy's random module generates random numbers for simulations, testing, and more!

```python
import numpy as np

# Set seed for reproducibility (same "random" numbers every time)
np.random.seed(42)
```

## Random Floats (0 to 1)

```python
# Single random float between 0 and 1
np.random.random()  # 0.3745...

# Array of random floats
np.random.random(5)  # 5 random numbers
np.random.random((2, 3))  # 2x3 array
```

### Visual: Random Floats

```
np.random.random(5):
[0.37, 0.95, 0.73, 0.59, 0.15]
  |     |     |     |     |
  All between 0 and 1
```

## Random Integers

```python
# Random integer from 0 to 9
np.random.randint(10)

# Random integer from 5 to 15 (15 not included)
np.random.randint(5, 15)

# Array of random integers
np.random.randint(1, 100, size=5)  # 5 random ints from 1-99
np.random.randint(1, 7, size=(3, 4))  # 3x4 array, dice rolls (1-6)
```

### Visual: randint

```
np.random.randint(1, 7, size=6):   # Simulating 6 dice rolls
[3, 5, 1, 6, 2, 4]
 |  |  |  |  |  |
 All between 1 and 6 (inclusive)
```

## Random from Normal Distribution

```python
# Standard normal (mean=0, std=1)
np.random.randn(5)  # 5 values from standard normal

# Custom normal distribution
np.random.normal(loc=100, scale=15, size=5)  # mean=100, std=15
```

### Visual: Normal Distribution

```
                    *****
                 ***     ***
              ***           ***
           **                  **
        **                        **
     *                               *
  ---+---+---+---+---+---+---+---+---+---
    70   80   90  100  110  120  130
                   ^
                 mean
              
Most values cluster around the mean!
```

## Random from Uniform Distribution

```python
# Uniform between a and b
np.random.uniform(0, 10, size=5)  # 5 floats between 0 and 10
np.random.uniform(-1, 1, size=(2, 3))  # 2x3 array, -1 to 1
```

### Visual: Uniform vs Normal

```
Uniform (all equally likely):    Normal (bell curve):
|||||||||||||||||||||            .
|||||||||||||||||||||         ..   ..
|||||||||||||||||||||       ..       ..
|||||||||||||||||||||     ..           ..
+---------------------    +--------------+
  a                 b     mean-3std  mean+3std
```

## Shuffling and Choosing

```python
arr = np.array([1, 2, 3, 4, 5])

# Shuffle in place
np.random.shuffle(arr)
print(arr)  # [3, 1, 5, 2, 4] (example)

# Random choice from array
np.random.choice(arr)  # Pick one
np.random.choice(arr, size=3)  # Pick 3 (with replacement)
np.random.choice(arr, size=3, replace=False)  # Pick 3 (no repeats)
```

### Visual: Choice

```
arr = [1, 2, 3, 4, 5]

np.random.choice(arr, size=3):
Pick 1: [2] <- can pick any
Pick 2: [2] <- can pick 2 again!
Pick 3: [5]
Result: [2, 2, 5]

np.random.choice(arr, size=3, replace=False):
Pick 1: [2] <- picked, now removed from pool
Pick 2: [5] <- can't pick 2 again
Pick 3: [1]
Result: [2, 5, 1]
```

## Random Permutation

```python
# Return a shuffled copy (original unchanged)
arr = np.array([1, 2, 3, 4, 5])
shuffled = np.random.permutation(arr)
print(arr)      # [1, 2, 3, 4, 5] (original unchanged)
print(shuffled) # [3, 1, 5, 2, 4] (shuffled copy)

# Works with integers too
np.random.permutation(5)  # Shuffled [0, 1, 2, 3, 4]
```

## Setting Seeds for Reproducibility

```python
# Same seed = same "random" numbers
np.random.seed(42)
print(np.random.randint(1, 100, 5))  # Always: [52 93 15 72 61]

np.random.seed(42)
print(np.random.randint(1, 100, 5))  # Same: [52 93 15 72 61]
```

### Why Use Seeds?

```
Without seed:
Run 1: [23, 67, 45, 12, 89]
Run 2: [56, 34, 78, 90, 11]  <- Different every time!

With seed(42):
Run 1: [52, 93, 15, 72, 61]
Run 2: [52, 93, 15, 72, 61]  <- Same! Reproducible!
```

## Common Random Functions Summary

| Function | What It Does | Example |
|----------|--------------|---------|
| `random()` | Float 0-1 | 0.374 |
| `randint(low, high)` | Integer low to high-1 | 1-6 for dice |
| `randn()` | Standard normal | mean=0, std=1 |
| `normal(mean, std)` | Custom normal | IQ scores: mean=100, std=15 |
| `uniform(low, high)` | Float in range | 0.0 to 10.0 |
| `choice(arr)` | Pick from array | Random element |
| `shuffle(arr)` | Shuffle in place | Modifies array |
| `permutation(arr)` | Shuffled copy | New array |
| `seed(n)` | Set random seed | Reproducibility |

## Practical Examples

### Example 1: Simulate Dice Rolls

```python
# Roll a die 10 times
rolls = np.random.randint(1, 7, size=10)
print("Rolls:", rolls)
print("Sum:", rolls.sum())
```

### Example 2: Generate Test Scores

```python
# 30 students, scores normally distributed
# mean=75, std=10
scores = np.random.normal(75, 10, size=30)
scores = np.clip(scores, 0, 100)  # Keep between 0-100
scores = np.round(scores)
print("Scores:", scores)
```

### Example 3: Random Sample

```python
# Pick 5 random students from class of 30
students = np.arange(1, 31)  # Students 1-30
sample = np.random.choice(students, size=5, replace=False)
print("Selected students:", sample)
```

## Common Mistakes

| Mistake | Problem | Fix |
|---------|---------|-----|
| `randint(1, 6)` for dice | 6 not included! | Use `randint(1, 7)` |
| Forgetting `size=` | Gets single value | Add `size=n` |
| Not setting seed | Results change | Use `seed(42)` for testing |
| `shuffle()` returns None | Shuffles in place | Use `permutation()` for copy |

## Try It Yourself

1. Generate 10 random integers between 1 and 100
2. Create a 3x3 array of random floats
3. Simulate 100 coin flips (0 or 1)
4. Generate 50 test scores with mean 70, std 15
5. Randomly select 3 items from a list without replacement
