# Basic Operations in NumPy

## The Magic of Element-wise Operations

NumPy performs operations on **every element at once** - no loops needed!

```
Python List (need loop):     NumPy Array (automatic):
[1, 2, 3] * 2                [1, 2, 3] * 2
    |                              |
    v                              v
[1, 2, 3, 1, 2, 3]           [2, 4, 6]
(repeats list!)              (multiplies each!)
```

## Basic Math Operations

```python
import numpy as np

a = np.array([10, 20, 30, 40])

# Arithmetic with scalars (single numbers)
print(a + 5)   # [15 25 35 45]
print(a - 5)   # [5 15 25 35]
print(a * 2)   # [20 40 60 80]
print(a / 2)   # [5. 10. 15. 20.]
print(a ** 2)  # [100 400 900 1600]
print(a % 3)   # [1 2 0 1] (remainder)
print(a // 3)  # [3 6 10 13] (floor division)
```

### Visual: How It Works

```
Array:    [10, 20, 30, 40]
           |   |   |   |
Operation: +5  +5  +5  +5
           |   |   |   |
Result:   [15, 25, 35, 45]

Each element is processed independently!
```

## Array-to-Array Operations

When operating on two arrays, operations happen element-by-element:

```python
a = np.array([1, 2, 3, 4])
b = np.array([10, 20, 30, 40])

print(a + b)   # [11 22 33 44]
print(b - a)   # [9 18 27 36]
print(a * b)   # [10 40 90 160]
print(b / a)   # [10. 10. 10. 10.]
```

### Visual: Array + Array

```
Array a:  [1,  2,  3,  4]
           +   +   +   +
Array b:  [10, 20, 30, 40]
           =   =   =   =
Result:   [11, 22, 33, 44]

Position 0: 1 + 10 = 11
Position 1: 2 + 20 = 22
... and so on
```

## Universal Functions (ufuncs)

NumPy has special fast functions for common operations:

```python
arr = np.array([1, 4, 9, 16, 25])

# Square root
print(np.sqrt(arr))  # [1. 2. 3. 4. 5.]

# Absolute value
print(np.abs(np.array([-1, -2, 3])))  # [1 2 3]

# Exponential (e^x)
print(np.exp([0, 1, 2]))  # [1. 2.718... 7.389...]

# Natural log
print(np.log([1, 2.718, 7.389]))  # [0. ~1. ~2.]

# Trigonometry
angles = np.array([0, np.pi/2, np.pi])
print(np.sin(angles))  # [0. 1. 0.]
print(np.cos(angles))  # [1. 0. -1.]
```

## Comparison Operations

Returns boolean arrays (True/False for each element):

```python
arr = np.array([1, 2, 3, 4, 5])

print(arr > 3)   # [False False False True True]
print(arr == 3)  # [False False True False False]
print(arr <= 2)  # [True True False False False]
print(arr != 3)  # [True True False True True]
```

### Visual: Comparison

```
Array:      [1,    2,    3,    4,    5]
Compare:    >3    >3    >3    >3    >3
Result:   [False False False True  True]
```

## 2D Array Operations

Works the same way with 2D arrays!

```python
arr2d = np.array([[1, 2, 3],
                  [4, 5, 6]])

# Scalar operations
print(arr2d * 10)
# [[10 20 30]
#  [40 50 60]]

# Array operations
other = np.array([[1, 1, 1],
                  [2, 2, 2]])
print(arr2d + other)
# [[2 3 4]
#  [6 7 8]]
```

## Common Math Functions Summary

### Arithmetic

| Operation | Symbol | Example |
|-----------|--------|---------|
| Add | `+` or `np.add` | `a + b` |
| Subtract | `-` or `np.subtract` | `a - b` |
| Multiply | `*` or `np.multiply` | `a * b` |
| Divide | `/` or `np.divide` | `a / b` |
| Power | `**` or `np.power` | `a ** 2` |
| Floor divide | `//` | `a // b` |
| Modulo | `%` or `np.mod` | `a % b` |

### Math Functions

| Function | What It Does | Example |
|----------|--------------|---------|
| `np.sqrt()` | Square root | `np.sqrt(16)` = 4 |
| `np.abs()` | Absolute value | `np.abs(-5)` = 5 |
| `np.exp()` | e^x | `np.exp(1)` = 2.718... |
| `np.log()` | Natural log | `np.log(2.718)` = ~1 |
| `np.log10()` | Log base 10 | `np.log10(100)` = 2 |
| `np.sin()` | Sine | `np.sin(0)` = 0 |
| `np.cos()` | Cosine | `np.cos(0)` = 1 |
| `np.round()` | Round | `np.round(3.7)` = 4 |

## Common Mistakes

| Mistake | Problem | Fix |
|---------|---------|-----|
| `a + b` with different shapes | Shape mismatch | Ensure same shape or use broadcasting |
| `1/arr` when arr has 0 | Division by zero | Results in `inf`, check first |
| Expecting Python list behavior | `[1,2,3] * 2` = `[1,2,3,1,2,3]` | Use `np.array()` |

## Try It Yourself

1. Create two arrays and add them
2. Square every element in an array
3. Find the square root of numbers 1-10
4. Compare an array to 5 (find which elements are > 5)
5. Calculate the sine of angles 0, 30, 45, 60, 90 degrees
