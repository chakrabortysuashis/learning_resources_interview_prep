# Introduction to NumPy

## What is NumPy?

NumPy (Numerical Python) is like a **super-powered calculator** for Python. While regular Python lists are great for storing data, NumPy arrays are designed specifically for math and science.

Think of it this way:
- **Regular Python list** = A regular backpack (holds stuff, but not optimized)
- **NumPy array** = A specialized sports bag (designed for specific purpose, way more efficient)

```
Regular Python List          NumPy Array
[1, 2, 3, 4, 5]             array([1, 2, 3, 4, 5])
     |                              |
     v                              v
Slower math operations      Lightning-fast math!
```

## Why Use NumPy?

### Speed Comparison

```
Python List:  [1, 2, 3, 4, 5]  +  [1, 2, 3, 4, 5]  = [1, 2, 3, 4, 5, 1, 2, 3, 4, 5]
                                                      (concatenation, not math!)

NumPy Array:  [1, 2, 3, 4, 5]  +  [1, 2, 3, 4, 5]  = [2, 4, 6, 8, 10]
                                                      (actual addition!)
```

### Key Benefits

- **Speed**: 50-100x faster than Python lists for math
- **Memory efficient**: Uses less computer memory
- **Convenient**: One line of code does what takes 10 lines with lists
- **Foundation**: Pandas, TensorFlow, and other libraries are built on NumPy

## Installation

```bash
pip install numpy
```

Or if you have Anaconda:
```bash
conda install numpy
```

## Your First NumPy Array

```python
import numpy as np  # We use 'np' as a shortcut

# Create your first array
my_array = np.array([1, 2, 3, 4, 5])
print(my_array)  # Output: [1 2 3 4 5]

# Notice: no commas between numbers in the output!
```

## Quick Comparison: List vs Array

```python
# Python List
python_list = [1, 2, 3, 4, 5]
# To double each number, you need a loop:
doubled = [x * 2 for x in python_list]

# NumPy Array
numpy_array = np.array([1, 2, 3, 4, 5])
# To double each number, just multiply!
doubled = numpy_array * 2  # That's it!
```

## Visual: How NumPy Stores Data

```
Python List (scattered in memory):
+---+     +---+     +---+     +---+
| 1 | --> | 2 | --> | 3 | --> | 4 |
+---+     +---+     +---+     +---+
  (pointers jumping around)

NumPy Array (continuous in memory):
+---+---+---+---+
| 1 | 2 | 3 | 4 |
+---+---+---+---+
  (all together = FAST!)
```

## Key Takeaways

- NumPy is essential for data science and scientific computing
- Arrays are faster and more memory-efficient than lists
- Import with `import numpy as np`
- Create arrays with `np.array([...])`

## Try It Yourself

1. Install NumPy if you haven't already
2. Create an array with your favorite numbers
3. Try multiplying it by 2
4. Compare with doing the same thing with a Python list

## Common Mistakes

| Mistake | Fix |
|---------|-----|
| `import Numpy` | Use lowercase: `import numpy` |
| Forgetting `as np` | It's optional but standard practice |
| `np.array(1, 2, 3)` | Use a list: `np.array([1, 2, 3])` |
