# Broadcasting in NumPy

## What is Broadcasting?

Broadcasting is NumPy's superpower that lets you do math with arrays of **different shapes**. NumPy automatically "stretches" the smaller array to match the larger one!

```
Without Broadcasting (error):
[1, 2, 3] + [10, 20]  -->  ERROR! Different sizes!

With Broadcasting (magic):
[1, 2, 3] + 10  -->  [11, 12, 13]

NumPy treats 10 as [10, 10, 10] internally!
```

## Simple Broadcasting: Scalar + Array

```python
import numpy as np

arr = np.array([1, 2, 3, 4, 5])
result = arr + 10

# NumPy broadcasts 10 to match the array shape:
# [1, 2, 3, 4, 5] + [10, 10, 10, 10, 10] = [11, 12, 13, 14, 15]
```

### Visual: Scalar Broadcasting

```
Array:      [1, 2, 3, 4, 5]
            +  +  +  +  +
Scalar 10:  [10, 10, 10, 10, 10]  <-- "stretched" to match
            =  =  =  =  =
Result:     [11, 12, 13, 14, 15]
```

## 2D Broadcasting Examples

### Example 1: Adding a Row to Every Row

```python
matrix = np.array([[1, 2, 3],
                   [4, 5, 6],
                   [7, 8, 9]])

row = np.array([10, 20, 30])

result = matrix + row
# [[11, 22, 33],
#  [14, 25, 36],
#  [17, 28, 39]]
```

### Visual: Row Broadcasting

```
Matrix:         Row (broadcasted):
[[1, 2, 3],     [10, 20, 30]
 [4, 5, 6],  +  [10, 20, 30]   (repeated for each row!)
 [7, 8, 9]]     [10, 20, 30]

Result:
[[11, 22, 33],
 [14, 25, 36],
 [17, 28, 39]]
```

### Example 2: Adding a Column to Every Column

```python
matrix = np.array([[1, 2, 3],
                   [4, 5, 6],
                   [7, 8, 9]])

# Column vector (shape: 3, 1)
column = np.array([[10],
                   [20],
                   [30]])

result = matrix + column
# [[11, 12, 13],
#  [24, 25, 26],
#  [37, 38, 39]]
```

### Visual: Column Broadcasting

```
Matrix:          Column (broadcasted):
[[1, 2, 3],     [[10, 10, 10],
 [4, 5, 6],  +   [20, 20, 20],   (repeated for each column!)
 [7, 8, 9]]      [30, 30, 30]]

Result:
[[11, 12, 13],
 [24, 25, 26],
 [37, 38, 39]]
```

## Broadcasting Rules

NumPy compares shapes from RIGHT to LEFT:

```
Rule 1: Dimensions are compatible if they're equal
Rule 2: Dimensions are compatible if one of them is 1

Shape A:    (3, 4)
Shape B:       (4)  <-- Compare from right
            ------
               OK (4 == 4)
            ------
Result:     (3, 4)
```

### More Examples of Compatible Shapes

```
(3, 4) and (4,)     --> OK, result is (3, 4)
(3, 4) and (1, 4)   --> OK, result is (3, 4)
(3, 4) and (3, 1)   --> OK, result is (3, 4)
(3, 4) and (3,)     --> ERROR! 4 != 3
(3, 4) and (2, 4)   --> ERROR! 3 != 2
```

### Visual: How Rules Work

```
Shape Comparison (right to left):

Example: (4, 3) + (3,)
         4  3
            3
         ----
         4  3  <-- Result shape

Step 1: Compare rightmost: 3 == 3 ✓
Step 2: Shape B has no more dims, broadcast to (1, 3), then (4, 3)
```

## Practical Examples

### Example 1: Centering Data

```python
# Student scores in 3 subjects
scores = np.array([[85, 90, 78],
                   [92, 88, 95],
                   [70, 75, 80]])

# Calculate mean of each column
means = scores.mean(axis=0)  # [82.33, 84.33, 84.33]

# Center the data (subtract mean from each column)
centered = scores - means
```

### Example 2: Normalizing Data

```python
data = np.array([[1, 2],
                 [3, 4],
                 [5, 6]])

# Min and max of each column
col_min = data.min(axis=0)  # [1, 2]
col_max = data.max(axis=0)  # [5, 6]

# Normalize to 0-1 range
normalized = (data - col_min) / (col_max - col_min)
```

### Example 3: Outer Product

```python
a = np.array([1, 2, 3])
b = np.array([10, 20, 30, 40])

# Reshape a to column, then multiply
outer = a.reshape(-1, 1) * b

# [[10, 20, 30, 40],
#  [20, 40, 60, 80],
#  [30, 60, 90, 120]]
```

## Quick Broadcasting Reference

| Shape A | Shape B | Result | Works? |
|---------|---------|--------|--------|
| (5,) | scalar | (5,) | Yes |
| (3, 4) | (4,) | (3, 4) | Yes |
| (3, 4) | (3, 1) | (3, 4) | Yes |
| (3, 4) | (1, 4) | (3, 4) | Yes |
| (3, 4) | (3,) | Error | No |
| (3, 1, 4) | (2, 1) | (3, 2, 4) | Yes |

## Common Mistakes

| Mistake | Why It's Wrong | Fix |
|---------|----------------|-----|
| `(3, 4) + (3,)` | 4 != 3 | Use `(4,)` or `(3, 1)` |
| Expecting auto-transpose | NumPy doesn't transpose | Reshape manually |
| Forgetting column shape | `(3,)` is NOT `(3, 1)` | Use `.reshape(-1, 1)` |

## Try It Yourself

1. Add a scalar to a 2D array
2. Add a 1D array to each row of a 2D array
3. Add a column vector to each column of a 2D array
4. Check which shape combinations are compatible
5. Normalize a dataset column-wise
