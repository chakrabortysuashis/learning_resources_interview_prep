# Boolean Masking and Filtering

## What is Boolean Masking?

Boolean masking is like having a filter that says "yes" or "no" to each element. It's one of NumPy's most powerful features!

```
Array:        [10, 25, 30, 15, 45, 20]
Condition:    > 20
Mask:         [False, True, True, False, True, False]
                 ^      ^     ^      ^     ^      ^
                No!    Yes!  Yes!   No!   Yes!   No!
```

## Creating Boolean Arrays

```python
import numpy as np

arr = np.array([10, 25, 30, 15, 45, 20])

# Comparison creates a boolean array
mask = arr > 20
print(mask)  # [False  True  True False  True False]
```

### Visual: How It Works

```
arr:   [10,   25,   30,   15,   45,   20]
        |     |     |     |     |     |
       >20?  >20?  >20?  >20?  >20?  >20?
        |     |     |     |     |     |
mask:  [False, True, True, False, True, False]
```

## Filtering with Boolean Masks

Use the mask inside square brackets to filter!

```python
arr = np.array([10, 25, 30, 15, 45, 20])

# Get elements greater than 20
result = arr[arr > 20]
print(result)  # [25 30 45]
```

### Visual: Filtering Process

```
Step 1: Create mask
arr > 20 = [False, True, True, False, True, False]

Step 2: Apply mask (keep only True positions)
arr:    [10, 25, 30, 15, 45, 20]
mask:   [ X,  O,  O,  X,  O,  X]  (X = excluded, O = included)
         
result: [25, 30, 45]
```

## Common Comparison Operations

```python
arr = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])

# Greater than
print(arr[arr > 5])     # [6 7 8 9 10]

# Less than
print(arr[arr < 5])     # [1 2 3 4]

# Equal to
print(arr[arr == 5])    # [5]

# Not equal to
print(arr[arr != 5])    # [1 2 3 4 6 7 8 9 10]

# Greater than or equal
print(arr[arr >= 5])    # [5 6 7 8 9 10]

# Less than or equal
print(arr[arr <= 5])    # [1 2 3 4 5]
```

## Combining Conditions

Use `&` (and), `|` (or), `~` (not) for multiple conditions.

**Important:** Use parentheses around each condition!

```python
arr = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])

# AND: Both conditions must be true
print(arr[(arr > 3) & (arr < 8)])  # [4 5 6 7]

# OR: At least one condition must be true
print(arr[(arr < 3) | (arr > 8)])  # [1 2 9 10]

# NOT: Invert the condition
print(arr[~(arr > 5)])  # [1 2 3 4 5]
```

### Visual: AND vs OR

```
arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

(arr > 3):  [F, F, F, T, T, T, T, T, T, T]
(arr < 8):  [T, T, T, T, T, T, T, F, F, F]

AND (&):    [F, F, F, T, T, T, T, F, F, F]  --> [4, 5, 6, 7]
             Both must be True

OR (|):     [T, T, T, T, T, T, T, T, T, T]  --> [1,2,3,4,5,6,7,8,9,10]
             At least one True
```

## np.where() - Conditional Selection

`np.where(condition, if_true, if_false)` returns different values based on condition.

```python
arr = np.array([1, 2, 3, 4, 5])

# Replace values: if > 3, use 'big', else use 'small'
result = np.where(arr > 3, 'big', 'small')
print(result)  # ['small' 'small' 'small' 'big' 'big']

# Numerical example: if > 3, double it, else keep it
result = np.where(arr > 3, arr * 2, arr)
print(result)  # [1 2 3 8 10]
```

### Visual: np.where()

```
arr:        [1,    2,     3,     4,     5]
condition:  [F,    F,     F,     T,     T]    (arr > 3)
if_true:    [-,    -,     -,     8,    10]   (arr * 2)
if_false:   [1,    2,     3,     -,     -]   (arr)
result:     [1,    2,     3,     8,    10]
```

## Finding Indices

```python
arr = np.array([10, 25, 30, 15, 45, 20])

# Find indices where condition is true
indices = np.where(arr > 20)[0]
print(indices)  # [1 2 4] (positions of 25, 30, 45)

# Find indices of specific value
idx = np.where(arr == 30)[0]
print(idx)  # [2]
```

## Practical Examples

### Example 1: Grade Classification

```python
grades = np.array([55, 72, 89, 45, 95, 78, 62, 88])

# Find passing grades (>= 60)
passing = grades[grades >= 60]
print("Passing grades:", passing)

# Count how many passed
passed_count = np.sum(grades >= 60)
print("Students passed:", passed_count)
```

### Example 2: Data Cleaning

```python
data = np.array([10, -5, 20, -3, 15, -8, 25])

# Replace negative values with 0
cleaned = np.where(data < 0, 0, data)
print("Cleaned:", cleaned)  # [10 0 20 0 15 0 25]
```

### Example 3: Outlier Detection

```python
values = np.array([10, 12, 11, 100, 13, 11, 12])  # 100 is outlier

mean = np.mean(values)
std = np.std(values)

# Find outliers (more than 2 standard deviations from mean)
outliers = values[np.abs(values - mean) > 2 * std]
print("Outliers:", outliers)
```

## Quick Reference

| Operation | Syntax | Example |
|-----------|--------|---------|
| Greater than | `arr > x` | `arr[arr > 5]` |
| Less than | `arr < x` | `arr[arr < 5]` |
| Equal | `arr == x` | `arr[arr == 5]` |
| Not equal | `arr != x` | `arr[arr != 5]` |
| AND | `(a) & (b)` | `arr[(arr > 3) & (arr < 8)]` |
| OR | `(a) \| (b)` | `arr[(arr < 3) \| (arr > 8)]` |
| NOT | `~(a)` | `arr[~(arr > 5)]` |
| Conditional | `np.where(cond, a, b)` | Replace based on condition |

## Common Mistakes

| Mistake | Problem | Fix |
|---------|---------|-----|
| `arr > 3 and arr < 8` | Python's `and` doesn't work | Use `(arr > 3) & (arr < 8)` |
| Missing parentheses | Operator precedence issues | Always use `(cond1) & (cond2)` |
| `arr[arr = 5]` | Single `=` is assignment | Use `arr[arr == 5]` |

## Try It Yourself

1. Create an array of temperatures and find all values above 75
2. Find all even numbers in an array
3. Use np.where to replace all negatives with 0
4. Find values between 10 and 50
5. Count how many values are greater than the mean
