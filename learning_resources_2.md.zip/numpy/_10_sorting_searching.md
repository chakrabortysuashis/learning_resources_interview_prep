# Sorting and Searching in NumPy

## Sorting Arrays

NumPy makes sorting super easy and fast!

```python
import numpy as np

arr = np.array([3, 1, 4, 1, 5, 9, 2, 6])

# Sort the array
sorted_arr = np.sort(arr)
print(sorted_arr)  # [1 1 2 3 4 5 6 9]
```

### Visual: How Sorting Works

```
Original: [3, 1, 4, 1, 5, 9, 2, 6]
                  |
              sort()
                  |
Sorted:   [1, 1, 2, 3, 4, 5, 6, 9]
           (smallest to largest)
```

## np.sort() vs arr.sort()

```python
arr = np.array([3, 1, 4, 1, 5])

# np.sort() - returns NEW sorted array (original unchanged)
sorted_arr = np.sort(arr)
print("Original:", arr)       # [3 1 4 1 5] (unchanged!)
print("Sorted:", sorted_arr)  # [1 1 3 4 5]

# arr.sort() - sorts IN PLACE (modifies original)
arr.sort()
print("After arr.sort():", arr)  # [1 1 3 4 5] (original changed!)
```

## Reverse Sort (Descending)

```python
arr = np.array([3, 1, 4, 1, 5, 9])

# Sort descending (largest to smallest)
sorted_desc = np.sort(arr)[::-1]
print(sorted_desc)  # [9 5 4 3 1 1]
```

### Visual: Reverse Sorting

```
Step 1: Sort ascending
[3, 1, 4, 1, 5, 9] --> [1, 1, 3, 4, 5, 9]

Step 2: Reverse with [::-1]
[1, 1, 3, 4, 5, 9] --> [9, 5, 4, 3, 1, 1]
```

## Sorting 2D Arrays

```python
arr2d = np.array([[3, 1, 2],
                  [6, 4, 5]])

# Sort each row (axis=1)
print(np.sort(arr2d, axis=1))
# [[1 2 3]
#  [4 5 6]]

# Sort each column (axis=0)
print(np.sort(arr2d, axis=0))
# [[3 1 2]
#  [6 4 5]]
```

### Visual: 2D Sorting by Axis

```
Original:        axis=1 (sort rows):    axis=0 (sort columns):
[[3, 1, 2],      [[1, 2, 3],            [[3, 1, 2],
 [6, 4, 5]]       [4, 5, 6]]             [6, 4, 5]]
                  each row sorted        each column sorted
```

## np.argsort() - Get Sorted Indices

Returns the INDICES that would sort the array, not the sorted values!

```python
arr = np.array([30, 10, 20, 40])

# Get indices that would sort the array
indices = np.argsort(arr)
print(indices)  # [1 2 0 3]

# Use indices to get sorted array
print(arr[indices])  # [10 20 30 40]
```

### Visual: argsort Explained

```
Array:   [30, 10, 20, 40]
Index:     0   1   2   3

Sorted:  [10, 20, 30, 40]
Came from: 1   2   0   3  <-- argsort returns this!

"The smallest is at index 1, next at index 2, then 0, then 3"
```

## Finding Min/Max Indices

```python
arr = np.array([30, 10, 50, 20, 40])

# Index of minimum value
min_idx = np.argmin(arr)
print(f"Min value {arr[min_idx]} at index {min_idx}")  # 10 at index 1

# Index of maximum value
max_idx = np.argmax(arr)
print(f"Max value {arr[max_idx]} at index {max_idx}")  # 50 at index 2
```

### Visual: argmin and argmax

```
Array: [30, 10, 50, 20, 40]
Index:   0   1   2   3   4

argmin() = 1  (10 is smallest, at index 1)
argmax() = 2  (50 is largest, at index 2)
```

## np.searchsorted() - Find Insertion Points

Find where to insert values to keep array sorted.

```python
sorted_arr = np.array([10, 20, 30, 40, 50])

# Where should 25 go to keep it sorted?
pos = np.searchsorted(sorted_arr, 25)
print(pos)  # 2 (between 20 and 30)

# Multiple values at once
positions = np.searchsorted(sorted_arr, [15, 35, 55])
print(positions)  # [1 3 5]
```

### Visual: searchsorted

```
sorted_arr = [10, 20, 30, 40, 50]
               0   1   2   3   4   5 (positions)
                   ^
                   |
               Where does 25 go?
               Between 20 and 30
               Answer: position 2
```

## Practical Examples

### Example 1: Find Top N Scores

```python
scores = np.array([85, 92, 78, 95, 88, 70, 98, 82])

# Get top 3 scores
sorted_scores = np.sort(scores)[::-1]  # Sort descending
top_3 = sorted_scores[:3]
print("Top 3 scores:", top_3)  # [98 95 92]

# Or find their indices
top_3_indices = np.argsort(scores)[::-1][:3]
print("Indices of top 3:", top_3_indices)
```

### Example 2: Rank Students

```python
scores = np.array([85, 92, 78, 95])

# Rank students (1 = highest)
ranks = np.argsort(np.argsort(scores)[::-1]) + 1
print("Scores:", scores)
print("Ranks:", ranks)  # [3 2 4 1]
```

### Example 3: Find Closest Value

```python
arr = np.array([10, 20, 30, 40, 50])
target = 27

# Find index of closest value
idx = np.argmin(np.abs(arr - target))
print(f"Closest to {target}: {arr[idx]}")  # 30
```

## Quick Reference

| Function | What It Does | Example |
|----------|--------------|---------|
| `np.sort(arr)` | Returns sorted copy | `[3,1,2]` -> `[1,2,3]` |
| `arr.sort()` | Sorts in place | Modifies original |
| `np.argsort(arr)` | Indices that would sort | `[3,1,2]` -> `[1,2,0]` |
| `np.argmin(arr)` | Index of minimum | Position of smallest |
| `np.argmax(arr)` | Index of maximum | Position of largest |
| `np.searchsorted(arr, x)` | Insert position | Where x would go |

## Common Mistakes

| Mistake | Problem | Fix |
|---------|---------|-----|
| `sorted(arr)` | Returns list, not array | Use `np.sort(arr)` |
| Confusing sort() and np.sort() | In-place vs new array | Choose based on need |
| Forgetting axis in 2D | Sorts flattened array | Specify `axis=0` or `axis=1` |

## Try It Yourself

1. Sort an array of test scores from highest to lowest
2. Find the index of the maximum value in an array
3. Use argsort to rank items
4. Find where 75 would be inserted in a sorted grade list
5. Get the top 5 values from an array
