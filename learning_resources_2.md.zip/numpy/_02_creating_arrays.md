# Creating Arrays in NumPy

## Overview

NumPy gives you many ways to create arrays. Think of it like having different cookie cutters - each one makes a different shape!

```
Different Array Creation Methods:
+------------------+---------------------------+
| np.array()       | From your own data        |
| np.zeros()       | All zeros                 |
| np.ones()        | All ones                  |
| np.arange()      | Range of numbers          |
| np.linspace()    | Evenly spaced numbers     |
| np.eye()         | Identity matrix           |
+------------------+---------------------------+
```

## 1. np.array() - From Your Data

Convert a Python list into a NumPy array.

```python
import numpy as np

# 1D array (like a line of numbers)
grades = np.array([85, 90, 78, 92])

# 2D array (like a table/grid)
table = np.array([[1, 2, 3],
                  [4, 5, 6]])
```

### Visual: 1D vs 2D Arrays

```
1D Array (like a ruler):
[1] [2] [3] [4] [5]

2D Array (like a spreadsheet):
[1] [2] [3]
[4] [5] [6]
[7] [8] [9]
```

## 2. np.zeros() - Array of Zeros

Creates an array filled with zeros. Great for initializing data!

```python
# 1D array of 5 zeros
zeros_1d = np.zeros(5)
# Output: [0. 0. 0. 0. 0.]

# 2D array of zeros (3 rows, 4 columns)
zeros_2d = np.zeros((3, 4))
# Output:
# [[0. 0. 0. 0.]
#  [0. 0. 0. 0.]
#  [0. 0. 0. 0.]]
```

### Visual

```
np.zeros(5):
[0] [0] [0] [0] [0]

np.zeros((2, 3)):
[0] [0] [0]
[0] [0] [0]
```

## 3. np.ones() - Array of Ones

Same idea, but filled with ones!

```python
# 1D array of 4 ones
ones_1d = np.ones(4)
# Output: [1. 1. 1. 1.]

# 2D array (2 rows, 3 columns)
ones_2d = np.ones((2, 3))
# Output:
# [[1. 1. 1.]
#  [1. 1. 1.]]

# Multiply to get any number you want!
fives = np.ones(4) * 5
# Output: [5. 5. 5. 5.]
```

## 4. np.arange() - Range of Numbers

Like Python's `range()`, but creates an array!

```python
# Basic: 0 to 9
np.arange(10)
# Output: [0 1 2 3 4 5 6 7 8 9]

# Start and stop: 5 to 9
np.arange(5, 10)
# Output: [5 6 7 8 9]

# With step: 0, 2, 4, 6, 8
np.arange(0, 10, 2)
# Output: [0 2 4 6 8]
```

### Visual: arange Parameters

```
np.arange(start, stop, step)
           |      |     |
           v      v     v
           5     15     3  --> [5, 8, 11, 14]
           
Timeline:
5----8----11----14
  +3   +3    +3
```

## 5. np.linspace() - Evenly Spaced Numbers

When you need exactly N numbers between two values.

```python
# 5 numbers between 0 and 10 (inclusive)
np.linspace(0, 10, 5)
# Output: [ 0.   2.5  5.   7.5 10. ]

# 4 numbers between 1 and 4
np.linspace(1, 4, 4)
# Output: [1. 2. 3. 4.]
```

### arange vs linspace

```
np.arange(0, 10, 2):    You specify the STEP
[0] [2] [4] [6] [8]     (how big each jump is)

np.linspace(0, 10, 5):  You specify HOW MANY numbers
[0] [2.5] [5] [7.5] [10]  (it figures out the spacing)
```

## 6. np.eye() - Identity Matrix

Creates a special square matrix with 1s on the diagonal.

```python
# 3x3 identity matrix
np.eye(3)
# Output:
# [[1. 0. 0.]
#  [0. 1. 0.]
#  [0. 0. 1.]]

# 4x4 identity matrix
np.eye(4)
# Output:
# [[1. 0. 0. 0.]
#  [0. 1. 0. 0.]
#  [0. 0. 1. 0.]
#  [0. 0. 0. 1.]]
```

### Visual: Identity Matrix

```
np.eye(3):
[1] [ ] [ ]      The 1s form
[ ] [1] [ ]  <-- a diagonal!
[ ] [ ] [1]
```

## Quick Reference Table

| Function | Purpose | Example |
|----------|---------|---------|
| `np.array([1,2,3])` | From list | `[1 2 3]` |
| `np.zeros(3)` | All zeros | `[0. 0. 0.]` |
| `np.ones(3)` | All ones | `[1. 1. 1.]` |
| `np.arange(5)` | Range | `[0 1 2 3 4]` |
| `np.linspace(0,1,3)` | N numbers | `[0. 0.5 1.]` |
| `np.eye(2)` | Identity | `[[1,0],[0,1]]` |

## Common Mistakes

| Mistake | Fix |
|---------|-----|
| `np.zeros(3, 4)` | Use tuple: `np.zeros((3, 4))` |
| `np.arange(1, 10, 0)` | Step can't be 0 |
| Confusing arange/linspace | arange = step size, linspace = count |

## Try It Yourself

1. Create an array of 10 zeros
2. Create a 3x3 array of ones
3. Create numbers from 0 to 100 in steps of 10
4. Create exactly 7 numbers between 0 and 1
5. Create a 5x5 identity matrix
