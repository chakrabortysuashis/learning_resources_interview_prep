# Aggregation Functions in NumPy

## What are Aggregation Functions?

Aggregation functions take many values and return ONE result. Think of them as "summarizers"!

```
[10, 20, 30, 40, 50]
        |
        v
   sum() = 150 (one number!)
   mean() = 30 (one number!)
   max() = 50 (one number!)
```

## Common Aggregation Functions

```python
import numpy as np

arr = np.array([10, 20, 30, 40, 50])

np.sum(arr)   # 150 - Total of all elements
np.mean(arr)  # 30.0 - Average
np.min(arr)   # 10 - Smallest
np.max(arr)   # 50 - Largest
np.std(arr)   # 14.14... - Standard deviation
np.var(arr)   # 200.0 - Variance
np.prod(arr)  # 12000000 - Product of all
```

### Visual: What Each Function Does

```
Array: [10, 20, 30, 40, 50]

sum():  10 + 20 + 30 + 40 + 50 = 150
mean(): 150 / 5 = 30
min():  smallest = 10
max():  largest = 50
```

## The Axis Parameter (Super Important!)

For 2D arrays, `axis` controls the direction:
- `axis=0`: Work along **columns** (down)
- `axis=1`: Work along **rows** (across)
- `axis=None` (default): Use all elements

```python
arr2d = np.array([[1, 2, 3],
                  [4, 5, 6]])

# Default: sum everything
np.sum(arr2d)       # 21

# axis=0: sum each column
np.sum(arr2d, axis=0)  # [5, 7, 9]

# axis=1: sum each row
np.sum(arr2d, axis=1)  # [6, 15]
```

### Visual: Understanding Axis

```
          axis=1 (across rows) -->
          
          Col0 Col1 Col2
axis=0    [1,   2,   3]    Row sum: 6
(down)    [4,   5,   6]    Row sum: 15
 |         |    |    |
 v         v    v    v
          Col   Col  Col
          sum:  sum: sum:
           5    7    9
```

### Memory Trick

```
axis=0 → "Collapse rows" → Result has same columns
axis=1 → "Collapse columns" → Result has same rows
```

## All Functions with Axis

```python
arr2d = np.array([[1, 2, 3],
                  [4, 5, 6],
                  [7, 8, 9]])

# Sum
np.sum(arr2d)          # 45 (all)
np.sum(arr2d, axis=0)  # [12, 15, 18] (column sums)
np.sum(arr2d, axis=1)  # [6, 15, 24] (row sums)

# Mean
np.mean(arr2d)          # 5.0 (all)
np.mean(arr2d, axis=0)  # [4., 5., 6.] (column means)
np.mean(arr2d, axis=1)  # [2., 5., 8.] (row means)

# Min
np.min(arr2d)          # 1 (all)
np.min(arr2d, axis=0)  # [1, 2, 3] (min of each column)
np.min(arr2d, axis=1)  # [1, 4, 7] (min of each row)

# Max
np.max(arr2d)          # 9 (all)
np.max(arr2d, axis=0)  # [7, 8, 9] (max of each column)
np.max(arr2d, axis=1)  # [3, 6, 9] (max of each row)
```

## Other Useful Aggregations

```python
arr = np.array([3, 1, 4, 1, 5, 9, 2, 6])

# Count non-zero elements
np.count_nonzero(arr)  # 8

# Cumulative sum (running total)
np.cumsum(arr)  # [3, 4, 8, 9, 14, 23, 25, 31]

# Cumulative product
np.cumprod(np.array([1, 2, 3, 4]))  # [1, 2, 6, 24]

# Percentiles
np.percentile(arr, 50)  # Median (50th percentile)
np.percentile(arr, [25, 50, 75])  # Quartiles

# Median
np.median(arr)  # 3.5
```

### Visual: Cumulative Sum

```
Array:  [3, 1, 4, 1, 5, 9, 2, 6]

cumsum: [3, 4, 8, 9, 14, 23, 25, 31]
         |  |  |  |   |   |   |   |
         3  3+1 4+4 8+1 9+5 14+9...
            =4  =8  =9  =14  =23
```

## Practical Examples

### Example 1: Grade Analysis

```python
# Grades for 5 students in 3 subjects
grades = np.array([[85, 90, 78],
                   [92, 88, 95],
                   [70, 75, 80],
                   [88, 82, 90],
                   [95, 98, 92]])

# Average grade per student
student_avg = np.mean(grades, axis=1)
# [84.33, 91.67, 75., 86.67, 95.]

# Average grade per subject
subject_avg = np.mean(grades, axis=0)
# [86., 86.6, 87.]

# Highest score in each subject
best_scores = np.max(grades, axis=0)
# [95, 98, 95]
```

### Example 2: Sales Data

```python
# Monthly sales for 4 products
sales = np.array([[100, 120, 90, 110],
                  [80, 95, 85, 100],
                  [150, 140, 160, 155]])

# Total sales per month
monthly_total = np.sum(sales, axis=0)

# Average sales per product
product_avg = np.mean(sales, axis=1)

# Best month for each product
best_months = np.max(sales, axis=1)
```

## Quick Reference

| Function | What It Does | Example |
|----------|--------------|---------|
| `np.sum()` | Total | 1+2+3 = 6 |
| `np.mean()` | Average | 6/3 = 2 |
| `np.min()` | Smallest | 1 |
| `np.max()` | Largest | 3 |
| `np.std()` | Spread | How spread out |
| `np.var()` | Variance | std^2 |
| `np.median()` | Middle value | - |
| `np.prod()` | Product | 1*2*3 = 6 |

## Common Mistakes

| Mistake | Problem | Fix |
|---------|---------|-----|
| Forgetting axis | Gets total instead of per-row/col | Specify `axis=0` or `axis=1` |
| axis=0 vs axis=1 | Confusing direction | Remember: 0=down, 1=across |
| Using on wrong dtype | String array issues | Ensure numeric data |

## Try It Yourself

1. Create a 4x5 array of random numbers
2. Find the sum of each row
3. Find the mean of each column
4. Find the overall maximum
5. Calculate the standard deviation of each row
