# Indexing and Slicing Arrays

## What is Indexing?

Indexing is how you get **one specific element** from an array. Think of it like seat numbers in a theater - each element has an address!

```
Array:  [10, 20, 30, 40, 50]
Index:    0   1   2   3   4   (starts at 0!)
        -5  -4  -3  -2  -1   (negative = from end)
```

## Basic Indexing (1D Arrays)

```python
import numpy as np

arr = np.array([10, 20, 30, 40, 50])

# Get single elements
print(arr[0])   # 10 (first element)
print(arr[2])   # 30 (third element)
print(arr[-1])  # 50 (last element)
print(arr[-2])  # 40 (second to last)
```

### Visual: Positive vs Negative Indexing

```
         [10] [20] [30] [40] [50]
Positive:  0    1    2    3    4   (left to right)
Negative: -5   -4   -3   -2   -1   (right to left)

arr[0]  = arr[-5] = 10
arr[4]  = arr[-1] = 50
```

## 2D Array Indexing

For 2D arrays, use: `arr[row, column]`

```python
arr2d = np.array([[1, 2, 3],
                  [4, 5, 6],
                  [7, 8, 9]])

# Get specific elements
print(arr2d[0, 0])  # 1 (top-left)
print(arr2d[0, 2])  # 3 (top-right)
print(arr2d[2, 0])  # 7 (bottom-left)
print(arr2d[1, 1])  # 5 (center)
```

### Visual: 2D Indexing

```
        col 0  col 1  col 2
row 0:   [1]    [2]    [3]
row 1:   [4]    [5]    [6]
row 2:   [7]    [8]    [9]

arr2d[1, 2] = 6  (row 1, column 2)
arr2d[2, 0] = 7  (row 2, column 0)
```

## What is Slicing?

Slicing gets **multiple elements** at once. Syntax: `arr[start:stop:step]`

```
arr[start:stop:step]
     |     |    |
     |     |    +-- How many to skip (optional)
     |     +------- Where to stop (exclusive)
     +------------- Where to start (inclusive)
```

## 1D Slicing

```python
arr = np.array([0, 10, 20, 30, 40, 50, 60, 70, 80, 90])

# Basic slices
print(arr[2:5])    # [20 30 40] (index 2, 3, 4)
print(arr[:4])     # [0 10 20 30] (first 4)
print(arr[6:])     # [60 70 80 90] (from index 6 to end)
print(arr[::2])    # [0 20 40 60 80] (every 2nd element)
print(arr[::-1])   # [90 80 70 60 50 40 30 20 10 0] (reversed!)
```

### Visual: Slicing Examples

```
arr = [0, 10, 20, 30, 40, 50, 60, 70, 80, 90]
       0   1   2   3   4   5   6   7   8   9

arr[2:5]:    [ ]  [ ] [20] [30] [40] [ ]  [ ]  [ ]  [ ]  [ ]
                   ^start        ^stop (not included)

arr[:4]:     [0] [10] [20] [30]  [ ]  [ ]  [ ]  [ ]  [ ]  [ ]
             ^start(0)       ^stop

arr[6:]:     [ ]  [ ]  [ ]  [ ]  [ ]  [ ] [60] [70] [80] [90]
                                          ^start         ^end
```

## 2D Slicing

Syntax: `arr[row_start:row_stop, col_start:col_stop]`

```python
arr2d = np.array([[1, 2, 3, 4],
                  [5, 6, 7, 8],
                  [9, 10, 11, 12]])

# Get specific rows and columns
print(arr2d[0, :])     # [1 2 3 4] - entire first row
print(arr2d[:, 0])     # [1 5 9] - entire first column
print(arr2d[0:2, 1:3]) # [[2 3]    - rows 0-1, cols 1-2
                       #  [6 7]]
```

### Visual: 2D Slicing

```
Original array:
        col 0  col 1  col 2  col 3
row 0:   [1]    [2]    [3]    [4]
row 1:   [5]    [6]    [7]    [8]
row 2:   [9]   [10]   [11]   [12]

arr2d[0, :] - First row, all columns:
[1] [2] [3] [4]

arr2d[:, 0] - All rows, first column:
[1]
[5]
[9]

arr2d[0:2, 1:3] - Rows 0-1, columns 1-2:
    [2] [3]
    [6] [7]
```

## Slicing Shortcuts

```python
arr = np.array([0, 10, 20, 30, 40])

arr[:]      # All elements
arr[::2]    # Every 2nd element
arr[::-1]   # Reversed
arr[1::2]   # Every 2nd, starting at index 1
```

## Important: Slices are Views!

Modifying a slice changes the original array!

```python
arr = np.array([1, 2, 3, 4, 5])
slice_arr = arr[1:4]
slice_arr[0] = 100

print(arr)  # [1 100 3 4 5] - Original changed!
```

To avoid this, make a copy:
```python
slice_arr = arr[1:4].copy()
```

## Quick Reference

| Syntax | Result |
|--------|--------|
| `arr[2]` | Element at index 2 |
| `arr[-1]` | Last element |
| `arr[1:4]` | Elements 1, 2, 3 |
| `arr[:3]` | First 3 elements |
| `arr[3:]` | From index 3 to end |
| `arr[::2]` | Every other element |
| `arr[::-1]` | Reversed array |
| `arr2d[1, 2]` | Row 1, column 2 |
| `arr2d[0, :]` | Entire first row |
| `arr2d[:, 0]` | Entire first column |

## Common Mistakes

| Mistake | Correct |
|---------|---------|
| `arr[1, 2, 3]` (1D) | `arr[[1, 2, 3]]` or `arr[1:4]` |
| Forgetting stop is exclusive | `arr[0:3]` gets indices 0, 1, 2 |
| Modifying slice affects original | Use `.copy()` if needed |

## Try It Yourself

1. Create an array of numbers 1-10
2. Get the first 3 elements
3. Get the last 2 elements
4. Get every 3rd element
5. Reverse the array
