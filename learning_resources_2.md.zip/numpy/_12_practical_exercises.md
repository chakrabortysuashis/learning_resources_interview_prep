# Practical NumPy Exercises

## How to Use This Section

Each exercise includes:
1. Problem description
2. Hints (if you get stuck)
3. Solution (try first before looking!)

---

## Exercise 1: Temperature Converter

**Problem:** Create an array of Celsius temperatures [0, 10, 20, 30, 40] and convert them to Fahrenheit using the formula: F = C * 9/5 + 32

**Hints:**
- Create array with np.array()
- NumPy does element-wise operations automatically

**Solution:**
```python
import numpy as np

celsius = np.array([0, 10, 20, 30, 40])
fahrenheit = celsius * 9/5 + 32

print("Celsius:   ", celsius)
print("Fahrenheit:", fahrenheit)
# Output: [32. 50. 68. 86. 104.]
```

---

## Exercise 2: Grade Statistics

**Problem:** Given student grades [85, 92, 78, 95, 88, 72, 96, 83], find:
- Average grade
- Highest and lowest grade
- How many students scored above 85
- Standard deviation

**Solution:**
```python
grades = np.array([85, 92, 78, 95, 88, 72, 96, 83])

average = np.mean(grades)
highest = np.max(grades)
lowest = np.min(grades)
above_85 = np.sum(grades > 85)
std_dev = np.std(grades)

print(f"Average: {average:.2f}")
print(f"Highest: {highest}")
print(f"Lowest: {lowest}")
print(f"Above 85: {above_85} students")
print(f"Std Dev: {std_dev:.2f}")
```

---

## Exercise 3: Multiplication Table

**Problem:** Create a 10x10 multiplication table using broadcasting.

**Hints:**
- Create row and column vectors
- Use broadcasting to multiply them

**Solution:**
```python
row = np.arange(1, 11)           # [1, 2, 3, ..., 10]
col = np.arange(1, 11).reshape(-1, 1)  # Column vector

mult_table = row * col

print("Multiplication Table:")
print(mult_table)
```

---

## Exercise 4: Dice Simulation

**Problem:** Simulate rolling two dice 10,000 times. Find the probability of getting:
- A total of 7
- A total of 2 (snake eyes)
- A total of 12

**Solution:**
```python
np.random.seed(42)
n_rolls = 10000

die1 = np.random.randint(1, 7, size=n_rolls)
die2 = np.random.randint(1, 7, size=n_rolls)
totals = die1 + die2

prob_7 = np.sum(totals == 7) / n_rolls
prob_2 = np.sum(totals == 2) / n_rolls
prob_12 = np.sum(totals == 12) / n_rolls

print(f"Probability of 7: {prob_7:.4f} (theoretical: 0.1667)")
print(f"Probability of 2: {prob_2:.4f} (theoretical: 0.0278)")
print(f"Probability of 12: {prob_12:.4f} (theoretical: 0.0278)")
```

---

## Exercise 5: Data Normalization

**Problem:** Normalize the array [10, 20, 30, 40, 50] to a range of 0-1 using the formula:
normalized = (x - min) / (max - min)

**Solution:**
```python
data = np.array([10, 20, 30, 40, 50])

min_val = np.min(data)
max_val = np.max(data)
normalized = (data - min_val) / (max_val - min_val)

print("Original:  ", data)
print("Normalized:", normalized)
# Output: [0.   0.25 0.5  0.75 1.  ]
```

---

## Exercise 6: Finding Outliers

**Problem:** In the dataset [12, 15, 14, 10, 12, 100, 13, 11, 14, 15], find outliers (values more than 2 standard deviations from the mean).

**Solution:**
```python
data = np.array([12, 15, 14, 10, 12, 100, 13, 11, 14, 15])

mean = np.mean(data)
std = np.std(data)
threshold = 2 * std

outliers = data[np.abs(data - mean) > threshold]
print(f"Mean: {mean:.2f}")
print(f"Std: {std:.2f}")
print(f"Outliers: {outliers}")
# Output: [100]
```

---

## Exercise 7: Moving Average

**Problem:** Calculate a 3-day moving average for the stock prices [100, 102, 101, 105, 110, 108, 112, 115, 113, 118].

**Hints:**
- Use array slicing
- Average groups of 3

**Solution:**
```python
prices = np.array([100, 102, 101, 105, 110, 108, 112, 115, 113, 118])

# Simple approach with a loop
moving_avg = np.zeros(len(prices) - 2)
for i in range(len(moving_avg)):
    moving_avg[i] = np.mean(prices[i:i+3])

print("Prices:", prices)
print("3-day moving average:", np.round(moving_avg, 2))

# Or using NumPy's convolve
kernel = np.ones(3) / 3
moving_avg2 = np.convolve(prices, kernel, mode='valid')
print("Using convolve:", np.round(moving_avg2, 2))
```

---

## Exercise 8: Image Operations (Simple)

**Problem:** Create a simple 5x5 "image" array with random values 0-255. Then:
- Find the brightest pixel (max value)
- Darken the image by 50 (subtract 50, clip at 0)
- Brighten the image by 20% (multiply by 1.2, clip at 255)

**Solution:**
```python
np.random.seed(42)
image = np.random.randint(0, 256, size=(5, 5))

print("Original image:")
print(image)
print(f"Brightest pixel: {np.max(image)} at {np.unravel_index(np.argmax(image), image.shape)}")

# Darken
darkened = np.clip(image - 50, 0, 255)
print("\nDarkened by 50:")
print(darkened)

# Brighten
brightened = np.clip(image * 1.2, 0, 255).astype(int)
print("\nBrightened by 20%:")
print(brightened)
```

---

## Exercise 9: Grading System

**Problem:** Convert numerical scores to letter grades:
- A: 90-100
- B: 80-89
- C: 70-79
- D: 60-69
- F: below 60

Scores: [95, 82, 67, 73, 55, 89, 91, 78, 65, 99]

**Solution:**
```python
scores = np.array([95, 82, 67, 73, 55, 89, 91, 78, 65, 99])

grades = np.empty(len(scores), dtype='U1')  # Unicode string array
grades[scores >= 90] = 'A'
grades[(scores >= 80) & (scores < 90)] = 'B'
grades[(scores >= 70) & (scores < 80)] = 'C'
grades[(scores >= 60) & (scores < 70)] = 'D'
grades[scores < 60] = 'F'

print("Scores:", scores)
print("Grades:", grades)

# Count each grade
for g in ['A', 'B', 'C', 'D', 'F']:
    count = np.sum(grades == g)
    print(f"Grade {g}: {count}")
```

---

## Exercise 10: Sales Analysis

**Problem:** Given monthly sales data for 3 products over 4 months:

```
         Jan  Feb  Mar  Apr
Product1: 100, 120, 115, 130
Product2: 80,  85,  90,  95
Product3: 150, 140, 160, 155
```

Find:
- Total sales per product
- Total sales per month
- Best-selling product
- Best month

**Solution:**
```python
sales = np.array([[100, 120, 115, 130],
                  [80, 85, 90, 95],
                  [150, 140, 160, 155]])

products = ['Product1', 'Product2', 'Product3']
months = ['Jan', 'Feb', 'Mar', 'Apr']

# Total per product (sum across columns)
product_totals = np.sum(sales, axis=1)
print("Total per product:", product_totals)

# Total per month (sum across rows)
month_totals = np.sum(sales, axis=0)
print("Total per month:", month_totals)

# Best product
best_product_idx = np.argmax(product_totals)
print(f"Best product: {products[best_product_idx]} ({product_totals[best_product_idx]})")

# Best month
best_month_idx = np.argmax(month_totals)
print(f"Best month: {months[best_month_idx]} ({month_totals[best_month_idx]})")
```

---

## Bonus Challenge: Matrix Operations

**Problem:** Create a 3x3 matrix A and:
- Find the transpose
- Calculate the sum of the diagonal
- Multiply by its transpose

**Solution:**
```python
A = np.array([[1, 2, 3],
              [4, 5, 6],
              [7, 8, 9]])

print("Matrix A:")
print(A)

# Transpose
print("\nTranspose:")
print(A.T)

# Diagonal sum (trace)
diagonal_sum = np.trace(A)
print(f"\nSum of diagonal: {diagonal_sum}")

# Matrix multiplication with transpose
result = np.dot(A, A.T)  # or A @ A.T
print("\nA * A^T:")
print(result)
```

---

## Congratulations!

You've completed the NumPy learning materials! You now know:
- Creating arrays
- Array attributes and shapes
- Indexing and slicing
- Reshaping arrays
- Mathematical operations
- Broadcasting
- Aggregation functions
- Boolean masking
- Sorting and searching
- Random number generation

Keep practicing with real data and projects!
