# Array Attributes in NumPy

## What Are Attributes?

Attributes are like the "ID card" of your array - they tell you everything about it!

```
Array's ID Card:
+------------------+-------------------------+
| shape            | Dimensions (rows, cols) |
| size             | Total number of elements|
| dtype            | Data type               |
| ndim             | Number of dimensions    |
| itemsize         | Bytes per element       |
+------------------+-------------------------+
```

## 1. shape - The Dimensions

Tells you the size of each dimension (rows, columns, etc.)

```python
import numpy as np

# 1D array
arr1d = np.array([1, 2, 3, 4, 5])
print(arr1d.shape)  # (5,) - 5 elements

# 2D array
arr2d = np.array([[1, 2, 3],
                  [4, 5, 6]])
print(arr2d.shape)  # (2, 3) - 2 rows, 3 columns
```

### Visual: Understanding Shape

```
1D Array: [1, 2, 3, 4, 5]
Shape: (5,)
         ^
         |
    5 elements

2D Array: [[1, 2, 3],
           [4, 5, 6]]
Shape: (2, 3)
        ^  ^
        |  |
   2 rows  3 columns

3D Array: Think of it as layers of 2D arrays
Shape: (2, 3, 4) = 2 layers, 3 rows, 4 columns
```

## 2. size - Total Elements

The total count of all elements in the array.

```python
arr2d = np.array([[1, 2, 3],
                  [4, 5, 6]])

print(arr2d.size)  # 6 (2 rows x 3 cols = 6)
```

### Visual

```
[[1, 2, 3],    Count them: 1, 2, 3, 4, 5, 6
 [4, 5, 6]]    
               size = 6

shape = (2, 3)
size = 2 * 3 = 6
```

## 3. dtype - Data Type

What kind of data is stored in the array.

```python
# Integers
int_arr = np.array([1, 2, 3])
print(int_arr.dtype)  # int64 (or int32 on Windows)

# Floats
float_arr = np.array([1.0, 2.0, 3.0])
print(float_arr.dtype)  # float64

# Mixed (becomes float)
mixed = np.array([1, 2.5, 3])
print(mixed.dtype)  # float64
```

### Common Data Types

```
+----------+------------------+-------------------+
| dtype    | Description      | Example           |
+----------+------------------+-------------------+
| int32    | Integer (32-bit) | 1, 2, -5, 100     |
| int64    | Integer (64-bit) | Large integers    |
| float32  | Decimal (32-bit) | 3.14              |
| float64  | Decimal (64-bit) | More precision    |
| bool     | True/False       | True, False       |
| str      | Text             | 'hello'           |
+----------+------------------+-------------------+
```

### Specifying dtype

```python
# Force a specific data type
arr = np.array([1, 2, 3], dtype=float)
print(arr)  # [1. 2. 3.]

# Integer array
arr = np.array([1.9, 2.8, 3.7], dtype=int)
print(arr)  # [1 2 3] - decimals truncated!
```

## 4. ndim - Number of Dimensions

How many dimensions (axes) the array has.

```python
arr1d = np.array([1, 2, 3])
arr2d = np.array([[1, 2], [3, 4]])
arr3d = np.array([[[1, 2], [3, 4]], [[5, 6], [7, 8]]])

print(arr1d.ndim)  # 1
print(arr2d.ndim)  # 2
print(arr3d.ndim)  # 3
```

### Visual: Dimensions

```
1D (ndim=1):  [1, 2, 3, 4]          Like a line
              ───────────>

2D (ndim=2):  [[1, 2],              Like a table
               [3, 4]]              
              ───────────>
              |
              v

3D (ndim=3):  [[[1,2],[3,4]],       Like a cube
               [[5,6],[7,8]]]       (stack of tables)
```

## 5. itemsize - Bytes Per Element

How much memory each element takes up.

```python
int_arr = np.array([1, 2, 3], dtype=np.int32)
print(int_arr.itemsize)  # 4 bytes

float_arr = np.array([1.0, 2.0, 3.0], dtype=np.float64)
print(float_arr.itemsize)  # 8 bytes
```

### Memory Calculation

```
Total memory = size * itemsize

Example:
arr = np.zeros((1000, 1000), dtype=np.float64)
Memory = 1,000,000 * 8 bytes = 8,000,000 bytes = ~8 MB
```

## Quick Reference

```python
import numpy as np

arr = np.array([[1, 2, 3],
                [4, 5, 6]])

print(f"Shape: {arr.shape}")      # (2, 3)
print(f"Size: {arr.size}")        # 6
print(f"Dtype: {arr.dtype}")      # int64
print(f"Ndim: {arr.ndim}")        # 2
print(f"Itemsize: {arr.itemsize}") # 8
```

## Summary Table

| Attribute | What It Tells You | Example |
|-----------|-------------------|---------|
| `shape` | (rows, cols, ...) | `(2, 3)` |
| `size` | Total elements | `6` |
| `dtype` | Data type | `int64` |
| `ndim` | Number of dimensions | `2` |
| `itemsize` | Bytes per element | `8` |

## Common Mistakes

| Mistake | Explanation |
|---------|-------------|
| `arr.shape()` | Use `arr.shape` (no parentheses!) |
| Confusing shape and size | shape = dimensions, size = total count |
| Forgetting dtype affects math | int + int = int, int + float = float |

## Try It Yourself

1. Create a 3x4 array and check all its attributes
2. Create arrays with different dtypes and compare itemsize
3. Calculate the total memory used by a large array
