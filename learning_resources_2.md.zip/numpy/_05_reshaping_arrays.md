# Reshaping Arrays in NumPy

## What is Reshaping?

Reshaping is like reorganizing items in a box without changing the items themselves. You're just changing how they're arranged!

```
Original 1D array:  [1, 2, 3, 4, 5, 6]

Reshape to (2, 3):  [[1, 2, 3],      2 rows, 3 columns
                     [4, 5, 6]]

Reshape to (3, 2):  [[1, 2],         3 rows, 2 columns
                     [3, 4],
                     [5, 6]]

Same 6 elements, different arrangements!
```

## 1. reshape() - Change Dimensions

```python
import numpy as np

arr = np.array([1, 2, 3, 4, 5, 6])

# Reshape to 2x3
arr_2x3 = arr.reshape(2, 3)
print(arr_2x3)
# [[1 2 3]
#  [4 5 6]]

# Reshape to 3x2
arr_3x2 = arr.reshape(3, 2)
print(arr_3x2)
# [[1 2]
#  [3 4]
#  [5 6]]
```

### Visual: How Reshape Works

```
Original: [1, 2, 3, 4, 5, 6]

reshape(2, 3) - Fill row by row:
Row 0: [1, 2, 3]
Row 1: [4, 5, 6]

reshape(3, 2) - Fill row by row:
Row 0: [1, 2]
Row 1: [3, 4]
Row 2: [5, 6]
```

### The -1 Trick (Auto-Calculate)

Use -1 to let NumPy figure out one dimension:

```python
arr = np.arange(12)  # [0, 1, 2, ..., 11]

# "Give me 3 rows, figure out columns"
print(arr.reshape(3, -1))  # (3, 4)

# "Give me 4 columns, figure out rows"
print(arr.reshape(-1, 4))  # (3, 4)
```

## 2. flatten() - Make 1D (Copy)

Flattens any array to 1D. Returns a **copy**.

```python
arr2d = np.array([[1, 2, 3],
                  [4, 5, 6]])

flat = arr2d.flatten()
print(flat)  # [1 2 3 4 5 6]
```

### Visual: Flatten

```
[[1, 2, 3],        flatten()       [1, 2, 3, 4, 5, 6]
 [4, 5, 6]]    ------------->    (reads row by row)
```

## 3. ravel() - Make 1D (View)

Similar to flatten, but returns a **view** (not a copy).

```python
arr2d = np.array([[1, 2, 3],
                  [4, 5, 6]])

raveled = arr2d.ravel()
print(raveled)  # [1 2 3 4 5 6]
```

### flatten() vs ravel()

```
flatten():
- Creates a COPY
- Modifying it doesn't affect original
- Uses more memory

ravel():
- Creates a VIEW
- Modifying it MIGHT affect original
- More memory efficient
```

## 4. transpose() / .T - Swap Rows and Columns

```python
arr = np.array([[1, 2, 3],
                [4, 5, 6]])

print("Original (2x3):")
print(arr)

print("\nTransposed (3x2):")
print(arr.T)  # or arr.transpose()
```

### Visual: Transpose

```
Original (2 rows, 3 cols):      Transposed (3 rows, 2 cols):
     Col0 Col1 Col2                  Col0 Col1
Row0  [1]  [2]  [3]             Row0  [1]  [4]
Row1  [4]  [5]  [6]             Row1  [2]  [5]
                                Row2  [3]  [6]

Rows become columns, columns become rows!
```

## 5. resize() - Change Size (Can Add/Remove)

Unlike reshape, resize can change the total number of elements:

```python
arr = np.array([1, 2, 3, 4])

# Make it bigger (repeats values)
arr.resize(6)
print(arr)  # [1 2 3 4 0 0] - Fills with zeros

# Or use np.resize() for repeating
bigger = np.resize(arr, 8)
print(bigger)  # [1 2 3 4 1 2 3 4]
```

## Quick Comparison

| Method | Returns | Changes Size? |
|--------|---------|---------------|
| `reshape()` | View | No |
| `flatten()` | Copy | No |
| `ravel()` | View | No |
| `.T` / `transpose()` | View | No |
| `resize()` | None (modifies in place) | Yes |

## Common Reshape Patterns

```python
# 1D to 2D column vector
arr = np.array([1, 2, 3])
column = arr.reshape(-1, 1)  # [[1], [2], [3]]

# 1D to 2D row vector
row = arr.reshape(1, -1)  # [[1, 2, 3]]

# 2D to 1D
flat = arr2d.reshape(-1)  # Same as flatten()
```

## Common Mistakes

| Mistake | Problem | Fix |
|---------|---------|-----|
| `reshape(2, 4)` on 6 elements | 2*4=8 != 6 | Sizes must match! |
| Forgetting reshape returns view | Original may change | Use `.copy()` if needed |
| `arr.reshape(2, 3, 4)` | Wrong total size | Total must equal `arr.size` |

## The Golden Rule

```
Original elements = New elements

If arr.size = 12, valid reshapes:
(1, 12), (2, 6), (3, 4), (4, 3), (6, 2), (12, 1)
(2, 2, 3), (2, 3, 2), (3, 2, 2), (1, 2, 6), etc.

All multiply to 12!
```

## Try It Yourself

1. Create an array 1-12 and reshape it to 3x4
2. Reshape the same array to 4x3, then 2x6
3. Flatten a 2D array
4. Transpose a 3x2 array to 2x3
5. Use -1 to auto-calculate dimensions
