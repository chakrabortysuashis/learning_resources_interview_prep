"""A complete multiple-tool loop with local, fictional course data."""

import argparse
import json

from openai import OpenAI
from pydantic import BaseModel, ConfigDict, Field, ValidationError

from common import make_client, model_name, require_completed


class CourseArgs(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    course_code: str = Field(description="Course identifier: PY101 or LLM201.")


class PriceArgs(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    course_code: str = Field(description="Course identifier: PY101 or LLM201.")
    coupon: str | None = Field(description="Coupon code if the user supplied one, otherwise null.")


TOOLS = [
    {
        "type": "function",
        "name": "get_course",
        "description": "Read a fictional course's title, prerequisites, and duration. Does not return its price.",
        "parameters": CourseArgs.model_json_schema(),
        "strict": True,
    },
    {
        "type": "function",
        "name": "get_price",
        "description": "Read a fictional course's price in INR, optionally applying a supplied coupon. Does not enroll or charge anyone.",
        "parameters": PriceArgs.model_json_schema(),
        "strict": True,
    },
]

CATALOG = {
    "PY101": {"title": "Python Foundations", "hours": 12, "prerequisites": [], "price_inr": 1200},
    "LLM201": {"title": "LLM Applications", "hours": 16, "prerequisites": ["PY101"], "price_inr": 2400},
}


def get_course(args: CourseArgs) -> dict:
    course = CATALOG[args.course_code.upper()]
    return {key: course[key] for key in ("title", "hours", "prerequisites")}


def get_price(args: PriceArgs) -> dict:
    price = CATALOG[args.course_code.upper()]["price_inr"]
    if args.coupon is not None and args.coupon.upper() != "LEARN10":
        return {"error": "Unknown coupon; supported demo coupon is LEARN10."}
    return {"currency": "INR", "price": price * 9 // 10 if args.coupon else price}


# This allowlist is the only route from a model-supplied name to executable code.
REGISTRY = {
    "get_course": (CourseArgs, get_course),
    "get_price": (PriceArgs, get_price),
}


def execute_tool(name: str, arguments: str) -> str:
    if name not in REGISTRY:
        return json.dumps({"error": f"Unknown tool: {name}"})
    argument_model, handler = REGISTRY[name]
    try:
        args = argument_model.model_validate_json(arguments)
    except ValidationError:
        return json.dumps({"error": "Arguments must be valid JSON matching the tool schema."})
    try:
        result = handler(args)
    except KeyError:
        result = {"error": "Unknown course. Available demo courses: PY101, LLM201."}
    return json.dumps(result)


def run_tool_loop(
    client: OpenAI,
    prompt: str,
    *,
    mode: str = "auto",
    max_rounds: int = 5,
) -> str:
    if mode not in {"auto", "required", "none", "force-price"}:
        raise ValueError(f"Unknown tool mode: {mode}")
    if max_rounds < 1:
        raise ValueError("max_rounds must be positive")
    first_choice = (
        {"type": "function", "name": "get_price"}
        if mode == "force-price"
        else mode
    )
    history = [{"role": "user", "content": prompt}]
    for round_index in range(max_rounds):
        response = client.responses.create(
            model=model_name(),
            instructions=(
                "You help learners with a fictional course catalog. Use tools for "
                "catalog facts and prices. Never invent missing data or coupons. "
                "If tools are disabled, say you cannot look up current catalog data."
            ),
            input=history,
            tools=TOOLS,
            tool_choice=first_choice if round_index == 0 else "auto",
            parallel_tool_calls=mode != "force-price",
            max_output_tokens=1500,
            store=False,
            include=["reasoning.encrypted_content"],
        )
        require_completed(response)
        # Preserve all output items, including reasoning and every function call.
        history.extend(response.output)
        calls = [item for item in response.output if item.type == "function_call"]
        if not calls:
            if not response.output_text:
                raise RuntimeError("Response completed without tool calls or final text.")
            return response.output_text
        for call in calls:
            print(f"Tool: {call.name}({call.arguments})")
            result = execute_tool(call.name, call.arguments)
            print("Result:", result)
            history.append({
                "type": "function_call_output",
                "call_id": call.call_id,
                "output": result,
            })
    raise RuntimeError(f"Tool loop reached {max_rounds} requests without a final answer.")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=["auto", "required", "none", "force-price"])
    parser.add_argument("--prompt", default=(
        "What are the prerequisites and duration of LLM201, and what is its price "
        "with coupon LEARN10?"
    ))
    args = parser.parse_args()
    with make_client() as client:
        print(run_tool_loop(client, args.prompt, mode=args.mode))


if __name__ == "__main__":
    main()
