# 02 - Generation parameters and their limits

[Index](README.md) | [Python examples](02_parameters.py) | [Next: tools](03_tool_use.md)

Parameters control different parts of generation. Their presence in the SDK does
not mean every model accepts them. Unsupported model/parameter combinations can
return HTTP 400. The examples deliberately separate sampling from reasoning.

## Compatibility table

| Concept | Responses API | Chat Completions | Important limitation |
| --- | --- | --- | --- |
| Model | `model` | `model` | Availability and capabilities vary by model/project |
| Temperature | `temperature` | `temperature` | Sampling demo uses GPT-4.1 mini; do not copy into the GPT-5 mini reasoning call |
| Nucleus sampling | `top_p` | `top_p` | Same model caveat; usually tune this or temperature |
| Top-k sampling | No general `top_k` parameter | No general `top_k` parameter | Concept only; do not pass `topk`, `top_k`, or hide it in `extra_body` |
| Reasoning effort | `reasoning={"effort": "low"}` | `reasoning_effort="low"` | Reasoning models only; values are model-dependent |
| Reasoning summary | `reasoning={"summary": "auto"}` | No directly equivalent setting shown here | Summary support/access varies; not raw hidden reasoning |
| Output limit | `max_output_tokens` | `max_completion_tokens` | Includes reasoning tokens where applicable; not a word count |
| Stop sequence | No `stop` field | `stop=["END"]` | Supported models only; use the GPT-4.1 mini example |
| Streaming | `stream=True` | `stream=True` | Different event/chunk shapes |
| Tool selection | `tool_choice` | `tool_choice` | Forced-function object shape differs |
| Structured JSON | `text.format` or SDK `text_format` | `response_format` | Use a model supporting Structured Outputs |
| Frequency/presence penalties | Not general Responses controls | `frequency_penalty`, `presence_penalty` | Supported Chat models only; not all reasoning models |

The original GPT-5 family (`gpt-5`, `gpt-5-mini`, `gpt-5-nano`) has different
parameter support from later families. For these lessons, use `gpt-4.1-mini` for
sampling and `gpt-5-mini` for reasoning. Do not generalize their settings to every
model that starts with `gpt-5` or to later model generations.

## Temperature: reshape token probabilities

At each step, the model assigns scores to possible next tokens. Temperature changes
how sharply it favors higher-scoring tokens. For positive temperature `T`, the
idea is `probability(token_i) = softmax(logit_i / T)`.

Lower values, such as `0.2`, favor predictable choices. Higher values, such as
`0.9`, permit more variation. The API's documented range is 0 to 2 for supported
models. Zero favors the highest-probability choice, but does not guarantee identical
responses across requests or make facts correct. The positive-temperature formula
is not evaluated literally at zero.

```python
response = client.responses.create(
    model="gpt-4.1-mini",
    input="Suggest three names for a Python study group.",
    temperature=0.2,
    max_output_tokens=200,
)
```

```powershell
python 02_parameters.py temperature --temperature 0.2
python 02_parameters.py temperature --temperature 0.9
```

## Top-p and top-k: choose candidates

Suppose the next-token probabilities are:

| Token | Probability | Cumulative probability |
| --- | --- | --- |
| A | 0.50 | 0.50 |
| B | 0.25 | 0.75 |
| C | 0.15 | 0.90 |
| D | 0.10 | 1.00 |

`top_p=0.8` keeps the smallest highest-probability set whose cumulative probability
reaches at least 0.8: A, B, and C. Sampling then uses that candidate set.
`top_p=1` applies no nucleus cutoff. Top-p is a probability mass, not a percentage
of vocabulary entries and not a fixed number of tokens.

Conceptually, `top_k=2` would keep A and B regardless of their cumulative mass.
**The OpenAI endpoints taught here do not expose general top-k sampling.**
`top_logprobs` reports probabilities for likely tokens where supported; it does
not implement top-k sampling. A `top_k` option in another provider or framework
does not automatically map to OpenAI.

```python
response = client.responses.create(
    model="gpt-4.1-mini",
    input="Suggest three names for a Python study group.",
    top_p=0.9,
    max_output_tokens=200,
)
```

Run `python 02_parameters.py top-p --top-p 0.9`. Start by adjusting temperature
or top-p, leaving the other at its default, so you can understand the effect.

## Reasoning effort: control reasoning work

```python
response = client.responses.create(
    model="gpt-5-mini",
    input="A notebook and pen cost 110 rupees. The notebook costs 100 more. Find each price.",
    reasoning={"effort": "low"},
    max_output_tokens=4096,
)
```

For this GPT-5 mini example, use `minimal`, `low`, `medium`, or `high`. Later models
can add or remove values. More effort can increase latency and token use; it is
not a correctness guarantee. It is distinct from temperature and from answer length.

```powershell
python 02_parameters.py reasoning --effort low
python 02_parameters.py reasoning --effort medium --summary
```

The answer should identify a 5-rupee pen and a 105-rupee notebook. The script prints
usage, including reasoning token details when returned. `--summary` adds
`"summary": "auto"` and prints available summary items. A reasoning summary is
not the model's raw internal reasoning, and it can be absent or require access.

`max_output_tokens` is a ceiling for generated output, including reasoning. A
reasoning model can exhaust it before producing any visible answer. The small
4096-token demo budget can still be insufficient for harder questions. Check
`response.status` and `response.incomplete_details`; increase the limit only when
the task warrants it. `text.verbosity` on supporting models controls answer detail,
but does not replace a hard output cap.

## Stop sequences: stop before a marker

```python
completion = client.chat.completions.create(
    model="gpt-4.1-mini",
    messages=[{"role": "user", "content": "Write exactly: apple, banana, END, cherry"}],
    temperature=0,
    stop=["END"],
    max_completion_tokens=100,
)
print(repr(completion.choices[0].message.content))
```

Run `python 02_parameters.py stop`. If the model generates that marker, generation
ends before it; `END` is excluded from the returned text. The output might look
like `'apple, banana, '`. Stop sequences are literal and case-sensitive. A
supported Chat request accepts a string or up to four stop strings.

The parameter name is `stop`, not `stopsequence`, `stop_sequence`, or
`stop_sequences`. Responses does not expose it. Chat also has model-specific
restrictions, including reasoning models that do not support stop sequences.

`finish_reason="stop"` can mean a normal end or a configured stop match; it does
not prove your marker was generated. `finish_reason="length"` means a limit was
reached. A stop string can cut JSON in half; use Structured Outputs for data.
Trimming a Responses result in your own code changes displayed text only and
does not retroactively prevent or discount generation.

## Other settings worth recognizing

`timeout=60.0` and `max_retries=2` configure the Python client, not model creativity.
`store` controls response storage. `metadata` can attach application labels.
`parallel_tool_calls` controls whether a model may propose multiple function calls;
it does not execute your Python functions concurrently. Chat frequency penalties
reduce repeated-token tendencies, while presence penalties discourage reusing
tokens already present. They are not substitutes for a good prompt.

Sources: [Responses request parameters](https://developers.openai.com/api/reference/resources/responses/methods/create),
[Chat request parameters](https://developers.openai.com/api/reference/resources/chat/subresources/completions/methods/create),
[reasoning](https://developers.openai.com/api/docs/guides/reasoning), and
[GPT-5 guidance](https://developers.openai.com/api/docs/guides/gpt-5).
