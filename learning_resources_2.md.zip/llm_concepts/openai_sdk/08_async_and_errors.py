"""Handle request failures, run bounded async calls, or stream asynchronously."""

import argparse
import asyncio
import sys

from openai import (
    APIConnectionError, APIStatusError, APITimeoutError, AsyncOpenAI,
    AuthenticationError, BadRequestError, RateLimitError,
)

from common import make_client, model_name, require_api_key, require_completed


def error_example() -> int:
    try:
        with make_client() as client:
            response = client.responses.create(
                model=model_name(), input="Explain an API timeout in one sentence.",
                max_output_tokens=150, store=False,
            )
        require_completed(response)
        print(response.output_text)
        print("Request ID:", response._request_id)
        return 0
    except AuthenticationError:
        print("Authentication failed. Check the API key and its project.", file=sys.stderr)
    except RateLimitError:
        print("Rate or quota limit reached. Check quota and reduce request concurrency.", file=sys.stderr)
    except BadRequestError as error:
        print(f"Invalid request: {error.message}", file=sys.stderr)
    except APITimeoutError:
        print("Request timed out after SDK retries.", file=sys.stderr)
    except APIConnectionError:
        print("Could not connect. Check the network, proxy, and certificates.", file=sys.stderr)
    except APIStatusError as error:
        print(f"HTTP {error.status_code}; request ID: {error.request_id}", file=sys.stderr)
    except RuntimeError as error:
        print(str(error), file=sys.stderr)
    return 1


async def async_examples(mode: str) -> None:
    require_api_key()
    async with AsyncOpenAI(timeout=60.0, max_retries=2) as client:
        if mode == "async-stream":
            final = None
            stream = await client.responses.create(
                model=model_name(), input="Explain async/await with a short Python example.",
                max_output_tokens=500, stream=True, store=False,
            )
            async with stream:
                async for event in stream:
                    if event.type == "response.output_text.delta":
                        print(event.delta, end="", flush=True)
                    elif event.type in {"response.completed", "response.incomplete", "response.failed"}:
                        final = event.response
                    elif event.type == "error":
                        raise RuntimeError(event.message)
            print()
            if final is None:
                raise RuntimeError("Stream ended without a terminal event.")
            require_completed(final)
            return

        semaphore = asyncio.Semaphore(2)

        async def ask(prompt: str) -> str:
            async with semaphore:
                response = await client.responses.create(
                    model=model_name(), input=prompt, max_output_tokens=150, store=False,
                )
                require_completed(response)
                return response.output_text

        prompts = [
            "Define a Python generator in one sentence.",
            "Define a Python decorator in one sentence.",
            "Define a Python context manager in one sentence.",
        ]
        results = await asyncio.gather(*(ask(prompt) for prompt in prompts), return_exceptions=True)
        failures = 0
        for prompt, result in zip(prompts, results):
            print("\nPrompt:", prompt)
            if isinstance(result, BaseException):
                failures += 1
                print(f"Failed: {type(result).__name__}: {result}")
            else:
                print(result)
        if failures:
            raise RuntimeError(f"{failures} request(s) failed; other results are printed above.")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=["errors", "async", "async-stream"])
    args = parser.parse_args()
    if args.mode == "errors":
        raise SystemExit(error_example())
    asyncio.run(async_examples(args.mode))


if __name__ == "__main__":
    main()
