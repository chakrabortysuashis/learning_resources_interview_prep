# Quick reference and sources

[Back to the learning index](README.md)

## Responses versus Chat Completions

| Task | Responses API | Chat Completions |
| --- | --- | --- |
| Request | `client.responses.create(...)` | `client.chat.completions.create(...)` |
| Messages | `input=[...]` | `messages=[...]` |
| Application instructions | `instructions=...` or developer/system messages | Developer/system messages |
| Final text | `response.output_text` | `completion.choices[0].message.content` |
| Output cap | `max_output_tokens` | `max_completion_tokens` |
| Reasoning effort | `reasoning={"effort": "low"}` | `reasoning_effort="low"` |
| Stop marker | Not exposed | `stop=["END"]` on supported models |
| Function definition | Flat `type`, `name`, `description`, `parameters`, `strict` | `type="function"`, nested `function={...}` |
| Function calls | Typed `function_call` items in `response.output` | `message.tool_calls` |
| Function result | `function_call_output`, `call_id`, `output` | Role `tool`, `tool_call_id`, `content` |
| Pydantic parsing | `responses.parse(text_format=MyModel)` | `chat.completions.parse(response_format=MyModel)` |
| Parsed object | `response.output_parsed` | `completion.choices[0].message.parsed` |
| Raw schema | `text={"format": {"type": "json_schema", "name": ..., "strict": True, "schema": ...}}` | `response_format={"type": "json_schema", "json_schema": {"name": ..., "strict": True, "schema": ...}}` |
| Image part | `{"type": "input_image", "image_url": "..."}` | `{"type": "image_url", "image_url": {"url": "..."}}` |
| Streaming text | `event.type == "response.output_text.delta"`, then `event.delta` | `choice.delta.content` |
| Status | `response.status`, `incomplete_details` | `choice.finish_reason` |

## Common mistakes

| Symptom | Check |
| --- | --- |
| Unexpected `top_k` keyword | General top-k sampling is not exposed by these OpenAI endpoints |
| Temperature request returns 400 | Does the selected model/reasoning mode support sampling controls? |
| Unexpected `stop_sequences` keyword | Chat uses `stop`; Responses has no stop-sequence field |
| Empty `output_text` after a tool request | Inspect `response.output` for function calls |
| Tool outputs rejected | Preserve the calls and use each call's `call_id`, not the output item's `id` |
| Model keeps calling a forced tool | Switch from forced/required selection to `auto` after the initial call |
| Structured output is missing | Check refusal, incomplete response, and parser errors |
| Invalid strict schema | Require all keys, allow null for optional values, forbid extra object properties |
| Follow-up lacks context | Supply history or an accessible stored response ID |
| Follow-up loses application instructions | Send `instructions` again with `previous_response_id` |
| Local image path does not work | Send a data URL or upload; local paths are not public URLs |
| Streaming prints duplicated text | Append deltas once; don't append the full `done` text again |

## Official documentation

Prepared against official documentation on 2026-09-14. Models, parameter support,
and input limits can change; follow the model-specific docs when changing defaults.
Local verification uses Python 3.13, `openai` 2.40.0, and Pydantic 2.13.4.

- [Text generation and roles](https://developers.openai.com/api/docs/guides/text)
- [Responses create reference](https://developers.openai.com/api/reference/resources/responses/methods/create)
- [Chat Completions create reference](https://developers.openai.com/api/reference/resources/chat/subresources/completions/methods/create)
- [Reasoning models and summaries](https://developers.openai.com/api/docs/guides/reasoning)
- [GPT-5 family guidance](https://developers.openai.com/api/docs/guides/gpt-5)
- [GPT-4.1 mini capabilities](https://developers.openai.com/api/docs/models/gpt-4.1-mini)
- [GPT-5 mini capabilities](https://developers.openai.com/api/docs/models/gpt-5-mini)
- [Function calling](https://developers.openai.com/api/docs/guides/function-calling)
- [Structured Outputs](https://developers.openai.com/api/docs/guides/structured-outputs)
- [Streaming](https://developers.openai.com/api/docs/guides/streaming-responses)
- [Images and vision](https://developers.openai.com/api/docs/guides/images-vision)
- [File inputs](https://developers.openai.com/api/docs/guides/file-inputs)
- [Conversation state](https://developers.openai.com/api/docs/guides/conversation-state)
- [SDK installation](https://developers.openai.com/api/docs/libraries)
- [Error codes](https://developers.openai.com/api/docs/guides/error-codes)
- [Rate limits](https://developers.openai.com/api/docs/guides/rate-limits)

No lesson requires a particular model to be the latest. Account access and billed
cost are not established by offline checks. Start with the small examples and
inspect usage before expanding prompts, files, or tool loops.
