"""Offline checks for SDK parsing, tool handoffs, streaming, and upload cleanup."""

from contextlib import redirect_stdout
import importlib
import io
import json
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import MagicMock, patch

import httpx
from openai import OpenAI

LESSONS = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(LESSONS))
tools_demo = importlib.import_module("03_tool_use")
structured = importlib.import_module("04_structured_output")
streaming = importlib.import_module("05_streaming")
media = importlib.import_module("06_images_files")
common = importlib.import_module("common")


def message(text: str) -> dict:
    return {
        "id": "msg_demo", "type": "message", "role": "assistant", "status": "completed",
        "content": [{"type": "output_text", "text": text, "annotations": []}],
    }


def response_body(output: list, *, status: str = "completed") -> dict:
    return {
        "id": "resp_demo", "object": "response", "created_at": 1,
        "status": status, "model": "gpt-4.1-mini", "output": output,
        "error": None,
        "incomplete_details": {"reason": "max_output_tokens"} if status == "incomplete" else None,
        "instructions": None, "metadata": {}, "parallel_tool_calls": True,
        "tools": [], "tool_choice": "auto", "temperature": 1, "top_p": 1,
        "usage": {"input_tokens": 10, "output_tokens": 5, "total_tokens": 15,
                  "input_tokens_details": {"cached_tokens": 0},
                  "output_tokens_details": {"reasoning_tokens": 0}},
    }


def function_call(name: str, call_id: str, arguments: dict) -> dict:
    return {
        "id": f"fc_{call_id}", "type": "function_call", "call_id": call_id,
        "name": name, "arguments": json.dumps(arguments), "status": "completed",
    }


def mock_client(handler) -> OpenAI:
    return OpenAI(
        api_key="offline-test-key", max_retries=0,
        http_client=httpx.Client(transport=httpx.MockTransport(handler)),
    )


def sse_events(*, status: str = "completed", terminal: bool = True) -> bytes:
    final_message = message("Hello")
    part = final_message["content"][0]
    events = [
        {"type": "response.created", "response": response_body([], status="in_progress")},
        {"type": "response.output_item.added", "output_index": 0,
         "item": {**final_message, "status": "in_progress", "content": []}},
        {"type": "response.content_part.added", "output_index": 0, "content_index": 0,
         "item_id": "msg_demo", "part": {**part, "text": ""}},
        {"type": "response.output_text.delta", "output_index": 0, "content_index": 0,
         "item_id": "msg_demo", "delta": "Hello", "logprobs": []},
        {"type": "response.output_text.done", "output_index": 0, "content_index": 0,
         "item_id": "msg_demo", "text": "Hello", "logprobs": []},
        {"type": "response.content_part.done", "output_index": 0, "content_index": 0,
         "item_id": "msg_demo", "part": part},
        {"type": "response.output_item.done", "output_index": 0, "item": final_message},
    ]
    if terminal:
        events.append({"type": f"response.{status}", "response": response_body([final_message], status=status)})
    return "".join(
        f"event: {event['type']}\ndata: {json.dumps({**event, 'sequence_number': index})}\n\n"
        for index, event in enumerate(events)
    ).encode()


class OfflineFlowTests(unittest.TestCase):
    def setUp(self) -> None:
        self.output = io.StringIO()
        context = redirect_stdout(self.output)
        context.__enter__()
        self.addCleanup(context.__exit__, None, None, None)

    def test_multiple_tools_and_dependent_round_preserve_all_items(self) -> None:
        requests = []
        reasoning = {"id": "rs_demo", "type": "reasoning", "summary": [], "encrypted_content": "opaque-demo"}
        replies = [
            response_body([
                reasoning,
                function_call("get_course", "call_course", {"course_code": "LLM201"}),
                function_call("get_price", "call_price", {"course_code": "LLM201", "coupon": "LEARN10"}),
            ]),
            response_body([function_call("get_course", "call_prereq", {"course_code": "PY101"})]),
            response_body([message("LLM201 costs INR 2160 and requires Python Foundations.")]),
        ]

        def handler(request):
            requests.append(json.loads(request.content))
            return httpx.Response(200, json=replies[len(requests) - 1])

        with mock_client(handler) as client:
            answer = tools_demo.run_tool_loop(client, "Explain LLM201 and its prerequisites.")
        self.assertIn("2160", answer)
        second_input = requests[1]["input"]
        self.assertIn(reasoning, second_input)
        results = {item["call_id"]: json.loads(item["output"]) for item in second_input if item.get("type") == "function_call_output"}
        self.assertEqual(results["call_price"]["price"], 2160)
        self.assertEqual(results["call_course"]["prerequisites"], ["PY101"])
        third_input = requests[2]["input"]
        self.assertTrue(any(item.get("call_id") == "call_prereq" and item["type"] == "function_call_output" for item in third_input))

    def test_forced_and_required_choices_release_for_final_answer(self) -> None:
        for mode, first_choice in [
            ("required", "required"),
            ("force-price", {"type": "function", "name": "get_price"}),
        ]:
            with self.subTest(mode=mode):
                requests = []

                def handler(request):
                    requests.append(json.loads(request.content))
                    output = (
                        [function_call("get_price", "call_price", {"course_code": "PY101", "coupon": None})]
                        if len(requests) == 1 else [message("INR 1200")]
                    )
                    return httpx.Response(200, json=response_body(output))

                with mock_client(handler) as client:
                    tools_demo.run_tool_loop(client, "Price?", mode=mode)
                self.assertEqual(requests[0]["tool_choice"], first_choice)
                self.assertEqual(requests[1]["tool_choice"], "auto")
                if mode == "force-price":
                    self.assertFalse(requests[0]["parallel_tool_calls"])

    def test_tool_loop_stops_at_request_limit(self) -> None:
        def handler(request):
            return httpx.Response(200, json=response_body([
                function_call("get_course", "call_repeat", {"course_code": "PY101"})
            ]))

        with mock_client(handler) as client:
            with self.assertRaisesRegex(RuntimeError, "reached 2 requests"):
                tools_demo.run_tool_loop(client, "Keep looking it up.", max_rounds=2)

    def test_invalid_arguments_never_reach_handler(self) -> None:
        blocked_handler = MagicMock()
        with patch.dict(tools_demo.REGISTRY, {"get_price": (tools_demo.PriceArgs, blocked_handler)}):
            for arguments in ["not json", "[]", '{"course_code": 42, "coupon": null}', '{"course_code": "PY101"}', '{"course_code": "PY101", "coupon": null, "extra": true}']:
                self.assertIn("error", json.loads(tools_demo.execute_tool("get_price", arguments)))
        blocked_handler.assert_not_called()
        self.assertIn("error", json.loads(tools_demo.execute_tool("unknown", "{}")))

    def test_null_coupon_is_required_but_valid(self) -> None:
        for tool in tools_demo.TOOLS:
            schema = tool["parameters"]
            self.assertFalse(schema["additionalProperties"])
            self.assertEqual(set(schema["properties"]), set(schema["required"]))
        result = json.loads(tools_demo.execute_tool("get_price", '{"course_code": "PY101", "coupon": null}'))
        self.assertEqual(result["price"], 1200)

    def test_sdk_parses_structured_output_into_pydantic(self) -> None:
        event = {"title": "Python Study Group", "date": "2026-10-05", "participants": ["Asha"], "level": "beginner", "location": None}

        def handler(request):
            body = json.loads(request.content)
            schema = body["text"]["format"]
            self.assertEqual(schema["type"], "json_schema")
            self.assertTrue(schema["strict"])
            return httpx.Response(200, json=response_body([message(json.dumps(event))]))

        with mock_client(handler) as client:
            response = client.responses.parse(model="gpt-4.1-mini", input="Extract event", text_format=structured.StudyEvent)
        common.require_completed(response)
        self.assertIsInstance(response.output_parsed, structured.StudyEvent)
        self.assertIsNone(response.output_parsed.location)

    def test_refusal_and_incomplete_response_are_not_accepted(self) -> None:
        refused = message("")
        refused["content"] = [{"type": "refusal", "refusal": "Cannot fulfill this request."}]
        for body, reason in [
            (response_body([refused]), "Model refused"),
            (response_body([message("partial")], status="incomplete"), "incomplete"),
        ]:
            with mock_client(lambda request: httpx.Response(200, json=body)) as client:
                response = client.responses.create(model="gpt-4.1-mini", input="demo")
            with self.assertRaisesRegex(RuntimeError, reason):
                common.require_completed(response)

    def test_raw_and_helper_streams_display_deltas_once(self) -> None:
        for mode in ["responses", "helper"]:
            with self.subTest(mode=mode):
                client = mock_client(lambda request: httpx.Response(200, content=sse_events(), headers={"content-type": "text/event-stream"}))
                self.output.seek(0)
                self.output.truncate(0)
                with patch.object(streaming, "make_client", return_value=client), patch.object(sys, "argv", ["05_streaming.py", mode]):
                    streaming.main()
                self.assertEqual(self.output.getvalue().count("Hello"), 1)
                self.assertIn("Usage:", self.output.getvalue())

    def test_stream_reports_incomplete_and_missing_terminal(self) -> None:
        for payload, reason in [
            (sse_events(status="incomplete"), "incomplete"),
            (sse_events(terminal=False), "without a terminal"),
        ]:
            client = mock_client(lambda request: httpx.Response(200, content=payload, headers={"content-type": "text/event-stream"}))
            with patch.object(streaming, "make_client", return_value=client), patch.object(sys, "argv", ["05_streaming.py", "responses"]):
                with self.assertRaisesRegex(RuntimeError, reason):
                    streaming.main()

    def test_upload_is_deleted_when_generation_fails(self) -> None:
        client = MagicMock()
        client.__enter__.return_value = client
        client.files.create.return_value = SimpleNamespace(id="file_created_by_demo")
        client.responses.create.side_effect = RuntimeError("generation failed")
        argv = ["06_images_files.py", "file-upload", "--path", str(LESSONS / "sample_notes.txt")]
        with patch.object(media, "make_client", return_value=client), patch.object(sys, "argv", argv):
            with self.assertRaisesRegex(RuntimeError, "generation failed"):
                media.main()
        client.files.delete.assert_called_once_with("file_created_by_demo")


if __name__ == "__main__":
    unittest.main()
