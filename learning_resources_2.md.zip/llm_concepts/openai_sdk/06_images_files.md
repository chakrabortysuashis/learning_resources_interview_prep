# 06 - Send images, PDFs, and other files

[Index](README.md) | [Python examples](06_images_files.py) | [Next: conversation state](07_conversation_state.md)

A multimodal user message contains a list of content parts. Put the question in
an `input_text` part and the image or document in its own part. A local path such
as `C:\docs\report.pdf` is not accessible to OpenAI until you transmit its contents
or upload it. Writing a URL in plain prompt text also differs from an image/file
content part.

## Input shapes

| Source | Responses content part |
| --- | --- |
| Text | `{"type": "input_text", "text": "Summarize this."}` |
| Image URL | `{"type": "input_image", "image_url": "https://..."}` |
| Local image encoded inline | `{"type": "input_image", "image_url": "data:image/png;base64,..."}` |
| Uploaded image | `{"type": "input_image", "file_id": "file-..."}` |
| Uploaded document | `{"type": "input_file", "file_id": "file-..."}` |
| Document URL | `{"type": "input_file", "file_url": "https://..."}` |
| Inline PDF | `{"type": "input_file", "filename": "report.pdf", "file_data": "data:application/pdf;base64,..."}` |

Use one source field per part: URL, inline data, or file ID. Multiple images or
files can be separate parts in the same message, subject to model and input limits.

## Image from a URL

```python
response = client.responses.create(
    model="gpt-4.1-mini",
    input=[{"role": "user", "content": [
        {"type": "input_text", "text": "Describe this image."},
        {"type": "input_image", "image_url": image_url, "detail": "auto"},
    ]}],
)
```

The URL must be accessible to the API without your browser's login/cookies.
For example, using the public image referenced in the official vision guide:

```powershell
python 06_images_files.py image-url --url "https://api.nga.gov/iiif/a2e6da57-3cd1-4235-b20e-95dcaefed6c8/full/!800,800/0/default.jpg"
```

The script accepts `--prompt "Read the text in the image"` and image
`--detail auto|low|high`. Detail changes image preprocessing. Effects on token
usage and precision depend on the model; lower detail is not universally cheaper.
Some newer models support `original`, which is not exposed in this GPT-4.1 mini
demo. Consult the model-specific image sizing table before changing it.

## Local image as base64

```python
import base64
from pathlib import Path

encoded = base64.b64encode(Path("diagram.png").read_bytes()).decode("ascii")
image_part = {
    "type": "input_image",
    "image_url": f"data:image/png;base64,{encoded}",
}
```

Use a real path to your own supported image:

```powershell
python 06_images_files.py image-local --path "C:\images\diagram.png"
python 06_images_files.py image-local --path "C:\images\photo.jpg" --prompt "What objects are visible?"
```

PNG, JPEG, WebP, and non-animated GIF are supported image types. The script chooses
the MIME type from the extension; ensure the file actually matches it. Renaming a
PDF to `.png` does not turn it into an image. The demo does not decode images or
verify whether a GIF is animated. Base64 is encoding, not encryption, and adds
roughly one-third to the binary payload size.

## Upload a file, then reference its ID

```python
with open("report.pdf", "rb") as file:
    uploaded = client.files.create(file=file, purpose="user_data")

try:
    response = client.responses.create(
        model="gpt-4.1-mini",
        input=[{"role": "user", "content": [
            {"type": "input_text", "text": "Summarize the report."},
            {"type": "input_file", "file_id": uploaded.id},
        ]}],
    )
    print(response.output_text)
finally:
    client.files.delete(uploaded.id)
```

The upload returns metadata and an ID; it does not ask the model to analyze the
file. The Responses request is the analysis step. `purpose="user_data"` is the
recommended purpose for document inputs. The image-upload example uses
`purpose="vision"` and an `input_image` part.

```powershell
python 06_images_files.py file-upload --path "C:\docs\report.pdf"
python 06_images_files.py file-upload --path sample_notes.txt
python 06_images_files.py image-upload --path "C:\images\diagram.png"
```

The runnable upload modes delete only the upload created by that run in `finally`.
If deletion fails, they report the file ID for later cleanup. In a real application
you may keep uploads for reuse, then delete them when the workflow is finished.
Reusing a file ID is not a guarantee that subsequent model processing is free.
`store=False` on a response does not delete separately uploaded Files API objects.

## Inline PDF or public document URL

```powershell
python 06_images_files.py file-base64 --path "C:\docs\report.pdf"
python 06_images_files.py file-url --url "https://www.berkshirehathaway.com/letters/2024ltr.pdf"
```

Inline PDFs use `filename` and `file_data` with a PDF data URL. This avoids creating
a separately managed Files API object. The demo limits this mode to PDFs to keep
the MIME handling clear. External file URLs use `file_url`, not `image_url`.

The current file-input guide explains these differences:

- PDF processing on vision-capable models includes extracted text and page images.
- Non-PDF documents and code files contribute extracted text; embedded images and
  charts are not included. Converting a document to PDF can preserve visual content.
- Spreadsheet inputs use an augmentation process that reads up to the first 1,000
  rows per sheet and adds summaries/metadata. Do not assume the whole workbook was
  examined or use that limited view for exact full-dataset calculations.
- Each file must be under 50 MB, and all files in a request together have a 50 MB
  limit. The extracted content must also fit the model's context window.

For PDF page images, Responses also supports an `input_file` `detail` of `auto`,
`low`, or `high`. It affects page-image processing, not extracted text. For example:

```python
pdf_part = {"type": "input_file", "file_id": uploaded.id, "detail": "high"}
```

The demo's CLI `--detail` applies to images only. Document modes use PDF defaults.
Vision descriptions, OCR, chart interpretation, and counting can be wrong; check
the source when accuracy matters. Avoid printing image base64 or document contents
to logs unnecessarily.

## Small local text file without an upload

```powershell
python 06_images_files.py text-file
python 06_images_files.py text-file --path "C:\docs\notes.txt"
```

The default [sample notes](sample_notes.txt) make this mode immediately runnable.
It reads UTF-8 text and sends an `input_text` part. This is appropriate for small
text files that fit in context. It is not a PDF parser and cannot read binary
Word/Excel documents as text. It still transmits the file's text to the API.

For searching across a large document collection, use a retrieval workflow such
as [File Search](https://developers.openai.com/api/docs/guides/tools-file-search).
Uploading a file alone does not build that retrieval workflow. For precise
spreadsheet calculations, use a suitable computation tool.

Chat uses different image shapes, such as
`{"type": "image_url", "image_url": {"url": "https://..."}}`. Responses uses
`input_image` with a string `image_url`. Do not mix these shapes.

Sources: [OpenAI images and vision](https://developers.openai.com/api/docs/guides/images-vision)
and [file inputs](https://developers.openai.com/api/docs/guides/file-inputs).
