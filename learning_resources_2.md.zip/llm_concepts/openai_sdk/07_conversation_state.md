# 07 - Continue a conversation

[Index](README.md) | [Python examples](07_conversation_state.py) | [Next: async and errors](08_async_and_errors.md)

Creating one `OpenAI()` client does not give it conversational memory. The client
manages requests and connections. You must supply history or reference API-managed
state when asking a follow-up such as "Show an example of that."

## Explicit history

```python
history = [{"role": "user", "content": "I am building a Python library catalog."}]
first = client.responses.create(
    model="gpt-4.1-mini",
    instructions="Be a concise Python tutor.",
    input=history,
    store=False,
)
history.extend(first.output)
history.append({"role": "user", "content": "Suggest a data structure for it."})
second = client.responses.create(
    model="gpt-4.1-mini",
    instructions="Be a concise Python tutor.",
    input=history,
    store=False,
)
```

Run `python 07_conversation_state.py manual`. It makes two requests and prints both
answers. The full output items are preserved, including tool calls and reasoning
items if they are present. If you reconstruct history using only `output_text`,
you lose those other items.

The script includes `reasoning.encrypted_content` for compatibility with stateless
reasoning histories. Current documentation says encrypted content is automatically
included for stateless responses. Treat it as opaque state and pass it back with
the other output items.

Manual history gives your application control over what it sends. You must manage
growth, keep required tool call/result pairs intact, and eventually summarize,
compact, or otherwise limit history for long conversations. Be deliberate about
which context gets dropped.

## Stored response IDs

```python
first = client.responses.create(
    model="gpt-4.1-mini",
    instructions="Be a concise Python tutor.",
    input="I am building a library catalog. Suggest a data structure.",
    store=True,
)
second = client.responses.create(
    model="gpt-4.1-mini",
    previous_response_id=first.id,
    instructions="Be a concise Python tutor.",
    input="Show how to add one item to it.",
    store=True,
)
```

Run `python 07_conversation_state.py previous-id`. This mode explicitly stores the
responses so the second request can reference the first. It requires a project
configuration that permits response storage. Do not point `previous_response_id`
at an unstored, deleted, or inaccessible response.

The earlier `instructions` are **not** automatically carried forward by
`previous_response_id`. Send application instructions again for each request. Pass
only new input when linking by ID; also resending the same full history duplicates
context. The stored chain provides model context, not free tokens: previous context
can still count toward input usage.

## Choose a state strategy

| Strategy | Application responsibility | Storage implication |
| --- | --- | --- |
| Manual `input` history | Keep and replay messages/output items | Can use `store=False` |
| `previous_response_id` | Keep the latest response ID and send new inputs | Referenced response must be available |
| Conversations API | Manage a durable conversation ID and its items | API-managed conversation resource |

The Conversations API is another option for durable conversations. A Responses
request can reference `conversation=...`; do not combine it with
`previous_response_id`. The two runnable modes are enough to learn the core
state concepts without introducing another resource lifecycle.

`store=False` is specifically a response-storage setting, not a promise of zero
retention everywhere. Data controls, abuse-monitoring retention, uploaded files,
and application logs have separate rules and lifecycles.

Exercise: add a third user turn asking for a dictionary lookup. Try both strategies
and inspect which information you must retain between requests.

Sources: [conversation state](https://developers.openai.com/api/docs/guides/conversation-state),
[text instructions](https://developers.openai.com/api/docs/guides/text), and
[reasoning state](https://developers.openai.com/api/docs/guides/reasoning).
