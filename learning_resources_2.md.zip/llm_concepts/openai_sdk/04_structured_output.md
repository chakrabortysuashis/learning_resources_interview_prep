# 04 - Turn model output into typed data

[Index](README.md) | [Python examples](04_structured_output.py) | [Next: streaming](05_streaming.md)

Use tools when the model needs to request an action or retrieve external data.
Use Structured Outputs when your application needs the model's answer in a known
shape. The two features can be combined: retrieve with a tool, then return a
structured final answer.

## Three levels of structure

| Approach | What it provides | What you must still check |
| --- | --- | --- |
| Prompt says "return JSON" | A natural-language request for formatting | JSON validity, keys, types, and facts |
| JSON mode, `{"type": "json_object"}` | Valid JSON for a successful complete output | Schema adherence and facts; handle interrupted output |
| Structured Outputs, strict JSON Schema | Schema-constrained output on supporting models | Refusal, incomplete output, and semantic correctness |

A schema can require an integer. It cannot by itself ensure the integer is the
correct price from your database. Schema guarantees apply to successful structured
responses, not to refusals or output that was cut short.

## Pydantic: define the shape in Python

```python
from pydantic import BaseModel, ConfigDict

class StudyEvent(BaseModel):
    model_config = ConfigDict(extra="forbid")
    title: str
    date: str
    participants: list[str]
    location: str | None

response = client.responses.parse(
    model="gpt-4.1-mini",
    instructions="Extract the event. Use null for a missing location.",
    input="Asha and Ravi have a Python study group on 2026-10-05. Location undecided.",
    text_format=StudyEvent,
)
event = response.output_parsed
```

The SDK converts the Pydantic class to a schema and parses successful output back
into a `StudyEvent`. `text_format` is the SDK parsing helper's argument, not a
top-level REST field. It becomes a JSON Schema configuration under `text.format`.

After checking response status/refusal and confirming `event is not None`, use
`event.title` and `event.participants` as typed values. The full Python example adds
an enum `level`, explicit checks, and `event.model_dump_json(indent=2)`.

```powershell
python 04_structured_output.py pydantic
```

A plausible result is:

```json
{
  "title": "Python Study Group",
  "date": "2026-10-05",
  "participants": ["Asha", "Ravi"],
  "level": "beginner",
  "location": null
}
```

## Raw JSON Schema: understand the wire format

```python
response = client.responses.create(
    model="gpt-4.1-mini",
    input="Extract an event from this source text...",
    text={"format": {
        "type": "json_schema",
        "name": "study_event",
        "strict": True,
        "schema": {
            "type": "object",
            "properties": {
                "title": {"type": "string"},
                "location": {"type": ["string", "null"]},
            },
            "required": ["title", "location"],
            "additionalProperties": False,
        },
    }},
)
```

The runnable `schema` mode contains all five event fields and validates the returned
JSON locally. Its schema name labels the output format; it is not a function
name to execute.

```powershell
python 04_structured_output.py schema
```

Structured Outputs supports a subset of JSON Schema. The root must be an object;
object properties are required, and objects need `additionalProperties: false`.
Nested objects need the same treatment. Use an enum for a finite set of choices.
Check the official guide before using advanced keywords or very large schemas.

`location: str | None` is required and nullable in Pydantic v2. Writing
`location: str | None = None` changes whether the field is required in the generated
schema. The examples deliberately use the former. Missing information becomes a
present key with `null` rather than an omitted key or an invented value.

## JSON mode and local validation

```python
response = client.responses.create(
    model="gpt-4.1-mini",
    instructions="Return JSON containing the extracted event fields.",
    input="Asha and Ravi have a Python study group on 2026-10-05.",
    text={"format": {"type": "json_object"}},
)
```

Explicitly instruct the model to produce JSON; the API checks for `JSON` in the
context. JSON mode alone does not enforce keys, enums, or types. The runnable
`json-mode` example validates with `StudyEvent.model_validate_json()` and lets a
validation failure surface, so you can observe the weaker contract.

```powershell
python 04_structured_output.py json-mode
```

## Failure handling is part of parsing

Check `response.status`. If it is `incomplete`, examine `incomplete_details` before
using the data. Also inspect message content for `type="refusal"`. A refusal may
arrive in an otherwise completed response and does not follow your event schema.
`common.require_completed()` performs these checks in the examples.

The parsing helper or local validator can also raise parsing/validation exceptions,
including when text is truncated. In an application, catch the relevant exception
at the feature boundary and report that extraction failed. Never continue with a
partially parsed object as if it were complete.

Do not assume a date-shaped string is a real date. This lesson requests YYYY-MM-DD
but declares it as a string; add date validation and business rules when needed.

## Chat Completions equivalent

```python
completion = client.chat.completions.parse(
    model="gpt-4.1-mini",
    messages=[{"role": "user", "content": "Extract the event from this text..."}],
    response_format=StudyEvent,
)
event = completion.choices[0].message.parsed
```

Check `message.refusal` and completion state before using `parsed`. For raw Chat
JSON Schema, `response_format` contains `{"type": "json_schema", "json_schema":
{"name": ..., "strict": True, "schema": ...}}`. Do not send this Chat wrapper as
Responses `text.format`; the nesting differs.

Exercise: add `duration_minutes` as a nullable integer, update the source text,
and compare the three modes. Also try an input with no location and verify that
your downstream code handles `None`.

Source: [OpenAI Structured Outputs](https://developers.openai.com/api/docs/guides/structured-outputs).
