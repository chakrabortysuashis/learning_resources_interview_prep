"""Stream text with Responses events, its accumulating helper, or Chat Completions."""

import argparse

from common import make_client, model_name, require_completed

PROMPT = "Explain how a Python generator works, with one small example."


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=["responses", "helper", "chat"])
    args = parser.parse_args()

    with make_client() as client:
        if args.mode == "chat":
            finish_reason = None
            refused = False
            usage = None
            with client.chat.completions.create(
                model=model_name(),
                messages=[{"role": "user", "content": PROMPT}],
                max_completion_tokens=600,
                stream=True,
                stream_options={"include_usage": True},
            ) as stream:
                for chunk in stream:
                    if chunk.usage:
                        usage = chunk.usage
                    # The final usage chunk can have no choices.
                    for choice in chunk.choices:
                        if choice.delta.content:
                            print(choice.delta.content, end="", flush=True)
                        if choice.delta.refusal:
                            refused = True
                        if choice.finish_reason:
                            finish_reason = choice.finish_reason
            print()
            if refused:
                raise RuntimeError("Model refused the request.")
            if finish_reason != "stop":
                raise RuntimeError(f"Stream did not finish normally: {finish_reason}")
            if usage:
                print("Usage:", usage.model_dump())
            return

        if args.mode == "helper":
            with client.responses.stream(
                model=model_name(), input=PROMPT, max_output_tokens=600, store=False,
            ) as stream:
                for event in stream:
                    if event.type == "response.output_text.delta":
                        print(event.delta, end="", flush=True)
                    elif event.type == "error":
                        raise RuntimeError(event.message)
                final = stream.get_final_response()
        else:
            final = None
            with client.responses.create(
                model=model_name(), input=PROMPT, max_output_tokens=600,
                stream=True, store=False,
            ) as stream:
                for event in stream:
                    if event.type == "response.output_text.delta":
                        print(event.delta, end="", flush=True)
                    elif event.type in {"response.completed", "response.incomplete", "response.failed"}:
                        final = event.response
                    elif event.type == "error":
                        raise RuntimeError(event.message)
            if final is None:
                raise RuntimeError("Stream ended without a terminal response event.")
        print()
        require_completed(final)
        if final.usage:
            print("Usage:", final.usage.model_dump())


if __name__ == "__main__":
    main()
