"""Run one example: python 01_basic_messages.py simple|roles|few-shot|chat"""

import argparse

from common import make_client, model_name, require_completed


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=["simple", "roles", "few-shot", "chat"])
    args = parser.parse_args()

    with make_client() as client:
        if args.mode == "chat":
            completion = client.chat.completions.create(
                model=model_name(),
                messages=[
                    {"role": "system", "content": "You are a concise Python tutor."},
                    {"role": "user", "content": "What is a list?"},
                    {"role": "assistant", "content": "An ordered, mutable collection."},
                    {"role": "user", "content": "Show me one containing three numbers."},
                ],
                max_completion_tokens=300,
            )
            choice = completion.choices[0]
            if choice.message.refusal:
                raise RuntimeError(choice.message.refusal)
            if choice.finish_reason != "stop":
                raise RuntimeError(f"Unexpected finish reason: {choice.finish_reason}")
            print(choice.message.content)
            return

        if args.mode == "simple":
            response = client.responses.create(
                model=model_name(),
                instructions="You are a patient Python tutor. Use a short example.",
                input="Explain a Python dictionary to a beginner.",
                max_output_tokens=300,
                store=False,
            )
        else:
            if args.mode == "roles":
                messages = [
                    {"role": "system", "content": "You are an accurate coding tutor."},
                    {"role": "developer", "content": "Use plain English and short examples."},
                    {"role": "user", "content": "What is a Python list?"},
                    {"role": "assistant", "content": "An ordered, mutable collection."},
                    {"role": "user", "content": "How is a tuple different?"},
                ]
            else:
                messages = [
                    {"role": "developer", "content": "Classify sentiment. Reply positive, negative, or neutral."},
                    {"role": "user", "content": "This lesson was wonderful."},
                    {"role": "assistant", "content": "positive"},
                    {"role": "user", "content": "The installation failed again."},
                    {"role": "assistant", "content": "negative"},
                    {"role": "user", "content": "The package contains three modules."},
                ]
            response = client.responses.create(
                model=model_name(),
                input=messages,
                max_output_tokens=300,
                store=False,
            )
        require_completed(response)
        print(response.output_text)
        if response.usage:
            print("Usage:", response.usage.model_dump())


if __name__ == "__main__":
    main()
