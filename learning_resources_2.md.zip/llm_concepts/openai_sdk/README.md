# OpenAI Python SDK: learn by running examples

Start with a prompt, then add generation controls, tools, typed JSON, streaming,
images, files, and conversation history. Each numbered Markdown lesson has a
Python file with the same name. Read the lesson, run one example, then change it.

These lessons use the official `openai` Python package. The Responses API is the
main API; Chat Completions examples show its different request and response shapes.
No framework or Agents SDK is required.

## Setup

Use Python 3.10 or newer. From the repository root in PowerShell:

```powershell
cd llm_concepts\openai_sdk
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
$env:OPENAI_API_KEY="your-api-key"
.\.venv\Scripts\python.exe 01_basic_messages.py simple
```

Activate the environment to use the shorter `python` commands throughout the
lessons. Activation is optional; using its Python executable directly also works.

```powershell
.\.venv\Scripts\Activate.ps1
python 01_basic_messages.py roles
```

On macOS/Linux:

```bash
cd llm_concepts/openai_sdk
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
export OPENAI_API_KEY="your-api-key"
python 01_basic_messages.py simple
```

Get an API key from [the API platform](https://platform.openai.com/api-keys).
API usage is billed separately from a ChatGPT subscription. Never put a real key
in source code. `OpenAI()` reads the environment; it does not load `.env` files
automatically. These examples do not use a dotenv dependency.

## Learning order

| Read | Run | What you learn |
| --- | --- | --- |
| [01 Basic messages](01_basic_messages.md) | `python 01_basic_messages.py roles` | System, developer, user, assistant, and few-shot prompts |
| [02 Parameters](02_parameters.md) | `python 02_parameters.py temperature` | Temperature, top-p, top-k limitations, reasoning, stop, tokens |
| [03 Tool use](03_tool_use.md) | `python 03_tool_use.py auto` | JSON Schema, multiple tools, selection, dispatch, results |
| [04 Structured output](04_structured_output.md) | `python 04_structured_output.py pydantic` | Pydantic parsing, JSON Schema, JSON mode, refusals |
| [05 Streaming](05_streaming.md) | `python 05_streaming.py responses` | Text deltas, completion, usage, streamed tool arguments |
| [06 Images and files](06_images_files.md) | `python 06_images_files.py text-file` | Image URLs/base64, file uploads, PDF inputs, cleanup |
| [07 Conversation state](07_conversation_state.md) | `python 07_conversation_state.py manual` | History, response IDs, repeated instructions |
| [08 Async and errors](08_async_and_errors.md) | `python 08_async_and_errors.py errors` | Async calls, bounded concurrency, retries, status errors |

Run `python <file>.py --help` for the available modes. Imports and `--help` make
no API calls. Running a mode makes real, potentially billable requests. Tool loops,
conversation examples, and the async batch can make more than one request. Tool
data is a small, explicitly fictional local catalog.

## Models and compatibility

The defaults are deliberately chosen to teach two different kinds of controls:

| Environment variable | Default | Used for |
| --- | --- | --- |
| `OPENAI_MODEL` | `gpt-4.1-mini` | Text, temperature/top-p, stop via Chat Completions, tools, structured output, vision |
| `OPENAI_REASONING_MODEL` | `gpt-5-mini` | Reasoning effort examples |

These are educational defaults, not a claim that they are the newest models.
Model availability depends on your project. To change them:

```powershell
$env:OPENAI_MODEL="gpt-4.1-mini"
$env:OPENAI_REASONING_MODEL="gpt-5-mini"
```

A model change can also require parameter changes. In particular, the original
GPT-5 family does not accept the sampling controls demonstrated with GPT-4.1.
See the [parameter compatibility table](02_parameters.md#compatibility-table).
Do not send every parameter in the same call.

## Smallest complete request

```python
from openai import OpenAI

client = OpenAI()
response = client.responses.create(
    model="gpt-4.1-mini",
    instructions="You are a patient Python tutor. Use one short example.",
    input="Explain a list comprehension.",
    max_output_tokens=300,
    store=False,
)
print(response.output_text)
```

`input` is the request, `instructions` sets application behavior, and
`output_text` collects generated text. The longer scripts also check response
status and refusals. `common.py` only shares configuration and those checks so
the API calls remain visible in each lesson.

## Offline checks

After installing the dependencies, run these without an API key:

```powershell
python -m compileall -q . -x "[\\/]\.venv[\\/]"
python -m unittest discover -s tests -v
```

The tests use mocked HTTP responses to check tool handoffs and failure paths.
They do not establish real model quality, account access, or service availability.
See [the quick reference and official sources](REFERENCE.md) for endpoint mappings
and the documentation used to prepare these lessons.
