# 01 - Build a prompt and call the API

[Index](README.md) | [Python examples](01_basic_messages.py) | [Next: parameters](02_parameters.md)

## What is a prompt?

A prompt is the context you send to the model: application instructions, the
user's question, examples, previous messages, and possibly images or documents.
It does not have to be one large string. A message has a `role` and `content`.

| Role | Purpose | Example |
| --- | --- | --- |
| `system` | High-priority instructions supported by the selected API/model | "You are an accurate Python tutor." |
| `developer` | Application rules and output preferences; the usual role for application instructions in modern examples | "Use short examples. Ask for missing inputs." |
| `user` | The learner's request or supplied data | "Explain a tuple." |
| `assistant` | An earlier model answer or an example of the desired answer | "A tuple is an ordered, immutable collection." |

System and developer instructions take priority over user messages. Within this
instruction hierarchy, system has higher authority than developer. Usually choose
one consistent place for your application instructions; the `roles` example
includes both to make their shapes visible. Some model families prefer developer
messages in place of older system-message patterns; consult that model's guide.

An `assistant` message does not mean "instructions for the assistant." It represents
something the assistant previously said, or a demonstration you provide. The next
answer is also an assistant output. You do not need to append an empty assistant
message or prefill it with `"Sure, here is..."`.

## First request, line by line

```python
from openai import OpenAI

client = OpenAI()  # Reads OPENAI_API_KEY from the environment.
response = client.responses.create(
    model="gpt-4.1-mini",
    instructions="You are a patient Python tutor. Give one short example.",
    input="What is a dictionary?",
    max_output_tokens=300,
    store=False,
)
print(response.output_text)
```

`model` chooses the model. `instructions` supplies high-priority behavior for this
request. A string `input` is a convenient way to send a user request.
`max_output_tokens` caps generated tokens, not words. `store=False` disables
response storage for later retrieval; it is not a blanket data-retention guarantee.

`response` is an SDK object. `response.output` is a list of typed items which can
include messages, reasoning, or tool calls. `response.output_text` joins its text
outputs. Do not assume the first item is always a text message.

```powershell
python 01_basic_messages.py simple
```

## Send explicit messages

```python
response = client.responses.create(
    model="gpt-4.1-mini",
    input=[
        {"role": "developer", "content": "Teach Python using short examples."},
        {"role": "user", "content": "What is a list?"},
        {"role": "assistant", "content": "An ordered, mutable collection."},
        {"role": "user", "content": "How is a tuple different?"},
    ],
    store=False,
)
```

Messages are ordered history. The last question uses the earlier exchange as
context. The Python script's `roles` mode also includes a `system` message.

```powershell
python 01_basic_messages.py roles
```

The client does not remember previous calls automatically. This request works
because the history is in the payload. [Lesson 07](07_conversation_state.md)
shows how to append actual model outputs or use a stored response ID.

## Few-shot prompting

"Zero-shot" means giving the task without demonstrations. "Few-shot" means adding
a few examples. Alternating `user` and `assistant` messages can teach a pattern:

```python
messages = [
    {"role": "developer", "content": "Reply positive, negative, or neutral."},
    {"role": "user", "content": "This lesson was wonderful."},
    {"role": "assistant", "content": "positive"},
    {"role": "user", "content": "The installation failed again."},
    {"role": "assistant", "content": "negative"},
    {"role": "user", "content": "The package contains three modules."},
]
```

Run `python 01_basic_messages.py few-shot`. A plausible answer is `neutral`.
Examples influence behavior; they do not train or update the model's weights.
Use diverse, correct examples. For an enforced enum, use Structured Outputs.

## A practical prompt pattern

State the task, necessary context, constraints, and desired result:

```text
You are a Python tutor for someone who understands lists.
Explain dictionaries using a library catalog example.
Use one code block and no more than three explanatory sentences.
If the question lacks needed information, identify what is missing.
```

Keep fixed application rules in `instructions` or a developer message. Put changing
user content in user messages. Supply source documents as data, and tell the model
when it should use them. Do not place untrusted document text in system/developer
messages. Role separation helps, but it does not make prompt injection impossible.

For reasoning models, ask for the result and a useful explanation. You do not need
to demand hidden chain-of-thought or prescribe every internal reasoning step.

## Chat Completions equivalent

```python
completion = client.chat.completions.create(
    model="gpt-4.1-mini",
    messages=[
        {"role": "system", "content": "You are a concise Python tutor."},
        {"role": "user", "content": "Explain a list."},
    ],
    max_completion_tokens=300,
)
print(completion.choices[0].message.content)
```

Run `python 01_basic_messages.py chat`. Chat uses `messages`, whereas Responses
uses `input`. Their response objects are also different. See the [API mapping](REFERENCE.md).

## Try it

Change the tutor's audience to an experienced Java developer. Then add two examples
of your preferred explanation style. Compare what changed while keeping the user
question constant. Model text is variable, so evaluate usefulness and correctness,
not equality to a particular sentence.

Source: [OpenAI text generation and message roles](https://developers.openai.com/api/docs/guides/text).
