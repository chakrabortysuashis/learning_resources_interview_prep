"""Continue a conversation with explicit history or a stored response ID."""

import argparse

from common import make_client, model_name, require_completed

INSTRUCTIONS = "You are a concise Python tutor. Use the learner's stated project as context."


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=["manual", "previous-id"])
    args = parser.parse_args()
    with make_client() as client:
        history = [{"role": "user", "content": "I am building a library catalog in Python. Suggest a data structure."}]
        first = client.responses.create(
            model=model_name(), instructions=INSTRUCTIONS, input=history,
            max_output_tokens=400, store=args.mode == "previous-id",
            include=["reasoning.encrypted_content"],
        )
        require_completed(first)
        print("Turn 1:", first.output_text)
        follow_up = "Show how to add one item to it."

        if args.mode == "previous-id":
            second = client.responses.create(
                model=model_name(),
                previous_response_id=first.id,
                instructions=INSTRUCTIONS,
                input=follow_up,
                max_output_tokens=400,
                store=True,
            )
        else:
            history.extend(first.output)
            history.append({"role": "user", "content": follow_up})
            second = client.responses.create(
                model=model_name(), instructions=INSTRUCTIONS, input=history,
                max_output_tokens=400, store=False,
                include=["reasoning.encrypted_content"],
            )
        require_completed(second)
        print("Turn 2:", second.output_text)


if __name__ == "__main__":
    main()
