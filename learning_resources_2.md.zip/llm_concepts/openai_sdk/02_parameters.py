"""Try temperature, top-p, reasoning, or stop; each mode makes one API call."""

import argparse

from common import make_client, model_name, require_completed


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=["temperature", "top-p", "reasoning", "stop"])
    parser.add_argument("--temperature", type=float, default=0.2)
    parser.add_argument("--top-p", type=float, default=0.9)
    parser.add_argument("--effort", choices=["minimal", "low", "medium", "high"], default="low")
    parser.add_argument("--summary", action="store_true", help="Request a reasoning summary, if supported")
    args = parser.parse_args()
    if not 0 <= args.temperature <= 2:
        parser.error("temperature must be between 0 and 2")
    if not 0 < args.top_p <= 1:
        parser.error("this demo accepts top-p in (0, 1]")

    with make_client() as client:
        if args.mode == "stop":
            completion = client.chat.completions.create(
                model=model_name(),
                messages=[{
                    "role": "user",
                    "content": "Write exactly: apple, banana, END, cherry",
                }],
                temperature=0,
                stop=["END"],
                max_completion_tokens=100,
            )
            choice = completion.choices[0]
            if choice.message.refusal:
                raise RuntimeError(choice.message.refusal)
            print(repr(choice.message.content))
            print("finish_reason:", choice.finish_reason)
            return

        if args.mode == "reasoning":
            reasoning = {"effort": args.effort}
            if args.summary:
                reasoning["summary"] = "auto"
            response = client.responses.create(
                model=model_name(reasoning=True),
                reasoning=reasoning,
                input=(
                    "A notebook and a pen cost 110 rupees in total. The notebook "
                    "costs 100 rupees more than the pen. What does each cost? "
                    "Give the answer and a short algebraic justification."
                ),
                max_output_tokens=4096,
                store=False,
            )
        else:
            # Tune one sampling control at a time; do not forward it to reasoning mode.
            sampling = (
                {"temperature": args.temperature}
                if args.mode == "temperature"
                else {"top_p": args.top_p}
            )
            response = client.responses.create(
                model=model_name(),
                input="Suggest three names for a Python study group.",
                max_output_tokens=200,
                store=False,
                **sampling,
            )

        require_completed(response)
        print(response.output_text)
        for item in response.output:
            if item.type == "reasoning":
                for part in item.summary:
                    if part.type == "summary_text":
                        print("Reasoning summary:", part.text)
        if response.usage:
            print("Usage:", response.usage.model_dump())


if __name__ == "__main__":
    main()
