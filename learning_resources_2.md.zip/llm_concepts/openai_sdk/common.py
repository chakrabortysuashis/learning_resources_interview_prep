"""Shared setup only; the actual SDK calls stay visible in each lesson."""

import os

from openai import OpenAI
from openai.types.responses import Response


def model_name(*, reasoning: bool = False) -> str:
    if reasoning:
        return os.getenv("OPENAI_REASONING_MODEL", "gpt-5-mini")
    return os.getenv("OPENAI_MODEL", "gpt-4.1-mini")


def require_api_key() -> None:
    if not os.getenv("OPENAI_API_KEY"):
        raise SystemExit(
            'Set OPENAI_API_KEY first. PowerShell: $env:OPENAI_API_KEY="your-key"'
        )


def make_client() -> OpenAI:
    require_api_key()
    return OpenAI(timeout=60.0, max_retries=2)


def require_completed(response: Response) -> None:
    """A successful HTTP request can still contain an incomplete or refused answer."""
    if response.status != "completed":
        raise RuntimeError(
            f"Response status={response.status}; "
            f"details={response.incomplete_details}; error={response.error}"
        )
    for item in response.output:
        if item.type == "message":
            for part in item.content:
                if part.type == "refusal":
                    raise RuntimeError(f"Model refused: {part.refusal}")
