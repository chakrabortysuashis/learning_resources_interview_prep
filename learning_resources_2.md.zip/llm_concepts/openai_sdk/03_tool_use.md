# 03 - Define tools and choose among them

[Index](README.md) | [Python examples](03_tool_use.py) | [Next: structured output](04_structured_output.md)

A tool connects a model to a capability in your application. A function schema
describes that capability; it does not upload or execute the Python function.
The model requests a call, your code validates and executes it, and you return
the result so the model can answer or request another call.

## The complete flow

```text
User asks about a course
  -> Send question and available tool schemas
  -> Model returns get_course and/or get_price calls
  -> Python validates the arguments and runs local functions
  -> Python returns each result with its call_id
  -> Model answers, or requests another tool
```

The demo has two tools backed by a fictional local catalog:

| Tool | When to select it | Arguments |
| --- | --- | --- |
| `get_course` | Title, prerequisites, duration | `course_code` |
| `get_price` | Price in INR, optionally with a supplied coupon | `course_code`, nullable `coupon` |

Separating their descriptions gives the model a reason to choose one or both.
The model reads names, descriptions, argument schemas, and conversation context.
`auto` selection is a model decision, not a deterministic Python router.

## Anatomy of a Responses function schema

```python
tool = {
    "type": "function",
    "name": "get_price",
    "description": "Read a fictional course price in INR. Does not charge anyone.",
    "parameters": {
        "type": "object",
        "properties": {
            "course_code": {
                "type": "string",
                "description": "Course identifier, such as PY101 or LLM201.",
            },
            "coupon": {
                "type": ["string", "null"],
                "description": "User-supplied coupon, otherwise null.",
            },
        },
        "required": ["course_code", "coupon"],
        "additionalProperties": False,
    },
    "strict": True,
}
```

`type="function"` identifies the tool kind. `name` is the identifier used to
dispatch a returned call. `description` explains when to use it. `parameters`
is a JSON Schema for the arguments, not the return value. `strict=True` requests
schema adherence on supported models.

With strict schemas, all properties are required and objects must set
`additionalProperties: false`. A conceptually optional value can be nullable
while its key remains required: `"coupon": null`. In Python dictionaries write
`True`, `False`, and `None`; serialized JSON uses `true`, `false`, and `null`.

The runnable script generates equivalent schemas from Pydantic classes using
`model_json_schema()`. `ConfigDict(extra="forbid")` prevents extra keys, and
`coupon: str | None` without a default makes the key required but nullable.
Pydantic's `strict=True` checks local argument types; the tool's `strict=True`
is a separate API setting. Both are useful.

## Choose one tool, several, or none

```python
response = client.responses.create(
    model="gpt-4.1-mini",
    input="Give the prerequisites and discounted price of LLM201 using LEARN10.",
    tools=TOOLS,
    tool_choice="auto",
    parallel_tool_calls=True,
)
```

| `tool_choice` | Meaning | Demo |
| --- | --- | --- |
| `"auto"` | Model can answer directly or request tool calls | `python 03_tool_use.py auto` |
| `"required"` | Must request at least one tool | `python 03_tool_use.py required` |
| `"none"` | Cannot call any supplied tool | `python 03_tool_use.py none` |
| `{"type": "function", "name": "get_price"}` | Force this named function | `python 03_tool_use.py force-price` |

The demo applies required/forced selection on the first request, then switches
to `auto`. Otherwise a forced call could repeat forever and prevent a final
answer. Forcing a name still leaves argument generation to the model; application
validation remains necessary. To expose only a subset, pass only that subset in
`tools`. Some models also support more advanced allowed-tool controls.

`parallel_tool_calls=True` permits multiple calls in a response. The demo executes
them sequentially in Python. You can use concurrency for independent read-only
tools when appropriate. Dependent calls, such as looking up an ID before using
it, naturally require additional rounds. Setting it to `False` limits function
calling to zero or one per turn, or one when tool choice requires it.

## Inspect, validate, execute, and return results

```python
history.extend(response.output)

for call in response.output:
    if call.type != "function_call":
        continue
    result = execute_tool(call.name, call.arguments)
    history.append({
        "type": "function_call_output",
        "call_id": call.call_id,
        "output": result,
    })
```

`call.arguments` is a JSON string. Parse and validate it before passing values to
code. The script uses `model_validate_json()` and a name-to-function allowlist.
It never uses `eval()`, dynamic imports from model names, or arbitrary `getattr()`.
Unknown names and invalid arguments produce useful tool errors without executing.

`call.call_id` associates this result with that exact call. It is distinct from
the output item's `id`; do not substitute one for the other. Process every call,
not just `response.output[0]`. Results here are serialized with `json.dumps()`.

Preserve **all** model output items before appending results, including reasoning
items where present. With stateless reasoning workflows, encrypted reasoning
content can preserve continuity. The example includes
`include=["reasoning.encrypted_content"]` for compatibility; current documentation
says stateless responses include it automatically. This is opaque state, not text
you should decrypt or display.

Send the expanded `history` with the same tools and instructions. Continue until
there are no function calls, checking completion/refusal on each response.
The script stops with an error after five requests if no final answer arrives.

## Expected result and exercises

The catalog says LLM201 takes 16 hours, requires PY101, and costs INR 2400.
`LEARN10` makes the price INR 2160. The model's wording and call order can vary.

```powershell
python 03_tool_use.py auto --prompt "How many hours is PY101?"
python 03_tool_use.py force-price --prompt "What does PY101 cost? I have no coupon."
python 03_tool_use.py auto --prompt "What does UNKNOWN cost?"
```

Add a `get_schedule` tool as an exercise. Define a schema, add an allowlisted
handler, and give its description a clear purpose. For real tools, enforce user
authorization and domain rules in code. A valid schema does not establish that
an action is authorized or an argument is factually correct. For writes, design
confirmation and idempotency according to your application's needs.

## Chat Completions and built-in tools

Chat nests a function definition inside a `function` key:

```python
chat_tool = {"type": "function", "function": {
    "name": tool["name"], "description": tool["description"],
    "parameters": tool["parameters"], "strict": True,
}}
chat_choice = {"type": "function", "function": {"name": "get_price"}}
```

Chat returns `message.tool_calls`. Preserve the assistant message, then append
`{"role": "tool", "tool_call_id": call.id, "content": result}` for each call.
Responses instead uses the flat schema and `function_call_output` items above.

OpenAI-hosted tools, such as `tools=[{"type": "web_search"}]` on a supporting
Responses model, run on the service. They are different from your local functions
and can have tool-specific charges. File Search also requires a configured vector
store. These are optional extensions beyond this local function-calling lesson.

Source: [OpenAI function calling](https://developers.openai.com/api/docs/guides/function-calling).
