"""Extract a typed study event using Pydantic, JSON Schema, or JSON mode."""

import argparse
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from common import make_client, model_name, require_completed


class StudyEvent(BaseModel):
    model_config = ConfigDict(extra="forbid")
    title: str
    date: str = Field(description="Date in YYYY-MM-DD format, copied from the source.")
    participants: list[str]
    level: Literal["beginner", "intermediate", "advanced"]
    location: str | None = Field(description="Location from the source, or null when absent.")


EVENT_SCHEMA = {
    "type": "object",
    "properties": {
        "title": {"type": "string"},
        "date": {"type": "string", "description": "YYYY-MM-DD"},
        "participants": {"type": "array", "items": {"type": "string"}},
        "level": {"type": "string", "enum": ["beginner", "intermediate", "advanced"]},
        "location": {"type": ["string", "null"]},
    },
    "required": ["title", "date", "participants", "level", "location"],
    "additionalProperties": False,
}

SOURCE = (
    "Asha and Ravi will attend the beginner Python Study Group on 2026-10-05. "
    "The location has not been decided."
)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=["pydantic", "schema", "json-mode"])
    args = parser.parse_args()
    with make_client() as client:
        if args.mode == "pydantic":
            response = client.responses.parse(
                model=model_name(),
                instructions="Extract the study event. Do not invent a missing location.",
                input=SOURCE,
                text_format=StudyEvent,
                max_output_tokens=700,
                store=False,
            )
            require_completed(response)
            event = response.output_parsed
            if event is None:
                raise RuntimeError("No parsed event was returned.")
        else:
            text_format = (
                {"type": "json_schema", "name": "study_event", "strict": True, "schema": EVENT_SCHEMA}
                if args.mode == "schema"
                else {"type": "json_object"}
            )
            response = client.responses.create(
                model=model_name(),
                instructions=(
                    "Extract a JSON object with title, date (YYYY-MM-DD), participants "
                    "(string array), level (beginner/intermediate/advanced), and location "
                    "(string or null). Use null for an absent location."
                ),
                input=SOURCE,
                text={"format": text_format},
                max_output_tokens=700,
                store=False,
            )
            require_completed(response)
            # Especially in JSON mode, valid JSON need not match our data model.
            event = StudyEvent.model_validate_json(response.output_text)
        print(event.model_dump_json(indent=2))
        print("Typed access:", event.title, event.participants)


if __name__ == "__main__":
    main()
