# 05 - Read output while it is generated

[Index](README.md) | [Python examples](05_streaming.py) | [Next: images and files](06_images_files.md)

With a normal request, you receive the completed response. With HTTP streaming,
you receive server-sent events (SSE) while generation is happening. Streaming can
reduce time to the first displayed text; it does not inherently reduce total
generation, token cost, or time to finish.

## Responses API events

```python
with client.responses.create(
    model="gpt-4.1-mini",
    input="Explain a Python generator.",
    stream=True,
) as stream:
    for event in stream:
        if event.type == "response.output_text.delta":
            print(event.delta, end="", flush=True)
```

`event.delta` is a text fragment. A fragment need not be one token, one word, or
a complete sentence. `end=""` avoids adding newlines between fragments, and
`flush=True` makes terminal output visible promptly. The context manager closes
the stream even when iteration fails.

The full script tracks the final response as well:

| Event | What to do |
| --- | --- |
| `response.created`, `response.in_progress` | Observe lifecycle if needed |
| `response.output_text.delta` | Append or display a text fragment |
| `response.output_text.done` | Final text for one content part; don't append it again after its deltas |
| `response.completed` | Inspect the final response and usage |
| `response.incomplete` | Report truncation or another incomplete reason |
| `response.failed`, `error` | Surface failure |
| `response.refusal.delta` | Optional incremental refusal display; inspect final refusal too |

```powershell
python 05_streaming.py responses
```

A successful HTTP connection does not mean generation completed. If a connection
ends before a terminal event, do not silently call the partial text a complete
answer. The example checks that case and validates the final response.

## SDK stream helper

```python
with client.responses.stream(
    model="gpt-4.1-mini",
    input="Explain a Python generator.",
) as stream:
    for event in stream:
        if event.type == "response.output_text.delta":
            print(event.delta, end="", flush=True)
    final_response = stream.get_final_response()
```

Run `python 05_streaming.py helper`. The helper accumulates the response for you.
It already selects streaming; do not add `stream=True` to this helper call.
Check the final status/refusal before accepting the accumulated answer.

## Chat Completions chunks

```python
with client.chat.completions.create(
    model="gpt-4.1-mini",
    messages=[{"role": "user", "content": "Explain a Python generator."}],
    stream=True,
    stream_options={"include_usage": True},
) as stream:
    for chunk in stream:
        for choice in chunk.choices:
            if choice.delta.content:
                print(choice.delta.content, end="", flush=True)
```

Run `python 05_streaming.py chat`. Use `choice.delta`, not the non-streaming
`choice.message`. Some chunks carry a role or finish reason and no text. The final
usage chunk can have an empty `choices` list. If a stream is interrupted, final
usage may never arrive. Responses reports usage in its terminal response without
the Chat `stream_options` setting.

## Streaming tools and JSON

Tool calls have their own events, including
`response.function_call_arguments.delta` and
`response.function_call_arguments.done`. If you accumulate arguments yourself,
keep fragments separate by output item/index because multiple calls can occur.
The intermediate string `{"course_code": "LL` is not valid complete JSON.

For a simple implementation, stream displayable text, use the helper's final
response, then run [Lesson 03's validation and dispatch loop](03_tool_use.py)
over its complete `function_call` items. Validate all arguments before executing.
For lower-latency dispatch, use complete argument events and carefully track each
call; never execute an action from partial JSON.

Similarly, do not parse every text delta as a complete Structured Outputs object.
You can display partial text, but consume the validated final object only after
successful completion. The SDK also offers structured streaming helpers for
applications that need incremental parsed state.

See `python 08_async_and_errors.py async-stream` for `async for` streaming.

Source: [OpenAI streaming responses](https://developers.openai.com/api/docs/guides/streaming-responses).
