# 08 - Async requests, retries, and errors

[Index](README.md) | [Python examples](08_async_and_errors.py) | [Quick reference](REFERENCE.md)

Once one API call works, the next concerns are waiting efficiently and handling
failures. Keep HTTP errors separate from a model response that is incomplete or
refused, even when its HTTP status is successful.

## Asynchronous requests

```python
import asyncio
from openai import AsyncOpenAI

async def main():
    async with AsyncOpenAI(timeout=60.0, max_retries=2) as client:
        response = await client.responses.create(
            model="gpt-4.1-mini",
            input="Explain async/await in one sentence.",
        )
        print(response.output_text)

if __name__ == "__main__":
    asyncio.run(main())
```

Use `AsyncOpenAI` with `await`. A normal synchronous `OpenAI` request blocks its
calling thread. Reuse a client across calls and close it when finished. Inside an
already running event loop, such as a notebook or async web handler, `await` the
coroutine instead of starting another loop with `asyncio.run()`.

```powershell
python 08_async_and_errors.py async
```

The example uses `asyncio.gather()` for three independent questions and a semaphore
that permits at most two active requests. Results are printed in input order,
which can differ from completion order. `return_exceptions=True` lets successful
results survive another request's failure; the script reports failures and exits
unsuccessfully if any occurred.

Concurrency overlaps network waits. It does not raise your rate limits. Limit
concurrency based on requests/minute, tokens/minute, cost, and the task's needs.

## Async streaming

```python
stream = await client.responses.create(
    model="gpt-4.1-mini", input="Explain generators.", stream=True,
)
async with stream:
    async for event in stream:
        if event.type == "response.output_text.delta":
            print(event.delta, end="", flush=True)
```

Run `python 08_async_and_errors.py async-stream`. The full script checks the final
status and detects missing terminal events. `await` obtains the stream, while
`async for` consumes its events.

## Common errors and what they mean

| Error | Typical cause | Useful response |
| --- | --- | --- |
| `AuthenticationError` / 401 | Missing, invalid, or inappropriate API key | Check credentials and project |
| `BadRequestError` / 400 | Unsupported parameter, invalid schema, oversized request | Fix the payload; unchanged retries won't fix it |
| `NotFoundError` / 404 | Model/resource missing or unavailable | Check the ID and project access |
| `RateLimitError` / 429 | Request/token rate limit or insufficient quota | Inspect the error; reduce rate or address quota |
| `APITimeoutError` | Request did not complete within the configured timeout | Adjust timeout or retry policy for the workload |
| `APIConnectionError` | Network, proxy, DNS, or TLS problem | Check connectivity |
| `APIStatusError` | Other non-success HTTP response | Record status and request ID; handle by category |
| Completed HTTP call, incomplete model response | Output limit or another generation interruption | Inspect `status` and `incomplete_details` |
| Model refusal | Request cannot be fulfilled by the model | Handle the refusal as a separate application state |

Run `python 08_async_and_errors.py errors`. It makes a normal request and demonstrates
exception handling if a failure occurs. It does not intentionally trigger errors.
The catch order matters because specific SDK exceptions subclass broader ones;
`APITimeoutError` should be handled before `APIConnectionError`.

## Retries and timeouts

```python
client = OpenAI(timeout=60.0, max_retries=2)
```

The SDK automatically retries selected transient failures, including connection
errors, 408, 409, 429, and server errors, with backoff. `max_retries=2` means up to
two retries after the initial attempt. A retry policy and HTTP timeout are not one
strict wall-clock deadline for the entire business operation.

Avoid stacking an unbounded retry loop on top of SDK retries. An invalid schema
or unsupported temperature setting needs a request change. A quota error may need
account action. Once a stream has delivered text, a connection break is not a
transparent continuation: blindly starting over can duplicate displayed output.

For tools with side effects, design idempotency and record successful execution
so a retried workflow does not repeat a purchase or database write. The catalog
tools here only read fictional local data.

## Useful diagnostics

On successful SDK responses, `response._request_id` is a supported diagnostic
property despite its leading underscore. On `APIStatusError`, use `request_id`
and `status_code`. Record the model, chosen parameters, elapsed time, response
status, and token usage when useful. Avoid logging keys, complete private prompts,
uploaded content, or base64 images by default.

The scripts use a main guard, so importing their definitions does not make requests.
The offline tests mock HTTP transport while exercising the real installed SDK.
They check local behavior and payload handling, not real service access or model
accuracy. Run a chosen example yourself after setting your API key to check those.

References: [official Python library setup](https://developers.openai.com/api/docs/libraries),
[API errors](https://developers.openai.com/api/docs/guides/error-codes), and
[rate limits](https://developers.openai.com/api/docs/guides/rate-limits).
