# Anthropic Claude SDK - Complete Guide

This directory contains comprehensive educational material for working with the Anthropic Claude SDK in Python.

## Installation

```bash
pip install anthropic
```

## Directory Structure

| File | Description |
|------|-------------|
| `01_basic_messages.md` | Understanding prompt structure (system, user, assistant) |
| `01_basic_messages.py` | Code examples for basic messages |
| `02_parameters.md` | API parameters (effort, stop_sequence, etc.) |
| `02_parameters.py` | Code examples for parameters |
| `03_tool_use.md` | Defining and calling tools |
| `03_tool_use.py` | Tool use code examples |
| `04_structured_output.md` | Getting structured JSON responses |
| `04_structured_output.py` | Structured output code examples |
| `05_streaming.md` | Streaming responses |
| `05_streaming.py` | Streaming code examples |
| `06_images_files.md` | Passing images and files |
| `06_images_files.py` | Image and file handling examples |

## Quick Start

```python
import anthropic

# Initialize client (reads ANTHROPIC_API_KEY from environment)
client = anthropic.Anthropic()

# Make a simple request
response = client.messages.create(
    model="claude-opus-5",
    max_tokens=1024,
    messages=[{"role": "user", "content": "Hello, Claude!"}]
)

print(response.content[0].text)
```

## Authentication

Set your API key as an environment variable:

```bash
# Linux/macOS
export ANTHROPIC_API_KEY="your-api-key-here"

# Windows (PowerShell)
$env:ANTHROPIC_API_KEY="your-api-key-here"

# Windows (CMD)
set ANTHROPIC_API_KEY=your-api-key-here
```

Or use the `ant` CLI for OAuth-based authentication:
```bash
ant auth login
```

## Current Models (as of 2026)

| Model | Model ID | Context | Input $/1M | Output $/1M |
|-------|----------|---------|------------|-------------|
| Claude Fable 5.1 | `claude-fable-5-1` | 1M | $10.00 | $50.00 |
| Claude Opus 5 | `claude-opus-5` | 1M | $5.00 | $25.00 |
| Claude Sonnet 5 | `claude-sonnet-5` | 1M | $2.00 | $10.00 |
| Claude Haiku 4.5 | `claude-haiku-4-5` | 200K | $1.00 | $5.00 |

## Key Concepts

1. **Messages API**: The core API endpoint for all Claude interactions
2. **System Prompts**: Instructions that set Claude's behavior
3. **Extended Thinking**: Claude's reasoning capabilities with effort levels
4. **Tools**: Enable Claude to call functions you define
5. **Structured Outputs**: Get responses in specific JSON formats
6. **Streaming**: Receive responses token-by-token in real-time
