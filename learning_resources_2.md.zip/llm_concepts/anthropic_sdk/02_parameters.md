# API Parameters - Controlling Claude's Output

The Claude API provides several parameters to control how responses are generated.

## Key Parameters

### max_tokens (Required)
Maximum number of tokens Claude can generate. Always required.

```python
max_tokens=1024   # Short response
max_tokens=16000  # Medium response (recommended default)
max_tokens=64000  # Long response (use with streaming)
max_tokens=128000 # Maximum (requires streaming)
```

**Best Practices:**
- Use ~16000 for non-streaming requests (avoids HTTP timeouts)
- Use ~64000 for streaming requests
- Don't lowball - hitting the cap truncates output mid-thought

---

## Thinking and Effort (Extended Thinking)

Claude's reasoning capability is controlled by two related parameters.

### thinking Parameter
Controls whether Claude shows its reasoning process.

```python
# Adaptive thinking (recommended for Claude Opus 5, Fable 5)
thinking={"type": "adaptive"}

# With visible summary of reasoning
thinking={"type": "adaptive", "display": "summarized"}

# Disabled (only at effort "high" or below on Opus 5)
thinking={"type": "disabled"}
```

**Model-Specific Behavior:**
- **Claude Opus 5**: Thinking is ON by default. Omitting `thinking` runs adaptive.
- **Opus 4.8/4.7**: Must set `thinking={"type": "adaptive"}` explicitly
- **Older models (Haiku 4.5)**: Use `thinking={"type": "enabled", "budget_tokens": N}`

### effort Parameter
Controls thinking depth and token spend. Set inside `output_config`.

```python
output_config={"effort": "low"}     # Minimal thinking, fast, cheap
output_config={"effort": "medium"}  # Balanced
output_config={"effort": "high"}    # Default - good for most tasks
output_config={"effort": "xhigh"}   # Best for coding/agentic work
output_config={"effort": "max"}     # Maximum reasoning, highest cost
```

**When to use each level:**
- `low`: Simple classification, subagents, speed-critical tasks
- `medium`: Chat, summaries, cost-sensitive routes
- `high`: Default for most tasks (quality/cost balance)
- `xhigh`: Coding, complex reasoning, agentic workflows
- `max`: When correctness matters more than cost

---

## Sampling Parameters (Older Models Only)

**IMPORTANT**: These parameters are **removed** on Fable 5, Opus 5, Opus 4.8, Opus 4.7, and Sonnet 5. Sending them returns a 400 error. Only use on older models like Haiku 4.5.

### temperature (Older models only)
Controls randomness. Higher = more creative, lower = more deterministic.

```python
temperature=0.0  # Deterministic (same input = same output)
temperature=0.5  # Balanced
temperature=1.0  # Default, moderate randomness
temperature=2.0  # Maximum randomness
```

### top_p (Older models only)
Nucleus sampling - considers tokens comprising the top P probability mass.

```python
top_p=0.9   # Consider tokens in top 90% probability
top_p=0.5   # More focused selection
top_p=1.0   # Default, consider all tokens
```

### top_k (Older models only)
Limits to the K most probable tokens.

```python
top_k=40   # Consider only top 40 tokens
top_k=100  # More variety
```

**Note:** Don't use both `temperature` and `top_p` together - pick one.

---

## Stop Sequences

Custom strings that cause Claude to stop generating.

```python
stop_sequences=["END", "STOP", "---"]
```

**Use cases:**
- Structured output extraction
- Preventing runaway generation
- Creating delimiters

Example:
```python
response = client.messages.create(
    model="claude-opus-5",
    max_tokens=1024,
    stop_sequences=["```"],  # Stop at code block end
    messages=[{"role": "user", "content": "Write Python code to sort a list"}]
)
```

---

## Stop Reasons

The `stop_reason` field tells you why Claude stopped:

| Value | Meaning |
|-------|---------|
| `end_turn` | Natural completion |
| `max_tokens` | Hit the token limit |
| `stop_sequence` | Hit a custom stop sequence |
| `tool_use` | Wants to call a tool |
| `pause_turn` | Paused (agentic flows) |
| `refusal` | Safety refusal |

---

## Complete Example

```python
import anthropic

client = anthropic.Anthropic()

response = client.messages.create(
    model="claude-opus-5",
    max_tokens=16000,
    
    # System prompt
    system="You are a helpful assistant.",
    
    # Extended thinking with effort
    thinking={"type": "adaptive", "display": "summarized"},
    output_config={"effort": "high"},
    
    # Stop sequences
    stop_sequences=["END"],
    
    # The conversation
    messages=[
        {"role": "user", "content": "Explain quantum computing briefly."}
    ]
)

# Check why it stopped
print(f"Stop reason: {response.stop_reason}")

# Access the response
for block in response.content:
    if block.type == "thinking":
        print(f"Thinking: {block.thinking}")
    elif block.type == "text":
        print(f"Response: {block.text}")
```

---

## Token Usage

Every response includes usage information:

```python
print(response.usage.input_tokens)   # Tokens in your prompt
print(response.usage.output_tokens)  # Tokens in Claude's response

# With caching
print(response.usage.cache_creation_input_tokens)  # Tokens written to cache
print(response.usage.cache_read_input_tokens)      # Tokens read from cache
```
