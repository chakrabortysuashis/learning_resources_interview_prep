"""
Images and Files - Multimodal Input

This module demonstrates how to send images, PDFs, and other files to Claude.
"""

import anthropic
import base64
from pathlib import Path


def image_from_base64():
    """Send an image using base64 encoding."""
    client = anthropic.Anthropic()

    # Read and encode image
    image_path = Path("example_image.png")

    if not image_path.exists():
        print("Note: Create an 'example_image.png' file to test this example")
        print("Demonstrating with a placeholder...")

        # For demo purposes, we'll just show the structure
        response = client.messages.create(
            model="claude-opus-5",
            max_tokens=1024,
            messages=[{
                "role": "user",
                "content": "Describe what an image description workflow looks like."
            }]
        )
        print(response.content[0].text)
        return

    with open(image_path, "rb") as f:
        # standard_b64encode returns bytes, decode to string
        # Important: no newlines allowed in the base64 string
        image_data = base64.standard_b64encode(f.read()).decode("utf-8")

    # Determine media type from extension
    media_types = {
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".gif": "image/gif",
        ".webp": "image/webp",
    }
    media_type = media_types.get(image_path.suffix.lower(), "image/png")

    response = client.messages.create(
        model="claude-opus-5",
        max_tokens=1024,
        messages=[{
            "role": "user",
            "content": [
                {
                    "type": "image",
                    "source": {
                        "type": "base64",
                        "media_type": media_type,
                        "data": image_data
                    }
                },
                {"type": "text", "text": "What's in this image? Describe it in detail."}
            ]
        }]
    )

    print(response.content[0].text)


def image_from_url():
    """Send an image using a URL."""
    client = anthropic.Anthropic()

    # Use a publicly accessible image URL
    image_url = "https://upload.wikimedia.org/wikipedia/commons/thumb/4/47/PNG_transparency_demonstration_1.png/300px-PNG_transparency_demonstration_1.png"

    response = client.messages.create(
        model="claude-opus-5",
        max_tokens=1024,
        messages=[{
            "role": "user",
            "content": [
                {
                    "type": "image",
                    "source": {
                        "type": "url",
                        "url": image_url
                    }
                },
                {"type": "text", "text": "Describe this image."}
            ]
        }]
    )

    print(response.content[0].text)


def multiple_images():
    """Compare multiple images."""
    client = anthropic.Anthropic()

    # Using URLs for demonstration
    image1_url = "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c3/Python-logo-notext.svg/200px-Python-logo-notext.svg.png"
    image2_url = "https://upload.wikimedia.org/wikipedia/commons/thumb/6/6a/JavaScript-logo.png/200px-JavaScript-logo.png"

    response = client.messages.create(
        model="claude-opus-5",
        max_tokens=1024,
        messages=[{
            "role": "user",
            "content": [
                {
                    "type": "image",
                    "source": {"type": "url", "url": image1_url}
                },
                {
                    "type": "image",
                    "source": {"type": "url", "url": image2_url}
                },
                {"type": "text", "text": "What programming languages do these logos represent? Compare them."}
            ]
        }]
    )

    print(response.content[0].text)


def pdf_document():
    """Send a PDF document for analysis."""
    client = anthropic.Anthropic()

    pdf_path = Path("example_document.pdf")

    if not pdf_path.exists():
        print("Note: Create an 'example_document.pdf' file to test this example")
        print("Demonstrating the structure...")

        # Show the expected structure
        print("""
Expected code structure:

with open("document.pdf", "rb") as f:
    pdf_data = base64.standard_b64encode(f.read()).decode("utf-8")

response = client.messages.create(
    model="claude-opus-5",
    max_tokens=4096,
    messages=[{
        "role": "user",
        "content": [
            {
                "type": "document",
                "source": {
                    "type": "base64",
                    "media_type": "application/pdf",
                    "data": pdf_data
                }
            },
            {"type": "text", "text": "Summarize this document."}
        ]
    }]
)
""")
        return

    with open(pdf_path, "rb") as f:
        pdf_data = base64.standard_b64encode(f.read()).decode("utf-8")

    response = client.messages.create(
        model="claude-opus-5",
        max_tokens=4096,
        messages=[{
            "role": "user",
            "content": [
                {
                    "type": "document",
                    "source": {
                        "type": "base64",
                        "media_type": "application/pdf",
                        "data": pdf_data
                    }
                },
                {"type": "text", "text": "Please summarize the key points of this document."}
            ]
        }]
    )

    print(response.content[0].text)


def files_api_upload():
    """Use the Files API to upload and reference files."""
    client = anthropic.Anthropic()

    print("Files API demonstration:")
    print("-" * 40)

    # Create a sample file for demonstration
    sample_file = Path("sample_data.txt")
    sample_file.write_text("""
    Sample Data Report
    ==================

    Quarter: Q4 2024
    Revenue: $1.2M
    Growth: 15%

    Key Metrics:
    - New customers: 150
    - Retention rate: 92%
    - NPS Score: 78

    Summary:
    Strong performance across all metrics with
    particular strength in customer acquisition.
    """)

    try:
        # Upload the file
        with open(sample_file, "rb") as f:
            uploaded = client.files.upload(file=f)

        print(f"Uploaded file ID: {uploaded.id}")

        # Use the uploaded file in a request
        response = client.messages.create(
            model="claude-opus-5",
            max_tokens=1024,
            messages=[{
                "role": "user",
                "content": [
                    {
                        "type": "document",
                        "source": {"type": "file", "file_id": uploaded.id}
                    },
                    {"type": "text", "text": "Analyze this report and highlight the most important metrics."}
                ]
            }]
        )

        print(f"\nAnalysis:\n{response.content[0].text}")

        # Get file metadata
        metadata = client.files.retrieve_metadata(uploaded.id)
        print(f"\nFile metadata:")
        print(f"  Filename: {metadata.filename}")
        print(f"  Size: {metadata.size_bytes} bytes")

    finally:
        # Clean up
        sample_file.unlink(missing_ok=True)


def with_citations():
    """Enable document citations for source tracking."""
    client = anthropic.Anthropic()

    print("Document with citations:")
    print("-" * 40)

    # Create sample document
    sample_doc = Path("research_paper.txt")
    sample_doc.write_text("""
    Introduction to Machine Learning

    Chapter 1: Supervised Learning

    Supervised learning is a type of machine learning where the model
    is trained on labeled data. The algorithm learns from examples
    where the correct answers are provided, allowing it to make
    predictions on new, unseen data.

    Key concepts include:
    - Training data: Labeled examples used to train the model
    - Features: Input variables used for prediction
    - Labels: Target variables the model learns to predict
    - Model: The mathematical function learned from data

    Chapter 2: Unsupervised Learning

    Unlike supervised learning, unsupervised learning works with
    unlabeled data. The algorithm must find patterns and structures
    in the data without explicit guidance.

    Common techniques include:
    - Clustering: Grouping similar data points
    - Dimensionality reduction: Simplifying complex data
    - Anomaly detection: Finding unusual patterns
    """)

    try:
        with open(sample_doc, "rb") as f:
            uploaded = client.files.upload(file=f)

        response = client.messages.create(
            model="claude-opus-5",
            max_tokens=1024,
            messages=[{
                "role": "user",
                "content": [
                    {
                        "type": "document",
                        "source": {"type": "file", "file_id": uploaded.id},
                        "citations": {"enabled": True}  # Enable citations
                    },
                    {"type": "text", "text": "What is the difference between supervised and unsupervised learning?"}
                ]
            }]
        )

        # Process response with citations
        for block in response.content:
            if block.type == "text":
                print(f"Response: {block.text}")

                # Check for citations
                if hasattr(block, 'citations') and block.citations:
                    print("\nCitations:")
                    for i, citation in enumerate(block.citations, 1):
                        print(f"  [{i}] \"{citation.cited_text[:50]}...\"")

    finally:
        sample_doc.unlink(missing_ok=True)


def code_execution_with_files():
    """Use code execution to analyze uploaded files."""
    client = anthropic.Anthropic()

    print("Code execution with file upload:")
    print("-" * 40)

    # Create sample CSV data
    csv_file = Path("sales_data.csv")
    csv_file.write_text("""date,product,quantity,revenue
2024-01-01,Widget A,100,2500
2024-01-02,Widget B,150,3750
2024-01-03,Widget A,80,2000
2024-01-04,Widget C,200,6000
2024-01-05,Widget B,120,3000
2024-01-06,Widget A,90,2250
2024-01-07,Widget C,180,5400
""")

    try:
        # Upload the file
        with open(csv_file, "rb") as f:
            uploaded = client.files.upload(file=f)

        print(f"Uploaded: {uploaded.id}")

        # Use code execution to analyze
        response = client.messages.create(
            model="claude-opus-5",
            max_tokens=4096,
            messages=[{
                "role": "user",
                "content": [
                    {"type": "text", "text": "Analyze this sales data. Calculate totals by product and identify the best-selling product."},
                    {"type": "container_upload", "file_id": uploaded.id}
                ]
            }],
            tools=[{"type": "code_execution_20260120", "name": "code_execution"}]
        )

        # Process response
        for block in response.content:
            if block.type == "text":
                print(f"\n{block.text}")
            elif block.type == "bash_code_execution_tool_result":
                result = block.content
                if hasattr(result, 'stdout') and result.stdout:
                    print(f"\nCode output:\n{result.stdout}")

    finally:
        csv_file.unlink(missing_ok=True)


def image_analysis_workflow():
    """Complete workflow for image analysis."""
    client = anthropic.Anthropic()

    print("Image Analysis Workflow:")
    print("-" * 40)

    # Using a public domain image for demonstration
    image_url = "https://upload.wikimedia.org/wikipedia/commons/thumb/1/15/Cat_August_2010-4.jpg/220px-Cat_August_2010-4.jpg"

    # Step 1: Initial description
    print("\nStep 1: Get initial description")
    response1 = client.messages.create(
        model="claude-opus-5",
        max_tokens=512,
        messages=[{
            "role": "user",
            "content": [
                {"type": "image", "source": {"type": "url", "url": image_url}},
                {"type": "text", "text": "Describe this image in one sentence."}
            ]
        }]
    )
    description = response1.content[0].text
    print(f"Description: {description}")

    # Step 2: Ask follow-up questions
    print("\nStep 2: Follow-up analysis")
    response2 = client.messages.create(
        model="claude-opus-5",
        max_tokens=512,
        messages=[
            {
                "role": "user",
                "content": [
                    {"type": "image", "source": {"type": "url", "url": image_url}},
                    {"type": "text", "text": "Describe this image."}
                ]
            },
            {"role": "assistant", "content": description},
            {"role": "user", "content": "What emotions or mood does this image convey?"}
        ]
    )
    print(f"Mood analysis: {response2.content[0].text}")


def helper_encode_image(file_path: str) -> tuple[str, str]:
    """Helper function to encode an image file.

    Returns:
        Tuple of (base64_data, media_type)
    """
    path = Path(file_path)

    media_types = {
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".gif": "image/gif",
        ".webp": "image/webp",
    }

    media_type = media_types.get(path.suffix.lower())
    if not media_type:
        raise ValueError(f"Unsupported image format: {path.suffix}")

    with open(path, "rb") as f:
        data = base64.standard_b64encode(f.read()).decode("utf-8")

    return data, media_type


def helper_encode_pdf(file_path: str) -> str:
    """Helper function to encode a PDF file.

    Returns:
        Base64 encoded PDF data
    """
    with open(file_path, "rb") as f:
        return base64.standard_b64encode(f.read()).decode("utf-8")


if __name__ == "__main__":
    print("=" * 60)
    print("1. Image from URL")
    print("=" * 60)
    image_from_url()

    print("\n" + "=" * 60)
    print("2. Multiple Images")
    print("=" * 60)
    multiple_images()

    print("\n" + "=" * 60)
    print("3. Files API Upload")
    print("=" * 60)
    files_api_upload()

    print("\n" + "=" * 60)
    print("4. Document with Citations")
    print("=" * 60)
    with_citations()

    print("\n" + "=" * 60)
    print("5. Image Analysis Workflow")
    print("=" * 60)
    image_analysis_workflow()

    print("\n" + "=" * 60)
    print("6. PDF Document (requires example_document.pdf)")
    print("=" * 60)
    pdf_document()

    print("\n" + "=" * 60)
    print("7. Image from Base64 (requires example_image.png)")
    print("=" * 60)
    image_from_base64()
