"""
Basic Messages - System, User, and Assistant Roles

This module demonstrates how to structure prompts with the Claude API.
"""

import anthropic


def basic_message():
    """Simple single-turn message."""
    client = anthropic.Anthropic()

    response = client.messages.create(
        model="claude-opus-5",
        max_tokens=1024,
        messages=[
            {"role": "user", "content": "What is the capital of France?"}
        ]
    )

    # response.content is a list of content blocks
    for block in response.content:
        if block.type == "text":
            print(block.text)

    return response


def with_system_prompt():
    """Using a system prompt to set Claude's behavior."""
    client = anthropic.Anthropic()

    response = client.messages.create(
        model="claude-opus-5",
        max_tokens=1024,
        system="You are a helpful coding assistant. Always provide examples in Python. Be concise.",
        messages=[
            {"role": "user", "content": "How do I read a JSON file?"}
        ]
    )

    print(response.content[0].text)
    return response


def multi_turn_conversation():
    """Multi-turn conversation - sending full history each time."""
    client = anthropic.Anthropic()

    # Store conversation history
    messages = []

    # Turn 1
    messages.append({"role": "user", "content": "My name is Alice and I'm learning Python."})

    response1 = client.messages.create(
        model="claude-opus-5",
        max_tokens=1024,
        system="You are a friendly programming tutor.",
        messages=messages
    )

    # Add Claude's response to history
    assistant_text = response1.content[0].text
    messages.append({"role": "assistant", "content": assistant_text})
    print(f"Claude: {assistant_text}\n")

    # Turn 2
    messages.append({"role": "user", "content": "What's my name and what am I learning?"})

    response2 = client.messages.create(
        model="claude-opus-5",
        max_tokens=1024,
        system="You are a friendly programming tutor.",
        messages=messages
    )

    print(f"Claude: {response2.content[0].text}")
    return response2


def complex_content_blocks():
    """Using content blocks for structured input."""
    client = anthropic.Anthropic()

    # Content can be a list of blocks
    response = client.messages.create(
        model="claude-opus-5",
        max_tokens=1024,
        messages=[
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "Please analyze the following code:"},
                    {"type": "text", "text": "```python\ndef add(a, b):\n    return a + b\n```"},
                    {"type": "text", "text": "Is this function correct?"}
                ]
            }
        ]
    )

    print(response.content[0].text)
    return response


class ConversationManager:
    """A helper class to manage multi-turn conversations."""

    def __init__(self, model: str = "claude-opus-5", system: str = None):
        self.client = anthropic.Anthropic()
        self.model = model
        self.system = system
        self.messages = []

    def send(self, user_message: str, max_tokens: int = 1024) -> str:
        """Send a message and get a response."""
        self.messages.append({"role": "user", "content": user_message})

        response = self.client.messages.create(
            model=self.model,
            max_tokens=max_tokens,
            system=self.system,
            messages=self.messages
        )

        # Extract text from response
        assistant_text = next(
            (b.text for b in response.content if b.type == "text"), ""
        )
        self.messages.append({"role": "assistant", "content": assistant_text})

        return assistant_text

    def clear(self):
        """Clear conversation history."""
        self.messages = []


def conversation_manager_example():
    """Using the ConversationManager helper class."""
    conv = ConversationManager(
        model="claude-opus-5",
        system="You are a helpful math tutor. Explain concepts simply."
    )

    print("User: What is a prime number?")
    response1 = conv.send("What is a prime number?")
    print(f"Claude: {response1}\n")

    print("User: Give me 5 examples")
    response2 = conv.send("Give me 5 examples")
    print(f"Claude: {response2}\n")

    print("User: Is 1 a prime number?")
    response3 = conv.send("Is 1 a prime number?")
    print(f"Claude: {response3}")


if __name__ == "__main__":
    print("=" * 50)
    print("1. Basic Message")
    print("=" * 50)
    basic_message()

    print("\n" + "=" * 50)
    print("2. With System Prompt")
    print("=" * 50)
    with_system_prompt()

    print("\n" + "=" * 50)
    print("3. Multi-Turn Conversation")
    print("=" * 50)
    multi_turn_conversation()

    print("\n" + "=" * 50)
    print("4. Conversation Manager")
    print("=" * 50)
    conversation_manager_example()
