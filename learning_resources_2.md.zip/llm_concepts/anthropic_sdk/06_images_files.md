# Images and Files - Multimodal Input

Claude can process images, PDFs, and other files as part of conversations.

## Supported Media Types

### Images
- `image/jpeg`
- `image/png`
- `image/gif`
- `image/webp`

### Documents
- `application/pdf`
- Plain text files

---

## Images

### Method 1: Base64 Encoding

```python
import base64

with open("image.png", "rb") as f:
    image_data = base64.standard_b64encode(f.read()).decode("utf-8")

response = client.messages.create(
    model="claude-opus-5",
    max_tokens=1024,
    messages=[{
        "role": "user",
        "content": [
            {
                "type": "image",
                "source": {
                    "type": "base64",
                    "media_type": "image/png",
                    "data": image_data  # No newlines allowed
                }
            },
            {"type": "text", "text": "What's in this image?"}
        ]
    }]
)
```

### Method 2: URL Reference

```python
response = client.messages.create(
    model="claude-opus-5",
    max_tokens=1024,
    messages=[{
        "role": "user",
        "content": [
            {
                "type": "image",
                "source": {
                    "type": "url",
                    "url": "https://example.com/image.png"
                }
            },
            {"type": "text", "text": "Describe this image"}
        ]
    }]
)
```

### Method 3: Files API (Recommended for Reuse)

```python
# Upload once
uploaded = client.files.upload(file=open("image.png", "rb"))

# Use in multiple requests
response = client.messages.create(
    model="claude-opus-5",
    max_tokens=1024,
    messages=[{
        "role": "user",
        "content": [
            {
                "type": "image",
                "source": {"type": "file", "file_id": uploaded.id}
            },
            {"type": "text", "text": "Analyze this image"}
        ]
    }]
)
```

---

## PDFs

### Base64 PDF

```python
import base64

with open("document.pdf", "rb") as f:
    pdf_data = base64.standard_b64encode(f.read()).decode("utf-8")

response = client.messages.create(
    model="claude-opus-5",
    max_tokens=4096,
    messages=[{
        "role": "user",
        "content": [
            {
                "type": "document",
                "source": {
                    "type": "base64",
                    "media_type": "application/pdf",
                    "data": pdf_data
                }
            },
            {"type": "text", "text": "Summarize this document"}
        ]
    }]
)
```

### PDF via Files API

```python
uploaded = client.files.upload(file=open("document.pdf", "rb"))

response = client.messages.create(
    model="claude-opus-5",
    max_tokens=4096,
    messages=[{
        "role": "user",
        "content": [
            {
                "type": "document",
                "source": {"type": "file", "file_id": uploaded.id}
            },
            {"type": "text", "text": "What are the key points?"}
        ]
    }]
)
```

### PDF Limits
- Maximum 32 MB per request
- Maximum 600 pages (100 for 200K context models)
- Base64 string must have no newlines

---

## Files API

Upload files once and reference them in multiple requests.

### Upload a File

```python
# Upload from file path
uploaded = client.files.upload(file=open("data.csv", "rb"))
print(f"File ID: {uploaded.id}")

# Or with explicit filename
with open("data.csv", "rb") as f:
    uploaded = client.files.upload(
        file=f,
        purpose="user_data"
    )
```

### Use Uploaded File

```python
# For documents (PDF, text)
{"type": "document", "source": {"type": "file", "file_id": file_id}}

# For images
{"type": "image", "source": {"type": "file", "file_id": file_id}}
```

### Retrieve File Metadata

```python
metadata = client.files.retrieve_metadata(file_id)
print(f"Filename: {metadata.filename}")
print(f"Size: {metadata.size_bytes} bytes")
```

### Download File

```python
content = client.files.download(file_id)
content.write_to_file("output.pdf")
```

---

## Code Execution with Files

Upload files for Claude to analyze with code:

```python
# Upload data file
uploaded = client.files.upload(file=open("sales_data.csv", "rb"))

response = client.messages.create(
    model="claude-opus-5",
    max_tokens=16000,
    messages=[{
        "role": "user",
        "content": [
            {"type": "text", "text": "Analyze this data and create a visualization."},
            {"type": "container_upload", "file_id": uploaded.id}
        ]
    }],
    tools=[{"type": "code_execution_20260120", "name": "code_execution"}]
)
```

### Retrieve Generated Files

```python
for block in response.content:
    if block.type == "bash_code_execution_tool_result":
        result = block.content
        if result.content:
            for file_ref in result.content:
                if file_ref.type == "bash_code_execution_output":
                    # Download generated file
                    content = client.files.download(file_ref.file_id)
                    content.write_to_file(f"output_{file_ref.file_id[:8]}.png")
```

---

## Citations

Enable citations for document references:

```python
response = client.messages.create(
    model="claude-opus-5",
    max_tokens=4096,
    messages=[{
        "role": "user",
        "content": [
            {
                "type": "document",
                "source": {"type": "file", "file_id": file_id},
                "citations": {"enabled": True}  # Enable citations
            },
            {"type": "text", "text": "What does this document say about X?"}
        ]
    }]
)

# Response includes citations
for block in response.content:
    if block.type == "text":
        print(block.text)
        if block.citations:
            for citation in block.citations:
                print(f"  Source: {citation.cited_text}")
                print(f"  Page: {citation.page_location}")
```

**Note:** Citations are incompatible with `output_config.format` (structured outputs).

---

## Multiple Files

```python
response = client.messages.create(
    model="claude-opus-5",
    max_tokens=4096,
    messages=[{
        "role": "user",
        "content": [
            {"type": "image", "source": {"type": "file", "file_id": image1_id}},
            {"type": "image", "source": {"type": "file", "file_id": image2_id}},
            {"type": "document", "source": {"type": "file", "file_id": pdf_id}},
            {"type": "text", "text": "Compare these images and summarize the document."}
        ]
    }]
)
```

---

## Best Practices

1. **Use Files API for repeated use** - Upload once, use many times
2. **Put images/documents before text** - Helps Claude focus on the content
3. **Be specific** - Tell Claude exactly what you want analyzed
4. **Check file sizes** - Stay within limits (32MB request, 600 pages for PDF)
5. **Handle errors** - Files may fail to upload or parse
