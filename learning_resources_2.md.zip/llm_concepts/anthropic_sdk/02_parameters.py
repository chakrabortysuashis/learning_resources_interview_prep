"""
API Parameters - Controlling Claude's Output

This module demonstrates various API parameters for the Claude SDK.
"""

import anthropic


def basic_parameters():
    """Basic request with essential parameters."""
    client = anthropic.Anthropic()

    response = client.messages.create(
        model="claude-opus-5",
        max_tokens=1024,  # Required: maximum output tokens
        messages=[
            {"role": "user", "content": "Explain what an API is in one sentence."}
        ]
    )

    print(f"Response: {response.content[0].text}")
    print(f"Stop reason: {response.stop_reason}")
    print(f"Input tokens: {response.usage.input_tokens}")
    print(f"Output tokens: {response.usage.output_tokens}")

    return response


def with_extended_thinking():
    """Using extended thinking with effort levels."""
    client = anthropic.Anthropic()

    response = client.messages.create(
        model="claude-opus-5",
        max_tokens=16000,

        # Adaptive thinking with visible summary
        thinking={"type": "adaptive", "display": "summarized"},

        # Effort level controls thinking depth
        output_config={"effort": "high"},  # low | medium | high | xhigh | max

        messages=[
            {"role": "user", "content": "What is 15% of 847? Show your reasoning."}
        ]
    )

    # Access both thinking and response
    for block in response.content:
        if block.type == "thinking":
            print(f"Claude's reasoning:\n{block.thinking}\n")
        elif block.type == "text":
            print(f"Final answer:\n{block.text}")

    return response


def with_stop_sequences():
    """Using stop sequences to control output."""
    client = anthropic.Anthropic()

    response = client.messages.create(
        model="claude-opus-5",
        max_tokens=1024,

        # Stop when hitting any of these strings
        stop_sequences=["END", "---", "```"],

        system="When you finish your response, write 'END' on a new line.",

        messages=[
            {"role": "user", "content": "List 3 Python data types."}
        ]
    )

    print(f"Response: {response.content[0].text}")
    print(f"Stop reason: {response.stop_reason}")

    # Check if stopped due to stop sequence
    if response.stop_reason == "stop_sequence":
        print("Stopped due to stop sequence!")

    return response


def effort_comparison():
    """Compare different effort levels."""
    client = anthropic.Anthropic()

    prompt = "What is the sum of the first 10 prime numbers?"
    effort_levels = ["low", "medium", "high"]

    for effort in effort_levels:
        print(f"\n{'='*50}")
        print(f"Effort: {effort}")
        print("=" * 50)

        response = client.messages.create(
            model="claude-opus-5",
            max_tokens=4096,
            thinking={"type": "adaptive", "display": "summarized"},
            output_config={"effort": effort},
            messages=[{"role": "user", "content": prompt}]
        )

        # Count thinking tokens if present
        thinking_text = ""
        response_text = ""
        for block in response.content:
            if block.type == "thinking":
                thinking_text = block.thinking
            elif block.type == "text":
                response_text = block.text

        print(f"Thinking length: {len(thinking_text)} chars")
        print(f"Response: {response_text[:200]}...")
        print(f"Output tokens: {response.usage.output_tokens}")


def handle_stop_reasons():
    """Properly handle different stop reasons."""
    client = anthropic.Anthropic()

    response = client.messages.create(
        model="claude-opus-5",
        max_tokens=50,  # Intentionally low to potentially hit limit
        messages=[
            {"role": "user", "content": "Write a detailed essay about climate change."}
        ]
    )

    # Handle different stop reasons
    match response.stop_reason:
        case "end_turn":
            print("Claude finished naturally")
            print(response.content[0].text)

        case "max_tokens":
            print("WARNING: Response was truncated!")
            print("Partial response:", response.content[0].text)
            print("Consider increasing max_tokens")

        case "stop_sequence":
            print("Stopped at custom stop sequence")
            print(response.content[0].text)

        case "tool_use":
            print("Claude wants to call a tool")
            # Handle tool call...

        case "refusal":
            print("Claude refused the request")
            if response.stop_details:
                print(f"Category: {response.stop_details.category}")
                print(f"Explanation: {response.stop_details.explanation}")

        case "pause_turn":
            print("Response paused (agentic flow)")

        case _:
            print(f"Unknown stop reason: {response.stop_reason}")


def token_counting():
    """Count tokens before making a request."""
    client = anthropic.Anthropic()

    messages = [
        {"role": "user", "content": "Explain machine learning in detail."}
    ]
    system = "You are a computer science professor."

    # Count tokens before the request
    count_response = client.messages.count_tokens(
        model="claude-opus-5",
        messages=messages,
        system=system
    )

    print(f"Input tokens: {count_response.input_tokens}")

    # Estimate cost (at $5/1M input tokens for Opus 5)
    estimated_cost = count_response.input_tokens * 0.000005
    print(f"Estimated input cost: ${estimated_cost:.6f}")

    # Now make the actual request
    response = client.messages.create(
        model="claude-opus-5",
        max_tokens=1024,
        system=system,
        messages=messages
    )

    total_input = response.usage.input_tokens
    total_output = response.usage.output_tokens

    # Calculate actual cost
    input_cost = total_input * 0.000005  # $5/1M
    output_cost = total_output * 0.000025  # $25/1M
    total_cost = input_cost + output_cost

    print(f"\nActual usage:")
    print(f"  Input tokens: {total_input}")
    print(f"  Output tokens: {total_output}")
    print(f"  Total cost: ${total_cost:.6f}")


def prompt_caching_example():
    """Using prompt caching to reduce costs."""
    client = anthropic.Anthropic()

    # Large system prompt that will be cached
    large_context = """
    You are an expert Python programmer with deep knowledge of:
    - Object-oriented programming principles
    - Design patterns (Singleton, Factory, Observer, etc.)
    - Data structures and algorithms
    - Best practices for code quality
    - Testing methodologies (unit tests, integration tests)
    - Performance optimization techniques
    ... (imagine 10KB+ of context here) ...
    """

    # First request - writes to cache
    response1 = client.messages.create(
        model="claude-opus-5",
        max_tokens=1024,
        cache_control={"type": "ephemeral"},  # Enable auto-caching
        system=large_context,
        messages=[{"role": "user", "content": "How do I implement a singleton?"}]
    )

    print("First request (cache write):")
    print(f"  Cache creation tokens: {response1.usage.cache_creation_input_tokens}")
    print(f"  Cache read tokens: {response1.usage.cache_read_input_tokens}")

    # Second request - reads from cache
    response2 = client.messages.create(
        model="claude-opus-5",
        max_tokens=1024,
        cache_control={"type": "ephemeral"},
        system=large_context,  # Same system prompt
        messages=[{"role": "user", "content": "How do I implement a factory pattern?"}]
    )

    print("\nSecond request (cache read):")
    print(f"  Cache creation tokens: {response2.usage.cache_creation_input_tokens}")
    print(f"  Cache read tokens: {response2.usage.cache_read_input_tokens}")


if __name__ == "__main__":
    print("=" * 60)
    print("1. Basic Parameters")
    print("=" * 60)
    basic_parameters()

    print("\n" + "=" * 60)
    print("2. Extended Thinking")
    print("=" * 60)
    with_extended_thinking()

    print("\n" + "=" * 60)
    print("3. Stop Sequences")
    print("=" * 60)
    with_stop_sequences()

    print("\n" + "=" * 60)
    print("4. Handle Stop Reasons")
    print("=" * 60)
    handle_stop_reasons()

    print("\n" + "=" * 60)
    print("5. Token Counting")
    print("=" * 60)
    token_counting()
