# Tool Use - Defining and Calling Tools

Tools (also called function calling) allow Claude to interact with external systems by calling functions you define.

## How Tool Use Works

1. **You define tools** with a name, description, and input schema
2. **Claude decides** when to use them based on the conversation
3. **You execute** the tool and return results
4. **Claude continues** with the tool results

## Tool Schema Definition

Each tool has three parts:

### 1. Name
A unique identifier for the tool (snake_case recommended).

### 2. Description
Explains what the tool does and when to use it. This is crucial - Claude uses this to decide when to call the tool.

### 3. Input Schema
A JSON Schema defining the expected parameters.

```python
tool = {
    "name": "get_weather",
    "description": "Get the current weather for a specific location. Use this when the user asks about weather conditions.",
    "input_schema": {
        "type": "object",
        "properties": {
            "location": {
                "type": "string",
                "description": "City and state, e.g., 'San Francisco, CA'"
            },
            "unit": {
                "type": "string",
                "enum": ["celsius", "fahrenheit"],
                "description": "Temperature unit"
            }
        },
        "required": ["location"]
    }
}
```

## JSON Schema Basics

| Type | Example | Description |
|------|---------|-------------|
| `string` | `"hello"` | Text values |
| `number` | `42.5` | Numbers (int or float) |
| `integer` | `42` | Whole numbers only |
| `boolean` | `true/false` | True or false |
| `array` | `[1, 2, 3]` | Lists of items |
| `object` | `{"key": "value"}` | Nested structures |

### Common Schema Patterns

```python
# String with enum (limited choices)
"status": {
    "type": "string",
    "enum": ["active", "inactive", "pending"]
}

# Array of strings
"tags": {
    "type": "array",
    "items": {"type": "string"}
}

# Optional with default
"limit": {
    "type": "integer",
    "default": 10
}
```

---

## Tool Use Flow

### Step 1: Send request with tools

```python
response = client.messages.create(
    model="claude-opus-5",
    max_tokens=1024,
    tools=[weather_tool, calculator_tool],  # List of tools
    messages=[{"role": "user", "content": "What's the weather in Paris?"}]
)
```

### Step 2: Check if Claude wants to use a tool

```python
if response.stop_reason == "tool_use":
    # Claude wants to call a tool
    for block in response.content:
        if block.type == "tool_use":
            tool_name = block.name
            tool_input = block.input
            tool_id = block.id
```

### Step 3: Execute the tool and return results

```python
# Execute your tool
result = execute_tool(tool_name, tool_input)

# Continue the conversation with the result
response = client.messages.create(
    model="claude-opus-5",
    max_tokens=1024,
    tools=tools,
    messages=[
        {"role": "user", "content": "What's the weather in Paris?"},
        {"role": "assistant", "content": response.content},  # Include Claude's tool call
        {"role": "user", "content": [
            {
                "type": "tool_result",
                "tool_use_id": tool_id,
                "content": result
            }
        ]}
    ]
)
```

---

## Tool Runner (Recommended)

The SDK provides a tool runner that handles the loop automatically:

```python
from anthropic import beta_tool

@beta_tool
def get_weather(location: str, unit: str = "celsius") -> str:
    """Get current weather for a location.

    Args:
        location: City and state, e.g., San Francisco, CA.
        unit: Temperature unit, either "celsius" or "fahrenheit".
    """
    # Your implementation
    return f"72°F and sunny in {location}"

# The runner handles everything
runner = client.beta.messages.tool_runner(
    model="claude-opus-5",
    max_tokens=1024,
    tools=[get_weather],
    messages=[{"role": "user", "content": "What's the weather in Tokyo?"}]
)

for message in runner:
    print(message)
```

---

## Strict Tool Use

Guarantees tool inputs match the schema exactly:

```python
tool = {
    "name": "book_flight",
    "description": "Book a flight",
    "strict": True,  # Enable strict mode
    "input_schema": {
        "type": "object",
        "properties": {
            "destination": {"type": "string"},
            "date": {"type": "string", "format": "date"},
            "passengers": {"type": "integer"}
        },
        "required": ["destination", "date", "passengers"],
        "additionalProperties": False  # Required for strict
    }
}
```

---

## Tool Choice

Control which tools Claude can use:

```python
# Auto (default) - Claude decides
tool_choice={"type": "auto"}

# Force a specific tool
tool_choice={"type": "tool", "name": "get_weather"}

# Any tool (must use one)
tool_choice={"type": "any"}

# No tools
tool_choice={"type": "none"}
```

**Note:** `tool_choice: "any"` and `"tool"` are NOT supported on Claude Fable 5.1. Use `"auto"` with an instruction instead.

---

## Multiple Tool Calls

Claude can call multiple tools in a single turn. Execute them and return all results:

```python
tool_results = []
for block in response.content:
    if block.type == "tool_use":
        result = execute_tool(block.name, block.input)
        tool_results.append({
            "type": "tool_result",
            "tool_use_id": block.id,
            "content": result
        })

# Return ALL results in one message
messages.append({"role": "user", "content": tool_results})
```

---

## Error Handling

Return errors properly so Claude can adapt:

```python
tool_result = {
    "type": "tool_result",
    "tool_use_id": tool_id,
    "content": "Error: Location 'xyz' not found. Please provide a valid city.",
    "is_error": True  # Marks this as an error
}
```

---

## Best Practices

1. **Write clear descriptions** - Claude uses these to decide when to call tools
2. **Use strict mode** for reliable schemas
3. **Handle errors gracefully** - Return helpful error messages
4. **Keep tools focused** - One tool, one purpose
5. **Validate inputs** - Even with strict mode, validate business logic
