"""
Structured Output - Getting JSON Responses

This module demonstrates how to get structured, validated responses from Claude.
"""

import anthropic
import json
from typing import List, Optional
from pydantic import BaseModel, Field
from enum import Enum


# =============================================================================
# Pydantic Models for Structured Output
# =============================================================================

class Sentiment(str, Enum):
    POSITIVE = "positive"
    NEGATIVE = "negative"
    NEUTRAL = "neutral"


class ContactInfo(BaseModel):
    """Contact information extracted from text."""
    name: str = Field(description="Full name of the person")
    email: str = Field(description="Email address")
    company: Optional[str] = Field(default=None, description="Company name if mentioned")
    phone: Optional[str] = Field(default=None, description="Phone number if mentioned")


class ProductReview(BaseModel):
    """Structured product review analysis."""
    product_name: str
    rating: float = Field(ge=1, le=5, description="Rating from 1-5")
    sentiment: Sentiment
    pros: List[str] = Field(default_factory=list)
    cons: List[str] = Field(default_factory=list)
    summary: str = Field(description="One sentence summary")


class TaskItem(BaseModel):
    """A task extracted from meeting notes."""
    title: str
    assignee: Optional[str] = None
    due_date: Optional[str] = None
    priority: str = Field(default="medium")


class MeetingNotes(BaseModel):
    """Structured meeting notes."""
    title: str
    date: str
    attendees: List[str]
    key_points: List[str]
    action_items: List[TaskItem]
    next_meeting: Optional[str] = None


# =============================================================================
# Examples
# =============================================================================

def pydantic_basic_example():
    """Basic structured output with Pydantic."""
    client = anthropic.Anthropic()

    response = client.messages.parse(
        model="claude-opus-5",
        max_tokens=1024,
        messages=[{
            "role": "user",
            "content": """Extract contact info from this email signature:

            Best regards,
            Jane Smith
            Senior Engineer at TechCorp
            jane.smith@techcorp.com
            +1 (555) 123-4567
            """
        }],
        output_format=ContactInfo,
    )

    # parsed_output is a validated ContactInfo instance
    contact = response.parsed_output
    print(f"Name: {contact.name}")
    print(f"Email: {contact.email}")
    print(f"Company: {contact.company}")
    print(f"Phone: {contact.phone}")

    return contact


def pydantic_complex_example():
    """Complex nested structure with Pydantic."""
    client = anthropic.Anthropic()

    meeting_text = """
    Team Standup - March 15, 2024

    Attendees: Alice, Bob, Charlie, Diana

    Discussion:
    - Reviewed Q1 progress, on track for targets
    - Discussed new feature rollout timeline
    - Bob raised concerns about testing coverage

    Action Items:
    - Alice to complete API documentation by March 20
    - Bob to add unit tests for auth module (high priority)
    - Charlie to schedule client demo
    - Diana to review security audit findings by March 18

    Next meeting: March 18, 2024 at 10 AM
    """

    response = client.messages.parse(
        model="claude-opus-5",
        max_tokens=2048,
        messages=[{
            "role": "user",
            "content": f"Parse these meeting notes into structured format:\n\n{meeting_text}"
        }],
        output_format=MeetingNotes,
    )

    notes = response.parsed_output

    print(f"Meeting: {notes.title}")
    print(f"Date: {notes.date}")
    print(f"Attendees: {', '.join(notes.attendees)}")
    print(f"\nKey Points:")
    for point in notes.key_points:
        print(f"  - {point}")
    print(f"\nAction Items:")
    for task in notes.action_items:
        print(f"  - {task.title}")
        if task.assignee:
            print(f"    Assignee: {task.assignee}")
        if task.due_date:
            print(f"    Due: {task.due_date}")
    print(f"\nNext meeting: {notes.next_meeting}")

    return notes


def json_schema_example():
    """Using raw JSON schema instead of Pydantic."""
    client = anthropic.Anthropic()

    response = client.messages.create(
        model="claude-opus-5",
        max_tokens=1024,
        messages=[{
            "role": "user",
            "content": "Analyze this review: 'Great laptop! Fast processor and beautiful screen. Battery life could be better though. 4/5 stars.'"
        }],
        output_config={
            "format": {
                "type": "json_schema",
                "schema": {
                    "type": "object",
                    "properties": {
                        "product_type": {
                            "type": "string",
                            "description": "Type of product being reviewed"
                        },
                        "rating": {
                            "type": "number",
                            "minimum": 1,
                            "maximum": 5
                        },
                        "sentiment": {
                            "type": "string",
                            "enum": ["positive", "negative", "neutral"]
                        },
                        "pros": {
                            "type": "array",
                            "items": {"type": "string"}
                        },
                        "cons": {
                            "type": "array",
                            "items": {"type": "string"}
                        }
                    },
                    "required": ["product_type", "rating", "sentiment", "pros", "cons"],
                    "additionalProperties": False
                }
            }
        }
    )

    # Parse the JSON response
    result = json.loads(response.content[0].text)

    print(f"Product Type: {result['product_type']}")
    print(f"Rating: {result['rating']}/5")
    print(f"Sentiment: {result['sentiment']}")
    print(f"Pros: {', '.join(result['pros'])}")
    print(f"Cons: {', '.join(result['cons'])}")

    return result


def strict_tool_example():
    """Using strict tools for structured extraction."""
    client = anthropic.Anthropic()

    response = client.messages.create(
        model="claude-opus-5",
        max_tokens=1024,
        tools=[{
            "name": "extract_event",
            "description": "Extract event details from text",
            "strict": True,  # Guarantees schema compliance
            "input_schema": {
                "type": "object",
                "properties": {
                    "event_name": {"type": "string"},
                    "date": {"type": "string", "description": "ISO format date"},
                    "location": {"type": "string"},
                    "attendee_count": {"type": "integer"},
                    "is_virtual": {"type": "boolean"}
                },
                "required": ["event_name", "date", "location", "is_virtual"],
                "additionalProperties": False
            }
        }],
        tool_choice={"type": "tool", "name": "extract_event"},
        messages=[{
            "role": "user",
            "content": "Event: Tech Conference 2024 on April 15th at San Francisco Convention Center. Expected 500 attendees. In-person event."
        }]
    )

    # Get the structured data from tool input
    for block in response.content:
        if block.type == "tool_use":
            event = block.input
            print(f"Event: {event['event_name']}")
            print(f"Date: {event['date']}")
            print(f"Location: {event['location']}")
            print(f"Attendees: {event.get('attendee_count', 'N/A')}")
            print(f"Virtual: {'Yes' if event['is_virtual'] else 'No'}")
            return event


def batch_extraction_example():
    """Extracting multiple items from text."""
    client = anthropic.Anthropic()

    class Person(BaseModel):
        name: str
        role: str
        department: Optional[str] = None

    class TeamRoster(BaseModel):
        team_name: str
        members: List[Person]

    text = """
    Engineering Team Alpha:
    - Sarah Chen, Tech Lead, Backend
    - Mike Johnson, Senior Developer, Frontend
    - Lisa Park, Developer
    - Tom Wilson, QA Engineer, Quality Assurance

    Engineering Team Beta:
    - James Lee, Tech Lead
    - Anna Smith, Developer, Backend
    - Chris Brown, DevOps Engineer
    """

    class AllTeams(BaseModel):
        teams: List[TeamRoster]

    response = client.messages.parse(
        model="claude-opus-5",
        max_tokens=2048,
        messages=[{
            "role": "user",
            "content": f"Extract all team and member information:\n\n{text}"
        }],
        output_format=AllTeams,
    )

    for team in response.parsed_output.teams:
        print(f"\n{team.team_name}:")
        for member in team.members:
            dept = f" ({member.department})" if member.department else ""
            print(f"  - {member.name}: {member.role}{dept}")


def classification_example():
    """Using structured output for classification."""
    client = anthropic.Anthropic()

    class Classification(BaseModel):
        category: str = Field(description="Main category")
        subcategory: Optional[str] = None
        confidence: float = Field(ge=0, le=1)
        reasoning: str = Field(description="Brief explanation")

    texts = [
        "My order arrived damaged and customer service won't help!",
        "Love the new features in the latest update!",
        "How do I reset my password?",
    ]

    for text in texts:
        response = client.messages.parse(
            model="claude-opus-5",
            max_tokens=512,
            system="Classify support tickets into categories: complaint, feedback, question, bug_report",
            messages=[{"role": "user", "content": f"Classify: {text}"}],
            output_format=Classification,
        )

        result = response.parsed_output
        print(f"\nText: {text[:50]}...")
        print(f"Category: {result.category}")
        print(f"Confidence: {result.confidence:.0%}")
        print(f"Reasoning: {result.reasoning}")


def with_both_tools_and_output():
    """Combining tools with structured output."""
    client = anthropic.Anthropic()

    class TravelPlan(BaseModel):
        destination: str
        weather_summary: str
        recommended_activities: List[str]
        packing_suggestions: List[str]

    # In a real scenario, you'd have actual tool implementations
    # This example shows the structure

    response = client.messages.create(
        model="claude-opus-5",
        max_tokens=2048,
        output_config={
            "format": {
                "type": "json_schema",
                "schema": {
                    "type": "object",
                    "properties": {
                        "destination": {"type": "string"},
                        "weather_summary": {"type": "string"},
                        "recommended_activities": {
                            "type": "array",
                            "items": {"type": "string"}
                        },
                        "packing_suggestions": {
                            "type": "array",
                            "items": {"type": "string"}
                        }
                    },
                    "required": ["destination", "weather_summary", "recommended_activities", "packing_suggestions"],
                    "additionalProperties": False
                }
            }
        },
        messages=[{
            "role": "user",
            "content": "Create a travel plan for Tokyo in April. Assume typical spring weather."
        }]
    )

    plan = json.loads(response.content[0].text)
    print(f"Destination: {plan['destination']}")
    print(f"Weather: {plan['weather_summary']}")
    print(f"\nActivities:")
    for activity in plan['recommended_activities']:
        print(f"  - {activity}")
    print(f"\nPacking List:")
    for item in plan['packing_suggestions']:
        print(f"  - {item}")


if __name__ == "__main__":
    print("=" * 60)
    print("1. Basic Pydantic Example")
    print("=" * 60)
    pydantic_basic_example()

    print("\n" + "=" * 60)
    print("2. Complex Nested Structure")
    print("=" * 60)
    pydantic_complex_example()

    print("\n" + "=" * 60)
    print("3. JSON Schema Example")
    print("=" * 60)
    json_schema_example()

    print("\n" + "=" * 60)
    print("4. Strict Tool Example")
    print("=" * 60)
    strict_tool_example()

    print("\n" + "=" * 60)
    print("5. Batch Extraction")
    print("=" * 60)
    batch_extraction_example()

    print("\n" + "=" * 60)
    print("6. Classification")
    print("=" * 60)
    classification_example()
