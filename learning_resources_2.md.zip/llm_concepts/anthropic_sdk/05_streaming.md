# Streaming - Real-Time Response Delivery

Streaming allows you to receive Claude's response token-by-token as it's generated, rather than waiting for the complete response.

## Why Use Streaming?

1. **Better UX**: Users see responses immediately
2. **Avoid timeouts**: Large responses don't hit HTTP timeout limits
3. **Required for large `max_tokens`**: The SDK requires streaming for values > ~16000
4. **Progress feedback**: Show typing indicators, track generation

---

## Basic Streaming

### Using `messages.stream()` (Recommended)

```python
with client.messages.stream(
    model="claude-opus-5",
    max_tokens=64000,
    messages=[{"role": "user", "content": "Write a story"}]
) as stream:
    for text in stream.text_stream:
        print(text, end="", flush=True)
```

### Async Streaming

```python
async with client.messages.stream(
    model="claude-opus-5",
    max_tokens=64000,
    messages=[{"role": "user", "content": "Write a story"}]
) as stream:
    async for text in stream.text_stream:
        print(text, end="", flush=True)
```

---

## Getting the Final Message

After streaming, you can get the complete message:

```python
with client.messages.stream(
    model="claude-opus-5",
    max_tokens=64000,
    messages=[{"role": "user", "content": "Hello"}]
) as stream:
    for text in stream.text_stream:
        print(text, end="", flush=True)

    # Get the complete message after streaming
    final_message = stream.get_final_message()
    print(f"\n\nTotal tokens: {final_message.usage.output_tokens}")
```

---

## Stream Event Types

When iterating over the raw stream, you get these events:

| Event Type | Description | Useful Fields |
|------------|-------------|---------------|
| `message_start` | Message begins | `message` (metadata) |
| `content_block_start` | New content block | `content_block.type` |
| `content_block_delta` | Incremental content | `delta.text` or `delta.thinking` |
| `content_block_stop` | Block complete | `index` |
| `message_delta` | Message-level updates | `stop_reason`, `usage` |
| `message_stop` | Message complete | - |

---

## Handling Different Content Types

Claude can return text, thinking blocks, and tool calls. Handle each:

```python
with client.messages.stream(
    model="claude-opus-5",
    max_tokens=64000,
    thinking={"type": "adaptive", "display": "summarized"},
    messages=[{"role": "user", "content": "Solve this step by step: 15% of 847"}]
) as stream:
    for event in stream:
        if event.type == "content_block_start":
            if event.content_block.type == "thinking":
                print("\n[Thinking...]")
            elif event.content_block.type == "text":
                print("\n[Response:]")

        elif event.type == "content_block_delta":
            if event.delta.type == "thinking_delta":
                print(event.delta.thinking, end="", flush=True)
            elif event.delta.type == "text_delta":
                print(event.delta.text, end="", flush=True)
```

---

## Streaming with Tools

The tool runner supports streaming:

```python
from anthropic import beta_tool

@beta_tool
def get_weather(location: str) -> str:
    """Get weather for a location."""
    return f"Sunny in {location}"

runner = client.beta.messages.tool_runner(
    model="claude-opus-5",
    max_tokens=16000,
    tools=[get_weather],
    messages=[{"role": "user", "content": "What's the weather in Paris?"}],
    stream=True,  # Enable streaming
)

for stream in runner:
    for text in stream.text_stream:
        print(text, end="", flush=True)
    final = stream.get_final_message()
```

### Manual Loop with Streaming

```python
with client.messages.stream(
    model="claude-opus-5",
    max_tokens=64000,
    tools=tools,
    messages=messages
) as stream:
    for text in stream.text_stream:
        print(text, end="", flush=True)

    response = stream.get_final_message()

    if response.stop_reason == "tool_use":
        # Handle tool calls
        pass
```

---

## Low-Level: `stream=True`

For minimal memory usage, use `stream=True` instead of `messages.stream()`:

```python
for event in client.messages.create(
    model="claude-opus-5",
    max_tokens=64000,
    messages=[{"role": "user", "content": "Write a story"}],
    stream=True,
):
    if event.type == "content_block_delta":
        if event.delta.type == "text_delta":
            print(event.delta.text, end="", flush=True)
```

This doesn't accumulate state, so there's no `get_final_message()`.

---

## Best Practices

1. **Always flush output**: Use `flush=True` to show tokens immediately
2. **Handle interruptions**: Partial content may be valid
3. **Track usage**: The `message_delta` event contains token counts
4. **Default to streaming**: Use `get_final_message()` for the complete response
5. **Large max_tokens**: The SDK requires streaming for values that might timeout

---

## Error Handling

```python
import anthropic

try:
    with client.messages.stream(
        model="claude-opus-5",
        max_tokens=64000,
        messages=[{"role": "user", "content": "Hello"}]
    ) as stream:
        for text in stream.text_stream:
            print(text, end="", flush=True)
except anthropic.APIConnectionError:
    print("\nConnection lost. Retry needed.")
except anthropic.RateLimitError:
    print("\nRate limited. Wait and retry.")
except anthropic.APIStatusError as e:
    print(f"\nAPI error: {e.status_code}")
```

---

## Progress Tracking

```python
def stream_with_progress(client, **kwargs):
    """Stream with progress updates."""
    total_tokens = 0

    with client.messages.stream(**kwargs) as stream:
        for event in stream:
            if event.type == "content_block_delta":
                if event.delta.type == "text_delta":
                    print(event.delta.text, end="", flush=True)

            elif event.type == "message_delta":
                if event.usage:
                    total_tokens = event.usage.output_tokens

        final = stream.get_final_message()

    print(f"\n\n[Generated {total_tokens} tokens]")
    return final
```
