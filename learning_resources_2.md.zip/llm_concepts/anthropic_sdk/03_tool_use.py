"""
Tool Use - Defining and Calling Tools

This module demonstrates how to define tools and handle tool calls with the Claude SDK.
"""

import anthropic
import json
from typing import Any


# =============================================================================
# Tool Definitions
# =============================================================================

WEATHER_TOOL = {
    "name": "get_weather",
    "description": "Get the current weather for a specific location. Use this when the user asks about weather, temperature, or atmospheric conditions.",
    "input_schema": {
        "type": "object",
        "properties": {
            "location": {
                "type": "string",
                "description": "City and state/country, e.g., 'San Francisco, CA' or 'London, UK'"
            },
            "unit": {
                "type": "string",
                "enum": ["celsius", "fahrenheit"],
                "description": "Temperature unit preference"
            }
        },
        "required": ["location"]
    }
}

CALCULATOR_TOOL = {
    "name": "calculator",
    "description": "Perform mathematical calculations. Use for arithmetic, percentages, or any numeric computation.",
    "input_schema": {
        "type": "object",
        "properties": {
            "expression": {
                "type": "string",
                "description": "Mathematical expression to evaluate, e.g., '15 * 7 + 23'"
            }
        },
        "required": ["expression"]
    }
}

SEARCH_TOOL = {
    "name": "search_database",
    "description": "Search a database for records matching given criteria.",
    "strict": True,  # Strict mode for guaranteed schema compliance
    "input_schema": {
        "type": "object",
        "properties": {
            "query": {
                "type": "string",
                "description": "Search query"
            },
            "filters": {
                "type": "object",
                "properties": {
                    "category": {"type": "string"},
                    "min_price": {"type": "number"},
                    "max_price": {"type": "number"}
                },
                "additionalProperties": False
            },
            "limit": {
                "type": "integer",
                "description": "Maximum results to return",
                "default": 10
            }
        },
        "required": ["query"],
        "additionalProperties": False  # Required for strict mode
    }
}


# =============================================================================
# Tool Implementations (Mock)
# =============================================================================

def get_weather(location: str, unit: str = "celsius") -> str:
    """Mock weather API."""
    weather_data = {
        "paris": {"temp_c": 18, "temp_f": 64, "condition": "Partly cloudy"},
        "tokyo": {"temp_c": 22, "temp_f": 72, "condition": "Sunny"},
        "new york": {"temp_c": 15, "temp_f": 59, "condition": "Rainy"},
    }

    city = location.lower().split(",")[0].strip()
    if city in weather_data:
        data = weather_data[city]
        temp = data["temp_f"] if unit == "fahrenheit" else data["temp_c"]
        unit_symbol = "°F" if unit == "fahrenheit" else "°C"
        return f"Weather in {location}: {temp}{unit_symbol}, {data['condition']}"
    else:
        return f"Weather data not available for {location}"


def calculator(expression: str) -> str:
    """Safe calculator."""
    try:
        allowed_chars = set("0123456789+-*/.() ")
        if not all(c in allowed_chars for c in expression):
            return "Error: Invalid characters in expression"
        result = eval(expression)  # Safe because we validated chars
        return f"Result: {result}"
    except Exception as e:
        return f"Error: Could not evaluate expression - {str(e)}"


def search_database(query: str, filters: dict = None, limit: int = 10) -> str:
    """Mock database search."""
    return json.dumps({
        "query": query,
        "filters": filters or {},
        "results": [
            {"id": 1, "name": f"Result for '{query}'", "price": 29.99},
            {"id": 2, "name": f"Another result for '{query}'", "price": 49.99},
        ][:limit]
    })


def execute_tool(name: str, inputs: dict) -> str:
    """Route tool calls to implementations."""
    tools = {
        "get_weather": lambda i: get_weather(i["location"], i.get("unit", "celsius")),
        "calculator": lambda i: calculator(i["expression"]),
        "search_database": lambda i: search_database(i["query"], i.get("filters"), i.get("limit", 10)),
    }

    if name in tools:
        return tools[name](inputs)
    return f"Error: Unknown tool '{name}'"


# =============================================================================
# Examples
# =============================================================================

def single_tool_call():
    """Basic single tool call example."""
    client = anthropic.Anthropic()

    print("User: What's the weather in Paris?")

    response = client.messages.create(
        model="claude-opus-5",
        max_tokens=1024,
        tools=[WEATHER_TOOL],
        messages=[{"role": "user", "content": "What's the weather in Paris?"}]
    )

    print(f"Stop reason: {response.stop_reason}")

    if response.stop_reason == "tool_use":
        for block in response.content:
            if block.type == "tool_use":
                print(f"\nClaude wants to call: {block.name}")
                print(f"With inputs: {block.input}")

                # Execute the tool
                result = execute_tool(block.name, block.input)
                print(f"Tool result: {result}")

                # Continue the conversation with the result
                followup = client.messages.create(
                    model="claude-opus-5",
                    max_tokens=1024,
                    tools=[WEATHER_TOOL],
                    messages=[
                        {"role": "user", "content": "What's the weather in Paris?"},
                        {"role": "assistant", "content": response.content},
                        {"role": "user", "content": [
                            {
                                "type": "tool_result",
                                "tool_use_id": block.id,
                                "content": result
                            }
                        ]}
                    ]
                )

                print(f"\nClaude's final response: {followup.content[0].text}")


def multiple_tools():
    """Using multiple tools in one conversation."""
    client = anthropic.Anthropic()
    tools = [WEATHER_TOOL, CALCULATOR_TOOL]

    print("User: What's 15% of 847? Also, what's the weather in Tokyo?")

    messages = [
        {"role": "user", "content": "What's 15% of 847? Also, what's the weather in Tokyo?"}
    ]

    # Loop until Claude is done calling tools
    while True:
        response = client.messages.create(
            model="claude-opus-5",
            max_tokens=1024,
            tools=tools,
            messages=messages
        )

        if response.stop_reason == "end_turn":
            print(f"\nClaude's response: {response.content[0].text}")
            break

        # Handle tool calls
        tool_results = []
        for block in response.content:
            if block.type == "tool_use":
                print(f"Calling {block.name} with {block.input}")
                result = execute_tool(block.name, block.input)
                print(f"Result: {result}")

                tool_results.append({
                    "type": "tool_result",
                    "tool_use_id": block.id,
                    "content": result
                })

        # Add Claude's message and tool results
        messages.append({"role": "assistant", "content": response.content})
        messages.append({"role": "user", "content": tool_results})


def agentic_loop():
    """Complete agentic loop pattern."""
    client = anthropic.Anthropic()
    tools = [WEATHER_TOOL, CALCULATOR_TOOL, SEARCH_TOOL]

    def run_agent(user_message: str, max_iterations: int = 10) -> str:
        """Run an agentic loop until completion."""
        messages = [{"role": "user", "content": user_message}]

        for _ in range(max_iterations):
            response = client.messages.create(
                model="claude-opus-5",
                max_tokens=4096,
                tools=tools,
                messages=messages
            )

            # Check stop reason
            if response.stop_reason == "end_turn":
                return next(b.text for b in response.content if b.type == "text")

            if response.stop_reason == "max_tokens":
                return "Error: Response was truncated"

            if response.stop_reason != "tool_use":
                return f"Unexpected stop reason: {response.stop_reason}"

            # Execute all tool calls
            tool_results = []
            for block in response.content:
                if block.type == "tool_use":
                    try:
                        result = execute_tool(block.name, block.input)
                        tool_results.append({
                            "type": "tool_result",
                            "tool_use_id": block.id,
                            "content": result
                        })
                    except Exception as e:
                        tool_results.append({
                            "type": "tool_result",
                            "tool_use_id": block.id,
                            "content": f"Error: {str(e)}",
                            "is_error": True
                        })

            messages.append({"role": "assistant", "content": response.content})
            messages.append({"role": "user", "content": tool_results})

        return "Error: Max iterations reached"

    # Test the agent
    result = run_agent("I need to know the weather in Paris and calculate 20% tip on a $85 bill")
    print(f"\nAgent result:\n{result}")


def tool_runner_example():
    """Using the SDK's tool runner (recommended approach)."""
    from anthropic import beta_tool

    client = anthropic.Anthropic()

    @beta_tool
    def get_stock_price(symbol: str) -> str:
        """Get the current stock price for a ticker symbol.

        Args:
            symbol: Stock ticker symbol, e.g., 'AAPL' for Apple.
        """
        prices = {"AAPL": 178.50, "GOOGL": 141.25, "MSFT": 378.90}
        if symbol.upper() in prices:
            return f"{symbol.upper()}: ${prices[symbol.upper()]}"
        return f"Price not found for {symbol}"

    @beta_tool
    def convert_currency(amount: float, from_currency: str, to_currency: str) -> str:
        """Convert an amount from one currency to another.

        Args:
            amount: The amount to convert.
            from_currency: Source currency code (e.g., 'USD').
            to_currency: Target currency code (e.g., 'EUR').
        """
        rates = {"USD_EUR": 0.92, "USD_GBP": 0.79, "EUR_USD": 1.09}
        key = f"{from_currency.upper()}_{to_currency.upper()}"
        if key in rates:
            result = amount * rates[key]
            return f"{amount} {from_currency} = {result:.2f} {to_currency}"
        return f"Conversion rate not available for {from_currency} to {to_currency}"

    print("Using tool runner:")

    runner = client.beta.messages.tool_runner(
        model="claude-opus-5",
        max_tokens=1024,
        tools=[get_stock_price, convert_currency],
        messages=[
            {"role": "user", "content": "What's Apple's stock price? Convert $100 USD to EUR."}
        ]
    )

    for message in runner:
        for block in message.content:
            if block.type == "text":
                print(f"Claude: {block.text}")


def error_handling_example():
    """Demonstrating proper error handling in tool calls."""
    client = anthropic.Anthropic()

    tools = [{
        "name": "divide_numbers",
        "description": "Divide two numbers",
        "input_schema": {
            "type": "object",
            "properties": {
                "numerator": {"type": "number"},
                "denominator": {"type": "number"}
            },
            "required": ["numerator", "denominator"]
        }
    }]

    messages = [{"role": "user", "content": "Divide 10 by 0"}]

    response = client.messages.create(
        model="claude-opus-5",
        max_tokens=1024,
        tools=tools,
        messages=messages
    )

    if response.stop_reason == "tool_use":
        for block in response.content:
            if block.type == "tool_use":
                inputs = block.input

                # Check for division by zero
                if inputs.get("denominator") == 0:
                    tool_result = {
                        "type": "tool_result",
                        "tool_use_id": block.id,
                        "content": "Error: Division by zero is not allowed",
                        "is_error": True  # Mark as error
                    }
                else:
                    result = inputs["numerator"] / inputs["denominator"]
                    tool_result = {
                        "type": "tool_result",
                        "tool_use_id": block.id,
                        "content": f"Result: {result}"
                    }

                # Continue with error result
                followup = client.messages.create(
                    model="claude-opus-5",
                    max_tokens=1024,
                    tools=tools,
                    messages=[
                        *messages,
                        {"role": "assistant", "content": response.content},
                        {"role": "user", "content": [tool_result]}
                    ]
                )

                print(f"Claude's response to error: {followup.content[0].text}")


if __name__ == "__main__":
    print("=" * 60)
    print("1. Single Tool Call")
    print("=" * 60)
    single_tool_call()

    print("\n" + "=" * 60)
    print("2. Multiple Tools")
    print("=" * 60)
    multiple_tools()

    print("\n" + "=" * 60)
    print("3. Agentic Loop")
    print("=" * 60)
    agentic_loop()

    print("\n" + "=" * 60)
    print("4. Tool Runner (Recommended)")
    print("=" * 60)
    tool_runner_example()

    print("\n" + "=" * 60)
    print("5. Error Handling")
    print("=" * 60)
    error_handling_example()
