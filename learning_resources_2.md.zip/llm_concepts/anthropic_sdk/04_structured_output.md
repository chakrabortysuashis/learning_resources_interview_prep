# Structured Output - Getting JSON Responses

Structured outputs ensure Claude returns data in a specific, predictable format. This is essential for:
- Parsing responses programmatically
- Data extraction tasks
- API integrations
- Form filling

## Two Approaches

### 1. `messages.parse()` with Pydantic (Recommended)
Best for Python - type-safe, validated, auto-generates schema.

### 2. `output_config.format` with JSON Schema
Direct schema definition - works in any language.

---

## Approach 1: Pydantic Models (Recommended)

```python
from pydantic import BaseModel
from typing import List
import anthropic

class ContactInfo(BaseModel):
    name: str
    email: str
    company: str
    interests: List[str]
    demo_requested: bool

client = anthropic.Anthropic()

response = client.messages.parse(
    model="claude-opus-5",
    max_tokens=1024,
    messages=[{
        "role": "user",
        "content": "Extract: Jane Doe (jane@acme.com) from Acme Corp, interested in API and SDKs, wants a demo."
    }],
    output_format=ContactInfo,  # Pass the Pydantic model
)

# response.parsed_output is a validated ContactInfo instance
contact = response.parsed_output
print(contact.name)        # "Jane Doe"
print(contact.email)       # "jane@acme.com"
print(contact.interests)   # ["API", "SDKs"]
```

### Pydantic Features

```python
from pydantic import BaseModel, Field
from typing import Optional, List, Literal
from enum import Enum

class Priority(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"

class Task(BaseModel):
    title: str = Field(description="Brief task title")
    description: Optional[str] = Field(default=None, description="Detailed description")
    priority: Priority
    tags: List[str] = Field(default_factory=list)
    estimated_hours: float = Field(ge=0, le=100)  # Constraints: 0-100
```

---

## Approach 2: JSON Schema

```python
response = client.messages.create(
    model="claude-opus-5",
    max_tokens=1024,
    messages=[{"role": "user", "content": "Extract contact info from: John at john@example.com"}],
    output_config={
        "format": {
            "type": "json_schema",
            "schema": {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "email": {"type": "string", "format": "email"},
                    "phone": {"type": "string"}
                },
                "required": ["name", "email"],
                "additionalProperties": False
            }
        }
    }
)

import json
data = json.loads(response.content[0].text)
```

### Common JSON Schema Patterns

```python
# String with enum
"status": {
    "type": "string",
    "enum": ["pending", "approved", "rejected"]
}

# Array of objects
"items": {
    "type": "array",
    "items": {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "quantity": {"type": "integer"}
        },
        "required": ["name", "quantity"]
    }
}

# Nullable field
"notes": {
    "type": ["string", "null"]
}

# Number with constraints
"price": {
    "type": "number",
    "minimum": 0,
    "maximum": 10000
}
```

---

## Strict Tool Use

Another way to get structured data is with strict tools:

```python
response = client.messages.create(
    model="claude-opus-5",
    max_tokens=1024,
    tools=[{
        "name": "extract_contact",
        "description": "Extract contact information",
        "strict": True,  # Guarantees schema compliance
        "input_schema": {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "email": {"type": "string"}
            },
            "required": ["name", "email"],
            "additionalProperties": False
        }
    }],
    tool_choice={"type": "tool", "name": "extract_contact"},
    messages=[{"role": "user", "content": "Contact: Bob (bob@test.com)"}]
)

# Get the tool input
for block in response.content:
    if block.type == "tool_use":
        contact = block.input  # Already a dict matching the schema
```

---

## When to Use Which

| Approach | Best For |
|----------|----------|
| `messages.parse()` + Pydantic | Python apps, type safety, complex nested structures |
| `output_config.format` | Any language, simple structures, when you need raw JSON |
| Strict tools | When extraction is part of a tool-calling workflow |

---

## Best Practices

1. **Always use `additionalProperties: false`** in JSON schemas for strict compliance
2. **Provide descriptions** - helps Claude understand what you want
3. **Use enums** for constrained values
4. **Mark fields as required** when they must be present
5. **Handle parsing errors** - even with strict mode, validate in your code

---

## Limitations

- **Citations incompatible**: Can't use `output_config.format` with document citations
- **Tool choice on Fable 5.1**: `tool_choice: "tool"` not supported - use `auto` with instruction
- **Nested depth**: Very deep nesting can confuse the model
