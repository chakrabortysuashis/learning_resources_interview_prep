"""
Streaming - Real-Time Response Delivery

This module demonstrates streaming responses from the Claude API.
"""

import anthropic
import time


def basic_streaming():
    """Basic streaming example."""
    client = anthropic.Anthropic()

    print("Streaming response:")
    print("-" * 40)

    with client.messages.stream(
        model="claude-opus-5",
        max_tokens=1024,
        messages=[{"role": "user", "content": "Write a haiku about programming."}]
    ) as stream:
        for text in stream.text_stream:
            print(text, end="", flush=True)

    print("\n" + "-" * 40)


def streaming_with_final_message():
    """Get the complete message after streaming."""
    client = anthropic.Anthropic()

    print("Streaming with final message:")

    with client.messages.stream(
        model="claude-opus-5",
        max_tokens=1024,
        messages=[{"role": "user", "content": "List 3 Python tips."}]
    ) as stream:
        for text in stream.text_stream:
            print(text, end="", flush=True)

        # Get the complete message after streaming
        final_message = stream.get_final_message()

    print(f"\n\nStop reason: {final_message.stop_reason}")
    print(f"Output tokens: {final_message.usage.output_tokens}")


def streaming_with_thinking():
    """Stream both thinking and response."""
    client = anthropic.Anthropic()

    print("Streaming with extended thinking:")

    with client.messages.stream(
        model="claude-opus-5",
        max_tokens=4096,
        thinking={"type": "adaptive", "display": "summarized"},
        messages=[{"role": "user", "content": "What is 23 * 47? Show your work."}]
    ) as stream:
        current_block = None

        for event in stream:
            if event.type == "content_block_start":
                block_type = event.content_block.type
                if block_type == "thinking":
                    print("\n[Thinking...]")
                    current_block = "thinking"
                elif block_type == "text":
                    print("\n[Response:]")
                    current_block = "text"

            elif event.type == "content_block_delta":
                if event.delta.type == "thinking_delta":
                    print(event.delta.thinking, end="", flush=True)
                elif event.delta.type == "text_delta":
                    print(event.delta.text, end="", flush=True)

            elif event.type == "content_block_stop":
                print()  # New line after block ends


def streaming_all_events():
    """Explore all event types in the stream."""
    client = anthropic.Anthropic()

    print("All stream events:")

    with client.messages.stream(
        model="claude-opus-5",
        max_tokens=256,
        messages=[{"role": "user", "content": "Say hello"}]
    ) as stream:
        for event in stream:
            print(f"Event: {event.type}")

            if event.type == "message_start":
                print(f"  Model: {event.message.model}")
                print(f"  Input tokens: {event.message.usage.input_tokens}")

            elif event.type == "content_block_start":
                print(f"  Block type: {event.content_block.type}")
                print(f"  Block index: {event.index}")

            elif event.type == "content_block_delta":
                if event.delta.type == "text_delta":
                    print(f"  Text: '{event.delta.text}'")

            elif event.type == "content_block_stop":
                print(f"  Block {event.index} complete")

            elif event.type == "message_delta":
                print(f"  Stop reason: {event.delta.stop_reason}")
                if event.usage:
                    print(f"  Output tokens: {event.usage.output_tokens}")

            elif event.type == "message_stop":
                print("  Message complete")


def streaming_with_progress():
    """Stream with progress tracking."""
    client = anthropic.Anthropic()

    print("Streaming with progress:")
    print("-" * 40)

    start_time = time.time()
    char_count = 0

    with client.messages.stream(
        model="claude-opus-5",
        max_tokens=1024,
        messages=[{"role": "user", "content": "Explain recursion briefly."}]
    ) as stream:
        for event in stream:
            if event.type == "content_block_delta":
                if event.delta.type == "text_delta":
                    text = event.delta.text
                    char_count += len(text)
                    print(text, end="", flush=True)

            elif event.type == "message_delta":
                if event.usage:
                    elapsed = time.time() - start_time
                    tokens = event.usage.output_tokens
                    print(f"\n\nStats:")
                    print(f"  Characters: {char_count}")
                    print(f"  Tokens: {tokens}")
                    print(f"  Time: {elapsed:.2f}s")
                    print(f"  Rate: {tokens/elapsed:.1f} tokens/sec")


def streaming_with_tools():
    """Streaming in a tool-using context."""
    client = anthropic.Anthropic()

    tools = [{
        "name": "get_time",
        "description": "Get the current time",
        "input_schema": {
            "type": "object",
            "properties": {
                "timezone": {"type": "string", "description": "Timezone name"}
            },
            "required": ["timezone"]
        }
    }]

    messages = [{"role": "user", "content": "What time is it in Tokyo?"}]

    print("Streaming with tools:")

    with client.messages.stream(
        model="claude-opus-5",
        max_tokens=1024,
        tools=tools,
        messages=messages
    ) as stream:
        for text in stream.text_stream:
            print(text, end="", flush=True)

        response = stream.get_final_message()

    print(f"\n\nStop reason: {response.stop_reason}")

    # Handle tool call if needed
    if response.stop_reason == "tool_use":
        for block in response.content:
            if block.type == "tool_use":
                print(f"Tool call: {block.name}({block.input})")


def low_level_streaming():
    """Low-level streaming with stream=True (no state accumulation)."""
    client = anthropic.Anthropic()

    print("Low-level streaming (stream=True):")
    print("-" * 40)

    # This form doesn't accumulate state - lower memory usage
    for event in client.messages.create(
        model="claude-opus-5",
        max_tokens=256,
        messages=[{"role": "user", "content": "Count to 5."}],
        stream=True,  # Low-level streaming
    ):
        if event.type == "content_block_delta":
            if event.delta.type == "text_delta":
                print(event.delta.text, end="", flush=True)

    print("\n" + "-" * 40)
    print("(No get_final_message() available in this form)")


def error_handling_streaming():
    """Proper error handling for streams."""
    client = anthropic.Anthropic()

    print("Error handling in streaming:")

    try:
        with client.messages.stream(
            model="claude-opus-5",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hello!"}]
        ) as stream:
            for text in stream.text_stream:
                print(text, end="", flush=True)

    except anthropic.APIConnectionError:
        print("\nConnection error - check your internet connection")

    except anthropic.RateLimitError as e:
        retry_after = e.response.headers.get("retry-after", "60")
        print(f"\nRate limited - retry after {retry_after} seconds")

    except anthropic.AuthenticationError:
        print("\nAuthentication failed - check your API key")

    except anthropic.APIStatusError as e:
        print(f"\nAPI error ({e.status_code}): {e.message}")

    print("\nStream completed or handled error")


async def async_streaming():
    """Async streaming example."""
    client = anthropic.AsyncAnthropic()

    print("Async streaming:")
    print("-" * 40)

    async with client.messages.stream(
        model="claude-opus-5",
        max_tokens=1024,
        messages=[{"role": "user", "content": "Write a short poem."}]
    ) as stream:
        async for text in stream.text_stream:
            print(text, end="", flush=True)

        final = stream.get_final_message()

    print(f"\n\nTokens: {final.usage.output_tokens}")


def typewriter_effect():
    """Create a typewriter effect with delays."""
    client = anthropic.Anthropic()

    print("Typewriter effect:")
    print("-" * 40)

    with client.messages.stream(
        model="claude-opus-5",
        max_tokens=256,
        messages=[{"role": "user", "content": "Write one sentence about AI."}]
    ) as stream:
        for text in stream.text_stream:
            for char in text:
                print(char, end="", flush=True)
                time.sleep(0.02)  # Small delay for typewriter effect

    print("\n" + "-" * 40)


if __name__ == "__main__":
    print("=" * 60)
    print("1. Basic Streaming")
    print("=" * 60)
    basic_streaming()

    print("\n" + "=" * 60)
    print("2. Streaming with Final Message")
    print("=" * 60)
    streaming_with_final_message()

    print("\n" + "=" * 60)
    print("3. Streaming with Thinking")
    print("=" * 60)
    streaming_with_thinking()

    print("\n" + "=" * 60)
    print("4. All Stream Events")
    print("=" * 60)
    streaming_all_events()

    print("\n" + "=" * 60)
    print("5. Streaming with Progress")
    print("=" * 60)
    streaming_with_progress()

    print("\n" + "=" * 60)
    print("6. Low-Level Streaming")
    print("=" * 60)
    low_level_streaming()

    print("\n" + "=" * 60)
    print("7. Error Handling")
    print("=" * 60)
    error_handling_streaming()

    print("\n" + "=" * 60)
    print("8. Typewriter Effect")
    print("=" * 60)
    typewriter_effect()

    # Async example requires async context
    print("\n" + "=" * 60)
    print("9. Async Streaming (requires asyncio.run)")
    print("=" * 60)
    import asyncio
    asyncio.run(async_streaming())
