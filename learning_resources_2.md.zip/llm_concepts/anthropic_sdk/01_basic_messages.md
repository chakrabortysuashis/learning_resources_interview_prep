# Basic Messages - System, User, and Assistant Roles

The Claude API uses a messages-based format with three distinct roles that work together to create conversations.

## The Three Roles

### 1. System Role
The system prompt sets Claude's behavior, personality, and constraints. It's like giving instructions to an employee before they start a task.

```python
system="You are a helpful coding assistant. Always provide examples in Python."
```

**Best Practices:**
- Put stable instructions here (they can be cached for cost savings)
- Define the persona, tone, and constraints
- Specify output format requirements
- Set any rules Claude should follow

### 2. User Role
Messages from the human user. These are the questions, requests, or inputs.

```python
{"role": "user", "content": "How do I read a JSON file?"}
```

### 3. Assistant Role
Messages from Claude. In multi-turn conversations, you include Claude's previous responses.

```python
{"role": "assistant", "content": "Here's how to read a JSON file in Python..."}
```

## Message Structure

The API expects messages as a list of dictionaries:

```python
messages = [
    {"role": "user", "content": "What is 2+2?"},
    {"role": "assistant", "content": "2+2 equals 4."},
    {"role": "user", "content": "And what about 3+3?"}
]
```

## Rules

1. **First message must be from user**: The conversation must start with a user message
2. **Roles should alternate**: User -> Assistant -> User -> Assistant...
3. **Consecutive same-role messages are allowed**: The API combines them automatically
4. **System is separate**: System prompt is passed as a separate parameter, not in messages

## Content Formats

Messages can contain simple strings or complex content blocks:

### Simple String
```python
{"role": "user", "content": "Hello!"}
```

### Content Blocks (for images, files, etc.)
```python
{
    "role": "user",
    "content": [
        {"type": "text", "text": "What's in this image?"},
        {"type": "image", "source": {"type": "base64", "media_type": "image/png", "data": "..."}}
    ]
}
```

## Multi-Turn Conversations

The API is **stateless** - you must send the full conversation history each time:

```python
# Turn 1
response1 = client.messages.create(
    model="claude-opus-5",
    max_tokens=1024,
    messages=[{"role": "user", "content": "My name is Alice."}]
)

# Turn 2 - include previous messages
response2 = client.messages.create(
    model="claude-opus-5",
    max_tokens=1024,
    messages=[
        {"role": "user", "content": "My name is Alice."},
        {"role": "assistant", "content": response1.content[0].text},
        {"role": "user", "content": "What's my name?"}
    ]
)
```

## Mid-Conversation System Messages

For advanced use cases, you can inject system instructions mid-conversation (supported on Claude Opus 5, Opus 4.8, Fable 5):

```python
messages = [
    {"role": "user", "content": "Help me write code"},
    {"role": "assistant", "content": "I'd be happy to help!"},
    {"role": "user", "content": "Write a function to sort a list"},
    {"role": "system", "content": "Terse mode: keep responses under 50 words"}
]
```

This preserves the cached conversation prefix while adding new instructions.
