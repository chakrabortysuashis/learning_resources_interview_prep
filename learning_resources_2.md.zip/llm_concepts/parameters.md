# LLM Sampling Parameters: Temperature, Top-P, and Top-K

When an LLM generates text, it doesn't just pick one word—it calculates **probabilities** for every possible next word (token). These parameters control **how the model chooses** from those probabilities.

---

## The Core Idea: Token Probabilities

Imagine the model is completing: **"The cat sat on the ___"**

The model assigns probabilities to possible next words:

```
┌─────────────────────────────────────────────────────────┐
│  Token Probabilities (before any sampling)              │
├─────────────────────────────────────────────────────────┤
│  mat      ████████████████████████████████  50%         │
│  floor    ██████████████████                25%         │
│  couch    ████████████                      15%         │
│  roof     ████                               5%         │
│  moon     ██                                 3%         │
│  pizza    █                                  2%         │
└─────────────────────────────────────────────────────────┘
```

Now let's see how each parameter affects which word gets selected.

---

## 1. Temperature

**What it does:** Controls how "sharp" or "flat" the probability distribution is.

### Simple Analogy
Think of temperature like **confidence in decision-making**:
- **Low temperature (0.1-0.3)** = Very confident, always picks the obvious choice
- **Medium temperature (0.7-1.0)** = Balanced, some variety
- **High temperature (1.5-2.0)** = Adventurous, willing to pick unusual options

### How It Works

Temperature **divides** the raw scores (logits) before converting to probabilities.

```
                    LOW TEMPERATURE (0.2)
                    Very peaked/confident
    
    Probability
         │
     50% │  ████
         │  ████
     40% │  ████
         │  ████
     30% │  ████
         │  ████
     20% │  ████
         │  ████  ██
     10% │  ████  ██  █
      0% └──────────────────────
           mat  floor couch roof
           
    → Almost always picks "mat"
```

```
                    HIGH TEMPERATURE (1.5)
                    Flattened/uncertain
    
    Probability
         │
     30% │  ████
         │  ████  ████
     20% │  ████  ████  ████
         │  ████  ████  ████  ████
     10% │  ████  ████  ████  ████  ████
      0% └────────────────────────────────
           mat  floor couch roof  moon
           
    → More likely to pick unexpected words
```

### Temperature Values

| Value | Behavior | Use Case |
|-------|----------|----------|
| 0 | Always picks highest probability (deterministic) | Factual Q&A, coding |
| 0.1-0.3 | Very focused, predictable | Technical writing |
| 0.7-1.0 | Balanced creativity | General conversation |
| 1.2-2.0 | Very creative, sometimes chaotic | Brainstorming, poetry |

---

## 2. Top-K Sampling

**What it does:** Only considers the **K most likely** tokens, ignoring everything else.

### Simple Analogy
Imagine ordering food:
- **Top-K = 3:** "I'll only consider the top 3 dishes on the menu"
- **Top-K = 10:** "I'll consider the top 10 dishes"
- **Top-K = 1:** "Just give me the most popular dish" (greedy)

### How It Works

```
    BEFORE Top-K                    AFTER Top-K = 3
    (all tokens)                    (only top 3 kept)
    
    ┌────────────────┐              ┌────────────────┐
    │ mat     50%    │  ─────────►  │ mat     55%    │  (renormalized)
    │ floor   25%    │  ─────────►  │ floor   28%    │  (renormalized)
    │ couch   15%    │  ─────────►  │ couch   17%    │  (renormalized)
    │ roof     5%    │  ────X────   │                │  (excluded)
    │ moon     3%    │  ────X────   │                │  (excluded)
    │ pizza    2%    │  ────X────   │                │  (excluded)
    └────────────────┘              └────────────────┘
    
    The remaining probabilities are rescaled to sum to 100%
```

### Top-K Values

| Value | Behavior |
|-------|----------|
| 1 | Greedy decoding (always picks the best) |
| 10-40 | Focused but allows some variety |
| 100+ | Very permissive |

### Problem with Top-K
Top-K is **rigid**—it always keeps exactly K tokens regardless of their probabilities.

```
    Scenario A: Clear winner          Scenario B: Uncertain
    
    │ cat    90%  │  ← Keep          │ cat    25%  │  ← Keep
    │ dog     5%  │  ← Keep          │ dog    24%  │  ← Keep
    │ bird    3%  │  ← Keep          │ bird   23%  │  ← Keep
    │ fish    2%  │  ← DROP          │ fish   20%  │  ← DROP (unfair!)
    
    In Scenario B, "fish" is almost as likely but gets excluded!
```

This is why **Top-P** was invented.

---

## 3. Top-P (Nucleus Sampling)

**What it does:** Keeps the **smallest set of tokens** whose cumulative probability exceeds P.

### Simple Analogy
Instead of "give me top 3 dishes," you say:
- "Give me dishes until I've covered 90% of what people order"
- If one dish is super popular (80%), you might only get 2 options
- If choices are spread out, you might get 10 options

### How It Works

```
    Top-P = 0.9 (keep tokens until cumulative prob ≥ 90%)
    
    Token      Probability    Cumulative    Included?
    ─────────────────────────────────────────────────
    mat           50%            50%           ✓
    floor         25%            75%           ✓
    couch         15%            90%           ✓  ← Hit 90% here!
    roof           5%            95%           ✗
    moon           3%            98%           ✗
    pizza          2%           100%           ✗
    
    Result: Only {mat, floor, couch} are considered
```

### Visual Comparison

```
    ┌───────────────────────────────────────────────────────────┐
    │                    Top-P = 0.9                            │
    │                                                           │
    │   ████████████████████████  mat (50%)      ─┐             │
    │   ████████████              floor (25%)     ├─ 90% ✓      │
    │   ██████                    couch (15%)    ─┘             │
    │   ██                        roof (5%)      ─ excluded     │
    │   █                         moon (3%)      ─ excluded     │
    │                                                           │
    └───────────────────────────────────────────────────────────┘
```

### Top-P Values

| Value | Behavior |
|-------|----------|
| 0.1 | Very restrictive (only most likely tokens) |
| 0.5 | Moderate restriction |
| 0.9 | Standard setting, good balance |
| 1.0 | No restriction (consider all tokens) |

---

## Comparing the Three

```
    ┌─────────────────────────────────────────────────────────────────┐
    │                    COMPARISON DIAGRAM                           │
    ├─────────────────────────────────────────────────────────────────┤
    │                                                                 │
    │  TEMPERATURE: Changes the SHAPE of probabilities               │
    │  ─────────────────────────────────────────────────              │
    │       Low temp              High temp                           │
    │         │                      │                                │
    │         ▼                      ▼                                │
    │       █████                 ██  ██                              │
    │       █████                ███ ████                             │
    │       █████ █             ████ ████ ███                         │
    │       Sharp peak          Flat distribution                     │
    │                                                                 │
    ├─────────────────────────────────────────────────────────────────┤
    │                                                                 │
    │  TOP-K: Cuts off after K tokens (fixed number)                 │
    │  ─────────────────────────────────────────────                  │
    │                                                                 │
    │       K=3: [mat, floor, couch] ✓  [roof, moon, pizza] ✗        │
    │                                                                 │
    │       Always exactly K tokens, regardless of probabilities      │
    │                                                                 │
    ├─────────────────────────────────────────────────────────────────┤
    │                                                                 │
    │  TOP-P: Cuts off when cumulative probability reaches P         │
    │  ─────────────────────────────────────────────────              │
    │                                                                 │
    │       P=0.9: Keep adding tokens until sum ≥ 90%                │
    │                                                                 │
    │       Number of tokens varies based on probability spread       │
    │                                                                 │
    └─────────────────────────────────────────────────────────────────┘
```

---

## How They Work Together

These parameters are typically applied in this order:

```
    ┌──────────────────────────────────────────────────────────────┐
    │                    SAMPLING PIPELINE                         │
    └──────────────────────────────────────────────────────────────┘
    
           Raw Logits
               │
               ▼
    ┌──────────────────┐
    │  1. TEMPERATURE  │  ← Adjust probability sharpness
    └────────┬─────────┘
             │
             ▼
    ┌──────────────────┐
    │    2. TOP-K      │  ← Keep only top K tokens
    └────────┬─────────┘
             │
             ▼
    ┌──────────────────┐
    │    3. TOP-P      │  ← Keep tokens until cumulative P
    └────────┬─────────┘
             │
             ▼
    ┌──────────────────┐
    │  4. SAMPLE       │  ← Randomly pick from remaining
    └────────┬─────────┘
             │
             ▼
        Selected Token
```

---

## Common Settings by Use Case

| Use Case | Temperature | Top-P | Top-K |
|----------|-------------|-------|-------|
| **Code generation** | 0 - 0.2 | 0.1 | 1-10 |
| **Factual Q&A** | 0 - 0.3 | 0.5 | 10-40 |
| **Conversation** | 0.7 - 1.0 | 0.9 | 40-100 |
| **Creative writing** | 1.0 - 1.5 | 0.95 | 100+ |
| **Brainstorming** | 1.2 - 2.0 | 1.0 | disabled |

---

## Quick Reference

| Parameter | Controls | Low Value | High Value |
|-----------|----------|-----------|------------|
| **Temperature** | Randomness/creativity | Deterministic, focused | Random, creative |
| **Top-K** | Number of candidates | Few choices | Many choices |
| **Top-P** | Probability mass | Restrictive | Permissive |

---

## Key Takeaways

1. **Temperature** = How confident/adventurous the model is
2. **Top-K** = "Only consider the top K options"
3. **Top-P** = "Consider options until I've covered P% of probability"
4. They can be combined for fine-grained control
5. Lower values = more predictable, higher values = more creative
