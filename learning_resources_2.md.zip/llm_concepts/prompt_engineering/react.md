# ReAct (Reasoning + Acting) Prompting

## What is it?

ReAct stands for **Re**asoning and **Act**ing. It's a technique where the AI doesn't just think - it also takes actions (like searching for information) and then thinks about what it found.

Imagine you're a detective solving a mystery:
1. You **think** about what you know
2. You **act** (search for clues, ask questions)
3. You **observe** what you found
4. You **think** again about the new information
5. Repeat until you solve the case!

That's exactly what ReAct does for AI!

## The ReAct Loop

```
┌─────────────┐
│   THOUGHT   │  ← "What do I need to find out?"
└──────┬──────┘
       │
       ▼
┌─────────────┐
│   ACTION    │  ← "Let me search/look this up"
└──────┬──────┘
       │
       ▼
┌─────────────┐
│ OBSERVATION │  ← "Here's what I found..."
└──────┬──────┘
       │
       ▼
┌─────────────┐
│   THOUGHT   │  ← "Based on this, I now know..."
└──────┬──────┘
       │
       ▼
    (Repeat or give final answer)
```

## Why is ReAct Special?

Regular prompting is like taking a test with a blindfold - you can only use what's in your head.

ReAct is like taking an open-book test - you can look things up!

| Regular Prompting | ReAct Prompting |
|-------------------|-----------------|
| Uses only existing knowledge | Can search for new info |
| One-shot thinking | Iterative thinking |
| May hallucinate facts | Verifies with real data |
| Static | Dynamic |

## Simple Example

### Question: "Who won the NBA championship in 2024 and what was the final score?"

### ReAct Process:

```
Thought 1: I need to find out who won the 2024 NBA championship. 
Let me search for this information.

Action 1: Search["2024 NBA championship winner"]

Observation 1: The Boston Celtics won the 2024 NBA Championship, 
defeating the Dallas Mavericks.

Thought 2: Good, I know the Celtics won against the Mavericks. 
Now I need the final score of the series.

Action 2: Search["2024 NBA Finals final score Celtics vs Mavericks"]

Observation 2: The Boston Celtics won the series 4-1. The final 
game score was 106-88.

Thought 3: I now have all the information needed to answer.

Final Answer: The Boston Celtics won the 2024 NBA Championship, 
defeating the Dallas Mavericks 4-1 in the series. The final game 
score was 106-88.
```

## How to Create ReAct Prompts

### Step 1: Define Available Actions

Tell the AI what tools it can use:

```
You have access to the following tools:
- Search[query]: Search the web for information
- Calculate[expression]: Do math calculations
- Lookup[term]: Look up a definition

Format your response as:
Thought: (your reasoning)
Action: (tool you want to use)
```

### Step 2: Show the Format with an Example

```
Question: What is the population of France divided by 2?

Thought: I need to find the population of France first.
Action: Search[population of France 2024]
Observation: France has a population of approximately 68 million.

Thought: Now I need to divide 68 million by 2.
Action: Calculate[68000000 / 2]
Observation: 34000000

Thought: I have my answer.
Final Answer: 34 million (34,000,000)
```

### Step 3: Ask Your Question

```
Now answer this question using the same format:
Question: [Your question here]
```

## Complete ReAct Prompt Template

```
You are a helpful assistant that thinks step by step and uses tools 
when needed.

Available Tools:
1. Search[query] - Search for current information online
2. Calculate[math] - Perform mathematical calculations  
3. Lookup[topic] - Get detailed information about a topic

Instructions:
- Always start with a Thought about what you need to do
- Use an Action when you need information you don't have
- After each Observation, have another Thought
- When you have enough information, give your Final Answer

Format:
Thought: [your reasoning]
Action: [tool name][input]
Observation: [result - this will be provided]
... (repeat as needed)
Final Answer: [your complete answer]

Question: [INSERT YOUR QUESTION HERE]
```

## Real-World Uses

### 1. Research Questions
```
Question: Compare the GDP of Japan and Germany. Which is higher and by how much?

Thought: I need to look up both countries' GDP...
Action: Search[Japan GDP 2024]
...
```

### 2. Fact-Checking
```
Question: Is it true that the Great Wall of China is visible from space?

Thought: This is a common claim. Let me verify it...
Action: Search[can you see Great Wall of China from space fact check]
...
```

### 3. Multi-Step Problems
```
Question: If I invest $1000 at the current S&P 500 average return 
for 10 years, how much will I have?

Thought: First, I need the average S&P 500 return...
Action: Search[S&P 500 average annual return]
...
```

## ReAct vs Chain of Thought

| Chain of Thought | ReAct |
|------------------|-------|
| Think → Answer | Think → Act → Observe → Think → Answer |
| Uses existing knowledge | Can get new information |
| Best for reasoning problems | Best for research/fact-based questions |
| Faster | More accurate for current info |

## Tips for Better ReAct Prompts

1. **Be clear about available tools** - List exactly what the AI can do
2. **Show an example** - Demonstrate the format you expect
3. **Keep actions simple** - One action at a time
4. **Allow iteration** - Let the AI do multiple thought-action cycles

## Summary

ReAct = **Thinking + Doing + Learning from what you find**

It's like giving the AI the ability to:
- Think about what it needs
- Go look it up
- Come back and think again
- Repeat until it has a good answer

Perfect for questions that need current, accurate, or verified information!
