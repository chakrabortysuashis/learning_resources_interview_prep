# Chain of Thought (CoT) Prompting

## What is it?

Chain of Thought is like showing your work in a math test. Instead of just giving the AI a question and expecting an answer, you ask it to **think step by step** before giving the final answer.

Think of it like this: When your teacher asks you to solve a word problem, they don't just want the answer - they want to see HOW you got there. Chain of Thought does the same thing for AI!

## Why Does It Work?

When you ask an AI to "think step by step," it:
1. Breaks down the problem into smaller pieces
2. Works through each piece one at a time
3. Makes fewer mistakes because it's checking its work along the way

It's like climbing a ladder - you go one step at a time instead of trying to jump to the top!

## Simple Example

### Without Chain of Thought (Bad)

**Prompt:**
```
If I have 23 apples and give away 7, then buy 15 more, and eat 3, how many do I have?
```

**AI might say:** "28 apples" (could be wrong, no explanation)

### With Chain of Thought (Good)

**Prompt:**
```
If I have 23 apples and give away 7, then buy 15 more, and eat 3, how many do I have?

Think step by step.
```

**AI says:**
```
Let me work through this step by step:

Step 1: Start with 23 apples
Step 2: Give away 7 → 23 - 7 = 16 apples
Step 3: Buy 15 more → 16 + 15 = 31 apples
Step 4: Eat 3 → 31 - 3 = 28 apples

Final answer: 28 apples
```

## How to Create Chain of Thought Prompts

### Method 1: Just Ask for Steps

Add one of these phrases to your prompt:
- "Think step by step"
- "Let's work through this together"
- "Show your reasoning"
- "Explain your thought process"

### Method 2: Give an Example First (Few-Shot CoT)

Show the AI HOW to think by giving an example:

```
Question: Sally has 5 candies. She gets 3 more from Tom. How many does she have?

Thinking:
- Sally starts with 5 candies
- Tom gives her 3 more
- 5 + 3 = 8
Answer: 8 candies

Question: John has 12 marbles. He loses 4 and finds 6. How many does he have?

Thinking:
```

The AI will follow your example pattern!

## Real-World Uses

### 1. Math Problems
```
A train travels 60 miles per hour for 2.5 hours, then 80 miles per hour for 1.5 hours. 
What's the total distance?

Think step by step.
```

### 2. Logic Puzzles
```
If all cats are animals, and Whiskers is a cat, what can we conclude about Whiskers?

Reason through this carefully.
```

### 3. Code Debugging
```
This code should print numbers 1-10 but it's not working:

for i in range(10):
    print(i)

Walk through what the code does step by step to find the bug.
```

### 4. Decision Making
```
I need to choose between Job A ($50k, close to home) and Job B ($70k, 1 hour commute).
Help me think through this decision step by step.
```

## Tips for Better Chain of Thought

1. **Be specific** - Tell the AI exactly what kind of steps you want
2. **Ask for verification** - Add "double-check your answer"
3. **Request structure** - Ask for numbered steps or bullet points
4. **Set the pace** - Say "take your time" for complex problems

## Common Mistakes to Avoid

- Don't use CoT for simple questions ("What's 2+2?")
- Don't forget to actually read the reasoning - that's where you catch errors!
- Don't make prompts too complicated - keep them clear

## Summary

Chain of Thought = Making the AI show its homework!

| Without CoT | With CoT |
|-------------|----------|
| Quick but risky | Slower but accurate |
| Black box | Transparent |
| Hard to verify | Easy to check |

Just add "Think step by step" and watch the magic happen!
