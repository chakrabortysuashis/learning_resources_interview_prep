# Prompt Engineering Techniques

Welcome! This folder contains simple explanations of advanced prompt engineering techniques. Each technique helps you get better responses from AI language models like ChatGPT, Claude, etc.

## What is Prompt Engineering?

Prompt engineering is the art of writing good instructions for AI. Just like how a good teacher gets better answers from students by asking better questions, you can get better AI responses by writing better prompts!

## Techniques Covered

| Technique | What It Does | Best For |
|-----------|--------------|----------|
| [Chain of Thought](chain_of_thought.md) | Makes AI show its reasoning step by step | Math, logic, reasoning problems |
| [ReAct](react.md) | Combines thinking with taking actions | Research, fact-checking, current info |
| [Tree of Thoughts](tree_of_thoughts.md) | Explores multiple solutions, picks the best | Creative tasks, complex decisions |
| [Prompt Chaining](prompt_chaining.md) | Breaks big tasks into connected smaller prompts | Multi-step projects, content creation |

## Quick Comparison

```
┌─────────────────────────────────────────────────────────────────┐
│                     WHEN TO USE WHAT?                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Simple question ────────────────────────▶ Just ask directly   │
│                                                                 │
│  Need reasoning ─────────────────────────▶ Chain of Thought    │
│                                                                 │
│  Need current facts ─────────────────────▶ ReAct               │
│                                                                 │
│  Multiple possible solutions ────────────▶ Tree of Thoughts    │
│                                                                 │
│  Big multi-step project ─────────────────▶ Prompt Chaining     │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

## The Simplest Summary

- **Chain of Thought**: "Think step by step"
- **ReAct**: "Think, then search, then think again"
- **Tree of Thoughts**: "Try multiple approaches, pick the best"
- **Prompt Chaining**: "Do step 1, use that result for step 2, etc."

## Learning Order

If you're new to this, I recommend reading in this order:
1. Chain of Thought (simplest, most commonly used)
2. Prompt Chaining (builds on understanding of steps)
3. Tree of Thoughts (explores multiple paths)
4. ReAct (combines thinking with tools)

Happy learning!
