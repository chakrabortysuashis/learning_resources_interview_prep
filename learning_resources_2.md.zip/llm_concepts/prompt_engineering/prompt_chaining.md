# Prompt Chaining

## What is it?

Prompt Chaining is like an assembly line in a factory. Instead of asking an AI to do everything at once, you break the task into smaller steps, where **the output of one prompt becomes the input for the next prompt**.

Think of making a sandwich:
1. First, get the bread ➡️ output: bread
2. Then, add ingredients to the bread ➡️ output: assembled sandwich
3. Finally, cut and serve ➡️ output: ready-to-eat sandwich

Each step uses what the previous step created!

## Visual Explanation

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│  Prompt 1   │────▶│  Prompt 2   │────▶│  Prompt 3   │
│             │     │             │     │             │
│  Input: X   │     │ Input: Y    │     │ Input: Z    │
│  Output: Y  │     │ Output: Z   │     │ Output: ✓   │
└─────────────┘     └─────────────┘     └─────────────┘

Output of Step 1 ──becomes──▶ Input of Step 2
Output of Step 2 ──becomes──▶ Input of Step 3
```

## Why Use Prompt Chaining?

Imagine asking someone to do ALL of this at once:
> "Write a blog post about climate change, make it SEO-friendly, translate it to Spanish, and create social media posts for it."

That's a LOT! Things could go wrong anywhere.

With chaining:
1. First prompt: Write the blog post
2. Second prompt: Optimize for SEO
3. Third prompt: Translate to Spanish
4. Fourth prompt: Create social media posts

Each step is focused, checked, and reliable!

## Simple Example: Writing an Email

### Without Chaining (Everything at Once)

```
Write a professional email to a client explaining that their project 
will be delayed by 2 weeks, include an apology, explain the reason 
(supply chain issues), offer a 10% discount, suggest new timeline, 
and make it friendly but professional.
```

This might work, but it's hard to control quality.

### With Prompt Chaining

**Prompt 1: Draft the core message**
```
Write a brief explanation for a client that their project is delayed 
by 2 weeks due to supply chain issues.
```
Output: "Due to unexpected supply chain disruptions affecting our 
component suppliers, your project delivery will be delayed by 
approximately two weeks..."

**Prompt 2: Add the apology and offer**
```
Take this message and add:
1. A sincere apology at the beginning
2. An offer of 10% discount for the inconvenience
3. The new expected delivery date (assume original was March 15)

Message: [paste output from Prompt 1]
```
Output: "We sincerely apologize for the inconvenience. Due to 
unexpected supply chain... As a gesture of goodwill, we're offering 
a 10% discount... New delivery date: March 29..."

**Prompt 3: Polish the tone**
```
Rewrite this email to be warm and professional. Add a friendly 
opening and closing.

Email: [paste output from Prompt 2]
```
Output: Final polished email!

## How to Create Prompt Chains

### Step 1: Break Down the Task

Ask yourself: "What are the distinct stages of this task?"

Example - Creating a presentation:
1. Research the topic
2. Create an outline
3. Write the content for each slide
4. Add speaker notes
5. Suggest visuals

### Step 2: Design Each Prompt

Each prompt should:
- Have ONE clear goal
- Take input from the previous step (if any)
- Produce output the next step can use

### Step 3: Include "Handoff" Instructions

Tell the AI what format you need for the next step:

```
...end your response with a bullet-point summary that I can use 
in the next step.
```

## Real-World Examples

### Example 1: Content Creation Pipeline

```
Chain:
1. Brainstorm → "Give me 5 blog topic ideas about healthy eating"
2. Select & Outline → "Create an outline for topic #3"
3. Draft → "Write the first draft based on this outline: [outline]"
4. Edit → "Improve this draft for clarity: [draft]"
5. SEO → "Add SEO keywords to this article: [edited draft]"
```

### Example 2: Code Development

```
Chain:
1. Requirements → "List what a todo app needs to do"
2. Design → "Create a class structure for: [requirements]"
3. Implement → "Write Python code for this design: [design]"
4. Test → "Write unit tests for this code: [code]"
5. Document → "Add docstrings to this code: [code]"
```

### Example 3: Data Analysis

```
Chain:
1. Understand → "What questions can we answer with this data? [describe data]"
2. Plan → "How should we analyze question #2? [question]"
3. Code → "Write Python code for this analysis: [plan]"
4. Interpret → "Explain these results in plain English: [results]"
5. Recommend → "What actions should we take based on: [interpretation]"
```

## Prompt Chain Template

```
=== CHAIN STEP [N] ===

Context: [Brief description of overall goal]

Previous Output: [Paste output from step N-1, or "N/A" for first step]

Task for This Step: [Clear, specific instruction]

Output Format: [How to structure the output for the next step]

---
[AI completes this step]
---

=== CHAIN STEP [N+1] ===
...
```

## Types of Chains

### 1. Linear Chain (A → B → C)
```
Step 1 → Step 2 → Step 3 → Done
```
Good for: Sequential tasks like writing → editing → formatting

### 2. Branching Chain
```
        ┌→ Step 2A ─┐
Step 1 ─┤           ├→ Step 3
        └→ Step 2B ─┘
```
Good for: Getting multiple perspectives, then combining

### 3. Loop Chain
```
Step 1 → Step 2 → Check → (if not good) → Back to Step 1
                       → (if good) → Done
```
Good for: Iterative improvement until quality threshold met

## Tips for Better Prompt Chains

1. **Keep each step focused** - One task per prompt
2. **Be explicit about format** - Tell AI how to structure output
3. **Check intermediate outputs** - Don't blindly pass bad output forward
4. **Add context** - Remind the AI what the overall goal is
5. **Use clear markers** - "Output from previous step:" helps clarity

## When to Use Prompt Chaining

✅ **Good for:**
- Complex multi-step tasks
- Tasks needing different "skills" (writing vs. analysis)
- When you want to verify each step
- Long-form content creation
- When one mega-prompt keeps failing

❌ **Not needed for:**
- Simple, single-step tasks
- Quick questions
- When speed is more important than quality

## Comparison with Other Techniques

| Technique | Structure | Use Case |
|-----------|-----------|----------|
| Chain of Thought | Single prompt, step-by-step thinking | Reasoning problems |
| Tree of Thoughts | Single prompt, multiple paths | Complex decisions |
| ReAct | Single prompt, think-act loop | Research tasks |
| Prompt Chaining | Multiple prompts, output→input | Multi-stage projects |

## Summary

Prompt Chaining = **Breaking big tasks into smaller, connected prompts**

Key ideas:
- 🔗 Output of prompt 1 → Input of prompt 2
- 🎯 Each prompt has ONE clear job
- ✓ Check quality at each step
- 🔄 Can branch or loop if needed

It's like building with LEGO - one brick at a time, each building on the last, until you have something amazing!

## Quick Reference

```python
# Pseudocode for prompt chaining

result_1 = ask_ai("Step 1: " + initial_input)
# Check result_1 is good

result_2 = ask_ai("Step 2: " + result_1)
# Check result_2 is good

result_3 = ask_ai("Step 3: " + result_2)
# Check result_3 is good

final_output = result_3
```
