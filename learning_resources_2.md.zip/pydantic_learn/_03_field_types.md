# Module 03: Field Types

---

## Table of Contents
- [Type System Overview](#type-system-overview)
- [Standard Python Types](#standard-python-types)
- [Collection Types](#collection-types)
- [Optional and Union Types](#optional-and-union-types)
- [Literal Types](#literal-types)
- [DateTime Types](#datetime-types)
- [UUID, Path, URL Types](#uuid-path-url-types)
- [Pydantic Special Types](#pydantic-special-types)
- [Any Type and Implications](#any-type-and-implications)
- [Type Coercion Behavior](#type-coercion-behavior)
- [Quick Reference](#quick-reference)

---

## Type System Overview

Pydantic leverages Python's type hints to provide runtime validation. Understanding the type hierarchy is essential for building robust models.

### Type Hierarchy Diagram

```
+------------------------------------------------------------------+
|                     PYDANTIC TYPE HIERARCHY                       |
+------------------------------------------------------------------+
|                                                                  |
|                        +----------------+                        |
|                        |   Any Type     |  <-- No validation     |
|                        +-------+--------+                        |
|                                |                                 |
|            +-------------------+-------------------+              |
|            |                   |                   |              |
|   +--------v--------+  +-------v-------+  +-------v-------+      |
|   | SCALAR TYPES    |  | COLLECTION    |  | SPECIAL       |      |
|   |                 |  | TYPES         |  | TYPES         |      |
|   +-----------------+  +---------------+  +---------------+      |
|   | - str           |  | - list        |  | - datetime    |      |
|   | - int           |  | - dict        |  | - date        |      |
|   | - float         |  | - set         |  | - time        |      |
|   | - bool          |  | - tuple       |  | - timedelta   |      |
|   | - bytes         |  | - frozenset   |  | - UUID        |      |
|   +-----------------+  +---------------+  | - Path        |      |
|                                          | - HttpUrl     |      |
|                                          | - EmailStr    |      |
|                                          | - SecretStr   |      |
|                                          +---------------+      |
|                                                                  |
|   +-------------------------------------------------------------+
|   |                   COMPOSITE TYPES                            |
|   +-------------------------------------------------------------+
|   |  Optional[T]  |  Union[T1, T2]  |  Literal["a", "b"]        |
|   |  T | None     |  T1 | T2        |  Annotated[T, ...]        |
|   +-------------------------------------------------------------+
|                                                                  |
+------------------------------------------------------------------+
```

### Import Overview

```python
# Standard library imports
from typing import (
    Optional, Union, Literal, Any,
    List, Dict, Set, Tuple, FrozenSet,
    Annotated
)
from datetime import datetime, date, time, timedelta
from uuid import UUID
from pathlib import Path

# Pydantic imports
from pydantic import (
    BaseModel, Field,
    HttpUrl, AnyUrl,
    EmailStr, SecretStr,
    FilePath, DirectoryPath, NewPath,
    PositiveInt, NegativeInt,
    PositiveFloat, NegativeFloat,
    constr, conint, confloat
)
```

---

## Standard Python Types

The fundamental building blocks for all Pydantic models.

### Type Overview Table

```
+----------+------------------+-------------------------+------------------------+
|   Type   |    Python Type   |    Example Values       |    Coerces From        |
+----------+------------------+-------------------------+------------------------+
|   str    |    <class 'str'> |    "hello", ""          |    int, float, bytes   |
|   int    |    <class 'int'> |    42, -1, 0            |    str("42"), float    |
|   float  |  <class 'float'> |    3.14, -0.5           |    int, str("3.14")    |
|   bool   |   <class 'bool'> |    True, False          |    int(0,1), str       |
|   bytes  |  <class 'bytes'> |    b"data"              |    str (encoded)       |
+----------+------------------+-------------------------+------------------------+
```

### str (String)

```python
from pydantic import BaseModel

class StringExample(BaseModel):
    name: str
    description: str = ""  # Default empty string

# Valid inputs
model = StringExample(name="Alice")
model = StringExample(name="Alice", description="A user")

# Coercion: numbers become strings in strict=False mode
model = StringExample(name=123)  # name becomes "123"
```

### int (Integer)

```python
class IntegerExample(BaseModel):
    count: int
    quantity: int = 0

# Valid inputs
model = IntegerExample(count=42)
model = IntegerExample(count="42")     # String coerced to int
model = IntegerExample(count=42.0)     # Float 42.0 coerced to int 42

# Invalid - will raise ValidationError
# model = IntegerExample(count="not a number")
# model = IntegerExample(count=42.5)   # Non-integer float fails
```

### float (Floating Point)

```python
class FloatExample(BaseModel):
    price: float
    discount: float = 0.0

# Valid inputs
model = FloatExample(price=19.99)
model = FloatExample(price="19.99")    # String coerced to float
model = FloatExample(price=20)         # Integer coerced to float

# Special float values
model = FloatExample(price=float('inf'))   # Infinity
model = FloatExample(price=float('-inf'))  # Negative infinity
# model = FloatExample(price=float('nan'))   # NaN (may cause issues)
```

### bool (Boolean)

```python
class BoolExample(BaseModel):
    is_active: bool
    is_verified: bool = False

# Valid inputs
model = BoolExample(is_active=True)
model = BoolExample(is_active=False)

# Coercion from various types
model = BoolExample(is_active=1)       # True
model = BoolExample(is_active=0)       # False
model = BoolExample(is_active="true")  # True
model = BoolExample(is_active="false") # False
model = BoolExample(is_active="yes")   # True
model = BoolExample(is_active="no")    # False
model = BoolExample(is_active="1")     # True
model = BoolExample(is_active="0")     # False
```

### Bool Coercion Visual

```
+------------------+-------------------+
|   Input Value    |   Coerced To      |
+------------------+-------------------+
|   True           |   True            |
|   False          |   False           |
|   1              |   True            |
|   0              |   False           |
|   "true"         |   True            |
|   "false"        |   False           |
|   "yes"          |   True            |
|   "no"           |   False           |
|   "on"           |   True            |
|   "off"          |   False           |
|   "1"            |   True            |
|   "0"            |   False           |
|   ""             |   ERROR           |
|   "random"       |   ERROR           |
+------------------+-------------------+
```

### bytes (Binary Data)

```python
class BytesExample(BaseModel):
    data: bytes
    signature: bytes = b""

# Valid inputs
model = BytesExample(data=b"binary data")
model = BytesExample(data="text data")  # String encoded to bytes (UTF-8)

# Access the data
print(model.data)  # b'text data'
```

---

## Collection Types

Pydantic supports all standard Python collection types with full type parameter validation.

### Collection Overview

```
+---------------+-------------------------+----------------------------------+
|     Type      |        Syntax           |          Description             |
+---------------+-------------------------+----------------------------------+
|     list      |    list[T]              |  Ordered, mutable sequence       |
|     dict      |    dict[K, V]           |  Key-value mapping               |
|     set       |    set[T]               |  Unordered unique elements       |
|     tuple     |    tuple[T1, T2, ...]   |  Fixed-length immutable sequence |
|   frozenset   |    frozenset[T]         |  Immutable set                   |
+---------------+-------------------------+----------------------------------+
```

### list (Lists)

```python
from pydantic import BaseModel

class ListExample(BaseModel):
    tags: list[str]                    # List of strings
    scores: list[int]                  # List of integers
    items: list[float] = []            # Default empty list
    nested: list[list[int]] = []       # Nested lists

# Valid inputs
model = ListExample(
    tags=["python", "pydantic"],
    scores=[95, 87, 92]
)

# Coercion: tuple becomes list, elements are validated
model = ListExample(
    tags=("tag1", "tag2"),  # Tuple coerced to list
    scores=["95", "87"]     # Strings coerced to ints
)
```

### dict (Dictionaries)

```python
class DictExample(BaseModel):
    metadata: dict[str, str]              # String keys and values
    scores: dict[str, int]                # String keys, int values
    config: dict[str, Any] = {}           # Any value type
    nested: dict[str, dict[str, int]] = {}  # Nested dicts

# Valid inputs
model = DictExample(
    metadata={"author": "Alice", "version": "1.0"},
    scores={"math": 95, "science": 87}
)

# Coercion happens for values
model = DictExample(
    metadata={"key": 123},     # 123 coerced to "123"
    scores={"test": "100"}     # "100" coerced to 100
)
```

### set (Sets)

```python
class SetExample(BaseModel):
    unique_ids: set[int]
    permissions: set[str] = set()

# Valid inputs
model = SetExample(unique_ids={1, 2, 3})
model = SetExample(unique_ids=[1, 2, 2, 3])  # List coerced, duplicates removed

print(model.unique_ids)  # {1, 2, 3}
```

### tuple (Tuples)

Tuples have two modes: fixed-length with specific types, or variable-length homogeneous.

```python
class TupleExample(BaseModel):
    # Fixed-length tuple with specific types per position
    coordinates: tuple[float, float]           # (x, y)
    rgb: tuple[int, int, int]                  # (r, g, b)
    
    # Variable-length homogeneous tuple
    values: tuple[int, ...]                    # Any number of ints
    
    # Optional with default
    point: tuple[float, float] = (0.0, 0.0)

# Valid inputs
model = TupleExample(
    coordinates=(10.5, 20.3),
    rgb=(255, 128, 0),
    values=(1, 2, 3, 4, 5)
)

# Length validation for fixed tuples
# This will FAIL - wrong number of elements:
# model = TupleExample(coordinates=(1.0, 2.0, 3.0), rgb=(255, 0, 0), values=())
```

### Tuple Types Visual

```
+---------------------------+------------------------+-------------------------+
|         Type              |     Example Input      |      Valid Lengths      |
+---------------------------+------------------------+-------------------------+
| tuple[int, str]           | (1, "hello")           |  Exactly 2              |
| tuple[int, str, float]    | (1, "hi", 3.14)        |  Exactly 3              |
| tuple[int, ...]           | (1, 2, 3, 4, 5)        |  Any (0 or more)        |
| tuple[()]                 | ()                     |  Exactly 0 (empty)      |
+---------------------------+------------------------+-------------------------+
```

### frozenset (Immutable Sets)

```python
class FrozenSetExample(BaseModel):
    immutable_tags: frozenset[str]

model = FrozenSetExample(immutable_tags=["a", "b", "c"])
print(type(model.immutable_tags))  # <class 'frozenset'>

# Cannot modify after creation
# model.immutable_tags.add("d")  # AttributeError: 'frozenset' has no 'add'
```

---

## Optional and Union Types

Handle fields that may have multiple types or may be absent.

### Optional vs Required Visual

```
+------------------------------------------------------------------+
|                    OPTIONAL vs REQUIRED                           |
+------------------------------------------------------------------+
|                                                                  |
|  REQUIRED FIELD                    OPTIONAL FIELD                |
|  +--------------+                  +--------------+              |
|  |  name: str   |                  | name: str |  |              |
|  |              |                  |      None    |              |
|  |  Must have   |                  | Can be None  |              |
|  |  a value     |                  | or string    |              |
|  +--------------+                  +--------------+              |
|                                                                  |
|  REQUIRED WITH DEFAULT             OPTIONAL WITH DEFAULT         |
|  +--------------+                  +--------------+              |
|  | age: int = 0 |                  | age: int |   |              |
|  |              |                  |     None = 0 |              |
|  |  Has default |                  | Default is 0 |              |
|  |  if not given|                  | can be None  |              |
|  +--------------+                  +--------------+              |
|                                                                  |
+------------------------------------------------------------------+
```

### Optional Types

```python
from typing import Optional
from pydantic import BaseModel

class OptionalExample(BaseModel):
    # Three ways to declare optional (all equivalent in Python 3.10+)
    
    # Method 1: Optional[T]
    nickname: Optional[str] = None
    
    # Method 2: T | None (Python 3.10+ preferred)
    middle_name: str | None = None
    
    # Method 3: Union[T, None]
    suffix: Union[str, None] = None
    
    # Required field for comparison
    first_name: str

# Valid inputs
model = OptionalExample(first_name="John")  # optionals default to None
model = OptionalExample(first_name="John", nickname="Johnny")
model = OptionalExample(first_name="John", nickname=None)  # Explicit None
```

### Union Types

```python
from typing import Union
from pydantic import BaseModel

class UnionExample(BaseModel):
    # Can be either int or str
    identifier: Union[int, str]
    
    # Python 3.10+ syntax
    value: int | str | float
    
    # More complex union
    result: Union[dict[str, int], list[int], None] = None

# Valid inputs - Pydantic tries types in order
model = UnionExample(identifier=123, value=42)
model = UnionExample(identifier="ABC-123", value="hello")
model = UnionExample(identifier=123, value=3.14)
```

### Union Resolution Order

```
+------------------------------------------------------------------+
|                    UNION TYPE RESOLUTION                          |
+------------------------------------------------------------------+
|                                                                  |
|  field: int | str | float                                        |
|                                                                  |
|  Input: "42"                                                     |
|                                                                  |
|  Step 1: Try int     -> "42" can be coerced to 42   -> SUCCESS   |
|  Result: 42 (int)                                                |
|                                                                  |
|  ---                                                             |
|                                                                  |
|  Input: "hello"                                                  |
|                                                                  |
|  Step 1: Try int     -> "hello" cannot be int       -> FAIL      |
|  Step 2: Try str     -> "hello" is a string         -> SUCCESS   |
|  Result: "hello" (str)                                           |
|                                                                  |
|  ---                                                             |
|                                                                  |
|  Input: 3.14                                                     |
|                                                                  |
|  Step 1: Try int     -> 3.14 is not an integer      -> FAIL      |
|  Step 2: Try str     -> Coercion depends on mode    -> VARIES    |
|  Step 3: Try float   -> 3.14 is a float             -> SUCCESS   |
|  Result: 3.14 (float)                                            |
|                                                                  |
+------------------------------------------------------------------+
```

### Discriminated Unions (Tagged Unions)

For complex unions, use discriminators for better performance and clarity.

```python
from typing import Literal, Union
from pydantic import BaseModel, Field

class Cat(BaseModel):
    pet_type: Literal["cat"]
    meows: int

class Dog(BaseModel):
    pet_type: Literal["dog"]
    barks: float

class Pet(BaseModel):
    # Discriminated union - uses 'pet_type' to determine which model
    pet: Union[Cat, Dog] = Field(discriminator='pet_type')

# Pydantic knows immediately which type to use
pet = Pet(pet={"pet_type": "cat", "meows": 5})
print(type(pet.pet))  # <class 'Cat'>

pet = Pet(pet={"pet_type": "dog", "barks": 3.5})
print(type(pet.pet))  # <class 'Dog'>
```

---

## Literal Types

Restrict values to specific literals for enum-like behavior.

### Literal Overview

```
+------------------------------------------------------------------+
|                      LITERAL TYPES                                |
+------------------------------------------------------------------+
|                                                                  |
|   Literal["value1", "value2"]   ->   Only these exact values     |
|                                                                  |
|   +-------------------+                                          |
|   |   status: Literal |                                          |
|   |   ["pending",     | <-- Only "pending", "approved",          |
|   |    "approved",    |     or "rejected" allowed                |
|   |    "rejected"]    |                                          |
|   +-------------------+                                          |
|                                                                  |
+------------------------------------------------------------------+
```

### Literal Examples

```python
from typing import Literal
from pydantic import BaseModel

class OrderStatus(BaseModel):
    # String literals
    status: Literal["pending", "processing", "shipped", "delivered"]
    
    # Integer literals
    priority: Literal[1, 2, 3]
    
    # Boolean literal (rare but valid)
    is_express: Literal[True, False] = False
    
    # Mixed types (not recommended but possible)
    code: Literal["A", "B", 1, 2]

# Valid
order = OrderStatus(status="pending", priority=1)
order = OrderStatus(status="shipped", priority=3)

# Invalid - will raise ValidationError
# order = OrderStatus(status="cancelled", priority=1)  # "cancelled" not in literals
# order = OrderStatus(status="pending", priority=5)    # 5 not in literals
```

### Literal vs Enum

```
+------------------------------------------------------------------+
|                 LITERAL vs ENUM COMPARISON                        |
+------------------------------------------------------------------+
|                                                                  |
|  LITERAL                           ENUM                          |
|  -------                           ----                          |
|  Literal["a", "b", "c"]            class MyEnum(str, Enum):      |
|                                        A = "a"                   |
|                                        B = "b"                   |
|                                        C = "c"                   |
|                                                                  |
|  PROS:                             PROS:                         |
|  - Simpler syntax                  - Reusable                    |
|  - No extra class                  - Methods and properties      |
|  - Good for small sets             - IDE support for members     |
|                                                                  |
|  CONS:                             CONS:                         |
|  - Repeated if used multiple       - More verbose                |
|    places                          - Requires import             |
|  - No additional methods                                         |
|                                                                  |
+------------------------------------------------------------------+
```

---

## DateTime Types

Pydantic provides excellent support for date and time handling.

### DateTime Types Overview

```
+------------------------------------------------------------------+
|                     DATETIME TYPES                                |
+------------------------------------------------------------------+
|                                                                  |
|  +------------+     +------------+     +------------+            |
|  |  datetime  |     |    date    |     |    time    |            |
|  +------------+     +------------+     +------------+            |
|  | Date + Time|     | Date only  |     | Time only  |            |
|  | 2024-01-15 |     | 2024-01-15 |     | 14:30:00   |            |
|  | 14:30:00   |     |            |     |            |            |
|  +------------+     +------------+     +------------+            |
|                                                                  |
|  +------------------+                                            |
|  |    timedelta     |                                            |
|  +------------------+                                            |
|  | Duration/Period  |                                            |
|  | 5 days, 3 hours  |                                            |
|  +------------------+                                            |
|                                                                  |
+------------------------------------------------------------------+
```

### datetime Examples

```python
from datetime import datetime, date, time, timedelta
from pydantic import BaseModel

class DateTimeExample(BaseModel):
    # Full datetime
    created_at: datetime
    updated_at: datetime | None = None
    
    # Date only
    birth_date: date
    
    # Time only  
    start_time: time
    
    # Duration
    duration: timedelta

# Create from various formats
model = DateTimeExample(
    created_at="2024-01-15T14:30:00",      # ISO format string
    birth_date="2000-05-20",               # Date string
    start_time="09:30:00",                 # Time string
    duration="P1DT2H30M"                   # ISO 8601 duration
)

# Also accepts Python objects directly
from datetime import datetime, date, time, timedelta

model = DateTimeExample(
    created_at=datetime(2024, 1, 15, 14, 30),
    birth_date=date(2000, 5, 20),
    start_time=time(9, 30),
    duration=timedelta(days=1, hours=2, minutes=30)
)
```

### DateTime String Formats Accepted

```
+------------------------------------------------------------------+
|                  ACCEPTED DATETIME FORMATS                        |
+------------------------------------------------------------------+
|                                                                  |
|  DATETIME (datetime)                                             |
|  -------------------                                             |
|  "2024-01-15T14:30:00"           ISO 8601                        |
|  "2024-01-15T14:30:00Z"          UTC timezone                    |
|  "2024-01-15T14:30:00+05:30"     With timezone offset            |
|  "2024-01-15 14:30:00"           Space separator                 |
|  1705329000                       Unix timestamp (seconds)       |
|  1705329000000                    Unix timestamp (milliseconds)  |
|                                                                  |
|  DATE (date)                                                     |
|  -----------                                                     |
|  "2024-01-15"                    ISO format                      |
|  "2024/01/15"                    Slash separator                 |
|                                                                  |
|  TIME (time)                                                     |
|  -----------                                                     |
|  "14:30:00"                      With seconds                    |
|  "14:30"                         Without seconds                 |
|  "14:30:00.123456"               With microseconds               |
|                                                                  |
|  TIMEDELTA (timedelta)                                           |
|  ---------------------                                           |
|  "P1D"                           1 day (ISO 8601)                |
|  "P1DT2H30M"                     1 day, 2 hours, 30 minutes      |
|  "PT1H30M"                       1 hour, 30 minutes              |
|  86400                           Seconds (number)                |
|  86400.5                         Seconds with fraction           |
|                                                                  |
+------------------------------------------------------------------+
```

### Timezone-Aware Datetimes

```python
from datetime import datetime, timezone
from pydantic import BaseModel, AwareDatetime, NaiveDatetime

class TimezoneExample(BaseModel):
    # Requires timezone information
    aware_dt: AwareDatetime
    
    # Must NOT have timezone (naive)
    naive_dt: NaiveDatetime
    
    # Regular datetime accepts both
    any_dt: datetime

# Valid
model = TimezoneExample(
    aware_dt="2024-01-15T14:30:00+05:30",  # Has timezone
    naive_dt="2024-01-15T14:30:00",        # No timezone
    any_dt="2024-01-15T14:30:00Z"          # Either works
)
```

---

## UUID, Path, URL Types

Special types for common data formats.

### UUID (Universally Unique Identifier)

```python
from uuid import UUID
from pydantic import BaseModel

class UUIDExample(BaseModel):
    id: UUID
    session_id: UUID | None = None

# Valid inputs
model = UUIDExample(id="550e8400-e29b-41d4-a716-446655440000")
model = UUIDExample(id=UUID("550e8400-e29b-41d4-a716-446655440000"))

# The value is always a UUID object
print(type(model.id))  # <class 'uuid.UUID'>
print(model.id.hex)    # 550e8400e29b41d4a716446655440000

# Invalid - will raise ValidationError
# model = UUIDExample(id="not-a-uuid")
```

### Path Types

```python
from pathlib import Path
from pydantic import BaseModel, FilePath, DirectoryPath, NewPath

class PathExample(BaseModel):
    # Any path (file or directory, exists or not)
    path: Path
    
    # Must be an existing file
    config_file: FilePath
    
    # Must be an existing directory
    output_dir: DirectoryPath
    
    # Must NOT exist (for creating new files)
    new_file: NewPath

# Valid (assuming paths exist)
model = PathExample(
    path="/any/path/here",
    config_file="/etc/config.yaml",     # Must exist as file
    output_dir="/tmp/output",           # Must exist as directory
    new_file="/tmp/new_file.txt"        # Must NOT exist
)

# Path is always converted to pathlib.Path
print(type(model.path))  # <class 'pathlib.PosixPath'> or WindowsPath
```

### Path Types Visual

```
+------------------------------------------------------------------+
|                       PATH TYPES                                  |
+------------------------------------------------------------------+
|                                                                  |
|  Path                FilePath             DirectoryPath          |
|  ----                --------             -------------          |
|  Any path            Must exist           Must exist             |
|  No validation       Must be file         Must be directory      |
|                                                                  |
|  /any/path    -->    /etc/hosts    -->    /tmp/                  |
|  (OK)                (OK if file)         (OK if dir)            |
|                                                                  |
|  NewPath                                                         |
|  -------                                                         |
|  Must NOT exist (for creating new files/dirs)                    |
|                                                                  |
+------------------------------------------------------------------+
```

### URL Types

```python
from pydantic import BaseModel, HttpUrl, AnyUrl, AnyHttpUrl

class URLExample(BaseModel):
    # HTTP or HTTPS URL
    website: HttpUrl
    
    # Any valid URL (http, https, ftp, etc.)
    resource: AnyUrl
    
    # HTTP URL allowing any HTTP scheme
    endpoint: AnyHttpUrl

# Valid inputs
model = URLExample(
    website="https://example.com/page",
    resource="ftp://files.example.com/data.zip",
    endpoint="http://api.example.com/v1"
)

# URL objects provide useful attributes
print(model.website.scheme)  # https
print(model.website.host)    # example.com
print(model.website.path)    # /page

# Invalid - will raise ValidationError
# model = URLExample(website="not-a-url", resource="", endpoint="")
# model = URLExample(website="ftp://...", ...)  # HttpUrl requires http(s)
```

---

## Pydantic Special Types

Types unique to Pydantic for common validation scenarios.

### Special Types Overview

```
+------------------------------------------------------------------+
|                   PYDANTIC SPECIAL TYPES                          |
+------------------------------------------------------------------+
|                                                                  |
|  EmailStr         Validated email address format                 |
|  SecretStr        String that hides value in repr/logs           |
|  SecretBytes      Bytes that hides value in repr/logs            |
|  PaymentCardNumber Credit card number validation                 |
|  PositiveInt      int > 0                                        |
|  NegativeInt      int < 0                                        |
|  PositiveFloat    float > 0                                      |
|  NegativeFloat    float < 0                                      |
|  NonNegativeInt   int >= 0                                       |
|  NonPositiveInt   int <= 0                                       |
|  StrictStr        str (no coercion)                              |
|  StrictInt        int (no coercion)                              |
|  StrictFloat      float (no coercion from int)                   |
|  StrictBool       bool (no coercion)                             |
|                                                                  |
+------------------------------------------------------------------+
```

### EmailStr

Requires: `pip install pydantic[email]` or `pip install email-validator`

```python
from pydantic import BaseModel, EmailStr

class ContactForm(BaseModel):
    email: EmailStr
    backup_email: EmailStr | None = None

# Valid
contact = ContactForm(email="user@example.com")
contact = ContactForm(email="user.name+tag@subdomain.example.co.uk")

# Invalid - will raise ValidationError
# contact = ContactForm(email="not-an-email")
# contact = ContactForm(email="missing@domain")
# contact = ContactForm(email="@nodomain.com")
```

### SecretStr and SecretBytes

```python
from pydantic import BaseModel, SecretStr, SecretBytes

class Credentials(BaseModel):
    username: str
    password: SecretStr
    api_key: SecretStr
    token: SecretBytes | None = None

creds = Credentials(
    username="admin",
    password="super_secret_123",
    api_key="sk-abc123xyz"
)

# The secret is hidden in string representation
print(creds)
# username='admin' password=SecretStr('**********') api_key=SecretStr('**********')

# To access the actual value, use get_secret_value()
print(creds.password.get_secret_value())  # super_secret_123

# Useful for logging - secrets won't be exposed
import logging
logging.info(f"User credentials: {creds}")  # Password is hidden!
```

### SecretStr Visual

```
+------------------------------------------------------------------+
|                    SecretStr BEHAVIOR                             |
+------------------------------------------------------------------+
|                                                                  |
|  INPUT: "my_password_123"                                        |
|                                                                  |
|  +-----------------------+     +---------------------------+     |
|  |  str(creds.password)  | --> |  "**********"             |     |
|  +-----------------------+     +---------------------------+     |
|                                                                  |
|  +-----------------------+     +---------------------------+     |
|  |  repr(creds.password) | --> |  "SecretStr('**********')" |     |
|  +-----------------------+     +---------------------------+     |
|                                                                  |
|  +-----------------------+     +---------------------------+     |
|  |  password.            | --> |  "my_password_123"        |     |
|  |  get_secret_value()   |     |  (actual value)           |     |
|  +-----------------------+     +---------------------------+     |
|                                                                  |
|  +-----------------------+     +---------------------------+     |
|  |  model_dump()         | --> |  {"password": SecretStr}  |     |
|  +-----------------------+     +---------------------------+     |
|                                                                  |
|  +-----------------------+     +---------------------------+     |
|  |  model_dump_json()    | --> |  {"password": "**********"}|    |
|  +-----------------------+     +---------------------------+     |
|                                                                  |
+------------------------------------------------------------------+
```

### Constrained Types

```python
from pydantic import BaseModel, constr, conint, confloat, conlist

class ConstrainedExample(BaseModel):
    # Constrained string
    username: constr(min_length=3, max_length=20, pattern=r'^[a-z]+$')
    
    # Constrained integer
    age: conint(ge=0, le=150)
    
    # Constrained float
    score: confloat(ge=0.0, le=100.0)
    
    # Constrained list
    tags: conlist(str, min_length=1, max_length=5)

# Valid
model = ConstrainedExample(
    username="johndoe",
    age=25,
    score=87.5,
    tags=["python", "pydantic"]
)

# Invalid examples:
# username="AB"         # Too short, uppercase
# age=200              # Too high
# score=150.0          # Above max
# tags=[]              # Empty list not allowed
```

### Positive/Negative Number Types

```python
from pydantic import BaseModel, PositiveInt, NegativeInt, PositiveFloat, NegativeFloat
from pydantic import NonNegativeInt, NonPositiveInt, NonNegativeFloat, NonPositiveFloat

class NumberConstraints(BaseModel):
    # Must be > 0
    quantity: PositiveInt      # 1, 2, 3, ... (not 0)
    price: PositiveFloat       # 0.01, 1.5, ... (not 0.0)
    
    # Must be < 0
    debt: NegativeInt          # -1, -2, ...
    loss: NegativeFloat        # -0.01, -1.5, ...
    
    # Must be >= 0
    count: NonNegativeInt      # 0, 1, 2, ...
    balance: NonNegativeFloat  # 0.0, 0.01, ...
    
    # Must be <= 0
    offset: NonPositiveInt     # 0, -1, -2, ...
    delta: NonPositiveFloat    # 0.0, -0.01, ...
```

---

## Any Type and Implications

The `Any` type bypasses Pydantic's validation.

### Any Type Overview

```
+------------------------------------------------------------------+
|                       Any TYPE                                    |
+------------------------------------------------------------------+
|                                                                  |
|  field: Any                                                      |
|                                                                  |
|  +------------------+                                            |
|  |   NO VALIDATION  |                                            |
|  |   NO COERCION    |                                            |
|  |   ACCEPTS ALL    |                                            |
|  +------------------+                                            |
|                                                                  |
|  Input          Output                                           |
|  -----          ------                                           |
|  "string"   --> "string"   (str)                                 |
|  123        --> 123        (int)                                 |
|  [1,2,3]    --> [1,2,3]    (list)                                |
|  {"a": 1}   --> {"a": 1}   (dict)                                |
|  None       --> None       (NoneType)                            |
|  <object>   --> <object>   (anything)                            |
|                                                                  |
+------------------------------------------------------------------+
```

### Any Examples

```python
from typing import Any
from pydantic import BaseModel

class FlexibleModel(BaseModel):
    strict_field: int           # Validated
    flexible_field: Any         # Not validated
    metadata: dict[str, Any]    # Dict with any values

# All inputs accepted for Any field
model = FlexibleModel(
    strict_field=42,
    flexible_field="could be anything",
    metadata={"count": 1, "items": ["a", "b"], "nested": {"x": 1}}
)

model = FlexibleModel(
    strict_field=42,
    flexible_field={"complex": [1, 2, {"nested": True}]},
    metadata={}
)
```

### When to Use Any

```
+------------------------------------------------------------------+
|                   WHEN TO USE Any                                 |
+------------------------------------------------------------------+
|                                                                  |
|  USE Any WHEN:                                                   |
|  -------------                                                   |
|  - Storing arbitrary JSON data                                   |
|  - Plugin/extension data with unknown structure                  |
|  - Legacy code migration                                         |
|  - Metadata fields with varying schemas                          |
|                                                                  |
|  AVOID Any WHEN:                                                 |
|  ---------------                                                 |
|  - You know the possible types (use Union instead)               |
|  - Data integrity is critical                                    |
|  - You want type safety benefits                                 |
|  - API contracts need to be enforced                             |
|                                                                  |
|  ALTERNATIVES:                                                   |
|  -------------                                                   |
|  - Union[type1, type2, ...]  for known alternatives              |
|  - dict[str, SomeType]       for typed dictionaries              |
|  - Nested BaseModel          for structured data                 |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Type Coercion Behavior

Pydantic automatically converts compatible types. Understanding coercion is crucial.

### Coercion Table

```
+------------------------------------------------------------------+
|                    TYPE COERCION TABLE                            |
+------------------------------------------------------------------+
|                                                                  |
|  TARGET TYPE  |  INPUT TYPE      |  RESULT              |  OK?   |
|  -------------|------------------|----------------------|--------|
|  str          |  "hello"         |  "hello"             |  Yes   |
|  str          |  123             |  "123"               |  Yes*  |
|  str          |  12.5            |  "12.5"              |  Yes*  |
|  str          |  True            |  "True"              |  Yes*  |
|  str          |  b"bytes"        |  "bytes"             |  Yes   |
|  -------------|------------------|----------------------|--------|
|  int          |  42              |  42                  |  Yes   |
|  int          |  "42"            |  42                  |  Yes   |
|  int          |  42.0            |  42                  |  Yes   |
|  int          |  42.5            |  ERROR               |  No    |
|  int          |  "42.5"          |  ERROR               |  No    |
|  int          |  True            |  1                   |  Yes   |
|  int          |  False           |  0                   |  Yes   |
|  -------------|------------------|----------------------|--------|
|  float        |  3.14            |  3.14                |  Yes   |
|  float        |  "3.14"          |  3.14                |  Yes   |
|  float        |  42              |  42.0                |  Yes   |
|  float        |  "inf"           |  inf                 |  Yes   |
|  -------------|------------------|----------------------|--------|
|  bool         |  True/False      |  True/False          |  Yes   |
|  bool         |  1/0             |  True/False          |  Yes   |
|  bool         |  "true"/"false"  |  True/False          |  Yes   |
|  bool         |  "yes"/"no"      |  True/False          |  Yes   |
|  bool         |  "1"/"0"         |  True/False          |  Yes   |
|  bool         |  ""              |  ERROR               |  No    |
|  bool         |  "random"        |  ERROR               |  No    |
|  -------------|------------------|----------------------|--------|
|  list[T]      |  [...]           |  list[T]             |  Yes   |
|  list[T]      |  (...)           |  list[T]             |  Yes   |
|  list[T]      |  {...}           |  list[T] (keys)      |  Yes   |
|  list[T]      |  "string"        |  ERROR               |  No    |
|  -------------|------------------|----------------------|--------|
|  datetime     |  datetime obj    |  datetime            |  Yes   |
|  datetime     |  "ISO string"    |  datetime            |  Yes   |
|  datetime     |  timestamp int   |  datetime            |  Yes   |
|  datetime     |  "random"        |  ERROR               |  No    |
|                                                                  |
|  * str coercion from non-string types depends on strict mode     |
|                                                                  |
+------------------------------------------------------------------+
```

### Strict Mode vs Lax Mode

```
+------------------------------------------------------------------+
|                 STRICT vs LAX MODE                                |
+------------------------------------------------------------------+
|                                                                  |
|  LAX MODE (default)               STRICT MODE                    |
|  -----------------                -----------                    |
|  Coerces compatible types         No automatic coercion          |
|                                                                  |
|  int field:                       int field:                     |
|    "42" -> 42  (OK)                 "42" -> ERROR                 |
|    42.0 -> 42  (OK)                 42.0 -> ERROR                 |
|                                                                  |
|  str field:                       str field:                     |
|    123 -> "123"  (OK)               123 -> ERROR                  |
|                                                                  |
+------------------------------------------------------------------+
```

### Enabling Strict Mode

```python
from pydantic import BaseModel, ConfigDict

# Method 1: Model-wide strict mode
class StrictModel(BaseModel):
    model_config = ConfigDict(strict=True)
    
    count: int
    name: str

# Method 2: Per-field strict mode
from pydantic import Field

class MixedModel(BaseModel):
    strict_count: int = Field(strict=True)   # Strict for this field
    lax_count: int                           # Lax (default)

# Method 3: Strict types
from pydantic import StrictInt, StrictStr, StrictFloat, StrictBool

class StrictTypesModel(BaseModel):
    count: StrictInt      # Only accepts actual int
    name: StrictStr       # Only accepts actual str
    price: StrictFloat    # Only accepts actual float
    active: StrictBool    # Only accepts actual bool
```

### Coercion Examples

```python
from pydantic import BaseModel, ValidationError

class CoercionDemo(BaseModel):
    count: int
    price: float
    active: bool
    tags: list[str]

# All these work with coercion
model = CoercionDemo(
    count="42",           # str -> int
    price=10,             # int -> float
    active="yes",         # str -> bool
    tags=("a", "b")       # tuple -> list
)

print(model)
# count=42 price=10.0 active=True tags=['a', 'b']

# These fail even with coercion
try:
    bad = CoercionDemo(
        count="not a number",  # Cannot convert
        price=10,
        active="yes",
        tags=["a"]
    )
except ValidationError as e:
    print("Error:", e.errors()[0]['msg'])
    # Error: Input should be a valid integer, unable to parse string as an integer
```

---

## Quick Reference

### Complete Type Reference Card

```
+------------------------------------------------------------------+
|                   PYDANTIC v2 TYPE REFERENCE                      |
+------------------------------------------------------------------+
|                                                                  |
|  STANDARD TYPES                                                  |
|  --------------                                                  |
|  str, int, float, bool, bytes                                    |
|                                                                  |
|  COLLECTION TYPES                                                |
|  ----------------                                                |
|  list[T], dict[K,V], set[T], tuple[T,...], frozenset[T]         |
|                                                                  |
|  OPTIONAL/UNION                                                  |
|  --------------                                                  |
|  Optional[T], T | None, Union[T1, T2]                           |
|                                                                  |
|  LITERAL                                                         |
|  -------                                                         |
|  Literal["a", "b", 1, 2]                                        |
|                                                                  |
|  DATETIME                                                        |
|  --------                                                        |
|  datetime, date, time, timedelta                                 |
|  AwareDatetime, NaiveDatetime                                    |
|                                                                  |
|  SPECIAL                                                         |
|  -------                                                         |
|  UUID, Path, FilePath, DirectoryPath, NewPath                   |
|  HttpUrl, AnyUrl, AnyHttpUrl                                    |
|  EmailStr, SecretStr, SecretBytes                               |
|  PositiveInt, NegativeInt, NonNegativeInt, NonPositiveInt       |
|  PositiveFloat, NegativeFloat, NonNegativeFloat, NonPositiveFloat|
|  StrictStr, StrictInt, StrictFloat, StrictBool                  |
|                                                                  |
|  CONSTRAINED                                                     |
|  -----------                                                     |
|  constr(min_length, max_length, pattern)                        |
|  conint(gt, ge, lt, le, multiple_of)                            |
|  confloat(gt, ge, lt, le)                                       |
|  conlist(item_type, min_length, max_length)                     |
|                                                                  |
|  ESCAPE HATCH                                                    |
|  ------------                                                    |
|  Any (no validation)                                             |
|                                                                  |
+------------------------------------------------------------------+
```

### Import Cheat Sheet

```python
# Standard library
from typing import Optional, Union, Literal, Any, Annotated
from typing import List, Dict, Set, Tuple, FrozenSet
from datetime import datetime, date, time, timedelta
from uuid import UUID
from pathlib import Path

# Pydantic core
from pydantic import BaseModel, Field, ConfigDict

# Pydantic types
from pydantic import (
    # URLs
    HttpUrl, AnyUrl, AnyHttpUrl,
    
    # Paths
    FilePath, DirectoryPath, NewPath,
    
    # Strings
    EmailStr, SecretStr, SecretBytes,
    
    # Numbers
    PositiveInt, NegativeInt, NonNegativeInt, NonPositiveInt,
    PositiveFloat, NegativeFloat, NonNegativeFloat, NonPositiveFloat,
    
    # Strict types
    StrictStr, StrictInt, StrictFloat, StrictBool,
    
    # Constrained types
    constr, conint, confloat, conlist,
    
    # Datetime
    AwareDatetime, NaiveDatetime
)
```

---

## Next Steps

In the next module, we'll explore:
- Field constraints with `Field()`
- Validation patterns (gt, lt, ge, le)
- String patterns and regex
- Custom constraints

---
