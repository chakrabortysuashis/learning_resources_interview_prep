# Module 11: Generic Models

---

## Table of Contents
- [Python Generics Refresher](#python-generics-refresher)
- [Creating Generic Pydantic Models](#creating-generic-pydantic-models)
- [Constraining Generic Types](#constraining-generic-types)
- [Multiple Type Parameters](#multiple-type-parameters)
- [Practical Use Cases](#practical-use-cases)
- [Generic Models with Validators](#generic-models-with-validators)
- [Limitations and Gotchas](#limitations-and-gotchas)
- [Visual Diagram: Type Resolution](#visual-diagram-type-resolution)

---

## Python Generics Refresher

Before diving into Pydantic generic models, let's refresh our understanding of Python's typing system for generics.

### What Are Generics?

Generics allow you to write code that works with multiple types while maintaining type safety. They're like templates that get filled in with specific types later.

```
+------------------------------------------------------------------+
|                    WHY USE GENERICS?                             |
+------------------------------------------------------------------+
|                                                                  |
|  WITHOUT GENERICS                    WITH GENERICS               |
|  ----------------                    -------------               |
|                                                                  |
|  class IntContainer:                 class Container(Generic[T]):|
|      def __init__(self, value: int)     def __init__(self, value: T)|
|                                                                  |
|  class StrContainer:                 # One class handles all!    |
|      def __init__(self, value: str)  Container[int](42)          |
|                                      Container[str]("hello")     |
|  class FloatContainer:                                           |
|      def __init__(self, value: float)                            |
|                                                                  |
|  # Multiple classes for each type   # Reusable, type-safe code   |
|                                                                  |
+------------------------------------------------------------------+
```

### TypeVar and Generic

```python
from typing import TypeVar, Generic

# Create a type variable - a placeholder for any type
T = TypeVar('T')

# Use it in a generic class
class Box(Generic[T]):
    def __init__(self, content: T) -> None:
        self.content = content
    
    def get(self) -> T:
        return self.content

# When used, T gets replaced with a specific type
int_box: Box[int] = Box(42)        # T becomes int
str_box: Box[str] = Box("hello")   # T becomes str
```

### TypeVar Options

```
+------------------------------------------------------------------+
|                     TYPEVAR CONFIGURATIONS                       |
+------------------------------------------------------------------+
|                                                                  |
|  UNBOUNDED (any type)                                            |
|  --------------------                                            |
|  T = TypeVar('T')                                                |
|  # T can be int, str, MyClass, anything                          |
|                                                                  |
|  BOUND (type or subtype)                                         |
|  -----------------------                                         |
|  T = TypeVar('T', bound=BaseModel)                               |
|  # T must be BaseModel or a subclass of it                       |
|                                                                  |
|  CONSTRAINED (specific types only)                               |
|  ---------------------------------                               |
|  T = TypeVar('T', int, str, float)                               |
|  # T can ONLY be int, str, or float - nothing else               |
|                                                                  |
+------------------------------------------------------------------+
```

### Key Differences: bound vs constraints

```python
from typing import TypeVar
from pydantic import BaseModel

# bound: T must be BaseModel or ANY subclass
T_bound = TypeVar('T_bound', bound=BaseModel)

# constraints: T must be EXACTLY one of these types
T_constrained = TypeVar('T_constrained', int, str)

# With bound=BaseModel:
#   - User(BaseModel) is valid
#   - Product(BaseModel) is valid
#   - Any BaseModel subclass is valid

# With constraints (int, str):
#   - int is valid
#   - str is valid
#   - float is NOT valid (not in the list)
#   - bool is NOT valid (even though bool is subclass of int)
```

---

## Creating Generic Pydantic Models

Pydantic supports generic models by combining `BaseModel` with Python's `Generic`.

### Basic Generic Model

```python
from typing import TypeVar, Generic
from pydantic import BaseModel

# Define a type variable
T = TypeVar('T')

# Create a generic model
class Wrapper(BaseModel, Generic[T]):
    data: T
    metadata: str = ""

# Use with different types
int_wrapper = Wrapper[int](data=42, metadata="integer value")
str_wrapper = Wrapper[str](data="hello", metadata="string value")

print(int_wrapper)  # data=42 metadata='integer value'
print(str_wrapper)  # data='hello' metadata='string value'
```

### Inheritance Order Matters

```
+------------------------------------------------------------------+
|                    INHERITANCE ORDER                             |
+------------------------------------------------------------------+
|                                                                  |
|  CORRECT                             INCORRECT                   |
|  -------                             ---------                   |
|                                                                  |
|  class MyModel(BaseModel, Generic[T]):   class MyModel(Generic[T], BaseModel):
|      data: T                                 # May cause issues!
|                                                                  |
|  # BaseModel FIRST, then Generic[T]                              |
|                                                                  |
+------------------------------------------------------------------+
```

### Generic Model with Nested Types

```python
from typing import TypeVar, Generic, List
from pydantic import BaseModel

T = TypeVar('T')

class Container(BaseModel, Generic[T]):
    items: List[T]
    count: int = 0

# Using with a list of integers
int_container = Container[int](items=[1, 2, 3])
int_container.count = len(int_container.items)

# Using with a list of Pydantic models
class Product(BaseModel):
    name: str
    price: float

product_container = Container[Product](
    items=[
        Product(name="Widget", price=9.99),
        Product(name="Gadget", price=19.99)
    ],
    count=2
)
```

---

## Constraining Generic Types

You can restrict what types are allowed in your generic model.

### Using bound

```python
from typing import TypeVar, Generic
from pydantic import BaseModel

# Only allow BaseModel subclasses
ModelT = TypeVar('ModelT', bound=BaseModel)

class ModelWrapper(BaseModel, Generic[ModelT]):
    model: ModelT
    version: int = 1

class User(BaseModel):
    name: str
    email: str

class Product(BaseModel):
    name: str
    price: float

# Works with any BaseModel subclass
user_wrapper = ModelWrapper[User](model=User(name="Alice", email="alice@example.com"))
product_wrapper = ModelWrapper[Product](model=Product(name="Widget", price=9.99))

# This would fail type checking (str is not a BaseModel)
# wrapper = ModelWrapper[str](model="hello")  # Type error!
```

### Using Constraints

```python
from typing import TypeVar, Generic
from pydantic import BaseModel

# Only allow these specific types
NumericT = TypeVar('NumericT', int, float)

class NumericResult(BaseModel, Generic[NumericT]):
    value: NumericT
    unit: str

int_result = NumericResult[int](value=42, unit="count")
float_result = NumericResult[float](value=3.14, unit="radians")

# String would NOT be allowed
# str_result = NumericResult[str](value="hello", unit="text")  # Type error!
```

### Constraint Hierarchy Diagram

```
+------------------------------------------------------------------+
|                    TYPE CONSTRAINT LEVELS                        |
+------------------------------------------------------------------+
|                                                                  |
|                        TypeVar('T')                              |
|                             |                                    |
|                    +--------+--------+                           |
|                    |                 |                           |
|              (unbounded)        (constrained)                    |
|                    |                 |                           |
|            Any type allowed    Specific types                    |
|                    |                 |                           |
|                    |          +------+------+                    |
|                    |          |             |                    |
|                    |     bound=X       T, int, str               |
|                    |          |             |                    |
|                    |     X or any      ONLY these               |
|                    |     subclass      exact types               |
|                    |                                             |
|  +-----------------|------------------------------------------+  |
|  |                 v                                          |  |
|  |  T = TypeVar('T')                    # Any type            |  |
|  |  T = TypeVar('T', bound=BaseModel)   # BaseModel or child  |  |
|  |  T = TypeVar('T', int, str)          # ONLY int or str     |  |
|  +------------------------------------------------------------+  |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Multiple Type Parameters

Generic models can have multiple type parameters for complex data structures.

### Two Type Parameters

```python
from typing import TypeVar, Generic
from pydantic import BaseModel

K = TypeVar('K')  # Key type
V = TypeVar('V')  # Value type

class KeyValuePair(BaseModel, Generic[K, V]):
    key: K
    value: V

# String key, integer value
pair1 = KeyValuePair[str, int](key="count", value=42)

# Integer key, list value
pair2 = KeyValuePair[int, list](key=1, value=["a", "b", "c"])

print(pair1)  # key='count' value=42
print(pair2)  # key=1 value=['a', 'b', 'c']
```

### Practical Example: Result Type

```python
from typing import TypeVar, Generic, Optional
from pydantic import BaseModel

T = TypeVar('T')  # Success type
E = TypeVar('E')  # Error type

class Result(BaseModel, Generic[T, E]):
    """A Result type similar to Rust's Result<T, E>"""
    success: Optional[T] = None
    error: Optional[E] = None
    is_ok: bool = True

    @property
    def is_error(self) -> bool:
        return not self.is_ok

class UserError(BaseModel):
    code: int
    message: str

class User(BaseModel):
    id: int
    name: str

# Success case
success_result: Result[User, UserError] = Result(
    success=User(id=1, name="Alice"),
    is_ok=True
)

# Error case
error_result: Result[User, UserError] = Result(
    error=UserError(code=404, message="User not found"),
    is_ok=False
)
```

### Visualization: Multiple Type Parameters

```
+------------------------------------------------------------------+
|              MULTIPLE TYPE PARAMETERS IN ACTION                  |
+------------------------------------------------------------------+
|                                                                  |
|  class Result(BaseModel, Generic[T, E]):                         |
|                                     |  |                         |
|                                     |  +-- Error type            |
|                                     +---- Success type           |
|                                                                  |
|  Result[User, UserError]                                         |
|         |        |                                               |
|         v        v                                               |
|  +------+--+  +--+--------+                                      |
|  |  User   |  |  UserError |                                     |
|  |---------|  |------------|                                     |
|  | id: int |  | code: int  |                                     |
|  | name:str|  | msg: str   |                                     |
|  +---------+  +------------+                                     |
|                                                                  |
|  Usage:                                                          |
|  result.success -> User | None                                   |
|  result.error   -> UserError | None                              |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Practical Use Cases

### Use Case 1: API Response Wrapper

The most common use of generic models is wrapping API responses with consistent metadata.

```python
from typing import TypeVar, Generic, Optional, List
from pydantic import BaseModel, Field
from datetime import datetime

T = TypeVar('T')

class APIResponse(BaseModel, Generic[T]):
    """Generic API response wrapper"""
    success: bool = True
    data: Optional[T] = None
    error: Optional[str] = None
    timestamp: datetime = Field(default_factory=datetime.now)
    
    @classmethod
    def ok(cls, data: T) -> "APIResponse[T]":
        return cls(success=True, data=data)
    
    @classmethod
    def fail(cls, error: str) -> "APIResponse[T]":
        return cls(success=False, error=error)

# Define your data models
class User(BaseModel):
    id: int
    name: str
    email: str

class Product(BaseModel):
    id: int
    name: str
    price: float

# Use the same wrapper for different responses
user_response: APIResponse[User] = APIResponse.ok(
    User(id=1, name="Alice", email="alice@example.com")
)

product_response: APIResponse[Product] = APIResponse.ok(
    Product(id=101, name="Widget", price=29.99)
)

# List responses work too!
users_response: APIResponse[List[User]] = APIResponse.ok([
    User(id=1, name="Alice", email="alice@example.com"),
    User(id=2, name="Bob", email="bob@example.com"),
])

# Error response
error_response: APIResponse[User] = APIResponse.fail("User not found")
```

### API Response Wrapper Diagram

```
+------------------------------------------------------------------+
|                    API RESPONSE PATTERN                          |
+------------------------------------------------------------------+
|                                                                  |
|                      APIResponse[T]                              |
|                      +-----------------+                         |
|                      | success: bool   |                         |
|                      | data: T | None  |                         |
|                      | error: str|None |                         |
|                      | timestamp: dt   |                         |
|                      +-----------------+                         |
|                              |                                   |
|            +-----------------+-----------------+                  |
|            |                 |                 |                  |
|            v                 v                 v                  |
|  APIResponse[User]  APIResponse[Product]  APIResponse[List[User]]|
|  +---------------+  +------------------+  +-------------------+  |
|  | data: User    |  | data: Product    |  | data: List[User]  |  |
|  +---------------+  +------------------+  +-------------------+  |
|                                                                  |
|  EXAMPLE JSON OUTPUT:                                            |
|  {                                                               |
|    "success": true,                                              |
|    "data": {                                                     |
|      "id": 1,                                                    |
|      "name": "Alice",                                            |
|      "email": "alice@example.com"                                |
|    },                                                            |
|    "error": null,                                                |
|    "timestamp": "2024-01-15T10:30:00"                            |
|  }                                                               |
|                                                                  |
+------------------------------------------------------------------+
```

### Use Case 2: Paginated Results

```python
from typing import TypeVar, Generic, List
from pydantic import BaseModel, Field, computed_field

T = TypeVar('T')

class Paginated(BaseModel, Generic[T]):
    """Generic pagination wrapper"""
    items: List[T]
    page: int = Field(ge=1, default=1)
    page_size: int = Field(ge=1, le=100, default=20)
    total_items: int = Field(ge=0, default=0)
    
    @computed_field
    @property
    def total_pages(self) -> int:
        if self.total_items == 0:
            return 0
        return (self.total_items + self.page_size - 1) // self.page_size
    
    @computed_field
    @property
    def has_next(self) -> bool:
        return self.page < self.total_pages
    
    @computed_field
    @property
    def has_previous(self) -> bool:
        return self.page > 1

class Article(BaseModel):
    id: int
    title: str
    author: str

# Paginated articles
articles_page: Paginated[Article] = Paginated(
    items=[
        Article(id=1, title="Getting Started with Python", author="Alice"),
        Article(id=2, title="Advanced Pydantic", author="Bob"),
    ],
    page=1,
    page_size=10,
    total_items=42
)

print(f"Page {articles_page.page} of {articles_page.total_pages}")
print(f"Has next: {articles_page.has_next}")
print(f"Has previous: {articles_page.has_previous}")
```

### Pagination Diagram

```
+------------------------------------------------------------------+
|                    PAGINATION PATTERN                            |
+------------------------------------------------------------------+
|                                                                  |
|  Paginated[Article]                                              |
|  +------------------------------------------------------------+  |
|  |                                                            |  |
|  |  items: [Article, Article, ...]    <- Generic type T       |  |
|  |                                                            |  |
|  |  +------------------+  +------------------+                 |  |
|  |  | id: 1            |  | id: 2            |  ...           |  |
|  |  | title: "..."     |  | title: "..."     |                |  |
|  |  | author: "Alice"  |  | author: "Bob"    |                |  |
|  |  +------------------+  +------------------+                 |  |
|  |                                                            |  |
|  |  page: 1                                                   |  |
|  |  page_size: 10                                             |  |
|  |  total_items: 42                                           |  |
|  |  total_pages: 5      <- computed                           |  |
|  |  has_next: true      <- computed                           |  |
|  |  has_previous: false <- computed                           |  |
|  |                                                            |  |
|  +------------------------------------------------------------+  |
|                                                                  |
|  [Prev] [1] [2] [3] [4] [5] [Next]                               |
|          ^                                                       |
|          current page                                            |
|                                                                  |
+------------------------------------------------------------------+
```

### Use Case 3: Cache Wrapper

```python
from typing import TypeVar, Generic, Optional
from pydantic import BaseModel, Field
from datetime import datetime, timedelta

T = TypeVar('T')

class Cached(BaseModel, Generic[T]):
    """Generic cache wrapper with expiration"""
    value: T
    cached_at: datetime = Field(default_factory=datetime.now)
    ttl_seconds: int = 3600  # 1 hour default
    
    @property
    def expires_at(self) -> datetime:
        return self.cached_at + timedelta(seconds=self.ttl_seconds)
    
    @property
    def is_expired(self) -> bool:
        return datetime.now() > self.expires_at
    
    @property
    def is_valid(self) -> bool:
        return not self.is_expired

class UserProfile(BaseModel):
    id: int
    name: str
    avatar_url: str

# Cache a user profile for 1 hour
cached_profile: Cached[UserProfile] = Cached(
    value=UserProfile(
        id=1,
        name="Alice",
        avatar_url="https://example.com/alice.png"
    ),
    ttl_seconds=3600
)

if cached_profile.is_valid:
    print(f"Using cached profile: {cached_profile.value.name}")
else:
    print("Cache expired, fetching fresh data...")
```

---

## Generic Models with Validators

You can add validators to generic models, though there are some considerations.

### Field Validators on Generic Fields

```python
from typing import TypeVar, Generic, Any
from pydantic import BaseModel, field_validator

T = TypeVar('T')

class NonEmptyContainer(BaseModel, Generic[T]):
    """Container that validates the data is not empty/None"""
    data: T
    
    @field_validator('data', mode='before')
    @classmethod
    def validate_not_empty(cls, v: Any) -> Any:
        if v is None:
            raise ValueError('data cannot be None')
        if isinstance(v, (str, list, dict)) and len(v) == 0:
            raise ValueError('data cannot be empty')
        return v

# Valid
container = NonEmptyContainer[str](data="hello")
print(container)

# Invalid - will raise ValidationError
# container = NonEmptyContainer[str](data="")  # Empty string
# container = NonEmptyContainer[list](data=[])  # Empty list
```

### Model Validators with Generics

```python
from typing import TypeVar, Generic, List
from pydantic import BaseModel, model_validator

T = TypeVar('T')

class UniqueCollection(BaseModel, Generic[T]):
    """Collection that ensures all items are unique"""
    items: List[T]
    
    @model_validator(mode='after')
    def check_uniqueness(self) -> 'UniqueCollection[T]':
        # For hashable items, check uniqueness
        try:
            if len(self.items) != len(set(self.items)):
                raise ValueError('All items must be unique')
        except TypeError:
            # Items are not hashable (e.g., dicts), skip check
            pass
        return self

# Valid - unique items
unique = UniqueCollection[int](items=[1, 2, 3, 4, 5])

# Invalid - duplicates
# UniqueCollection[int](items=[1, 2, 2, 3])  # Raises ValidationError
```

### Type-Specific Validators

```python
from typing import TypeVar, Generic, get_args
from pydantic import BaseModel, model_validator

T = TypeVar('T')

class TypeAwareWrapper(BaseModel, Generic[T]):
    """Wrapper that knows its type parameter"""
    value: T
    
    @model_validator(mode='after')
    def log_type(self) -> 'TypeAwareWrapper[T]':
        # Note: Getting the actual type parameter at runtime 
        # requires some tricks
        print(f"Created wrapper with value: {self.value}")
        return self

# When you need to know T at runtime, you can use __pydantic_generic_metadata__
wrapper = TypeAwareWrapper[int](value=42)
# Access: wrapper.__pydantic_generic_metadata__
```

---

## Limitations and Gotchas

### 1. Type Erasure at Runtime

Python's generic types are primarily for static type checking. At runtime, type information may not be available.

```python
from typing import TypeVar, Generic
from pydantic import BaseModel

T = TypeVar('T')

class Container(BaseModel, Generic[T]):
    value: T

# These are the SAME class at runtime!
int_container = Container[int](value=42)
str_container = Container[str](value="hello")

print(type(int_container))  # <class '__main__.Container'>
print(type(str_container))  # <class '__main__.Container'>

# They are instances of the same class
print(type(int_container) == type(str_container))  # True!
```

### 2. Concrete Type Required for Instantiation

You cannot instantiate a generic model without specifying the type parameter.

```python
from typing import TypeVar, Generic
from pydantic import BaseModel

T = TypeVar('T')

class Wrapper(BaseModel, Generic[T]):
    data: T

# WRONG - T is not specified
# wrapper = Wrapper(data=42)  # Works but loses type info

# CORRECT - specify the type
wrapper: Wrapper[int] = Wrapper[int](data=42)
```

### 3. Generic Types and JSON Schema

Generic models generate schemas, but the generic nature may not be fully captured.

```python
from typing import TypeVar, Generic
from pydantic import BaseModel
import json

T = TypeVar('T')

class Response(BaseModel, Generic[T]):
    data: T
    success: bool

# Concrete type generates proper schema
UserResponse = Response[dict]
schema = UserResponse.model_json_schema()
print(json.dumps(schema, indent=2))
```

### 4. Nested Generics Can Be Complex

```python
from typing import TypeVar, Generic, List, Optional
from pydantic import BaseModel

T = TypeVar('T')

class Page(BaseModel, Generic[T]):
    items: List[T]

class Response(BaseModel, Generic[T]):
    data: Optional[T] = None

# Nested generic - Response containing Page of Users
class User(BaseModel):
    name: str

# This works
response: Response[Page[User]] = Response(
    data=Page(items=[User(name="Alice")])
)
```

### Gotchas Summary Table

```
+------------------------------------------------------------------+
|                    GENERIC MODEL GOTCHAS                         |
+------------------------------------------------------------------+
|                                                                  |
|  ISSUE                          | SOLUTION                       |
|  -------------------------------|-------------------------------|
|  Type erasure at runtime        | Use __pydantic_generic_metadata__|
|  Unspecified type parameter     | Always specify: Model[Type]()  |
|  Inheritance order              | BaseModel first, then Generic[T]|
|  Validator access to T          | Limited - use mode='before'    |
|  Complex nested generics        | Keep nesting shallow           |
|  JSON schema for generics       | Create concrete types first    |
|                                                                  |
+------------------------------------------------------------------+
```

### 5. Forward References with Generics

```python
from __future__ import annotations
from typing import TypeVar, Generic, List
from pydantic import BaseModel

T = TypeVar('T')

class TreeNode(BaseModel, Generic[T]):
    value: T
    children: List[TreeNode[T]] = []  # Self-referential generic

# Works with forward references
node: TreeNode[int] = TreeNode(
    value=1,
    children=[
        TreeNode(value=2),
        TreeNode(value=3, children=[TreeNode(value=4)])
    ]
)
```

---

## Visual Diagram: Type Resolution

This diagram shows how Pydantic resolves types when you use generic models.

```
+------------------------------------------------------------------+
|                    TYPE RESOLUTION FLOW                          |
+------------------------------------------------------------------+
|                                                                  |
|  DEFINITION PHASE                                                |
|  ----------------                                                |
|                                                                  |
|  T = TypeVar('T')                   <- Create placeholder        |
|           |                                                      |
|           v                                                      |
|  class Response(BaseModel, Generic[T]):                          |
|      data: T        <- T is unresolved                           |
|      success: bool                                               |
|                                                                  |
|  +------------------------------------------------------------+  |
|  |  Response[T]                                               |  |
|  |  +------------------+                                      |  |
|  |  | data: T (?)      |  <- Type unknown                     |  |
|  |  | success: bool    |                                      |  |
|  |  +------------------+                                      |  |
|  +------------------------------------------------------------+  |
|                                                                  |
|  SPECIALIZATION PHASE                                            |
|  --------------------                                            |
|                                                                  |
|  Response[User]     <- T gets replaced with User                 |
|           |                                                      |
|           v                                                      |
|  +------------------------------------------------------------+  |
|  |  Response[User]                                            |  |
|  |  +------------------+                                      |  |
|  |  | data: User       |  <- Type resolved!                   |  |
|  |  | success: bool    |                                      |  |
|  |  +------------------+                                      |  |
|  +------------------------------------------------------------+  |
|                                                                  |
|  INSTANTIATION PHASE                                             |
|  -------------------                                             |
|                                                                  |
|  response = Response[User](                                      |
|      data=User(name="Alice"),                                    |
|      success=True                                                |
|  )                                                               |
|           |                                                      |
|           v                                                      |
|  +------------------------------------------------------------+  |
|  |  Instance of Response[User]                                |  |
|  |  +------------------+                                      |  |
|  |  | data: User(...)  |  <- Actual User instance             |  |
|  |  | success: True    |                                      |  |
|  |  +------------------+                                      |  |
|  +------------------------------------------------------------+  |
|                                                                  |
+------------------------------------------------------------------+

VALIDATION FLOW:
                                                                   
  Input Dict                  Type Check                 Output     
  +---------+                +-----------+            +----------+  
  | "data": |  ----------->  | Is it a   |  -------> | User     |  
  |  {...}  |    Parse       | valid     |   Yes     | instance |  
  +---------+                | User?     |            +----------+  
                             +-----------+                          
                                  |                                 
                                  | No                              
                                  v                                 
                            ValidationError                         
```

---

## Quick Reference

```
+------------------------------------------------------------------+
|                    GENERIC MODELS CHEAT SHEET                    |
+------------------------------------------------------------------+
|                                                                  |
|  IMPORTS                                                         |
|  -------                                                         |
|  from typing import TypeVar, Generic, List, Optional             |
|  from pydantic import BaseModel, Field                           |
|                                                                  |
|  BASIC PATTERN                                                   |
|  -------------                                                   |
|  T = TypeVar('T')                                                |
|  class Wrapper(BaseModel, Generic[T]):                           |
|      data: T                                                     |
|                                                                  |
|  CONSTRAINED TYPES                                               |
|  ----------------                                                |
|  T = TypeVar('T', bound=BaseModel)    # Subclasses only          |
|  T = TypeVar('T', int, str, float)    # Specific types           |
|                                                                  |
|  MULTIPLE PARAMETERS                                             |
|  -------------------                                             |
|  K = TypeVar('K')                                                |
|  V = TypeVar('V')                                                |
|  class KVStore(BaseModel, Generic[K, V]):                        |
|      key: K                                                      |
|      value: V                                                    |
|                                                                  |
|  COMMON PATTERNS                                                 |
|  ---------------                                                 |
|  APIResponse[T]    - Wrap any data with metadata                 |
|  Paginated[T]      - Add pagination to any list                  |
|  Result[T, E]      - Success/error pattern                       |
|  Cached[T]         - Add caching metadata                        |
|                                                                  |
|  REMEMBER                                                        |
|  --------                                                        |
|  - BaseModel comes before Generic[T] in inheritance              |
|  - Always specify type: Model[Type]() not Model()                |
|  - Type info is for static checking; limited at runtime          |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Next Steps

In the next module, we'll explore:
- **Strict Mode** - Disabling type coercion for maximum type safety
- When to use strict vs lax validation
- Performance implications of strict mode

---
