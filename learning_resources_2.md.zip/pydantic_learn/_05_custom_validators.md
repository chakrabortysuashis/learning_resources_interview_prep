# Module 05: Custom Validators in Pydantic v2

## Table of Contents
1. [Introduction to Custom Validators](#introduction-to-custom-validators)
2. [@field_validator Decorator](#field_validator-decorator)
3. [Validation Modes](#validation-modes)
4. [@model_validator Decorator](#model_validator-decorator)
5. [Raising ValidationError](#raising-validationerror)
6. [Reusing Validators](#reusing-validators)
7. [Validator Execution Order](#validator-execution-order)
8. [Common Validation Patterns](#common-validation-patterns)

---

## Introduction to Custom Validators

Pydantic v2 provides powerful custom validation capabilities through two main decorators:
- **`@field_validator`** - Validates individual fields
- **`@model_validator`** - Validates the entire model (cross-field validation)

```
+------------------------------------------------------------------+
|                    PYDANTIC V2 VALIDATORS                        |
+------------------------------------------------------------------+
|                                                                  |
|   @field_validator       |    @model_validator                   |
|   - Single field         |    - Entire model                     |
|   - Independent values   |    - Cross-field logic                |
|   - Type coercion        |    - Conditional validation           |
|                                                                  |
+------------------------------------------------------------------+
```

> **IMPORTANT**: Pydantic v2 uses `@field_validator`, NOT `@validator` (v1 syntax)

---

## @field_validator Decorator

The `@field_validator` decorator is used to validate individual fields.

### Basic Syntax

```python
from pydantic import BaseModel, field_validator

class User(BaseModel):
    name: str
    age: int
    
    @field_validator('name')
    @classmethod
    def validate_name(cls, v: str) -> str:
        if len(v) < 2:
            raise ValueError('Name must be at least 2 characters')
        return v.title()
```

### Key Points

```
+------------------------------------------------------------------+
|                   @field_validator ESSENTIALS                    |
+------------------------------------------------------------------+
|                                                                  |
|   1. Must be a @classmethod (decorated AFTER @field_validator)   |
|   2. First argument is 'cls', second is the value 'v'            |
|   3. Must return the (possibly transformed) value                |
|   4. Can validate multiple fields: @field_validator('a', 'b')    |
|   5. Use '*' to validate ALL fields: @field_validator('*')       |
|                                                                  |
+------------------------------------------------------------------+
```

### Validating Multiple Fields

```python
from pydantic import BaseModel, field_validator

class Product(BaseModel):
    name: str
    description: str
    
    @field_validator('name', 'description')
    @classmethod
    def strip_whitespace(cls, v: str) -> str:
        return v.strip()
```

### The FieldValidationInfo Parameter

Access field metadata and other field values using `ValidationInfo`:

```python
from pydantic import BaseModel, field_validator, ValidationInfo

class User(BaseModel):
    username: str
    password: str
    
    @field_validator('password')
    @classmethod
    def validate_password(cls, v: str, info: ValidationInfo) -> str:
        # Access the field name
        print(f"Validating field: {info.field_name}")
        
        # Access already-validated data (fields defined BEFORE this one)
        if info.data.get('username') and v == info.data['username']:
            raise ValueError('Password cannot be the same as username')
        return v
```

---

## Validation Modes

Pydantic v2 supports four validation modes that determine WHEN your validator runs:

```
+==================================================================+
|                     VALIDATION MODES OVERVIEW                    |
+==================================================================+

         RAW INPUT DATA
              |
              v
    +-------------------+
    |  mode='before'    |  <-- Runs BEFORE Pydantic's parsing
    |  (raw input)      |      Receives: Any type
    +-------------------+
              |
              v
    +-------------------+
    |  Pydantic's       |  <-- Type coercion & parsing
    |  Core Validation  |
    +-------------------+
              |
              v
    +-------------------+
    |  mode='after'     |  <-- Runs AFTER Pydantic's parsing (DEFAULT)
    |  (parsed value)   |      Receives: Validated type
    +-------------------+
              |
              v
         FINAL VALUE

+------------------------------------------------------------------+
|  mode='wrap'   |  Wraps the entire validation - you control it   |
|  mode='plain'  |  Replaces Pydantic's validation entirely        |
+------------------------------------------------------------------+
```

### Mode: 'before' (Pre-validation)

Runs BEFORE Pydantic parses the value. Receives raw input.

```python
from pydantic import BaseModel, field_validator

class Config(BaseModel):
    debug: bool
    
    @field_validator('debug', mode='before')
    @classmethod
    def parse_debug(cls, v):
        # Handle string inputs like "true", "yes", "1"
        if isinstance(v, str):
            return v.lower() in ('true', 'yes', '1', 'on')
        return v

# Usage:
Config(debug="yes")   # Works! debug=True
Config(debug="TRUE")  # Works! debug=True
Config(debug=1)       # Works! debug=True
```

### Mode: 'after' (Post-validation) - DEFAULT

Runs AFTER Pydantic parses the value. Receives the validated type.

```python
from pydantic import BaseModel, field_validator

class User(BaseModel):
    email: str
    
    @field_validator('email', mode='after')  # 'after' is the default
    @classmethod
    def normalize_email(cls, v: str) -> str:
        # v is guaranteed to be a string here
        return v.lower().strip()
```

### Mode: 'wrap' (Wrapper Validation)

Wraps the entire validation process. You control when/if core validation runs.

```python
from pydantic import BaseModel, field_validator, ValidationInfo
from pydantic_core import PydanticUseDefault

class Settings(BaseModel):
    port: int = 8080
    
    @field_validator('port', mode='wrap')
    @classmethod
    def validate_port(cls, v, handler, info: ValidationInfo):
        # handler is the next validation step (Pydantic's core validation)
        
        if v is None:
            # Use the default value
            raise PydanticUseDefault()
        
        # Call the handler to perform core validation
        validated = handler(v)
        
        # Post-validation check
        if validated < 1024:
            raise ValueError('Port must be >= 1024 (non-privileged)')
        return validated
```

```
+------------------------------------------------------------------+
|                      WRAP MODE FLOW                              |
+------------------------------------------------------------------+
|                                                                  |
|    Your Validator (before handler)                               |
|           |                                                      |
|           v                                                      |
|    handler(v)  <-- Calls Pydantic's core validation              |
|           |                                                      |
|           v                                                      |
|    Your Validator (after handler)                                |
|           |                                                      |
|           v                                                      |
|    Return final value                                            |
|                                                                  |
+------------------------------------------------------------------+
```

### Mode: 'plain' (Replace Validation)

Completely replaces Pydantic's core validation.

```python
from pydantic import BaseModel, field_validator

class LegacyData(BaseModel):
    value: int
    
    @field_validator('value', mode='plain')
    @classmethod
    def custom_parse(cls, v):
        # You handle ALL validation - Pydantic won't do type checking
        if isinstance(v, str):
            return int(v.replace(',', ''))  # Handle "1,000" -> 1000
        return int(v)
```

### Mode Comparison Chart

```
+==================================================================+
|  MODE      |  RECEIVES    |  PYDANTIC RUNS  |  USE CASE          |
+==================================================================+
|  before    |  Any type    |  After you      |  Pre-processing,   |
|            |              |                 |  type coercion     |
+------------------------------------------------------------------+
|  after     |  Validated   |  Before you     |  Post-validation,  |
|  (default) |  type        |                 |  normalization     |
+------------------------------------------------------------------+
|  wrap      |  Any type    |  When you call  |  Conditional       |
|            |              |  handler()      |  validation        |
+------------------------------------------------------------------+
|  plain     |  Any type    |  Never          |  Custom parsing,   |
|            |              |                 |  legacy support    |
+------------------------------------------------------------------+
```

---

## @model_validator Decorator

Use `@model_validator` for cross-field validation when fields depend on each other.

### mode='before' - Validate Raw Input

```python
from pydantic import BaseModel, model_validator
from typing import Any

class UserRegistration(BaseModel):
    password: str
    confirm_password: str
    
    @model_validator(mode='before')
    @classmethod
    def check_raw_data(cls, data: Any) -> Any:
        # data is the raw input (usually a dict)
        if isinstance(data, dict):
            # Normalize keys to lowercase
            return {k.lower(): v for k, v in data.items()}
        return data
```

### mode='after' - Validate Parsed Model

```python
from pydantic import BaseModel, model_validator
from typing import Self

class DateRange(BaseModel):
    start_date: str
    end_date: str
    
    @model_validator(mode='after')
    def check_dates(self) -> Self:
        # self is the fully validated model instance
        if self.start_date > self.end_date:
            raise ValueError('start_date must be before end_date')
        return self
```

### Model Validator Flow Diagram

```
+==================================================================+
|                   MODEL VALIDATOR LIFECYCLE                      |
+==================================================================+

              RAW INPUT (dict, object, etc.)
                          |
                          v
           +------------------------------+
           |  @model_validator(mode='before')  |
           |  - Receives: raw data (Any)       |
           |  - Returns: modified data         |
           |  - Must be @classmethod           |
           +------------------------------+
                          |
                          v
           +------------------------------+
           |  FIELD VALIDATORS (before)   |
           |  Run for each field          |
           +------------------------------+
                          |
                          v
           +------------------------------+
           |  PYDANTIC CORE VALIDATION    |
           |  Type coercion & parsing     |
           +------------------------------+
                          |
                          v
           +------------------------------+
           |  FIELD VALIDATORS (after)    |
           |  Run for each field          |
           +------------------------------+
                          |
                          v
           +------------------------------+
           |  @model_validator(mode='after')   |
           |  - Receives: model instance       |
           |  - Returns: Self                  |
           |  - NOT a classmethod              |
           +------------------------------+
                          |
                          v
               VALIDATED MODEL INSTANCE
```

### Cross-Field Validation Example

```python
from pydantic import BaseModel, model_validator
from typing import Self

class Order(BaseModel):
    product: str
    quantity: int
    unit_price: float
    total: float
    
    @model_validator(mode='after')
    def validate_total(self) -> Self:
        expected_total = self.quantity * self.unit_price
        if abs(self.total - expected_total) > 0.01:
            raise ValueError(
                f'Total {self.total} does not match '
                f'quantity * price = {expected_total}'
            )
        return self
```

---

## Raising ValidationError

### Using ValueError

The simplest way - Pydantic wraps it automatically:

```python
@field_validator('age')
@classmethod
def validate_age(cls, v: int) -> int:
    if v < 0:
        raise ValueError('Age cannot be negative')
    if v > 150:
        raise ValueError('Age seems unrealistic')
    return v
```

### Using AssertionError

```python
@field_validator('email')
@classmethod
def validate_email(cls, v: str) -> str:
    assert '@' in v, 'Invalid email format'
    return v
```

### Using PydanticCustomError for Detailed Errors

```python
from pydantic import BaseModel, field_validator
from pydantic_core import PydanticCustomError

class User(BaseModel):
    username: str
    
    @field_validator('username')
    @classmethod
    def validate_username(cls, v: str) -> str:
        if len(v) < 3:
            raise PydanticCustomError(
                'username_too_short',           # error type
                'Username must be at least {min_length} characters',  # message template
                {'min_length': 3}               # context
            )
        return v
```

### Error Output Structure

```
+------------------------------------------------------------------+
|                    VALIDATION ERROR STRUCTURE                    |
+------------------------------------------------------------------+

ValidationError(
    [
        {
            'type': 'value_error',           # Error type
            'loc': ('age',),                 # Field location (tuple)
            'msg': 'Age cannot be negative', # Human-readable message
            'input': -5,                     # The invalid input
            'ctx': {...}                     # Additional context
        }
    ]
)

+------------------------------------------------------------------+
```

---

## Reusing Validators

### Method 1: Standalone Functions with Annotated

```python
from typing import Annotated
from pydantic import BaseModel, AfterValidator, BeforeValidator

def normalize_string(v: str) -> str:
    return v.strip().lower()

def validate_non_empty(v: str) -> str:
    if not v:
        raise ValueError('Cannot be empty')
    return v

# Create a reusable type
NormalizedString = Annotated[str, AfterValidator(normalize_string)]
NonEmptyString = Annotated[str, BeforeValidator(validate_non_empty)]

class User(BaseModel):
    username: NormalizedString
    email: NormalizedString

class Product(BaseModel):
    name: NormalizedString
    sku: NonEmptyString
```

### Method 2: Combining Validators with Annotated

```python
from typing import Annotated
from pydantic import BaseModel, AfterValidator, BeforeValidator
import re

def strip_whitespace(v: str) -> str:
    return v.strip()

def to_lowercase(v: str) -> str:
    return v.lower()

def validate_email_format(v: str) -> str:
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    if not re.match(pattern, v):
        raise ValueError('Invalid email format')
    return v

# Chain validators: strip -> lowercase -> validate
Email = Annotated[
    str,
    BeforeValidator(strip_whitespace),
    AfterValidator(to_lowercase),
    AfterValidator(validate_email_format)
]

class User(BaseModel):
    email: Email
    backup_email: Email  # Reused!
```

### Method 3: Field Validator Inheritance

```python
from pydantic import BaseModel, field_validator

class BaseUser(BaseModel):
    name: str
    
    @field_validator('name')
    @classmethod
    def validate_name(cls, v: str) -> str:
        return v.strip().title()

class AdminUser(BaseUser):
    role: str = 'admin'
    # Inherits validate_name automatically!

class GuestUser(BaseUser):
    expires_in: int
    # Inherits validate_name automatically!
```

### Reusable Validators Diagram

```
+==================================================================+
|               VALIDATOR REUSE STRATEGIES                         |
+==================================================================+

   STRATEGY 1: Annotated Types           STRATEGY 2: Inheritance
   -------------------------             -----------------------
   
   +------------------+                  +------------------+
   | Validator Func   |                  |   BaseModel      |
   +------------------+                  |  + validators    |
           |                             +------------------+
           v                                     |
   +------------------+                  +-------+-------+
   | Annotated[type,  |                  |               |
   |   AfterValidator |                  v               v
   |   BeforeValidator|             ChildModel1    ChildModel2
   +------------------+             (inherits)     (inherits)
           |
           v
   Use in ANY model's
   field annotation

+==================================================================+
```

---

## Validator Execution Order

Understanding the order of validator execution is crucial for complex models.

### Complete Execution Order Diagram

```
+==================================================================+
|              COMPLETE VALIDATOR EXECUTION ORDER                  |
+==================================================================+

INPUT DATA
    |
    v
+--------------------------------------------------------------+
|  PHASE 1: MODEL VALIDATOR (mode='before')                    |
|  - Runs ONCE before any field processing                     |
|  - Can transform the entire input data structure             |
+--------------------------------------------------------------+
    |
    v
+--------------------------------------------------------------+
|  PHASE 2: FOR EACH FIELD (in definition order)               |
|                                                              |
|    +--------------------------------------------------+      |
|    |  2a. FIELD VALIDATOR (mode='before')             |      |
|    |      Receives: raw field value (Any)             |      |
|    +--------------------------------------------------+      |
|                         |                                    |
|                         v                                    |
|    +--------------------------------------------------+      |
|    |  2b. PYDANTIC CORE VALIDATION                    |      |
|    |      Type coercion, constraints, etc.            |      |
|    +--------------------------------------------------+      |
|                         |                                    |
|                         v                                    |
|    +--------------------------------------------------+      |
|    |  2c. FIELD VALIDATOR (mode='after')              |      |
|    |      Receives: validated type                    |      |
|    +--------------------------------------------------+      |
|                                                              |
+--------------------------------------------------------------+
    |
    v
+--------------------------------------------------------------+
|  PHASE 3: MODEL VALIDATOR (mode='after')                     |
|  - Runs ONCE after all fields are validated                  |
|  - Receives: fully constructed model instance                |
|  - Perfect for cross-field validation                        |
+--------------------------------------------------------------+
    |
    v
VALIDATED MODEL INSTANCE
```

### Multiple Validators on Same Field

When multiple validators target the same field, they run in **definition order**:

```python
from pydantic import BaseModel, field_validator

class User(BaseModel):
    name: str
    
    @field_validator('name', mode='before')
    @classmethod
    def first_before(cls, v):
        print("1. First before validator")
        return v
    
    @field_validator('name', mode='before')
    @classmethod
    def second_before(cls, v):
        print("2. Second before validator")
        return v
    
    @field_validator('name', mode='after')
    @classmethod
    def first_after(cls, v):
        print("3. First after validator")
        return v
    
    @field_validator('name', mode='after')
    @classmethod
    def second_after(cls, v):
        print("4. Second after validator")
        return v

# Output order:
# 1. First before validator
# 2. Second before validator
# [Pydantic core validation]
# 3. First after validator
# 4. Second after validator
```

### Field Order Matters for Cross-Field Access

```python
from pydantic import BaseModel, field_validator, ValidationInfo

class User(BaseModel):
    first_name: str  # Validated first
    last_name: str   # Validated second
    full_name: str   # Validated third
    
    @field_validator('full_name')
    @classmethod
    def build_full_name(cls, v: str, info: ValidationInfo) -> str:
        # Can access first_name and last_name (already validated)
        data = info.data
        if 'first_name' in data and 'last_name' in data:
            expected = f"{data['first_name']} {data['last_name']}"
            if v != expected:
                raise ValueError(f'full_name should be "{expected}"')
        return v
```

```
+------------------------------------------------------------------+
|              INFO.DATA AVAILABILITY BY FIELD ORDER               |
+------------------------------------------------------------------+
|                                                                  |
|   Field Order:  first_name -> last_name -> full_name             |
|                                                                  |
|   When validating first_name:                                    |
|       info.data = {}  (empty, no fields validated yet)           |
|                                                                  |
|   When validating last_name:                                     |
|       info.data = {'first_name': '...'}                          |
|                                                                  |
|   When validating full_name:                                     |
|       info.data = {'first_name': '...', 'last_name': '...'}      |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Common Validation Patterns

### Email Validation

```python
from pydantic import BaseModel, field_validator
import re

class User(BaseModel):
    email: str
    
    @field_validator('email')
    @classmethod
    def validate_email(cls, v: str) -> str:
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        if not re.match(pattern, v):
            raise ValueError('Invalid email format')
        return v.lower()
```

### Phone Number Validation

```python
from pydantic import BaseModel, field_validator
import re

class Contact(BaseModel):
    phone: str
    
    @field_validator('phone', mode='before')
    @classmethod
    def normalize_phone(cls, v: str) -> str:
        # Remove all non-digit characters
        digits = re.sub(r'\D', '', str(v))
        
        if len(digits) == 10:
            return f"+1{digits}"  # Assume US
        elif len(digits) == 11 and digits.startswith('1'):
            return f"+{digits}"
        elif len(digits) >= 11:
            return f"+{digits}"
        else:
            raise ValueError('Phone number must have at least 10 digits')
```

### Password Strength Validation

```python
from pydantic import BaseModel, field_validator
import re

class Registration(BaseModel):
    password: str
    
    @field_validator('password')
    @classmethod
    def validate_password_strength(cls, v: str) -> str:
        if len(v) < 8:
            raise ValueError('Password must be at least 8 characters')
        if not re.search(r'[A-Z]', v):
            raise ValueError('Password must contain an uppercase letter')
        if not re.search(r'[a-z]', v):
            raise ValueError('Password must contain a lowercase letter')
        if not re.search(r'\d', v):
            raise ValueError('Password must contain a digit')
        if not re.search(r'[!@#$%^&*(),.?":{}|<>]', v):
            raise ValueError('Password must contain a special character')
        return v
```

### URL Validation

```python
from pydantic import BaseModel, field_validator
from urllib.parse import urlparse

class Website(BaseModel):
    url: str
    
    @field_validator('url')
    @classmethod
    def validate_url(cls, v: str) -> str:
        try:
            result = urlparse(v)
            if not all([result.scheme, result.netloc]):
                raise ValueError('Invalid URL')
            if result.scheme not in ('http', 'https'):
                raise ValueError('URL must use http or https')
        except Exception as e:
            raise ValueError(f'Invalid URL: {e}')
        return v
```

### Date Range Validation

```python
from pydantic import BaseModel, model_validator
from datetime import date
from typing import Self

class Event(BaseModel):
    name: str
    start_date: date
    end_date: date
    
    @model_validator(mode='after')
    def validate_date_range(self) -> Self:
        if self.end_date < self.start_date:
            raise ValueError('end_date must be after start_date')
        return self
```

### Conditional Required Fields

```python
from pydantic import BaseModel, model_validator
from typing import Self

class Payment(BaseModel):
    method: str  # 'card' or 'bank'
    card_number: str | None = None
    bank_account: str | None = None
    
    @model_validator(mode='after')
    def validate_payment_details(self) -> Self:
        if self.method == 'card' and not self.card_number:
            raise ValueError('card_number is required for card payments')
        if self.method == 'bank' and not self.bank_account:
            raise ValueError('bank_account is required for bank payments')
        return self
```

### Slug/Username Validation

```python
from pydantic import BaseModel, field_validator
import re

class Article(BaseModel):
    slug: str
    
    @field_validator('slug')
    @classmethod
    def validate_slug(cls, v: str) -> str:
        if not re.match(r'^[a-z0-9]+(?:-[a-z0-9]+)*$', v):
            raise ValueError(
                'Slug must contain only lowercase letters, '
                'numbers, and hyphens (no consecutive hyphens)'
            )
        return v
```

---

## Quick Reference Card

```
+==================================================================+
|                   PYDANTIC V2 VALIDATORS CHEATSHEET              |
+==================================================================+

FIELD VALIDATOR:
----------------
@field_validator('field_name', mode='after')
@classmethod
def validate_field(cls, v: Type) -> Type:
    # validate and return
    return v

MODEL VALIDATOR:
----------------
@model_validator(mode='after')
def validate_model(self) -> Self:
    # cross-field validation
    return self

MODES:
------
- 'before'  : Before type coercion (receives Any)
- 'after'   : After type coercion (receives validated type) [DEFAULT]
- 'wrap'    : Wraps core validation (you control when it runs)
- 'plain'   : Replaces core validation entirely

REUSABLE VALIDATORS:
-------------------
NormalizedStr = Annotated[str, AfterValidator(normalize_func)]

ERROR RAISING:
--------------
raise ValueError('message')
raise PydanticCustomError('type', 'template {var}', {'var': value})

+==================================================================+
```

---

## Summary

| Concept | Key Point |
|---------|-----------|
| `@field_validator` | Validates single fields, must be `@classmethod` |
| `@model_validator` | Cross-field validation, `mode='after'` is NOT classmethod |
| `mode='before'` | Runs before type coercion, receives raw input |
| `mode='after'` | Runs after type coercion, receives validated type |
| `mode='wrap'` | Wraps validation, you control when core validation runs |
| `mode='plain'` | Replaces Pydantic's validation entirely |
| `ValidationInfo` | Access field name, other fields via `info.data` |
| Reuse with `Annotated` | `Annotated[str, AfterValidator(func)]` |
| Execution Order | Model(before) -> Fields(before->core->after) -> Model(after) |

---

**Next Module**: Module 06 - Serialization and Deserialization
