# 📦 Module 02: Basic Models

> Master the fundamentals of creating and using Pydantic models

---

## 🎯 Learning Objectives

```
┌────────────────────────────────────────────────────────────────────┐
│                    WHAT YOU'LL LEARN                               │
├────────────────────────────────────────────────────────────────────┤
│                                                                    │
│   ✓ Create BaseModel classes                                       │
│   ✓ Define fields with type hints                                  │
│   ✓ Understand Required vs Optional fields                         │
│   ✓ Use default values and default_factory                         │
│   ✓ Instantiate models from dict, kwargs, JSON                     │
│   ✓ Access model attributes                                        │
│   ✓ Use model methods (model_dump, model_dump_json, model_copy)   │
│   ✓ Create field aliases                                           │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘
```

---

## 📐 1. Creating a BaseModel Class

### The Foundation of Pydantic

Every Pydantic model inherits from `BaseModel`. This is where the magic begins!

```python
from pydantic import BaseModel

class User(BaseModel):
    name: str
    age: int
    email: str
```

### 🔍 Anatomy of a Model

```
┌─────────────────────────────────────────────────────────────┐
│                     PYDANTIC MODEL                          │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│    from pydantic import BaseModel                           │
│              │                                              │
│              └─► Import the base class                      │
│                                                             │
│    class User(BaseModel):    ◄─── Inherit from BaseModel    │
│        name: str             ◄─── Field: name, type: str    │
│        age: int              ◄─── Field: age, type: int     │
│        email: str            ◄─── Field: email, type: str   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### 💡 What You Get For Free

When you create a model, Pydantic automatically provides:

| Feature | Description |
|---------|-------------|
| **Type Validation** | Validates data types at runtime |
| **Type Coercion** | Converts compatible types (e.g., `"42"` → `42`) |
| **Error Messages** | Clear, detailed validation error messages |
| **Serialization** | Convert to dict, JSON, and more |
| **IDE Support** | Full autocomplete and type checking |

---

## 🏷️ 2. Defining Fields with Type Hints

### Basic Type Annotations

```python
from pydantic import BaseModel
from datetime import datetime
from typing import List, Dict

class Product(BaseModel):
    # Basic types
    name: str
    price: float
    quantity: int
    available: bool
    
    # Complex types
    created_at: datetime
    tags: List[str]
    metadata: Dict[str, str]
```

### 📊 Common Field Types

```
┌──────────────────┬──────────────────────────────────────────┐
│   TYPE HINT      │              EXAMPLE VALUES              │
├──────────────────┼──────────────────────────────────────────┤
│ str              │ "hello", "world"                         │
│ int              │ 1, 42, -100                              │
│ float            │ 3.14, -2.5, 1.0                          │
│ bool             │ True, False                              │
│ datetime         │ datetime(2024, 1, 15)                    │
│ date             │ date(2024, 1, 15)                        │
│ List[str]        │ ["a", "b", "c"]                          │
│ Dict[str, int]   │ {"key": 42}                              │
│ Optional[str]    │ "value" or None                          │
│ Any              │ anything at all                          │
└──────────────────┴──────────────────────────────────────────┘
```

---

## ⚖️ 3. Required vs Optional Fields

### 🔴 Required Fields (No Default)

Fields without defaults are **required** - you MUST provide them!

```python
class RequiredExample(BaseModel):
    username: str      # REQUIRED - no default
    email: str         # REQUIRED - no default
```

### 🟢 Optional Fields (With Default)

Fields with defaults are **optional** - Pydantic uses the default if not provided.

```python
from typing import Optional

class OptionalExample(BaseModel):
    username: str                    # REQUIRED
    nickname: str = "Anonymous"      # OPTIONAL with default value
    bio: Optional[str] = None        # OPTIONAL, can be None
```

### 📊 Visual Comparison

```
┌───────────────────────────────────────────────────────────────────────┐
│                    REQUIRED vs OPTIONAL FIELDS                        │
├───────────────────────────────────────────────────────────────────────┤
│                                                                       │
│   REQUIRED FIELD                    OPTIONAL FIELD                    │
│   ──────────────                    ──────────────                    │
│                                                                       │
│   name: str                         name: str = "John"                │
│       │                                 │                             │
│       ▼                                 ▼                             │
│   ┌─────────────┐                 ┌─────────────────┐                │
│   │ NO DEFAULT  │                 │ HAS DEFAULT     │                │
│   │             │                 │ value: "John"   │                │
│   └─────────────┘                 └─────────────────┘                │
│       │                                 │                             │
│       ▼                                 ▼                             │
│   ┌─────────────┐                 ┌─────────────────┐                │
│   │ MUST        │                 │ CAN SKIP        │                │
│   │ PROVIDE     │                 │ (uses default)  │                │
│   └─────────────┘                 └─────────────────┘                │
│                                                                       │
├───────────────────────────────────────────────────────────────────────┤
│                                                                       │
│   Optional[str] = None              │   This is OPTIONAL!            │
│       │      │     │                │   • Type can be str OR None    │
│       │      │     └── Default      │   • Default is None            │
│       │      └──────── Inner Type   │   • You can omit it entirely   │
│       └──────────────── Optional    │                                │
│                                                                       │
└───────────────────────────────────────────────────────────────────────┘
```

### ⚠️ Important Distinction

```python
from typing import Optional

class User(BaseModel):
    # These are DIFFERENT!
    
    bio: Optional[str]          # REQUIRED! Must pass str or None
    bio: Optional[str] = None   # OPTIONAL! Can omit entirely
```

| Declaration | Required? | Can be None? | Can Omit? |
|-------------|-----------|--------------|-----------|
| `name: str` | ✅ Yes | ❌ No | ❌ No |
| `name: str = "default"` | ❌ No | ❌ No | ✅ Yes |
| `name: Optional[str]` | ✅ Yes | ✅ Yes | ❌ No |
| `name: Optional[str] = None` | ❌ No | ✅ Yes | ✅ Yes |
| `name: str \| None = None` | ❌ No | ✅ Yes | ✅ Yes |

---

## 🏭 4. Default Values and default_factory

### Simple Default Values

```python
class Settings(BaseModel):
    theme: str = "dark"
    font_size: int = 14
    notifications: bool = True
```

### ⚠️ The Mutable Default Trap

**DANGER!** Never use mutable defaults directly:

```python
# ❌ WRONG - Shared mutable default!
class BadModel(BaseModel):
    items: list = []  # All instances share the SAME list!
```

### ✅ Solution: default_factory

Use `Field(default_factory=...)` for mutable defaults:

```python
from pydantic import BaseModel, Field

# ✅ CORRECT - Each instance gets its own list
class GoodModel(BaseModel):
    items: list = Field(default_factory=list)
    tags: dict = Field(default_factory=dict)
    scores: list = Field(default_factory=lambda: [0, 0, 0])
```

### 📊 default_factory Visual

```
┌────────────────────────────────────────────────────────────────────┐
│                      default_factory                               │
├────────────────────────────────────────────────────────────────────┤
│                                                                    │
│   Field(default_factory=list)                                      │
│                         │                                          │
│                         ▼                                          │
│   ┌─────────────────────────────────────────────────┐             │
│   │  Called EACH time a new instance is created     │             │
│   │                                                 │             │
│   │  Instance 1: list() → []  (new list object)    │             │
│   │  Instance 2: list() → []  (different list!)    │             │
│   │  Instance 3: list() → []  (another new list!)  │             │
│   └─────────────────────────────────────────────────┘             │
│                                                                    │
│   Examples:                                                        │
│   ─────────                                                        │
│   default_factory=list          →  []                              │
│   default_factory=dict          →  {}                              │
│   default_factory=set           →  set()                           │
│   default_factory=lambda: [1,2] →  [1, 2]                          │
│   default_factory=datetime.now  →  current timestamp               │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘
```

---

## 🔨 5. Model Instantiation

### Method 1: Keyword Arguments (Most Common)

```python
user = User(name="Alice", age=30, email="alice@example.com")
```

### Method 2: From Dictionary (model_validate)

```python
data = {"name": "Bob", "age": 25, "email": "bob@example.com"}
user = User.model_validate(data)
```

### Method 3: From JSON String (model_validate_json)

```python
json_data = '{"name": "Charlie", "age": 35, "email": "charlie@example.com"}'
user = User.model_validate_json(json_data)
```

### Method 4: Unpacking a Dictionary

```python
data = {"name": "Diana", "age": 28, "email": "diana@example.com"}
user = User(**data)
```

### 📊 Instantiation Methods Comparison

```
┌─────────────────────────────────────────────────────────────────────┐
│                    MODEL INSTANTIATION METHODS                      │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌──────────────────┐     ┌──────────────────┐                     │
│  │   kwargs         │     │   dict           │                     │
│  │   name="Alice"   │     │   {"name": ...}  │                     │
│  └────────┬─────────┘     └────────┬─────────┘                     │
│           │                        │                                │
│           ▼                        ▼                                │
│    User(name=...)          User.model_validate(dict)               │
│                                    │                                │
│           │                        │                                │
│           └────────┬───────────────┘                                │
│                    ▼                                                │
│             ┌──────────────┐                                        │
│             │  VALIDATION  │                                        │
│             └──────┬───────┘                                        │
│                    ▼                                                │
│             ┌──────────────┐                                        │
│             │ User object  │                                        │
│             └──────────────┘                                        │
│                                                                     │
│  ┌──────────────────┐                                               │
│  │   JSON string    │                                               │
│  │   '{"name":...}' │                                               │
│  └────────┬─────────┘                                               │
│           │                                                         │
│           ▼                                                         │
│  User.model_validate_json(json_str)                                │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 🔑 6. Accessing Model Attributes

### Dot Notation (Standard Way)

```python
user = User(name="Alice", age=30, email="alice@example.com")

# Access attributes directly
print(user.name)    # "Alice"
print(user.age)     # 30
print(user.email)   # "alice@example.com"
```

### Dictionary-Style Access

```python
# Using model_dump() to get a dict
user_dict = user.model_dump()
print(user_dict["name"])  # "Alice"
```

### Iterating Over Fields

```python
# Get all field names
for field_name in user.model_fields:
    print(f"{field_name}: {getattr(user, field_name)}")

# Output:
# name: Alice
# age: 30
# email: alice@example.com
```

### 📊 Attribute Access Methods

| Method | Returns | Use Case |
|--------|---------|----------|
| `user.name` | Field value | Direct access |
| `user.model_fields` | Dict of field info | Introspection |
| `user.model_dump()` | Dict representation | Serialization |
| `getattr(user, "name")` | Field value | Dynamic access |

---

## 🛠️ 7. Model Methods

### model_dump() - Convert to Dictionary

```python
user = User(name="Alice", age=30, email="alice@example.com")

# Basic dump
data = user.model_dump()
# {'name': 'Alice', 'age': 30, 'email': 'alice@example.com'}

# Selective dump
data = user.model_dump(include={"name", "email"})
# {'name': 'Alice', 'email': 'alice@example.com'}

data = user.model_dump(exclude={"email"})
# {'name': 'Alice', 'age': 30}

# Exclude None values
data = user.model_dump(exclude_none=True)

# Exclude unset values (fields not explicitly set)
data = user.model_dump(exclude_unset=True)
```

### model_dump_json() - Convert to JSON String

```python
user = User(name="Alice", age=30, email="alice@example.com")

# Basic JSON dump
json_str = user.model_dump_json()
# '{"name":"Alice","age":30,"email":"alice@example.com"}'

# Pretty printed JSON
json_str = user.model_dump_json(indent=2)
# {
#   "name": "Alice",
#   "age": 30,
#   "email": "alice@example.com"
# }
```

### model_copy() - Create a Copy

```python
user = User(name="Alice", age=30, email="alice@example.com")

# Shallow copy
user_copy = user.model_copy()

# Copy with updates
updated_user = user.model_copy(update={"age": 31})
# User(name='Alice', age=31, email='alice@example.com')

# Deep copy (copies nested mutable objects)
deep_copy = user.model_copy(deep=True)
```

### 📊 Model Methods Overview

```
┌─────────────────────────────────────────────────────────────────────┐
│                      MODEL METHODS                                  │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│   ┌─────────────────────────────────────────────────────────────┐  │
│   │                     User Instance                            │  │
│   │   name="Alice", age=30, email="alice@example.com"           │  │
│   └─────────────────────────────────────────────────────────────┘  │
│                              │                                      │
│          ┌───────────────────┼───────────────────┐                 │
│          ▼                   ▼                   ▼                 │
│   ┌─────────────┐    ┌─────────────────┐   ┌─────────────┐        │
│   │ model_dump()│    │model_dump_json()│   │ model_copy()│        │
│   └──────┬──────┘    └────────┬────────┘   └──────┬──────┘        │
│          ▼                    ▼                   ▼                │
│   ┌─────────────┐    ┌─────────────────┐   ┌─────────────┐        │
│   │    dict     │    │   JSON string   │   │  New User   │        │
│   │ {           │    │ '{"name":       │   │  instance   │        │
│   │   "name":   │    │   "Alice",...}' │   │  (copy)     │        │
│   │   "Alice"   │    │                 │   │             │        │
│   │   ...       │    │                 │   │             │        │
│   │ }           │    │                 │   │             │        │
│   └─────────────┘    └─────────────────┘   └─────────────┘        │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Common Parameters for model_dump()

| Parameter | Type | Description |
|-----------|------|-------------|
| `include` | set/dict | Only include these fields |
| `exclude` | set/dict | Exclude these fields |
| `exclude_unset` | bool | Exclude fields not explicitly set |
| `exclude_defaults` | bool | Exclude fields with default values |
| `exclude_none` | bool | Exclude fields with None values |
| `by_alias` | bool | Use field aliases as keys |

---

## 🏷️ 8. Field Aliases

Aliases let you use different names for input and output.

### Basic Alias

```python
from pydantic import BaseModel, Field

class User(BaseModel):
    name: str = Field(alias="userName")
    email: str = Field(alias="emailAddress")

# Input uses alias
user = User(userName="Alice", emailAddress="alice@example.com")

# But attribute access uses field name
print(user.name)   # "Alice"
print(user.email)  # "alice@example.com"
```

### Validation Alias vs Serialization Alias

```python
from pydantic import BaseModel, Field

class User(BaseModel):
    name: str = Field(
        validation_alias="user_name",    # Used when CREATING/VALIDATING
        serialization_alias="userName"    # Used when DUMPING/SERIALIZING
    )

# Input uses validation_alias
user = User(user_name="Alice")

# Output uses serialization_alias
print(user.model_dump(by_alias=True))
# {"userName": "Alice"}
```

### Allow Both Field Name and Alias

```python
from pydantic import BaseModel, ConfigDict, Field

class User(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    
    name: str = Field(alias="userName")

# Both work now!
user1 = User(name="Alice")       # Using field name
user2 = User(userName="Bob")     # Using alias
```

### 📊 Alias Visual Guide

```
┌─────────────────────────────────────────────────────────────────────┐
│                         FIELD ALIASES                               │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│   ┌─────────────────────────────────────────────────────────────┐  │
│   │  External World (JSON/API)        Internal Code             │  │
│   │  ─────────────────────────        ─────────────             │  │
│   │                                                             │  │
│   │   "userName" ─────────────────────► user.name               │  │
│   │        │                               │                    │  │
│   │        │    validation_alias           │                    │  │
│   │        │    (input parsing)            │                    │  │
│   │        ▼                               ▼                    │  │
│   │   ┌─────────┐                    ┌─────────┐               │  │
│   │   │  JSON   │◄──────────────────►│  Model  │               │  │
│   │   │  Input  │                    │ Field   │               │  │
│   │   └─────────┘                    └─────────┘               │  │
│   │        ▲                               │                    │  │
│   │        │    serialization_alias        │                    │  │
│   │        │    (output generation)        │                    │  │
│   │        │                               ▼                    │  │
│   │   "userName" ◄─────────────────── user.name                │  │
│   │                                                             │  │
│   └─────────────────────────────────────────────────────────────┘  │
│                                                                     │
│   USE CASES:                                                        │
│   ──────────                                                        │
│   • API uses camelCase, Python uses snake_case                     │
│   • Database column names differ from model attributes             │
│   • Support multiple input formats                                 │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 🎯 Quick Reference Card

```
┌─────────────────────────────────────────────────────────────────────┐
│                    BASIC MODELS CHEAT SHEET                         │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  CREATE MODEL                    INSTANTIATE                        │
│  ────────────                    ───────────                        │
│  class User(BaseModel):          User(name="A", age=30)            │
│      name: str                   User.model_validate(dict)          │
│      age: int                    User.model_validate_json(json)     │
│                                  User(**dict)                       │
│                                                                     │
│  FIELD TYPES                     DEFAULTS                           │
│  ───────────                     ────────                           │
│  name: str           required    name: str = "default"              │
│  age: int = 0        optional    items: list = Field(               │
│  bio: str | None     nullable        default_factory=list)         │
│                                                                     │
│  MODEL METHODS                   ALIASES                            │
│  ─────────────                   ───────                            │
│  .model_dump()       → dict      Field(alias="userName")            │
│  .model_dump_json()  → JSON      Field(validation_alias="user_n")   │
│  .model_copy()       → copy      Field(serialization_alias="usrN")  │
│  .model_fields       → info      model_config = ConfigDict(         │
│                                      populate_by_name=True)         │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 📝 Summary

| Concept | Key Point |
|---------|-----------|
| BaseModel | Foundation class for all Pydantic models |
| Type Hints | Define field types for automatic validation |
| Required Fields | No default = must provide value |
| Optional Fields | Has default = can omit when creating |
| default_factory | Use for mutable defaults (list, dict) |
| model_validate | Create model from dict |
| model_validate_json | Create model from JSON string |
| model_dump | Convert model to dict |
| model_dump_json | Convert model to JSON string |
| model_copy | Create copy, optionally with updates |
| Aliases | Map external names to internal field names |

---

## ➡️ Next Steps

Now that you understand basic models, continue to:

**[Module 03: Field Types](_03_field_types.md)** - Explore all the data types Pydantic supports!

---

*Happy modeling! 🐍*
