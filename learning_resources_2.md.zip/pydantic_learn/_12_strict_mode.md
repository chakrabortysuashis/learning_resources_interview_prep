# Module 12: Strict Mode

> Control type coercion behavior for more predictable validation

---

## Overview

```
+------------------------------------------------------------------+
|                    PYDANTIC VALIDATION MODES                      |
+------------------------------------------------------------------+
|                                                                    |
|    LAX MODE (Default)              STRICT MODE                     |
|    -----------------               -----------                     |
|    "123" -> int(123)               "123" -> ValidationError        |
|    1.0 -> int(1)                   1.0 -> ValidationError          |
|    "true" -> bool(True)            "true" -> ValidationError       |
|                                                                    |
|    Flexible & Forgiving            Precise & Exact                 |
|                                                                    |
+------------------------------------------------------------------+
```

---

## Lax Mode vs Strict Mode

### The Core Difference

```
                    INPUT: "42"
                         |
         +---------------+---------------+
         |                               |
    [LAX MODE]                     [STRICT MODE]
         |                               |
         v                               v
    Coerces to int(42)           ValidationError!
         |                        "Input should be
         v                         a valid integer"
    Model created                        |
    successfully                         v
                                  No model created
```

### Why Two Modes?

| Aspect | Lax Mode | Strict Mode |
|--------|----------|-------------|
| **Philosophy** | Accept anything reasonable | Accept only exact types |
| **Use Case** | APIs, user input, JSON parsing | Internal data, type safety |
| **Error Rate** | Lower (more forgiving) | Higher (more strict) |
| **Data Integrity** | May have silent conversions | Guaranteed type match |
| **Debugging** | Harder (implicit coercion) | Easier (explicit failures) |

---

## Type Coercion in Lax Mode

### Coercion Behavior Table

This table shows what Pydantic accepts and converts in **lax mode**:

| Target Type | Input Value | Lax Mode Result | Strict Mode Result |
|-------------|-------------|-----------------|-------------------|
| `int` | `"123"` | `123` | ValidationError |
| `int` | `123.0` | `123` | ValidationError |
| `int` | `True` | `1` | ValidationError |
| `float` | `"3.14"` | `3.14` | ValidationError |
| `float` | `123` | `123.0` | `123.0` (allowed) |
| `str` | `123` | `"123"` | ValidationError |
| `str` | `b"hello"` | `"hello"` | ValidationError |
| `bool` | `1` | `True` | ValidationError |
| `bool` | `0` | `False` | ValidationError |
| `bool` | `"true"` | `True` | ValidationError |
| `bool` | `""` | `False` | ValidationError |
| `list` | `(1, 2, 3)` | `[1, 2, 3]` | ValidationError |
| `set` | `[1, 2, 3]` | `{1, 2, 3}` | ValidationError |
| `bytes` | `"hello"` | `b"hello"` | ValidationError |

### Visual Coercion Flow

```
                        LAX MODE COERCION
    
    String "42"  ───────────┐
                            │
    Float 42.0   ───────────┼──────>  int(42)
                            │
    Bool True    ───────────┘
                            
    
    Int 1        ───────────┐
                            │
    String "1"   ───────────┼──────>  bool(True)
                            │
    Float 1.0    ───────────┘
```

---

## Enabling Strict Mode

There are **three ways** to enable strict mode, each with different scopes:

```
+------------------------------------------------------------------+
|                    STRICT MODE SCOPE LEVELS                       |
+------------------------------------------------------------------+
|                                                                    |
|     LEVEL 1              LEVEL 2              LEVEL 3              |
|     Per-Field            Per-Model            Per-Validation       |
|     ─────────            ─────────            ──────────────       |
|     Field(strict=True)   model_config         model_validate(      |
|                          strict=True            ..., strict=True)  |
|                                                                    |
|     Granular control     All fields strict    Runtime control      |
|                                                                    |
+------------------------------------------------------------------+
```

### Method 1: Per-Field Strict Mode

Apply strict validation to specific fields only:

```python
from pydantic import BaseModel, Field

class User(BaseModel):
    # This field is strict - no coercion
    user_id: int = Field(strict=True)
    
    # This field is lax - coercion allowed
    name: str
    
    # This field is strict
    age: int = Field(strict=True)
```

```
Validation behavior:
    
    user_id: "123"  -->  ValidationError (strict)
    user_id: 123    -->  OK
    
    name: 123       -->  "123" (lax, coerced)
    name: "Alice"   -->  OK
    
    age: "25"       -->  ValidationError (strict)
    age: 25         -->  OK
```

### Method 2: Per-Model Strict Mode

Make all fields in a model strict:

```python
from pydantic import BaseModel, ConfigDict

class StrictUser(BaseModel):
    model_config = ConfigDict(strict=True)
    
    user_id: int
    name: str
    age: int
    is_active: bool
```

```
ALL fields are now strict:
    
    {"user_id": "1", ...}     -->  ValidationError
    {"name": 123, ...}        -->  ValidationError
    {"age": "25", ...}        -->  ValidationError
    {"is_active": 1, ...}     -->  ValidationError
    
    {"user_id": 1,            -->  OK
     "name": "Alice",
     "age": 25,
     "is_active": True}
```

### Method 3: Per-Validation Strict Mode

Apply strict mode at validation time:

```python
from pydantic import BaseModel

class User(BaseModel):
    user_id: int
    name: str

# Default lax validation
user1 = User(user_id="123", name="Alice")  # Works! Coerces "123"

# Strict validation at runtime
user2 = User.model_validate(
    {"user_id": "123", "name": "Alice"},
    strict=True  # ValidationError!
)
```

```
Same model, different validation modes:
    
    User(user_id="1", ...)                        -->  OK (lax)
    User.model_validate({...}, strict=True)       -->  ValidationError
    User.model_validate({...}, strict=False)      -->  OK (explicit lax)
    User.model_validate({...})                    -->  OK (default lax)
```

---

## What Strict Mode Prevents

### Visual Comparison

```
+------------------------------------------------------------------+
|                    WHAT STRICT MODE BLOCKS                        |
+------------------------------------------------------------------+
|                                                                    |
|    INPUT             LAX RESULT          STRICT RESULT            |
|    ─────             ──────────          ─────────────            |
|                                                                    |
|    String Integers                                                 |
|    "42" -> int       42                  BLOCKED                   |
|                                                                    |
|    Float to Int                                                    |
|    3.0 -> int        3                   BLOCKED                   |
|                                                                    |
|    Bool to Int                                                     |
|    True -> int       1                   BLOCKED                   |
|                                                                    |
|    Int to String                                                   |
|    42 -> str         "42"                BLOCKED                   |
|                                                                    |
|    Int to Bool                                                     |
|    1 -> bool         True                BLOCKED                   |
|                                                                    |
|    Container Type Changes                                          |
|    tuple -> list     [1,2,3]             BLOCKED                   |
|    list -> set       {1,2,3}             BLOCKED                   |
|                                                                    |
+------------------------------------------------------------------+
```

### Exceptions: What Strict Mode ALLOWS

Even in strict mode, some conversions are still allowed:

```
+------------------------------------------------------------------+
|                 ALLOWED IN STRICT MODE                            |
+------------------------------------------------------------------+
|                                                                    |
|    int -> float        123 -> 123.0       ALLOWED                 |
|    (Widening is safe - no precision loss)                         |
|                                                                    |
|    Subclass instances                     ALLOWED                 |
|    (MyInt(5) where MyInt(int) -> int)                             |
|                                                                    |
|    None for Optional                      ALLOWED                 |
|    (None -> Optional[X])                                          |
|                                                                    |
+------------------------------------------------------------------+
```

---

## Strict Type Annotations

Pydantic provides special strict types that are **always strict**, regardless of model config:

### Available Strict Types

```python
from pydantic import (
    StrictInt,
    StrictFloat,
    StrictStr,
    StrictBool,
    StrictBytes
)
```

### Usage Example

```python
from pydantic import BaseModel, StrictInt, StrictStr, StrictBool

class StrictTypesModel(BaseModel):
    # These are ALWAYS strict, no config needed
    count: StrictInt
    name: StrictStr
    active: StrictBool
```

### Strict Types vs Field(strict=True)

```
+------------------------------------------------------------------+
|              STRICT TYPES vs FIELD(strict=True)                   |
+------------------------------------------------------------------+
|                                                                    |
|    STRICT TYPES                    FIELD(strict=True)             |
|    ────────────                    ──────────────────             |
|                                                                    |
|    count: StrictInt                count: int = Field(strict=True)|
|                                                                    |
|    - Self-documenting              - More verbose                 |
|    - Always strict                 - Can be overridden            |
|    - No extra import needed        - Part of Field API            |
|      (if using from pydantic)      - Consistent with other        |
|    - Clear intent                    Field options                |
|                                                                    |
|    RECOMMENDATION: Use StrictInt etc. for individual fields       |
|                    Use model_config for whole-model strictness    |
|                                                                    |
+------------------------------------------------------------------+
```

### All Strict Type Variants

| Standard Type | Strict Variant | Description |
|---------------|----------------|-------------|
| `int` | `StrictInt` | Accepts only `int` |
| `float` | `StrictFloat` | Accepts only `float` (or `int`) |
| `str` | `StrictStr` | Accepts only `str` |
| `bool` | `StrictBool` | Accepts only `bool` |
| `bytes` | `StrictBytes` | Accepts only `bytes` |

---

## When to Use Strict Mode

### Use Strict Mode When:

```
+------------------------------------------------------------------+
|                    USE STRICT MODE FOR                            |
+------------------------------------------------------------------+
|                                                                    |
|    [1] Internal APIs & Data Pipelines                             |
|        - Data should already be clean                             |
|        - Silent coercion masks bugs                               |
|                                                                    |
|    [2] Type-Critical Applications                                 |
|        - Financial calculations (int vs float matters!)           |
|        - Scientific computing                                     |
|        - Database schemas                                         |
|                                                                    |
|    [3] Debugging & Development                                    |
|        - Find type mismatches early                               |
|        - Explicit failures are easier to debug                    |
|                                                                    |
|    [4] Configuration Validation                                   |
|        - Config files should have correct types                   |
|        - Catch YAML/JSON type errors                              |
|                                                                    |
+------------------------------------------------------------------+
```

### Use Lax Mode When:

```
+------------------------------------------------------------------+
|                      USE LAX MODE FOR                             |
+------------------------------------------------------------------+
|                                                                    |
|    [1] External API Input                                         |
|        - User input is often stringly-typed                       |
|        - JSON numbers may come as strings                         |
|                                                                    |
|    [2] Form Data Processing                                       |
|        - HTML forms send everything as strings                    |
|        - Query parameters are strings                             |
|                                                                    |
|    [3] Legacy System Integration                                  |
|        - Old APIs may have inconsistent types                     |
|        - Backwards compatibility                                  |
|                                                                    |
|    [4] User-Friendly Validation                                   |
|        - Accept "true" or "1" for boolean fields                  |
|        - Convert numeric strings automatically                    |
|                                                                    |
+------------------------------------------------------------------+
```

### Decision Flowchart

```
                    Where is data coming from?
                              |
            +-----------------+-----------------+
            |                                   |
      [External]                          [Internal]
      (APIs, users,                       (Your code,
       forms, files)                       pipelines)
            |                                   |
            v                                   v
    Is type precision                  Use STRICT MODE
    critical?                          (bugs should fail)
            |
      +-----+-----+
      |           |
     YES          NO
      |           |
      v           v
   STRICT      LAX MODE
   MODE        (user-friendly)
```

---

## Performance Implications

### Strict vs Lax Performance

```
+------------------------------------------------------------------+
|                  PERFORMANCE COMPARISON                           |
+------------------------------------------------------------------+
|                                                                    |
|    Operation                    Lax Mode      Strict Mode         |
|    ─────────                    ────────      ───────────         |
|                                                                    |
|    Type matches (int -> int)    Fast          Fast                |
|    Type coercion (str -> int)   Slower        N/A (fails)         |
|    Validation check             Standard      Standard            |
|                                                                    |
|    OVERALL: Strict mode is slightly FASTER when types match       |
|             because it skips coercion logic                       |
|                                                                    |
+------------------------------------------------------------------+
```

### Why Strict Can Be Faster

```python
# Lax mode processing flow:
# 1. Check if input is int        -> No
# 2. Check if input is coercible  -> Yes (it's a string)
# 3. Attempt coercion             -> "123" -> 123
# 4. Return coerced value

# Strict mode processing flow:
# 1. Check if input is int        -> No
# 2. Raise ValidationError        -> Done
# OR
# 1. Check if input is int        -> Yes
# 2. Return value                 -> Done
```

### Benchmark Insight

```
Input: {"user_id": 123, "name": "Alice"}  (correct types)

LAX MODE:    ~1.00x baseline
STRICT MODE: ~0.95x baseline (5% faster)

Input: {"user_id": "123", "name": "Alice"}  (needs coercion)

LAX MODE:    ~1.10x baseline (coercion overhead)
STRICT MODE: Fails (no performance comparison)
```

---

## Combining Approaches

### Mixed Strictness Strategy

```python
from pydantic import BaseModel, Field, StrictInt

class HybridModel(BaseModel):
    # Critical fields: strict
    account_id: StrictInt
    transaction_amount: int = Field(strict=True)
    
    # User-facing fields: lax
    display_name: str
    preferences: dict
```

### Hierarchy of Strictness

```
STRICTNESS PRIORITY (highest to lowest):

1. StrictInt, StrictStr, etc.     (always strict)
         |
         v
2. Field(strict=True/False)       (overrides model config)
         |
         v
3. model_config strict=True       (model-wide default)
         |
         v
4. model_validate(strict=True)    (runtime override)
         |
         v
5. Default lax mode               (if nothing specified)
```

---

## Common Patterns

### Pattern 1: Strict Internal, Lax External

```python
from pydantic import BaseModel, ConfigDict

class InternalUser(BaseModel):
    """For internal data processing - strict."""
    model_config = ConfigDict(strict=True)
    
    user_id: int
    balance: float

class APIUser(BaseModel):
    """For API responses - lax for flexibility."""
    user_id: int
    balance: float
    
# Internal processing
def process_internal(data: dict) -> InternalUser:
    return InternalUser.model_validate(data)  # Strict

# API handling
def handle_api_request(data: dict) -> APIUser:
    return APIUser.model_validate(data)  # Lax
```

### Pattern 2: Runtime Mode Selection

```python
from pydantic import BaseModel

class FlexibleModel(BaseModel):
    value: int
    name: str

def validate_data(data: dict, strict: bool = False):
    """Validate with configurable strictness."""
    return FlexibleModel.model_validate(data, strict=strict)

# Development: strict for catching bugs
dev_result = validate_data({"value": "123", "name": "test"}, strict=True)

# Production API: lax for user-friendliness
prod_result = validate_data({"value": "123", "name": "test"}, strict=False)
```

---

## Summary

```
+------------------------------------------------------------------+
|                    STRICT MODE SUMMARY                            |
+------------------------------------------------------------------+
|                                                                    |
|    KEY CONCEPTS                                                    |
|    ────────────                                                    |
|    - Lax mode (default): Coerces compatible types                 |
|    - Strict mode: Requires exact type matches                     |
|                                                                    |
|    THREE WAYS TO ENABLE                                           |
|    ────────────────────                                           |
|    1. Field(strict=True)         Per-field                        |
|    2. model_config strict=True   Per-model                        |
|    3. model_validate(strict=T)   Per-validation                   |
|                                                                    |
|    STRICT TYPES                                                    |
|    ────────────                                                    |
|    StrictInt, StrictStr, StrictFloat, StrictBool, StrictBytes     |
|                                                                    |
|    WHEN TO USE                                                     |
|    ────────────                                                    |
|    Strict: Internal APIs, type-critical, debugging                |
|    Lax: External input, forms, user-friendly APIs                 |
|                                                                    |
|    PERFORMANCE                                                     |
|    ───────────                                                     |
|    Strict mode is slightly faster when types already match        |
|                                                                    |
+------------------------------------------------------------------+
```

---

## Next Steps

- Practice with the companion notebook: `_12_strict_mode.ipynb`
- Next module: [Error Handling](_13_error_handling.md)
