# Module 04: Field Constraints

---

## Table of Contents
- [Overview](#overview)
- [The Field() Function](#the-field-function)
- [Numeric Constraints](#numeric-constraints)
- [String Constraints](#string-constraints)
- [Collection Constraints](#collection-constraints)
- [Annotated Types](#annotated-types)
- [Constrained Types (Legacy)](#constrained-types-legacy)
- [Default Values](#default-values)
- [Field Descriptions and Examples](#field-descriptions-and-examples)
- [Constraint Reference Table](#constraint-reference-table)
- [Common Patterns](#common-patterns)

---

## Overview

Field constraints allow you to add validation rules beyond simple type checking. Pydantic v2 provides powerful ways to ensure your data meets specific requirements.

### The Constraint Hierarchy

```
+------------------------------------------------------------------+
|                    DATA VALIDATION LAYERS                         |
+------------------------------------------------------------------+
|                                                                   |
|   Layer 1: TYPE CHECKING                                          |
|   +----------------------------------------------------------+   |
|   |  age: int   ->   Must be an integer (or coercible)       |   |
|   +----------------------------------------------------------+   |
|                              |                                    |
|                              v                                    |
|   Layer 2: FIELD CONSTRAINTS                                      |
|   +----------------------------------------------------------+   |
|   |  age: int = Field(ge=0, le=150)                          |   |
|   |  -> Must be >= 0 AND <= 150                              |   |
|   +----------------------------------------------------------+   |
|                              |                                    |
|                              v                                    |
|   Layer 3: CUSTOM VALIDATORS                                      |
|   +----------------------------------------------------------+   |
|   |  @field_validator('age')                                 |   |
|   |  -> Custom business logic                                |   |
|   +----------------------------------------------------------+   |
|                                                                   |
+------------------------------------------------------------------+
```

### Why Use Constraints?

```
+------------------------+     +---------------------------+
|   WITHOUT CONSTRAINTS  |     |    WITH CONSTRAINTS       |
+------------------------+     +---------------------------+
|                        |     |                           |
|  class Product:        |     |  class Product(BaseModel):|
|      price: float      |     |      price: float = Field(|
|                        |     |          gt=0,            |
|  # Price could be:     |     |          le=10000         |
|  # -5.00  (invalid!)   |     |      )                    |
|  # 0      (invalid!)   |     |                           |
|  # 999999 (too high?)  |     |  # Price MUST be:         |
|                        |     |  # > 0 AND <= 10000       |
+------------------------+     +---------------------------+
```

---

## The Field() Function

`Field()` is the primary way to add constraints and metadata to model fields in Pydantic v2.

### Basic Syntax

```python
from pydantic import BaseModel, Field

class Product(BaseModel):
    name: str = Field(...)           # Required field with constraints
    price: float = Field(default=0)  # Optional field with default
    quantity: int = Field(0)         # Shorthand: default as first positional arg
```

### Field() Parameters Overview

```
+------------------------------------------------------------------+
|                    FIELD() PARAMETERS                             |
+------------------------------------------------------------------+
|                                                                   |
|   VALIDATION PARAMETERS                                           |
|   +----------------------------------------------------------+   |
|   |  gt, ge, lt, le      - Numeric comparisons               |   |
|   |  multiple_of         - Must be multiple of value         |   |
|   |  min_length          - Minimum length (str/list)         |   |
|   |  max_length          - Maximum length (str/list)         |   |
|   |  pattern             - Regex pattern (strings)           |   |
|   |  strict              - Disable type coercion             |   |
|   +----------------------------------------------------------+   |
|                                                                   |
|   DEFAULT VALUE PARAMETERS                                        |
|   +----------------------------------------------------------+   |
|   |  default             - Static default value              |   |
|   |  default_factory     - Callable for mutable defaults     |   |
|   +----------------------------------------------------------+   |
|                                                                   |
|   DOCUMENTATION PARAMETERS                                        |
|   +----------------------------------------------------------+   |
|   |  title               - Field title for schema            |   |
|   |  description         - Field description                 |   |
|   |  examples            - Example values for docs           |   |
|   |  json_schema_extra   - Additional JSON schema props      |   |
|   +----------------------------------------------------------+   |
|                                                                   |
|   SERIALIZATION PARAMETERS                                        |
|   +----------------------------------------------------------+   |
|   |  alias               - Alternative name for input        |   |
|   |  validation_alias    - Alias for validation only         |   |
|   |  serialization_alias - Alias for serialization only      |   |
|   |  exclude             - Exclude from serialization        |   |
|   +----------------------------------------------------------+   |
|                                                                   |
+------------------------------------------------------------------+
```

### Required Fields with Field()

```python
from pydantic import BaseModel, Field

class User(BaseModel):
    # Three ways to mark a field as required:
    
    name: str                        # Method 1: No default value
    email: str = Field()             # Method 2: Field() with no default
    username: str = Field(...)       # Method 3: Ellipsis (explicit required)
```

---

## Numeric Constraints

Pydantic provides precise control over numeric values.

### Constraint Operators

```
+-------------------+------------------+-------------------------+
|    Constraint     |    Meaning       |    Mathematical         |
+-------------------+------------------+-------------------------+
|    gt=5           |  Greater than    |    value > 5            |
|    ge=5           |  Greater or eq   |    value >= 5           |
|    lt=10          |  Less than       |    value < 10           |
|    le=10          |  Less or equal   |    value <= 10          |
|    multiple_of=5  |  Divisible by    |    value % 5 == 0       |
+-------------------+------------------+-------------------------+
```

### Visual Number Line Examples

```
gt=0, lt=100  (exclusive bounds)
|---(0)---------------------------------------------(100)---|
      ^                                               ^
      |  Valid: 0.001 to 99.999                       |
      +-----------------------------------------------+

ge=0, le=100  (inclusive bounds)
|---[0]==============================================[100]---|
      ^                                               ^
      |  Valid: 0 to 100 (including endpoints)        |
      +-----------------------------------------------+

ge=0, lt=100  (mixed bounds)
|---[0]----------------------------------------------(100)---|
      ^                                               ^
      |  Valid: 0 to 99.999                           |
      +-----------------------------------------------+
```

### Integer Constraints

```python
from pydantic import BaseModel, Field

class Person(BaseModel):
    # Age: must be 0-150 (inclusive)
    age: int = Field(ge=0, le=150)
    
    # Quantity: must be positive (> 0)
    quantity: int = Field(gt=0)
    
    # Even numbers only
    even_number: int = Field(multiple_of=2)
    
    # Port number: valid range
    port: int = Field(ge=1, le=65535)
    
    # Percentage: 0-100
    percentage: int = Field(ge=0, le=100)
```

### Float Constraints

```python
from pydantic import BaseModel, Field

class Product(BaseModel):
    # Price: must be positive
    price: float = Field(gt=0)
    
    # Discount: 0% to 100%
    discount: float = Field(ge=0, le=100)
    
    # Rating: 0.0 to 5.0
    rating: float = Field(ge=0, le=5)
    
    # Tax rate: typical values
    tax_rate: float = Field(ge=0, lt=1)  # 0.0 to 0.999...
```

### Combining Multiple Constraints

```python
from pydantic import BaseModel, Field

class OrderItem(BaseModel):
    # Price: positive and reasonable
    price: float = Field(gt=0, le=1_000_000)
    
    # Quantity: positive integer, max 1000
    quantity: int = Field(gt=0, le=1000)
    
    # Discount: percentage, multiples of 5
    discount_percent: int = Field(
        ge=0,
        le=100,
        multiple_of=5  # 0, 5, 10, 15, ... 100
    )
```

### Validation Error Examples

```python
from pydantic import BaseModel, Field, ValidationError

class Score(BaseModel):
    value: int = Field(ge=0, le=100)

# Valid
score = Score(value=85)  # OK

# Invalid - too low
try:
    Score(value=-5)
except ValidationError as e:
    print(e)
    # value
    #   Input should be greater than or equal to 0

# Invalid - too high
try:
    Score(value=150)
except ValidationError as e:
    print(e)
    # value
    #   Input should be less than or equal to 100
```

---

## String Constraints

Control string length and format with built-in constraints.

### String Constraint Types

```
+------------------------------------------------------------------+
|                    STRING CONSTRAINTS                             |
+------------------------------------------------------------------+
|                                                                   |
|   LENGTH CONSTRAINTS                                              |
|   +----------------------------------------------------------+   |
|   |                                                          |   |
|   |  min_length=3     "ab"    -> FAIL                        |   |
|   |                   "abc"   -> PASS                        |   |
|   |                                                          |   |
|   |  max_length=5     "hello" -> PASS                        |   |
|   |                   "hello!" -> FAIL                       |   |
|   |                                                          |   |
|   +----------------------------------------------------------+   |
|                                                                   |
|   PATTERN CONSTRAINT (REGEX)                                      |
|   +----------------------------------------------------------+   |
|   |                                                          |   |
|   |  pattern=r'^\d{5}$'   "12345"  -> PASS                   |   |
|   |                       "1234"   -> FAIL                   |   |
|   |                       "123456" -> FAIL                   |   |
|   |                                                          |   |
|   +----------------------------------------------------------+   |
|                                                                   |
+------------------------------------------------------------------+
```

### Length Constraints

```python
from pydantic import BaseModel, Field

class User(BaseModel):
    # Username: 3-20 characters
    username: str = Field(min_length=3, max_length=20)
    
    # Password: at least 8 characters
    password: str = Field(min_length=8)
    
    # Bio: optional, max 500 characters
    bio: str = Field(default="", max_length=500)
    
    # Exactly 2 characters (country code)
    country_code: str = Field(min_length=2, max_length=2)
```

### Pattern (Regex) Constraints

```python
from pydantic import BaseModel, Field

class Contact(BaseModel):
    # Email pattern (simplified)
    email: str = Field(
        pattern=r'^[\w\.-]+@[\w\.-]+\.\w+$'
    )
    
    # Phone: digits only, 10-15 characters
    phone: str = Field(
        pattern=r'^\d{10,15}$'
    )
    
    # US ZIP code: 5 digits or 5+4 format
    zip_code: str = Field(
        pattern=r'^\d{5}(-\d{4})?$'
    )
    
    # Alphanumeric code: letters and numbers only
    code: str = Field(
        pattern=r'^[a-zA-Z0-9]+$'
    )
```

### Common Regex Patterns Reference

```
+------------------------+--------------------------------+---------------------------+
|      Pattern Name      |           Regex                |        Examples           |
+------------------------+--------------------------------+---------------------------+
| Alphanumeric           | ^[a-zA-Z0-9]+$                 | abc123, ABC, 123          |
| Alpha only             | ^[a-zA-Z]+$                    | Hello, abc                |
| Digits only            | ^\d+$                          | 12345, 0                  |
| Email (simple)         | ^[\w\.-]+@[\w\.-]+\.\w+$       | user@example.com          |
| US Phone               | ^\d{3}-\d{3}-\d{4}$            | 123-456-7890              |
| US ZIP                 | ^\d{5}(-\d{4})?$               | 12345, 12345-6789         |
| URL slug               | ^[a-z0-9]+(-[a-z0-9]+)*$       | my-blog-post              |
| UUID                   | ^[0-9a-f]{8}-[0-9a-f]{4}-...   | 123e4567-e89b-...         |
| ISO Date               | ^\d{4}-\d{2}-\d{2}$            | 2024-01-15                |
| Hex color              | ^#[0-9A-Fa-f]{6}$              | #FF5733                   |
+------------------------+--------------------------------+---------------------------+
```

### Combining Length and Pattern

```python
from pydantic import BaseModel, Field

class Product(BaseModel):
    # SKU: exactly 8 alphanumeric characters
    sku: str = Field(
        min_length=8,
        max_length=8,
        pattern=r'^[A-Z0-9]+$'
    )
    
    # Slug: 3-50 characters, lowercase with hyphens
    slug: str = Field(
        min_length=3,
        max_length=50,
        pattern=r'^[a-z0-9]+(-[a-z0-9]+)*$'
    )
```

---

## Collection Constraints

Apply constraints to lists, sets, and other collections.

### List Constraints

```
+------------------------------------------------------------------+
|                    LIST CONSTRAINTS                               |
+------------------------------------------------------------------+
|                                                                   |
|   min_length / max_length apply to collection SIZE                |
|                                                                   |
|   tags: list[str] = Field(min_length=1, max_length=5)             |
|                                                                   |
|   []                    -> FAIL (need at least 1)                 |
|   ["python"]            -> PASS                                   |
|   ["a", "b", "c"]       -> PASS                                   |
|   ["a","b","c","d","e"] -> PASS (exactly 5)                       |
|   ["1","2","3","4","5","6"] -> FAIL (max is 5)                    |
|                                                                   |
+------------------------------------------------------------------+
```

### List Examples

```python
from pydantic import BaseModel, Field

class Article(BaseModel):
    # Tags: at least 1, max 10
    tags: list[str] = Field(min_length=1, max_length=10)
    
    # Categories: exactly 1-3 categories
    categories: list[str] = Field(min_length=1, max_length=3)
    
    # Optional images: 0-5 allowed
    images: list[str] = Field(default_factory=list, max_length=5)
```

### Nested Constraints (List Items)

```python
from typing import Annotated
from pydantic import BaseModel, Field

class Survey(BaseModel):
    # List of scores, each score 1-5
    ratings: list[Annotated[int, Field(ge=1, le=5)]]
    
    # List of tags, each tag 2-20 characters
    tags: list[Annotated[str, Field(min_length=2, max_length=20)]]
```

### Set and Dict Constraints

```python
from pydantic import BaseModel, Field

class UserPreferences(BaseModel):
    # Set of unique interests: 1-10 items
    interests: set[str] = Field(min_length=1, max_length=10)
    
    # Dict with limited entries
    # Note: min_length/max_length apply to number of keys
    metadata: dict[str, str] = Field(
        default_factory=dict,
        max_length=20
    )
```

---

## Annotated Types

Pydantic v2 recommends using `Annotated` for cleaner constraint syntax.

### What is Annotated?

```
+------------------------------------------------------------------+
|                    ANNOTATED EXPLAINED                            |
+------------------------------------------------------------------+
|                                                                   |
|   from typing import Annotated                                    |
|   from pydantic import Field                                      |
|                                                                   |
|   # Traditional syntax                                            |
|   age: int = Field(ge=0, le=150)                                  |
|                                                                   |
|   # Annotated syntax                                              |
|   age: Annotated[int, Field(ge=0, le=150)]                        |
|                                                                   |
|   +----------------------------------------------------------+   |
|   |  Annotated[   int   ,   Field(ge=0, le=150)   ]          |   |
|   |              ^               ^                            |   |
|   |              |               |                            |   |
|   |           Base Type      Metadata (constraints)           |   |
|   +----------------------------------------------------------+   |
|                                                                   |
+------------------------------------------------------------------+
```

### Benefits of Annotated

```
+------------------------+------------------------------------------+
|       BENEFIT          |              EXPLANATION                  |
+------------------------+------------------------------------------+
| Reusable Types         | Define once, use in multiple models      |
| Cleaner Separation     | Type info separate from default values   |
| Better IDE Support     | Type checkers understand the base type   |
| Composable             | Can combine multiple annotations         |
+------------------------+------------------------------------------+
```

### Creating Reusable Type Aliases

```python
from typing import Annotated
from pydantic import BaseModel, Field

# Define reusable constrained types
PositiveInt = Annotated[int, Field(gt=0)]
Percentage = Annotated[float, Field(ge=0, le=100)]
NonEmptyStr = Annotated[str, Field(min_length=1)]
Email = Annotated[str, Field(pattern=r'^[\w\.-]+@[\w\.-]+\.\w+$')]
Username = Annotated[str, Field(min_length=3, max_length=20, pattern=r'^[a-zA-Z0-9_]+$')]

# Use in models
class User(BaseModel):
    id: PositiveInt
    username: Username
    email: Email
    score: Percentage = 0.0


class Product(BaseModel):
    id: PositiveInt
    name: NonEmptyStr
    price: Annotated[float, Field(gt=0)]
    discount: Percentage = 0.0
```

### Annotated with Default Values

```python
from typing import Annotated
from pydantic import BaseModel, Field

# Type alias without default
PositiveInt = Annotated[int, Field(gt=0)]

class Item(BaseModel):
    # Required field using type alias
    id: PositiveInt
    
    # Optional field with default (default specified separately)
    quantity: PositiveInt = 1
    
    # Alternative: include description in Annotated, default separate
    price: Annotated[float, Field(gt=0, description="Price in USD")] = 0.0
```

### Combining Multiple Annotations

```python
from typing import Annotated
from pydantic import BaseModel, Field
from pydantic.functional_validators import AfterValidator

def must_be_title_case(v: str) -> str:
    if v != v.title():
        raise ValueError('must be title case')
    return v

# Combine Field constraints with custom validator
TitleCaseName = Annotated[
    str,
    Field(min_length=1, max_length=100),
    AfterValidator(must_be_title_case)
]

class Person(BaseModel):
    name: TitleCaseName  # "John Doe" OK, "john doe" FAIL
```

---

## Constrained Types (Legacy)

Pydantic v1 introduced constrained types like `conint`, `constr`, `confloat`. While still available in v2 for backwards compatibility, `Annotated` is preferred.

### Legacy Types Reference

```
+------------------------------------------------------------------+
|                CONSTRAINED TYPES (LEGACY)                         |
+------------------------------------------------------------------+
|                                                                   |
|   from pydantic import conint, constr, confloat, conlist          |
|                                                                   |
|   PREFERRED (v2)              LEGACY (v1 style)                   |
|   ─────────────────────       ─────────────────────               |
|   Annotated[int, Field(       conint(                             |
|       gt=0, le=100                gt=0, le=100                    |
|   )]                          )                                   |
|                                                                   |
|   Annotated[str, Field(       constr(                             |
|       min_length=1,               min_length=1,                   |
|       max_length=100              max_length=100                  |
|   )]                          )                                   |
|                                                                   |
+------------------------------------------------------------------+
```

### conint - Constrained Integer

```python
from pydantic import BaseModel, conint

class LegacyExample(BaseModel):
    # Positive integer
    positive: conint(gt=0)
    
    # Age range
    age: conint(ge=0, le=150)
    
    # Even numbers only
    even: conint(multiple_of=2)
    
    # Strict (no coercion from string)
    strict_int: conint(strict=True)
```

### constr - Constrained String

```python
from pydantic import BaseModel, constr

class LegacyStringExample(BaseModel):
    # Length constraints
    username: constr(min_length=3, max_length=20)
    
    # Pattern matching
    zip_code: constr(pattern=r'^\d{5}$')
    
    # Auto-strip whitespace
    name: constr(strip_whitespace=True)
    
    # Convert to lowercase
    code: constr(to_lower=True)
    
    # Convert to uppercase
    country: constr(to_upper=True)
```

### confloat - Constrained Float

```python
from pydantic import BaseModel, confloat

class LegacyFloatExample(BaseModel):
    # Positive price
    price: confloat(gt=0)
    
    # Percentage
    rate: confloat(ge=0, le=1)
    
    # Multiple of
    quantity: confloat(multiple_of=0.5)
```

### conlist - Constrained List

```python
from pydantic import BaseModel, conlist

class LegacyListExample(BaseModel):
    # List of strings, 1-5 items
    tags: conlist(str, min_length=1, max_length=5)
    
    # List of integers with constraints
    scores: conlist(int, min_length=1)
```

### Migration: Legacy to Modern

```python
# LEGACY STYLE (v1)
from pydantic import BaseModel, conint, constr

class OldUser(BaseModel):
    age: conint(ge=0, le=150)
    name: constr(min_length=1, max_length=100)


# MODERN STYLE (v2) - PREFERRED
from typing import Annotated
from pydantic import BaseModel, Field

class NewUser(BaseModel):
    age: Annotated[int, Field(ge=0, le=150)]
    name: Annotated[str, Field(min_length=1, max_length=100)]
```

---

## Default Values

Understanding the difference between default values and Field(default=...).

### Default Value Patterns

```
+------------------------------------------------------------------+
|                    DEFAULT VALUE PATTERNS                         |
+------------------------------------------------------------------+
|                                                                   |
|   SIMPLE DEFAULT (immutable types)                                |
|   +----------------------------------------------------------+   |
|   |  name: str = "Unknown"                                   |   |
|   |  age: int = 0                                            |   |
|   |  active: bool = True                                     |   |
|   +----------------------------------------------------------+   |
|                                                                   |
|   FIELD DEFAULT (with constraints)                                |
|   +----------------------------------------------------------+   |
|   |  age: int = Field(default=0, ge=0)                       |   |
|   |  name: str = Field(default="Unknown", min_length=1)      |   |
|   +----------------------------------------------------------+   |
|                                                                   |
|   DEFAULT FACTORY (mutable types - REQUIRED!)                     |
|   +----------------------------------------------------------+   |
|   |  tags: list[str] = Field(default_factory=list)           |   |
|   |  metadata: dict = Field(default_factory=dict)            |   |
|   |  created: datetime = Field(default_factory=datetime.now) |   |
|   +----------------------------------------------------------+   |
|                                                                   |
+------------------------------------------------------------------+
```

### Why Use default_factory?

```
+------------------------------------------------------------------+
|                    MUTABLE DEFAULT DANGER                         |
+------------------------------------------------------------------+
|                                                                   |
|   WRONG - Mutable default shared across instances!                |
|   +----------------------------------------------------------+   |
|   |  class Bad(BaseModel):                                   |   |
|   |      items: list = []  # DANGER! Same list for all!      |   |
|   +----------------------------------------------------------+   |
|                                                                   |
|   RIGHT - Factory creates new list for each instance              |
|   +----------------------------------------------------------+   |
|   |  class Good(BaseModel):                                  |   |
|   |      items: list = Field(default_factory=list)           |   |
|   +----------------------------------------------------------+   |
|                                                                   |
|   Note: Pydantic actually handles this correctly, but using       |
|   default_factory is the explicit, safe pattern.                  |
|                                                                   |
+------------------------------------------------------------------+
```

### Default Value Examples

```python
from datetime import datetime
from pydantic import BaseModel, Field


class Article(BaseModel):
    # Simple defaults
    title: str = "Untitled"
    published: bool = False
    views: int = 0
    
    # Field with default AND constraints
    rating: float = Field(default=0.0, ge=0, le=5)
    
    # Default factory for mutable types
    tags: list[str] = Field(default_factory=list)
    metadata: dict[str, str] = Field(default_factory=dict)
    
    # Dynamic default using factory
    created_at: datetime = Field(default_factory=datetime.now)
    

# Usage
article = Article(title="My Post")
print(article.tags)      # []  (new empty list)
print(article.views)     # 0
print(article.created_at)  # Current timestamp
```

### Default Factory with Custom Functions

```python
from pydantic import BaseModel, Field
import uuid

def generate_id() -> str:
    return str(uuid.uuid4())

def default_config() -> dict:
    return {
        "theme": "light",
        "language": "en",
        "notifications": True
    }

class User(BaseModel):
    id: str = Field(default_factory=generate_id)
    settings: dict = Field(default_factory=default_config)


# Each instance gets unique ID and fresh config
user1 = User()
user2 = User()
print(user1.id != user2.id)  # True - different UUIDs
```

---

## Field Descriptions and Examples

Add documentation directly to your model fields for auto-generated schemas.

### Documentation Parameters

```
+------------------------------------------------------------------+
|                FIELD DOCUMENTATION PARAMETERS                     |
+------------------------------------------------------------------+
|                                                                   |
|   title           Short title for the field                       |
|   description     Longer description/explanation                  |
|   examples        List of example values                          |
|   json_schema_extra   Additional JSON Schema properties           |
|   deprecated      Mark field as deprecated                        |
|                                                                   |
+------------------------------------------------------------------+
```

### Adding Documentation

```python
from pydantic import BaseModel, Field


class Product(BaseModel):
    name: str = Field(
        title="Product Name",
        description="The display name of the product",
        examples=["Widget Pro", "Gadget X"],
        min_length=1,
        max_length=100
    )
    
    price: float = Field(
        title="Price",
        description="Product price in USD. Must be positive.",
        examples=[9.99, 29.99, 99.99],
        gt=0
    )
    
    sku: str = Field(
        title="SKU",
        description="Stock Keeping Unit - unique product identifier",
        examples=["PROD-001", "WIDG-PRO-2024"],
        pattern=r'^[A-Z]+-[A-Z0-9-]+$'
    )
    
    quantity: int = Field(
        default=0,
        title="Quantity",
        description="Number of items in stock",
        examples=[0, 10, 100],
        ge=0
    )
```

### Generated JSON Schema

```python
import json

# View the generated schema
schema = Product.model_json_schema()
print(json.dumps(schema, indent=2))
```

Output:
```json
{
  "title": "Product",
  "type": "object",
  "properties": {
    "name": {
      "title": "Product Name",
      "description": "The display name of the product",
      "examples": ["Widget Pro", "Gadget X"],
      "minLength": 1,
      "maxLength": 100,
      "type": "string"
    },
    "price": {
      "title": "Price",
      "description": "Product price in USD. Must be positive.",
      "examples": [9.99, 29.99, 99.99],
      "exclusiveMinimum": 0,
      "type": "number"
    }
  },
  "required": ["name", "price", "sku"]
}
```

### json_schema_extra for Custom Properties

```python
from pydantic import BaseModel, Field


class Config(BaseModel):
    api_key: str = Field(
        description="API authentication key",
        json_schema_extra={
            "format": "password",
            "writeOnly": True,
            "x-env-var": "API_KEY"
        }
    )
    
    log_level: str = Field(
        default="INFO",
        description="Logging verbosity level",
        json_schema_extra={
            "enum": ["DEBUG", "INFO", "WARNING", "ERROR"],
            "x-category": "logging"
        }
    )
```

### Deprecated Fields

```python
from pydantic import BaseModel, Field
import warnings


class User(BaseModel):
    name: str
    
    # Deprecated field - will show in schema
    username: str | None = Field(
        default=None,
        deprecated=True,
        description="Use 'name' instead. Will be removed in v3.0"
    )
```

---

## Constraint Reference Table

### Complete Constraints Quick Reference

```
+========================+==================+===========================+=============================+
|      CONSTRAINT        |   APPLIES TO     |         EXAMPLE           |        DESCRIPTION          |
+========================+==================+===========================+=============================+
|                        |                  |                           |                             |
|  NUMERIC CONSTRAINTS   |                  |                           |                             |
|  ────────────────────  |                  |                           |                             |
|  gt                    | int, float       | Field(gt=0)               | Greater than (exclusive)    |
|  ge                    | int, float       | Field(ge=0)               | Greater than or equal       |
|  lt                    | int, float       | Field(lt=100)             | Less than (exclusive)       |
|  le                    | int, float       | Field(le=100)             | Less than or equal          |
|  multiple_of           | int, float       | Field(multiple_of=5)      | Must be divisible by value  |
|                        |                  |                           |                             |
+------------------------+------------------+---------------------------+-----------------------------+
|                        |                  |                           |                             |
|  STRING CONSTRAINTS    |                  |                           |                             |
|  ───────────────────   |                  |                           |                             |
|  min_length            | str              | Field(min_length=1)       | Minimum string length       |
|  max_length            | str              | Field(max_length=100)     | Maximum string length       |
|  pattern               | str              | Field(pattern=r'^\d+$')   | Regex pattern to match      |
|                        |                  |                           |                             |
+------------------------+------------------+---------------------------+-----------------------------+
|                        |                  |                           |                             |
|  COLLECTION CONSTRAINTS|                  |                           |                             |
|  ─────────────────────-|                  |                           |                             |
|  min_length            | list, set, dict  | Field(min_length=1)       | Minimum number of items     |
|  max_length            | list, set, dict  | Field(max_length=10)      | Maximum number of items     |
|                        |                  |                           |                             |
+------------------------+------------------+---------------------------+-----------------------------+
|                        |                  |                           |                             |
|  DEFAULT VALUES        |                  |                           |                             |
|  ──────────────────    |                  |                           |                             |
|  default               | any              | Field(default=0)          | Static default value        |
|  default_factory       | any              | Field(default_factory=    | Callable for mutable        |
|                        |                  |     list)                 |   defaults                  |
|                        |                  |                           |                             |
+------------------------+------------------+---------------------------+-----------------------------+
|                        |                  |                           |                             |
|  VALIDATION BEHAVIOR   |                  |                           |                             |
|  ────────────────────  |                  |                           |                             |
|  strict                | any              | Field(strict=True)        | Disable type coercion       |
|                        |                  |                           |                             |
+------------------------+------------------+---------------------------+-----------------------------+
|                        |                  |                           |                             |
|  DOCUMENTATION         |                  |                           |                             |
|  ─────────────────     |                  |                           |                             |
|  title                 | any              | Field(title="Name")       | Field title for schema      |
|  description           | any              | Field(description="...")  | Field description           |
|  examples              | any              | Field(examples=[1, 2])    | Example values              |
|  deprecated            | any              | Field(deprecated=True)    | Mark as deprecated          |
|  json_schema_extra     | any              | Field(json_schema_extra=  | Additional schema props     |
|                        |                  |     {"format": "email"})  |                             |
|                        |                  |                           |                             |
+========================+==================+===========================+=============================+
```

### Constraint Combinations Cheat Sheet

```
+------------------------------------------------------------------+
|                 COMMON CONSTRAINT PATTERNS                        |
+------------------------------------------------------------------+
|                                                                   |
|  POSITIVE INTEGER        Field(gt=0)                              |
|  NON-NEGATIVE INTEGER    Field(ge=0)                              |
|  PERCENTAGE (0-100)      Field(ge=0, le=100)                      |
|  PORT NUMBER             Field(ge=1, le=65535)                    |
|  RATING (1-5)            Field(ge=1, le=5)                        |
|                                                                   |
|  NON-EMPTY STRING        Field(min_length=1)                      |
|  LIMITED STRING          Field(min_length=1, max_length=100)      |
|  EMAIL (simple)          Field(pattern=r'^[\w\.-]+@[\w\.-]+\.\w+$')|
|  ALPHANUMERIC            Field(pattern=r'^[a-zA-Z0-9]+$')         |
|                                                                   |
|  NON-EMPTY LIST          Field(min_length=1)                      |
|  LIMITED LIST            Field(min_length=1, max_length=10)       |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Common Patterns

### Pattern: Creating Type Libraries

```python
# types.py - Reusable type definitions
from typing import Annotated
from pydantic import Field

# IDs
PositiveInt = Annotated[int, Field(gt=0)]
NonNegativeInt = Annotated[int, Field(ge=0)]

# Strings
NonEmptyStr = Annotated[str, Field(min_length=1)]
ShortStr = Annotated[str, Field(min_length=1, max_length=50)]
LongStr = Annotated[str, Field(min_length=1, max_length=500)]

# Domain-specific
Username = Annotated[str, Field(min_length=3, max_length=30, pattern=r'^[a-zA-Z0-9_]+$')]
Email = Annotated[str, Field(pattern=r'^[\w\.-]+@[\w\.-]+\.\w+$')]
PhoneNumber = Annotated[str, Field(pattern=r'^\+?[\d\s-]{10,20}$')]
Percentage = Annotated[float, Field(ge=0, le=100)]
Currency = Annotated[float, Field(ge=0, decimal_places=2)]
Rating = Annotated[float, Field(ge=0, le=5)]
```

### Pattern: API Request/Response Models

```python
from typing import Annotated
from pydantic import BaseModel, Field


class CreateUserRequest(BaseModel):
    username: Annotated[str, Field(
        min_length=3,
        max_length=30,
        pattern=r'^[a-zA-Z0-9_]+$',
        description="Unique username (letters, numbers, underscore)"
    )]
    email: Annotated[str, Field(
        pattern=r'^[\w\.-]+@[\w\.-]+\.\w+$',
        description="Valid email address"
    )]
    password: Annotated[str, Field(
        min_length=8,
        description="Password (minimum 8 characters)"
    )]
    age: Annotated[int, Field(
        ge=13,
        le=120,
        description="Age (must be 13 or older)"
    )] | None = None


class UserResponse(BaseModel):
    id: Annotated[int, Field(gt=0)]
    username: str
    email: str
    created_at: str
```

### Pattern: Configuration Models

```python
from typing import Annotated
from pydantic import BaseModel, Field


class DatabaseConfig(BaseModel):
    host: Annotated[str, Field(min_length=1)] = "localhost"
    port: Annotated[int, Field(ge=1, le=65535)] = 5432
    database: Annotated[str, Field(min_length=1, max_length=63)]
    username: Annotated[str, Field(min_length=1)]
    password: Annotated[str, Field(min_length=1)]
    pool_size: Annotated[int, Field(ge=1, le=100)] = 10
    timeout: Annotated[float, Field(gt=0, le=300)] = 30.0
```

---

## Summary

```
+------------------------------------------------------------------+
|                    MODULE 04 SUMMARY                              |
+------------------------------------------------------------------+
|                                                                   |
|  KEY CONCEPTS                                                     |
|  ────────────                                                     |
|  1. Field() adds constraints beyond basic type checking           |
|  2. Numeric: gt, ge, lt, le, multiple_of                          |
|  3. String: min_length, max_length, pattern                       |
|  4. Collections: min_length, max_length (for size)                |
|  5. Annotated[] is the modern way to define constrained types     |
|  6. default_factory for mutable default values                    |
|  7. Documentation via title, description, examples                |
|                                                                   |
|  BEST PRACTICES                                                   |
|  ──────────────                                                   |
|  - Use Annotated[] for reusable type definitions                  |
|  - Always use default_factory for lists, dicts, etc.              |
|  - Add descriptions for API documentation                         |
|  - Prefer modern syntax over legacy conint/constr                 |
|                                                                   |
|  NEXT UP                                                          |
|  ───────                                                          |
|  Module 05: Custom Validators - Complex validation logic          |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Quick Reference Card

```
+------------------------------------------------------------------+
|              FIELD CONSTRAINTS CHEAT SHEET                        |
+------------------------------------------------------------------+
|                                                                   |
|  IMPORTS                                                          |
|  from pydantic import BaseModel, Field                            |
|  from typing import Annotated                                     |
|                                                                   |
|  NUMERIC                                                          |
|  age: int = Field(ge=0, le=150)                                   |
|  price: float = Field(gt=0)                                       |
|  even: int = Field(multiple_of=2)                                 |
|                                                                   |
|  STRING                                                           |
|  name: str = Field(min_length=1, max_length=100)                  |
|  code: str = Field(pattern=r'^[A-Z]{3}$')                         |
|                                                                   |
|  COLLECTION                                                       |
|  tags: list[str] = Field(min_length=1, max_length=10)             |
|                                                                   |
|  ANNOTATED (RECOMMENDED)                                          |
|  PositiveInt = Annotated[int, Field(gt=0)]                        |
|  value: PositiveInt                                               |
|                                                                   |
|  DEFAULTS                                                         |
|  items: list = Field(default_factory=list)                        |
|  count: int = Field(default=0, ge=0)                              |
|                                                                   |
|  DOCUMENTATION                                                    |
|  Field(title="...", description="...", examples=[...])            |
|                                                                   |
+------------------------------------------------------------------+
```
