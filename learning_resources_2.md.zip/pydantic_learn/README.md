# 🎯 Pydantic Learning Course

> A comprehensive, step-by-step guide to mastering Pydantic - Python's most powerful data validation library

---

## 📚 Course Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                    PYDANTIC LEARNING PATH                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   📦 BASICS          →   🔧 INTERMEDIATE    →   🚀 ADVANCED    │
│   ─────────              ──────────────          ──────────     │
│   • Introduction         • Custom Validators     • Generics    │
│   • Basic Models         • Nested Models         • Strict Mode │
│   • Field Types          • Serialization         • JSON Schema │
│   • Constraints          • BaseSettings          • FastAPI     │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 📋 Course Modules

| # | Module | Description | Difficulty |
|---|--------|-------------|------------|
| 01 | [Introduction](_01_introduction.md) | What is Pydantic, why use it, installation | 🟢 Beginner |
| 02 | [Basic Models](_02_basic_models.md) | Creating your first models | 🟢 Beginner |
| 03 | [Field Types](_03_field_types.md) | Common field types and annotations | 🟢 Beginner |
| 04 | [Field Constraints](_04_field_constraints.md) | Validation constraints (gt, lt, regex, etc.) | 🟢 Beginner |
| 05 | [Custom Validators](_05_custom_validators.md) | Field and model validators | 🟡 Intermediate |
| 06 | [Nested Models](_06_nested_models.md) | Complex data structures | 🟡 Intermediate |
| 07 | [Model Configuration](_07_model_config.md) | Config class and model settings | 🟡 Intermediate |
| 08 | [Serialization](_08_serialization.md) | JSON, dict conversion, custom encoders | 🟡 Intermediate |
| 09 | [BaseSettings](_09_base_settings.md) | Environment variables and config management | 🟡 Intermediate |
| 10 | [Computed Fields](_10_computed_fields.md) | Dynamic and computed properties | 🟡 Intermediate |
| 11 | [Generic Models](_11_generic_models.md) | Using TypeVar and Generic | 🔴 Advanced |
| 12 | [Strict Mode](_12_strict_mode.md) | Type coercion and strict validation | 🔴 Advanced |
| 13 | [Error Handling](_13_error_handling.md) | ValidationError and custom messages | 🔴 Advanced |
| 14 | [JSON Schema](_14_json_schema.md) | Schema generation and OpenAPI | 🔴 Advanced |

---

## 🛠️ Prerequisites

```python
# Python 3.8+ required
python --version  # Should be 3.8 or higher

# Install Pydantic v2
pip install pydantic
pip install pydantic-settings  # For BaseSettings
```

---

## 📁 File Structure

```
pydantic_learn/
├── README.md                    # This file (Course Overview)
├── _01_introduction.md          # Theory + explanations
├── _01_introduction.ipynb       # Hands-on practice
├── _02_basic_models.md
├── _02_basic_models.ipynb
├── ... (and so on)
```

---

## 🎓 How to Use This Course

```
┌──────────────────────────────────────────────────────────────┐
│                     LEARNING WORKFLOW                        │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│    1️⃣  READ         2️⃣  CODE         3️⃣  EXPERIMENT        │
│    ──────────       ──────────       ─────────────          │
│    .md file         .ipynb file     Modify examples         │
│    (concepts)       (practice)      (explore edge cases)    │
│                                                              │
│              ↓              ↓              ↓                 │
│         Understand  →   Apply   →   Master                  │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

---

## ✨ What You'll Learn

By the end of this course, you'll be able to:

- ✅ Create robust data models with automatic validation
- ✅ Handle complex nested data structures
- ✅ Build type-safe configurations with environment variables
- ✅ Generate JSON schemas for API documentation
- ✅ Integrate Pydantic with FastAPI and other frameworks
- ✅ Handle validation errors gracefully
- ✅ Use advanced features like generics and strict mode

---

Happy Learning! 🚀
