# Module 14: JSON Schema Generation

## Overview

Pydantic models can automatically generate **JSON Schema** definitions, making them perfect for API documentation, validation specifications, and interoperability with other systems.

```
+------------------+                      +----------------------+
|  Pydantic Model  |  ───────────────►   |    JSON Schema       |
+------------------+    model_json_       +----------------------+
| class User:      |    schema()          | {                    |
|   name: str      |                      |   "type": "object",  |
|   age: int       |                      |   "properties": {    |
+------------------+                      |     "name": {...},   |
                                          |     "age": {...}     |
                                          |   }                  |
                                          | }                    |
                                          +----------------------+
```

---

## 1. Basic Schema Generation with `model_json_schema()`

The `model_json_schema()` class method generates a JSON Schema from your model.

### Model Definition

```python
from pydantic import BaseModel

class User(BaseModel):
    name: str
    age: int
    email: str
```

### Generated Schema

```python
User.model_json_schema()
```

```json
{
    "title": "User",
    "type": "object",
    "properties": {
        "name": {
            "title": "Name",
            "type": "string"
        },
        "age": {
            "title": "Age",
            "type": "integer"
        },
        "email": {
            "title": "Email",
            "type": "string"
        }
    },
    "required": ["name", "age", "email"]
}
```

---

## 2. JSON Schema Draft Version

Pydantic v2 generates schemas compliant with **JSON Schema Draft 2020-12** by default.

```python
from pydantic import BaseModel

class Product(BaseModel):
    id: int
    name: str

schema = Product.model_json_schema()
print(schema.get('$schema'))
# Output: None (schema URI not included by default)
```

### Specifying Schema Mode

```python
from pydantic import BaseModel

# Generate schema optimized for validation
schema_validation = Product.model_json_schema(mode='validation')

# Generate schema optimized for serialization
schema_serialization = Product.model_json_schema(mode='serialization')
```

```
+---------------------+----------------------------------+
|       Mode          |          Use Case                |
+---------------------+----------------------------------+
| 'validation'        | Input validation (default)       |
| 'serialization'     | Output/response schemas          |
+---------------------+----------------------------------+
```

---

## 3. Schema Customization with `Field()`

Use `Field()` to add metadata that appears in the generated schema.

### Model with Field Metadata

```python
from pydantic import BaseModel, Field

class Product(BaseModel):
    id: int = Field(
        title="Product ID",
        description="Unique identifier for the product",
        ge=1
    )
    name: str = Field(
        title="Product Name",
        description="Display name of the product",
        min_length=1,
        max_length=100
    )
    price: float = Field(
        title="Price",
        description="Product price in USD",
        gt=0,
        examples=[9.99, 19.99, 29.99]
    )
```

### Generated Schema

```json
{
    "title": "Product",
    "type": "object",
    "properties": {
        "id": {
            "title": "Product ID",
            "description": "Unique identifier for the product",
            "type": "integer",
            "minimum": 1
        },
        "name": {
            "title": "Product Name",
            "description": "Display name of the product",
            "type": "string",
            "minLength": 1,
            "maxLength": 100
        },
        "price": {
            "title": "Price",
            "description": "Product price in USD",
            "type": "number",
            "exclusiveMinimum": 0,
            "examples": [9.99, 19.99, 29.99]
        }
    },
    "required": ["id", "name", "price"]
}
```

---

## 4. `json_schema_extra` for Additional Properties

Add custom schema properties not covered by standard Field options.

### Using `json_schema_extra` in Field

```python
from pydantic import BaseModel, Field

class Config(BaseModel):
    timeout: int = Field(
        default=30,
        json_schema_extra={
            "deprecated": True,
            "x-custom-tag": "internal",
            "units": "seconds"
        }
    )
```

### Using `json_schema_extra` in Model Config

```python
from pydantic import BaseModel, ConfigDict

class APIResponse(BaseModel):
    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {"status": "success", "data": {"id": 1}},
                {"status": "error", "message": "Not found"}
            ],
            "x-api-version": "2.0"
        }
    )
    
    status: str
    data: dict | None = None
    message: str | None = None
```

### Using a Callable for Dynamic Schema

```python
from pydantic import BaseModel, ConfigDict

def add_metadata(schema: dict) -> None:
    """Modify schema in place."""
    schema['x-generated-at'] = '2024-01-01'
    schema['x-version'] = '1.0.0'
    # Add conditional logic based on schema content
    if 'email' in schema.get('properties', {}):
        schema['x-contains-pii'] = True

class User(BaseModel):
    model_config = ConfigDict(json_schema_extra=add_metadata)
    
    name: str
    email: str
```

---

## 5. Title and Description in Schema

### Model-Level Title and Description

```python
from pydantic import BaseModel, ConfigDict

class Order(BaseModel):
    """Represents a customer order in the system."""
    
    model_config = ConfigDict(
        title="CustomerOrder",  # Override class name as title
    )
    
    order_id: str
    total: float
```

**Note:** The docstring becomes the schema description automatically!

### Generated Schema

```json
{
    "title": "CustomerOrder",
    "description": "Represents a customer order in the system.",
    "type": "object",
    "properties": {
        "order_id": {
            "title": "Order Id",
            "type": "string"
        },
        "total": {
            "title": "Total",
            "type": "number"
        }
    },
    "required": ["order_id", "total"]
}
```

---

## 6. Examples in Schema

### Field-Level Examples

```python
from pydantic import BaseModel, Field

class Address(BaseModel):
    street: str = Field(
        examples=["123 Main St", "456 Oak Ave"]
    )
    city: str = Field(
        examples=["New York", "Los Angeles"]
    )
    zip_code: str = Field(
        examples=["10001", "90001"],
        pattern=r"^\d{5}(-\d{4})?$"
    )
```

### Model-Level Examples

```python
from pydantic import BaseModel, ConfigDict

class Person(BaseModel):
    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "name": "John Doe",
                    "age": 30,
                    "email": "john@example.com"
                },
                {
                    "name": "Jane Smith",
                    "age": 25,
                    "email": "jane@example.com"
                }
            ]
        }
    )
    
    name: str
    age: int
    email: str
```

---

## 7. Nested Model Schemas

Pydantic automatically handles nested models with `$defs` references.

### Nested Model Example

```python
from pydantic import BaseModel
from datetime import datetime

class Address(BaseModel):
    street: str
    city: str
    country: str

class Company(BaseModel):
    name: str
    address: Address

class Employee(BaseModel):
    name: str
    email: str
    company: Company
    hire_date: datetime
```

### Visual Schema Structure

```
Employee Schema
+------------------------------------------+
| title: "Employee"                        |
| properties:                              |
|   - name: string                         |
|   - email: string                        |
|   - company: { $ref: "#/$defs/Company" } |
|   - hire_date: string (format: date-time)|
+------------------------------------------+
           |
           | $defs
           v
+------------------+     +------------------+
| Company          |     | Address          |
| properties:      |     | properties:      |
|   - name: string |     |   - street       |
|   - address: ref |---->|   - city         |
+------------------+     |   - country      |
                         +------------------+
```

### Generated Schema (Simplified)

```json
{
    "title": "Employee",
    "type": "object",
    "properties": {
        "name": {"type": "string"},
        "email": {"type": "string"},
        "company": {"$ref": "#/$defs/Company"},
        "hire_date": {"type": "string", "format": "date-time"}
    },
    "$defs": {
        "Company": {
            "title": "Company",
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "address": {"$ref": "#/$defs/Address"}
            }
        },
        "Address": {
            "title": "Address",
            "type": "object",
            "properties": {
                "street": {"type": "string"},
                "city": {"type": "string"},
                "country": {"type": "string"}
            }
        }
    }
}
```

---

## 8. `$defs` and References

### How References Work

When the same model is used multiple times, Pydantic uses `$ref` to avoid duplication.

```python
from pydantic import BaseModel

class Tag(BaseModel):
    name: str
    color: str

class Article(BaseModel):
    title: str
    tags: list[Tag]
    featured_tag: Tag | None = None
```

```
Schema Structure:
+------------------------------------------+
| Article                                  |
|   tags: array of $ref -> Tag             |
|   featured_tag: $ref -> Tag (or null)    |
+------------------------------------------+
           |
           | References same definition
           v
+------------------------------------------+
| $defs.Tag                                |
|   name: string                           |
|   color: string                          |
+------------------------------------------+
```

### Controlling Reference Generation

```python
from pydantic import BaseModel
from pydantic.json_schema import GenerateJsonSchema

class CustomGenerateJsonSchema(GenerateJsonSchema):
    def generate(self, schema, mode='validation'):
        json_schema = super().generate(schema, mode=mode)
        # Customize the generated schema
        json_schema['$schema'] = 'https://json-schema.org/draft/2020-12/schema'
        return json_schema

class MyModel(BaseModel):
    name: str

schema = MyModel.model_json_schema(schema_generator=CustomGenerateJsonSchema)
```

---

## 9. OpenAPI Integration

Pydantic schemas integrate seamlessly with OpenAPI (Swagger) specifications.

### FastAPI Example

```python
from fastapi import FastAPI
from pydantic import BaseModel, Field

app = FastAPI()

class Item(BaseModel):
    """An item in the inventory."""
    
    name: str = Field(
        description="The item name",
        examples=["Widget"]
    )
    price: float = Field(
        description="Price in USD",
        gt=0,
        examples=[9.99]
    )
    quantity: int = Field(
        description="Available quantity",
        ge=0,
        examples=[100]
    )

@app.post("/items/")
async def create_item(item: Item) -> Item:
    return item
```

### OpenAPI Schema Output

```
FastAPI automatically generates:

/docs (Swagger UI)
+------------------------------------------+
| POST /items/                             |
| Request Body:                            |
|   {                                      |
|     "name": "Widget",                    |
|     "price": 9.99,                       |
|     "quantity": 100                      |
|   }                                      |
+------------------------------------------+

/openapi.json
+------------------------------------------+
| "components": {                          |
|   "schemas": {                           |
|     "Item": {                            |
|       "title": "Item",                   |
|       "description": "An item...",       |
|       "properties": {...}                |
|     }                                    |
|   }                                      |
| }                                        |
+------------------------------------------+
```

---

## 10. Customizing Schema Generation

### Custom Schema Generator Class

```python
from pydantic import BaseModel
from pydantic.json_schema import GenerateJsonSchema, JsonSchemaValue
from pydantic_core import CoreSchema

class CustomSchemaGenerator(GenerateJsonSchema):
    def generate(self, schema: CoreSchema, mode: str = 'validation') -> JsonSchemaValue:
        json_schema = super().generate(schema, mode=mode)
        
        # Add custom metadata
        json_schema['$id'] = 'https://example.com/schemas/my-schema'
        json_schema['$schema'] = 'https://json-schema.org/draft/2020-12/schema'
        
        return json_schema
    
    def str_schema(self, schema: CoreSchema) -> JsonSchemaValue:
        # Customize all string schemas
        result = super().str_schema(schema)
        result['x-custom-string'] = True
        return result

class User(BaseModel):
    name: str
    email: str

# Use custom generator
schema = User.model_json_schema(schema_generator=CustomSchemaGenerator)
```

### Using `__get_pydantic_json_schema__`

```python
from typing import Any, Annotated
from pydantic import BaseModel, GetJsonSchemaHandler
from pydantic.json_schema import JsonSchemaValue
from pydantic_core import CoreSchema

class CustomType:
    """A custom type with custom schema generation."""
    
    @classmethod
    def __get_pydantic_core_schema__(cls, source_type, handler):
        return handler(str)  # Validate as string
    
    @classmethod
    def __get_pydantic_json_schema__(
        cls, 
        schema: CoreSchema, 
        handler: GetJsonSchemaHandler
    ) -> JsonSchemaValue:
        return {
            'type': 'string',
            'format': 'custom-format',
            'x-custom-type': 'CustomType'
        }

class MyModel(BaseModel):
    custom_field: CustomType
```

---

## 11. Visual Model to Schema Transformation

### Complete Example

```python
from pydantic import BaseModel, Field, ConfigDict
from datetime import datetime
from enum import Enum

class Status(str, Enum):
    PENDING = "pending"
    ACTIVE = "active"
    COMPLETED = "completed"

class Task(BaseModel):
    """A task in the project management system."""
    
    model_config = ConfigDict(
        title="ProjectTask",
        json_schema_extra={
            "examples": [
                {
                    "id": 1,
                    "title": "Review PR",
                    "status": "pending",
                    "due_date": "2024-12-31T23:59:59"
                }
            ]
        }
    )
    
    id: int = Field(
        description="Unique task identifier",
        ge=1
    )
    title: str = Field(
        description="Task title",
        min_length=1,
        max_length=200
    )
    description: str | None = Field(
        default=None,
        description="Detailed task description"
    )
    status: Status = Field(
        default=Status.PENDING,
        description="Current task status"
    )
    due_date: datetime | None = Field(
        default=None,
        description="Task due date"
    )
    tags: list[str] = Field(
        default_factory=list,
        description="Task labels/tags"
    )
```

### Transformation Diagram

```
+----------------------------------+          +----------------------------------------+
|           Python Model           |          |            JSON Schema                 |
+----------------------------------+          +----------------------------------------+
|                                  |          | {                                      |
| class Task(BaseModel):           |          |   "$defs": {                           |
|   """A task in the project...""" |   ───►   |     "Status": {                        |
|                                  |          |       "enum": ["pending","active",...],|
|   model_config = ConfigDict(     |          |       "type": "string"                 |
|     title="ProjectTask",         |          |     }                                  |
|     json_schema_extra={...}      |          |   },                                   |
|   )                              |          |   "title": "ProjectTask",              |
|                                  |          |   "description": "A task in the...",   |
|   id: int = Field(ge=1)          |          |   "type": "object",                    |
|   title: str = Field(...)        |          |   "properties": {                      |
|   description: str | None        |          |     "id": {                            |
|   status: Status                 |          |       "type": "integer",               |
|   due_date: datetime | None      |          |       "minimum": 1,                    |
|   tags: list[str]                |          |       "description": "Unique task..."  |
|                                  |          |     },                                 |
+----------------------------------+          |     "title": {...},                    |
                                              |     "description": {...},              |
                                              |     "status": {"$ref": "#/$defs/..."},|
                                              |     "due_date": {...},                 |
                                              |     "tags": {"type": "array", ...}     |
                                              |   },                                   |
                                              |   "required": ["id", "title"],         |
                                              |   "examples": [...]                    |
                                              | }                                      |
                                              +----------------------------------------+
```

---

## 12. Quick Reference

### Type Mappings

| Python Type        | JSON Schema Type              |
|--------------------|-------------------------------|
| `str`              | `{"type": "string"}`          |
| `int`              | `{"type": "integer"}`         |
| `float`            | `{"type": "number"}`          |
| `bool`             | `{"type": "boolean"}`         |
| `list[T]`          | `{"type": "array", "items": ...}` |
| `dict[K, V]`       | `{"type": "object", ...}`     |
| `T \| None`        | `{"anyOf": [..., {"type": "null"}]}` |
| `datetime`         | `{"type": "string", "format": "date-time"}` |
| `Enum`             | `{"enum": [...], "type": "string"}` |
| `Literal['a','b']` | `{"enum": ["a", "b"]}`        |

### Common Field Options for Schema

```python
Field(
    title="...",              # JSON Schema title
    description="...",        # JSON Schema description
    examples=[...],           # JSON Schema examples
    deprecated=True,          # Mark as deprecated
    json_schema_extra={...},  # Additional properties
    
    # Numeric constraints
    ge=0, gt=0, le=100, lt=100, multiple_of=5,
    
    # String constraints
    min_length=1, max_length=100, pattern=r"^[a-z]+$",
    
    # Array constraints
    min_length=1, max_length=10  # For lists
)
```

---

## Summary

| Feature                  | Method/Property                        |
|--------------------------|----------------------------------------|
| Generate schema          | `Model.model_json_schema()`            |
| Add field metadata       | `Field(title=..., description=...)`    |
| Add custom properties    | `json_schema_extra={...}`              |
| Add examples             | `Field(examples=[...])` or config      |
| Customize generator      | `schema_generator=CustomGenerator`     |
| Control mode             | `mode='validation'` or `'serialization'` |
| Handle nested models     | Automatic via `$defs` and `$ref`       |

JSON Schema generation makes Pydantic models self-documenting and enables seamless integration with API frameworks, validation tools, and documentation generators.
