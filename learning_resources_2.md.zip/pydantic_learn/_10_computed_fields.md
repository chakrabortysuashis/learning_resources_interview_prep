# Module 10: Computed Fields

---

## Table of Contents
- [What are Computed Fields?](#what-are-computed-fields)
- [@property vs @computed_field](#property-vs-computed_field)
- [Basic @computed_field Usage](#basic-computed_field-usage)
- [When Computed Fields are Calculated](#when-computed-fields-are-calculated)
- [Computed Fields in Serialization](#computed-fields-in-serialization)
- [Computed Fields with Dependencies](#computed-fields-with-dependencies)
- [cached_property for Expensive Computations](#cached_property-for-expensive-computations)
- [Return Type Annotations](#return-type-annotations)
- [Advanced Patterns](#advanced-patterns)
- [Quick Reference](#quick-reference)

---

## What are Computed Fields?

**Computed fields** are properties whose values are derived from other fields in the model. Instead of storing data, they calculate their value on demand based on existing field values.

### The Problem Computed Fields Solve

```
+------------------------------------------------------------------+
|                    WITHOUT COMPUTED FIELDS                        |
+------------------------------------------------------------------+
|                                                                   |
|  class User(BaseModel):                                           |
|      first_name: str                                              |
|      last_name: str                                               |
|      full_name: str  # Must be passed manually!                   |
|                                                                   |
|  # Redundant and error-prone:                                     |
|  user = User(                                                     |
|      first_name="John",                                           |
|      last_name="Doe",                                             |
|      full_name="John Doe"  # Can get out of sync!                 |
|  )                                                                |
|                                                                   |
+------------------------------------------------------------------+

                              VS

+------------------------------------------------------------------+
|                    WITH COMPUTED FIELDS                           |
+------------------------------------------------------------------+
|                                                                   |
|  class User(BaseModel):                                           |
|      first_name: str                                              |
|      last_name: str                                               |
|                                                                   |
|      @computed_field                                              |
|      @property                                                    |
|      def full_name(self) -> str:                                  |
|          return f"{self.first_name} {self.last_name}"             |
|                                                                   |
|  # Automatically computed - always in sync!                       |
|  user = User(first_name="John", last_name="Doe")                  |
|  print(user.full_name)  # "John Doe"                              |
|                                                                   |
+------------------------------------------------------------------+
```

### Common Use Cases

```
+------------------------+    +------------------------+    +------------------------+
|    DERIVED VALUES      |    |    CALCULATIONS        |    |    TRANSFORMATIONS     |
+------------------------+    +------------------------+    +------------------------+
|                        |    |                        |    |                        |
|  full_name from        |    |  age from birthdate    |    |  uppercase name        |
|  first + last          |    |                        |    |                        |
|                        |    |  total from            |    |  formatted phone       |
|  display_name from     |    |  price * quantity      |    |  number                |
|  name + title          |    |                        |    |                        |
|                        |    |  discount_price from   |    |  slug from title       |
|  address from          |    |  price * (1-discount)  |    |                        |
|  street, city, zip     |    |                        |    |                        |
+------------------------+    +------------------------+    +------------------------+
```

---

## @property vs @computed_field

In Python, `@property` creates a computed attribute. Pydantic v2 introduces `@computed_field` to include these properties in serialization.

### Key Differences

```
+------------------------------------------------------------------+
|                    @property ONLY                                 |
+------------------------------------------------------------------+
|                                                                   |
|  class User(BaseModel):                                           |
|      first_name: str                                              |
|      last_name: str                                               |
|                                                                   |
|      @property                                                    |
|      def full_name(self) -> str:                                  |
|          return f"{self.first_name} {self.last_name}"             |
|                                                                   |
|  user = User(first_name="John", last_name="Doe")                  |
|  print(user.full_name)        # "John Doe" - Works!               |
|  print(user.model_dump())     # {'first_name': 'John',            |
|                               #  'last_name': 'Doe'}              |
|                               # full_name NOT included!           |
|                                                                   |
+------------------------------------------------------------------+

                              VS

+------------------------------------------------------------------+
|                @computed_field + @property                        |
+------------------------------------------------------------------+
|                                                                   |
|  class User(BaseModel):                                           |
|      first_name: str                                              |
|      last_name: str                                               |
|                                                                   |
|      @computed_field                                              |
|      @property                                                    |
|      def full_name(self) -> str:                                  |
|          return f"{self.first_name} {self.last_name}"             |
|                                                                   |
|  user = User(first_name="John", last_name="Doe")                  |
|  print(user.full_name)        # "John Doe" - Works!               |
|  print(user.model_dump())     # {'first_name': 'John',            |
|                               #  'last_name': 'Doe',              |
|                               #  'full_name': 'John Doe'}         |
|                               # full_name IS included!            |
|                                                                   |
+------------------------------------------------------------------+
```

### Comparison Table

| Feature | @property | @computed_field + @property |
|---------|-----------|----------------------------|
| Access as attribute | Yes | Yes |
| Included in `model_dump()` | No | Yes |
| Included in `model_dump_json()` | No | Yes |
| Included in JSON Schema | No | Yes |
| Can be excluded from serialization | N/A | Yes (with `repr=False`) |
| Requires return type annotation | No | Yes |

### When to Use Which

```
+------------------------------------------------------------------+
|                    DECISION TREE                                  |
+------------------------------------------------------------------+
|                                                                   |
|  Do you need the computed value in serialization output?          |
|                                                                   |
|                    /                    \                         |
|                   /                      \                        |
|                 YES                       NO                      |
|                  |                         |                      |
|                  v                         v                      |
|        Use @computed_field         Use @property only             |
|        + @property                 (internal use)                 |
|        (API responses,                                            |
|         JSON output)                                              |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Basic @computed_field Usage

### Syntax

```python
from pydantic import BaseModel, computed_field

class MyModel(BaseModel):
    field1: str
    field2: str

    @computed_field
    @property
    def derived_field(self) -> str:  # Return type is REQUIRED
        return f"{self.field1} {self.field2}"
```

### Important Notes

```
+------------------------------------------------------------------+
|                    DECORATOR ORDER MATTERS!                       |
+------------------------------------------------------------------+
|                                                                   |
|  CORRECT:                          INCORRECT:                     |
|  ---------                         -----------                    |
|  @computed_field                   @property                      |
|  @property        <-- property     @computed_field  <-- WRONG!    |
|  def method(self):    comes        def method(self):              |
|      ...              second           ...                        |
|                                                                   |
+------------------------------------------------------------------+
```

### Example: Full Name from First and Last

```python
from pydantic import BaseModel, computed_field

class Person(BaseModel):
    first_name: str
    last_name: str

    @computed_field
    @property
    def full_name(self) -> str:
        return f"{self.first_name} {self.last_name}"

    @computed_field
    @property
    def initials(self) -> str:
        return f"{self.first_name[0]}.{self.last_name[0]}."

# Usage
person = Person(first_name="Alice", last_name="Smith")
print(person.full_name)    # "Alice Smith"
print(person.initials)     # "A.S."
print(person.model_dump())
# {'first_name': 'Alice', 'last_name': 'Smith', 
#  'full_name': 'Alice Smith', 'initials': 'A.S.'}
```

### Example: Age from Birthdate

```python
from datetime import date
from pydantic import BaseModel, computed_field

class Person(BaseModel):
    name: str
    birthdate: date

    @computed_field
    @property
    def age(self) -> int:
        today = date.today()
        age = today.year - self.birthdate.year
        # Adjust if birthday hasn't occurred this year
        if (today.month, today.day) < (self.birthdate.month, self.birthdate.day):
            age -= 1
        return age

    @computed_field
    @property
    def is_adult(self) -> bool:
        return self.age >= 18

# Usage
person = Person(name="Bob", birthdate=date(1990, 5, 15))
print(person.age)       # Calculated based on current date
print(person.is_adult)  # True (if age >= 18)
```

---

## When Computed Fields are Calculated

### Computed Field Lifecycle

```
+------------------------------------------------------------------+
|                COMPUTED FIELD LIFECYCLE                           |
+------------------------------------------------------------------+

    +------------------+
    |  Model Created   |
    | (fields stored)  |
    +--------+---------+
             |
             |  Computed fields are NOT calculated yet!
             |
             v
    +------------------+
    |  Field Accessed  |  <-- user.full_name
    +--------+---------+
             |
             |  NOW the property method executes
             |
             v
    +------------------+
    |  Value Computed  |  <-- return f"{first} {last}"
    +--------+---------+
             |
             |  Value returned (not cached by default)
             |
             v
    +------------------+
    |  Accessed Again  |  <-- user.full_name (second time)
    +--------+---------+
             |
             |  Property method executes AGAIN
             |  (recomputed each time!)
             |
             v
    +------------------+
    |  New Value       |
    +------------------+

```

### Lazy Evaluation

Computed fields use **lazy evaluation** - they are only calculated when accessed:

```python
from pydantic import BaseModel, computed_field

class Example(BaseModel):
    value: int

    @computed_field
    @property
    def expensive_calculation(self) -> int:
        print("Calculating...")  # This prints each time accessed
        return self.value ** 2

example = Example(value=5)
# Nothing printed yet - field not accessed

print(example.expensive_calculation)
# Prints: Calculating...
# Prints: 25

print(example.expensive_calculation)
# Prints: Calculating...  <-- Calculated AGAIN!
# Prints: 25
```

### Calculation Timeline

```
+------------------------------------------------------------------+
|                    CALCULATION TIMELINE                           |
+------------------------------------------------------------------+
|                                                                   |
|  Time ------>                                                     |
|                                                                   |
|  t0: Model instantiated                                           |
|      [first_name, last_name stored]                               |
|      [full_name NOT calculated]                                   |
|                                                                   |
|  t1: First access: user.full_name                                 |
|      [full_name CALCULATED: "John Doe"]                           |
|      [value returned]                                             |
|                                                                   |
|  t2: Second access: user.full_name                                |
|      [full_name CALCULATED AGAIN: "John Doe"]                     |
|      [value returned]                                             |
|                                                                   |
|  t3: model_dump() called                                          |
|      [full_name CALCULATED for serialization]                     |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Computed Fields in Serialization

### Automatic Inclusion

Computed fields are automatically included in serialization methods:

```python
from pydantic import BaseModel, computed_field

class Product(BaseModel):
    name: str
    price: float
    quantity: int

    @computed_field
    @property
    def total(self) -> float:
        return self.price * self.quantity

    @computed_field
    @property
    def display_price(self) -> str:
        return f"${self.price:.2f}"

product = Product(name="Widget", price=9.99, quantity=3)

# Included in model_dump()
print(product.model_dump())
# {'name': 'Widget', 'price': 9.99, 'quantity': 3, 
#  'total': 29.97, 'display_price': '$9.99'}

# Included in model_dump_json()
print(product.model_dump_json())
# '{"name":"Widget","price":9.99,"quantity":3,"total":29.97,"display_price":"$9.99"}'
```

### Excluding Computed Fields

You can exclude computed fields from serialization:

```python
from pydantic import BaseModel, computed_field

class User(BaseModel):
    first_name: str
    last_name: str

    @computed_field
    @property
    def full_name(self) -> str:
        return f"{self.first_name} {self.last_name}"

user = User(first_name="John", last_name="Doe")

# Exclude specific fields
print(user.model_dump(exclude={'full_name'}))
# {'first_name': 'John', 'last_name': 'Doe'}

# Include only specific fields
print(user.model_dump(include={'full_name'}))
# {'full_name': 'John Doe'}
```

### Controlling repr

```python
from pydantic import BaseModel, computed_field

class User(BaseModel):
    first_name: str
    last_name: str

    @computed_field(repr=False)  # Won't show in repr/print
    @property
    def full_name(self) -> str:
        return f"{self.first_name} {self.last_name}"

user = User(first_name="John", last_name="Doe")
print(user)
# first_name='John' last_name='Doe'
# (full_name not shown, but still serialized!)

print(user.model_dump())
# {'first_name': 'John', 'last_name': 'Doe', 'full_name': 'John Doe'}
```

### JSON Schema Generation

Computed fields are included in JSON schema:

```python
from pydantic import BaseModel, computed_field

class Rectangle(BaseModel):
    width: float
    height: float

    @computed_field
    @property
    def area(self) -> float:
        return self.width * self.height

print(Rectangle.model_json_schema())
# {
#     'properties': {
#         'width': {'title': 'Width', 'type': 'number'},
#         'height': {'title': 'Height', 'type': 'number'},
#         'area': {'readOnly': True, 'title': 'Area', 'type': 'number'}
#     },
#     'required': ['width', 'height'],
#     'title': 'Rectangle',
#     'type': 'object'
# }
```

Note: Computed fields are marked as `readOnly: True` in the schema.

---

## Computed Fields with Dependencies

### Chaining Computed Fields

Computed fields can depend on other computed fields:

```python
from pydantic import BaseModel, computed_field

class Invoice(BaseModel):
    items: list[dict]  # [{name, price, qty}, ...]
    tax_rate: float = 0.1  # 10% tax

    @computed_field
    @property
    def subtotal(self) -> float:
        return sum(item['price'] * item['qty'] for item in self.items)

    @computed_field
    @property
    def tax(self) -> float:
        return self.subtotal * self.tax_rate  # Depends on subtotal

    @computed_field
    @property
    def total(self) -> float:
        return self.subtotal + self.tax  # Depends on subtotal and tax

# Usage
invoice = Invoice(items=[
    {'name': 'Widget', 'price': 10.0, 'qty': 2},
    {'name': 'Gadget', 'price': 25.0, 'qty': 1},
])

print(invoice.model_dump())
# {'items': [...], 'tax_rate': 0.1, 
#  'subtotal': 45.0, 'tax': 4.5, 'total': 49.5}
```

### Dependency Diagram

```
+------------------------------------------------------------------+
|                    INVOICE DEPENDENCIES                           |
+------------------------------------------------------------------+

    +----------+     +----------+
    |  items   |     | tax_rate |
    +----+-----+     +----+-----+
         |                |
         v                |
    +----+-----+          |
    | subtotal |<---------+
    +----+-----+          |
         |                |
    +----+----+           |
    |         |           |
    v         v           |
+---+---+ +---+---+       |
|  tax  | | total |       |
+-------+ +---+---+       |
              ^           |
              +-----------+

```

### Example: E-commerce Order

```python
from datetime import datetime, timedelta
from pydantic import BaseModel, computed_field, Field

class Order(BaseModel):
    product_name: str
    unit_price: float
    quantity: int = 1
    discount_percent: float = 0.0
    created_at: datetime = Field(default_factory=datetime.now)

    @computed_field
    @property
    def gross_total(self) -> float:
        """Total before discount."""
        return self.unit_price * self.quantity

    @computed_field
    @property
    def discount_amount(self) -> float:
        """Amount saved from discount."""
        return self.gross_total * (self.discount_percent / 100)

    @computed_field
    @property
    def net_total(self) -> float:
        """Final amount after discount."""
        return self.gross_total - self.discount_amount

    @computed_field
    @property
    def estimated_delivery(self) -> datetime:
        """Estimated delivery 5 days from order."""
        return self.created_at + timedelta(days=5)

# Usage
order = Order(
    product_name="Laptop",
    unit_price=999.99,
    quantity=2,
    discount_percent=10.0
)

print(f"Gross Total: ${order.gross_total:.2f}")      # $1999.98
print(f"Discount: ${order.discount_amount:.2f}")     # $199.998
print(f"Net Total: ${order.net_total:.2f}")          # $1799.98
print(f"Delivery: {order.estimated_delivery}")
```

---

## cached_property for Expensive Computations

For computationally expensive operations, use `functools.cached_property` to compute the value only once.

### The Problem

```
+------------------------------------------------------------------+
|               WITHOUT CACHING (computed each time)                |
+------------------------------------------------------------------+
|                                                                   |
|  Access 1: user.expensive_field  -->  Compute (takes 2 seconds)   |
|  Access 2: user.expensive_field  -->  Compute (takes 2 seconds)   |
|  Access 3: user.expensive_field  -->  Compute (takes 2 seconds)   |
|                                                                   |
|  Total time: 6 seconds                                            |
|                                                                   |
+------------------------------------------------------------------+

                              VS

+------------------------------------------------------------------+
|               WITH CACHING (computed once)                        |
+------------------------------------------------------------------+
|                                                                   |
|  Access 1: user.expensive_field  -->  Compute (takes 2 seconds)   |
|  Access 2: user.expensive_field  -->  Return cached (instant)     |
|  Access 3: user.expensive_field  -->  Return cached (instant)     |
|                                                                   |
|  Total time: ~2 seconds                                           |
|                                                                   |
+------------------------------------------------------------------+
```

### Using cached_property

```python
from functools import cached_property
from pydantic import BaseModel, computed_field
import time

class DataAnalyzer(BaseModel):
    data: list[int]

    model_config = {'frozen': False}  # Required for cached_property

    @computed_field
    @cached_property
    def analysis_result(self) -> dict:
        """Expensive computation - only runs once."""
        print("Running expensive analysis...")
        time.sleep(1)  # Simulate expensive operation
        return {
            'sum': sum(self.data),
            'avg': sum(self.data) / len(self.data),
            'max': max(self.data),
            'min': min(self.data),
        }

# Usage
analyzer = DataAnalyzer(data=[1, 2, 3, 4, 5])

print(analyzer.analysis_result)  # Takes 1 second, prints "Running..."
print(analyzer.analysis_result)  # Instant! Uses cached value
print(analyzer.analysis_result)  # Instant! Uses cached value
```

### cached_property vs property

| Aspect | @property | @cached_property |
|--------|-----------|------------------|
| Computation | Every access | First access only |
| Memory | No storage | Stores result |
| Mutable models | Works | Works (if not frozen) |
| Frozen models | Works | Does NOT work |
| Use case | Cheap computations | Expensive computations |

### Important: Frozen Models and cached_property

```python
from functools import cached_property
from pydantic import BaseModel, computed_field, ConfigDict

class FrozenModel(BaseModel):
    model_config = ConfigDict(frozen=True)  # Immutable model
    value: int

    # This will raise an error when accessed!
    @computed_field
    @cached_property
    def cached_value(self) -> int:
        return self.value * 2

# This will fail:
# model = FrozenModel(value=5)
# print(model.cached_value)  # AttributeError!

# Solution: Use regular @property for frozen models
class FrozenModelFixed(BaseModel):
    model_config = ConfigDict(frozen=True)
    value: int

    @computed_field
    @property
    def computed_value(self) -> int:
        return self.value * 2  # Computed each time, but works!
```

### Cache Invalidation Pattern

Since `cached_property` caches forever, changes to the model won't update it:

```python
from functools import cached_property
from pydantic import BaseModel, computed_field

class User(BaseModel):
    first_name: str
    last_name: str

    @computed_field
    @cached_property
    def full_name(self) -> str:
        return f"{self.first_name} {self.last_name}"

user = User(first_name="John", last_name="Doe")
print(user.full_name)  # "John Doe"

# Modify the model
user.first_name = "Jane"
print(user.full_name)  # Still "John Doe"! Cached value!

# Manual cache invalidation
del user.__dict__['full_name']  # Clear the cache
print(user.full_name)  # "Jane Doe" - Recomputed!
```

---

## Return Type Annotations

### Required Type Annotations

Computed fields **require** return type annotations:

```python
from pydantic import BaseModel, computed_field

class Example(BaseModel):
    value: int

    # CORRECT - has return type
    @computed_field
    @property
    def doubled(self) -> int:
        return self.value * 2

    # INCORRECT - missing return type (will raise error)
    # @computed_field
    # @property
    # def tripled(self):  # Missing -> int
    #     return self.value * 3
```

### Complex Return Types

```python
from pydantic import BaseModel, computed_field
from typing import Optional

class Document(BaseModel):
    content: str
    author: str | None = None

    @computed_field
    @property
    def word_count(self) -> int:
        return len(self.content.split())

    @computed_field
    @property
    def words(self) -> list[str]:
        return self.content.split()

    @computed_field
    @property
    def metadata(self) -> dict[str, str | int]:
        return {
            'author': self.author or 'Unknown',
            'word_count': self.word_count,
        }

    @computed_field
    @property
    def preview(self) -> str | None:
        """First 50 characters or None if empty."""
        if not self.content:
            return None
        return self.content[:50] + ('...' if len(self.content) > 50 else '')
```

### Return Type in Schema

The return type affects JSON Schema generation:

```
+------------------------------------------------------------------+
|                    RETURN TYPE -> JSON SCHEMA                     |
+------------------------------------------------------------------+
|                                                                   |
|  Python Type          JSON Schema Type                            |
|  -----------          ----------------                            |
|  int              ->  {"type": "integer"}                         |
|  float            ->  {"type": "number"}                          |
|  str              ->  {"type": "string"}                          |
|  bool             ->  {"type": "boolean"}                         |
|  list[int]        ->  {"type": "array", "items": {"type": "integer"}}
|  dict[str, int]   ->  {"type": "object", ...}                     |
|  Optional[str]    ->  {"anyOf": [{"type": "string"}, {"type": "null"}]}
|                                                                   |
+------------------------------------------------------------------+
```

---

## Advanced Patterns

### Computed Field with Alias

```python
from pydantic import BaseModel, computed_field, Field

class User(BaseModel):
    first_name: str
    last_name: str

    @computed_field(alias='displayName')
    @property
    def full_name(self) -> str:
        return f"{self.first_name} {self.last_name}"

user = User(first_name="John", last_name="Doe")
print(user.model_dump(by_alias=True))
# {'first_name': 'John', 'last_name': 'Doe', 'displayName': 'John Doe'}
```

### Computed Field with Description

```python
from pydantic import BaseModel, computed_field

class Rectangle(BaseModel):
    width: float
    height: float

    @computed_field(description="Area of the rectangle in square units")
    @property
    def area(self) -> float:
        return self.width * self.height

# Description appears in JSON Schema
schema = Rectangle.model_json_schema()
print(schema['properties']['area']['description'])
# "Area of the rectangle in square units"
```

### Validation in Computed Fields

While computed fields don't have validators, you can raise exceptions:

```python
from pydantic import BaseModel, computed_field

class Ratio(BaseModel):
    numerator: float
    denominator: float

    @computed_field
    @property
    def value(self) -> float:
        if self.denominator == 0:
            raise ValueError("Cannot divide by zero")
        return self.numerator / self.denominator

# This will raise when accessing .value
ratio = Ratio(numerator=10, denominator=0)
# print(ratio.value)  # Raises ValueError!
```

### Computed Fields in Nested Models

```python
from pydantic import BaseModel, computed_field

class Address(BaseModel):
    street: str
    city: str
    state: str
    zip_code: str

    @computed_field
    @property
    def full_address(self) -> str:
        return f"{self.street}, {self.city}, {self.state} {self.zip_code}"

class Person(BaseModel):
    name: str
    address: Address

    @computed_field
    @property
    def mailing_label(self) -> str:
        return f"{self.name}\n{self.address.full_address}"

# Usage
person = Person(
    name="Alice Smith",
    address=Address(
        street="123 Main St",
        city="Springfield",
        state="IL",
        zip_code="62701"
    )
)

print(person.mailing_label)
# Alice Smith
# 123 Main St, Springfield, IL 62701
```

### Conditional Computed Fields

```python
from pydantic import BaseModel, computed_field

class UserProfile(BaseModel):
    username: str
    email: str | None = None
    phone: str | None = None
    is_verified: bool = False

    @computed_field
    @property
    def contact_method(self) -> str:
        """Returns best available contact method."""
        if self.email:
            return f"email: {self.email}"
        elif self.phone:
            return f"phone: {self.phone}"
        else:
            return "No contact method available"

    @computed_field
    @property
    def display_status(self) -> str:
        """User status badge."""
        return "Verified" if self.is_verified else "Unverified"
```

---

## Quick Reference

### Computed Field Cheat Sheet

```
+------------------------------------------------------------------+
|                 COMPUTED FIELDS QUICK REFERENCE                   |
+------------------------------------------------------------------+
|                                                                   |
|  BASIC SYNTAX                                                     |
|  ------------                                                     |
|  from pydantic import BaseModel, computed_field                   |
|                                                                   |
|  class Model(BaseModel):                                          |
|      field: str                                                   |
|                                                                   |
|      @computed_field                                              |
|      @property                                                    |
|      def computed(self) -> str:  # Return type REQUIRED           |
|          return self.field.upper()                                |
|                                                                   |
+------------------------------------------------------------------+
|                                                                   |
|  WITH CACHING                                                     |
|  ------------                                                     |
|  from functools import cached_property                            |
|                                                                   |
|  @computed_field                                                  |
|  @cached_property                                                 |
|  def expensive(self) -> int:                                      |
|      return heavy_computation()                                   |
|                                                                   |
+------------------------------------------------------------------+
|                                                                   |
|  WITH OPTIONS                                                     |
|  ------------                                                     |
|  @computed_field(                                                 |
|      repr=False,           # Hide from repr                       |
|      alias='myAlias',      # Serialization alias                  |
|      description='...',    # Schema description                   |
|  )                                                                |
|  @property                                                        |
|  def field(self) -> str: ...                                      |
|                                                                   |
+------------------------------------------------------------------+
```

### Visual Summary: Computed Field Flow

```
+------------------------------------------------------------------+
|                 COMPUTED FIELD COMPLETE FLOW                      |
+------------------------------------------------------------------+

                    +-------------------+
                    |    INPUT DATA     |
                    | first_name="John" |
                    | last_name="Doe"   |
                    +--------+----------+
                             |
                             v
                    +--------+----------+
                    |   MODEL CREATED   |
                    |   (fields stored) |
                    +--------+----------+
                             |
              +--------------+--------------+
              |                             |
              v                             v
    +---------+----------+        +---------+----------+
    |   ACCESS FIELD     |        |   SERIALIZE        |
    |   user.full_name   |        |   model_dump()     |
    +---------+----------+        +---------+----------+
              |                             |
              v                             v
    +---------+----------+        +---------+----------+
    |   COMPUTE VALUE    |        |   COMPUTE ALL      |
    |   (lazy eval)      |        |   COMPUTED FIELDS  |
    +---------+----------+        +---------+----------+
              |                             |
              v                             v
    +---------+----------+        +---------+----------+
    |   RETURN VALUE     |        |   INCLUDE IN       |
    |   "John Doe"       |        |   OUTPUT DICT      |
    +--------------------+        +--------------------+

```

### Common Patterns

```
+------------------------------------------------------------------+
|                    COMMON COMPUTED FIELD PATTERNS                 |
+------------------------------------------------------------------+

  1. STRING CONCATENATION
  -----------------------
  @computed_field
  @property
  def full_name(self) -> str:
      return f"{self.first} {self.last}"

  2. DATE CALCULATION
  -------------------
  @computed_field
  @property
  def age(self) -> int:
      return (date.today() - self.birthdate).days // 365

  3. MATHEMATICAL FORMULA
  -----------------------
  @computed_field
  @property
  def total(self) -> float:
      return self.price * self.quantity * (1 - self.discount)

  4. CONDITIONAL VALUE
  --------------------
  @computed_field
  @property
  def status(self) -> str:
      return "active" if self.is_active else "inactive"

  5. LIST AGGREGATION
  -------------------
  @computed_field
  @property
  def item_count(self) -> int:
      return len(self.items)

  6. NESTED ACCESS
  ----------------
  @computed_field
  @property
  def owner_name(self) -> str:
      return self.owner.name if self.owner else "Unknown"

+------------------------------------------------------------------+
```

---

## Next Steps

In the next module, we'll explore:
- Generic Models with TypeVar
- Creating reusable, type-parameterized models
- Advanced typing patterns

---

## Practice Exercises

1. Create a `BankAccount` model with computed fields for `balance` (from transactions) and `account_status` (based on balance)

2. Build a `Recipe` model with computed fields for `total_calories` and `prep_time_formatted`

3. Implement a `StudentGrade` model with computed `letter_grade` and `is_passing` fields

4. Create an `Employee` model with `years_of_service` computed from `hire_date`

5. Build a `ShoppingCart` model with computed `subtotal`, `tax`, and `total` fields
