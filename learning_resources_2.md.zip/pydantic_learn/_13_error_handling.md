# Module 13: Error Handling

---

## Table of Contents
- [ValidationError Exception](#validationerror-exception)
- [Error Structure](#error-structure)
- [Accessing Error Details](#accessing-error-details)
- [Error Types and Codes](#error-types-and-codes)
- [Custom Error Messages](#custom-error-messages)
- [JSON Representation](#json-representation)
- [Handling Errors in Applications](#handling-errors-in-applications)
- [Web API Error Patterns](#web-api-error-patterns)
- [Quick Reference](#quick-reference)

---

## ValidationError Exception

When Pydantic validation fails, it raises a `ValidationError` exception. This exception contains all the information about what went wrong.

### Basic Error Flow

```
+------------------+      +------------------+      +--------------------+
|   INVALID DATA   |      |   PYDANTIC       |      |   ValidationError  |
|   {"age": "abc"} | ---> |   VALIDATION     | ---> |   Exception        |
|                  |      |   age: int       |      |   Raised!          |
+------------------+      +------------------+      +--------------------+
                                                            |
                                                            v
                                                   +--------------------+
                                                   |  ERROR DETAILS     |
                                                   |  - loc: ('age',)   |
                                                   |  - msg: "Input..." |
                                                   |  - type: "int_..." |
                                                   +--------------------+
```

### Basic Example

```python
from pydantic import BaseModel, ValidationError

class User(BaseModel):
    name: str
    age: int
    email: str

try:
    user = User(
        name="John",
        age="not a number",  # Invalid!
        email="invalid-email"
    )
except ValidationError as e:
    print("Validation failed!")
    print(e)
```

Output:
```
Validation failed!
2 validation errors for User
age
  Input should be a valid integer, unable to parse string as an integer
  [type=int_parsing, input_value='not a number', input_type=str]
email
  value is not a valid email address: An email address must have an @-sign.
  [type=value_error, input_value='invalid-email', input_type=str]
```

---

## Error Structure

### Visual Error Anatomy

```
+-------------------------------------------------------------------------+
|                         ValidationError                                  |
+-------------------------------------------------------------------------+
|                                                                         |
|  +-------------------------------------------------------------------+  |
|  |  errors() -> List[ErrorDetails]                                   |  |
|  +-------------------------------------------------------------------+  |
|  |                                                                   |  |
|  |  [                                                                |  |
|  |    +-----------------------------------------------------------+  |  |
|  |    |  Error 1 (dict)                                           |  |  |
|  |    +-----------------------------------------------------------+  |  |
|  |    |  'type': 'int_parsing'        <- Error type code          |  |  |
|  |    |  'loc': ('age',)              <- Location (field path)    |  |  |
|  |    |  'msg': 'Input should be...'  <- Human-readable message   |  |  |
|  |    |  'input': 'not a number'      <- The invalid value        |  |  |
|  |    |  'url': 'https://...'         <- Documentation link       |  |  |
|  |    +-----------------------------------------------------------+  |  |
|  |    ,                                                              |  |
|  |    +-----------------------------------------------------------+  |  |
|  |    |  Error 2 (dict)                                           |  |  |
|  |    +-----------------------------------------------------------+  |  |
|  |    |  'type': 'value_error'                                    |  |  |
|  |    |  'loc': ('email',)                                        |  |  |
|  |    |  'msg': 'value is not a valid email...'                   |  |  |
|  |    |  'input': 'invalid-email'                                 |  |  |
|  |    |  'url': 'https://...'                                     |  |  |
|  |    +-----------------------------------------------------------+  |  |
|  |  ]                                                                |  |
|  +-------------------------------------------------------------------+  |
|                                                                         |
|  +-------------------------------------------------------------------+  |
|  |  error_count() -> int          # Total number of errors           |  |
|  +-------------------------------------------------------------------+  |
|                                                                         |
|  +-------------------------------------------------------------------+  |
|  |  json() -> str                 # JSON representation of errors    |  |
|  +-------------------------------------------------------------------+  |
|                                                                         |
+-------------------------------------------------------------------------+
```

### The `errors()` Method

Returns a list of dictionaries, each containing details about a validation error.

```python
from pydantic import BaseModel, ValidationError

class Product(BaseModel):
    name: str
    price: float
    quantity: int

try:
    product = Product(name="", price=-10, quantity="abc")
except ValidationError as e:
    errors = e.errors()
    
    for error in errors:
        print(f"Field: {error['loc']}")
        print(f"Message: {error['msg']}")
        print(f"Type: {error['type']}")
        print(f"Input: {error['input']}")
        print("---")
```

### The `error_count()` Method

Returns the total number of validation errors.

```python
from pydantic import BaseModel, ValidationError

class User(BaseModel):
    username: str
    email: str
    age: int

try:
    User(username=123, email="bad", age="old")
except ValidationError as e:
    count = e.error_count()
    print(f"Total errors: {count}")  # Total errors: 3
```

---

## Accessing Error Details

### Error Detail Components

```
+-------------------------+------------------------------------------------+
|      Component          |                 Description                     |
+-------------------------+------------------------------------------------+
|                         |                                                |
|  'loc' (location)       |  Tuple representing the path to the field     |
|                         |  - ('age',) for simple fields                  |
|                         |  - ('address', 'city') for nested models       |
|                         |  - ('items', 0, 'name') for list items         |
|                         |                                                |
+-------------------------+------------------------------------------------+
|                         |                                                |
|  'msg' (message)        |  Human-readable error description              |
|                         |  Can be customized with validators             |
|                         |                                                |
+-------------------------+------------------------------------------------+
|                         |                                                |
|  'type' (error type)    |  Machine-readable error code                   |
|                         |  Examples: 'int_parsing', 'missing',           |
|                         |  'string_too_short', 'value_error'             |
|                         |                                                |
+-------------------------+------------------------------------------------+
|                         |                                                |
|  'input'                |  The actual value that caused the error        |
|                         |                                                |
+-------------------------+------------------------------------------------+
|                         |                                                |
|  'ctx' (context)        |  Additional context (optional)                 |
|                         |  E.g., {'min_length': 3} for string_too_short  |
|                         |                                                |
+-------------------------+------------------------------------------------+
|                         |                                                |
|  'url'                  |  Link to documentation about the error         |
|                         |                                                |
+-------------------------+------------------------------------------------+
```

### Location Path Examples

```
SIMPLE FIELD:
+------------------+
| User             |
| +-- name: str    |  <-- loc: ('name',)
| +-- age: int     |  <-- loc: ('age',)
+------------------+

NESTED MODEL:
+------------------+
| User             |
| +-- address      |
|     +-- city     |  <-- loc: ('address', 'city')
|     +-- zip      |  <-- loc: ('address', 'zip')
+------------------+

LIST OF MODELS:
+------------------+
| Order            |
| +-- items: List  |
|     +-- [0]      |
|         +-- name |  <-- loc: ('items', 0, 'name')
|     +-- [1]      |
|         +-- name |  <-- loc: ('items', 1, 'name')
+------------------+
```

### Working with Nested Errors

```python
from pydantic import BaseModel, ValidationError
from typing import List

class Address(BaseModel):
    street: str
    city: str
    zip_code: str

class Item(BaseModel):
    name: str
    price: float

class Order(BaseModel):
    customer: str
    address: Address
    items: List[Item]

try:
    order = Order(
        customer="",
        address={"street": "123 Main", "city": "", "zip_code": "invalid"},
        items=[
            {"name": "", "price": -5},
            {"name": "Widget", "price": "free"}
        ]
    )
except ValidationError as e:
    for error in e.errors():
        # Convert location tuple to dot notation
        loc_str = ".".join(str(x) for x in error['loc'])
        print(f"{loc_str}: {error['msg']}")
```

Output:
```
customer: String should have at least 1 character
address.city: String should have at least 1 character
items.0.name: String should have at least 1 character
items.0.price: Input should be greater than 0
items.1.price: Input should be a valid number, unable to parse string as a number
```

---

## Error Types and Codes

### Common Error Types Reference

```
+---------------------------+----------------------------------------+------------------------------+
|     Error Type            |           Description                  |        Example Input         |
+---------------------------+----------------------------------------+------------------------------+
|                           |                                        |                              |
| missing                   | Required field is missing              | Field not provided           |
|                           |                                        |                              |
+---------------------------+----------------------------------------+------------------------------+
|                           |                                        |                              |
| string_type               | Expected string, got different type    | 123 instead of "123"         |
|                           |                                        |                              |
+---------------------------+----------------------------------------+------------------------------+
|                           |                                        |                              |
| int_parsing               | Cannot parse value as integer          | "abc" for int field          |
|                           |                                        |                              |
+---------------------------+----------------------------------------+------------------------------+
|                           |                                        |                              |
| int_type                  | Expected int, got different type       | "hello" for strict int       |
|                           |                                        |                              |
+---------------------------+----------------------------------------+------------------------------+
|                           |                                        |                              |
| float_parsing             | Cannot parse value as float            | "xyz" for float field        |
|                           |                                        |                              |
+---------------------------+----------------------------------------+------------------------------+
|                           |                                        |                              |
| bool_parsing              | Cannot parse value as boolean          | "maybe" for bool field       |
|                           |                                        |                              |
+---------------------------+----------------------------------------+------------------------------+
|                           |                                        |                              |
| string_too_short          | String length below minimum            | "ab" with min_length=3       |
|                           |                                        |                              |
+---------------------------+----------------------------------------+------------------------------+
|                           |                                        |                              |
| string_too_long           | String length above maximum            | Long string with max=10      |
|                           |                                        |                              |
+---------------------------+----------------------------------------+------------------------------+
|                           |                                        |                              |
| string_pattern_mismatch   | String doesn't match regex pattern     | "abc" with pattern=r'^\d+$'  |
|                           |                                        |                              |
+---------------------------+----------------------------------------+------------------------------+
|                           |                                        |                              |
| greater_than              | Value not greater than constraint      | 5 with gt=10                 |
|                           |                                        |                              |
+---------------------------+----------------------------------------+------------------------------+
|                           |                                        |                              |
| greater_than_equal        | Value not >= constraint                | 5 with ge=10                 |
|                           |                                        |                              |
+---------------------------+----------------------------------------+------------------------------+
|                           |                                        |                              |
| less_than                 | Value not less than constraint         | 15 with lt=10                |
|                           |                                        |                              |
+---------------------------+----------------------------------------+------------------------------+
|                           |                                        |                              |
| less_than_equal           | Value not <= constraint                | 15 with le=10                |
|                           |                                        |                              |
+---------------------------+----------------------------------------+------------------------------+
|                           |                                        |                              |
| list_type                 | Expected list, got different type      | "item" instead of ["item"]   |
|                           |                                        |                              |
+---------------------------+----------------------------------------+------------------------------+
|                           |                                        |                              |
| dict_type                 | Expected dict, got different type      | "data" instead of {}         |
|                           |                                        |                              |
+---------------------------+----------------------------------------+------------------------------+
|                           |                                        |                              |
| value_error               | Custom validation failed               | From raise ValueError()      |
|                           |                                        |                              |
+---------------------------+----------------------------------------+------------------------------+
|                           |                                        |                              |
| assertion_error           | Assertion in validator failed          | From raise AssertionError()  |
|                           |                                        |                              |
+---------------------------+----------------------------------------+------------------------------+
|                           |                                        |                              |
| enum_member               | Value not in enum                      | "UNKNOWN" for Color enum     |
|                           |                                        |                              |
+---------------------------+----------------------------------------+------------------------------+
|                           |                                        |                              |
| url_parsing               | Invalid URL format                     | "not-a-url"                  |
|                           |                                        |                              |
+---------------------------+----------------------------------------+------------------------------+
|                           |                                        |                              |
| datetime_parsing          | Invalid datetime format                | "not-a-date"                 |
|                           |                                        |                              |
+---------------------------+----------------------------------------+------------------------------+
```

### Error Type Categories

```
+---------------------------------------------------------------------+
|                     ERROR TYPE CATEGORIES                            |
+---------------------------------------------------------------------+
|                                                                     |
|   +---------------------+                                           |
|   |   TYPE ERRORS       |   When the type is completely wrong       |
|   +---------------------+                                           |
|   |  string_type        |                                           |
|   |  int_type           |                                           |
|   |  float_type         |                                           |
|   |  bool_type          |                                           |
|   |  list_type          |                                           |
|   |  dict_type          |                                           |
|   +---------------------+                                           |
|                                                                     |
|   +---------------------+                                           |
|   |   PARSING ERRORS    |   When parsing/coercion fails             |
|   +---------------------+                                           |
|   |  int_parsing        |                                           |
|   |  float_parsing      |                                           |
|   |  bool_parsing       |                                           |
|   |  datetime_parsing   |                                           |
|   |  url_parsing        |                                           |
|   |  json_invalid       |                                           |
|   +---------------------+                                           |
|                                                                     |
|   +---------------------+                                           |
|   |  CONSTRAINT ERRORS  |   When value violates constraints         |
|   +---------------------+                                           |
|   |  greater_than       |                                           |
|   |  less_than          |                                           |
|   |  string_too_short   |                                           |
|   |  string_too_long    |                                           |
|   |  too_short (lists)  |                                           |
|   |  too_long (lists)   |                                           |
|   +---------------------+                                           |
|                                                                     |
|   +---------------------+                                           |
|   |  CUSTOM ERRORS      |   From validators                         |
|   +---------------------+                                           |
|   |  value_error        |                                           |
|   |  assertion_error    |                                           |
|   +---------------------+                                           |
|                                                                     |
+---------------------------------------------------------------------+
```

---

## Custom Error Messages

### Using `field_validator` with Custom Messages

```python
from pydantic import BaseModel, field_validator, ValidationError

class User(BaseModel):
    username: str
    age: int
    email: str

    @field_validator('username')
    @classmethod
    def validate_username(cls, v: str) -> str:
        if len(v) < 3:
            raise ValueError('Username must be at least 3 characters long')
        if not v.isalnum():
            raise ValueError('Username must contain only letters and numbers')
        return v.lower()

    @field_validator('age')
    @classmethod
    def validate_age(cls, v: int) -> int:
        if v < 18:
            raise ValueError('Must be at least 18 years old')
        if v > 120:
            raise ValueError('Invalid age: must be realistic')
        return v

    @field_validator('email')
    @classmethod
    def validate_email(cls, v: str) -> str:
        if '@' not in v:
            raise ValueError('Email must contain @ symbol')
        if not v.endswith(('.com', '.org', '.net', '.edu')):
            raise ValueError('Email must have a valid domain extension')
        return v.lower()

try:
    User(username="ab", age=15, email="test")
except ValidationError as e:
    for error in e.errors():
        print(f"{error['loc'][0]}: {error['msg']}")
```

Output:
```
username: Value error, Username must be at least 3 characters long
age: Value error, Must be at least 18 years old
email: Value error, Email must contain @ symbol
```

### Using `model_validator` for Cross-Field Validation

```python
from pydantic import BaseModel, model_validator, ValidationError

class DateRange(BaseModel):
    start_date: str
    end_date: str

    @model_validator(mode='after')
    def validate_date_range(self) -> 'DateRange':
        if self.start_date >= self.end_date:
            raise ValueError('Start date must be before end date')
        return self

try:
    DateRange(start_date="2024-12-31", end_date="2024-01-01")
except ValidationError as e:
    print(e.errors())
```

### Custom Error Message Patterns

```
+------------------------------------------------------------------+
|               CUSTOM ERROR MESSAGE PATTERNS                       |
+------------------------------------------------------------------+
|                                                                  |
|  PATTERN 1: Simple ValueError                                    |
|  --------------------------------                                |
|  @field_validator('field')                                       |
|  @classmethod                                                    |
|  def validate(cls, v):                                           |
|      if bad_condition:                                           |
|          raise ValueError('Your custom message')                 |
|      return v                                                    |
|                                                                  |
+------------------------------------------------------------------+
|                                                                  |
|  PATTERN 2: Multiple Conditions                                  |
|  --------------------------------                                |
|  @field_validator('password')                                    |
|  @classmethod                                                    |
|  def validate_password(cls, v):                                  |
|      errors = []                                                 |
|      if len(v) < 8:                                              |
|          errors.append('at least 8 characters')                  |
|      if not any(c.isupper() for c in v):                         |
|          errors.append('one uppercase letter')                   |
|      if not any(c.isdigit() for c in v):                         |
|          errors.append('one digit')                              |
|      if errors:                                                  |
|          raise ValueError(f'Password must have: {", ".join(e)}') |
|      return v                                                    |
|                                                                  |
+------------------------------------------------------------------+
|                                                                  |
|  PATTERN 3: AssertionError (shorter syntax)                      |
|  --------------------------------                                |
|  @field_validator('age')                                         |
|  @classmethod                                                    |
|  def validate_age(cls, v):                                       |
|      assert v >= 0, 'Age cannot be negative'                     |
|      assert v < 150, 'Age must be realistic'                     |
|      return v                                                    |
|                                                                  |
+------------------------------------------------------------------+
```

---

## JSON Representation

### Using `e.json()` Method

```python
from pydantic import BaseModel, ValidationError, Field
import json

class Product(BaseModel):
    name: str = Field(min_length=1)
    price: float = Field(gt=0)
    quantity: int = Field(ge=0)

try:
    Product(name="", price=-10, quantity=-5)
except ValidationError as e:
    # Get JSON string representation
    json_str = e.json()
    print(json_str)
    
    # Parse to work with as Python object
    errors_list = json.loads(json_str)
    print(f"\nParsed {len(errors_list)} errors")
```

Output:
```json
[
  {
    "type": "string_too_short",
    "loc": ["name"],
    "msg": "String should have at least 1 character",
    "input": "",
    "ctx": {"min_length": 1},
    "url": "https://errors.pydantic.dev/2.5/v/string_too_short"
  },
  {
    "type": "greater_than",
    "loc": ["price"],
    "msg": "Input should be greater than 0",
    "input": -10,
    "ctx": {"gt": 0},
    "url": "https://errors.pydantic.dev/2.5/v/greater_than"
  },
  {
    "type": "greater_than_equal",
    "loc": ["quantity"],
    "msg": "Input should be greater than or equal to 0",
    "input": -5,
    "ctx": {"ge": 0},
    "url": "https://errors.pydantic.dev/2.5/v/greater_than_equal"
  }
]
```

### JSON Error Structure

```
+-------------------------------------------------------------------------+
|                    JSON ERROR REPRESENTATION                             |
+-------------------------------------------------------------------------+
|                                                                         |
|  e.json() returns:                                                      |
|                                                                         |
|  [                                                                      |
|    {                                                                    |
|      "type": "error_type_code",     <- Machine-readable identifier      |
|      "loc": ["field", "subfield"],  <- Array path to field              |
|      "msg": "Human readable...",    <- Display message                  |
|      "input": <the_value>,          <- What was submitted               |
|      "ctx": { ... },                <- Extra context (optional)         |
|      "url": "https://..."           <- Documentation link               |
|    },                                                                   |
|    ...                                                                  |
|  ]                                                                      |
|                                                                         |
+-------------------------------------------------------------------------+
```

---

## Handling Errors in Applications

### Error Handling Flow

```
+------------------------------------------------------------------+
|                   ERROR HANDLING WORKFLOW                         |
+------------------------------------------------------------------+
|                                                                  |
|                      +-------------------+                        |
|                      |   User Input      |                        |
|                      +--------+----------+                        |
|                               |                                  |
|                               v                                  |
|                      +-------------------+                        |
|                      |  try:             |                        |
|                      |    Model(**data)  |                        |
|                      +--------+----------+                        |
|                               |                                  |
|             +-----------------+-----------------+                 |
|             |                                   |                 |
|             v                                   v                 |
|   +-------------------+               +-------------------+       |
|   |  SUCCESS          |               |  ValidationError  |       |
|   |  Process data     |               |  raised           |       |
|   +-------------------+               +--------+----------+       |
|                                                |                 |
|                                                v                 |
|                                      +-------------------+       |
|                                      |  except:          |       |
|                                      |  Handle errors    |       |
|                                      +--------+----------+       |
|                                                |                 |
|                      +-------------------------+-------+         |
|                      |                         |       |         |
|                      v                         v       v         |
|             +---------------+    +---------------+  +-------+    |
|             | Log errors    |    | Return to     |  | Retry |    |
|             | for debugging |    | user          |  |       |    |
|             +---------------+    +---------------+  +-------+    |
|                                                                  |
+------------------------------------------------------------------+
```

### Graceful Error Handling Pattern

```python
from pydantic import BaseModel, ValidationError, Field
from typing import Tuple, Any
import logging

logger = logging.getLogger(__name__)

class UserInput(BaseModel):
    username: str = Field(min_length=3, max_length=20)
    email: str
    age: int = Field(ge=18, le=120)


def validate_user_input(data: dict) -> Tuple[bool, Any]:
    """
    Validate user input and return structured result.
    
    Returns:
        Tuple of (success: bool, result: UserInput | dict)
        On success: (True, UserInput instance)
        On failure: (False, dict with error details)
    """
    try:
        user = UserInput(**data)
        return True, user
    except ValidationError as e:
        # Log for debugging
        logger.warning(f"Validation failed: {e.error_count()} errors")
        
        # Format errors for user
        formatted_errors = {}
        for error in e.errors():
            field = ".".join(str(loc) for loc in error['loc'])
            formatted_errors[field] = {
                'message': error['msg'],
                'type': error['type'],
                'input': error.get('input')
            }
        
        return False, formatted_errors


# Usage
success, result = validate_user_input({
    'username': 'ab',
    'email': 'test@example.com',
    'age': 15
})

if success:
    print(f"Valid user: {result}")
else:
    print("Validation errors:")
    for field, details in result.items():
        print(f"  {field}: {details['message']}")
```

### Error Collection Pattern (Multiple Records)

```python
from pydantic import BaseModel, ValidationError, Field
from typing import List, Tuple

class Product(BaseModel):
    sku: str = Field(pattern=r'^[A-Z]{3}-\d{4}$')
    name: str = Field(min_length=1)
    price: float = Field(gt=0)


def process_products(products: List[dict]) -> Tuple[List[Product], List[dict]]:
    """
    Process multiple products, collecting valid ones and errors.
    
    Returns:
        Tuple of (valid_products, errors)
    """
    valid_products = []
    errors = []
    
    for index, product_data in enumerate(products):
        try:
            product = Product(**product_data)
            valid_products.append(product)
        except ValidationError as e:
            errors.append({
                'index': index,
                'data': product_data,
                'errors': e.errors()
            })
    
    return valid_products, errors


# Usage
products_data = [
    {'sku': 'ABC-1234', 'name': 'Widget', 'price': 9.99},
    {'sku': 'invalid', 'name': '', 'price': -5},
    {'sku': 'XYZ-5678', 'name': 'Gadget', 'price': 19.99},
]

valid, errors = process_products(products_data)
print(f"Valid: {len(valid)}, Errors: {len(errors)}")
```

---

## Web API Error Patterns

### FastAPI Error Handling

```
+------------------------------------------------------------------+
|                 FASTAPI ERROR HANDLING FLOW                       |
+------------------------------------------------------------------+
|                                                                  |
|  CLIENT                    SERVER                                |
|    |                         |                                   |
|    |   POST /users           |                                   |
|    |   {"age": "invalid"}    |                                   |
|    | ----------------------> |                                   |
|    |                         |                                   |
|    |                    +----+----+                               |
|    |                    | Pydantic |                              |
|    |                    | validates|                              |
|    |                    +----+----+                               |
|    |                         |                                   |
|    |                         v                                   |
|    |                    ValidationError                          |
|    |                         |                                   |
|    |                    +----+----+                               |
|    |                    | FastAPI  |                              |
|    |                    | converts |                              |
|    |                    +----+----+                               |
|    |                         |                                   |
|    |   422 Unprocessable     |                                   |
|    |   {"detail": [...]}     |                                   |
|    | <---------------------- |                                   |
|                                                                  |
+------------------------------------------------------------------+
```

### FastAPI with Pydantic Errors

```python
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, ValidationError, Field
from typing import List

app = FastAPI()


class UserCreate(BaseModel):
    username: str = Field(min_length=3, max_length=20)
    email: str
    password: str = Field(min_length=8)


class ErrorDetail(BaseModel):
    field: str
    message: str
    error_type: str


class ErrorResponse(BaseModel):
    success: bool = False
    errors: List[ErrorDetail]


# FastAPI automatically handles Pydantic ValidationErrors
# but you can customize the response:

@app.post("/users")
async def create_user(user: UserCreate):
    # FastAPI automatically validates and returns 422 on error
    return {"success": True, "user": user.model_dump()}


# For custom error handling:
@app.post("/users/custom")
async def create_user_custom(data: dict):
    try:
        user = UserCreate(**data)
        return {"success": True, "user": user.model_dump()}
    except ValidationError as e:
        errors = [
            ErrorDetail(
                field=".".join(str(loc) for loc in err['loc']),
                message=err['msg'],
                error_type=err['type']
            )
            for err in e.errors()
        ]
        raise HTTPException(
            status_code=422,
            detail=ErrorResponse(errors=errors).model_dump()
        )
```

### Generic API Error Response Pattern

```python
from pydantic import BaseModel, ValidationError
from typing import List, Optional, Any
from datetime import datetime


class APIError(BaseModel):
    """Standardized API error format."""
    field: str
    code: str
    message: str
    value: Optional[Any] = None


class APIResponse(BaseModel):
    """Standardized API response wrapper."""
    success: bool
    data: Optional[Any] = None
    errors: Optional[List[APIError]] = None
    timestamp: str = datetime.utcnow().isoformat()


def validation_error_to_api_response(e: ValidationError) -> APIResponse:
    """Convert Pydantic ValidationError to standardized API response."""
    errors = [
        APIError(
            field=".".join(str(loc) for loc in error['loc']),
            code=error['type'],
            message=error['msg'],
            value=error.get('input')
        )
        for error in e.errors()
    ]
    
    return APIResponse(
        success=False,
        errors=errors
    )


# Usage Example
from pydantic import Field

class CreateOrderRequest(BaseModel):
    product_id: str
    quantity: int = Field(ge=1, le=100)
    shipping_address: str = Field(min_length=10)


def handle_create_order(data: dict) -> dict:
    try:
        request = CreateOrderRequest(**data)
        # Process order...
        return APIResponse(
            success=True,
            data={"order_id": "ORD-12345"}
        ).model_dump()
    except ValidationError as e:
        return validation_error_to_api_response(e).model_dump()


# Test
result = handle_create_order({
    "product_id": "PROD-001",
    "quantity": 0,
    "shipping_address": "Short"
})
print(result)
```

Output:
```python
{
    "success": False,
    "data": None,
    "errors": [
        {
            "field": "quantity",
            "code": "greater_than_equal",
            "message": "Input should be greater than or equal to 1",
            "value": 0
        },
        {
            "field": "shipping_address",
            "code": "string_too_short",
            "message": "String should have at least 10 characters",
            "value": "Short"
        }
    ],
    "timestamp": "2024-01-15T10:30:00.000000"
}
```

### Error Response Formats Comparison

```
+------------------------------------------------------------------+
|              ERROR RESPONSE FORMAT COMPARISON                     |
+------------------------------------------------------------------+
|                                                                  |
|  PYDANTIC DEFAULT (e.errors())                                   |
|  +------------------------------------------------------------+  |
|  |  [                                                         |  |
|  |    {"type": "...", "loc": [...], "msg": "...", ...}        |  |
|  |  ]                                                         |  |
|  +------------------------------------------------------------+  |
|                                                                  |
|  FASTAPI DEFAULT                                                 |
|  +------------------------------------------------------------+  |
|  |  {                                                         |  |
|  |    "detail": [                                             |  |
|  |      {"type": "...", "loc": [...], "msg": "...", ...}      |  |
|  |    ]                                                       |  |
|  |  }                                                         |  |
|  +------------------------------------------------------------+  |
|                                                                  |
|  CUSTOM API FORMAT (recommended)                                 |
|  +------------------------------------------------------------+  |
|  |  {                                                         |  |
|  |    "success": false,                                       |  |
|  |    "errors": [                                             |  |
|  |      {"field": "name", "code": "...", "message": "..."}    |  |
|  |    ],                                                      |  |
|  |    "timestamp": "2024-01-15T10:30:00Z"                     |  |
|  |  }                                                         |  |
|  +------------------------------------------------------------+  |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Quick Reference

### ValidationError Methods

```
+------------------------------------------------------------------+
|                  VALIDATIONERROR QUICK REFERENCE                  |
+------------------------------------------------------------------+
|                                                                  |
|  except ValidationError as e:                                    |
|                                                                  |
|  +-------------------------+------------------------------------+ |
|  |  Method                 |  Returns                           | |
|  +-------------------------+------------------------------------+ |
|  |  e.errors()             |  List[dict] - all error details    | |
|  |  e.error_count()        |  int - number of errors            | |
|  |  e.json()               |  str - JSON representation         | |
|  |  str(e)                 |  str - human-readable summary      | |
|  +-------------------------+------------------------------------+ |
|                                                                  |
+------------------------------------------------------------------+
```

### Error Detail Keys

```
+------------------------------------------------------------------+
|                    ERROR DETAIL STRUCTURE                         |
+------------------------------------------------------------------+
|                                                                  |
|  error = e.errors()[0]                                           |
|                                                                  |
|  +------------------+------------------------------------------+ |
|  |  Key             |  Description                             | |
|  +------------------+------------------------------------------+ |
|  |  error['type']   |  Error type code (e.g., 'int_parsing')   | |
|  |  error['loc']    |  Location tuple (e.g., ('field',))       | |
|  |  error['msg']    |  Human-readable message                  | |
|  |  error['input']  |  The invalid input value                 | |
|  |  error['ctx']    |  Extra context (optional)                | |
|  |  error['url']    |  Documentation URL (optional)            | |
|  +------------------+------------------------------------------+ |
|                                                                  |
+------------------------------------------------------------------+
```

### Common Patterns

```python
# PATTERN 1: Simple try/except
try:
    model = Model(**data)
except ValidationError as e:
    print(e)

# PATTERN 2: Get error count
try:
    model = Model(**data)
except ValidationError as e:
    print(f"Found {e.error_count()} errors")

# PATTERN 3: Iterate over errors
try:
    model = Model(**data)
except ValidationError as e:
    for error in e.errors():
        print(f"{error['loc']}: {error['msg']}")

# PATTERN 4: Get JSON for API response
try:
    model = Model(**data)
except ValidationError as e:
    return {"errors": e.json()}

# PATTERN 5: Custom error messages
@field_validator('field')
@classmethod
def validate_field(cls, v):
    if condition:
        raise ValueError('Your custom message here')
    return v
```

---

## Next Steps

In the next module, we'll explore:
- JSON Schema generation with `model_json_schema()`
- Customizing JSON Schema output
- OpenAPI integration
- Schema for complex types

---
