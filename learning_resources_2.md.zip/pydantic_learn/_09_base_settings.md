# Module 09: BaseSettings - Environment & Configuration Management

---

## Table of Contents
- [What is BaseSettings?](#what-is-basesettings)
- [Installing pydantic-settings](#installing-pydantic-settings)
- [Basic Usage](#basic-usage)
- [Reading Environment Variables](#reading-environment-variables)
- [.env File Support](#env-file-support)
- [Settings Sources Priority](#settings-sources-priority)
- [env_prefix for Namespacing](#env_prefix-for-namespacing)
- [case_sensitive Option](#case_sensitive-option)
- [Nested Settings](#nested-settings)
- [Secrets Management](#secrets-management)
- [Custom Settings Sources](#custom-settings-sources)
- [Settings Validation](#settings-validation)
- [Best Practices](#best-practices)

---

## What is BaseSettings?

**BaseSettings** is a Pydantic class designed for application configuration management. It automatically reads values from environment variables, `.env` files, and other sources, providing type-safe configuration with validation.

### Why Use BaseSettings?

```
+------------------------------------------------------------------+
|                    CONFIGURATION CHALLENGES                       |
+------------------------------------------------------------------+
|                                                                  |
|   WITHOUT BaseSettings              WITH BaseSettings            |
|   ------------------                ----------------             |
|   os.environ.get("DB_HOST")         settings.db_host             |
|   No type checking                  Full type validation         |
|   Manual type conversion            Automatic coercion           |
|   No default handling               Clean defaults               |
|   Scattered config access           Centralized config           |
|   No validation                     Built-in validation          |
|                                                                  |
+------------------------------------------------------------------+
```

### Configuration Flow Overview

```
+------------------+     +------------------+     +------------------+
|  ENVIRONMENT     |     |   .env FILE      |     |  SECRETS FILE    |
|  VARIABLES       |     |                  |     |                  |
|  ~~~~~~~~~~~~    |     |  ~~~~~~~~~~~~    |     |  ~~~~~~~~~~~~    |
|  DB_HOST=prod    |     |  DB_HOST=local   |     |  /run/secrets/   |
|  DB_PORT=5432    |     |  DEBUG=true      |     |  db_password     |
+--------+---------+     +--------+---------+     +--------+---------+
         |                        |                        |
         +------------------------+------------------------+
                                  |
                                  v
                    +-------------+-------------+
                    |                           |
                    |      BaseSettings         |
                    |      ~~~~~~~~~~~~         |
                    |  class Settings:          |
                    |      db_host: str         |
                    |      db_port: int         |
                    |      db_password: str     |
                    |                           |
                    +-------------+-------------+
                                  |
                                  v
                    +-------------+-------------+
                    |                           |
                    |   VALIDATED CONFIG        |
                    |   ~~~~~~~~~~~~~~~~        |
                    |   settings.db_host        |
                    |   settings.db_port        |
                    |   settings.db_password    |
                    |                           |
                    +---------------------------+
```

---

## Installing pydantic-settings

In Pydantic v2, BaseSettings has been moved to a separate package called `pydantic-settings`.

### Installation Commands

```bash
# Using pip
pip install pydantic-settings

# Using poetry
poetry add pydantic-settings

# Using uv
uv add pydantic-settings

# With python-dotenv for .env support
pip install pydantic-settings python-dotenv
```

### Verify Installation

```python
from pydantic_settings import BaseSettings, SettingsConfigDict
print("pydantic-settings installed successfully!")
```

### Import Comparison: v1 vs v2

```
+------------------------------------------+------------------------------------------+
|           PYDANTIC v1                    |           PYDANTIC v2                    |
+------------------------------------------+------------------------------------------+
|                                          |                                          |
|  from pydantic import BaseSettings       |  from pydantic_settings import           |
|                                          |      BaseSettings,                       |
|                                          |      SettingsConfigDict                  |
|                                          |                                          |
|  class Settings(BaseSettings):           |  class Settings(BaseSettings):           |
|      class Config:                       |      model_config = SettingsConfigDict(  |
|          env_file = ".env"               |          env_file=".env"                 |
|                                          |      )                                   |
|                                          |                                          |
+------------------------------------------+------------------------------------------+
```

---

## Basic Usage

### Simple Settings Class

```python
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    app_name: str = "MyApp"
    debug: bool = False
    database_url: str
    api_key: str

# Create settings instance (reads from environment)
settings = Settings()

print(settings.app_name)      # "MyApp" or from env APP_NAME
print(settings.debug)         # False or from env DEBUG
print(settings.database_url)  # From env DATABASE_URL (required)
```

### Field Types and Defaults

```python
from pydantic_settings import BaseSettings
from pydantic import Field

class AppSettings(BaseSettings):
    # Required field (must be in environment)
    secret_key: str
    
    # Optional with default
    debug: bool = False
    
    # With Field constraints
    port: int = Field(default=8000, ge=1, le=65535)
    
    # Complex types
    allowed_hosts: list[str] = ["localhost", "127.0.0.1"]
    
    # Optional field (can be None)
    sentry_dsn: str | None = None
```

### How Pydantic Maps Environment Variables

```
+------------------------------------------------------------------+
|                  AUTOMATIC NAMING CONVENTION                      |
+------------------------------------------------------------------+
|                                                                  |
|  Python Field Name     -->    Environment Variable               |
|  -----------------            --------------------               |
|  database_url         -->     DATABASE_URL                       |
|  api_key              -->     API_KEY                            |
|  debug                -->     DEBUG                              |
|  my_setting_name      -->     MY_SETTING_NAME                    |
|                                                                  |
|  * Lowercase in Python, UPPERCASE in environment                 |
|  * Underscores preserved                                         |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Reading Environment Variables

### Direct Environment Variable Mapping

```python
import os
from pydantic_settings import BaseSettings

# Set environment variables (usually done outside Python)
os.environ["DATABASE_HOST"] = "localhost"
os.environ["DATABASE_PORT"] = "5432"
os.environ["DEBUG"] = "true"

class Settings(BaseSettings):
    database_host: str
    database_port: int      # Automatically converted from "5432" to 5432
    debug: bool             # Automatically converted from "true" to True

settings = Settings()
print(f"Host: {settings.database_host}")  # localhost
print(f"Port: {settings.database_port}")  # 5432 (int)
print(f"Debug: {settings.debug}")         # True (bool)
```

### Type Coercion from Environment

```
+------------------------------------------------------------------+
|              ENVIRONMENT STRING --> PYTHON TYPE                   |
+------------------------------------------------------------------+
|                                                                  |
|  "5432"           --> int       5432                             |
|  "3.14"           --> float     3.14                             |
|  "true"           --> bool      True                             |
|  "false"          --> bool      False                            |
|  "1"              --> bool      True                             |
|  "0"              --> bool      False                            |
|  '["a","b","c"]'  --> list      ["a", "b", "c"]                  |
|  '{"key":"val"}'  --> dict      {"key": "val"}                   |
|                                                                  |
+------------------------------------------------------------------+
```

### Custom Environment Variable Names

```python
from pydantic_settings import BaseSettings
from pydantic import Field

class Settings(BaseSettings):
    # Use validation_alias for custom env var name
    db_host: str = Field(validation_alias="POSTGRES_HOST")
    db_port: int = Field(default=5432, validation_alias="POSTGRES_PORT")
    
    # Multiple aliases with AliasChoices
    from pydantic import AliasChoices
    
    api_key: str = Field(
        validation_alias=AliasChoices("API_KEY", "SECRET_KEY", "APP_KEY")
    )
```

---

## .env File Support

### Basic .env Setup

Create a `.env` file in your project root:

```env
# .env file
DATABASE_URL=postgresql://user:pass@localhost:5432/mydb
SECRET_KEY=super-secret-key-12345
DEBUG=true
LOG_LEVEL=INFO
```

### Loading .env Files

```python
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8"
    )
    
    database_url: str
    secret_key: str
    debug: bool = False
    log_level: str = "WARNING"

settings = Settings()
```

### Multiple .env Files

```python
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        # Files loaded in order (later files override earlier)
        env_file=(".env", ".env.local", ".env.production"),
        env_file_encoding="utf-8"
    )
    
    database_url: str
    debug: bool = False
```

### .env File Hierarchy

```
+------------------------------------------------------------------+
|                    .env FILE LOADING ORDER                        |
+------------------------------------------------------------------+
|                                                                  |
|   .env               (Base settings)                             |
|        |                                                         |
|        v                                                         |
|   .env.local         (Local overrides - not committed)           |
|        |                                                         |
|        v                                                         |
|   .env.production    (Environment-specific)                      |
|        |                                                         |
|        v                                                         |
|   ACTUAL ENV VARS    (Highest priority - always wins)            |
|                                                                  |
+------------------------------------------------------------------+
```

### Ignoring Missing .env Files

```python
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_ignore_empty=True,  # Ignore empty env values
        extra="ignore"          # Ignore extra fields in .env
    )
    
    app_name: str = "MyApp"
```

---

## Settings Sources Priority

BaseSettings reads from multiple sources in a specific order. **Later sources override earlier ones.**

### Priority Diagram

```
+------------------------------------------------------------------+
|               SETTINGS SOURCES PRIORITY (LOW TO HIGH)             |
+------------------------------------------------------------------+
|                                                                  |
|  PRIORITY     SOURCE                  EXAMPLE                    |
|  ~~~~~~~~     ~~~~~~                  ~~~~~~~                    |
|                                                                  |
|     1         Default values          debug: bool = False        |
|               (lowest priority)                                  |
|                    |                                             |
|                    v                                             |
|     2         .env file               DEBUG=true (in .env)       |
|               (loaded if exists)                                 |
|                    |                                             |
|                    v                                             |
|     3         Environment             export DEBUG=false         |
|               variables                                          |
|                    |                                             |
|                    v                                             |
|     4         Secrets files           /run/secrets/debug         |
|               (Docker secrets)                                   |
|                    |                                             |
|                    v                                             |
|     5         Init arguments          Settings(debug=True)       |
|               (highest priority)                                 |
|                                                                  |
+------------------------------------------------------------------+
```

### Visual Example of Override Behavior

```
+------------------------------------------------------------------+
|                     VALUE RESOLUTION EXAMPLE                      |
+------------------------------------------------------------------+
|                                                                  |
|  class Settings(BaseSettings):                                   |
|      debug: bool = False        # Default: False                 |
|                                                                  |
|  .env file:                                                      |
|      DEBUG=true                 # .env says: True                |
|                                                                  |
|  Environment:                                                    |
|      export DEBUG=false         # Env says: False                |
|                                                                  |
|  Instantiation:                                                  |
|      Settings(debug=True)       # Init says: True                |
|                                                                  |
|  RESULT: debug = True  (init arg wins)                           |
|                                                                  |
|  Without init arg:                                               |
|      Settings()                                                  |
|  RESULT: debug = False (env var wins over .env)                  |
|                                                                  |
+------------------------------------------------------------------+
```

### Customizing Source Priority

```python
from pydantic_settings import (
    BaseSettings,
    SettingsConfigDict,
    PydanticBaseSettingsSource,
)

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env")
    
    database_url: str
    debug: bool = False
    
    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> tuple[PydanticBaseSettingsSource, ...]:
        # Custom order: env_file first, then env vars, then init
        return (
            dotenv_settings,
            env_settings,
            init_settings,
        )
```

---

## env_prefix for Namespacing

Use `env_prefix` to namespace your environment variables and avoid conflicts between different applications or modules.

### Basic Prefix Usage

```python
from pydantic_settings import BaseSettings, SettingsConfigDict

class DatabaseSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="DB_")
    
    host: str = "localhost"
    port: int = 5432
    name: str = "myapp"
    user: str = "postgres"
    password: str

# These environment variables are now expected:
# DB_HOST=production-server
# DB_PORT=5432
# DB_NAME=production_db
# DB_USER=admin
# DB_PASSWORD=secret
```

### Multiple Settings Classes with Different Prefixes

```python
from pydantic_settings import BaseSettings, SettingsConfigDict

class DatabaseSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="DB_")
    host: str = "localhost"
    port: int = 5432

class CacheSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="REDIS_")
    host: str = "localhost"
    port: int = 6379

class EmailSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="SMTP_")
    host: str = "smtp.gmail.com"
    port: int = 587

# Environment variables:
# DB_HOST, DB_PORT
# REDIS_HOST, REDIS_PORT
# SMTP_HOST, SMTP_PORT
```

### Prefix Visualization

```
+------------------------------------------------------------------+
|                   ENVIRONMENT VARIABLE NAMESPACING                |
+------------------------------------------------------------------+
|                                                                  |
|  Without Prefix:          With Prefix (env_prefix="MYAPP_"):     |
|  ~~~~~~~~~~~~~~~          ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~      |
|                                                                  |
|  HOST=localhost           MYAPP_HOST=localhost                   |
|  PORT=8000                MYAPP_PORT=8000                        |
|  DEBUG=true               MYAPP_DEBUG=true                       |
|  SECRET_KEY=xxx           MYAPP_SECRET_KEY=xxx                   |
|                                                                  |
|  Problem: Conflicts       Solution: Clear namespacing            |
|  with other apps          for multi-app environments             |
|                                                                  |
+------------------------------------------------------------------+
```

---

## case_sensitive Option

By default, environment variable matching is case-insensitive on Windows and case-sensitive on Linux/macOS. You can control this explicitly.

### Case Sensitivity Configuration

```python
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="APP_",
        case_sensitive=True  # Exact case matching required
    )
    
    api_key: str
    debug: bool = False

# With case_sensitive=True:
#   APP_api_key=xxx   --> WORKS (matches exactly)
#   APP_API_KEY=xxx   --> DOES NOT MATCH
#   app_api_key=xxx   --> DOES NOT MATCH

# With case_sensitive=False (default on Windows):
#   APP_API_KEY=xxx   --> WORKS
#   app_api_key=xxx   --> WORKS
#   APP_api_key=xxx   --> WORKS
```

### Case Sensitivity Behavior

```
+------------------------------------------------------------------+
|                   CASE SENSITIVITY BEHAVIOR                       |
+------------------------------------------------------------------+
|                                                                  |
|  case_sensitive=False (default)                                  |
|  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                  |
|  Field: api_key                                                  |
|  Matches: API_KEY, api_key, Api_Key, API_KEY (all work)          |
|                                                                  |
|  case_sensitive=True                                             |
|  ~~~~~~~~~~~~~~~~~~                                              |
|  Field: api_key                                                  |
|  Matches: api_key ONLY                                           |
|                                                                  |
|  With env_prefix="APP_" and case_sensitive=True:                 |
|  Field: api_key                                                  |
|  Matches: APP_api_key ONLY                                       |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Nested Settings

### Using Nested Models

```python
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import BaseModel

class DatabaseConfig(BaseModel):
    """Nested model (not BaseSettings)"""
    host: str = "localhost"
    port: int = 5432
    name: str = "myapp"

class CacheConfig(BaseModel):
    host: str = "localhost"
    port: int = 6379

class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="APP_",
        env_nested_delimiter="__"  # Double underscore for nesting
    )
    
    debug: bool = False
    database: DatabaseConfig = DatabaseConfig()
    cache: CacheConfig = CacheConfig()

# Environment variables with nested delimiter:
# APP_DEBUG=true
# APP_DATABASE__HOST=production-server
# APP_DATABASE__PORT=5432
# APP_DATABASE__NAME=prod_db
# APP_CACHE__HOST=redis-server
# APP_CACHE__PORT=6379
```

### Nested Settings Visualization

```
+------------------------------------------------------------------+
|                    NESTED ENVIRONMENT VARIABLES                   |
+------------------------------------------------------------------+
|                                                                  |
|  Settings Class Structure:                                       |
|  ~~~~~~~~~~~~~~~~~~~~~~~~                                        |
|  Settings                                                        |
|  |-- debug                    --> APP_DEBUG                      |
|  |-- database (DatabaseConfig)                                   |
|  |   |-- host                 --> APP_DATABASE__HOST             |
|  |   |-- port                 --> APP_DATABASE__PORT             |
|  |   +-- name                 --> APP_DATABASE__NAME             |
|  +-- cache (CacheConfig)                                         |
|      |-- host                 --> APP_CACHE__HOST                |
|      +-- port                 --> APP_CACHE__PORT                |
|                                                                  |
|  Delimiter: __ (double underscore)                               |
|                                                                  |
+------------------------------------------------------------------+
```

### Deep Nesting Example

```python
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import BaseModel

class SSLConfig(BaseModel):
    enabled: bool = True
    cert_path: str = "/etc/ssl/cert.pem"

class DatabaseConfig(BaseModel):
    host: str = "localhost"
    port: int = 5432
    ssl: SSLConfig = SSLConfig()

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_nested_delimiter="__")
    
    database: DatabaseConfig = DatabaseConfig()

# Environment variable for deep nesting:
# DATABASE__SSL__ENABLED=false
# DATABASE__SSL__CERT_PATH=/custom/path/cert.pem
```

---

## Secrets Management

### Docker Secrets Support

BaseSettings can read secrets from files, which is perfect for Docker Swarm or Kubernetes secrets.

```python
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        secrets_dir="/run/secrets"  # Docker secrets location
    )
    
    database_password: str
    api_key: str

# File-based secrets:
# /run/secrets/database_password  (contains the password)
# /run/secrets/api_key            (contains the API key)
```

### How Secrets Files Work

```
+------------------------------------------------------------------+
|                    SECRETS FILE STRUCTURE                         |
+------------------------------------------------------------------+
|                                                                  |
|  /run/secrets/                                                   |
|  |-- database_password     Content: "super-secret-password"      |
|  |-- api_key               Content: "sk-1234567890abcdef"        |
|  +-- jwt_secret            Content: "jwt-signing-key-xyz"        |
|                                                                  |
|  Field Name          -->   Secret File                           |
|  ~~~~~~~~~~                ~~~~~~~~~~~                           |
|  database_password   -->   /run/secrets/database_password        |
|  api_key             -->   /run/secrets/api_key                  |
|  jwt_secret          -->   /run/secrets/jwt_secret               |
|                                                                  |
+------------------------------------------------------------------+
```

### Combining Secrets with Environment Variables

```python
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        secrets_dir="/run/secrets"
    )
    
    # From environment
    database_host: str = "localhost"
    database_port: int = 5432
    debug: bool = False
    
    # From secrets (sensitive data)
    database_password: str
    api_key: str
```

### Secrets Priority

```
+------------------------------------------------------------------+
|                    SECRETS LOADING PRIORITY                       |
+------------------------------------------------------------------+
|                                                                  |
|     LOWEST PRIORITY                                              |
|     ---------------                                              |
|  1. Default value in code                                        |
|           |                                                      |
|           v                                                      |
|  2. .env file                                                    |
|           |                                                      |
|           v                                                      |
|  3. Environment variable                                         |
|           |                                                      |
|           v                                                      |
|  4. Secrets file (/run/secrets/field_name)                       |
|           |                                                      |
|           v                                                      |
|  5. Init argument: Settings(api_key="...")                       |
|     ---------------                                              |
|     HIGHEST PRIORITY                                             |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Custom Settings Sources

You can create custom sources to load settings from databases, config servers, or any other source.

### Creating a Custom Source

```python
from typing import Any
from pydantic_settings import (
    BaseSettings,
    PydanticBaseSettingsSource,
    SettingsConfigDict,
)

class JsonConfigSettingsSource(PydanticBaseSettingsSource):
    """Load settings from a JSON config file."""
    
    def get_field_value(
        self,
        field: Any,
        field_name: str,
    ) -> tuple[Any, str, bool]:
        import json
        from pathlib import Path
        
        config_path = Path("config.json")
        if config_path.exists():
            config = json.loads(config_path.read_text())
            if field_name in config:
                return config[field_name], field_name, False
        
        return None, field_name, False
    
    def __call__(self) -> dict[str, Any]:
        import json
        from pathlib import Path
        
        config_path = Path("config.json")
        if config_path.exists():
            return json.loads(config_path.read_text())
        return {}


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env")
    
    app_name: str = "MyApp"
    debug: bool = False
    database_url: str
    
    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> tuple[PydanticBaseSettingsSource, ...]:
        return (
            init_settings,
            env_settings,
            dotenv_settings,
            JsonConfigSettingsSource(settings_cls),
            file_secret_settings,
        )
```

### Custom Source Flow

```
+------------------------------------------------------------------+
|                    CUSTOM SETTINGS SOURCES                        |
+------------------------------------------------------------------+
|                                                                  |
|  Potential Custom Sources:                                       |
|  ~~~~~~~~~~~~~~~~~~~~~~~~                                        |
|                                                                  |
|  +------------+   +------------+   +------------+                |
|  |   JSON     |   |   YAML     |   |   TOML     |                |
|  |   File     |   |   File     |   |   File     |                |
|  +-----+------+   +-----+------+   +-----+------+                |
|        |               |               |                         |
|        +---------------+---------------+                         |
|                        |                                         |
|                        v                                         |
|  +------------+   +----+-------+   +------------+                |
|  |  HashiCorp |   |   AWS      |   |  Database  |                |
|  |  Vault     |   | Parameter  |   |   Config   |                |
|  |            |   |  Store     |   |   Table    |                |
|  +-----+------+   +-----+------+   +-----+------+                |
|        |               |               |                         |
|        +---------------+---------------+                         |
|                        |                                         |
|                        v                                         |
|               +--------+--------+                                |
|               |                 |                                |
|               |  BaseSettings   |                                |
|               |    Instance     |                                |
|               |                 |                                |
|               +-----------------+                                |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Settings Validation

BaseSettings inherits all validation capabilities from Pydantic BaseModel.

### Field Validation

```python
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field, field_validator

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env")
    
    # With Field constraints
    port: int = Field(default=8000, ge=1, le=65535)
    log_level: str = Field(default="INFO", pattern="^(DEBUG|INFO|WARNING|ERROR)$")
    max_connections: int = Field(default=100, gt=0)
    
    # With custom validators
    database_url: str
    
    @field_validator("database_url")
    @classmethod
    def validate_database_url(cls, v: str) -> str:
        if not v.startswith(("postgresql://", "mysql://", "sqlite://")):
            raise ValueError(
                "database_url must start with postgresql://, mysql://, or sqlite://"
            )
        return v
```

### Model-Level Validation

```python
from pydantic_settings import BaseSettings
from pydantic import model_validator

class Settings(BaseSettings):
    database_host: str = "localhost"
    database_port: int = 5432
    database_url: str | None = None
    
    @model_validator(mode="after")
    def build_database_url(self) -> "Settings":
        if self.database_url is None:
            self.database_url = (
                f"postgresql://user:pass@{self.database_host}:{self.database_port}/db"
            )
        return self
```

### Validation Error Handling

```python
from pydantic_settings import BaseSettings
from pydantic import ValidationError, Field

class Settings(BaseSettings):
    port: int = Field(ge=1, le=65535)
    api_key: str = Field(min_length=10)

try:
    # This will fail if PORT or API_KEY env vars are invalid
    settings = Settings()
except ValidationError as e:
    print("Configuration Error!")
    for error in e.errors():
        print(f"  {error['loc'][0]}: {error['msg']}")
```

---

## Best Practices

### 1. Singleton Pattern for Settings

```python
from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env")
    
    database_url: str
    secret_key: str
    debug: bool = False

@lru_cache
def get_settings() -> Settings:
    """Cache settings to avoid re-reading on every call."""
    return Settings()

# Usage
settings = get_settings()
```

### 2. Environment-Specific Settings

```python
from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import Literal

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env")
    
    environment: Literal["development", "staging", "production"] = "development"
    debug: bool = False
    
    @property
    def is_production(self) -> bool:
        return self.environment == "production"
    
    @property
    def log_level(self) -> str:
        return "DEBUG" if self.debug else "INFO"
```

### 3. Organized Settings Structure

```python
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import BaseModel, Field

class DatabaseSettings(BaseModel):
    host: str = "localhost"
    port: int = 5432
    name: str = "app"
    user: str = "postgres"
    password: str = ""

class RedisSettings(BaseModel):
    host: str = "localhost"
    port: int = 6379
    db: int = 0

class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_nested_delimiter="__",
        extra="ignore"
    )
    
    # Application
    app_name: str = "MyApp"
    debug: bool = False
    secret_key: str = Field(min_length=32)
    
    # Nested configs
    database: DatabaseSettings = DatabaseSettings()
    redis: RedisSettings = RedisSettings()

# Usage
settings = Settings()
print(settings.database.host)
print(settings.redis.port)
```

### Best Practices Summary

```
+------------------------------------------------------------------+
|                    SETTINGS BEST PRACTICES                        |
+------------------------------------------------------------------+
|                                                                  |
|  1. USE SINGLETON PATTERN                                        |
|     - Cache settings with @lru_cache                             |
|     - Avoid re-reading env vars repeatedly                       |
|                                                                  |
|  2. NEVER COMMIT SECRETS                                         |
|     - Use .env.example for templates                             |
|     - Add .env to .gitignore                                     |
|     - Use secrets_dir for production                             |
|                                                                  |
|  3. VALIDATE EARLY                                               |
|     - Load settings at startup                                   |
|     - Fail fast on invalid configuration                         |
|                                                                  |
|  4. USE TYPE HINTS                                               |
|     - Leverage Pydantic's type coercion                          |
|     - Get IDE autocomplete support                               |
|                                                                  |
|  5. NAMESPACE WITH env_prefix                                    |
|     - Avoid conflicts in multi-app environments                  |
|     - Makes env vars self-documenting                            |
|                                                                  |
|  6. DOCUMENT REQUIRED VARS                                       |
|     - Maintain a .env.example file                               |
|     - List all required variables                                |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Quick Reference

### Common SettingsConfigDict Options

| Option | Description | Example |
|--------|-------------|---------|
| `env_file` | Path to .env file(s) | `".env"` or `(".env", ".env.local")` |
| `env_file_encoding` | File encoding | `"utf-8"` |
| `env_prefix` | Prefix for env vars | `"MYAPP_"` |
| `env_nested_delimiter` | Delimiter for nested | `"__"` |
| `case_sensitive` | Case-sensitive matching | `True` or `False` |
| `secrets_dir` | Path to secrets | `"/run/secrets"` |
| `extra` | Extra fields handling | `"ignore"`, `"forbid"`, `"allow"` |

### Import Cheat Sheet

```python
# Core imports
from pydantic_settings import BaseSettings, SettingsConfigDict

# For custom sources
from pydantic_settings import PydanticBaseSettingsSource

# Pydantic imports still used
from pydantic import Field, field_validator, model_validator
from pydantic import BaseModel  # For nested configs
from pydantic import ValidationError  # For error handling
```

---

## Next Steps

In the next module, we'll explore:
- Computed fields with `@computed_field`
- Dynamic property generation
- Cached computed values

---
