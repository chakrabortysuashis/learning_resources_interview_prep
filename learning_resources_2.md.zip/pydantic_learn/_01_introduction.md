# Module 01: Introduction to Pydantic

---

## Table of Contents
- [What is Pydantic?](#-what-is-pydantic)
- [Why Use Pydantic?](#-why-use-pydantic)
- [Pydantic v1 vs v2](#-pydantic-v1-vs-v2)
- [Installation](#-installation)
- [Your First Model](#-your-first-model)
- [How Validation Works](#-how-validation-works)
- [Key Concepts](#-key-concepts)

---

## What is Pydantic?

**Pydantic** is a data validation and settings management library for Python that uses Python type annotations to validate data and serialize/deserialize objects.

### Data Flow Visualization

```
+------------------+      +-------------------+      +------------------+
|   RAW INPUT      |      |    PYDANTIC       |      |   VALIDATED      |
|   (dict, JSON,   | ---> |    MODEL          | ---> |   PYTHON         |
|    API response) |      |    (BaseModel)    |      |   OBJECT         |
+------------------+      +-------------------+      +------------------+
        |                         |                         |
        v                         v                         v
  {"name": "John",          class User:               user.name = "John"
   "age": "25"}              name: str                user.age = 25 (int!)
                             age: int
```

### The Pydantic Pipeline

```
+------------+     +-----------+     +------------+     +-------------+
|            |     |           |     |            |     |             |
|  Input     | --> | Parse &   | --> | Validate   | --> | Validated   |
|  Data      |     | Coerce    |     | Rules      |     | Instance    |
|            |     |           |     |            |     |             |
+------------+     +-----------+     +------------+     +-------------+
     ^                   |                  |                  |
     |                   v                  v                  v
  - dict            - "25" -> 25      - Check types     - Type-safe
  - JSON            - "true" -> True  - Custom rules    - Auto-complete
  - kwargs          - ISO date str    - Constraints     - Serializable
                      -> datetime
```

---

## Why Use Pydantic?

### Benefits at a Glance

| Feature | Without Pydantic | With Pydantic |
|---------|------------------|---------------|
| **Type Validation** | Manual `isinstance()` checks | Automatic |
| **Data Coercion** | Manual type conversion | Automatic |
| **Error Messages** | Custom error handling | Detailed, structured |
| **IDE Support** | Limited | Full autocomplete |
| **JSON Serialization** | Manual `json.dumps()` | Built-in `.model_dump_json()` |
| **Documentation** | Separate schema files | Auto-generated JSON Schema |
| **Performance** | Python speed | Rust-powered (v2) |

### Code Comparison

```
+------------------------------------------+------------------------------------------+
|           WITHOUT PYDANTIC               |            WITH PYDANTIC                 |
+------------------------------------------+------------------------------------------+
|                                          |                                          |
|  def create_user(data: dict):            |  from pydantic import BaseModel          |
|      if not isinstance(data, dict):      |                                          |
|          raise ValueError("...")         |  class User(BaseModel):                  |
|      name = data.get("name")             |      name: str                           |
|      if not isinstance(name, str):       |      age: int                            |
|          raise ValueError("...")         |      email: str                          |
|      age = data.get("age")               |                                          |
|      if age is not None:                 |  # That's it! Validation is automatic    |
|          try:                            |  user = User(                            |
|              age = int(age)              |      name="John",                        |
|          except ValueError:              |      age="25",  # Auto-converted to int  |
|              raise ValueError("...")     |      email="john@example.com"            |
|      email = data.get("email")           |  )                                       |
|      # ... more validation ...           |                                          |
|      return {"name": name, ...}          |                                          |
|                                          |                                          |
+------------------------------------------+------------------------------------------+
```

### Key Benefits Explained

```
+------------------------+
|    TYPE SAFETY         |
+------------------------+
|                        |
|  Python Type Hints     |
|         +              |
|  Runtime Validation    |
|         =              |
|  Fewer Bugs!           |
|                        |
+------------------------+

+------------------------+
|   DEVELOPER           |
|   EXPERIENCE          |
+------------------------+
|                        |
|  - IDE Autocomplete    |
|  - Clear Error Msgs    |
|  - Less Boilerplate    |
|  - Self-documenting    |
|                        |
+------------------------+

+------------------------+
|   PERFORMANCE         |
|   (Pydantic v2)       |
+------------------------+
|                        |
|  Core written in Rust  |
|  5-50x faster than v1  |
|  Efficient memory use  |
|                        |
+------------------------+
```

---

## Pydantic v1 vs v2

Pydantic v2 was a major rewrite with significant improvements. Here are the key differences:

| Aspect | Pydantic v1 | Pydantic v2 |
|--------|-------------|-------------|
| **Core** | Pure Python | Rust (pydantic-core) |
| **Speed** | Baseline | 5-50x faster |
| **Config** | `class Config:` | `model_config = ConfigDict()` |
| **Validators** | `@validator` | `@field_validator` |
| **Root Validators** | `@root_validator` | `@model_validator` |
| **Export to dict** | `.dict()` | `.model_dump()` |
| **Export to JSON** | `.json()` | `.model_dump_json()` |
| **Schema** | `.schema()` | `.model_json_schema()` |
| **Field** | `Field(...)` | `Field(...)` (same) |
| **Optional fields** | `Optional[str] = None` | `str | None = None` |

### Migration Quick Reference

```python
# v1 Style (deprecated)                    # v2 Style (current)
class User(BaseModel):                     class User(BaseModel):
    class Config:                              model_config = ConfigDict(
        str_strip_whitespace = True                str_strip_whitespace=True
                                               )
    @validator('name')                         @field_validator('name')
    def validate_name(cls, v):                 @classmethod
        return v.title()                       def validate_name(cls, v):
                                                   return v.title()

user.dict()                                user.model_dump()
user.json()                                user.model_dump_json()
User.schema()                              User.model_json_schema()
```

---

## Installation

### Basic Installation

```bash
# Using pip
pip install pydantic

# Using poetry
poetry add pydantic

# Using uv (fast!)
uv add pydantic
```

### With Optional Dependencies

```bash
# With email validation support
pip install pydantic[email]

# With timezone support
pip install pydantic[timezone]

# All extras
pip install pydantic[email,timezone]
```

### Verify Installation

```python
import pydantic
print(f"Pydantic version: {pydantic.__version__}")
# Should show: Pydantic version: 2.x.x
```

---

## Your First Model

### Basic Example

```python
from pydantic import BaseModel

class User(BaseModel):
    name: str
    age: int
    email: str

# Create an instance
user = User(
    name="Alice",
    age=30,
    email="alice@example.com"
)

print(user)
# name='Alice' age=30 email='alice@example.com'

print(user.name)    # Alice
print(user.age)     # 30
```

### Automatic Type Coercion

```python
# Pydantic automatically converts compatible types!
user = User(
    name="Bob",
    age="25",        # String "25" -> Integer 25
    email="bob@example.com"
)

print(user.age)      # 25
print(type(user.age))  # <class 'int'>
```

### Validation Errors

```python
from pydantic import ValidationError

try:
    user = User(
        name="Charlie",
        age="not a number",  # This will fail!
        email="charlie@example.com"
    )
except ValidationError as e:
    print(e)
```

Output:
```
1 validation error for User
age
  Input should be a valid integer, unable to parse string as an integer
  [type=int_parsing, input_value='not a number', input_type=str]
```

---

## How Validation Works

### Validation Flow Diagram

```
                              +------------------+
                              |   INPUT DATA     |
                              | {"name": "John", |
                              |  "age": "25"}    |
                              +--------+---------+
                                       |
                                       v
                    +------------------+------------------+
                    |           FIELD PARSING            |
                    |    For each field in the model:    |
                    +------------------+-----------------+
                                       |
              +------------------------+------------------------+
              |                        |                        |
              v                        v                        v
     +--------+--------+     +---------+--------+     +---------+--------+
     |   name: str     |     |    age: int      |     |  (more fields)   |
     +--------+--------+     +---------+--------+     +---------+--------+
              |                        |                        |
              v                        v                        v
     +--------+--------+     +---------+--------+     +---------+--------+
     | Check if str    |     | Check if int     |     |    ...           |
     | "John" -> OK    |     | "25" -> coerce   |     |                  |
     |                 |     | Result: 25       |     |                  |
     +--------+--------+     +---------+--------+     +---------+--------+
              |                        |                        |
              +------------------------+------------------------+
                                       |
                                       v
                    +------------------+------------------+
                    |        CUSTOM VALIDATORS           |
                    |   @field_validator, @model_validator|
                    +------------------+-----------------+
                                       |
                                       v
                    +------------------+------------------+
                    |        ALL VALID?                  |
                    +------------------+-----------------+
                           /                    \
                          /                      \
                         v                        v
              +----------+----------+   +---------+---------+
              |      YES            |   |       NO          |
              |  Return validated   |   |  Raise            |
              |  model instance     |   |  ValidationError  |
              +---------------------+   +-------------------+
```

### Validation Order

```
1. FIELD VALIDATORS (mode='before')
         |
         v
2. INNER VALIDATORS (type coercion)
         |
         v
3. FIELD VALIDATORS (mode='after')  <-- default mode
         |
         v
4. MODEL VALIDATORS (mode='before')
         |
         v
5. MODEL VALIDATORS (mode='after')
         |
         v
    FINAL MODEL INSTANCE
```

---

## Key Concepts

### 1. BaseModel

The foundation of all Pydantic models.

```python
from pydantic import BaseModel

class Product(BaseModel):
    name: str
    price: float
    in_stock: bool = True  # Default value

# All these work:
p1 = Product(name="Widget", price=9.99)
p2 = Product(name="Gadget", price=19.99, in_stock=False)
p3 = Product(**{"name": "Thing", "price": 5.99})  # From dict
```

### 2. Field

Customize field behavior with `Field()`.

```python
from pydantic import BaseModel, Field

class Product(BaseModel):
    name: str = Field(
        min_length=1,
        max_length=100,
        description="Product name"
    )
    price: float = Field(
        gt=0,  # greater than 0
        description="Price in USD"
    )
    quantity: int = Field(
        default=0,
        ge=0,  # greater than or equal to 0
        description="Items in stock"
    )
```

### Field Constraints Quick Reference

```
+-------------------+------------------------+---------------------------+
|    Constraint     |       Applies To       |        Example            |
+-------------------+------------------------+---------------------------+
| gt                | Numbers                | Field(gt=0)               |
| ge                | Numbers                | Field(ge=0)               |
| lt                | Numbers                | Field(lt=100)             |
| le                | Numbers                | Field(le=100)             |
| multiple_of       | Numbers                | Field(multiple_of=5)      |
| min_length        | Strings, Lists         | Field(min_length=1)       |
| max_length        | Strings, Lists         | Field(max_length=100)     |
| pattern           | Strings                | Field(pattern=r'^\d+$')   |
| default           | Any                    | Field(default=0)          |
| default_factory   | Any (mutable defaults) | Field(default_factory=list)|
+-------------------+------------------------+---------------------------+
```

### 3. Validation

Custom validation with decorators.

```python
from pydantic import BaseModel, field_validator, model_validator

class User(BaseModel):
    username: str
    password: str
    password_confirm: str

    @field_validator('username')
    @classmethod
    def username_alphanumeric(cls, v: str) -> str:
        if not v.isalnum():
            raise ValueError('must be alphanumeric')
        return v.lower()

    @model_validator(mode='after')
    def passwords_match(self) -> 'User':
        if self.password != self.password_confirm:
            raise ValueError('passwords do not match')
        return self
```

### Summary Diagram

```
+------------------------------------------------------------------+
|                        PYDANTIC MODEL                            |
+------------------------------------------------------------------+
|                                                                  |
|  class MyModel(BaseModel):           <-- Inherit from BaseModel  |
|      |                                                           |
|      +-- model_config = ConfigDict() <-- Model configuration     |
|      |                                                           |
|      +-- field1: str                 <-- Simple field            |
|      +-- field2: int = 0             <-- Field with default      |
|      +-- field3: str = Field(...)    <-- Field with constraints  |
|      |                                                           |
|      +-- @field_validator            <-- Field-level validation  |
|      +-- @model_validator            <-- Model-level validation  |
|                                                                  |
+------------------------------------------------------------------+
                              |
                              v
+------------------------------------------------------------------+
|                        USAGE                                     |
+------------------------------------------------------------------+
|                                                                  |
|  instance = MyModel(field1="hello", field2=42)                   |
|                                                                  |
|  instance.field1              # Access fields                    |
|  instance.model_dump()        # Convert to dict                  |
|  instance.model_dump_json()   # Convert to JSON string           |
|  MyModel.model_json_schema()  # Get JSON Schema                  |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Next Steps

In the next module, we'll dive deeper into:
- Complex type annotations (List, Dict, Optional, Union)
- Nested models
- Custom types
- Advanced validation patterns

---

## Quick Reference Card

```
+------------------------------------------------------------------+
|                    PYDANTIC v2 CHEAT SHEET                       |
+------------------------------------------------------------------+
|                                                                  |
|  IMPORTS                                                         |
|  -------                                                         |
|  from pydantic import BaseModel, Field                           |
|  from pydantic import field_validator, model_validator           |
|  from pydantic import ConfigDict, ValidationError                |
|                                                                  |
|  BASIC MODEL                                                     |
|  -----------                                                     |
|  class User(BaseModel):                                          |
|      name: str                                                   |
|      age: int = 0                                                |
|                                                                  |
|  INSTANCE METHODS                                                |
|  ----------------                                                |
|  user.model_dump()           # -> dict                           |
|  user.model_dump_json()      # -> JSON string                    |
|  user.model_copy()           # -> shallow copy                   |
|  user.model_copy(deep=True)  # -> deep copy                      |
|                                                                  |
|  CLASS METHODS                                                   |
|  -------------                                                   |
|  User.model_validate(data)       # Create from dict              |
|  User.model_validate_json(json)  # Create from JSON string       |
|  User.model_json_schema()        # Get JSON Schema               |
|                                                                  |
+------------------------------------------------------------------+
```
