# Serialization in Pydantic v2

## What is Serialization?

Serialization is the process of converting a Pydantic model into a different format - either a Python dictionary or a JSON string. It's the reverse of validation: you're taking structured data OUT of your model.

```
VALIDATION (Input)                SERIALIZATION (Output)
─────────────────                 ─────────────────────
Raw Data → Model                  Model → Dict/JSON

  dict/JSON                         Pydantic Model
      │                                   │
      ▼                                   ▼
  ┌─────────┐                       ┌───────────┐
  │ Pydantic│                       │model_dump │
  │ Model   │                       │model_dump_│
  │         │                       │json       │
  └─────────┘                       └───────────┘
      │                                   │
      ▼                                   ▼
  Validated                          dict or
  Object                             JSON string
```

---

## The Serialization Pipeline

```
┌─────────────────────────────────────────────────────────────────────┐
│                    SERIALIZATION FLOW                                │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│   Pydantic Model                                                     │
│        │                                                             │
│        ├──────────────────────────────────────────┐                  │
│        │                                          │                  │
│        ▼                                          ▼                  │
│   ┌─────────────────┐                    ┌──────────────────┐        │
│   │  model_dump()   │                    │ model_dump_json()│        │
│   │                 │                    │                  │        │
│   │  Returns: dict  │                    │ Returns: str     │        │
│   └────────┬────────┘                    └────────┬─────────┘        │
│            │                                      │                  │
│            ▼                                      ▼                  │
│   {'name': 'Alice',                     '{"name": "Alice",           │
│    'age': 30,                            "age": 30,                  │
│    'active': True}                       "active": true}'            │
│                                                                      │
│   (Python dict)                          (JSON string)               │
│                                                                      │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Basic Serialization Methods

### model_dump() - Convert to Dictionary

```python
from pydantic import BaseModel
from datetime import datetime

class User(BaseModel):
    name: str
    email: str
    age: int
    created_at: datetime

user = User(
    name="Alice",
    email="alice@example.com",
    age=30,
    created_at=datetime(2024, 1, 15, 10, 30)
)

# Convert to dictionary
user_dict = user.model_dump()
print(user_dict)
# {
#     'name': 'Alice',
#     'email': 'alice@example.com',
#     'age': 30,
#     'created_at': datetime(2024, 1, 15, 10, 30)
# }
```

### model_dump_json() - Convert to JSON String

```python
# Convert to JSON string
user_json = user.model_dump_json()
print(user_json)
# {"name":"Alice","email":"alice@example.com","age":30,"created_at":"2024-01-15T10:30:00"}
```

---

## Serialization Options

```
┌────────────────────────────────────────────────────────────────────┐
│                    SERIALIZATION OPTIONS                            │
├────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Option              │ Purpose                                      │
│  ────────────────────┼────────────────────────────────────────────  │
│  include             │ Only include these fields                    │
│  exclude             │ Exclude these fields                         │
│  by_alias            │ Use field aliases instead of names           │
│  exclude_none        │ Exclude fields with None values              │
│  exclude_unset       │ Exclude fields that weren't explicitly set   │
│  exclude_defaults    │ Exclude fields with default values           │
│  round_trip          │ Ensure output can be parsed back             │
│  mode='json'         │ JSON-compatible serialization                │
│  mode='python'       │ Python-native serialization (default)        │
│                                                                     │
└────────────────────────────────────────────────────────────────────┘
```

### include - Select Specific Fields

```python
from pydantic import BaseModel

class Product(BaseModel):
    id: int
    name: str
    price: float
    description: str
    internal_code: str

product = Product(
    id=1,
    name="Widget",
    price=29.99,
    description="A useful widget",
    internal_code="WDG-001"
)

# Only include specific fields
public_data = product.model_dump(include={'id', 'name', 'price'})
print(public_data)
# {'id': 1, 'name': 'Widget', 'price': 29.99}
```

### exclude - Remove Specific Fields

```python
# Exclude sensitive or internal fields
public_data = product.model_dump(exclude={'internal_code'})
print(public_data)
# {'id': 1, 'name': 'Widget', 'price': 29.99, 'description': 'A useful widget'}

# Exclude multiple fields
public_data = product.model_dump(exclude={'internal_code', 'description'})
print(public_data)
# {'id': 1, 'name': 'Widget', 'price': 29.99}
```

### by_alias - Use Field Aliases

```python
from pydantic import BaseModel, Field

class APIResponse(BaseModel):
    user_id: int = Field(alias='userId')
    user_name: str = Field(alias='userName')
    is_active: bool = Field(alias='isActive')

response = APIResponse(userId=123, userName="Alice", isActive=True)

# Default: use field names
print(response.model_dump())
# {'user_id': 123, 'user_name': 'Alice', 'is_active': True}

# Use aliases (for API compatibility)
print(response.model_dump(by_alias=True))
# {'userId': 123, 'userName': 'Alice', 'isActive': True}
```

### exclude_none - Remove None Values

```python
from pydantic import BaseModel
from typing import Optional

class Profile(BaseModel):
    name: str
    bio: Optional[str] = None
    website: Optional[str] = None
    avatar_url: Optional[str] = None

profile = Profile(name="Alice", bio="Software Developer")

# Include None values (default)
print(profile.model_dump())
# {'name': 'Alice', 'bio': 'Software Developer', 'website': None, 'avatar_url': None}

# Exclude None values
print(profile.model_dump(exclude_none=True))
# {'name': 'Alice', 'bio': 'Software Developer'}
```

### exclude_unset - Remove Unset Fields

```python
from pydantic import BaseModel
from typing import Optional

class UserUpdate(BaseModel):
    name: Optional[str] = None
    email: Optional[str] = None
    age: Optional[int] = None

# User only wants to update their name
update = UserUpdate(name="New Name")

# Default: includes all fields
print(update.model_dump())
# {'name': 'New Name', 'email': None, 'age': None}

# exclude_unset: only fields that were explicitly provided
print(update.model_dump(exclude_unset=True))
# {'name': 'New Name'}

# This is perfect for PATCH operations in APIs!
```

### exclude_defaults - Remove Default Values

```python
from pydantic import BaseModel

class Settings(BaseModel):
    debug: bool = False
    max_connections: int = 100
    timeout: int = 30
    custom_header: str = ""

settings = Settings(timeout=60)  # Only override timeout

print(settings.model_dump(exclude_defaults=True))
# {'timeout': 60}  # Only non-default values
```

---

## Serialization Modes: 'json' vs 'python'

```
┌────────────────────────────────────────────────────────────────────┐
│                    SERIALIZATION MODES                              │
├───────────────────────────────┬────────────────────────────────────┤
│         mode='python'         │          mode='json'               │
│         (default)             │                                    │
├───────────────────────────────┼────────────────────────────────────┤
│                               │                                    │
│  datetime → datetime object   │  datetime → ISO string             │
│  bytes → bytes                │  bytes → base64 string             │
│  Decimal → Decimal            │  Decimal → float or string         │
│  UUID → UUID object           │  UUID → string                     │
│  set → set                    │  set → list                        │
│  custom type → custom type    │  custom type → JSON-safe type      │
│                               │                                    │
│  Use for: Python processing   │  Use for: API responses, storage   │
│                               │                                    │
└───────────────────────────────┴────────────────────────────────────┘
```

```python
from pydantic import BaseModel
from datetime import datetime
from uuid import UUID, uuid4

class Event(BaseModel):
    id: UUID
    name: str
    timestamp: datetime

event = Event(
    id=uuid4(),
    name="Launch",
    timestamp=datetime(2024, 6, 15, 14, 30)
)

# Python mode (default) - keeps native Python types
python_dict = event.model_dump(mode='python')
print(type(python_dict['id']))        # <class 'uuid.UUID'>
print(type(python_dict['timestamp'])) # <class 'datetime.datetime'>

# JSON mode - converts to JSON-serializable types
json_dict = event.model_dump(mode='json')
print(type(json_dict['id']))        # <class 'str'>
print(type(json_dict['timestamp'])) # <class 'str'>
print(json_dict['timestamp'])       # 2024-06-15T14:30:00
```

---

## Custom Serializers with @field_serializer

For custom serialization logic on specific fields.

```
┌─────────────────────────────────────────────────────────────────┐
│                    @field_serializer                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  @field_serializer('field_name')                                 │
│  def serialize_field(self, value) -> serialized_value:           │
│      return transformed_value                                    │
│                                                                  │
│  Options:                                                        │
│  • mode='plain'  - Always applies (default)                      │
│  • mode='wrap'   - Can call default serializer                   │
│  • when_used='always' | 'unless-none' | 'json' | 'json-unless-none' │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Basic Field Serializer

```python
from pydantic import BaseModel, field_serializer
from datetime import datetime

class Article(BaseModel):
    title: str
    content: str
    published_at: datetime
    views: int

    @field_serializer('published_at')
    def serialize_date(self, value: datetime) -> str:
        return value.strftime("%B %d, %Y")  # "January 15, 2024"

    @field_serializer('views')
    def serialize_views(self, value: int) -> str:
        if value >= 1_000_000:
            return f"{value / 1_000_000:.1f}M"
        elif value >= 1_000:
            return f"{value / 1_000:.1f}K"
        return str(value)

article = Article(
    title="Pydantic Guide",
    content="...",
    published_at=datetime(2024, 1, 15),
    views=1_500_000
)

print(article.model_dump())
# {
#     'title': 'Pydantic Guide',
#     'content': '...',
#     'published_at': 'January 15, 2024',
#     'views': '1.5M'
# }
```

### Conditional Serialization with when_used

```python
from pydantic import BaseModel, field_serializer
from decimal import Decimal

class Price(BaseModel):
    amount: Decimal
    currency: str

    @field_serializer('amount', when_used='json')
    def serialize_amount_json(self, value: Decimal) -> str:
        # Only applies when serializing to JSON
        return f"{value:.2f}"

price = Price(amount=Decimal("29.99"), currency="USD")

# Python mode: Decimal unchanged
print(price.model_dump(mode='python'))
# {'amount': Decimal('29.99'), 'currency': 'USD'}

# JSON mode: custom serializer applies
print(price.model_dump(mode='json'))
# {'amount': '29.99', 'currency': 'USD'}
```

### Serializing Multiple Fields

```python
from pydantic import BaseModel, field_serializer

class Coordinates(BaseModel):
    latitude: float
    longitude: float
    altitude: float

    @field_serializer('latitude', 'longitude', 'altitude')
    def round_coordinates(self, value: float) -> float:
        return round(value, 4)

coords = Coordinates(
    latitude=37.7749295847,
    longitude=-122.4194155,
    altitude=16.583902
)

print(coords.model_dump())
# {'latitude': 37.7749, 'longitude': -122.4194, 'altitude': 16.5839}
```

---

## Custom Model Serialization with @model_serializer

For complete control over the entire model's serialization.

```
┌─────────────────────────────────────────────────────────────────┐
│                    @model_serializer                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  @model_serializer                                               │
│  def serialize_model(self) -> dict:                              │
│      return {                                                    │
│          # Complete custom output structure                      │
│      }                                                           │
│                                                                  │
│  Use when you need to:                                           │
│  • Completely restructure output                                 │
│  • Add computed fields to output                                 │
│  • Flatten nested structures                                     │
│  • Change field names dynamically                                │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Basic Model Serializer

```python
from pydantic import BaseModel, model_serializer
from datetime import datetime

class Person(BaseModel):
    first_name: str
    last_name: str
    birth_date: datetime

    @model_serializer
    def serialize_model(self) -> dict:
        return {
            'full_name': f"{self.first_name} {self.last_name}",
            'age': (datetime.now() - self.birth_date).days // 365,
            'birth_year': self.birth_date.year
        }

person = Person(
    first_name="Alice",
    last_name="Smith",
    birth_date=datetime(1990, 5, 15)
)

print(person.model_dump())
# {'full_name': 'Alice Smith', 'age': 34, 'birth_year': 1990}
```

### Wrap Mode Model Serializer

```python
from pydantic import BaseModel, model_serializer
from typing import Any

class AuditableModel(BaseModel):
    id: int
    name: str
    created_by: str

    @model_serializer(mode='wrap')
    def add_metadata(self, handler) -> dict:
        # Get default serialization
        data = handler(self)
        # Add extra metadata
        data['_model_type'] = self.__class__.__name__
        data['_field_count'] = len(self.model_fields)
        return data

obj = AuditableModel(id=1, name="Test", created_by="admin")
print(obj.model_dump())
# {
#     'id': 1,
#     'name': 'Test',
#     'created_by': 'admin',
#     '_model_type': 'AuditableModel',
#     '_field_count': 3
# }
```

---

## The round_trip Parameter

Ensures serialized data can be parsed back into the original model.

```
┌─────────────────────────────────────────────────────────────────┐
│                    round_trip=True                               │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│   Model  ──model_dump(round_trip=True)──►  Dict/JSON             │
│     ▲                                          │                 │
│     │                                          │                 │
│     └────────── Model.model_validate() ◄───────┘                 │
│                                                                  │
│   Guarantees: output can reconstruct original model              │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

```python
from pydantic import BaseModel
from datetime import timedelta

class Task(BaseModel):
    name: str
    duration: timedelta

task = Task(name="Build", duration=timedelta(hours=2, minutes=30))

# Without round_trip - may lose precision
print(task.model_dump())
# {'name': 'Build', 'duration': datetime.timedelta(seconds=9000)}

# With round_trip - preserves parseable format
print(task.model_dump(mode='json', round_trip=True))
# {'name': 'Build', 'duration': 'PT2H30M'}  # ISO 8601 duration

# Can be parsed back
json_data = task.model_dump_json(round_trip=True)
restored = Task.model_validate_json(json_data)
assert restored == task  # Works!
```

---

## JSON Encoders for Custom Types

Handle types that aren't JSON-serializable by default.

### Using Annotated Types with Serializers

```python
from pydantic import BaseModel, PlainSerializer
from typing import Annotated
from ipaddress import IPv4Address

# Define a custom serializer for IPv4Address
IPAddress = Annotated[
    IPv4Address,
    PlainSerializer(lambda x: str(x), return_type=str)
]

class Server(BaseModel):
    hostname: str
    ip_address: IPAddress
    port: int

server = Server(
    hostname="web-01",
    ip_address=IPv4Address("192.168.1.100"),
    port=8080
)

print(server.model_dump_json())
# {"hostname":"web-01","ip_address":"192.168.1.100","port":8080}
```

### Custom Types with __get_pydantic_core_schema__

```python
from pydantic import BaseModel, GetCoreSchemaHandler
from pydantic_core import core_schema
from typing import Any

class Color:
    """Custom color class with RGB values."""
    
    def __init__(self, r: int, g: int, b: int):
        self.r = r
        self.g = g
        self.b = b
    
    def to_hex(self) -> str:
        return f"#{self.r:02x}{self.g:02x}{self.b:02x}"
    
    @classmethod
    def from_hex(cls, hex_str: str) -> 'Color':
        hex_str = hex_str.lstrip('#')
        return cls(
            int(hex_str[0:2], 16),
            int(hex_str[2:4], 16),
            int(hex_str[4:6], 16)
        )
    
    @classmethod
    def __get_pydantic_core_schema__(
        cls, source_type: Any, handler: GetCoreSchemaHandler
    ) -> core_schema.CoreSchema:
        return core_schema.no_info_after_validator_function(
            cls.from_hex,
            core_schema.str_schema(),
            serialization=core_schema.plain_serializer_function_ser_schema(
                lambda x: x.to_hex()
            )
        )

class Theme(BaseModel):
    primary: Color
    secondary: Color

theme = Theme(primary="#ff5733", secondary="#33ff57")

print(theme.model_dump())
# {'primary': '#ff5733', 'secondary': '#33ff57'}

print(theme.primary.r)  # 255 - still a Color object internally
```

---

## Nested Model Serialization

```
┌─────────────────────────────────────────────────────────────────┐
│                NESTED MODEL SERIALIZATION                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌─────────────┐      model_dump()      ┌─────────────────┐     │
│  │   Order     │  ──────────────────►   │  {              │     │
│  │  ┌────────┐ │                        │   'id': 1,      │     │
│  │  │Customer│ │  Recursively dumps     │   'customer': { │     │
│  │  └────────┘ │  all nested models     │     'name':..., │     │
│  │  ┌────────┐ │                        │   },            │     │
│  │  │Items[] │ │                        │   'items': [...] │    │
│  │  └────────┘ │                        │  }              │     │
│  └─────────────┘                        └─────────────────┘     │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

```python
from pydantic import BaseModel, field_serializer
from typing import List
from datetime import datetime

class Address(BaseModel):
    street: str
    city: str
    country: str

class Customer(BaseModel):
    name: str
    email: str
    address: Address

class OrderItem(BaseModel):
    product_name: str
    quantity: int
    unit_price: float

    @property
    def total(self) -> float:
        return self.quantity * self.unit_price

class Order(BaseModel):
    id: int
    customer: Customer
    items: List[OrderItem]
    created_at: datetime

    @field_serializer('created_at')
    def serialize_date(self, value: datetime) -> str:
        return value.isoformat()

# Create order
order = Order(
    id=1001,
    customer=Customer(
        name="Alice",
        email="alice@example.com",
        address=Address(
            street="123 Main St",
            city="Boston",
            country="USA"
        )
    ),
    items=[
        OrderItem(product_name="Widget", quantity=2, unit_price=29.99),
        OrderItem(product_name="Gadget", quantity=1, unit_price=49.99)
    ],
    created_at=datetime(2024, 6, 15, 14, 30)
)

# Serialize entire nested structure
order_dict = order.model_dump()
print(order_dict)
# {
#     'id': 1001,
#     'customer': {
#         'name': 'Alice',
#         'email': 'alice@example.com',
#         'address': {
#             'street': '123 Main St',
#             'city': 'Boston',
#             'country': 'USA'
#         }
#     },
#     'items': [
#         {'product_name': 'Widget', 'quantity': 2, 'unit_price': 29.99},
#         {'product_name': 'Gadget', 'quantity': 1, 'unit_price': 49.99}
#     ],
#     'created_at': '2024-06-15T14:30:00'
# }

# Exclude nested fields
order_dict = order.model_dump(
    exclude={'customer': {'address'}, 'items': {'__all__': {'unit_price'}}}
)
```

---

## Practical Examples

### API Response Serialization

```python
from pydantic import BaseModel, Field, field_serializer
from typing import Optional, List
from datetime import datetime
from enum import Enum

class Status(Enum):
    PENDING = "pending"
    ACTIVE = "active"
    COMPLETED = "completed"

class Task(BaseModel):
    id: int
    title: str
    description: Optional[str] = None
    status: Status = Status.PENDING
    created_at: datetime = Field(default_factory=datetime.now)
    updated_at: Optional[datetime] = None
    tags: List[str] = []
    
    # Internal field - should not be exposed
    internal_priority: int = Field(default=5, exclude=True)

    @field_serializer('status')
    def serialize_status(self, value: Status) -> str:
        return value.value

    @field_serializer('created_at', 'updated_at')
    def serialize_datetime(self, value: Optional[datetime]) -> Optional[str]:
        return value.isoformat() if value else None

# Create task
task = Task(id=1, title="Learn Pydantic", tags=["python", "learning"])

# API response (JSON)
api_response = task.model_dump_json(exclude_none=True, indent=2)
print(api_response)
```

### Database Model Serialization

```python
from pydantic import BaseModel, Field, computed_field
from datetime import datetime
from typing import Optional

class UserDB(BaseModel):
    """User model for database operations."""
    
    id: Optional[int] = None
    username: str
    email: str
    password_hash: str  # Sensitive - exclude from API responses
    created_at: datetime = Field(default_factory=datetime.now)
    last_login: Optional[datetime] = None
    is_active: bool = True

    @computed_field
    @property
    def display_name(self) -> str:
        return f"@{self.username}"

    def to_api_response(self) -> dict:
        """Serialize for API response - excludes sensitive data."""
        return self.model_dump(
            exclude={'password_hash'},
            exclude_none=True
        )

    def to_db_insert(self) -> dict:
        """Serialize for database insertion."""
        return self.model_dump(
            exclude={'id'},  # ID is auto-generated
            exclude_unset=True
        )

user = UserDB(
    username="alice",
    email="alice@example.com",
    password_hash="hashed_password_here"
)

print("API Response:", user.to_api_response())
print("DB Insert:", user.to_db_insert())
```

---

## Summary Cheat Sheet

```
┌─────────────────────────────────────────────────────────────────┐
│                 SERIALIZATION CHEAT SHEET                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  METHODS                                                         │
│  ───────                                                         │
│  model.model_dump()      → dict (Python objects)                 │
│  model.model_dump_json() → str (JSON string)                     │
│                                                                  │
│  OPTIONS                                                         │
│  ───────                                                         │
│  include={...}           → Only these fields                     │
│  exclude={...}           → All except these                      │
│  by_alias=True           → Use Field aliases                     │
│  exclude_none=True       → Skip None values                      │
│  exclude_unset=True      → Skip unset fields (great for PATCH)   │
│  exclude_defaults=True   → Skip fields with default values       │
│  mode='json'             → JSON-compatible types                 │
│  mode='python'           → Native Python types (default)         │
│  round_trip=True         → Ensure parseable output               │
│                                                                  │
│  DECORATORS                                                      │
│  ──────────                                                      │
│  @field_serializer('field')  → Custom field serialization        │
│  @model_serializer           → Custom model serialization        │
│                                                                  │
│  FIELD OPTIONS                                                   │
│  ─────────────                                                   │
│  Field(exclude=True)     → Always exclude from serialization     │
│  Field(alias='...')      → Use with by_alias=True                │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## Key Points to Remember

1. **model_dump()** returns a Python dict; **model_dump_json()** returns a JSON string
2. Use **exclude_unset** for PATCH operations in APIs
3. Use **exclude_none** for cleaner API responses
4. Use **mode='json'** when you need JSON-serializable types
5. Use **@field_serializer** for custom field formatting
6. Use **@model_serializer** for complete output restructuring
7. Use **round_trip=True** when you need to deserialize the output later
8. Nested models are serialized recursively

---

## Practice Exercise

Create a `BlogPost` model with:
- Fields: title, content, author, published_at, tags, is_draft
- Custom serializer for published_at (human-readable format)
- Exclude is_draft from serialization when False
- Method to return API-friendly JSON (excluding None values)

```python
# Your implementation here
from pydantic import BaseModel, field_serializer
from datetime import datetime
from typing import List, Optional

class BlogPost(BaseModel):
    title: str
    content: str
    author: str
    published_at: Optional[datetime] = None
    tags: List[str] = []
    is_draft: bool = True

    @field_serializer('published_at')
    def serialize_published_at(self, value: Optional[datetime]) -> Optional[str]:
        if value:
            return value.strftime("%B %d, %Y at %I:%M %p")
        return None

    def to_api_response(self) -> str:
        """Return JSON for API response."""
        return self.model_dump_json(
            exclude_none=True,
            exclude={'is_draft'} if not self.is_draft else set()
        )

# Test it!
post = BlogPost(
    title="Getting Started with Pydantic",
    content="Pydantic is amazing...",
    author="Alice",
    published_at=datetime(2024, 6, 15, 10, 30),
    tags=["python", "pydantic"],
    is_draft=False
)

print(post.to_api_response())
```
