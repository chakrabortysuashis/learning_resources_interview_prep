# Module 06: Nested Models

---

## Table of Contents
- [Introduction](#-introduction)
- [Models as Field Types](#-models-as-field-types)
- [List of Models](#-list-of-models)
- [Dict with Model Values](#-dict-with-model-values)
- [Optional Nested Models](#-optional-nested-models)
- [Deep Nesting Patterns](#-deep-nesting-patterns)
- [Forward References](#-forward-references)
- [Self-Referencing Models](#-self-referencing-models)
- [Recursive Models (Trees)](#-recursive-models-trees)
- [JSON to Nested Model](#-json-to-nested-model)
- [Best Practices](#-best-practices)

---

## Introduction

Nested models allow you to build complex, hierarchical data structures by using Pydantic models as field types within other models. This mirrors real-world data relationships and enables powerful validation at every level.

### Why Nested Models?

```
+------------------------------------------------------------------+
|                    REAL-WORLD DATA IS NESTED                      |
+------------------------------------------------------------------+
|                                                                   |
|   User                          Order                             |
|   +-- name                      +-- order_id                      |
|   +-- address (nested)          +-- customer (nested)             |
|       +-- street                +-- items (list of nested)        |
|       +-- city                      +-- name                      |
|       +-- country                   +-- price                     |
|   +-- payment_methods (list)        +-- quantity                  |
|       +-- card_type                                               |
|       +-- last_four                                               |
|                                                                   |
+------------------------------------------------------------------+
```

### Benefits

| Benefit | Description |
|---------|-------------|
| **Reusability** | Define once, use in multiple models |
| **Type Safety** | Full validation at every nesting level |
| **IDE Support** | Autocomplete works through nested structures |
| **Clear Structure** | Self-documenting code with explicit relationships |
| **Modular Design** | Change nested model without affecting parent |

---

## Models as Field Types

The simplest form of nesting: use one model as a field type in another.

### Basic Example

```python
from pydantic import BaseModel

class Address(BaseModel):
    street: str
    city: str
    country: str
    zip_code: str

class User(BaseModel):
    name: str
    email: str
    address: Address  # Nested model!

# Creating nested data
user = User(
    name="Alice",
    email="alice@example.com",
    address=Address(
        street="123 Main St",
        city="Boston",
        country="USA",
        zip_code="02101"
    )
)

# Or from a dict (auto-converts nested dicts)
user = User(
    name="Alice",
    email="alice@example.com",
    address={
        "street": "123 Main St",
        "city": "Boston",
        "country": "USA",
        "zip_code": "02101"
    }
)

# Access nested fields
print(user.address.city)  # Boston
```

### Visual Structure

```
+------------------+
|      User        |
+------------------+
| name: str        |
| email: str       |
| address:         |-------+
+------------------+       |
                           v
                 +------------------+
                 |     Address      |
                 +------------------+
                 | street: str      |
                 | city: str        |
                 | country: str     |
                 | zip_code: str    |
                 +------------------+
```

### Validation at All Levels

```python
from pydantic import BaseModel, Field, ValidationError

class Address(BaseModel):
    street: str = Field(min_length=1)
    city: str = Field(min_length=1)
    country: str = Field(min_length=2, max_length=2)  # ISO code
    zip_code: str = Field(pattern=r'^\d{5}(-\d{4})?$')

class User(BaseModel):
    name: str
    address: Address

# This will fail validation at the nested level
try:
    user = User(
        name="Bob",
        address={
            "street": "",  # Too short!
            "city": "NYC",
            "country": "USA",  # Too long! (not ISO code)
            "zip_code": "invalid"  # Bad format!
        }
    )
except ValidationError as e:
    print(e)
```

Output shows nested path in errors:
```
3 validation errors for User
address.street
  String should have at least 1 character [type=string_too_short]
address.country
  String should have at most 2 characters [type=string_too_long]
address.zip_code
  String should match pattern '^\\d{5}(-\\d{4})?$' [type=string_pattern_mismatch]
```

---

## List of Models

When you need a collection of nested models.

### Basic List Example

```python
from pydantic import BaseModel, Field

class Item(BaseModel):
    name: str
    price: float = Field(gt=0)
    quantity: int = Field(ge=1)

class Order(BaseModel):
    order_id: str
    customer_name: str
    items: list[Item]  # List of nested models

# Create with list of Items
order = Order(
    order_id="ORD-001",
    customer_name="Alice",
    items=[
        Item(name="Widget", price=9.99, quantity=2),
        Item(name="Gadget", price=24.99, quantity=1),
    ]
)

# Or from dicts
order = Order(
    order_id="ORD-001",
    customer_name="Alice",
    items=[
        {"name": "Widget", "price": 9.99, "quantity": 2},
        {"name": "Gadget", "price": 24.99, "quantity": 1},
    ]
)

# Iterate over items
for item in order.items:
    print(f"{item.name}: ${item.price * item.quantity:.2f}")
```

### Visual Structure

```
+-----------------------+
|        Order          |
+-----------------------+
| order_id: str         |
| customer_name: str    |
| items: list[Item]     |-----+
+-----------------------+     |
                              |
          +-------------------+-------------------+
          |                   |                   |
          v                   v                   v
   +-----------+       +-----------+       +-----------+
   |   Item    |       |   Item    |       |   Item    |
   +-----------+       +-----------+       +-----------+
   | name      |       | name      |       | name      |
   | price     |       | price     |       | price     |
   | quantity  |       | quantity  |       | quantity  |
   +-----------+       +-----------+       +-----------+
```

### Constrained Lists

```python
from pydantic import BaseModel, Field

class Order(BaseModel):
    order_id: str
    items: list[Item] = Field(min_length=1)  # At least one item required

# This will fail - empty list!
try:
    order = Order(order_id="ORD-001", items=[])
except ValidationError as e:
    print(e)
# List should have at least 1 item after validation, not 0
```

---

## Dict with Model Values

When you need key-value pairs where values are models.

### Basic Dict Example

```python
from pydantic import BaseModel

class Permission(BaseModel):
    read: bool = False
    write: bool = False
    delete: bool = False

class User(BaseModel):
    name: str
    permissions: dict[str, Permission]  # Resource -> Permission mapping

user = User(
    name="Alice",
    permissions={
        "documents": Permission(read=True, write=True, delete=False),
        "photos": Permission(read=True, write=False, delete=False),
        "admin": {"read": False, "write": False, "delete": False},  # Dict auto-converts
    }
)

# Access permissions
print(user.permissions["documents"].write)  # True
```

### Visual Structure

```
+---------------------------+
|           User            |
+---------------------------+
| name: str                 |
| permissions:              |
|   dict[str, Permission]   |
+---------------------------+
            |
            v
+------------------------------------------+
|       permissions (dict)                 |
+------------------------------------------+
|                                          |
|  "documents" -----> +-------------+      |
|                     | Permission  |      |
|                     | read: True  |      |
|                     | write: True |      |
|                     | delete: False|     |
|                     +-------------+      |
|                                          |
|  "photos" -------> +-------------+       |
|                    | Permission  |       |
|                    | read: True  |       |
|                    | write: False|       |
|                    | delete: False|      |
|                    +-------------+       |
+------------------------------------------+
```

### Dict with Complex Keys

```python
from pydantic import BaseModel
from datetime import date

class DailyStats(BaseModel):
    visits: int
    sales: float

class Analytics(BaseModel):
    site_name: str
    stats_by_date: dict[date, DailyStats]  # Date -> Stats

analytics = Analytics(
    site_name="MyStore",
    stats_by_date={
        date(2024, 1, 1): DailyStats(visits=1000, sales=5000.0),
        "2024-01-02": {"visits": 1200, "sales": 6000.0},  # String date auto-parsed
    }
)
```

---

## Optional Nested Models

When nested data might not be present.

### Basic Optional Nesting

```python
from pydantic import BaseModel

class Address(BaseModel):
    street: str
    city: str

class Contact(BaseModel):
    phone: str | None = None
    email: str | None = None

class User(BaseModel):
    name: str
    address: Address | None = None  # Optional nested model
    contact: Contact | None = None

# User without optional fields
user1 = User(name="Alice")
print(user1.address)  # None

# User with optional fields
user2 = User(
    name="Bob",
    address={"street": "123 Main", "city": "Boston"},
    contact={"email": "bob@example.com"}
)
print(user2.address.city)  # Boston
```

### Visual Structure

```
+-------------------+
|       User        |
+-------------------+
| name: str         |
| address:          |----->  Address | None
|   Address | None  |          |
| contact:          |          +--> +-------------+
|   Contact | None  |               | Address     |
+-------------------+               | street: str |
        |                           | city: str   |
        |                           +-------------+
        +----->  Contact | None
                    |
                    +--> +----------------+
                         | Contact        |
                         | phone: str|None|
                         | email: str|None|
                         +----------------+
```

### Optional with Default Instance

```python
from pydantic import BaseModel, Field

class Settings(BaseModel):
    theme: str = "light"
    notifications: bool = True

class User(BaseModel):
    name: str
    settings: Settings = Field(default_factory=Settings)

# User gets default settings automatically
user = User(name="Alice")
print(user.settings.theme)  # "light"
```

---

## Deep Nesting Patterns

Complex real-world structures often have multiple levels of nesting.

### Example: E-commerce Order

```python
from pydantic import BaseModel, Field
from datetime import datetime
from decimal import Decimal

class Address(BaseModel):
    street: str
    city: str
    state: str
    country: str
    zip_code: str

class PaymentMethod(BaseModel):
    method_type: str  # "credit_card", "paypal", etc.
    last_four: str | None = None

class Product(BaseModel):
    sku: str
    name: str
    unit_price: Decimal

class OrderItem(BaseModel):
    product: Product  # Level 3 nesting
    quantity: int = Field(ge=1)
    
    @property
    def subtotal(self) -> Decimal:
        return self.product.unit_price * self.quantity

class Customer(BaseModel):
    customer_id: str
    name: str
    email: str
    billing_address: Address  # Level 2 nesting
    shipping_address: Address | None = None

class Order(BaseModel):  # Level 1 (root)
    order_id: str
    customer: Customer  # Contains Address (Level 2 -> Level 3)
    items: list[OrderItem]  # Contains Product (Level 2 -> Level 3)
    payment: PaymentMethod
    created_at: datetime = Field(default_factory=datetime.now)
```

### Visual Hierarchy

```
ORDER (Root)
+------------------------------------------------------+
|  order_id: str                                       |
|  created_at: datetime                                |
|                                                      |
|  +-- customer: Customer                              |
|  |   +-- customer_id: str                            |
|  |   +-- name: str                                   |
|  |   +-- email: str                                  |
|  |   +-- billing_address: Address                    |
|  |   |   +-- street, city, state, country, zip_code  |
|  |   +-- shipping_address: Address | None            |
|  |       +-- street, city, state, country, zip_code  |
|  |                                                   |
|  +-- items: list[OrderItem]                          |
|  |   +-- [0] OrderItem                               |
|  |   |   +-- product: Product                        |
|  |   |   |   +-- sku, name, unit_price               |
|  |   |   +-- quantity: int                           |
|  |   +-- [1] OrderItem                               |
|  |   |   +-- product: Product                        |
|  |   |   +-- quantity: int                           |
|  |   +-- ...                                         |
|  |                                                   |
|  +-- payment: PaymentMethod                          |
|      +-- method_type: str                            |
|      +-- last_four: str | None                       |
+------------------------------------------------------+
```

### Accessing Deep Nested Data

```python
# Create the order
order = Order(
    order_id="ORD-12345",
    customer={
        "customer_id": "CUST-001",
        "name": "Alice Smith",
        "email": "alice@example.com",
        "billing_address": {
            "street": "123 Main St",
            "city": "Boston",
            "state": "MA",
            "country": "USA",
            "zip_code": "02101"
        }
    },
    items=[
        {
            "product": {"sku": "WIDGET-001", "name": "Widget", "unit_price": "9.99"},
            "quantity": 2
        },
        {
            "product": {"sku": "GADGET-001", "name": "Gadget", "unit_price": "24.99"},
            "quantity": 1
        }
    ],
    payment={"method_type": "credit_card", "last_four": "4242"}
)

# Access deep nested data with full autocomplete support
print(order.customer.billing_address.city)  # Boston
print(order.items[0].product.name)  # Widget
print(order.items[0].subtotal)  # 19.98
```

---

## Forward References

When you need to reference a model before it's defined.

### String Annotation Method

```python
from pydantic import BaseModel

class Department(BaseModel):
    name: str
    manager: "Employee"  # Forward reference as string

class Employee(BaseModel):
    name: str
    department: Department

# Both models now work
dept = Department(
    name="Engineering",
    manager={"name": "Alice"}
)
```

### Using `from __future__ import annotations`

```python
from __future__ import annotations  # All annotations become strings
from pydantic import BaseModel

class Department(BaseModel):
    name: str
    manager: Employee  # No quotes needed!

class Employee(BaseModel):
    name: str
    department: Department
```

### Model Rebuild for Complex References

```python
from pydantic import BaseModel

class Category(BaseModel):
    name: str
    parent: "Category | None" = None  # Self-reference
    children: "list[Category]" = []

# Required after forward references
Category.model_rebuild()

# Now it works
root = Category(
    name="Electronics",
    children=[
        Category(name="Phones"),
        Category(name="Laptops")
    ]
)
```

---

## Self-Referencing Models

Models that reference themselves for hierarchical data.

### Basic Self-Reference

```python
from __future__ import annotations
from pydantic import BaseModel

class Employee(BaseModel):
    name: str
    title: str
    direct_reports: list[Employee] = []

# Org chart
ceo = Employee(
    name="Alice",
    title="CEO",
    direct_reports=[
        Employee(
            name="Bob",
            title="VP Engineering",
            direct_reports=[
                Employee(name="Charlie", title="Senior Dev"),
                Employee(name="Diana", title="Senior Dev")
            ]
        ),
        Employee(
            name="Eve",
            title="VP Sales"
        )
    ]
)

# Print org chart
def print_org(emp: Employee, indent: int = 0):
    print("  " * indent + f"{emp.name} ({emp.title})")
    for report in emp.direct_reports:
        print_org(report, indent + 1)

print_org(ceo)
```

Output:
```
Alice (CEO)
  Bob (VP Engineering)
    Charlie (Senior Dev)
    Diana (Senior Dev)
  Eve (VP Sales)
```

### Visual: Self-Referencing Structure

```
Employee
+------------------+
| name: str        |
| title: str       |
| direct_reports:  |----+
|   list[Employee] |    |
+------------------+    |
        ^               |
        +---------------+
        (references itself)
        
        
INSTANCE HIERARCHY:
        
        +------------------+
        | Alice (CEO)      |
        +------------------+
               |
      +--------+--------+
      |                 |
      v                 v
+-------------+   +-------------+
| Bob (VP Eng)|   | Eve (VP Sales)|
+-------------+   +-------------+
      |
   +--+--+
   |     |
   v     v
+------+ +------+
|Charlie| |Diana|
+------+ +------+
```

---

## Recursive Models (Trees)

Perfect for tree structures like file systems, comments, or menus.

### Binary Tree

```python
from __future__ import annotations
from pydantic import BaseModel

class TreeNode(BaseModel):
    value: int
    left: TreeNode | None = None
    right: TreeNode | None = None

# Build a tree
#       5
#      / \
#     3   7
#    / \   \
#   1   4   9

tree = TreeNode(
    value=5,
    left=TreeNode(
        value=3,
        left=TreeNode(value=1),
        right=TreeNode(value=4)
    ),
    right=TreeNode(
        value=7,
        right=TreeNode(value=9)
    )
)

# Tree traversal
def inorder(node: TreeNode | None) -> list[int]:
    if node is None:
        return []
    return inorder(node.left) + [node.value] + inorder(node.right)

print(inorder(tree))  # [1, 3, 4, 5, 7, 9]
```

### File System Tree

```python
from __future__ import annotations
from pydantic import BaseModel
from typing import Literal

class FileSystemNode(BaseModel):
    name: str
    node_type: Literal["file", "directory"]
    size_bytes: int = 0
    children: list[FileSystemNode] = []

# Build a file system structure
root = FileSystemNode(
    name="home",
    node_type="directory",
    children=[
        FileSystemNode(
            name="documents",
            node_type="directory",
            children=[
                FileSystemNode(name="resume.pdf", node_type="file", size_bytes=102400),
                FileSystemNode(name="cover_letter.docx", node_type="file", size_bytes=51200)
            ]
        ),
        FileSystemNode(
            name="photos",
            node_type="directory",
            children=[
                FileSystemNode(name="vacation.jpg", node_type="file", size_bytes=2048000)
            ]
        )
    ]
)

def print_tree(node: FileSystemNode, indent: int = 0):
    icon = "[D]" if node.node_type == "directory" else "[F]"
    size = f" ({node.size_bytes:,} bytes)" if node.node_type == "file" else ""
    print("  " * indent + f"{icon} {node.name}{size}")
    for child in node.children:
        print_tree(child, indent + 1)

print_tree(root)
```

Output:
```
[D] home
  [D] documents
    [F] resume.pdf (102,400 bytes)
    [F] cover_letter.docx (51,200 bytes)
  [D] photos
    [F] vacation.jpg (2,048,000 bytes)
```

### Comment Thread (Nested Comments)

```python
from __future__ import annotations
from pydantic import BaseModel
from datetime import datetime

class Comment(BaseModel):
    author: str
    text: str
    created_at: datetime
    replies: list[Comment] = []

# Thread structure
thread = Comment(
    author="Alice",
    text="Great article!",
    created_at=datetime(2024, 1, 1, 10, 0),
    replies=[
        Comment(
            author="Bob",
            text="I agree!",
            created_at=datetime(2024, 1, 1, 10, 30),
            replies=[
                Comment(
                    author="Alice",
                    text="Thanks for the support!",
                    created_at=datetime(2024, 1, 1, 11, 0)
                )
            ]
        ),
        Comment(
            author="Charlie",
            text="Interesting perspective.",
            created_at=datetime(2024, 1, 1, 12, 0)
        )
    ]
)
```

### Visual: Tree Structure

```
BINARY TREE                    FILE SYSTEM TREE

       5                           home/
      / \                         /    \
     3   7                  documents/  photos/
    / \   \                   /    \        \
   1   4   9             resume  cover   vacation
                          .pdf   .docx     .jpg


COMMENT THREAD

Comment (Alice: "Great article!")
    |
    +-- Reply (Bob: "I agree!")
    |       |
    |       +-- Reply (Alice: "Thanks!")
    |
    +-- Reply (Charlie: "Interesting...")
```

---

## JSON to Nested Model

Pydantic seamlessly converts JSON/dict data to nested models.

### From JSON String

```python
from pydantic import BaseModel
import json

class Address(BaseModel):
    city: str
    country: str

class User(BaseModel):
    name: str
    address: Address

# JSON string
json_data = '{"name": "Alice", "address": {"city": "Boston", "country": "USA"}}'

# Parse JSON to model
user = User.model_validate_json(json_data)
print(user.address.city)  # Boston

# Alternatively, parse JSON first
data = json.loads(json_data)
user = User.model_validate(data)
```

### From API Response

```python
from pydantic import BaseModel
import json

# Simulated API response
api_response = """
{
    "order_id": "ORD-001",
    "customer": {
        "name": "Alice",
        "email": "alice@example.com"
    },
    "items": [
        {"name": "Widget", "price": 9.99, "qty": 2},
        {"name": "Gadget", "price": 24.99, "qty": 1}
    ]
}
"""

class Customer(BaseModel):
    name: str
    email: str

class Item(BaseModel):
    name: str
    price: float
    qty: int

class Order(BaseModel):
    order_id: str
    customer: Customer
    items: list[Item]

# Directly from JSON
order = Order.model_validate_json(api_response)

print(f"Order {order.order_id} for {order.customer.name}")
print(f"Items: {len(order.items)}")
for item in order.items:
    print(f"  - {item.name}: ${item.price} x {item.qty}")
```

### Back to JSON

```python
# Convert back to JSON string
json_output = order.model_dump_json(indent=2)
print(json_output)

# Convert to dict
dict_output = order.model_dump()
print(dict_output)
```

### Conversion Flow

```
+-------------------+         +--------------------+         +-------------------+
|                   |         |                    |         |                   |
|   JSON String     | ------> |   Pydantic Model   | ------> |   JSON String     |
|                   |         |                    |         |                   |
|   {"name":...}    |  model_validate_json()       | model_dump_json()           |
|                   |         |   user.name        |         |   {"name":...}    |
+-------------------+         |   user.address     |         +-------------------+
                              |   user.address.city|
                              +--------------------+
                                       |
                              model_dump()
                                       |
                                       v
                              +-------------------+
                              |                   |
                              |   Python Dict     |
                              |                   |
                              |   {"name": ...    |
                              |    "address": {}} |
                              |                   |
                              +-------------------+
```

---

## Best Practices

### 1. Keep Models Focused

```python
# GOOD: Small, focused models
class Address(BaseModel):
    street: str
    city: str
    country: str

class User(BaseModel):
    name: str
    address: Address

# BAD: Monolithic model
class User(BaseModel):
    name: str
    address_street: str
    address_city: str
    address_country: str
```

### 2. Use Type Aliases for Complex Types

```python
from pydantic import BaseModel

# Define reusable type aliases
AddressDict = dict[str, "Address"]
ItemList = list["Item"]

class Item(BaseModel):
    name: str
    price: float

class Address(BaseModel):
    city: str

class User(BaseModel):
    addresses: AddressDict  # Clear and reusable
    favorites: ItemList
```

### 3. Limit Nesting Depth

```
RECOMMENDED: 3-4 levels max

Level 1: Order
    |
    +-- Level 2: Customer
    |       |
    |       +-- Level 3: Address
    |
    +-- Level 2: Items[]
            |
            +-- Level 3: Product

Beyond 4 levels: Consider flattening or redesigning
```

### 4. Use model_rebuild() for Forward References

```python
from __future__ import annotations
from pydantic import BaseModel

class Node(BaseModel):
    value: int
    children: list[Node] = []

# Always call after defining self-referencing models
Node.model_rebuild()
```

### 5. Validate with Realistic Test Data

```python
# Always test with real-world-like nested data
test_data = {
    "order_id": "ORD-001",
    "customer": {
        "name": "Test User",
        "address": {"city": "Test City", "country": "TC"}
    },
    "items": [
        {"name": "Item 1", "price": 10.0},
        {"name": "Item 2", "price": 20.0}
    ]
}

# Validate structure
order = Order.model_validate(test_data)
```

---

## Summary

```
+------------------------------------------------------------------+
|                    NESTED MODELS CHEAT SHEET                      |
+------------------------------------------------------------------+
|                                                                   |
|  BASIC NESTING                                                    |
|  -------------                                                    |
|  class Parent(BaseModel):                                         |
|      child: ChildModel         # Single nested model              |
|      children: list[Child]     # List of models                   |
|      mapping: dict[str, Child] # Dict with model values           |
|      maybe: Child | None       # Optional nested model            |
|                                                                   |
|  SELF-REFERENCE (use __future__ annotations)                      |
|  -------------------------------------------                      |
|  from __future__ import annotations                               |
|  class Node(BaseModel):                                           |
|      children: list[Node] = []                                    |
|  Node.model_rebuild()  # Required!                                |
|                                                                   |
|  JSON CONVERSION                                                  |
|  ---------------                                                  |
|  Model.model_validate_json(json_str)  # JSON -> Model             |
|  Model.model_validate(dict_data)      # Dict -> Model             |
|  model.model_dump_json()              # Model -> JSON             |
|  model.model_dump()                   # Model -> Dict             |
|                                                                   |
|  ACCESSING NESTED DATA                                            |
|  ---------------------                                            |
|  order.customer.address.city    # Dot notation                    |
|  order.items[0].product.name    # List index + dot                |
|  order.permissions["docs"].read # Dict key + dot                  |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Next Steps

In the next module, we'll explore:
- Model Configuration with `model_config`
- Strict vs Lax mode
- Custom JSON encoders/decoders
- Field aliases and serialization options
