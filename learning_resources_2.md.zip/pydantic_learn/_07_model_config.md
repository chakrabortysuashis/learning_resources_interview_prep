# Module 07: Model Configuration

---

## Table of Contents
- [What is Model Configuration?](#what-is-model-configuration)
- [The model_config Dict](#the-model_config-dict)
- [ConfigDict Overview](#configdict-overview)
- [String Configuration](#string-configuration)
- [Strict Mode](#strict-mode)
- [Frozen Models (Immutability)](#frozen-models-immutability)
- [Extra Fields Handling](#extra-fields-handling)
- [Alias Configuration](#alias-configuration)
- [Validate on Assignment](#validate-on-assignment)
- [Enum Values](#enum-values)
- [Complete Config Options Reference](#complete-config-options-reference)
- [When to Use Each Option](#when-to-use-each-option)

---

## What is Model Configuration?

Model configuration allows you to customize the behavior of your Pydantic models at the class level. Instead of configuring each field individually, you can set policies that apply to the entire model.

### Configuration Flow

```
+------------------------------------------------------------------+
|                    MODEL CONFIGURATION                           |
+------------------------------------------------------------------+
|                                                                  |
|   class User(BaseModel):                                         |
|       model_config = ConfigDict(                                 |
|           str_strip_whitespace=True,      <-- String handling    |
|           strict=True,                    <-- Type coercion      |
|           frozen=True,                    <-- Immutability       |
|           extra='forbid',                 <-- Extra fields       |
|           validate_assignment=True,       <-- Re-validation      |
|       )                                                          |
|                                                                  |
|       name: str                                                  |
|       age: int                                                   |
|                                                                  |
+------------------------------------------------------------------+
                              |
                              v
+------------------------------------------------------------------+
|                    BEHAVIOR APPLIED                              |
+------------------------------------------------------------------+
|                                                                  |
|   - All string fields auto-strip whitespace                      |
|   - No type coercion (strict types required)                     |
|   - Instance is immutable after creation                         |
|   - Extra fields cause validation error                          |
|   - Changes to fields trigger re-validation                      |
|                                                                  |
+------------------------------------------------------------------+
```

---

## The model_config Dict

### Pydantic v2 Way (Recommended)

In Pydantic v2, model configuration is done using `model_config` with `ConfigDict`:

```python
from pydantic import BaseModel, ConfigDict

class User(BaseModel):
    model_config = ConfigDict(
        str_strip_whitespace=True,
        frozen=True
    )
    
    name: str
    email: str
```

### Migration from v1

```
+------------------------------------------+------------------------------------------+
|           PYDANTIC v1 (OLD)              |           PYDANTIC v2 (NEW)              |
+------------------------------------------+------------------------------------------+
|                                          |                                          |
|  class User(BaseModel):                  |  from pydantic import ConfigDict         |
|                                          |                                          |
|      class Config:                       |  class User(BaseModel):                  |
|          str_strip_whitespace = True     |      model_config = ConfigDict(          |
|          frozen = True                   |          str_strip_whitespace=True,      |
|                                          |          frozen=True                     |
|                                          |      )                                   |
|      name: str                           |                                          |
|      email: str                          |      name: str                           |
|                                          |      email: str                          |
|                                          |                                          |
+------------------------------------------+------------------------------------------+
```

---

## ConfigDict Overview

`ConfigDict` is a TypedDict that provides IDE autocompletion and type checking for configuration options.

```python
from pydantic import BaseModel, ConfigDict

class MyModel(BaseModel):
    # ConfigDict provides:
    # - IDE autocomplete for all options
    # - Type checking for option values
    # - Clear documentation in tooltips
    model_config = ConfigDict(
        # Configuration options go here
    )
```

### Import

```python
from pydantic import ConfigDict
# or
from pydantic.config import ConfigDict
```

---

## String Configuration

### str_strip_whitespace

Automatically strips leading and trailing whitespace from string fields.

```
+------------------------------------------------------------------+
|                    str_strip_whitespace=True                     |
+------------------------------------------------------------------+
|                                                                  |
|   INPUT:  "   hello world   "                                    |
|                    |                                             |
|                    v                                             |
|   OUTPUT: "hello world"                                          |
|                                                                  |
+------------------------------------------------------------------+
```

```python
from pydantic import BaseModel, ConfigDict

class CleanUser(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)
    
    name: str
    email: str

user = CleanUser(name="  John Doe  ", email="  john@example.com  ")
print(user.name)   # "John Doe" (whitespace stripped)
print(user.email)  # "john@example.com"
```

### str_min_length

Sets a minimum length for all string fields in the model.

```python
from pydantic import BaseModel, ConfigDict

class SecureInput(BaseModel):
    model_config = ConfigDict(str_min_length=1)  # No empty strings allowed
    
    username: str
    password: str

# This will fail - empty string
try:
    user = SecureInput(username="", password="secret")
except ValidationError as e:
    print(e)  # String should have at least 1 character
```

### str_max_length

Sets a maximum length for all string fields.

```python
from pydantic import BaseModel, ConfigDict

class LimitedInput(BaseModel):
    model_config = ConfigDict(str_max_length=100)
    
    name: str
    bio: str  # Both fields limited to 100 chars
```

### str_to_lower / str_to_upper

Automatically convert strings to lowercase or uppercase.

```python
from pydantic import BaseModel, ConfigDict

class LowercaseModel(BaseModel):
    model_config = ConfigDict(str_to_lower=True)
    
    email: str
    username: str

user = LowercaseModel(email="John@Example.COM", username="JohnDoe")
print(user.email)     # "john@example.com"
print(user.username)  # "johndoe"
```

---

## Strict Mode

### What is Strict Mode?

Strict mode disables type coercion. Values must be of the exact type specified.

```
+------------------------------------------------------------------+
|              STRICT MODE COMPARISON                              |
+------------------------------------------------------------------+
|                                                                  |
|   strict=False (default)         strict=True                     |
|   ----------------------         -----------                     |
|                                                                  |
|   age: int                       age: int                        |
|   age="25"  --> 25 (OK)          age="25"  --> ERROR!            |
|   age=25    --> 25 (OK)          age=25    --> 25 (OK)           |
|                                                                  |
|   active: bool                   active: bool                    |
|   active=1    --> True (OK)      active=1    --> ERROR!          |
|   active=True --> True (OK)      active=True --> True (OK)       |
|                                                                  |
+------------------------------------------------------------------+
```

### Model-Level Strict Mode

```python
from pydantic import BaseModel, ConfigDict

class StrictUser(BaseModel):
    model_config = ConfigDict(strict=True)
    
    name: str
    age: int
    active: bool

# This works - exact types
user = StrictUser(name="John", age=30, active=True)

# This FAILS - "30" is a string, not an int
try:
    user = StrictUser(name="John", age="30", active=True)
except ValidationError as e:
    print(e)  # Input should be a valid integer
```

### When to Use Strict Mode

```
+------------------------+------------------------------------------+
|   USE STRICT MODE      |   KEEP PERMISSIVE (default)              |
+------------------------+------------------------------------------+
|                        |                                          |
| - Type safety critical | - API endpoints (JSON has limited types) |
| - Internal data models | - User input processing                  |
| - Type bugs hard to    | - Data from external sources             |
|   track down           | - Convenience over strictness            |
| - Performance critical | - Legacy system integration              |
|   (skip coercion)      |                                          |
|                        |                                          |
+------------------------+------------------------------------------+
```

---

## Frozen Models (Immutability)

### What is Frozen?

`frozen=True` makes model instances immutable - once created, they cannot be modified.

```
+------------------------------------------------------------------+
|                    FROZEN MODEL                                  |
+------------------------------------------------------------------+
|                                                                  |
|   model_config = ConfigDict(frozen=True)                         |
|                                                                  |
|   user = User(name="John", age=30)                               |
|                                                                  |
|   user.name = "Jane"   <-- ERROR! Cannot modify frozen instance  |
|   user.age = 31        <-- ERROR! Cannot modify frozen instance  |
|                                                                  |
+------------------------------------------------------------------+
```

```python
from pydantic import BaseModel, ConfigDict

class FrozenUser(BaseModel):
    model_config = ConfigDict(frozen=True)
    
    name: str
    age: int

user = FrozenUser(name="John", age=30)

# Attempting to modify raises an error
try:
    user.name = "Jane"
except ValidationError as e:
    print(e)  # Instance is frozen
```

### Benefits of Frozen Models

```
+------------------------------------------------------------------+
|                    FROZEN MODEL BENEFITS                         |
+------------------------------------------------------------------+
|                                                                  |
|  1. HASHABLE - Can be used as dict keys or in sets               |
|     frozen_user = FrozenUser(name="John", age=30)                |
|     user_set = {frozen_user}  # Works!                           |
|     user_dict = {frozen_user: "some value"}  # Works!            |
|                                                                  |
|  2. THREAD-SAFE - No race conditions from mutations              |
|     Multiple threads can safely read the same instance           |
|                                                                  |
|  3. PREDICTABLE - State cannot change unexpectedly               |
|     Pass to functions without defensive copying                  |
|                                                                  |
+------------------------------------------------------------------+
```

### Creating Modified Copies

Use `model_copy()` to create a modified copy of a frozen instance:

```python
user = FrozenUser(name="John", age=30)

# Create a copy with modifications
new_user = user.model_copy(update={"age": 31})
print(new_user)  # name='John' age=31
```

---

## Extra Fields Handling

### The extra Option

Controls how the model handles fields not defined in the schema.

```
+------------------------------------------------------------------+
|                    EXTRA FIELDS OPTIONS                          |
+------------------------------------------------------------------+
|                                                                  |
|   extra='forbid'     Raise error if extra fields provided        |
|   extra='ignore'     Silently discard extra fields (default)     |
|   extra='allow'      Store extra fields in the model             |
|                                                                  |
+------------------------------------------------------------------+
```

### extra='forbid' (Strict Input)

```python
from pydantic import BaseModel, ConfigDict

class StrictInput(BaseModel):
    model_config = ConfigDict(extra='forbid')
    
    name: str
    age: int

# This works
user = StrictInput(name="John", age=30)

# This FAILS - 'email' is not a defined field
try:
    user = StrictInput(name="John", age=30, email="john@example.com")
except ValidationError as e:
    print(e)  # Extra inputs are not permitted
```

### extra='ignore' (Default)

```python
from pydantic import BaseModel, ConfigDict

class IgnoreExtra(BaseModel):
    model_config = ConfigDict(extra='ignore')  # This is the default
    
    name: str
    age: int

# Extra 'email' field is silently ignored
user = IgnoreExtra(name="John", age=30, email="john@example.com")
print(user)  # name='John' age=30 (no email field)
```

### extra='allow' (Flexible Input)

```python
from pydantic import BaseModel, ConfigDict

class FlexibleModel(BaseModel):
    model_config = ConfigDict(extra='allow')
    
    name: str
    age: int

# Extra fields are stored
user = FlexibleModel(name="John", age=30, email="john@example.com", role="admin")
print(user.name)   # "John"
print(user.email)  # "john@example.com" (accessible as attribute)
print(user.role)   # "admin"

# Extra fields appear in model_dump()
print(user.model_dump())
# {'name': 'John', 'age': 30, 'email': 'john@example.com', 'role': 'admin'}
```

### Comparison Table

```
+------------------------------------------------------------------+
|                EXTRA FIELDS COMPARISON                           |
+------------------------------------------------------------------+
|                                                                  |
|  data = {"name": "John", "age": 30, "unknown": "value"}          |
|                                                                  |
|  +---------------+---------------+---------------+               |
|  | extra='forbid'| extra='ignore'| extra='allow' |               |
|  +---------------+---------------+---------------+               |
|  |               |               |               |               |
|  |  ERROR!       |  Discarded    |  Stored       |               |
|  |  ValidationErr|  name="John"  |  name="John"  |               |
|  |               |  age=30       |  age=30       |               |
|  |               |  (no unknown) |  unknown=     |               |
|  |               |               |    "value"    |               |
|  +---------------+---------------+---------------+               |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Alias Configuration

### populate_by_name

When using aliases, `populate_by_name=True` allows using either the alias OR the field name.

```
+------------------------------------------------------------------+
|                    POPULATE BY NAME                              |
+------------------------------------------------------------------+
|                                                                  |
|   Field: user_name with alias="userName"                         |
|                                                                  |
|   populate_by_name=False (default):                              |
|       {"userName": "John"}    --> OK                             |
|       {"user_name": "John"}   --> ERROR (field not found)        |
|                                                                  |
|   populate_by_name=True:                                         |
|       {"userName": "John"}    --> OK                             |
|       {"user_name": "John"}   --> OK (also works!)               |
|                                                                  |
+------------------------------------------------------------------+
```

```python
from pydantic import BaseModel, ConfigDict, Field

class APIUser(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    
    user_name: str = Field(alias="userName")
    email_address: str = Field(alias="emailAddress")

# Works with aliases (from API)
user1 = APIUser(userName="john_doe", emailAddress="john@example.com")

# Also works with field names (in Python code)
user2 = APIUser(user_name="john_doe", email_address="john@example.com")

print(user1)  # user_name='john_doe' email_address='john@example.com'
print(user2)  # user_name='john_doe' email_address='john@example.com'
```

### Use Case: JavaScript/API to Python Naming Conventions

```python
from pydantic import BaseModel, ConfigDict, Field

class UserProfile(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    
    # JavaScript uses camelCase, Python uses snake_case
    first_name: str = Field(alias="firstName")
    last_name: str = Field(alias="lastName")
    email_verified: bool = Field(alias="emailVerified")
    created_at: str = Field(alias="createdAt")

# Accept data from JavaScript API
js_data = {
    "firstName": "John",
    "lastName": "Doe",
    "emailVerified": True,
    "createdAt": "2024-01-15"
}

user = UserProfile(**js_data)
print(user.first_name)  # Access with Python naming
print(user.last_name)
```

---

## Validate on Assignment

### validate_assignment

When `True`, field validators run every time an attribute is set, not just during initialization.

```
+------------------------------------------------------------------+
|                    VALIDATE ASSIGNMENT                           |
+------------------------------------------------------------------+
|                                                                  |
|   validate_assignment=False (default):                           |
|   ------------------------------------                           |
|   user = User(name="John", age=30)  # Validated                  |
|   user.age = -5                     # NOT validated (no error)   |
|                                                                  |
|   validate_assignment=True:                                      |
|   -------------------------                                      |
|   user = User(name="John", age=30)  # Validated                  |
|   user.age = -5                     # VALIDATED --> ERROR!       |
|                                                                  |
+------------------------------------------------------------------+
```

```python
from pydantic import BaseModel, ConfigDict, Field

class ValidatedUser(BaseModel):
    model_config = ConfigDict(validate_assignment=True)
    
    name: str = Field(min_length=1)
    age: int = Field(ge=0, le=150)

user = ValidatedUser(name="John", age=30)

# This triggers validation
try:
    user.age = -5  # Invalid!
except ValidationError as e:
    print(e)  # Input should be greater than or equal to 0

# This also validates
try:
    user.name = ""  # Invalid!
except ValidationError as e:
    print(e)  # String should have at least 1 character
```

### When to Use validate_assignment

```
+------------------------+------------------------------------------+
|   USE THIS WHEN        |   DON'T USE WHEN                         |
+------------------------+------------------------------------------+
|                        |                                          |
| - Data integrity is    | - High-performance inner loops           |
|   critical             | - Frequently updated objects             |
| - User-facing apps     | - Validated data from trusted sources    |
| - Long-lived objects   | - One-time data processing               |
| - Objects modified     |                                          |
|   after creation       |                                          |
|                        |                                          |
+------------------------+------------------------------------------+
```

---

## Enum Values

### use_enum_values

When `True`, Enum members are converted to their values during validation.

```
+------------------------------------------------------------------+
|                    USE ENUM VALUES                               |
+------------------------------------------------------------------+
|                                                                  |
|   use_enum_values=False (default):                               |
|   --------------------------------                               |
|   user.status = Status.ACTIVE   # Stores the Enum member         |
|   print(user.status)            # Status.ACTIVE                  |
|   type(user.status)             # <enum 'Status'>                |
|                                                                  |
|   use_enum_values=True:                                          |
|   --------------------                                           |
|   user.status = Status.ACTIVE   # Stores the value               |
|   print(user.status)            # "active"                       |
|   type(user.status)             # <class 'str'>                  |
|                                                                  |
+------------------------------------------------------------------+
```

```python
from enum import Enum
from pydantic import BaseModel, ConfigDict

class Status(Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class UserWithEnum(BaseModel):
    model_config = ConfigDict(use_enum_values=True)
    
    name: str
    status: Status

user = UserWithEnum(name="John", status=Status.ACTIVE)
print(user.status)        # "active" (string, not Enum)
print(type(user.status))  # <class 'str'>

# JSON serialization works naturally
print(user.model_dump_json())  # {"name":"John","status":"active"}
```

### Without use_enum_values

```python
class UserWithoutEnumValues(BaseModel):
    name: str
    status: Status

user = UserWithoutEnumValues(name="John", status=Status.ACTIVE)
print(user.status)        # Status.ACTIVE (Enum member)
print(type(user.status))  # <enum 'Status'>

# Still works, but status is the Enum member
print(user.model_dump())  # {'name': 'John', 'status': <Status.ACTIVE: 'active'>}
```

---

## Complete Config Options Reference

### Core Configuration Options

```
+----------------------+----------------------+------------------------------------------+
|       Option         |    Default Value     |           Description                    |
+----------------------+----------------------+------------------------------------------+
| str_strip_whitespace | False                | Strip whitespace from strings            |
| str_min_length       | None                 | Minimum length for all strings           |
| str_max_length       | None                 | Maximum length for all strings           |
| str_to_lower         | False                | Convert strings to lowercase             |
| str_to_upper         | False                | Convert strings to uppercase             |
+----------------------+----------------------+------------------------------------------+
| strict               | False                | Disable type coercion                    |
| frozen               | False                | Make instances immutable                 |
| extra                | 'ignore'             | Handle extra fields: forbid/ignore/allow |
+----------------------+----------------------+------------------------------------------+
| populate_by_name     | False                | Allow field name in addition to alias    |
| validate_assignment  | False                | Re-validate on attribute assignment      |
| use_enum_values      | True                 | Use enum values instead of members       |
+----------------------+----------------------+------------------------------------------+
```

### Serialization Options

```
+----------------------+----------------------+------------------------------------------+
|       Option         |    Default Value     |           Description                    |
+----------------------+----------------------+------------------------------------------+
| ser_json_timedelta   | 'iso8601'            | Serialize timedelta as 'iso8601'/'float' |
| ser_json_bytes       | 'utf8'               | Serialize bytes as 'utf8'/'base64'/'hex' |
| ser_json_inf_nan     | 'null'               | Handle inf/nan: 'null'/'constants'       |
| validate_default     | False                | Validate default values                  |
+----------------------+----------------------+------------------------------------------+
```

### Advanced Options

```
+-------------------------+----------------------+------------------------------------------+
|       Option            |    Default Value     |           Description                    |
+-------------------------+----------------------+------------------------------------------+
| arbitrary_types_allowed | False                | Allow arbitrary types (non-Pydantic)     |
| from_attributes         | False                | Create model from ORM objects            |
| loc_by_alias            | True                 | Use alias in error locations             |
| revalidate_instances    | 'never'              | When to revalidate nested models         |
| coerce_numbers_to_str   | False                | Coerce numbers to strings                |
| regex_engine            | 'rust-regex'         | Regex engine: 'rust-regex'/'python-re'   |
+-------------------------+----------------------+------------------------------------------+
```

### JSON Schema Options

```
+-------------------------+----------------------+------------------------------------------+
|       Option            |    Default Value     |           Description                    |
+-------------------------+----------------------+------------------------------------------+
| title                   | None                 | Title for JSON Schema                    |
| json_schema_extra       | None                 | Extra JSON Schema properties             |
| json_schema_mode_override| None                | Override JSON schema mode                |
+-------------------------+----------------------+------------------------------------------+
```

---

## When to Use Each Option

### Decision Tree

```
+------------------------------------------------------------------+
|               CHOOSING MODEL CONFIGURATION                       |
+------------------------------------------------------------------+

Do you need to clean string input?
    |
    +-- Yes --> str_strip_whitespace=True
    |           str_min_length=1 (no empty strings)
    |
    +-- No --> Leave defaults

Do you need strict type checking?
    |
    +-- Yes (internal data, type safety) --> strict=True
    |
    +-- No (API input, flexibility) --> strict=False (default)

Should instances be immutable?
    |
    +-- Yes (thread safety, hashable) --> frozen=True
    |
    +-- No (need to modify) --> frozen=False (default)

How to handle extra fields?
    |
    +-- Fail fast, strict schema --> extra='forbid'
    |
    +-- Keep extra data --> extra='allow'
    |
    +-- Ignore quietly --> extra='ignore' (default)

Using aliases (API naming)?
    |
    +-- Yes --> populate_by_name=True
    |
    +-- No --> Leave default

Need ongoing validation?
    |
    +-- Yes (long-lived objects) --> validate_assignment=True
    |
    +-- No (create once) --> validate_assignment=False (default)

Using Enums?
    |
    +-- Need string values --> use_enum_values=True
    |
    +-- Need Enum members --> use_enum_values=False
```

### Common Configuration Patterns

```python
from pydantic import BaseModel, ConfigDict

# Pattern 1: Strict API Input
class StrictAPIInput(BaseModel):
    model_config = ConfigDict(
        extra='forbid',           # No unexpected fields
        str_strip_whitespace=True, # Clean input
        str_min_length=1,         # No empty strings
    )

# Pattern 2: Immutable Value Object
class Money(BaseModel):
    model_config = ConfigDict(
        frozen=True,              # Immutable
    )
    amount: float
    currency: str

# Pattern 3: Flexible External Data
class ExternalData(BaseModel):
    model_config = ConfigDict(
        extra='allow',            # Keep unknown fields
        populate_by_name=True,    # Accept both naming conventions
    )

# Pattern 4: Type-Safe Internal Model
class InternalModel(BaseModel):
    model_config = ConfigDict(
        strict=True,              # Exact types required
        validate_assignment=True, # Always valid
        frozen=True,              # Immutable
    )

# Pattern 5: API Response Parsing
class APIResponse(BaseModel):
    model_config = ConfigDict(
        extra='ignore',           # Ignore unknown API fields
        populate_by_name=True,    # Handle camelCase aliases
        use_enum_values=True,     # Simple enum serialization
    )
```

---

## Configuration Inheritance

### Child Models Inherit Config

```python
from pydantic import BaseModel, ConfigDict

class BaseStrictModel(BaseModel):
    model_config = ConfigDict(
        strict=True,
        str_strip_whitespace=True
    )

class User(BaseStrictModel):
    # Inherits strict=True and str_strip_whitespace=True
    name: str
    age: int

class Product(BaseStrictModel):
    # Also inherits the same config
    name: str
    price: float
```

### Overriding Parent Config

```python
class PermissiveChild(BaseStrictModel):
    # Override parent's strict mode
    model_config = ConfigDict(
        strict=False,  # Now permissive
        str_strip_whitespace=True  # Keep this from parent intent
    )
    
    name: str
    quantity: int
```

---

## Quick Reference Card

```
+------------------------------------------------------------------+
|                MODEL CONFIGURATION CHEAT SHEET                   |
+------------------------------------------------------------------+
|                                                                  |
|  SETUP                                                           |
|  -----                                                           |
|  from pydantic import BaseModel, ConfigDict                      |
|                                                                  |
|  class MyModel(BaseModel):                                       |
|      model_config = ConfigDict(...)                              |
|                                                                  |
|  STRING OPTIONS                                                  |
|  --------------                                                  |
|  str_strip_whitespace=True    # "  hi  " -> "hi"                 |
|  str_min_length=1             # No empty strings                 |
|  str_to_lower=True            # "HELLO" -> "hello"               |
|                                                                  |
|  VALIDATION OPTIONS                                              |
|  ------------------                                              |
|  strict=True                  # No type coercion                 |
|  validate_assignment=True     # Re-validate on change            |
|                                                                  |
|  IMMUTABILITY                                                    |
|  ------------                                                    |
|  frozen=True                  # Cannot modify after creation     |
|                                                                  |
|  EXTRA FIELDS                                                    |
|  ------------                                                    |
|  extra='forbid'               # Error on unknown fields          |
|  extra='ignore'               # Silently discard (default)       |
|  extra='allow'                # Store extra fields               |
|                                                                  |
|  ALIASES                                                         |
|  -------                                                         |
|  populate_by_name=True        # Accept alias OR field name       |
|                                                                  |
|  ENUMS                                                           |
|  -----                                                           |
|  use_enum_values=True         # Store value, not Enum member     |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Next Steps

In the next module, we'll explore:
- Serialization with `model_dump()` and `model_dump_json()`
- Custom serializers
- Excluding and including fields
- JSON serialization patterns

---
