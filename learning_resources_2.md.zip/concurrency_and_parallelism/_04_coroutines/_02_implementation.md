# Coroutines in Python - Implementation & Code

## Table of Contents
1. [Creating Coroutines](#1-creating-coroutines)
2. [Running Coroutines](#2-running-coroutines)
3. [Awaitables](#3-awaitables)
4. [Coroutine Chaining](#4-coroutine-chaining)
5. [Concurrent Execution](#5-concurrent-execution)
6. [Practical Patterns](#6-practical-patterns)

---

## 1. Creating Coroutines

### Basic Coroutine Definition

```python
import asyncio

# Define a coroutine with async def
async def say_hello(name: str) -> str:
    print(f"Hello, {name}!")
    return f"Greeted {name}"

# Calling a coroutine returns a coroutine OBJECT (not the result!)
coro = say_hello("World")
print(type(coro))  # <class 'coroutine'>

# Must be awaited or run to execute
result = asyncio.run(say_hello("World"))
print(result)  # "Greeted World"
```

### Coroutine with await

```python
import asyncio

async def fetch_data(url: str) -> str:
    print(f"Fetching {url}...")
    await asyncio.sleep(1)  # Simulate network delay
    print(f"Done fetching {url}")
    return f"Data from {url}"

async def main():
    # await pauses here until fetch_data completes
    result = await fetch_data("http://example.com")
    print(result)

asyncio.run(main())
```

### Coroutine with Parameters and Return Values

```python
import asyncio
from typing import List

async def process_items(items: List[int]) -> List[int]:
    """Process items asynchronously"""
    results = []
    for item in items:
        # Simulate async processing
        await asyncio.sleep(0.1)
        results.append(item * 2)
    return results

async def main():
    items = [1, 2, 3, 4, 5]
    results = await process_items(items)
    print(f"Results: {results}")  # [2, 4, 6, 8, 10]

asyncio.run(main())
```

---

## 2. Running Coroutines

### Method 1: asyncio.run() (Main Entry Point)

```python
import asyncio

async def hello():
    print("Hello!")
    return 42

# From synchronous code - use asyncio.run()
result = asyncio.run(hello())
print(result)  # 42
```

### Method 2: await (Inside Async Context)

```python
import asyncio

async def inner():
    return "inner result"

async def outer():
    # Inside async function, use await
    result = await inner()
    return f"outer got: {result}"

print(asyncio.run(outer()))  # "outer got: inner result"
```

### Method 3: Creating Tasks

```python
import asyncio

async def slow_operation(name: str, delay: float):
    await asyncio.sleep(delay)
    return f"{name} completed"

async def main():
    # Create a task - starts running immediately
    task = asyncio.create_task(slow_operation("Task1", 2))
    
    # Do other things while task runs
    print("Task created, doing other work...")
    await asyncio.sleep(1)
    print("Other work done, waiting for task...")
    
    # Wait for task to complete
    result = await task
    print(result)

asyncio.run(main())
```

### Method 4: Running in Existing Loop

```python
import asyncio

async def my_coroutine():
    return "result"

# If loop is already running (e.g., in Jupyter)
loop = asyncio.get_event_loop()
if loop.is_running():
    # Can't use asyncio.run(), use create_task instead
    task = loop.create_task(my_coroutine())
else:
    # Normal case
    result = loop.run_until_complete(my_coroutine())
```

---

## 3. Awaitables

### What Can You await?

```python
import asyncio

# 1. Coroutines
async def my_coroutine():
    return "coroutine result"

# 2. Tasks
async def main():
    coro = my_coroutine()
    task = asyncio.create_task(my_coroutine())
    
    # Both are awaitable
    result1 = await coro   # Await coroutine
    result2 = await task   # Await task

# 3. Futures
async def with_future():
    loop = asyncio.get_event_loop()
    future = loop.create_future()
    
    # Something will set the result later
    async def set_result():
        await asyncio.sleep(1)
        future.set_result("future result")
    
    asyncio.create_task(set_result())
    result = await future  # Wait for result
    return result
```

### Custom Awaitable Objects

```python
import asyncio

class AsyncResource:
    """Custom awaitable class"""
    
    def __init__(self, value):
        self.value = value
    
    def __await__(self):
        # Must return an iterator
        # Typically delegate to another awaitable
        return self._fetch().__await__()
    
    async def _fetch(self):
        await asyncio.sleep(1)  # Simulate work
        return self.value * 2

async def main():
    resource = AsyncResource(21)
    result = await resource  # Uses __await__
    print(result)  # 42

asyncio.run(main())
```

### Coroutine vs Task Behavior

```python
import asyncio

async def work():
    print("Starting work")
    await asyncio.sleep(1)
    print("Work done")
    return "result"

async def main():
    # Coroutine: doesn't start until awaited
    coro = work()
    print("Coroutine created")
    await asyncio.sleep(0.5)
    print("About to await coroutine")
    await coro  # NOW it starts
    
    print("\n--- Task version ---\n")
    
    # Task: starts immediately when created
    task = asyncio.create_task(work())
    print("Task created")
    await asyncio.sleep(0.5)  # Task is already running!
    print("About to await task")
    await task  # Just waiting for completion

asyncio.run(main())
```

---

## 4. Coroutine Chaining

### Sequential Chaining

```python
import asyncio

async def step1():
    await asyncio.sleep(1)
    return "Step 1 done"

async def step2(prev_result):
    await asyncio.sleep(1)
    return f"{prev_result} -> Step 2 done"

async def step3(prev_result):
    await asyncio.sleep(1)
    return f"{prev_result} -> Step 3 done"

async def sequential_chain():
    """Each step waits for the previous"""
    r1 = await step1()
    r2 = await step2(r1)
    r3 = await step3(r2)
    return r3

result = asyncio.run(sequential_chain())
print(result)  # "Step 1 done -> Step 2 done -> Step 3 done"
# Total time: ~3 seconds
```

### Parallel Execution with gather()

```python
import asyncio

async def task(name, delay):
    await asyncio.sleep(delay)
    return f"{name} completed"

async def parallel_tasks():
    """All tasks run concurrently"""
    results = await asyncio.gather(
        task("A", 2),
        task("B", 1),
        task("C", 3),
    )
    return results

results = asyncio.run(parallel_tasks())
print(results)  # ["A completed", "B completed", "C completed"]
# Total time: ~3 seconds (max of all, not sum!)
```

### Mixed Sequential and Parallel

```python
import asyncio

async def fetch_user(user_id):
    await asyncio.sleep(0.5)
    return {"id": user_id, "name": f"User{user_id}"}

async def fetch_user_posts(user_id):
    await asyncio.sleep(0.3)
    return [f"Post{i}" for i in range(3)]

async def fetch_user_friends(user_id):
    await asyncio.sleep(0.4)
    return [f"Friend{i}" for i in range(5)]

async def get_user_data(user_id):
    # First: fetch user (sequential - need user first)
    user = await fetch_user(user_id)
    
    # Then: fetch posts and friends in parallel
    posts, friends = await asyncio.gather(
        fetch_user_posts(user_id),
        fetch_user_friends(user_id)
    )
    
    return {
        "user": user,
        "posts": posts,
        "friends": friends
    }

result = asyncio.run(get_user_data(1))
print(result)
# Total time: ~0.9s (0.5 + max(0.3, 0.4))
```

---

## 5. Concurrent Execution

### asyncio.gather() - Run Multiple Coroutines

```python
import asyncio

async def fetch(url):
    await asyncio.sleep(1)
    return f"Data from {url}"

async def main():
    # All fetches run concurrently
    results = await asyncio.gather(
        fetch("url1"),
        fetch("url2"),
        fetch("url3"),
        return_exceptions=True  # Don't fail if one raises
    )
    return results

results = asyncio.run(main())
print(results)  # ["Data from url1", "Data from url2", "Data from url3"]
```

### asyncio.wait() - More Control

```python
import asyncio

async def task(n):
    await asyncio.sleep(n)
    if n == 2:
        raise ValueError("Task 2 failed")
    return f"Task {n} done"

async def main():
    tasks = [
        asyncio.create_task(task(1)),
        asyncio.create_task(task(2)),
        asyncio.create_task(task(3)),
    ]
    
    # Wait with different strategies
    done, pending = await asyncio.wait(
        tasks,
        return_when=asyncio.FIRST_COMPLETED  # or ALL_COMPLETED, FIRST_EXCEPTION
    )
    
    print(f"Done: {len(done)}, Pending: {len(pending)}")
    
    for t in done:
        try:
            print(t.result())
        except Exception as e:
            print(f"Error: {e}")

asyncio.run(main())
```

### asyncio.as_completed() - Process Results as They Arrive

```python
import asyncio

async def fetch(url, delay):
    await asyncio.sleep(delay)
    return f"Data from {url}"

async def main():
    coros = [
        fetch("fast.com", 0.5),
        fetch("slow.com", 2),
        fetch("medium.com", 1),
    ]
    
    # Process results as they complete (fastest first)
    for coro in asyncio.as_completed(coros):
        result = await coro
        print(result)

asyncio.run(main())
# Output order:
# Data from fast.com (after 0.5s)
# Data from medium.com (after 1s)
# Data from slow.com (after 2s)
```

### Creating Multiple Tasks

```python
import asyncio

async def worker(n):
    await asyncio.sleep(0.5)
    return n * 2

async def main():
    # Create all tasks at once
    tasks = [asyncio.create_task(worker(i)) for i in range(10)]
    
    # Wait for all to complete
    results = await asyncio.gather(*tasks)
    print(results)  # [0, 2, 4, 6, 8, 10, 12, 14, 16, 18]

asyncio.run(main())
# Total time: ~0.5s (all run concurrently)
```

---

## 6. Practical Patterns

### Pattern 1: Timeout Handling

```python
import asyncio

async def slow_operation():
    await asyncio.sleep(10)
    return "completed"

async def with_timeout():
    try:
        # Cancel if takes more than 2 seconds
        result = await asyncio.wait_for(slow_operation(), timeout=2.0)
        return result
    except asyncio.TimeoutError:
        return "timed out"

result = asyncio.run(with_timeout())
print(result)  # "timed out"
```

### Pattern 2: Retry Logic

```python
import asyncio
import random

async def flaky_operation():
    """Operation that sometimes fails"""
    if random.random() < 0.7:
        raise ValueError("Random failure")
    return "success"

async def retry(coro_func, max_attempts=3, delay=1):
    """Retry a coroutine with exponential backoff"""
    for attempt in range(max_attempts):
        try:
            return await coro_func()
        except Exception as e:
            if attempt == max_attempts - 1:
                raise
            print(f"Attempt {attempt + 1} failed: {e}")
            await asyncio.sleep(delay * (2 ** attempt))

async def main():
    result = await retry(flaky_operation, max_attempts=5)
    print(f"Result: {result}")

asyncio.run(main())
```

### Pattern 3: Rate Limiting

```python
import asyncio
import time

class RateLimiter:
    def __init__(self, rate: float):
        """rate: calls per second"""
        self.rate = rate
        self.tokens = rate
        self.last_update = time.monotonic()
        self.lock = asyncio.Lock()
    
    async def acquire(self):
        async with self.lock:
            now = time.monotonic()
            elapsed = now - self.last_update
            self.tokens = min(self.rate, self.tokens + elapsed * self.rate)
            self.last_update = now
            
            if self.tokens < 1:
                wait_time = (1 - self.tokens) / self.rate
                await asyncio.sleep(wait_time)
                self.tokens = 0
            else:
                self.tokens -= 1

limiter = RateLimiter(rate=2)  # 2 calls per second

async def rate_limited_request(url):
    await limiter.acquire()
    print(f"{time.time():.2f} - Requesting {url}")
    await asyncio.sleep(0.1)
    return f"Data from {url}"

async def main():
    tasks = [rate_limited_request(f"url{i}") for i in range(10)]
    results = await asyncio.gather(*tasks)

asyncio.run(main())
```

### Pattern 4: Producer-Consumer

```python
import asyncio

async def producer(queue: asyncio.Queue, n: int):
    """Produce items"""
    for i in range(n):
        await asyncio.sleep(0.1)  # Simulate work
        await queue.put(f"item-{i}")
        print(f"Produced item-{i}")
    await queue.put(None)  # Signal end

async def consumer(queue: asyncio.Queue, name: str):
    """Consume items"""
    while True:
        item = await queue.get()
        if item is None:
            queue.put_nowait(None)  # Pass sentinel to other consumers
            break
        await asyncio.sleep(0.2)  # Simulate processing
        print(f"{name} consumed {item}")
        queue.task_done()

async def main():
    queue = asyncio.Queue(maxsize=5)
    
    # Start producer and multiple consumers
    await asyncio.gather(
        producer(queue, 10),
        consumer(queue, "Consumer-1"),
        consumer(queue, "Consumer-2"),
    )

asyncio.run(main())
```

### Pattern 5: Async Context Manager

```python
import asyncio

class AsyncResource:
    async def __aenter__(self):
        print("Acquiring resource...")
        await asyncio.sleep(0.5)  # Simulate async setup
        print("Resource acquired")
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        print("Releasing resource...")
        await asyncio.sleep(0.2)  # Simulate async cleanup
        print("Resource released")
        return False  # Don't suppress exceptions
    
    async def do_work(self):
        print("Doing work...")
        await asyncio.sleep(0.3)
        return "work result"

async def main():
    async with AsyncResource() as resource:
        result = await resource.do_work()
        print(f"Got: {result}")

asyncio.run(main())
```

---

## Quick Reference

```python
import asyncio

# Define coroutine
async def my_coro():
    await asyncio.sleep(1)
    return "result"

# Run from sync code
result = asyncio.run(my_coro())

# Run from async code
async def main():
    result = await my_coro()

# Create task (starts immediately)
task = asyncio.create_task(my_coro())

# Run multiple concurrently
results = await asyncio.gather(coro1(), coro2(), coro3())

# With timeout
result = await asyncio.wait_for(my_coro(), timeout=5.0)

# Wait for first completion
done, pending = await asyncio.wait(tasks, return_when=FIRST_COMPLETED)

# Process as completed
for coro in asyncio.as_completed(coros):
    result = await coro
```

---

*Next: [Deep Dive](_03_deep_dive.md)*
