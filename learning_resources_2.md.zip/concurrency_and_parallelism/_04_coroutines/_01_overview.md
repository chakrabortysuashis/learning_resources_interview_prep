# Coroutines in Python - Overview

## What is a Coroutine? (The Simple Explanation)

Imagine you're reading a **really long book**. You don't have to finish the whole book in one sitting. You can:
1. Read for a while
2. Put a **bookmark** where you stopped
3. Do other things
4. Come back and **continue from the bookmark**

**A coroutine is like that book** - it's a function that can pause itself, let other things happen, and then resume from where it left off!

```
┌─────────────────────────────────────────────────────────────────────┐
│                    THE BOOKMARK ANALOGY                              │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  REGULAR FUNCTION (Must finish in one go):                          │
│                                                                     │
│  📖 Start reading ─────────────────────────────────────▶ Finish     │
│     Can't stop in the middle!                                       │
│                                                                     │
│  COROUTINE (Can pause and resume):                                  │
│                                                                     │
│  📖 Start reading ──▶ 🔖 Pause ──▶ Resume ──▶ 🔖 Pause ──▶ Finish  │
│                          │           ▲                              │
│                          └───────────┘                              │
│                       (Other things happen)                         │
│                                                                     │
│  async def read_book():                                             │
│      read_chapter_1()                                               │
│      await take_a_break()  # 🔖 Pause here, let others run         │
│      read_chapter_2()                                               │
│      await take_a_break()  # 🔖 Pause again                        │
│      read_chapter_3()                                               │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Why Do We Need Coroutines?

### The Waiting Problem

Imagine a **restaurant waiter** who serves only one customer at a time:

```
┌─────────────────────────────────────────────────────────────────────┐
│              THE INEFFICIENT WAITER (Regular Functions)              │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Customer A orders → Waiter takes order                             │
│                   → Waiter stands waiting for food... ⏳            │
│                   → Waiter stands waiting... ⏳                     │
│                   → Food ready! Serve customer A                    │
│                                                                     │
│  Customer B orders → Waiter takes order                             │
│                   → Waiter stands waiting for food... ⏳            │
│                   → ...                                             │
│                                                                     │
│  ❌ Customers B, C, D wait while waiter does NOTHING!               │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│               THE EFFICIENT WAITER (Coroutines)                      │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Customer A orders → Waiter: "I'll wait for your food"              │
│                   → await kitchen() # Pauses, goes to B             │
│                                                                     │
│  Customer B orders → Waiter takes order                             │
│                   → await kitchen() # Pauses, goes to C             │
│                                                                     │
│  Customer C orders → Waiter takes order                             │
│                   → await kitchen() # Pauses                        │
│                                                                     │
│  Customer A's food ready! → Resume A → Serve                        │
│  Customer B's food ready! → Resume B → Serve                        │
│  Customer C's food ready! → Resume C → Serve                        │
│                                                                     │
│  ✅ Waiter serves EVERYONE efficiently without standing around!     │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

**Coroutines let your code do useful work instead of waiting around!**

---

## The Magic Words: `async` and `await`

### `async def` - "This function can pause"

```python
# Regular function - runs start to finish
def regular_function():
    print("Start")
    time.sleep(1)  # Blocks everything!
    print("End")

# Coroutine - CAN pause
async def coroutine_function():
    print("Start")
    await asyncio.sleep(1)  # Pauses here, lets others run
    print("End")
```

### `await` - "Pause here until this is done"

```
┌─────────────────────────────────────────────────────────────────────┐
│                    WHAT await DOES                                   │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  async def make_breakfast():                                        │
│      print("Start making breakfast")                                │
│                                                                     │
│      await boil_water()     # ← "Pause here until water boils"     │
│                             #   While waiting, other tasks can run  │
│                                                                     │
│      await toast_bread()    # ← "Pause here until bread is toasted"│
│                                                                     │
│      print("Breakfast ready!")                                      │
│                                                                     │
│  Timeline:                                                          │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │ make_breakfast: [Start]→[await]   [Resume]→[await] [Resume] │   │
│  │                         ↓              ↑         ↓       ↑   │   │
│  │ boil_water:             [boiling...]───┘                     │   │
│  │ toast_bread:                             [toasting...]───┘   │   │
│  │                                                              │   │
│  │ OTHER tasks can run during the waits!                        │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Coroutine vs Regular Function

```
┌─────────────────────────────────────────────────────────────────────┐
│              REGULAR FUNCTION vs COROUTINE                           │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  REGULAR FUNCTION                 COROUTINE                         │
│  ────────────────                 ─────────                         │
│                                                                     │
│  def greet():                     async def greet():                │
│      return "Hello"                   return "Hello"                │
│                                                                     │
│  # Calling it:                    # Calling it:                     │
│  result = greet()                 coro = greet()  # Returns object! │
│  print(result)  # "Hello"         # NOT executed yet!               │
│                                                                     │
│                                   result = await greet()  # NOW run │
│                                   print(result)  # "Hello"          │
│                                                                     │
│  • Runs immediately               • Returns coroutine OBJECT        │
│  • Returns the result             • Must be awaited to run          │
│  • Can't pause                    • Can pause with await            │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## The Power of Coroutines: Running Multiple Things

```python
# WITHOUT coroutines (Sequential - SLOW)
def download_files():
    download("file1.txt")  # 2 seconds
    download("file2.txt")  # 2 seconds
    download("file3.txt")  # 2 seconds
    # Total: 6 seconds

# WITH coroutines (Concurrent - FAST)
async def download_files():
    await asyncio.gather(
        download("file1.txt"),  # All start
        download("file2.txt"),  # at the
        download("file3.txt"),  # same time!
    )
    # Total: ~2 seconds (overlapping waits)
```

```
┌─────────────────────────────────────────────────────────────────────┐
│                    SEQUENTIAL vs CONCURRENT                          │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  SEQUENTIAL (Regular):                                              │
│  File 1: [████████████████████]                                     │
│  File 2:                       [████████████████████]               │
│  File 3:                                             [████████████] │
│  ───────────────────────────────────────────────────────────────▶  │
│  0s                            2s                    4s          6s │
│                                                                     │
│  CONCURRENT (Coroutines):                                           │
│  File 1: [████████████████████]                                     │
│  File 2: [████████████████████]                                     │
│  File 3: [████████████████████]                                     │
│  ───────────────────────────────────────────────────────────────▶  │
│  0s                            2s                                   │
│                                                                     │
│  3x faster! (All downloads happen at the same time)                 │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Key Concepts

### 1. Coroutines Don't Run Themselves

```python
async def hello():
    print("Hello!")
    return 42

# This does NOT run the coroutine!
result = hello()
print(type(result))  # <class 'coroutine'>

# You need to await it (inside another async function)
# OR run it with asyncio.run()
import asyncio
result = asyncio.run(hello())  # NOW it runs
print(result)  # 42
```

### 2. await Can Only Be Used Inside async Functions

```python
# WRONG - can't await in regular function
def my_function():
    await asyncio.sleep(1)  # SyntaxError!

# RIGHT - await inside async function
async def my_coroutine():
    await asyncio.sleep(1)  # OK!
```

### 3. Coroutines Are Single-Threaded

```
┌─────────────────────────────────────────────────────────────────────┐
│           THREADING vs COROUTINES: KEY DIFFERENCE                    │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  THREADING (Multiple threads):                                      │
│  ┌────────────┐ ┌────────────┐ ┌────────────┐                      │
│  │  Thread 1  │ │  Thread 2  │ │  Thread 3  │                      │
│  │  [running] │ │  [running] │ │  [running] │                      │
│  └────────────┘ └────────────┘ └────────────┘                      │
│  Multiple threads, OS switches between them (preemptive)            │
│                                                                     │
│  COROUTINES (Single thread, many tasks):                            │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │                    ONE THREAD                                  │  │
│  │  Task A: [run]→[await]     [run]→[await]     [run]           │  │
│  │  Task B:       [run]→[await]    [run]→[await]                │  │
│  │  Task C:              [run]→[await]    [run]                 │  │
│  │                                                              │  │
│  │  Tasks voluntarily pause (cooperative)                        │  │
│  └──────────────────────────────────────────────────────────────┘  │
│                                                                     │
│  • No race conditions (only one thing runs at a time)              │
│  • Lower overhead (no thread switching)                             │
│  • YOU control when tasks switch (at await points)                 │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Simple Mental Model

Think of coroutines like a **TV remote**:

```
┌─────────────────────────────────────────────────────────────────────┐
│                    THE TV REMOTE ANALOGY                             │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  You're watching Channel 1 (Task A) - a commercial comes on         │
│      ↓                                                              │
│  await commercial_break()  # Pause Channel 1                        │
│      ↓                                                              │
│  Switch to Channel 2 (Task B) - something interesting!              │
│      ↓                                                              │
│  Channel 2 has a commercial too                                     │
│      ↓                                                              │
│  await commercial_break()  # Pause Channel 2                        │
│      ↓                                                              │
│  Switch to Channel 3 (Task C)                                       │
│      ↓                                                              │
│  Channel 1's show is back!                                          │
│      ↓                                                              │
│  Resume Channel 1                                                   │
│                                                                     │
│  You're ONE person with ONE TV, but you efficiently "watch"         │
│  multiple channels by switching during boring parts!                │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Quick Summary

| Concept | Explanation |
|---------|-------------|
| **Coroutine** | A function that can pause and resume |
| **async def** | Marks a function as a coroutine |
| **await** | Pauses here until something completes |
| **asyncio.run()** | Runs a coroutine from regular code |
| **Concurrency** | Multiple tasks making progress (not parallel!) |

---

## Key Takeaways

1. **Coroutines can pause** - Unlike regular functions, they can stop and continue later
2. **`async def`** creates a coroutine
3. **`await`** pauses until something is done, letting other tasks run
4. **Single-threaded** - Only one thing runs at a time (no race conditions!)
5. **Great for I/O** - Perfect when you're waiting for network, files, databases
6. **Cooperative** - YOU decide when tasks switch (at `await` points)

---

*Next: [Implementation & Code](_02_implementation.md)*
