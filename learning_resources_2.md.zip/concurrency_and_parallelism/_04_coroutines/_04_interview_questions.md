# Coroutines in Python - Interview Questions

## Table of Contents
1. [Basic Questions](#basic-questions)
2. [Intermediate Questions](#intermediate-questions)
3. [Advanced Questions](#advanced-questions)
4. [Scenario-Based Questions](#scenario-based-questions)
5. [Code Analysis Questions](#code-analysis-questions)

---

## Basic Questions

### Q1: What is a coroutine in Python?

<details>
<summary>Answer</summary>

A coroutine is a specialized function that can:
- **Pause** its execution at specific points (`await`)
- **Resume** later from where it paused
- Allow other code to run during the pause

```python
async def my_coroutine():
    print("Start")
    await asyncio.sleep(1)  # Pause here
    print("Resumed")         # Continue here later
    return "Done"
```

**Key characteristics:**
- Defined with `async def`
- Returns a coroutine object when called (not the result!)
- Must be `awaited` or run with `asyncio.run()` to execute
- Single-threaded concurrency (cooperative multitasking)

</details>

---

### Q2: What's the difference between `async def` and a regular `def`?

<details>
<summary>Answer</summary>

| Aspect | `def func()` | `async def func()` |
|--------|--------------|-------------------|
| **Returns** | Actual result | Coroutine object |
| **Execution** | Runs immediately | Must be awaited/run |
| **Can use await** | No | Yes |
| **Blocking** | Blocks caller | Can yield control |

```python
def regular():
    return 42

async def coroutine():
    return 42

# Regular function
result = regular()  # 42 immediately

# Coroutine
coro = coroutine()  # <coroutine object>
result = asyncio.run(coro)  # NOW runs, returns 42
```

**Important:** Calling an async function doesn't execute it - it creates a coroutine object that must be awaited.

</details>

---

### Q3: Why can't you use `await` outside an async function?

<details>
<summary>Answer</summary>

`await` requires a running event loop and async context because:

1. **Suspension mechanism:** `await` suspends the current coroutine and returns control to the event loop
2. **No event loop in sync code:** Regular functions don't have an event loop managing them
3. **No way to resume:** Without async context, there's nothing to resume the paused code

```python
# WRONG - SyntaxError
def regular():
    await asyncio.sleep(1)  # Can't await here!

# RIGHT
async def async_func():
    await asyncio.sleep(1)  # OK - in async context

# To call from sync code, use asyncio.run()
asyncio.run(async_func())
```

</details>

---

### Q4: What's the difference between a coroutine and a task?

<details>
<summary>Answer</summary>

| Aspect | Coroutine | Task |
|--------|-----------|------|
| **Created by** | `async def func()` | `asyncio.create_task(coro)` |
| **Starts running** | Only when awaited | Immediately upon creation |
| **Scheduling** | Sequential | Concurrent |
| **Cancellable** | No (directly) | Yes |
| **Can track state** | Limited | Yes (done(), result(), etc.) |

```python
async def work():
    await asyncio.sleep(1)
    return "done"

async def main():
    # Coroutine - won't start until awaited
    coro = work()  # Nothing happens yet
    result = await coro  # NOW it runs
    
    # Task - starts immediately
    task = asyncio.create_task(work())  # Starts running!
    # Do other things while task runs
    result = await task  # Get result when ready
```

**Use task when:** You want concurrent execution
**Use coroutine when:** Sequential execution is fine

</details>

---

## Intermediate Questions

### Q5: Explain `asyncio.gather()` vs `asyncio.wait()` vs `asyncio.as_completed()`.

<details>
<summary>Answer</summary>

| Function | Returns | Order | Error Handling |
|----------|---------|-------|----------------|
| `gather()` | List of results | Input order | `return_exceptions=True` |
| `wait()` | (done, pending) sets | Completion order | Manual |
| `as_completed()` | Iterator | Completion order | Manual |

```python
import asyncio

async def task(n, delay):
    await asyncio.sleep(delay)
    if n == 2:
        raise ValueError("Task 2 failed")
    return f"Task {n}"

# gather() - returns results in input order
results = await asyncio.gather(
    task(1, 0.3),
    task(2, 0.1),  # Fails
    task(3, 0.2),
    return_exceptions=True  # Don't fail all on exception
)
# results: ["Task 1", ValueError(...), "Task 3"]

# wait() - returns sets of done/pending tasks
done, pending = await asyncio.wait(
    [task(1, 0.3), task(2, 0.1), task(3, 0.2)],
    return_when=asyncio.FIRST_COMPLETED
)

# as_completed() - process results as they finish
for coro in asyncio.as_completed([task(1, 0.3), task(2, 0.1)]):
    result = await coro  # Fastest first
```

**Use cases:**
- `gather()`: Wait for all, need all results
- `wait()`: Need control (first completed, timeouts)
- `as_completed()`: Process results as available

</details>

---

### Q6: How do you handle timeouts with coroutines?

<details>
<summary>Answer</summary>

```python
import asyncio

async def slow_operation():
    await asyncio.sleep(10)
    return "completed"

# Method 1: wait_for() - cancels on timeout
async def with_wait_for():
    try:
        result = await asyncio.wait_for(slow_operation(), timeout=2.0)
        return result
    except asyncio.TimeoutError:
        return "timed out"

# Method 2: timeout() context manager (Python 3.11+)
async def with_timeout_cm():
    try:
        async with asyncio.timeout(2.0):
            return await slow_operation()
    except asyncio.TimeoutError:
        return "timed out"

# Method 3: wait() with timeout
async def with_wait():
    task = asyncio.create_task(slow_operation())
    done, pending = await asyncio.wait([task], timeout=2.0)
    
    if pending:
        task.cancel()
        return "timed out"
    return task.result()
```

**Key difference:** `wait_for()` cancels the coroutine on timeout, while `wait()` returns pending tasks for manual handling.

</details>

---

### Q7: What is the awaitable protocol?

<details>
<summary>Answer</summary>

An object is **awaitable** if it has an `__await__()` method that returns an iterator.

```python
class MyAwaitable:
    def __init__(self, value):
        self.value = value
    
    def __await__(self):
        """Must return an iterator"""
        # Typically delegate to a coroutine
        async def _impl():
            await asyncio.sleep(0.1)
            return self.value * 2
        return _impl().__await__()

async def main():
    result = await MyAwaitable(21)  # Uses __await__
    print(result)  # 42
```

**Three awaitable types:**
1. Coroutines (`async def` functions)
2. Tasks (`asyncio.create_task()`)
3. Objects with `__await__` method

```python
import collections.abc

# Check if awaitable
isinstance(obj, collections.abc.Awaitable)
```

</details>

---

### Q8: How do you cancel a coroutine/task?

<details>
<summary>Answer</summary>

```python
import asyncio

async def long_running():
    try:
        while True:
            print("Working...")
            await asyncio.sleep(1)
    except asyncio.CancelledError:
        print("Cancelled! Cleaning up...")
        # Cleanup code here
        raise  # Re-raise to propagate

async def main():
    # Create task
    task = asyncio.create_task(long_running())
    
    # Let it run for a bit
    await asyncio.sleep(2.5)
    
    # Cancel it
    task.cancel()
    
    # Wait for cancellation to complete
    try:
        await task
    except asyncio.CancelledError:
        print("Task successfully cancelled")

asyncio.run(main())
```

**Best practices:**
1. Always handle `CancelledError` in long-running coroutines
2. Re-raise `CancelledError` after cleanup
3. Use `asyncio.shield()` to protect critical sections from cancellation

```python
# Protected section
await asyncio.shield(critical_operation())
```

</details>

---

## Advanced Questions

### Q9: Explain the difference between generator-based and native coroutines.

<details>
<summary>Answer</summary>

**Generator-based (Python 3.4, legacy):**
```python
@asyncio.coroutine
def old_style():
    yield from asyncio.sleep(1)
    return "done"
```

**Native coroutines (Python 3.5+, recommended):**
```python
async def new_style():
    await asyncio.sleep(1)
    return "done"
```

| Feature | Generator-based | Native |
|---------|----------------|--------|
| Syntax | `@asyncio.coroutine`, `yield from` | `async def`, `await` |
| Type | `generator` | `coroutine` |
| Can use `yield` | Yes (confusing!) | No (use async generator) |
| `inspect.iscoroutine()` | False | True |
| Status | Deprecated | Current standard |

**Why native is better:**
- Clearer intent (can't confuse with generators)
- Better error messages
- Type checking support
- Cannot accidentally `yield` in coroutine

</details>

---

### Q10: What are the states of a coroutine?

<details>
<summary>Answer</summary>

```
CORO_CREATED → CORO_RUNNING → CORO_SUSPENDED → CORO_CLOSED
```

**States:**
1. **CORO_CREATED:** Coroutine created but not started
2. **CORO_RUNNING:** Currently executing
3. **CORO_SUSPENDED:** Paused at await point
4. **CORO_CLOSED:** Finished or cleaned up

```python
import inspect
import asyncio

async def demo():
    await asyncio.sleep(1)

coro = demo()
print(inspect.getcoroutinestate(coro))  # CORO_CREATED

# After starting (would show CORO_RUNNING inside)
# After await (would show CORO_SUSPENDED)
# After completion (CORO_CLOSED)

coro.close()  # Clean up
```

**Coroutine attributes:**
- `cr_frame`: Current execution frame
- `cr_code`: Code object
- `cr_await`: Object being awaited (or None)
- `cr_running`: Whether currently running

</details>

---

### Q11: How do async context managers and iterators work?

<details>
<summary>Answer</summary>

**Async Context Manager (`async with`):**
```python
class AsyncResource:
    async def __aenter__(self):
        print("Acquiring...")
        await setup()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        print("Releasing...")
        await cleanup()
        return False  # Don't suppress exceptions

async with AsyncResource() as r:
    await r.do_work()
```

**Async Iterator (`async for`):**
```python
class AsyncRange:
    def __init__(self, end):
        self.current = 0
        self.end = end
    
    def __aiter__(self):
        return self
    
    async def __anext__(self):
        if self.current >= self.end:
            raise StopAsyncIteration
        await asyncio.sleep(0.1)
        value = self.current
        self.current += 1
        return value

async for i in AsyncRange(5):
    print(i)
```

**Async Generator (simpler):**
```python
async def async_range(end):
    for i in range(end):
        await asyncio.sleep(0.1)
        yield i

async for i in async_range(5):
    print(i)
```

</details>

---

## Scenario-Based Questions

### Q12: How would you run multiple API calls concurrently?

<details>
<summary>Answer</summary>

```python
import asyncio
import aiohttp

async def fetch(session, url):
    async with session.get(url) as response:
        return await response.json()

async def fetch_all(urls):
    async with aiohttp.ClientSession() as session:
        # Create all tasks
        tasks = [fetch(session, url) for url in urls]
        # Run concurrently
        results = await asyncio.gather(*tasks, return_exceptions=True)
        return results

# Usage
urls = [
    "https://api.example.com/1",
    "https://api.example.com/2",
    "https://api.example.com/3",
]

results = asyncio.run(fetch_all(urls))
```

**With rate limiting:**
```python
import asyncio

semaphore = asyncio.Semaphore(5)  # Max 5 concurrent

async def fetch_with_limit(session, url):
    async with semaphore:
        async with session.get(url) as response:
            return await response.json()

async def fetch_all_limited(urls):
    async with aiohttp.ClientSession() as session:
        tasks = [fetch_with_limit(session, url) for url in urls]
        return await asyncio.gather(*tasks)
```

</details>

---

### Q13: Implement a retry decorator for async functions.

<details>
<summary>Answer</summary>

```python
import asyncio
import functools
from typing import Type

def async_retry(
    max_attempts: int = 3,
    delay: float = 1.0,
    backoff: float = 2.0,
    exceptions: tuple = (Exception,)
):
    """
    Retry decorator for async functions with exponential backoff
    """
    def decorator(func):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            last_exception = None
            current_delay = delay
            
            for attempt in range(max_attempts):
                try:
                    return await func(*args, **kwargs)
                except exceptions as e:
                    last_exception = e
                    if attempt < max_attempts - 1:
                        print(f"Attempt {attempt + 1} failed: {e}")
                        print(f"Retrying in {current_delay}s...")
                        await asyncio.sleep(current_delay)
                        current_delay *= backoff
            
            raise last_exception
        
        return wrapper
    return decorator

# Usage
@async_retry(max_attempts=3, delay=1.0, exceptions=(ConnectionError, TimeoutError))
async def fetch_data(url):
    # May fail sometimes
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as response:
            return await response.json()
```

</details>

---

### Q14: How do you bridge sync and async code?

<details>
<summary>Answer</summary>

**Calling async from sync:**
```python
import asyncio

async def async_function():
    await asyncio.sleep(1)
    return "result"

# Option 1: asyncio.run() (creates new event loop)
result = asyncio.run(async_function())

# Option 2: Get existing loop
loop = asyncio.get_event_loop()
result = loop.run_until_complete(async_function())
```

**Calling sync from async:**
```python
import asyncio

def blocking_io():
    import time
    time.sleep(2)
    return "result"

async def main():
    loop = asyncio.get_event_loop()
    
    # Run in thread pool (doesn't block event loop)
    result = await loop.run_in_executor(None, blocking_io)
    
    # With ProcessPoolExecutor for CPU-bound
    from concurrent.futures import ProcessPoolExecutor
    with ProcessPoolExecutor() as pool:
        result = await loop.run_in_executor(pool, cpu_intensive)
    
    return result
```

**Common pattern for libraries:**
```python
def sync_api():
    """Sync wrapper for async implementation"""
    return asyncio.run(async_api())

async def async_api():
    """Actual async implementation"""
    await do_work()
```

</details>

---

## Code Analysis Questions

### Q15: What's wrong with this code?

```python
import asyncio

async def fetch(url):
    await asyncio.sleep(1)
    return f"Data from {url}"

async def main():
    urls = ["url1", "url2", "url3"]
    results = []
    
    for url in urls:
        result = await fetch(url)  # Problem here
        results.append(result)
    
    return results
```

<details>
<summary>Answer</summary>

**Problem:** The code is **sequential**, not concurrent!

Each `await fetch(url)` waits for completion before starting the next. Total time: 3 seconds (1s × 3).

**Fixed (concurrent):**
```python
async def main():
    urls = ["url1", "url2", "url3"]
    
    # All fetches run concurrently
    results = await asyncio.gather(
        *(fetch(url) for url in urls)
    )
    return results
    
# Total time: ~1 second (all run at same time)
```

**Or with tasks:**
```python
async def main():
    urls = ["url1", "url2", "url3"]
    
    tasks = [asyncio.create_task(fetch(url)) for url in urls]
    results = await asyncio.gather(*tasks)
    return results
```

</details>

---

### Q16: Will this code work? Why or why not?

```python
import asyncio

async def hello():
    return "Hello"

def main():
    result = hello()
    print(result)

main()
```

<details>
<summary>Answer</summary>

**No, it won't work as expected!**

**What happens:**
- `hello()` returns a **coroutine object**, not "Hello"
- `print(result)` prints `<coroutine object hello at 0x...>`
- Python will issue `RuntimeWarning: coroutine 'hello' was never awaited`

**Fix:**
```python
import asyncio

async def hello():
    return "Hello"

# Option 1: asyncio.run()
result = asyncio.run(hello())
print(result)  # "Hello"

# Option 2: async main
async def main():
    result = await hello()
    print(result)

asyncio.run(main())
```

**Key lesson:** Calling an async function returns a coroutine object that must be awaited or run with `asyncio.run()`.

</details>

---

## Quick Reference: Interview Cheat Sheet

```
┌─────────────────────────────────────────────────────────────────────┐
│                COROUTINES INTERVIEW CHEAT SHEET                      │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  BASICS:                                                            │
│  • async def creates coroutine                                      │
│  • Calling async function returns coroutine OBJECT (not result)     │
│  • Must await or asyncio.run() to execute                           │
│  • await can only be used inside async functions                    │
│                                                                     │
│  KEY FUNCTIONS:                                                     │
│  • asyncio.run(coro) - Run from sync code                           │
│  • asyncio.create_task(coro) - Schedule concurrent execution        │
│  • asyncio.gather(*coros) - Run multiple, get all results           │
│  • asyncio.wait(tasks) - More control over completion               │
│  • asyncio.wait_for(coro, timeout) - With timeout                   │
│                                                                     │
│  COROUTINE vs TASK:                                                 │
│  • Coroutine: Starts when awaited                                   │
│  • Task: Starts immediately, runs concurrently                      │
│                                                                     │
│  PROTOCOLS:                                                         │
│  • __await__: Makes object awaitable                                │
│  • __aenter__/__aexit__: async with                                 │
│  • __aiter__/__anext__: async for                                   │
│                                                                     │
│  COMMON PITFALLS:                                                   │
│  • Sequential awaits in loop (use gather)                           │
│  • Forgetting to await (returns coroutine object)                   │
│  • await in regular function (SyntaxError)                          │
│  • Not handling CancelledError                                      │
│                                                                     │
│  STATES: CREATED → RUNNING → SUSPENDED → CLOSED                     │
│                                                                     │
│  PERFORMANCE:                                                       │
│  • Coroutine creation: ~300ns                                       │
│  • Task creation: ~1μs                                              │
│  • Single-threaded, no GIL issues                                   │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

*Back to: [Overview](_01_overview.md) | [Implementation](_02_implementation.md) | [Deep Dive](_03_deep_dive.md)*
