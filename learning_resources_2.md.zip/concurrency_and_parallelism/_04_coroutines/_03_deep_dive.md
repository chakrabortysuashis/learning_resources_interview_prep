# Coroutines in Python - Deep Dive

## Table of Contents
1. [Coroutine Evolution in Python](#1-coroutine-evolution-in-python)
2. [Under the Hood: How Coroutines Work](#2-under-the-hood-how-coroutines-work)
3. [Generator-Based vs Native Coroutines](#3-generator-based-vs-native-coroutines)
4. [Coroutine States and Lifecycle](#4-coroutine-states-and-lifecycle)
5. [The Awaitable Protocol](#5-the-awaitable-protocol)
6. [Advanced Patterns](#6-advanced-patterns)
7. [Performance Considerations](#7-performance-considerations)

---

## 1. Coroutine Evolution in Python

```
┌─────────────────────────────────────────────────────────────────────┐
│                  COROUTINE HISTORY IN PYTHON                         │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Python 2.2 (2001) ────────────────────────────────────────────────│
│  │  Simple generators with yield                                    │
│  │  def gen(): yield 1; yield 2                                     │
│  │                                                                  │
│  Python 2.5 (2006) ────────────────────────────────────────────────│
│  │  PEP 342: Enhanced generators                                    │
│  │  - send(), throw(), close() methods                              │
│  │  - value = yield expression                                      │
│  │  - First "coroutine-like" behavior                               │
│  │                                                                  │
│  Python 3.3 (2012) ────────────────────────────────────────────────│
│  │  PEP 380: yield from                                             │
│  │  - Delegate to sub-generator                                     │
│  │  - Foundation for generator-based coroutines                     │
│  │                                                                  │
│  Python 3.4 (2014) ────────────────────────────────────────────────│
│  │  asyncio module introduced                                       │
│  │  @asyncio.coroutine decorator                                    │
│  │  yield from for async operations                                 │
│  │                                                                  │
│  Python 3.5 (2015) ────────────────────────────────────────────────│
│  │  PEP 492: NATIVE COROUTINES                                      │
│  │  async def / await syntax                                        │
│  │  __await__, __aiter__, __anext__                                 │
│  │                                                                  │
│  Python 3.7+ (2018) ───────────────────────────────────────────────│
│     asyncio.run() for easy entry                                    │
│     Context variables                                               │
│     Performance improvements                                         │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 2. Under the Hood: How Coroutines Work

### Coroutine Object Structure

```python
import asyncio
import inspect

async def example_coro(x):
    await asyncio.sleep(1)
    return x * 2

# Create coroutine object
coro = example_coro(21)

# Inspect the coroutine
print(f"Type: {type(coro)}")
print(f"Is coroutine: {inspect.iscoroutine(coro)}")
print(f"Coroutine state: {inspect.getcoroutinestate(coro)}")

# Coroutine attributes
print(f"cr_frame: {coro.cr_frame}")        # Current execution frame
print(f"cr_code: {coro.cr_code}")          # Code object
print(f"cr_await: {coro.cr_await}")        # Object being awaited (None initially)
print(f"cr_running: {coro.cr_running}")    # Is it currently running?

# Clean up
coro.close()
```

### How await Actually Works

```
┌─────────────────────────────────────────────────────────────────────┐
│                    AWAIT MECHANISM                                   │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  async def outer():                                                 │
│      result = await inner()  # What happens here?                   │
│      return result                                                  │
│                                                                     │
│  Step by step:                                                      │
│                                                                     │
│  1. outer() is called → creates coroutine object                    │
│  2. Event loop starts running outer()                               │
│  3. outer() reaches "await inner()"                                 │
│  4. inner() coroutine object is created                             │
│  5. inner().__await__() is called                                   │
│  6. Returns iterator that yields control points                     │
│  7. outer() suspends, saves state in cr_frame                       │
│  8. Event loop runs other tasks                                     │
│  9. inner() completes, sends result back                            │
│  10. outer() resumes from suspension point                          │
│  11. result receives the value                                      │
│                                                                     │
│  ┌────────────────────────────────────────────────────────────┐    │
│  │  outer()    inner()     Event Loop                         │    │
│  │  ────────   ────────    ──────────                         │    │
│  │  start                                                     │    │
│  │  │                                                         │    │
│  │  await ────▶ start                                         │    │
│  │  (suspend)  │                                              │    │
│  │             yield ─────▶ run other tasks                   │    │
│  │             (suspend)   │                                  │    │
│  │                        ◀┘ (I/O ready)                      │    │
│  │             resume                                         │    │
│  │             return ─────▶                                  │    │
│  │  resume ◀──────────────┘                                   │    │
│  │  continue                                                  │    │
│  │  return                                                    │    │
│  └────────────────────────────────────────────────────────────┘    │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Bytecode Analysis

```python
import dis
import asyncio

async def simple_coro():
    await asyncio.sleep(1)
    return 42

# Disassemble the coroutine
print("Bytecode:")
dis.dis(simple_coro)

# Key instructions:
# GET_AWAITABLE - Gets __await__ from the object
# YIELD_FROM - Suspends execution (legacy)
# SEND - Resumes with a value
# In Python 3.11+: SEND replaces YIELD_FROM for await
```

---

## 3. Generator-Based vs Native Coroutines

### Generator-Based Coroutines (Legacy)

```python
import asyncio

# Old style (Python 3.4)
@asyncio.coroutine
def old_style_coro():
    yield from asyncio.sleep(1)
    return "done"

# Equivalent to
def generator_coro():
    """Uses yield from for suspension"""
    result = yield from asyncio.sleep(1)
    return "done"
```

### Native Coroutines (Modern)

```python
# New style (Python 3.5+)
async def native_coro():
    await asyncio.sleep(1)
    return "done"

# Key differences
import types
import inspect

old = old_style_coro()
new = native_coro()

print(type(old))  # <class 'generator'>
print(type(new))  # <class 'coroutine'>

print(inspect.isgenerator(old))    # True
print(inspect.iscoroutine(old))    # False

print(inspect.isgenerator(new))    # False
print(inspect.iscoroutine(new))    # True
```

### Comparison

```
┌─────────────────────────────────────────────────────────────────────┐
│         GENERATOR-BASED vs NATIVE COROUTINES                         │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Generator-Based (@asyncio.coroutine)  Native (async def)           │
│  ───────────────────────────────────   ─────────────────            │
│  Uses yield from                       Uses await                   │
│  Returns generator object              Returns coroutine object     │
│  Can use yield (confusing!)            Cannot use yield             │
│  inspect.isgenerator() = True          inspect.iscoroutine() = True │
│  Legacy, deprecated                    Recommended                  │
│  Works in Python 3.4+                  Requires Python 3.5+         │
│                                                                     │
│  # You CAN'T do this with native:                                   │
│  async def bad():                                                   │
│      yield 1  # SyntaxError! Use async generators instead          │
│      await something()                                              │
│                                                                     │
│  # For async generators, use async def + yield:                     │
│  async def async_gen():                                             │
│      for i in range(5):                                             │
│          await asyncio.sleep(0.1)                                   │
│          yield i                                                    │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 4. Coroutine States and Lifecycle

### Coroutine States

```python
import asyncio
import inspect

async def demo():
    await asyncio.sleep(1)
    return "done"

coro = demo()

# States: CORO_CREATED, CORO_RUNNING, CORO_SUSPENDED, CORO_CLOSED

print(inspect.getcoroutinestate(coro))  # CORO_CREATED

async def check_states():
    async def inner():
        # When running, we're in CORO_RUNNING
        return "inner done"
    
    coro = inner()
    print(f"Created: {inspect.getcoroutinestate(coro)}")  # CORO_CREATED
    
    result = await coro
    # After completion, coroutine is closed
    # Can't check state after await completes

asyncio.run(check_states())
```

### Lifecycle Diagram

```
┌─────────────────────────────────────────────────────────────────────┐
│                    COROUTINE LIFECYCLE                               │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌─────────────────┐                                                │
│  │  CORO_CREATED   │ ◀── async def func() called                   │
│  │  (Initial)      │     Coroutine object created                  │
│  └────────┬────────┘     Not yet started                           │
│           │                                                         │
│           │ await coro / send(None)                                 │
│           ▼                                                         │
│  ┌─────────────────┐                                                │
│  │  CORO_RUNNING   │ ◀── Currently executing                       │
│  │  (Executing)    │     Only one can run at a time               │
│  └────────┬────────┘                                                │
│           │                                                         │
│           ├──── await something ────▶ ┌─────────────────┐          │
│           │                           │ CORO_SUSPENDED  │          │
│           │    ◀── resumed ────────── │ (Waiting)       │          │
│           │                           └─────────────────┘          │
│           │                                                         │
│           │ return / raise / close()                                │
│           ▼                                                         │
│  ┌─────────────────┐                                                │
│  │  CORO_CLOSED    │ ◀── Finished (normally or with exception)     │
│  │  (Done)         │     Cannot be restarted                       │
│  └─────────────────┘                                                │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Cleaning Up Coroutines

```python
import asyncio
import warnings

async def long_running():
    try:
        await asyncio.sleep(100)
    except asyncio.CancelledError:
        print("Coroutine was cancelled!")
        raise

async def main():
    coro = long_running()
    task = asyncio.create_task(coro)
    
    await asyncio.sleep(1)
    
    # Cancel the task
    task.cancel()
    
    try:
        await task
    except asyncio.CancelledError:
        print("Task cancelled successfully")

asyncio.run(main())

# Warning: never-awaited coroutines
coro = long_running()
# RuntimeWarning: coroutine 'long_running' was never awaited
del coro  # Triggers warning

# Proper cleanup
coro = long_running()
coro.close()  # No warning
```

---

## 5. The Awaitable Protocol

### __await__ Method

```python
import asyncio

class Awaitable:
    """Custom awaitable object"""
    
    def __init__(self, value):
        self.value = value
    
    def __await__(self):
        """Must return an iterator"""
        # Simplest: delegate to a coroutine
        return self._async_impl().__await__()
    
    async def _async_impl(self):
        await asyncio.sleep(0.1)
        return self.value * 2

async def main():
    obj = Awaitable(21)
    result = await obj  # Calls obj.__await__()
    print(result)  # 42

asyncio.run(main())
```

### Building Awaitable from Scratch

```python
import asyncio

class FutureAwaitable:
    """Awaitable that wraps a future-like pattern"""
    
    def __init__(self):
        self._result = None
        self._done = False
        self._callbacks = []
    
    def set_result(self, value):
        self._result = value
        self._done = True
        for cb in self._callbacks:
            cb()
    
    def __await__(self):
        if not self._done:
            # Yield self to suspend
            yield self
        return self._result

async def main():
    awaitable = FutureAwaitable()
    
    async def setter():
        await asyncio.sleep(1)
        awaitable.set_result(42)
    
    # Start setter
    asyncio.create_task(setter())
    
    # This won't work with simple await...
    # Need event loop integration for real use
    # result = await awaitable

asyncio.run(main())
```

### Types of Awaitables

```python
import asyncio
import collections.abc

# Check if something is awaitable
def is_awaitable(obj):
    return isinstance(obj, collections.abc.Awaitable)

# Three types of awaitables:
# 1. Coroutines
async def coro():
    pass

# 2. Objects with __await__
class MyAwaitable:
    def __await__(self):
        yield

# 3. Futures/Tasks
future = asyncio.get_event_loop().create_future()
task = asyncio.create_task(coro())

print(is_awaitable(coro()))      # True
print(is_awaitable(MyAwaitable()))  # True
print(is_awaitable(future))      # True
print(is_awaitable(task))        # True
print(is_awaitable(42))          # False
```

---

## 6. Advanced Patterns

### Coroutine Wrapper/Decorator

```python
import asyncio
import functools
import time

def async_timer(func):
    """Decorator to time async functions"""
    @functools.wraps(func)
    async def wrapper(*args, **kwargs):
        start = time.perf_counter()
        result = await func(*args, **kwargs)
        elapsed = time.perf_counter() - start
        print(f"{func.__name__} took {elapsed:.2f}s")
        return result
    return wrapper

@async_timer
async def slow_operation():
    await asyncio.sleep(1.5)
    return "done"

asyncio.run(slow_operation())
# Output: slow_operation took 1.50s
```

### Async Context Manager Protocol

```python
import asyncio

class AsyncResource:
    """
    __aenter__ and __aexit__ for async with
    """
    
    async def __aenter__(self):
        print("Entering async context")
        await asyncio.sleep(0.1)
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        print("Exiting async context")
        await asyncio.sleep(0.1)
        return False  # Don't suppress exceptions
    
    async def work(self):
        return "working"

async def main():
    async with AsyncResource() as resource:
        result = await resource.work()
        print(result)

asyncio.run(main())
```

### Async Iterator Protocol

```python
import asyncio

class AsyncRange:
    """
    __aiter__ and __anext__ for async for
    """
    
    def __init__(self, start, end):
        self.current = start
        self.end = end
    
    def __aiter__(self):
        return self
    
    async def __anext__(self):
        if self.current >= self.end:
            raise StopAsyncIteration
        
        await asyncio.sleep(0.1)  # Simulate async work
        value = self.current
        self.current += 1
        return value

async def main():
    async for i in AsyncRange(0, 5):
        print(i)

asyncio.run(main())
# Prints 0, 1, 2, 3, 4 with 0.1s delay each
```

### Coroutine Cancellation Handling

```python
import asyncio

async def cancellable_operation():
    """Properly handle cancellation"""
    try:
        while True:
            print("Working...")
            await asyncio.sleep(1)
    except asyncio.CancelledError:
        print("Cancellation requested!")
        # Cleanup code here
        print("Cleanup complete")
        raise  # Re-raise to propagate cancellation

async def shielded_operation():
    """Protect critical section from cancellation"""
    try:
        # This part can be cancelled
        await asyncio.sleep(1)
        
        # This part is protected
        await asyncio.shield(critical_cleanup())
        
    except asyncio.CancelledError:
        print("Cancelled, but cleanup was protected")
        raise

async def critical_cleanup():
    print("Critical cleanup running...")
    await asyncio.sleep(0.5)
    print("Critical cleanup done")

async def main():
    task = asyncio.create_task(cancellable_operation())
    await asyncio.sleep(2.5)
    task.cancel()
    try:
        await task
    except asyncio.CancelledError:
        print("Task was cancelled")

asyncio.run(main())
```

---

## 7. Performance Considerations

### Coroutine Creation Overhead

```python
import asyncio
import time

async def minimal():
    return 1

# Benchmark coroutine creation
start = time.perf_counter()
for _ in range(1_000_000):
    coro = minimal()
    coro.close()  # Clean up
elapsed = time.perf_counter() - start
print(f"1M coroutine creations: {elapsed:.3f}s")
# Typically: ~0.3s (very fast!)

# vs function calls
def regular():
    return 1

start = time.perf_counter()
for _ in range(1_000_000):
    regular()
elapsed = time.perf_counter() - start
print(f"1M function calls: {elapsed:.3f}s")
# Typically: ~0.05s (faster, but coroutines still fast)
```

### Task vs Coroutine Overhead

```python
import asyncio
import time

async def minimal():
    return 1

async def benchmark():
    # Creating and awaiting coroutines directly
    start = time.perf_counter()
    for _ in range(10000):
        await minimal()
    direct_time = time.perf_counter() - start
    
    # Creating tasks
    start = time.perf_counter()
    tasks = [asyncio.create_task(minimal()) for _ in range(10000)]
    await asyncio.gather(*tasks)
    task_time = time.perf_counter() - start
    
    print(f"Direct await: {direct_time:.3f}s")
    print(f"Tasks: {task_time:.3f}s")
    # Tasks have more overhead but enable concurrency

asyncio.run(benchmark())
```

### Memory Usage

```python
import asyncio
import sys

async def memory_test():
    # Single coroutine size
    async def coro():
        await asyncio.sleep(0)
    
    c = coro()
    print(f"Single coroutine: {sys.getsizeof(c)} bytes")
    c.close()
    
    # Task size
    task = asyncio.create_task(coro())
    print(f"Single task: {sys.getsizeof(task)} bytes")
    await task

asyncio.run(memory_test())
# Coroutine: ~120 bytes
# Task: ~400 bytes
```

---

## Summary: Key Internals

```
┌─────────────────────────────────────────────────────────────────────┐
│                    COROUTINE INTERNALS SUMMARY                       │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  COROUTINE OBJECT ATTRIBUTES:                                       │
│  • cr_frame: Current execution frame                                │
│  • cr_code: Code object being executed                              │
│  • cr_await: Object currently being awaited                         │
│  • cr_running: Whether coroutine is currently running               │
│                                                                     │
│  STATES:                                                            │
│  • CORO_CREATED → CORO_RUNNING → CORO_SUSPENDED → CORO_CLOSED      │
│                                                                     │
│  AWAITABLE PROTOCOL:                                                │
│  • __await__() must return an iterator                              │
│  • Iterator yields to suspend, returns to complete                  │
│                                                                     │
│  ASYNC PROTOCOLS:                                                   │
│  • __aenter__/__aexit__: async with                                 │
│  • __aiter__/__anext__: async for                                   │
│                                                                     │
│  PERFORMANCE:                                                       │
│  • Coroutine creation: ~300ns                                       │
│  • Task creation: ~1μs                                              │
│  • Coroutine size: ~120 bytes                                       │
│  • Task size: ~400 bytes                                            │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

*Next: [Interview Questions](_04_interview_questions.md)*
