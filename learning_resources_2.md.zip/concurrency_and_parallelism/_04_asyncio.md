# Asyncio in Python

## Table of Contents
1. [Introduction to Asyncio](#introduction-to-asyncio)
2. [Async/Await Syntax](#asyncawait-syntax)
3. [Running Async Code](#running-async-code)
4. [Tasks and Concurrency](#tasks-and-concurrency)
5. [Gathering and Waiting](#gathering-and-waiting)
6. [Asyncio Primitives](#asyncio-primitives)
7. [Async Context Managers and Iterators](#async-context-managers-and-iterators)
8. [Error Handling](#error-handling)
9. [Common Patterns](#common-patterns)
10. [Interview Questions](#interview-questions)

---

## Introduction to Asyncio

**Asyncio** is Python's built-in library for writing concurrent code using the async/await syntax. It provides a foundation for asynchronous I/O operations, networking, and concurrent task execution.

```
┌─────────────────────────────────────────────────────────────────┐
│                 Asyncio Architecture                             │
│                                                                  │
│   ┌─────────────────────────────────────────────────────────┐   │
│   │                     Event Loop                           │   │
│   │  ┌─────────────────────────────────────────────────────┐│   │
│   │  │                  Task Queue                          ││   │
│   │  │  [Task1] [Task2] [Task3] [Task4] [Task5]            ││   │
│   │  └─────────────────────────────────────────────────────┘│   │
│   │                          │                               │   │
│   │                          ▼                               │   │
│   │  ┌─────────────────────────────────────────────────────┐│   │
│   │  │              Selector (epoll/kqueue)                 ││   │
│   │  │         Monitors I/O readiness                       ││   │
│   │  └─────────────────────────────────────────────────────┘│   │
│   └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│   Single Thread, Cooperative Multitasking                       │
│   Tasks voluntarily yield control at await points               │
└─────────────────────────────────────────────────────────────────┘
```

### Why Asyncio?

| Feature | Benefit |
|---------|---------|
| Single-threaded | No GIL issues, no race conditions |
| Cooperative | Explicit yield points (await) |
| High concurrency | Handle thousands of connections |
| Low overhead | No thread/process creation cost |
| Structured | Clear async/await syntax |

### When to Use Asyncio

```
┌─────────────────────────────────────────────────────────────────┐
│                 Asyncio vs Threading vs Multiprocessing          │
│                                                                  │
│   Task Type          │ Recommended Approach                     │
│   ───────────────────────────────────────────────────────────── │
│   I/O-bound,         │                                          │
│   many connections   │ asyncio ✓                                │
│   (web servers)      │                                          │
│                      │                                          │
│   I/O-bound,         │ threading or asyncio                     │
│   few connections    │                                          │
│                      │                                          │
│   CPU-bound          │ multiprocessing ✓                        │
│                      │ (asyncio doesn't help)                   │
│                      │                                          │
│   Mixed I/O + CPU    │ asyncio + ProcessPoolExecutor            │
└─────────────────────────────────────────────────────────────────┘
```

---

## Async/Await Syntax

### Basic Syntax

```python
import asyncio

# Define a coroutine function with 'async def'
async def greet(name):
    print(f"Hello, {name}!")
    await asyncio.sleep(1)  # Non-blocking sleep
    print(f"Goodbye, {name}!")
    return f"Greeted {name}"

# Run the coroutine
async def main():
    result = await greet("Alice")
    print(result)

# Entry point
asyncio.run(main())
```

### Understanding Coroutines

```python
import asyncio

async def my_coroutine():
    return 42

# Calling async function returns a coroutine object, doesn't execute it
coro = my_coroutine()
print(type(coro))  # <class 'coroutine'>

# Must be awaited to execute
async def main():
    result = await my_coroutine()
    print(result)  # 42

asyncio.run(main())
```

```
┌─────────────────────────────────────────────────────────────────┐
│                   Coroutine Lifecycle                            │
│                                                                  │
│   async def foo():              │                                │
│       return 42                 │                                │
│                                 │                                │
│   coro = foo()                  │  Coroutine object created     │
│        │                        │  (not yet running)             │
│        ▼                        │                                │
│   ┌─────────────┐               │                                │
│   │  PENDING    │ ◄─────────────┘                                │
│   └──────┬──────┘                                                │
│          │ await coro                                            │
│          ▼                                                       │
│   ┌─────────────┐                                                │
│   │  RUNNING    │ ← Executing code                               │
│   └──────┬──────┘                                                │
│          │ return/exception                                      │
│          ▼                                                       │
│   ┌─────────────┐                                                │
│   │  FINISHED   │ ← Result available                             │
│   └─────────────┘                                                │
└─────────────────────────────────────────────────────────────────┘
```

### Awaitable Objects

```python
import asyncio

# 1. Coroutines (from async def)
async def coroutine_example():
    return "coroutine result"

# 2. Tasks (wrapped coroutines)
async def task_example():
    task = asyncio.create_task(coroutine_example())
    result = await task
    return result

# 3. Futures (low-level)
async def future_example():
    loop = asyncio.get_running_loop()
    future = loop.create_future()
    future.set_result("future result")
    result = await future
    return result

# All three are awaitable
async def main():
    print(await coroutine_example())
    print(await task_example())
    print(await future_example())

asyncio.run(main())
```

---

## Running Async Code

### Method 1: asyncio.run() (Recommended)

```python
import asyncio

async def main():
    print("Running main")
    await asyncio.sleep(1)
    print("Done")

# Creates event loop, runs coroutine, closes loop
asyncio.run(main())
```

### Method 2: Manual Event Loop (Advanced)

```python
import asyncio

async def main():
    return "Hello, World!"

# Manual control
loop = asyncio.new_event_loop()
asyncio.set_event_loop(loop)
try:
    result = loop.run_until_complete(main())
    print(result)
finally:
    loop.close()
```

### Method 3: Running in Existing Loop

```python
import asyncio

async def background_task():
    while True:
        print("Background task running...")
        await asyncio.sleep(1)

async def main():
    # Get current running loop
    loop = asyncio.get_running_loop()
    
    # Schedule background task
    task = asyncio.create_task(background_task())
    
    # Do main work
    await asyncio.sleep(3)
    
    # Cancel background task
    task.cancel()
    try:
        await task
    except asyncio.CancelledError:
        print("Background task cancelled")

asyncio.run(main())
```

### Running Sync Functions in Async Context

```python
import asyncio
from concurrent.futures import ThreadPoolExecutor
import time

def blocking_io():
    """Simulate blocking I/O operation"""
    time.sleep(2)
    return "IO complete"

def cpu_bound():
    """Simulate CPU-bound operation"""
    return sum(i * i for i in range(10_000_000))

async def main():
    loop = asyncio.get_running_loop()
    
    # Run blocking I/O in thread pool
    with ThreadPoolExecutor() as pool:
        result = await loop.run_in_executor(pool, blocking_io)
        print(f"IO result: {result}")
    
    # Run CPU-bound in process pool
    from concurrent.futures import ProcessPoolExecutor
    with ProcessPoolExecutor() as pool:
        result = await loop.run_in_executor(pool, cpu_bound)
        print(f"CPU result: {result}")
    
    # Default executor (thread pool)
    result = await loop.run_in_executor(None, blocking_io)
    print(f"Default executor: {result}")

if __name__ == '__main__':
    asyncio.run(main())
```

---

## Tasks and Concurrency

### Creating Tasks

```python
import asyncio
import time

async def fetch_data(url, delay):
    """Simulate fetching data"""
    print(f"Fetching {url}...")
    await asyncio.sleep(delay)
    print(f"Got {url}")
    return f"Data from {url}"

async def main():
    start = time.perf_counter()
    
    # Sequential execution (slow)
    # result1 = await fetch_data("url1", 2)
    # result2 = await fetch_data("url2", 1)
    # result3 = await fetch_data("url3", 3)
    
    # Concurrent execution with tasks (fast)
    task1 = asyncio.create_task(fetch_data("url1", 2))
    task2 = asyncio.create_task(fetch_data("url2", 1))
    task3 = asyncio.create_task(fetch_data("url3", 3))
    
    # Wait for all tasks
    result1 = await task1
    result2 = await task2
    result3 = await task3
    
    print(f"\nTime: {time.perf_counter() - start:.2f}s")
    print(f"Results: {result1}, {result2}, {result3}")

asyncio.run(main())
```

```
┌─────────────────────────────────────────────────────────────────┐
│                Sequential vs Concurrent Execution                │
│                                                                  │
│   Sequential:                                                    │
│   ┌────────────┐ ┌────────────┐ ┌────────────────┐              │
│   │   url1     │ │   url2     │ │     url3       │              │
│   │  (2 sec)   │ │  (1 sec)   │ │    (3 sec)     │              │
│   └────────────┘ └────────────┘ └────────────────┘              │
│   ═══════════════════════════════════════════════► 6 seconds    │
│                                                                  │
│   Concurrent (with tasks):                                       │
│   ┌────────────┐                                                │
│   │   url1 (2s)│                                                │
│   └────────────┘                                                │
│   ┌────────┐                                                    │
│   │url2(1s)│                                                    │
│   └────────┘                                                    │
│   ┌────────────────┐                                            │
│   │   url3 (3s)    │                                            │
│   └────────────────┘                                            │
│   ═══════════════════► 3 seconds (max of all)                   │
└─────────────────────────────────────────────────────────────────┘
```

### Task Management

```python
import asyncio

async def long_running():
    try:
        while True:
            print("Working...")
            await asyncio.sleep(1)
    except asyncio.CancelledError:
        print("Task was cancelled!")
        raise  # Re-raise to mark task as cancelled

async def main():
    # Create task
    task = asyncio.create_task(long_running(), name="MyTask")
    
    # Task properties
    print(f"Task name: {task.get_name()}")
    print(f"Task done: {task.done()}")
    print(f"Task cancelled: {task.cancelled()}")
    
    # Let it run for a bit
    await asyncio.sleep(3)
    
    # Cancel the task
    task.cancel()
    
    try:
        await task
    except asyncio.CancelledError:
        print("Caught cancellation in main")
    
    print(f"Task done: {task.done()}")
    print(f"Task cancelled: {task.cancelled()}")

asyncio.run(main())
```

### Task Groups (Python 3.11+)

```python
import asyncio

async def fetch(url):
    await asyncio.sleep(1)
    if url == "bad_url":
        raise ValueError(f"Bad URL: {url}")
    return f"Data from {url}"

async def main():
    # TaskGroup ensures all tasks complete or all are cancelled on error
    async with asyncio.TaskGroup() as tg:
        task1 = tg.create_task(fetch("url1"))
        task2 = tg.create_task(fetch("url2"))
        task3 = tg.create_task(fetch("url3"))
    
    # All tasks completed successfully
    print(task1.result(), task2.result(), task3.result())

asyncio.run(main())
```

---

## Gathering and Waiting

### asyncio.gather()

```python
import asyncio
import time

async def fetch(name, delay):
    await asyncio.sleep(delay)
    return f"Result from {name}"

async def main():
    start = time.perf_counter()
    
    # Run multiple coroutines concurrently
    results = await asyncio.gather(
        fetch("A", 1),
        fetch("B", 2),
        fetch("C", 1.5),
    )
    
    print(f"Time: {time.perf_counter() - start:.2f}s")
    print(f"Results: {results}")

asyncio.run(main())
# Time: ~2s (not 4.5s)
# Results: ['Result from A', 'Result from B', 'Result from C']
```

### Handling Exceptions with gather()

```python
import asyncio

async def might_fail(name, should_fail):
    await asyncio.sleep(1)
    if should_fail:
        raise ValueError(f"{name} failed!")
    return f"{name} succeeded"

async def main():
    # With return_exceptions=False (default) - raises first exception
    try:
        results = await asyncio.gather(
            might_fail("A", False),
            might_fail("B", True),  # This fails
            might_fail("C", False),
        )
    except ValueError as e:
        print(f"Caught exception: {e}")
    
    # With return_exceptions=True - returns exceptions as results
    results = await asyncio.gather(
        might_fail("A", False),
        might_fail("B", True),
        might_fail("C", False),
        return_exceptions=True
    )
    
    for i, result in enumerate(results):
        if isinstance(result, Exception):
            print(f"Task {i} failed: {result}")
        else:
            print(f"Task {i} succeeded: {result}")

asyncio.run(main())
```

### asyncio.wait()

```python
import asyncio

async def fetch(name, delay):
    await asyncio.sleep(delay)
    return f"Result from {name}"

async def main():
    tasks = [
        asyncio.create_task(fetch("A", 1)),
        asyncio.create_task(fetch("B", 2)),
        asyncio.create_task(fetch("C", 3)),
    ]
    
    # Wait for first to complete
    done, pending = await asyncio.wait(
        tasks, 
        return_when=asyncio.FIRST_COMPLETED
    )
    
    print(f"Done: {len(done)}, Pending: {len(pending)}")
    for task in done:
        print(f"Completed: {task.result()}")
    
    # Cancel pending tasks
    for task in pending:
        task.cancel()

asyncio.run(main())
```

### Wait Options

```python
import asyncio

async def main():
    tasks = [asyncio.create_task(fetch(i)) for i in range(5)]
    
    # FIRST_COMPLETED - Return when any task completes
    done, pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
    
    # FIRST_EXCEPTION - Return when first exception or all complete
    done, pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_EXCEPTION)
    
    # ALL_COMPLETED (default) - Return when all complete
    done, pending = await asyncio.wait(tasks, return_when=asyncio.ALL_COMPLETED)
    
    # With timeout
    done, pending = await asyncio.wait(tasks, timeout=2.0)
```

### asyncio.as_completed()

```python
import asyncio

async def fetch(name, delay):
    await asyncio.sleep(delay)
    return name, delay

async def main():
    tasks = [
        asyncio.create_task(fetch("A", 3)),
        asyncio.create_task(fetch("B", 1)),
        asyncio.create_task(fetch("C", 2)),
    ]
    
    # Process results as they complete (not in order)
    for coro in asyncio.as_completed(tasks):
        result = await coro
        print(f"Completed: {result}")

asyncio.run(main())
# Output order: B (1s), C (2s), A (3s)
```

```
┌─────────────────────────────────────────────────────────────────┐
│                 gather() vs wait() vs as_completed()             │
│                                                                  │
│   gather():                                                      │
│   • Returns list of results (ordered)                           │
│   • Simple API for common case                                  │
│   • return_exceptions option                                    │
│                                                                  │
│   wait():                                                        │
│   • Returns (done, pending) sets                                │
│   • More control (FIRST_COMPLETED, timeout)                     │
│   • Works with Task objects directly                            │
│                                                                  │
│   as_completed():                                                │
│   • Iterator yielding in completion order                       │
│   • Process results as they arrive                              │
│   • Good for streaming results                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## Asyncio Primitives

### asyncio.Lock

```python
import asyncio

class SharedResource:
    def __init__(self):
        self.value = 0
        self.lock = asyncio.Lock()
    
    async def increment(self):
        async with self.lock:  # Only one coroutine at a time
            temp = self.value
            await asyncio.sleep(0.1)  # Simulate work
            self.value = temp + 1

async def worker(resource, name):
    for _ in range(5):
        await resource.increment()
        print(f"{name}: value = {resource.value}")

async def main():
    resource = SharedResource()
    
    await asyncio.gather(
        worker(resource, "Worker-1"),
        worker(resource, "Worker-2"),
    )
    
    print(f"Final value: {resource.value}")  # Always 10

asyncio.run(main())
```

### asyncio.Event

```python
import asyncio

async def waiter(event, name):
    print(f"{name}: Waiting for event...")
    await event.wait()
    print(f"{name}: Event received!")

async def setter(event):
    print("Setter: Preparing data...")
    await asyncio.sleep(2)
    print("Setter: Setting event!")
    event.set()

async def main():
    event = asyncio.Event()
    
    await asyncio.gather(
        waiter(event, "Waiter-1"),
        waiter(event, "Waiter-2"),
        setter(event),
    )

asyncio.run(main())
```

### asyncio.Semaphore

```python
import asyncio

async def limited_fetch(semaphore, url):
    async with semaphore:  # Limit concurrent operations
        print(f"Fetching {url}")
        await asyncio.sleep(1)  # Simulate fetch
        print(f"Done {url}")
        return url

async def main():
    # Allow only 3 concurrent fetches
    semaphore = asyncio.Semaphore(3)
    
    urls = [f"url{i}" for i in range(10)]
    
    tasks = [limited_fetch(semaphore, url) for url in urls]
    results = await asyncio.gather(*tasks)
    print(f"Fetched {len(results)} URLs")

asyncio.run(main())
```

### asyncio.Condition

```python
import asyncio
from collections import deque

class AsyncQueue:
    def __init__(self, maxsize=0):
        self.maxsize = maxsize
        self.queue = deque()
        self.condition = asyncio.Condition()
    
    async def put(self, item):
        async with self.condition:
            while self.maxsize > 0 and len(self.queue) >= self.maxsize:
                await self.condition.wait()
            self.queue.append(item)
            self.condition.notify()
    
    async def get(self):
        async with self.condition:
            while not self.queue:
                await self.condition.wait()
            item = self.queue.popleft()
            self.condition.notify()
            return item

async def producer(queue):
    for i in range(5):
        await queue.put(i)
        print(f"Produced: {i}")

async def consumer(queue):
    for _ in range(5):
        item = await queue.get()
        print(f"Consumed: {item}")
        await asyncio.sleep(0.5)

async def main():
    queue = AsyncQueue(maxsize=2)
    await asyncio.gather(producer(queue), consumer(queue))

asyncio.run(main())
```

### asyncio.Queue

```python
import asyncio

async def producer(queue, count):
    for i in range(count):
        await queue.put(i)
        print(f"Produced: {i}")
        await asyncio.sleep(0.1)
    await queue.put(None)  # Sentinel

async def consumer(queue, name):
    while True:
        item = await queue.get()
        if item is None:
            queue.task_done()
            break
        print(f"{name} consumed: {item}")
        await asyncio.sleep(0.3)
        queue.task_done()

async def main():
    queue = asyncio.Queue(maxsize=5)
    
    # Start producer and consumers
    await asyncio.gather(
        producer(queue, 10),
        consumer(queue, "Consumer-1"),
    )
    
    # Wait for all items to be processed
    await queue.join()
    print("All items processed")

asyncio.run(main())
```

---

## Async Context Managers and Iterators

### Async Context Manager

```python
import asyncio

class AsyncResource:
    async def __aenter__(self):
        print("Acquiring resource...")
        await asyncio.sleep(1)  # Simulate async acquisition
        print("Resource acquired")
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        print("Releasing resource...")
        await asyncio.sleep(0.5)  # Simulate async cleanup
        print("Resource released")
        return False  # Don't suppress exceptions
    
    async def do_work(self):
        print("Working...")
        await asyncio.sleep(1)

async def main():
    async with AsyncResource() as resource:
        await resource.do_work()

asyncio.run(main())
```

### Using contextlib

```python
import asyncio
from contextlib import asynccontextmanager

@asynccontextmanager
async def async_database_connection(host):
    print(f"Connecting to {host}...")
    await asyncio.sleep(1)  # Simulate connection
    connection = {"host": host, "connected": True}
    
    try:
        yield connection
    finally:
        print(f"Disconnecting from {host}...")
        await asyncio.sleep(0.5)  # Simulate disconnection
        connection["connected"] = False
        print("Disconnected")

async def main():
    async with async_database_connection("localhost") as conn:
        print(f"Using connection: {conn}")
        await asyncio.sleep(1)

asyncio.run(main())
```

### Async Iterator

```python
import asyncio

class AsyncRange:
    def __init__(self, start, stop):
        self.start = start
        self.stop = stop
    
    def __aiter__(self):
        self.current = self.start
        return self
    
    async def __anext__(self):
        if self.current >= self.stop:
            raise StopAsyncIteration
        
        await asyncio.sleep(0.1)  # Simulate async operation
        value = self.current
        self.current += 1
        return value

async def main():
    async for num in AsyncRange(0, 5):
        print(f"Got: {num}")

asyncio.run(main())
```

### Async Generator

```python
import asyncio

async def async_counter(start, stop):
    """Async generator function"""
    for i in range(start, stop):
        await asyncio.sleep(0.1)
        yield i

async def async_fetch_pages(urls):
    """Yield results as they're fetched"""
    for url in urls:
        await asyncio.sleep(0.5)  # Simulate fetch
        yield f"Content from {url}"

async def main():
    # Using async for with generator
    async for num in async_counter(0, 5):
        print(f"Counter: {num}")
    
    # Collecting results
    urls = ["url1", "url2", "url3"]
    results = [content async for content in async_fetch_pages(urls)]
    print(results)

asyncio.run(main())
```

---

## Error Handling

### Basic Exception Handling

```python
import asyncio

async def might_fail(should_fail):
    await asyncio.sleep(1)
    if should_fail:
        raise ValueError("Something went wrong!")
    return "Success"

async def main():
    # Handle exceptions in individual coroutines
    try:
        result = await might_fail(True)
    except ValueError as e:
        print(f"Caught: {e}")
    
    # Handle exceptions with tasks
    task = asyncio.create_task(might_fail(True))
    try:
        result = await task
    except ValueError as e:
        print(f"Task raised: {e}")

asyncio.run(main())
```

### Exception Groups (Python 3.11+)

```python
import asyncio

async def failing_task(name, error_type):
    await asyncio.sleep(0.1)
    raise error_type(f"{name} failed")

async def main():
    try:
        async with asyncio.TaskGroup() as tg:
            tg.create_task(failing_task("A", ValueError))
            tg.create_task(failing_task("B", TypeError))
            tg.create_task(failing_task("C", RuntimeError))
    except* ValueError as eg:
        print(f"ValueError exceptions: {eg.exceptions}")
    except* TypeError as eg:
        print(f"TypeError exceptions: {eg.exceptions}")
    except* RuntimeError as eg:
        print(f"RuntimeError exceptions: {eg.exceptions}")

asyncio.run(main())
```

### Timeout Handling

```python
import asyncio

async def slow_operation():
    await asyncio.sleep(10)
    return "Done"

async def main():
    # Method 1: asyncio.timeout (Python 3.11+)
    try:
        async with asyncio.timeout(2):
            result = await slow_operation()
    except TimeoutError:
        print("Operation timed out!")
    
    # Method 2: asyncio.wait_for
    try:
        result = await asyncio.wait_for(slow_operation(), timeout=2)
    except asyncio.TimeoutError:
        print("Operation timed out!")
    
    # Method 3: asyncio.timeout_at (Python 3.11+)
    loop = asyncio.get_running_loop()
    deadline = loop.time() + 2
    try:
        async with asyncio.timeout_at(deadline):
            result = await slow_operation()
    except TimeoutError:
        print("Operation timed out!")

asyncio.run(main())
```

### Cancellation Handling

```python
import asyncio

async def cancellable_operation():
    try:
        while True:
            print("Working...")
            await asyncio.sleep(1)
    except asyncio.CancelledError:
        print("Cleaning up before cancellation...")
        await asyncio.sleep(0.5)  # Cleanup work
        print("Cleanup complete")
        raise  # Re-raise to signal cancellation

async def main():
    task = asyncio.create_task(cancellable_operation())
    
    await asyncio.sleep(3)
    
    print("Cancelling task...")
    task.cancel()
    
    try:
        await task
    except asyncio.CancelledError:
        print("Task was cancelled")

asyncio.run(main())
```

### Shielding from Cancellation

```python
import asyncio

async def critical_operation():
    """This operation must complete even if outer task is cancelled"""
    print("Critical operation starting...")
    await asyncio.sleep(2)
    print("Critical operation complete!")
    return "Critical result"

async def main():
    async def outer_task():
        # Shield protects inner coroutine from cancellation
        result = await asyncio.shield(critical_operation())
        return result
    
    task = asyncio.create_task(outer_task())
    
    await asyncio.sleep(0.5)
    task.cancel()
    
    try:
        result = await task
    except asyncio.CancelledError:
        print("Outer task cancelled, but critical operation continues")
        # Critical operation is still running!
        await asyncio.sleep(2)

asyncio.run(main())
```

---

## Common Patterns

### Pattern 1: Concurrent HTTP Requests

```python
import asyncio
import aiohttp  # pip install aiohttp

async def fetch_url(session, url):
    async with session.get(url) as response:
        return await response.text()

async def fetch_all(urls):
    async with aiohttp.ClientSession() as session:
        tasks = [fetch_url(session, url) for url in urls]
        return await asyncio.gather(*tasks)

async def main():
    urls = [
        "https://httpbin.org/get",
        "https://httpbin.org/ip",
        "https://httpbin.org/headers",
    ]
    
    results = await fetch_all(urls)
    for url, result in zip(urls, results):
        print(f"{url}: {len(result)} bytes")

asyncio.run(main())
```

### Pattern 2: Rate Limiting

```python
import asyncio
import time

class RateLimiter:
    def __init__(self, rate, per):
        self.rate = rate  # Number of operations
        self.per = per    # Per seconds
        self.semaphore = asyncio.Semaphore(rate)
    
    async def acquire(self):
        await self.semaphore.acquire()
        asyncio.create_task(self._release_after_delay())
    
    async def _release_after_delay(self):
        await asyncio.sleep(self.per)
        self.semaphore.release()

async def limited_fetch(limiter, url):
    await limiter.acquire()
    print(f"Fetching {url} at {time.strftime('%H:%M:%S')}")
    await asyncio.sleep(0.1)  # Simulate fetch
    return url

async def main():
    # 5 requests per second
    limiter = RateLimiter(rate=5, per=1)
    
    urls = [f"url{i}" for i in range(15)]
    tasks = [limited_fetch(limiter, url) for url in urls]
    await asyncio.gather(*tasks)

asyncio.run(main())
```

### Pattern 3: Worker Pool

```python
import asyncio
from dataclasses import dataclass

@dataclass
class Job:
    id: int
    data: str

async def worker(name, queue, results):
    while True:
        job = await queue.get()
        if job is None:
            break
        
        print(f"{name} processing job {job.id}")
        await asyncio.sleep(0.5)  # Simulate work
        results.append(f"Job {job.id} completed by {name}")
        queue.task_done()

async def main():
    queue = asyncio.Queue()
    results = []
    num_workers = 3
    
    # Create workers
    workers = [
        asyncio.create_task(worker(f"Worker-{i}", queue, results))
        for i in range(num_workers)
    ]
    
    # Add jobs
    for i in range(10):
        await queue.put(Job(i, f"data-{i}"))
    
    # Wait for all jobs to complete
    await queue.join()
    
    # Stop workers
    for _ in range(num_workers):
        await queue.put(None)
    
    await asyncio.gather(*workers)
    print(f"Results: {results}")

asyncio.run(main())
```

### Pattern 4: Retry with Backoff

```python
import asyncio
import random

async def unreliable_operation():
    if random.random() < 0.7:  # 70% chance of failure
        raise ConnectionError("Failed to connect")
    return "Success!"

async def retry_with_backoff(coro_func, max_retries=5, base_delay=1):
    for attempt in range(max_retries):
        try:
            return await coro_func()
        except Exception as e:
            if attempt == max_retries - 1:
                raise
            
            delay = base_delay * (2 ** attempt)  # Exponential backoff
            delay += random.uniform(0, 1)  # Jitter
            print(f"Attempt {attempt + 1} failed: {e}. Retrying in {delay:.2f}s")
            await asyncio.sleep(delay)

async def main():
    try:
        result = await retry_with_backoff(unreliable_operation)
        print(f"Result: {result}")
    except ConnectionError:
        print("All retries failed")

asyncio.run(main())
```

### Pattern 5: Pub/Sub

```python
import asyncio
from collections import defaultdict

class PubSub:
    def __init__(self):
        self.subscribers = defaultdict(list)
    
    def subscribe(self, topic, callback):
        self.subscribers[topic].append(callback)
    
    async def publish(self, topic, message):
        tasks = []
        for callback in self.subscribers[topic]:
            tasks.append(asyncio.create_task(callback(message)))
        if tasks:
            await asyncio.gather(*tasks)

async def handler1(message):
    print(f"Handler 1 received: {message}")
    await asyncio.sleep(0.1)

async def handler2(message):
    print(f"Handler 2 received: {message}")
    await asyncio.sleep(0.1)

async def main():
    pubsub = PubSub()
    
    pubsub.subscribe("news", handler1)
    pubsub.subscribe("news", handler2)
    pubsub.subscribe("sports", handler1)
    
    await pubsub.publish("news", "Breaking: Python is awesome!")
    await pubsub.publish("sports", "Score: 3-2")

asyncio.run(main())
```

---

## Interview Questions

### Q1: What is the difference between concurrency and parallelism?
**Answer**:
- **Concurrency**: Multiple tasks making progress (may be interleaved on single CPU)
- **Parallelism**: Multiple tasks running simultaneously (requires multiple CPUs)
- asyncio provides concurrency, not parallelism (single-threaded)

### Q2: When does asyncio provide performance benefits?
**Answer**: When waiting for I/O operations (network, disk, etc.). During waits, other tasks can run. For CPU-bound work, asyncio provides no benefit because there's no waiting.

### Q3: What is the difference between `asyncio.create_task()` and `await`?
**Answer**:
- `await`: Immediately suspends and waits for coroutine to complete
- `create_task()`: Schedules coroutine to run concurrently, returns immediately with Task object
- Use `create_task()` when you want concurrent execution

### Q4: How do you run blocking code in asyncio?
**Answer**: Use `loop.run_in_executor()`:
```python
result = await loop.run_in_executor(None, blocking_function)  # Thread pool
result = await loop.run_in_executor(process_pool, cpu_bound)  # Process pool
```

### Q5: What happens if you forget to await a coroutine?
**Answer**: The coroutine is not executed. Python will issue a `RuntimeWarning: coroutine 'xxx' was never awaited`. The coroutine object is created but never runs.

### Q6: How do you handle timeouts in asyncio?
**Answer**:
```python
# Python 3.11+
async with asyncio.timeout(seconds):
    await operation()

# Earlier versions
await asyncio.wait_for(operation(), timeout=seconds)
```

---

## Summary

```
┌─────────────────────────────────────────────────────────────────┐
│                      Asyncio Summary                             │
├─────────────────────────────────────────────────────────────────┤
│  Core Concepts:                                                  │
│  • async def - Define coroutine function                        │
│  • await - Suspend and wait for result                          │
│  • asyncio.run() - Run main coroutine                           │
│  • asyncio.create_task() - Schedule concurrent execution        │
│                                                                  │
│  Coordination:                                                   │
│  • gather() - Run coroutines concurrently, return all results  │
│  • wait() - Fine-grained control over completion               │
│  • as_completed() - Process results in completion order        │
│                                                                  │
│  Primitives:                                                     │
│  • Lock - Mutual exclusion                                      │
│  • Event - Signaling                                            │
│  • Semaphore - Limited concurrent access                        │
│  • Queue - Thread-safe producer/consumer                        │
│                                                                  │
│  Best Practices:                                                 │
│  • Use async context managers (async with)                      │
│  • Handle CancelledError appropriately                          │
│  • Use timeouts for external operations                         │
│  • Run blocking code in executor                                │
└─────────────────────────────────────────────────────────────────┘
```
