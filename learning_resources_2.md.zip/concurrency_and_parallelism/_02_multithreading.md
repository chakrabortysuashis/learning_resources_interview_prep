# Multithreading in Python

## Table of Contents
1. [Introduction to Threads](#introduction-to-threads)
2. [The threading Module](#the-threading-module)
3. [Creating and Managing Threads](#creating-and-managing-threads)
4. [Thread Synchronization](#thread-synchronization)
5. [Thread Communication](#thread-communication)
6. [Thread Pools](#thread-pools)
7. [Thread Safety Patterns](#thread-safety-patterns)
8. [Common Pitfalls](#common-pitfalls)
9. [Best Practices](#best-practices)
10. [Interview Questions](#interview-questions)

---

## Introduction to Threads

### What is a Thread?

A **thread** is the smallest unit of execution within a process. Multiple threads share the same memory space but have their own execution stack.

```
┌─────────────────────────────────────────────────────────────────┐
│                         Process                                  │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │                    Shared Memory                           │  │
│  │  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐      │  │
│  │  │  Heap   │  │  Data   │  │  Code   │  │ Globals │      │  │
│  │  └─────────┘  └─────────┘  └─────────┘  └─────────┘      │  │
│  └───────────────────────────────────────────────────────────┘  │
│                                                                  │
│  ┌───────────┐    ┌───────────┐    ┌───────────┐               │
│  │  Thread 1 │    │  Thread 2 │    │  Thread 3 │               │
│  │  ┌─────┐  │    │  ┌─────┐  │    │  ┌─────┐  │               │
│  │  │Stack│  │    │  │Stack│  │    │  │Stack│  │               │
│  │  └─────┘  │    │  └─────┘  │    │  └─────┘  │               │
│  │  ┌─────┐  │    │  ┌─────┐  │    │  ┌─────┐  │               │
│  │  │ PC  │  │    │  │ PC  │  │    │  │ PC  │  │               │
│  │  └─────┘  │    │  └─────┘  │    │  └─────┘  │               │
│  └───────────┘    └───────────┘    └───────────┘               │
└─────────────────────────────────────────────────────────────────┘

PC = Program Counter (instruction pointer)
```

### Threads vs Processes

| Aspect | Thread | Process |
|--------|--------|---------|
| Memory | Shared | Isolated |
| Creation | Fast (lightweight) | Slow (heavyweight) |
| Communication | Easy (shared memory) | Complex (IPC needed) |
| Context Switch | Fast | Slow |
| Crash Impact | Can crash entire process | Isolated |
| GIL Impact | Affected by GIL | Bypasses GIL |

---

## The threading Module

### Basic Components

```python
import threading

# Key classes and functions
threading.Thread        # Thread class
threading.Lock          # Mutual exclusion lock
threading.RLock         # Reentrant lock
threading.Condition     # Condition variable
threading.Event         # Event flag
threading.Semaphore     # Semaphore
threading.Barrier       # Synchronization barrier
threading.Timer         # Timer thread
threading.local()       # Thread-local data

# Utility functions
threading.current_thread()    # Get current thread
threading.main_thread()       # Get main thread
threading.active_count()      # Number of active threads
threading.enumerate()         # List all active threads
```

### Thread States

```
┌─────────────────────────────────────────────────────────────────┐
│                      Thread Lifecycle                            │
│                                                                  │
│     ┌──────────┐                                                │
│     │  Created │ ← Thread() called                              │
│     └────┬─────┘                                                │
│          │ .start()                                              │
│          ▼                                                       │
│     ┌──────────┐                                                │
│     │  Ready   │ ← Waiting for CPU                              │
│     └────┬─────┘                                                │
│          │ Scheduled by OS                                       │
│          ▼                                                       │
│     ┌──────────┐      .join() or                                │
│     │ Running  │ ────► blocking I/O ────┐                       │
│     └────┬─────┘                         │                       │
│          │                               ▼                       │
│          │                        ┌──────────┐                  │
│          │                        │ Blocked  │                  │
│          │                        └────┬─────┘                  │
│          │                             │ I/O complete           │
│          │ ◄───────────────────────────┘                        │
│          │                                                       │
│          │ Task complete                                         │
│          ▼                                                       │
│     ┌──────────┐                                                │
│     │   Dead   │ ← Thread finished                              │
│     └──────────┘                                                │
└─────────────────────────────────────────────────────────────────┘
```

---

## Creating and Managing Threads

### Method 1: Using Thread with Target Function

```python
import threading
import time

def worker(name, duration):
    """Worker function that runs in a thread"""
    print(f"[{name}] Starting...")
    time.sleep(duration)
    print(f"[{name}] Finished after {duration}s")
    return f"Result from {name}"

# Create threads
t1 = threading.Thread(target=worker, args=("Thread-1", 2))
t2 = threading.Thread(target=worker, args=("Thread-2", 1))

# Start threads
t1.start()
t2.start()

# Wait for threads to complete
t1.join()
t2.join()

print("All threads completed!")
```

### Method 2: Subclassing Thread

```python
import threading
import time

class WorkerThread(threading.Thread):
    def __init__(self, name, duration):
        super().__init__()
        self.name = name
        self.duration = duration
        self.result = None
    
    def run(self):
        """Override run() method"""
        print(f"[{self.name}] Starting...")
        time.sleep(self.duration)
        self.result = f"Completed by {self.name}"
        print(f"[{self.name}] Finished")

# Create and start threads
threads = [
    WorkerThread("Worker-1", 2),
    WorkerThread("Worker-2", 1),
    WorkerThread("Worker-3", 3),
]

for t in threads:
    t.start()

for t in threads:
    t.join()
    print(f"Result: {t.result}")
```

### Thread Naming and Identification

```python
import threading

def task():
    current = threading.current_thread()
    print(f"Thread Name: {current.name}")
    print(f"Thread ID: {current.ident}")
    print(f"Native ID: {current.native_id}")
    print(f"Is Alive: {current.is_alive()}")
    print(f"Is Daemon: {current.daemon}")

# Named thread
t = threading.Thread(target=task, name="MyWorker")
t.start()
t.join()

# Check main thread
main = threading.main_thread()
print(f"Main thread: {main.name}")
```

### Daemon Threads

Daemon threads are background threads that automatically terminate when all non-daemon threads finish.

```python
import threading
import time

def background_task():
    """This runs forever but won't prevent program exit"""
    while True:
        print("Background task running...")
        time.sleep(1)

def foreground_task():
    """Main work"""
    for i in range(3):
        print(f"Foreground work: {i}")
        time.sleep(0.5)

# Daemon thread - will be killed when main exits
daemon = threading.Thread(target=background_task, daemon=True)
daemon.start()

# Regular thread
worker = threading.Thread(target=foreground_task)
worker.start()
worker.join()

print("Main thread exiting - daemon will be killed")
# Program exits here, daemon thread is terminated
```

```
┌─────────────────────────────────────────────────────────────────┐
│                    Daemon vs Non-Daemon                          │
│                                                                  │
│   Non-Daemon (default):                                          │
│   ┌─────────────────────────────────────────────────────┐       │
│   │ Main Thread ████████████████░░░░░░░░░░░░░░░░░░░░░░│       │
│   │ Worker      ░░░░████████████████████████████████████│       │
│   └─────────────────────────────────────────────────────┘       │
│   Program waits for worker to finish ──────────────────►        │
│                                                                  │
│   Daemon:                                                        │
│   ┌─────────────────────────────────────────────────────┐       │
│   │ Main Thread ████████████████│                       │       │
│   │ Daemon      ████████████████✗ (killed)              │       │
│   └─────────────────────────────────────────────────────┘       │
│   Program exits when main finishes, daemon killed ────►         │
└─────────────────────────────────────────────────────────────────┘
```

---

## Thread Synchronization

### 1. Lock (Mutex)

```python
import threading

class Counter:
    def __init__(self):
        self.value = 0
        self.lock = threading.Lock()
    
    def increment(self):
        # Without lock - race condition!
        # self.value += 1
        
        # With lock - thread safe
        with self.lock:  # Acquires lock, releases on exit
            self.value += 1
    
    def increment_manual(self):
        """Manual lock management"""
        self.lock.acquire()
        try:
            self.value += 1
        finally:
            self.lock.release()

counter = Counter()
threads = []

for _ in range(1000):
    t = threading.Thread(target=counter.increment)
    threads.append(t)
    t.start()

for t in threads:
    t.join()

print(f"Final count: {counter.value}")  # Always 1000 with lock
```

```
┌─────────────────────────────────────────────────────────────────┐
│                    Lock Mechanism                                │
│                                                                  │
│   Without Lock (Race Condition):                                 │
│   ┌────────────┐                    ┌────────────┐              │
│   │  Thread 1  │                    │  Thread 2  │              │
│   └────────────┘                    └────────────┘              │
│         │ Read: value = 5                │                       │
│         │◄───────────────────────────────│ Read: value = 5       │
│         │ Add 1: temp = 6                │ Add 1: temp = 6       │
│         │ Write: value = 6               │                       │
│         │───────────────────────────────►│ Write: value = 6      │
│         │                                │                       │
│   Expected: 7    Actual: 6  ← WRONG!                            │
│                                                                  │
│   With Lock:                                                     │
│   ┌────────────┐                    ┌────────────┐              │
│   │  Thread 1  │                    │  Thread 2  │              │
│   └────────────┘                    └────────────┘              │
│         │ acquire()                      │                       │
│         │ ████████ LOCKED ████████       │ acquire() ← BLOCKED   │
│         │ Read: value = 5                │     │                 │
│         │ Add 1: temp = 6                │     │ (waiting)       │
│         │ Write: value = 6               │     │                 │
│         │ release()                      │     │                 │
│         │                                │     ▼                 │
│         │                                │ ████████ LOCKED ██████│
│         │                                │ Read: value = 6       │
│         │                                │ Add 1: temp = 7       │
│         │                                │ Write: value = 7      │
│   Result: 7  ← CORRECT!                                         │
└─────────────────────────────────────────────────────────────────┘
```

### 2. RLock (Reentrant Lock)

RLock can be acquired multiple times by the same thread.

```python
import threading

class RecursiveWorker:
    def __init__(self):
        self.lock = threading.RLock()  # Not Lock!
        self.data = []
    
    def outer_method(self):
        with self.lock:
            print("Outer acquired lock")
            self.inner_method()  # Same thread can re-acquire
    
    def inner_method(self):
        with self.lock:  # Would deadlock with regular Lock
            print("Inner acquired lock")
            self.data.append(1)

worker = RecursiveWorker()
worker.outer_method()
```

```
┌─────────────────────────────────────────────────────────────────┐
│                 Lock vs RLock                                    │
│                                                                  │
│   Regular Lock:                                                  │
│   Thread A: acquire() ✓                                          │
│   Thread A: acquire() ✗ DEADLOCK! (can't acquire twice)          │
│                                                                  │
│   RLock:                                                         │
│   Thread A: acquire() ✓  (count = 1)                             │
│   Thread A: acquire() ✓  (count = 2)                             │
│   Thread A: release()    (count = 1)                             │
│   Thread A: release()    (count = 0, unlocked)                   │
└─────────────────────────────────────────────────────────────────┘
```

### 3. Condition Variable

Used for thread coordination based on conditions.

```python
import threading
import time
import random

class BoundedBuffer:
    def __init__(self, capacity):
        self.capacity = capacity
        self.buffer = []
        self.condition = threading.Condition()
    
    def produce(self, item):
        with self.condition:
            while len(self.buffer) >= self.capacity:
                print(f"Buffer full, producer waiting...")
                self.condition.wait()  # Release lock and wait
            
            self.buffer.append(item)
            print(f"Produced: {item}, Buffer: {self.buffer}")
            self.condition.notify()  # Wake up one waiting thread
    
    def consume(self):
        with self.condition:
            while len(self.buffer) == 0:
                print(f"Buffer empty, consumer waiting...")
                self.condition.wait()
            
            item = self.buffer.pop(0)
            print(f"Consumed: {item}, Buffer: {self.buffer}")
            self.condition.notify()
            return item

buffer = BoundedBuffer(3)

def producer():
    for i in range(5):
        time.sleep(random.uniform(0.1, 0.3))
        buffer.produce(i)

def consumer():
    for _ in range(5):
        time.sleep(random.uniform(0.2, 0.4))
        buffer.consume()

t1 = threading.Thread(target=producer)
t2 = threading.Thread(target=consumer)
t1.start()
t2.start()
t1.join()
t2.join()
```

```
┌─────────────────────────────────────────────────────────────────┐
│              Producer-Consumer with Condition                    │
│                                                                  │
│   ┌──────────────────────────────────────────────────────────┐  │
│   │                    Bounded Buffer                         │  │
│   │   ┌─────┬─────┬─────┐                                    │  │
│   │   │  1  │  2  │  3  │  capacity = 3                      │  │
│   │   └─────┴─────┴─────┘                                    │  │
│   └──────────────────────────────────────────────────────────┘  │
│          ▲                               │                       │
│          │ produce()                     │ consume()             │
│          │                               ▼                       │
│   ┌──────────────┐                ┌──────────────┐              │
│   │   Producer   │                │   Consumer   │              │
│   │              │                │              │              │
│   │  if full:    │                │  if empty:   │              │
│   │   wait()     │◄──notify()─────│   wait()     │              │
│   │              │────notify()───►│              │              │
│   └──────────────┘                └──────────────┘              │
└─────────────────────────────────────────────────────────────────┘
```

### 4. Event

Used for simple signaling between threads.

```python
import threading
import time

# Create an event
data_ready = threading.Event()

def producer():
    print("Producer: Preparing data...")
    time.sleep(2)
    print("Producer: Data ready!")
    data_ready.set()  # Signal that data is ready

def consumer():
    print("Consumer: Waiting for data...")
    data_ready.wait()  # Block until event is set
    print("Consumer: Got data, processing...")

t1 = threading.Thread(target=producer)
t2 = threading.Thread(target=consumer)

t2.start()  # Consumer starts waiting
t1.start()  # Producer prepares data

t1.join()
t2.join()
```

```
┌─────────────────────────────────────────────────────────────────┐
│                    Event Mechanism                               │
│                                                                  │
│   Timeline ─────────────────────────────────────────────────►   │
│                                                                  │
│   Event:      [clear]                 [set]                     │
│               ░░░░░░░░░░░░░░░░░░░░░░░░█████████████████         │
│                                        │                         │
│   Producer:   ████████████████████████│ set()                   │
│               "Preparing data..."      │                         │
│                                        │                         │
│   Consumer:   wait()                   │                         │
│               ░░░░░░░░░░░░░░░░░░░░░░░░░████████████████         │
│               (blocked)                "Processing..."           │
└─────────────────────────────────────────────────────────────────┘
```

### 5. Semaphore

Controls access to a resource with limited capacity.

```python
import threading
import time
import random

# Semaphore with 3 permits (e.g., 3 database connections)
connection_pool = threading.Semaphore(3)

def worker(name):
    print(f"{name}: Waiting for connection...")
    
    with connection_pool:  # Acquire permit
        print(f"{name}: Got connection!")
        time.sleep(random.uniform(1, 2))  # Simulate work
        print(f"{name}: Releasing connection")
    
    # Permit automatically released

threads = [
    threading.Thread(target=worker, args=(f"Worker-{i}",))
    for i in range(6)
]

for t in threads:
    t.start()

for t in threads:
    t.join()
```

```
┌─────────────────────────────────────────────────────────────────┐
│                   Semaphore (permits = 3)                        │
│                                                                  │
│   Permits Available: [●] [●] [●]                                │
│                                                                  │
│   Worker-1: acquire() ✓  [○] [●] [●]                            │
│   Worker-2: acquire() ✓  [○] [○] [●]                            │
│   Worker-3: acquire() ✓  [○] [○] [○]                            │
│   Worker-4: acquire() ✗  BLOCKED (waiting)                      │
│   Worker-5: acquire() ✗  BLOCKED (waiting)                      │
│                                                                  │
│   Worker-1: release()    [●] [○] [○]                            │
│   Worker-4: acquire() ✓  [○] [○] [○]  (was waiting, now runs)   │
└─────────────────────────────────────────────────────────────────┘
```

### 6. Barrier

Synchronization point where threads wait for each other.

```python
import threading
import time
import random

# Barrier for 3 threads
barrier = threading.Barrier(3)

def worker(name):
    print(f"{name}: Doing phase 1 work...")
    time.sleep(random.uniform(0.5, 1.5))
    
    print(f"{name}: Waiting at barrier...")
    barrier.wait()  # Wait for all threads
    
    print(f"{name}: Passed barrier, doing phase 2...")

threads = [
    threading.Thread(target=worker, args=(f"Worker-{i}",))
    for i in range(3)
]

for t in threads:
    t.start()

for t in threads:
    t.join()
```

```
┌─────────────────────────────────────────────────────────────────┐
│                    Barrier Synchronization                       │
│                                                                  │
│   Timeline ─────────────────────────────────────────────────►   │
│                                                                  │
│                              BARRIER                             │
│                                 │                                │
│   Worker-1: ████████────────────┼─────────█████████████         │
│   Worker-2: ██████████████──────┼─────────█████████████         │
│   Worker-3: ██████████████████──┼─────────█████████████         │
│                                 │                                │
│             Phase 1          wait()        Phase 2               │
│                                 │                                │
│   All threads must reach barrier before any can proceed         │
└─────────────────────────────────────────────────────────────────┘
```

---

## Thread Communication

### Using Queue (Thread-Safe)

```python
import threading
import queue
import time
import random

# Thread-safe queue
task_queue = queue.Queue()
results = []
results_lock = threading.Lock()

def producer(num_tasks):
    for i in range(num_tasks):
        task = f"Task-{i}"
        task_queue.put(task)
        print(f"Produced: {task}")
        time.sleep(random.uniform(0.1, 0.2))
    
    # Signal end of tasks
    for _ in range(3):  # One for each consumer
        task_queue.put(None)

def consumer(name):
    while True:
        task = task_queue.get()  # Blocks until item available
        
        if task is None:
            print(f"{name}: Received shutdown signal")
            break
        
        print(f"{name}: Processing {task}")
        time.sleep(random.uniform(0.2, 0.3))
        
        with results_lock:
            results.append(f"{name} completed {task}")
        
        task_queue.task_done()

# Start threads
producer_thread = threading.Thread(target=producer, args=(10,))
consumer_threads = [
    threading.Thread(target=consumer, args=(f"Consumer-{i}",))
    for i in range(3)
]

producer_thread.start()
for t in consumer_threads:
    t.start()

producer_thread.join()
for t in consumer_threads:
    t.join()

print(f"\nResults: {len(results)} tasks completed")
```

### Queue Types

```python
import queue

# FIFO Queue (default)
fifo = queue.Queue(maxsize=10)

# LIFO Queue (Stack)
lifo = queue.LifoQueue()

# Priority Queue
pq = queue.PriorityQueue()
pq.put((2, "low priority"))
pq.put((1, "high priority"))
print(pq.get())  # (1, "high priority")

# Queue methods
q = queue.Queue()
q.put(item)              # Add item (blocks if full)
q.put(item, timeout=5)   # With timeout
q.put_nowait(item)       # Non-blocking (raises Full)

item = q.get()           # Get item (blocks if empty)
item = q.get(timeout=5)  # With timeout
item = q.get_nowait()    # Non-blocking (raises Empty)

q.task_done()            # Mark task as complete
q.join()                 # Wait for all tasks to complete
q.empty()                # Check if empty (not reliable)
q.qsize()                # Approximate size
```

---

## Thread Pools

### Using concurrent.futures

```python
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

def process_item(item):
    """Simulate processing"""
    time.sleep(0.5)
    return f"Processed: {item}"

items = list(range(10))

# Method 1: Using executor.map()
with ThreadPoolExecutor(max_workers=4) as executor:
    results = list(executor.map(process_item, items))
    print(results)

# Method 2: Using executor.submit() with as_completed()
with ThreadPoolExecutor(max_workers=4) as executor:
    futures = {executor.submit(process_item, item): item for item in items}
    
    for future in as_completed(futures):
        item = futures[future]
        try:
            result = future.result()
            print(f"Item {item}: {result}")
        except Exception as e:
            print(f"Item {item} raised: {e}")
```

```
┌─────────────────────────────────────────────────────────────────┐
│                    Thread Pool Execution                         │
│                                                                  │
│   Task Queue: [T1] [T2] [T3] [T4] [T5] [T6] [T7] [T8]           │
│                │    │    │    │                                  │
│                ▼    ▼    ▼    ▼                                  │
│   ┌─────────────────────────────────────────┐                   │
│   │         Thread Pool (4 workers)          │                   │
│   │  ┌────┐  ┌────┐  ┌────┐  ┌────┐        │                   │
│   │  │ W1 │  │ W2 │  │ W3 │  │ W4 │        │                   │
│   │  │ T1 │  │ T2 │  │ T3 │  │ T4 │        │                   │
│   │  └────┘  └────┘  └────┘  └────┘        │                   │
│   └─────────────────────────────────────────┘                   │
│                                                                  │
│   After W1 finishes T1, it picks up T5                          │
│   After W2 finishes T2, it picks up T6                          │
│   ... and so on                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Thread Pool with Callbacks

```python
from concurrent.futures import ThreadPoolExecutor
import time

def fetch_data(url):
    time.sleep(1)  # Simulate network request
    return f"Data from {url}"

def process_result(future):
    """Callback executed when future completes"""
    result = future.result()
    print(f"Callback received: {result}")

with ThreadPoolExecutor(max_workers=3) as executor:
    urls = ["url1.com", "url2.com", "url3.com"]
    
    for url in urls:
        future = executor.submit(fetch_data, url)
        future.add_done_callback(process_result)
    
    # Executor waits for all tasks on context exit
```

---

## Thread Safety Patterns

### Pattern 1: Thread-Local Data

```python
import threading

# Thread-local storage
local_data = threading.local()

def process_request(request_id):
    # Each thread has its own copy
    local_data.request_id = request_id
    local_data.user = f"user_{request_id}"
    
    # Access in nested function
    do_work()

def do_work():
    # Access thread-local data without passing parameters
    print(f"Processing request {local_data.request_id} for {local_data.user}")

threads = [
    threading.Thread(target=process_request, args=(i,))
    for i in range(3)
]

for t in threads:
    t.start()

for t in threads:
    t.join()
```

### Pattern 2: Immutable Data

```python
from typing import NamedTuple
from dataclasses import dataclass, field
import threading

# Immutable using NamedTuple
class Config(NamedTuple):
    host: str
    port: int
    timeout: float

# Immutable using frozen dataclass
@dataclass(frozen=True)
class Settings:
    api_key: str
    max_retries: int

# These are thread-safe because they can't be modified
config = Config("localhost", 8080, 30.0)
settings = Settings("secret", 3)
```

### Pattern 3: Copy-on-Write

```python
import threading
import copy

class ThreadSafeConfig:
    def __init__(self):
        self._config = {"setting1": "value1", "setting2": "value2"}
        self._lock = threading.Lock()
    
    def get_config(self):
        """Return a copy to prevent external modification"""
        with self._lock:
            return copy.deepcopy(self._config)
    
    def update_config(self, key, value):
        """Update atomically"""
        with self._lock:
            self._config[key] = value
```

### Pattern 4: Read-Write Lock

```python
import threading

class ReadWriteLock:
    def __init__(self):
        self._read_ready = threading.Condition(threading.Lock())
        self._readers = 0
    
    def acquire_read(self):
        with self._read_ready:
            self._readers += 1
    
    def release_read(self):
        with self._read_ready:
            self._readers -= 1
            if self._readers == 0:
                self._read_ready.notify_all()
    
    def acquire_write(self):
        self._read_ready.acquire()
        while self._readers > 0:
            self._read_ready.wait()
    
    def release_write(self):
        self._read_ready.release()

class SharedData:
    def __init__(self):
        self.data = {}
        self.lock = ReadWriteLock()
    
    def read(self, key):
        self.lock.acquire_read()
        try:
            return self.data.get(key)
        finally:
            self.lock.release_read()
    
    def write(self, key, value):
        self.lock.acquire_write()
        try:
            self.data[key] = value
        finally:
            self.lock.release_write()
```

---

## Common Pitfalls

### 1. Race Conditions

```python
import threading

# BAD: Race condition
counter = 0

def increment():
    global counter
    for _ in range(100000):
        counter += 1  # NOT atomic!

# counter += 1 compiles to multiple bytecode instructions:
# LOAD_GLOBAL, LOAD_CONST, BINARY_ADD, STORE_GLOBAL

# GOOD: Use lock
counter = 0
lock = threading.Lock()

def safe_increment():
    global counter
    for _ in range(100000):
        with lock:
            counter += 1
```

### 2. Deadlocks

```python
import threading

lock_a = threading.Lock()
lock_b = threading.Lock()

def thread_1():
    with lock_a:
        print("Thread 1: Got lock A")
        with lock_b:  # Waiting for lock B
            print("Thread 1: Got lock B")

def thread_2():
    with lock_b:
        print("Thread 2: Got lock B")
        with lock_a:  # Waiting for lock A - DEADLOCK!
            print("Thread 2: Got lock A")

# SOLUTION: Always acquire locks in the same order
def safe_thread_1():
    with lock_a:
        with lock_b:
            print("Safe Thread 1")

def safe_thread_2():
    with lock_a:  # Same order as thread_1
        with lock_b:
            print("Safe Thread 2")
```

```
┌─────────────────────────────────────────────────────────────────┐
│                       Deadlock Scenario                          │
│                                                                  │
│   Thread 1                           Thread 2                    │
│   ┌──────────────┐                   ┌──────────────┐           │
│   │ acquire(A) ✓ │                   │ acquire(B) ✓ │           │
│   │              │                   │              │           │
│   │ acquire(B)   │──── waiting ─────►│ acquire(A)   │           │
│   │    ⏳        │◄─── waiting ──────│    ⏳        │           │
│   └──────────────┘                   └──────────────┘           │
│                                                                  │
│   Both threads waiting forever = DEADLOCK                       │
└─────────────────────────────────────────────────────────────────┘
```

### 3. Starvation

```python
import threading
import time

lock = threading.Lock()

def greedy_worker():
    """Holds lock for too long"""
    while True:
        with lock:
            time.sleep(10)  # Other threads starved!

def polite_worker():
    """Acquires lock briefly"""
    while True:
        with lock:
            # Quick operation
            pass
        time.sleep(0.1)  # Give others a chance
```

### 4. GIL-related Issues

```python
import threading
import time

# CPU-bound work - threads don't help!
def cpu_work(n):
    total = 0
    for i in range(n):
        total += i
    return total

# Use multiprocessing instead for CPU-bound tasks
from multiprocessing import Pool

def parallel_cpu_work():
    with Pool(4) as pool:
        results = pool.map(cpu_work, [10_000_000] * 4)
    return results
```

---

## Best Practices

### 1. Use Context Managers

```python
# GOOD
with lock:
    do_work()

# BAD
lock.acquire()
do_work()
lock.release()  # What if exception occurs?
```

### 2. Minimize Lock Scope

```python
# GOOD: Lock only critical section
def process_data(data):
    processed = expensive_computation(data)  # No lock needed
    with lock:
        shared_results.append(processed)

# BAD: Lock too much
def process_data(data):
    with lock:
        processed = expensive_computation(data)  # Blocks other threads
        shared_results.append(processed)
```

### 3. Use High-Level Abstractions

```python
# GOOD: Use ThreadPoolExecutor
from concurrent.futures import ThreadPoolExecutor

with ThreadPoolExecutor(max_workers=4) as executor:
    results = executor.map(process, items)

# AVOID: Manual thread management for simple tasks
threads = []
for item in items:
    t = threading.Thread(target=process, args=(item,))
    threads.append(t)
    t.start()
for t in threads:
    t.join()
```

### 4. Use Thread-Safe Data Structures

```python
import queue
from collections import deque
import threading

# Thread-safe queue
q = queue.Queue()

# For simple appends, collections.deque is thread-safe
# for append() and popleft()
d = deque()
d.append(item)      # Thread-safe
item = d.popleft()  # Thread-safe
```

### 5. Set Timeouts

```python
import threading

lock = threading.Lock()

# With timeout - avoids infinite waiting
acquired = lock.acquire(timeout=5)
if acquired:
    try:
        do_work()
    finally:
        lock.release()
else:
    handle_timeout()
```

---

## Interview Questions

### Q1: What's the difference between Lock and RLock?
**Answer**: 
- `Lock`: Can only be acquired once. Same thread trying to acquire again causes deadlock.
- `RLock`: Reentrant lock. Same thread can acquire multiple times. Must release same number of times.

### Q2: How do you prevent deadlocks?
**Answer**:
1. **Lock ordering**: Always acquire locks in consistent order
2. **Lock timeout**: Use `acquire(timeout=n)` 
3. **Try-lock**: Use `acquire(blocking=False)`
4. **Lock hierarchy**: Define lock levels, only acquire lower levels

### Q3: When should you use threading vs multiprocessing?
**Answer**:
- **Threading**: I/O-bound tasks (network, file I/O, database)
- **Multiprocessing**: CPU-bound tasks (computation, data processing)
- **asyncio**: High-concurrency I/O (thousands of connections)

### Q4: What is a daemon thread?
**Answer**: A thread that runs in the background and is automatically killed when all non-daemon threads exit. Used for background tasks like monitoring, cleanup, etc.

### Q5: How do you share data between threads safely?
**Answer**:
1. Use `threading.Lock` for mutual exclusion
2. Use `queue.Queue` for thread-safe data passing
3. Use `threading.local()` for thread-specific data
4. Use immutable data structures
5. Use atomic operations where possible

### Q6: What is the difference between `join()` and `is_alive()`?
**Answer**:
- `join()`: Blocks calling thread until target thread completes
- `is_alive()`: Returns True if thread is still running (non-blocking check)

```python
t.start()
while t.is_alive():  # Non-blocking check
    print("Thread still running")
    time.sleep(0.1)

# vs

t.start()
t.join()  # Blocks until thread completes
print("Thread finished")
```

---

## Summary

```
┌─────────────────────────────────────────────────────────────────┐
│                  Multithreading Summary                          │
├─────────────────────────────────────────────────────────────────┤
│  Use threading for: I/O-bound tasks, concurrent operations      │
│  Avoid for: CPU-bound tasks (use multiprocessing)               │
│                                                                  │
│  Synchronization:                                                │
│  • Lock/RLock - Mutual exclusion                                │
│  • Condition - Wait/notify pattern                              │
│  • Event - Simple signaling                                     │
│  • Semaphore - Limited resource access                          │
│  • Barrier - Synchronization point                              │
│                                                                  │
│  Best Practices:                                                 │
│  • Use context managers (with lock:)                            │
│  • Minimize lock scope                                          │
│  • Use ThreadPoolExecutor for thread pools                      │
│  • Use Queue for thread communication                           │
│  • Always handle exceptions in threads                          │
└─────────────────────────────────────────────────────────────────┘
```
