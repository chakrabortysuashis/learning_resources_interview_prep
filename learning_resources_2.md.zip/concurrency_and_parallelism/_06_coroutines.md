# Coroutines in Python

## Table of Contents
1. [What are Coroutines?](#what-are-coroutines)
2. [Evolution of Coroutines in Python](#evolution-of-coroutines-in-python)
3. [Coroutine Fundamentals](#coroutine-fundamentals)
4. [Awaitable Objects](#awaitable-objects)
5. [Coroutine Execution Flow](#coroutine-execution-flow)
6. [Coroutine Chaining](#coroutine-chaining)
7. [Coroutine vs Generator](#coroutine-vs-generator)
8. [Advanced Coroutine Patterns](#advanced-coroutine-patterns)
9. [Coroutine State and Lifecycle](#coroutine-state-and-lifecycle)
10. [Interview Questions](#interview-questions)

---

## What are Coroutines?

A **coroutine** is a specialized function that can pause execution and yield control back to the caller, then resume from where it left off. Unlike regular functions that run to completion, coroutines support suspension and resumption.

```
┌─────────────────────────────────────────────────────────────────┐
│                Regular Function vs Coroutine                     │
│                                                                  │
│   Regular Function:                                              │
│   ┌─────────────────────────────────────────────────────────┐   │
│   │  START ────────────────────────────────────────► END    │   │
│   │         (runs continuously until completion)             │   │
│   └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│   Coroutine:                                                     │
│   ┌─────────────────────────────────────────────────────────┐   │
│   │  START ──► SUSPEND ──► RESUME ──► SUSPEND ──► END       │   │
│   │       │      ▲           │          ▲         │          │   │
│   │       │      │           │          │         │          │   │
│   │       └──────┘           └──────────┘         │          │   │
│   │    yield control     yield control            │          │   │
│   │    to event loop     to event loop            │          │   │
│   └─────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
```

### Key Characteristics

| Feature | Description |
|---------|-------------|
| Suspension | Can pause mid-execution at `await` points |
| Resumption | Can continue from suspension point |
| State Preservation | Local variables preserved during suspension |
| Single-threaded | No thread switching, cooperative multitasking |
| Non-blocking | Yields control during I/O waits |

---

## Evolution of Coroutines in Python

### Timeline

```
┌─────────────────────────────────────────────────────────────────┐
│                  Python Coroutine Evolution                      │
│                                                                  │
│   Python 2.5 (2006)  │  Generator-based coroutines              │
│                      │  yield expression + send()               │
│                      │                                           │
│   Python 3.3 (2012)  │  yield from statement                    │
│                      │  Delegation to sub-generators            │
│                      │                                           │
│   Python 3.4 (2014)  │  asyncio module introduced               │
│                      │  @asyncio.coroutine decorator            │
│                      │                                           │
│   Python 3.5 (2015)  │  async/await syntax (native coroutines) │
│                      │  async def, await keywords               │
│                      │                                           │
│   Python 3.6+ (2016) │  Async generators                        │
│                      │  async for, async with                   │
│                      │                                           │
│   Python 3.11 (2022) │  TaskGroups, exception groups           │
└─────────────────────────────────────────────────────────────────┘
```

### Generator-based Coroutines (Legacy)

```python
import asyncio

# Old style (Python 3.4) - DEPRECATED
@asyncio.coroutine
def old_style_coroutine():
    yield from asyncio.sleep(1)
    return "Old style result"

# New style (Python 3.5+) - RECOMMENDED
async def new_style_coroutine():
    await asyncio.sleep(1)
    return "New style result"

# Both work the same, but async/await is clearer
```

---

## Coroutine Fundamentals

### Defining Coroutines

```python
import asyncio

# A coroutine function (async def)
async def fetch_data(url):
    print(f"Fetching {url}...")
    await asyncio.sleep(1)  # Simulate network delay
    return f"Data from {url}"

# Calling the function returns a coroutine object
coro = fetch_data("https://example.com")
print(type(coro))  # <class 'coroutine'>

# The coroutine is NOT executed yet!
# Must be awaited or run with asyncio
async def main():
    result = await coro  # NOW it executes
    print(result)

asyncio.run(main())
```

### The await Expression

```python
import asyncio

async def inner():
    await asyncio.sleep(0.5)
    return 42

async def outer():
    # await suspends outer() until inner() completes
    result = await inner()
    print(f"Got: {result}")
    
    # Can await multiple things
    a = await inner()
    b = await inner()
    print(f"Sum: {a + b}")

asyncio.run(outer())
```

```
┌─────────────────────────────────────────────────────────────────┐
│                   await Execution Flow                           │
│                                                                  │
│   async def outer():                                             │
│       result = await inner()  ──┐                               │
│       print(result)             │                               │
│                                 │                               │
│   When await is reached:        │                               │
│   1. outer() SUSPENDS ◄─────────┘                               │
│   2. Control returns to event loop                              │
│   3. Event loop can run other tasks                             │
│   4. When inner() completes:                                    │
│      - Event loop RESUMES outer()                               │
│      - result receives return value                             │
│                                                                  │
│   Timeline:                                                      │
│   outer: ████░░░░░░░░░░░░░░░░████████████                       │
│   inner:     ████████████████                                   │
│   other:     ████  ████  ████ (can run while waiting)          │
└─────────────────────────────────────────────────────────────────┘
```

### What Can Be Awaited?

```python
import asyncio

# 1. Coroutines
async def coroutine_example():
    return "coroutine"

# 2. Tasks
async def task_example():
    task = asyncio.create_task(coroutine_example())
    return await task

# 3. Futures
async def future_example():
    loop = asyncio.get_running_loop()
    future = loop.create_future()
    loop.call_later(1, future.set_result, "future")
    return await future

# 4. Objects with __await__ method
class Awaitable:
    def __await__(self):
        yield  # Must yield at least once
        return "custom awaitable"

async def custom_example():
    return await Awaitable()
```

---

## Awaitable Objects

### The __await__ Protocol

```python
import asyncio

class CustomAwaitable:
    def __init__(self, value, delay):
        self.value = value
        self.delay = delay
    
    def __await__(self):
        # Delegate to a coroutine's __await__
        return self._wait().__await__()
    
    async def _wait(self):
        await asyncio.sleep(self.delay)
        return self.value

async def main():
    result = await CustomAwaitable("Hello", 1)
    print(result)

asyncio.run(main())
```

### Awaitable Type Hierarchy

```
┌─────────────────────────────────────────────────────────────────┐
│                   Awaitable Type Hierarchy                       │
│                                                                  │
│                      ┌───────────────┐                          │
│                      │   Awaitable   │                          │
│                      │  (ABC)        │                          │
│                      └───────┬───────┘                          │
│                              │                                   │
│              ┌───────────────┼───────────────┐                  │
│              │               │               │                  │
│              ▼               ▼               ▼                  │
│     ┌────────────┐   ┌────────────┐   ┌────────────┐           │
│     │  Coroutine │   │   Future   │   │   Custom   │           │
│     │            │   │            │   │ __await__  │           │
│     └────────────┘   └─────┬──────┘   └────────────┘           │
│                            │                                    │
│                            ▼                                    │
│                      ┌───────────┐                              │
│                      │   Task    │                              │
│                      │ (Future)  │                              │
│                      └───────────┘                              │
│                                                                  │
│   All can be used with: await obj                               │
└─────────────────────────────────────────────────────────────────┘
```

### Checking if Object is Awaitable

```python
import asyncio
import inspect
from collections.abc import Awaitable

async def coro():
    pass

def regular():
    pass

# Check if awaitable
print(inspect.iscoroutine(coro()))           # True
print(inspect.iscoroutinefunction(coro))     # True
print(inspect.isawaitable(coro()))           # True
print(isinstance(coro(), Awaitable))         # True

print(inspect.iscoroutinefunction(regular))  # False
```

---

## Coroutine Execution Flow

### Single Coroutine Flow

```python
import asyncio

async def step_by_step():
    print("Step 1: Start")
    
    print("Step 2: Before first await")
    await asyncio.sleep(1)
    print("Step 3: After first await")
    
    print("Step 4: Before second await")
    await asyncio.sleep(1)
    print("Step 5: After second await")
    
    print("Step 6: End")
    return "Complete"

asyncio.run(step_by_step())
```

```
┌─────────────────────────────────────────────────────────────────┐
│                Single Coroutine Execution                        │
│                                                                  │
│   Time:  0s        1s        2s                                 │
│          │         │         │                                   │
│          ▼         ▼         ▼                                   │
│   ┌──────────┐ ┌──────────┐ ┌──────────┐                        │
│   │ Step 1-2 │ │ Step 3-4 │ │ Step 5-6 │                        │
│   └────┬─────┘ └────┬─────┘ └──────────┘                        │
│        │            │                                            │
│        ▼            ▼                                            │
│   ┌──────────┐ ┌──────────┐                                     │
│   │  await   │ │  await   │                                     │
│   │ sleep(1) │ │ sleep(1) │                                     │
│   │(suspend) │ │(suspend) │                                     │
│   └──────────┘ └──────────┘                                     │
│                                                                  │
│   Event loop is free during await periods                       │
└─────────────────────────────────────────────────────────────────┘
```

### Multiple Coroutines Flow

```python
import asyncio

async def task_a():
    print("A: Start")
    await asyncio.sleep(2)
    print("A: End")
    return "A"

async def task_b():
    print("B: Start")
    await asyncio.sleep(1)
    print("B: End")
    return "B"

async def task_c():
    print("C: Start")
    await asyncio.sleep(1.5)
    print("C: End")
    return "C"

async def main():
    # Run concurrently
    results = await asyncio.gather(task_a(), task_b(), task_c())
    print(f"Results: {results}")

asyncio.run(main())
```

```
┌─────────────────────────────────────────────────────────────────┐
│              Multiple Coroutines Execution                       │
│                                                                  │
│   Time:  0s     0.5s     1s     1.5s     2s                     │
│          │       │       │       │       │                       │
│   A:     ├───────────────────────────────┤                      │
│          │ Start          await          │ End                   │
│          │               sleep(2)        │                       │
│                                                                  │
│   B:     ├───────────────┤                                      │
│          │ Start  await  │ End                                   │
│          │      sleep(1) │                                       │
│                                                                  │
│   C:     ├───────────────────────┤                              │
│          │ Start    await        │ End                           │
│          │        sleep(1.5)     │                               │
│                                                                  │
│   Output order: A:Start, B:Start, C:Start,                      │
│                 B:End (1s), C:End (1.5s), A:End (2s)            │
└─────────────────────────────────────────────────────────────────┘
```

### Context Switching

```python
import asyncio

async def verbose_task(name, steps):
    for i in range(steps):
        print(f"[{name}] Step {i + 1}")
        await asyncio.sleep(0)  # Yield control

async def main():
    # Create tasks
    task1 = asyncio.create_task(verbose_task("A", 3))
    task2 = asyncio.create_task(verbose_task("B", 3))
    
    await asyncio.gather(task1, task2)

asyncio.run(main())

# Output shows interleaving:
# [A] Step 1
# [B] Step 1
# [A] Step 2
# [B] Step 2
# [A] Step 3
# [B] Step 3
```

---

## Coroutine Chaining

### Sequential Chaining

```python
import asyncio

async def fetch(url):
    await asyncio.sleep(1)
    return f"data from {url}"

async def parse(data):
    await asyncio.sleep(0.5)
    return f"parsed: {data}"

async def save(parsed):
    await asyncio.sleep(0.5)
    return f"saved: {parsed}"

async def pipeline(url):
    # Sequential chain
    data = await fetch(url)
    parsed = await parse(data)
    result = await save(parsed)
    return result

async def main():
    result = await pipeline("https://example.com")
    print(result)
    # Total time: ~2 seconds

asyncio.run(main())
```

### Parallel Chaining

```python
import asyncio

async def fetch_user(user_id):
    await asyncio.sleep(1)
    return {"id": user_id, "name": f"User {user_id}"}

async def fetch_posts(user_id):
    await asyncio.sleep(1.5)
    return [f"Post {i} by user {user_id}" for i in range(3)]

async def fetch_comments(user_id):
    await asyncio.sleep(0.8)
    return [f"Comment {i} on user {user_id}" for i in range(5)]

async def get_user_dashboard(user_id):
    # Fetch all data in parallel
    user, posts, comments = await asyncio.gather(
        fetch_user(user_id),
        fetch_posts(user_id),
        fetch_comments(user_id)
    )
    
    return {
        "user": user,
        "posts": posts,
        "comments": comments
    }

async def main():
    import time
    start = time.perf_counter()
    
    result = await get_user_dashboard(123)
    
    print(f"Time: {time.perf_counter() - start:.2f}s")
    # Time: ~1.5s (not 3.3s if sequential)
    print(result)

asyncio.run(main())
```

```
┌─────────────────────────────────────────────────────────────────┐
│            Sequential vs Parallel Chaining                       │
│                                                                  │
│   Sequential:                                                    │
│   ┌────────┐ ┌────────────┐ ┌──────────┐                        │
│   │  user  │ │   posts    │ │ comments │                        │
│   │  (1s)  │ │   (1.5s)   │ │  (0.8s)  │                        │
│   └────────┘ └────────────┘ └──────────┘                        │
│   ═══════════════════════════════════════► 3.3s                 │
│                                                                  │
│   Parallel (with gather):                                        │
│   ┌────────┐                                                     │
│   │  user  │                                                     │
│   │  (1s)  │                                                     │
│   └────────┘                                                     │
│   ┌────────────┐                                                │
│   │   posts    │                                                │
│   │   (1.5s)   │                                                │
│   └────────────┘                                                │
│   ┌──────────┐                                                  │
│   │ comments │                                                  │
│   │  (0.8s)  │                                                  │
│   └──────────┘                                                  │
│   ═══════════════► 1.5s (max of all)                            │
└─────────────────────────────────────────────────────────────────┘
```

### Dependency Chains

```python
import asyncio

async def fetch_config():
    await asyncio.sleep(0.5)
    return {"api_url": "https://api.example.com"}

async def fetch_token(config):
    await asyncio.sleep(0.5)
    return f"token_for_{config['api_url']}"

async def fetch_data(token):
    await asyncio.sleep(1)
    return f"data_with_{token}"

async def main():
    # Dependencies: config → token → data
    config = await fetch_config()
    token = await fetch_token(config)  # Needs config
    data = await fetch_data(token)     # Needs token
    print(data)

asyncio.run(main())
```

---

## Coroutine vs Generator

### Key Differences

```
┌─────────────────────────────────────────────────────────────────┐
│              Generator vs Coroutine Comparison                   │
│                                                                  │
│   Feature          │ Generator         │ Coroutine              │
│   ─────────────────────────────────────────────────────────────│
│   Definition       │ def + yield       │ async def + await      │
│   Purpose          │ Produce values    │ Async operations       │
│   Control Flow     │ Pull (next())     │ Push/Pull (await)      │
│   Return           │ StopIteration     │ Return value           │
│   Iteration        │ for x in gen      │ await coro             │
│   State            │ Preserves locals  │ Preserves locals       │
│   Scheduling       │ Manual            │ Event loop             │
└─────────────────────────────────────────────────────────────────┘
```

### Generator Example

```python
def countdown(n):
    """Generator: produces values lazily"""
    while n > 0:
        yield n  # Produces value, suspends
        n -= 1

# Usage: pull values
for num in countdown(5):
    print(num)

# Or manually
gen = countdown(3)
print(next(gen))  # 3
print(next(gen))  # 2
print(next(gen))  # 1
```

### Coroutine Example

```python
import asyncio

async def countdown(n):
    """Coroutine: async operation"""
    while n > 0:
        print(n)
        await asyncio.sleep(1)  # Async wait, suspends
        n -= 1
    return "Done"

# Usage: must be awaited
async def main():
    result = await countdown(3)
    print(result)

asyncio.run(main())
```

### Async Generators (Combining Both)

```python
import asyncio

async def async_countdown(n):
    """Async generator: produces values with async operations"""
    while n > 0:
        await asyncio.sleep(1)
        yield n  # Produces value
        n -= 1

async def main():
    # Use async for
    async for num in async_countdown(3):
        print(num)
    
    # Or async comprehension
    values = [num async for num in async_countdown(3)]
    print(values)

asyncio.run(main())
```

---

## Advanced Coroutine Patterns

### Pattern 1: Timeout Wrapper

```python
import asyncio
from typing import TypeVar, Coroutine

T = TypeVar('T')

async def with_timeout(coro: Coroutine[None, None, T], timeout: float) -> T:
    """Wrapper that adds timeout to any coroutine"""
    try:
        return await asyncio.wait_for(coro, timeout=timeout)
    except asyncio.TimeoutError:
        raise TimeoutError(f"Operation timed out after {timeout}s")

async def slow_operation():
    await asyncio.sleep(10)
    return "Done"

async def main():
    try:
        result = await with_timeout(slow_operation(), 2)
    except TimeoutError as e:
        print(e)

asyncio.run(main())
```

### Pattern 2: Retry Decorator

```python
import asyncio
import functools
from typing import Callable, TypeVar

T = TypeVar('T')

def async_retry(max_attempts: int = 3, delay: float = 1.0):
    """Decorator that retries async functions on failure"""
    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            last_exception = None
            for attempt in range(max_attempts):
                try:
                    return await func(*args, **kwargs)
                except Exception as e:
                    last_exception = e
                    if attempt < max_attempts - 1:
                        await asyncio.sleep(delay * (2 ** attempt))
            raise last_exception
        return wrapper
    return decorator

@async_retry(max_attempts=3, delay=1.0)
async def flaky_operation():
    import random
    if random.random() < 0.7:
        raise ConnectionError("Random failure")
    return "Success"

async def main():
    try:
        result = await flaky_operation()
        print(result)
    except ConnectionError:
        print("All retries failed")

asyncio.run(main())
```

### Pattern 3: Semaphore for Rate Limiting

```python
import asyncio

class RateLimitedClient:
    def __init__(self, max_concurrent: int = 5):
        self.semaphore = asyncio.Semaphore(max_concurrent)
    
    async def fetch(self, url: str) -> str:
        async with self.semaphore:
            # Only max_concurrent fetches at a time
            print(f"Fetching {url}")
            await asyncio.sleep(1)
            return f"Data from {url}"

async def main():
    client = RateLimitedClient(max_concurrent=3)
    
    urls = [f"url_{i}" for i in range(10)]
    
    # All 10 start, but only 3 run concurrently
    results = await asyncio.gather(*[client.fetch(url) for url in urls])
    print(f"Fetched {len(results)} URLs")

asyncio.run(main())
```

### Pattern 4: Producer-Consumer

```python
import asyncio
import random

async def producer(queue: asyncio.Queue, name: str):
    for i in range(5):
        item = f"{name}_item_{i}"
        await queue.put(item)
        print(f"Produced: {item}")
        await asyncio.sleep(random.uniform(0.1, 0.5))
    await queue.put(None)  # Sentinel

async def consumer(queue: asyncio.Queue, name: str):
    while True:
        item = await queue.get()
        if item is None:
            print(f"{name}: Received shutdown signal")
            break
        print(f"{name}: Consumed {item}")
        await asyncio.sleep(random.uniform(0.2, 0.6))
        queue.task_done()

async def main():
    queue = asyncio.Queue(maxsize=10)
    
    producers = [
        asyncio.create_task(producer(queue, f"P{i}"))
        for i in range(2)
    ]
    
    consumers = [
        asyncio.create_task(consumer(queue, f"C{i}"))
        for i in range(3)
    ]
    
    await asyncio.gather(*producers)
    
    # Send shutdown to all consumers
    for _ in consumers:
        await queue.put(None)
    
    await asyncio.gather(*consumers)

asyncio.run(main())
```

### Pattern 5: Context-Aware Coroutines

```python
import asyncio
from contextvars import ContextVar

# Context variable for request ID
request_id: ContextVar[str] = ContextVar('request_id', default='unknown')

async def log(message: str):
    """Logger that includes context"""
    rid = request_id.get()
    print(f"[{rid}] {message}")

async def fetch_data():
    await log("Fetching data...")
    await asyncio.sleep(1)
    await log("Data fetched")
    return "data"

async def process_request(rid: str):
    # Set context for this request
    request_id.set(rid)
    
    await log("Starting request")
    data = await fetch_data()
    await log(f"Processed: {data}")

async def main():
    # Each request has its own context
    await asyncio.gather(
        process_request("REQ-001"),
        process_request("REQ-002"),
        process_request("REQ-003"),
    )

asyncio.run(main())
```

---

## Coroutine State and Lifecycle

### Inspecting Coroutine State

```python
import asyncio
import inspect

async def example_coroutine():
    await asyncio.sleep(1)
    return "done"

# Create coroutine object
coro = example_coroutine()

# Inspect state
print(f"Is coroutine: {inspect.iscoroutine(coro)}")
print(f"Coroutine state: {inspect.getcoroutinestate(coro)}")
# Output: CORO_CREATED

async def main():
    task = asyncio.create_task(coro)
    
    # While running
    await asyncio.sleep(0.1)
    # State would be: CORO_RUNNING or CORO_SUSPENDED
    
    result = await task
    print(f"Result: {result}")

asyncio.run(main())
```

### Coroutine States

```
┌─────────────────────────────────────────────────────────────────┐
│                    Coroutine States                              │
│                                                                  │
│   State           │ Description                                 │
│   ─────────────────────────────────────────────────────────────│
│   CORO_CREATED    │ Created, not yet started                   │
│   CORO_RUNNING    │ Currently being executed                   │
│   CORO_SUSPENDED  │ Suspended at await                         │
│   CORO_CLOSED     │ Completed or closed                        │
│                                                                  │
│   Lifecycle:                                                     │
│   ┌────────────┐                                                │
│   │  CREATED   │                                                │
│   └─────┬──────┘                                                │
│         │ await / send()                                        │
│         ▼                                                        │
│   ┌────────────┐     await suspended                            │
│   │  RUNNING   │◄────────────────────┐                          │
│   └─────┬──────┘                     │                          │
│         │ await expression           │                          │
│         ▼                            │                          │
│   ┌────────────┐                     │                          │
│   │ SUSPENDED  │─────────────────────┘                          │
│   └─────┬──────┘     awaited value ready                        │
│         │ return / exception / close()                          │
│         ▼                                                        │
│   ┌────────────┐                                                │
│   │   CLOSED   │                                                │
│   └────────────┘                                                │
└─────────────────────────────────────────────────────────────────┘
```

### Closing Coroutines

```python
import asyncio

async def cleanup_coroutine():
    try:
        while True:
            print("Working...")
            await asyncio.sleep(1)
    except asyncio.CancelledError:
        print("Cleanup: Coroutine was cancelled")
        raise
    finally:
        print("Finally: Always runs on close")

async def main():
    coro = cleanup_coroutine()
    task = asyncio.create_task(coro)
    
    await asyncio.sleep(2.5)
    
    # Cancel the task
    task.cancel()
    
    try:
        await task
    except asyncio.CancelledError:
        print("Main: Caught cancellation")

asyncio.run(main())
```

### Stack Inspection

```python
import asyncio
import traceback

async def level_3():
    await asyncio.sleep(10)

async def level_2():
    await level_3()

async def level_1():
    await level_2()

async def main():
    task = asyncio.create_task(level_1())
    
    await asyncio.sleep(0.1)
    
    # Print coroutine stack
    print("Coroutine stack:")
    for frame in task.get_stack():
        print(f"  {frame.f_code.co_name} at {frame.f_code.co_filename}:{frame.f_lineno}")
    
    task.cancel()
    try:
        await task
    except asyncio.CancelledError:
        pass

asyncio.run(main())
```

---

## Interview Questions

### Q1: What is a coroutine and how is it different from a function?
**Answer**: A coroutine is a function that can suspend and resume execution. Regular functions run to completion; coroutines can pause at `await` points, allowing other code to run. Defined with `async def`, they return coroutine objects that must be awaited.

### Q2: What happens when you call an async function without await?
**Answer**: You get a coroutine object, but it doesn't execute. Python issues a `RuntimeWarning: coroutine 'xxx' was never awaited`. The coroutine is garbage collected without running.

```python
async def foo():
    return 42

foo()  # Returns coroutine object, doesn't run!
# RuntimeWarning: coroutine 'foo' was never awaited
```

### Q3: Can you use await outside of an async function?
**Answer**: No. `await` can only be used inside `async def` functions. Using it elsewhere raises `SyntaxError`. To run async code from sync context, use `asyncio.run()`.

### Q4: What is the difference between asyncio.create_task() and await?
**Answer**:
- `await`: Suspends current coroutine, waits for result
- `create_task()`: Schedules coroutine to run concurrently, returns immediately

```python
# Sequential (slow)
result1 = await coro1()
result2 = await coro2()

# Concurrent (fast)
task1 = asyncio.create_task(coro1())
task2 = asyncio.create_task(coro2())
result1 = await task1
result2 = await task2
```

### Q5: How do async generators differ from regular generators?
**Answer**:
- Regular generator: `def` + `yield`, iterated with `for`
- Async generator: `async def` + `yield`, iterated with `async for`
- Async generators can contain `await` expressions

```python
async def async_gen():
    for i in range(3):
        await asyncio.sleep(1)
        yield i

async for value in async_gen():
    print(value)
```

### Q6: What is CancelledError and how should you handle it?
**Answer**: `CancelledError` is raised when a task is cancelled. Best practice:
1. Catch it to perform cleanup
2. Re-raise it so the cancellation propagates
3. Don't suppress it unless you're intentionally preventing cancellation

```python
async def cancellable():
    try:
        await asyncio.sleep(10)
    except asyncio.CancelledError:
        print("Cleaning up...")
        raise  # Re-raise!
```

---

## Summary

```
┌─────────────────────────────────────────────────────────────────┐
│                     Coroutine Summary                            │
├─────────────────────────────────────────────────────────────────┤
│  Definition:                                                     │
│  • async def func() - defines coroutine function                │
│  • await expr - suspend and wait for awaitable                  │
│  • Calling async func returns coroutine object                  │
│                                                                  │
│  Awaitable Types:                                                │
│  • Coroutines (from async def)                                  │
│  • Tasks (wrapped coroutines)                                   │
│  • Futures (low-level promises)                                 │
│  • Objects with __await__                                       │
│                                                                  │
│  Execution:                                                      │
│  • asyncio.run(main()) - entry point                            │
│  • asyncio.create_task() - concurrent execution                 │
│  • asyncio.gather() - wait for multiple                         │
│                                                                  │
│  Lifecycle:                                                      │
│  • CREATED → RUNNING → SUSPENDED → CLOSED                       │
│  • Handle CancelledError for cleanup                            │
│                                                                  │
│  Best Practices:                                                 │
│  • Always await coroutines                                      │
│  • Use create_task for concurrency                              │
│  • Handle cancellation properly                                 │
│  • Don't block inside coroutines                                │
└─────────────────────────────────────────────────────────────────┘
```
