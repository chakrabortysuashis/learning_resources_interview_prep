# Event Loop in Python - Implementation & Code

## Table of Contents
1. [Getting and Running the Event Loop](#1-getting-and-running-the-event-loop)
2. [Scheduling Callbacks](#2-scheduling-callbacks)
3. [Working with Tasks](#3-working-with-tasks)
4. [Running Blocking Code](#4-running-blocking-code)
5. [Event Loop Methods](#5-event-loop-methods)
6. [Practical Patterns](#6-practical-patterns)

---

## 1. Getting and Running the Event Loop

### Using asyncio.run() (Recommended)

```python
import asyncio

async def main():
    print("Hello")
    await asyncio.sleep(1)
    print("World")
    return "Done"

# Best way to run async code from sync
result = asyncio.run(main())
print(result)  # "Done"

# asyncio.run():
# 1. Creates a new event loop
# 2. Runs the coroutine until complete
# 3. Closes the loop
# 4. Returns the result
```

### Getting the Current Event Loop

```python
import asyncio

async def show_loop():
    # Inside async function
    loop = asyncio.get_running_loop()
    print(f"Running loop: {loop}")
    print(f"Is running: {loop.is_running()}")

asyncio.run(show_loop())
```

### Manual Loop Management

```python
import asyncio

async def my_coroutine():
    await asyncio.sleep(1)
    return "result"

# Manual loop management (advanced use only)
loop = asyncio.new_event_loop()
asyncio.set_event_loop(loop)

try:
    result = loop.run_until_complete(my_coroutine())
    print(result)
finally:
    loop.close()
```

### Running Forever

```python
import asyncio

async def periodic_task():
    while True:
        print("Running periodic task...")
        await asyncio.sleep(2)

async def main():
    # Start background task
    task = asyncio.create_task(periodic_task())
    
    # Run for 10 seconds then cancel
    await asyncio.sleep(10)
    task.cancel()
    
    try:
        await task
    except asyncio.CancelledError:
        print("Periodic task cancelled")

asyncio.run(main())
```

---

## 2. Scheduling Callbacks

### call_soon() - Schedule Immediately

```python
import asyncio

def callback(message):
    print(f"Callback: {message}")

async def main():
    loop = asyncio.get_running_loop()
    
    # Schedule callback to run on next iteration
    loop.call_soon(callback, "Hello")
    loop.call_soon(callback, "World")
    
    print("Callbacks scheduled")
    
    # Let the event loop run
    await asyncio.sleep(0)
    
    print("Done")

asyncio.run(main())
# Output:
# Callbacks scheduled
# Callback: Hello
# Callback: World
# Done
```

### call_later() - Schedule After Delay

```python
import asyncio

def delayed_callback(name, time_scheduled):
    print(f"{name} executed (scheduled at {time_scheduled})")

async def main():
    loop = asyncio.get_running_loop()
    current = loop.time()
    
    # Schedule callbacks with delays
    loop.call_later(2.0, delayed_callback, "Task A", current)
    loop.call_later(1.0, delayed_callback, "Task B", current)
    loop.call_later(0.5, delayed_callback, "Task C", current)
    
    print("All callbacks scheduled")
    
    # Wait for all callbacks to execute
    await asyncio.sleep(3)

asyncio.run(main())
# Output:
# All callbacks scheduled
# Task C executed (after ~0.5s)
# Task B executed (after ~1.0s)
# Task A executed (after ~2.0s)
```

### call_at() - Schedule at Specific Time

```python
import asyncio

def timed_callback(scheduled_time):
    loop = asyncio.get_running_loop()
    print(f"Executed at loop time {loop.time():.2f} (scheduled for {scheduled_time:.2f})")

async def main():
    loop = asyncio.get_running_loop()
    now = loop.time()
    
    # Schedule at specific loop times
    loop.call_at(now + 1.0, timed_callback, now + 1.0)
    loop.call_at(now + 2.0, timed_callback, now + 2.0)
    
    await asyncio.sleep(3)

asyncio.run(main())
```

### Cancelling Scheduled Callbacks

```python
import asyncio

def my_callback():
    print("This will NOT run")

async def main():
    loop = asyncio.get_running_loop()
    
    # call_later returns a Handle
    handle = loop.call_later(1.0, my_callback)
    
    # Cancel before it executes
    handle.cancel()
    
    await asyncio.sleep(2)
    print("Callback was cancelled")

asyncio.run(main())
```

---

## 3. Working with Tasks

### Creating and Managing Tasks

```python
import asyncio

async def worker(name, delay):
    print(f"{name} starting")
    await asyncio.sleep(delay)
    print(f"{name} finished")
    return f"{name} result"

async def main():
    # Create tasks
    task1 = asyncio.create_task(worker("Task-1", 2))
    task2 = asyncio.create_task(worker("Task-2", 1))
    
    # Tasks start running immediately!
    print("Tasks created")
    
    # Wait for both
    results = await asyncio.gather(task1, task2)
    print(f"Results: {results}")

asyncio.run(main())
```

### Task Properties

```python
import asyncio

async def example():
    await asyncio.sleep(1)
    return "done"

async def main():
    task = asyncio.create_task(example(), name="my-task")
    
    # Task properties
    print(f"Name: {task.get_name()}")
    print(f"Done: {task.done()}")
    print(f"Cancelled: {task.cancelled()}")
    
    # Wait for completion
    result = await task
    
    print(f"Done: {task.done()}")
    print(f"Result: {task.result()}")

asyncio.run(main())
```

### Getting All Tasks

```python
import asyncio

async def background_task(n):
    await asyncio.sleep(n)

async def main():
    # Create some tasks
    tasks = [
        asyncio.create_task(background_task(1), name="task-1"),
        asyncio.create_task(background_task(2), name="task-2"),
        asyncio.create_task(background_task(3), name="task-3"),
    ]
    
    # Get all tasks
    all_tasks = asyncio.all_tasks()
    print(f"Total tasks: {len(all_tasks)}")
    for task in all_tasks:
        print(f"  - {task.get_name()}")
    
    # Get current task
    current = asyncio.current_task()
    print(f"Current task: {current.get_name()}")
    
    await asyncio.gather(*tasks)

asyncio.run(main())
```

---

## 4. Running Blocking Code

### run_in_executor() - Thread Pool

```python
import asyncio
import time
from concurrent.futures import ThreadPoolExecutor

def blocking_io(seconds):
    """Blocking I/O operation"""
    print(f"Blocking for {seconds}s...")
    time.sleep(seconds)
    return f"Blocked for {seconds}s"

async def main():
    loop = asyncio.get_running_loop()
    
    # Run in default thread pool (None)
    result = await loop.run_in_executor(None, blocking_io, 2)
    print(result)
    
    # Run in custom thread pool
    with ThreadPoolExecutor(max_workers=4) as pool:
        futures = [
            loop.run_in_executor(pool, blocking_io, 1),
            loop.run_in_executor(pool, blocking_io, 1),
            loop.run_in_executor(pool, blocking_io, 1),
        ]
        results = await asyncio.gather(*futures)
        print(f"Results: {results}")

asyncio.run(main())
```

### run_in_executor() - Process Pool

```python
import asyncio
from concurrent.futures import ProcessPoolExecutor

def cpu_intensive(n):
    """CPU-bound operation"""
    return sum(i * i for i in range(n))

async def main():
    loop = asyncio.get_running_loop()
    
    # Use ProcessPoolExecutor for CPU-bound work
    with ProcessPoolExecutor(max_workers=4) as pool:
        futures = [
            loop.run_in_executor(pool, cpu_intensive, 10_000_000),
            loop.run_in_executor(pool, cpu_intensive, 10_000_000),
            loop.run_in_executor(pool, cpu_intensive, 10_000_000),
            loop.run_in_executor(pool, cpu_intensive, 10_000_000),
        ]
        results = await asyncio.gather(*futures)
        print(f"Results: {results}")

if __name__ == "__main__":
    asyncio.run(main())
```

### asyncio.to_thread() (Python 3.9+)

```python
import asyncio
import time

def blocking_task(name, delay):
    time.sleep(delay)
    return f"{name} completed"

async def main():
    # Simpler syntax for running in thread
    results = await asyncio.gather(
        asyncio.to_thread(blocking_task, "A", 1),
        asyncio.to_thread(blocking_task, "B", 1),
        asyncio.to_thread(blocking_task, "C", 1),
    )
    print(results)

asyncio.run(main())
```

---

## 5. Event Loop Methods

### Time Management

```python
import asyncio

async def main():
    loop = asyncio.get_running_loop()
    
    # Get loop time (monotonic)
    start = loop.time()
    
    await asyncio.sleep(1)
    
    elapsed = loop.time() - start
    print(f"Elapsed: {elapsed:.2f}s")

asyncio.run(main())
```

### Debug Mode

```python
import asyncio

async def slow_operation():
    # This blocks the event loop!
    import time
    time.sleep(0.2)  # Bad! Should use await asyncio.sleep()

async def main():
    await slow_operation()

# Enable debug mode
asyncio.run(main(), debug=True)
# Will show warning about slow callback
```

### Exception Handling

```python
import asyncio

def exception_handler(loop, context):
    """Custom exception handler for the event loop"""
    exception = context.get('exception')
    message = context.get('message')
    
    print(f"Exception handler caught: {message}")
    if exception:
        print(f"Exception: {exception}")

async def failing_task():
    raise ValueError("Something went wrong")

async def main():
    loop = asyncio.get_running_loop()
    loop.set_exception_handler(exception_handler)
    
    # Fire and forget - exception will be caught by handler
    task = asyncio.create_task(failing_task())
    
    await asyncio.sleep(1)
    # Exception is logged but doesn't crash the program

asyncio.run(main())
```

---

## 6. Practical Patterns

### Pattern 1: Graceful Shutdown

```python
import asyncio
import signal

class Application:
    def __init__(self):
        self.running = True
        self.tasks = []
    
    async def background_task(self, name):
        while self.running:
            print(f"{name} running...")
            await asyncio.sleep(1)
        print(f"{name} stopped")
    
    async def run(self):
        # Start background tasks
        self.tasks = [
            asyncio.create_task(self.background_task("Worker-1")),
            asyncio.create_task(self.background_task("Worker-2")),
        ]
        
        # Wait for shutdown signal
        try:
            await asyncio.gather(*self.tasks)
        except asyncio.CancelledError:
            print("Tasks cancelled")
    
    def shutdown(self):
        print("Shutting down...")
        self.running = False
        for task in self.tasks:
            task.cancel()

async def main():
    app = Application()
    
    loop = asyncio.get_running_loop()
    
    # Handle SIGINT (Ctrl+C)
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, app.shutdown)
    
    await app.run()

# Note: signal handlers only work on Unix
# asyncio.run(main())
```

### Pattern 2: Periodic Tasks

```python
import asyncio
from datetime import datetime

async def periodic(interval: float, func, *args):
    """Run a function periodically"""
    while True:
        await func(*args)
        await asyncio.sleep(interval)

async def log_time():
    print(f"Current time: {datetime.now()}")

async def check_health():
    print("Health check OK")

async def main():
    # Start periodic tasks
    tasks = [
        asyncio.create_task(periodic(2.0, log_time)),
        asyncio.create_task(periodic(5.0, check_health)),
    ]
    
    # Run for 15 seconds
    await asyncio.sleep(15)
    
    # Cancel periodic tasks
    for task in tasks:
        task.cancel()
    
    await asyncio.gather(*tasks, return_exceptions=True)

asyncio.run(main())
```

### Pattern 3: Rate-Limited Task Scheduler

```python
import asyncio
from collections import deque
import time

class RateLimitedScheduler:
    def __init__(self, max_per_second: float):
        self.min_interval = 1.0 / max_per_second
        self.last_run = 0
        self.queue = asyncio.Queue()
        self._running = True
    
    async def submit(self, coro):
        """Submit a coroutine for rate-limited execution"""
        future = asyncio.get_event_loop().create_future()
        await self.queue.put((coro, future))
        return await future
    
    async def run(self):
        """Process queue with rate limiting"""
        while self._running:
            try:
                coro, future = await asyncio.wait_for(
                    self.queue.get(), timeout=1.0
                )
            except asyncio.TimeoutError:
                continue
            
            # Enforce rate limit
            now = time.monotonic()
            wait_time = self.last_run + self.min_interval - now
            if wait_time > 0:
                await asyncio.sleep(wait_time)
            
            # Execute coroutine
            try:
                result = await coro
                future.set_result(result)
            except Exception as e:
                future.set_exception(e)
            
            self.last_run = time.monotonic()
    
    def stop(self):
        self._running = False

async def api_call(n):
    """Simulate API call"""
    print(f"API call {n} at {time.time():.2f}")
    return f"Result {n}"

async def main():
    scheduler = RateLimitedScheduler(max_per_second=2)
    
    # Start scheduler
    scheduler_task = asyncio.create_task(scheduler.run())
    
    # Submit multiple calls
    results = await asyncio.gather(
        scheduler.submit(api_call(1)),
        scheduler.submit(api_call(2)),
        scheduler.submit(api_call(3)),
        scheduler.submit(api_call(4)),
        scheduler.submit(api_call(5)),
    )
    
    print(f"Results: {results}")
    
    scheduler.stop()
    scheduler_task.cancel()

asyncio.run(main())
```

### Pattern 4: Connection Pool

```python
import asyncio
from contextlib import asynccontextmanager

class AsyncConnectionPool:
    def __init__(self, max_connections: int):
        self.max_connections = max_connections
        self.semaphore = asyncio.Semaphore(max_connections)
        self.connections = []
    
    async def _create_connection(self):
        """Simulate creating a connection"""
        await asyncio.sleep(0.1)
        return {"id": len(self.connections), "connected": True}
    
    @asynccontextmanager
    async def acquire(self):
        """Acquire a connection from the pool"""
        async with self.semaphore:
            if not self.connections:
                conn = await self._create_connection()
                self.connections.append(conn)
            else:
                conn = self.connections.pop()
            
            try:
                yield conn
            finally:
                self.connections.append(conn)

async def use_connection(pool, task_id):
    async with pool.acquire() as conn:
        print(f"Task {task_id} using connection {conn['id']}")
        await asyncio.sleep(0.5)  # Simulate work
        print(f"Task {task_id} done")

async def main():
    pool = AsyncConnectionPool(max_connections=3)
    
    # 10 tasks competing for 3 connections
    await asyncio.gather(
        *[use_connection(pool, i) for i in range(10)]
    )

asyncio.run(main())
```

---

## Quick Reference

```python
import asyncio

# Run async code
asyncio.run(main())

# Get current loop
loop = asyncio.get_running_loop()  # Inside async
loop = asyncio.get_event_loop()    # Outside async (deprecated)

# Schedule callbacks
loop.call_soon(callback, arg)
loop.call_later(delay, callback, arg)
loop.call_at(when, callback, arg)

# Run blocking code
await loop.run_in_executor(None, blocking_func, arg)
await asyncio.to_thread(blocking_func, arg)  # Python 3.9+

# Task management
task = asyncio.create_task(coro())
all_tasks = asyncio.all_tasks()
current = asyncio.current_task()

# Loop time
now = loop.time()

# Debug
asyncio.run(main(), debug=True)
```

---

*Next: [Deep Dive](_03_deep_dive.md)*
