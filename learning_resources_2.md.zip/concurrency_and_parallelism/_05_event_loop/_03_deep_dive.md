# Event Loop in Python - Deep Dive

## Table of Contents
1. [Event Loop Architecture](#1-event-loop-architecture)
2. [Selectors and I/O Multiplexing](#2-selectors-and-io-multiplexing)
3. [Task Scheduling Internals](#3-task-scheduling-internals)
4. [Event Loop Policies](#4-event-loop-policies)
5. [Custom Event Loops](#5-custom-event-loops)
6. [Performance Optimization](#6-performance-optimization)
7. [Debugging and Profiling](#7-debugging-and-profiling)

---

## 1. Event Loop Architecture

### Internal Components

```
┌─────────────────────────────────────────────────────────────────────┐
│                    EVENT LOOP ARCHITECTURE                           │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                     BaseSelectorEventLoop                    │   │
│  │                                                             │   │
│  │  ┌─────────────────────────────────────────────────────┐   │   │
│  │  │                    _selector                         │   │   │
│  │  │    (selectors.DefaultSelector / epoll / kqueue)     │   │   │
│  │  │    Monitors file descriptors for I/O readiness      │   │   │
│  │  └─────────────────────────────────────────────────────┘   │   │
│  │                                                             │   │
│  │  ┌─────────────────────────────────────────────────────┐   │   │
│  │  │                    _ready                            │   │   │
│  │  │    collections.deque() of callbacks                  │   │   │
│  │  │    Ready to execute immediately                      │   │   │
│  │  └─────────────────────────────────────────────────────┘   │   │
│  │                                                             │   │
│  │  ┌─────────────────────────────────────────────────────┐   │   │
│  │  │                    _scheduled                        │   │   │
│  │  │    heapq of TimerHandle objects                     │   │   │
│  │  │    Sorted by execution time                         │   │   │
│  │  └─────────────────────────────────────────────────────┘   │   │
│  │                                                             │   │
│  │  ┌─────────────────────────────────────────────────────┐   │   │
│  │  │                    _running                          │   │   │
│  │  │    bool - is loop currently running?                │   │   │
│  │  └─────────────────────────────────────────────────────┘   │   │
│  │                                                             │   │
│  │  ┌─────────────────────────────────────────────────────┐   │   │
│  │  │              _default_executor                       │   │   │
│  │  │    ThreadPoolExecutor for run_in_executor           │   │   │
│  │  └─────────────────────────────────────────────────────┘   │   │
│  │                                                             │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### The Main Loop (Simplified)

```python
# Simplified version of what the event loop does
def _run_once(self):
    """One iteration of the event loop"""
    
    # 1. Process scheduled callbacks that are due
    while self._scheduled:
        handle = self._scheduled[0]
        if handle._when > self.time():
            break
        handle = heapq.heappop(self._scheduled)
        self._ready.append(handle)
    
    # 2. Calculate how long we can wait for I/O
    if self._ready:
        timeout = 0  # Don't wait, we have work
    elif self._scheduled:
        timeout = self._scheduled[0]._when - self.time()
    else:
        timeout = None  # Wait indefinitely
    
    # 3. Wait for I/O events
    events = self._selector.select(timeout)
    
    # 4. Process I/O events
    for key, mask in events:
        callback = key.data
        self._ready.append(callback)
    
    # 5. Execute ready callbacks
    ntodo = len(self._ready)
    for _ in range(ntodo):
        handle = self._ready.popleft()
        if not handle._cancelled:
            handle._run()
```

---

## 2. Selectors and I/O Multiplexing

### How I/O Monitoring Works

```
┌─────────────────────────────────────────────────────────────────────┐
│                    I/O MULTIPLEXING MECHANISM                        │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Traditional I/O (blocking):                                        │
│  Thread 1: [read socket A] ░░░░░░░░░░░░░░░ [data arrives]          │
│  Thread 2:                  [read socket B] ░░░░░░ [data]           │
│  Thread 3:                                  [read socket C] ░░░    │
│                                                                     │
│  Each socket needs its own thread waiting!                          │
│                                                                     │
│  ────────────────────────────────────────────────────────────────  │
│                                                                     │
│  I/O Multiplexing (selector):                                       │
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                    SELECTOR (epoll/kqueue/select)           │   │
│  │                                                             │   │
│  │   "Watch these sockets and tell me when ANY is ready"       │   │
│  │                                                             │   │
│  │   Socket A ──┐                                              │   │
│  │   Socket B ──┼──▶ [SELECTOR] ──▶ "Socket B has data!"       │   │
│  │   Socket C ──┘                                              │   │
│  │                                                             │   │
│  │   ONE thread monitors THOUSANDS of connections!             │   │
│  │                                                             │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Selector Types by Platform

```python
import selectors
import sys

# Python chooses the best selector for your platform
selector = selectors.DefaultSelector()
print(f"Default selector: {type(selector).__name__}")

# Platform-specific selectors:
# Linux:   EpollSelector (best for many connections)
# macOS:   KqueueSelector
# Windows: SelectSelector (limited to 512 sockets)

# Check what's available
print(f"Available selectors:")
for name in ['SelectSelector', 'PollSelector', 'EpollSelector', 'KqueueSelector']:
    if hasattr(selectors, name):
        print(f"  {name}: available")
```

### Low-Level Selector Usage

```python
import selectors
import socket

sel = selectors.DefaultSelector()

def accept(sock):
    conn, addr = sock.accept()
    print(f"Accepted from {addr}")
    conn.setblocking(False)
    sel.register(conn, selectors.EVENT_READ, read)

def read(conn):
    data = conn.recv(1024)
    if data:
        print(f"Received: {data}")
    else:
        sel.unregister(conn)
        conn.close()

# Server socket
sock = socket.socket()
sock.bind(('localhost', 8080))
sock.listen()
sock.setblocking(False)
sel.register(sock, selectors.EVENT_READ, accept)

# Event loop
while True:
    events = sel.select()  # Block until I/O ready
    for key, mask in events:
        callback = key.data
        callback(key.fileobj)
```

---

## 3. Task Scheduling Internals

### How Tasks Are Scheduled

```
┌─────────────────────────────────────────────────────────────────────┐
│                    TASK SCHEDULING FLOW                              │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  asyncio.create_task(coro)                                         │
│            │                                                        │
│            ▼                                                        │
│  ┌────────────────────────────────────────┐                        │
│  │  Task created with coroutine           │                        │
│  │  task._coro = coro                     │                        │
│  │  task._loop = current_loop             │                        │
│  └────────────────────┬───────────────────┘                        │
│                       │                                             │
│                       ▼                                             │
│  ┌────────────────────────────────────────┐                        │
│  │  loop.call_soon(task.__step)           │                        │
│  │  Schedules task to run on next cycle   │                        │
│  └────────────────────┬───────────────────┘                        │
│                       │                                             │
│                       ▼                                             │
│  ┌────────────────────────────────────────┐                        │
│  │  Task.__step() executes:               │                        │
│  │  1. result = coro.send(None)           │                        │
│  │  2. If result is Future/Task:          │                        │
│  │     - Add callback to that future      │                        │
│  │  3. If StopIteration:                  │                        │
│  │     - Task is done                     │                        │
│  └────────────────────────────────────────┘                        │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Handle and TimerHandle

```python
import asyncio
import inspect

async def main():
    loop = asyncio.get_running_loop()
    
    # call_soon returns a Handle
    def callback():
        pass
    
    handle = loop.call_soon(callback)
    print(f"Handle type: {type(handle)}")
    print(f"Handle cancelled: {handle.cancelled()}")
    
    # call_later returns a TimerHandle
    timer_handle = loop.call_later(1.0, callback)
    print(f"TimerHandle type: {type(timer_handle)}")
    print(f"TimerHandle when: {timer_handle.when()}")
    
    # Cancel before execution
    handle.cancel()
    timer_handle.cancel()
    
    await asyncio.sleep(0)

asyncio.run(main())
```

---

## 4. Event Loop Policies

### What Are Policies?

```python
import asyncio

# Policy controls:
# - Which event loop implementation to use
# - How loops are created and managed
# - Per-thread loop behavior

# Get current policy
policy = asyncio.get_event_loop_policy()
print(f"Current policy: {type(policy).__name__}")

# Create loop using policy
loop = policy.new_event_loop()
print(f"Loop type: {type(loop).__name__}")
```

### Platform-Specific Policies

```python
import asyncio
import sys

# Windows has two policies
if sys.platform == 'win32':
    # Default: SelectorEventLoop
    # Alternative: ProactorEventLoop (better for subprocesses)
    asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

# UV Loop (third-party, faster)
try:
    import uvloop
    asyncio.set_event_loop_policy(uvloop.EventLoopPolicy())
    print("Using uvloop!")
except ImportError:
    print("uvloop not available")
```

### Custom Policy

```python
import asyncio

class MyEventLoopPolicy(asyncio.DefaultEventLoopPolicy):
    """Custom event loop policy with logging"""
    
    def new_event_loop(self):
        loop = super().new_event_loop()
        print(f"Created new event loop: {loop}")
        return loop
    
    def get_event_loop(self):
        loop = super().get_event_loop()
        print(f"Getting event loop: {loop}")
        return loop

# Set custom policy
asyncio.set_event_loop_policy(MyEventLoopPolicy())

# Now all loop operations use our policy
async def main():
    loop = asyncio.get_running_loop()
    print(f"Running in loop: {loop}")

asyncio.run(main())
```

---

## 5. Custom Event Loops

### Simplified Custom Event Loop

```python
import heapq
import time
from collections import deque

class SimpleEventLoop:
    """Minimal event loop implementation"""
    
    def __init__(self):
        self._ready = deque()      # Callbacks ready to run
        self._scheduled = []       # Heap of (time, callback)
        self._stopping = False
        self._time = time.monotonic
    
    def call_soon(self, callback, *args):
        """Schedule callback for next iteration"""
        self._ready.append((callback, args))
    
    def call_later(self, delay, callback, *args):
        """Schedule callback after delay"""
        when = self._time() + delay
        heapq.heappush(self._scheduled, (when, callback, args))
    
    def run_forever(self):
        """Run until stop() is called"""
        while not self._stopping:
            self._run_once()
    
    def _run_once(self):
        """One iteration of the event loop"""
        # Move scheduled callbacks that are due to ready
        now = self._time()
        while self._scheduled and self._scheduled[0][0] <= now:
            _, callback, args = heapq.heappop(self._scheduled)
            self._ready.append((callback, args))
        
        # Execute ready callbacks
        while self._ready:
            callback, args = self._ready.popleft()
            callback(*args)
        
        # Sleep if nothing to do
        if self._scheduled and not self._ready:
            delay = self._scheduled[0][0] - self._time()
            if delay > 0:
                time.sleep(min(delay, 0.1))
    
    def stop(self):
        self._stopping = True

# Usage
loop = SimpleEventLoop()

def greet(name):
    print(f"Hello, {name}!")

def stop_loop():
    print("Stopping...")
    loop.stop()

loop.call_soon(greet, "World")
loop.call_later(1.0, greet, "Delayed")
loop.call_later(2.0, stop_loop)

loop.run_forever()
```

---

## 6. Performance Optimization

### Measuring Event Loop Lag

```python
import asyncio
import time

async def monitor_lag():
    """Monitor event loop responsiveness"""
    while True:
        start = time.perf_counter()
        await asyncio.sleep(0.1)  # Should take ~0.1s
        actual = time.perf_counter() - start
        lag = (actual - 0.1) * 1000
        if lag > 10:  # More than 10ms lag
            print(f"Event loop lag: {lag:.1f}ms")

async def blocking_task():
    """This blocks the event loop!"""
    time.sleep(0.5)  # BAD! Use await asyncio.sleep()

async def main():
    monitor = asyncio.create_task(monitor_lag())
    
    # This will cause lag
    await asyncio.sleep(1)
    blocking_task()  # Causes 500ms lag!
    
    await asyncio.sleep(2)
    monitor.cancel()

asyncio.run(main())
```

### Optimizing Task Creation

```python
import asyncio
import time

async def minimal_task():
    return 1

async def benchmark():
    # Creating many tasks has overhead
    start = time.perf_counter()
    tasks = [asyncio.create_task(minimal_task()) for _ in range(10000)]
    await asyncio.gather(*tasks)
    task_time = time.perf_counter() - start
    
    # Direct await is faster for sequential work
    start = time.perf_counter()
    for _ in range(10000):
        await minimal_task()
    direct_time = time.perf_counter() - start
    
    print(f"Tasks: {task_time:.3f}s")
    print(f"Direct: {direct_time:.3f}s")

asyncio.run(benchmark())
```

### Using uvloop for Speed

```python
# uvloop is 2-4x faster than default asyncio
# pip install uvloop

try:
    import uvloop
    asyncio.set_event_loop_policy(uvloop.EventLoopPolicy())
    print("Using uvloop")
except ImportError:
    print("uvloop not available, using default loop")

async def main():
    # Your async code here
    pass

asyncio.run(main())
```

---

## 7. Debugging and Profiling

### Debug Mode

```python
import asyncio
import warnings

# Enable debug mode
asyncio.run(main(), debug=True)

# Or set environment variable
# PYTHONASYNCIODEBUG=1 python script.py

# Debug mode provides:
# - Warnings for coroutines that were never awaited
# - Warnings for callbacks taking too long (>100ms)
# - Better exception tracebacks
```

### Slow Callback Detection

```python
import asyncio

async def main():
    loop = asyncio.get_running_loop()
    
    # Set slow callback threshold (default 0.1s)
    loop.slow_callback_duration = 0.05  # 50ms
    
    def slow_callback():
        import time
        time.sleep(0.1)  # This will trigger warning
    
    loop.call_soon(slow_callback)
    await asyncio.sleep(0.5)

asyncio.run(main(), debug=True)
# Warning: Executing <Handle slow_callback()> took 0.100 seconds
```

### Profiling Async Code

```python
import asyncio
import cProfile
import pstats
import io

async def work():
    await asyncio.sleep(0.1)
    return sum(range(10000))

async def main():
    tasks = [asyncio.create_task(work()) for _ in range(10)]
    await asyncio.gather(*tasks)

# Profile the async code
profiler = cProfile.Profile()
profiler.enable()

asyncio.run(main())

profiler.disable()

# Print stats
stream = io.StringIO()
stats = pstats.Stats(profiler, stream=stream)
stats.sort_stats('cumulative')
stats.print_stats(20)
print(stream.getvalue())
```

### Task Tracking

```python
import asyncio
import traceback

class TaskTracker:
    """Track all tasks and their creation points"""
    
    def __init__(self):
        self.tasks = {}
    
    def create_task(self, coro, name=None):
        task = asyncio.create_task(coro, name=name)
        self.tasks[id(task)] = {
            'task': task,
            'created_at': asyncio.get_event_loop().time(),
            'traceback': ''.join(traceback.format_stack())
        }
        task.add_done_callback(self._task_done)
        return task
    
    def _task_done(self, task):
        task_id = id(task)
        if task_id in self.tasks:
            del self.tasks[task_id]
    
    def get_pending(self):
        return [info for info in self.tasks.values() 
                if not info['task'].done()]

tracker = TaskTracker()

async def example():
    await asyncio.sleep(10)

async def main():
    tracker.create_task(example(), name="long-task")
    
    await asyncio.sleep(1)
    
    pending = tracker.get_pending()
    print(f"Pending tasks: {len(pending)}")
    for info in pending:
        print(f"  {info['task'].get_name()}")
        print(f"  Created at: {info['created_at']}")

asyncio.run(main())
```

---

## Summary: Event Loop Internals

```
┌─────────────────────────────────────────────────────────────────────┐
│                EVENT LOOP INTERNALS SUMMARY                          │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  MAIN COMPONENTS:                                                   │
│  • _ready: deque of callbacks to run now                            │
│  • _scheduled: heap of (time, callback) for later                   │
│  • _selector: monitors I/O file descriptors                         │
│                                                                     │
│  LOOP ITERATION:                                                    │
│  1. Process due scheduled callbacks                                 │
│  2. Calculate I/O wait timeout                                      │
│  3. Wait for I/O events (select/poll/epoll)                        │
│  4. Process I/O callbacks                                           │
│  5. Execute all ready callbacks                                     │
│                                                                     │
│  SELECTORS:                                                         │
│  • select: Universal, limited (512 on Windows)                      │
│  • poll: Unix, better than select                                   │
│  • epoll: Linux, best for many connections                          │
│  • kqueue: macOS/BSD, similar to epoll                              │
│                                                                     │
│  POLICIES:                                                          │
│  • Control loop implementation per platform                         │
│  • Can be customized for special needs                              │
│  • uvloop: Drop-in replacement, 2-4x faster                         │
│                                                                     │
│  OPTIMIZATION:                                                      │
│  • Avoid blocking calls (use run_in_executor)                       │
│  • Minimize task creation for simple operations                     │
│  • Use uvloop for production                                        │
│  • Enable debug mode during development                             │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

*Next: [Interview Questions](_04_interview_questions.md)*
