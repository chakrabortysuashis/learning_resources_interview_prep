# Event Loop in Python - Interview Questions

## Table of Contents
1. [Basic Questions](#basic-questions)
2. [Intermediate Questions](#intermediate-questions)
3. [Advanced Questions](#advanced-questions)
4. [Scenario-Based Questions](#scenario-based-questions)
5. [Code Analysis Questions](#code-analysis-questions)

---

## Basic Questions

### Q1: What is an event loop in asyncio?

<details>
<summary>Answer</summary>

The event loop is the **core of asyncio** that:
- Manages and schedules coroutines/tasks
- Monitors I/O operations (network, files)
- Executes callbacks when events occur
- Decides which task runs next

```
while running:
    1. Check what's ready to run
    2. Run ready tasks until they await
    3. Wait for I/O or timers
    4. Repeat
```

**Key characteristics:**
- Single-threaded (one task at a time)
- Cooperative multitasking (tasks yield with await)
- Non-blocking I/O via selectors

```python
import asyncio

async def main():
    loop = asyncio.get_running_loop()
    print(f"Running in: {loop}")

asyncio.run(main())  # Creates and runs event loop
```

</details>

---

### Q2: How do you get the current event loop?

<details>
<summary>Answer</summary>

**Inside async function (recommended):**
```python
async def main():
    loop = asyncio.get_running_loop()  # Python 3.7+
```

**Outside async function:**
```python
loop = asyncio.get_event_loop()  # Deprecated in 3.10+
```

**Differences:**
- `get_running_loop()`: Only works inside running async context, raises if no loop running
- `get_event_loop()`: Creates loop if none exists (deprecated behavior)

**Best practice:**
```python
# Use asyncio.run() and get_running_loop() inside
async def main():
    loop = asyncio.get_running_loop()
    
asyncio.run(main())
```

</details>

---

### Q3: What's the difference between `asyncio.run()` and `loop.run_until_complete()`?

<details>
<summary>Answer</summary>

| Feature | asyncio.run() | loop.run_until_complete() |
|---------|--------------|--------------------------|
| **Creates loop** | Yes, always new | No, uses existing |
| **Closes loop** | Yes, after completion | No |
| **Cleanup** | Cancels pending tasks | No cleanup |
| **Recommended** | Yes (Python 3.7+) | For advanced use only |

```python
# asyncio.run() - simple and safe
asyncio.run(main())  # Creates, runs, closes

# Manual management - more control
loop = asyncio.new_event_loop()
try:
    loop.run_until_complete(main())
finally:
    loop.close()
```

**Use `asyncio.run()` unless you need:**
- Custom event loop
- Running loop in background
- Integration with frameworks

</details>

---

### Q4: How does the event loop handle I/O?

<details>
<summary>Answer</summary>

The event loop uses **I/O selectors** (system-level monitoring):

```
┌──────────────────────────────────────────────────────────┐
│                      EVENT LOOP                           │
│                                                          │
│   1. Registers file descriptors with selector            │
│      "Tell me when socket A can read"                    │
│                                                          │
│   2. Calls selector.select(timeout)                      │
│      Blocks until I/O ready OR timeout                   │
│                                                          │
│   3. Selector returns which descriptors are ready        │
│      "Socket A can read, Socket B can write"             │
│                                                          │
│   4. Event loop schedules callbacks for ready I/O        │
│                                                          │
└──────────────────────────────────────────────────────────┘
```

**Selector types:**
- `select`: Portable but slow (O(n))
- `poll`: Better than select
- `epoll` (Linux): O(1), handles millions of connections
- `kqueue` (macOS): Similar to epoll

```python
import selectors
# Python auto-selects best for platform
selector = selectors.DefaultSelector()
```

</details>

---

## Intermediate Questions

### Q5: How do you schedule a callback to run later?

<details>
<summary>Answer</summary>

```python
import asyncio

async def main():
    loop = asyncio.get_running_loop()
    
    # call_soon: Next iteration
    loop.call_soon(print, "Soon!")
    
    # call_later: After delay (seconds)
    loop.call_later(1.0, print, "After 1 second")
    
    # call_at: At specific loop time
    loop.call_at(loop.time() + 2.0, print, "At specific time")
    
    # Returns Handle for cancellation
    handle = loop.call_later(5.0, print, "Cancelled")
    handle.cancel()  # Won't run
    
    await asyncio.sleep(3)

asyncio.run(main())
```

**Key points:**
- Callbacks are regular functions (not coroutines)
- Returns `Handle` object for cancellation
- `call_later`/`call_at` use loop's monotonic clock

</details>

---

### Q6: How do you run blocking code without blocking the event loop?

<details>
<summary>Answer</summary>

**Method 1: run_in_executor() with thread pool**
```python
import asyncio
import time

def blocking_io():
    time.sleep(2)
    return "result"

async def main():
    loop = asyncio.get_running_loop()
    
    # Run in default thread pool
    result = await loop.run_in_executor(None, blocking_io)
    print(result)
```

**Method 2: asyncio.to_thread() (Python 3.9+)**
```python
result = await asyncio.to_thread(blocking_io)
```

**Method 3: ProcessPoolExecutor for CPU-bound**
```python
from concurrent.futures import ProcessPoolExecutor

def cpu_intensive(n):
    return sum(i*i for i in range(n))

async def main():
    loop = asyncio.get_running_loop()
    with ProcessPoolExecutor() as pool:
        result = await loop.run_in_executor(pool, cpu_intensive, 10**7)
```

**When to use:**
- Thread pool: I/O-bound blocking (file, network libraries)
- Process pool: CPU-bound blocking (calculations)

</details>

---

### Q7: What happens if you run a blocking operation directly in a coroutine?

<details>
<summary>Answer</summary>

**It blocks the entire event loop!**

```python
import asyncio
import time

async def bad_example():
    time.sleep(2)  # BAD! Blocks everything
    return "done"

async def good_example():
    await asyncio.sleep(2)  # Good! Yields control
    return "done"

async def main():
    # These run sequentially because bad_example blocks
    await asyncio.gather(
        bad_example(),  # Takes 2s, blocks loop
        bad_example(),  # Takes another 2s
    )
    # Total: 4 seconds!
    
    # These run concurrently
    await asyncio.gather(
        good_example(),  # Yields during sleep
        good_example(),  # Can run during other's sleep
    )
    # Total: 2 seconds!
```

**Debug mode helps catch this:**
```python
asyncio.run(main(), debug=True)
# Warning: Executing <Task> took 2.00 seconds
```

</details>

---

### Q8: What is an event loop policy?

<details>
<summary>Answer</summary>

**Policy** controls how event loops are created and managed.

```python
import asyncio

# Get current policy
policy = asyncio.get_event_loop_policy()
print(type(policy))  # DefaultEventLoopPolicy

# Policy responsibilities:
# - Create new loops: policy.new_event_loop()
# - Get/set current loop: policy.get_event_loop()
# - Child watcher (Unix subprocesses)
```

**Platform-specific policies:**
```python
import sys

if sys.platform == 'win32':
    # Windows options
    asyncio.set_event_loop_policy(
        asyncio.WindowsSelectorEventLoopPolicy()  # Default
        # or
        # asyncio.WindowsProactorEventLoopPolicy()  # Better for subprocesses
    )
```

**High-performance alternative:**
```python
try:
    import uvloop
    asyncio.set_event_loop_policy(uvloop.EventLoopPolicy())
    # 2-4x faster!
except ImportError:
    pass
```

</details>

---

## Advanced Questions

### Q9: Explain the internal structure of the event loop.

<details>
<summary>Answer</summary>

**Main components:**

```python
class EventLoop:
    _ready = deque()       # Callbacks ready to execute
    _scheduled = []        # Heap of (time, callback) - timers
    _selector = ...        # I/O multiplexer (epoll/kqueue/select)
    _running = False       # Is loop currently running?
    _stopping = False      # Stop requested?
```

**Main loop iteration:**
```python
def _run_once(self):
    # 1. Process due timers
    while self._scheduled and self._scheduled[0].time <= now:
        handle = heappop(self._scheduled)
        self._ready.append(handle)
    
    # 2. Calculate I/O wait timeout
    timeout = min_scheduled_time - now if self._scheduled else None
    
    # 3. Wait for I/O events
    events = self._selector.select(timeout)
    for key, mask in events:
        self._ready.append(key.data)  # I/O callback
    
    # 4. Execute ready callbacks
    while self._ready:
        handle = self._ready.popleft()
        handle._run()
```

**Task scheduling:**
- `create_task(coro)` → Wraps in Task → `call_soon(task.__step)`
- Task.__step: Calls `coro.send()`, handles result
- If result is Future: adds callback to resume when ready
- If StopIteration: task is done

</details>

---

### Q10: How would you implement a simple event loop?

<details>
<summary>Answer</summary>

```python
import heapq
import time
from collections import deque

class SimpleLoop:
    def __init__(self):
        self._ready = deque()
        self._scheduled = []  # (time, callback, args)
        self._stopping = False
    
    def call_soon(self, callback, *args):
        self._ready.append((callback, args))
    
    def call_later(self, delay, callback, *args):
        when = time.monotonic() + delay
        heapq.heappush(self._scheduled, (when, callback, args))
    
    def run_forever(self):
        while not self._stopping:
            # Move due scheduled to ready
            now = time.monotonic()
            while self._scheduled and self._scheduled[0][0] <= now:
                _, cb, args = heapq.heappop(self._scheduled)
                self._ready.append((cb, args))
            
            # Run ready callbacks
            while self._ready:
                cb, args = self._ready.popleft()
                cb(*args)
            
            # Sleep until next scheduled
            if self._scheduled:
                delay = self._scheduled[0][0] - time.monotonic()
                if delay > 0:
                    time.sleep(delay)
    
    def stop(self):
        self._stopping = True

# Usage
loop = SimpleLoop()
loop.call_soon(print, "Immediate")
loop.call_later(1.0, print, "After 1s")
loop.call_later(2.0, loop.stop)
loop.run_forever()
```

**Missing from real implementation:** I/O monitoring, coroutine support, error handling, task management.

</details>

---

### Q11: What are the different selector types and when are they used?

<details>
<summary>Answer</summary>

| Selector | Platform | Scalability | Notes |
|----------|----------|-------------|-------|
| `SelectSelector` | All | Poor (O(n)) | Limited to 512-1024 FDs on Windows |
| `PollSelector` | Unix | Better (O(n)) | No FD limit |
| `EpollSelector` | Linux | Excellent (O(1)) | Best for many connections |
| `KqueueSelector` | macOS/BSD | Excellent (O(1)) | Similar to epoll |

```python
import selectors

# Python picks best for platform
selector = selectors.DefaultSelector()

# Manual selection (advanced)
if hasattr(selectors, 'EpollSelector'):
    selector = selectors.EpollSelector()
elif hasattr(selectors, 'KqueueSelector'):
    selector = selectors.KqueueSelector()
else:
    selector = selectors.SelectSelector()
```

**For millions of concurrent connections:** Use Linux with epoll.

</details>

---

## Scenario-Based Questions

### Q12: How would you implement graceful shutdown?

<details>
<summary>Answer</summary>

```python
import asyncio
import signal

async def worker(name, shutdown_event):
    try:
        while not shutdown_event.is_set():
            print(f"{name} working...")
            await asyncio.sleep(1)
    except asyncio.CancelledError:
        print(f"{name} cancelled, cleaning up...")
        await asyncio.sleep(0.1)  # Cleanup
        raise

async def main():
    shutdown_event = asyncio.Event()
    
    # Start workers
    workers = [
        asyncio.create_task(worker(f"Worker-{i}", shutdown_event))
        for i in range(3)
    ]
    
    # Setup signal handlers
    loop = asyncio.get_running_loop()
    
    def signal_handler():
        print("Shutdown signal received")
        shutdown_event.set()
    
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, signal_handler)
    
    # Wait for shutdown signal
    await shutdown_event.wait()
    
    # Give workers time to finish gracefully
    await asyncio.sleep(0.5)
    
    # Cancel remaining tasks
    for task in workers:
        task.cancel()
    
    # Wait for cancellation
    await asyncio.gather(*workers, return_exceptions=True)
    print("Shutdown complete")

# asyncio.run(main())  # Unix only for signal handlers
```

</details>

---

### Q13: How do you debug event loop performance issues?

<details>
<summary>Answer</summary>

```python
import asyncio
import time

# 1. Enable debug mode
asyncio.run(main(), debug=True)

# 2. Monitor loop lag
async def monitor_lag():
    while True:
        start = time.perf_counter()
        await asyncio.sleep(0.1)
        lag = (time.perf_counter() - start - 0.1) * 1000
        if lag > 10:
            print(f"Loop lag: {lag:.1f}ms")

# 3. Set slow callback threshold
loop = asyncio.get_running_loop()
loop.slow_callback_duration = 0.05  # 50ms

# 4. Track task count
print(f"Active tasks: {len(asyncio.all_tasks())}")

# 5. Profile with cProfile
import cProfile
cProfile.run('asyncio.run(main())')

# 6. Check for blocking calls
# Look for time.sleep(), synchronous I/O, heavy computation
```

**Common issues:**
- Blocking calls in coroutines
- Too many tasks
- Synchronous database/HTTP clients
- CPU-intensive operations

</details>

---

### Q14: How do you handle multiple event loops in different threads?

<details>
<summary>Answer</summary>

```python
import asyncio
import threading

def run_loop_in_thread():
    """Run event loop in a separate thread"""
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    
    async def background_work():
        while True:
            print("Background working...")
            await asyncio.sleep(1)
    
    loop.run_until_complete(background_work())

# Start loop in thread
thread = threading.Thread(target=run_loop_in_thread, daemon=True)
thread.start()

# Schedule work from main thread
def schedule_in_loop(loop, coro):
    """Thread-safe way to schedule coroutine"""
    future = asyncio.run_coroutine_threadsafe(coro, loop)
    return future.result()  # Block until done

# Main thread continues...
```

**Important:**
- Each thread can have ONE event loop
- Use `run_coroutine_threadsafe()` for cross-thread scheduling
- Call `loop.call_soon_threadsafe()` for callbacks

</details>

---

## Code Analysis Questions

### Q15: What's wrong with this code?

```python
import asyncio

async def fetch(url):
    await asyncio.sleep(1)
    return f"Data from {url}"

def main():
    loop = asyncio.get_event_loop()
    result = fetch("http://example.com")
    print(result)

main()
```

<details>
<summary>Answer</summary>

**Problems:**

1. `fetch()` returns coroutine object, not result
2. Coroutine is never awaited or run
3. Will get "coroutine was never awaited" warning

**Fixed:**
```python
import asyncio

async def fetch(url):
    await asyncio.sleep(1)
    return f"Data from {url}"

# Option 1: asyncio.run (recommended)
async def main():
    result = await fetch("http://example.com")
    print(result)

asyncio.run(main())

# Option 2: run_until_complete
def main():
    loop = asyncio.get_event_loop()
    result = loop.run_until_complete(fetch("http://example.com"))
    print(result)
    loop.close()

main()
```

</details>

---

### Q16: Will this cause problems? Why?

```python
import asyncio
import time

async def handler():
    # Simulate processing
    data = heavy_computation()  # CPU-intensive, takes 2 seconds
    return process(data)

async def main():
    # Handle 100 requests
    tasks = [asyncio.create_task(handler()) for _ in range(100)]
    await asyncio.gather(*tasks)
```

<details>
<summary>Answer</summary>

**Yes, this causes problems!**

**Issue:** `heavy_computation()` blocks the event loop for 2 seconds. Since asyncio is single-threaded, during those 2 seconds:
- No other tasks can run
- No I/O can be processed
- All 100 handlers run sequentially (200+ seconds total!)

**Solutions:**

1. **Run in thread pool:**
```python
async def handler():
    loop = asyncio.get_running_loop()
    data = await loop.run_in_executor(None, heavy_computation)
    return process(data)
```

2. **Run in process pool (CPU-bound):**
```python
from concurrent.futures import ProcessPoolExecutor

pool = ProcessPoolExecutor(4)

async def handler():
    loop = asyncio.get_running_loop()
    data = await loop.run_in_executor(pool, heavy_computation)
    return process(data)
```

3. **Use asyncio.to_thread() (Python 3.9+):**
```python
async def handler():
    data = await asyncio.to_thread(heavy_computation)
    return process(data)
```

</details>

---

## Quick Reference: Interview Cheat Sheet

```
┌─────────────────────────────────────────────────────────────────────┐
│                 EVENT LOOP INTERVIEW CHEAT SHEET                     │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  WHAT IT DOES:                                                      │
│  • Schedules and runs coroutines                                    │
│  • Monitors I/O via selectors                                       │
│  • Executes callbacks                                               │
│  • Single-threaded, cooperative multitasking                        │
│                                                                     │
│  KEY FUNCTIONS:                                                     │
│  • asyncio.run(main()) - Entry point                                │
│  • asyncio.get_running_loop() - Get current loop                    │
│  • loop.call_soon/later/at() - Schedule callbacks                   │
│  • loop.run_in_executor() - Run blocking code                       │
│                                                                     │
│  SELECTORS (I/O monitoring):                                        │
│  • select: Universal, slow                                          │
│  • epoll: Linux, fast (millions of connections)                     │
│  • kqueue: macOS, fast                                              │
│                                                                     │
│  BLOCKING CODE:                                                     │
│  • NEVER call time.sleep() in coroutine                             │
│  • Use loop.run_in_executor() for blocking I/O                      │
│  • Use ProcessPoolExecutor for CPU-bound                            │
│                                                                     │
│  DEBUG:                                                             │
│  • asyncio.run(main(), debug=True)                                  │
│  • loop.slow_callback_duration = 0.1                                │
│  • Monitor lag with periodic task                                   │
│                                                                     │
│  OPTIMIZATION:                                                      │
│  • Use uvloop for 2-4x speedup                                      │
│  • Avoid blocking calls                                             │
│  • Minimize task creation overhead                                  │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

*Back to: [Overview](_01_overview.md) | [Implementation](_02_implementation.md) | [Deep Dive](_03_deep_dive.md)*
