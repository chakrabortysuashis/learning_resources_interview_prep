# Event Loop in Python - Overview

## What is an Event Loop? (The Simple Explanation)

Imagine you're a **restaurant manager** who coordinates all the waiters:

```
┌─────────────────────────────────────────────────────────────────────┐
│                    THE RESTAURANT MANAGER ANALOGY                    │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│   👔 MANAGER (Event Loop)                                           │
│   "I don't serve food, I coordinate who does what and when!"        │
│                                                                     │
│   ┌─────────────────────────────────────────────────────────────┐  │
│   │                      Manager's Tasks                         │  │
│   ├─────────────────────────────────────────────────────────────┤  │
│   │                                                             │  │
│   │  1. Keep a TO-DO list of things waiting to happen           │  │
│   │     "Table 3 waiting for appetizer"                         │  │
│   │     "Table 7 needs their bill"                              │  │
│   │     "Kitchen bell rang - food ready!"                       │  │
│   │                                                             │  │
│   │  2. Check what's ready and assign work                      │  │
│   │     "Waiter A, Table 3's food is ready - serve it!"        │  │
│   │                                                             │  │
│   │  3. Keep everything moving smoothly                         │  │
│   │     Never sits idle while there's work to do                │  │
│   │                                                             │  │
│   └─────────────────────────────────────────────────────────────┘  │
│                                                                     │
│   WITHOUT a manager: Chaos! Waiters bump into each other!          │
│   WITH a manager: Smooth, efficient service!                        │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

**The Event Loop is Python's "manager" for async code** - it keeps track of all the coroutines and decides which one should run next!

---

## The Event Loop's Job

```
┌─────────────────────────────────────────────────────────────────────┐
│                    WHAT THE EVENT LOOP DOES                          │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  The Event Loop runs in an infinite cycle:                          │
│                                                                     │
│       ┌─────────────────────────────────────────────┐              │
│       │                                             │              │
│       │    1. CHECK: "Is anything ready to run?"    │              │
│       │         ↓                                   │              │
│       │    2. RUN: Execute ready tasks              │              │
│       │         ↓                                   │              │
│       │    3. WAIT: Check for I/O events            │              │
│       │         │                                   │              │
│       │         └──────────────────────────────────▶│              │
│       │                   (repeat forever)          │              │
│       └─────────────────────────────────────────────┘              │
│                                                                     │
│  Simplified:                                                        │
│  while True:                                                        │
│      ready_tasks = get_ready_tasks()                                │
│      for task in ready_tasks:                                       │
│          run(task)  # Run until it hits 'await'                    │
│      wait_for_io_events()                                           │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## How Tasks Flow Through the Event Loop

```
┌─────────────────────────────────────────────────────────────────────┐
│                    TASK LIFECYCLE IN EVENT LOOP                      │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Your code:                                                         │
│  async def fetch_data():                                            │
│      print("Starting")         # ← Runs immediately                │
│      await asyncio.sleep(1)    # ← PAUSES here                     │
│      print("Resuming")         # ← Runs after 1 second             │
│      return "data"                                                  │
│                                                                     │
│  What happens:                                                      │
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │ Event Loop                                                   │   │
│  │                                                             │   │
│  │ Time 0.0s: Run fetch_data()                                 │   │
│  │            → prints "Starting"                               │   │
│  │            → hits await sleep(1)                            │   │
│  │            → Task goes to "waiting" list                    │   │
│  │            → Loop runs other tasks                          │   │
│  │                                                             │   │
│  │ Time 0.2s: Run some_other_task()                            │   │
│  │            → ...                                            │   │
│  │                                                             │   │
│  │ Time 1.0s: Sleep timer finished!                            │   │
│  │            → fetch_data() moves to "ready" list             │   │
│  │            → Resume fetch_data()                            │   │
│  │            → prints "Resuming"                               │   │
│  │            → returns "data"                                 │   │
│  │            → Task complete!                                 │   │
│  │                                                             │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## The Event Loop's Internal Structure

```
┌─────────────────────────────────────────────────────────────────────┐
│                    EVENT LOOP COMPONENTS                             │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                       EVENT LOOP                             │   │
│  │                                                             │   │
│  │  ┌─────────────────┐  ┌─────────────────┐                  │   │
│  │  │  READY QUEUE    │  │  WAITING LIST   │                  │   │
│  │  │  (run these!)   │  │  (sleeping/IO)  │                  │   │
│  │  │                 │  │                 │                  │   │
│  │  │  • Task A       │  │  • Task D (IO)  │                  │   │
│  │  │  • Task B       │  │  • Task E (1s)  │                  │   │
│  │  │  • Task C       │  │  • Task F (IO)  │                  │   │
│  │  │                 │  │                 │                  │   │
│  │  └────────┬────────┘  └────────┬────────┘                  │   │
│  │           │                    │                           │   │
│  │           ▼                    ▼                           │   │
│  │  ┌─────────────────┐  ┌─────────────────┐                  │   │
│  │  │    EXECUTOR     │  │   I/O SELECTOR  │                  │   │
│  │  │  (runs tasks)   │  │ (monitors I/O)  │                  │   │
│  │  └─────────────────┘  └─────────────────┘                  │   │
│  │                                                             │   │
│  │  ┌─────────────────────────────────────────────────────┐   │   │
│  │  │                SCHEDULED CALLBACKS                   │   │   │
│  │  │  "Call func_x at time 10.5"                         │   │   │
│  │  │  "Call func_y at time 12.0"                         │   │   │
│  │  └─────────────────────────────────────────────────────┘   │   │
│  │                                                             │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Event Loop vs Threading vs Multiprocessing

```
┌─────────────────────────────────────────────────────────────────────┐
│                    CONCURRENCY APPROACHES                            │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  THREADING: Multiple workers, one at a time (GIL)                   │
│  ┌─────┐ ┌─────┐ ┌─────┐                                           │
│  │ T1  │ │ T2  │ │ T3  │  ← OS switches between them               │
│  └─────┘ └─────┘ └─────┘    (preemptive)                           │
│                                                                     │
│  MULTIPROCESSING: Multiple kitchens entirely                        │
│  ┌─────┐ ┌─────┐ ┌─────┐                                           │
│  │ P1  │ │ P2  │ │ P3  │  ← True parallelism                       │
│  └─────┘ └─────┘ └─────┘    (separate memory)                      │
│                                                                     │
│  EVENT LOOP: One worker, many tasks                                 │
│  ┌───────────────────────────────────────────────────────────┐     │
│  │                    SINGLE THREAD                           │     │
│  │                                                           │     │
│  │  Task A: [run]→[await]      [run]→[await]      [done]    │     │
│  │  Task B:       [run]→[await]      [run]→[done]           │     │
│  │  Task C:              [run]→[await]     [run]→[done]     │     │
│  │                                                           │     │
│  │  Tasks voluntarily yield at 'await' (cooperative)         │     │
│  │                                                           │     │
│  └───────────────────────────────────────────────────────────┘     │
│                                                                     │
│  KEY INSIGHT: Event loop is SINGLE-THREADED!                       │
│  • No race conditions (only one thing runs at a time)              │
│  • No locks needed                                                  │
│  • You control when tasks switch (at await)                        │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## The Event Loop Lifecycle

```
┌─────────────────────────────────────────────────────────────────────┐
│                    EVENT LOOP STATES                                 │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌──────────────┐                                                   │
│  │   CREATED    │  ← asyncio.new_event_loop()                      │
│  │   (exists)   │     Loop exists but not running                  │
│  └──────┬───────┘                                                   │
│         │                                                           │
│         │ loop.run_until_complete() / asyncio.run()                 │
│         ▼                                                           │
│  ┌──────────────┐                                                   │
│  │   RUNNING    │  ← Processing tasks and events                   │
│  │   (active)   │     Only ONE loop can run per thread             │
│  └──────┬───────┘                                                   │
│         │                                                           │
│         │ All tasks done / loop.stop()                              │
│         ▼                                                           │
│  ┌──────────────┐                                                   │
│  │   STOPPED    │  ← No longer processing                          │
│  │   (paused)   │     Can be restarted                             │
│  └──────┬───────┘                                                   │
│         │                                                           │
│         │ loop.close() / asyncio.run() completion                   │
│         ▼                                                           │
│  ┌──────────────┐                                                   │
│  │   CLOSED     │  ← Cannot be used anymore                        │
│  │   (done)     │     Resources released                           │
│  └──────────────┘                                                   │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Simple Mental Model: The Traffic Controller

```
┌─────────────────────────────────────────────────────────────────────┐
│                    TRAFFIC CONTROLLER ANALOGY                        │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  🚦 Traffic Controller (Event Loop)                                 │
│                                                                     │
│  Intersection with multiple roads (tasks):                          │
│                                                                     │
│       Road A (Task A)                                               │
│          │                                                          │
│          ▼                                                          │
│  ────────────────                                                   │
│          │         Road B (Task B)                                  │
│  Road C  │◀────────────────                                         │
│  ────────┼─────────                                                 │
│          │                                                          │
│          ▼                                                          │
│                                                                     │
│  Controller's job:                                                  │
│  • Let ONE road go at a time (single-threaded)                      │
│  • When a car stops at a red light (await), let another road go     │
│  • Keep traffic flowing smoothly                                    │
│  • Handle emergencies (high-priority callbacks)                     │
│                                                                     │
│  No two cars ever crash (no race conditions) because                │
│  only ONE road has a green light at any moment!                     │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Key Concepts Summary

| Concept | Explanation |
|---------|-------------|
| **Event Loop** | The orchestrator that runs async tasks |
| **Ready Queue** | Tasks that can run right now |
| **Waiting List** | Tasks waiting for I/O or timers |
| **I/O Selector** | Monitors network/file events |
| **Single Thread** | Only one task runs at a time |
| **Cooperative** | Tasks voluntarily yield at `await` |

---

## Key Takeaways

1. **Event loop is the coordinator** - It decides what runs when
2. **Single-threaded** - Only one coroutine runs at any moment
3. **Cooperative multitasking** - Coroutines yield at `await` points
4. **No race conditions** - Because only one thing runs at a time
5. **Great for I/O** - While one task waits for I/O, others can run
6. **Not for CPU work** - Long calculations block the entire loop

---

*Next: [Implementation & Code](_02_implementation.md)*
