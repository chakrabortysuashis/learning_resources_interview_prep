# Global Interpreter Lock (GIL)

## Table of Contents
1. [What is the GIL?](#what-is-the-gil)
2. [Why Does Python Have a GIL?](#why-does-python-have-a-gil)
3. [How the GIL Works](#how-the-gil-works)
4. [Impact on Multithreading](#impact-on-multithreading)
5. [When GIL Matters and When It Doesn't](#when-gil-matters-and-when-it-doesnt)
6. [Workarounds for the GIL](#workarounds-for-the-gil)
7. [GIL in Different Python Implementations](#gil-in-different-python-implementations)
8. [Code Examples](#code-examples)
9. [Interview Questions](#interview-questions)

---

## What is the GIL?

The **Global Interpreter Lock (GIL)** is a mutex (mutual exclusion lock) that protects access to Python objects, preventing multiple native threads from executing Python bytecodes simultaneously in the same process.

```
┌─────────────────────────────────────────────────────────────────┐
│                      Python Process                              │
│  ┌─────────────────────────────────────────────────────────────┐ │
│  │                         GIL                                  │ │
│  │                    (Single Lock)                             │ │
│  └─────────────────────────────────────────────────────────────┘ │
│         │                    │                    │              │
│         ▼                    ▼                    ▼              │
│  ┌───────────┐        ┌───────────┐        ┌───────────┐        │
│  │  Thread 1 │        │  Thread 2 │        │  Thread 3 │        │
│  │  (Active) │        │ (Waiting) │        │ (Waiting) │        │
│  └───────────┘        └───────────┘        └───────────┘        │
│         │                                                        │
│         ▼                                                        │
│  ┌─────────────────────────────────────────────────────────────┐ │
│  │              Python Interpreter (Bytecode)                   │ │
│  └─────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

### Key Characteristics:
- **Process-level lock**: Each Python process has its own GIL
- **Interpreter lock**: It locks the entire interpreter, not individual objects
- **Bytecode execution**: Only one thread can execute Python bytecode at a time

---

## Why Does Python Have a GIL?

### Historical Reasons

1. **Memory Management Simplicity**
   - Python uses reference counting for memory management
   - Without GIL, every reference count update would need its own lock
   - This would cause significant overhead and potential deadlocks

2. **C Extension Compatibility**
   - Many C extensions are not thread-safe
   - GIL provides implicit thread safety for C extensions
   - Made it easier to write Python C extensions

3. **Single-threaded Performance**
   - GIL actually improves single-threaded performance
   - No overhead of fine-grained locking

### Reference Counting Example

```python
import sys

# Every Python object has a reference count
a = []          # refcount = 1
b = a           # refcount = 2
c = a           # refcount = 3

print(sys.getrefcount(a))  # Output: 4 (including the argument to getrefcount)

# Without GIL, concurrent modifications to refcount could corrupt memory
```

```
┌─────────────────────────────────────────────────────────────────┐
│                   Reference Count Problem                        │
│                                                                  │
│   Without GIL (Race Condition):                                  │
│   ┌─────────────┐                    ┌─────────────┐            │
│   │  Thread 1   │                    │  Thread 2   │            │
│   └─────────────┘                    └─────────────┘            │
│         │                                  │                     │
│         │ Read refcount = 5                │                     │
│         │◄─────────────────────────────────│ Read refcount = 5   │
│         │                                  │                     │
│         │ Increment: 5 + 1 = 6             │ Increment: 5 + 1 = 6│
│         │                                  │                     │
│         │ Write refcount = 6               │                     │
│         │─────────────────────────────────►│ Write refcount = 6  │
│         │                                  │                     │
│   ┌─────────────────────────────────────────────────────────────┐│
│   │   Expected: 7    Actual: 6    ← DATA CORRUPTION!            ││
│   └─────────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────────┘
```

---

## How the GIL Works

### GIL Acquisition and Release

```
┌─────────────────────────────────────────────────────────────────┐
│                    GIL Switching Mechanism                       │
│                                                                  │
│   Timeline ──────────────────────────────────────────────────►   │
│                                                                  │
│   Thread 1: ████████░░░░░░░░████████░░░░░░░░████████            │
│                     │       │        │       │                   │
│   Thread 2: ░░░░░░░░████████░░░░░░░░████████░░░░░░░░            │
│                     │       │        │       │                   │
│              GIL    GIL     GIL      GIL     GIL                │
│              held   switch  held     switch  held               │
│                                                                  │
│   Legend: ████ = Executing    ░░░░ = Waiting for GIL            │
└─────────────────────────────────────────────────────────────────┘
```

### GIL Check Interval (Python 3.2+)

In Python 3.2+, the GIL uses a **time-based switching mechanism**:

```python
import sys

# Get the current switch interval (default: 5 milliseconds)
print(sys.getswitchinterval())  # Output: 0.005

# Set a new switch interval
sys.setswitchinterval(0.01)  # 10 milliseconds
```

### GIL Release Points

The GIL is released in these situations:

1. **I/O Operations**: File reads/writes, network operations
2. **Sleep**: `time.sleep()`
3. **C Extensions**: When calling certain C functions
4. **Explicit Release**: Using `Py_BEGIN_ALLOW_THREADS` in C

```python
import time
import threading

def io_bound_task():
    """GIL is released during I/O operations"""
    with open('file.txt', 'r') as f:
        data = f.read()  # GIL released here
    return data

def cpu_bound_task():
    """GIL is NOT released during pure Python computation"""
    total = 0
    for i in range(1000000):
        total += i  # GIL held here
    return total
```

---

## Impact on Multithreading

### CPU-Bound Tasks (GIL is a Bottleneck)

```python
import threading
import time

def cpu_intensive():
    """Simulate CPU-bound work"""
    count = 0
    for _ in range(50_000_000):
        count += 1
    return count

# Single-threaded execution
start = time.perf_counter()
cpu_intensive()
cpu_intensive()
single_time = time.perf_counter() - start
print(f"Single-threaded: {single_time:.2f}s")

# Multi-threaded execution (same or slower due to GIL!)
start = time.perf_counter()
t1 = threading.Thread(target=cpu_intensive)
t2 = threading.Thread(target=cpu_intensive)
t1.start()
t2.start()
t1.join()
t2.join()
multi_time = time.perf_counter() - start
print(f"Multi-threaded: {multi_time:.2f}s")

# Result: Multi-threaded is NOT faster (often slower due to GIL overhead)
```

```
┌─────────────────────────────────────────────────────────────────┐
│              CPU-Bound Task Performance                          │
│                                                                  │
│   Single Thread:                                                 │
│   ┌──────────────────────────────────────────────────────┐      │
│   │████████████████████████████████████████████████████████│      │
│   └──────────────────────────────────────────────────────┘      │
│   Time: ═══════════════════════════════════════════════►        │
│                                                                  │
│   Two Threads (with GIL):                                        │
│   Thread 1: ████░░░░████░░░░████░░░░████░░░░████░░░░████        │
│   Thread 2: ░░░░████░░░░████░░░░████░░░░████░░░░████░░░░        │
│   Time: ═══════════════════════════════════════════════►        │
│                                                                  │
│   ⚠️  Same total time + GIL switching overhead!                  │
└─────────────────────────────────────────────────────────────────┘
```

### I/O-Bound Tasks (GIL is NOT a Bottleneck)

```python
import threading
import time
import urllib.request

def download_page(url):
    """I/O-bound operation - GIL is released during network wait"""
    with urllib.request.urlopen(url) as response:
        return len(response.read())

urls = ['http://example.com'] * 5

# Single-threaded
start = time.perf_counter()
for url in urls:
    download_page(url)
single_time = time.perf_counter() - start
print(f"Single-threaded: {single_time:.2f}s")

# Multi-threaded (much faster!)
start = time.perf_counter()
threads = [threading.Thread(target=download_page, args=(url,)) for url in urls]
for t in threads:
    t.start()
for t in threads:
    t.join()
multi_time = time.perf_counter() - start
print(f"Multi-threaded: {multi_time:.2f}s")

# Result: Multi-threaded is significantly faster for I/O
```

```
┌─────────────────────────────────────────────────────────────────┐
│              I/O-Bound Task Performance                          │
│                                                                  │
│   Single Thread:                                                 │
│   ┌────┐   ┌────┐   ┌────┐   ┌────┐   ┌────┐                   │
│   │ IO │───│ IO │───│ IO │───│ IO │───│ IO │                   │
│   └────┘   └────┘   └────┘   └────┘   └────┘                   │
│   Time: ═════════════════════════════════════════►              │
│                                                                  │
│   Multiple Threads (I/O overlapped):                             │
│   T1: ┌────┐                                                     │
│   T2:    ┌────┐                                                  │
│   T3:       ┌────┐                                               │
│   T4:          ┌────┐                                            │
│   T5:             ┌────┐                                         │
│   Time: ════════════►                                            │
│                                                                  │
│   ✅ Much faster! GIL released during I/O wait                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## When GIL Matters and When It Doesn't

### GIL IS a Problem:
| Scenario | Why |
|----------|-----|
| CPU-bound multithreading | Only one thread can execute Python bytecode |
| Parallel computation | Cannot utilize multiple CPU cores |
| High-performance computing | Serialized execution defeats purpose |

### GIL is NOT a Problem:
| Scenario | Why |
|----------|-----|
| I/O-bound operations | GIL released during I/O wait |
| Single-threaded programs | No contention |
| Multiprocessing | Each process has its own GIL |
| C extensions that release GIL | NumPy, pandas operations |
| async/await | Cooperative multitasking, not parallel |

---

## Workarounds for the GIL

### 1. Multiprocessing (Recommended for CPU-bound)

```python
from multiprocessing import Pool
import time

def cpu_intensive(n):
    count = 0
    for _ in range(n):
        count += 1
    return count

if __name__ == '__main__':
    # Each process has its own GIL
    start = time.perf_counter()
    with Pool(4) as pool:
        results = pool.map(cpu_intensive, [10_000_000] * 4)
    print(f"Multiprocessing: {time.perf_counter() - start:.2f}s")
```

```
┌─────────────────────────────────────────────────────────────────┐
│                  Multiprocessing Solution                        │
│                                                                  │
│  ┌─────────────────────┐    ┌─────────────────────┐             │
│  │    Process 1        │    │    Process 2        │             │
│  │  ┌─────────────┐    │    │  ┌─────────────┐    │             │
│  │  │    GIL 1    │    │    │  │    GIL 2    │    │             │
│  │  └─────────────┘    │    │  └─────────────┘    │             │
│  │  ┌─────────────┐    │    │  ┌─────────────┐    │             │
│  │  │  Thread 1   │    │    │  │  Thread 1   │    │             │
│  │  │  (Running)  │    │    │  │  (Running)  │    │             │
│  │  └─────────────┘    │    │  └─────────────┘    │             │
│  └─────────────────────┘    └─────────────────────┘             │
│           │                          │                           │
│           └──────────────┬───────────┘                          │
│                          │                                       │
│                    ┌─────▼─────┐                                │
│                    │   CPU 1   │   CPU 2                        │
│                    │  (Core)   │  (Core)                        │
│                    └───────────┘                                │
│                                                                  │
│  ✅ True parallel execution on multiple CPU cores!             │
└─────────────────────────────────────────────────────────────────┘
```

### 2. C Extensions that Release GIL

```python
import numpy as np
import time

# NumPy releases GIL during heavy computations
def numpy_operation():
    arr = np.random.rand(10000, 10000)
    return np.dot(arr, arr)  # GIL released during this operation

# This CAN benefit from threading because NumPy releases the GIL
import threading
threads = [threading.Thread(target=numpy_operation) for _ in range(4)]
```

### 3. Use Alternative Python Implementations

```
┌─────────────────────────────────────────────────────────────────┐
│              Python Implementations Comparison                   │
│                                                                  │
│   Implementation    │  Has GIL?  │  Notes                       │
│   ─────────────────────────────────────────────────────────────│
│   CPython           │    Yes     │  Reference implementation    │
│   PyPy              │    Yes     │  But JIT makes it faster     │
│   Jython            │    No      │  Uses JVM threads            │
│   IronPython        │    No      │  Uses .NET threads           │
│   GraalPy           │    No      │  GraalVM based               │
│   Cython            │  Optional  │  Can release GIL explicitly  │
│   Nogil CPython     │    No      │  Experimental (PEP 703)      │
└─────────────────────────────────────────────────────────────────┘
```

### 4. Use concurrent.futures

```python
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
import time

def task(n):
    return sum(range(n))

# For CPU-bound: Use ProcessPoolExecutor
with ProcessPoolExecutor(max_workers=4) as executor:
    futures = [executor.submit(task, 10_000_000) for _ in range(4)]
    results = [f.result() for f in futures]

# For I/O-bound: Use ThreadPoolExecutor
with ThreadPoolExecutor(max_workers=4) as executor:
    futures = [executor.submit(io_task, url) for url in urls]
    results = [f.result() for f in futures]
```

---

## GIL in Different Python Implementations

### CPython (Reference Implementation)
- **Has GIL**: Yes
- **Reason**: Memory management simplicity

### PyPy
- **Has GIL**: Yes
- **Note**: JIT compilation makes single-threaded code much faster

### Jython
- **Has GIL**: No
- **Uses**: JVM threading model

### IronPython
- **Has GIL**: No
- **Uses**: .NET threading model

### Free-threaded Python (PEP 703)
- **Status**: Experimental in Python 3.13+
- **Goal**: Optional GIL-free mode

```python
# Python 3.13+ (experimental)
# Build Python with: --disable-gil

# Check if running without GIL
import sys
print(sys._is_gil_enabled())  # False if GIL is disabled
```

---

## Code Examples

### Example 1: Demonstrating GIL Impact

```python
import threading
import time
import sys

def count_up(n, results, index):
    """CPU-bound task"""
    count = 0
    for _ in range(n):
        count += 1
    results[index] = count

def benchmark(num_threads, iterations_per_thread):
    results = [0] * num_threads
    threads = []
    
    start = time.perf_counter()
    
    for i in range(num_threads):
        t = threading.Thread(
            target=count_up, 
            args=(iterations_per_thread, results, i)
        )
        threads.append(t)
        t.start()
    
    for t in threads:
        t.join()
    
    elapsed = time.perf_counter() - start
    return elapsed, sum(results)

# Test with different thread counts
total_work = 100_000_000

print("Threads | Time (s) | Speedup")
print("-" * 35)

baseline = None
for num_threads in [1, 2, 4, 8]:
    iterations = total_work // num_threads
    elapsed, total = benchmark(num_threads, iterations)
    
    if baseline is None:
        baseline = elapsed
    speedup = baseline / elapsed
    
    print(f"   {num_threads}    |  {elapsed:.2f}   |  {speedup:.2f}x")
```

### Example 2: I/O vs CPU Bound Comparison

```python
import threading
import time

def io_task(duration):
    """Simulates I/O - GIL is released"""
    time.sleep(duration)
    return duration

def cpu_task(iterations):
    """Pure Python computation - GIL is held"""
    total = 0
    for i in range(iterations):
        total += i * i
    return total

def run_sequential(task, args_list):
    start = time.perf_counter()
    results = [task(arg) for arg in args_list]
    return time.perf_counter() - start

def run_threaded(task, args_list):
    start = time.perf_counter()
    threads = []
    results = [None] * len(args_list)
    
    def wrapper(idx, arg):
        results[idx] = task(arg)
    
    for i, arg in enumerate(args_list):
        t = threading.Thread(target=wrapper, args=(i, arg))
        threads.append(t)
        t.start()
    
    for t in threads:
        t.join()
    
    return time.perf_counter() - start

# I/O-bound test
io_args = [0.5] * 4  # 4 tasks, each sleeps 0.5s
print("I/O-Bound Task (4 x 0.5s sleep):")
print(f"  Sequential: {run_sequential(io_task, io_args):.2f}s")
print(f"  Threaded:   {run_threaded(io_task, io_args):.2f}s")

# CPU-bound test
cpu_args = [5_000_000] * 4  # 4 tasks
print("\nCPU-Bound Task (4 x 5M iterations):")
print(f"  Sequential: {run_sequential(cpu_task, cpu_args):.2f}s")
print(f"  Threaded:   {run_threaded(cpu_task, cpu_args):.2f}s")
```

### Example 3: Checking GIL Status

```python
import sys
import threading

# Get GIL switch interval
print(f"GIL switch interval: {sys.getswitchinterval()}s")

# Check thread count
print(f"Active threads: {threading.active_count()}")

# Python version info
print(f"Python version: {sys.version}")

# Check if GIL is enabled (Python 3.13+)
if hasattr(sys, '_is_gil_enabled'):
    print(f"GIL enabled: {sys._is_gil_enabled()}")
```

---

## Interview Questions

### Q1: What is the GIL and why does Python have it?
**Answer**: The GIL (Global Interpreter Lock) is a mutex that allows only one thread to execute Python bytecode at a time. Python has it because:
1. Simplifies memory management (reference counting)
2. Makes C extension development easier
3. Improves single-threaded performance

### Q2: Does the GIL make Python thread-safe?
**Answer**: No! The GIL only protects Python interpreter internals. You still need locks for your own data structures. The GIL can switch between threads at any bytecode instruction boundary.

```python
# NOT thread-safe even with GIL!
counter = 0

def increment():
    global counter
    for _ in range(100000):
        counter += 1  # This is NOT atomic!

# counter += 1 is actually:
# 1. LOAD_GLOBAL counter
# 2. LOAD_CONST 1
# 3. BINARY_ADD
# 4. STORE_GLOBAL counter
# GIL can release between any of these!
```

### Q3: How can you achieve true parallelism in Python?
**Answer**:
1. Use `multiprocessing` module (separate processes, separate GILs)
2. Use C extensions that release the GIL (NumPy, pandas)
3. Use alternative implementations (Jython, IronPython)
4. Use `concurrent.futures.ProcessPoolExecutor`

### Q4: When should you use threading despite the GIL?
**Answer**: For I/O-bound operations:
- Network requests
- File I/O
- Database queries
- User input
The GIL is released during these operations, allowing true concurrency.

### Q5: What is the GIL switch interval?
**Answer**: The time Python waits before forcing a thread to release the GIL (default: 5ms in Python 3.2+). Can be modified with `sys.setswitchinterval()`.

---

## Summary

```
┌─────────────────────────────────────────────────────────────────┐
│                        GIL Summary                               │
├─────────────────────────────────────────────────────────────────┤
│  What:     Mutex preventing parallel Python bytecode execution  │
│  Why:      Memory safety, C extension compatibility             │
│  Impact:   CPU-bound threading doesn't parallelize              │
│  Solution: multiprocessing, C extensions, async I/O             │
│  Future:   PEP 703 (optional GIL removal in Python 3.13+)       │
└─────────────────────────────────────────────────────────────────┘
```

---

## Further Reading

1. [Python Wiki - GlobalInterpreterLock](https://wiki.python.org/moin/GlobalInterpreterLock)
2. [PEP 703 – Making the Global Interpreter Lock Optional](https://peps.python.org/pep-0703/)
3. [David Beazley - Understanding the GIL](https://www.dabeaz.com/GIL/)
4. [Real Python - GIL Guide](https://realpython.com/python-gil/)
