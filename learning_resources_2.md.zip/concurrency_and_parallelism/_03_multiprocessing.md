# Multiprocessing in Python

## Table of Contents
1. [Introduction to Multiprocessing](#introduction-to-multiprocessing)
2. [Process vs Thread](#process-vs-thread)
3. [Creating Processes](#creating-processes)
4. [Process Pools](#process-pools)
5. [Inter-Process Communication (IPC)](#inter-process-communication-ipc)
6. [Shared Memory](#shared-memory)
7. [Synchronization Primitives](#synchronization-primitives)
8. [Process Management](#process-management)
9. [Best Practices](#best-practices)
10. [Interview Questions](#interview-questions)

---

## Introduction to Multiprocessing

**Multiprocessing** allows you to run multiple processes in parallel, each with its own Python interpreter and memory space. This bypasses the GIL limitation, enabling true parallel execution on multi-core CPUs.

```
┌─────────────────────────────────────────────────────────────────┐
│                     Multiprocessing Architecture                 │
│                                                                  │
│   ┌───────────────────────┐    ┌───────────────────────┐        │
│   │      Process 1        │    │      Process 2        │        │
│   │  ┌─────────────────┐  │    │  ┌─────────────────┐  │        │
│   │  │ Python Interp.  │  │    │  │ Python Interp.  │  │        │
│   │  │   + Own GIL     │  │    │  │   + Own GIL     │  │        │
│   │  └─────────────────┘  │    │  └─────────────────┘  │        │
│   │  ┌─────────────────┐  │    │  ┌─────────────────┐  │        │
│   │  │  Memory Space   │  │    │  │  Memory Space   │  │        │
│   │  │   (Isolated)    │  │    │  │   (Isolated)    │  │        │
│   │  └─────────────────┘  │    │  └─────────────────┘  │        │
│   └───────────────────────┘    └───────────────────────┘        │
│              │                          │                        │
│              ▼                          ▼                        │
│   ┌─────────────────────────────────────────────────────────┐   │
│   │                   Operating System                       │   │
│   │      CPU Core 1              CPU Core 2                  │   │
│   │         ████                    ████                     │   │
│   └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│   ✅ True parallel execution on multiple CPU cores!            │
└─────────────────────────────────────────────────────────────────┘
```

### When to Use Multiprocessing

| Use Case | Why Multiprocessing |
|----------|---------------------|
| CPU-bound computations | Bypass GIL, use all CPU cores |
| Parallel data processing | Process chunks simultaneously |
| Scientific computing | Heavy numerical operations |
| Image/video processing | Parallel pixel operations |
| Machine learning training | Parallel model training |

---

## Process vs Thread

```
┌─────────────────────────────────────────────────────────────────┐
│                    Process vs Thread Comparison                  │
│                                                                  │
│   PROCESS                              THREAD                    │
│   ┌─────────────────────┐              ┌─────────────────────┐  │
│   │   Own Memory Space  │              │   Shared Memory     │  │
│   │   Own GIL           │              │   Shared GIL        │  │
│   │   Own Resources     │              │   Shared Resources  │  │
│   └─────────────────────┘              └─────────────────────┘  │
│                                                                  │
│   Creation: Slow (fork/spawn)          Creation: Fast           │
│   Memory:   High overhead              Memory:   Low overhead   │
│   Crash:    Isolated                   Crash:    Affects all    │
│   IPC:      Complex (pickle)           IPC:      Easy (shared)  │
│   GIL:      Bypassed ✓                 GIL:      Affected ✗     │
└─────────────────────────────────────────────────────────────────┘
```

### Performance Comparison

```python
import time
import threading
import multiprocessing

def cpu_intensive(n):
    """CPU-bound task"""
    total = 0
    for i in range(n):
        total += i * i
    return total

def benchmark_sequential(func, args, count):
    start = time.perf_counter()
    results = [func(arg) for arg in [args] * count]
    return time.perf_counter() - start

def benchmark_threaded(func, args, count):
    start = time.perf_counter()
    threads = [threading.Thread(target=func, args=(args,)) for _ in range(count)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    return time.perf_counter() - start

def benchmark_multiprocess(func, args, count):
    start = time.perf_counter()
    with multiprocessing.Pool(count) as pool:
        results = pool.map(func, [args] * count)
    return time.perf_counter() - start

if __name__ == '__main__':
    N = 5_000_000
    COUNT = 4
    
    print(f"Sequential:     {benchmark_sequential(cpu_intensive, N, COUNT):.2f}s")
    print(f"Threaded:       {benchmark_threaded(cpu_intensive, N, COUNT):.2f}s")
    print(f"Multiprocessing: {benchmark_multiprocess(cpu_intensive, N, COUNT):.2f}s")
```

---

## Creating Processes

### Method 1: Using Process Class

```python
import multiprocessing
import os
import time

def worker(name, duration):
    """Function that runs in a separate process"""
    print(f"[{name}] PID: {os.getpid()}, Parent PID: {os.getppid()}")
    time.sleep(duration)
    print(f"[{name}] Finished after {duration}s")

if __name__ == '__main__':
    print(f"Main process PID: {os.getpid()}")
    
    # Create processes
    p1 = multiprocessing.Process(target=worker, args=("Process-1", 2))
    p2 = multiprocessing.Process(target=worker, args=("Process-2", 1))
    
    # Start processes
    p1.start()
    p2.start()
    
    # Wait for completion
    p1.join()
    p2.join()
    
    print("All processes completed!")
```

### Method 2: Subclassing Process

```python
import multiprocessing
import os

class WorkerProcess(multiprocessing.Process):
    def __init__(self, name, data):
        super().__init__()
        self.name = name
        self.data = data
        self.result = None
    
    def run(self):
        """Override run() method"""
        print(f"[{self.name}] Processing: {self.data}")
        self.result = sum(self.data)  # Note: result not accessible from parent!
        print(f"[{self.name}] Result: {self.result}")

if __name__ == '__main__':
    processes = [
        WorkerProcess("Worker-1", [1, 2, 3, 4, 5]),
        WorkerProcess("Worker-2", [10, 20, 30, 40, 50]),
    ]
    
    for p in processes:
        p.start()
    
    for p in processes:
        p.join()
        # p.result is None here! Memory is not shared
```

### Getting Return Values

```python
import multiprocessing

def compute(x):
    """Function that returns a value"""
    return x * x

if __name__ == '__main__':
    # Method 1: Using Pool.map()
    with multiprocessing.Pool(4) as pool:
        results = pool.map(compute, [1, 2, 3, 4, 5])
        print(f"Results: {results}")
    
    # Method 2: Using Queue
    def worker_with_queue(x, queue):
        result = x * x
        queue.put((x, result))
    
    queue = multiprocessing.Queue()
    processes = []
    
    for i in range(5):
        p = multiprocessing.Process(target=worker_with_queue, args=(i, queue))
        processes.append(p)
        p.start()
    
    for p in processes:
        p.join()
    
    while not queue.empty():
        x, result = queue.get()
        print(f"{x}² = {result}")
```

### Process Start Methods

```python
import multiprocessing

# Check available start methods
print(multiprocessing.get_all_start_methods())
# ['fork', 'spawn', 'forkserver'] on Unix
# ['spawn'] on Windows

# Set start method (must be done before creating processes)
multiprocessing.set_start_method('spawn')

# Or use context
ctx = multiprocessing.get_context('spawn')
p = ctx.Process(target=worker)
```

```
┌─────────────────────────────────────────────────────────────────┐
│                    Process Start Methods                         │
│                                                                  │
│   fork (Unix default):                                           │
│   ┌─────────────────┐      fork()      ┌─────────────────┐      │
│   │  Parent Process │ ───────────────► │  Child Process  │      │
│   │  ┌───────────┐  │                  │  ┌───────────┐  │      │
│   │  │   Memory  │  │   Copy-on-Write  │  │   Memory  │  │      │
│   │  │  (shared) │  │                  │  │  (copied) │  │      │
│   │  └───────────┘  │                  │  └───────────┘  │      │
│   └─────────────────┘                  └─────────────────┘      │
│   Fast, but can have issues with threads/locks                  │
│                                                                  │
│   spawn (Windows default, macOS default in 3.8+):               │
│   ┌─────────────────┐                  ┌─────────────────┐      │
│   │  Parent Process │                  │  Child Process  │      │
│   │                 │   New Interp.    │  Fresh Python   │      │
│   │                 │ ───────────────► │  + pickle args  │      │
│   └─────────────────┘                  └─────────────────┘      │
│   Slower, but safer and more portable                           │
│                                                                  │
│   forkserver (Unix only):                                        │
│   Parent ──► Server Process ──► Fork children                   │
│   Compromise: faster than spawn, safer than fork                │
└─────────────────────────────────────────────────────────────────┘
```

---

## Process Pools

### Basic Pool Usage

```python
from multiprocessing import Pool
import time

def process_item(item):
    """Simulate processing"""
    time.sleep(0.5)
    return item ** 2

if __name__ == '__main__':
    items = list(range(10))
    
    # Sequential (for comparison)
    start = time.perf_counter()
    sequential_results = [process_item(i) for i in items]
    print(f"Sequential: {time.perf_counter() - start:.2f}s")
    
    # Parallel with Pool
    start = time.perf_counter()
    with Pool(4) as pool:
        parallel_results = pool.map(process_item, items)
    print(f"Parallel: {time.perf_counter() - start:.2f}s")
```

### Pool Methods

```python
from multiprocessing import Pool
import time

def square(x):
    time.sleep(0.1)
    return x * x

def cube(x):
    time.sleep(0.1)
    return x ** 3

if __name__ == '__main__':
    with Pool(4) as pool:
        
        # map() - Blocks until all results ready
        results = pool.map(square, range(10))
        print(f"map: {results}")
        
        # map_async() - Returns AsyncResult immediately
        async_result = pool.map_async(square, range(10))
        results = async_result.get(timeout=10)  # Get results with timeout
        print(f"map_async: {results}")
        
        # imap() - Returns iterator, lazily evaluated
        for result in pool.imap(square, range(10)):
            print(f"imap result: {result}")
        
        # imap_unordered() - Results in completion order (faster)
        for result in pool.imap_unordered(square, range(10)):
            print(f"imap_unordered: {result}")
        
        # apply() - Single function call, blocks
        result = pool.apply(square, (5,))
        print(f"apply: {result}")
        
        # apply_async() - Single function call, async
        async_result = pool.apply_async(square, (5,))
        result = async_result.get()
        print(f"apply_async: {result}")
        
        # starmap() - Like map, but unpacks arguments
        pairs = [(1, 2), (3, 4), (5, 6)]
        def add(a, b):
            return a + b
        results = pool.starmap(add, pairs)
        print(f"starmap: {results}")
```

```
┌─────────────────────────────────────────────────────────────────┐
│                    Pool Methods Comparison                       │
│                                                                  │
│   Method          │ Blocking │ Ordered │ Use Case               │
│   ────────────────────────────────────────────────────────────  │
│   map()           │   Yes    │   Yes   │ Simple parallel map    │
│   map_async()     │   No     │   Yes   │ Non-blocking map       │
│   imap()          │   Iter   │   Yes   │ Memory-efficient       │
│   imap_unordered()│   Iter   │   No    │ Fastest completion     │
│   apply()         │   Yes    │   N/A   │ Single call            │
│   apply_async()   │   No     │   N/A   │ Single async call      │
│   starmap()       │   Yes    │   Yes   │ Multiple args per call │
└─────────────────────────────────────────────────────────────────┘
```

### Using ProcessPoolExecutor

```python
from concurrent.futures import ProcessPoolExecutor, as_completed
import time

def heavy_computation(n):
    """Simulate heavy CPU work"""
    total = sum(i * i for i in range(n))
    return n, total

if __name__ == '__main__':
    numbers = [1_000_000, 2_000_000, 3_000_000, 4_000_000]
    
    with ProcessPoolExecutor(max_workers=4) as executor:
        # Submit all tasks
        futures = {executor.submit(heavy_computation, n): n for n in numbers}
        
        # Process results as they complete
        for future in as_completed(futures):
            n = futures[future]
            try:
                result_n, result_sum = future.result()
                print(f"Sum of squares up to {result_n}: {result_sum}")
            except Exception as e:
                print(f"Error processing {n}: {e}")
```

### Pool with Initialization

```python
from multiprocessing import Pool
import os

# Global variable in worker processes
db_connection = None

def init_worker():
    """Called once per worker process"""
    global db_connection
    pid = os.getpid()
    print(f"Worker {pid} initializing...")
    db_connection = f"Connection-{pid}"  # Simulate DB connection

def process_query(query):
    """Uses the initialized connection"""
    global db_connection
    return f"Processed '{query}' using {db_connection}"

if __name__ == '__main__':
    with Pool(4, initializer=init_worker) as pool:
        queries = ["SELECT * FROM users", "SELECT * FROM orders", "SELECT * FROM products"]
        results = pool.map(process_query, queries)
        
        for result in results:
            print(result)
```

---

## Inter-Process Communication (IPC)

### 1. Queue

```python
from multiprocessing import Process, Queue
import time
import random

def producer(queue, items):
    """Produce items and put them in queue"""
    for item in items:
        print(f"Producing: {item}")
        queue.put(item)
        time.sleep(random.uniform(0.1, 0.3))
    queue.put(None)  # Sentinel to signal completion

def consumer(queue, name):
    """Consume items from queue"""
    while True:
        item = queue.get()
        if item is None:
            print(f"{name}: Received shutdown signal")
            break
        print(f"{name}: Consumed {item}")
        time.sleep(random.uniform(0.2, 0.4))

if __name__ == '__main__':
    queue = Queue()
    
    items = list(range(10))
    
    prod = Process(target=producer, args=(queue, items))
    cons = Process(target=consumer, args=(queue, "Consumer"))
    
    prod.start()
    cons.start()
    
    prod.join()
    cons.join()
```

```
┌─────────────────────────────────────────────────────────────────┐
│                    Queue Communication                           │
│                                                                  │
│   ┌──────────────┐                    ┌──────────────┐          │
│   │   Producer   │                    │   Consumer   │          │
│   │   Process    │                    │   Process    │          │
│   └──────┬───────┘                    └───────▲──────┘          │
│          │ put()                              │ get()           │
│          ▼                                    │                  │
│   ┌──────────────────────────────────────────────────┐          │
│   │              Multiprocessing Queue               │          │
│   │  ┌────┬────┬────┬────┬────┬────┬────┬────┐     │          │
│   │  │ 1  │ 2  │ 3  │ 4  │ 5  │    │    │    │     │          │
│   │  └────┴────┴────┴────┴────┴────┴────┴────┘     │          │
│   │              (Thread-safe, Process-safe)        │          │
│   └──────────────────────────────────────────────────┘          │
└─────────────────────────────────────────────────────────────────┘
```

### 2. Pipe

```python
from multiprocessing import Process, Pipe

def sender(conn):
    """Send data through pipe"""
    messages = ["Hello", "World", "Done"]
    for msg in messages:
        print(f"Sending: {msg}")
        conn.send(msg)
    conn.close()

def receiver(conn):
    """Receive data from pipe"""
    while True:
        try:
            msg = conn.recv()
            print(f"Received: {msg}")
            if msg == "Done":
                break
        except EOFError:
            break
    conn.close()

if __name__ == '__main__':
    # Create a pipe (returns two connection objects)
    parent_conn, child_conn = Pipe()
    
    p1 = Process(target=sender, args=(parent_conn,))
    p2 = Process(target=receiver, args=(child_conn,))
    
    p1.start()
    p2.start()
    
    p1.join()
    p2.join()
```

```
┌─────────────────────────────────────────────────────────────────┐
│                     Pipe Communication                           │
│                                                                  │
│   ┌──────────────┐                    ┌──────────────┐          │
│   │   Process 1  │                    │   Process 2  │          │
│   │   (Sender)   │                    │  (Receiver)  │          │
│   └──────┬───────┘                    └───────▲──────┘          │
│          │                                    │                  │
│          │    ┌────────────────────────┐     │                  │
│          └───►│         Pipe           │─────┘                  │
│               │   ◄──── data ────►     │                        │
│               │   (Bidirectional)      │                        │
│               └────────────────────────┘                        │
│                                                                  │
│   Pipe vs Queue:                                                │
│   • Pipe: 2 endpoints, faster, less overhead                   │
│   • Queue: Multiple producers/consumers, more features         │
└─────────────────────────────────────────────────────────────────┘
```

### 3. Manager (Shared State)

```python
from multiprocessing import Process, Manager

def worker(shared_dict, shared_list, name, value):
    """Modify shared data structures"""
    shared_dict[name] = value
    shared_list.append(f"{name}: {value}")
    print(f"Worker {name} added value {value}")

if __name__ == '__main__':
    with Manager() as manager:
        # Create shared data structures
        shared_dict = manager.dict()
        shared_list = manager.list()
        
        processes = []
        for i in range(5):
            p = Process(
                target=worker, 
                args=(shared_dict, shared_list, f"Worker-{i}", i * 10)
            )
            processes.append(p)
            p.start()
        
        for p in processes:
            p.join()
        
        print(f"\nShared dict: {dict(shared_dict)}")
        print(f"Shared list: {list(shared_list)}")
```

```
┌─────────────────────────────────────────────────────────────────┐
│                    Manager Architecture                          │
│                                                                  │
│   ┌──────────────────────────────────────────────────────────┐  │
│   │                   Manager Process                         │  │
│   │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐      │  │
│   │  │ Shared Dict │  │ Shared List │  │ Shared Lock │      │  │
│   │  └─────────────┘  └─────────────┘  └─────────────┘      │  │
│   └──────────────────────────────────────────────────────────┘  │
│          ▲                   ▲                   ▲               │
│          │ (proxy)           │ (proxy)           │ (proxy)       │
│          │                   │                   │               │
│   ┌──────┴──────┐    ┌───────┴──────┐    ┌──────┴───────┐      │
│   │  Process 1  │    │  Process 2   │    │  Process 3   │      │
│   │ dict[k] = v │    │ list.append()│    │ with lock:   │      │
│   └─────────────┘    └──────────────┘    └──────────────┘      │
│                                                                  │
│   Manager provides proxy objects that sync to central process   │
└─────────────────────────────────────────────────────────────────┘
```

---

## Shared Memory

### Using Value and Array

```python
from multiprocessing import Process, Value, Array
import ctypes

def increment_counter(counter, lock):
    """Increment shared counter"""
    for _ in range(10000):
        with lock:
            counter.value += 1

def modify_array(arr):
    """Modify shared array"""
    for i in range(len(arr)):
        arr[i] = arr[i] ** 2

if __name__ == '__main__':
    from multiprocessing import Lock
    
    # Shared integer
    counter = Value('i', 0)  # 'i' = signed int
    lock = Lock()
    
    # Shared array
    arr = Array('d', [1.0, 2.0, 3.0, 4.0, 5.0])  # 'd' = double
    
    # Counter example
    processes = [
        Process(target=increment_counter, args=(counter, lock))
        for _ in range(4)
    ]
    
    for p in processes:
        p.start()
    for p in processes:
        p.join()
    
    print(f"Counter: {counter.value}")  # Should be 40000
    
    # Array example
    p = Process(target=modify_array, args=(arr,))
    p.start()
    p.join()
    
    print(f"Array: {list(arr)}")
```

### Type Codes for Value/Array

```
┌─────────────────────────────────────────────────────────────────┐
│                    ctypes Type Codes                             │
│                                                                  │
│   Code │ C Type           │ Python Type │ Size                  │
│   ─────────────────────────────────────────────────────────────│
│   'b'  │ signed char      │ int         │ 1 byte                │
│   'B'  │ unsigned char    │ int         │ 1 byte                │
│   'h'  │ signed short     │ int         │ 2 bytes               │
│   'H'  │ unsigned short   │ int         │ 2 bytes               │
│   'i'  │ signed int       │ int         │ 4 bytes               │
│   'I'  │ unsigned int     │ int         │ 4 bytes               │
│   'l'  │ signed long      │ int         │ 4-8 bytes             │
│   'L'  │ unsigned long    │ int         │ 4-8 bytes             │
│   'q'  │ signed long long │ int         │ 8 bytes               │
│   'Q'  │ unsigned long long│ int        │ 8 bytes               │
│   'f'  │ float            │ float       │ 4 bytes               │
│   'd'  │ double           │ float       │ 8 bytes               │
│   'c'  │ char             │ bytes       │ 1 byte                │
└─────────────────────────────────────────────────────────────────┘
```

### Using shared_memory (Python 3.8+)

```python
from multiprocessing import Process, shared_memory
import numpy as np

def worker(shm_name, shape, dtype):
    """Access shared memory in child process"""
    # Attach to existing shared memory
    existing_shm = shared_memory.SharedMemory(name=shm_name)
    
    # Create numpy array backed by shared memory
    arr = np.ndarray(shape, dtype=dtype, buffer=existing_shm.buf)
    
    # Modify array
    arr[:] = arr * 2
    
    print(f"Worker modified array: {arr}")
    
    existing_shm.close()

if __name__ == '__main__':
    # Create numpy array
    original = np.array([1.0, 2.0, 3.0, 4.0, 5.0])
    
    # Create shared memory block
    shm = shared_memory.SharedMemory(create=True, size=original.nbytes)
    
    # Create numpy array backed by shared memory
    shared_arr = np.ndarray(original.shape, dtype=original.dtype, buffer=shm.buf)
    shared_arr[:] = original[:]  # Copy data
    
    print(f"Before: {shared_arr}")
    
    # Start worker process
    p = Process(target=worker, args=(shm.name, original.shape, original.dtype))
    p.start()
    p.join()
    
    print(f"After: {shared_arr}")
    
    # Cleanup
    shm.close()
    shm.unlink()  # Delete shared memory block
```

```
┌─────────────────────────────────────────────────────────────────┐
│                   Shared Memory Diagram                          │
│                                                                  │
│                    Physical Memory                               │
│   ┌──────────────────────────────────────────────────────────┐  │
│   │                                                          │  │
│   │   ┌──────────────────────────────────────┐               │  │
│   │   │     Shared Memory Block              │               │  │
│   │   │  [1.0][2.0][3.0][4.0][5.0]          │               │  │
│   │   └──────────────────────────────────────┘               │  │
│   │          ▲                      ▲                        │  │
│   │          │                      │                        │  │
│   └──────────┼──────────────────────┼────────────────────────┘  │
│              │                      │                            │
│   ┌──────────┴──────────┐  ┌───────┴────────────┐              │
│   │    Parent Process   │  │   Child Process    │              │
│   │                     │  │                    │              │
│   │  shm.buf ──────────────► np.ndarray(buf=)  │              │
│   │  np.ndarray(buf=)  │  │                    │              │
│   └─────────────────────┘  └────────────────────┘              │
│                                                                  │
│   Zero-copy sharing: both processes see same memory            │
└─────────────────────────────────────────────────────────────────┘
```

---

## Synchronization Primitives

### Lock

```python
from multiprocessing import Process, Lock, Value

def increment(counter, lock):
    for _ in range(10000):
        lock.acquire()
        try:
            counter.value += 1
        finally:
            lock.release()

if __name__ == '__main__':
    counter = Value('i', 0)
    lock = Lock()
    
    processes = [Process(target=increment, args=(counter, lock)) for _ in range(4)]
    
    for p in processes:
        p.start()
    for p in processes:
        p.join()
    
    print(f"Final count: {counter.value}")
```

### Semaphore

```python
from multiprocessing import Process, Semaphore
import time
import random

def limited_resource_access(semaphore, name):
    """Only N processes can access resource simultaneously"""
    print(f"{name}: Waiting for resource...")
    
    with semaphore:
        print(f"{name}: Got access!")
        time.sleep(random.uniform(1, 2))
        print(f"{name}: Releasing resource")

if __name__ == '__main__':
    # Only 2 processes can access simultaneously
    semaphore = Semaphore(2)
    
    processes = [
        Process(target=limited_resource_access, args=(semaphore, f"Process-{i}"))
        for i in range(5)
    ]
    
    for p in processes:
        p.start()
    for p in processes:
        p.join()
```

### Event

```python
from multiprocessing import Process, Event
import time

def waiter(event, name):
    print(f"{name}: Waiting for event...")
    event.wait()  # Block until event is set
    print(f"{name}: Event received, continuing!")

def setter(event):
    print("Setter: Preparing...")
    time.sleep(2)
    print("Setter: Setting event!")
    event.set()

if __name__ == '__main__':
    event = Event()
    
    waiters = [Process(target=waiter, args=(event, f"Waiter-{i}")) for i in range(3)]
    setter_proc = Process(target=setter, args=(event,))
    
    for w in waiters:
        w.start()
    setter_proc.start()
    
    for w in waiters:
        w.join()
    setter_proc.join()
```

### Condition

```python
from multiprocessing import Process, Condition, Value

def producer(condition, counter, max_count):
    for i in range(max_count):
        with condition:
            counter.value = i
            print(f"Produced: {i}")
            condition.notify()
            condition.wait()

def consumer(condition, counter, max_count):
    for _ in range(max_count):
        with condition:
            condition.wait()
            print(f"Consumed: {counter.value}")
            condition.notify()

if __name__ == '__main__':
    condition = Condition()
    counter = Value('i', 0)
    
    prod = Process(target=producer, args=(condition, counter, 5))
    cons = Process(target=consumer, args=(condition, counter, 5))
    
    prod.start()
    cons.start()
    
    prod.join()
    cons.join()
```

---

## Process Management

### Process Properties

```python
from multiprocessing import Process, current_process
import os
import time

def worker():
    proc = current_process()
    print(f"Name: {proc.name}")
    print(f"PID: {proc.pid}")
    print(f"Parent PID: {os.getppid()}")
    print(f"Is Alive: {proc.is_alive()}")
    print(f"Daemon: {proc.daemon}")
    print(f"Exit Code: {proc.exitcode}")
    time.sleep(1)

if __name__ == '__main__':
    p = Process(target=worker, name="MyWorker")
    
    print(f"Before start - is_alive: {p.is_alive()}")
    p.start()
    print(f"After start - is_alive: {p.is_alive()}")
    p.join()
    print(f"After join - is_alive: {p.is_alive()}")
    print(f"Exit code: {p.exitcode}")
```

### Daemon Processes

```python
from multiprocessing import Process
import time

def daemon_task():
    while True:
        print("Daemon working...")
        time.sleep(1)

def normal_task():
    for i in range(3):
        print(f"Normal task: {i}")
        time.sleep(0.5)

if __name__ == '__main__':
    daemon = Process(target=daemon_task, daemon=True)
    normal = Process(target=normal_task)
    
    daemon.start()
    normal.start()
    
    normal.join()  # Wait for normal process
    print("Main exiting - daemon will be terminated")
    # Daemon process is automatically killed
```

### Terminating Processes

```python
from multiprocessing import Process
import time
import signal

def long_running_task():
    try:
        while True:
            print("Working...")
            time.sleep(0.5)
    except KeyboardInterrupt:
        print("Interrupted!")

if __name__ == '__main__':
    p = Process(target=long_running_task)
    p.start()
    
    time.sleep(2)
    
    # Graceful termination
    p.terminate()  # Sends SIGTERM
    p.join(timeout=1)
    
    if p.is_alive():
        print("Process didn't terminate, killing...")
        p.kill()  # Sends SIGKILL (Python 3.7+)
    
    print(f"Exit code: {p.exitcode}")
    # -15 = SIGTERM, -9 = SIGKILL
```

### Process Exception Handling

```python
from multiprocessing import Process, Queue
import traceback

def worker_with_error(queue, should_fail):
    try:
        if should_fail:
            raise ValueError("Intentional error!")
        result = "Success!"
        queue.put(("success", result))
    except Exception as e:
        queue.put(("error", str(e), traceback.format_exc()))

if __name__ == '__main__':
    results_queue = Queue()
    
    # Process that succeeds
    p1 = Process(target=worker_with_error, args=(results_queue, False))
    # Process that fails
    p2 = Process(target=worker_with_error, args=(results_queue, True))
    
    p1.start()
    p2.start()
    p1.join()
    p2.join()
    
    # Get results
    while not results_queue.empty():
        result = results_queue.get()
        if result[0] == "success":
            print(f"Success: {result[1]}")
        else:
            print(f"Error: {result[1]}")
            print(f"Traceback: {result[2]}")
```

---

## Best Practices

### 1. Always Use `if __name__ == '__main__'`

```python
# REQUIRED on Windows (spawn start method)
# GOOD PRACTICE everywhere

from multiprocessing import Process

def worker():
    print("Working...")

# This code runs when module is imported
print("Module loaded")

if __name__ == '__main__':
    # This code only runs when script is executed directly
    p = Process(target=worker)
    p.start()
    p.join()
```

### 2. Properly Close/Join Processes

```python
from multiprocessing import Pool

# GOOD: Using context manager
with Pool(4) as pool:
    results = pool.map(func, items)
# Pool automatically closed and joined

# MANUAL: If not using context manager
pool = Pool(4)
try:
    results = pool.map(func, items)
finally:
    pool.close()  # No more tasks
    pool.join()   # Wait for completion
```

### 3. Handle Exceptions Properly

```python
from concurrent.futures import ProcessPoolExecutor, as_completed

def might_fail(x):
    if x == 3:
        raise ValueError(f"Bad value: {x}")
    return x * 2

if __name__ == '__main__':
    with ProcessPoolExecutor() as executor:
        futures = {executor.submit(might_fail, i): i for i in range(5)}
        
        for future in as_completed(futures):
            x = futures[future]
            try:
                result = future.result()
                print(f"{x} -> {result}")
            except Exception as e:
                print(f"{x} raised exception: {e}")
```

### 4. Choose Right Pool Size

```python
import multiprocessing
import os

# CPU-bound tasks: use CPU count
cpu_count = multiprocessing.cpu_count()
# or
cpu_count = os.cpu_count()

# I/O-bound tasks: can use more
io_workers = cpu_count * 2  # or more

# Memory-intensive: fewer workers
memory_workers = cpu_count // 2
```

### 5. Avoid Sharing State When Possible

```python
from multiprocessing import Pool

# GOOD: Stateless function, data passed explicitly
def process_chunk(chunk):
    return [x * 2 for x in chunk]

# BAD: Relying on global state
global_data = []  # This won't work as expected!

def bad_process(x):
    global_data.append(x)  # Each process has its own copy!
```

### 6. Use Appropriate IPC Mechanism

```
┌─────────────────────────────────────────────────────────────────┐
│              Choosing IPC Mechanism                              │
│                                                                  │
│   Use Case                          │ Mechanism                 │
│   ─────────────────────────────────────────────────────────────│
│   Simple data passing               │ Queue                     │
│   Two-process communication         │ Pipe (faster)             │
│   Shared complex objects            │ Manager                   │
│   High-performance numeric          │ shared_memory + numpy     │
│   Simple counters/flags             │ Value/Array               │
│   Return values from functions      │ Pool.map() / futures      │
└─────────────────────────────────────────────────────────────────┘
```

---

## Interview Questions

### Q1: What's the difference between multiprocessing and threading in Python?
**Answer**:
- **Threading**: Threads share memory, affected by GIL, good for I/O-bound tasks
- **Multiprocessing**: Separate memory spaces, bypass GIL, good for CPU-bound tasks
- Multiprocessing has higher overhead (process creation, IPC) but enables true parallelism

### Q2: How do you share data between processes?
**Answer**:
1. **Queue/Pipe**: Message passing (data copied)
2. **Manager**: Proxy objects with automatic sync
3. **Value/Array**: Shared memory for simple types
4. **shared_memory**: Zero-copy sharing (Python 3.8+)

### Q3: What is the `if __name__ == '__main__'` guard and why is it needed?
**Answer**: On Windows (spawn start method), child processes import the main module. Without the guard, the process creation code would run recursively, causing infinite spawning. The guard ensures process creation only happens in the main script.

### Q4: How does Pool.map() differ from Pool.imap()?
**Answer**:
- `map()`: Blocks until all results ready, returns list
- `imap()`: Returns iterator, yields results as they complete
- `imap_unordered()`: Like imap but results in completion order (fastest)
- Use `imap` for memory efficiency with large datasets

### Q5: How do you handle exceptions in child processes?
**Answer**:
1. Use try/except in worker function, return error info via Queue
2. Use `ProcessPoolExecutor` with `future.result()` which re-raises exceptions
3. Check `Process.exitcode` (non-zero indicates error)

### Q6: What is the difference between terminate() and kill()?
**Answer**:
- `terminate()`: Sends SIGTERM, allows cleanup handlers to run
- `kill()`: Sends SIGKILL (Python 3.7+), immediate termination, no cleanup
- Always try terminate() first, kill() as last resort

---

## Summary

```
┌─────────────────────────────────────────────────────────────────┐
│                  Multiprocessing Summary                         │
├─────────────────────────────────────────────────────────────────┤
│  Use multiprocessing for: CPU-bound tasks, true parallelism     │
│  Avoid for: I/O-bound tasks (use threading/asyncio)             │
│                                                                  │
│  Key Components:                                                 │
│  • Process - Individual process                                 │
│  • Pool - Worker pool for parallel execution                    │
│  • Queue/Pipe - Inter-process communication                     │
│  • Value/Array - Shared memory primitives                       │
│  • Manager - Shared complex objects                             │
│  • Lock/Semaphore - Synchronization                             │
│                                                                  │
│  Best Practices:                                                 │
│  • Always use if __name__ == '__main__'                         │
│  • Use context managers (with Pool() as p:)                     │
│  • Choose right pool size (cpu_count() for CPU-bound)           │
│  • Handle exceptions in worker functions                        │
│  • Prefer stateless workers                                     │
└─────────────────────────────────────────────────────────────────┘
```
