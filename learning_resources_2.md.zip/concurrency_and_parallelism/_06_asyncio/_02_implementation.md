# Asyncio in Python - Implementation & Code

## Table of Contents
1. [Basic Patterns](#1-basic-patterns)
2. [Running Concurrent Tasks](#2-running-concurrent-tasks)
3. [Synchronization Primitives](#3-synchronization-primitives)
4. [Async Queues](#4-async-queues)
5. [Timeouts and Cancellation](#5-timeouts-and-cancellation)
6. [Practical Examples](#6-practical-examples)

---

## 1. Basic Patterns

### Simple Async Function

```python
import asyncio

async def greet(name: str) -> str:
    print(f"Hello, {name}!")
    await asyncio.sleep(1)  # Non-blocking sleep
    return f"Goodbye, {name}!"

async def main():
    result = await greet("World")
    print(result)

asyncio.run(main())
```

### Multiple Sequential Operations

```python
import asyncio

async def fetch_user(user_id: int):
    await asyncio.sleep(0.5)
    return {"id": user_id, "name": f"User{user_id}"}

async def fetch_orders(user_id: int):
    await asyncio.sleep(0.3)
    return [f"Order{i}" for i in range(3)]

async def main():
    # Sequential - one after another
    user = await fetch_user(1)
    orders = await fetch_orders(user["id"])
    print(f"{user['name']} has orders: {orders}")

asyncio.run(main())
# Total time: ~0.8 seconds (0.5 + 0.3)
```

### Multiple Concurrent Operations

```python
import asyncio

async def fetch_user(user_id: int):
    await asyncio.sleep(0.5)
    return {"id": user_id, "name": f"User{user_id}"}

async def fetch_orders(user_id: int):
    await asyncio.sleep(0.3)
    return [f"Order{i}" for i in range(3)]

async def main():
    # Concurrent - both at the same time
    user, orders = await asyncio.gather(
        fetch_user(1),
        fetch_orders(1),
    )
    print(f"{user['name']} has orders: {orders}")

asyncio.run(main())
# Total time: ~0.5 seconds (max of both)
```

---

## 2. Running Concurrent Tasks

### asyncio.gather() - Run Multiple

```python
import asyncio

async def task(name: str, delay: float):
    print(f"{name} starting")
    await asyncio.sleep(delay)
    print(f"{name} finished")
    return f"{name} result"

async def main():
    # Run all tasks concurrently
    results = await asyncio.gather(
        task("A", 1),
        task("B", 2),
        task("C", 1.5),
    )
    print(f"Results: {results}")

asyncio.run(main())
# Total time: ~2 seconds (max delay)
```

### asyncio.gather() with Exceptions

```python
import asyncio

async def might_fail(n: int):
    await asyncio.sleep(0.1)
    if n == 2:
        raise ValueError(f"Task {n} failed!")
    return f"Task {n} succeeded"

async def main():
    # Without return_exceptions - first exception stops all
    try:
        results = await asyncio.gather(
            might_fail(1),
            might_fail(2),  # This will fail
            might_fail(3),
        )
    except ValueError as e:
        print(f"Error: {e}")
    
    # With return_exceptions - collect all results/exceptions
    results = await asyncio.gather(
        might_fail(1),
        might_fail(2),
        might_fail(3),
        return_exceptions=True
    )
    print(results)  # ['Task 1 succeeded', ValueError(...), 'Task 3 succeeded']

asyncio.run(main())
```

### asyncio.create_task() - Fire and Forget

```python
import asyncio

async def background_task():
    while True:
        print("Background running...")
        await asyncio.sleep(1)

async def main():
    # Start task but don't wait for it
    task = asyncio.create_task(background_task())
    
    # Do other work
    for i in range(5):
        print(f"Main work {i}")
        await asyncio.sleep(0.5)
    
    # Cancel background task
    task.cancel()
    try:
        await task
    except asyncio.CancelledError:
        print("Background task cancelled")

asyncio.run(main())
```

### asyncio.wait() - More Control

```python
import asyncio

async def task(n: int, delay: float):
    await asyncio.sleep(delay)
    return f"Task {n}"

async def main():
    tasks = [
        asyncio.create_task(task(1, 2)),
        asyncio.create_task(task(2, 1)),
        asyncio.create_task(task(3, 3)),
    ]
    
    # Wait for first to complete
    done, pending = await asyncio.wait(
        tasks,
        return_when=asyncio.FIRST_COMPLETED
    )
    print(f"First done: {[t.result() for t in done]}")
    print(f"Still pending: {len(pending)}")
    
    # Wait for rest
    done, pending = await asyncio.wait(pending)
    print(f"All done: {[t.result() for t in done]}")

asyncio.run(main())
```

### asyncio.as_completed() - Process as Ready

```python
import asyncio

async def fetch(url: str, delay: float):
    await asyncio.sleep(delay)
    return f"Data from {url}"

async def main():
    tasks = [
        fetch("slow.com", 2),
        fetch("fast.com", 0.5),
        fetch("medium.com", 1),
    ]
    
    # Process results as they complete (fastest first)
    for coro in asyncio.as_completed(tasks):
        result = await coro
        print(result)

asyncio.run(main())
# Output order:
# Data from fast.com (after 0.5s)
# Data from medium.com (after 1s)
# Data from slow.com (after 2s)
```

---

## 3. Synchronization Primitives

### asyncio.Lock

```python
import asyncio

class BankAccount:
    def __init__(self):
        self.balance = 100
        self.lock = asyncio.Lock()
    
    async def transfer(self, amount: int, name: str):
        async with self.lock:  # Only one at a time
            print(f"{name}: Checking balance ({self.balance})")
            await asyncio.sleep(0.1)  # Simulate processing
            
            if self.balance >= amount:
                self.balance -= amount
                print(f"{name}: Withdrew {amount}, new balance: {self.balance}")
                return True
            return False

async def main():
    account = BankAccount()
    
    # Multiple concurrent transfers
    results = await asyncio.gather(
        account.transfer(60, "Alice"),
        account.transfer(60, "Bob"),
    )
    print(f"Results: {results}")  # [True, False] - only one succeeds

asyncio.run(main())
```

### asyncio.Semaphore

```python
import asyncio

async def fetch_with_limit(url: str, semaphore: asyncio.Semaphore):
    async with semaphore:  # Max N concurrent
        print(f"Fetching {url}")
        await asyncio.sleep(1)
        return f"Data from {url}"

async def main():
    # Only 3 concurrent requests
    semaphore = asyncio.Semaphore(3)
    
    urls = [f"url{i}" for i in range(10)]
    tasks = [fetch_with_limit(url, semaphore) for url in urls]
    
    results = await asyncio.gather(*tasks)
    print(f"Fetched {len(results)} URLs")

asyncio.run(main())
```

### asyncio.Event

```python
import asyncio

async def waiter(event: asyncio.Event, name: str):
    print(f"{name} waiting for event...")
    await event.wait()
    print(f"{name} got the event!")

async def setter(event: asyncio.Event):
    await asyncio.sleep(2)
    print("Setting event!")
    event.set()

async def main():
    event = asyncio.Event()
    
    await asyncio.gather(
        waiter(event, "Waiter-1"),
        waiter(event, "Waiter-2"),
        waiter(event, "Waiter-3"),
        setter(event),
    )

asyncio.run(main())
```

### asyncio.Condition

```python
import asyncio

async def producer(condition: asyncio.Condition, items: list):
    for i in range(5):
        await asyncio.sleep(0.5)
        async with condition:
            items.append(f"item-{i}")
            print(f"Produced item-{i}")
            condition.notify()  # Wake one consumer

async def consumer(condition: asyncio.Condition, items: list, name: str):
    while True:
        async with condition:
            while not items:
                await condition.wait()
            item = items.pop(0)
            print(f"{name} consumed {item}")
            if item == "item-4":
                return

async def main():
    condition = asyncio.Condition()
    items = []
    
    await asyncio.gather(
        producer(condition, items),
        consumer(condition, items, "Consumer-1"),
        consumer(condition, items, "Consumer-2"),
    )

asyncio.run(main())
```

---

## 4. Async Queues

### Basic Queue Operations

```python
import asyncio

async def producer(queue: asyncio.Queue):
    for i in range(10):
        await asyncio.sleep(0.1)
        await queue.put(f"item-{i}")
        print(f"Produced item-{i}")
    await queue.put(None)  # Sentinel to stop consumer

async def consumer(queue: asyncio.Queue):
    while True:
        item = await queue.get()
        if item is None:
            break
        print(f"Consumed {item}")
        queue.task_done()

async def main():
    queue = asyncio.Queue(maxsize=5)
    
    await asyncio.gather(
        producer(queue),
        consumer(queue),
    )

asyncio.run(main())
```

### Priority Queue

```python
import asyncio
from dataclasses import dataclass, field

@dataclass(order=True)
class PrioritizedItem:
    priority: int
    item: str = field(compare=False)

async def main():
    queue = asyncio.PriorityQueue()
    
    # Add items with priority (lower = higher priority)
    await queue.put(PrioritizedItem(3, "Low priority"))
    await queue.put(PrioritizedItem(1, "High priority"))
    await queue.put(PrioritizedItem(2, "Medium priority"))
    
    # Process in priority order
    while not queue.empty():
        item = await queue.get()
        print(f"Processing: {item.item} (priority {item.priority})")

asyncio.run(main())
```

### Multiple Producers and Consumers

```python
import asyncio
import random

async def producer(queue: asyncio.Queue, producer_id: int):
    for i in range(5):
        await asyncio.sleep(random.uniform(0.1, 0.3))
        item = f"P{producer_id}-{i}"
        await queue.put(item)
        print(f"Producer {producer_id} put {item}")

async def consumer(queue: asyncio.Queue, consumer_id: int):
    while True:
        try:
            item = await asyncio.wait_for(queue.get(), timeout=1.0)
            print(f"Consumer {consumer_id} got {item}")
            queue.task_done()
        except asyncio.TimeoutError:
            print(f"Consumer {consumer_id} timeout, exiting")
            return

async def main():
    queue = asyncio.Queue()
    
    producers = [producer(queue, i) for i in range(2)]
    consumers = [consumer(queue, i) for i in range(3)]
    
    await asyncio.gather(*producers, *consumers)

asyncio.run(main())
```

---

## 5. Timeouts and Cancellation

### asyncio.wait_for() - Timeout

```python
import asyncio

async def slow_operation():
    await asyncio.sleep(10)
    return "completed"

async def main():
    try:
        result = await asyncio.wait_for(slow_operation(), timeout=2.0)
        print(result)
    except asyncio.TimeoutError:
        print("Operation timed out!")

asyncio.run(main())
```

### asyncio.timeout() - Context Manager (Python 3.11+)

```python
import asyncio

async def main():
    try:
        async with asyncio.timeout(2.0):
            await asyncio.sleep(10)
    except TimeoutError:
        print("Timed out!")

asyncio.run(main())
```

### Task Cancellation

```python
import asyncio

async def long_running():
    try:
        print("Starting long operation...")
        await asyncio.sleep(10)
        print("Completed!")
    except asyncio.CancelledError:
        print("Task was cancelled, cleaning up...")
        await asyncio.sleep(0.1)  # Cleanup
        raise  # Re-raise to propagate

async def main():
    task = asyncio.create_task(long_running())
    
    await asyncio.sleep(1)
    
    print("Cancelling task...")
    task.cancel()
    
    try:
        await task
    except asyncio.CancelledError:
        print("Task successfully cancelled")

asyncio.run(main())
```

### asyncio.shield() - Protect from Cancellation

```python
import asyncio

async def critical_operation():
    print("Critical operation starting...")
    await asyncio.sleep(2)
    print("Critical operation done!")
    return "important result"

async def main():
    task = asyncio.create_task(
        asyncio.shield(critical_operation())
    )
    
    await asyncio.sleep(0.5)
    task.cancel()  # Try to cancel
    
    try:
        result = await task
    except asyncio.CancelledError:
        print("Task was cancelled, but shielded operation continues")
        # The shielded operation keeps running!

asyncio.run(main())
```

---

## 6. Practical Examples

### HTTP Client with aiohttp

```python
import asyncio
import aiohttp

async def fetch(session: aiohttp.ClientSession, url: str):
    async with session.get(url) as response:
        return await response.text()

async def fetch_all(urls: list):
    async with aiohttp.ClientSession() as session:
        tasks = [fetch(session, url) for url in urls]
        return await asyncio.gather(*tasks)

async def main():
    urls = [
        "https://httpbin.org/get",
        "https://httpbin.org/ip",
        "https://httpbin.org/user-agent",
    ]
    results = await fetch_all(urls)
    print(f"Fetched {len(results)} pages")

# asyncio.run(main())
```

### Async File Operations

```python
import asyncio
import aiofiles

async def read_file(path: str):
    async with aiofiles.open(path, 'r') as f:
        return await f.read()

async def write_file(path: str, content: str):
    async with aiofiles.open(path, 'w') as f:
        await f.write(content)

async def process_files(input_paths: list, output_dir: str):
    # Read all files concurrently
    contents = await asyncio.gather(
        *[read_file(p) for p in input_paths]
    )
    
    # Process
    processed = [content.upper() for content in contents]
    
    # Write all files concurrently
    output_paths = [f"{output_dir}/output_{i}.txt" for i in range(len(processed))]
    await asyncio.gather(
        *[write_file(p, c) for p, c in zip(output_paths, processed)]
    )

# asyncio.run(process_files(['file1.txt', 'file2.txt'], 'output'))
```

### Rate-Limited API Calls

```python
import asyncio
from datetime import datetime

class RateLimiter:
    def __init__(self, calls_per_second: float):
        self.calls_per_second = calls_per_second
        self.semaphore = asyncio.Semaphore(int(calls_per_second))
        self._reset_task = None
    
    async def __aenter__(self):
        await self.semaphore.acquire()
        return self
    
    async def __aexit__(self, *args):
        asyncio.create_task(self._release_after_delay())
    
    async def _release_after_delay(self):
        await asyncio.sleep(1.0 / self.calls_per_second)
        self.semaphore.release()

async def api_call(rate_limiter: RateLimiter, n: int):
    async with rate_limiter:
        print(f"{datetime.now()}: API call {n}")
        await asyncio.sleep(0.1)  # Simulate API call
        return f"Result {n}"

async def main():
    rate_limiter = RateLimiter(calls_per_second=2)
    
    tasks = [api_call(rate_limiter, i) for i in range(10)]
    results = await asyncio.gather(*tasks)
    print(f"Completed {len(results)} calls")

asyncio.run(main())
```

### Async Context Manager for Resources

```python
import asyncio

class AsyncDatabase:
    async def __aenter__(self):
        print("Connecting to database...")
        await asyncio.sleep(0.5)  # Simulate connection
        print("Connected!")
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        print("Closing database connection...")
        await asyncio.sleep(0.1)  # Simulate cleanup
        print("Connection closed")
        return False
    
    async def query(self, sql: str):
        await asyncio.sleep(0.1)  # Simulate query
        return [{"id": 1, "name": "Result"}]

async def main():
    async with AsyncDatabase() as db:
        results = await db.query("SELECT * FROM users")
        print(f"Got {len(results)} results")

asyncio.run(main())
```

---

## Quick Reference

```python
import asyncio

# Running
asyncio.run(main())
task = asyncio.create_task(coro())

# Gathering
results = await asyncio.gather(coro1(), coro2(), coro3())
done, pending = await asyncio.wait(tasks)
for coro in asyncio.as_completed(coros):
    result = await coro

# Timing
await asyncio.sleep(1)
await asyncio.wait_for(coro(), timeout=5)
async with asyncio.timeout(5):  # Python 3.11+
    await coro()

# Synchronization
lock = asyncio.Lock()
sem = asyncio.Semaphore(5)
event = asyncio.Event()
cond = asyncio.Condition()
queue = asyncio.Queue()

# Cancellation
task.cancel()
await asyncio.shield(coro())  # Protect from cancel

# Blocking code
await asyncio.to_thread(blocking_func)
await loop.run_in_executor(None, blocking_func)
```

---

*Next: [Deep Dive](_03_deep_dive.md)*
