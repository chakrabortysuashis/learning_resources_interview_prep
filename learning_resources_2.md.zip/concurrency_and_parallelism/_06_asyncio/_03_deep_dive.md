# Asyncio in Python - Deep Dive

## Table of Contents
1. [TaskGroup and Structured Concurrency](#1-taskgroup-and-structured-concurrency)
2. [Async Iterators and Generators](#2-async-iterators-and-generators)
3. [Streams API](#3-streams-api)
4. [Subprocesses](#4-subprocesses)
5. [Testing Async Code](#5-testing-async-code)
6. [Performance and Best Practices](#6-performance-and-best-practices)
7. [Common Patterns](#7-common-patterns)

---

## 1. TaskGroup and Structured Concurrency

### TaskGroup (Python 3.11+)

```python
import asyncio

async def task(name: str, delay: float):
    await asyncio.sleep(delay)
    print(f"{name} completed")
    return f"{name} result"

async def main():
    # TaskGroup ensures all tasks complete or all are cancelled
    async with asyncio.TaskGroup() as tg:
        task1 = tg.create_task(task("A", 1))
        task2 = tg.create_task(task("B", 2))
        task3 = tg.create_task(task("C", 1.5))
    
    # All tasks are guaranteed complete here
    print(f"Results: {task1.result()}, {task2.result()}, {task3.result()}")

asyncio.run(main())
```

### Exception Handling in TaskGroup

```python
import asyncio

async def failing_task(n: int):
    await asyncio.sleep(0.1 * n)
    if n == 2:
        raise ValueError(f"Task {n} failed!")
    return f"Task {n} ok"

async def main():
    try:
        async with asyncio.TaskGroup() as tg:
            t1 = tg.create_task(failing_task(1))
            t2 = tg.create_task(failing_task(2))  # Will fail
            t3 = tg.create_task(failing_task(3))
    except* ValueError as eg:  # Python 3.11+ ExceptionGroup
        print(f"Caught errors: {eg.exceptions}")
        # Other tasks are automatically cancelled!

asyncio.run(main())
```

### Why TaskGroup Over gather()

```python
# gather() issues:
# 1. First exception cancels nothing (unless return_exceptions=True)
# 2. No structured cleanup guarantee

# TaskGroup benefits:
# 1. If any task fails, ALL tasks are cancelled
# 2. Context manager ensures cleanup
# 3. Better error handling with ExceptionGroup

async def structured_concurrency():
    async with asyncio.TaskGroup() as tg:
        tg.create_task(operation1())
        tg.create_task(operation2())
        # If we exit the 'with' block early (exception, return),
        # ALL tasks are cancelled and awaited
```

---

## 2. Async Iterators and Generators

### Async Iterator Protocol

```python
import asyncio

class AsyncCounter:
    """Custom async iterator"""
    
    def __init__(self, stop: int):
        self.current = 0
        self.stop = stop
    
    def __aiter__(self):
        return self
    
    async def __anext__(self):
        if self.current >= self.stop:
            raise StopAsyncIteration
        await asyncio.sleep(0.1)
        value = self.current
        self.current += 1
        return value

async def main():
    async for number in AsyncCounter(5):
        print(number)

asyncio.run(main())
```

### Async Generator (Simpler)

```python
import asyncio

async def async_range(start: int, stop: int):
    """Async generator - simpler than async iterator"""
    for i in range(start, stop):
        await asyncio.sleep(0.1)
        yield i

async def fetch_pages(urls: list):
    """Yield results as they arrive"""
    for url in urls:
        await asyncio.sleep(0.5)  # Simulate fetch
        yield f"Data from {url}"

async def main():
    # Using async generator
    async for n in async_range(0, 5):
        print(n)
    
    # Collecting from async generator
    urls = ["url1", "url2", "url3"]
    results = [result async for result in fetch_pages(urls)]
    print(results)

asyncio.run(main())
```

### Async Comprehensions

```python
import asyncio

async def get_data(n: int):
    await asyncio.sleep(0.1)
    return n * 2

async def main():
    # Async list comprehension
    results = [await get_data(n) for n in range(5)]
    print(results)  # [0, 2, 4, 6, 8]
    
    # Async generator expression
    async def async_numbers():
        for i in range(5):
            await asyncio.sleep(0.1)
            yield i
    
    # Async comprehension with async for
    results = [n async for n in async_numbers() if n % 2 == 0]
    print(results)  # [0, 2, 4]

asyncio.run(main())
```

---

## 3. Streams API

### TCP Client

```python
import asyncio

async def tcp_client(message: str):
    reader, writer = await asyncio.open_connection('127.0.0.1', 8888)
    
    print(f"Sending: {message}")
    writer.write(message.encode())
    await writer.drain()
    
    data = await reader.read(100)
    print(f"Received: {data.decode()}")
    
    writer.close()
    await writer.wait_closed()

# asyncio.run(tcp_client("Hello"))
```

### TCP Server

```python
import asyncio

async def handle_client(reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
    addr = writer.get_extra_info('peername')
    print(f"Connection from {addr}")
    
    while True:
        data = await reader.read(100)
        if not data:
            break
        
        message = data.decode()
        print(f"Received {message} from {addr}")
        
        response = f"Echo: {message}"
        writer.write(response.encode())
        await writer.drain()
    
    print(f"Connection closed from {addr}")
    writer.close()
    await writer.wait_closed()

async def main():
    server = await asyncio.start_server(
        handle_client, '127.0.0.1', 8888
    )
    
    addr = server.sockets[0].getsockname()
    print(f"Serving on {addr}")
    
    async with server:
        await server.serve_forever()

# asyncio.run(main())
```

### Unix Socket

```python
import asyncio
import os

async def unix_socket_server():
    path = '/tmp/asyncio_socket'
    
    # Remove if exists
    if os.path.exists(path):
        os.unlink(path)
    
    server = await asyncio.start_unix_server(
        handle_client, path=path
    )
    
    async with server:
        await server.serve_forever()

async def unix_socket_client():
    reader, writer = await asyncio.open_unix_connection('/tmp/asyncio_socket')
    writer.write(b"Hello Unix!")
    await writer.drain()
    
    response = await reader.read(100)
    print(f"Response: {response.decode()}")
    
    writer.close()
    await writer.wait_closed()
```

---

## 4. Subprocesses

### Running Shell Commands

```python
import asyncio

async def run_command(cmd: str):
    proc = await asyncio.create_subprocess_shell(
        cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )
    
    stdout, stderr = await proc.communicate()
    
    print(f"Command: {cmd}")
    print(f"Return code: {proc.returncode}")
    print(f"stdout: {stdout.decode()}")
    if stderr:
        print(f"stderr: {stderr.decode()}")
    
    return proc.returncode

async def main():
    await run_command("echo Hello World")
    await run_command("ls -la")

asyncio.run(main())
```

### Running Multiple Commands Concurrently

```python
import asyncio

async def run(cmd: str):
    proc = await asyncio.create_subprocess_shell(
        cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )
    stdout, stderr = await proc.communicate()
    return cmd, proc.returncode, stdout.decode()

async def main():
    commands = [
        "sleep 1 && echo 'First'",
        "sleep 2 && echo 'Second'",
        "sleep 1 && echo 'Third'",
    ]
    
    results = await asyncio.gather(*[run(cmd) for cmd in commands])
    
    for cmd, code, output in results:
        print(f"{cmd}: {output.strip()}")

asyncio.run(main())
# Total time: ~2 seconds (not 4 seconds!)
```

### Interactive Process

```python
import asyncio

async def interactive_process():
    proc = await asyncio.create_subprocess_exec(
        'python', '-i',
        stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )
    
    # Send commands
    proc.stdin.write(b"print('Hello from Python!')\n")
    await proc.stdin.drain()
    
    proc.stdin.write(b"exit()\n")
    await proc.stdin.drain()
    
    stdout, stderr = await proc.communicate()
    print(f"Output: {stdout.decode()}")

asyncio.run(interactive_process())
```

---

## 5. Testing Async Code

### Using pytest-asyncio

```python
# pip install pytest-asyncio

import pytest
import asyncio

async def fetch_data():
    await asyncio.sleep(0.1)
    return {"key": "value"}

async def process_data(data):
    await asyncio.sleep(0.1)
    return data["key"].upper()

# Test with pytest-asyncio
@pytest.mark.asyncio
async def test_fetch_data():
    result = await fetch_data()
    assert result == {"key": "value"}

@pytest.mark.asyncio
async def test_process_data():
    data = await fetch_data()
    result = await process_data(data)
    assert result == "VALUE"

@pytest.mark.asyncio
async def test_concurrent_operations():
    results = await asyncio.gather(
        fetch_data(),
        fetch_data(),
        fetch_data(),
    )
    assert len(results) == 3
```

### Mocking Async Functions

```python
import pytest
from unittest.mock import AsyncMock, patch

async def api_client():
    # In real code, this would make HTTP requests
    pass

async def service_function():
    data = await api_client()
    return process(data)

@pytest.mark.asyncio
async def test_with_mock():
    # Create async mock
    mock_client = AsyncMock(return_value={"data": "mocked"})
    
    with patch('module.api_client', mock_client):
        result = await service_function()
    
    mock_client.assert_called_once()
    assert result == expected_value
```

### Testing Timeouts

```python
import pytest
import asyncio

@pytest.mark.asyncio
async def test_timeout():
    async def slow_operation():
        await asyncio.sleep(10)
    
    with pytest.raises(asyncio.TimeoutError):
        await asyncio.wait_for(slow_operation(), timeout=0.1)
```

---

## 6. Performance and Best Practices

### Avoiding Common Mistakes

```python
import asyncio

# WRONG: Sequential when could be concurrent
async def bad_pattern():
    result1 = await fetch(url1)  # Wait
    result2 = await fetch(url2)  # Then wait
    result3 = await fetch(url3)  # Then wait
    return [result1, result2, result3]

# RIGHT: Concurrent
async def good_pattern():
    return await asyncio.gather(
        fetch(url1),
        fetch(url2),
        fetch(url3),
    )

# WRONG: Blocking call in coroutine
async def bad_blocking():
    import time
    time.sleep(1)  # Blocks entire event loop!

# RIGHT: Use async sleep or run_in_executor
async def good_nonblocking():
    await asyncio.sleep(1)  # Non-blocking
    # OR
    await asyncio.to_thread(blocking_function)

# WRONG: Creating tasks without tracking
async def bad_fire_and_forget():
    asyncio.create_task(background_work())  # May be garbage collected!

# RIGHT: Keep reference or use TaskGroup
async def good_task_management():
    async with asyncio.TaskGroup() as tg:
        tg.create_task(background_work())
```

### Connection Pooling

```python
import asyncio
import aiohttp

# WRONG: New session per request
async def bad_fetch(url):
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as response:
            return await response.text()

# RIGHT: Reuse session
async def fetch_all(urls):
    async with aiohttp.ClientSession() as session:
        tasks = [fetch_with_session(session, url) for url in urls]
        return await asyncio.gather(*tasks)

async def fetch_with_session(session, url):
    async with session.get(url) as response:
        return await response.text()
```

### Using uvloop

```python
# pip install uvloop

import asyncio

# 2-4x faster event loop
try:
    import uvloop
    asyncio.set_event_loop_policy(uvloop.EventLoopPolicy())
except ImportError:
    pass  # Use default loop

async def main():
    # Your async code benefits from faster loop
    pass

asyncio.run(main())
```

---

## 7. Common Patterns

### Retry with Exponential Backoff

```python
import asyncio
import random

async def retry_with_backoff(
    coro_func,
    max_retries: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 60.0,
    exceptions: tuple = (Exception,)
):
    delay = base_delay
    
    for attempt in range(max_retries):
        try:
            return await coro_func()
        except exceptions as e:
            if attempt == max_retries - 1:
                raise
            
            # Add jitter
            jitter = random.uniform(0, delay * 0.1)
            sleep_time = min(delay + jitter, max_delay)
            
            print(f"Attempt {attempt + 1} failed, retrying in {sleep_time:.2f}s")
            await asyncio.sleep(sleep_time)
            
            delay *= 2  # Exponential backoff
```

### Circuit Breaker

```python
import asyncio
from enum import Enum
from datetime import datetime, timedelta

class CircuitState(Enum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"

class CircuitBreaker:
    def __init__(self, failure_threshold: int = 5, recovery_timeout: float = 30):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.failures = 0
        self.state = CircuitState.CLOSED
        self.last_failure_time = None
    
    async def call(self, coro_func):
        if self.state == CircuitState.OPEN:
            if self._should_try_recovery():
                self.state = CircuitState.HALF_OPEN
            else:
                raise Exception("Circuit breaker is OPEN")
        
        try:
            result = await coro_func()
            self._on_success()
            return result
        except Exception as e:
            self._on_failure()
            raise
    
    def _on_success(self):
        self.failures = 0
        self.state = CircuitState.CLOSED
    
    def _on_failure(self):
        self.failures += 1
        self.last_failure_time = datetime.now()
        
        if self.failures >= self.failure_threshold:
            self.state = CircuitState.OPEN
    
    def _should_try_recovery(self):
        if self.last_failure_time is None:
            return True
        return datetime.now() - self.last_failure_time > timedelta(seconds=self.recovery_timeout)
```

### Async Cache

```python
import asyncio
from functools import wraps
from typing import Dict, Any
import time

def async_cache(ttl_seconds: float = 300):
    """Async cache decorator with TTL"""
    def decorator(func):
        cache: Dict[str, tuple] = {}
        lock = asyncio.Lock()
        
        @wraps(func)
        async def wrapper(*args, **kwargs):
            key = str(args) + str(kwargs)
            
            async with lock:
                if key in cache:
                    result, timestamp = cache[key]
                    if time.time() - timestamp < ttl_seconds:
                        return result
            
            result = await func(*args, **kwargs)
            
            async with lock:
                cache[key] = (result, time.time())
            
            return result
        
        return wrapper
    return decorator

@async_cache(ttl_seconds=60)
async def expensive_operation(param):
    await asyncio.sleep(1)
    return f"Result for {param}"
```

### Graceful Shutdown

```python
import asyncio
import signal

class GracefulShutdown:
    def __init__(self):
        self.shutdown_event = asyncio.Event()
        self.tasks = []
    
    def add_task(self, task):
        self.tasks.append(task)
    
    async def shutdown(self):
        print("Shutting down...")
        self.shutdown_event.set()
        
        for task in self.tasks:
            task.cancel()
        
        await asyncio.gather(*self.tasks, return_exceptions=True)
        print("Shutdown complete")
    
    async def run(self, main_coro):
        loop = asyncio.get_running_loop()
        
        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(
                sig,
                lambda: asyncio.create_task(self.shutdown())
            )
        
        await main_coro

# Usage
async def background_worker(shutdown: GracefulShutdown):
    while not shutdown.shutdown_event.is_set():
        print("Working...")
        await asyncio.sleep(1)
    print("Worker stopped")

async def main():
    shutdown = GracefulShutdown()
    
    task = asyncio.create_task(background_worker(shutdown))
    shutdown.add_task(task)
    
    # Run forever until signal
    await shutdown.shutdown_event.wait()

# asyncio.run(main())  # Unix only for signal handlers
```

---

## Summary

```
┌─────────────────────────────────────────────────────────────────────┐
│                    ASYNCIO DEEP DIVE SUMMARY                         │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  STRUCTURED CONCURRENCY (Python 3.11+):                             │
│  • TaskGroup for automatic cleanup                                  │
│  • ExceptionGroup for error handling                                │
│                                                                     │
│  ASYNC ITERATION:                                                   │
│  • async for / async with                                           │
│  • Async generators (yield in async def)                            │
│  • Async comprehensions                                             │
│                                                                     │
│  STREAMS:                                                           │
│  • open_connection() for TCP client                                 │
│  • start_server() for TCP server                                    │
│  • StreamReader/StreamWriter                                        │
│                                                                     │
│  SUBPROCESSES:                                                      │
│  • create_subprocess_shell/exec                                     │
│  • Concurrent command execution                                     │
│                                                                     │
│  BEST PRACTICES:                                                    │
│  • Use gather() for concurrent tasks                                │
│  • Reuse connections/sessions                                       │
│  • Never block (use to_thread for blocking)                        │
│  • Consider uvloop for performance                                  │
│  • Use TaskGroup for structured concurrency                         │
│                                                                     │
│  PATTERNS:                                                          │
│  • Retry with backoff                                               │
│  • Circuit breaker                                                  │
│  • Async caching                                                    │
│  • Graceful shutdown                                                │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

*Next: [Interview Questions](_04_interview_questions.md)*
