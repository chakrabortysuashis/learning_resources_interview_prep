# Asyncio in Python - Interview Questions

## Table of Contents
1. [Basic Questions](#basic-questions)
2. [Intermediate Questions](#intermediate-questions)
3. [Advanced Questions](#advanced-questions)
4. [Scenario-Based Questions](#scenario-based-questions)
5. [Code Analysis Questions](#code-analysis-questions)

---

## Basic Questions

### Q1: What is asyncio and when should you use it?

<details>
<summary>Answer</summary>

**Asyncio** is Python's library for asynchronous programming, providing:
- Event loop for task scheduling
- Coroutines (async/await syntax)
- Concurrent execution utilities

**Use it when:**
- I/O-bound operations (network, files, databases)
- High concurrency needed (thousands of connections)
- Non-blocking behavior required

**Don't use for:**
- CPU-bound tasks (use multiprocessing)
- Simple sequential scripts
- Legacy blocking libraries (without async versions)

```python
import asyncio

async def fetch_all(urls):
    # Perfect use case: many network requests
    results = await asyncio.gather(
        *(fetch(url) for url in urls)
    )
    return results
```

</details>

---

### Q2: What's the difference between `asyncio.run()` and `asyncio.create_task()`?

<details>
<summary>Answer</summary>

| Function | Purpose | When to Use |
|----------|---------|-------------|
| `asyncio.run()` | Entry point from sync code | Start async program |
| `create_task()` | Schedule coroutine inside async | Run concurrently |

```python
import asyncio

async def work():
    await asyncio.sleep(1)
    return "done"

# asyncio.run() - entry point
async def main():
    # create_task() - schedule concurrent execution
    task1 = asyncio.create_task(work())
    task2 = asyncio.create_task(work())
    
    # Both run concurrently
    results = await asyncio.gather(task1, task2)

# Main entry from sync code
asyncio.run(main())
```

**Key differences:**
- `run()`: Creates event loop, runs until complete, closes loop
- `create_task()`: Returns immediately, task starts running, must await later

</details>

---

### Q3: What is the difference between `gather()` and `wait()`?

<details>
<summary>Answer</summary>

| Feature | gather() | wait() |
|---------|----------|--------|
| **Returns** | List of results | (done, pending) sets |
| **Order** | Preserves input order | Completion order |
| **Exceptions** | Can use return_exceptions | Must handle manually |
| **Timeout** | No timeout parameter | Has timeout parameter |
| **Partial results** | All or nothing | Can get completed ones |

```python
import asyncio

# gather() - simple, ordered results
results = await asyncio.gather(
    task1(), task2(), task3(),
    return_exceptions=True
)

# wait() - more control
done, pending = await asyncio.wait(
    tasks,
    timeout=5.0,
    return_when=asyncio.FIRST_COMPLETED
)

# Process completed tasks
for task in done:
    try:
        result = task.result()
    except Exception as e:
        print(f"Error: {e}")
```

**Use gather():** When you need all results in order
**Use wait():** When you need timeout, partial results, or first-completed

</details>

---

### Q4: How do you handle exceptions in asyncio?

<details>
<summary>Answer</summary>

**Method 1: Try-except in coroutine**
```python
async def safe_fetch(url):
    try:
        return await fetch(url)
    except Exception as e:
        return f"Error: {e}"
```

**Method 2: gather with return_exceptions**
```python
results = await asyncio.gather(
    task1(), task2(), task3(),
    return_exceptions=True
)
for r in results:
    if isinstance(r, Exception):
        print(f"Error: {r}")
```

**Method 3: TaskGroup (Python 3.11+)**
```python
try:
    async with asyncio.TaskGroup() as tg:
        tg.create_task(task1())
        tg.create_task(task2())
except* ValueError as eg:
    print(f"Caught: {eg.exceptions}")
```

**Method 4: Exception handler for unhandled**
```python
def handler(loop, context):
    print(f"Caught: {context['exception']}")

loop = asyncio.get_running_loop()
loop.set_exception_handler(handler)
```

</details>

---

## Intermediate Questions

### Q5: Explain asyncio.Semaphore and when to use it.

<details>
<summary>Answer</summary>

**Semaphore** limits concurrent access to a resource.

```python
import asyncio

# Limit to 5 concurrent requests
semaphore = asyncio.Semaphore(5)

async def fetch_with_limit(url):
    async with semaphore:  # Acquire, wait if at limit
        print(f"Fetching {url}")
        await asyncio.sleep(1)
        return f"Data from {url}"

async def main():
    urls = [f"url{i}" for i in range(20)]
    # Only 5 fetches run at a time
    results = await asyncio.gather(
        *(fetch_with_limit(url) for url in urls)
    )
```

**Use cases:**
- Rate limiting API calls
- Limiting database connections
- Controlling concurrent file operations
- Preventing resource exhaustion

**BoundedSemaphore:** Raises error if released too many times (catches bugs)

</details>

---

### Q6: What is asyncio.Queue and how does it differ from queue.Queue?

<details>
<summary>Answer</summary>

| Feature | asyncio.Queue | queue.Queue |
|---------|---------------|-------------|
| **For** | Async code | Threading |
| **put/get** | await required | Blocking |
| **Thread-safe** | No (single-threaded) | Yes |
| **Context** | Event loop | Multiple threads |

```python
import asyncio

async def producer(queue):
    for i in range(5):
        await queue.put(f"item-{i}")
        await asyncio.sleep(0.1)
    await queue.put(None)  # Sentinel

async def consumer(queue):
    while True:
        item = await queue.get()
        if item is None:
            break
        print(f"Got: {item}")
        queue.task_done()

async def main():
    queue = asyncio.Queue(maxsize=10)
    await asyncio.gather(
        producer(queue),
        consumer(queue),
    )

asyncio.run(main())
```

**Types:**
- `Queue`: FIFO
- `PriorityQueue`: Priority-based
- `LifoQueue`: LIFO (stack)

</details>

---

### Q7: How do you run blocking code in asyncio?

<details>
<summary>Answer</summary>

**Problem:** Blocking calls freeze the entire event loop.

**Solution 1: asyncio.to_thread() (Python 3.9+)**
```python
import asyncio
import time

def blocking_io():
    time.sleep(2)
    return "result"

async def main():
    result = await asyncio.to_thread(blocking_io)
    print(result)
```

**Solution 2: run_in_executor()**
```python
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor

async def main():
    loop = asyncio.get_running_loop()
    
    # Thread pool (I/O-bound)
    result = await loop.run_in_executor(None, blocking_io)
    
    # Process pool (CPU-bound)
    with ProcessPoolExecutor() as pool:
        result = await loop.run_in_executor(pool, cpu_intensive)
```

**When to use:**
- `to_thread`: Simple, Python 3.9+
- `ThreadPoolExecutor`: I/O-bound, custom pool
- `ProcessPoolExecutor`: CPU-bound work

</details>

---

### Q8: Explain asyncio.shield() and when to use it.

<details>
<summary>Answer</summary>

**shield()** protects a coroutine from cancellation.

```python
import asyncio

async def critical_operation():
    print("Starting critical work...")
    await asyncio.sleep(2)
    print("Critical work done!")
    return "important result"

async def main():
    task = asyncio.create_task(
        asyncio.shield(critical_operation())
    )
    
    await asyncio.sleep(0.5)
    task.cancel()  # Try to cancel
    
    try:
        await task
    except asyncio.CancelledError:
        print("Task cancelled, but shielded operation continues!")
        # The critical_operation keeps running
```

**Use cases:**
- Database transactions that must complete
- Critical cleanup operations
- Operations that shouldn't be interrupted

**Warning:** The shielded coroutine continues even if parent is cancelled!

</details>

---

## Advanced Questions

### Q9: What is TaskGroup and how does it enable structured concurrency?

<details>
<summary>Answer</summary>

**TaskGroup** (Python 3.11+) provides structured concurrency:

```python
import asyncio

async def task(n):
    if n == 2:
        raise ValueError(f"Task {n} failed")
    await asyncio.sleep(n * 0.1)
    return f"Task {n} done"

async def main():
    try:
        async with asyncio.TaskGroup() as tg:
            t1 = tg.create_task(task(1))
            t2 = tg.create_task(task(2))  # Fails
            t3 = tg.create_task(task(3))
    except* ValueError as eg:
        print(f"Errors: {eg.exceptions}")
        # t1 and t3 are automatically cancelled!
```

**Benefits over gather():**
1. **Automatic cleanup:** If any task fails, all others are cancelled
2. **Guaranteed completion:** When exiting `async with`, all tasks are done
3. **Better error handling:** ExceptionGroup collects all errors
4. **Structured lifetime:** Tasks can't outlive the TaskGroup

**Structured concurrency principle:** Tasks have clear parent-child relationships and lifetimes.

</details>

---

### Q10: How do async context managers and iterators work?

<details>
<summary>Answer</summary>

**Async Context Manager (`async with`):**
```python
class AsyncResource:
    async def __aenter__(self):
        await self.connect()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.disconnect()
        return False

async with AsyncResource() as resource:
    await resource.do_work()
```

**Async Iterator (`async for`):**
```python
class AsyncIterator:
    def __aiter__(self):
        return self
    
    async def __anext__(self):
        if condition:
            raise StopAsyncIteration
        return await get_next_item()

async for item in AsyncIterator():
    process(item)
```

**Async Generator (simpler):**
```python
async def async_gen():
    for i in range(5):
        await asyncio.sleep(0.1)
        yield i

async for value in async_gen():
    print(value)
```

**Async Comprehension:**
```python
results = [x async for x in async_gen() if x % 2 == 0]
```

</details>

---

### Q11: How do you implement rate limiting in asyncio?

<details>
<summary>Answer</summary>

**Method 1: Simple Semaphore + Sleep**
```python
import asyncio

class RateLimiter:
    def __init__(self, rate: float):
        self.rate = rate  # calls per second
        self.semaphore = asyncio.Semaphore(1)
    
    async def acquire(self):
        await self.semaphore.acquire()
        # Release after delay
        asyncio.create_task(self._release())
    
    async def _release(self):
        await asyncio.sleep(1 / self.rate)
        self.semaphore.release()
```

**Method 2: Token Bucket**
```python
import asyncio
import time

class TokenBucket:
    def __init__(self, rate: float, capacity: float):
        self.rate = rate
        self.capacity = capacity
        self.tokens = capacity
        self.last_update = time.monotonic()
        self.lock = asyncio.Lock()
    
    async def acquire(self, tokens: int = 1):
        async with self.lock:
            now = time.monotonic()
            self.tokens = min(
                self.capacity,
                self.tokens + (now - self.last_update) * self.rate
            )
            self.last_update = now
            
            if self.tokens < tokens:
                wait_time = (tokens - self.tokens) / self.rate
                await asyncio.sleep(wait_time)
                self.tokens = 0
            else:
                self.tokens -= tokens
```

</details>

---

## Scenario-Based Questions

### Q12: Design an async web scraper that handles rate limiting and retries.

<details>
<summary>Answer</summary>

```python
import asyncio
import aiohttp
from typing import List, Dict
import random

class AsyncScraper:
    def __init__(self, max_concurrent: int = 10, rate_per_second: float = 5):
        self.semaphore = asyncio.Semaphore(max_concurrent)
        self.rate_limiter = asyncio.Semaphore(int(rate_per_second))
        self.session = None
    
    async def __aenter__(self):
        self.session = aiohttp.ClientSession()
        asyncio.create_task(self._refill_rate_tokens())
        return self
    
    async def __aexit__(self, *args):
        await self.session.close()
    
    async def _refill_rate_tokens(self):
        while True:
            await asyncio.sleep(1)
            for _ in range(5):  # Refill 5 tokens per second
                try:
                    self.rate_limiter.release()
                except ValueError:
                    pass
    
    async def fetch(self, url: str, max_retries: int = 3) -> Dict:
        async with self.semaphore:
            await self.rate_limiter.acquire()
            
            for attempt in range(max_retries):
                try:
                    async with self.session.get(url) as response:
                        if response.status == 200:
                            return {
                                "url": url,
                                "status": 200,
                                "data": await response.text()
                            }
                        elif response.status == 429:  # Rate limited
                            delay = 2 ** attempt + random.uniform(0, 1)
                            await asyncio.sleep(delay)
                except Exception as e:
                    if attempt == max_retries - 1:
                        return {"url": url, "error": str(e)}
                    await asyncio.sleep(2 ** attempt)
        
        return {"url": url, "error": "Max retries exceeded"}
    
    async def fetch_all(self, urls: List[str]) -> List[Dict]:
        return await asyncio.gather(
            *(self.fetch(url) for url in urls)
        )

async def main():
    urls = [f"https://example.com/{i}" for i in range(100)]
    
    async with AsyncScraper(max_concurrent=10, rate_per_second=5) as scraper:
        results = await scraper.fetch_all(urls)
    
    print(f"Fetched {len(results)} URLs")
```

</details>

---

### Q13: Implement an async producer-consumer pattern with multiple workers.

<details>
<summary>Answer</summary>

```python
import asyncio
import random

class AsyncWorkerPool:
    def __init__(self, num_workers: int):
        self.num_workers = num_workers
        self.queue = asyncio.Queue()
        self.results = asyncio.Queue()
        self.shutdown = asyncio.Event()
        self.workers = []
    
    async def worker(self, worker_id: int):
        while not self.shutdown.is_set():
            try:
                task = await asyncio.wait_for(
                    self.queue.get(), timeout=0.5
                )
            except asyncio.TimeoutError:
                continue
            
            try:
                result = await self.process(task)
                await self.results.put({
                    "task": task,
                    "result": result,
                    "worker": worker_id
                })
            except Exception as e:
                await self.results.put({
                    "task": task,
                    "error": str(e),
                    "worker": worker_id
                })
            finally:
                self.queue.task_done()
    
    async def process(self, task):
        # Simulate work
        await asyncio.sleep(random.uniform(0.1, 0.5))
        return task * 2
    
    async def start(self):
        self.workers = [
            asyncio.create_task(self.worker(i))
            for i in range(self.num_workers)
        ]
    
    async def stop(self):
        self.shutdown.set()
        await asyncio.gather(*self.workers)
    
    async def submit(self, tasks: list):
        for task in tasks:
            await self.queue.put(task)
    
    async def get_results(self, count: int):
        results = []
        for _ in range(count):
            result = await self.results.get()
            results.append(result)
        return results

async def main():
    pool = AsyncWorkerPool(num_workers=4)
    await pool.start()
    
    # Submit 20 tasks
    tasks = list(range(20))
    await pool.submit(tasks)
    
    # Wait for completion
    await pool.queue.join()
    
    # Get results
    results = await pool.get_results(20)
    print(f"Processed {len(results)} tasks")
    
    await pool.stop()

asyncio.run(main())
```

</details>

---

## Code Analysis Questions

### Q14: What's wrong with this code?

```python
import asyncio

async def fetch_data():
    await asyncio.sleep(1)
    return "data"

async def main():
    tasks = []
    for i in range(10):
        task = fetch_data()  # Problem here
        tasks.append(task)
    
    results = await asyncio.gather(*tasks)
    print(results)

asyncio.run(main())
```

<details>
<summary>Answer</summary>

**The code will work, but it's suboptimal.**

**Issue:** `fetch_data()` returns coroutine objects, not tasks. While `gather()` will handle them, they don't start running until `gather()` is called.

**Better approach:**
```python
async def main():
    # Create tasks - they start immediately
    tasks = [asyncio.create_task(fetch_data()) for i in range(10)]
    
    # Wait for all
    results = await asyncio.gather(*tasks)
```

**Why it matters:**
- With `create_task()`: Tasks start immediately, work begins
- Without: Coroutines are just objects, work starts only when awaited

For this specific case, the difference is minimal, but for more complex scenarios (where you do work between creating and awaiting), it matters.

</details>

---

### Q15: Will this cause issues? How would you fix it?

```python
import asyncio

results = []

async def worker(n):
    await asyncio.sleep(0.1)
    results.append(n * 2)

async def main():
    tasks = [asyncio.create_task(worker(i)) for i in range(100)]
    await asyncio.gather(*tasks)
    print(results)

asyncio.run(main())
```

<details>
<summary>Answer</summary>

**This code is actually SAFE in asyncio!**

**Why?** Asyncio is single-threaded. The `append()` operation happens during execution, and only one coroutine runs at a time. There are no race conditions.

However, there are **style issues:**

1. **Global mutable state** - harder to test and reason about
2. **No return values** - missing the point of gather

**Better approach:**
```python
import asyncio

async def worker(n):
    await asyncio.sleep(0.1)
    return n * 2  # Return instead of append

async def main():
    tasks = [asyncio.create_task(worker(i)) for i in range(100)]
    results = await asyncio.gather(*tasks)  # Collect results
    print(results)

asyncio.run(main())
```

**When it WOULD be a problem:**
- If using threading alongside asyncio
- If using `run_in_executor()` without a lock

</details>

---

## Quick Reference: Interview Cheat Sheet

```
┌─────────────────────────────────────────────────────────────────────┐
│                  ASYNCIO INTERVIEW CHEAT SHEET                       │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  WHEN TO USE:                                                       │
│  ✅ I/O-bound tasks (network, files, databases)                     │
│  ✅ High concurrency (thousands of connections)                     │
│  ❌ CPU-bound tasks (use multiprocessing)                           │
│                                                                     │
│  KEY FUNCTIONS:                                                     │
│  • asyncio.run(main()) - Entry point                                │
│  • create_task(coro) - Schedule concurrent execution                │
│  • gather(*coros) - Run multiple, get ordered results               │
│  • wait(tasks) - More control over completion                       │
│  • wait_for(coro, timeout) - With timeout                           │
│                                                                     │
│  SYNCHRONIZATION:                                                   │
│  • Lock - Mutual exclusion                                          │
│  • Semaphore - Limit concurrent access                              │
│  • Event - One-time signal                                          │
│  • Queue - Producer-consumer                                        │
│                                                                     │
│  BLOCKING CODE:                                                     │
│  • asyncio.to_thread(func) - Run in thread (3.9+)                   │
│  • run_in_executor(pool, func) - Custom executor                    │
│                                                                     │
│  PYTHON 3.11+:                                                      │
│  • TaskGroup - Structured concurrency                               │
│  • ExceptionGroup - Multiple exceptions                             │
│                                                                     │
│  COMMON MISTAKES:                                                   │
│  • Sequential awaits when could be concurrent                       │
│  • Blocking calls (time.sleep instead of asyncio.sleep)            │
│  • Not handling exceptions in tasks                                 │
│  • Creating tasks without tracking                                  │
│                                                                     │
│  PERFORMANCE:                                                       │
│  • Use uvloop for 2-4x speedup                                      │
│  • Reuse connections (aiohttp.ClientSession)                        │
│  • Use Semaphore for rate limiting                                  │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

*Back to: [Overview](_01_overview.md) | [Implementation](_02_implementation.md) | [Deep Dive](_03_deep_dive.md)*
