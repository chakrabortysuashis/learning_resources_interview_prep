# Asyncio in Python - Overview

## What is Asyncio? (The Simple Explanation)

**Asyncio** is Python's built-in library for writing **asynchronous code**. Think of it as the complete toolkit that brings together everything we've learned:

- **Coroutines** (the pausable functions)
- **Event Loop** (the coordinator)
- **Tasks** (scheduled work)
- **Utilities** (gather, wait, queues, locks, etc.)

```
┌─────────────────────────────────────────────────────────────────────┐
│                    ASYNCIO = THE COMPLETE PACKAGE                    │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                        ASYNCIO                               │   │
│  │                                                             │   │
│  │  ┌───────────────┐  ┌───────────────┐  ┌───────────────┐   │   │
│  │  │  Coroutines   │  │  Event Loop   │  │    Tasks      │   │   │
│  │  │  async/await  │  │  (scheduler)  │  │  (wrappers)   │   │   │
│  │  └───────────────┘  └───────────────┘  └───────────────┘   │   │
│  │                                                             │   │
│  │  ┌───────────────┐  ┌───────────────┐  ┌───────────────┐   │   │
│  │  │   Streams     │  │    Queues     │  │Synchronization│   │   │
│  │  │  (network)    │  │  (data flow)  │  │   (locks)     │   │   │
│  │  └───────────────┘  └───────────────┘  └───────────────┘   │   │
│  │                                                             │   │
│  │  ┌───────────────┐  ┌───────────────┐  ┌───────────────┐   │   │
│  │  │  Subprocesses │  │   Timeouts    │  │    Futures    │   │   │
│  │  │  (shell cmds) │  │  (deadlines)  │  │  (promises)   │   │   │
│  │  └───────────────┘  └───────────────┘  └───────────────┘   │   │
│  │                                                             │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
│  "Asyncio is NOT just async/await - it's a complete framework      │
│   for building concurrent I/O applications."                        │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Why Use Asyncio?

### The Problem It Solves

Imagine a **web server** handling 10,000 users:

```
┌─────────────────────────────────────────────────────────────────────┐
│                    THE WEB SERVER PROBLEM                            │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  WITHOUT ASYNCIO (Synchronous):                                     │
│                                                                     │
│  User 1: [─request─][░░░░waiting for DB░░░░][─response─]           │
│  User 2:                                    [─request─][░░░]       │
│  User 3:                                               wait...     │
│  ...                                                               │
│  User 10000: Still waiting for User 1! 😫                          │
│                                                                     │
│  Each user BLOCKS while waiting for database/network!               │
│  Only ONE user at a time!                                           │
│                                                                     │
│  ────────────────────────────────────────────────────────────────  │
│                                                                     │
│  WITH ASYNCIO:                                                      │
│                                                                     │
│  User 1: [request]→[await DB]    [response]                        │
│  User 2:           [request]→[await DB] [response]                 │
│  User 3:                    [request]→[await] [response]           │
│  ...                                                               │
│  User 10000: Being served! 😊                                       │
│                                                                     │
│  While one user waits, serve others!                                │
│  Handle THOUSANDS concurrently!                                     │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Asyncio Core Concepts Recap

```
┌─────────────────────────────────────────────────────────────────────┐
│                    CORE CONCEPTS RECAP                               │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  1. COROUTINE (async def)                                           │
│     A function that can pause and resume                            │
│     ┌──────────────────────────────────────┐                       │
│     │ async def fetch_data():              │                       │
│     │     data = await get_from_db()       │                       │
│     │     return process(data)             │                       │
│     └──────────────────────────────────────┘                       │
│                                                                     │
│  2. AWAIT                                                           │
│     "Pause here, let others run, resume when ready"                │
│     ┌──────────────────────────────────────┐                       │
│     │ result = await some_async_operation()│                       │
│     └──────────────────────────────────────┘                       │
│                                                                     │
│  3. TASK                                                            │
│     A scheduled coroutine (runs concurrently)                       │
│     ┌──────────────────────────────────────┐                       │
│     │ task = asyncio.create_task(coro())   │                       │
│     └──────────────────────────────────────┘                       │
│                                                                     │
│  4. EVENT LOOP                                                      │
│     The coordinator that runs everything                            │
│     ┌──────────────────────────────────────┐                       │
│     │ asyncio.run(main())                  │                       │
│     └──────────────────────────────────────┘                       │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## The Basic Pattern

```python
import asyncio

# Step 1: Define coroutines
async def fetch_data(url):
    print(f"Fetching {url}...")
    await asyncio.sleep(1)  # Simulate network delay
    return f"Data from {url}"

# Step 2: Create main coroutine
async def main():
    # Run multiple fetches concurrently
    results = await asyncio.gather(
        fetch_data("url1"),
        fetch_data("url2"),
        fetch_data("url3"),
    )
    print(results)

# Step 3: Run the event loop
asyncio.run(main())
```

---

## Asyncio vs Threading vs Multiprocessing

```
┌─────────────────────────────────────────────────────────────────────┐
│                    COMPARISON OF APPROACHES                          │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  THREADING                                                          │
│  ─────────                                                          │
│  ✅ Good for I/O-bound                                              │
│  ✅ Shared memory                                                   │
│  ❌ GIL limits CPU parallelism                                      │
│  ❌ Race conditions possible                                        │
│  ❌ Overhead per thread                                             │
│                                                                     │
│  MULTIPROCESSING                                                    │
│  ──────────────                                                     │
│  ✅ True parallelism                                                │
│  ✅ Bypasses GIL                                                    │
│  ❌ High memory overhead                                            │
│  ❌ Complex communication (IPC)                                     │
│  ❌ Slow to start processes                                         │
│                                                                     │
│  ASYNCIO                                                            │
│  ───────                                                            │
│  ✅ BEST for I/O-bound                                              │
│  ✅ Low overhead (single thread)                                    │
│  ✅ No race conditions (cooperative)                                │
│  ✅ Handles 10,000+ concurrent connections                          │
│  ❌ Not for CPU-bound (use with multiprocessing)                    │
│  ❌ Need async-compatible libraries                                 │
│                                                                     │
│  ────────────────────────────────────────────────────────────────  │
│                                                                     │
│  WHEN TO USE WHAT:                                                  │
│                                                                     │
│  Network I/O (APIs, web servers) ──────────▶ ASYNCIO               │
│  File I/O with async libs ─────────────────▶ ASYNCIO               │
│  CPU-intensive calculations ───────────────▶ MULTIPROCESSING       │
│  Blocking libraries (no async version) ───▶ THREADING              │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Key Asyncio Functions

```
┌─────────────────────────────────────────────────────────────────────┐
│                    MOST IMPORTANT FUNCTIONS                          │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  RUNNING:                                                           │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │ asyncio.run(main())        # Entry point for async code     │   │
│  │ asyncio.create_task(coro)  # Schedule concurrent execution  │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
│  WAITING:                                                           │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │ await asyncio.sleep(1)     # Non-blocking delay             │   │
│  │ await asyncio.gather(...)  # Run multiple concurrently      │   │
│  │ await asyncio.wait(...)    # More control over completion   │   │
│  │ await asyncio.wait_for(coro, timeout=5)  # With timeout     │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
│  SYNCHRONIZATION:                                                   │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │ asyncio.Lock()             # Mutual exclusion               │   │
│  │ asyncio.Event()            # Signaling                      │   │
│  │ asyncio.Semaphore(n)       # Limit concurrent access        │   │
│  │ asyncio.Queue()            # Producer-consumer              │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
│  UTILITIES:                                                         │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │ asyncio.to_thread(func)    # Run blocking in thread         │   │
│  │ asyncio.timeout(seconds)   # Context manager timeout        │   │
│  │ asyncio.TaskGroup()        # Structured concurrency         │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Real-World Use Cases

```
┌─────────────────────────────────────────────────────────────────────┐
│                    WHERE ASYNCIO SHINES                              │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  🌐 WEB SERVERS                                                     │
│     FastAPI, Starlette, aiohttp                                     │
│     Handle thousands of concurrent requests                         │
│                                                                     │
│  🔌 WEB SCRAPING                                                    │
│     Scrape hundreds of pages simultaneously                         │
│     aiohttp, httpx                                                  │
│                                                                     │
│  💬 CHAT APPLICATIONS                                               │
│     Real-time messaging, WebSockets                                 │
│     Handle many simultaneous connections                            │
│                                                                     │
│  📊 DATABASE OPERATIONS                                             │
│     asyncpg, aiomysql, motor (MongoDB)                              │
│     Non-blocking database queries                                   │
│                                                                     │
│  🔄 API CLIENTS                                                     │
│     Call multiple APIs concurrently                                 │
│     httpx, aiohttp                                                  │
│                                                                     │
│  📁 FILE OPERATIONS                                                 │
│     aiofiles for async file I/O                                     │
│     Process many files concurrently                                 │
│                                                                     │
│  🎮 GAME SERVERS                                                    │
│     Handle many players simultaneously                              │
│     Real-time updates                                               │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Asyncio Ecosystem

```
┌─────────────────────────────────────────────────────────────────────┐
│                    POPULAR ASYNC LIBRARIES                           │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  HTTP Clients/Servers:                                              │
│  • aiohttp         - HTTP client and server                         │
│  • httpx           - Modern HTTP client (sync + async)              │
│  • FastAPI         - Modern web framework                           │
│  • Starlette       - ASGI framework                                 │
│                                                                     │
│  Databases:                                                         │
│  • asyncpg         - PostgreSQL                                     │
│  • aiomysql        - MySQL                                          │
│  • motor           - MongoDB                                        │
│  • aiosqlite       - SQLite                                         │
│  • databases       - Multi-database async ORM                       │
│                                                                     │
│  Messaging/Cache:                                                   │
│  • aioredis        - Redis                                          │
│  • aiokafka        - Kafka                                          │
│  • aio-pika        - RabbitMQ                                       │
│                                                                     │
│  Files:                                                             │
│  • aiofiles        - Async file operations                          │
│                                                                     │
│  Performance:                                                       │
│  • uvloop          - Fast event loop replacement                    │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Key Takeaways

1. **Asyncio is Python's async framework** - Complete toolkit for concurrent I/O
2. **Single-threaded concurrency** - One thread, many tasks
3. **Best for I/O-bound work** - Network, files, databases
4. **No race conditions** - Cooperative scheduling at await points
5. **High scalability** - Handle thousands of concurrent connections
6. **Ecosystem support** - Many async libraries available
7. **Not for CPU-bound** - Combine with multiprocessing for that

---

*Next: [Implementation & Code](_02_implementation.md)*
