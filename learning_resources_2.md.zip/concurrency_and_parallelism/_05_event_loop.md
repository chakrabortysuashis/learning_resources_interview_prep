# Event Loop in Python

## Table of Contents
1. [What is an Event Loop?](#what-is-an-event-loop)
2. [Event Loop Architecture](#event-loop-architecture)
3. [Event Loop Lifecycle](#event-loop-lifecycle)
4. [Working with the Event Loop](#working-with-the-event-loop)
5. [Scheduling Callbacks](#scheduling-callbacks)
6. [Running Blocking Code](#running-blocking-code)
7. [Low-Level APIs](#low-level-apis)
8. [Custom Event Loop Policies](#custom-event-loop-policies)
9. [Debugging Event Loops](#debugging-event-loops)
10. [Interview Questions](#interview-questions)

---

## What is an Event Loop?

The **Event Loop** is the core of asyncio. It's a programming construct that waits for and dispatches events or messages in a program. It runs asynchronous tasks, executes callbacks, handles I/O operations, and manages subprocesses.

```
┌─────────────────────────────────────────────────────────────────┐
│                    Event Loop Concept                            │
│                                                                  │
│   ┌──────────────────────────────────────────────────────────┐  │
│   │                    EVENT LOOP                             │  │
│   │                                                           │  │
│   │    ┌────────────┐                                        │  │
│   │    │   Start    │                                        │  │
│   │    └─────┬──────┘                                        │  │
│   │          │                                               │  │
│   │          ▼                                               │  │
│   │    ┌─────────────────────────────────────────┐          │  │
│   │    │          Wait for events                 │          │  │
│   │    │   (I/O ready, timer expired, etc.)      │◄────┐    │  │
│   │    └──────────────────┬──────────────────────┘     │    │  │
│   │                       │                            │    │  │
│   │                       ▼                            │    │  │
│   │    ┌─────────────────────────────────────────┐    │    │  │
│   │    │         Process ready events             │    │    │  │
│   │    │   (run callbacks, resume coroutines)    │    │    │  │
│   │    └──────────────────┬──────────────────────┘    │    │  │
│   │                       │                            │    │  │
│   │                       └────────────────────────────┘    │  │
│   │                                                          │  │
│   │    ┌────────────┐                                        │  │
│   │    │    Stop    │ (when no more work)                    │  │
│   │    └────────────┘                                        │  │
│   └──────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
```

### Key Responsibilities

| Responsibility | Description |
|----------------|-------------|
| Task Scheduling | Schedule and execute coroutines and callbacks |
| I/O Multiplexing | Monitor multiple I/O sources efficiently |
| Timer Management | Handle delayed callbacks and timeouts |
| Signal Handling | Respond to OS signals (Unix) |
| Subprocess Management | Handle child process communication |

---

## Event Loop Architecture

### Internal Components

```
┌─────────────────────────────────────────────────────────────────┐
│                  Event Loop Internal Architecture                │
│                                                                  │
│   ┌──────────────────────────────────────────────────────────┐  │
│   │                      Event Loop                          │  │
│   │  ┌────────────────────────────────────────────────────┐ │  │
│   │  │                  Ready Queue                        │ │  │
│   │  │  Callbacks ready to execute immediately            │ │  │
│   │  │  [callback1] [callback2] [callback3]               │ │  │
│   │  └────────────────────────────────────────────────────┘ │  │
│   │                                                          │  │
│   │  ┌────────────────────────────────────────────────────┐ │  │
│   │  │                Scheduled Queue                      │ │  │
│   │  │  Callbacks scheduled for future execution          │ │  │
│   │  │  (sorted by execution time)                        │ │  │
│   │  │  [t=1.0: cb1] [t=2.5: cb2] [t=5.0: cb3]           │ │  │
│   │  └────────────────────────────────────────────────────┘ │  │
│   │                                                          │  │
│   │  ┌────────────────────────────────────────────────────┐ │  │
│   │  │              I/O Selector (epoll/kqueue)            │ │  │
│   │  │  Monitors file descriptors for I/O readiness       │ │  │
│   │  │  ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐                 │ │  │
│   │  │  │ fd1 │ │ fd2 │ │ fd3 │ │ fd4 │                 │ │  │
│   │  │  └─────┘ └─────┘ └─────┘ └─────┘                 │ │  │
│   │  └────────────────────────────────────────────────────┘ │  │
│   └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│   Each iteration:                                                │
│   1. Run all ready callbacks                                    │
│   2. Check scheduled callbacks, move expired to ready           │
│   3. Poll I/O selector, add ready I/O callbacks                │
│   4. Repeat                                                      │
└─────────────────────────────────────────────────────────────────┘
```

### I/O Selectors

```
┌─────────────────────────────────────────────────────────────────┐
│                   I/O Selector Implementations                   │
│                                                                  │
│   Platform       │ Selector    │ Scalability                   │
│   ────────────────────────────────────────────────────────────  │
│   Linux          │ epoll       │ O(1) for ready events         │
│   macOS/BSD      │ kqueue      │ O(1) for ready events         │
│   Windows        │ IOCP        │ O(1) for ready events         │
│   Fallback       │ select      │ O(n) - limited to 1024 fds    │
│                                                                  │
│   Modern selectors (epoll, kqueue, IOCP) handle thousands      │
│   of connections efficiently                                    │
└─────────────────────────────────────────────────────────────────┘
```

---

## Event Loop Lifecycle

### Loop States

```
┌─────────────────────────────────────────────────────────────────┐
│                   Event Loop States                              │
│                                                                  │
│   ┌────────────┐                                                │
│   │  Created   │  ← asyncio.new_event_loop()                    │
│   └─────┬──────┘                                                │
│         │ run_until_complete() / run_forever()                   │
│         ▼                                                        │
│   ┌────────────┐                                                │
│   │  Running   │  ← loop.is_running() == True                   │
│   └─────┬──────┘                                                │
│         │ stop() or coroutine completes                          │
│         ▼                                                        │
│   ┌────────────┐                                                │
│   │  Stopped   │  ← Can be restarted                            │
│   └─────┬──────┘                                                │
│         │ close()                                                │
│         ▼                                                        │
│   ┌────────────┐                                                │
│   │   Closed   │  ← Cannot be restarted                         │
│   └────────────┘    loop.is_closed() == True                    │
└─────────────────────────────────────────────────────────────────┘
```

### Complete Example

```python
import asyncio

async def main():
    print("Running main coroutine")
    await asyncio.sleep(1)
    return "Done"

# Method 1: asyncio.run() (Recommended - Python 3.7+)
# Creates loop, runs coroutine, closes loop automatically
result = asyncio.run(main())
print(result)

# Method 2: Manual management
loop = asyncio.new_event_loop()
asyncio.set_event_loop(loop)

try:
    print(f"Loop running: {loop.is_running()}")  # False
    print(f"Loop closed: {loop.is_closed()}")    # False
    
    # Run until coroutine completes
    result = loop.run_until_complete(main())
    print(result)
    
finally:
    # Cleanup
    loop.run_until_complete(loop.shutdown_asyncgens())
    loop.close()
    print(f"Loop closed: {loop.is_closed()}")    # True
```

---

## Working with the Event Loop

### Getting the Event Loop

```python
import asyncio

# Outside async context
loop = asyncio.new_event_loop()

# Inside async context
async def inside_async():
    # Recommended way (Python 3.7+)
    loop = asyncio.get_running_loop()
    print(f"Current loop: {loop}")
    
    # Deprecated way (still works)
    # loop = asyncio.get_event_loop()

asyncio.run(inside_async())
```

### Running the Event Loop

```python
import asyncio

async def background_task():
    while True:
        print("Background task running...")
        await asyncio.sleep(1)

async def main_task():
    for i in range(5):
        print(f"Main task: {i}")
        await asyncio.sleep(0.5)

# Method 1: run_until_complete - runs until coroutine finishes
loop = asyncio.new_event_loop()
loop.run_until_complete(main_task())
loop.close()

# Method 2: run_forever - runs until stop() is called
async def setup():
    asyncio.create_task(background_task())
    await asyncio.sleep(5)
    asyncio.get_running_loop().stop()

loop = asyncio.new_event_loop()
loop.run_until_complete(setup())
loop.close()
```

### Stopping the Event Loop

```python
import asyncio
import signal

async def main():
    loop = asyncio.get_running_loop()
    
    # Schedule stop after 5 seconds
    loop.call_later(5, loop.stop)
    
    # Or handle signals (Unix only)
    # loop.add_signal_handler(signal.SIGINT, loop.stop)
    
    while True:
        print("Running...")
        await asyncio.sleep(1)

try:
    asyncio.run(main())
except RuntimeError:
    print("Loop was stopped")
```

---

## Scheduling Callbacks

### call_soon()

```python
import asyncio

def callback(message):
    print(f"Callback: {message}")

async def main():
    loop = asyncio.get_running_loop()
    
    # Schedule callback for next iteration
    loop.call_soon(callback, "Hello")
    loop.call_soon(callback, "World")
    
    print("Callbacks scheduled")
    await asyncio.sleep(0)  # Let callbacks run
    print("After callbacks")

asyncio.run(main())
# Output:
# Callbacks scheduled
# Callback: Hello
# Callback: World
# After callbacks
```

### call_later() and call_at()

```python
import asyncio
import time

def delayed_callback(message, scheduled_time):
    actual_time = time.time()
    delay = actual_time - scheduled_time
    print(f"{message} (delay: {delay:.3f}s)")

async def main():
    loop = asyncio.get_running_loop()
    now = time.time()
    
    # Schedule callback after delay
    loop.call_later(1.0, delayed_callback, "After 1 second", now)
    loop.call_later(0.5, delayed_callback, "After 0.5 seconds", now)
    loop.call_later(2.0, delayed_callback, "After 2 seconds", now)
    
    # Schedule callback at specific time
    loop.call_at(loop.time() + 1.5, delayed_callback, "At specific time", now)
    
    print(f"Current loop time: {loop.time()}")
    await asyncio.sleep(3)

asyncio.run(main())
```

```
┌─────────────────────────────────────────────────────────────────┐
│                 Callback Scheduling Timeline                     │
│                                                                  │
│   Time: 0      0.5      1.0      1.5      2.0      2.5          │
│         │       │        │        │        │        │            │
│         ▼       ▼        ▼        ▼        ▼        │            │
│        [S]    [0.5s]   [1.0s]  [1.5s]   [2.0s]                  │
│         │       │        │        │        │                     │
│   [S] = Scheduled                                                │
│                                                                  │
│   call_later(0.5, cb) → Executes at t=0.5                       │
│   call_later(1.0, cb) → Executes at t=1.0                       │
│   call_at(time+1.5, cb) → Executes at t=1.5                     │
│   call_later(2.0, cb) → Executes at t=2.0                       │
└─────────────────────────────────────────────────────────────────┘
```

### call_soon_threadsafe()

```python
import asyncio
import threading
import time

def background_thread(loop):
    """Run in a separate thread"""
    time.sleep(1)
    # Schedule callback from another thread
    loop.call_soon_threadsafe(print, "From background thread!")

async def main():
    loop = asyncio.get_running_loop()
    
    # Start background thread
    thread = threading.Thread(target=background_thread, args=(loop,))
    thread.start()
    
    print("Main coroutine running")
    await asyncio.sleep(2)
    
    thread.join()

asyncio.run(main())
```

### Cancelling Callbacks

```python
import asyncio

def my_callback():
    print("Callback executed!")

async def main():
    loop = asyncio.get_running_loop()
    
    # Schedule callback
    handle = loop.call_later(2, my_callback)
    
    print(f"Handle: {handle}")
    print(f"Cancelled: {handle.cancelled()}")
    
    # Cancel before execution
    handle.cancel()
    
    print(f"Cancelled: {handle.cancelled()}")
    
    await asyncio.sleep(3)
    print("Callback was cancelled, never executed")

asyncio.run(main())
```

---

## Running Blocking Code

### run_in_executor()

```python
import asyncio
import time
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor

def blocking_io(seconds):
    """Simulates blocking I/O operation"""
    print(f"Starting blocking I/O for {seconds}s")
    time.sleep(seconds)
    return f"IO completed after {seconds}s"

def cpu_intensive(n):
    """CPU-bound computation"""
    print(f"Starting CPU work for n={n}")
    return sum(i * i for i in range(n))

async def main():
    loop = asyncio.get_running_loop()
    
    print("Starting async operations...")
    start = time.perf_counter()
    
    # Run blocking I/O in thread pool (default executor)
    result1 = await loop.run_in_executor(None, blocking_io, 2)
    print(result1)
    
    # Run in custom thread pool
    with ThreadPoolExecutor(max_workers=4) as pool:
        result2 = await loop.run_in_executor(pool, blocking_io, 1)
        print(result2)
    
    # Run CPU-bound in process pool
    with ProcessPoolExecutor() as pool:
        result3 = await loop.run_in_executor(pool, cpu_intensive, 10_000_000)
        print(f"CPU result: {result3}")
    
    print(f"Total time: {time.perf_counter() - start:.2f}s")

if __name__ == '__main__':
    asyncio.run(main())
```

### Concurrent Executor Calls

```python
import asyncio
import time
from concurrent.futures import ThreadPoolExecutor

def slow_operation(n):
    time.sleep(1)
    return n * 2

async def main():
    loop = asyncio.get_running_loop()
    
    with ThreadPoolExecutor(max_workers=4) as pool:
        # Run multiple blocking operations concurrently
        futures = [
            loop.run_in_executor(pool, slow_operation, i)
            for i in range(4)
        ]
        
        # Wait for all to complete
        results = await asyncio.gather(*futures)
        print(f"Results: {results}")

asyncio.run(main())
# Takes ~1s instead of 4s because of concurrent execution
```

```
┌─────────────────────────────────────────────────────────────────┐
│               run_in_executor() Architecture                     │
│                                                                  │
│   ┌─────────────────────────────────────────┐                   │
│   │            Event Loop (main thread)      │                   │
│   │                                          │                   │
│   │   await run_in_executor(pool, func)     │                   │
│   │              │                           │                   │
│   └──────────────┼───────────────────────────┘                   │
│                  │                                               │
│                  ▼                                               │
│   ┌─────────────────────────────────────────┐                   │
│   │         Thread/Process Pool              │                   │
│   │  ┌───────┐ ┌───────┐ ┌───────┐         │                   │
│   │  │ Worker│ │ Worker│ │ Worker│         │                   │
│   │  │   1   │ │   2   │ │   3   │         │                   │
│   │  │ func()│ │ func()│ │ func()│         │                   │
│   │  └───────┘ └───────┘ └───────┘         │                   │
│   └─────────────────────────────────────────┘                   │
│                  │                                               │
│                  ▼                                               │
│   Event loop continues while waiting                            │
│   When worker finishes, Future is resolved                      │
└─────────────────────────────────────────────────────────────────┘
```

### asyncio.to_thread() (Python 3.9+)

```python
import asyncio
import time

def blocking_function():
    time.sleep(2)
    return "Blocking complete"

async def main():
    # Simpler alternative to run_in_executor
    result = await asyncio.to_thread(blocking_function)
    print(result)

asyncio.run(main())
```

---

## Low-Level APIs

### Creating Futures

```python
import asyncio

async def main():
    loop = asyncio.get_running_loop()
    
    # Create a future
    future = loop.create_future()
    
    # Set result later
    async def set_result():
        await asyncio.sleep(1)
        future.set_result("Future result!")
    
    asyncio.create_task(set_result())
    
    # Wait for future
    result = await future
    print(result)

asyncio.run(main())
```

### Socket Operations

```python
import asyncio
import socket

async def tcp_echo_client():
    loop = asyncio.get_running_loop()
    
    # Create socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setblocking(False)
    
    # Connect asynchronously
    await loop.sock_connect(sock, ('localhost', 8888))
    
    # Send data
    await loop.sock_sendall(sock, b'Hello, server!')
    
    # Receive response
    data = await loop.sock_recv(sock, 1024)
    print(f"Received: {data.decode()}")
    
    sock.close()

# Note: Requires a running server on localhost:8888
```

### File Operations

```python
import asyncio
import os

async def async_file_operations():
    loop = asyncio.get_running_loop()
    
    # Read file asynchronously (using executor)
    def read_file(path):
        with open(path, 'r') as f:
            return f.read()
    
    content = await loop.run_in_executor(None, read_file, 'example.txt')
    print(content)

# For better async file I/O, use aiofiles library:
# pip install aiofiles
import aiofiles

async def async_file_with_aiofiles():
    async with aiofiles.open('example.txt', 'r') as f:
        content = await f.read()
    print(content)
```

### Subprocess Operations

```python
import asyncio

async def run_command():
    # Create subprocess
    process = await asyncio.create_subprocess_exec(
        'python', '-c', 'print("Hello from subprocess")',
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )
    
    # Wait for completion and get output
    stdout, stderr = await process.communicate()
    
    print(f"Return code: {process.returncode}")
    print(f"Stdout: {stdout.decode()}")
    
    # Using shell
    process = await asyncio.create_subprocess_shell(
        'echo "Shell command"',
        stdout=asyncio.subprocess.PIPE
    )
    stdout, _ = await process.communicate()
    print(f"Shell output: {stdout.decode()}")

asyncio.run(run_command())
```

---

## Custom Event Loop Policies

### Understanding Policies

```python
import asyncio

# Get current policy
policy = asyncio.get_event_loop_policy()
print(f"Current policy: {type(policy).__name__}")

# Get default loop from policy
loop = policy.get_event_loop()
print(f"Loop: {type(loop).__name__}")
```

### Windows-Specific Policies

```python
import asyncio
import sys

if sys.platform == 'win32':
    # Default on Windows: SelectorEventLoop
    # For subprocess support, use ProactorEventLoop
    asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())
    
    # Or for older compatibility
    # asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

async def main():
    # Now subprocesses work on Windows
    process = await asyncio.create_subprocess_exec('cmd', '/c', 'echo Hello')
    await process.wait()

asyncio.run(main())
```

### Unix-Specific Features

```python
import asyncio
import signal

async def main():
    loop = asyncio.get_running_loop()
    
    # Signal handling (Unix only)
    def signal_handler():
        print("Received SIGINT!")
        loop.stop()
    
    # Add signal handler
    loop.add_signal_handler(signal.SIGINT, signal_handler)
    
    # Run forever
    try:
        while True:
            await asyncio.sleep(1)
            print("Running...")
    except asyncio.CancelledError:
        pass
    finally:
        # Remove signal handler
        loop.remove_signal_handler(signal.SIGINT)

# This won't work on Windows - signals handled differently
```

### Custom Event Loop

```python
import asyncio

class CustomEventLoop(asyncio.SelectorEventLoop):
    def __init__(self):
        super().__init__()
        self.iteration_count = 0
    
    def _run_once(self):
        self.iteration_count += 1
        super()._run_once()

class CustomPolicy(asyncio.DefaultEventLoopPolicy):
    def new_event_loop(self):
        return CustomEventLoop()

# Set custom policy
asyncio.set_event_loop_policy(CustomPolicy())

async def main():
    loop = asyncio.get_running_loop()
    await asyncio.sleep(0.1)
    print(f"Loop iterations: {loop.iteration_count}")

asyncio.run(main())
```

---

## Debugging Event Loops

### Debug Mode

```python
import asyncio
import logging

# Enable debug mode
asyncio.run(main(), debug=True)

# Or via environment variable
# PYTHONASYNCIODEBUG=1 python script.py

# Or manually
loop = asyncio.new_event_loop()
loop.set_debug(True)
```

### Slow Callback Warnings

```python
import asyncio
import time

def slow_callback():
    # This will trigger a warning in debug mode
    time.sleep(0.2)  # Blocking call!
    print("Slow callback completed")

async def main():
    loop = asyncio.get_running_loop()
    loop.call_soon(slow_callback)
    await asyncio.sleep(1)

# Run with debug mode
asyncio.run(main(), debug=True)
# Warning: Executing <Handle slow_callback()> took 0.200 seconds
```

### Tracking Unawaited Coroutines

```python
import asyncio
import warnings

# Show warnings for unawaited coroutines
warnings.filterwarnings('error', category=RuntimeWarning)

async def forgotten_coroutine():
    await asyncio.sleep(1)
    return "result"

async def main():
    # This creates a coroutine but doesn't await it
    coro = forgotten_coroutine()  # Warning!
    # Should be: await forgotten_coroutine()
    # Or: asyncio.create_task(forgotten_coroutine())

# RuntimeWarning: coroutine 'forgotten_coroutine' was never awaited
```

### Monitoring Event Loop Performance

```python
import asyncio
import time

class LoopMonitor:
    def __init__(self):
        self.total_callbacks = 0
        self.total_time = 0
        self.slow_callbacks = []
    
    def callback_wrapper(self, callback, *args):
        start = time.perf_counter()
        try:
            callback(*args)
        finally:
            elapsed = time.perf_counter() - start
            self.total_callbacks += 1
            self.total_time += elapsed
            if elapsed > 0.1:
                self.slow_callbacks.append((callback.__name__, elapsed))
    
    def report(self):
        print(f"Total callbacks: {self.total_callbacks}")
        print(f"Total time: {self.total_time:.3f}s")
        print(f"Slow callbacks: {self.slow_callbacks}")
```

### Using asyncio-specific Debugging Tools

```python
import asyncio

async def main():
    loop = asyncio.get_running_loop()
    
    # Get all current tasks
    tasks = asyncio.all_tasks()
    print(f"Current tasks: {len(tasks)}")
    for task in tasks:
        print(f"  - {task.get_name()}: {task.get_coro()}")
    
    # Get current task
    current = asyncio.current_task()
    print(f"Current task: {current.get_name()}")

asyncio.run(main())
```

---

## Event Loop Best Practices

### 1. Use asyncio.run()

```python
# GOOD: Simple and handles cleanup
async def main():
    await do_work()

asyncio.run(main())

# AVOID: Manual loop management unless necessary
loop = asyncio.get_event_loop()
try:
    loop.run_until_complete(main())
finally:
    loop.close()
```

### 2. Don't Block the Event Loop

```python
import asyncio
import time

# BAD: Blocks the event loop
async def bad_example():
    time.sleep(5)  # Blocks everything!

# GOOD: Use async sleep
async def good_example():
    await asyncio.sleep(5)

# GOOD: Run blocking code in executor
async def executor_example():
    loop = asyncio.get_running_loop()
    await loop.run_in_executor(None, time.sleep, 5)
```

### 3. Handle Exceptions Properly

```python
import asyncio

async def risky_operation():
    raise ValueError("Something went wrong!")

async def main():
    # Bad: Exception lost
    asyncio.create_task(risky_operation())  # Exception logged but not raised
    
    # Good: Handle task exceptions
    task = asyncio.create_task(risky_operation())
    try:
        await task
    except ValueError as e:
        print(f"Caught: {e}")
    
    # Good: Use gather with return_exceptions
    results = await asyncio.gather(
        risky_operation(),
        return_exceptions=True
    )
    for result in results:
        if isinstance(result, Exception):
            print(f"Error: {result}")

asyncio.run(main())
```

### 4. Clean Shutdown

```python
import asyncio
import signal

async def cleanup():
    print("Cleaning up...")
    # Cancel all running tasks
    tasks = [t for t in asyncio.all_tasks() if t is not asyncio.current_task()]
    for task in tasks:
        task.cancel()
    
    # Wait for cancellation
    await asyncio.gather(*tasks, return_exceptions=True)
    print("Cleanup complete")

async def main():
    loop = asyncio.get_running_loop()
    
    # Handle shutdown signals
    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(
            sig,
            lambda: asyncio.create_task(cleanup())
        )
    
    # Main application logic
    while True:
        await asyncio.sleep(1)

# Unix only - Windows handles signals differently
```

---

## Interview Questions

### Q1: What is the event loop and what does it do?
**Answer**: The event loop is the core of asyncio that:
- Manages and executes coroutines and tasks
- Handles I/O operations asynchronously
- Schedules callbacks and timers
- Multiplexes I/O using OS primitives (epoll, kqueue, IOCP)
- Single-threaded, uses cooperative multitasking

### Q2: What's the difference between `call_soon()` and `call_later()`?
**Answer**:
- `call_soon()`: Schedules callback for next loop iteration
- `call_later(delay, callback)`: Schedules callback after `delay` seconds
- `call_at(when, callback)`: Schedules callback at specific loop time

### Q3: How do you run blocking code in an async application?
**Answer**: Use `loop.run_in_executor()` or `asyncio.to_thread()`:
```python
# For I/O-bound blocking
result = await loop.run_in_executor(None, blocking_func)

# For CPU-bound (use ProcessPoolExecutor)
result = await loop.run_in_executor(process_pool, cpu_func)

# Python 3.9+ shorthand
result = await asyncio.to_thread(blocking_func)
```

### Q4: What happens if you block the event loop?
**Answer**: All other tasks stop making progress. The entire async application becomes unresponsive because no other coroutines can run until the blocking operation completes. This defeats the purpose of async programming.

### Q5: How do you get the current event loop?
**Answer**:
- Inside async context: `asyncio.get_running_loop()` (recommended)
- Outside async context: `asyncio.new_event_loop()`
- Deprecated: `asyncio.get_event_loop()` (implicit creation issues)

### Q6: What is the difference between `run_until_complete()` and `run_forever()`?
**Answer**:
- `run_until_complete(coro)`: Runs until the coroutine completes
- `run_forever()`: Runs indefinitely until `stop()` is called
- `run_forever()` is used for servers that should run continuously

---

## Summary

```
┌─────────────────────────────────────────────────────────────────┐
│                    Event Loop Summary                            │
├─────────────────────────────────────────────────────────────────┤
│  Core Functions:                                                 │
│  • asyncio.run() - Run main coroutine (recommended)             │
│  • get_running_loop() - Get current loop in async context       │
│  • create_task() - Schedule coroutine as task                   │
│                                                                  │
│  Scheduling:                                                     │
│  • call_soon() - Next iteration                                 │
│  • call_later() - After delay                                   │
│  • call_at() - At specific time                                 │
│  • call_soon_threadsafe() - From other threads                  │
│                                                                  │
│  Blocking Code:                                                  │
│  • run_in_executor() - Run in thread/process pool              │
│  • to_thread() - Simpler alternative (3.9+)                    │
│                                                                  │
│  Best Practices:                                                 │
│  • Never block the event loop                                   │
│  • Use asyncio.run() for entry point                            │
│  • Handle task exceptions                                       │
│  • Clean shutdown with signal handlers                          │
│  • Debug mode for development                                   │
└─────────────────────────────────────────────────────────────────┘
```
