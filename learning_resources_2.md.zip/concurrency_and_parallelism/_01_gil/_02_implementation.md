# Global Interpreter Lock (GIL) - Implementation & Code

## Table of Contents
1. [Observing the GIL in Action](#observing-the-gil-in-action)
2. [CPU-Bound vs I/O-Bound Examples](#cpu-bound-vs-io-bound-examples)
3. [GIL Release Mechanisms](#gil-release-mechanisms)
4. [Working Around the GIL](#working-around-the-gil)
5. [Practical Patterns](#practical-patterns)

---

## 1. Observing the GIL in Action

### Basic Example: Threads Don't Speed Up CPU Work

```python
import threading
import time

def count_to_million():
    """CPU-bound task: counting"""
    count = 0
    for _ in range(10_000_000):
        count += 1
    return count

# Single-threaded execution
def run_single_threaded():
    start = time.perf_counter()
    
    count_to_million()
    count_to_million()
    
    end = time.perf_counter()
    print(f"Single-threaded: {end - start:.2f} seconds")

# Multi-threaded execution
def run_multi_threaded():
    start = time.perf_counter()
    
    t1 = threading.Thread(target=count_to_million)
    t2 = threading.Thread(target=count_to_million)
    
    t1.start()
    t2.start()
    
    t1.join()
    t2.join()
    
    end = time.perf_counter()
    print(f"Multi-threaded: {end - start:.2f} seconds")

if __name__ == "__main__":
    run_single_threaded()  # ~1.2 seconds
    run_multi_threaded()   # ~1.2 seconds (NOT faster!)
```

**Output:**
```
Single-threaded: 1.23 seconds
Multi-threaded: 1.25 seconds  ← Not faster! Sometimes even slower!
```

---

## 2. CPU-Bound vs I/O-Bound Examples

### CPU-Bound: GIL is a Bottleneck

```python
import threading
import multiprocessing
import time

def cpu_intensive(n):
    """Simulate CPU-heavy work"""
    total = 0
    for i in range(n):
        total += i * i
    return total

def benchmark_cpu_bound():
    n = 10_000_000
    
    # Sequential
    start = time.perf_counter()
    cpu_intensive(n)
    cpu_intensive(n)
    cpu_intensive(n)
    cpu_intensive(n)
    sequential_time = time.perf_counter() - start
    
    # Threading (affected by GIL)
    start = time.perf_counter()
    threads = [threading.Thread(target=cpu_intensive, args=(n,)) for _ in range(4)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    threading_time = time.perf_counter() - start
    
    # Multiprocessing (bypasses GIL)
    start = time.perf_counter()
    with multiprocessing.Pool(4) as pool:
        pool.map(cpu_intensive, [n, n, n, n])
    multiprocessing_time = time.perf_counter() - start
    
    print(f"Sequential:      {sequential_time:.2f}s")
    print(f"Threading:       {threading_time:.2f}s")
    print(f"Multiprocessing: {multiprocessing_time:.2f}s")

if __name__ == "__main__":
    benchmark_cpu_bound()
```

**Output:**
```
Sequential:      4.52s
Threading:       4.78s  ← GIL prevents parallelism
Multiprocessing: 1.23s  ← True parallelism!
```

### I/O-Bound: Threading Works Great

```python
import threading
import time
import urllib.request

def fetch_url(url):
    """I/O-bound task: network request"""
    try:
        with urllib.request.urlopen(url, timeout=10) as response:
            return len(response.read())
    except:
        return 0

def simulate_io_delay():
    """Simulate I/O wait"""
    time.sleep(1)  # GIL is released during sleep!
    return "done"

def benchmark_io_bound():
    # Sequential
    start = time.perf_counter()
    for _ in range(4):
        simulate_io_delay()
    sequential_time = time.perf_counter() - start
    
    # Threading (GIL released during I/O)
    start = time.perf_counter()
    threads = [threading.Thread(target=simulate_io_delay) for _ in range(4)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    threading_time = time.perf_counter() - start
    
    print(f"I/O Sequential: {sequential_time:.2f}s")
    print(f"I/O Threading:  {threading_time:.2f}s")

if __name__ == "__main__":
    benchmark_io_bound()
```

**Output:**
```
I/O Sequential: 4.01s
I/O Threading:  1.01s  ← Threading works! GIL released during I/O
```

---

## 3. GIL Release Mechanisms

### When Does Python Release the GIL?

```python
import sys

# Check the GIL switch interval
print(f"GIL switch interval: {sys.getswitchinterval()} seconds")
# Default: 0.005 seconds (5 milliseconds)

# You can change it (not recommended in production)
sys.setswitchinterval(0.001)  # 1 millisecond
```

### Operations That Release the GIL

```python
"""
GIL is RELEASED during:
1. I/O operations (file, network, database)
2. time.sleep()
3. Many C extension operations (NumPy, etc.)
4. Waiting for locks/events

GIL is HELD during:
1. Pure Python calculations
2. Object creation/manipulation
3. Reference count updates
"""

import threading
import time

counter = 0
lock = threading.Lock()

def increment_with_lock():
    global counter
    for _ in range(100000):
        with lock:  # GIL + explicit lock
            counter += 1

def increment_without_lock():
    global counter
    for _ in range(100000):
        counter += 1  # Race condition possible!

# Even with GIL, race conditions can occur
# because operations like += are not atomic
def demonstrate_race_condition():
    global counter
    counter = 0
    
    threads = [threading.Thread(target=increment_without_lock) for _ in range(10)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    
    print(f"Expected: 1,000,000 | Actual: {counter}")
    # Actual will likely be less than 1,000,000!

if __name__ == "__main__":
    demonstrate_race_condition()
```

---

## 4. Working Around the GIL

### Method 1: Multiprocessing

```python
from multiprocessing import Pool, cpu_count
import time

def square_numbers(numbers):
    return [n * n for n in numbers]

def parallel_processing():
    data = list(range(10_000_000))
    chunks = 4
    chunk_size = len(data) // chunks
    data_chunks = [data[i:i + chunk_size] for i in range(0, len(data), chunk_size)]
    
    # Sequential
    start = time.perf_counter()
    results = [square_numbers(chunk) for chunk in data_chunks]
    seq_time = time.perf_counter() - start
    
    # Parallel with multiprocessing
    start = time.perf_counter()
    with Pool(cpu_count()) as pool:
        results = pool.map(square_numbers, data_chunks)
    par_time = time.perf_counter() - start
    
    print(f"Sequential: {seq_time:.2f}s")
    print(f"Parallel:   {par_time:.2f}s")
    print(f"Speedup:    {seq_time/par_time:.2f}x")

if __name__ == "__main__":
    parallel_processing()
```

### Method 2: C Extensions (NumPy)

```python
import numpy as np
import threading
import time

def python_sum(arr):
    """Pure Python - GIL bound"""
    return sum(arr)

def numpy_sum(arr):
    """NumPy - releases GIL during computation"""
    return np.sum(arr)

def benchmark_numpy():
    # Large array
    data = list(range(10_000_000))
    np_data = np.array(data)
    
    # Python sum (GIL bound)
    start = time.perf_counter()
    threads = [threading.Thread(target=python_sum, args=(data,)) for _ in range(4)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    python_time = time.perf_counter() - start
    
    # NumPy sum (releases GIL)
    start = time.perf_counter()
    threads = [threading.Thread(target=numpy_sum, args=(np_data,)) for _ in range(4)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    numpy_time = time.perf_counter() - start
    
    print(f"Python sum (4 threads): {python_time:.2f}s")
    print(f"NumPy sum (4 threads):  {numpy_time:.2f}s")

if __name__ == "__main__":
    benchmark_numpy()
```

### Method 3: concurrent.futures (High-Level API)

```python
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
import time

def cpu_task(n):
    """CPU-bound task"""
    return sum(i * i for i in range(n))

def io_task(seconds):
    """I/O-bound task"""
    time.sleep(seconds)
    return f"Slept {seconds}s"

def using_executors():
    # CPU-bound: Use ProcessPoolExecutor
    print("CPU-bound tasks:")
    start = time.perf_counter()
    with ProcessPoolExecutor(max_workers=4) as executor:
        results = list(executor.map(cpu_task, [5_000_000] * 4))
    print(f"  ProcessPool: {time.perf_counter() - start:.2f}s")
    
    start = time.perf_counter()
    with ThreadPoolExecutor(max_workers=4) as executor:
        results = list(executor.map(cpu_task, [5_000_000] * 4))
    print(f"  ThreadPool:  {time.perf_counter() - start:.2f}s")
    
    # I/O-bound: Use ThreadPoolExecutor
    print("\nI/O-bound tasks:")
    start = time.perf_counter()
    with ThreadPoolExecutor(max_workers=4) as executor:
        results = list(executor.map(io_task, [1, 1, 1, 1]))
    print(f"  ThreadPool:  {time.perf_counter() - start:.2f}s")

if __name__ == "__main__":
    using_executors()
```

**Output:**
```
CPU-bound tasks:
  ProcessPool: 1.12s  ← Fast (true parallelism)
  ThreadPool:  3.89s  ← Slow (GIL)

I/O-bound tasks:
  ThreadPool:  1.01s  ← Fast (GIL released during sleep)
```

---

## 5. Practical Patterns

### Pattern 1: Hybrid Approach

```python
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
import time

def download_data(url):
    """I/O-bound: downloading"""
    time.sleep(0.5)  # Simulate download
    return list(range(1000000))

def process_data(data):
    """CPU-bound: processing"""
    return sum(x * x for x in data)

def hybrid_pipeline():
    urls = [f"http://example.com/data{i}" for i in range(4)]
    
    # Step 1: Download in parallel (I/O-bound - use threads)
    start = time.perf_counter()
    with ThreadPoolExecutor(max_workers=4) as executor:
        datasets = list(executor.map(download_data, urls))
    download_time = time.perf_counter() - start
    
    # Step 2: Process in parallel (CPU-bound - use processes)
    start = time.perf_counter()
    with ProcessPoolExecutor(max_workers=4) as executor:
        results = list(executor.map(process_data, datasets))
    process_time = time.perf_counter() - start
    
    print(f"Download (threads): {download_time:.2f}s")
    print(f"Process (processes): {process_time:.2f}s")
    print(f"Total: {download_time + process_time:.2f}s")

if __name__ == "__main__":
    hybrid_pipeline()
```

### Pattern 2: Producer-Consumer with GIL Awareness

```python
import threading
import queue
import time

def producer(q, items):
    """I/O simulation - produces items"""
    for item in items:
        time.sleep(0.1)  # Simulate I/O (releases GIL)
        q.put(item)
        print(f"Produced: {item}")
    q.put(None)  # Signal end

def consumer(q):
    """CPU processing simulation"""
    results = []
    while True:
        item = q.get()  # Blocks, releases GIL
        if item is None:
            break
        # Process (this part is GIL-bound)
        result = item * item
        results.append(result)
        print(f"Consumed: {item} -> {result}")
    return results

def producer_consumer_example():
    q = queue.Queue(maxsize=5)
    items = list(range(10))
    
    producer_thread = threading.Thread(target=producer, args=(q, items))
    consumer_thread = threading.Thread(target=consumer, args=(q,))
    
    start = time.perf_counter()
    producer_thread.start()
    consumer_thread.start()
    
    producer_thread.join()
    consumer_thread.join()
    print(f"Total time: {time.perf_counter() - start:.2f}s")

if __name__ == "__main__":
    producer_consumer_example()
```

### Pattern 3: Check Your Task Type

```python
import time
import threading
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor

def analyze_task(task_func, task_args, num_tasks=4):
    """
    Helper to determine if a task is CPU-bound or I/O-bound
    by comparing thread vs process performance
    """
    # Sequential baseline
    start = time.perf_counter()
    for _ in range(num_tasks):
        task_func(*task_args)
    sequential = time.perf_counter() - start
    
    # Threading
    start = time.perf_counter()
    with ThreadPoolExecutor(num_tasks) as ex:
        list(ex.map(lambda _: task_func(*task_args), range(num_tasks)))
    threaded = time.perf_counter() - start
    
    # Multiprocessing
    start = time.perf_counter()
    with ProcessPoolExecutor(num_tasks) as ex:
        list(ex.map(lambda _: task_func(*task_args), range(num_tasks)))
    multiproc = time.perf_counter() - start
    
    print(f"Sequential:      {sequential:.2f}s")
    print(f"Threading:       {threaded:.2f}s")
    print(f"Multiprocessing: {multiproc:.2f}s")
    
    if threaded < sequential * 0.7:
        print("→ Task appears I/O-bound: Use threading")
    elif multiproc < sequential * 0.7:
        print("→ Task appears CPU-bound: Use multiprocessing")
    else:
        print("→ Task may not benefit from parallelism")
```

---

## Quick Reference: GIL-Aware Code Selection

```python
"""
DECISION FLOWCHART IN CODE:

if task_type == "CPU-bound":
    # Heavy calculations, data processing, image manipulation
    from concurrent.futures import ProcessPoolExecutor
    with ProcessPoolExecutor() as executor:
        results = executor.map(cpu_function, data)

elif task_type == "I/O-bound":
    # Network, file, database operations
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor() as executor:
        results = executor.map(io_function, data)

elif task_type == "Mixed":
    # Use appropriate executor for each phase
    # Download (I/O) with threads, process (CPU) with processes
    pass
"""
```

---

*Next: [Deep Dive](_03_deep_dive.md)*
