# Global Interpreter Lock (GIL) - Overview

## What is GIL? (The Simple Explanation)

Imagine you're in a classroom with only **ONE microphone**. Even though there are 30 students who want to speak, only ONE student can use the microphone at a time. The others have to wait.

```
┌─────────────────────────────────────────────────────────────┐
│                    THE CLASSROOM ANALOGY                     │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│    🎤 = Microphone (The GIL)                                │
│                                                             │
│    👨‍🎓 👩‍🎓 👨‍🎓 👩‍🎓 👨‍🎓  = Students (Python Threads)              │
│                                                             │
│    Only ONE student can hold the microphone at a time!      │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

**The GIL is Python's microphone** - it's a lock that allows only ONE thread to execute Python code at any given moment, even if you have multiple threads.

---

## Why Does Python Have a GIL?

### The Memory Problem

Think of Python like a librarian managing books (memory). When you create a variable:

```python
my_name = "Alice"
```

Python needs to:
1. **Remember** where "Alice" is stored
2. **Count** how many people are using "Alice"
3. **Clean up** when nobody needs "Alice" anymore

This counting is called **Reference Counting**.

```
┌─────────────────────────────────────────────────────────────┐
│                   REFERENCE COUNTING                         │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│   my_name = "Alice"     →  "Alice" has 1 reference          │
│   your_name = my_name   →  "Alice" has 2 references         │
│   del my_name           →  "Alice" has 1 reference          │
│   del your_name         →  "Alice" has 0 references → 🗑️    │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### The Chaos Without GIL

Imagine TWO librarians (threads) trying to update the book count at the SAME time:

```
WITHOUT GIL (DANGEROUS!):

Thread 1: Reads count = 5
Thread 2: Reads count = 5
Thread 1: Adds 1, writes count = 6
Thread 2: Adds 1, writes count = 6  ← WRONG! Should be 7!

WITH GIL (SAFE):

Thread 1: Gets GIL, reads count = 5, adds 1, writes 6, releases GIL
Thread 2: Gets GIL, reads count = 6, adds 1, writes 7, releases GIL ✓
```

---

## Real-World Analogy: The Bathroom Key

Think of a small coffee shop with ONE bathroom and ONE key.

```
┌─────────────────────────────────────────────────────────────┐
│                  THE BATHROOM KEY ANALOGY                    │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│   🔑 = Bathroom Key (GIL)                                   │
│   🚻 = Bathroom (Python Interpreter)                        │
│   👤👤👤 = Customers (Threads)                               │
│                                                             │
│   Rules:                                                    │
│   1. Only ONE person can have the key at a time            │
│   2. You MUST return the key after use                     │
│   3. Others wait in line for their turn                    │
│                                                             │
│   ┌────────┐                                                │
│   │   🚻   │  👤 ← Using bathroom (has key)                 │
│   │        │                                                │
│   └────────┘  👤 👤 👤 ← Waiting in line                    │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## When Does the GIL Become a Problem?

### Scenario 1: CPU-Heavy Tasks (PROBLEM!)

Imagine you have 4 workers (threads) and 4 math problems to solve. You'd expect them to work in parallel, right?

```
WHAT YOU EXPECT:
┌─────────────────────────────────────────────────────────────┐
│ Worker 1: ████████████ Problem 1                            │
│ Worker 2: ████████████ Problem 2                            │
│ Worker 3: ████████████ Problem 3                            │
│ Worker 4: ████████████ Problem 4                            │
│                                                             │
│ Total Time: ████████████ (All done together!)               │
└─────────────────────────────────────────────────────────────┘

WHAT ACTUALLY HAPPENS (Because of GIL):
┌─────────────────────────────────────────────────────────────┐
│ Worker 1: ████                                              │
│ Worker 2:     ████                                          │
│ Worker 3:         ████                                      │
│ Worker 4:             ████                                  │
│                                                             │
│ Total Time: ████████████████ (One at a time!)               │
└─────────────────────────────────────────────────────────────┘
```

**The GIL makes CPU tasks run one-at-a-time, NOT in parallel!**

### Scenario 2: Waiting Tasks (NO PROBLEM!)

Now imagine 4 workers waiting for 4 different websites to respond:

```
WAITING TASKS (GIL is NOT a problem here!):
┌─────────────────────────────────────────────────────────────┐
│ Worker 1: ░░░░░░░░░░░░ Waiting for website 1                │
│ Worker 2: ░░░░░░░░░░░░ Waiting for website 2                │
│ Worker 3: ░░░░░░░░░░░░ Waiting for website 3                │
│ Worker 4: ░░░░░░░░░░░░ Waiting for website 4                │
│                                                             │
│ ░ = Waiting (GIL released, others can work!)                │
└─────────────────────────────────────────────────────────────┘
```

**When a thread is WAITING (I/O), it releases the GIL so others can work!**

---

## The Golden Rule

```
┌─────────────────────────────────────────────────────────────┐
│                     THE GOLDEN RULE                          │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌─────────────────┐         ┌─────────────────┐           │
│  │   CPU-BOUND     │         │   I/O-BOUND     │           │
│  │   (Calculating) │         │   (Waiting)     │           │
│  ├─────────────────┤         ├─────────────────┤           │
│  │ • Math          │         │ • Reading files │           │
│  │ • Image process │         │ • Web requests  │           │
│  │ • Data crunching│         │ • Database      │           │
│  │ • Encryption    │         │ • User input    │           │
│  ├─────────────────┤         ├─────────────────┤           │
│  │ GIL = PROBLEM   │         │ GIL = NO ISSUE  │           │
│  │                 │         │                 │           │
│  │ Use:            │         │ Use:            │           │
│  │ multiprocessing │         │ threading       │           │
│  │ (separate       │         │ asyncio         │           │
│  │  processes)     │         │                 │           │
│  └─────────────────┘         └─────────────────┘           │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Simple Summary

| Question | Answer |
|----------|--------|
| What is GIL? | A lock that lets only ONE thread run Python code at a time |
| Why does it exist? | To keep Python's memory management safe and simple |
| When is it a problem? | When doing heavy calculations (CPU-bound tasks) |
| When is it NOT a problem? | When waiting for things (I/O-bound tasks like web requests) |
| How to avoid GIL? | Use `multiprocessing` instead of `threading` for CPU tasks |

---

## Quick Quiz (Test Yourself!)

**Q1:** You have a program that downloads 100 images from the internet. Will GIL slow you down?

<details>
<summary>Click for Answer</summary>

**NO!** Downloading is I/O-bound (waiting for network). The GIL is released while waiting, so threads can work efficiently together.

</details>

**Q2:** You have a program that resizes 100 images. Will GIL slow you down?

<details>
<summary>Click for Answer</summary>

**YES!** Image resizing is CPU-bound (heavy calculations). Use `multiprocessing` instead of `threading` to get true parallelism.

</details>

**Q3:** Why doesn't Python just remove the GIL?

<details>
<summary>Click for Answer</summary>

Removing the GIL would:
1. Break lots of existing Python code
2. Make single-threaded programs slower
3. Require rewriting many C extensions

It's a tradeoff Python made for simplicity and safety.

</details>

---

## Key Takeaways

1. **GIL = One thread at a time** (like one microphone in a classroom)
2. **Exists for safety** (prevents memory corruption)
3. **Problem for CPU tasks** (calculations can't run in parallel)
4. **NOT a problem for I/O tasks** (waiting releases the GIL)
5. **Workaround: multiprocessing** (each process has its own GIL)

---

*Next: [Implementation & Code Examples](_02_implementation.md)*
