# Global Interpreter Lock (GIL) - Deep Dive

## Table of Contents
1. [GIL Internals](#1-gil-internals)
2. [Reference Counting Deep Dive](#2-reference-counting-deep-dive)
3. [GIL and the Python C API](#3-gil-and-the-python-c-api)
4. [GIL Evolution Through Python Versions](#4-gil-evolution-through-python-versions)
5. [PEP 703: Making GIL Optional](#5-pep-703-making-gil-optional)
6. [Alternative Python Implementations](#6-alternative-python-implementations)
7. [Advanced GIL Manipulation](#7-advanced-gil-manipulation)
8. [Performance Profiling with GIL](#8-performance-profiling-with-gil)

---

## 1. GIL Internals

### How the GIL Actually Works

The GIL is implemented as a binary semaphore in CPython's source code (`Python/ceval_gil.c`):

```
┌─────────────────────────────────────────────────────────────────────┐
│                        GIL STATE MACHINE                             │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Thread A (Running)              Thread B (Waiting)                 │
│  ┌─────────────────┐            ┌─────────────────┐                │
│  │  Holds GIL      │            │  Wants GIL      │                │
│  │  Executing      │            │  Blocked        │                │
│  │  Python code    │            │  on gil_cond    │                │
│  └────────┬────────┘            └────────┬────────┘                │
│           │                              │                          │
│           │  ┌─────────────────────┐    │                          │
│           └──│  GIL Drop Request   │◄───┘                          │
│              │  (after 5ms or I/O) │                                │
│              └──────────┬──────────┘                                │
│                         │                                           │
│                         ▼                                           │
│              ┌─────────────────────┐                                │
│              │  Signal gil_cond    │                                │
│              │  Thread A releases  │                                │
│              │  Thread B acquires  │                                │
│              └─────────────────────┘                                │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### GIL Data Structures (Simplified C)

```c
/* Simplified representation of GIL internals */
struct _gil_runtime_state {
    /* Mutex for GIL operations */
    pthread_mutex_t mutex;
    
    /* Condition variable for waiting threads */
    pthread_cond_t cond;
    
    /* Is GIL currently held? */
    int locked;
    
    /* Switch interval in microseconds */
    unsigned long interval;  /* Default: 5000 (5ms) */
    
    /* Last thread that held the GIL */
    PyThreadState *last_holder;
    
    /* Number of GIL switches */
    unsigned long switch_number;
};
```

### The Tick Counter vs Time-Based Switching

**Python 2.x (Tick-based):**
```
┌─────────────────────────────────────────────────────────────────┐
│  Python 2.x: Switch every 100 "ticks" (bytecode instructions)   │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Thread A: [████████████]─┐                                     │
│                           │ 100 ticks                           │
│  Thread B:                └──[████████████]─┐                   │
│                                             │ 100 ticks         │
│  Thread A:                                  └──[████████████]   │
│                                                                 │
│  PROBLEM: Ticks vary wildly in actual time!                     │
│  - 100 simple additions ≈ 0.001ms                               │
│  - 100 dict lookups ≈ 0.1ms                                     │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

**Python 3.2+ (Time-based):**
```
┌─────────────────────────────────────────────────────────────────┐
│  Python 3.2+: Switch every 5ms (configurable)                   │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Thread A: [██████████████████████████████████]─┐               │
│                                                 │ 5ms           │
│  Thread B:                                      └──[████████...]│
│                                                                 │
│  BENEFIT: Predictable, fair scheduling                          │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 2. Reference Counting Deep Dive

### Why Reference Counting Needs Protection

```python
import sys

# Every Python object has a reference count
a = "hello"
print(sys.getrefcount(a))  # Shows refcount (includes temp ref from getrefcount)

b = a  # Increment refcount
print(sys.getrefcount(a))  # Higher now

del b  # Decrement refcount
print(sys.getrefcount(a))  # Back to original
```

### The Race Condition Without GIL

```
┌─────────────────────────────────────────────────────────────────────┐
│              RACE CONDITION IN REFERENCE COUNTING                    │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Object X: refcount = 2                                             │
│                                                                     │
│  Thread A                          Thread B                         │
│  ─────────                         ─────────                        │
│  READ refcount (2)                 READ refcount (2)                │
│  DECREMENT (2-1=1)                 DECREMENT (2-1=1)                │
│  WRITE refcount (1)                WRITE refcount (1)               │
│                                                                     │
│  Result: refcount = 1 (WRONG! Should be 0)                          │
│  Object X is NEVER freed → MEMORY LEAK                              │
│                                                                     │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  WORSE SCENARIO:                                                    │
│                                                                     │
│  Object Y: refcount = 1                                             │
│                                                                     │
│  Thread A                          Thread B                         │
│  ─────────                         ─────────                        │
│  READ refcount (1)                                                  │
│  DECREMENT (1-1=0)                                                  │
│                    ← context switch →                               │
│                                    READ refcount (still 1 in cache) │
│  WRITE 0, FREE object              USE object → CRASH!              │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Alternative: Fine-Grained Locking

```
┌─────────────────────────────────────────────────────────────────────┐
│         WHY NOT USE FINE-GRAINED LOCKS INSTEAD OF GIL?              │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Option 1: GIL (Current Approach)                                   │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │  ONE lock for EVERYTHING                                     │   │
│  │  + Simple                                                    │   │
│  │  + Fast single-threaded performance                          │   │
│  │  - No CPU parallelism                                        │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
│  Option 2: Fine-Grained Locks (Rejected)                            │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │  EVERY object has its OWN lock                               │   │
│  │  + True parallelism possible                                 │   │
│  │  - Lock overhead on EVERY operation                          │   │
│  │  - Deadlock risk                                             │   │
│  │  - 15-30% slower single-threaded (measured)                  │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
│  Most Python programs are single-threaded, so GIL wins overall!     │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 3. GIL and the Python C API

### Releasing GIL in C Extensions

```c
/* C extension code that releases the GIL */

#include <Python.h>

static PyObject* compute_intensive(PyObject* self, PyObject* args) {
    long n;
    if (!PyArg_ParseTuple(args, "l", &n))
        return NULL;
    
    long result;
    
    /* Release GIL before CPU-intensive work */
    Py_BEGIN_ALLOW_THREADS
    
    /* This code runs WITHOUT the GIL */
    result = 0;
    for (long i = 0; i < n; i++) {
        result += i * i;
    }
    
    /* Re-acquire GIL before returning to Python */
    Py_END_ALLOW_THREADS
    
    return PyLong_FromLong(result);
}
```

### GIL State Management

```
┌─────────────────────────────────────────────────────────────────────┐
│                    GIL STATE TRANSITIONS                             │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Python Code                    C Extension Code                    │
│  ────────────                   ──────────────────                  │
│                                                                     │
│  ┌────────────┐                                                     │
│  │ GIL HELD   │─── Call C function ───▶ ┌────────────┐             │
│  │            │                         │ GIL HELD   │             │
│  └────────────┘                         └─────┬──────┘             │
│                                               │                     │
│                                    Py_BEGIN_ALLOW_THREADS           │
│                                               │                     │
│                                               ▼                     │
│                                         ┌────────────┐              │
│                                         │GIL RELEASED│              │
│                                         │ (parallel  │              │
│                                         │  OK here)  │              │
│                                         └─────┬──────┘              │
│                                               │                     │
│                                    Py_END_ALLOW_THREADS             │
│                                               │                     │
│                                               ▼                     │
│  ┌────────────┐                         ┌────────────┐              │
│  │ GIL HELD   │◀── Return to Python ────│ GIL HELD   │              │
│  └────────────┘                         └────────────┘              │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Common C API Functions for GIL

```c
/* GIL Management Functions */

// Release GIL (macro version)
Py_BEGIN_ALLOW_THREADS
// ... C code without GIL ...
Py_END_ALLOW_THREADS

// Function versions (more control)
PyThreadState* state = PyEval_SaveThread();  // Release GIL
// ... C code without GIL ...
PyEval_RestoreThread(state);  // Acquire GIL

// Ensure GIL is held (for callbacks from C)
PyGILState_STATE gstate = PyGILState_Ensure();
// ... Python API calls ...
PyGILState_Release(gstate);
```

---

## 4. GIL Evolution Through Python Versions

```
┌─────────────────────────────────────────────────────────────────────┐
│                      GIL HISTORY TIMELINE                            │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  1991  Python 0.9 ─────────────────────────────────────────────────│
│        │ No threading support yet                                   │
│        │                                                            │
│  1997  Python 1.5 ─────────────────────────────────────────────────│
│        │ GIL introduced with threading module                       │
│        │ Tick-based switching (sys.setcheckinterval)                │
│        │                                                            │
│  2008  Python 3.0 ─────────────────────────────────────────────────│
│        │ GIL remains, some internal improvements                    │
│        │                                                            │
│  2011  Python 3.2 ─────────────────────────────────────────────────│
│        │ MAJOR CHANGE: New GIL implementation                       │
│        │ - Time-based switching (5ms default)                       │
│        │ - sys.setswitchinterval() replaces setcheckinterval()     │
│        │ - Better fairness between threads                          │
│        │ - Reduced "convoy effect"                                  │
│        │                                                            │
│  2020  Python 3.9 ─────────────────────────────────────────────────│
│        │ PEP 554: Multiple Interpreters proposed                    │
│        │ (Each interpreter has its own GIL)                         │
│        │                                                            │
│  2023  Python 3.12 ────────────────────────────────────────────────│
│        │ Per-interpreter GIL (PEP 684)                              │
│        │ Subinterpreters can run truly parallel                     │
│        │                                                            │
│  2024  Python 3.13 ────────────────────────────────────────────────│
│        │ PEP 703: Optional GIL (--disable-gil build)                │
│        │ Experimental free-threaded mode                            │
│        │                                                            │
│  Future ───────────────────────────────────────────────────────────│
│        GIL-free Python as default (maybe Python 3.15+?)             │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 5. PEP 703: Making GIL Optional

### The Free-Threaded Build (Python 3.13+)

```python
"""
Python 3.13 introduces experimental --disable-gil build option

To check if running free-threaded Python:
"""
import sys

# Check for free-threaded build
if hasattr(sys, '_is_gil_enabled'):
    print(f"GIL enabled: {sys._is_gil_enabled()}")
else:
    print("Running standard CPython (GIL always present)")
```

### How Free-Threading Works

```
┌─────────────────────────────────────────────────────────────────────┐
│              FREE-THREADED PYTHON ARCHITECTURE                       │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Standard CPython              Free-Threaded CPython                │
│  ────────────────              ─────────────────────                │
│                                                                     │
│  Reference Counting:           Biased Reference Counting:           │
│  ┌─────────────┐              ┌──────────────────────┐             │
│  │ refcount: 5 │              │ local_refcount: 3    │             │
│  └─────────────┘              │ shared_refcount: 2   │             │
│                               │ (atomic operations)  │             │
│                               └──────────────────────┘             │
│                                                                     │
│  Object Access:                Object Access:                       │
│  ┌─────────────┐              ┌──────────────────────┐             │
│  │ GIL protects│              │ Per-object locks     │             │
│  │ everything  │              │ (only when needed)   │             │
│  └─────────────┘              └──────────────────────┘             │
│                                                                     │
│  Collections:                  Collections:                         │
│  ┌─────────────┐              ┌──────────────────────┐             │
│  │ No internal │              │ Internal locks for   │             │
│  │ locks needed│              │ dict, list mutations │             │
│  └─────────────┘              └──────────────────────┘             │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Performance Implications

```
┌─────────────────────────────────────────────────────────────────────┐
│         FREE-THREADED PYTHON PERFORMANCE CHARACTERISTICS            │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Scenario                 With GIL    Free-Threaded   Comparison   │
│  ──────────────────────   ─────────   ─────────────   ──────────   │
│  Single-threaded          100%        85-95%          Slower        │
│  (overhead from locks)                                              │
│                                                                     │
│  Multi-threaded CPU       ~100%       Up to 400%+     Much faster   │
│  (4 cores, CPU-bound)     (no ||)     (true ||)                     │
│                                                                     │
│  Multi-threaded I/O       ~100%       ~100%           Same          │
│  (GIL released anyway)                                              │
│                                                                     │
│  Memory usage             100%        105-110%        Slightly more │
│  (per-object overhead)                                              │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 6. Alternative Python Implementations

### Comparison of Python Implementations

```
┌─────────────────────────────────────────────────────────────────────┐
│              PYTHON IMPLEMENTATIONS AND GIL                          │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Implementation    GIL?    Threading Model    Best For              │
│  ──────────────    ────    ───────────────    ────────              │
│                                                                     │
│  CPython           YES     Limited by GIL     General use           │
│  (Standard)                                   C extensions          │
│                                                                     │
│  Jython            NO      JVM threads        Java integration      │
│  (Python on JVM)           True parallelism   Enterprise systems    │
│                                                                     │
│  IronPython        NO      .NET threads       .NET integration      │
│  (Python on .NET)          True parallelism   Windows development   │
│                                                                     │
│  PyPy              YES*    Similar to         Speed-critical        │
│  (JIT compiler)            CPython            Pure Python code      │
│                            *STM branch        Long-running          │
│                            has no GIL                               │
│                                                                     │
│  GraalPy           NO      JVM threads        Polyglot apps         │
│  (GraalVM)                 True parallelism   High performance      │
│                                                                     │
│  MicroPython       YES     Simpler GIL        Embedded systems      │
│  (Embedded)                                   IoT devices           │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Code Example: Jython Parallelism

```python
# This code runs differently on CPython vs Jython

import threading
import time

counter = 0
lock = threading.Lock()

def increment():
    global counter
    for _ in range(1_000_000):
        with lock:
            counter += 1

def test_parallel():
    threads = [threading.Thread(target=increment) for _ in range(4)]
    
    start = time.time()
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    elapsed = time.time() - start
    
    print(f"Counter: {counter}")
    print(f"Time: {elapsed:.2f}s")
    
# CPython: ~4.0s (threads run sequentially due to GIL)
# Jython:  ~1.5s (threads run in parallel on JVM)
```

---

## 7. Advanced GIL Manipulation

### Monitoring GIL Contention

```python
import sys
import threading
import time

def monitor_gil_switches():
    """Monitor GIL switch interval behavior"""
    
    # Get current switch interval
    interval = sys.getswitchinterval()
    print(f"Current GIL switch interval: {interval * 1000:.1f}ms")
    
    # Track execution
    execution_log = []
    
    def worker(worker_id):
        for i in range(5):
            start = time.perf_counter()
            # Simulate work
            total = sum(range(100000))
            elapsed = time.perf_counter() - start
            execution_log.append((worker_id, i, elapsed))
    
    threads = [threading.Thread(target=worker, args=(i,)) for i in range(3)]
    
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    
    # Analyze execution pattern
    for worker_id, iteration, elapsed in sorted(execution_log):
        print(f"Worker {worker_id}, Iteration {iteration}: {elapsed*1000:.2f}ms")

if __name__ == "__main__":
    monitor_gil_switches()
```

### Tuning Switch Interval

```python
import sys
import threading
import time

def benchmark_switch_interval(interval):
    """Test performance with different GIL switch intervals"""
    
    old_interval = sys.getswitchinterval()
    sys.setswitchinterval(interval)
    
    def cpu_work():
        return sum(i * i for i in range(500000))
    
    start = time.perf_counter()
    threads = [threading.Thread(target=cpu_work) for _ in range(4)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    elapsed = time.perf_counter() - start
    
    sys.setswitchinterval(old_interval)
    return elapsed

if __name__ == "__main__":
    intervals = [0.001, 0.005, 0.01, 0.05, 0.1]
    
    print("GIL Switch Interval Benchmark:")
    print("-" * 40)
    
    for interval in intervals:
        elapsed = benchmark_switch_interval(interval)
        print(f"Interval {interval*1000:5.1f}ms: {elapsed:.3f}s")
```

---

## 8. Performance Profiling with GIL

### Using cProfile to Identify GIL Impact

```python
import cProfile
import pstats
import threading
import io

def profile_threaded_code():
    """Profile code to identify GIL-related bottlenecks"""
    
    def cpu_bound():
        return sum(i ** 2 for i in range(100000))
    
    def io_bound():
        import time
        time.sleep(0.1)
        return "done"
    
    # Profile CPU-bound multi-threaded code
    profiler = cProfile.Profile()
    profiler.enable()
    
    threads = [threading.Thread(target=cpu_bound) for _ in range(4)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    
    profiler.disable()
    
    # Analyze results
    stream = io.StringIO()
    stats = pstats.Stats(profiler, stream=stream)
    stats.sort_stats('cumulative')
    stats.print_stats(10)
    
    print(stream.getvalue())

if __name__ == "__main__":
    profile_threaded_code()
```

### Visualizing Thread Execution

```python
import threading
import time
from collections import defaultdict

class ThreadTracer:
    """Trace thread execution to visualize GIL behavior"""
    
    def __init__(self):
        self.events = defaultdict(list)
        self.start_time = None
    
    def trace(self, thread_name, event_type):
        if self.start_time is None:
            self.start_time = time.perf_counter()
        
        elapsed = time.perf_counter() - self.start_time
        self.events[thread_name].append((elapsed, event_type))
    
    def visualize(self, duration=1.0, resolution=50):
        """Create ASCII visualization of thread execution"""
        
        print("\nThread Execution Timeline:")
        print("=" * (resolution + 20))
        
        for thread_name, events in sorted(self.events.items()):
            line = [' '] * resolution
            
            for elapsed, event_type in events:
                pos = int((elapsed / duration) * resolution)
                if 0 <= pos < resolution:
                    if event_type == 'start':
                        line[pos] = '['
                    elif event_type == 'end':
                        line[pos] = ']'
                    elif event_type == 'work':
                        line[pos] = '█'
            
            print(f"{thread_name:15} |{''.join(line)}|")
        
        print("=" * (resolution + 20))
        print(f"{'':15} |{'0':<{resolution//2}}{f'{duration}s':>{resolution//2}}|")

# Usage
tracer = ThreadTracer()

def traced_worker(name, work_units=10):
    tracer.trace(name, 'start')
    for _ in range(work_units):
        # Simulate small work unit
        sum(range(10000))
        tracer.trace(name, 'work')
    tracer.trace(name, 'end')

threads = [
    threading.Thread(target=traced_worker, args=(f"Thread-{i}",))
    for i in range(4)
]

for t in threads:
    t.start()
for t in threads:
    t.join()

tracer.visualize()
```

---

## Key Takeaways

1. **GIL is a mutex** protecting Python's reference counting mechanism
2. **Time-based switching** (5ms default) replaced tick-based in Python 3.2
3. **C extensions** can release GIL for parallel execution
4. **PEP 703** introduces optional GIL in Python 3.13+
5. **Alternative implementations** (Jython, IronPython) don't have GIL
6. **Per-interpreter GIL** (Python 3.12) enables parallel subinterpreters
7. **Profiling tools** help identify GIL-related bottlenecks

---

*Next: [Interview Questions](_04_interview_questions.md)*
