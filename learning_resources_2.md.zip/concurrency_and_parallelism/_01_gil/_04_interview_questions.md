# Global Interpreter Lock (GIL) - Interview Questions

## Table of Contents
1. [Basic Questions](#basic-questions)
2. [Intermediate Questions](#intermediate-questions)
3. [Advanced Questions](#advanced-questions)
4. [Scenario-Based Questions](#scenario-based-questions)
5. [Code Analysis Questions](#code-analysis-questions)

---

## Basic Questions

### Q1: What is the Global Interpreter Lock (GIL)?

<details>
<summary>Answer</summary>

The GIL is a mutex (mutual exclusion lock) in CPython that allows only one thread to execute Python bytecode at a time. Even on multi-core processors, only one thread can hold the GIL and run Python code.

**Key points:**
- It's specific to CPython (the reference implementation)
- Protects Python's memory management (reference counting)
- Released during I/O operations
- Switches between threads every 5ms (Python 3.2+)

</details>

---

### Q2: Why does Python have a GIL?

<details>
<summary>Answer</summary>

Python has a GIL primarily because of **reference counting** for memory management.

**Reasons:**
1. **Reference counting protection**: Every Python object has a reference count. Without GIL, multiple threads could corrupt this count, causing memory leaks or crashes.

2. **Simplicity**: One global lock is simpler than fine-grained locks on every object.

3. **Single-threaded performance**: GIL makes single-threaded programs faster by avoiding lock overhead.

4. **C extension compatibility**: Many C extensions were written assuming GIL protection.

</details>

---

### Q3: Does the GIL make Python thread-safe?

<details>
<summary>Answer</summary>

**No, the GIL does NOT make Python code thread-safe.**

The GIL only ensures that:
- Reference counts are protected
- Internal interpreter state is consistent

You still need explicit synchronization for:
- Compound operations (like `counter += 1`)
- Shared data structures
- Any operation that isn't atomic

```python
# NOT thread-safe despite GIL
counter = 0
def increment():
    global counter
    for _ in range(100000):
        counter += 1  # This is NOT atomic!

# Thread-safe version
import threading
lock = threading.Lock()

def safe_increment():
    global counter
    for _ in range(100000):
        with lock:
            counter += 1
```

</details>

---

### Q4: What's the difference between CPU-bound and I/O-bound tasks in relation to GIL?

<details>
<summary>Answer</summary>

| Aspect | CPU-Bound | I/O-Bound |
|--------|-----------|-----------|
| **Definition** | Tasks doing calculations | Tasks waiting for external resources |
| **Examples** | Math, image processing, encryption | Network requests, file I/O, database |
| **GIL Impact** | Severe - no parallelism | Minimal - GIL released during wait |
| **Threading Benefit** | None (use multiprocessing) | Significant speedup |
| **Best Approach** | `multiprocessing` or C extensions | `threading` or `asyncio` |

```python
# CPU-bound: GIL is bottleneck
def cpu_bound():
    return sum(i*i for i in range(10**7))

# I/O-bound: GIL released, threading works
def io_bound():
    import urllib.request
    return urllib.request.urlopen('http://example.com').read()
```

</details>

---

## Intermediate Questions

### Q5: How can you work around the GIL for CPU-bound tasks?

<details>
<summary>Answer</summary>

**1. Multiprocessing** (Most common)
```python
from multiprocessing import Pool

def cpu_task(n):
    return sum(i*i for i in range(n))

with Pool(4) as p:
    results = p.map(cpu_task, [10**6]*4)  # True parallelism
```

**2. C Extensions that release GIL**
```python
import numpy as np
# NumPy releases GIL for many operations
arr = np.random.rand(10**7)
result = np.sum(arr)  # Parallel-friendly
```

**3. Cython with `nogil`**
```cython
cdef int compute(int n) nogil:
    cdef int i, total = 0
    for i in range(n):
        total += i * i
    return total
```

**4. ctypes/cffi** for calling C libraries

**5. concurrent.futures.ProcessPoolExecutor**
```python
from concurrent.futures import ProcessPoolExecutor

with ProcessPoolExecutor(max_workers=4) as executor:
    results = list(executor.map(cpu_task, data))
```

</details>

---

### Q6: What happens to the GIL during I/O operations?

<details>
<summary>Answer</summary>

**The GIL is released before I/O operations and reacquired after.**

```
Timeline:
Thread A: [Python code] → [Release GIL] → [Waiting for I/O] → [Acquire GIL] → [Python code]
Thread B:                  [Acquire GIL] → [Python code] → [Release GIL]

When Thread A waits for I/O:
1. Thread A releases GIL
2. OS blocks Thread A waiting for I/O
3. Thread B acquires GIL
4. Thread B runs Python code
5. When I/O completes, Thread A competes for GIL again
```

This is why threading works well for I/O-bound tasks:
```python
# All 4 downloads happen concurrently
import threading
import urllib.request

def download(url):
    return urllib.request.urlopen(url).read()

threads = [threading.Thread(target=download, args=(url,)) for url in urls]
# All threads can be "in flight" simultaneously
```

</details>

---

### Q7: How does the GIL switching mechanism work in Python 3.2+?

<details>
<summary>Answer</summary>

Python 3.2 introduced **time-based GIL switching**:

**Mechanism:**
1. A thread holds the GIL for up to 5ms (configurable)
2. After 5ms, if another thread is waiting, a "drop request" is set
3. The running thread checks this flag at safe points
4. If set, it releases the GIL and signals waiting threads
5. OS scheduler decides which thread gets it next

```python
import sys

# Check/set switch interval
print(sys.getswitchinterval())  # Default: 0.005 (5ms)
sys.setswitchinterval(0.001)    # Set to 1ms

# Note: Smaller interval = more switching overhead
# Larger interval = less fair scheduling
```

**vs Python 2.x:**
- Python 2 used "tick" counting (100 bytecode instructions)
- Problem: bytecode instructions vary wildly in execution time
- Python 3.2's time-based approach is more predictable and fair

</details>

---

### Q8: What is the "convoy effect" and how did Python 3.2 address it?

<details>
<summary>Answer</summary>

**Convoy Effect:** A performance problem where I/O-bound threads get stuck waiting behind CPU-bound threads.

**Problem (Python 2.x):**
```
CPU Thread: [████████████][████████████][████████████]
                    ↑              ↑              ↑
               I/O thread's request ignored repeatedly

I/O Thread: Request → wait → wait → wait → finally get GIL
```

**Python 3.2 Solution:**
1. Time-based switching (not tick-based)
2. Drop request mechanism
3. CPU thread MUST release GIL when requested

```
CPU Thread: [██████]─drop──[██████]─drop──[██████]
                    ↓              ↓
I/O Thread:        [IO]          [IO]

More fair distribution of execution time
```

</details>

---

## Advanced Questions

### Q9: Explain reference counting and why it necessitates the GIL.

<details>
<summary>Answer</summary>

**Reference Counting:**
Every Python object contains a reference count tracking how many references point to it.

```python
import sys

a = [1, 2, 3]
print(sys.getrefcount(a))  # Shows count (includes temp ref)

b = a  # Increment count
c = a  # Increment count
del b  # Decrement count
# When count reaches 0, object is freed
```

**Why GIL is needed:**

Without protection, race conditions corrupt counts:
```
Object X: refcount = 2

Thread 1                    Thread 2
────────                    ────────
temp = refcount (2)         temp = refcount (2)
temp = temp - 1 (1)         temp = temp - 1 (1)
refcount = temp (1)         refcount = temp (1)

Result: refcount = 1 (should be 0!)
Object leaks or gets freed while still in use.
```

**Alternatives to GIL:**
1. **Atomic operations**: Slower for single-threaded code
2. **Per-object locks**: Complex, risk of deadlocks
3. **Tracing GC only**: Would require removing refcounting entirely

Python chose GIL for simplicity and single-threaded performance.

</details>

---

### Q10: What is PEP 703 and how does it affect the GIL?

<details>
<summary>Answer</summary>

**PEP 703: Making the Global Interpreter Lock Optional**

**Status:** Accepted, experimental in Python 3.13

**Key Changes:**
1. **Build option**: `--disable-gil` creates "free-threaded" Python
2. **Biased reference counting**: Thread-local counts + shared atomic count
3. **Per-object locking**: Fine-grained locks when needed
4. **Immortal objects**: Common objects never freed, no counting needed

**Trade-offs:**
```
                    With GIL        Free-Threaded
Single-thread:      100%            85-95%
Multi-thread CPU:   ~100%           300-400%+
Memory:             100%            105-110%
```

**Code to check:**
```python
import sys
if hasattr(sys, '_is_gil_enabled'):
    print(f"GIL enabled: {sys._is_gil_enabled()}")
```

**Important:** Most existing code works unchanged, but C extensions may need updates.

</details>

---

### Q11: How do subinterpreters relate to the GIL? (Python 3.12+)

<details>
<summary>Answer</summary>

**Per-Interpreter GIL (PEP 684, Python 3.12):**

Each subinterpreter can have its own GIL, enabling true parallelism.

```
Traditional:
┌─────────────────────────────────────┐
│           ONE GIL                   │
│  ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐   │
│  │ T1  │ │ T2  │ │ T3  │ │ T4  │   │
│  └─────┘ └─────┘ └─────┘ └─────┘   │
│     All threads share ONE GIL       │
└─────────────────────────────────────┘

Per-Interpreter GIL (3.12+):
┌─────────────────┐  ┌─────────────────┐
│  Interpreter 1  │  │  Interpreter 2  │
│  ┌────┐ ┌────┐  │  │  ┌────┐ ┌────┐  │
│  │ T1 │ │ T2 │  │  │  │ T3 │ │ T4 │  │
│  └────┘ └────┘  │  │  └────┘ └────┘  │
│    GIL #1       │  │    GIL #2       │
└─────────────────┘  └─────────────────┘
       ↓                    ↓
  Can run in parallel!
```

**Limitations:**
- Objects can't be shared directly between interpreters
- Communication via pickle/channels
- Higher memory usage (separate heaps)

</details>

---

## Scenario-Based Questions

### Q12: You have a web scraper that downloads 1000 pages and parses HTML. How would you optimize it considering the GIL?

<details>
<summary>Answer</summary>

**Analysis:**
- Downloading = I/O-bound (network wait)
- Parsing HTML = CPU-bound (processing)

**Solution: Hybrid approach**

```python
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
import requests
from bs4 import BeautifulSoup

def download(url):
    """I/O-bound - use threads"""
    return requests.get(url, timeout=10).text

def parse(html):
    """CPU-bound - use processes"""
    soup = BeautifulSoup(html, 'lxml')
    return soup.get_text()

def scrape(urls):
    # Step 1: Download with threads (GIL released during I/O)
    with ThreadPoolExecutor(max_workers=50) as executor:
        htmls = list(executor.map(download, urls))
    
    # Step 2: Parse with processes (bypass GIL)
    with ProcessPoolExecutor(max_workers=4) as executor:
        texts = list(executor.map(parse, htmls))
    
    return texts
```

**Alternative: asyncio + multiprocessing**
```python
import asyncio
import aiohttp
from multiprocessing import Pool

async def download_all(urls):
    async with aiohttp.ClientSession() as session:
        tasks = [session.get(url) for url in urls]
        responses = await asyncio.gather(*tasks)
        return [await r.text() for r in responses]

def process_all(htmls):
    with Pool() as p:
        return p.map(parse, htmls)
```

</details>

---

### Q13: Your machine learning training is slow. It uses NumPy but also pure Python loops. How would you approach this?

<details>
<summary>Answer</summary>

**Diagnosis:**
```python
import cProfile
cProfile.run('train_model()')  # Identify bottlenecks
```

**Optimization Strategy:**

1. **Replace Python loops with NumPy vectorization**
```python
# Slow (GIL-bound)
for i in range(len(data)):
    result[i] = data[i] * weights[i]

# Fast (NumPy releases GIL)
result = data * weights
```

2. **Use NumPy's parallel capabilities**
```python
import os
os.environ['OMP_NUM_THREADS'] = '4'  # OpenMP threads
os.environ['MKL_NUM_THREADS'] = '4'  # Intel MKL threads
```

3. **Parallelize independent operations**
```python
from concurrent.futures import ProcessPoolExecutor

def train_batch(batch):
    return model.forward(batch), model.compute_loss(batch)

with ProcessPoolExecutor() as ex:
    results = list(ex.map(train_batch, batches))
```

4. **Consider alternatives:**
- Numba: JIT compilation, releases GIL
- Cython: Compile to C, `nogil` sections
- JAX/PyTorch: GPU acceleration

</details>

---

### Q14: You're seeing inconsistent results from a multi-threaded counter. The GIL is supposed to protect Python objects. What's happening?

<details>
<summary>Answer</summary>

**The Issue:**
```python
counter = 0
def increment():
    global counter
    for _ in range(100000):
        counter += 1
```

**Why it fails despite GIL:**

`counter += 1` is NOT atomic. It compiles to multiple bytecode instructions:

```
1. LOAD_GLOBAL    (counter)    # Load current value
2. LOAD_CONST     (1)          # Load 1
3. BINARY_ADD                  # Add them
4. STORE_GLOBAL   (counter)    # Store result
```

GIL can switch between any of these instructions:
```
Thread A: LOAD_GLOBAL (0) → [GIL switch]
Thread B: LOAD_GLOBAL (0) → ADD → STORE (1) → [GIL switch]
Thread A: ADD → STORE (1)  # Overwrites Thread B's work!
```

**Solution:**
```python
import threading
lock = threading.Lock()

def safe_increment():
    global counter
    for _ in range(100000):
        with lock:
            counter += 1
```

**Key insight:** GIL protects Python's internals, not your application logic.

</details>

---

## Code Analysis Questions

### Q15: What's wrong with this code and how would you fix it?

```python
import threading

results = []

def fetch_and_process(url):
    data = download(url)  # I/O
    processed = heavy_computation(data)  # CPU
    results.append(processed)

threads = [threading.Thread(target=fetch_and_process, args=(url,)) 
           for url in urls]
for t in threads: t.start()
for t in threads: t.join()
```

<details>
<summary>Answer</summary>

**Problems:**

1. **Mixed I/O and CPU**: Threading helps I/O but hurts CPU work
2. **Shared list modification**: `results.append()` may have race conditions
3. **No error handling**: Failed downloads crash silently

**Fixed Version:**
```python
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
import threading

def download_all(urls):
    """I/O-bound: use threads"""
    with ThreadPoolExecutor(max_workers=20) as ex:
        return list(ex.map(download, urls))

def process_all(data_list):
    """CPU-bound: use processes"""
    with ProcessPoolExecutor() as ex:
        return list(ex.map(heavy_computation, data_list))

# Sequential pipeline, parallel within each stage
raw_data = download_all(urls)
results = process_all(raw_data)
```

**Or with thread-safe collection:**
```python
import queue

results_queue = queue.Queue()

def fetch_and_process(url):
    try:
        data = download(url)
        processed = heavy_computation(data)
        results_queue.put(('success', processed))
    except Exception as e:
        results_queue.put(('error', str(e)))
```

</details>

---

### Q16: Analyze this code. Will it benefit from threading? Why or why not?

```python
def process_images(image_paths):
    results = []
    for path in image_paths:
        img = load_image(path)           # Line A
        resized = resize(img, 800, 600)  # Line B
        filtered = apply_filter(resized) # Line C
        results.append(save_image(filtered, f"out_{path}"))  # Line D
    return results
```

<details>
<summary>Answer</summary>

**Analysis by line:**

| Line | Operation | Type | GIL Impact |
|------|-----------|------|------------|
| A | `load_image` | I/O (disk read) | GIL released |
| B | `resize` | CPU (pixel manipulation) | GIL held |
| C | `apply_filter` | CPU (pixel manipulation) | GIL held |
| D | `save_image` | I/O (disk write) | GIL released |

**Will threading help?**
- Partially. I/O operations (A, D) benefit
- CPU operations (B, C) will bottleneck

**Better approach:**

```python
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor

def process_images_optimized(image_paths):
    # Stage 1: Load images (I/O - threads)
    with ThreadPoolExecutor(max_workers=10) as ex:
        images = list(ex.map(load_image, image_paths))
    
    # Stage 2: Process images (CPU - processes)
    def process(img):
        resized = resize(img, 800, 600)
        return apply_filter(resized)
    
    with ProcessPoolExecutor() as ex:
        processed = list(ex.map(process, images))
    
    # Stage 3: Save images (I/O - threads)
    def save(args):
        img, path = args
        return save_image(img, f"out_{path}")
    
    with ThreadPoolExecutor(max_workers=10) as ex:
        results = list(ex.map(save, zip(processed, image_paths)))
    
    return results
```

**Even better:** Use a library like Pillow with SIMD support, or process with NumPy (releases GIL).

</details>

---

## Quick Reference: Interview Talking Points

```
┌─────────────────────────────────────────────────────────────────────┐
│                    GIL INTERVIEW CHEAT SHEET                         │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  WHAT IT IS:                                                        │
│  • Mutex allowing one thread to execute Python bytecode             │
│  • Protects reference counting                                      │
│  • CPython-specific (Jython, IronPython don't have it)             │
│                                                                     │
│  WHEN IT MATTERS:                                                   │
│  • CPU-bound tasks: GIL = bottleneck                                │
│  • I/O-bound tasks: GIL released, threading works                   │
│                                                                     │
│  SOLUTIONS:                                                         │
│  • multiprocessing (each process has own GIL)                       │
│  • C extensions (NumPy releases GIL)                                │
│  • async/await for I/O                                              │
│  • Cython with nogil                                                │
│                                                                     │
│  COMMON MISCONCEPTIONS:                                             │
│  • "GIL makes Python thread-safe" → FALSE (still need locks)       │
│  • "Threading never works in Python" → FALSE (I/O benefits)        │
│  • "Just remove the GIL" → Complex (PEP 703 is addressing this)    │
│                                                                     │
│  RECENT DEVELOPMENTS:                                               │
│  • Python 3.12: Per-interpreter GIL                                 │
│  • Python 3.13: Optional GIL (--disable-gil)                        │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

*Back to: [Overview](_01_overview.md) | [Implementation](_02_implementation.md) | [Deep Dive](_03_deep_dive.md)*
