# Multithreading in Python - Interview Questions

## Table of Contents
1. [Basic Questions](#basic-questions)
2. [Intermediate Questions](#intermediate-questions)
3. [Advanced Questions](#advanced-questions)
4. [Scenario-Based Questions](#scenario-based-questions)
5. [Code Analysis Questions](#code-analysis-questions)

---

## Basic Questions

### Q1: What is the difference between a thread and a process?

<details>
<summary>Answer</summary>

| Aspect | Process | Thread |
|--------|---------|--------|
| Memory | Separate memory space | Shared memory space |
| Creation cost | Heavy (full memory copy) | Light (shared resources) |
| Communication | IPC (pipes, queues, sockets) | Direct shared memory |
| Isolation | Complete isolation | No isolation |
| Crash impact | Other processes unaffected | Can crash entire process |
| GIL impact | Each has own GIL | All share one GIL |

**Key insight:** Threads are "lightweight processes" that share memory, making communication easy but requiring synchronization.

</details>

---

### Q2: How do you create a thread in Python? Show two methods.

<details>
<summary>Answer</summary>

**Method 1: Using target function**
```python
import threading

def worker(name):
    print(f"Hello from {name}")

t = threading.Thread(target=worker, args=("Thread-1",))
t.start()
t.join()
```

**Method 2: Subclassing Thread**
```python
import threading

class WorkerThread(threading.Thread):
    def __init__(self, name):
        super().__init__()
        self.name = name
    
    def run(self):
        print(f"Hello from {self.name}")

t = WorkerThread("Thread-1")
t.start()
t.join()
```

**When to use which:**
- Target function: Simple tasks, one-off operations
- Subclassing: Complex threads with state, custom methods

</details>

---

### Q3: What is a daemon thread?

<details>
<summary>Answer</summary>

A daemon thread is a background thread that:
- Automatically terminates when all non-daemon threads exit
- Doesn't prevent the program from ending
- Used for background tasks like monitoring, logging

```python
import threading
import time

def background_task():
    while True:
        print("Background running...")
        time.sleep(1)

# Daemon thread - dies when main program exits
daemon = threading.Thread(target=background_task, daemon=True)
daemon.start()

# Main program
time.sleep(3)
print("Main ending - daemon will be killed")
```

**Caution:** Daemon threads may not complete cleanup (file writes, etc.) because they're killed abruptly.

</details>

---

### Q4: What does `join()` do?

<details>
<summary>Answer</summary>

`join()` blocks the calling thread until the target thread completes.

```python
import threading
import time

def worker():
    time.sleep(2)
    print("Worker done")

t = threading.Thread(target=worker)
t.start()

print("Before join")
t.join()  # Blocks here until worker completes
print("After join")  # Only prints after worker is done

# With timeout
t.join(timeout=1)  # Wait max 1 second
if t.is_alive():
    print("Thread still running!")
```

**Without join:** Main thread might exit before worker finishes.

</details>

---

## Intermediate Questions

### Q5: What is a race condition? How do you prevent it?

<details>
<summary>Answer</summary>

**Race condition:** When the behavior of code depends on the timing/order of thread execution.

```python
# Example of race condition
counter = 0

def increment():
    global counter
    for _ in range(100000):
        counter += 1  # NOT atomic!

# Two threads incrementing
t1 = threading.Thread(target=increment)
t2 = threading.Thread(target=increment)
t1.start(); t2.start()
t1.join(); t2.join()

print(counter)  # Less than 200000!
```

**Prevention methods:**
1. **Lock:** Mutual exclusion
2. **RLock:** Reentrant lock
3. **Atomic operations:** Using queue.Queue
4. **Thread-local storage:** `threading.local()`

```python
# Fixed with lock
lock = threading.Lock()

def safe_increment():
    global counter
    for _ in range(100000):
        with lock:
            counter += 1
```

</details>

---

### Q6: Explain the difference between Lock and RLock.

<details>
<summary>Answer</summary>

| Feature | Lock | RLock |
|---------|------|-------|
| Same thread re-acquire | Deadlock! | Allowed |
| Overhead | Lower | Higher |
| Use case | Simple mutual exclusion | Recursive calls |

```python
import threading

lock = threading.Lock()
rlock = threading.RLock()

def outer():
    with lock:
        inner()  # DEADLOCK with Lock!

def inner():
    with lock:  # Same thread trying to acquire again
        print("Inner")

# With RLock - works fine
def outer_r():
    with rlock:
        inner_r()  # OK - same thread can re-acquire

def inner_r():
    with rlock:
        print("Inner")  # Works!
```

**Rule:** Use RLock when a function with a lock might call other functions that need the same lock.

</details>

---

### Q7: What is a deadlock? How do you prevent it?

<details>
<summary>Answer</summary>

**Deadlock:** Two or more threads waiting for each other, causing all to block forever.

```python
# Deadlock example
lock_a = threading.Lock()
lock_b = threading.Lock()

def thread_1():
    with lock_a:
        time.sleep(0.1)
        with lock_b:  # Waiting for lock_b
            print("Thread 1")

def thread_2():
    with lock_b:
        time.sleep(0.1)
        with lock_a:  # Waiting for lock_a
            print("Thread 2")

# Both threads wait forever!
```

**Prevention strategies:**
1. **Lock ordering:** Always acquire locks in same order
2. **Timeout:** Use `lock.acquire(timeout=5)`
3. **Try-lock:** `if lock.acquire(blocking=False): ...`
4. **Single lock:** Use one lock instead of multiple

```python
# Fixed: Consistent lock ordering
def thread_1_fixed():
    with lock_a:  # Always A first
        with lock_b:
            print("Thread 1")

def thread_2_fixed():
    with lock_a:  # Always A first (not B!)
        with lock_b:
            print("Thread 2")
```

</details>

---

### Q8: When would you use Semaphore?

<details>
<summary>Answer</summary>

**Semaphore:** Allows N threads to access a resource simultaneously.

**Use cases:**
1. **Connection pools:** Limit database connections
2. **Rate limiting:** Control API calls
3. **Resource pools:** Manage limited resources

```python
import threading
import time

# Only 3 threads can download at once
download_semaphore = threading.Semaphore(3)

def download(url):
    with download_semaphore:
        print(f"Downloading {url}")
        time.sleep(2)  # Simulate download
        print(f"Done {url}")

# Start 10 downloads, but only 3 run at a time
threads = [
    threading.Thread(target=download, args=(f"url_{i}",))
    for i in range(10)
]

for t in threads:
    t.start()
for t in threads:
    t.join()
```

**BoundedSemaphore:** Same but raises error if released too many times (catches bugs).

</details>

---

## Advanced Questions

### Q9: Explain the difference between threading.Event, threading.Condition, and threading.Barrier.

<details>
<summary>Answer</summary>

| Primitive | Purpose | Pattern |
|-----------|---------|---------|
| Event | One-time or toggle signal | "Start!" / "Stop!" |
| Condition | Wait for complex condition | Producer-Consumer |
| Barrier | Synchronization point | "Everyone wait, then go" |

**Event:** Simple flag
```python
event = threading.Event()
event.wait()   # Block until set
event.set()    # Signal all waiters
event.clear()  # Reset the flag
```

**Condition:** Wait/notify with custom logic
```python
condition = threading.Condition()
items = []

# Consumer
with condition:
    while not items:  # Check condition
        condition.wait()  # Release lock, wait
    item = items.pop()

# Producer
with condition:
    items.append(item)
    condition.notify()  # Wake one waiter
```

**Barrier:** N threads must reach point before any continue
```python
barrier = threading.Barrier(3)

def worker():
    print("Phase 1")
    barrier.wait()  # All 3 must reach here
    print("Phase 2")  # Then all continue
```

</details>

---

### Q10: How does ThreadPoolExecutor work internally?

<details>
<summary>Answer</summary>

**Internal architecture:**
```
┌─────────────────────────────────────────────────────┐
│                ThreadPoolExecutor                    │
├─────────────────────────────────────────────────────┤
│                                                     │
│  Work Queue (SimpleQueue)                           │
│  ┌─────┬─────┬─────┬─────┬─────┐                   │
│  │Task1│Task2│Task3│Task4│Task5│...                │
│  └─────┴─────┴─────┴─────┴─────┘                   │
│            │                                        │
│            ▼                                        │
│  ┌─────────────────────────────────┐               │
│  │     Worker Threads (pool)       │               │
│  │  ┌────┐ ┌────┐ ┌────┐ ┌────┐   │               │
│  │  │ W1 │ │ W2 │ │ W3 │ │ W4 │   │               │
│  │  └────┘ └────┘ └────┘ └────┘   │               │
│  │  Each pulls from queue          │               │
│  └─────────────────────────────────┘               │
│                                                     │
│  Futures (results)                                  │
│  ┌────────┬────────┬────────┐                      │
│  │Future1 │Future2 │Future3 │                      │
│  └────────┴────────┴────────┘                      │
│                                                     │
└─────────────────────────────────────────────────────┘
```

**Key components:**
1. **Work queue:** Holds pending tasks
2. **Worker threads:** Pull and execute tasks
3. **Futures:** Represent pending results

```python
from concurrent.futures import ThreadPoolExecutor, as_completed

with ThreadPoolExecutor(max_workers=4) as executor:
    # submit() returns Future immediately
    future = executor.submit(func, arg)
    
    # map() applies function to all items
    results = executor.map(func, items)
    
    # as_completed() yields futures as they finish
    futures = [executor.submit(func, i) for i in items]
    for future in as_completed(futures):
        result = future.result()
```

</details>

---

### Q11: How do you handle exceptions in threads?

<details>
<summary>Answer</summary>

**Problem:** Exceptions in threads don't propagate to main thread.

```python
import threading

def buggy_worker():
    raise ValueError("Oops!")

t = threading.Thread(target=buggy_worker)
t.start()
t.join()
print("Main continues - exception was silent!")
```

**Solutions:**

**1. Wrap with exception handling:**
```python
def safe_worker(result_queue):
    try:
        # Work here
        result_queue.put(("success", result))
    except Exception as e:
        result_queue.put(("error", e))

import queue
results = queue.Queue()
t = threading.Thread(target=safe_worker, args=(results,))
t.start()
t.join()

status, value = results.get()
if status == "error":
    raise value
```

**2. Use ThreadPoolExecutor (recommended):**
```python
from concurrent.futures import ThreadPoolExecutor

def worker():
    raise ValueError("Oops!")

with ThreadPoolExecutor() as executor:
    future = executor.submit(worker)
    try:
        result = future.result()  # Re-raises exception
    except ValueError as e:
        print(f"Caught: {e}")
```

**3. Custom exception handler:**
```python
import threading
import sys

def exception_handler(args):
    print(f"Exception in {args.thread.name}: {args.exc_value}")

threading.excepthook = exception_handler
```

</details>

---

## Scenario-Based Questions

### Q12: Design a thread-safe counter class.

<details>
<summary>Answer</summary>

```python
import threading

class ThreadSafeCounter:
    def __init__(self, initial=0):
        self._value = initial
        self._lock = threading.Lock()
    
    def increment(self):
        with self._lock:
            self._value += 1
            return self._value
    
    def decrement(self):
        with self._lock:
            self._value -= 1
            return self._value
    
    def get(self):
        with self._lock:
            return self._value
    
    def add(self, amount):
        with self._lock:
            self._value += amount
            return self._value

# Thread-safe usage
counter = ThreadSafeCounter()

def worker():
    for _ in range(10000):
        counter.increment()

threads = [threading.Thread(target=worker) for _ in range(10)]
for t in threads:
    t.start()
for t in threads:
    t.join()

print(counter.get())  # Always 100000
```

</details>

---

### Q13: Implement a thread-safe bounded buffer (producer-consumer).

<details>
<summary>Answer</summary>

```python
import threading
from collections import deque

class BoundedBuffer:
    def __init__(self, capacity):
        self._buffer = deque(maxlen=capacity)
        self._capacity = capacity
        self._lock = threading.Lock()
        self._not_full = threading.Condition(self._lock)
        self._not_empty = threading.Condition(self._lock)
    
    def put(self, item):
        with self._not_full:
            while len(self._buffer) >= self._capacity:
                self._not_full.wait()  # Wait until space available
            
            self._buffer.append(item)
            self._not_empty.notify()  # Signal consumers
    
    def get(self):
        with self._not_empty:
            while len(self._buffer) == 0:
                self._not_empty.wait()  # Wait until item available
            
            item = self._buffer.popleft()
            self._not_full.notify()  # Signal producers
            return item
    
    def __len__(self):
        with self._lock:
            return len(self._buffer)

# Usage
buffer = BoundedBuffer(capacity=5)

def producer():
    for i in range(10):
        buffer.put(f"item-{i}")
        print(f"Produced item-{i}")

def consumer():
    for _ in range(10):
        item = buffer.get()
        print(f"Consumed {item}")

p = threading.Thread(target=producer)
c = threading.Thread(target=consumer)
p.start(); c.start()
p.join(); c.join()
```

</details>

---

### Q14: You have a function that makes API calls. How would you parallelize 100 calls while limiting to max 10 concurrent requests?

<details>
<summary>Answer</summary>

**Method 1: Using Semaphore**
```python
import threading
import time

semaphore = threading.Semaphore(10)

def api_call(url):
    with semaphore:  # Max 10 at a time
        print(f"Calling {url}")
        time.sleep(1)  # Simulate API call
        return f"Response from {url}"

threads = []
for i in range(100):
    t = threading.Thread(target=api_call, args=(f"url_{i}",))
    threads.append(t)
    t.start()

for t in threads:
    t.join()
```

**Method 2: Using ThreadPoolExecutor (Recommended)**
```python
from concurrent.futures import ThreadPoolExecutor
import time

def api_call(url):
    time.sleep(1)  # Simulate API call
    return f"Response from {url}"

urls = [f"url_{i}" for i in range(100)]

# max_workers=10 limits concurrent calls
with ThreadPoolExecutor(max_workers=10) as executor:
    results = list(executor.map(api_call, urls))

print(f"Got {len(results)} responses")
```

**Method 3: With rate limiting**
```python
import threading
import time

class RateLimitedPool:
    def __init__(self, max_concurrent, calls_per_second):
        self.semaphore = threading.Semaphore(max_concurrent)
        self.rate_limiter = threading.Semaphore(calls_per_second)
        self._start_rate_reset()
    
    def _start_rate_reset(self):
        def reset():
            while True:
                time.sleep(1)
                # Reset rate limiter each second
                try:
                    while True:
                        self.rate_limiter.release()
                except ValueError:
                    pass
        
        t = threading.Thread(target=reset, daemon=True)
        t.start()
    
    def call(self, func, *args):
        with self.semaphore:
            self.rate_limiter.acquire()
            return func(*args)
```

</details>

---

## Code Analysis Questions

### Q15: What's wrong with this code?

```python
import threading

data = []

def worker(n):
    for i in range(n):
        data.append(i)
        if len(data) > 1000:
            data.clear()

threads = [threading.Thread(target=worker, args=(10000,)) for _ in range(5)]
for t in threads:
    t.start()
for t in threads:
    t.join()
```

<details>
<summary>Answer</summary>

**Problems:**

1. **Race condition on `len(data) > 1000` and `data.clear()`:**
   - Thread A checks len (999)
   - Thread B appends, now len is 1000
   - Thread A appends (len now 1001)
   - Thread A checks len (1001 > 1000) and clears
   - Thread B also checks (1001 > 1000) and clears again

2. **Race condition between append and clear:**
   - While one thread is clearing, another might be appending

**Fixed version:**
```python
import threading

data = []
lock = threading.Lock()

def worker(n):
    for i in range(n):
        with lock:
            data.append(i)
            if len(data) > 1000:
                data.clear()
```

**Even better:** Use thread-safe data structure or rethink the design.

</details>

---

### Q16: Will this code deadlock? Why or why not?

```python
import threading

lock = threading.Lock()

def func_a():
    with lock:
        print("A acquired lock")
        func_b()

def func_b():
    with lock:
        print("B acquired lock")

func_a()
```

<details>
<summary>Answer</summary>

**YES, this will deadlock!**

**Sequence:**
1. `func_a()` acquires `lock`
2. `func_a()` calls `func_b()`
3. `func_b()` tries to acquire `lock`
4. `lock` is already held by the same thread
5. Thread waits forever for itself → **DEADLOCK**

**Fix: Use RLock (Reentrant Lock)**
```python
import threading

lock = threading.RLock()  # Changed from Lock to RLock

def func_a():
    with lock:
        print("A acquired lock")
        func_b()  # Same thread can re-acquire

def func_b():
    with lock:
        print("B acquired lock")

func_a()  # Works fine now!
```

**RLock allows the same thread to acquire the lock multiple times.**

</details>

---

## Quick Reference: Interview Cheat Sheet

```
┌─────────────────────────────────────────────────────────────────────┐
│              MULTITHREADING INTERVIEW CHEAT SHEET                    │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  WHEN TO USE THREADS:                                               │
│  ✅ I/O-bound tasks (network, file, database)                       │
│  ✅ GUI responsiveness                                              │
│  ❌ CPU-bound tasks (use multiprocessing instead)                   │
│                                                                     │
│  SYNCHRONIZATION PRIMITIVES:                                        │
│  • Lock: Basic mutual exclusion                                     │
│  • RLock: Same thread can re-acquire                                │
│  • Semaphore: Allow N threads                                       │
│  • Event: Simple signaling                                          │
│  • Condition: Complex wait/notify                                   │
│  • Barrier: Sync point for N threads                                │
│                                                                     │
│  COMMON PROBLEMS:                                                   │
│  • Race condition → Use locks                                       │
│  • Deadlock → Lock ordering, timeout, single lock                   │
│  • Starvation → Fair scheduling, priority queues                    │
│  • GIL limitation → Use multiprocessing for CPU tasks               │
│                                                                     │
│  BEST PRACTICES:                                                    │
│  • Use ThreadPoolExecutor (not raw threads)                         │
│  • Use context managers (with lock:)                                │
│  • Keep critical sections small                                     │
│  • Prefer thread-safe data structures (queue.Queue)                 │
│  • Don't share mutable state if possible                            │
│                                                                     │
│  THREAD POOL SIZING:                                                │
│  • I/O-bound: cpu_count * 5 (or more)                              │
│  • CPU-bound: cpu_count (but use processes!)                        │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

*Back to: [Overview](_01_overview.md) | [Implementation](_02_implementation.md) | [Deep Dive](_03_deep_dive.md)*
