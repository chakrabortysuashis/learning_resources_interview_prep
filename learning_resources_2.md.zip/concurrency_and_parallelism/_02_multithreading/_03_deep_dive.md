# Multithreading in Python - Deep Dive

## Table of Contents
1. [Thread Internals](#1-thread-internals)
2. [Memory Model & Visibility](#2-memory-model--visibility)
3. [Advanced Synchronization](#3-advanced-synchronization)
4. [Thread Safety Patterns](#4-thread-safety-patterns)
5. [Performance Optimization](#5-performance-optimization)
6. [Debugging Threaded Code](#6-debugging-threaded-code)
7. [Common Pitfalls & Solutions](#7-common-pitfalls--solutions)

---

## 1. Thread Internals

### How Python Threads Map to OS Threads

```
┌─────────────────────────────────────────────────────────────────────┐
│                   PYTHON THREAD ARCHITECTURE                         │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Python Level            CPython Level           OS Level           │
│  ────────────            ─────────────           ────────           │
│                                                                     │
│  threading.Thread   ──▶  PyThreadState    ──▶   pthread_t          │
│  (Python object)         (C structure)          (OS thread)         │
│                                                                     │
│  ┌─────────────┐        ┌──────────────┐       ┌──────────────┐    │
│  │ target=func │        │ frame        │       │ stack        │    │
│  │ args=(...)  │        │ recursion    │       │ registers    │    │
│  │ name="..."  │        │ exception    │       │ TLS          │    │
│  │ daemon=bool │        │ dict         │       │ priority     │    │
│  └─────────────┘        │ GIL state    │       └──────────────┘    │
│                         └──────────────┘                            │
│                                                                     │
│  Python threads are 1:1 with OS threads (native threads)            │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Thread State Transitions

```python
import threading
import time

def show_thread_states():
    """Demonstrate thread state transitions"""
    
    def worker():
        time.sleep(2)
    
    t = threading.Thread(target=worker)
    
    # State: CREATED (not started yet)
    print(f"Created - is_alive: {t.is_alive()}, ident: {t.ident}")
    # is_alive: False, ident: None
    
    t.start()
    
    # State: RUNNING
    print(f"Started - is_alive: {t.is_alive()}, ident: {t.ident}")
    # is_alive: True, ident: 12345 (some number)
    
    t.join()
    
    # State: TERMINATED
    print(f"Joined - is_alive: {t.is_alive()}, ident: {t.ident}")
    # is_alive: False, ident: 12345 (still has ident)

show_thread_states()
```

### Thread Stack Size

```python
import threading
import sys

# Get/set thread stack size
current_size = threading.stack_size()
print(f"Default stack size: {current_size}")  # 0 means OS default

# Set custom stack size (must be >= 32KB and multiple of 4KB)
# threading.stack_size(65536)  # 64KB

# Recursion in threads
def recursive_func(depth, max_depth):
    if depth >= max_depth:
        return depth
    return recursive_func(depth + 1, max_depth)

def test_recursion():
    try:
        result = recursive_func(0, 10000)
        print(f"Reached depth: {result}")
    except RecursionError:
        print("RecursionError hit")

# Thread has its own recursion limit
t = threading.Thread(target=test_recursion)
t.start()
t.join()
```

---

## 2. Memory Model & Visibility

### Memory Visibility Problem

```
┌─────────────────────────────────────────────────────────────────────┐
│                   MEMORY VISIBILITY ISSUE                            │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Thread A (CPU 1)                    Thread B (CPU 2)               │
│  ┌──────────────┐                   ┌──────────────┐                │
│  │ CPU Cache    │                   │ CPU Cache    │                │
│  │ flag = True  │                   │ flag = False │                │
│  └──────┬───────┘                   └──────┬───────┘                │
│         │                                  │                        │
│         └──────────┬───────────────────────┘                        │
│                    │                                                │
│              ┌─────┴─────┐                                          │
│              │  Main     │                                          │
│              │  Memory   │                                          │
│              │ flag = ???│                                          │
│              └───────────┘                                          │
│                                                                     │
│  Without proper synchronization, Thread B might not see             │
│  Thread A's update to 'flag' immediately (or ever!)                 │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Ensuring Visibility with Locks

```python
import threading
import time

# WRONG: No synchronization
class UnsafeFlag:
    def __init__(self):
        self.flag = False
    
    def set(self):
        self.flag = True
    
    def check(self):
        return self.flag

# RIGHT: Using lock for visibility
class SafeFlag:
    def __init__(self):
        self._flag = False
        self._lock = threading.Lock()
    
    def set(self):
        with self._lock:
            self._flag = True
    
    def check(self):
        with self._lock:
            return self._flag

# RIGHT: Using Event (simpler for flags)
class EventFlag:
    def __init__(self):
        self._event = threading.Event()
    
    def set(self):
        self._event.set()
    
    def check(self):
        return self._event.is_set()
    
    def wait(self, timeout=None):
        return self._event.wait(timeout)
```

### Atomic Operations

```python
import threading

# These operations are ATOMIC in CPython (due to GIL):
# - Reading/writing a single variable
# - List append/pop
# - Dict get/set
# - Set add/remove

# These are NOT ATOMIC:
# - counter += 1 (read-modify-write)
# - list.sort()
# - Multiple operations

# Example: Atomic vs Non-Atomic
shared_list = []
counter = 0

def atomic_operations():
    # Atomic - safe without lock (but lock still recommended!)
    shared_list.append("item")
    
def non_atomic_operations():
    global counter
    # NOT atomic - needs lock!
    counter += 1  # Actually: tmp = counter; tmp += 1; counter = tmp

# For guaranteed safety, always use locks for shared data
lock = threading.Lock()

def safe_increment():
    global counter
    with lock:
        counter += 1
```

---

## 3. Advanced Synchronization

### Read-Write Lock Pattern

```python
import threading

class ReadWriteLock:
    """
    Multiple readers can access simultaneously.
    Writers get exclusive access.
    """
    def __init__(self):
        self._read_ready = threading.Condition(threading.Lock())
        self._readers = 0
    
    def acquire_read(self):
        with self._read_ready:
            self._readers += 1
    
    def release_read(self):
        with self._read_ready:
            self._readers -= 1
            if self._readers == 0:
                self._read_ready.notify_all()
    
    def acquire_write(self):
        self._read_ready.acquire()
        while self._readers > 0:
            self._read_ready.wait()
    
    def release_write(self):
        self._read_ready.release()

# Usage with context manager
class ReadLock:
    def __init__(self, rw_lock):
        self.rw_lock = rw_lock
    
    def __enter__(self):
        self.rw_lock.acquire_read()
        return self
    
    def __exit__(self, *args):
        self.rw_lock.release_read()

class WriteLock:
    def __init__(self, rw_lock):
        self.rw_lock = rw_lock
    
    def __enter__(self):
        self.rw_lock.acquire_write()
        return self
    
    def __exit__(self, *args):
        self.rw_lock.release_write()

# Example usage
rw_lock = ReadWriteLock()
data = {"value": 0}

def reader(name):
    with ReadLock(rw_lock):
        print(f"{name} reading: {data['value']}")

def writer(name, value):
    with WriteLock(rw_lock):
        print(f"{name} writing: {value}")
        data['value'] = value
```

### Double-Checked Locking (Singleton)

```python
import threading

class Singleton:
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls):
        # First check (no lock) - fast path
        if cls._instance is None:
            with cls._lock:
                # Second check (with lock) - safe creation
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
        return cls._instance

# Thread-safe usage
def get_instance():
    return Singleton()

# All threads get the same instance
threads = [threading.Thread(target=get_instance) for _ in range(10)]
for t in threads:
    t.start()
for t in threads:
    t.join()
```

### Lock Ordering to Prevent Deadlock

```python
import threading

# Resources with assigned IDs for ordering
class Resource:
    _counter = 0
    _counter_lock = threading.Lock()
    
    def __init__(self, name):
        with Resource._counter_lock:
            self._id = Resource._counter
            Resource._counter += 1
        self.name = name
        self.lock = threading.Lock()
    
    @property
    def id(self):
        return self._id

def use_resources(res1, res2):
    """Always acquire locks in ID order to prevent deadlock"""
    first, second = sorted([res1, res2], key=lambda r: r.id)
    
    with first.lock:
        with second.lock:
            print(f"Using {res1.name} and {res2.name}")

# Even if threads call with different order, no deadlock!
r1 = Resource("A")
r2 = Resource("B")

t1 = threading.Thread(target=use_resources, args=(r1, r2))
t2 = threading.Thread(target=use_resources, args=(r2, r1))  # Reversed!

t1.start()
t2.start()
t1.join()
t2.join()
```

---

## 4. Thread Safety Patterns

### Immutable Objects

```python
from dataclasses import dataclass
from typing import Tuple

@dataclass(frozen=True)
class ImmutableConfig:
    """Immutable = thread-safe by default"""
    host: str
    port: int
    options: Tuple[str, ...]  # Use tuple, not list
    
    # No setters possible, no lock needed
    def with_port(self, new_port):
        """Create new instance instead of modifying"""
        return ImmutableConfig(self.host, new_port, self.options)

# Safe to share across threads
config = ImmutableConfig("localhost", 8080, ("option1", "option2"))
```

### Thread-Safe Lazy Initialization

```python
import threading
from functools import lru_cache

class LazyLoader:
    def __init__(self):
        self._data = None
        self._lock = threading.Lock()
        self._loaded = threading.Event()
    
    def get_data(self):
        if self._loaded.is_set():
            return self._data
        
        with self._lock:
            if self._data is None:
                self._data = self._expensive_load()
                self._loaded.set()
        
        return self._data
    
    def _expensive_load(self):
        # Simulate expensive initialization
        import time
        time.sleep(1)
        return {"key": "value"}

# Alternative: Using lru_cache (thread-safe)
@lru_cache(maxsize=1)
def get_expensive_resource():
    import time
    time.sleep(1)
    return {"key": "value"}
```

### Copy-on-Write Pattern

```python
import threading
import copy

class CopyOnWriteList:
    """Thread-safe list using copy-on-write"""
    
    def __init__(self):
        self._list = []
        self._lock = threading.Lock()
    
    def append(self, item):
        with self._lock:
            new_list = self._list.copy()
            new_list.append(item)
            self._list = new_list
    
    def get_snapshot(self):
        """Returns a snapshot - safe to iterate"""
        return self._list  # No lock needed - reference is atomic
    
    def __iter__(self):
        """Iteration over snapshot"""
        return iter(self.get_snapshot())

# Readers never block, even during writes
cow_list = CopyOnWriteList()

def reader():
    for item in cow_list:  # Safe iteration
        print(item)

def writer():
    cow_list.append("new_item")
```

---

## 5. Performance Optimization

### Lock Granularity

```python
import threading
import time

# COARSE-GRAINED: One lock for everything (simple but slow)
class CoarseGrainedCache:
    def __init__(self):
        self._data = {}
        self._lock = threading.Lock()
    
    def get(self, key):
        with self._lock:
            return self._data.get(key)
    
    def set(self, key, value):
        with self._lock:
            self._data[key] = value

# FINE-GRAINED: Lock per bucket (complex but faster)
class FineGrainedCache:
    def __init__(self, num_buckets=16):
        self._buckets = [{} for _ in range(num_buckets)]
        self._locks = [threading.Lock() for _ in range(num_buckets)]
        self._num_buckets = num_buckets
    
    def _get_bucket(self, key):
        index = hash(key) % self._num_buckets
        return self._buckets[index], self._locks[index]
    
    def get(self, key):
        bucket, lock = self._get_bucket(key)
        with lock:
            return bucket.get(key)
    
    def set(self, key, value):
        bucket, lock = self._get_bucket(key)
        with lock:
            bucket[key] = value
```

### Reducing Lock Contention

```python
import threading
from collections import deque

class BatchProcessor:
    """Batch updates to reduce lock contention"""
    
    def __init__(self, batch_size=100):
        self._pending = threading.local()
        self._global_data = []
        self._lock = threading.Lock()
        self._batch_size = batch_size
    
    def add(self, item):
        # Thread-local buffer (no lock needed)
        if not hasattr(self._pending, 'buffer'):
            self._pending.buffer = []
        
        self._pending.buffer.append(item)
        
        # Flush when batch is full
        if len(self._pending.buffer) >= self._batch_size:
            self._flush()
    
    def _flush(self):
        if hasattr(self._pending, 'buffer') and self._pending.buffer:
            with self._lock:
                self._global_data.extend(self._pending.buffer)
            self._pending.buffer = []
    
    def flush_all(self):
        self._flush()
```

### Thread Pool Sizing

```python
import os
from concurrent.futures import ThreadPoolExecutor
import time

def optimal_thread_count(task_type="io"):
    """
    Calculate optimal thread count based on task type
    """
    cpu_count = os.cpu_count() or 1
    
    if task_type == "cpu":
        # CPU-bound: use multiprocessing instead!
        return cpu_count
    elif task_type == "io":
        # I/O-bound: more threads than CPUs
        # Formula: threads = cpu_count * (1 + wait_time/service_time)
        # For network I/O, ratio is typically 5-10
        return cpu_count * 5
    elif task_type == "mixed":
        return cpu_count * 2

# Benchmark different pool sizes
def benchmark_pool_size(pool_size, num_tasks=100):
    def io_task():
        time.sleep(0.1)  # Simulate I/O
        return True
    
    start = time.perf_counter()
    with ThreadPoolExecutor(max_workers=pool_size) as executor:
        list(executor.map(io_task, range(num_tasks)))
    elapsed = time.perf_counter() - start
    
    return elapsed

# Find optimal size
for size in [5, 10, 20, 50, 100]:
    elapsed = benchmark_pool_size(size)
    print(f"Pool size {size:3d}: {elapsed:.2f}s")
```

---

## 6. Debugging Threaded Code

### Thread Debugging Tools

```python
import threading
import sys
import traceback

def dump_threads():
    """Print stack traces of all threads"""
    print("\n*** THREAD DUMP ***")
    for thread_id, frame in sys._current_frames().items():
        name = threading._active.get(thread_id, 
               threading.Thread(name="Unknown")).name
        print(f"\nThread: {name} (ID: {thread_id})")
        traceback.print_stack(frame)

# Register signal handler for debugging
import signal
signal.signal(signal.SIGUSR1, lambda sig, frame: dump_threads())

# Example: Detect potential deadlock
class DeadlockDetector:
    def __init__(self, timeout=5):
        self.timeout = timeout
        self._lock_order = threading.local()
    
    def acquire(self, lock, name):
        if not hasattr(self._lock_order, 'held'):
            self._lock_order.held = []
        
        # Try to acquire with timeout
        acquired = lock.acquire(timeout=self.timeout)
        if not acquired:
            print(f"Potential deadlock! Waiting for {name}")
            print(f"Currently holding: {self._lock_order.held}")
            dump_threads()
            raise TimeoutError(f"Could not acquire {name}")
        
        self._lock_order.held.append(name)
        return True
    
    def release(self, lock, name):
        lock.release()
        self._lock_order.held.remove(name)
```

### Logging in Threaded Applications

```python
import logging
import threading
import time

# Configure thread-safe logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s [%(threadName)s] %(levelname)s: %(message)s',
    handlers=[logging.StreamHandler()]
)

logger = logging.getLogger(__name__)

def worker(name):
    logger.info(f"Worker {name} starting")
    time.sleep(1)
    logger.debug(f"Worker {name} processing")
    time.sleep(1)
    logger.info(f"Worker {name} completed")

# Threads automatically include their name in logs
threads = [
    threading.Thread(target=worker, args=(i,), name=f"Worker-{i}")
    for i in range(3)
]

for t in threads:
    t.start()
for t in threads:
    t.join()
```

### Race Condition Detection

```python
import threading
import time
import random

class RaceDetector:
    """Simple race condition detector for debugging"""
    
    def __init__(self):
        self._accesses = {}
        self._lock = threading.Lock()
    
    def access(self, resource_name, access_type):
        thread_id = threading.current_thread().name
        timestamp = time.time()
        
        with self._lock:
            if resource_name not in self._accesses:
                self._accesses[resource_name] = []
            
            # Check for concurrent access
            recent = [a for a in self._accesses[resource_name] 
                     if timestamp - a['time'] < 0.001]  # Within 1ms
            
            for access in recent:
                if access['thread'] != thread_id:
                    if access['type'] == 'write' or access_type == 'write':
                        print(f"RACE DETECTED on {resource_name}!")
                        print(f"  {access['thread']} ({access['type']}) vs "
                              f"{thread_id} ({access_type})")
            
            self._accesses[resource_name].append({
                'thread': thread_id,
                'type': access_type,
                'time': timestamp
            })

# Usage
detector = RaceDetector()
shared_data = [0]

def unsafe_increment():
    detector.access('shared_data', 'read')
    val = shared_data[0]
    
    time.sleep(random.uniform(0, 0.001))  # Simulate delay
    
    detector.access('shared_data', 'write')
    shared_data[0] = val + 1

threads = [threading.Thread(target=unsafe_increment) for _ in range(10)]
for t in threads:
    t.start()
for t in threads:
    t.join()
```

---

## 7. Common Pitfalls & Solutions

### Pitfall 1: Modifying Shared Data Without Lock

```python
# WRONG
results = []
def worker():
    results.append(process())  # May miss items!

# RIGHT
results = []
lock = threading.Lock()
def worker():
    result = process()
    with lock:
        results.append(result)

# BETTER: Use thread-safe queue
import queue
results = queue.Queue()
def worker():
    results.put(process())  # Thread-safe
```

### Pitfall 2: Catching BaseException and Breaking Cleanup

```python
# WRONG: Lock never released if KeyboardInterrupt
lock.acquire()
try:
    do_work()
except:  # Catches KeyboardInterrupt
    pass  # Lock still held!
finally:
    lock.release()

# RIGHT: Use context manager
with lock:
    do_work()  # Always released, even on interrupt
```

### Pitfall 3: Daemon Threads Losing Data

```python
import threading
import queue
import time
import atexit

# WRONG: Data lost when main exits
work_queue = queue.Queue()

def worker():
    while True:
        item = work_queue.get()
        process(item)  # May not complete!

daemon = threading.Thread(target=worker, daemon=True)
daemon.start()

# RIGHT: Graceful shutdown
shutdown_event = threading.Event()

def worker():
    while not shutdown_event.is_set():
        try:
            item = work_queue.get(timeout=0.1)
            process(item)
        except queue.Empty:
            continue

def cleanup():
    shutdown_event.set()
    daemon.join(timeout=5)

atexit.register(cleanup)
```

### Pitfall 4: Thread Leaks

```python
import threading
import weakref

# Track active threads
active_threads = weakref.WeakSet()

def tracked_thread_factory(target, *args, **kwargs):
    def wrapper():
        try:
            target(*args, **kwargs)
        finally:
            pass  # Thread automatically removed from WeakSet
    
    t = threading.Thread(target=wrapper)
    active_threads.add(t)
    return t

# Monitor thread count
def check_thread_count():
    active = len(list(active_threads))
    total = threading.active_count()
    print(f"Tracked: {active}, Total: {total}")
```

---

## Performance Comparison Table

| Scenario | Single-Thread | Multi-Thread | Notes |
|----------|---------------|--------------|-------|
| 10 HTTP requests | 10s | 1s | I/O-bound, excellent speedup |
| 10 file reads | 5s | 0.5s | I/O-bound, excellent speedup |
| 10 CPU calculations | 10s | 10s | GIL blocks parallelism |
| Mixed I/O + CPU | 10s | 5s | Partial benefit |

---

*Next: [Interview Questions](_04_interview_questions.md)*
