# Multithreading in Python - Implementation & Code

## Table of Contents
1. [Creating Threads](#1-creating-threads)
2. [Thread Methods & Properties](#2-thread-methods--properties)
3. [Synchronization Primitives](#3-synchronization-primitives)
4. [Thread Pools](#4-thread-pools)
5. [Thread Communication](#5-thread-communication)
6. [Practical Patterns](#6-practical-patterns)

---

## 1. Creating Threads

### Method 1: Using Target Function

```python
import threading
import time

def worker(name, delay):
    """A simple worker function"""
    print(f"{name} starting")
    time.sleep(delay)
    print(f"{name} finished")

# Create threads
t1 = threading.Thread(target=worker, args=("Thread-1", 2))
t2 = threading.Thread(target=worker, args=("Thread-2", 1))

# Start threads
t1.start()
t2.start()

# Wait for completion
t1.join()
t2.join()

print("All threads completed!")
```

### Method 2: Subclassing Thread

```python
import threading
import time

class WorkerThread(threading.Thread):
    def __init__(self, name, delay):
        super().__init__()
        self.name = name
        self.delay = delay
        self.result = None
    
    def run(self):
        """This method runs when thread starts"""
        print(f"{self.name} starting")
        time.sleep(self.delay)
        self.result = f"{self.name} completed after {self.delay}s"
        print(f"{self.name} finished")

# Create and run
threads = [WorkerThread(f"Worker-{i}", i) for i in range(1, 4)]

for t in threads:
    t.start()

for t in threads:
    t.join()
    print(f"Result: {t.result}")
```

### Method 3: Using Lambda/Inline Functions

```python
import threading

data = []

# Quick inline thread
t = threading.Thread(target=lambda: data.append("from thread"))
t.start()
t.join()

print(data)  # ['from thread']
```

---

## 2. Thread Methods & Properties

### Essential Thread Methods

```python
import threading
import time

def long_task():
    for i in range(5):
        print(f"Working... {i}")
        time.sleep(1)

t = threading.Thread(target=long_task, name="MyWorker")

# Before starting
print(f"Thread name: {t.name}")           # MyWorker
print(f"Is alive: {t.is_alive()}")        # False
print(f"Is daemon: {t.daemon}")           # False

# Start the thread
t.start()

# While running
print(f"Is alive: {t.is_alive()}")        # True
print(f"Thread ident: {t.ident}")         # OS thread ID
print(f"Native ID: {t.native_id}")        # Native thread ID

# Wait with timeout
t.join(timeout=2)  # Wait max 2 seconds
if t.is_alive():
    print("Thread still running after timeout")

# Wait for completion
t.join()  # Block until done
print(f"Is alive: {t.is_alive()}")        # False
```

### Daemon Threads

```python
import threading
import time

def background_task():
    """Runs forever until main program exits"""
    while True:
        print("Background task running...")
        time.sleep(1)

# Daemon thread dies when main program exits
daemon = threading.Thread(target=background_task, daemon=True)
daemon.start()

# Main program
time.sleep(3)
print("Main program ending - daemon will be killed")
# Program exits, daemon thread is terminated
```

### Thread Local Data

```python
import threading
import time

# Thread-local storage - each thread has its own copy
local_data = threading.local()

def worker(name):
    # Each thread gets its own 'value'
    local_data.value = name
    time.sleep(0.1)
    # Still has its own value (not overwritten by other threads)
    print(f"Thread {threading.current_thread().name}: {local_data.value}")

threads = [
    threading.Thread(target=worker, args=(f"Data-{i}",), name=f"Thread-{i}")
    for i in range(3)
]

for t in threads:
    t.start()
for t in threads:
    t.join()
```

---

## 3. Synchronization Primitives

### Lock (Mutex)

```python
import threading

counter = 0
lock = threading.Lock()

def increment():
    global counter
    for _ in range(100000):
        # Method 1: Explicit acquire/release
        lock.acquire()
        try:
            counter += 1
        finally:
            lock.release()

def increment_with_context():
    global counter
    for _ in range(100000):
        # Method 2: Context manager (preferred)
        with lock:
            counter += 1

# Without lock: counter will be wrong (race condition)
# With lock: counter will be exactly 200000
threads = [threading.Thread(target=increment_with_context) for _ in range(2)]
for t in threads:
    t.start()
for t in threads:
    t.join()

print(f"Final counter: {counter}")  # 200000
```

### RLock (Reentrant Lock)

```python
import threading

rlock = threading.RLock()

def outer():
    with rlock:  # First acquisition
        print("Outer lock acquired")
        inner()  # Can acquire same lock again!

def inner():
    with rlock:  # Second acquisition (same thread) - OK!
        print("Inner lock acquired")

# With regular Lock, this would DEADLOCK!
# RLock allows same thread to acquire multiple times
outer()
```

### Semaphore (Limited Access)

```python
import threading
import time

# Only 3 threads can access at once
semaphore = threading.Semaphore(3)

def limited_resource(name):
    print(f"{name} waiting for access...")
    with semaphore:
        print(f"{name} got access!")
        time.sleep(2)  # Simulate work
        print(f"{name} releasing access")

# Start 10 threads, only 3 run at a time
threads = [threading.Thread(target=limited_resource, args=(f"Thread-{i}",)) 
           for i in range(10)]

for t in threads:
    t.start()
for t in threads:
    t.join()
```

### Event (Signaling)

```python
import threading
import time

event = threading.Event()

def waiter(name):
    print(f"{name} waiting for signal...")
    event.wait()  # Block until event is set
    print(f"{name} received signal!")

def setter():
    time.sleep(2)
    print("Setting event!")
    event.set()  # Signal all waiting threads

# Start waiters
waiters = [threading.Thread(target=waiter, args=(f"Waiter-{i}",)) 
           for i in range(3)]
for w in waiters:
    w.start()

# Start setter
setter_thread = threading.Thread(target=setter)
setter_thread.start()

# All will finish after event is set
for w in waiters:
    w.join()
setter_thread.join()
```

### Condition (Complex Signaling)

```python
import threading
import time

condition = threading.Condition()
items = []

def producer():
    for i in range(5):
        time.sleep(0.5)
        with condition:
            items.append(f"item-{i}")
            print(f"Produced item-{i}")
            condition.notify()  # Wake up ONE consumer

def consumer(name):
    while True:
        with condition:
            while not items:
                print(f"{name} waiting...")
                condition.wait()  # Release lock and wait
            item = items.pop(0)
            print(f"{name} consumed {item}")
        
        if item == "item-4":
            break

# Run producer and consumers
producer_thread = threading.Thread(target=producer)
consumer_threads = [threading.Thread(target=consumer, args=(f"Consumer-{i}",)) 
                    for i in range(2)]

producer_thread.start()
for c in consumer_threads:
    c.start()

producer_thread.join()
for c in consumer_threads:
    c.join()
```

### Barrier (Synchronization Point)

```python
import threading
import time
import random

# All 3 threads must reach barrier before any can continue
barrier = threading.Barrier(3)

def worker(name):
    delay = random.uniform(0.5, 2)
    print(f"{name} working for {delay:.1f}s...")
    time.sleep(delay)
    
    print(f"{name} reached barrier, waiting for others...")
    barrier.wait()  # Wait for all threads
    
    print(f"{name} continuing past barrier!")

threads = [threading.Thread(target=worker, args=(f"Worker-{i}",)) 
           for i in range(3)]

for t in threads:
    t.start()
for t in threads:
    t.join()
```

---

## 4. Thread Pools

### Using concurrent.futures.ThreadPoolExecutor

```python
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

def fetch_data(url):
    """Simulate fetching data"""
    time.sleep(1)
    return f"Data from {url}"

urls = [f"http://example.com/page{i}" for i in range(5)]

# Method 1: Using map()
with ThreadPoolExecutor(max_workers=3) as executor:
    results = executor.map(fetch_data, urls)
    for result in results:
        print(result)

# Method 2: Using submit() with as_completed()
with ThreadPoolExecutor(max_workers=3) as executor:
    futures = {executor.submit(fetch_data, url): url for url in urls}
    
    for future in as_completed(futures):
        url = futures[future]
        try:
            data = future.result()
            print(f"{url}: {data}")
        except Exception as e:
            print(f"{url} generated exception: {e}")
```

### Custom Thread Pool

```python
import threading
import queue
import time

class ThreadPool:
    def __init__(self, num_threads):
        self.tasks = queue.Queue()
        self.workers = []
        self.shutdown_flag = threading.Event()
        
        for i in range(num_threads):
            worker = threading.Thread(target=self._worker, name=f"Worker-{i}")
            worker.start()
            self.workers.append(worker)
    
    def _worker(self):
        while not self.shutdown_flag.is_set():
            try:
                func, args, kwargs, result_queue = self.tasks.get(timeout=0.1)
                try:
                    result = func(*args, **kwargs)
                    result_queue.put(('success', result))
                except Exception as e:
                    result_queue.put(('error', e))
            except queue.Empty:
                continue
    
    def submit(self, func, *args, **kwargs):
        result_queue = queue.Queue()
        self.tasks.put((func, args, kwargs, result_queue))
        return result_queue
    
    def shutdown(self):
        self.shutdown_flag.set()
        for worker in self.workers:
            worker.join()

# Usage
def process(x):
    time.sleep(0.5)
    return x * 2

pool = ThreadPool(3)
results = [pool.submit(process, i) for i in range(5)]

for r in results:
    status, value = r.get()
    print(f"{status}: {value}")

pool.shutdown()
```

---

## 5. Thread Communication

### Using Queue (Thread-Safe)

```python
import threading
import queue
import time

# Thread-safe queue
q = queue.Queue(maxsize=5)

def producer():
    for i in range(10):
        item = f"item-{i}"
        q.put(item)  # Blocks if queue full
        print(f"Produced: {item}")
        time.sleep(0.1)
    q.put(None)  # Sentinel to stop consumer

def consumer():
    while True:
        item = q.get()  # Blocks if queue empty
        if item is None:
            break
        print(f"Consumed: {item}")
        q.task_done()  # Mark item as processed

producer_thread = threading.Thread(target=producer)
consumer_thread = threading.Thread(target=consumer)

producer_thread.start()
consumer_thread.start()

producer_thread.join()
consumer_thread.join()
```

### Priority Queue

```python
import threading
import queue

# Items with lower numbers have higher priority
pq = queue.PriorityQueue()

# Add items (priority, data)
pq.put((3, "Low priority"))
pq.put((1, "High priority"))
pq.put((2, "Medium priority"))

# Get items in priority order
while not pq.empty():
    priority, item = pq.get()
    print(f"Priority {priority}: {item}")

# Output:
# Priority 1: High priority
# Priority 2: Medium priority
# Priority 3: Low priority
```

### Sharing Results with Futures

```python
from concurrent.futures import ThreadPoolExecutor, Future
import time

def compute(x):
    time.sleep(1)
    if x < 0:
        raise ValueError("Negative not allowed")
    return x * x

with ThreadPoolExecutor(max_workers=2) as executor:
    # Submit returns Future immediately
    future1 = executor.submit(compute, 5)
    future2 = executor.submit(compute, -1)
    
    # Check if done
    print(f"Future1 done: {future1.done()}")  # False
    
    # Get result (blocks until ready)
    try:
        result1 = future1.result(timeout=5)
        print(f"Result 1: {result1}")  # 25
    except TimeoutError:
        print("Timed out")
    
    # Handle exceptions
    try:
        result2 = future2.result()
    except ValueError as e:
        print(f"Future 2 error: {e}")  # Negative not allowed
```

---

## 6. Practical Patterns

### Pattern 1: Worker Pool with Results

```python
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

def download_file(url):
    """Simulate file download"""
    time.sleep(0.5)
    return {"url": url, "size": len(url) * 100}

urls = [f"http://example.com/file{i}.txt" for i in range(20)]

def download_all(urls, max_workers=5):
    results = []
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_url = {executor.submit(download_file, url): url for url in urls}
        
        for future in as_completed(future_to_url):
            url = future_to_url[future]
            try:
                data = future.result()
                results.append(data)
                print(f"Downloaded: {url}")
            except Exception as e:
                print(f"Error downloading {url}: {e}")
    
    return results

results = download_all(urls)
print(f"Downloaded {len(results)} files")
```

### Pattern 2: Rate-Limited Thread Pool

```python
import threading
import time
from concurrent.futures import ThreadPoolExecutor

class RateLimiter:
    def __init__(self, calls_per_second):
        self.calls_per_second = calls_per_second
        self.lock = threading.Lock()
        self.last_call = 0
    
    def wait(self):
        with self.lock:
            now = time.time()
            min_interval = 1.0 / self.calls_per_second
            time_since_last = now - self.last_call
            
            if time_since_last < min_interval:
                time.sleep(min_interval - time_since_last)
            
            self.last_call = time.time()

limiter = RateLimiter(calls_per_second=2)

def rate_limited_request(url):
    limiter.wait()
    print(f"Requesting {url} at {time.time():.2f}")
    time.sleep(0.1)
    return f"Response from {url}"

urls = [f"http://api.example.com/{i}" for i in range(10)]

with ThreadPoolExecutor(max_workers=5) as executor:
    results = list(executor.map(rate_limited_request, urls))
```

### Pattern 3: Thread-Safe Counter

```python
import threading

class ThreadSafeCounter:
    def __init__(self):
        self._value = 0
        self._lock = threading.Lock()
    
    def increment(self, amount=1):
        with self._lock:
            self._value += amount
            return self._value
    
    def decrement(self, amount=1):
        with self._lock:
            self._value -= amount
            return self._value
    
    @property
    def value(self):
        with self._lock:
            return self._value

# Usage
counter = ThreadSafeCounter()

def worker():
    for _ in range(10000):
        counter.increment()

threads = [threading.Thread(target=worker) for _ in range(5)]
for t in threads:
    t.start()
for t in threads:
    t.join()

print(f"Final count: {counter.value}")  # Always 50000
```

### Pattern 4: Producer-Consumer with Multiple Consumers

```python
import threading
import queue
import time
import random

class ProducerConsumer:
    def __init__(self, num_consumers):
        self.queue = queue.Queue(maxsize=10)
        self.stop_event = threading.Event()
        self.num_consumers = num_consumers
    
    def produce(self, num_items):
        for i in range(num_items):
            item = f"item-{i}"
            self.queue.put(item)
            print(f"Produced: {item}")
            time.sleep(random.uniform(0.1, 0.3))
        
        # Signal consumers to stop
        for _ in range(self.num_consumers):
            self.queue.put(None)
    
    def consume(self, consumer_id):
        while True:
            item = self.queue.get()
            if item is None:
                print(f"Consumer-{consumer_id} stopping")
                break
            
            # Process item
            time.sleep(random.uniform(0.2, 0.5))
            print(f"Consumer-{consumer_id} processed: {item}")
            self.queue.task_done()
    
    def run(self, num_items):
        producer = threading.Thread(target=self.produce, args=(num_items,))
        consumers = [
            threading.Thread(target=self.consume, args=(i,))
            for i in range(self.num_consumers)
        ]
        
        producer.start()
        for c in consumers:
            c.start()
        
        producer.join()
        for c in consumers:
            c.join()

# Run
pc = ProducerConsumer(num_consumers=3)
pc.run(num_items=10)
```

---

## Quick Reference

```python
# Thread Creation
t = threading.Thread(target=func, args=(arg1,), name="Name", daemon=False)
t.start()
t.join(timeout=None)

# Synchronization
lock = threading.Lock()
rlock = threading.RLock()
semaphore = threading.Semaphore(n)
event = threading.Event()
condition = threading.Condition()
barrier = threading.Barrier(n)

# Thread Pool
from concurrent.futures import ThreadPoolExecutor
with ThreadPoolExecutor(max_workers=5) as executor:
    results = executor.map(func, items)
    future = executor.submit(func, arg)

# Queue
q = queue.Queue()
q.put(item)
item = q.get()
q.task_done()
q.join()  # Wait for all tasks
```

---

*Next: [Deep Dive](_03_deep_dive.md)*
