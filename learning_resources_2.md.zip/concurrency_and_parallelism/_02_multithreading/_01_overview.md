# Multithreading in Python - Overview

## What is a Thread? (The Simple Explanation)

Imagine you're a **chef** in a kitchen. You need to:
1. Boil pasta
2. Make sauce
3. Prepare salad

**Without threads (Sequential):** You do one thing at a time.
- Boil pasta (10 min) → Make sauce (10 min) → Prepare salad (5 min)
- **Total: 25 minutes**

**With threads (Concurrent):** You do multiple things, switching between them.
- Start boiling pasta, while waiting... make sauce, while sauce simmers... prepare salad
- **Total: ~12 minutes** (tasks overlap!)

```
┌─────────────────────────────────────────────────────────────────────┐
│                     THE CHEF ANALOGY                                 │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  WITHOUT THREADS (Sequential):                                      │
│  ┌──────────┐ ┌──────────┐ ┌─────┐                                 │
│  │  Pasta   │ │  Sauce   │ │Salad│                                 │
│  └──────────┘ └──────────┘ └─────┘                                 │
│  0         10          20      25 minutes                          │
│                                                                     │
│  WITH THREADS (Concurrent):                                         │
│  ┌──────────────────────┐  Pasta (boiling in background)           │
│  │░░░░░░░░░░░░░░░░░░░░░░│                                          │
│  └──────────────────────┘                                          │
│  ┌──────────────────────┐  Sauce (stirring occasionally)           │
│  │████░░░░████░░░░██████│                                          │
│  └──────────────────────┘                                          │
│  ┌─────────────┐           Salad (in spare moments)                │
│  │░░░░████░░░░░│                                                   │
│  └─────────────┘                                                   │
│  0                      12 minutes                                 │
│                                                                     │
│  ░ = Waiting    █ = Active work                                    │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Thread vs Process: The Apartment Analogy

Think of your computer's memory as an **apartment building**.

```
┌─────────────────────────────────────────────────────────────────────┐
│              PROCESS VS THREAD: APARTMENT ANALOGY                    │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  PROCESSES = Separate Apartments                                    │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐             │
│  │ Apartment 1 │    │ Apartment 2 │    │ Apartment 3 │             │
│  │             │    │             │    │             │             │
│  │ 🛋️ Own      │    │ 🛋️ Own      │    │ 🛋️ Own      │             │
│  │   furniture │    │   furniture │    │   furniture │             │
│  │ 🚿 Own bath │    │ 🚿 Own bath │    │ 🚿 Own bath │             │
│  │ 🍳 Own kit. │    │ 🍳 Own kit. │    │ 🍳 Own kit. │             │
│  └─────────────┘    └─────────────┘    └─────────────┘             │
│  • Completely isolated                                              │
│  • Can't share stuff easily                                         │
│  • Each pays full rent (memory)                                     │
│                                                                     │
│  THREADS = Roommates in ONE Apartment                               │
│  ┌─────────────────────────────────────────────────────────┐       │
│  │                   Shared Apartment                       │       │
│  │  👤 👤 👤  (Roommates = Threads)                         │       │
│  │                                                         │       │
│  │  🛋️ Shared living room    (Shared memory)               │       │
│  │  🍳 Shared kitchen         (Shared data)                │       │
│  │  🚿 Shared bathroom        (Shared resources)           │       │
│  │                                                         │       │
│  │  ⚠️ Need rules: "I'm using the bathroom!"               │       │
│  │     (Synchronization)                                   │       │
│  └─────────────────────────────────────────────────────────┘       │
│  • Share everything                                                 │
│  • Easy communication                                               │
│  • Lower overhead (one rent)                                        │
│  • BUT: Need coordination!                                          │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## When Should You Use Threads?

### Perfect for Threads: Waiting Tasks (I/O-Bound)

```
┌─────────────────────────────────────────────────────────────────────┐
│                    WHEN TO USE THREADS                               │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ✅ GREAT for I/O-Bound Tasks (Lots of WAITING):                    │
│                                                                     │
│  • Downloading files from internet                                  │
│  • Reading/writing to disk                                          │
│  • Database queries                                                 │
│  • API calls                                                        │
│  • User input                                                       │
│                                                                     │
│  WHY? While one thread waits, others can work!                      │
│                                                                     │
│  Thread 1: [Request]░░░░░░░░░░░░░░░░░░░░░░░░[Response]             │
│  Thread 2:          [Request]░░░░░░░░░░░░░░░░░░░░[Response]        │
│  Thread 3:                   [Request]░░░░░░░░░░░░░░[Response]     │
│                                                                     │
│  ░ = Waiting (Thread doesn't need CPU)                              │
│  All three run "at the same time"!                                  │
│                                                                     │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ❌ NOT GREAT for CPU-Bound Tasks (Heavy Calculations):             │
│                                                                     │
│  • Number crunching                                                 │
│  • Image processing                                                 │
│  • Machine learning training                                        │
│  • Encryption/Decryption                                            │
│                                                                     │
│  WHY? Python's GIL only allows one thread to compute at a time!    │
│                                                                     │
│  Thread 1: [████]      [████]      [████]                          │
│  Thread 2:       [████]      [████]      [████]                    │
│                                                                     │
│  They take turns, no speedup! Use multiprocessing instead.          │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Real-World Example: Downloading Photos

**Without threads:** Download one photo, wait, then download next.

```
Photo 1: [████████████████████] 2 seconds
Photo 2:                       [████████████████████] 2 seconds
Photo 3:                                              [████████████████████] 2 seconds

Total: 6 seconds
```

**With threads:** Download all photos simultaneously.

```
Photo 1: [████████████████████]
Photo 2: [████████████████████]
Photo 3: [████████████████████]

Total: ~2 seconds (all download together!)
```

---

## The Basics: Creating a Thread

Think of creating a thread like hiring an assistant:

```
┌─────────────────────────────────────────────────────────────────────┐
│                   THREAD LIFECYCLE                                   │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  1. CREATE (Hire assistant)                                         │
│     "Hey, I want you to do this task"                               │
│     ↓                                                               │
│  2. START (Send them to work)                                       │
│     "Go do it now!"                                                 │
│     ↓                                                               │
│  3. RUNNING (Assistant is working)                                  │
│     (They work independently)                                       │
│     ↓                                                               │
│  4. JOIN (Wait for them to finish)                                  │
│     "Tell me when you're done"                                      │
│     ↓                                                               │
│  5. TERMINATED (Task complete)                                      │
│     "Thanks, you're done!"                                          │
│                                                                     │
│  ┌─────────┐     ┌─────────┐     ┌─────────┐     ┌──────────┐      │
│  │  NEW    │────▶│ STARTED │────▶│ RUNNING │────▶│TERMINATED│      │
│  └─────────┘     └─────────┘     └─────────┘     └──────────┘      │
│                                       │                             │
│                                       ▼                             │
│                                  ┌─────────┐                        │
│                                  │ BLOCKED │                        │
│                                  │(waiting)│                        │
│                                  └─────────┘                        │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Thread Safety: The Shared Bathroom Problem

When roommates share a bathroom, you need RULES:

```
┌─────────────────────────────────────────────────────────────────────┐
│              THE SHARED BATHROOM PROBLEM                             │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  WITHOUT RULES (Race Condition):                                    │
│                                                                     │
│  Person A: "Bathroom empty? Let me go in..."                        │
│  Person B: "Bathroom empty? Let me go in..."                        │
│  BOTH: *walk in at same time* 😱                                    │
│                                                                     │
│  WITH RULES (Lock/Mutex):                                           │
│                                                                     │
│  🚪 Door with Lock 🔒                                               │
│                                                                     │
│  Person A: *locks door* 🔒 "I'm in!" *uses bathroom* *unlocks* 🔓  │
│  Person B: *tries door* "Locked. I'll wait..."                      │
│  Person B: *door unlocks* *locks door* 🔒 "My turn!"               │
│                                                                     │
│  In Python:                                                         │
│  lock = Lock()           # The door lock                           │
│  with lock:              # Lock the door                           │
│      use_bathroom()      # Use the resource                        │
│                          # Door automatically unlocks               │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Common Problems with Threads

### 1. Race Condition (Who Gets There First?)

Two threads trying to update the same thing at the same time:

```
┌─────────────────────────────────────────────────────────────────────┐
│                      RACE CONDITION                                  │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Bank Account: $100                                                 │
│                                                                     │
│  Thread A (Deposit $50):        Thread B (Deposit $30):            │
│  1. Read balance: $100          1. Read balance: $100               │
│  2. Add $50: $150               2. Add $30: $130                    │
│  3. Write: $150                 3. Write: $130                      │
│                                                                     │
│  Final balance: $130 (WRONG! Should be $180)                        │
│                                                                     │
│  FIX: Use a lock so only ONE thread updates at a time!             │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### 2. Deadlock (Everyone Waiting Forever)

```
┌─────────────────────────────────────────────────────────────────────┐
│                        DEADLOCK                                      │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Two people, two forks, one piece of food                           │
│                                                                     │
│  Person A: "I have fork 1, waiting for fork 2..."                   │
│  Person B: "I have fork 2, waiting for fork 1..."                   │
│                                                                     │
│       Person A                Person B                              │
│       ┌─────┐                ┌─────┐                                │
│       │     │    waiting     │     │                                │
│       │ 🍴1 │ ───────────▶  │ 🍴2 │                                 │
│       │     │  ◀───────────  │     │                                │
│       └─────┘    waiting     └─────┘                                │
│                                                                     │
│  Both wait forever! ♾️                                               │
│                                                                     │
│  FIX: Always acquire locks in the same ORDER!                       │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Quick Summary Table

| Concept | Simple Explanation | Example |
|---------|-------------------|---------|
| **Thread** | A helper that can do a task | Assistant doing a job |
| **Main Thread** | The original worker (your program) | The boss |
| **Start** | Tell thread to begin working | "Go!" |
| **Join** | Wait for thread to finish | "Tell me when done" |
| **Lock** | A key to access shared stuff | Bathroom door lock |
| **Race Condition** | Two threads mess up shared data | Two people editing same doc |
| **Deadlock** | Threads waiting forever | Traffic jam at 4-way stop |

---

## When to Use What?

```
┌─────────────────────────────────────────────────────────────────────┐
│                  DECISION GUIDE                                      │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  "I need to..."                                                     │
│                                                                     │
│  ├─▶ Download many files    ──▶ ✅ Use THREADS                      │
│  │                                                                  │
│  ├─▶ Make many API calls    ──▶ ✅ Use THREADS (or asyncio)        │
│  │                                                                  │
│  ├─▶ Read many database     ──▶ ✅ Use THREADS                      │
│  │   records                                                        │
│  │                                                                  │
│  ├─▶ Process many images    ──▶ ❌ Use MULTIPROCESSING              │
│  │                                                                  │
│  ├─▶ Heavy calculations     ──▶ ❌ Use MULTIPROCESSING              │
│  │                                                                  │
│  └─▶ Keep GUI responsive    ──▶ ✅ Use THREADS                      │
│      while doing work            (heavy work in background)         │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Key Takeaways

1. **Threads are like assistants** - They help do multiple things at once
2. **Threads share memory** - Like roommates sharing an apartment
3. **Great for waiting tasks** - Downloading, reading files, API calls
4. **Need locks for shared data** - Like locking the bathroom door
5. **Watch out for race conditions** - When two threads update same data
6. **Not for heavy calculations** - Use multiprocessing for that (because of GIL)

---

*Next: [Implementation & Code](_02_implementation.md)*
