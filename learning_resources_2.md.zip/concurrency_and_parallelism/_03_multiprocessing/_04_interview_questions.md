# Multiprocessing in Python - Interview Questions

## Table of Contents
1. [Basic Questions](#basic-questions)
2. [Intermediate Questions](#intermediate-questions)
3. [Advanced Questions](#advanced-questions)
4. [Scenario-Based Questions](#scenario-based-questions)
5. [Code Analysis Questions](#code-analysis-questions)

---

## Basic Questions

### Q1: What is the difference between multiprocessing and threading in Python?

<details>
<summary>Answer</summary>

| Aspect | Threading | Multiprocessing |
|--------|-----------|-----------------|
| **GIL** | Shared (blocks CPU parallelism) | Each process has own GIL |
| **Memory** | Shared | Separate |
| **Parallelism** | Concurrent (not parallel for CPU) | True parallel |
| **Overhead** | Low (~0.1ms) | High (~10-100ms) |
| **Communication** | Direct (shared memory) | IPC (Queue, Pipe) |
| **Best for** | I/O-bound tasks | CPU-bound tasks |

**Key insight:** Threading is limited by the GIL for CPU work, while multiprocessing bypasses it by using separate interpreters.

</details>

---

### Q2: What is the `if __name__ == "__main__"` guard and why is it important?

<details>
<summary>Answer</summary>

**Required on Windows** (and recommended on all platforms) because:

1. **Spawn method** creates new Python process
2. New process imports the main module
3. Without guard, code runs again in child process
4. Creates infinite loop of process creation!

```python
# WRONG - infinite processes on Windows
from multiprocessing import Process

def worker():
    print("Working")

p = Process(target=worker)  # This runs when module imports
p.start()                    # Child imports module, starts another...

# RIGHT
from multiprocessing import Process

def worker():
    print("Working")

if __name__ == "__main__":  # Only runs in main process
    p = Process(target=worker)
    p.start()
```

</details>

---

### Q3: What are the three process start methods in Python?

<details>
<summary>Answer</summary>

**1. fork** (Unix default)
- Copies parent process memory (copy-on-write)
- Fast startup
- Can inherit problematic state (locks, connections)

**2. spawn** (Windows default, safest)
- Starts fresh Python interpreter
- Slower but cleaner
- Everything must be picklable

**3. forkserver** (Unix only)
- Forks from dedicated server process
- Good for mixing threads and processes
- Avoids fork issues with threads

```python
import multiprocessing as mp

# Set globally
mp.set_start_method('spawn')

# Or use context
ctx = mp.get_context('spawn')
p = ctx.Process(target=func)
```

**When to use:**
- Windows: spawn (only option)
- Unix with threads: forkserver
- Unix simple cases: fork
- Cross-platform: spawn

</details>

---

### Q4: How do processes communicate in Python?

<details>
<summary>Answer</summary>

**1. Queue** - Thread and process safe, FIFO
```python
from multiprocessing import Queue
q = Queue()
q.put(item)
item = q.get()
```

**2. Pipe** - Two-way communication, two endpoints
```python
from multiprocessing import Pipe
parent_conn, child_conn = Pipe()
parent_conn.send(data)
data = child_conn.recv()
```

**3. Manager** - Shared objects via proxy
```python
from multiprocessing import Manager
with Manager() as m:
    shared_dict = m.dict()
    shared_list = m.list()
```

**4. Shared Memory** - Direct memory sharing
```python
from multiprocessing import Value, Array
counter = Value('i', 0)
arr = Array('d', [0.0, 0.0])
```

**When to use:**
- Queue: Producer-consumer, task distribution
- Pipe: Two processes, bidirectional
- Manager: Shared complex objects
- Shared Memory: High-performance, raw data

</details>

---

## Intermediate Questions

### Q5: What is pickling and why is it important for multiprocessing?

<details>
<summary>Answer</summary>

**Pickling** is Python's serialization mechanism, converting objects to bytes.

**Important because:**
- spawn/forkserver must serialize arguments
- Queue/Pipe serialize data for transfer
- Function and class must be picklable

**Can be pickled:**
- Basic types (int, str, list, dict)
- Module-level classes and functions
- Most standard library objects

**Cannot be pickled:**
- Lambda functions
- Nested/local functions
- Open files, sockets, connections
- Generators

```python
# FAILS
with Pool() as pool:
    pool.map(lambda x: x*2, data)  # Lambda can't pickle!

# WORKS
def double(x):
    return x * 2

with Pool() as pool:
    pool.map(double, data)  # Module-level function OK
```

**Custom pickling:**
```python
class MyClass:
    def __getstate__(self):
        # Return state to pickle
        pass
    
    def __setstate__(self, state):
        # Restore from state
        pass
```

</details>

---

### Q6: Explain the difference between Pool.map() and Pool.imap().

<details>
<summary>Answer</summary>

| Feature | map() | imap() | imap_unordered() |
|---------|-------|--------|------------------|
| **Return** | List | Iterator | Iterator |
| **Blocking** | Yes (waits for all) | No (yields as ready) | No |
| **Order** | Preserved | Preserved | Fastest first |
| **Memory** | All results in memory | One at a time | One at a time |

```python
from multiprocessing import Pool
import time

def slow_task(x):
    time.sleep(0.5)
    return x * 2

with Pool(4) as pool:
    # map: Returns when ALL complete
    results = pool.map(slow_task, range(10))  # Waits for all 10
    
    # imap: Yields results in order as available
    for result in pool.imap(slow_task, range(10)):
        print(result)  # Prints as each completes (in order)
    
    # imap_unordered: Yields fastest first
    for result in pool.imap_unordered(slow_task, range(10)):
        print(result)  # Prints in completion order
```

**Use cases:**
- `map`: Need all results, simple case
- `imap`: Memory-constrained, need order
- `imap_unordered`: Fastest processing, order doesn't matter

</details>

---

### Q7: How do you handle exceptions in multiprocessing?

<details>
<summary>Answer</summary>

**Problem:** Exceptions in worker processes don't automatically propagate.

**Solution 1: Catch in worker**
```python
def safe_worker(x):
    try:
        return ("success", risky_operation(x))
    except Exception as e:
        return ("error", str(e))
```

**Solution 2: Use ProcessPoolExecutor**
```python
from concurrent.futures import ProcessPoolExecutor, as_completed

with ProcessPoolExecutor() as executor:
    futures = [executor.submit(worker, x) for x in data]
    
    for future in as_completed(futures):
        try:
            result = future.result()  # Re-raises exception
        except Exception as e:
            print(f"Error: {e}")
```

**Solution 3: Pool with error callback**
```python
def error_callback(e):
    print(f"Error: {e}")

pool.apply_async(worker, args=(x,), error_callback=error_callback)
```

</details>

---

### Q8: What is the `maxtasksperchild` parameter in Pool?

<details>
<summary>Answer</summary>

**Purpose:** Restart worker process after N tasks.

**Why use it:**
1. **Memory leaks:** Worker accumulates memory over time
2. **State reset:** Clear cached data or connections
3. **Library bugs:** Some libraries have issues with long-running processes

```python
from multiprocessing import Pool

def leaky_worker(x):
    # Imagine this accumulates memory over time
    global cache
    cache.append(large_data)
    return x * 2

# Workers restart every 100 tasks
with Pool(4, maxtasksperchild=100) as pool:
    results = pool.map(leaky_worker, range(10000))
```

**Trade-off:** Restarting processes has overhead, so don't set too low.

</details>

---

## Advanced Questions

### Q9: Explain copy-on-write and its implications for multiprocessing.

<details>
<summary>Answer</summary>

**Copy-on-write (COW):** Memory optimization in fork().

**How it works:**
1. Fork creates child process
2. Parent and child share same physical memory pages
3. Pages marked read-only
4. When either writes, that page is copied
5. Only modified pages use extra memory

**Implications:**
```python
# GOOD: Read-only data stays shared
large_data = load_huge_dataset()

def worker(index):
    return analyze(large_data[index])  # Reading - no copy

# BAD: Modification triggers copies
def worker_bad(index):
    large_data[index] *= 2  # Writing - copies that page!
```

**Python gotcha:** Reference counting triggers COW
```python
# Even reading triggers writes to refcount!
x = large_data[0]  # Increments refcount -> page copied

# Solution: Use numpy arrays or shared memory
import numpy as np
large_data = np.array(...)  # NumPy handles refcounts differently
```

</details>

---

### Q10: How would you share a large numpy array between processes efficiently?

<details>
<summary>Answer</summary>

**Method 1: shared_memory (Python 3.8+, recommended)**
```python
from multiprocessing import shared_memory, Process
import numpy as np

def worker(shm_name, shape, dtype):
    existing_shm = shared_memory.SharedMemory(name=shm_name)
    arr = np.ndarray(shape, dtype=dtype, buffer=existing_shm.buf)
    arr += 1  # Modify in-place
    existing_shm.close()

# Create shared array
arr = np.array([1, 2, 3, 4, 5])
shm = shared_memory.SharedMemory(create=True, size=arr.nbytes)
shared_arr = np.ndarray(arr.shape, dtype=arr.dtype, buffer=shm.buf)
shared_arr[:] = arr

# Workers access same memory
p = Process(target=worker, args=(shm.name, arr.shape, arr.dtype))
p.start()
p.join()

print(shared_arr)  # [2, 3, 4, 5, 6]
shm.close()
shm.unlink()
```

**Method 2: Pool with initializer**
```python
worker_array = None

def init(arr):
    global worker_array
    worker_array = arr

def process(index):
    return worker_array[index] * 2

with Pool(4, initializer=init, initargs=(large_array,)) as pool:
    results = pool.map(process, range(len(large_array)))
```

**Method 3: Memory-mapped files**
```python
arr = np.memmap('data.npy', dtype='float64', mode='r', shape=(10000,))
# Workers can all read this file
```

</details>

---

### Q11: What are the dangers of using fork with threads?

<details>
<summary>Answer</summary>

**Problem:** Only the calling thread is copied during fork.

```python
import threading
import multiprocessing as mp

lock = threading.Lock()

def background_task():
    with lock:
        while True:
            time.sleep(1)

# Start background thread (holds lock)
t = threading.Thread(target=background_task)
t.start()

# Fork while thread holds lock
def child_work():
    with lock:  # DEADLOCK - lock is held, but thread doesn't exist
        print("Working")

p = mp.Process(target=child_work)
p.start()  # Will deadlock!
```

**Why it happens:**
1. Parent has thread holding lock
2. Fork copies memory (including locked lock)
3. Child has no threads (fork only copies calling thread)
4. Lock is stuck in locked state forever

**Solutions:**
1. Use `spawn` start method (recommended)
2. Use `forkserver`
3. Don't mix threads and multiprocessing
4. If must fork, use `os.register_at_fork()` to reset state

</details>

---

## Scenario-Based Questions

### Q12: Design a parallel image processing pipeline.

<details>
<summary>Answer</summary>

```python
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
from multiprocessing import cpu_count
import os

def load_image(path):
    """I/O-bound: use threads"""
    with open(path, 'rb') as f:
        return f.read()

def process_image(image_data):
    """CPU-bound: use processes"""
    # Decode, resize, filter, etc.
    return processed_data

def save_image(data_path):
    """I/O-bound: use threads"""
    data, path = data_path
    with open(path, 'wb') as f:
        f.write(data)

def process_images(input_paths, output_dir):
    # Stage 1: Load images (I/O-bound, use threads)
    with ThreadPoolExecutor(max_workers=10) as executor:
        raw_images = list(executor.map(load_image, input_paths))
    
    # Stage 2: Process images (CPU-bound, use processes)
    with ProcessPoolExecutor(max_workers=cpu_count()) as executor:
        processed = list(executor.map(process_image, raw_images))
    
    # Stage 3: Save images (I/O-bound, use threads)
    output_paths = [
        os.path.join(output_dir, os.path.basename(p))
        for p in input_paths
    ]
    with ThreadPoolExecutor(max_workers=10) as executor:
        executor.map(save_image, zip(processed, output_paths))

if __name__ == "__main__":
    process_images(["img1.jpg", "img2.jpg", ...], "output/")
```

**Key design decisions:**
- I/O stages use ThreadPoolExecutor (GIL released)
- CPU stage uses ProcessPoolExecutor (bypass GIL)
- Pipeline stages are sequential (simpler, still fast)

</details>

---

### Q13: Implement a task queue with worker processes.

<details>
<summary>Answer</summary>

```python
from multiprocessing import Process, Queue, Event
import time

class TaskQueue:
    def __init__(self, num_workers=4):
        self.task_queue = Queue()
        self.result_queue = Queue()
        self.shutdown_event = Event()
        self.workers = []
        
        for i in range(num_workers):
            w = Process(target=self._worker, args=(i,))
            w.start()
            self.workers.append(w)
    
    def _worker(self, worker_id):
        while not self.shutdown_event.is_set():
            try:
                task_id, func, args = self.task_queue.get(timeout=0.1)
                try:
                    result = func(*args)
                    self.result_queue.put((task_id, 'success', result))
                except Exception as e:
                    self.result_queue.put((task_id, 'error', str(e)))
            except:
                continue
    
    def submit(self, func, *args):
        task_id = id(args)
        self.task_queue.put((task_id, func, args))
        return task_id
    
    def get_result(self, timeout=None):
        return self.result_queue.get(timeout=timeout)
    
    def shutdown(self, wait=True):
        self.shutdown_event.set()
        if wait:
            for w in self.workers:
                w.join(timeout=5)
                if w.is_alive():
                    w.terminate()

# Usage
def square(x):
    time.sleep(0.1)
    return x * x

if __name__ == "__main__":
    queue = TaskQueue(num_workers=4)
    
    # Submit tasks
    for i in range(10):
        queue.submit(square, i)
    
    # Collect results
    for _ in range(10):
        task_id, status, result = queue.get_result()
        print(f"Task {task_id}: {status} = {result}")
    
    queue.shutdown()
```

</details>

---

### Q14: How would you limit memory usage when processing large datasets?

<details>
<summary>Answer</summary>

**Problem:** Large data × N workers = memory explosion

**Solution 1: Chunked processing with imap**
```python
def chunked(iterable, size):
    """Yield chunks of data"""
    it = iter(iterable)
    while chunk := list(itertools.islice(it, size)):
        yield chunk

def process_chunk(chunk):
    return [process(item) for item in chunk]

with Pool(4) as pool:
    # Process in chunks, release memory as we go
    for result_chunk in pool.imap(process_chunk, chunked(huge_data, 1000)):
        save_results(result_chunk)
        # result_chunk is garbage collected
```

**Solution 2: Generator-based approach**
```python
def data_generator(filepath):
    """Yield items one at a time"""
    with open(filepath) as f:
        for line in f:
            yield parse(line)

with Pool(4) as pool:
    for result in pool.imap(process, data_generator('huge.txt')):
        save(result)  # Each result processed immediately
```

**Solution 3: Memory-mapped files**
```python
import numpy as np
import os

# Memory-map: doesn't load entire file
data = np.memmap('huge_array.npy', dtype='float64', mode='r', shape=(10_000_000,))

def process_slice(start_end):
    start, end = start_end
    # Only loads needed portion into RAM
    return np.sum(data[start:end])

slices = [(i, i+100000) for i in range(0, 10_000_000, 100000)]
with Pool(4) as pool:
    results = pool.map(process_slice, slices)
```

</details>

---

## Code Analysis Questions

### Q15: What's wrong with this code?

```python
from multiprocessing import Pool

data = [1, 2, 3, 4, 5]
result = []

def worker(x):
    result.append(x * 2)

with Pool(4) as pool:
    pool.map(worker, data)

print(result)
```

<details>
<summary>Answer</summary>

**Problem:** `result` is not shared between processes!

**Why:** Each worker process has its own copy of `result`. Appending in workers doesn't affect the main process's list.

**Output:** `[]` (empty list)

**Fix 1: Return values**
```python
def worker(x):
    return x * 2

with Pool(4) as pool:
    result = pool.map(worker, data)
print(result)  # [2, 4, 6, 8, 10]
```

**Fix 2: Use Manager for shared list**
```python
from multiprocessing import Pool, Manager

def worker(args):
    x, shared_list = args
    shared_list.append(x * 2)

with Manager() as m:
    shared_list = m.list()
    with Pool(4) as pool:
        pool.map(worker, [(x, shared_list) for x in data])
    print(list(shared_list))
```

</details>

---

### Q16: Will this code deadlock? Why?

```python
from multiprocessing import Pool, Lock

lock = Lock()

def worker(x):
    with lock:
        return x * 2

with Pool(4) as pool:
    results = pool.map(worker, range(10))
```

<details>
<summary>Answer</summary>

**Yes, this will fail** (but not exactly deadlock).

**Problem:** Lock created in main process can't be used directly in worker processes.

**What happens:**
- With `fork`: Lock is copied in locked state → deadlock
- With `spawn`: Lock can't be pickled → error

**Error message (spawn):**
```
RuntimeError: Lock objects should only be shared between processes through inheritance
```

**Fix: Pass lock through initializer**
```python
from multiprocessing import Pool, Lock

def init(l):
    global lock
    lock = l

def worker(x):
    with lock:
        return x * 2

lock = Lock()
with Pool(4, initializer=init, initargs=(lock,)) as pool:
    results = pool.map(worker, range(10))
```

**Or use Manager's Lock:**
```python
from multiprocessing import Pool, Manager

def worker(args):
    x, lock = args
    with lock:
        return x * 2

with Manager() as m:
    lock = m.Lock()
    with Pool(4) as pool:
        results = pool.starmap(worker, [(x, lock) for x in range(10)])
```

</details>

---

## Quick Reference: Interview Cheat Sheet

```
┌─────────────────────────────────────────────────────────────────────┐
│              MULTIPROCESSING INTERVIEW CHEAT SHEET                   │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  WHEN TO USE MULTIPROCESSING:                                       │
│  ✅ CPU-bound tasks (calculations, processing)                      │
│  ✅ Need true parallelism (bypass GIL)                              │
│  ✅ Tasks are independent                                           │
│  ✅ Each task takes significant time (>100ms)                       │
│                                                                     │
│  START METHODS:                                                     │
│  • fork: Fast, Unix only, can have issues with threads             │
│  • spawn: Safe, cross-platform, slower, must pickle                │
│  • forkserver: Best of both on Unix                                │
│                                                                     │
│  IPC MECHANISMS:                                                    │
│  • Queue: Many-to-many, FIFO                                        │
│  • Pipe: Two processes, bidirectional                              │
│  • Manager: Shared complex objects                                 │
│  • Value/Array: Shared primitives/arrays                           │
│  • shared_memory: Fastest, raw bytes                               │
│                                                                     │
│  COMMON PATTERNS:                                                   │
│  • Pool.map(): Simple parallel map                                 │
│  • ProcessPoolExecutor: Modern API, better errors                  │
│  • Initializer: Share data without pickling                        │
│  • maxtasksperchild: Handle memory leaks                           │
│                                                                     │
│  PITFALLS:                                                          │
│  • Missing if __name__ guard (Windows)                             │
│  • Assuming variables are shared (they're not!)                    │
│  • Forgetting to pickle arguments (spawn)                          │
│  • Fork with threads = deadlock risk                               │
│                                                                     │
│  PERFORMANCE:                                                       │
│  • Process creation: ~100ms overhead                               │
│  • Make sure task time >> overhead                                 │
│  • Batch small tasks                                               │
│  • Minimize data transfer                                          │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

*Back to: [Overview](_01_overview.md) | [Implementation](_02_implementation.md) | [Deep Dive](_03_deep_dive.md)*
