# Multiprocessing in Python - Implementation & Code

## Table of Contents
1. [Creating Processes](#1-creating-processes)
2. [Process Pool](#2-process-pool)
3. [Inter-Process Communication (IPC)](#3-inter-process-communication-ipc)
4. [Shared Memory](#4-shared-memory)
5. [Synchronization](#5-synchronization)
6. [Practical Patterns](#6-practical-patterns)

---

## 1. Creating Processes

### Basic Process Creation

```python
from multiprocessing import Process
import os
import time

def worker(name, delay):
    """Worker function that runs in a separate process"""
    print(f"Worker {name} starting (PID: {os.getpid()})")
    time.sleep(delay)
    print(f"Worker {name} finished")

if __name__ == "__main__":  # Required on Windows!
    print(f"Main process PID: {os.getpid()}")
    
    # Create processes
    p1 = Process(target=worker, args=("A", 2))
    p2 = Process(target=worker, args=("B", 1))
    
    # Start processes
    p1.start()
    p2.start()
    
    # Wait for completion
    p1.join()
    p2.join()
    
    print("All processes completed")
```

### Process Class with Return Values

```python
from multiprocessing import Process, Queue
import time

class WorkerProcess(Process):
    def __init__(self, data, result_queue):
        super().__init__()
        self.data = data
        self.result_queue = result_queue
    
    def run(self):
        # Heavy computation
        result = sum(x * x for x in self.data)
        self.result_queue.put(result)

if __name__ == "__main__":
    result_queue = Queue()
    
    # Split data across processes
    data_chunks = [range(0, 2500000), range(2500000, 5000000), 
                   range(5000000, 7500000), range(7500000, 10000000)]
    
    processes = [WorkerProcess(chunk, result_queue) for chunk in data_chunks]
    
    for p in processes:
        p.start()
    for p in processes:
        p.join()
    
    # Collect results
    total = sum(result_queue.get() for _ in processes)
    print(f"Total: {total}")
```

### Using concurrent.futures.ProcessPoolExecutor

```python
from concurrent.futures import ProcessPoolExecutor, as_completed
import time

def process_item(item):
    """Process a single item"""
    time.sleep(0.1)  # Simulate work
    return item * item

if __name__ == "__main__":
    items = list(range(100))
    
    # Method 1: Using map()
    with ProcessPoolExecutor(max_workers=4) as executor:
        results = list(executor.map(process_item, items))
    print(f"Map results: {len(results)} items")
    
    # Method 2: Using submit() with as_completed()
    with ProcessPoolExecutor(max_workers=4) as executor:
        futures = {executor.submit(process_item, item): item for item in items}
        
        for future in as_completed(futures):
            item = futures[future]
            try:
                result = future.result()
            except Exception as e:
                print(f"{item} generated exception: {e}")
```

---

## 2. Process Pool

### Using Pool with map

```python
from multiprocessing import Pool, cpu_count
import time

def square(x):
    time.sleep(0.01)  # Simulate work
    return x * x

if __name__ == "__main__":
    data = list(range(100))
    
    # Create pool with number of CPUs
    with Pool(processes=cpu_count()) as pool:
        # map: preserves order, blocks until all done
        results = pool.map(square, data)
        print(f"map results: {results[:5]}...")
        
        # map_async: non-blocking
        async_result = pool.map_async(square, data)
        results = async_result.get(timeout=10)
        print(f"map_async results: {results[:5]}...")
        
        # imap: iterator, preserves order
        for result in pool.imap(square, data):
            pass  # Process results as they come (in order)
        
        # imap_unordered: iterator, fastest completion first
        for result in pool.imap_unordered(square, data):
            pass  # Process results as they complete
```

### Using Pool with starmap (Multiple Arguments)

```python
from multiprocessing import Pool

def multiply(x, y):
    return x * y

if __name__ == "__main__":
    # Multiple arguments per call
    args = [(1, 2), (3, 4), (5, 6), (7, 8)]
    
    with Pool(4) as pool:
        results = pool.starmap(multiply, args)
        print(results)  # [2, 12, 30, 56]
```

### Using Pool with apply/apply_async

```python
from multiprocessing import Pool
import time

def slow_function(x, delay=0.5):
    time.sleep(delay)
    return x * x

if __name__ == "__main__":
    with Pool(4) as pool:
        # apply: blocking, single call
        result = pool.apply(slow_function, args=(10,), kwds={'delay': 0.1})
        print(f"apply result: {result}")
        
        # apply_async: non-blocking
        results = []
        for i in range(10):
            result = pool.apply_async(slow_function, args=(i,), kwds={'delay': 0.1})
            results.append(result)
        
        # Get results (blocks until ready)
        for r in results:
            print(r.get())
```

### Pool with Initializer

```python
from multiprocessing import Pool
import os

# Global in worker process
worker_data = None

def init_worker(data):
    """Initialize each worker process"""
    global worker_data
    worker_data = data
    print(f"Worker {os.getpid()} initialized with {len(data)} items")

def process_item(item):
    """Use the initialized data"""
    return item in worker_data

if __name__ == "__main__":
    shared_data = set(range(0, 1000, 2))  # Even numbers
    
    # Initialize pool with shared data
    with Pool(4, initializer=init_worker, initargs=(shared_data,)) as pool:
        items = list(range(10))
        results = pool.map(process_item, items)
        print(f"Results: {results}")  # [True, False, True, False, ...]
```

---

## 3. Inter-Process Communication (IPC)

### Queue (Thread and Process Safe)

```python
from multiprocessing import Process, Queue
import time

def producer(queue, items):
    """Put items into queue"""
    for item in items:
        print(f"Producing: {item}")
        queue.put(item)
        time.sleep(0.1)
    queue.put(None)  # Sentinel to stop consumer

def consumer(queue):
    """Get items from queue"""
    while True:
        item = queue.get()
        if item is None:
            break
        print(f"Consuming: {item}")
        time.sleep(0.2)

if __name__ == "__main__":
    queue = Queue()
    
    p1 = Process(target=producer, args=(queue, list(range(5))))
    p2 = Process(target=consumer, args=(queue,))
    
    p1.start()
    p2.start()
    
    p1.join()
    p2.join()
```

### Pipe (Two-Way Communication)

```python
from multiprocessing import Process, Pipe
import time

def sender(conn):
    """Send messages through pipe"""
    for i in range(5):
        msg = f"Message {i}"
        conn.send(msg)
        print(f"Sent: {msg}")
        time.sleep(0.1)
    conn.send(None)  # Signal end
    conn.close()

def receiver(conn):
    """Receive messages from pipe"""
    while True:
        msg = conn.recv()
        if msg is None:
            break
        print(f"Received: {msg}")
    conn.close()

if __name__ == "__main__":
    # Create two ends of pipe
    parent_conn, child_conn = Pipe()
    
    p1 = Process(target=sender, args=(parent_conn,))
    p2 = Process(target=receiver, args=(child_conn,))
    
    p1.start()
    p2.start()
    
    p1.join()
    p2.join()
```

### Manager (Shared Objects)

```python
from multiprocessing import Process, Manager

def worker(shared_dict, shared_list, lock, worker_id):
    """Modify shared data"""
    with lock:
        shared_dict[worker_id] = worker_id * 10
        shared_list.append(worker_id)

if __name__ == "__main__":
    with Manager() as manager:
        # Create shared objects
        shared_dict = manager.dict()
        shared_list = manager.list()
        lock = manager.Lock()
        
        # Create and start processes
        processes = [
            Process(target=worker, args=(shared_dict, shared_list, lock, i))
            for i in range(5)
        ]
        
        for p in processes:
            p.start()
        for p in processes:
            p.join()
        
        print(f"Dict: {dict(shared_dict)}")
        print(f"List: {list(shared_list)}")
```

---

## 4. Shared Memory

### Value and Array

```python
from multiprocessing import Process, Value, Array
import ctypes

def increment_counter(counter, lock):
    """Increment shared counter"""
    for _ in range(10000):
        with lock:
            counter.value += 1

def modify_array(arr, index, value):
    """Modify shared array"""
    arr[index] = value

if __name__ == "__main__":
    from multiprocessing import Lock
    
    # Shared counter
    counter = Value('i', 0)  # 'i' = integer
    lock = Lock()
    
    processes = [
        Process(target=increment_counter, args=(counter, lock))
        for _ in range(4)
    ]
    
    for p in processes:
        p.start()
    for p in processes:
        p.join()
    
    print(f"Counter: {counter.value}")  # 40000
    
    # Shared array
    arr = Array('d', [0.0, 0.0, 0.0, 0.0])  # 'd' = double
    
    processes = [
        Process(target=modify_array, args=(arr, i, i * 1.5))
        for i in range(4)
    ]
    
    for p in processes:
        p.start()
    for p in processes:
        p.join()
    
    print(f"Array: {list(arr)}")  # [0.0, 1.5, 3.0, 4.5]
```

### shared_memory (Python 3.8+)

```python
from multiprocessing import Process
from multiprocessing.shared_memory import SharedMemory
import numpy as np

def worker(shm_name, shape, dtype):
    """Access shared memory in worker process"""
    # Attach to existing shared memory
    existing_shm = SharedMemory(name=shm_name)
    
    # Create numpy array backed by shared memory
    arr = np.ndarray(shape, dtype=dtype, buffer=existing_shm.buf)
    
    # Modify the array
    arr += 1
    
    # Cleanup
    existing_shm.close()

if __name__ == "__main__":
    # Create shared memory
    arr = np.array([1, 2, 3, 4, 5], dtype=np.int64)
    shm = SharedMemory(create=True, size=arr.nbytes)
    
    # Create numpy array backed by shared memory
    shared_arr = np.ndarray(arr.shape, dtype=arr.dtype, buffer=shm.buf)
    shared_arr[:] = arr[:]  # Copy data
    
    print(f"Before: {shared_arr}")
    
    # Create process that modifies shared array
    p = Process(target=worker, args=(shm.name, arr.shape, arr.dtype))
    p.start()
    p.join()
    
    print(f"After: {shared_arr}")
    
    # Cleanup
    shm.close()
    shm.unlink()
```

---

## 5. Synchronization

### Lock

```python
from multiprocessing import Process, Lock, Value

counter = Value('i', 0)

def increment_unsafe():
    global counter
    for _ in range(10000):
        counter.value += 1

def increment_safe(lock):
    global counter
    for _ in range(10000):
        with lock:
            counter.value += 1

if __name__ == "__main__":
    lock = Lock()
    
    # Without lock - race condition
    counter.value = 0
    processes = [Process(target=increment_unsafe) for _ in range(4)]
    for p in processes:
        p.start()
    for p in processes:
        p.join()
    print(f"Without lock: {counter.value}")  # Less than 40000
    
    # With lock - correct
    counter.value = 0
    processes = [Process(target=increment_safe, args=(lock,)) for _ in range(4)]
    for p in processes:
        p.start()
    for p in processes:
        p.join()
    print(f"With lock: {counter.value}")  # Exactly 40000
```

### Semaphore

```python
from multiprocessing import Process, Semaphore
import time

def limited_resource(semaphore, worker_id):
    """Access limited resource"""
    print(f"Worker {worker_id} waiting...")
    with semaphore:
        print(f"Worker {worker_id} accessing resource")
        time.sleep(1)
        print(f"Worker {worker_id} done")

if __name__ == "__main__":
    # Only 2 processes can access at once
    semaphore = Semaphore(2)
    
    processes = [
        Process(target=limited_resource, args=(semaphore, i))
        for i in range(5)
    ]
    
    for p in processes:
        p.start()
    for p in processes:
        p.join()
```

### Event

```python
from multiprocessing import Process, Event
import time

def waiter(event, name):
    """Wait for event"""
    print(f"{name} waiting...")
    event.wait()
    print(f"{name} proceeding!")

def setter(event, delay):
    """Set event after delay"""
    time.sleep(delay)
    print("Setting event!")
    event.set()

if __name__ == "__main__":
    event = Event()
    
    waiters = [
        Process(target=waiter, args=(event, f"Worker-{i}"))
        for i in range(3)
    ]
    setter_process = Process(target=setter, args=(event, 2))
    
    for w in waiters:
        w.start()
    setter_process.start()
    
    for w in waiters:
        w.join()
    setter_process.join()
```

---

## 6. Practical Patterns

### Pattern 1: Parallel Map-Reduce

```python
from multiprocessing import Pool
from functools import reduce

def mapper(chunk):
    """Map function: process chunk and return partial result"""
    return sum(x * x for x in chunk)

def reducer(results):
    """Reduce function: combine partial results"""
    return sum(results)

if __name__ == "__main__":
    # Split data into chunks
    data = list(range(10_000_000))
    num_workers = 4
    chunk_size = len(data) // num_workers
    chunks = [data[i:i + chunk_size] for i in range(0, len(data), chunk_size)]
    
    # Map phase
    with Pool(num_workers) as pool:
        partial_results = pool.map(mapper, chunks)
    
    # Reduce phase
    final_result = reducer(partial_results)
    print(f"Result: {final_result}")
```

### Pattern 2: Worker Pool with Progress

```python
from multiprocessing import Pool, Value, Lock
import time

counter = None
lock = None

def init_worker(c, l):
    global counter, lock
    counter = c
    lock = l

def process_item(item):
    """Process item and update progress"""
    time.sleep(0.1)  # Simulate work
    with lock:
        counter.value += 1
    return item * 2

if __name__ == "__main__":
    from multiprocessing import Value, Lock
    import threading
    
    items = list(range(100))
    counter = Value('i', 0)
    lock = Lock()
    
    # Progress monitor
    def monitor_progress(total):
        while counter.value < total:
            print(f"Progress: {counter.value}/{total}")
            time.sleep(0.5)
        print(f"Complete: {counter.value}/{total}")
    
    # Start monitor in background
    monitor = threading.Thread(target=monitor_progress, args=(len(items),))
    monitor.start()
    
    # Process items
    with Pool(4, initializer=init_worker, initargs=(counter, lock)) as pool:
        results = pool.map(process_item, items)
    
    monitor.join()
    print(f"Results: {len(results)} items processed")
```

### Pattern 3: Chunked Processing for Large Data

```python
from multiprocessing import Pool
import itertools

def process_chunk(chunk):
    """Process a chunk of data"""
    return [x * 2 for x in chunk]

def chunked(iterable, size):
    """Yield chunks of specified size"""
    it = iter(iterable)
    while True:
        chunk = list(itertools.islice(it, size))
        if not chunk:
            break
        yield chunk

if __name__ == "__main__":
    # Large data (generator to avoid memory issues)
    large_data = range(1_000_000)
    chunk_size = 10_000
    
    results = []
    with Pool(4) as pool:
        # Process in chunks to manage memory
        for result in pool.imap(process_chunk, chunked(large_data, chunk_size)):
            results.extend(result)
    
    print(f"Processed {len(results)} items")
```

### Pattern 4: Graceful Shutdown

```python
from multiprocessing import Process, Event, Queue
import time
import signal

def worker(shutdown_event, task_queue, result_queue):
    """Worker with graceful shutdown"""
    while not shutdown_event.is_set():
        try:
            task = task_queue.get(timeout=0.1)
            result = task * 2  # Process task
            result_queue.put(result)
        except:
            continue
    print("Worker shutting down gracefully")

if __name__ == "__main__":
    shutdown_event = Event()
    task_queue = Queue()
    result_queue = Queue()
    
    # Start workers
    workers = [
        Process(target=worker, args=(shutdown_event, task_queue, result_queue))
        for _ in range(4)
    ]
    for w in workers:
        w.start()
    
    # Add tasks
    for i in range(20):
        task_queue.put(i)
    
    # Wait for results
    time.sleep(1)
    
    # Graceful shutdown
    shutdown_event.set()
    for w in workers:
        w.join(timeout=2)
        if w.is_alive():
            w.terminate()
    
    # Collect results
    results = []
    while not result_queue.empty():
        results.append(result_queue.get())
    print(f"Results: {results}")
```

---

## Quick Reference

```python
# Basic Process
from multiprocessing import Process
p = Process(target=func, args=(arg,))
p.start()
p.join()

# Pool
from multiprocessing import Pool
with Pool(4) as pool:
    results = pool.map(func, items)
    results = pool.starmap(func, [(a, b), (c, d)])

# ProcessPoolExecutor
from concurrent.futures import ProcessPoolExecutor
with ProcessPoolExecutor(max_workers=4) as executor:
    results = executor.map(func, items)
    future = executor.submit(func, arg)

# IPC
from multiprocessing import Queue, Pipe, Manager
queue = Queue()
parent_conn, child_conn = Pipe()
manager = Manager()

# Shared Memory
from multiprocessing import Value, Array
counter = Value('i', 0)
arr = Array('d', [0.0, 0.0])

# Synchronization
from multiprocessing import Lock, Semaphore, Event
lock = Lock()
sem = Semaphore(3)
event = Event()
```

---

*Next: [Deep Dive](_03_deep_dive.md)*
