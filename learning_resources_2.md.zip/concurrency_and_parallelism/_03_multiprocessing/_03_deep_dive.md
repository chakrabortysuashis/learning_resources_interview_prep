# Multiprocessing in Python - Deep Dive

## Table of Contents
1. [Process Creation Methods](#1-process-creation-methods)
2. [Memory Architecture](#2-memory-architecture)
3. [Pickling and Serialization](#3-pickling-and-serialization)
4. [Pool Internals](#4-pool-internals)
5. [Performance Optimization](#5-performance-optimization)
6. [Error Handling](#6-error-handling)
7. [Platform Differences](#7-platform-differences)

---

## 1. Process Creation Methods

Python provides three methods to start processes, set via `multiprocessing.set_start_method()`:

```
┌─────────────────────────────────────────────────────────────────────┐
│                    PROCESS START METHODS                             │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  FORK (Unix default)                                                │
│  ┌─────────────┐     fork()      ┌─────────────┐                   │
│  │   Parent    │ ───────────────▶│    Child    │                   │
│  │ (original)  │                 │   (copy)    │                   │
│  │             │                 │             │                   │
│  │ memory ████ │                 │ memory ████ │ (copy-on-write)   │
│  │ file desc   │                 │ file desc   │ (inherited)       │
│  │ threads     │                 │ NO threads  │ (only 1 thread)   │
│  └─────────────┘                 └─────────────┘                   │
│  + Fast (no re-import)                                              │
│  - Can inherit unwanted state (locks, connections)                  │
│  - Not available on Windows                                         │
│                                                                     │
│  SPAWN (Windows default, safest)                                    │
│  ┌─────────────┐   new Python    ┌─────────────┐                   │
│  │   Parent    │ ───────────────▶│    Child    │                   │
│  │             │                 │   (fresh)   │                   │
│  │             │   pickle args   │             │                   │
│  │             │ ───────────────▶│  import     │                   │
│  │             │                 │  module     │                   │
│  └─────────────┘                 └─────────────┘                   │
│  + Clean process (no inherited state)                               │
│  + Available on all platforms                                       │
│  - Slower (new interpreter)                                         │
│  - Everything must be picklable                                     │
│                                                                     │
│  FORKSERVER (Unix only)                                             │
│  ┌─────────────┐                 ┌─────────────┐                   │
│  │   Parent    │─request fork───▶│   Server    │                   │
│  │             │                 │  (started   │                   │
│  │             │                 │   once)     │                   │
│  │             │                 └──────┬──────┘                   │
│  │             │                        │ fork                     │
│  │             │◀──────────────────────┐│                          │
│  │             │                 ┌──────▼──────┐                   │
│  │             │                 │    Child    │                   │
│  └─────────────┘                 └─────────────┘                   │
│  + Fork from clean server (not main process)                        │
│  + Avoids fork issues with threads                                  │
│  - Slight overhead                                                  │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Setting Start Method

```python
import multiprocessing as mp

# Set at program start (before any processes created)
if __name__ == "__main__":
    mp.set_start_method('spawn')  # 'fork', 'spawn', or 'forkserver'
    
    # Or use context for specific behavior
    ctx = mp.get_context('spawn')
    p = ctx.Process(target=worker)
    pool = ctx.Pool(4)
```

### Fork Safety Issues

```python
import threading
import multiprocessing

# DANGEROUS: Fork with active threads
lock = threading.Lock()

def worker():
    with lock:  # May deadlock if forked while lock held!
        print("Working")

def main():
    # Create thread that holds lock
    t = threading.Thread(target=worker)
    t.start()
    
    # Fork while thread might hold lock - DANGEROUS!
    # Child process gets copy of locked lock but not the thread
    p = multiprocessing.Process(target=worker)
    p.start()  # May deadlock!

# SAFE: Use spawn or forkserver when mixing threads and processes
```

---

## 2. Memory Architecture

### Copy-on-Write (Fork)

```
┌─────────────────────────────────────────────────────────────────────┐
│                    COPY-ON-WRITE BEHAVIOR                            │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  BEFORE FORK:                                                       │
│  ┌────────────────────────────────────────────────────────────┐    │
│  │                    Physical Memory                          │    │
│  │  ┌────────────────────────────────────────┐                │    │
│  │  │      Parent Process Data               │                │    │
│  │  │      [████████████████████]            │                │    │
│  │  └────────────────────────────────────────┘                │    │
│  └────────────────────────────────────────────────────────────┘    │
│                                                                     │
│  AFTER FORK (before writes):                                        │
│  ┌────────────────────────────────────────────────────────────┐    │
│  │                    Physical Memory                          │    │
│  │  ┌────────────────────────────────────────┐                │    │
│  │  │      Shared Data (read-only pages)     │                │    │
│  │  │      [████████████████████]            │                │    │
│  │  └───────────┬─────────────┬──────────────┘                │    │
│  │              │             │                                │    │
│  │        ┌─────┴─────┐ ┌─────┴─────┐                         │    │
│  │        │  Parent   │ │   Child   │ (both point to same)    │    │
│  │        └───────────┘ └───────────┘                         │    │
│  └────────────────────────────────────────────────────────────┘    │
│                                                                     │
│  AFTER WRITE (child modifies data):                                 │
│  ┌────────────────────────────────────────────────────────────┐    │
│  │                    Physical Memory                          │    │
│  │  ┌─────────────────────┐ ┌─────────────────────┐           │    │
│  │  │  Parent's Data      │ │   Child's Data      │           │    │
│  │  │  [████████████████] │ │  [████░░░░████████] │ (copied)  │    │
│  │  └─────────────────────┘ └─────────────────────┘           │    │
│  └────────────────────────────────────────────────────────────┘    │
│                                                                     │
│  Only modified pages are copied - efficient!                        │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Shared Memory Types

```python
from multiprocessing import shared_memory, Value, Array, Manager
import numpy as np

# Type 1: Value/Array (ctypes backed, fast)
counter = Value('i', 0)  # Integer
arr = Array('d', 100)    # 100 doubles

# Type 2: shared_memory (Python 3.8+, raw bytes)
shm = shared_memory.SharedMemory(create=True, size=1024)
# Access via numpy for efficiency
np_arr = np.ndarray((128,), dtype=np.float64, buffer=shm.buf)

# Type 3: Manager (proxy objects, slower but flexible)
with Manager() as m:
    shared_dict = m.dict()  # Shared dictionary
    shared_list = m.list()  # Shared list
```

### Memory Overhead Comparison

```
┌─────────────────────────────────────────────────────────────────────┐
│                MEMORY OVERHEAD BY START METHOD                       │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Parent Process: 500MB                                              │
│                                                                     │
│  FORK (copy-on-write):                                              │
│  ├── Initial: ~0MB additional (shared pages)                        │
│  ├── After modification: proportional to changes                    │
│  └── Typical: 50-200MB per worker                                   │
│                                                                     │
│  SPAWN (fresh interpreter):                                         │
│  ├── Base Python: ~30-50MB per worker                               │
│  ├── Plus imported modules                                          │
│  ├── Plus pickled arguments                                         │
│  └── Typical: 100-300MB per worker                                  │
│                                                                     │
│  For 8 workers with SPAWN: could use 1-2GB additional memory!       │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 3. Pickling and Serialization

### What Can Be Pickled

```python
import pickle
import multiprocessing as mp

# CAN be pickled (works with spawn/forkserver):
# - Basic types: int, float, str, bytes, None
# - Collections: list, tuple, dict, set
# - Classes defined at module level
# - Functions defined at module level
# - Instances of picklable classes

# CANNOT be pickled:
# - Lambda functions (mostly)
# - Nested functions
# - Open file handles
# - Network connections
# - Locks held by other threads
# - Generators and iterators

# Example: Picklable class
class Worker:
    def __init__(self, name):
        self.name = name
    
    def process(self, x):
        return f"{self.name}: {x * 2}"

# This works
def good_example():
    with mp.Pool(2) as pool:
        workers = [Worker("A"), Worker("B")]
        # Workers are pickled and sent to processes
        results = pool.map(lambda w: w.process(10), workers)

# This fails - lambda can't be pickled reliably
def bad_example():
    func = lambda x: x * 2  # Local lambda
    with mp.Pool(2) as pool:
        results = pool.map(func, [1, 2, 3])  # PicklingError!
```

### Custom Pickle Methods

```python
class DatabaseConnection:
    """Class with resources that can't be pickled"""
    
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self._conn = None  # Actual connection
    
    def connect(self):
        # Simulate connection
        self._conn = f"Connection to {self.host}:{self.port}"
    
    def __getstate__(self):
        """Called when pickling"""
        state = self.__dict__.copy()
        # Don't pickle the connection
        del state['_conn']
        return state
    
    def __setstate__(self, state):
        """Called when unpickling"""
        self.__dict__.update(state)
        # Reconnect in the new process
        self.connect()
```

### Reducing Pickle Overhead

```python
import multiprocessing as mp
from functools import partial
import numpy as np

# INEFFICIENT: Large data in function arguments
def process_data(data, config):
    return data * config['multiplier']

# Data is pickled every time!
big_data = np.random.rand(10_000_000)
config = {'multiplier': 2}

with mp.Pool(4) as pool:
    results = pool.starmap(process_data, [(big_data, config)] * 4)  # Slow!

# EFFICIENT: Use initializer to share data
worker_data = None

def init_worker(data, config):
    global worker_data
    worker_data = (data, config)

def process_index(index):
    global worker_data
    data, config = worker_data
    # Process chunk
    chunk = data[index::4]  # Every 4th element
    return chunk * config['multiplier']

with mp.Pool(4, initializer=init_worker, initargs=(big_data, config)) as pool:
    results = pool.map(process_index, range(4))  # Fast!
```

---

## 4. Pool Internals

### How Pool Works

```
┌─────────────────────────────────────────────────────────────────────┐
│                         POOL ARCHITECTURE                            │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Main Process                                                       │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                                                             │   │
│  │  pool.map(func, items)                                      │   │
│  │         │                                                   │   │
│  │         ▼                                                   │   │
│  │  ┌─────────────────┐                                       │   │
│  │  │  Task Handler   │ ── puts tasks ──▶ ┌──────────────┐    │   │
│  │  │    Thread       │                   │  Task Queue  │    │   │
│  │  └─────────────────┘                   │  (Inqueue)   │    │   │
│  │                                        └──────┬───────┘    │   │
│  │  ┌─────────────────┐                          │            │   │
│  │  │ Result Handler  │ ◀── gets results ── ┌────┴────────┐   │   │
│  │  │    Thread       │                     │Result Queue │   │   │
│  │  └─────────────────┘                     │ (Outqueue)  │   │   │
│  │                                          └──────┬──────┘   │   │
│  └─────────────────────────────────────────────────┼──────────┘   │
│                                                    │              │
│  Worker Processes                                  │              │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐  │              │
│  │  Worker 1   │ │  Worker 2   │ │  Worker 3   │  │              │
│  │             │ │             │ │             │◀─┘              │
│  │  1. get()   │ │  1. get()   │ │  1. get()   │                 │
│  │  2. func()  │ │  2. func()  │ │  2. func()  │                 │
│  │  3. put()   │ │  3. put()   │ │  3. put()   │                 │
│  └─────────────┘ └─────────────┘ └─────────────┘                 │
│                                                                   │
└───────────────────────────────────────────────────────────────────┘
```

### Pool Parameters

```python
from multiprocessing import Pool
import os

# Full Pool constructor
pool = Pool(
    processes=4,           # Number of workers (default: cpu_count())
    initializer=init_func, # Called once per worker at start
    initargs=(arg1, arg2), # Arguments for initializer
    maxtasksperchild=100,  # Restart worker after N tasks (memory leaks)
    context=None           # Start method context
)

# maxtasksperchild is useful for:
# - Preventing memory leaks in workers
# - Resetting worker state
# - Working around library bugs

def worker_with_leak():
    """Imagine this leaks memory"""
    cache.append(large_data)

# Workers restart after 100 tasks, freeing leaked memory
with Pool(4, maxtasksperchild=100) as pool:
    results = pool.map(worker_with_leak, large_dataset)
```

---

## 5. Performance Optimization

### Chunk Size Optimization

```python
from multiprocessing import Pool
import time

def process(x):
    return x * x

if __name__ == "__main__":
    data = list(range(1_000_000))
    
    # Default chunksize (len(items) / (workers * 4))
    with Pool(4) as pool:
        start = time.perf_counter()
        results = pool.map(process, data)  # Auto chunksize
        print(f"Default chunk: {time.perf_counter() - start:.2f}s")
    
    # Custom chunksize - larger = fewer IPC calls
    for chunksize in [100, 1000, 10000, 100000]:
        with Pool(4) as pool:
            start = time.perf_counter()
            results = pool.map(process, data, chunksize=chunksize)
            print(f"Chunksize {chunksize}: {time.perf_counter() - start:.2f}s")
```

### Reducing IPC Overhead

```python
import multiprocessing as mp
import numpy as np
from multiprocessing import shared_memory

# BAD: Passing large data through queue/pipe
def process_bad(data):
    return np.sum(data)

# GOOD: Using shared memory
def process_good(shm_name, shape, dtype, start, end):
    existing_shm = shared_memory.SharedMemory(name=shm_name)
    arr = np.ndarray(shape, dtype=dtype, buffer=existing_shm.buf)
    result = np.sum(arr[start:end])
    existing_shm.close()
    return result

if __name__ == "__main__":
    # Create large array in shared memory
    data = np.random.rand(10_000_000)
    shm = shared_memory.SharedMemory(create=True, size=data.nbytes)
    shared_arr = np.ndarray(data.shape, dtype=data.dtype, buffer=shm.buf)
    shared_arr[:] = data
    
    # Process using shared memory (fast!)
    chunk_size = len(data) // 4
    args = [
        (shm.name, data.shape, data.dtype, i * chunk_size, (i + 1) * chunk_size)
        for i in range(4)
    ]
    
    with mp.Pool(4) as pool:
        results = pool.starmap(process_good, args)
    
    print(f"Sum: {sum(results)}")
    
    shm.close()
    shm.unlink()
```

### When to Use multiprocessing vs NumPy

```python
import numpy as np
import multiprocessing as mp
import time

def pure_python_sum(data):
    """Pure Python - GIL bound"""
    return sum(data)

def numpy_sum(data):
    """NumPy - releases GIL, uses SIMD"""
    return np.sum(data)

def multiprocess_sum(data):
    """Multiprocessing - true parallelism"""
    def chunk_sum(chunk):
        return sum(chunk)
    
    chunks = np.array_split(data, 4)
    with mp.Pool(4) as pool:
        results = pool.map(chunk_sum, [list(c) for c in chunks])
    return sum(results)

if __name__ == "__main__":
    data = list(range(10_000_000))
    np_data = np.array(data)
    
    # Benchmark
    for name, func, d in [
        ("Pure Python", pure_python_sum, data),
        ("NumPy", numpy_sum, np_data),
        ("Multiprocessing", multiprocess_sum, data),
    ]:
        start = time.perf_counter()
        result = func(d)
        elapsed = time.perf_counter() - start
        print(f"{name}: {elapsed:.3f}s")

# Typical results:
# Pure Python: 0.500s
# NumPy: 0.010s  <- Winner for this case!
# Multiprocessing: 0.200s (overhead dominates)

# Multiprocessing wins when:
# - Task is truly CPU-bound and can't use NumPy
# - Each task takes significant time (>100ms)
# - Data is already in workers (initializer)
```

---

## 6. Error Handling

### Catching Exceptions in Workers

```python
from concurrent.futures import ProcessPoolExecutor, as_completed
import traceback

def worker(x):
    if x == 5:
        raise ValueError(f"Cannot process {x}")
    return x * 2

if __name__ == "__main__":
    items = list(range(10))
    
    # Method 1: Handle in worker
    def safe_worker(x):
        try:
            return ("success", worker(x))
        except Exception as e:
            return ("error", str(e))
    
    with ProcessPoolExecutor(4) as executor:
        results = list(executor.map(safe_worker, items))
        for status, value in results:
            if status == "error":
                print(f"Error: {value}")
    
    # Method 2: Handle when getting results
    with ProcessPoolExecutor(4) as executor:
        futures = [executor.submit(worker, x) for x in items]
        
        for future in as_completed(futures):
            try:
                result = future.result()
                print(f"Success: {result}")
            except Exception as e:
                print(f"Failed: {e}")
```

### Timeout Handling

```python
from multiprocessing import Process, Queue
import time

def slow_worker(result_queue):
    time.sleep(10)  # Very slow
    result_queue.put("done")

if __name__ == "__main__":
    result_queue = Queue()
    p = Process(target=slow_worker, args=(result_queue,))
    p.start()
    
    # Wait with timeout
    p.join(timeout=2)
    
    if p.is_alive():
        print("Worker timed out, terminating...")
        p.terminate()
        p.join()  # Clean up
    else:
        result = result_queue.get()
        print(f"Result: {result}")
```

### Handling Worker Crashes

```python
from multiprocessing import Pool
import signal
import sys

def worker(x):
    if x == 5:
        # Simulate crash
        sys.exit(1)
    return x * 2

if __name__ == "__main__":
    # Pool automatically restarts crashed workers
    with Pool(4) as pool:
        try:
            results = pool.map(worker, range(10))
        except Exception as e:
            print(f"Pool error: {e}")
    
    # For more control, use ProcessPoolExecutor
    from concurrent.futures import ProcessPoolExecutor
    
    with ProcessPoolExecutor(4) as executor:
        futures = [executor.submit(worker, x) for x in range(10)]
        
        for i, future in enumerate(futures):
            try:
                result = future.result(timeout=5)
                print(f"Item {i}: {result}")
            except Exception as e:
                print(f"Item {i} failed: {e}")
```

---

## 7. Platform Differences

### Windows vs Unix

```
┌─────────────────────────────────────────────────────────────────────┐
│                 PLATFORM DIFFERENCES                                 │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Feature              Windows            Unix (Linux/Mac)           │
│  ─────────────────    ─────────          ───────────────            │
│                                                                     │
│  Default start        spawn              fork                       │
│  method                                                             │
│                                                                     │
│  fork available       No                 Yes                        │
│                                                                     │
│  Process creation     ~100ms             ~10ms (fork)               │
│  time                                    ~100ms (spawn)             │
│                                                                     │
│  Requires             Always             Only with spawn            │
│  if __name__ ==                                                     │
│  "__main__"                                                         │
│                                                                     │
│  Global variables     Not inherited      Inherited (fork)           │
│  in workers           (must pickle)      Not inherited (spawn)      │
│                                                                     │
│  Open files           Not inherited      Inherited (fork)           │
│                                                                     │
│  CTRL+C handling      Tricky             Works as expected          │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Writing Cross-Platform Code

```python
import multiprocessing as mp
import sys

def worker(x):
    return x * 2

def main():
    # Always use spawn for cross-platform compatibility
    if sys.platform == 'win32':
        # Windows: spawn is the only option
        pass
    else:
        # Unix: explicitly set spawn for consistency
        mp.set_start_method('spawn')
    
    with mp.Pool(4) as pool:
        results = pool.map(worker, range(10))
    print(results)

# CRITICAL: Always use this guard on Windows
if __name__ == "__main__":
    main()
```

---

## Performance Benchmarks

```
┌─────────────────────────────────────────────────────────────────────┐
│            TYPICAL PERFORMANCE CHARACTERISTICS                       │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Operation                    Time                                  │
│  ─────────────────────────    ────────────────                      │
│  Process creation (spawn)     100-200ms                             │
│  Process creation (fork)      10-50ms                               │
│  Queue put/get (small)        0.1-0.5ms                             │
│  Queue put/get (1MB)          5-20ms                                │
│  Pipe send/recv (small)       0.05-0.2ms                            │
│  Shared memory access         <0.001ms                              │
│  Manager proxy call           0.5-2ms                               │
│                                                                     │
│  Rule of thumb:                                                     │
│  - Task should take >100ms to benefit from multiprocessing          │
│  - Keep data transfer minimal                                        │
│  - Use shared memory for large arrays                               │
│  - Batch small tasks together                                       │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

*Next: [Interview Questions](_04_interview_questions.md)*
