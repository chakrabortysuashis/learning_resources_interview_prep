# Multiprocessing in Python - Overview

## What is Multiprocessing? (The Simple Explanation)

Remember the **apartment analogy** from threading? Threads are like roommates sharing one apartment. **Processes are like having separate apartments entirely!**

```
┌─────────────────────────────────────────────────────────────────────┐
│                  MULTIPROCESSING = SEPARATE APARTMENTS               │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌─────────────────┐   ┌─────────────────┐   ┌─────────────────┐   │
│  │   Apartment 1   │   │   Apartment 2   │   │   Apartment 3   │   │
│  │   (Process 1)   │   │   (Process 2)   │   │   (Process 3)   │   │
│  │                 │   │                 │   │                 │   │
│  │  🛋️ Own memory  │   │  🛋️ Own memory  │   │  🛋️ Own memory  │   │
│  │  🔒 Own GIL     │   │  🔒 Own GIL     │   │  🔒 Own GIL     │   │
│  │  🖥️ Own Python  │   │  🖥️ Own Python  │   │  🖥️ Own Python  │   │
│  │                 │   │                 │   │                 │   │
│  └────────┬────────┘   └────────┬────────┘   └────────┬────────┘   │
│           │                     │                     │            │
│           │    Can run on different CPU cores!        │            │
│           │                     │                     │            │
│        ┌──┴─────────────────────┴─────────────────────┴──┐         │
│        │              CPU with Multiple Cores            │         │
│        │   ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐              │         │
│        │   │Core1│ │Core2│ │Core3│ │Core4│              │         │
│        │   └─────┘ └─────┘ └─────┘ └─────┘              │         │
│        └─────────────────────────────────────────────────┘         │
│                                                                     │
│  TRUE PARALLELISM! Each process runs independently.                │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Why Do We Need Multiprocessing?

Remember the **GIL** (Global Interpreter Lock)? It makes threads run one-at-a-time for CPU work.

**Multiprocessing solves this!** Each process has its own Python interpreter and its own GIL.

```
┌─────────────────────────────────────────────────────────────────────┐
│              THE GIL PROBLEM AND SOLUTION                            │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  THREADING (One GIL shared):                                        │
│                                                                     │
│  Process: [========== ONE GIL ==========]                           │
│           Thread A: ████      ████      ████                        │
│           Thread B:     ████      ████      ████                    │
│                     └── Take turns, no speedup! ──┘                 │
│                                                                     │
│  MULTIPROCESSING (Separate GILs):                                   │
│                                                                     │
│  Process 1: [GIL 1] ████████████████████                           │
│  Process 2: [GIL 2] ████████████████████                           │
│  Process 3: [GIL 3] ████████████████████                           │
│  Process 4: [GIL 4] ████████████████████                           │
│                     └── All run at SAME TIME! ──┘                   │
│                                                                     │
│  4x speedup on 4 cores!                                             │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Real-World Analogy: The Restaurant Kitchen

### Threading = One Kitchen, Multiple Chefs

```
┌─────────────────────────────────────────────────────────────────────┐
│                    ONE KITCHEN (Threading)                           │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                    SHARED KITCHEN                            │   │
│  │                                                             │   │
│  │   👨‍🍳 👨‍🍳 👨‍🍳 👨‍🍳                                                │   │
│  │   Chef Chef Chef Chef                                       │   │
│  │     1    2    3    4                                        │   │
│  │                                                             │   │
│  │   🍳 ONE stove (GIL) - only ONE chef can use at a time!    │   │
│  │                                                             │   │
│  │   Chef 1: *cooking*                                         │   │
│  │   Chef 2: "Waiting for stove..."                            │   │
│  │   Chef 3: "Waiting for stove..."                            │   │
│  │   Chef 4: "Waiting for stove..."                            │   │
│  │                                                             │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
│  ❌ Even with 4 chefs, cooking is still ONE-at-a-time!            │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Multiprocessing = Multiple Kitchens

```
┌─────────────────────────────────────────────────────────────────────┐
│               MULTIPLE KITCHENS (Multiprocessing)                    │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐ ┌────────────┐ │
│  │  Kitchen 1   │ │  Kitchen 2   │ │  Kitchen 3   │ │ Kitchen 4  │ │
│  │              │ │              │ │              │ │            │ │
│  │  👨‍🍳 Chef 1   │ │  👨‍🍳 Chef 2   │ │  👨‍🍳 Chef 3   │ │ 👨‍🍳 Chef 4  │ │
│  │  🍳 Stove    │ │  🍳 Stove    │ │  🍳 Stove    │ │ 🍳 Stove   │ │
│  │  *cooking*  │ │  *cooking*  │ │  *cooking*  │ │ *cooking*  │ │
│  │              │ │              │ │              │ │            │ │
│  └──────────────┘ └──────────────┘ └──────────────┘ └────────────┘ │
│                                                                     │
│  ✅ ALL 4 chefs cook at the SAME TIME! 4x faster!                  │
│                                                                     │
│  ⚠️ BUT: They can't easily share ingredients (memory)              │
│     They need to pass messages (IPC) to communicate                │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Threading vs Multiprocessing: When to Use Which?

```
┌─────────────────────────────────────────────────────────────────────┐
│                    DECISION GUIDE                                    │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  "What kind of task do I have?"                                     │
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                                                             │   │
│  │  I/O-BOUND                         CPU-BOUND                │   │
│  │  (Waiting for things)              (Calculating)            │   │
│  │                                                             │   │
│  │  Examples:                         Examples:                │   │
│  │  • Download files                  • Image processing       │   │
│  │  • Read/write files                • Data crunching         │   │
│  │  • Database queries                • Machine learning       │   │
│  │  • API calls                       • Video encoding         │   │
│  │  • User input                      • Encryption             │   │
│  │                                                             │   │
│  │         │                                   │                │   │
│  │         ▼                                   ▼                │   │
│  │                                                             │   │
│  │  ┌─────────────┐                   ┌─────────────┐          │   │
│  │  │  THREADING  │                   │MULTIPROCESS │          │   │
│  │  │   or        │                   │    ING      │          │   │
│  │  │  ASYNCIO    │                   │             │          │   │
│  │  └─────────────┘                   └─────────────┘          │   │
│  │                                                             │   │
│  │  • Low overhead                    • True parallelism       │   │
│  │  • Shared memory                   • Bypasses GIL           │   │
│  │  • GIL not a problem               • Higher overhead        │   │
│  │    (released during I/O)           • No shared memory       │   │
│  │                                                             │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## The Trade-Offs

### Advantages of Multiprocessing

```
┌─────────────────────────────────────────────────────────────────────┐
│                    PROS OF MULTIPROCESSING                           │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ✅ TRUE PARALLELISM                                                │
│     • Uses ALL your CPU cores                                       │
│     • 4 cores = potentially 4x speedup                              │
│                                                                     │
│  ✅ NO GIL PROBLEMS                                                 │
│     • Each process has its own GIL                                  │
│     • Perfect for CPU-heavy work                                    │
│                                                                     │
│  ✅ PROCESS ISOLATION                                               │
│     • One process crash doesn't kill others                         │
│     • Better stability for critical applications                    │
│                                                                     │
│  ✅ MEMORY ISOLATION                                                │
│     • No accidental data corruption                                 │
│     • No need for locks in many cases                               │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Disadvantages of Multiprocessing

```
┌─────────────────────────────────────────────────────────────────────┐
│                    CONS OF MULTIPROCESSING                           │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ❌ HIGHER OVERHEAD                                                 │
│     • Creating a process is slower than creating a thread           │
│     • Each process uses more memory                                 │
│                                                                     │
│  ❌ NO DIRECT MEMORY SHARING                                        │
│     • Must use special mechanisms (Queue, Pipe, Manager)            │
│     • Data must be serialized (pickle) to pass between processes    │
│                                                                     │
│  ❌ MORE COMPLEX COMMUNICATION                                      │
│     • Can't just share variables                                    │
│     • Need IPC (Inter-Process Communication)                        │
│                                                                     │
│  ❌ STARTUP TIME                                                    │
│     • On Windows: ~100ms to start a process                         │
│     • On Linux/Mac: ~10ms (fork is faster)                          │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## How Processes Communicate: The Mail Analogy

Since processes can't share memory directly, they need to send "mail" (messages):

```
┌─────────────────────────────────────────────────────────────────────┐
│              INTER-PROCESS COMMUNICATION (IPC)                       │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Like people in different apartments communicating:                 │
│                                                                     │
│  📬 QUEUE (Mailbox)                                                 │
│     One-way or many-to-many communication                           │
│     ┌──────────┐    📧📧📧    ┌──────────┐                         │
│     │Process 1 │ ────────────▶│Process 2 │                         │
│     └──────────┘   (queue)    └──────────┘                         │
│                                                                     │
│  📞 PIPE (Phone call)                                               │
│     Two-way communication between TWO processes                     │
│     ┌──────────┐◀───────────▶┌──────────┐                          │
│     │Process 1 │   (pipe)    │Process 2 │                          │
│     └──────────┘             └──────────┘                          │
│                                                                     │
│  🏢 MANAGER (Shared Office)                                         │
│     Shared data managed by a separate process                       │
│     ┌──────────┐    ┌───────────────┐    ┌──────────┐              │
│     │Process 1 │───▶│   Manager     │◀───│Process 2 │              │
│     └──────────┘    │(shared dict,  │    └──────────┘              │
│                     │ list, etc.)   │                              │
│                     └───────────────┘                              │
│                                                                     │
│  💾 SHARED MEMORY                                                   │
│     Direct memory sharing (fastest, but complex)                    │
│     ┌──────────┐                     ┌──────────┐                  │
│     │Process 1 │───┐           ┌─────│Process 2 │                  │
│     └──────────┘   │           │     └──────────┘                  │
│                    ▼           ▼                                    │
│               ┌────────────────────┐                               │
│               │   Shared Memory    │                               │
│               └────────────────────┘                               │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Quick Comparison Table

| Feature | Threading | Multiprocessing |
|---------|-----------|-----------------|
| **Memory** | Shared | Separate |
| **GIL** | Shared (blocks CPU work) | Separate (true parallelism) |
| **Creation cost** | Low (~0.1ms) | High (~10-100ms) |
| **Memory cost** | Low | High (copies) |
| **Communication** | Easy (shared variables) | Complex (IPC) |
| **Best for** | I/O-bound tasks | CPU-bound tasks |
| **Crash impact** | Kills whole program | Only kills that process |

---

## When to Use Multiprocessing

```
┌─────────────────────────────────────────────────────────────────────┐
│              USE MULTIPROCESSING WHEN:                               │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ✅ CPU-bound tasks (heavy calculations)                            │
│  ✅ You want to use ALL CPU cores                                   │
│  ✅ Tasks are independent (don't need to share much data)           │
│  ✅ Each task takes a while (startup cost is worth it)              │
│  ✅ You need process isolation (crash safety)                       │
│                                                                     │
│  Examples:                                                          │
│  • Image/video processing                                           │
│  • Scientific computing                                             │
│  • Machine learning training                                        │
│  • Data transformation                                              │
│  • Batch file processing                                            │
│                                                                     │
├─────────────────────────────────────────────────────────────────────┤
│              DON'T USE MULTIPROCESSING WHEN:                         │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ❌ Tasks are I/O-bound (use threading/asyncio)                     │
│  ❌ Tasks need to share lots of data frequently                     │
│  ❌ Tasks are very short (startup overhead not worth it)            │
│  ❌ You're on a single-core machine                                 │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Key Takeaways

1. **Multiprocessing = Multiple apartments** - Each process has its own memory and GIL
2. **True parallelism** - Actually uses multiple CPU cores simultaneously
3. **Solves GIL problem** - Perfect for CPU-heavy calculations
4. **Communication via IPC** - Processes talk through queues, pipes, or managers
5. **Higher overhead** - Creating processes is slower than threads
6. **Best for CPU-bound** - Calculations, processing, number-crunching

---

*Next: [Implementation & Code](_02_implementation.md)*
