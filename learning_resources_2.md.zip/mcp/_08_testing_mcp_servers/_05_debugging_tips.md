# Module 8.5: Debugging MCP Servers - Tips and Troubleshooting

## Introduction

Debugging MCP servers requires understanding both the MCP protocol and common failure patterns. This guide covers systematic approaches to diagnosing and fixing issues in MCP server implementations.

---

## Common MCP Issues and Solutions

### Issue Categories

```
+------------------------------------------------------------------+
|                     MCP Debugging Categories                      |
+------------------------------------------------------------------+
|                                                                    |
|  +----------------+  +----------------+  +----------------+       |
|  |   Connection   |  |   Protocol     |  |   Tool         |       |
|  |   Issues       |  |   Issues       |  |   Execution    |       |
|  +----------------+  +----------------+  +----------------+       |
|  | - Server start |  | - JSON-RPC     |  | - Input valid  |       |
|  | - Transport    |  | - Schema       |  | - Runtime err  |       |
|  | - Timeout      |  | - Method call  |  | - Return type  |       |
|  +----------------+  +----------------+  +----------------+       |
|                                                                    |
|  +----------------+  +----------------+  +----------------+       |
|  |   Resource     |  |   Performance  |  |   Integration  |       |
|  |   Issues       |  |   Issues       |  |   Issues       |       |
|  +----------------+  +----------------+  +----------------+       |
|  | - URI parsing  |  | - Memory leak  |  | - External API |       |
|  | - MIME types   |  | - Slow tools   |  | - Database     |       |
|  | - Access perms |  | - Concurrency  |  | - File system  |       |
|  +----------------+  +----------------+  +----------------+       |
|                                                                    |
+------------------------------------------------------------------+
```

---

## Connection Issues

### Problem: Server Won't Start

**Symptoms:**
- No output when running server
- Immediate exit
- "Module not found" errors

**Diagnostic Steps:**

```bash
# 1. Check Python environment
python --version
which python

# 2. Verify MCP package installed
pip list | grep mcp

# 3. Run with verbose output
python -u server.py 2>&1 | tee debug.log

# 4. Check for syntax errors
python -m py_compile server.py
```

**Common Causes and Fixes:**

| Cause | Fix |
|-------|-----|
| Wrong Python version | Use Python 3.10+ |
| Missing dependencies | `pip install mcp` |
| Import errors | Check module paths |
| Port already in use | Change port or kill process |

**Example Fix - Module Not Found:**
```python
# Before (broken)
from tools.calculator import CalculatorTools  # Relative import fails

# After (fixed)
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from tools.calculator import CalculatorTools
```

### Problem: Connection Timeout

**Symptoms:**
- Client hangs waiting for response
- "Connection timed out" error
- Server appears frozen

**Diagnostic Steps:**

```python
# Add connection logging
import logging

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# In your server code:
@server.call_tool()
async def handle_tool(name: str, arguments: dict):
    logger.debug(f"Tool call received: {name}")
    logger.debug(f"Arguments: {arguments}")
    
    try:
        result = await execute_tool(name, arguments)
        logger.debug(f"Tool result: {result}")
        return result
    except Exception as e:
        logger.exception(f"Tool execution failed: {e}")
        raise
```

**Common Causes and Fixes:**

```
+-----------------------------+----------------------------------------+
| Cause                       | Fix                                    |
+-----------------------------+----------------------------------------+
| Blocking I/O in async code  | Use asyncio versions of I/O calls      |
| Infinite loop in tool       | Add timeout to tool execution          |
| Deadlock                    | Review lock usage                      |
| Missing await               | Add await to async function calls      |
+-----------------------------+----------------------------------------+
```

### Problem: Transport Layer Errors

**Symptoms:**
- "Broken pipe" errors
- "Connection reset"
- Partial message received

**For stdio transport:**
```python
# Ensure stdout is unbuffered
import sys
sys.stdout = open(sys.stdout.fileno(), mode='w', buffering=1)

# Or use explicit flush
import sys
def send_response(response):
    sys.stdout.write(json.dumps(response) + '\n')
    sys.stdout.flush()
```

**For HTTP/SSE transport:**
```python
# Add connection keep-alive
from starlette.applications import Starlette
from starlette.middleware import Middleware
from starlette.middleware.cors import CORSMiddleware

app = Starlette(
    middleware=[
        Middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_methods=["*"],
            allow_headers=["*"],
        )
    ]
)

# Set appropriate timeouts
import uvicorn
uvicorn.run(app, host="0.0.0.0", port=8080, timeout_keep_alive=120)
```

---

## Protocol Issues

### Problem: Invalid JSON-RPC Format

**Symptoms:**
- "Parse error" response
- "Invalid request" error
- Missing response

**Diagnostic Tool:**
```python
def validate_jsonrpc_request(request: dict) -> list[str]:
    """Validate JSON-RPC 2.0 request format."""
    errors = []
    
    # Required: jsonrpc version
    if request.get("jsonrpc") != "2.0":
        errors.append("Missing or invalid 'jsonrpc' field (must be '2.0')")
    
    # Required: method
    if "method" not in request:
        errors.append("Missing 'method' field")
    elif not isinstance(request["method"], str):
        errors.append("'method' must be a string")
    
    # Required for requests (not notifications): id
    if "id" in request:
        if not isinstance(request["id"], (str, int, type(None))):
            errors.append("'id' must be string, number, or null")
    
    # Optional: params
    if "params" in request:
        if not isinstance(request["params"], (dict, list)):
            errors.append("'params' must be object or array")
    
    return errors

# Usage in debug
request = json.loads(raw_input)
errors = validate_jsonrpc_request(request)
if errors:
    print(f"Invalid request: {errors}")
```

### Problem: Method Not Found

**Symptoms:**
- Error code -32601
- "Method not found" message
- Tool works in other clients

**Debug Checklist:**
```
+------------------------------------------------------------------+
| Method Not Found Debugging Checklist                              |
+------------------------------------------------------------------+
|                                                                    |
| [ ] Is the tool registered with exact name?                       |
|     - Case sensitive: "Add" != "add"                              |
|     - No extra spaces: " add" != "add"                            |
|                                                                    |
| [ ] Is the server initialized before tool call?                   |
|     - Must call initialize first                                  |
|     - Check initialization succeeded                              |
|                                                                    |
| [ ] Does tools/list show the tool?                                |
|     - Run tools/list and verify tool appears                      |
|     - Check tool name matches exactly                             |
|                                                                    |
| [ ] Is the tool handler decorated correctly?                      |
|     - @server.call_tool() decorator present                       |
|     - Function name or explicit name matches                      |
|                                                                    |
+------------------------------------------------------------------+
```

**Fix Example:**
```python
# Before (tool name mismatch)
@server.call_tool()
async def handle_addition(name: str, arguments: dict):
    # Tool registered as "handle_addition" but called as "add"
    ...

# After (explicit name)
@server.call_tool()
async def handle_tool(name: str, arguments: dict):
    if name == "add":
        return do_add(arguments)
    elif name == "multiply":
        return do_multiply(arguments)
    else:
        raise ValueError(f"Unknown tool: {name}")
```

### Problem: Schema Validation Errors

**Symptoms:**
- "Invalid params" error
- Arguments not matching schema
- Type conversion issues

**Schema Debugging:**
```python
from jsonschema import validate, ValidationError

def debug_schema_validation(schema: dict, arguments: dict):
    """Debug schema validation issues."""
    try:
        validate(instance=arguments, schema=schema)
        print("Arguments valid!")
    except ValidationError as e:
        print(f"Validation error: {e.message}")
        print(f"Schema path: {' -> '.join(str(p) for p in e.schema_path)}")
        print(f"Instance path: {' -> '.join(str(p) for p in e.absolute_path)}")
        print(f"Expected: {e.schema}")
        print(f"Got: {e.instance}")

# Usage
tool_schema = {
    "type": "object",
    "properties": {
        "a": {"type": "number"},
        "b": {"type": "number"}
    },
    "required": ["a", "b"]
}

arguments = {"a": "5", "b": 3}  # Note: "5" is string, not number
debug_schema_validation(tool_schema, arguments)
```

---

## Tool Execution Issues

### Problem: Tool Returns Wrong Type

**Symptoms:**
- "Unexpected return type" error
- Content array malformed
- Missing text/type fields

**Correct Return Format:**
```python
from mcp.types import TextContent, ImageContent

# WRONG - returning raw value
async def add_tool(arguments: dict):
    return arguments["a"] + arguments["b"]  # Returns int

# CORRECT - returning content array
async def add_tool(arguments: dict) -> list:
    result = arguments["a"] + arguments["b"]
    return [TextContent(type="text", text=str(result))]

# CORRECT - returning multiple content items
async def search_tool(arguments: dict) -> list:
    results = perform_search(arguments["query"])
    return [
        TextContent(type="text", text=f"Found {len(results)} results:"),
        TextContent(type="text", text="\n".join(results)),
    ]
```

### Problem: Async/Await Issues

**Symptoms:**
- "coroutine was never awaited" warning
- RuntimeError about event loop
- Tool hangs indefinitely

**Common Mistakes and Fixes:**

```python
# MISTAKE 1: Forgetting await
async def tool_handler(name: str, arguments: dict):
    result = fetch_data(arguments)  # Missing await!
    return [TextContent(type="text", text=str(result))]

# FIX 1:
async def tool_handler(name: str, arguments: dict):
    result = await fetch_data(arguments)  # Added await
    return [TextContent(type="text", text=str(result))]

# MISTAKE 2: Using blocking I/O in async
async def read_file_tool(arguments: dict):
    with open(arguments["path"]) as f:  # Blocking!
        content = f.read()
    return [TextContent(type="text", text=content)]

# FIX 2: Use aiofiles
import aiofiles

async def read_file_tool(arguments: dict):
    async with aiofiles.open(arguments["path"]) as f:
        content = await f.read()
    return [TextContent(type="text", text=content)]

# MISTAKE 3: Running async from sync
def process_request(request):
    result = async_handler(request)  # Wrong!
    return result

# FIX 3: Use asyncio.run or ensure proper event loop
import asyncio

def process_request(request):
    return asyncio.run(async_handler(request))
```

### Problem: Exception Handling

**Symptoms:**
- Unhandled exceptions crash server
- No error message returned to client
- Server stops responding

**Robust Error Handling:**
```python
import traceback
from mcp.types import TextContent

async def handle_tool_call(name: str, arguments: dict):
    """Safely handle tool calls with proper error responses."""
    try:
        # Validate arguments
        validate_arguments(name, arguments)
        
        # Execute tool
        result = await execute_tool(name, arguments)
        
        return {
            "content": result,
            "isError": False
        }
        
    except ValueError as e:
        # User error - return friendly message
        return {
            "content": [TextContent(type="text", text=f"Invalid input: {e}")],
            "isError": True
        }
        
    except PermissionError as e:
        # Access error
        return {
            "content": [TextContent(type="text", text=f"Permission denied: {e}")],
            "isError": True
        }
        
    except Exception as e:
        # Unexpected error - log full details, return safe message
        logger.exception(f"Unexpected error in tool {name}")
        
        return {
            "content": [TextContent(
                type="text", 
                text=f"Internal error occurred. Please try again."
            )],
            "isError": True
        }
```

---

## Logging and Tracing

### Setting Up Comprehensive Logging

```python
"""MCP Server with comprehensive logging."""

import logging
import sys
from datetime import datetime
from pathlib import Path

# Create logs directory
log_dir = Path("logs")
log_dir.mkdir(exist_ok=True)

# Configure logging
def setup_logging(level=logging.DEBUG):
    """Configure logging for MCP server debugging."""
    
    # Create formatters
    detailed_formatter = logging.Formatter(
        '%(asctime)s | %(levelname)-8s | %(name)s:%(lineno)d | %(message)s'
    )
    
    simple_formatter = logging.Formatter(
        '%(levelname)s: %(message)s'
    )
    
    # File handler - detailed logs
    file_handler = logging.FileHandler(
        log_dir / f"mcp_server_{datetime.now():%Y%m%d_%H%M%S}.log"
    )
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(detailed_formatter)
    
    # Console handler - important messages only
    console_handler = logging.StreamHandler(sys.stderr)
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(simple_formatter)
    
    # Configure root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(level)
    root_logger.addHandler(file_handler)
    root_logger.addHandler(console_handler)
    
    # Create MCP-specific logger
    mcp_logger = logging.getLogger("mcp_server")
    
    return mcp_logger

logger = setup_logging()
```

### Request/Response Logging

```python
"""Log all MCP protocol messages."""

import json
from functools import wraps

class MCPRequestLogger:
    """Log MCP requests and responses."""
    
    def __init__(self, logger):
        self.logger = logger
        self.request_count = 0
    
    def log_request(self, request: dict):
        """Log incoming request."""
        self.request_count += 1
        req_id = request.get("id", "notification")
        method = request.get("method", "unknown")
        
        self.logger.debug(f"[REQ #{self.request_count}] --> {method}")
        self.logger.debug(f"Request body: {json.dumps(request, indent=2)}")
    
    def log_response(self, request_id, response: dict, duration_ms: float):
        """Log outgoing response."""
        status = "OK" if "result" in response else "ERROR"
        
        self.logger.debug(f"[RES #{request_id}] <-- {status} ({duration_ms:.2f}ms)")
        self.logger.debug(f"Response body: {json.dumps(response, indent=2)}")
    
    def log_error(self, request_id, error: Exception):
        """Log error during processing."""
        self.logger.error(f"[ERR #{request_id}] {type(error).__name__}: {error}")
        self.logger.exception("Full traceback:")

# Decorator for tool logging
def log_tool_call(logger):
    """Decorator to log tool calls."""
    def decorator(func):
        @wraps(func)
        async def wrapper(name: str, arguments: dict, *args, **kwargs):
            logger.info(f"Tool call: {name}")
            logger.debug(f"Arguments: {json.dumps(arguments)}")
            
            start_time = time.time()
            try:
                result = await func(name, arguments, *args, **kwargs)
                duration = (time.time() - start_time) * 1000
                
                logger.info(f"Tool {name} completed in {duration:.2f}ms")
                logger.debug(f"Result: {result}")
                
                return result
            except Exception as e:
                duration = (time.time() - start_time) * 1000
                logger.error(f"Tool {name} failed after {duration:.2f}ms: {e}")
                raise
        
        return wrapper
    return decorator
```

### Structured Logging for Production

```python
"""JSON structured logging for production environments."""

import json
import logging
from datetime import datetime, timezone

class JSONFormatter(logging.Formatter):
    """Format logs as JSON for log aggregation systems."""
    
    def format(self, record):
        log_entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno,
        }
        
        # Add exception info if present
        if record.exc_info:
            log_entry["exception"] = self.formatException(record.exc_info)
        
        # Add extra fields
        if hasattr(record, "request_id"):
            log_entry["request_id"] = record.request_id
        if hasattr(record, "tool_name"):
            log_entry["tool_name"] = record.tool_name
        if hasattr(record, "duration_ms"):
            log_entry["duration_ms"] = record.duration_ms
        
        return json.dumps(log_entry)

# Usage
handler = logging.StreamHandler()
handler.setFormatter(JSONFormatter())

logger = logging.getLogger("mcp_server")
logger.addHandler(handler)

# Log with extra context
logger.info(
    "Tool executed",
    extra={
        "request_id": "abc123",
        "tool_name": "add",
        "duration_ms": 15.5
    }
)
```

---

## Debugging Transport Issues

### stdio Transport Debugging

```python
"""Debug stdio transport issues."""

import sys
import os

def debug_stdio_setup():
    """Print stdio configuration for debugging."""
    print(f"stdin: {sys.stdin}", file=sys.stderr)
    print(f"stdin.encoding: {sys.stdin.encoding}", file=sys.stderr)
    print(f"stdin.isatty: {sys.stdin.isatty()}", file=sys.stderr)
    print(f"stdout: {sys.stdout}", file=sys.stderr)
    print(f"stdout.encoding: {sys.stdout.encoding}", file=sys.stderr)
    print(f"stdout.isatty: {sys.stdout.isatty()}", file=sys.stderr)
    print(f"PYTHONUNBUFFERED: {os.environ.get('PYTHONUNBUFFERED', 'not set')}", 
          file=sys.stderr)

def create_unbuffered_stdio():
    """Create unbuffered stdin/stdout for reliable MCP communication."""
    import io
    
    # Unbuffered binary stdin
    sys.stdin = io.TextIOWrapper(
        open(sys.stdin.fileno(), 'rb', buffering=0),
        encoding='utf-8',
        errors='replace',
        line_buffering=True
    )
    
    # Unbuffered binary stdout
    sys.stdout = io.TextIOWrapper(
        open(sys.stdout.fileno(), 'wb', buffering=0),
        encoding='utf-8',
        errors='replace',
        line_buffering=True
    )
```

### HTTP/SSE Transport Debugging

```python
"""Debug HTTP transport issues."""

from starlette.applications import Starlette
from starlette.middleware import Middleware
from starlette.requests import Request
from starlette.responses import Response
import time

class RequestLoggingMiddleware:
    """Middleware to log all HTTP requests."""
    
    def __init__(self, app):
        self.app = app
    
    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        
        request = Request(scope, receive)
        start_time = time.time()
        
        # Log request
        body = await request.body()
        print(f"[HTTP] {request.method} {request.url.path}", file=sys.stderr)
        print(f"Headers: {dict(request.headers)}", file=sys.stderr)
        print(f"Body: {body.decode()}", file=sys.stderr)
        
        # Process request
        response_started = False
        response_body = []
        
        async def send_wrapper(message):
            nonlocal response_started
            
            if message["type"] == "http.response.start":
                response_started = True
                print(f"Response status: {message['status']}", file=sys.stderr)
            elif message["type"] == "http.response.body":
                response_body.append(message.get("body", b""))
            
            await send(message)
        
        await self.app(scope, receive, send_wrapper)
        
        duration = (time.time() - start_time) * 1000
        print(f"Response body: {b''.join(response_body).decode()}", file=sys.stderr)
        print(f"Duration: {duration:.2f}ms", file=sys.stderr)

# Add to app
app = Starlette(
    middleware=[
        Middleware(RequestLoggingMiddleware),
    ]
)
```

---

## Error Interpretation Guide

### JSON-RPC Error Codes

```
+--------+------------------------+----------------------------------+
| Code   | Message                | Cause / Fix                      |
+--------+------------------------+----------------------------------+
| -32700 | Parse error            | Invalid JSON received            |
|        |                        | Fix: Check request formatting    |
+--------+------------------------+----------------------------------+
| -32600 | Invalid Request        | Not a valid JSON-RPC request     |
|        |                        | Fix: Check required fields       |
+--------+------------------------+----------------------------------+
| -32601 | Method not found       | Tool or method doesn't exist     |
|        |                        | Fix: Check tool registration     |
+--------+------------------------+----------------------------------+
| -32602 | Invalid params         | Arguments don't match schema     |
|        |                        | Fix: Validate against inputSchema|
+--------+------------------------+----------------------------------+
| -32603 | Internal error         | Server-side error                |
|        |                        | Fix: Check server logs           |
+--------+------------------------+----------------------------------+
| -32000 | Server error (custom)  | Application-specific error       |
| to     |                        | Fix: Check error message         |
| -32099 |                        |                                  |
+--------+------------------------+----------------------------------+
```

### MCP-Specific Errors

```
+----------------------------------+-----------------------------------+
| Error Pattern                    | Solution                          |
+----------------------------------+-----------------------------------+
| "Server not initialized"         | Send initialize request first     |
+----------------------------------+-----------------------------------+
| "Unknown capability"             | Check server capabilities         |
+----------------------------------+-----------------------------------+
| "Resource not found"             | Verify URI format and existence   |
+----------------------------------+-----------------------------------+
| "Tool execution failed"          | Check tool implementation         |
+----------------------------------+-----------------------------------+
| "Protocol version mismatch"      | Update client or server           |
+----------------------------------+-----------------------------------+
```

---

## Troubleshooting Checklist

### Quick Debug Checklist

```
+------------------------------------------------------------------+
|                    MCP Debugging Checklist                        |
+------------------------------------------------------------------+
|                                                                    |
| CONNECTION:                                                        |
| [ ] Server process starts without errors                          |
| [ ] Transport layer working (stdio/HTTP)                          |
| [ ] No firewall/network blocking                                  |
|                                                                    |
| INITIALIZATION:                                                    |
| [ ] Initialize request sent first                                 |
| [ ] Protocol version matches                                      |
| [ ] Capabilities exchanged correctly                              |
| [ ] Initialized notification sent                                 |
|                                                                    |
| TOOLS:                                                            |
| [ ] tools/list returns expected tools                             |
| [ ] Tool names match exactly (case-sensitive)                     |
| [ ] Arguments match input schema                                  |
| [ ] Tool handlers decorated correctly                             |
|                                                                    |
| RESOURCES:                                                        |
| [ ] resources/list returns expected resources                     |
| [ ] URI format is correct                                         |
| [ ] MIME types specified correctly                                |
| [ ] File/data access permissions OK                               |
|                                                                    |
| RESPONSES:                                                        |
| [ ] Content array properly formatted                              |
| [ ] isError flag set correctly                                    |
| [ ] JSON-RPC id matches request                                   |
|                                                                    |
+------------------------------------------------------------------+
```

### Debugging Commands

```bash
# Check server starts
python server.py 2>&1 | head -20

# Test with simple JSON-RPC
echo '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"debug","version":"1.0"}}}' | python server.py

# Check network ports (HTTP)
netstat -tlnp | grep 8080

# Monitor server logs
tail -f logs/mcp_server_*.log

# Test HTTP endpoint
curl -X POST http://localhost:8080/mcp \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' \
  -v

# Run with debug environment
DEBUG=1 PYTHONUNBUFFERED=1 python server.py
```

---

## Performance Debugging

### Identifying Slow Operations

```python
"""Profile slow tool executions."""

import time
import functools
from contextlib import contextmanager

@contextmanager
def timer(operation_name: str, threshold_ms: float = 100):
    """Context manager to time operations."""
    start = time.perf_counter()
    yield
    duration_ms = (time.perf_counter() - start) * 1000
    
    if duration_ms > threshold_ms:
        logger.warning(
            f"Slow operation: {operation_name} took {duration_ms:.2f}ms "
            f"(threshold: {threshold_ms}ms)"
        )
    else:
        logger.debug(f"{operation_name}: {duration_ms:.2f}ms")

def profile_async(func):
    """Decorator to profile async functions."""
    @functools.wraps(func)
    async def wrapper(*args, **kwargs):
        start = time.perf_counter()
        try:
            return await func(*args, **kwargs)
        finally:
            duration_ms = (time.perf_counter() - start) * 1000
            logger.info(f"{func.__name__}: {duration_ms:.2f}ms")
    return wrapper

# Usage
@profile_async
async def search_database(query: str):
    with timer("database_connection"):
        conn = await connect_to_database()
    
    with timer("execute_query"):
        results = await conn.execute(query)
    
    with timer("process_results"):
        processed = [process(r) for r in results]
    
    return processed
```

### Memory Debugging

```python
"""Debug memory issues in MCP servers."""

import tracemalloc
import psutil
import os

def log_memory_usage():
    """Log current memory usage."""
    process = psutil.Process(os.getpid())
    mem_info = process.memory_info()
    
    logger.info(
        f"Memory: RSS={mem_info.rss / 1024 / 1024:.1f}MB, "
        f"VMS={mem_info.vms / 1024 / 1024:.1f}MB"
    )

def start_memory_tracing():
    """Start memory allocation tracing."""
    tracemalloc.start()

def log_memory_snapshot():
    """Log top memory allocations."""
    snapshot = tracemalloc.take_snapshot()
    top_stats = snapshot.statistics('lineno')[:10]
    
    logger.info("Top 10 memory allocations:")
    for stat in top_stats:
        logger.info(f"  {stat}")
```

---

## Summary

| Issue Category | Primary Debug Tool | Quick Fix |
|---------------|-------------------|-----------|
| **Connection** | Logging, stderr | Check transport config |
| **Protocol** | JSON validator | Verify message format |
| **Tool Execution** | Exception logging | Add try/catch |
| **Resources** | URI validator | Check permissions |
| **Performance** | Profiler | Add timeouts |

### Key Takeaways

1. **Log everything** during development
2. **Validate inputs** before processing
3. **Handle errors gracefully** - return proper error responses
4. **Use MCP Inspector** for interactive debugging
5. **Write tests** to prevent regressions

---

## Next Steps

- **[Hands-on Lab](_06_testing_hands_on.ipynb)** - Practice debugging exercises
- **[Module 9](../_09_mcp_integration/)** - Deploying MCP servers
