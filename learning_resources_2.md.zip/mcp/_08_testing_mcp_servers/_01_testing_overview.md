# Module 8.1: Testing MCP Servers - Overview

## Introduction

Testing Model Context Protocol (MCP) servers is crucial for building reliable AI integrations. Unlike traditional APIs, MCP servers bridge AI models with external tools and data sources, making comprehensive testing essential for ensuring correct behavior, security, and performance.

---

## Why Testing MCP Servers is Important

### 1. **Reliability for AI Workflows**

MCP servers act as the backbone of AI agent capabilities. When an AI model invokes a tool or accesses a resource, the MCP server must respond correctly every time. Failures can lead to:

- Incorrect AI responses
- Failed task completions
- Poor user experience
- Data integrity issues

### 2. **Security Considerations**

MCP servers often have access to:
- Databases
- File systems
- External APIs
- Sensitive business data

Testing ensures that:
- Input validation works correctly
- Authorization checks are enforced
- Sensitive data is protected
- Error messages don't leak information

### 3. **Protocol Compliance**

MCP follows a specific JSON-RPC 2.0 based protocol. Testing verifies:
- Correct message formatting
- Proper error handling
- Schema compliance
- Transport layer reliability

### 4. **Maintainability**

Well-tested MCP servers are:
- Easier to refactor
- Safer to extend with new tools
- More reliable when dependencies change
- Better documented through test cases

---

## Different Testing Approaches

### Manual Testing

```
+------------------+     +------------------+     +------------------+
|   MCP Inspector  | --> |   MCP Server     | --> |   External APIs  |
|   (Interactive)  |     |   (Under Test)   |     |   / Databases    |
+------------------+     +------------------+     +------------------+
```

**Best for:**
- Exploratory testing
- Debugging issues
- Quick verification
- Learning the protocol

### Automated Testing

```
+------------------+     +------------------+     +------------------+
|   Test Suite     | --> |   MCP Server     | --> |   Mocked         |
|   (pytest/jest)  |     |   (Under Test)   |     |   Dependencies   |
+------------------+     +------------------+     +------------------+
         |
         v
+------------------+
|   CI/CD Pipeline |
|   (GitHub/GitLab)|
+------------------+
```

**Best for:**
- Regression testing
- Continuous integration
- Large-scale validation
- Documentation

### API Testing with Tools

```
+------------------+     +------------------+     +------------------+
|   Postman/curl   | --> |   HTTP/SSE       | --> |   MCP Server     |
|   (JSON-RPC)     |     |   Transport      |     |   (Under Test)   |
+------------------+     +------------------+     +------------------+
```

**Best for:**
- HTTP transport testing
- Request/response inspection
- Sharing test collections
- Performance testing

---

## The MCP Testing Pyramid

The testing pyramid for MCP servers follows a similar pattern to traditional software testing, but with MCP-specific considerations:

```
                        /\
                       /  \
                      /    \
                     / E2E  \
                    / Tests  \
                   /----------\
                  /            \
                 / Integration  \
                /    Tests       \
               /------------------\
              /                    \
             /     Unit Tests       \
            /      (Foundation)      \
           /--------------------------\
          
  More                                 Fewer
  Tests                                Tests
  Faster                               Slower
  Cheaper                              Expensive
```

### Level 1: Unit Tests (Base - Most Tests)

**What to Test:**
- Individual tool handler functions
- Resource read/list logic
- Input validation
- Error handling within functions
- Data transformations

**Example Structure:**
```python
# test_tools.py
def test_calculator_add():
    """Test the add tool with valid inputs."""
    result = calculator_tool.add(2, 3)
    assert result == 5

def test_calculator_divide_by_zero():
    """Test that division by zero raises appropriate error."""
    with pytest.raises(ValueError):
        calculator_tool.divide(10, 0)
```

**Characteristics:**
- Fast execution (milliseconds)
- No external dependencies
- Easy to write and maintain
- Run on every commit

### Level 2: Integration Tests (Middle - Moderate Tests)

**What to Test:**
- Tool registration with MCP server
- Request/response flow through the server
- Multiple tool interactions
- Resource subscription mechanisms
- Error propagation

**Example Structure:**
```python
# test_integration.py
async def test_tool_call_flow():
    """Test complete tool invocation through MCP protocol."""
    server = create_test_server()
    
    # Send tools/call request
    response = await server.handle_request({
        "jsonrpc": "2.0",
        "id": 1,
        "method": "tools/call",
        "params": {
            "name": "add",
            "arguments": {"a": 2, "b": 3}
        }
    })
    
    assert response["result"]["content"][0]["text"] == "5"
```

**Characteristics:**
- Moderate execution time
- May use test databases/mocks
- Tests component interactions
- Run before merging

### Level 3: End-to-End Tests (Top - Fewest Tests)

**What to Test:**
- Full server startup and shutdown
- Complete client-server communication
- Real external service integration
- Performance under load
- Multi-session scenarios

**Example Structure:**
```python
# test_e2e.py
async def test_full_session():
    """Test complete MCP session lifecycle."""
    # Start real server process
    server_process = await start_mcp_server()
    
    # Connect as client
    client = MCPClient()
    await client.connect("stdio")
    
    # Initialize session
    result = await client.initialize()
    assert "tools" in result.capabilities
    
    # List and call tools
    tools = await client.list_tools()
    result = await client.call_tool("add", {"a": 1, "b": 2})
    
    # Clean shutdown
    await client.close()
    server_process.terminate()
```

**Characteristics:**
- Slowest execution
- Uses real dependencies when possible
- Tests actual user scenarios
- Run before release

---

## Tools Available for Testing

### 1. MCP Inspector

```
+---------------------------------------------------------------+
|                       MCP Inspector                            |
|---------------------------------------------------------------|
|  [Connect]  Server: stdio python server.py                     |
|---------------------------------------------------------------|
|  Tools        |  Resources      |  Prompts      |  Logs       |
|---------------------------------------------------------------|
|  > add        |  > file://      |  > greeting   |  [2024-01] |
|  > multiply   |  > db://        |               |  Connected  |
|  > divide     |                 |               |  [2024-01] |
|               |                 |               |  Initialized|
+---------------------------------------------------------------+
```

**Features:**
- Interactive tool testing
- Real-time log viewing
- Resource inspection
- Prompt testing
- Visual debugging

**Installation:**
```bash
npx @modelcontextprotocol/inspector
```

### 2. Postman / Insomnia

**Best for:**
- HTTP/SSE transport testing
- Creating shareable test collections
- Automated API testing
- Response validation

### 3. pytest (Python)

**Best for:**
- Unit and integration tests
- Async test support
- Fixture-based setup
- CI/CD integration

```python
# Install
pip install pytest pytest-asyncio mcp

# Run
pytest tests/ -v
```

### 4. Jest/Vitest (TypeScript/JavaScript)

**Best for:**
- TypeScript MCP servers
- Fast test execution
- Built-in mocking
- Code coverage

```bash
# Install
npm install --save-dev jest @types/jest ts-jest

# Run
npm test
```

### 5. curl / httpie

**Best for:**
- Quick manual testing
- Scripted tests
- CI/CD pipelines
- Debugging

```bash
# Example JSON-RPC request
curl -X POST http://localhost:8080/mcp \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'
```

---

## Testing Architecture

### Complete Testing Setup

```
+------------------------------------------------------------------+
|                        Development Environment                     |
+------------------------------------------------------------------+
|                                                                    |
|  +------------------+     +------------------+                     |
|  |   Source Code    |     |   Test Suite     |                     |
|  |   (MCP Server)   |     |   (pytest/jest)  |                     |
|  +--------+---------+     +--------+---------+                     |
|           |                        |                               |
|           v                        v                               |
|  +------------------+     +------------------+                     |
|  |   Local Server   |<----|   Test Runner    |                     |
|  |   Instance       |     |                  |                     |
|  +--------+---------+     +------------------+                     |
|           |                        |                               |
|           v                        v                               |
|  +------------------+     +------------------+                     |
|  |   MCP Inspector  |     |   Coverage       |                     |
|  |   (Manual Test)  |     |   Report         |                     |
|  +------------------+     +------------------+                     |
|                                                                    |
+------------------------------------------------------------------+
                            |
                            v
+------------------------------------------------------------------+
|                         CI/CD Pipeline                             |
+------------------------------------------------------------------+
|                                                                    |
|  +------------------+     +------------------+     +-------------+ |
|  |   Lint/Format    | --> |   Unit Tests     | --> | Integration | |
|  |   Check          |     |   (Fast)         |     | Tests       | |
|  +------------------+     +------------------+     +-------------+ |
|                                    |                      |        |
|                                    v                      v        |
|                           +------------------+    +-------------+  |
|                           |   E2E Tests      |    | Deploy      |  |
|                           |   (Slow)         |    | Staging     |  |
|                           +------------------+    +-------------+  |
|                                                                    |
+------------------------------------------------------------------+
```

### Test Data Flow

```
Test Input                    MCP Server                    Expected Output
+-----------+                +------------+                +---------------+
| JSON-RPC  |   --------->   | Parse      |   --------->   | JSON-RPC      |
| Request   |                | Validate   |                | Response      |
+-----------+                | Execute    |                +---------------+
                             | Format     |
                             +------------+
                                   |
                                   v
                             +------------+
                             | Assertions |
                             | - Status   |
                             | - Content  |
                             | - Schema   |
                             +------------+
```

---

## Testing Strategy Recommendations

### For New MCP Servers

1. **Start with Unit Tests**
   - Test each tool function independently
   - Cover edge cases and error conditions
   - Aim for 80%+ code coverage

2. **Add Integration Tests**
   - Test the MCP protocol flow
   - Verify tool registration
   - Test error handling

3. **Use MCP Inspector**
   - Interactive debugging during development
   - Verify request/response format
   - Test real-world scenarios

### For Existing MCP Servers

1. **Add Tests for Bug Fixes**
   - Write a failing test first
   - Fix the bug
   - Ensure test passes

2. **Cover Critical Paths**
   - Identify most-used tools
   - Test security-sensitive operations
   - Cover integration points

3. **Gradual Test Coverage**
   - Add tests with each change
   - Focus on high-risk areas
   - Document with tests

---

## Test Configuration Example

### pytest.ini (Python)

```ini
[pytest]
asyncio_mode = auto
testpaths = tests
python_files = test_*.py
python_functions = test_*
addopts = -v --tb=short --cov=src --cov-report=html

markers =
    unit: Unit tests (fast, isolated)
    integration: Integration tests (moderate speed)
    e2e: End-to-end tests (slow, full system)
```

### Directory Structure

```
mcp_server/
|-- src/
|   |-- __init__.py
|   |-- server.py
|   |-- tools/
|   |   |-- calculator.py
|   |   |-- file_ops.py
|   |-- resources/
|       |-- database.py
|
|-- tests/
|   |-- __init__.py
|   |-- conftest.py           # Shared fixtures
|   |-- unit/
|   |   |-- test_calculator.py
|   |   |-- test_file_ops.py
|   |-- integration/
|   |   |-- test_server.py
|   |   |-- test_tools_flow.py
|   |-- e2e/
|       |-- test_full_session.py
|
|-- pytest.ini
|-- requirements-test.txt
```

---

## Summary

| Aspect | Unit Tests | Integration Tests | E2E Tests |
|--------|------------|-------------------|-----------|
| **Speed** | Fast (ms) | Moderate (seconds) | Slow (minutes) |
| **Isolation** | High | Medium | Low |
| **Maintenance** | Low | Medium | High |
| **Coverage** | Functions | Components | System |
| **Dependencies** | Mocked | Partial | Real |
| **Run Frequency** | Every commit | Pre-merge | Pre-release |

---

## Next Steps

1. **[MCP Inspector](_02_mcp_inspector.md)** - Interactive testing tool
2. **[Testing with Postman](_03_testing_with_postman.md)** - HTTP/SSE testing
3. **[Programmatic Testing](_04_programmatic_testing.md)** - Automated test suites
4. **[Debugging Tips](_05_debugging_tips.md)** - Troubleshooting guide
5. **[Hands-on Lab](_06_testing_hands_on.ipynb)** - Practice exercises
