# Module 8.4: Programmatic Testing for MCP Servers

## Introduction

Programmatic testing allows you to create automated, repeatable test suites for your MCP servers. This module covers writing unit tests, integration tests, and end-to-end tests using Python's pytest framework.

---

## Testing Setup

### Project Structure

```
mcp_calculator_server/
|
|-- src/
|   |-- __init__.py
|   |-- server.py              # Main MCP server
|   |-- tools/
|   |   |-- __init__.py
|   |   |-- calculator.py      # Calculator tool implementations
|   |   |-- file_ops.py        # File operation tools
|   |-- resources/
|   |   |-- __init__.py
|   |   |-- config.py          # Configuration resources
|   |-- utils/
|       |-- __init__.py
|       |-- validators.py      # Input validation helpers
|
|-- tests/
|   |-- __init__.py
|   |-- conftest.py            # Shared pytest fixtures
|   |-- unit/
|   |   |-- __init__.py
|   |   |-- test_calculator.py
|   |   |-- test_validators.py
|   |-- integration/
|   |   |-- __init__.py
|   |   |-- test_server.py
|   |   |-- test_tool_flow.py
|   |-- e2e/
|       |-- __init__.py
|       |-- test_full_session.py
|
|-- pytest.ini
|-- requirements.txt
|-- requirements-test.txt
```

### Dependencies

**requirements.txt:**
```
mcp>=1.0.0
pydantic>=2.0.0
```

**requirements-test.txt:**
```
pytest>=7.0.0
pytest-asyncio>=0.21.0
pytest-cov>=4.0.0
pytest-mock>=3.10.0
pytest-timeout>=2.1.0
httpx>=0.24.0
respx>=0.20.0
```

### pytest.ini Configuration

```ini
[pytest]
asyncio_mode = auto
testpaths = tests
python_files = test_*.py
python_classes = Test*
python_functions = test_*
addopts = 
    -v 
    --tb=short 
    --strict-markers
    --cov=src 
    --cov-report=term-missing
    --cov-report=html:coverage_html
    --cov-fail-under=80

markers =
    unit: Unit tests (fast, no external dependencies)
    integration: Integration tests (may use test doubles)
    e2e: End-to-end tests (full system)
    slow: Tests that take longer than 5 seconds
    requires_db: Tests requiring database connection

filterwarnings =
    ignore::DeprecationWarning
    ignore::PendingDeprecationWarning

timeout = 30
```

---

## Writing Unit Tests

### Testing Tool Functions in Isolation

**src/tools/calculator.py:**
```python
"""Calculator tools for the MCP server."""

from typing import Any
from mcp.types import TextContent

class CalculatorTools:
    """Calculator operations as MCP tools."""
    
    def add(self, a: float, b: float) -> float:
        """Add two numbers."""
        return a + b
    
    def subtract(self, a: float, b: float) -> float:
        """Subtract b from a."""
        return a - b
    
    def multiply(self, a: float, b: float) -> float:
        """Multiply two numbers."""
        return a * b
    
    def divide(self, a: float, b: float) -> float:
        """Divide a by b.
        
        Raises:
            ValueError: If b is zero.
        """
        if b == 0:
            raise ValueError("Cannot divide by zero")
        return a / b
    
    def power(self, base: float, exponent: float) -> float:
        """Raise base to the power of exponent."""
        result = base ** exponent
        if result == float('inf'):
            raise OverflowError("Result too large")
        return result
```

**tests/unit/test_calculator.py:**
```python
"""Unit tests for calculator tools."""

import pytest
from src.tools.calculator import CalculatorTools


class TestCalculatorAdd:
    """Tests for the add operation."""
    
    @pytest.fixture
    def calculator(self):
        """Create a calculator instance."""
        return CalculatorTools()
    
    def test_add_positive_numbers(self, calculator):
        """Test adding two positive numbers."""
        result = calculator.add(2, 3)
        assert result == 5
    
    def test_add_negative_numbers(self, calculator):
        """Test adding two negative numbers."""
        result = calculator.add(-2, -3)
        assert result == -5
    
    def test_add_mixed_numbers(self, calculator):
        """Test adding positive and negative numbers."""
        result = calculator.add(5, -3)
        assert result == 2
    
    def test_add_with_zero(self, calculator):
        """Test adding zero."""
        assert calculator.add(5, 0) == 5
        assert calculator.add(0, 5) == 5
        assert calculator.add(0, 0) == 0
    
    def test_add_floats(self, calculator):
        """Test adding floating point numbers."""
        result = calculator.add(1.5, 2.5)
        assert result == pytest.approx(4.0)
    
    def test_add_large_numbers(self, calculator):
        """Test adding very large numbers."""
        result = calculator.add(1e100, 1e100)
        assert result == pytest.approx(2e100)


class TestCalculatorDivide:
    """Tests for the divide operation."""
    
    @pytest.fixture
    def calculator(self):
        return CalculatorTools()
    
    def test_divide_normal(self, calculator):
        """Test normal division."""
        result = calculator.divide(10, 2)
        assert result == 5.0
    
    def test_divide_by_zero_raises_error(self, calculator):
        """Test that division by zero raises ValueError."""
        with pytest.raises(ValueError, match="Cannot divide by zero"):
            calculator.divide(10, 0)
    
    def test_divide_zero_numerator(self, calculator):
        """Test dividing zero by a number."""
        result = calculator.divide(0, 5)
        assert result == 0.0
    
    def test_divide_result_is_float(self, calculator):
        """Test that division always returns float."""
        result = calculator.divide(7, 2)
        assert isinstance(result, float)
        assert result == 3.5


class TestCalculatorPower:
    """Tests for the power operation."""
    
    @pytest.fixture
    def calculator(self):
        return CalculatorTools()
    
    def test_power_positive_exponent(self, calculator):
        """Test positive exponent."""
        result = calculator.power(2, 3)
        assert result == 8
    
    def test_power_zero_exponent(self, calculator):
        """Test zero exponent returns 1."""
        result = calculator.power(5, 0)
        assert result == 1
    
    def test_power_negative_exponent(self, calculator):
        """Test negative exponent."""
        result = calculator.power(2, -2)
        assert result == pytest.approx(0.25)
    
    def test_power_overflow_raises_error(self, calculator):
        """Test that overflow raises OverflowError."""
        with pytest.raises(OverflowError, match="Result too large"):
            calculator.power(10, 1000)


# Parametrized tests for comprehensive coverage
class TestCalculatorParametrized:
    """Parametrized tests for multiple inputs."""
    
    @pytest.fixture
    def calculator(self):
        return CalculatorTools()
    
    @pytest.mark.parametrize("a, b, expected", [
        (1, 1, 2),
        (0, 0, 0),
        (-1, 1, 0),
        (100, 200, 300),
        (1.5, 2.5, 4.0),
        (-10, -20, -30),
    ])
    def test_add_various_inputs(self, calculator, a, b, expected):
        """Test add with various input combinations."""
        result = calculator.add(a, b)
        assert result == pytest.approx(expected)
    
    @pytest.mark.parametrize("a, b, expected", [
        (6, 2, 3),
        (10, 4, 2.5),
        (-10, 2, -5),
        (10, -2, -5),
        (0, 5, 0),
    ])
    def test_divide_various_inputs(self, calculator, a, b, expected):
        """Test divide with various input combinations."""
        result = calculator.divide(a, b)
        assert result == pytest.approx(expected)
```

---

## Testing with Mocking and Fixtures

### Shared Fixtures (conftest.py)

**tests/conftest.py:**
```python
"""Shared pytest fixtures for MCP server tests."""

import pytest
import asyncio
from unittest.mock import AsyncMock, MagicMock
from typing import AsyncGenerator

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import (
    Tool,
    TextContent,
    Resource,
    Prompt,
    PromptMessage,
)


@pytest.fixture(scope="session")
def event_loop():
    """Create an event loop for the test session."""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


@pytest.fixture
def mock_mcp_server():
    """Create a mock MCP server for testing."""
    server = MagicMock(spec=Server)
    server.name = "test-server"
    return server


@pytest.fixture
def sample_tools():
    """Return sample tool definitions."""
    return [
        Tool(
            name="add",
            description="Add two numbers",
            inputSchema={
                "type": "object",
                "properties": {
                    "a": {"type": "number"},
                    "b": {"type": "number"}
                },
                "required": ["a", "b"]
            }
        ),
        Tool(
            name="multiply",
            description="Multiply two numbers",
            inputSchema={
                "type": "object",
                "properties": {
                    "a": {"type": "number"},
                    "b": {"type": "number"}
                },
                "required": ["a", "b"]
            }
        ),
    ]


@pytest.fixture
def sample_resources():
    """Return sample resource definitions."""
    return [
        Resource(
            uri="config://settings",
            name="Settings",
            description="Application settings",
            mimeType="application/json"
        ),
    ]


@pytest.fixture
def sample_prompts():
    """Return sample prompt definitions."""
    return [
        Prompt(
            name="greeting",
            description="Generate a greeting",
            arguments=[
                {"name": "name", "required": True},
                {"name": "style", "required": False}
            ]
        ),
    ]


@pytest.fixture
def mock_tool_result():
    """Return a mock successful tool result."""
    return {
        "content": [
            TextContent(type="text", text="8")
        ],
        "isError": False
    }


@pytest.fixture
def mock_error_result():
    """Return a mock error tool result."""
    return {
        "content": [
            TextContent(type="text", text="Error: Division by zero")
        ],
        "isError": True
    }


# Database fixtures (for tests that need it)
@pytest.fixture
def mock_database():
    """Create a mock database connection."""
    db = MagicMock()
    db.query = MagicMock(return_value=[
        {"id": 1, "name": "Alice"},
        {"id": 2, "name": "Bob"},
    ])
    db.execute = MagicMock(return_value=True)
    return db


# File system fixtures
@pytest.fixture
def temp_config_file(tmp_path):
    """Create a temporary config file."""
    config = tmp_path / "config.json"
    config.write_text('{"debug": true, "port": 8080}')
    return config


@pytest.fixture
def temp_data_directory(tmp_path):
    """Create a temporary data directory with files."""
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    
    (data_dir / "file1.txt").write_text("Content of file 1")
    (data_dir / "file2.txt").write_text("Content of file 2")
    (data_dir / "subdir").mkdir()
    (data_dir / "subdir" / "file3.txt").write_text("Content of file 3")
    
    return data_dir
```

### Mocking External Services

**tests/unit/test_with_mocks.py:**
```python
"""Tests demonstrating mocking patterns."""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch
import httpx


class TestExternalAPIMocking:
    """Tests that mock external API calls."""
    
    @pytest.fixture
    def api_tool(self):
        """Create API tool with mocked client."""
        from src.tools.api_tools import APITools
        return APITools()
    
    @pytest.mark.asyncio
    async def test_fetch_weather_success(self, api_tool):
        """Test weather fetch with mocked response."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "temperature": 72,
            "condition": "sunny"
        }
        
        with patch.object(
            httpx.AsyncClient, 
            'get', 
            new_callable=AsyncMock,
            return_value=mock_response
        ):
            result = await api_tool.fetch_weather("New York")
            assert result["temperature"] == 72
            assert result["condition"] == "sunny"
    
    @pytest.mark.asyncio
    async def test_fetch_weather_api_error(self, api_tool):
        """Test weather fetch handles API errors."""
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.text = "Internal Server Error"
        
        with patch.object(
            httpx.AsyncClient, 
            'get', 
            new_callable=AsyncMock,
            return_value=mock_response
        ):
            with pytest.raises(Exception, match="API error"):
                await api_tool.fetch_weather("New York")
    
    @pytest.mark.asyncio
    async def test_fetch_weather_network_error(self, api_tool):
        """Test weather fetch handles network errors."""
        with patch.object(
            httpx.AsyncClient, 
            'get', 
            new_callable=AsyncMock,
            side_effect=httpx.NetworkError("Connection refused")
        ):
            with pytest.raises(Exception, match="Network error"):
                await api_tool.fetch_weather("New York")


class TestDatabaseMocking:
    """Tests that mock database operations."""
    
    @pytest.fixture
    def db_tool(self, mock_database):
        """Create database tool with mock connection."""
        from src.tools.database_tools import DatabaseTools
        tool = DatabaseTools()
        tool.db = mock_database
        return tool
    
    def test_query_users(self, db_tool, mock_database):
        """Test querying users."""
        result = db_tool.query_users()
        
        mock_database.query.assert_called_once()
        assert len(result) == 2
        assert result[0]["name"] == "Alice"
    
    def test_insert_user(self, db_tool, mock_database):
        """Test inserting a user."""
        result = db_tool.insert_user("Charlie", "charlie@test.com")
        
        mock_database.execute.assert_called_once()
        assert result is True
```

---

## Integration Testing

### Testing the MCP Protocol Flow

**tests/integration/test_server.py:**
```python
"""Integration tests for MCP server protocol."""

import pytest
import json
from typing import Any, Dict


class TestMCPServerProtocol:
    """Test MCP server protocol compliance."""
    
    @pytest.fixture
    async def server_instance(self):
        """Create and configure test server instance."""
        from src.server import create_server
        server = await create_server()
        yield server
        # Cleanup if needed
    
    @pytest.mark.asyncio
    async def test_initialize_request(self, server_instance):
        """Test server responds to initialize correctly."""
        request = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {
                    "name": "test-client",
                    "version": "1.0.0"
                }
            }
        }
        
        response = await server_instance.handle_request(request)
        
        assert response["jsonrpc"] == "2.0"
        assert response["id"] == 1
        assert "result" in response
        assert "capabilities" in response["result"]
        assert "serverInfo" in response["result"]
    
    @pytest.mark.asyncio
    async def test_tools_list_request(self, server_instance):
        """Test listing available tools."""
        # First initialize
        await server_instance.handle_request({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "test", "version": "1.0"}
            }
        })
        
        # Then list tools
        request = {
            "jsonrpc": "2.0",
            "id": 2,
            "method": "tools/list"
        }
        
        response = await server_instance.handle_request(request)
        
        assert response["jsonrpc"] == "2.0"
        assert response["id"] == 2
        assert "result" in response
        assert "tools" in response["result"]
        assert isinstance(response["result"]["tools"], list)
    
    @pytest.mark.asyncio
    async def test_tool_call_success(self, server_instance):
        """Test successful tool execution."""
        # Initialize first
        await server_instance.handle_request({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "test", "version": "1.0"}
            }
        })
        
        # Call add tool
        request = {
            "jsonrpc": "2.0",
            "id": 3,
            "method": "tools/call",
            "params": {
                "name": "add",
                "arguments": {
                    "a": 5,
                    "b": 3
                }
            }
        }
        
        response = await server_instance.handle_request(request)
        
        assert response["jsonrpc"] == "2.0"
        assert response["id"] == 3
        assert "result" in response
        assert response["result"]["isError"] is False
        
        # Check content
        content = response["result"]["content"]
        assert len(content) > 0
        assert content[0]["type"] == "text"
        assert content[0]["text"] == "8"
    
    @pytest.mark.asyncio
    async def test_tool_call_with_invalid_tool(self, server_instance):
        """Test calling non-existent tool."""
        await server_instance.handle_request({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "test", "version": "1.0"}
            }
        })
        
        request = {
            "jsonrpc": "2.0",
            "id": 2,
            "method": "tools/call",
            "params": {
                "name": "nonexistent_tool",
                "arguments": {}
            }
        }
        
        response = await server_instance.handle_request(request)
        
        # Should return error
        assert "error" in response or response["result"]["isError"] is True
    
    @pytest.mark.asyncio
    async def test_resources_list(self, server_instance):
        """Test listing resources."""
        await server_instance.handle_request({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "test", "version": "1.0"}
            }
        })
        
        request = {
            "jsonrpc": "2.0",
            "id": 2,
            "method": "resources/list"
        }
        
        response = await server_instance.handle_request(request)
        
        assert "result" in response
        assert "resources" in response["result"]


class TestToolInteractions:
    """Test interactions between multiple tools."""
    
    @pytest.fixture
    async def initialized_server(self):
        """Create initialized server."""
        from src.server import create_server
        server = await create_server()
        
        await server.handle_request({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "test", "version": "1.0"}
            }
        })
        
        return server
    
    @pytest.mark.asyncio
    async def test_chained_calculations(self, initialized_server):
        """Test multiple calculations in sequence."""
        server = initialized_server
        
        # First: 5 + 3 = 8
        result1 = await server.handle_request({
            "jsonrpc": "2.0",
            "id": 10,
            "method": "tools/call",
            "params": {
                "name": "add",
                "arguments": {"a": 5, "b": 3}
            }
        })
        
        value1 = int(result1["result"]["content"][0]["text"])
        assert value1 == 8
        
        # Second: 8 * 2 = 16
        result2 = await server.handle_request({
            "jsonrpc": "2.0",
            "id": 11,
            "method": "tools/call",
            "params": {
                "name": "multiply",
                "arguments": {"a": value1, "b": 2}
            }
        })
        
        value2 = int(result2["result"]["content"][0]["text"])
        assert value2 == 16
    
    @pytest.mark.asyncio
    async def test_write_then_read(self, initialized_server, tmp_path):
        """Test writing a file then reading it back."""
        server = initialized_server
        
        test_file = tmp_path / "test.txt"
        test_content = "Hello, MCP!"
        
        # Write file
        write_result = await server.handle_request({
            "jsonrpc": "2.0",
            "id": 20,
            "method": "tools/call",
            "params": {
                "name": "write_file",
                "arguments": {
                    "path": str(test_file),
                    "content": test_content
                }
            }
        })
        
        assert write_result["result"]["isError"] is False
        
        # Read file back
        read_result = await server.handle_request({
            "jsonrpc": "2.0",
            "id": 21,
            "method": "tools/call",
            "params": {
                "name": "read_file",
                "arguments": {
                    "path": str(test_file)
                }
            }
        })
        
        assert read_result["result"]["isError"] is False
        assert test_content in read_result["result"]["content"][0]["text"]
```

---

## Testing Resources

**tests/integration/test_resources.py:**
```python
"""Tests for MCP resource operations."""

import pytest
import json


class TestResourceOperations:
    """Test resource reading and listing."""
    
    @pytest.fixture
    async def server_with_resources(self, temp_config_file):
        """Create server with test resources."""
        from src.server import create_server
        server = await create_server(config_path=str(temp_config_file))
        
        await server.handle_request({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "test", "version": "1.0"}
            }
        })
        
        return server
    
    @pytest.mark.asyncio
    async def test_read_config_resource(self, server_with_resources):
        """Test reading a configuration resource."""
        server = server_with_resources
        
        response = await server.handle_request({
            "jsonrpc": "2.0",
            "id": 5,
            "method": "resources/read",
            "params": {
                "uri": "config://settings"
            }
        })
        
        assert "result" in response
        assert "contents" in response["result"]
        
        contents = response["result"]["contents"]
        assert len(contents) > 0
        
        # Parse the JSON content
        config_data = json.loads(contents[0]["text"])
        assert config_data["debug"] is True
        assert config_data["port"] == 8080
    
    @pytest.mark.asyncio
    async def test_read_nonexistent_resource(self, server_with_resources):
        """Test reading a resource that doesn't exist."""
        server = server_with_resources
        
        response = await server.handle_request({
            "jsonrpc": "2.0",
            "id": 6,
            "method": "resources/read",
            "params": {
                "uri": "config://nonexistent"
            }
        })
        
        # Should return an error
        assert "error" in response or (
            "result" in response and 
            response["result"].get("contents", []) == []
        )
    
    @pytest.mark.asyncio
    async def test_list_file_resources(self, server_with_resources, temp_data_directory):
        """Test listing file resources from a directory."""
        server = server_with_resources
        
        response = await server.handle_request({
            "jsonrpc": "2.0",
            "id": 7,
            "method": "resources/list"
        })
        
        assert "result" in response
        resources = response["result"]["resources"]
        assert isinstance(resources, list)


class TestResourceSubscriptions:
    """Test resource subscription functionality."""
    
    @pytest.fixture
    async def server_with_subscriptions(self):
        """Create server that supports subscriptions."""
        from src.server import create_server
        server = await create_server()
        
        init_response = await server.handle_request({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {"roots": {"listChanged": True}},
                "clientInfo": {"name": "test", "version": "1.0"}
            }
        })
        
        # Check if server supports subscriptions
        capabilities = init_response["result"]["capabilities"]
        supports_subscribe = capabilities.get("resources", {}).get("subscribe", False)
        
        return server, supports_subscribe
    
    @pytest.mark.asyncio
    async def test_subscribe_to_resource(self, server_with_subscriptions):
        """Test subscribing to resource updates."""
        server, supports_subscribe = server_with_subscriptions
        
        if not supports_subscribe:
            pytest.skip("Server doesn't support subscriptions")
        
        response = await server.handle_request({
            "jsonrpc": "2.0",
            "id": 10,
            "method": "resources/subscribe",
            "params": {
                "uri": "config://settings"
            }
        })
        
        assert "result" in response
```

---

## End-to-End Testing

**tests/e2e/test_full_session.py:**
```python
"""End-to-end tests for complete MCP sessions."""

import pytest
import asyncio
import subprocess
import sys
from pathlib import Path


class TestFullMCPSession:
    """Test complete MCP server sessions."""
    
    @pytest.fixture
    async def live_server(self):
        """Start a real MCP server process."""
        server_path = Path(__file__).parent.parent.parent / "src" / "server.py"
        
        process = await asyncio.create_subprocess_exec(
            sys.executable, str(server_path),
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        
        yield process
        
        # Cleanup
        process.terminate()
        await process.wait()
    
    @pytest.mark.asyncio
    @pytest.mark.e2e
    async def test_complete_calculator_session(self, live_server):
        """Test a complete calculation session."""
        import json
        
        async def send_request(request: dict) -> dict:
            """Send JSON-RPC request and get response."""
            request_str = json.dumps(request) + "\n"
            live_server.stdin.write(request_str.encode())
            await live_server.stdin.drain()
            
            response_line = await live_server.stdout.readline()
            return json.loads(response_line.decode())
        
        # Initialize
        init_response = await send_request({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "e2e-test", "version": "1.0"}
            }
        })
        
        assert "result" in init_response
        assert init_response["result"]["serverInfo"]["name"] is not None
        
        # Send initialized notification
        await send_request({
            "jsonrpc": "2.0",
            "method": "notifications/initialized"
        })
        
        # List tools
        tools_response = await send_request({
            "jsonrpc": "2.0",
            "id": 2,
            "method": "tools/list"
        })
        
        tools = tools_response["result"]["tools"]
        tool_names = [t["name"] for t in tools]
        assert "add" in tool_names
        
        # Call add tool
        add_response = await send_request({
            "jsonrpc": "2.0",
            "id": 3,
            "method": "tools/call",
            "params": {
                "name": "add",
                "arguments": {"a": 100, "b": 200}
            }
        })
        
        result = add_response["result"]["content"][0]["text"]
        assert result == "300"
    
    @pytest.mark.asyncio
    @pytest.mark.e2e
    @pytest.mark.slow
    async def test_multiple_concurrent_requests(self, live_server):
        """Test handling multiple concurrent tool calls."""
        import json
        
        request_id = 100
        responses = []
        
        # Send multiple requests concurrently
        calculations = [
            (1, 2),
            (10, 20),
            (100, 200),
            (1000, 2000),
            (5, 5),
        ]
        
        async def send_and_receive(a: int, b: int, req_id: int):
            request = {
                "jsonrpc": "2.0",
                "id": req_id,
                "method": "tools/call",
                "params": {
                    "name": "add",
                    "arguments": {"a": a, "b": b}
                }
            }
            
            request_str = json.dumps(request) + "\n"
            live_server.stdin.write(request_str.encode())
            await live_server.stdin.drain()
            
            response_line = await live_server.stdout.readline()
            return json.loads(response_line.decode())
        
        # First initialize
        init_request = json.dumps({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "test", "version": "1.0"}
            }
        }) + "\n"
        
        live_server.stdin.write(init_request.encode())
        await live_server.stdin.drain()
        await live_server.stdout.readline()  # Consume init response
        
        # Send calculations
        tasks = []
        for i, (a, b) in enumerate(calculations):
            tasks.append(send_and_receive(a, b, request_id + i))
        
        responses = await asyncio.gather(*tasks)
        
        # Verify all responses
        for i, (a, b) in enumerate(calculations):
            response = responses[i]
            expected = str(a + b)
            actual = response["result"]["content"][0]["text"]
            assert actual == expected, f"Expected {expected}, got {actual}"


class TestErrorRecovery:
    """Test error handling and recovery."""
    
    @pytest.fixture
    async def server(self):
        """Create test server."""
        from src.server import create_server
        return await create_server()
    
    @pytest.mark.asyncio
    @pytest.mark.e2e
    async def test_server_recovers_from_tool_error(self, server):
        """Test that server continues working after tool error."""
        # Initialize
        await server.handle_request({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "test", "version": "1.0"}
            }
        })
        
        # Cause an error (divide by zero)
        error_response = await server.handle_request({
            "jsonrpc": "2.0",
            "id": 2,
            "method": "tools/call",
            "params": {
                "name": "divide",
                "arguments": {"a": 10, "b": 0}
            }
        })
        
        # Verify error was returned
        assert (
            "error" in error_response or 
            error_response.get("result", {}).get("isError", False)
        )
        
        # Server should still work for subsequent requests
        success_response = await server.handle_request({
            "jsonrpc": "2.0",
            "id": 3,
            "method": "tools/call",
            "params": {
                "name": "add",
                "arguments": {"a": 5, "b": 3}
            }
        })
        
        assert success_response["result"]["isError"] is False
        assert success_response["result"]["content"][0]["text"] == "8"
```

---

## Test Utilities

**tests/utils.py:**
```python
"""Test utilities and helpers."""

import json
from typing import Any, Dict, List, Optional


def create_json_rpc_request(
    method: str,
    params: Optional[Dict[str, Any]] = None,
    request_id: int = 1
) -> Dict[str, Any]:
    """Create a JSON-RPC 2.0 request."""
    request = {
        "jsonrpc": "2.0",
        "id": request_id,
        "method": method,
    }
    if params:
        request["params"] = params
    return request


def create_initialize_request(
    client_name: str = "test-client",
    client_version: str = "1.0.0",
    request_id: int = 1
) -> Dict[str, Any]:
    """Create an initialize request."""
    return create_json_rpc_request(
        method="initialize",
        params={
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": {
                "name": client_name,
                "version": client_version
            }
        },
        request_id=request_id
    )


def create_tool_call_request(
    tool_name: str,
    arguments: Dict[str, Any],
    request_id: int = 1
) -> Dict[str, Any]:
    """Create a tool call request."""
    return create_json_rpc_request(
        method="tools/call",
        params={
            "name": tool_name,
            "arguments": arguments
        },
        request_id=request_id
    )


def assert_successful_response(response: Dict[str, Any]) -> None:
    """Assert that a response is successful."""
    assert "error" not in response, f"Unexpected error: {response.get('error')}"
    assert "result" in response, "Response missing 'result'"


def assert_tool_result(
    response: Dict[str, Any],
    expected_text: Optional[str] = None,
    is_error: bool = False
) -> None:
    """Assert tool call result."""
    assert_successful_response(response)
    
    result = response["result"]
    assert result.get("isError", False) == is_error
    
    if expected_text is not None:
        content = result["content"]
        assert len(content) > 0
        assert content[0]["text"] == expected_text


def extract_tool_text(response: Dict[str, Any]) -> str:
    """Extract text content from tool response."""
    return response["result"]["content"][0]["text"]
```

---

## Running Tests

### Basic Commands

```bash
# Run all tests
pytest

# Run with verbose output
pytest -v

# Run specific test file
pytest tests/unit/test_calculator.py

# Run specific test class
pytest tests/unit/test_calculator.py::TestCalculatorAdd

# Run specific test
pytest tests/unit/test_calculator.py::TestCalculatorAdd::test_add_positive_numbers

# Run tests matching a pattern
pytest -k "add or multiply"

# Run only unit tests
pytest -m unit

# Run integration tests
pytest -m integration

# Run with coverage
pytest --cov=src --cov-report=html

# Run in parallel (requires pytest-xdist)
pytest -n auto
```

### CI/CD Configuration

**GitHub Actions (.github/workflows/test.yml):**
```yaml
name: MCP Server Tests

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: ['3.10', '3.11', '3.12']
    
    steps:
      - uses: actions/checkout@v4
      
      - name: Set up Python ${{ matrix.python-version }}
        uses: actions/setup-python@v5
        with:
          python-version: ${{ matrix.python-version }}
      
      - name: Install dependencies
        run: |
          python -m pip install --upgrade pip
          pip install -r requirements.txt
          pip install -r requirements-test.txt
      
      - name: Run unit tests
        run: pytest tests/unit -v --cov=src
      
      - name: Run integration tests
        run: pytest tests/integration -v
      
      - name: Run e2e tests
        run: pytest tests/e2e -v -m "e2e and not slow"
      
      - name: Upload coverage
        uses: codecov/codecov-action@v3
        with:
          files: ./coverage.xml
```

---

## Summary

| Test Type | Purpose | Speed | Dependencies |
|-----------|---------|-------|--------------|
| **Unit** | Test functions in isolation | Fast (ms) | Mocked |
| **Integration** | Test component interactions | Medium (s) | Test doubles |
| **E2E** | Test complete workflows | Slow (min) | Real/staging |

### Key Practices

1. **Use fixtures** for setup/teardown
2. **Mock external services** in unit tests
3. **Use parametrized tests** for coverage
4. **Run fast tests frequently**, slow tests before merge
5. **Maintain 80%+ code coverage**

---

## Next Steps

- **[Debugging Tips](_05_debugging_tips.md)** - Troubleshooting guide
- **[Hands-on Lab](_06_testing_hands_on.ipynb)** - Practice exercises
