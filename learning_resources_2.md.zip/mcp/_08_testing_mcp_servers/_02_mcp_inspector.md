# Module 8.2: MCP Inspector - Interactive Testing Tool

## Introduction

MCP Inspector is the official interactive debugging tool for Model Context Protocol servers. It provides a visual interface to connect to MCP servers, test tools, inspect resources, and debug issues in real-time.

---

## What is MCP Inspector?

MCP Inspector is a browser-based debugging tool that:

- **Connects** to any MCP server (stdio, HTTP/SSE)
- **Lists** available tools, resources, and prompts
- **Executes** tools with custom arguments
- **Reads** resources and views their content
- **Shows** real-time logs and messages
- **Validates** MCP protocol compliance

```
+------------------------------------------------------------------+
|                         MCP Inspector                             |
|                                                                    |
|  "The Chrome DevTools for MCP Servers"                            |
|                                                                    |
|  +-------------+  +-------------+  +-------------+  +------------+|
|  |   Tools     |  | Resources   |  |  Prompts    |  |   Logs     ||
|  |   Panel     |  |   Panel     |  |   Panel     |  |   Panel    ||
|  +-------------+  +-------------+  +-------------+  +------------+|
|                                                                    |
+------------------------------------------------------------------+
```

---

## Installation and Setup

### Prerequisites

- Node.js 18 or later
- npm or npx
- An MCP server to test

### Quick Start (npx - Recommended)

```bash
# Run directly without installation
npx @modelcontextprotocol/inspector
```

This command:
1. Downloads the latest MCP Inspector
2. Starts a local web server
3. Opens your browser to the Inspector UI

### Global Installation (Optional)

```bash
# Install globally
npm install -g @modelcontextprotocol/inspector

# Run the inspector
mcp-inspector
```

### Starting with a Specific Server

```bash
# Connect to a Python MCP server
npx @modelcontextprotocol/inspector python server.py

# Connect to a Node.js MCP server
npx @modelcontextprotocol/inspector node server.js

# Connect with environment variables
DATABASE_URL="postgres://..." npx @modelcontextprotocol/inspector python server.py

# Connect with custom arguments
npx @modelcontextprotocol/inspector python server.py --port 8080 --debug
```

---

## User Interface Overview

When MCP Inspector launches, you'll see a web interface:

```
+------------------------------------------------------------------+
|  MCP Inspector                                           [v1.0.0] |
+------------------------------------------------------------------+
|                                                                    |
|  Connection                                                        |
|  +--------------------------------------------------------------+ |
|  | Transport: [stdio v]                                          | |
|  | Command:   [python server.py                               ]  | |
|  | Args:      [--debug                                        ]  | |
|  |                                                               | |
|  | [Connect]  [Disconnect]                          Status: Idle | |
|  +--------------------------------------------------------------+ |
|                                                                    |
|  +------------------+------------------------------------------+  |
|  |                  |                                          |  |
|  |  Navigation      |  Main Content Area                       |  |
|  |  +-----------+   |                                          |  |
|  |  | Tools     |   |  Select a category from the left         |  |
|  |  +-----------+   |  to view available items.                |  |
|  |  | Resources |   |                                          |  |
|  |  +-----------+   |                                          |  |
|  |  | Prompts   |   |                                          |  |
|  |  +-----------+   |                                          |  |
|  |  | Logs      |   |                                          |  |
|  |  +-----------+   |                                          |  |
|  |                  |                                          |  |
|  +------------------+------------------------------------------+  |
|                                                                    |
+------------------------------------------------------------------+
```

---

## Connecting to Servers

### Method 1: stdio Transport (Most Common)

For servers that communicate via standard input/output:

```
+--------------------------------------------------------------+
| Transport: [stdio v]                                          |
| Command:   [python                                         ]  |
| Args:      [server.py                                      ]  |
|                                                               |
| Environment Variables (optional):                             |
| +----------------------------------------------------------+ |
| | DATABASE_URL = postgres://localhost:5432/mydb            | |
| | API_KEY = sk-xxx...                                      | |
| +----------------------------------------------------------+ |
|                                                               |
| [Connect]                                                     |
+--------------------------------------------------------------+
```

**Example Commands:**

| Server Type | Command | Args |
|-------------|---------|------|
| Python | `python` | `server.py` |
| Python (uv) | `uv` | `run server.py` |
| Node.js | `node` | `server.js` |
| TypeScript | `npx` | `ts-node server.ts` |
| Executable | `./my-server` | `--config config.json` |

### Method 2: HTTP/SSE Transport

For servers exposing an HTTP endpoint:

```
+--------------------------------------------------------------+
| Transport: [SSE v]                                            |
| URL:       [http://localhost:8080/mcp                      ]  |
| Headers (optional):                                           |
| +----------------------------------------------------------+ |
| | Authorization: Bearer token123                           | |
| +----------------------------------------------------------+ |
|                                                               |
| [Connect]                                                     |
+--------------------------------------------------------------+
```

### Connection States

```
Idle        -->  Connecting  -->  Connected  -->  Ready
  |                 |                 |              |
  |              Error            Timeout     Disconnected
  |                 |                 |              |
  +--------<--------+---------<-------+------<-------+
```

---

## Testing Tools

### Viewing Available Tools

After connecting, click "Tools" in the navigation:

```
+------------------------------------------------------------------+
|  Tools (5 available)                                              |
+------------------------------------------------------------------+
|                                                                    |
|  +------------------------+  +----------------------------------+ |
|  | Tool List              |  | Tool Details                     | |
|  |                        |  |                                  | |
|  | > add                  |  | Name: add                        | |
|  |   multiply             |  | Description: Add two numbers     | |
|  |   divide               |  |                                  | |
|  |   read_file            |  | Input Schema:                    | |
|  |   write_file           |  | {                                | |
|  |                        |  |   "type": "object",              | |
|  |                        |  |   "properties": {                | |
|  |                        |  |     "a": {"type": "number"},     | |
|  |                        |  |     "b": {"type": "number"}      | |
|  |                        |  |   },                             | |
|  |                        |  |   "required": ["a", "b"]         | |
|  |                        |  | }                                | |
|  |                        |  |                                  | |
|  +------------------------+  +----------------------------------+ |
|                                                                    |
+------------------------------------------------------------------+
```

### Executing a Tool

1. Select a tool from the list
2. Fill in the required arguments
3. Click "Execute"
4. View the result

```
+------------------------------------------------------------------+
|  Execute Tool: add                                                |
+------------------------------------------------------------------+
|                                                                    |
|  Arguments:                                                        |
|  +--------------------------------------------------------------+ |
|  | {                                                             | |
|  |   "a": 5,                                                     | |
|  |   "b": 3                                                      | |
|  | }                                                             | |
|  +--------------------------------------------------------------+ |
|                                                                    |
|  [Execute]  [Clear]                                               |
|                                                                    |
|  Result:                                                          |
|  +--------------------------------------------------------------+ |
|  | {                                                             | |
|  |   "content": [                                                | |
|  |     {                                                         | |
|  |       "type": "text",                                         | |
|  |       "text": "8"                                             | |
|  |     }                                                         | |
|  |   ],                                                          | |
|  |   "isError": false                                            | |
|  | }                                                             | |
|  +--------------------------------------------------------------+ |
|                                                                    |
|  Execution Time: 12ms                                             |
|                                                                    |
+------------------------------------------------------------------+
```

### Testing Error Cases

Test how your server handles invalid inputs:

```
+------------------------------------------------------------------+
|  Execute Tool: divide                                             |
+------------------------------------------------------------------+
|                                                                    |
|  Arguments:                                                        |
|  +--------------------------------------------------------------+ |
|  | {                                                             | |
|  |   "numerator": 10,                                            | |
|  |   "denominator": 0                                            | |
|  | }                                                             | |
|  +--------------------------------------------------------------+ |
|                                                                    |
|  [Execute]                                                        |
|                                                                    |
|  Result: ERROR                                                    |
|  +--------------------------------------------------------------+ |
|  | {                                                             | |
|  |   "content": [                                                | |
|  |     {                                                         | |
|  |       "type": "text",                                         | |
|  |       "text": "Error: Division by zero is not allowed"       | |
|  |     }                                                         | |
|  |   ],                                                          | |
|  |   "isError": true                                             | |
|  | }                                                             | |
|  +--------------------------------------------------------------+ |
|                                                                    |
+------------------------------------------------------------------+
```

---

## Testing Resources

### Viewing Available Resources

Click "Resources" to see what data sources your server exposes:

```
+------------------------------------------------------------------+
|  Resources                                                        |
+------------------------------------------------------------------+
|                                                                    |
|  +------------------------+  +----------------------------------+ |
|  | Resource Templates     |  | Resource Details                 | |
|  |                        |  |                                  | |
|  | > file:///{path}       |  | URI Template: file:///{path}     | |
|  |   db://tables/{name}   |  | Name: File System                | |
|  |   config://settings    |  | Description: Read local files    | |
|  |                        |  |                                  | |
|  | Static Resources       |  | MIME Types: text/*, application/*|
|  |                        |  |                                  | |
|  | > config://settings    |  |                                  | |
|  |                        |  |                                  | |
|  +------------------------+  +----------------------------------+ |
|                                                                    |
+------------------------------------------------------------------+
```

### Reading a Resource

```
+------------------------------------------------------------------+
|  Read Resource                                                    |
+------------------------------------------------------------------+
|                                                                    |
|  URI: [file:///home/user/config.json                          ]  |
|                                                                    |
|  [Read]                                                           |
|                                                                    |
|  Content:                                                         |
|  +--------------------------------------------------------------+ |
|  | MIME Type: application/json                                   | |
|  |                                                               | |
|  | {                                                             | |
|  |   "database": {                                               | |
|  |     "host": "localhost",                                      | |
|  |     "port": 5432,                                             | |
|  |     "name": "myapp"                                           | |
|  |   },                                                          | |
|  |   "cache": {                                                  | |
|  |     "enabled": true,                                          | |
|  |     "ttl": 3600                                               | |
|  |   }                                                           | |
|  | }                                                             | |
|  +--------------------------------------------------------------+ |
|                                                                    |
+------------------------------------------------------------------+
```

### Listing Resources

For resource templates, you can list available instances:

```
+------------------------------------------------------------------+
|  List Resources: db://tables/{name}                               |
+------------------------------------------------------------------+
|                                                                    |
|  [List All]                                                       |
|                                                                    |
|  Available Resources:                                             |
|  +--------------------------------------------------------------+ |
|  | > db://tables/users                                           | |
|  |   db://tables/products                                        | |
|  |   db://tables/orders                                          | |
|  |   db://tables/inventory                                       | |
|  +--------------------------------------------------------------+ |
|                                                                    |
|  Click a resource to read its contents                            |
|                                                                    |
+------------------------------------------------------------------+
```

---

## Testing Prompts

### Viewing Available Prompts

```
+------------------------------------------------------------------+
|  Prompts (3 available)                                            |
+------------------------------------------------------------------+
|                                                                    |
|  +------------------------+  +----------------------------------+ |
|  | Prompt List            |  | Prompt Details                   | |
|  |                        |  |                                  | |
|  | > greeting             |  | Name: greeting                   | |
|  |   code_review          |  | Description: Generate greeting   | |
|  |   summarize            |  |                                  | |
|  |                        |  | Arguments:                       | |
|  |                        |  | - name (string, required)        | |
|  |                        |  | - language (string, optional)    | |
|  |                        |  |                                  | |
|  +------------------------+  +----------------------------------+ |
|                                                                    |
+------------------------------------------------------------------+
```

### Executing a Prompt

```
+------------------------------------------------------------------+
|  Execute Prompt: greeting                                         |
+------------------------------------------------------------------+
|                                                                    |
|  Arguments:                                                        |
|  +--------------------------------------------------------------+ |
|  | name:     [Alice                                           ]  | |
|  | language: [Spanish                                         ]  | |
|  +--------------------------------------------------------------+ |
|                                                                    |
|  [Get Prompt]                                                     |
|                                                                    |
|  Generated Messages:                                              |
|  +--------------------------------------------------------------+ |
|  | [                                                             | |
|  |   {                                                           | |
|  |     "role": "user",                                           | |
|  |     "content": {                                              | |
|  |       "type": "text",                                         | |
|  |       "text": "Please greet Alice in Spanish with a warm,   | |
|  |                friendly tone."                                | |
|  |     }                                                         | |
|  |   }                                                           | |
|  | ]                                                             | |
|  +--------------------------------------------------------------+ |
|                                                                    |
+------------------------------------------------------------------+
```

---

## Interactive Debugging

### Real-Time Logs

The Logs panel shows all MCP protocol messages:

```
+------------------------------------------------------------------+
|  Logs                                              [Clear] [Save] |
+------------------------------------------------------------------+
|                                                                    |
|  Filter: [All v]  [Tools] [Resources] [Prompts] [Errors]          |
|                                                                    |
|  +--------------------------------------------------------------+ |
|  | 10:23:45 [INFO]  Connected to server                          | |
|  | 10:23:45 [SEND]  --> initialize                               | |
|  |          {"jsonrpc":"2.0","id":1,"method":"initialize"...}    | |
|  | 10:23:45 [RECV]  <-- initialize (OK)                          | |
|  |          {"jsonrpc":"2.0","id":1,"result":{"capabilities"...} | |
|  | 10:23:46 [SEND]  --> tools/list                               | |
|  | 10:23:46 [RECV]  <-- tools/list (OK)                          | |
|  | 10:24:01 [SEND]  --> tools/call (add)                         | |
|  |          {"jsonrpc":"2.0","id":3,"method":"tools/call"...}    | |
|  | 10:24:01 [RECV]  <-- tools/call (OK)                          | |
|  |          {"jsonrpc":"2.0","id":3,"result":{"content":[...]}}  | |
|  | 10:24:15 [SEND]  --> tools/call (divide)                      | |
|  | 10:24:15 [RECV]  <-- tools/call (ERROR)                       | |
|  |          {"jsonrpc":"2.0","id":4,"error":{"code":-32000...}   | |
|  +--------------------------------------------------------------+ |
|                                                                    |
+------------------------------------------------------------------+
```

### Filtering Logs

- **All**: Show all messages
- **Tools**: Only tool-related messages
- **Resources**: Only resource operations
- **Prompts**: Only prompt operations
- **Errors**: Only error messages

### Exporting Logs

Click "Save" to export logs as JSON for:
- Bug reports
- Documentation
- Test case creation
- Debugging sessions

---

## Step-by-Step Usage Guide

### Scenario: Testing a Calculator MCP Server

#### Step 1: Start the Inspector

```bash
# Navigate to your server directory
cd ~/projects/mcp-calculator

# Start inspector with your server
npx @modelcontextprotocol/inspector python server.py
```

#### Step 2: Connect to the Server

1. Inspector opens in your browser
2. Transport should show "stdio"
3. Command should show your server command
4. Click "Connect"

```
Expected: Status changes from "Idle" to "Connected" to "Ready"
```

#### Step 3: Verify Initialization

Check the Logs panel:

```
[SEND] --> initialize
[RECV] <-- initialize (OK)
       capabilities: { tools: { listChanged: true } }
```

#### Step 4: List Available Tools

1. Click "Tools" in navigation
2. View the list of tools

```
Expected tools:
- add (Add two numbers)
- subtract (Subtract two numbers)
- multiply (Multiply two numbers)
- divide (Divide two numbers)
```

#### Step 5: Test a Tool

1. Click on "add" tool
2. Enter arguments:
   ```json
   {
     "a": 10,
     "b": 5
   }
   ```
3. Click "Execute"
4. Verify result shows "15"

#### Step 6: Test Error Handling

1. Click on "divide" tool
2. Enter arguments:
   ```json
   {
     "numerator": 10,
     "denominator": 0
   }
   ```
3. Click "Execute"
4. Verify error message is returned

#### Step 7: Check Logs

Review the complete interaction in Logs:

```
[SEND] --> tools/call {"name":"add","arguments":{"a":10,"b":5}}
[RECV] <-- tools/call {"content":[{"type":"text","text":"15"}]}

[SEND] --> tools/call {"name":"divide","arguments":{"numerator":10,"denominator":0}}
[RECV] <-- tools/call {"isError":true,"content":[...]}
```

#### Step 8: Disconnect

1. Click "Disconnect" button
2. Verify clean shutdown in logs

---

## Common Testing Scenarios

### Testing Input Validation

```
Test: Missing required parameter
Input: {"a": 5}  (missing "b")
Expected: Error response with validation message
```

### Testing Type Coercion

```
Test: String instead of number
Input: {"a": "5", "b": "3"}
Expected: Either works (coerced) or clear type error
```

### Testing Large Inputs

```
Test: Very large numbers
Input: {"a": 99999999999999, "b": 1}
Expected: Correct result or handled overflow
```

### Testing Special Characters

```
Test: File path with spaces
Input: {"path": "/path/to/my file.txt"}
Expected: Properly handled
```

---

## Troubleshooting

### Inspector Won't Start

```bash
# Clear npm cache
npm cache clean --force

# Try with specific Node version
npx --node 18 @modelcontextprotocol/inspector
```

### Can't Connect to Server

1. **Check server starts independently:**
   ```bash
   python server.py
   # Should output to stderr, waiting for input
   ```

2. **Verify dependencies:**
   ```bash
   pip install mcp
   ```

3. **Check for port conflicts:**
   ```bash
   lsof -i :3000  # Default inspector port
   ```

### Connection Drops

- Check server logs for errors
- Verify server doesn't exit after idle period
- Check for unhandled exceptions

### Tools Not Showing

1. Verify server implements `tools/list`
2. Check initialization response includes tools capability
3. Look for errors in Logs panel

---

## Best Practices

### During Development

1. **Keep Inspector open** while coding
2. **Test incrementally** after each change
3. **Check logs** for protocol issues
4. **Save interesting sessions** for reference

### For Debugging

1. **Filter logs** to relevant category
2. **Compare** working vs failing requests
3. **Export logs** for complex issues
4. **Test edge cases** systematically

### For Documentation

1. **Screenshot** tool interfaces
2. **Export** sample request/response pairs
3. **Document** error scenarios
4. **Create** testing checklists

---

## Summary

MCP Inspector is essential for:

| Task | How Inspector Helps |
|------|---------------------|
| **Development** | Instant feedback on changes |
| **Debugging** | Visual protocol inspection |
| **Testing** | Interactive tool execution |
| **Documentation** | Generate examples |
| **Learning** | Understand MCP protocol |

---

## Next Steps

- **[Testing with Postman](_03_testing_with_postman.md)** - HTTP/SSE testing
- **[Programmatic Testing](_04_programmatic_testing.md)** - Automated tests
- **[Debugging Tips](_05_debugging_tips.md)** - Common issues
