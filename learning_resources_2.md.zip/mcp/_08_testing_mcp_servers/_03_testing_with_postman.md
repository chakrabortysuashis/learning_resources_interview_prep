# Module 8.3: Testing MCP Servers with Postman

## Introduction

While MCP Inspector is great for stdio-based servers, many production MCP deployments use HTTP/SSE transport. Postman is an excellent tool for testing these HTTP-based MCP servers, allowing you to craft custom JSON-RPC requests, save test collections, and automate testing.

---

## Prerequisites

- Postman Desktop App (recommended) or Web version
- An MCP server running with HTTP/SSE transport
- Basic understanding of JSON-RPC 2.0

---

## Understanding MCP over HTTP

### Transport Architecture

```
+------------------+     HTTP POST     +------------------+
|                  | ----------------> |                  |
|  Postman Client  |                   |  MCP Server      |
|                  | <---------------- |  (HTTP/SSE)      |
|                  |     SSE Stream    |                  |
+------------------+                   +------------------+
         |                                      |
         |     JSON-RPC 2.0 Messages           |
         +--------------------------------------+
```

### Request Flow

```
Client                                    Server
   |                                         |
   |  POST /mcp (initialize)                |
   |  ---------------------------------->   |
   |                                         |
   |  200 OK (capabilities)                 |
   |  <----------------------------------   |
   |                                         |
   |  POST /mcp (tools/list)                |
   |  ---------------------------------->   |
   |                                         |
   |  200 OK (tools array)                  |
   |  <----------------------------------   |
   |                                         |
   |  POST /mcp (tools/call)                |
   |  ---------------------------------->   |
   |                                         |
   |  200 OK (result)                       |
   |  <----------------------------------   |
   |                                         |
```

---

## Setting Up Postman for MCP Testing

### Step 1: Create a New Collection

1. Open Postman
2. Click "New" > "Collection"
3. Name it "MCP Server Tests"
4. Add a description: "Test collection for MCP server endpoints"

```
+------------------------------------------------------------------+
|  Collections                                                      |
|------------------------------------------------------------------|
|  > MCP Server Tests                                               |
|    |-- Initialize                                                 |
|    |-- List Tools                                                 |
|    |-- Call Tool                                                  |
|    |-- List Resources                                             |
|    |-- Read Resource                                              |
|    |-- List Prompts                                               |
|    |-- Get Prompt                                                 |
+------------------------------------------------------------------+
```

### Step 2: Configure Collection Variables

Set up reusable variables for your collection:

```
+------------------------------------------------------------------+
|  Collection Variables                                             |
|------------------------------------------------------------------|
|  Variable       | Initial Value              | Current Value      |
|------------------------------------------------------------------|
|  base_url       | http://localhost:8080      | http://localhost...|
|  mcp_endpoint   | /mcp                       | /mcp               |
|  request_id     | 1                          | 1                  |
|  session_id     | (auto-generated)           | abc123...          |
+------------------------------------------------------------------+
```

### Step 3: Set Default Headers

Configure headers for all requests in the collection:

```
+------------------------------------------------------------------+
|  Headers (Collection Level)                                       |
|------------------------------------------------------------------|
|  Key              | Value                                         |
|------------------------------------------------------------------|
|  Content-Type     | application/json                              |
|  Accept           | application/json                              |
|  X-Session-ID     | {{session_id}}                                |
+------------------------------------------------------------------+
```

---

## Crafting MCP Requests

### JSON-RPC 2.0 Structure

Every MCP request follows this format:

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "method_name",
  "params": {
    // method-specific parameters
  }
}
```

### 1. Initialize Request

**Purpose:** Establish MCP session and exchange capabilities

**Request:**
```
POST {{base_url}}{{mcp_endpoint}}
Content-Type: application/json
```

**Body:**
```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "initialize",
  "params": {
    "protocolVersion": "2024-11-05",
    "capabilities": {
      "roots": {
        "listChanged": true
      }
    },
    "clientInfo": {
      "name": "Postman MCP Tester",
      "version": "1.0.0"
    }
  }
}
```

**Expected Response:**
```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "result": {
    "protocolVersion": "2024-11-05",
    "capabilities": {
      "tools": {
        "listChanged": true
      },
      "resources": {
        "subscribe": true,
        "listChanged": true
      },
      "prompts": {
        "listChanged": true
      }
    },
    "serverInfo": {
      "name": "My MCP Server",
      "version": "1.0.0"
    }
  }
}
```

### 2. Initialized Notification

**Purpose:** Confirm client is ready

**Body:**
```json
{
  "jsonrpc": "2.0",
  "method": "notifications/initialized"
}
```

**Note:** Notifications don't have an `id` and don't expect a response.

### 3. List Tools Request

**Purpose:** Discover available tools

**Body:**
```json
{
  "jsonrpc": "2.0",
  "id": 2,
  "method": "tools/list"
}
```

**Expected Response:**
```json
{
  "jsonrpc": "2.0",
  "id": 2,
  "result": {
    "tools": [
      {
        "name": "add",
        "description": "Add two numbers together",
        "inputSchema": {
          "type": "object",
          "properties": {
            "a": {
              "type": "number",
              "description": "First number"
            },
            "b": {
              "type": "number",
              "description": "Second number"
            }
          },
          "required": ["a", "b"]
        }
      },
      {
        "name": "read_file",
        "description": "Read contents of a file",
        "inputSchema": {
          "type": "object",
          "properties": {
            "path": {
              "type": "string",
              "description": "Path to the file"
            }
          },
          "required": ["path"]
        }
      }
    ]
  }
}
```

---

## Testing Tool Calls

### Basic Tool Call

**Request:**
```json
{
  "jsonrpc": "2.0",
  "id": 3,
  "method": "tools/call",
  "params": {
    "name": "add",
    "arguments": {
      "a": 5,
      "b": 3
    }
  }
}
```

**Expected Response:**
```json
{
  "jsonrpc": "2.0",
  "id": 3,
  "result": {
    "content": [
      {
        "type": "text",
        "text": "8"
      }
    ],
    "isError": false
  }
}
```

### Tool Call with Complex Arguments

**Request:**
```json
{
  "jsonrpc": "2.0",
  "id": 4,
  "method": "tools/call",
  "params": {
    "name": "search_database",
    "arguments": {
      "table": "users",
      "filters": {
        "status": "active",
        "role": "admin"
      },
      "limit": 10,
      "offset": 0
    }
  }
}
```

### Tool Call Returning Multiple Content Types

**Response:**
```json
{
  "jsonrpc": "2.0",
  "id": 5,
  "result": {
    "content": [
      {
        "type": "text",
        "text": "Found 3 matching records:"
      },
      {
        "type": "text",
        "text": "| ID | Name | Email |\n|---|---|---|\n| 1 | Alice | alice@example.com |"
      },
      {
        "type": "image",
        "data": "iVBORw0KGgoAAAANSUhEUgAA...",
        "mimeType": "image/png"
      }
    ]
  }
}
```

### Testing Error Responses

**Request (Invalid Tool):**
```json
{
  "jsonrpc": "2.0",
  "id": 6,
  "method": "tools/call",
  "params": {
    "name": "nonexistent_tool",
    "arguments": {}
  }
}
```

**Expected Error Response:**
```json
{
  "jsonrpc": "2.0",
  "id": 6,
  "error": {
    "code": -32601,
    "message": "Tool not found: nonexistent_tool"
  }
}
```

**Request (Missing Required Argument):**
```json
{
  "jsonrpc": "2.0",
  "id": 7,
  "method": "tools/call",
  "params": {
    "name": "add",
    "arguments": {
      "a": 5
    }
  }
}
```

**Expected Error Response:**
```json
{
  "jsonrpc": "2.0",
  "id": 7,
  "result": {
    "content": [
      {
        "type": "text",
        "text": "Missing required argument: b"
      }
    ],
    "isError": true
  }
}
```

---

## Testing Resource Operations

### List Resources

**Request:**
```json
{
  "jsonrpc": "2.0",
  "id": 8,
  "method": "resources/list"
}
```

**Response:**
```json
{
  "jsonrpc": "2.0",
  "id": 8,
  "result": {
    "resources": [
      {
        "uri": "file:///config/settings.json",
        "name": "Application Settings",
        "description": "Main configuration file",
        "mimeType": "application/json"
      },
      {
        "uri": "db://tables/users",
        "name": "Users Table",
        "description": "User database records"
      }
    ]
  }
}
```

### Read a Resource

**Request:**
```json
{
  "jsonrpc": "2.0",
  "id": 9,
  "method": "resources/read",
  "params": {
    "uri": "file:///config/settings.json"
  }
}
```

**Response:**
```json
{
  "jsonrpc": "2.0",
  "id": 9,
  "result": {
    "contents": [
      {
        "uri": "file:///config/settings.json",
        "mimeType": "application/json",
        "text": "{\n  \"database\": {\n    \"host\": \"localhost\",\n    \"port\": 5432\n  }\n}"
      }
    ]
  }
}
```

### List Resource Templates

**Request:**
```json
{
  "jsonrpc": "2.0",
  "id": 10,
  "method": "resources/templates/list"
}
```

**Response:**
```json
{
  "jsonrpc": "2.0",
  "id": 10,
  "result": {
    "resourceTemplates": [
      {
        "uriTemplate": "db://tables/{tableName}",
        "name": "Database Table",
        "description": "Read data from a database table"
      },
      {
        "uriTemplate": "file:///{path}",
        "name": "File System",
        "description": "Read files from the filesystem"
      }
    ]
  }
}
```

---

## Creating a Complete Test Collection

### Collection Structure

```
MCP Server Tests/
|
|-- Environment Setup/
|   |-- Initialize Session
|   |-- Send Initialized Notification
|
|-- Tools/
|   |-- List All Tools
|   |-- Call: add
|   |-- Call: multiply
|   |-- Call: divide
|   |-- Call: divide (error - zero)
|   |-- Call: read_file
|   |-- Call: invalid_tool (error)
|
|-- Resources/
|   |-- List Resources
|   |-- List Resource Templates
|   |-- Read: settings.json
|   |-- Read: invalid_uri (error)
|
|-- Prompts/
|   |-- List Prompts
|   |-- Get: greeting
|   |-- Get: code_review
|
|-- Cleanup/
    |-- Close Session
```

### Pre-Request Script

Add to collection for auto-incrementing request IDs:

```javascript
// Pre-request script (Collection level)
let currentId = pm.collectionVariables.get("request_id") || 1;
pm.collectionVariables.set("request_id", parseInt(currentId) + 1);

// Make it available in request body
pm.variables.set("current_request_id", currentId);
```

**Usage in request body:**
```json
{
  "jsonrpc": "2.0",
  "id": {{current_request_id}},
  "method": "tools/list"
}
```

### Test Scripts

Add automated assertions to each request:

**Initialize Test:**
```javascript
pm.test("Status code is 200", function () {
    pm.response.to.have.status(200);
});

pm.test("Response is valid JSON-RPC", function () {
    const jsonData = pm.response.json();
    pm.expect(jsonData).to.have.property("jsonrpc", "2.0");
    pm.expect(jsonData).to.have.property("id");
    pm.expect(jsonData).to.have.property("result");
});

pm.test("Server has expected capabilities", function () {
    const jsonData = pm.response.json();
    pm.expect(jsonData.result.capabilities).to.have.property("tools");
});

pm.test("Protocol version matches", function () {
    const jsonData = pm.response.json();
    pm.expect(jsonData.result.protocolVersion).to.equal("2024-11-05");
});
```

**Tools List Test:**
```javascript
pm.test("Tools array exists", function () {
    const jsonData = pm.response.json();
    pm.expect(jsonData.result.tools).to.be.an("array");
});

pm.test("At least one tool is available", function () {
    const jsonData = pm.response.json();
    pm.expect(jsonData.result.tools.length).to.be.greaterThan(0);
});

pm.test("Tools have required properties", function () {
    const jsonData = pm.response.json();
    jsonData.result.tools.forEach(tool => {
        pm.expect(tool).to.have.property("name");
        pm.expect(tool).to.have.property("inputSchema");
    });
});
```

**Tool Call Test:**
```javascript
pm.test("Tool execution successful", function () {
    const jsonData = pm.response.json();
    pm.expect(jsonData.result.isError).to.be.oneOf([false, undefined]);
});

pm.test("Result has content", function () {
    const jsonData = pm.response.json();
    pm.expect(jsonData.result.content).to.be.an("array");
    pm.expect(jsonData.result.content.length).to.be.greaterThan(0);
});

pm.test("Add operation returns correct result", function () {
    const jsonData = pm.response.json();
    const textContent = jsonData.result.content.find(c => c.type === "text");
    pm.expect(textContent.text).to.equal("8"); // 5 + 3
});
```

**Error Test:**
```javascript
pm.test("Error response has correct structure", function () {
    const jsonData = pm.response.json();
    
    // Either JSON-RPC error or isError in result
    const hasError = jsonData.error || 
                     (jsonData.result && jsonData.result.isError);
    pm.expect(hasError).to.be.true;
});

pm.test("Division by zero returns error", function () {
    const jsonData = pm.response.json();
    
    if (jsonData.result && jsonData.result.isError) {
        const errorText = jsonData.result.content[0].text.toLowerCase();
        pm.expect(errorText).to.include("zero");
    }
});
```

---

## Testing SSE (Server-Sent Events)

For servers that use SSE for streaming responses:

### Setting Up SSE Testing

Postman doesn't natively support SSE, but you can:

1. **Use Postman for initial requests**
2. **Switch to curl/httpie for SSE streams**

**curl for SSE:**
```bash
# Subscribe to SSE events
curl -N -H "Accept: text/event-stream" \
     -H "Content-Type: application/json" \
     http://localhost:8080/mcp/events
```

### Testing Streaming Tool Results

Some tools return results via SSE:

```
POST /mcp
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "tools/call",
  "params": {
    "name": "long_running_task",
    "arguments": {}
  }
}

Response Headers:
Content-Type: text/event-stream

Response Body (SSE):
data: {"type": "progress", "value": 25}

data: {"type": "progress", "value": 50}

data: {"type": "progress", "value": 75}

data: {"type": "result", "content": [{"type": "text", "text": "Complete!"}]}
```

---

## Environment Management

### Creating Environments

Set up different environments for testing:

```
+------------------------------------------------------------------+
|  Environments                                                     |
|------------------------------------------------------------------|
|  Development                                                      |
|    base_url: http://localhost:8080                               |
|    debug: true                                                    |
|                                                                    |
|  Staging                                                          |
|    base_url: https://staging.api.example.com                     |
|    debug: false                                                   |
|                                                                    |
|  Production                                                       |
|    base_url: https://api.example.com                             |
|    debug: false                                                   |
+------------------------------------------------------------------+
```

### Environment Variables

```json
{
  "id": "dev-environment",
  "name": "Development",
  "values": [
    {
      "key": "base_url",
      "value": "http://localhost:8080",
      "enabled": true
    },
    {
      "key": "mcp_endpoint",
      "value": "/mcp",
      "enabled": true
    },
    {
      "key": "auth_token",
      "value": "dev-token-123",
      "enabled": true
    }
  ]
}
```

---

## Running Collection Tests

### Manual Run

1. Right-click on collection
2. Select "Run collection"
3. Choose environment
4. Click "Run"

### Command Line (Newman)

```bash
# Install Newman
npm install -g newman

# Run collection
newman run MCP_Server_Tests.postman_collection.json \
  -e Development.postman_environment.json \
  --reporters cli,json \
  --reporter-json-export results.json

# Run with iterations
newman run MCP_Server_Tests.postman_collection.json \
  -e Development.postman_environment.json \
  --iteration-count 10
```

### CI/CD Integration

**GitHub Actions:**
```yaml
name: MCP Server Tests

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Start MCP Server
        run: |
          python server.py --http --port 8080 &
          sleep 5  # Wait for server to start
      
      - name: Install Newman
        run: npm install -g newman
      
      - name: Run Postman Tests
        run: |
          newman run tests/MCP_Server_Tests.postman_collection.json \
            -e tests/Development.postman_environment.json \
            --reporters cli,junit \
            --reporter-junit-export results.xml
      
      - name: Upload Test Results
        uses: actions/upload-artifact@v3
        with:
          name: test-results
          path: results.xml
```

---

## Best Practices

### Request Organization

1. **Group by functionality:** Tools, Resources, Prompts
2. **Include error cases:** Invalid inputs, missing params
3. **Order logically:** Initialize first, then operations
4. **Name clearly:** "Call: add (success)", "Call: divide (error - zero)"

### Test Coverage

1. **Happy paths:** All tools with valid inputs
2. **Error paths:** Invalid tools, missing args, bad data
3. **Edge cases:** Empty strings, large numbers, special chars
4. **Boundary testing:** Min/max values, null/undefined

### Documentation

1. **Add descriptions** to requests
2. **Document expected responses**
3. **Include example values**
4. **Note any prerequisites**

---

## Sample Request Collection Export

```json
{
  "info": {
    "name": "MCP Server Tests",
    "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
  },
  "item": [
    {
      "name": "Initialize",
      "request": {
        "method": "POST",
        "header": [
          {
            "key": "Content-Type",
            "value": "application/json"
          }
        ],
        "body": {
          "mode": "raw",
          "raw": "{\n  \"jsonrpc\": \"2.0\",\n  \"id\": 1,\n  \"method\": \"initialize\",\n  \"params\": {\n    \"protocolVersion\": \"2024-11-05\",\n    \"capabilities\": {},\n    \"clientInfo\": {\n      \"name\": \"Postman\",\n      \"version\": \"1.0.0\"\n    }\n  }\n}"
        },
        "url": {
          "raw": "{{base_url}}{{mcp_endpoint}}",
          "host": ["{{base_url}}{{mcp_endpoint}}"]
        }
      },
      "response": []
    },
    {
      "name": "List Tools",
      "request": {
        "method": "POST",
        "header": [
          {
            "key": "Content-Type",
            "value": "application/json"
          }
        ],
        "body": {
          "mode": "raw",
          "raw": "{\n  \"jsonrpc\": \"2.0\",\n  \"id\": 2,\n  \"method\": \"tools/list\"\n}"
        },
        "url": {
          "raw": "{{base_url}}{{mcp_endpoint}}",
          "host": ["{{base_url}}{{mcp_endpoint}}"]
        }
      },
      "response": []
    }
  ]
}
```

---

## Summary

| Postman Feature | MCP Testing Use Case |
|-----------------|---------------------|
| **Collections** | Organize all MCP tests |
| **Environments** | Switch between dev/staging/prod |
| **Variables** | Reuse request IDs, URLs |
| **Test Scripts** | Automated assertions |
| **Newman CLI** | CI/CD integration |
| **Pre-request Scripts** | Dynamic request building |

---

## Next Steps

- **[Programmatic Testing](_04_programmatic_testing.md)** - pytest and code-based tests
- **[Debugging Tips](_05_debugging_tips.md)** - Troubleshooting guide
- **[Hands-on Lab](_06_testing_hands_on.ipynb)** - Practice exercises
