# MCP Architecture Overview

[Previous: JSON-RPC Basics](_03_json_rpc_basics.md) | [Next: Getting Started](_05_getting_started.ipynb)

---

## High-Level Architecture

MCP follows a **client-server architecture** where hosts (AI applications) connect to servers (tool providers) through a standardized protocol.

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        MCP HIGH-LEVEL ARCHITECTURE                           │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   ┌───────────────────────────────────────────────────────────────────┐    │
│   │                           HOST APPLICATION                         │    │
│   │                    (Claude Desktop, IDE, Custom App)               │    │
│   │                                                                    │    │
│   │   ┌──────────────────────────────────────────────────────────┐   │    │
│   │   │                         LLM                               │   │    │
│   │   │              (Claude, GPT, Local Model)                   │   │    │
│   │   └──────────────────────────────────────────────────────────┘   │    │
│   │                              │                                    │    │
│   │                              ▼                                    │    │
│   │   ┌──────────────────────────────────────────────────────────┐   │    │
│   │   │                    MCP CLIENT                             │   │    │
│   │   │           (Manages server connections)                    │   │    │
│   │   └──────────────────────────────────────────────────────────┘   │    │
│   │                              │                                    │    │
│   └──────────────────────────────┼────────────────────────────────────┘    │
│                                  │                                          │
│                    MCP Protocol (JSON-RPC 2.0)                              │
│                                  │                                          │
│         ┌────────────────────────┼────────────────────────┐                │
│         │                        │                        │                │
│         ▼                        ▼                        ▼                │
│   ┌───────────┐           ┌───────────┐           ┌───────────┐           │
│   │MCP Server │           │MCP Server │           │MCP Server │           │
│   │(Database) │           │(Files)    │           │(API)      │           │
│   └───────────┘           └───────────┘           └───────────┘           │
│         │                        │                        │                │
│         ▼                        ▼                        ▼                │
│   ┌───────────┐           ┌───────────┐           ┌───────────┐           │
│   │ PostgreSQL│           │File System│           │ External  │           │
│   │           │           │           │           │   API     │           │
│   └───────────┘           └───────────┘           └───────────┘           │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Core Concepts

### Hosts, Clients, and Servers

| Component | Role | Examples |
|-----------|------|----------|
| **Host** | Application containing the LLM | Claude Desktop, VS Code, Custom App |
| **Client** | Protocol handler within the host | MCP SDK Client, LangChain Adapter |
| **Server** | Provides tools, resources, prompts | File server, Database server, API wrapper |

```
┌─────────────────────────────────────────────────────────────────┐
│                    Component Relationships                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   Host (1)  ────contains────▶  Client (1..N)                    │
│                                    │                            │
│                              connects to                        │
│                                    │                            │
│                                    ▼                            │
│                               Server (1..N)                     │
│                                                                 │
│   One host can have multiple clients                            │
│   Each client connects to one or more servers                   │
│   Servers are independent processes                             │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Protocol Layers

MCP separates concerns into distinct layers:

```
┌─────────────────────────────────────────────────────────────────┐
│                    MCP Protocol Stack                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   ┌─────────────────────────────────────────────────────────┐  │
│   │                 APPLICATION LAYER                        │  │
│   │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌─────────┐ │  │
│   │  │Resources │  │  Tools   │  │ Prompts  │  │Sampling │ │  │
│   │  └──────────┘  └──────────┘  └──────────┘  └─────────┘ │  │
│   │                                                         │  │
│   │  What MCP can do: expose data, execute actions,         │  │
│   │  provide templates, request LLM completions             │  │
│   └─────────────────────────────────────────────────────────┘  │
│                              │                                  │
│                              ▼                                  │
│   ┌─────────────────────────────────────────────────────────┐  │
│   │                  PROTOCOL LAYER                          │  │
│   │                                                         │  │
│   │  JSON-RPC 2.0 message format                            │  │
│   │  Request/Response correlation                           │  │
│   │  Notifications for async events                         │  │
│   │  Error handling standards                               │  │
│   └─────────────────────────────────────────────────────────┘  │
│                              │                                  │
│                              ▼                                  │
│   ┌─────────────────────────────────────────────────────────┐  │
│   │                 TRANSPORT LAYER                          │  │
│   │  ┌──────────┐  ┌──────────────┐  ┌─────────────────┐   │  │
│   │  │  stdio   │  │  HTTP + SSE  │  │    WebSocket    │   │  │
│   │  └──────────┘  └──────────────┘  └─────────────────┘   │  │
│   │                                                         │  │
│   │  How messages are delivered: local pipes, HTTP,         │  │
│   │  streaming connections                                  │  │
│   └─────────────────────────────────────────────────────────┘  │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Layer Responsibilities

| Layer | Responsibility | Components |
|-------|---------------|------------|
| **Application** | Business logic, features | Resources, Tools, Prompts, Sampling |
| **Protocol** | Message format, correlation | JSON-RPC 2.0, IDs, errors |
| **Transport** | Message delivery | stdio, HTTP/SSE, WebSocket |

---

## Key Components

### 1. Resources

**Resources** expose data to the client. They're like read endpoints that the AI can access for context.

```
┌─────────────────────────────────────────────────────────────────┐
│                         RESOURCES                                │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   URI Pattern          Example                 Description      │
│   ───────────          ───────                 ───────────      │
│   file://              file:///home/user/doc   Local files      │
│   db://                db://users/123          Database records │
│   config://            config://app/settings   Configuration    │
│   git://               git://repo/main/README  Git content      │
│                                                                 │
│   ┌─────────────┐     resources/list      ┌─────────────┐      │
│   │   Client    │ ──────────────────────▶ │   Server    │      │
│   │             │ ◀────────────────────── │             │      │
│   │             │     [uri1, uri2, ...]   │             │      │
│   │             │                         │             │      │
│   │             │     resources/read      │             │      │
│   │             │ ──────────────────────▶ │             │      │
│   │             │ ◀────────────────────── │             │      │
│   └─────────────┘     {content}           └─────────────┘      │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 2. Tools

**Tools** are functions the AI can execute. They take parameters and return results.

```
┌─────────────────────────────────────────────────────────────────┐
│                           TOOLS                                  │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   Tool Definition:                                              │
│   {                                                             │
│     "name": "send_email",                                       │
│     "description": "Send an email to a recipient",              │
│     "inputSchema": {                                            │
│       "type": "object",                                         │
│       "properties": {                                           │
│         "to": {"type": "string"},                               │
│         "subject": {"type": "string"},                          │
│         "body": {"type": "string"}                              │
│       },                                                        │
│       "required": ["to", "subject", "body"]                     │
│     }                                                           │
│   }                                                             │
│                                                                 │
│   ┌─────────────┐       tools/call        ┌─────────────┐      │
│   │   Client    │ ──────────────────────▶ │   Server    │      │
│   │             │    name: "send_email"   │             │      │
│   │             │    args: {to, subj...}  │             │      │
│   │             │                         │   Execute   │      │
│   │             │ ◀────────────────────── │   Action    │      │
│   └─────────────┘    {result/error}       └─────────────┘      │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 3. Prompts

**Prompts** are reusable templates that guide AI interactions.

```
┌─────────────────────────────────────────────────────────────────┐
│                          PROMPTS                                 │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   Prompt Definition:                                            │
│   {                                                             │
│     "name": "code_review",                                      │
│     "description": "Review code for issues",                    │
│     "arguments": [                                              │
│       {"name": "code", "required": true},                       │
│       {"name": "language", "required": false}                   │
│     ]                                                           │
│   }                                                             │
│                                                                 │
│   When called with arguments, returns structured messages:      │
│   [                                                             │
│     {"role": "user", "content": "Review this Python code:"},    │
│     {"role": "user", "content": "<the actual code>"}            │
│   ]                                                             │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 4. Sampling (Advanced)

**Sampling** allows servers to request LLM completions from the client.

```
┌─────────────────────────────────────────────────────────────────┐
│                         SAMPLING                                 │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   Normal flow: Client asks Server to do things                  │
│   Sampling:    Server asks Client for LLM help                  │
│                                                                 │
│   ┌─────────────┐    sampling/create     ┌─────────────┐       │
│   │   Client    │ ◀───────────────────── │   Server    │       │
│   │             │   "Summarize this..."  │             │       │
│   │   [LLM]     │                        │             │       │
│   │   [Human    │                        │             │       │
│   │   Approval] │                        │             │       │
│   │             │ ──────────────────────▶│             │       │
│   └─────────────┘    {completion}        └─────────────┘       │
│                                                                 │
│   ⚠️  Requires human-in-the-loop for security                   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Connection Lifecycle

```
┌─────────────────────────────────────────────────────────────────┐
│                    CONNECTION LIFECYCLE                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   Client                                          Server        │
│     │                                               │           │
│     │                                               │           │
│     │  1. INITIALIZE                                │           │
│     │──────────────────────────────────────────────▶│           │
│     │     {protocolVersion, capabilities,           │           │
│     │      clientInfo}                              │           │
│     │                                               │           │
│     │◀──────────────────────────────────────────────│           │
│     │     {protocolVersion, capabilities,           │           │
│     │      serverInfo}                              │           │
│     │                                               │           │
│     │  2. INITIALIZED (notification)                │           │
│     │──────────────────────────────────────────────▶│           │
│     │                                               │           │
│     │                                               │           │
│     │  3. NORMAL OPERATIONS                         │           │
│     │═══════════════════════════════════════════════│           │
│     │     tools/list, tools/call                    │           │
│     │     resources/list, resources/read            │           │
│     │     prompts/list, prompts/get                 │           │
│     │═══════════════════════════════════════════════│           │
│     │                                               │           │
│     │                                               │           │
│     │  4. SHUTDOWN                                  │           │
│     │◀─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─│           │
│     │     Close connection gracefully               │           │
│     │                                               │           │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Lifecycle Phases

| Phase | Description | Messages |
|-------|-------------|----------|
| **Initialize** | Exchange versions and capabilities | `initialize` request/response |
| **Initialized** | Confirm ready state | `notifications/initialized` |
| **Operations** | Normal tool/resource usage | Various requests |
| **Shutdown** | Clean disconnection | Transport close |

---

## Capability Negotiation

Clients and servers declare what they support during initialization:

### Client Capabilities

```json
{
    "capabilities": {
        "roots": {
            "listChanged": true
        },
        "sampling": {}
    }
}
```

| Capability | Description |
|------------|-------------|
| `roots` | Client can provide root URIs for the server |
| `sampling` | Client supports LLM sampling requests |

### Server Capabilities

```json
{
    "capabilities": {
        "tools": {},
        "resources": {
            "subscribe": true,
            "listChanged": true
        },
        "prompts": {
            "listChanged": true
        }
    }
}
```

| Capability | Description |
|------------|-------------|
| `tools` | Server provides callable tools |
| `resources` | Server provides readable resources |
| `prompts` | Server provides prompt templates |
| `subscribe` | Client can subscribe to resource changes |
| `listChanged` | Server will notify when lists change |

---

## Data Flow Example

Here's a complete example of an LLM using MCP to answer a question:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    DATA FLOW: "What files are in my project?"               │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  User                  Host (Claude)              MCP Server (Files)        │
│   │                        │                            │                   │
│   │  "What files are       │                            │                   │
│   │   in my project?"      │                            │                   │
│   │───────────────────────▶│                            │                   │
│   │                        │                            │                   │
│   │                        │  tools/list                │                   │
│   │                        │───────────────────────────▶│                   │
│   │                        │◀───────────────────────────│                   │
│   │                        │  [{name: "list_files"}]    │                   │
│   │                        │                            │                   │
│   │                 LLM decides to                      │                   │
│   │                 use list_files                      │                   │
│   │                        │                            │                   │
│   │                        │  tools/call                │                   │
│   │                        │  name: "list_files"        │                   │
│   │                        │  args: {path: "."}         │                   │
│   │                        │───────────────────────────▶│                   │
│   │                        │                            │  List directory   │
│   │                        │◀───────────────────────────│                   │
│   │                        │  ["main.py", "README.md"]  │                   │
│   │                        │                            │                   │
│   │                 LLM formats                         │                   │
│   │                 response                            │                   │
│   │                        │                            │                   │
│   │  "Your project has     │                            │                   │
│   │   main.py and          │                            │                   │
│   │   README.md"           │                            │                   │
│   │◀───────────────────────│                            │                   │
│   │                        │                            │                   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Summary

| Concept | Key Points |
|---------|-----------|
| **Architecture** | Host → Client → Server pattern |
| **Layers** | Application, Protocol, Transport |
| **Components** | Resources (data), Tools (actions), Prompts (templates) |
| **Lifecycle** | Initialize → Operations → Shutdown |
| **Capabilities** | Negotiated at connection time |

---

## Next Steps

Ready to write your first MCP server? Let's get hands-on:

**[Next: Getting Started (Notebook) →](_05_getting_started.ipynb)**

---

## Quick Quiz

1. What's the difference between a Host, Client, and Server in MCP?
2. Name the three protocol layers and their responsibilities.
3. Which component would you use to let an AI read a configuration file?

<details>
<summary>Answers</summary>

1. Host is the AI application (Claude Desktop), Client is the protocol handler within the host, Server provides the tools/resources
2. Application (features), Protocol (JSON-RPC format), Transport (message delivery)
3. Resources - they're for exposing readable data to the AI

</details>
