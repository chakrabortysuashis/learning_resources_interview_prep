# JSON-RPC Basics

[Previous: Why MCP is Needed](_02_why_mcp_is_needed.md) | [Next: MCP Architecture Overview](_04_mcp_architecture_overview.md)

---

## What is JSON-RPC?

**JSON-RPC** is a lightweight remote procedure call (RPC) protocol encoded in JSON. MCP uses **JSON-RPC 2.0** as its message format foundation.

```
┌─────────────────────────────────────────────────────────────────┐
│                    JSON-RPC in MCP Stack                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   ┌─────────────────────────────────────────────────────────┐  │
│   │                  Application Layer                       │  │
│   │              (MCP Tools, Resources, Prompts)             │  │
│   └─────────────────────────────────────────────────────────┘  │
│                            │                                    │
│                            ▼                                    │
│   ┌─────────────────────────────────────────────────────────┐  │
│   │                  Protocol Layer                          │  │
│   │                   JSON-RPC 2.0                           │  │  ◀── You are here
│   └─────────────────────────────────────────────────────────┘  │
│                            │                                    │
│                            ▼                                    │
│   ┌─────────────────────────────────────────────────────────┐  │
│   │                  Transport Layer                         │  │
│   │              (stdio, HTTP/SSE, WebSocket)                │  │
│   └─────────────────────────────────────────────────────────┘  │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Why JSON-RPC for MCP?

| Reason | Benefit |
|--------|---------|
| **Simple** | Easy to implement and debug |
| **Language-agnostic** | Works with any programming language |
| **Lightweight** | Minimal overhead, just JSON |
| **Bidirectional** | Supports requests from both sides |
| **Well-defined** | Clear specification, fewer edge cases |

---

## JSON-RPC 2.0 Message Types

There are three types of messages in JSON-RPC:

```
┌─────────────────────────────────────────────────────────────────┐
│                    Message Types                                 │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   1. REQUEST         2. RESPONSE         3. NOTIFICATION        │
│   ───────────        ────────────        ──────────────         │
│   Has 'id'           Has 'id'            NO 'id'                │
│   Has 'method'       Has 'result'        Has 'method'           │
│   Expects response   OR 'error'          Fire-and-forget        │
│                                                                 │
│   Client ──Request──▶ Server             Client ──Notify──▶ X   │
│   Client ◀─Response── Server             (no response)          │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Request Structure

A **request** asks the server to perform an action and expects a response.

### Format

```json
{
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/call",
    "params": {
        "name": "get_weather",
        "arguments": {
            "city": "London"
        }
    }
}
```

### Fields Explained

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `jsonrpc` | string | Yes | Must be exactly `"2.0"` |
| `id` | string/number | Yes | Unique identifier for request-response correlation |
| `method` | string | Yes | Name of the method to invoke |
| `params` | object/array | No | Parameters for the method |

### Request Examples

**Initialize connection:**
```json
{
    "jsonrpc": "2.0",
    "id": 1,
    "method": "initialize",
    "params": {
        "protocolVersion": "2024-11-05",
        "capabilities": {
            "roots": { "listChanged": true }
        },
        "clientInfo": {
            "name": "my-client",
            "version": "1.0.0"
        }
    }
}
```

**List available tools:**
```json
{
    "jsonrpc": "2.0",
    "id": 2,
    "method": "tools/list",
    "params": {}
}
```

**Call a tool:**
```json
{
    "jsonrpc": "2.0",
    "id": 3,
    "method": "tools/call",
    "params": {
        "name": "read_file",
        "arguments": {
            "path": "/home/user/document.txt"
        }
    }
}
```

---

## Response Structure

A **response** is sent after processing a request. It can be successful or contain an error.

### Success Response

```json
{
    "jsonrpc": "2.0",
    "id": 1,
    "result": {
        "protocolVersion": "2024-11-05",
        "capabilities": {
            "tools": {},
            "resources": {}
        },
        "serverInfo": {
            "name": "my-server",
            "version": "1.0.0"
        }
    }
}
```

### Error Response

```json
{
    "jsonrpc": "2.0",
    "id": 1,
    "error": {
        "code": -32600,
        "message": "Invalid Request",
        "data": "Missing required field: method"
    }
}
```

### Response Fields

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `jsonrpc` | string | Yes | Must be exactly `"2.0"` |
| `id` | string/number | Yes | Same ID as the request |
| `result` | any | If success | The result of the method call |
| `error` | object | If error | Error information |

### Error Object Structure

```json
{
    "code": -32601,
    "message": "Method not found",
    "data": "Optional additional information"
}
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `code` | number | Yes | Numeric error code |
| `message` | string | Yes | Short error description |
| `data` | any | No | Additional error details |

---

## Notification Structure

A **notification** is a request without an `id` - the sender doesn't expect a response.

### Format

```json
{
    "jsonrpc": "2.0",
    "method": "notifications/progress",
    "params": {
        "progressToken": "abc123",
        "progress": 50,
        "total": 100
    }
}
```

### When to Use Notifications

```
┌─────────────────────────────────────────────────────────────────┐
│                    Notification Use Cases                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   Server ──────────────────────────────────────▶ Client         │
│                                                                 │
│   notifications/progress    "Task is 50% complete"              │
│   notifications/message     "Log: Processing file..."          │
│   notifications/resources/  "File config.json changed"         │
│     list_changed                                                │
│                                                                 │
│   Client ──────────────────────────────────────▶ Server         │
│                                                                 │
│   notifications/initialized "Client is ready"                   │
│   notifications/cancelled   "Cancel operation abc123"           │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Notification Examples

**Progress update:**
```json
{
    "jsonrpc": "2.0",
    "method": "notifications/progress",
    "params": {
        "progressToken": "task-123",
        "progress": 75,
        "total": 100
    }
}
```

**Log message:**
```json
{
    "jsonrpc": "2.0",
    "method": "notifications/message",
    "params": {
        "level": "info",
        "logger": "file-processor",
        "data": "Processing complete"
    }
}
```

---

## Standard Error Codes

JSON-RPC 2.0 defines standard error codes:

| Code | Message | Meaning |
|------|---------|---------|
| `-32700` | Parse error | Invalid JSON |
| `-32600` | Invalid Request | Not a valid request object |
| `-32601` | Method not found | Method doesn't exist |
| `-32602` | Invalid params | Invalid method parameters |
| `-32603` | Internal error | Server internal error |
| `-32000` to `-32099` | Server error | Reserved for implementation |

### MCP-Specific Error Codes

MCP extends JSON-RPC with additional error codes:

| Code | Message | Meaning |
|------|---------|---------|
| `-32001` | Resource not found | Requested resource doesn't exist |
| `-32002` | Tool not found | Requested tool doesn't exist |
| `-32003` | Invalid tool arguments | Tool arguments don't match schema |

---

## Message Flow Examples

### Successful Tool Call

```
┌─────────────────────────────────────────────────────────────────┐
│                    Tool Call Flow                                │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   Client                                          Server        │
│     │                                               │           │
│     │  ┌─────────────────────────────────────┐     │           │
│     │  │ {                                   │     │           │
│     │──│   "jsonrpc": "2.0",                 │────▶│           │
│     │  │   "id": 5,                          │     │           │
│     │  │   "method": "tools/call",           │     │           │
│     │  │   "params": {                       │     │           │
│     │  │     "name": "add",                  │     │           │
│     │  │     "arguments": {"a": 5, "b": 3}   │     │           │
│     │  │   }                                 │     │           │
│     │  │ }                                   │     │           │
│     │  └─────────────────────────────────────┘     │           │
│     │                                               │           │
│     │                                    Process    │           │
│     │                                    5 + 3 = 8  │           │
│     │                                               │           │
│     │  ┌─────────────────────────────────────┐     │           │
│     │  │ {                                   │     │           │
│     │◀─│   "jsonrpc": "2.0",                 │─────│           │
│     │  │   "id": 5,                          │     │           │
│     │  │   "result": {                       │     │           │
│     │  │     "content": [{                   │     │           │
│     │  │       "type": "text",               │     │           │
│     │  │       "text": "8"                   │     │           │
│     │  │     }]                              │     │           │
│     │  │   }                                 │     │           │
│     │  │ }                                   │     │           │
│     │  └─────────────────────────────────────┘     │           │
│     │                                               │           │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Error Response Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                    Error Flow                                    │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   Client                                          Server        │
│     │                                               │           │
│     │  ┌─────────────────────────────────────┐     │           │
│     │  │ {                                   │     │           │
│     │──│   "jsonrpc": "2.0",                 │────▶│           │
│     │  │   "id": 6,                          │     │           │
│     │  │   "method": "tools/call",           │     │           │
│     │  │   "params": {                       │     │           │
│     │  │     "name": "unknown_tool"          │     │           │
│     │  │   }                                 │     │           │
│     │  │ }                                   │     │           │
│     │  └─────────────────────────────────────┘     │           │
│     │                                               │           │
│     │                                   Tool not    │           │
│     │                                   found!      │           │
│     │                                               │           │
│     │  ┌─────────────────────────────────────┐     │           │
│     │  │ {                                   │     │           │
│     │◀─│   "jsonrpc": "2.0",                 │─────│           │
│     │  │   "id": 6,                          │     │           │
│     │  │   "error": {                        │     │           │
│     │  │     "code": -32002,                 │     │           │
│     │  │     "message": "Tool not found",    │     │           │
│     │  │     "data": "unknown_tool"          │     │           │
│     │  │   }                                 │     │           │
│     │  │ }                                   │     │           │
│     │  └─────────────────────────────────────┘     │           │
│     │                                               │           │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Code Examples

### Python: Creating JSON-RPC Messages

```python
import json
from typing import Any, Optional
from dataclasses import dataclass, asdict

@dataclass
class JsonRpcRequest:
    method: str
    params: Optional[dict] = None
    id: Optional[int] = None
    jsonrpc: str = "2.0"
    
    def to_json(self) -> str:
        data = {"jsonrpc": self.jsonrpc, "method": self.method}
        if self.id is not None:
            data["id"] = self.id
        if self.params is not None:
            data["params"] = self.params
        return json.dumps(data)

@dataclass  
class JsonRpcResponse:
    id: int
    result: Optional[Any] = None
    error: Optional[dict] = None
    jsonrpc: str = "2.0"
    
    def to_json(self) -> str:
        data = {"jsonrpc": self.jsonrpc, "id": self.id}
        if self.error is not None:
            data["error"] = self.error
        else:
            data["result"] = self.result
        return json.dumps(data)

# Creating a request
request = JsonRpcRequest(
    method="tools/call",
    params={"name": "greet", "arguments": {"name": "Alice"}},
    id=1
)
print(request.to_json())
# {"jsonrpc": "2.0", "method": "tools/call", "params": {...}, "id": 1}

# Creating a notification (no id)
notification = JsonRpcRequest(
    method="notifications/progress",
    params={"progress": 50, "total": 100}
)
print(notification.to_json())
# {"jsonrpc": "2.0", "method": "notifications/progress", "params": {...}}

# Creating a response
response = JsonRpcResponse(id=1, result={"content": [{"type": "text", "text": "Hello!"}]})
print(response.to_json())
# {"jsonrpc": "2.0", "id": 1, "result": {...}}
```

### Python: Parsing JSON-RPC Messages

```python
def parse_message(raw: str) -> dict:
    """Parse a JSON-RPC message and determine its type."""
    msg = json.loads(raw)
    
    if msg.get("jsonrpc") != "2.0":
        raise ValueError("Not a valid JSON-RPC 2.0 message")
    
    if "method" in msg:
        if "id" in msg:
            return {"type": "request", "data": msg}
        else:
            return {"type": "notification", "data": msg}
    elif "result" in msg or "error" in msg:
        return {"type": "response", "data": msg}
    else:
        raise ValueError("Unknown message type")

# Examples
messages = [
    '{"jsonrpc":"2.0","id":1,"method":"tools/list"}',
    '{"jsonrpc":"2.0","method":"notifications/progress","params":{}}',
    '{"jsonrpc":"2.0","id":1,"result":{"tools":[]}}',
]

for msg in messages:
    parsed = parse_message(msg)
    print(f"{parsed['type']}: {parsed['data'].get('method', 'N/A')}")
```

---

## Key Takeaways

| Concept | Key Point |
|---------|-----------|
| **Protocol Version** | Always use `"jsonrpc": "2.0"` |
| **Request ID** | Include `id` when you need a response |
| **Notification** | No `id` means no response expected |
| **Error Handling** | Use standard codes, include useful `data` |
| **Bidirectional** | Both client and server can send requests |

---

## Next Steps

Now that you understand JSON-RPC, let's see how MCP builds on this foundation:

**[Next: MCP Architecture Overview →](_04_mcp_architecture_overview.md)**

---

## Quick Quiz

1. What field distinguishes a request from a notification?
2. What are the three required fields in an error object?
3. Why would you choose a notification over a request?

<details>
<summary>Answers</summary>

1. The `id` field - requests have it, notifications don't
2. Only `code` and `message` are required; `data` is optional
3. When you don't need a response (fire-and-forget), like progress updates or log messages

</details>
