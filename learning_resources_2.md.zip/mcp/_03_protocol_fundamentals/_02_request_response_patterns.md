# Request-Response Patterns in MCP

## Overview

The request-response pattern is the fundamental interaction model in MCP. Understanding how requests flow, how responses are correlated, and how to handle various scenarios is crucial for building robust MCP implementations.

---

## Synchronous Request-Response Pattern

Although MCP is inherently asynchronous at the transport level, the logical model is synchronous request-response: for every request sent, exactly one response is expected.

### Basic Flow

```
+--------+                              +--------+
| Client |                              | Server |
+--------+                              +--------+
     |                                       |
     |  1. Generate unique ID                |
     |  2. Send request with ID              |
     |  ---------------------------------->  |
     |                                       |
     |                                       | 3. Process request
     |                                       | 4. Generate response
     |                                       |
     |  <----------------------------------  |
     |  5. Match response ID to request      |
     |  6. Resolve pending request           |
     |                                       |
```

### Code Example: Basic Request-Response

```python
import asyncio
import json
from dataclasses import dataclass
from typing import Dict, Any, Optional

@dataclass
class PendingRequest:
    """Tracks a request awaiting response"""
    id: int
    method: str
    future: asyncio.Future
    created_at: float

class MCPClient:
    def __init__(self):
        self._request_id = 0
        self._pending_requests: Dict[int, PendingRequest] = {}
    
    def _next_id(self) -> int:
        """Generate unique request ID"""
        self._request_id += 1
        return self._request_id
    
    async def send_request(
        self, 
        method: str, 
        params: Optional[Dict] = None
    ) -> Any:
        """Send request and await response"""
        request_id = self._next_id()
        
        # Create the request message
        request = {
            "jsonrpc": "2.0",
            "id": request_id,
            "method": method,
        }
        if params is not None:
            request["params"] = params
        
        # Create future to await response
        loop = asyncio.get_event_loop()
        future = loop.create_future()
        
        # Track pending request
        self._pending_requests[request_id] = PendingRequest(
            id=request_id,
            method=method,
            future=future,
            created_at=loop.time()
        )
        
        try:
            # Send the request (implementation depends on transport)
            await self._send_message(request)
            
            # Wait for response
            result = await future
            return result
        finally:
            # Clean up
            self._pending_requests.pop(request_id, None)
    
    def _handle_response(self, response: Dict):
        """Handle incoming response message"""
        response_id = response.get("id")
        
        if response_id not in self._pending_requests:
            # Unknown response ID - log warning
            print(f"Warning: Unknown response ID: {response_id}")
            return
        
        pending = self._pending_requests[response_id]
        
        if "error" in response:
            # Set exception on future
            error = response["error"]
            pending.future.set_exception(
                MCPError(error["code"], error["message"])
            )
        else:
            # Set result on future
            pending.future.set_result(response.get("result"))
```

---

## ID Correlation

Request IDs are the mechanism for matching responses to their originating requests. This is essential in async environments where responses may arrive out of order.

### ID Generation Strategies

```
+----------------------+------------------+------------------------+
| Strategy             | Example          | Use Case               |
+----------------------+------------------+------------------------+
| Sequential Integer   | 1, 2, 3, ...     | Simple clients         |
| UUID                 | "550e8400-..."   | Distributed systems    |
| Prefixed Sequential  | "req-001"        | Debugging/logging      |
| Timestamp-based      | 1699123456789    | Ordered requests       |
+----------------------+------------------+------------------------+
```

### Correlation Table Example

```
+------+----------------+------------------+------------+
| ID   | Method         | Sent At          | Status     |
+------+----------------+------------------+------------+
| 1    | initialize     | 10:00:00.001     | Completed  |
| 2    | tools/list     | 10:00:00.150     | Completed  |
| 3    | tools/call     | 10:00:00.200     | Pending    |
| 4    | resources/read | 10:00:00.201     | Pending    |
+------+----------------+------------------+------------+

Incoming response: {"id": 4, "result": {...}}
  --> Match to "resources/read", resolve pending request

Incoming response: {"id": 3, "result": {...}}
  --> Match to "tools/call", resolve pending request
```

### ID Correlation Implementation

```python
from typing import Dict, Optional
import threading

class RequestCorrelator:
    """Thread-safe request correlation"""
    
    def __init__(self):
        self._pending: Dict[int | str, PendingRequest] = {}
        self._lock = threading.Lock()
    
    def register(self, request_id: int | str, request: PendingRequest):
        """Register a pending request"""
        with self._lock:
            if request_id in self._pending:
                raise ValueError(f"Duplicate request ID: {request_id}")
            self._pending[request_id] = request
    
    def resolve(self, response_id: int | str, result: Any = None, error: Any = None):
        """Resolve a pending request with result or error"""
        with self._lock:
            if response_id not in self._pending:
                return False
            
            request = self._pending.pop(response_id)
        
        # Outside lock to avoid deadlock
        if error:
            request.future.set_exception(MCPError.from_dict(error))
        else:
            request.future.set_result(result)
        
        return True
    
    def get_pending(self, request_id: int | str) -> Optional[PendingRequest]:
        """Get pending request by ID"""
        with self._lock:
            return self._pending.get(request_id)
    
    def pending_count(self) -> int:
        """Number of pending requests"""
        with self._lock:
            return len(self._pending)
```

---

## Timeout Handling

Timeouts are critical for preventing resource leaks and handling unresponsive servers.

### Timeout Architecture

```
    CLIENT                                   SERVER
       |                                        |
       |  -------- Request (id: 5) -------->    |
       |  [Start timeout: 30s]                  |
       |                                        |
       |           [Server processing...]       |
       |           [Server becomes slow...]     |
       |                                        |
       |  [Timeout reached!]                    |
       |                                        |
       |  (Client raises TimeoutError)          |
       |  (Client may send cancel notification) |
       |                                        |
       |  ------- Cancel (notif) ---------->    |
       |  method: "notifications/cancelled"     |
       |  params: { requestId: 5 }              |
       |                                        |
```

### Timeout Implementation

```python
import asyncio
from typing import Optional

class TimeoutHandler:
    """Handle request timeouts"""
    
    DEFAULT_TIMEOUT = 30.0  # seconds
    
    def __init__(self, timeout: float = DEFAULT_TIMEOUT):
        self.timeout = timeout
    
    async def with_timeout(
        self, 
        coro, 
        timeout: Optional[float] = None,
        request_id: Optional[int | str] = None
    ):
        """Execute coroutine with timeout"""
        timeout = timeout or self.timeout
        
        try:
            return await asyncio.wait_for(coro, timeout=timeout)
        except asyncio.TimeoutError:
            # Optionally send cancellation
            if request_id is not None:
                await self._send_cancellation(request_id)
            raise RequestTimeoutError(
                f"Request {request_id} timed out after {timeout}s"
            )
    
    async def _send_cancellation(self, request_id: int | str):
        """Send cancellation notification"""
        notification = {
            "jsonrpc": "2.0",
            "method": "notifications/cancelled",
            "params": {
                "requestId": request_id,
                "reason": "Timeout"
            }
        }
        await self._send_message(notification)


# Usage
async def call_tool_with_timeout(client, tool_name, arguments, timeout=10.0):
    """Call a tool with custom timeout"""
    try:
        result = await asyncio.wait_for(
            client.call_tool(tool_name, arguments),
            timeout=timeout
        )
        return result
    except asyncio.TimeoutError:
        raise ToolTimeoutError(f"Tool '{tool_name}' timed out after {timeout}s")
```

### Tiered Timeout Strategy

Different operations may need different timeouts:

```python
class TimeoutConfig:
    """Operation-specific timeouts"""
    
    TIMEOUTS = {
        # Quick operations
        "initialize": 10.0,
        "tools/list": 5.0,
        "resources/list": 5.0,
        "prompts/list": 5.0,
        
        # Potentially slow operations
        "tools/call": 60.0,
        "resources/read": 30.0,
        "prompts/get": 10.0,
        
        # Default
        "default": 30.0
    }
    
    @classmethod
    def get_timeout(cls, method: str) -> float:
        return cls.TIMEOUTS.get(method, cls.TIMEOUTS["default"])
```

---

## Concurrent Requests

MCP supports multiple concurrent requests. The protocol doesn't mandate serial processing.

### Concurrent Request Flow

```
    CLIENT                                        SERVER
       |                                             |
  T=0  |  -------- Request A (id: 1) ------------>   |
  T=1  |  -------- Request B (id: 2) ------------>   |
  T=2  |  -------- Request C (id: 3) ------------>   |
       |                                             |
       |      [Server processes in parallel]         |
       |                                             |
  T=5  |  <-------- Response C (id: 3) -----------   |  (C finishes first)
  T=7  |  <-------- Response A (id: 1) -----------   |  (A finishes second)
  T=10 |  <-------- Response B (id: 2) -----------   |  (B finishes last)
       |                                             |

Note: Responses arrive out of order - correlation by ID is essential!
```

### Concurrent Request Implementation

```python
import asyncio
from typing import List, Dict, Any

class ConcurrentRequester:
    """Handle multiple concurrent requests"""
    
    def __init__(self, client, max_concurrent: int = 10):
        self.client = client
        self.semaphore = asyncio.Semaphore(max_concurrent)
    
    async def send_concurrent(
        self, 
        requests: List[Dict[str, Any]]
    ) -> List[Any]:
        """Send multiple requests concurrently"""
        
        async def send_one(method: str, params: Dict = None):
            async with self.semaphore:
                return await self.client.send_request(method, params)
        
        # Create tasks for all requests
        tasks = [
            send_one(req["method"], req.get("params"))
            for req in requests
        ]
        
        # Wait for all to complete
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        return results


# Usage example
async def fetch_all_capabilities(client):
    """Fetch all capabilities in parallel"""
    requester = ConcurrentRequester(client)
    
    requests = [
        {"method": "tools/list", "params": {}},
        {"method": "resources/list", "params": {}},
        {"method": "prompts/list", "params": {}},
    ]
    
    results = await requester.send_concurrent(requests)
    
    return {
        "tools": results[0],
        "resources": results[1],
        "prompts": results[2],
    }
```

### Rate Limiting

```python
import time
from collections import deque

class RateLimiter:
    """Limit request rate to prevent overwhelming server"""
    
    def __init__(self, max_requests: int, time_window: float):
        """
        Args:
            max_requests: Maximum requests allowed in time window
            time_window: Time window in seconds
        """
        self.max_requests = max_requests
        self.time_window = time_window
        self.request_times: deque = deque()
    
    async def acquire(self):
        """Wait until request is allowed"""
        while True:
            now = time.monotonic()
            
            # Remove old timestamps
            while self.request_times and \
                  now - self.request_times[0] > self.time_window:
                self.request_times.popleft()
            
            if len(self.request_times) < self.max_requests:
                self.request_times.append(now)
                return
            
            # Wait for oldest request to expire
            wait_time = self.time_window - (now - self.request_times[0])
            await asyncio.sleep(wait_time + 0.001)


# Usage
rate_limiter = RateLimiter(max_requests=10, time_window=1.0)  # 10 req/sec

async def rate_limited_request(client, method, params):
    await rate_limiter.acquire()
    return await client.send_request(method, params)
```

---

## Batch Operations

While JSON-RPC 2.0 supports batch requests (sending multiple requests in a single message), MCP implementations vary in their support.

### Batch Request Format

```json
[
  {"jsonrpc": "2.0", "id": 1, "method": "tools/list", "params": {}},
  {"jsonrpc": "2.0", "id": 2, "method": "resources/list", "params": {}},
  {"jsonrpc": "2.0", "id": 3, "method": "prompts/list", "params": {}}
]
```

### Batch Response Format

```json
[
  {"jsonrpc": "2.0", "id": 1, "result": {"tools": [...]}},
  {"jsonrpc": "2.0", "id": 3, "result": {"prompts": [...]}},
  {"jsonrpc": "2.0", "id": 2, "result": {"resources": [...]}}
]
```

### Batch Implementation (Client)

```python
from typing import List, Dict, Any

class BatchClient:
    """Client with batch request support"""
    
    def __init__(self, client):
        self.client = client
        self._batch_mode = False
        self._batch_queue: List[Dict] = []
    
    def begin_batch(self):
        """Start batching requests"""
        self._batch_mode = True
        self._batch_queue = []
    
    def queue_request(self, method: str, params: Dict = None) -> int:
        """Queue a request for batch sending"""
        if not self._batch_mode:
            raise RuntimeError("Not in batch mode")
        
        request_id = self.client._next_id()
        request = {
            "jsonrpc": "2.0",
            "id": request_id,
            "method": method,
        }
        if params:
            request["params"] = params
        
        self._batch_queue.append(request)
        return request_id
    
    async def send_batch(self) -> Dict[int, Any]:
        """Send all queued requests as a batch"""
        if not self._batch_mode:
            raise RuntimeError("Not in batch mode")
        
        batch = self._batch_queue
        self._batch_queue = []
        self._batch_mode = False
        
        if not batch:
            return {}
        
        # Send batch as JSON array
        responses = await self.client._send_batch(batch)
        
        # Map responses by ID
        result_map = {}
        for response in responses:
            response_id = response.get("id")
            if "error" in response:
                result_map[response_id] = MCPError.from_dict(response["error"])
            else:
                result_map[response_id] = response.get("result")
        
        return result_map


# Usage
async def batch_example(client):
    batch = BatchClient(client)
    
    batch.begin_batch()
    id1 = batch.queue_request("tools/list")
    id2 = batch.queue_request("resources/list")
    id3 = batch.queue_request("prompts/list")
    
    results = await batch.send_batch()
    
    tools = results[id1]
    resources = results[id2]
    prompts = results[id3]
```

---

## Request State Machine

```
                                    +------------------+
                                    |                  |
                                    v                  |
+----------+    send    +----------+     timeout   +--+-------+
|          | ---------> |          | ------------> |          |
|  IDLE    |            | PENDING  |               | TIMED_OUT|
|          | <--------- |          | <------------ |          |
+----------+  response  +----------+    cancel     +----------+
                            |
                            | error response
                            v
                       +----------+
                       |          |
                       |  FAILED  |
                       |          |
                       +----------+
```

### State Implementation

```python
from enum import Enum
from dataclasses import dataclass
from typing import Optional, Any

class RequestState(Enum):
    IDLE = "idle"
    PENDING = "pending"
    COMPLETED = "completed"
    FAILED = "failed"
    TIMED_OUT = "timed_out"
    CANCELLED = "cancelled"

@dataclass
class TrackedRequest:
    """Request with state tracking"""
    id: int | str
    method: str
    state: RequestState = RequestState.IDLE
    result: Optional[Any] = None
    error: Optional[Dict] = None
    sent_at: Optional[float] = None
    completed_at: Optional[float] = None
    
    def send(self):
        """Transition to PENDING"""
        if self.state != RequestState.IDLE:
            raise InvalidStateTransition(f"Cannot send from {self.state}")
        self.state = RequestState.PENDING
        self.sent_at = time.time()
    
    def complete(self, result: Any):
        """Transition to COMPLETED"""
        if self.state != RequestState.PENDING:
            raise InvalidStateTransition(f"Cannot complete from {self.state}")
        self.state = RequestState.COMPLETED
        self.result = result
        self.completed_at = time.time()
    
    def fail(self, error: Dict):
        """Transition to FAILED"""
        if self.state != RequestState.PENDING:
            raise InvalidStateTransition(f"Cannot fail from {self.state}")
        self.state = RequestState.FAILED
        self.error = error
        self.completed_at = time.time()
    
    def timeout(self):
        """Transition to TIMED_OUT"""
        if self.state != RequestState.PENDING:
            raise InvalidStateTransition(f"Cannot timeout from {self.state}")
        self.state = RequestState.TIMED_OUT
        self.completed_at = time.time()
    
    @property
    def duration(self) -> Optional[float]:
        """Request duration in seconds"""
        if self.sent_at and self.completed_at:
            return self.completed_at - self.sent_at
        return None
```

---

## Sequence Diagrams

### Successful Tool Call

```
    Client                    Server                   Tool
       |                         |                       |
       |   tools/call (id:1)     |                       |
       |------------------------>|                       |
       |   {                     |                       |
       |     "name": "calc",     |                       |
       |     "arguments": {...}  |                       |
       |   }                     |                       |
       |                         |   Execute tool        |
       |                         |---------------------->|
       |                         |                       |
       |                         |   Return result       |
       |                         |<----------------------|
       |                         |                       |
       |   Response (id:1)       |                       |
       |<------------------------|                       |
       |   {                     |                       |
       |     "result": {         |                       |
       |       "content": [...]  |                       |
       |     }                   |                       |
       |   }                     |                       |
```

### Request with Progress Updates

```
    Client                    Server
       |                         |
       |   tools/call (id:1)     |
       |   (with progressToken)  |
       |------------------------>|
       |                         |
       |   progress (notif)      |
       |<------------------------|
       |   progress: 25/100      |
       |                         |
       |   progress (notif)      |
       |<------------------------|
       |   progress: 50/100      |
       |                         |
       |   progress (notif)      |
       |<------------------------|
       |   progress: 100/100     |
       |                         |
       |   Response (id:1)       |
       |<------------------------|
       |   result: {...}         |
```

### Request Cancellation

```
    Client                    Server
       |                         |
       |   Request (id:5)        |
       |------------------------>|
       |                         |
       |   [User cancels]        |
       |                         |
       |   cancelled (notif)     |
       |------------------------>|
       |   requestId: 5          |
       |                         |
       |                         |  [Server stops work]
       |                         |
       |   Error Response (id:5) |
       |<------------------------|
       |   error: {              |
       |     code: -32800,       |
       |     message: "Cancelled"|
       |   }                     |
```

---

## Best Practices

### 1. Always Track Pending Requests

```python
# Good: Track all pending requests
pending = {}

def send_request(method, params):
    id = next_id()
    pending[id] = {"method": method, "sent_at": time.time()}
    send({"jsonrpc": "2.0", "id": id, "method": method, "params": params})
    return id

def handle_response(response):
    id = response.get("id")
    if id in pending:
        del pending[id]
        # Process response
```

### 2. Implement Cleanup for Stale Requests

```python
async def cleanup_stale_requests(pending: Dict, max_age: float = 300.0):
    """Periodically clean up stale pending requests"""
    while True:
        await asyncio.sleep(60)  # Check every minute
        
        now = time.time()
        stale_ids = [
            id for id, req in pending.items()
            if now - req["sent_at"] > max_age
        ]
        
        for id in stale_ids:
            req = pending.pop(id)
            logger.warning(f"Cleaned up stale request: {id} ({req['method']})")
```

### 3. Use Appropriate Timeouts

```python
# Configure per-operation timeouts
OPERATION_TIMEOUTS = {
    "initialize": 10,
    "tools/list": 5,
    "tools/call": 60,  # Tools might be slow
    "resources/read": 30,
}

async def send_with_timeout(client, method, params):
    timeout = OPERATION_TIMEOUTS.get(method, 30)
    return await asyncio.wait_for(
        client.send_request(method, params),
        timeout=timeout
    )
```

### 4. Handle Out-of-Order Responses

```python
# Good: Match by ID, not by order
def handle_responses(responses):
    for response in responses:
        id = response["id"]
        pending_request = pending_requests.get(id)
        if pending_request:
            resolve_request(pending_request, response)

# Bad: Assume responses arrive in order
def handle_responses_bad(responses):
    for i, response in enumerate(responses):
        resolve_request(sent_requests[i], response)  # WRONG!
```

---

## Summary

| Pattern | Description | Key Consideration |
|---------|-------------|-------------------|
| Synchronous | One request, one response | Use ID correlation |
| Timeout | Handle slow/unresponsive servers | Configure per-operation |
| Concurrent | Multiple in-flight requests | Proper ID management |
| Batch | Multiple requests in one message | Check server support |
| Cancellation | Stop pending requests | Send notification |

---

## Next Steps

- [Notifications](./_03_notifications.md) - Fire-and-forget messages
- [Error Handling](./_04_error_handling.md) - Handling failures gracefully
