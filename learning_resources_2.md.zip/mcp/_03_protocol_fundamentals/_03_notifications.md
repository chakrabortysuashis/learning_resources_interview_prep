# Notifications in MCP

## Overview

Notifications are one-way messages in MCP that don't expect or receive a response. They're used for events, status updates, progress reporting, and other fire-and-forget communications. Understanding notifications is essential for building responsive MCP applications.

---

## What Are Notifications?

A notification is a JSON-RPC message that:
- **Has no `id` field** - This is the key distinguishing feature
- **Expects no response** - The sender doesn't wait
- **Is fire-and-forget** - No acknowledgment or confirmation

### Notification vs Request

```
+------------------------+------------------------+
|       REQUEST          |     NOTIFICATION       |
+------------------------+------------------------+
| {                      | {                      |
|   "jsonrpc": "2.0",    |   "jsonrpc": "2.0",    |
|   "id": 1,         <-- |   (no id)          <-- |
|   "method": "...",     |   "method": "...",     |
|   "params": {...}      |   "params": {...}      |
| }                      | }                      |
+------------------------+------------------------+
| Sender WAITS for       | Sender CONTINUES       |
| response               | immediately            |
+------------------------+------------------------+
| Server MUST respond    | Server MUST NOT        |
|                        | respond                |
+------------------------+------------------------+
```

### Message Flow Comparison

```
REQUEST-RESPONSE:
    Client                     Server
       |                          |
       |  ---- Request (id:1) --> |
       |                          |  [Processing]
       |  <--- Response (id:1) -- |
       |                          |


NOTIFICATION:
    Client                     Server
       |                          |
       |  ---- Notification ----> |
       |  (no id, no waiting)     |  [Handle if interested]
       |                          |
       |  [Continue immediately]  |
```

---

## Common Notification Types in MCP

MCP defines several standard notification types:

```
+---------------------------------------+----------------------------------+
| Notification                          | Purpose                          |
+---------------------------------------+----------------------------------+
| notifications/initialized             | Client ready after init          |
| notifications/cancelled               | Cancel in-progress request       |
| notifications/progress                | Progress updates                 |
| notifications/message                 | Log messages                     |
| notifications/resources/updated       | Resource content changed         |
| notifications/resources/list_changed  | Available resources changed      |
| notifications/tools/list_changed      | Available tools changed          |
| notifications/prompts/list_changed    | Available prompts changed        |
| notifications/roots/list_changed      | Root directories changed         |
+---------------------------------------+----------------------------------+
```

---

## 1. Initialized Notification

Sent by the client after successfully receiving the `initialize` response.

### Format

```json
{
  "jsonrpc": "2.0",
  "method": "notifications/initialized"
}
```

### Protocol Flow

```
    Client                              Server
       |                                   |
       |  ===== initialize (request) ===>  |
       |  id: 1                            |
       |                                   |
       |  <==== initialize (response) ===  |
       |  id: 1, result: {...}             |
       |                                   |
       |  ----- initialized (notif) ---->  |
       |  (no id, no response)             |
       |                                   |
       |  ===== READY FOR OPERATIONS ===   |
       |                                   |
```

### Code Example

```python
async def perform_initialization(client):
    """Complete MCP initialization handshake"""
    
    # Step 1: Send initialize request
    init_result = await client.send_request("initialize", {
        "protocolVersion": "2024-11-05",
        "capabilities": {
            "roots": {"listChanged": True},
            "sampling": {}
        },
        "clientInfo": {
            "name": "MyClient",
            "version": "1.0.0"
        }
    })
    
    # Step 2: Send initialized notification
    # Note: No await needed for response - it's a notification
    await client.send_notification("notifications/initialized")
    
    # Step 3: Now ready for normal operations
    return init_result
```

---

## 2. Progress Notification

Used to report progress of long-running operations.

### Format

```json
{
  "jsonrpc": "2.0",
  "method": "notifications/progress",
  "params": {
    "progressToken": "operation-123",
    "progress": 75,
    "total": 100
  }
}
```

### Parameters

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `progressToken` | string \| number | Yes | Links to original request |
| `progress` | number | Yes | Current progress value |
| `total` | number | No | Total value (for percentage calculation) |

### Request with Progress Token

```json
{
  "jsonrpc": "2.0",
  "id": 5,
  "method": "tools/call",
  "params": {
    "name": "process_large_file",
    "arguments": {
      "file": "/data/large.csv"
    },
    "_meta": {
      "progressToken": "op-5"
    }
  }
}
```

### Progress Flow

```
    Client                                 Server
       |                                      |
       |  tools/call (id:5)                   |
       |  progressToken: "op-5"               |
       |  --------------------------------->  |
       |                                      |
       |  <-- progress (notif) -----------   |
       |      token: "op-5", progress: 10    |
       |                                      |
       |  <-- progress (notif) -----------   |
       |      token: "op-5", progress: 50    |
       |                                      |
       |  <-- progress (notif) -----------   |
       |      token: "op-5", progress: 100   |
       |                                      |
       |  <-- Response (id:5) -------------  |
       |      result: {...}                  |
       |                                      |
```

### Progress Handler Implementation

```python
from typing import Callable, Dict, Optional
from dataclasses import dataclass

@dataclass
class ProgressUpdate:
    token: str
    progress: float
    total: Optional[float] = None
    
    @property
    def percentage(self) -> Optional[float]:
        if self.total and self.total > 0:
            return (self.progress / self.total) * 100
        return None

class ProgressTracker:
    """Track progress of multiple operations"""
    
    def __init__(self):
        self._handlers: Dict[str, Callable] = {}
        self._progress: Dict[str, ProgressUpdate] = {}
    
    def register_handler(
        self, 
        token: str, 
        callback: Callable[[ProgressUpdate], None]
    ):
        """Register a callback for progress updates"""
        self._handlers[token] = callback
    
    def handle_notification(self, params: Dict):
        """Handle incoming progress notification"""
        token = params.get("progressToken")
        if not token:
            return
        
        update = ProgressUpdate(
            token=token,
            progress=params.get("progress", 0),
            total=params.get("total")
        )
        
        self._progress[token] = update
        
        # Call registered handler
        if token in self._handlers:
            self._handlers[token](update)
    
    def get_progress(self, token: str) -> Optional[ProgressUpdate]:
        """Get current progress for token"""
        return self._progress.get(token)


# Usage
tracker = ProgressTracker()

def on_upload_progress(update: ProgressUpdate):
    pct = update.percentage or 0
    print(f"Upload progress: {pct:.1f}%")

tracker.register_handler("upload-123", on_upload_progress)
```

---

## 3. Log Message Notification

Servers send log messages to clients for debugging and monitoring.

### Format

```json
{
  "jsonrpc": "2.0",
  "method": "notifications/message",
  "params": {
    "level": "info",
    "logger": "database",
    "data": "Connection established to postgres://localhost:5432"
  }
}
```

### Log Levels

```
+----------+-------+----------------------------------+
| Level    | Value | Description                      |
+----------+-------+----------------------------------+
| debug    | 1     | Detailed debugging info          |
| info     | 2     | General informational messages   |
| notice   | 3     | Normal but significant events    |
| warning  | 4     | Warning conditions               |
| error    | 5     | Error conditions                 |
| critical | 6     | Critical conditions              |
| alert    | 7     | Action must be taken immediately |
| emergency| 8     | System is unusable               |
+----------+-------+----------------------------------+
```

### Log Handler Implementation

```python
import logging
from enum import IntEnum
from typing import Any, Dict

class MCPLogLevel(IntEnum):
    DEBUG = 1
    INFO = 2
    NOTICE = 3
    WARNING = 4
    ERROR = 5
    CRITICAL = 6
    ALERT = 7
    EMERGENCY = 8

class MCPLogHandler:
    """Handle MCP log notifications"""
    
    # Map MCP levels to Python logging levels
    LEVEL_MAP = {
        "debug": logging.DEBUG,
        "info": logging.INFO,
        "notice": logging.INFO,
        "warning": logging.WARNING,
        "error": logging.ERROR,
        "critical": logging.CRITICAL,
        "alert": logging.CRITICAL,
        "emergency": logging.CRITICAL,
    }
    
    def __init__(self, min_level: str = "info"):
        self.min_level = MCPLogLevel[min_level.upper()]
        self.logger = logging.getLogger("mcp.server")
    
    def handle_notification(self, params: Dict):
        """Handle incoming log notification"""
        level = params.get("level", "info")
        logger_name = params.get("logger", "default")
        data = params.get("data")
        
        # Check if we should process this level
        mcp_level = MCPLogLevel[level.upper()]
        if mcp_level < self.min_level:
            return
        
        # Convert to Python logging
        py_level = self.LEVEL_MAP.get(level, logging.INFO)
        
        # Format message
        if isinstance(data, str):
            message = data
        else:
            message = str(data)
        
        # Log it
        self.logger.log(py_level, f"[{logger_name}] {message}")


# Usage
log_handler = MCPLogHandler(min_level="warning")

# When notification received:
# {"jsonrpc":"2.0","method":"notifications/message","params":{...}}
log_handler.handle_notification({
    "level": "warning",
    "logger": "rate-limiter", 
    "data": "Approaching rate limit: 95/100 requests"
})
```

---

## 4. Resource Notifications

### Resource Updated

Sent when the content of a subscribed resource changes.

```json
{
  "jsonrpc": "2.0",
  "method": "notifications/resources/updated",
  "params": {
    "uri": "file:///config/app.json"
  }
}
```

### Resource List Changed

Sent when the available resources change.

```json
{
  "jsonrpc": "2.0",
  "method": "notifications/resources/list_changed"
}
```

### Subscription Flow

```
    Client                              Server
       |                                   |
       |  resources/subscribe              |
       |  uri: "file:///config.json"       |
       |  ==============================>  |
       |                                   |
       |  <==============================  |
       |  result: {}                       |
       |                                   |
       |         [File is modified]        |
       |                                   |
       |  <-- resources/updated (notif) -- |
       |      uri: "file:///config.json"   |
       |                                   |
       |  resources/read                   |
       |  uri: "file:///config.json"       |
       |  ==============================>  |
       |                                   |
       |  <==============================  |
       |  result: { contents: [...] }      |
       |                                   |
```

### Resource Subscription Handler

```python
from typing import Callable, Set, Dict

class ResourceSubscriptionManager:
    """Manage resource subscriptions and updates"""
    
    def __init__(self, client):
        self.client = client
        self._subscriptions: Set[str] = set()
        self._handlers: Dict[str, Callable] = {}
    
    async def subscribe(
        self, 
        uri: str, 
        on_update: Callable[[str], None]
    ):
        """Subscribe to resource updates"""
        if uri not in self._subscriptions:
            await self.client.send_request(
                "resources/subscribe",
                {"uri": uri}
            )
            self._subscriptions.add(uri)
        
        self._handlers[uri] = on_update
    
    async def unsubscribe(self, uri: str):
        """Unsubscribe from resource updates"""
        if uri in self._subscriptions:
            await self.client.send_request(
                "resources/unsubscribe",
                {"uri": uri}
            )
            self._subscriptions.discard(uri)
            self._handlers.pop(uri, None)
    
    def handle_update_notification(self, params: Dict):
        """Handle resources/updated notification"""
        uri = params.get("uri")
        if uri in self._handlers:
            self._handlers[uri](uri)
    
    async def handle_list_changed_notification(self):
        """Handle resources/list_changed notification"""
        # Re-fetch resource list
        result = await self.client.send_request("resources/list")
        return result.get("resources", [])


# Usage
manager = ResourceSubscriptionManager(client)

async def on_config_change(uri: str):
    print(f"Config changed: {uri}")
    # Re-read the resource
    content = await client.send_request("resources/read", {"uri": uri})
    # Update local state
    apply_config(content)

await manager.subscribe("file:///config/app.json", on_config_change)
```

---

## 5. Cancellation Notification

Used to cancel an in-progress request.

### Format

```json
{
  "jsonrpc": "2.0",
  "method": "notifications/cancelled",
  "params": {
    "requestId": 42,
    "reason": "User requested cancellation"
  }
}
```

### Parameters

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `requestId` | string \| number | Yes | ID of request to cancel |
| `reason` | string | No | Human-readable reason |

### Cancellation Flow

```
    Client                              Server
       |                                   |
       |  tools/call (id:42)               |
       |  ==============================>  |
       |                                   |
       |  [User clicks Cancel]             |
       |                                   |
       |  --- cancelled (notif) -------->  |
       |      requestId: 42                |
       |                                   |
       |                                   | [Server attempts
       |                                   |  to stop operation]
       |                                   |
       |  <-- Error Response (id:42) ----  |
       |      code: -32800                 |
       |      message: "Request cancelled" |
       |                                   |
```

### Cancellation Implementation

```python
import asyncio
from typing import Dict, Set

class CancellationManager:
    """Manage request cancellation"""
    
    def __init__(self, client):
        self.client = client
        self._cancellable_requests: Dict[int, asyncio.Task] = {}
        self._cancelled: Set[int] = set()
    
    def register_cancellable(self, request_id: int, task: asyncio.Task):
        """Register a task that can be cancelled"""
        self._cancellable_requests[request_id] = task
    
    async def cancel_request(self, request_id: int, reason: str = None):
        """Cancel a pending request"""
        # Send cancellation notification
        notification = {
            "jsonrpc": "2.0",
            "method": "notifications/cancelled",
            "params": {
                "requestId": request_id
            }
        }
        if reason:
            notification["params"]["reason"] = reason
        
        await self.client._send_message(notification)
        
        # Mark as cancelled
        self._cancelled.add(request_id)
        
        # Cancel local task if exists
        if request_id in self._cancellable_requests:
            task = self._cancellable_requests.pop(request_id)
            task.cancel()
    
    def is_cancelled(self, request_id: int) -> bool:
        """Check if request was cancelled"""
        return request_id in self._cancelled
    
    def cleanup(self, request_id: int):
        """Clean up after request completes"""
        self._cancellable_requests.pop(request_id, None)
        self._cancelled.discard(request_id)


# Server-side cancellation handling
class CancellableOperation:
    """Base class for cancellable server operations"""
    
    def __init__(self, request_id: int):
        self.request_id = request_id
        self._cancelled = False
    
    def cancel(self, reason: str = None):
        """Mark operation as cancelled"""
        self._cancelled = True
        self._cancel_reason = reason
    
    def check_cancelled(self):
        """Check if cancelled, raise if so"""
        if self._cancelled:
            raise OperationCancelledError(
                self.request_id, 
                self._cancel_reason
            )
    
    async def run_with_cancellation_checks(self, steps):
        """Run steps with periodic cancellation checks"""
        for step in steps:
            self.check_cancelled()
            await step()
```

---

## 6. List Changed Notifications

Sent when available items (tools, prompts, resources, roots) change.

### Tools List Changed

```json
{
  "jsonrpc": "2.0",
  "method": "notifications/tools/list_changed"
}
```

### Prompts List Changed

```json
{
  "jsonrpc": "2.0",
  "method": "notifications/prompts/list_changed"
}
```

### Roots List Changed

```json
{
  "jsonrpc": "2.0",
  "method": "notifications/roots/list_changed"
}
```

### Handling List Changes

```python
class CapabilityCache:
    """Cache server capabilities with auto-refresh"""
    
    def __init__(self, client):
        self.client = client
        self._tools = None
        self._resources = None
        self._prompts = None
    
    async def get_tools(self, force_refresh: bool = False):
        """Get tools, refreshing if needed"""
        if self._tools is None or force_refresh:
            result = await self.client.send_request("tools/list")
            self._tools = result.get("tools", [])
        return self._tools
    
    def handle_notification(self, method: str):
        """Handle list_changed notifications"""
        if method == "notifications/tools/list_changed":
            self._tools = None  # Invalidate cache
        elif method == "notifications/resources/list_changed":
            self._resources = None
        elif method == "notifications/prompts/list_changed":
            self._prompts = None


# Central notification dispatcher
class NotificationDispatcher:
    """Route notifications to handlers"""
    
    def __init__(self):
        self._handlers = {}
    
    def register(self, method: str, handler: Callable):
        """Register notification handler"""
        if method not in self._handlers:
            self._handlers[method] = []
        self._handlers[method].append(handler)
    
    def dispatch(self, notification: Dict):
        """Dispatch notification to registered handlers"""
        method = notification.get("method")
        params = notification.get("params", {})
        
        if method in self._handlers:
            for handler in self._handlers[method]:
                try:
                    handler(params)
                except Exception as e:
                    logging.error(f"Handler error for {method}: {e}")


# Usage
dispatcher = NotificationDispatcher()
cache = CapabilityCache(client)

dispatcher.register(
    "notifications/tools/list_changed",
    lambda _: cache.handle_notification("notifications/tools/list_changed")
)
```

---

## Fire-and-Forget Semantics

### What "Fire-and-Forget" Means

```
+------------------------------------------------------------------+
|                    FIRE-AND-FORGET                                |
+------------------------------------------------------------------+
| 1. Sender sends notification                                      |
| 2. Sender does NOT wait                                           |
| 3. Sender does NOT know if received                               |
| 4. Sender does NOT know if processed                              |
| 5. No delivery guarantee (depends on transport)                   |
| 6. No ordering guarantee relative to other messages               |
+------------------------------------------------------------------+
```

### Implications

```python
# Notification sending - no await for response
async def send_progress(client, token: str, progress: int, total: int):
    """Send progress notification - fire and forget"""
    notification = {
        "jsonrpc": "2.0",
        "method": "notifications/progress",
        "params": {
            "progressToken": token,
            "progress": progress,
            "total": total
        }
    }
    
    # Just send, don't wait for anything
    await client._write_message(notification)
    
    # Immediately continue - don't wait for acknowledgment
    # The client may or may not receive this

# Notification handling - don't block
def handle_notification(notification: Dict):
    """Handle notification quickly, don't block"""
    method = notification.get("method")
    
    # DO: Quick processing
    if method == "notifications/progress":
        update_progress_bar(notification["params"])
    
    # DON'T: Long-running work in handler
    # if method == "notifications/resources/updated":
    #     content = await fetch_resource(uri)  # BAD! Blocks
    
    # DO: Queue for async processing
    if method == "notifications/resources/updated":
        task_queue.put_nowait(("refresh_resource", notification["params"]))
```

### No Acknowledgment Pattern

```
    Sender                              Receiver
       |                                   |
       |  --- Notification 1 ---------->   |
       |  --- Notification 2 ---------->   |  [May be dropped]
       |  --- Notification 3 ---------->   |
       |                                   |
       |  [Sender has no idea if 1,2,3     |
       |   were received or processed]     |
       |                                   |
```

---

## Use Cases for Notifications

### 1. Status Updates

```python
# Server sends status during long operation
async def process_batch(items, progress_token):
    total = len(items)
    for i, item in enumerate(items):
        await process_item(item)
        
        # Send progress (fire-and-forget)
        await send_notification("notifications/progress", {
            "progressToken": progress_token,
            "progress": i + 1,
            "total": total
        })
```

### 2. Event Broadcasting

```python
# Server broadcasts when state changes
class ResourceWatcher:
    async def on_file_change(self, uri: str):
        """Called by file watcher when file changes"""
        await self.server.send_notification(
            "notifications/resources/updated",
            {"uri": uri}
        )
```

### 3. Logging and Debugging

```python
# Server sends logs to client
class MCPLogger:
    async def log(self, level: str, message: str, logger: str = "default"):
        await self.server.send_notification(
            "notifications/message",
            {
                "level": level,
                "logger": logger,
                "data": message
            }
        )

# Usage
logger = MCPLogger(server)
await logger.log("info", "Starting database sync", "db")
await logger.log("warning", "Rate limit at 90%", "api")
```

### 4. Graceful Shutdown

```python
# Client sends cancellation for all pending requests
async def shutdown_gracefully(client, pending_requests: Dict):
    """Cancel all pending requests before disconnect"""
    for request_id in list(pending_requests.keys()):
        await client.send_notification(
            "notifications/cancelled",
            {
                "requestId": request_id,
                "reason": "Client shutting down"
            }
        )
```

---

## Best Practices

### 1. Don't Rely on Notification Delivery

```python
# Good: Use notifications for non-critical updates
await send_notification("notifications/progress", {"progress": 50})

# Bad: Relying on notification for critical state
await send_notification("notifications/critical_data", data)
# If this fails silently, client won't have the data!

# Better: Use request-response for critical data
result = await send_request("critical/sync", data)
```

### 2. Handle Notifications Asynchronously

```python
# Good: Non-blocking handler
async def notification_handler(notification):
    method = notification["method"]
    params = notification.get("params", {})
    
    # Quick dispatch to queue
    await notification_queue.put((method, params))

# Background worker processes queue
async def notification_worker():
    while True:
        method, params = await notification_queue.get()
        await process_notification(method, params)
```

### 3. Throttle High-Frequency Notifications

```python
import time

class ThrottledNotifier:
    """Throttle notification rate"""
    
    def __init__(self, min_interval: float = 0.1):
        self.min_interval = min_interval
        self._last_sent: Dict[str, float] = {}
    
    async def maybe_send(self, method: str, params: Dict):
        """Send notification if not throttled"""
        now = time.monotonic()
        last = self._last_sent.get(method, 0)
        
        if now - last >= self.min_interval:
            await self._send_notification(method, params)
            self._last_sent[method] = now


# Usage for progress updates
throttled = ThrottledNotifier(min_interval=0.1)  # Max 10/second

for i in range(1000):
    do_work(i)
    # Won't flood client with 1000 notifications
    await throttled.maybe_send("notifications/progress", {
        "progressToken": token,
        "progress": i,
        "total": 1000
    })
```

---

## Summary

| Notification Type | Direction | Purpose |
|------------------|-----------|---------|
| `initialized` | Client -> Server | Initialization complete |
| `cancelled` | Client -> Server | Cancel request |
| `progress` | Server -> Client | Progress updates |
| `message` | Server -> Client | Log messages |
| `resources/updated` | Server -> Client | Resource content changed |
| `*/list_changed` | Server -> Client | Available items changed |

Key Points:
- Notifications have **no ID** and expect **no response**
- They are **fire-and-forget** - no delivery guarantee
- Use for **non-critical** status updates and events
- Handle them **quickly and asynchronously**
- **Throttle** high-frequency notifications

---

## Next Steps

- [Error Handling](./_04_error_handling.md) - Handling errors in MCP
- [Protocol in Action](./_05_protocol_in_action.ipynb) - Hands-on examples
