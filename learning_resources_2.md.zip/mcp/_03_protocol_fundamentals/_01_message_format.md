# MCP Message Format

## Overview

The Model Context Protocol (MCP) is built on top of **JSON-RPC 2.0**, a lightweight remote procedure call protocol encoded in JSON. Understanding the message format is fundamental to working with MCP, whether you're building servers, clients, or debugging protocol interactions.

## JSON-RPC 2.0 Foundation

JSON-RPC 2.0 defines a stateless, transport-agnostic protocol for remote procedure calls. MCP adopts this standard with some specific conventions and extensions.

### Key Characteristics

- **Stateless**: Each message is self-contained
- **Transport-agnostic**: Works over stdio, HTTP, WebSocket, etc.
- **Lightweight**: Simple JSON encoding
- **Bidirectional**: Both client and server can initiate requests

---

## Message Types

MCP uses three types of messages:

```
+------------------+------------------+------------------+
|     REQUEST      |    RESPONSE      |   NOTIFICATION   |
+------------------+------------------+------------------+
| Has: method, id  | Has: result/     | Has: method      |
|      params      |      error, id   |      params      |
| Expects response | Is a response    | No id            |
|                  |                  | No response      |
+------------------+------------------+------------------+
```

---

## 1. Request Message Format

A request message is sent when one party wants to invoke a method on the other party and receive a response.

### Structure

```json
{
  "jsonrpc": "2.0",
  "id": <string | number>,
  "method": "<method_name>",
  "params": <object | array | omitted>
}
```

### Fields

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `jsonrpc` | string | Yes | Must be exactly `"2.0"` |
| `id` | string \| number | Yes | Unique identifier for matching request/response |
| `method` | string | Yes | Name of the method to invoke |
| `params` | object \| array | No | Parameters for the method |

### Example: Initialize Request

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "initialize",
  "params": {
    "protocolVersion": "2024-11-05",
    "capabilities": {
      "roots": {
        "listChanged": true
      },
      "sampling": {}
    },
    "clientInfo": {
      "name": "MyMCPClient",
      "version": "1.0.0"
    }
  }
}
```

### Example: Tools List Request

```json
{
  "jsonrpc": "2.0",
  "id": 2,
  "method": "tools/list",
  "params": {}
}
```

### Example: Tool Call Request

```json
{
  "jsonrpc": "2.0",
  "id": 3,
  "method": "tools/call",
  "params": {
    "name": "get_weather",
    "arguments": {
      "city": "San Francisco",
      "units": "celsius"
    }
  }
}
```

### Example: Resource Read Request

```json
{
  "jsonrpc": "2.0",
  "id": 4,
  "method": "resources/read",
  "params": {
    "uri": "file:///home/user/documents/report.txt"
  }
}
```

---

## 2. Response Message Format

A response is sent in reply to a request. It contains either a result (success) or an error (failure).

### Success Response Structure

```json
{
  "jsonrpc": "2.0",
  "id": <string | number>,
  "result": <any>
}
```

### Error Response Structure

```json
{
  "jsonrpc": "2.0",
  "id": <string | number>,
  "error": {
    "code": <integer>,
    "message": "<error_description>",
    "data": <any>  // optional
  }
}
```

### Fields

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `jsonrpc` | string | Yes | Must be exactly `"2.0"` |
| `id` | string \| number | Yes | Must match the request's id |
| `result` | any | Conditional | Present on success (mutually exclusive with error) |
| `error` | object | Conditional | Present on failure (mutually exclusive with result) |

### Example: Initialize Response (Success)

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "result": {
    "protocolVersion": "2024-11-05",
    "capabilities": {
      "tools": {
        "listChanged": true
      },
      "resources": {
        "subscribe": true,
        "listChanged": true
      },
      "prompts": {
        "listChanged": true
      },
      "logging": {}
    },
    "serverInfo": {
      "name": "WeatherServer",
      "version": "2.0.0"
    }
  }
}
```

### Example: Tools List Response

```json
{
  "jsonrpc": "2.0",
  "id": 2,
  "result": {
    "tools": [
      {
        "name": "get_weather",
        "description": "Get current weather for a city",
        "inputSchema": {
          "type": "object",
          "properties": {
            "city": {
              "type": "string",
              "description": "City name"
            },
            "units": {
              "type": "string",
              "enum": ["celsius", "fahrenheit"],
              "default": "celsius"
            }
          },
          "required": ["city"]
        }
      }
    ]
  }
}
```

### Example: Tool Call Response

```json
{
  "jsonrpc": "2.0",
  "id": 3,
  "result": {
    "content": [
      {
        "type": "text",
        "text": "Current weather in San Francisco: 18C, partly cloudy"
      }
    ],
    "isError": false
  }
}
```

### Example: Error Response

```json
{
  "jsonrpc": "2.0",
  "id": 3,
  "error": {
    "code": -32602,
    "message": "Invalid params",
    "data": {
      "field": "city",
      "reason": "City name cannot be empty"
    }
  }
}
```

---

## 3. Notification Message Format

Notifications are one-way messages that don't expect a response. They're used for events, status updates, and other fire-and-forget communications.

### Structure

```json
{
  "jsonrpc": "2.0",
  "method": "<method_name>",
  "params": <object | array | omitted>
}
```

### Key Differences from Requests

| Aspect | Request | Notification |
|--------|---------|--------------|
| Has `id` field | Yes | **No** |
| Expects response | Yes | **No** |
| Sender waits | Yes | **No** |

### Example: Initialized Notification

Sent by the client after receiving the initialize response:

```json
{
  "jsonrpc": "2.0",
  "method": "notifications/initialized"
}
```

### Example: Progress Notification

Sent during long-running operations:

```json
{
  "jsonrpc": "2.0",
  "method": "notifications/progress",
  "params": {
    "progressToken": "op-123",
    "progress": 75,
    "total": 100
  }
}
```

### Example: Resource List Changed Notification

Sent when available resources change:

```json
{
  "jsonrpc": "2.0",
  "method": "notifications/resources/list_changed"
}
```

### Example: Log Message Notification

```json
{
  "jsonrpc": "2.0",
  "method": "notifications/message",
  "params": {
    "level": "info",
    "logger": "weather-service",
    "data": "Weather data cache refreshed successfully"
  }
}
```

### Example: Cancelled Notification

Sent to cancel an in-progress request:

```json
{
  "jsonrpc": "2.0",
  "method": "notifications/cancelled",
  "params": {
    "requestId": 42,
    "reason": "User cancelled the operation"
  }
}
```

---

## Message Flow Diagrams

### Basic Request-Response Flow

```
    CLIENT                                    SERVER
       |                                         |
       |  -------- Request (id: 1) ---------->   |
       |  {                                      |
       |    "jsonrpc": "2.0",                    |
       |    "id": 1,                             |
       |    "method": "tools/list",              |
       |    "params": {}                         |
       |  }                                      |
       |                                         |
       |  <------- Response (id: 1) ----------   |
       |  {                                      |
       |    "jsonrpc": "2.0",                    |
       |    "id": 1,                             |
       |    "result": { "tools": [...] }         |
       |  }                                      |
       |                                         |
```

### Initialization Handshake

```
    CLIENT                                    SERVER
       |                                         |
       |  ======= initialize (request) =======>  |
       |  id: 1, method: "initialize"            |
       |  params: { clientInfo, capabilities }   |
       |                                         |
       |  <====== initialize (response) =======  |
       |  id: 1, result: { serverInfo, ... }     |
       |                                         |
       |  ------- initialized (notif) -------->  |
       |  method: "notifications/initialized"    |
       |  (no id, no response expected)          |
       |                                         |
       |  ====== READY FOR OPERATIONS ========   |
       |                                         |
```

### Multiple Concurrent Requests

```
    CLIENT                                    SERVER
       |                                         |
       |  -------- Request (id: 1) ---------->   |
       |  method: "tools/list"                   |
       |                                         |
       |  -------- Request (id: 2) ---------->   |
       |  method: "resources/list"               |
       |                                         |
       |  -------- Request (id: 3) ---------->   |
       |  method: "prompts/list"                 |
       |                                         |
       |  (server processes concurrently...)     |
       |                                         |
       |  <------- Response (id: 3) ----------   |
       |  result: { prompts: [...] }             |
       |                                         |
       |  <------- Response (id: 1) ----------   |
       |  result: { tools: [...] }               |
       |                                         |
       |  <------- Response (id: 2) ----------   |
       |  result: { resources: [...] }           |
       |                                         |
```

### Notification Flow (Fire-and-Forget)

```
    CLIENT                                    SERVER
       |                                         |
       |                                         |
       |  <------ Progress Notification ------   |
       |  method: "notifications/progress"       |
       |  params: { progress: 25, total: 100 }   |
       |                                         |
       |  (client receives, no response sent)    |
       |                                         |
       |  <------ Progress Notification ------   |
       |  params: { progress: 50, total: 100 }   |
       |                                         |
       |  <------ Progress Notification ------   |
       |  params: { progress: 100, total: 100 }  |
       |                                         |
```

---

## Message Encoding Rules

### 1. Character Encoding

- All messages MUST be encoded in **UTF-8**
- No BOM (Byte Order Mark) should be present

### 2. Whitespace

- Whitespace is insignificant except within strings
- Compact encoding is preferred for transport efficiency:

```json
{"jsonrpc":"2.0","id":1,"method":"tools/list","params":{}}
```

### 3. Field Order

- Field order is not significant
- Both of these are equivalent:

```json
{"jsonrpc":"2.0","id":1,"method":"test"}
{"method":"test","id":1,"jsonrpc":"2.0"}
```

### 4. ID Values

- Can be string or number (integer recommended)
- Should be unique within a session
- Null is valid but discouraged
- Must be echoed exactly in response

```json
// Number ID
{"jsonrpc":"2.0","id":1,"method":"test"}

// String ID
{"jsonrpc":"2.0","id":"req-001","method":"test"}

// UUID ID
{"jsonrpc":"2.0","id":"550e8400-e29b-41d4-a716-446655440000","method":"test"}
```

---

## Complete Message Reference

### MCP Method Categories

```
+--------------------+----------------------------------------+
| Category           | Methods                                |
+--------------------+----------------------------------------+
| Lifecycle          | initialize                             |
+--------------------+----------------------------------------+
| Tools              | tools/list, tools/call                 |
+--------------------+----------------------------------------+
| Resources          | resources/list, resources/read,        |
|                    | resources/subscribe,                   |
|                    | resources/unsubscribe                  |
+--------------------+----------------------------------------+
| Prompts            | prompts/list, prompts/get              |
+--------------------+----------------------------------------+
| Completion         | completion/complete                    |
+--------------------+----------------------------------------+
| Logging            | logging/setLevel                       |
+--------------------+----------------------------------------+
| Sampling           | sampling/createMessage                 |
+--------------------+----------------------------------------+
```

### MCP Notification Types

```
+------------------------------------+---------------------------+
| Notification                       | Purpose                   |
+------------------------------------+---------------------------+
| notifications/initialized          | Initialization complete   |
| notifications/cancelled            | Cancel a request          |
| notifications/progress             | Progress update           |
| notifications/message              | Log message               |
| notifications/resources/updated    | Resource content changed  |
| notifications/resources/list_changed| Resource list changed    |
| notifications/tools/list_changed   | Tool list changed         |
| notifications/prompts/list_changed | Prompt list changed       |
| notifications/roots/list_changed   | Root list changed         |
+------------------------------------+---------------------------+
```

---

## Best Practices

### 1. ID Generation

```python
import uuid
import itertools

# Simple incrementing IDs
id_counter = itertools.count(start=1)
request_id = next(id_counter)

# UUID-based IDs (for distributed systems)
request_id = str(uuid.uuid4())

# Prefixed IDs (for debugging)
request_id = f"req-{next(id_counter)}"
```

### 2. Validation

Always validate incoming messages:

```python
def validate_jsonrpc_message(msg: dict) -> bool:
    # Check jsonrpc version
    if msg.get("jsonrpc") != "2.0":
        return False
    
    # If has 'id', it's a request or response
    if "id" in msg:
        if "method" in msg:
            # It's a request
            return isinstance(msg["method"], str)
        elif "result" in msg or "error" in msg:
            # It's a response
            return True
    else:
        # It's a notification (no id)
        if "method" in msg:
            return isinstance(msg["method"], str)
    
    return False
```

### 3. Message Framing

When sending over streams, messages need framing:

```
# Newline-delimited (stdio transport)
{"jsonrpc":"2.0","id":1,"method":"test"}\n
{"jsonrpc":"2.0","id":2,"method":"test2"}\n

# HTTP (one message per request/response)
POST /mcp HTTP/1.1
Content-Type: application/json

{"jsonrpc":"2.0","id":1,"method":"test"}
```

---

## Summary

| Message Type | Has ID | Expects Response | Use Case |
|--------------|--------|------------------|----------|
| Request | Yes | Yes | Invoke method, get result |
| Response | Yes (matches request) | No | Return result/error |
| Notification | No | No | Fire-and-forget events |

Understanding these message formats is essential for:
- Building MCP servers and clients
- Debugging protocol issues
- Implementing custom transports
- Writing protocol analyzers

---

## Next Steps

- [Request-Response Patterns](./_02_request_response_patterns.md) - Deep dive into request handling
- [Notifications](./_03_notifications.md) - Understanding notification patterns
- [Error Handling](./_04_error_handling.md) - Handling errors properly
