# Error Handling in MCP

## Overview

Proper error handling is crucial for building robust MCP applications. MCP uses the JSON-RPC 2.0 error format, with additional MCP-specific error codes. This document covers the error format, standard and custom error codes, and best practices for handling errors.

---

## JSON-RPC 2.0 Error Format

### Error Response Structure

When a request fails, the response contains an `error` object instead of a `result`:

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "error": {
    "code": -32600,
    "message": "Invalid Request",
    "data": {
      "details": "Additional error information"
    }
  }
}
```

### Error Object Fields

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `code` | integer | Yes | Numeric error code |
| `message` | string | Yes | Short error description |
| `data` | any | No | Additional error details |

### Mutual Exclusivity

A response MUST have either `result` OR `error`, never both:

```
+---------------------------+---------------------------+
|     SUCCESS RESPONSE      |      ERROR RESPONSE       |
+---------------------------+---------------------------+
| {                         | {                         |
|   "jsonrpc": "2.0",       |   "jsonrpc": "2.0",       |
|   "id": 1,                |   "id": 1,                |
|   "result": {...}         |   "error": {...}          |
| }                         | }                         |
+---------------------------+---------------------------+
| result present            | error present             |
| error absent              | result absent             |
+---------------------------+---------------------------+
```

---

## Standard JSON-RPC Error Codes

JSON-RPC 2.0 reserves error codes from -32700 to -32600:

```
+--------+----------------------+----------------------------------------+
| Code   | Name                 | Description                            |
+--------+----------------------+----------------------------------------+
| -32700 | Parse error          | Invalid JSON received                  |
| -32600 | Invalid Request      | JSON is not a valid request object     |
| -32601 | Method not found     | Method does not exist or unavailable   |
| -32602 | Invalid params       | Invalid method parameters              |
| -32603 | Internal error       | Internal JSON-RPC error                |
+--------+----------------------+----------------------------------------+
| -32000 | Server error (start) | Reserved for implementation-defined    |
| to     |                      | server errors                          |
| -32099 | Server error (end)   |                                        |
+--------+----------------------+----------------------------------------+
```

### Example: Parse Error (-32700)

Invalid JSON was received:

```json
// Sent (malformed JSON):
{"jsonrpc": "2.0", "id": 1, "method": "test"

// Response:
{
  "jsonrpc": "2.0",
  "id": null,
  "error": {
    "code": -32700,
    "message": "Parse error",
    "data": {
      "position": 42,
      "expected": "}"
    }
  }
}
```

### Example: Invalid Request (-32600)

JSON is valid but not a proper JSON-RPC request:

```json
// Sent (missing method):
{"jsonrpc": "2.0", "id": 1}

// Response:
{
  "jsonrpc": "2.0",
  "id": 1,
  "error": {
    "code": -32600,
    "message": "Invalid Request",
    "data": {
      "missing": "method"
    }
  }
}
```

### Example: Method Not Found (-32601)

```json
// Sent:
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "nonexistent/method"
}

// Response:
{
  "jsonrpc": "2.0",
  "id": 1,
  "error": {
    "code": -32601,
    "message": "Method not found",
    "data": {
      "method": "nonexistent/method"
    }
  }
}
```

### Example: Invalid Params (-32602)

```json
// Sent (missing required parameter):
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "tools/call",
  "params": {
    "arguments": {"x": 1}
  }
}

// Response:
{
  "jsonrpc": "2.0",
  "id": 1,
  "error": {
    "code": -32602,
    "message": "Invalid params",
    "data": {
      "missing": ["name"],
      "hint": "The 'name' parameter is required for tools/call"
    }
  }
}
```

### Example: Internal Error (-32603)

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "error": {
    "code": -32603,
    "message": "Internal error",
    "data": {
      "exception": "DatabaseConnectionError",
      "detail": "Failed to connect to database"
    }
  }
}
```

---

## MCP-Specific Error Codes

MCP extends JSON-RPC with additional error codes in the -32000 to -32099 range:

```
+--------+---------------------+------------------------------------------+
| Code   | Name                | Description                              |
+--------+---------------------+------------------------------------------+
| -32800 | Request cancelled   | Request was cancelled by client          |
| -32801 | Content too large   | Content exceeds size limits              |
| -32802 | Resource not found  | Requested resource doesn't exist         |
| -32803 | Resource busy       | Resource is temporarily unavailable      |
+--------+---------------------+------------------------------------------+
```

### Example: Request Cancelled (-32800)

```json
{
  "jsonrpc": "2.0",
  "id": 42,
  "error": {
    "code": -32800,
    "message": "Request cancelled",
    "data": {
      "reason": "User cancelled the operation"
    }
  }
}
```

### Example: Content Too Large (-32801)

```json
{
  "jsonrpc": "2.0",
  "id": 5,
  "error": {
    "code": -32801,
    "message": "Content too large",
    "data": {
      "size": 10485760,
      "maxSize": 1048576,
      "unit": "bytes"
    }
  }
}
```

### Example: Resource Not Found (-32802)

```json
{
  "jsonrpc": "2.0",
  "id": 3,
  "error": {
    "code": -32802,
    "message": "Resource not found",
    "data": {
      "uri": "file:///nonexistent/path.txt"
    }
  }
}
```

---

## Error Response Structure in Detail

### Minimal Error Response

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "error": {
    "code": -32600,
    "message": "Invalid Request"
  }
}
```

### Error Response with Data

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "error": {
    "code": -32602,
    "message": "Invalid params",
    "data": {
      "path": "params.arguments.count",
      "expected": "integer",
      "received": "string",
      "value": "five"
    }
  }
}
```

### Error Response with Structured Data

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "error": {
    "code": -32603,
    "message": "Internal error",
    "data": {
      "type": "ValidationError",
      "errors": [
        {"field": "email", "message": "Invalid email format"},
        {"field": "age", "message": "Must be positive"}
      ],
      "timestamp": "2024-01-15T10:30:00Z",
      "requestId": "req-abc123"
    }
  }
}
```

---

## Tool Call Errors

Tool calls have a special error handling pattern. The `tools/call` response can indicate errors in two ways:

### 1. Protocol-Level Error (JSON-RPC Error)

The tool call itself failed at the protocol level:

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "error": {
    "code": -32601,
    "message": "Method not found",
    "data": {
      "tool": "unknown_tool"
    }
  }
}
```

### 2. Tool Execution Error (isError in Result)

The tool executed but returned an error:

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "result": {
    "content": [
      {
        "type": "text",
        "text": "Error: Division by zero is not allowed"
      }
    ],
    "isError": true
  }
}
```

### Handling Both Error Types

```python
async def call_tool_safely(client, tool_name: str, arguments: dict):
    """Call a tool and handle both error types"""
    try:
        result = await client.send_request("tools/call", {
            "name": tool_name,
            "arguments": arguments
        })
        
        # Check for tool-level error
        if result.get("isError", False):
            error_text = extract_error_text(result.get("content", []))
            raise ToolExecutionError(tool_name, error_text)
        
        return result
        
    except MCPError as e:
        # Protocol-level error
        if e.code == -32601:
            raise ToolNotFoundError(tool_name)
        elif e.code == -32602:
            raise InvalidToolArgumentsError(tool_name, e.message)
        else:
            raise

def extract_error_text(content: list) -> str:
    """Extract error text from content array"""
    for item in content:
        if item.get("type") == "text":
            return item.get("text", "Unknown error")
    return "Unknown error"
```

---

## Error Handling Implementation

### Error Classes

```python
from dataclasses import dataclass
from typing import Optional, Any, Dict

@dataclass
class MCPError(Exception):
    """Base MCP error"""
    code: int
    message: str
    data: Optional[Any] = None
    
    def to_dict(self) -> Dict:
        """Convert to JSON-RPC error object"""
        error = {
            "code": self.code,
            "message": self.message
        }
        if self.data is not None:
            error["data"] = self.data
        return error
    
    @classmethod
    def from_dict(cls, error_dict: Dict) -> "MCPError":
        """Create from JSON-RPC error object"""
        return cls(
            code=error_dict["code"],
            message=error_dict["message"],
            data=error_dict.get("data")
        )


# Standard JSON-RPC errors
class ParseError(MCPError):
    def __init__(self, data: Any = None):
        super().__init__(-32700, "Parse error", data)

class InvalidRequest(MCPError):
    def __init__(self, data: Any = None):
        super().__init__(-32600, "Invalid Request", data)

class MethodNotFound(MCPError):
    def __init__(self, method: str):
        super().__init__(-32601, "Method not found", {"method": method})

class InvalidParams(MCPError):
    def __init__(self, message: str = "Invalid params", data: Any = None):
        super().__init__(-32602, message, data)

class InternalError(MCPError):
    def __init__(self, message: str = "Internal error", data: Any = None):
        super().__init__(-32603, message, data)


# MCP-specific errors
class RequestCancelled(MCPError):
    def __init__(self, reason: str = None):
        super().__init__(-32800, "Request cancelled", {"reason": reason})

class ContentTooLarge(MCPError):
    def __init__(self, size: int, max_size: int):
        super().__init__(-32801, "Content too large", {
            "size": size,
            "maxSize": max_size
        })

class ResourceNotFound(MCPError):
    def __init__(self, uri: str):
        super().__init__(-32802, "Resource not found", {"uri": uri})
```

### Error Handler

```python
from typing import Callable, Dict, Type

class ErrorHandler:
    """Handle errors with appropriate responses"""
    
    def __init__(self):
        self._handlers: Dict[int, Callable] = {}
        self._type_handlers: Dict[Type[Exception], Callable] = {}
    
    def register_code_handler(
        self, 
        code: int, 
        handler: Callable[[MCPError], Any]
    ):
        """Register handler for specific error code"""
        self._handlers[code] = handler
    
    def register_type_handler(
        self, 
        exc_type: Type[Exception], 
        handler: Callable[[Exception], Any]
    ):
        """Register handler for exception type"""
        self._type_handlers[exc_type] = handler
    
    def handle(self, error: Exception) -> Any:
        """Handle an error"""
        if isinstance(error, MCPError):
            if error.code in self._handlers:
                return self._handlers[error.code](error)
        
        for exc_type, handler in self._type_handlers.items():
            if isinstance(error, exc_type):
                return handler(error)
        
        # Default: re-raise
        raise error


# Usage
handler = ErrorHandler()

handler.register_code_handler(-32601, lambda e: 
    print(f"Method not found: {e.data.get('method')}")
)

handler.register_code_handler(-32800, lambda e:
    print(f"Request cancelled: {e.data.get('reason')}")
)

handler.register_type_handler(TimeoutError, lambda e:
    print("Request timed out, retrying...")
)
```

### Retry Logic

```python
import asyncio
from typing import TypeVar, Callable, Awaitable

T = TypeVar('T')

class RetryPolicy:
    """Configurable retry policy"""
    
    def __init__(
        self,
        max_retries: int = 3,
        base_delay: float = 1.0,
        max_delay: float = 30.0,
        exponential_backoff: bool = True,
        retryable_codes: set = None
    ):
        self.max_retries = max_retries
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.exponential_backoff = exponential_backoff
        self.retryable_codes = retryable_codes or {-32603, -32803}
    
    def is_retryable(self, error: MCPError) -> bool:
        """Check if error is retryable"""
        return error.code in self.retryable_codes
    
    def get_delay(self, attempt: int) -> float:
        """Calculate delay for attempt"""
        if self.exponential_backoff:
            delay = self.base_delay * (2 ** attempt)
        else:
            delay = self.base_delay
        return min(delay, self.max_delay)


async def with_retry(
    func: Callable[[], Awaitable[T]],
    policy: RetryPolicy = None
) -> T:
    """Execute function with retry logic"""
    policy = policy or RetryPolicy()
    
    last_error = None
    for attempt in range(policy.max_retries + 1):
        try:
            return await func()
        except MCPError as e:
            last_error = e
            
            if not policy.is_retryable(e):
                raise
            
            if attempt < policy.max_retries:
                delay = policy.get_delay(attempt)
                await asyncio.sleep(delay)
    
    raise last_error


# Usage
async def fetch_with_retry(client, uri):
    async def do_fetch():
        return await client.send_request("resources/read", {"uri": uri})
    
    return await with_retry(do_fetch, RetryPolicy(
        max_retries=3,
        retryable_codes={-32603, -32803}
    ))
```

---

## Error Handling Best Practices

### 1. Always Check for Errors

```python
# Good: Check both success and error
async def safe_request(client, method, params):
    try:
        result = await client.send_request(method, params)
        return result
    except MCPError as e:
        logger.error(f"Request failed: {e.code} - {e.message}")
        raise

# Bad: Assume success
async def unsafe_request(client, method, params):
    result = await client.send_request(method, params)
    return result["tools"]  # May raise KeyError if error response
```

### 2. Provide Meaningful Error Data

```python
# Good: Rich error information
raise InvalidParams(
    message="Invalid date format",
    data={
        "field": "start_date",
        "received": "2024-13-45",
        "expected": "ISO 8601 format (YYYY-MM-DD)",
        "example": "2024-01-15"
    }
)

# Bad: Vague error
raise InvalidParams()  # No context
```

### 3. Map Errors to User-Friendly Messages

```python
ERROR_MESSAGES = {
    -32700: "Unable to process request: Invalid format",
    -32600: "Request was not properly formatted",
    -32601: "This operation is not supported",
    -32602: "Some required information was missing or invalid",
    -32603: "An unexpected error occurred. Please try again.",
    -32800: "The operation was cancelled",
    -32801: "The requested data is too large to process",
    -32802: "The requested item could not be found",
}

def get_user_message(error: MCPError) -> str:
    """Get user-friendly error message"""
    return ERROR_MESSAGES.get(error.code, "An error occurred")
```

### 4. Log Errors with Context

```python
import logging
import traceback

logger = logging.getLogger("mcp")

def log_error(error: MCPError, context: dict = None):
    """Log error with full context"""
    log_data = {
        "code": error.code,
        "message": error.message,
        "data": error.data,
        "context": context,
    }
    
    if error.code in {-32603, -32700}:
        # Internal errors - log full traceback
        logger.error(f"MCP Error: {log_data}", exc_info=True)
    else:
        # Expected errors - info level
        logger.info(f"MCP Error: {log_data}")
```

### 5. Handle Errors at Appropriate Levels

```python
class MCPClient:
    async def call_tool(self, name: str, arguments: dict):
        """Call tool with layered error handling"""
        try:
            result = await self._send_request("tools/call", {
                "name": name,
                "arguments": arguments
            })
            return result
        except MCPError as e:
            # Transport/protocol errors - handle or re-raise
            if e.code == -32601:
                raise ToolNotFoundError(name) from e
            raise


class Application:
    async def process_user_request(self, request):
        """Application-level error handling"""
        try:
            result = await self.client.call_tool("process", request)
            return {"success": True, "data": result}
        except ToolNotFoundError:
            return {"success": False, "error": "Feature not available"}
        except MCPError as e:
            log_error(e, {"request": request})
            return {"success": False, "error": get_user_message(e)}
```

---

## Error Flow Diagrams

### Request Error Flow

```
    Client                              Server
       |                                   |
       |  tools/call (id:1)                |
       |  name: "invalid_tool"             |
       |  ==============================>  |
       |                                   |
       |                                   |  [Tool not found]
       |                                   |
       |  <==============================  |
       |  {                                |
       |    "id": 1,                       |
       |    "error": {                     |
       |      "code": -32601,              |
       |      "message": "Method not found"|
       |    }                              |
       |  }                                |
       |                                   |
       |  [Client handles error]           |
       |                                   |
```

### Error with Retry

```
    Client                              Server
       |                                   |
       |  request (id:1)                   |
       |  ==============================>  |
       |                                   |
       |  <==============================  |
       |  error: -32603 (Internal)         |
       |                                   |
       |  [Wait 1 second]                  |
       |                                   |
       |  request (id:2, retry)            |
       |  ==============================>  |
       |                                   |
       |  <==============================  |
       |  result: {...}                    |
       |                                   |
```

---

## Common Error Scenarios

### 1. Tool Not Found

```json
// Request
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "tools/call",
  "params": {
    "name": "nonexistent_tool",
    "arguments": {}
  }
}

// Response
{
  "jsonrpc": "2.0",
  "id": 1,
  "error": {
    "code": -32601,
    "message": "Method not found",
    "data": {
      "tool": "nonexistent_tool",
      "availableTools": ["get_weather", "search", "calculate"]
    }
  }
}
```

### 2. Invalid Tool Arguments

```json
// Request
{
  "jsonrpc": "2.0",
  "id": 2,
  "method": "tools/call",
  "params": {
    "name": "get_weather",
    "arguments": {
      "city": 12345
    }
  }
}

// Response
{
  "jsonrpc": "2.0",
  "id": 2,
  "error": {
    "code": -32602,
    "message": "Invalid params",
    "data": {
      "field": "city",
      "expected": "string",
      "received": "number"
    }
  }
}
```

### 3. Resource Not Found

```json
// Request
{
  "jsonrpc": "2.0",
  "id": 3,
  "method": "resources/read",
  "params": {
    "uri": "file:///does/not/exist.txt"
  }
}

// Response
{
  "jsonrpc": "2.0",
  "id": 3,
  "error": {
    "code": -32802,
    "message": "Resource not found",
    "data": {
      "uri": "file:///does/not/exist.txt"
    }
  }
}
```

### 4. Server Internal Error

```json
{
  "jsonrpc": "2.0",
  "id": 4,
  "error": {
    "code": -32603,
    "message": "Internal error",
    "data": {
      "type": "DatabaseError",
      "message": "Connection refused",
      "retryable": true,
      "retryAfter": 5
    }
  }
}
```

---

## Summary

### Error Code Reference

| Code | Name | Retryable | Action |
|------|------|-----------|--------|
| -32700 | Parse error | No | Fix JSON |
| -32600 | Invalid Request | No | Fix request format |
| -32601 | Method not found | No | Check method name |
| -32602 | Invalid params | No | Fix parameters |
| -32603 | Internal error | Maybe | Retry with backoff |
| -32800 | Cancelled | No | User cancelled |
| -32801 | Content too large | No | Reduce content size |
| -32802 | Resource not found | No | Check resource URI |
| -32803 | Resource busy | Yes | Retry after delay |

### Key Takeaways

1. Always handle both protocol errors and tool execution errors
2. Provide rich error data for debugging
3. Map errors to user-friendly messages
4. Implement retry logic for transient errors
5. Log errors with full context
6. Handle errors at appropriate abstraction levels

---

## Next Steps

- [Protocol in Action](./_05_protocol_in_action.ipynb) - Hands-on error handling examples
