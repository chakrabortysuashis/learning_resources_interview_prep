# MCP Prompts

Prompts are pre-defined templates that servers can expose to help users interact with LLMs in structured, reusable ways. They provide standardized workflows for common tasks.

---

## Table of Contents

1. [What Are MCP Prompts](#what-are-mcp-prompts)
2. [Prompt Templates and Arguments](#prompt-templates-and-arguments)
3. [Multi-Message Prompts](#multi-message-prompts)
4. [Use Cases for Prompts](#use-cases-for-prompts)
5. [Prompt Listing and Retrieval](#prompt-listing-and-retrieval)
6. [JSON Examples](#json-examples)
7. [Best Practices](#best-practices)

---

## What Are MCP Prompts

Prompts are **user-facing templates** that define structured interactions with the LLM. Unlike tools (called by the LLM) or resources (read by the LLM), prompts are selected by users to initiate specific workflows.

```
+------------------------------------------------------------------+
|                     WHAT ARE PROMPTS?                             |
+------------------------------------------------------------------+
|                                                                   |
|  Prompts are USER-SELECTABLE templates for LLM interactions       |
|                                                                   |
|  +------------------+     +------------------+                     |
|  |      User        |     |    MCP Server    |                     |
|  |                  |     |                  |                     |
|  |  +-----------+   |     |   +-----------+  |                     |
|  |  |  Select   |---|--->-|-->|  Prompt   |  |                     |
|  |  |  Prompt   |   |     |   | Template  |  |                     |
|  |  +-----------+   |     |   +-----------+  |                     |
|  |       |          |     |        |         |                     |
|  |       v          |     |        v         |                     |
|  |  +-----------+   |     |   +-----------+  |                     |
|  |  | Fill Args |   |     |   | Generate  |  |                     |
|  |  +-----------+   |     |   | Messages  |  |                     |
|  |       |          |     |   +-----------+  |                     |
|  |       v          |     |        |         |                     |
|  |  +-----------+   |     |        v         |                     |
|  |  | LLM Chat  |<--|--<--|<-- Messages      |                     |
|  |  +-----------+   |     |                  |                     |
|  |                  |     |                  |                     |
|  +------------------+     +------------------+                     |
|                                                                   |
|  Examples of Prompts:                                             |
|  - "Code Review" - Review code for issues                         |
|  - "Explain Code" - Get explanation of complex code               |
|  - "Generate Tests" - Create unit tests for a function            |
|  - "Debug Error" - Help diagnose and fix an error                 |
|  - "Summarize Document" - Create a summary of content             |
|                                                                   |
+------------------------------------------------------------------+
```

### Key Characteristics

| Property | Description |
|----------|-------------|
| **User-facing** | Selected by users, not invoked by LLM |
| **Parameterized** | Can accept arguments to customize behavior |
| **Multi-message** | Can include system, user, and assistant messages |
| **Reusable** | Same prompt can be used with different arguments |
| **Workflow-oriented** | Guide specific tasks or interactions |

### Prompts vs Tools vs Resources

```
+------------------------------------------------------------------+
|               COMPONENT COMPARISON                                |
+------------------------------------------------------------------+
|                                                                   |
|  RESOURCES         TOOLS             PROMPTS                      |
|  ---------         -----             -------                      |
|                                                                   |
|  "Here's data      "Do this          "Let's have this             |
|   to read"          action"           conversation"               |
|                                                                   |
|  Passive           Active            Interactive                  |
|  Read by LLM       Called by LLM     Selected by User             |
|  Context           Function          Template                     |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Prompt Templates and Arguments

Prompts can define arguments that users provide to customize the interaction.

### Argument Structure

```json
{
  "name": "code_review",
  "description": "Review code for best practices, bugs, and improvements",
  "arguments": [
    {
      "name": "language",
      "description": "Programming language of the code",
      "required": true
    },
    {
      "name": "focus",
      "description": "What aspect to focus on (security, performance, readability)",
      "required": false
    },
    {
      "name": "code",
      "description": "The code to review",
      "required": true
    }
  ]
}
```

### Argument Properties

```
+------------------------------------------------------------------+
|                  ARGUMENT PROPERTIES                              |
+------------------------------------------------------------------+
|                                                                   |
|  {                                                                |
|    "name": "language",          <-- Identifier (required)         |
|                                                                   |
|    "description": "...",        <-- Help text (optional)          |
|                                                                   |
|    "required": true             <-- Is this mandatory? (optional) |
|  }                                                                |
|                                                                   |
|  Note: Unlike tools, prompts use simple argument definitions      |
|  rather than full JSON Schema. The arguments are typically        |
|  strings provided by the user.                                    |
|                                                                   |
+------------------------------------------------------------------+
```

### Argument Examples

```json
{
  "arguments": [
    {
      "name": "file_path",
      "description": "Path to the file to analyze",
      "required": true
    },
    {
      "name": "language",
      "description": "Programming language (auto-detected if not provided)",
      "required": false
    },
    {
      "name": "verbosity",
      "description": "Level of detail: 'brief', 'normal', or 'detailed'",
      "required": false
    }
  ]
}
```

---

## Multi-Message Prompts

Prompts can generate multiple messages to set up a complete conversation context.

### Message Structure

```
+------------------------------------------------------------------+
|                    PROMPT MESSAGES                                |
+------------------------------------------------------------------+
|                                                                   |
|  A prompt can generate messages with different roles:             |
|                                                                   |
|  +------------------+                                             |
|  |  SYSTEM MESSAGE  |  Sets context and instructions              |
|  +------------------+                                             |
|           |                                                       |
|           v                                                       |
|  +------------------+                                             |
|  |   USER MESSAGE   |  The user's request (with embedded args)    |
|  +------------------+                                             |
|           |                                                       |
|           v                                                       |
|  +------------------+                                             |
|  | ASSISTANT MSG    |  (Optional) Pre-filled assistant response   |
|  +------------------+                                             |
|                                                                   |
|  This creates a complete conversation starter for the LLM.        |
|                                                                   |
+------------------------------------------------------------------+
```

### Message Types

```json
{
  "messages": [
    {
      "role": "system",
      "content": {
        "type": "text",
        "text": "You are an expert code reviewer..."
      }
    },
    {
      "role": "user",
      "content": {
        "type": "text",
        "text": "Please review this code:\n\n```python\n{code}\n```"
      }
    }
  ]
}
```

### Content Types in Messages

Messages can include different content types:

**Text Content:**
```json
{
  "type": "text",
  "text": "Please review this Python code for security issues."
}
```

**Resource Content (Embedded):**
```json
{
  "type": "resource",
  "resource": {
    "uri": "file:///project/src/auth.py",
    "mimeType": "text/x-python",
    "text": "def authenticate(username, password):\n    ..."
  }
}
```

**Image Content:**
```json
{
  "type": "image",
  "data": "iVBORw0KGgoAAAANSUhEUgAAAAEAAAAB...",
  "mimeType": "image/png"
}
```

---

## Use Cases for Prompts

### 1. Code Review Workflow

```json
{
  "name": "code_review",
  "description": "Comprehensive code review for quality and best practices",
  "arguments": [
    {
      "name": "code",
      "description": "The code to review",
      "required": true
    },
    {
      "name": "language",
      "description": "Programming language",
      "required": true
    },
    {
      "name": "focus_areas",
      "description": "Comma-separated areas: security, performance, readability, testing",
      "required": false
    }
  ]
}
```

### 2. Documentation Generator

```json
{
  "name": "generate_docs",
  "description": "Generate documentation for code or APIs",
  "arguments": [
    {
      "name": "code",
      "description": "Code or API definition to document",
      "required": true
    },
    {
      "name": "style",
      "description": "Documentation style: docstring, markdown, jsdoc",
      "required": false
    },
    {
      "name": "audience",
      "description": "Target audience: developers, end-users, api-consumers",
      "required": false
    }
  ]
}
```

### 3. Bug Investigation

```json
{
  "name": "debug_error",
  "description": "Help diagnose and fix errors or bugs",
  "arguments": [
    {
      "name": "error_message",
      "description": "The error message or stack trace",
      "required": true
    },
    {
      "name": "context",
      "description": "Additional context about when the error occurs",
      "required": false
    },
    {
      "name": "code",
      "description": "Relevant code that may be causing the error",
      "required": false
    }
  ]
}
```

### 4. Test Generation

```json
{
  "name": "generate_tests",
  "description": "Generate unit tests for code",
  "arguments": [
    {
      "name": "code",
      "description": "The code to write tests for",
      "required": true
    },
    {
      "name": "framework",
      "description": "Testing framework: pytest, jest, junit, etc.",
      "required": false
    },
    {
      "name": "coverage",
      "description": "Coverage focus: edge-cases, happy-path, comprehensive",
      "required": false
    }
  ]
}
```

### 5. Data Analysis

```json
{
  "name": "analyze_data",
  "description": "Analyze data and provide insights",
  "arguments": [
    {
      "name": "data",
      "description": "The data to analyze (CSV, JSON, or description)",
      "required": true
    },
    {
      "name": "question",
      "description": "Specific question to answer about the data",
      "required": false
    },
    {
      "name": "output_format",
      "description": "Desired output: summary, charts, report",
      "required": false
    }
  ]
}
```

---

## Prompt Listing and Retrieval

### Listing Available Prompts

**Request:**
```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "prompts/list"
}
```

**Response:**
```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "result": {
    "prompts": [
      {
        "name": "code_review",
        "description": "Review code for bugs, security issues, and best practices",
        "arguments": [
          {
            "name": "code",
            "description": "The code to review",
            "required": true
          },
          {
            "name": "language",
            "description": "Programming language",
            "required": false
          }
        ]
      },
      {
        "name": "explain_code",
        "description": "Get a detailed explanation of how code works",
        "arguments": [
          {
            "name": "code",
            "description": "The code to explain",
            "required": true
          }
        ]
      },
      {
        "name": "generate_tests",
        "description": "Generate unit tests for the given code",
        "arguments": [
          {
            "name": "code",
            "description": "The code to test",
            "required": true
          },
          {
            "name": "framework",
            "description": "Testing framework to use",
            "required": false
          }
        ]
      }
    ]
  }
}
```

### Getting a Specific Prompt

**Request:**
```json
{
  "jsonrpc": "2.0",
  "id": 2,
  "method": "prompts/get",
  "params": {
    "name": "code_review",
    "arguments": {
      "code": "def calculate_sum(numbers):\n    total = 0\n    for n in numbers:\n        total += n\n    return total",
      "language": "python"
    }
  }
}
```

**Response:**
```json
{
  "jsonrpc": "2.0",
  "id": 2,
  "result": {
    "description": "Review code for bugs, security issues, and best practices",
    "messages": [
      {
        "role": "system",
        "content": {
          "type": "text",
          "text": "You are an expert code reviewer with deep knowledge of software engineering best practices, security vulnerabilities, and performance optimization. Provide constructive, actionable feedback."
        }
      },
      {
        "role": "user",
        "content": {
          "type": "text",
          "text": "Please review this Python code:\n\n```python\ndef calculate_sum(numbers):\n    total = 0\n    for n in numbers:\n        total += n\n    return total\n```\n\nProvide feedback on:\n1. Code correctness\n2. Best practices\n3. Potential improvements\n4. Any bugs or issues"
        }
      }
    ]
  }
}
```

---

## JSON Examples

### Complete Prompt Definition

```json
{
  "name": "technical_interview_prep",
  "description": "Practice technical interview questions with feedback",
  "arguments": [
    {
      "name": "topic",
      "description": "Topic area: algorithms, system-design, behavioral",
      "required": true
    },
    {
      "name": "difficulty",
      "description": "Difficulty level: easy, medium, hard",
      "required": false
    },
    {
      "name": "company_style",
      "description": "Company interview style: FAANG, startup, enterprise",
      "required": false
    }
  ]
}
```

### Prompt with Multiple Message Types

```json
{
  "description": "Code review with context",
  "messages": [
    {
      "role": "system",
      "content": {
        "type": "text",
        "text": "You are a senior software engineer conducting a code review. Be thorough but constructive. Focus on maintainability, security, and performance."
      }
    },
    {
      "role": "user",
      "content": {
        "type": "text",
        "text": "I need you to review the following code changes. Here's the project context:"
      }
    },
    {
      "role": "user",
      "content": {
        "type": "resource",
        "resource": {
          "uri": "file:///project/README.md",
          "mimeType": "text/markdown",
          "text": "# Project Name\n\nThis is a REST API for user management..."
        }
      }
    },
    {
      "role": "user",
      "content": {
        "type": "text",
        "text": "And here's the code to review:"
      }
    },
    {
      "role": "user",
      "content": {
        "type": "resource",
        "resource": {
          "uri": "file:///project/src/users.py",
          "mimeType": "text/x-python",
          "text": "def create_user(data):\n    # implementation here\n    pass"
        }
      }
    }
  ]
}
```

### Prompt with Pre-filled Assistant Message

Sometimes you want to guide the assistant's response format:

```json
{
  "description": "Structured code analysis",
  "messages": [
    {
      "role": "system",
      "content": {
        "type": "text",
        "text": "Analyze code and provide structured feedback in the exact format specified."
      }
    },
    {
      "role": "user",
      "content": {
        "type": "text",
        "text": "Analyze this code and provide feedback in a structured format:\n\n```python\ndef process_data(items):\n    result = []\n    for item in items:\n        if item > 0:\n            result.append(item * 2)\n    return result\n```"
      }
    },
    {
      "role": "assistant",
      "content": {
        "type": "text",
        "text": "## Code Analysis\n\n### Summary\n"
      }
    }
  ]
}
```

### Dynamic Prompt with Resource Embedding

```json
{
  "name": "explain_file",
  "description": "Get an explanation of a source file",
  "arguments": [
    {
      "name": "file_uri",
      "description": "URI of the file to explain",
      "required": true
    }
  ]
}
```

When retrieved with arguments, the server dynamically loads the resource:

```json
{
  "messages": [
    {
      "role": "system",
      "content": {
        "type": "text",
        "text": "You are a helpful coding assistant. Explain code clearly and thoroughly."
      }
    },
    {
      "role": "user",
      "content": {
        "type": "text",
        "text": "Please explain this file:"
      }
    },
    {
      "role": "user",
      "content": {
        "type": "resource",
        "resource": {
          "uri": "file:///project/src/auth.py",
          "mimeType": "text/x-python",
          "text": "import jwt\nimport bcrypt\n\nclass AuthManager:\n    def __init__(self, secret_key):\n        self.secret_key = secret_key\n    \n    def hash_password(self, password):\n        return bcrypt.hashpw(password.encode(), bcrypt.gensalt())\n    \n    def verify_password(self, password, hashed):\n        return bcrypt.checkpw(password.encode(), hashed)\n    \n    def create_token(self, user_id):\n        return jwt.encode({'user_id': user_id}, self.secret_key, algorithm='HS256')"
        }
      }
    }
  ]
}
```

---

## Best Practices

### 1. Write Clear Descriptions

```
+------------------------------------------------------------------+
|                  DESCRIPTION GUIDELINES                           |
+------------------------------------------------------------------+
|                                                                   |
|  GOOD:                                                            |
|  "Review code for bugs, security vulnerabilities, and best        |
|   practices. Provides actionable feedback with severity levels    |
|   and suggested fixes."                                           |
|                                                                   |
|  BAD:                                                             |
|  "Code review"                                                    |
|                                                                   |
|  Your description should help users understand:                   |
|  - What the prompt does                                           |
|  - What kind of output to expect                                  |
|  - When to use this prompt vs others                              |
|                                                                   |
+------------------------------------------------------------------+
```

### 2. Document Arguments Thoroughly

```json
{
  "arguments": [
    {
      "name": "verbosity",
      "description": "Output detail level. Use 'brief' for quick summaries, 'normal' for standard output, or 'detailed' for comprehensive analysis with examples",
      "required": false
    }
  ]
}
```

### 3. Design Effective System Messages

```
+------------------------------------------------------------------+
|                 SYSTEM MESSAGE TIPS                               |
+------------------------------------------------------------------+
|                                                                   |
|  A good system message should:                                    |
|                                                                   |
|  1. Define the assistant's role and expertise                     |
|     "You are an expert Python developer with 10+ years of         |
|      experience in security and performance optimization."        |
|                                                                   |
|  2. Set expectations for output format                            |
|     "Provide feedback in markdown format with severity levels:    |
|      CRITICAL, WARNING, SUGGESTION."                              |
|                                                                   |
|  3. Establish tone and approach                                   |
|     "Be constructive and educational. Explain the 'why' behind    |
|      each suggestion."                                            |
|                                                                   |
|  4. Include any constraints                                       |
|     "Focus only on the code provided. Do not suggest              |
|      architectural changes unless explicitly asked."              |
|                                                                   |
+------------------------------------------------------------------+
```

### 4. Use Resources for Context

Instead of expecting users to paste large amounts of code:

```json
{
  "messages": [
    {
      "role": "user",
      "content": {
        "type": "resource",
        "resource": {
          "uri": "file:///project/src/main.py",
          "mimeType": "text/x-python",
          "text": "..."
        }
      }
    }
  ]
}
```

### 5. Consider Prompt Composability

Design prompts that can work with various resource types:

```json
{
  "name": "analyze",
  "description": "Analyze any code file for issues and improvements",
  "arguments": [
    {
      "name": "file",
      "description": "File path or content to analyze (supports multiple languages)",
      "required": true
    }
  ]
}
```

### 6. Provide Sensible Defaults

```json
{
  "arguments": [
    {
      "name": "max_issues",
      "description": "Maximum issues to report (default: 10)",
      "required": false
    },
    {
      "name": "severity_threshold",
      "description": "Minimum severity to report: low, medium, high (default: low)",
      "required": false
    }
  ]
}
```

---

## Prompt Flow Summary

```
+------------------------------------------------------------------+
|                  COMPLETE PROMPT FLOW                             |
+------------------------------------------------------------------+
|                                                                   |
|  1. DISCOVERY                                                     |
|     Client calls prompts/list                                     |
|     User sees available prompts                                   |
|                                                                   |
|  2. SELECTION                                                     |
|     User selects a prompt                                         |
|     User provides required arguments                              |
|                                                                   |
|  3. RETRIEVAL                                                     |
|     Client calls prompts/get with name and arguments              |
|     Server returns generated messages                             |
|                                                                   |
|  4. CONVERSATION                                                  |
|     Messages are sent to the LLM                                  |
|     LLM responds based on the structured prompt                   |
|                                                                   |
|  5. INTERACTION                                                   |
|     User continues the conversation                               |
|     Context from prompt guides the interaction                    |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Summary

```
+------------------------------------------------------------------+
|                      KEY TAKEAWAYS                                |
+------------------------------------------------------------------+
|                                                                   |
|  1. Prompts are user-selectable templates for LLM interactions    |
|                                                                   |
|  2. Arguments allow customization:                                |
|     - name: identifier                                            |
|     - description: help text                                      |
|     - required: mandatory or optional                             |
|                                                                   |
|  3. Prompts generate messages:                                    |
|     - system: sets context and instructions                       |
|     - user: the request with embedded arguments                   |
|     - assistant: optional pre-filled response                     |
|                                                                   |
|  4. Content types in messages:                                    |
|     - text: plain text content                                    |
|     - resource: embedded file/data content                        |
|     - image: base64-encoded images                                |
|                                                                   |
|  5. Best practices:                                               |
|     - Clear descriptions                                          |
|     - Thorough argument documentation                             |
|     - Effective system messages                                   |
|     - Resource embedding for context                              |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Next Steps

Continue to [Sampling](./_05_sampling.md) to learn about server-initiated LLM requests.
