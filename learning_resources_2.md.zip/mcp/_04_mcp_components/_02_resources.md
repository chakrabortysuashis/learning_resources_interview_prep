# MCP Resources

Resources are a fundamental primitive in MCP that allow servers to expose data and content to clients. They represent any kind of data that an LLM might need as context for understanding or completing tasks.

---

## Table of Contents

1. [What Are MCP Resources](#what-are-mcp-resources)
2. [Resource URIs](#resource-uris)
3. [Static vs Dynamic Resources](#static-vs-dynamic-resources)
4. [Resource Templates](#resource-templates)
5. [Resource Subscriptions](#resource-subscriptions)
6. [JSON Examples](#json-examples)
7. [Best Practices](#best-practices)

---

## What Are MCP Resources

Resources provide **contextual data** that servers want to make available to clients. Think of them as "things the LLM should know about" rather than "things the LLM should do."

```
+------------------------------------------------------------------+
|                     WHAT ARE RESOURCES?                           |
+------------------------------------------------------------------+
|                                                                   |
|  Resources are READ-ONLY data that servers expose to clients      |
|                                                                   |
|  +------------------+     +------------------+                     |
|  |    MCP Server    |     |   MCP Client     |                     |
|  |                  |     |                  |                     |
|  |  +-----------+   |     |   +-----------+  |                     |
|  |  | Resource  |---|--->-|-->|  Context  |  |                     |
|  |  |   Data    |   |     |   |   for LLM |  |                     |
|  |  +-----------+   |     |   +-----------+  |                     |
|  |                  |     |                  |                     |
|  +------------------+     +------------------+                     |
|                                                                   |
|  Examples of Resources:                                           |
|  - File contents (source code, configs, docs)                     |
|  - Database schemas and sample data                               |
|  - API documentation and responses                                |
|  - System information and metrics                                 |
|  - User preferences and settings                                  |
|                                                                   |
+------------------------------------------------------------------+
```

### Key Characteristics

| Property | Description |
|----------|-------------|
| **Read-only** | Clients can read but not modify resources directly |
| **URI-addressed** | Each resource has a unique URI identifier |
| **Typed** | Resources have MIME types (text/plain, application/json, etc.) |
| **Named** | Human-readable names for display purposes |
| **Described** | Optional descriptions explain what the resource contains |

---

## Resource URIs

Every resource is identified by a unique URI (Uniform Resource Identifier). MCP supports various URI schemes:

```
+------------------------------------------------------------------+
|                     RESOURCE URI FORMATS                          |
+------------------------------------------------------------------+
|                                                                   |
|  Standard Schemes:                                                |
|  +--------------------------------------------------------------+ |
|  | file://    | Local filesystem paths                          | |
|  | http://    | Web resources                                    | |
|  | https://   | Secure web resources                            | |
|  +--------------------------------------------------------------+ |
|                                                                   |
|  Custom Schemes (server-defined):                                 |
|  +--------------------------------------------------------------+ |
|  | db://      | Database resources                               | |
|  | git://     | Git repository content                           | |
|  | config://  | Configuration data                               | |
|  | memory://  | In-memory data                                   | |
|  | custom://  | Any custom scheme your server defines            | |
|  +--------------------------------------------------------------+ |
|                                                                   |
+------------------------------------------------------------------+
```

### URI Examples

```
File Resources:
  file:///home/user/project/README.md
  file:///C:/Users/dev/project/config.json

Database Resources:
  db://mydb/users/schema
  db://mydb/tables/orders

Git Resources:
  git://repo/main/src/app.py
  git://repo/commits/abc123

Custom Resources:
  config://app/settings
  metrics://server/cpu
  docs://api/v2/endpoints
```

### URI Structure

```
+------------------------------------------------------------------+
|                      URI ANATOMY                                  |
+------------------------------------------------------------------+
|                                                                   |
|     scheme://authority/path?query#fragment                        |
|     |        |          |    |      |                             |
|     |        |          |    |      +-- Optional fragment         |
|     |        |          |    +--------- Optional query params     |
|     |        |          +-------------- Resource path             |
|     |        +------------------------- Optional authority        |
|     +---------------------------------- Protocol scheme           |
|                                                                   |
|  Example: db://production/users/schema?version=2                  |
|           |    |          |            |                          |
|           |    |          |            +-- Query: version=2       |
|           |    |          +--------------- Path: users/schema     |
|           |    +-------------------------- Authority: production  |
|           +------------------------------- Scheme: db             |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Static vs Dynamic Resources

MCP supports both static resources (listed upfront) and dynamic resources (generated on demand).

### Static Resources

Static resources are listed when the client calls `resources/list`. They exist as fixed entities:

```
+------------------------------------------------------------------+
|                     STATIC RESOURCES                              |
+------------------------------------------------------------------+
|                                                                   |
|  Client                              Server                       |
|    |                                   |                          |
|    |  resources/list                   |                          |
|    |---------------------------------->|                          |
|    |                                   |                          |
|    |  [                                |                          |
|    |    { uri: "file:///config.json" },|                          |
|    |    { uri: "file:///schema.sql" }, |                          |
|    |    { uri: "docs://api/reference" }|                          |
|    |  ]                                |                          |
|    |<----------------------------------|                          |
|    |                                   |                          |
|    |  resources/read (uri)             |                          |
|    |---------------------------------->|                          |
|    |                                   |                          |
|    |  { contents: [...] }              |                          |
|    |<----------------------------------|                          |
|                                                                   |
+------------------------------------------------------------------+
```

**Static Resource JSON:**

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "result": {
    "resources": [
      {
        "uri": "file:///project/README.md",
        "name": "Project README",
        "description": "Main documentation for the project",
        "mimeType": "text/markdown"
      },
      {
        "uri": "file:///project/config.json",
        "name": "Configuration",
        "description": "Application configuration file",
        "mimeType": "application/json"
      },
      {
        "uri": "db://app/schema",
        "name": "Database Schema",
        "description": "Current database table definitions",
        "mimeType": "text/plain"
      }
    ]
  }
}
```

### Dynamic Resources

Dynamic resources are generated based on templates and parameters. They don't exist until requested:

```
+------------------------------------------------------------------+
|                    DYNAMIC RESOURCES                              |
+------------------------------------------------------------------+
|                                                                   |
|  Client                              Server                       |
|    |                                   |                          |
|    |  resources/templates/list         |                          |
|    |---------------------------------->|                          |
|    |                                   |                          |
|    |  [                                |                          |
|    |    { uriTemplate: "db://{table}" }|                          |
|    |  ]                                |                          |
|    |<----------------------------------|                          |
|    |                                   |                          |
|    |  resources/read                   |                          |
|    |  (uri: "db://users")              |    Generate              |
|    |---------------------------------->|----> resource            |
|    |                                   |      on-the-fly          |
|    |  { contents: [...] }              |                          |
|    |<----------------------------------|                          |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Resource Templates

Resource templates allow servers to expose parameterized resources using URI templates (RFC 6570).

### Template Structure

```json
{
  "uriTemplate": "db://{database}/tables/{table}",
  "name": "Database Table",
  "description": "Access any table in any database",
  "mimeType": "application/json"
}
```

### Template Parameters

```
+------------------------------------------------------------------+
|                   URI TEMPLATE SYNTAX                             |
+------------------------------------------------------------------+
|                                                                   |
|  Basic Variable:                                                  |
|    db://{table}                                                   |
|    -> db://users                                                  |
|    -> db://orders                                                 |
|                                                                   |
|  Multiple Variables:                                              |
|    file://{project}/{path}                                        |
|    -> file://myapp/src/main.py                                    |
|    -> file://myapp/config.json                                    |
|                                                                   |
|  Path Segments:                                                   |
|    git://{repo}/commits/{sha}                                     |
|    -> git://myrepo/commits/abc123                                 |
|                                                                   |
+------------------------------------------------------------------+
```

### Resource Templates Response

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "result": {
    "resourceTemplates": [
      {
        "uriTemplate": "file://{project}/src/{filepath}",
        "name": "Project Source File",
        "description": "Access source files from any project",
        "mimeType": "text/plain"
      },
      {
        "uriTemplate": "db://{database}/tables/{table}/schema",
        "name": "Table Schema",
        "description": "Get the schema for any database table"
      },
      {
        "uriTemplate": "logs://{service}/{date}",
        "name": "Service Logs",
        "description": "Access logs for a service on a specific date",
        "mimeType": "text/plain"
      }
    ]
  }
}
```

---

## Resource Subscriptions

Clients can subscribe to resources to receive notifications when they change.

### Subscription Flow

```
+------------------------------------------------------------------+
|                  RESOURCE SUBSCRIPTION                            |
+------------------------------------------------------------------+
|                                                                   |
|  Client                              Server                       |
|    |                                   |                          |
|    |  1. resources/subscribe           |                          |
|    |     { uri: "file:///config.json" }|                          |
|    |---------------------------------->|                          |
|    |                                   |                          |
|    |  2. { success: true }             |                          |
|    |<----------------------------------|                          |
|    |                                   |                          |
|    |         ... time passes ...       |                          |
|    |         ... file changes ...      |                          |
|    |                                   |                          |
|    |  3. notifications/resources/      |                          |
|    |     updated                       |                          |
|    |     { uri: "file:///config.json" }|                          |
|    |<----------------------------------|                          |
|    |                                   |                          |
|    |  4. resources/read                |                          |
|    |     { uri: "file:///config.json" }|                          |
|    |---------------------------------->|                          |
|    |                                   |                          |
|    |  5. { contents: [...] }           |                          |
|    |<----------------------------------|                          |
|                                                                   |
+------------------------------------------------------------------+
```

### Subscription Request

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "resources/subscribe",
  "params": {
    "uri": "file:///project/config.json"
  }
}
```

### Resource Updated Notification

```json
{
  "jsonrpc": "2.0",
  "method": "notifications/resources/updated",
  "params": {
    "uri": "file:///project/config.json"
  }
}
```

### List Changed Notification

When the overall list of resources changes:

```json
{
  "jsonrpc": "2.0",
  "method": "notifications/resources/list_changed"
}
```

### Unsubscribe

```json
{
  "jsonrpc": "2.0",
  "id": 2,
  "method": "resources/unsubscribe",
  "params": {
    "uri": "file:///project/config.json"
  }
}
```

---

## JSON Examples

### Complete Resource List Response

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "result": {
    "resources": [
      {
        "uri": "file:///project/README.md",
        "name": "README",
        "description": "Project documentation and setup instructions",
        "mimeType": "text/markdown"
      },
      {
        "uri": "file:///project/package.json",
        "name": "Package Configuration",
        "description": "NPM package dependencies and scripts",
        "mimeType": "application/json"
      },
      {
        "uri": "db://production/schema",
        "name": "Production Database Schema",
        "description": "Current production database table definitions",
        "mimeType": "text/plain"
      },
      {
        "uri": "config://app/settings",
        "name": "Application Settings",
        "description": "Runtime configuration for the application",
        "mimeType": "application/json",
        "annotations": {
          "audience": ["developer", "admin"]
        }
      }
    ]
  }
}
```

### Resource Read Request

```json
{
  "jsonrpc": "2.0",
  "id": 2,
  "method": "resources/read",
  "params": {
    "uri": "file:///project/README.md"
  }
}
```

### Resource Read Response (Text Content)

```json
{
  "jsonrpc": "2.0",
  "id": 2,
  "result": {
    "contents": [
      {
        "uri": "file:///project/README.md",
        "mimeType": "text/markdown",
        "text": "# My Project\n\nThis is a sample project...\n\n## Installation\n\n```bash\nnpm install\n```"
      }
    ]
  }
}
```

### Resource Read Response (Binary/Blob Content)

```json
{
  "jsonrpc": "2.0",
  "id": 3,
  "result": {
    "contents": [
      {
        "uri": "file:///project/logo.png",
        "mimeType": "image/png",
        "blob": "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=="
      }
    ]
  }
}
```

### Resource with Annotations

```json
{
  "uri": "config://app/secrets",
  "name": "Application Secrets",
  "description": "Sensitive configuration data",
  "mimeType": "application/json",
  "annotations": {
    "audience": ["admin"],
    "priority": 0.3
  }
}
```

---

## Best Practices

### 1. Use Meaningful URIs

```
+------------------------------------------------------------------+
|                    URI NAMING CONVENTIONS                         |
+------------------------------------------------------------------+
|                                                                   |
|  GOOD URIs:                                                       |
|  +--------------------------------------------------------------+ |
|  | file:///project/src/components/Button.tsx                    | |
|  | db://production/users/schema                                 | |
|  | docs://api/v2/authentication                                 | |
|  | config://app/database/connection                             | |
|  +--------------------------------------------------------------+ |
|                                                                   |
|  AVOID:                                                           |
|  +--------------------------------------------------------------+ |
|  | resource://1234                    (Not descriptive)         | |
|  | file://x                           (Too vague)               | |
|  | data://stuff                       (Meaningless)             | |
|  +--------------------------------------------------------------+ |
|                                                                   |
+------------------------------------------------------------------+
```

### 2. Provide Rich Metadata

```json
{
  "uri": "db://production/orders",
  "name": "Orders Table",
  "description": "E-commerce orders with customer and product references. Updated in real-time.",
  "mimeType": "application/json",
  "annotations": {
    "audience": ["analyst", "developer"],
    "priority": 0.8,
    "refreshRate": "realtime"
  }
}
```

### 3. Use Templates for Dynamic Content

```json
{
  "resourceTemplates": [
    {
      "uriTemplate": "logs://{service}/{level}/{date}",
      "name": "Service Logs",
      "description": "Filter logs by service, level (info/warn/error), and date (YYYY-MM-DD)"
    }
  ]
}
```

### 4. Implement Subscriptions for Live Data

```
+------------------------------------------------------------------+
|            WHEN TO USE SUBSCRIPTIONS                              |
+------------------------------------------------------------------+
|                                                                   |
|  USE subscriptions for:                                           |
|  - Configuration files that may change                            |
|  - Live data feeds                                                |
|  - Collaborative documents                                        |
|  - System metrics                                                 |
|                                                                   |
|  DON'T use subscriptions for:                                     |
|  - Static documentation                                           |
|  - Historical data                                                |
|  - Large binary files                                             |
|                                                                   |
+------------------------------------------------------------------+
```

### 5. Handle Content Types Correctly

```
+------------------------------------------------------------------+
|                  CONTENT TYPE HANDLING                            |
+------------------------------------------------------------------+
|                                                                   |
|  Text Content (use "text" field):                                 |
|  - text/plain                                                     |
|  - text/markdown                                                  |
|  - text/html                                                      |
|  - application/json                                               |
|  - application/xml                                                |
|  - text/csv                                                       |
|                                                                   |
|  Binary Content (use "blob" field with base64):                   |
|  - image/png                                                      |
|  - image/jpeg                                                     |
|  - application/pdf                                                |
|  - application/octet-stream                                       |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Resource Flow Summary

```
+------------------------------------------------------------------+
|                 COMPLETE RESOURCE FLOW                            |
+------------------------------------------------------------------+
|                                                                   |
|  1. DISCOVERY                                                     |
|     Client calls resources/list                                   |
|     Client calls resources/templates/list                         |
|                                                                   |
|  2. SELECTION                                                     |
|     User or LLM selects relevant resources                        |
|     For templates, fill in URI parameters                         |
|                                                                   |
|  3. READING                                                       |
|     Client calls resources/read with URI                          |
|     Server returns content (text or blob)                         |
|                                                                   |
|  4. SUBSCRIPTION (optional)                                       |
|     Client subscribes to resources                                |
|     Server sends notifications on changes                         |
|                                                                   |
|  5. CONTEXT                                                       |
|     Resource content is provided to LLM as context                |
|     LLM uses this information for understanding and responses     |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Next Steps

Continue to [Tools](./_03_tools.md) to learn about executable functions in MCP.
