# MCP Tools

Tools are the action-oriented primitive in MCP. They allow servers to expose executable functions that LLMs can invoke to perform operations, retrieve dynamic data, or interact with external systems.

---

## Table of Contents

1. [What Are MCP Tools](#what-are-mcp-tools)
2. [Tool Definition Structure](#tool-definition-structure)
3. [JSON Schema for Parameters](#json-schema-for-parameters)
4. [Tool Execution Flow](#tool-execution-flow)
5. [Returning Results and Errors](#returning-results-and-errors)
6. [Common Tool Patterns](#common-tool-patterns)
7. [Best Practices](#best-practices)

---

## What Are MCP Tools

Tools represent **executable functions** that servers expose to clients. Unlike resources (which provide read-only context), tools can:

- Execute code and perform actions
- Modify state (create, update, delete)
- Call external APIs
- Return dynamic results

```
+------------------------------------------------------------------+
|                      WHAT ARE TOOLS?                              |
+------------------------------------------------------------------+
|                                                                   |
|  Tools are EXECUTABLE FUNCTIONS that the LLM can invoke           |
|                                                                   |
|  +------------------+     +------------------+                     |
|  |   MCP Client     |     |    MCP Server    |                     |
|  |                  |     |                  |                     |
|  |  +-----------+   |     |   +-----------+  |                     |
|  |  |    LLM    |---|--->-|-->|   Tool    |  |                     |
|  |  | (decides) |   |     |   | (executes)|  |                     |
|  |  +-----------+   |     |   +-----------+  |                     |
|  |       ^          |     |        |         |                     |
|  |       |          |     |        v         |                     |
|  |  +-----------+   |     |   +-----------+  |                     |
|  |  |  Result   |<--|--<--|<--|  Action   |  |                     |
|  |  +-----------+   |     |   +-----------+  |                     |
|  |                  |     |                  |                     |
|  +------------------+     +------------------+                     |
|                                                                   |
|  Examples of Tools:                                               |
|  - search_database(query, limit)                                  |
|  - send_email(to, subject, body)                                  |
|  - create_file(path, content)                                     |
|  - run_command(command)                                           |
|  - call_api(endpoint, method, data)                               |
|                                                                   |
+------------------------------------------------------------------+
```

### Key Characteristics

| Property | Description |
|----------|-------------|
| **Executable** | Tools run code and return results |
| **Parameterized** | Accept input defined by JSON Schema |
| **Named** | Unique identifier for invocation |
| **Described** | Natural language description helps LLM understand usage |
| **Potentially Dangerous** | May have side effects, require human approval |

---

## Tool Definition Structure

Every tool has three required components:

```
+------------------------------------------------------------------+
|                   TOOL DEFINITION ANATOMY                         |
+------------------------------------------------------------------+
|                                                                   |
|  {                                                                |
|    "name": "search_users",          <-- Unique identifier         |
|                                                                   |
|    "description": "Search for...",  <-- What it does (for LLM)    |
|                                                                   |
|    "inputSchema": {                 <-- Parameter definitions     |
|      "type": "object",                                            |
|      "properties": { ... },                                       |
|      "required": [ ... ]                                          |
|    }                                                              |
|  }                                                                |
|                                                                   |
+------------------------------------------------------------------+
```

### Complete Tool Definition Example

```json
{
  "name": "search_users",
  "description": "Search for users in the database by name, email, or ID. Returns matching user records with their profile information.",
  "inputSchema": {
    "type": "object",
    "properties": {
      "query": {
        "type": "string",
        "description": "Search term to match against user name or email"
      },
      "search_by": {
        "type": "string",
        "enum": ["name", "email", "id"],
        "description": "Field to search by",
        "default": "name"
      },
      "limit": {
        "type": "integer",
        "description": "Maximum number of results to return",
        "default": 10,
        "minimum": 1,
        "maximum": 100
      },
      "include_inactive": {
        "type": "boolean",
        "description": "Whether to include inactive users in results",
        "default": false
      }
    },
    "required": ["query"]
  }
}
```

### Tool List Response

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "result": {
    "tools": [
      {
        "name": "search_users",
        "description": "Search for users in the database",
        "inputSchema": {
          "type": "object",
          "properties": {
            "query": { "type": "string" },
            "limit": { "type": "integer", "default": 10 }
          },
          "required": ["query"]
        }
      },
      {
        "name": "create_user",
        "description": "Create a new user account",
        "inputSchema": {
          "type": "object",
          "properties": {
            "name": { "type": "string" },
            "email": { "type": "string", "format": "email" }
          },
          "required": ["name", "email"]
        }
      }
    ]
  }
}
```

---

## JSON Schema for Parameters

MCP uses JSON Schema to define tool input parameters. This provides:

- Type validation
- Constraints (min/max, patterns, enums)
- Default values
- Documentation

### Common JSON Schema Patterns

```
+------------------------------------------------------------------+
|                  JSON SCHEMA TYPES                                |
+------------------------------------------------------------------+
|                                                                   |
|  BASIC TYPES:                                                     |
|  +------------------------------------------------------------+  |
|  | string   | "hello"                                         |  |
|  | number   | 3.14                                            |  |
|  | integer  | 42                                              |  |
|  | boolean  | true                                            |  |
|  | null     | null                                            |  |
|  | array    | [1, 2, 3]                                       |  |
|  | object   | {"key": "value"}                                |  |
|  +------------------------------------------------------------+  |
|                                                                   |
|  CONSTRAINTS:                                                     |
|  +------------------------------------------------------------+  |
|  | enum         | Allowed values list                         |  |
|  | minimum      | Minimum number value                        |  |
|  | maximum      | Maximum number value                        |  |
|  | minLength    | Minimum string length                       |  |
|  | maxLength    | Maximum string length                       |  |
|  | pattern      | Regex pattern for strings                   |  |
|  | minItems     | Minimum array length                        |  |
|  | maxItems     | Maximum array length                        |  |
|  +------------------------------------------------------------+  |
|                                                                   |
+------------------------------------------------------------------+
```

### Schema Examples

**String with Constraints:**
```json
{
  "type": "string",
  "description": "User's email address",
  "format": "email",
  "maxLength": 255
}
```

**Number with Range:**
```json
{
  "type": "integer",
  "description": "Page number for pagination",
  "minimum": 1,
  "maximum": 1000,
  "default": 1
}
```

**Enum (Fixed Options):**
```json
{
  "type": "string",
  "description": "Sort order for results",
  "enum": ["asc", "desc"],
  "default": "asc"
}
```

**Array of Strings:**
```json
{
  "type": "array",
  "description": "Tags to filter by",
  "items": {
    "type": "string"
  },
  "minItems": 1,
  "maxItems": 10
}
```

**Nested Object:**
```json
{
  "type": "object",
  "description": "Filter criteria",
  "properties": {
    "status": {
      "type": "string",
      "enum": ["active", "inactive", "pending"]
    },
    "created_after": {
      "type": "string",
      "format": "date-time"
    }
  }
}
```

---

## Tool Execution Flow

```
+------------------------------------------------------------------+
|                   TOOL EXECUTION FLOW                             |
+------------------------------------------------------------------+
|                                                                   |
|  Client                   Server                                  |
|    |                        |                                     |
|    |  1. tools/list         |                                     |
|    |----------------------->|  Returns available tools            |
|    |                        |                                     |
|    |  2. [tool definitions] |                                     |
|    |<-----------------------|                                     |
|    |                        |                                     |
|    |  ... LLM conversation ..|                                     |
|    |  ... LLM decides to    |                                     |
|    |      call a tool ...   |                                     |
|    |                        |                                     |
|    |  3. tools/call         |                                     |
|    |  {                     |                                     |
|    |    name: "search",     |                                     |
|    |    arguments: {...}    |                                     |
|    |  }                     |                                     |
|    |----------------------->|  Validates & executes               |
|    |                        |                                     |
|    |  4. Result or Error    |                                     |
|    |<-----------------------|                                     |
|    |                        |                                     |
|    |  5. LLM processes      |                                     |
|    |     result and         |                                     |
|    |     continues          |                                     |
|    |                        |                                     |
+------------------------------------------------------------------+
```

### Tool Call Request

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "tools/call",
  "params": {
    "name": "search_users",
    "arguments": {
      "query": "john",
      "limit": 5,
      "include_inactive": false
    }
  }
}
```

### Progress Notifications

For long-running tools, servers can send progress updates:

```json
{
  "jsonrpc": "2.0",
  "method": "notifications/progress",
  "params": {
    "progressToken": "tool-123",
    "progress": 50,
    "total": 100
  }
}
```

---

## Returning Results and Errors

### Successful Result

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "result": {
    "content": [
      {
        "type": "text",
        "text": "Found 3 users matching 'john':\n1. John Doe (john.doe@example.com)\n2. Johnny Smith (johnny@example.com)\n3. John Connor (jconnor@example.com)"
      }
    ],
    "isError": false
  }
}
```

### Result with Structured Data

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "result": {
    "content": [
      {
        "type": "text",
        "text": "Query executed successfully. Found 3 matching users."
      },
      {
        "type": "resource",
        "resource": {
          "uri": "query://results/12345",
          "mimeType": "application/json",
          "text": "[{\"id\": 1, \"name\": \"John Doe\"}, {\"id\": 2, \"name\": \"Johnny Smith\"}]"
        }
      }
    ]
  }
}
```

### Result with Image

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "result": {
    "content": [
      {
        "type": "text",
        "text": "Generated chart showing user growth over time."
      },
      {
        "type": "image",
        "data": "iVBORw0KGgoAAAANSUhEUgAAAAEAAAAB...",
        "mimeType": "image/png"
      }
    ]
  }
}
```

### Tool Error (Application-Level)

When the tool executes but encounters an error:

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "result": {
    "content": [
      {
        "type": "text",
        "text": "Error: User 'john_doe_99' not found in database. The user may have been deleted or the ID may be incorrect."
      }
    ],
    "isError": true
  }
}
```

### Protocol Error

For invalid requests or system failures:

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "error": {
    "code": -32602,
    "message": "Invalid params",
    "data": {
      "details": "Required parameter 'query' is missing"
    }
  }
}
```

### Error Flow Diagram

```
+------------------------------------------------------------------+
|                    ERROR HANDLING                                 |
+------------------------------------------------------------------+
|                                                                   |
|                    Tool Call                                      |
|                        |                                          |
|            +-----------+-----------+                              |
|            |                       |                              |
|        Valid Request?          Invalid                            |
|            |                       |                              |
|            |               +---------------+                      |
|            |               | Protocol Error|                      |
|            |               | (code: -32602)|                      |
|            |               +---------------+                      |
|            |                                                      |
|        Execute Tool                                               |
|            |                                                      |
|    +-------+-------+                                              |
|    |               |                                              |
| Success          Failure                                          |
|    |               |                                              |
|    v               v                                              |
| +--------+    +------------+                                      |
| | Result |    | Result     |                                      |
| | isError|    | isError:   |                                      |
| | false  |    | true       |                                      |
| +--------+    +------------+                                      |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Common Tool Patterns

### 1. CRUD Operations

```json
{
  "tools": [
    {
      "name": "create_record",
      "description": "Create a new record in the database",
      "inputSchema": {
        "type": "object",
        "properties": {
          "table": { "type": "string" },
          "data": { "type": "object" }
        },
        "required": ["table", "data"]
      }
    },
    {
      "name": "read_record",
      "description": "Retrieve a record by ID",
      "inputSchema": {
        "type": "object",
        "properties": {
          "table": { "type": "string" },
          "id": { "type": "string" }
        },
        "required": ["table", "id"]
      }
    },
    {
      "name": "update_record",
      "description": "Update an existing record",
      "inputSchema": {
        "type": "object",
        "properties": {
          "table": { "type": "string" },
          "id": { "type": "string" },
          "data": { "type": "object" }
        },
        "required": ["table", "id", "data"]
      }
    },
    {
      "name": "delete_record",
      "description": "Delete a record by ID",
      "inputSchema": {
        "type": "object",
        "properties": {
          "table": { "type": "string" },
          "id": { "type": "string" }
        },
        "required": ["table", "id"]
      }
    }
  ]
}
```

### 2. Search and Query

```json
{
  "name": "advanced_search",
  "description": "Perform an advanced search with multiple filters and sorting options",
  "inputSchema": {
    "type": "object",
    "properties": {
      "query": {
        "type": "string",
        "description": "Full-text search query"
      },
      "filters": {
        "type": "object",
        "description": "Key-value pairs for filtering",
        "additionalProperties": true
      },
      "sort_by": {
        "type": "string",
        "description": "Field to sort results by"
      },
      "sort_order": {
        "type": "string",
        "enum": ["asc", "desc"],
        "default": "asc"
      },
      "page": {
        "type": "integer",
        "minimum": 1,
        "default": 1
      },
      "page_size": {
        "type": "integer",
        "minimum": 1,
        "maximum": 100,
        "default": 20
      }
    },
    "required": ["query"]
  }
}
```

### 3. External API Integration

```json
{
  "name": "call_external_api",
  "description": "Make a request to an external REST API",
  "inputSchema": {
    "type": "object",
    "properties": {
      "endpoint": {
        "type": "string",
        "description": "API endpoint path"
      },
      "method": {
        "type": "string",
        "enum": ["GET", "POST", "PUT", "DELETE", "PATCH"],
        "default": "GET"
      },
      "headers": {
        "type": "object",
        "description": "Request headers",
        "additionalProperties": { "type": "string" }
      },
      "body": {
        "type": "object",
        "description": "Request body for POST/PUT/PATCH"
      },
      "query_params": {
        "type": "object",
        "description": "URL query parameters",
        "additionalProperties": { "type": "string" }
      }
    },
    "required": ["endpoint"]
  }
}
```

### 4. File Operations

```json
{
  "tools": [
    {
      "name": "read_file",
      "description": "Read contents of a file",
      "inputSchema": {
        "type": "object",
        "properties": {
          "path": {
            "type": "string",
            "description": "Path to the file"
          },
          "encoding": {
            "type": "string",
            "enum": ["utf-8", "ascii", "base64"],
            "default": "utf-8"
          }
        },
        "required": ["path"]
      }
    },
    {
      "name": "write_file",
      "description": "Write content to a file",
      "inputSchema": {
        "type": "object",
        "properties": {
          "path": { "type": "string" },
          "content": { "type": "string" },
          "create_dirs": {
            "type": "boolean",
            "default": false,
            "description": "Create parent directories if they don't exist"
          }
        },
        "required": ["path", "content"]
      }
    },
    {
      "name": "list_files",
      "description": "List files in a directory",
      "inputSchema": {
        "type": "object",
        "properties": {
          "path": { "type": "string" },
          "pattern": {
            "type": "string",
            "description": "Glob pattern to filter files"
          },
          "recursive": {
            "type": "boolean",
            "default": false
          }
        },
        "required": ["path"]
      }
    }
  ]
}
```

### 5. Computation and Analysis

```json
{
  "name": "analyze_data",
  "description": "Perform statistical analysis on a dataset",
  "inputSchema": {
    "type": "object",
    "properties": {
      "data": {
        "type": "array",
        "items": { "type": "number" },
        "description": "Array of numerical values to analyze"
      },
      "operations": {
        "type": "array",
        "items": {
          "type": "string",
          "enum": ["mean", "median", "mode", "std_dev", "min", "max", "sum", "count"]
        },
        "description": "Statistical operations to perform"
      }
    },
    "required": ["data", "operations"]
  }
}
```

---

## Best Practices

### 1. Write Clear Descriptions

```
+------------------------------------------------------------------+
|                  DESCRIPTION BEST PRACTICES                       |
+------------------------------------------------------------------+
|                                                                   |
|  GOOD:                                                            |
|  "Search for users in the database by name, email, or ID.         |
|   Returns up to 'limit' matching records with profile info.       |
|   Use search_by='email' for exact email matching."                |
|                                                                   |
|  BAD:                                                             |
|  "Search users"                                                   |
|                                                                   |
|  The description should tell the LLM:                             |
|  - What the tool does                                             |
|  - What parameters affect behavior                                |
|  - What format the results will be in                             |
|  - Any important caveats or limitations                           |
|                                                                   |
+------------------------------------------------------------------+
```

### 2. Use Appropriate Parameter Types

```json
{
  "good_example": {
    "count": {
      "type": "integer",
      "minimum": 1,
      "maximum": 100
    }
  },
  "bad_example": {
    "count": {
      "type": "string"
    }
  }
}
```

### 3. Provide Sensible Defaults

```json
{
  "limit": {
    "type": "integer",
    "default": 10,
    "description": "Maximum results to return (default: 10)"
  }
}
```

### 4. Validate Input Thoroughly

```
+------------------------------------------------------------------+
|                    INPUT VALIDATION                               |
+------------------------------------------------------------------+
|                                                                   |
|  Use JSON Schema constraints:                                     |
|  - minimum/maximum for numbers                                    |
|  - minLength/maxLength for strings                                |
|  - pattern for format validation                                  |
|  - enum for fixed options                                         |
|  - required for mandatory fields                                  |
|                                                                   |
|  Also validate in your tool implementation:                       |
|  - Check for malicious input                                      |
|  - Verify permissions                                             |
|  - Sanitize for injection attacks                                 |
|                                                                   |
+------------------------------------------------------------------+
```

### 5. Return Informative Results

```json
{
  "content": [
    {
      "type": "text",
      "text": "Successfully created user 'john_doe' (ID: usr_12345).\n\nDetails:\n- Email: john@example.com\n- Created: 2024-01-15T10:30:00Z\n- Status: active\n\nNext steps: The user can now log in using their email."
    }
  ]
}
```

### 6. Handle Errors Gracefully

```json
{
  "content": [
    {
      "type": "text",
      "text": "Failed to create user: Email 'john@example.com' is already registered.\n\nSuggestions:\n1. Use a different email address\n2. Try the 'search_users' tool to find the existing account\n3. Use 'reset_password' if this is a forgotten account"
    }
  ],
  "isError": true
}
```

---

## Summary

```
+------------------------------------------------------------------+
|                      KEY TAKEAWAYS                                |
+------------------------------------------------------------------+
|                                                                   |
|  1. Tools are executable functions called by the LLM              |
|                                                                   |
|  2. Every tool needs:                                             |
|     - name: unique identifier                                     |
|     - description: what it does (for LLM understanding)           |
|     - inputSchema: JSON Schema defining parameters                |
|                                                                   |
|  3. Use JSON Schema features for validation:                      |
|     - types, enums, constraints, defaults                         |
|                                                                   |
|  4. Return results as content array with:                         |
|     - type: "text" for messages                                   |
|     - type: "resource" for structured data                        |
|     - type: "image" for visual content                            |
|                                                                   |
|  5. Use isError: true for application errors                      |
|     Use JSON-RPC error for protocol errors                        |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Next Steps

Continue to [Prompts](./_04_prompts.md) to learn about interaction templates in MCP.
