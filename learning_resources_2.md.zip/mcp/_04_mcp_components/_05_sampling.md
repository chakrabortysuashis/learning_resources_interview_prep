# MCP Sampling

Sampling is an advanced MCP feature that allows servers to request LLM completions through the client. This enables sophisticated agentic behaviors while maintaining security through human oversight.

---

## Table of Contents

1. [What is Sampling](#what-is-sampling)
2. [Server-Initiated LLM Requests](#server-initiated-llm-requests)
3. [Human-in-the-Loop Considerations](#human-in-the-loop-considerations)
4. [Security Implications](#security-implications)
5. [When and How to Use Sampling](#when-and-how-to-use-sampling)
6. [JSON Examples](#json-examples)
7. [Best Practices](#best-practices)

---

## What is Sampling

Sampling is the mechanism by which MCP servers can **request LLM completions from the client**. This inverts the normal flow where the LLM calls tools - instead, the server asks the client to generate text using the connected LLM.

```
+------------------------------------------------------------------+
|                      WHAT IS SAMPLING?                            |
+------------------------------------------------------------------+
|                                                                   |
|  NORMAL FLOW:                                                     |
|  +--------+    tool call    +--------+                            |
|  | Client |---------------->| Server |                            |
|  |  (LLM) |<----------------| (Tool) |                            |
|  +--------+    result       +--------+                            |
|                                                                   |
|  SAMPLING FLOW:                                                   |
|  +--------+   sampling req  +--------+                            |
|  | Client |<----------------| Server |                            |
|  |  (LLM) |---------------->| (Tool) |                            |
|  +--------+  LLM response   +--------+                            |
|                                                                   |
|  With sampling, the SERVER can ask the CLIENT to run an LLM       |
|  completion. This enables more sophisticated agentic workflows.   |
|                                                                   |
+------------------------------------------------------------------+
```

### Why Sampling Exists

Sampling enables several important patterns:

```
+------------------------------------------------------------------+
|                  SAMPLING USE CASES                               |
+------------------------------------------------------------------+
|                                                                   |
|  1. MULTI-STEP REASONING                                          |
|     Server breaks complex tasks into steps, using the LLM         |
|     for each sub-task                                             |
|                                                                   |
|  2. AGENTIC BEHAVIOR                                              |
|     Server can autonomously decide when it needs LLM help         |
|     without user intervention                                     |
|                                                                   |
|  3. DATA PROCESSING                                               |
|     Server processes large datasets, using LLM to analyze         |
|     individual items                                              |
|                                                                   |
|  4. CONTENT GENERATION                                            |
|     Server generates content (code, docs, tests) as part          |
|     of larger operations                                          |
|                                                                   |
|  5. DECISION MAKING                                               |
|     Server asks LLM to make decisions about next steps            |
|     in a workflow                                                 |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Server-Initiated LLM Requests

### The Sampling Request

When a server needs LLM assistance, it sends a `sampling/createMessage` request to the client:

```
+------------------------------------------------------------------+
|                  SAMPLING MESSAGE FLOW                            |
+------------------------------------------------------------------+
|                                                                   |
|  Server                         Client                            |
|    |                              |                               |
|    |  1. sampling/createMessage   |                               |
|    |  {                           |                               |
|    |    messages: [...],          |                               |
|    |    modelPreferences: {...}   |                               |
|    |  }                           |                               |
|    |----------------------------->|                               |
|    |                              |                               |
|    |                              |  2. (Human approval if        |
|    |                              |      required)                |
|    |                              |                               |
|    |                              |  3. Call LLM with messages    |
|    |                              |                               |
|    |  4. Response                 |                               |
|    |  {                           |                               |
|    |    role: "assistant",        |                               |
|    |    content: {...}            |                               |
|    |  }                           |                               |
|    |<-----------------------------|                               |
|    |                              |                               |
+------------------------------------------------------------------+
```

### Request Structure

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "sampling/createMessage",
  "params": {
    "messages": [
      {
        "role": "user",
        "content": {
          "type": "text",
          "text": "Analyze this error log and suggest a fix:\n\nTypeError: Cannot read property 'map' of undefined\n  at processItems (app.js:42)"
        }
      }
    ],
    "modelPreferences": {
      "hints": [
        { "name": "claude-3-5-sonnet" }
      ],
      "intelligencePriority": 0.8,
      "speedPriority": 0.2
    },
    "systemPrompt": "You are a debugging assistant. Analyze errors and suggest concise fixes.",
    "maxTokens": 500
  }
}
```

### Request Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `messages` | array | Yes | Conversation messages for the LLM |
| `modelPreferences` | object | No | Hints about which model to use |
| `systemPrompt` | string | No | System prompt for the LLM |
| `includeContext` | string | No | What context to include: "none", "thisServer", "allServers" |
| `maxTokens` | integer | Yes | Maximum tokens to generate |

### Model Preferences

```json
{
  "modelPreferences": {
    "hints": [
      { "name": "claude-3-5-sonnet" },
      { "name": "claude-3-haiku" }
    ],
    "costPriority": 0.3,
    "speedPriority": 0.5,
    "intelligencePriority": 0.7
  }
}
```

The client is free to choose any model - preferences are hints, not requirements.

---

## Human-in-the-Loop Considerations

Sampling was designed with human oversight as a core principle. The client controls whether and how sampling requests are fulfilled.

```
+------------------------------------------------------------------+
|                HUMAN-IN-THE-LOOP DESIGN                           |
+------------------------------------------------------------------+
|                                                                   |
|  SERVER                    CLIENT                    HUMAN        |
|    |                         |                         |          |
|    |  sampling request       |                         |          |
|    |------------------------>|                         |          |
|    |                         |                         |          |
|    |                         |  "Server X wants to     |          |
|    |                         |   generate a response.  |          |
|    |                         |   Allow?"               |          |
|    |                         |------------------------>|          |
|    |                         |                         |          |
|    |                         |         Approve         |          |
|    |                         |<------------------------|          |
|    |                         |                         |          |
|    |                         |  Call LLM               |          |
|    |                         |                         |          |
|    |  response               |                         |          |
|    |<------------------------|                         |          |
|    |                         |                         |          |
+------------------------------------------------------------------+
```

### Client Responsibilities

```
+------------------------------------------------------------------+
|             CLIENT RESPONSIBILITIES FOR SAMPLING                  |
+------------------------------------------------------------------+
|                                                                   |
|  1. APPROVAL CONTROL                                              |
|     - May require user approval for each request                  |
|     - May allow certain servers to sample automatically           |
|     - May deny sampling requests entirely                         |
|                                                                   |
|  2. REQUEST MODIFICATION                                          |
|     - Can modify the messages before sending to LLM               |
|     - Can add safety constraints                                  |
|     - Can inject additional context                               |
|                                                                   |
|  3. RESPONSE FILTERING                                            |
|     - Can filter or modify the LLM response                       |
|     - Can redact sensitive information                            |
|     - Can refuse to return certain content                        |
|                                                                   |
|  4. MODEL SELECTION                                               |
|     - Chooses which model to use (preferences are hints)          |
|     - May use a less capable model for security                   |
|     - Controls token limits and other parameters                  |
|                                                                   |
|  5. RATE LIMITING                                                 |
|     - Can limit how often servers can sample                      |
|     - Can set daily/hourly quotas                                 |
|     - Can prioritize certain servers                              |
|                                                                   |
+------------------------------------------------------------------+
```

### Approval Modes

Different clients may implement different approval strategies:

```
+------------------------------------------------------------------+
|                    APPROVAL STRATEGIES                            |
+------------------------------------------------------------------+
|                                                                   |
|  ALWAYS ASK:                                                      |
|  - Every sampling request requires explicit user approval         |
|  - Most secure, but interrupts workflow                           |
|  - Good for untrusted or new servers                              |
|                                                                   |
|  TRUST PER SERVER:                                                |
|  - User approves a server once                                    |
|  - Future requests from that server auto-approved                 |
|  - Balance of security and convenience                            |
|                                                                   |
|  TRUST PER SESSION:                                               |
|  - Auto-approve during current session                            |
|  - Reset on restart                                               |
|  - Good for interactive development                               |
|                                                                   |
|  ALWAYS ALLOW:                                                    |
|  - All sampling requests auto-approved                            |
|  - Least secure, maximum convenience                              |
|  - Only for fully trusted environments                            |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Security Implications

Sampling introduces unique security considerations because it allows servers to initiate LLM interactions.

### Potential Risks

```
+------------------------------------------------------------------+
|                    SECURITY RISKS                                 |
+------------------------------------------------------------------+
|                                                                   |
|  1. PROMPT INJECTION                                              |
|     Server could craft malicious prompts that cause the LLM       |
|     to reveal sensitive info or perform unwanted actions          |
|                                                                   |
|  2. RESOURCE EXHAUSTION                                           |
|     Server could make many sampling requests, consuming           |
|     API credits or causing rate limiting                          |
|                                                                   |
|  3. DATA EXFILTRATION                                             |
|     Server could use sampling to process and extract              |
|     sensitive data from the context                               |
|                                                                   |
|  4. UNAUTHORIZED ACTIONS                                          |
|     Server could use LLM responses to guide tool calls            |
|     that the user didn't intend                                   |
|                                                                   |
|  5. CONTEXT POLLUTION                                             |
|     Server could inject misleading context into the               |
|     conversation through sampling                                 |
|                                                                   |
+------------------------------------------------------------------+
```

### Mitigation Strategies

```
+------------------------------------------------------------------+
|                  SECURITY MITIGATIONS                             |
+------------------------------------------------------------------+
|                                                                   |
|  1. HUMAN APPROVAL                                                |
|     - Require approval for sampling requests                      |
|     - Show the prompt being sent to the LLM                       |
|     - Allow users to modify or reject requests                    |
|                                                                   |
|  2. CONTEXT ISOLATION                                             |
|     - Don't include sensitive context in sampling                 |
|     - Use includeContext: "none" when possible                    |
|     - Filter context before including                             |
|                                                                   |
|  3. RATE LIMITING                                                 |
|     - Limit sampling requests per server                          |
|     - Set maximum tokens per request                              |
|     - Track cumulative usage                                      |
|                                                                   |
|  4. RESPONSE FILTERING                                            |
|     - Scan responses for sensitive data                           |
|     - Redact PII or credentials                                   |
|     - Validate response format                                    |
|                                                                   |
|  5. AUDIT LOGGING                                                 |
|     - Log all sampling requests and responses                     |
|     - Track which servers use sampling                            |
|     - Alert on suspicious patterns                                |
|                                                                   |
+------------------------------------------------------------------+
```

### Security Flow

```
+------------------------------------------------------------------+
|                 SECURE SAMPLING FLOW                              |
+------------------------------------------------------------------+
|                                                                   |
|  Server                   Client                    Security      |
|    |                        |                          |          |
|    |  sampling request      |                          |          |
|    |----------------------->|                          |          |
|    |                        |                          |          |
|    |                        |  Validate request        |          |
|    |                        |------------------------->|          |
|    |                        |                          |          |
|    |                        |  Check rate limits       |          |
|    |                        |------------------------->|          |
|    |                        |                          |          |
|    |                        |  Filter context          |          |
|    |                        |------------------------->|          |
|    |                        |                          |          |
|    |                        |  Human approval          |          |
|    |                        |------------------------->|          |
|    |                        |                          |          |
|    |                        |  Call LLM                |          |
|    |                        |                          |          |
|    |                        |  Filter response         |          |
|    |                        |------------------------->|          |
|    |                        |                          |          |
|    |                        |  Log activity            |          |
|    |                        |------------------------->|          |
|    |                        |                          |          |
|    |  response              |                          |          |
|    |<-----------------------|                          |          |
|                                                                   |
+------------------------------------------------------------------+
```

---

## When and How to Use Sampling

### Appropriate Use Cases

```
+------------------------------------------------------------------+
|                  GOOD USE CASES FOR SAMPLING                      |
+------------------------------------------------------------------+
|                                                                   |
|  1. ITERATIVE REFINEMENT                                          |
|     Server generates content, uses LLM to improve it              |
|                                                                   |
|     Example: Generate code -> Ask LLM to review -> Fix issues     |
|                                                                   |
|  2. BATCH PROCESSING                                              |
|     Process many items, using LLM for each                        |
|                                                                   |
|     Example: Analyze 100 log entries, classify each one           |
|                                                                   |
|  3. DECISION GATES                                                |
|     Ask LLM to decide next steps in a workflow                    |
|                                                                   |
|     Example: "Should I deploy this change? Here's the diff..."    |
|                                                                   |
|  4. CONTENT TRANSFORMATION                                        |
|     Convert data between formats using LLM intelligence           |
|                                                                   |
|     Example: Convert API response to human-readable summary       |
|                                                                   |
|  5. ERROR RECOVERY                                                |
|     Ask LLM for help when something fails                         |
|                                                                   |
|     Example: "This query failed. Suggest an alternative."         |
|                                                                   |
+------------------------------------------------------------------+
```

### When NOT to Use Sampling

```
+------------------------------------------------------------------+
|                AVOID SAMPLING FOR                                 |
+------------------------------------------------------------------+
|                                                                   |
|  - Simple operations that don't need LLM intelligence             |
|  - High-frequency operations (use tools instead)                  |
|  - Operations where latency is critical                           |
|  - Situations where the user should make the decision             |
|  - When you need deterministic, reproducible results              |
|                                                                   |
+------------------------------------------------------------------+
```

### Implementation Example

Here's how a server might use sampling in a workflow:

```python
# Pseudocode for a code review server using sampling

async def review_code_tool(code: str, language: str):
    """Tool that uses sampling for intelligent code review."""
    
    # Step 1: Static analysis (no sampling needed)
    static_issues = run_linter(code, language)
    
    # Step 2: Use sampling for semantic analysis
    sampling_result = await client.create_message(
        messages=[
            {
                "role": "user",
                "content": {
                    "type": "text",
                    "text": f"""Analyze this {language} code for:
1. Potential bugs
2. Security issues
3. Performance problems

Code:
```{language}
{code}
```

Respond with a JSON array of issues found."""
                }
            }
        ],
        max_tokens=1000,
        system_prompt="You are a code analysis expert. Return only valid JSON."
    )
    
    # Step 3: Combine results
    semantic_issues = parse_json(sampling_result.content.text)
    
    return {
        "static_issues": static_issues,
        "semantic_issues": semantic_issues
    }
```

---

## JSON Examples

### Basic Sampling Request

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "sampling/createMessage",
  "params": {
    "messages": [
      {
        "role": "user",
        "content": {
          "type": "text",
          "text": "Summarize the following text in 2-3 sentences:\n\nLorem ipsum dolor sit amet..."
        }
      }
    ],
    "maxTokens": 200
  }
}
```

### Sampling with Model Preferences

```json
{
  "jsonrpc": "2.0",
  "id": 2,
  "method": "sampling/createMessage",
  "params": {
    "messages": [
      {
        "role": "user",
        "content": {
          "type": "text",
          "text": "Classify this support ticket: [ticket content]"
        }
      }
    ],
    "modelPreferences": {
      "hints": [
        { "name": "claude-3-haiku" }
      ],
      "speedPriority": 0.9,
      "intelligencePriority": 0.3,
      "costPriority": 0.8
    },
    "maxTokens": 50
  }
}
```

### Sampling with System Prompt

```json
{
  "jsonrpc": "2.0",
  "id": 3,
  "method": "sampling/createMessage",
  "params": {
    "messages": [
      {
        "role": "user",
        "content": {
          "type": "text",
          "text": "Input: SELECT * FROM users WHERE id = '1; DROP TABLE users;--'"
        }
      }
    ],
    "systemPrompt": "You are a SQL security analyzer. Identify SQL injection vulnerabilities and explain the risk. Respond with JSON: {\"vulnerable\": boolean, \"risk_level\": \"low|medium|high\", \"explanation\": string}",
    "maxTokens": 300
  }
}
```

### Sampling with Context Control

```json
{
  "jsonrpc": "2.0",
  "id": 4,
  "method": "sampling/createMessage",
  "params": {
    "messages": [
      {
        "role": "user",
        "content": {
          "type": "text",
          "text": "Based on the project context, suggest a name for this new function."
        }
      }
    ],
    "includeContext": "thisServer",
    "maxTokens": 100
  }
}
```

### Sampling Response

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "result": {
    "role": "assistant",
    "content": {
      "type": "text",
      "text": "The text discusses the origins and development of artificial intelligence, tracing its roots from early computational theories to modern machine learning. It emphasizes how recent advances in neural networks have accelerated AI capabilities. The main theme is the rapid evolution of AI technology over the past decade."
    },
    "model": "claude-3-5-sonnet-20241022",
    "stopReason": "end_turn"
  }
}
```

### Multi-turn Sampling

```json
{
  "jsonrpc": "2.0",
  "id": 5,
  "method": "sampling/createMessage",
  "params": {
    "messages": [
      {
        "role": "user",
        "content": {
          "type": "text",
          "text": "Here is a Python function:\n\ndef process(data):\n    return [x*2 for x in data]"
        }
      },
      {
        "role": "assistant",
        "content": {
          "type": "text",
          "text": "This function doubles each element in the input list."
        }
      },
      {
        "role": "user",
        "content": {
          "type": "text",
          "text": "Now add error handling for non-numeric inputs."
        }
      }
    ],
    "maxTokens": 500
  }
}
```

---

## Best Practices

### 1. Minimize Sampling Requests

```
+------------------------------------------------------------------+
|               REDUCE SAMPLING OVERHEAD                            |
+------------------------------------------------------------------+
|                                                                   |
|  - Batch multiple items into single requests when possible        |
|  - Use caching for repeated similar requests                      |
|  - Consider if the operation really needs LLM intelligence        |
|  - Use appropriate maxTokens to avoid waste                       |
|                                                                   |
+------------------------------------------------------------------+
```

### 2. Write Clear System Prompts

```json
{
  "systemPrompt": "You are a JSON extraction assistant. Extract the requested fields from the input text and return valid JSON only. Do not include explanations or markdown formatting."
}
```

### 3. Specify Output Format

```json
{
  "messages": [
    {
      "role": "user",
      "content": {
        "type": "text",
        "text": "Analyze this code and respond with JSON:\n{\"issues\": [{\"line\": number, \"severity\": \"low|medium|high\", \"description\": string}]}\n\nCode:\n..."
      }
    }
  ]
}
```

### 4. Handle Failures Gracefully

```python
try:
    result = await sampling_request(...)
except SamplingDeniedError:
    # User denied the request
    return fallback_result()
except SamplingTimeoutError:
    # Request took too long
    return timeout_result()
except SamplingError as e:
    # Other errors
    log_error(e)
    return error_result()
```

### 5. Respect User Privacy

```
+------------------------------------------------------------------+
|                  PRIVACY CONSIDERATIONS                           |
+------------------------------------------------------------------+
|                                                                   |
|  - Don't include sensitive data in sampling requests              |
|  - Use includeContext: "none" when context isn't needed           |
|  - Inform users what data will be sent to the LLM                 |
|  - Allow users to review requests before approval                 |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Summary

```
+------------------------------------------------------------------+
|                      KEY TAKEAWAYS                                |
+------------------------------------------------------------------+
|                                                                   |
|  1. Sampling allows servers to request LLM completions            |
|     - Enables agentic behaviors                                   |
|     - Supports complex multi-step workflows                       |
|                                                                   |
|  2. Human-in-the-loop is essential                                |
|     - Clients control approval                                    |
|     - Users can review and modify requests                        |
|     - Trust levels can be configured                              |
|                                                                   |
|  3. Security considerations                                       |
|     - Prompt injection risks                                      |
|     - Resource exhaustion                                         |
|     - Data exfiltration                                           |
|     - Rate limiting and filtering                                 |
|                                                                   |
|  4. Use sampling appropriately                                    |
|     - Iterative refinement                                        |
|     - Batch processing                                            |
|     - Decision gates                                              |
|     - Not for simple or high-frequency operations                 |
|                                                                   |
|  5. Best practices                                                |
|     - Minimize requests                                           |
|     - Clear system prompts                                        |
|     - Specify output format                                       |
|     - Handle failures gracefully                                  |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Next Steps

Continue to the [Hands-on Lab](./_06_components_hands_on.ipynb) to implement resources, tools, and prompts using FastMCP.
