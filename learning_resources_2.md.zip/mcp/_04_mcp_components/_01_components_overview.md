# MCP Components Overview

This module explores the three main primitives that make up the Model Context Protocol: **Resources**, **Tools**, and **Prompts**. Understanding these components is essential for building effective MCP servers and clients.

---

## Table of Contents

1. [The Three MCP Primitives](#the-three-mcp-primitives)
2. [Component Relationships](#component-relationships)
3. [Client vs Server Capabilities](#client-vs-server-capabilities)
4. [When to Use Which Component](#when-to-use-which-component)
5. [Component Comparison Table](#component-comparison-table)

---

## The Three MCP Primitives

MCP defines three fundamental building blocks that servers can expose to clients:

```
+------------------------------------------------------------------+
|                     MCP PRIMITIVES                                |
+------------------------------------------------------------------+
|                                                                   |
|  +------------------+  +------------------+  +------------------+ |
|  |    RESOURCES     |  |      TOOLS       |  |     PROMPTS      | |
|  +------------------+  +------------------+  +------------------+ |
|  |                  |  |                  |  |                  | |
|  |  Read-only data  |  |  Executable      |  |  User-facing     | |
|  |  exposed to LLM  |  |  functions that  |  |  templates for   | |
|  |                  |  |  perform actions |  |  interactions    | |
|  |  - File contents |  |                  |  |                  | |
|  |  - Database rows |  |  - Call APIs     |  |  - Workflows     | |
|  |  - API responses |  |  - Run queries   |  |  - Instructions  | |
|  |  - Live data     |  |  - Modify state  |  |  - Structured    | |
|  |                  |  |                  |  |    conversations | |
|  +------------------+  +------------------+  +------------------+ |
|                                                                   |
|       CONTEXT              ACTION              INTERACTION        |
|      (What to know)      (What to do)        (How to ask)        |
+------------------------------------------------------------------+
```

### 1. Resources - Contextual Data

**Resources** represent any kind of data that a server wants to make available to clients. They are:

- **Read-only**: Clients can read but not modify resources directly
- **URI-addressed**: Each resource has a unique identifier
- **Context providers**: They give the LLM information to work with

**Examples:**
- File contents from a filesystem
- Database records
- API responses
- Real-time metrics
- Configuration data

```json
{
  "resources": [
    {
      "uri": "file:///project/README.md",
      "name": "Project README",
      "mimeType": "text/markdown",
      "description": "Main project documentation"
    }
  ]
}
```

### 2. Tools - Executable Actions

**Tools** are functions that the LLM can invoke to perform actions. They are:

- **Executable**: They perform operations and return results
- **Schema-defined**: Input parameters are defined using JSON Schema
- **Action-oriented**: They change state or retrieve dynamic information

**Examples:**
- Execute database queries
- Call external APIs
- Send emails or notifications
- Perform calculations
- Create or modify files

```json
{
  "tools": [
    {
      "name": "search_database",
      "description": "Search for records in the database",
      "inputSchema": {
        "type": "object",
        "properties": {
          "query": { "type": "string" },
          "limit": { "type": "integer", "default": 10 }
        },
        "required": ["query"]
      }
    }
  ]
}
```

### 3. Prompts - Interaction Templates

**Prompts** are pre-defined templates for common interactions. They are:

- **User-facing**: Designed to be selected by users
- **Parameterized**: Can accept arguments to customize behavior
- **Workflow-oriented**: Help guide specific tasks or conversations

**Examples:**
- Code review template
- Bug report generator
- Documentation assistant
- Data analysis workflow

```json
{
  "prompts": [
    {
      "name": "code_review",
      "description": "Review code for best practices and issues",
      "arguments": [
        {
          "name": "language",
          "description": "Programming language of the code",
          "required": true
        }
      ]
    }
  ]
}
```

---

## Component Relationships

```
+-----------------------------------------------------------------------+
|                        MCP ARCHITECTURE                                |
+-----------------------------------------------------------------------+
|                                                                        |
|    CLIENT (Host Application)              SERVER (MCP Server)          |
|    +-----------------------+              +-----------------------+    |
|    |                       |              |                       |    |
|    |  +-----------------+  |   Request    |  +-----------------+  |    |
|    |  |   LLM / Model   |<-|--------------|->|   Resources     |  |    |
|    |  +-----------------+  |   Resources  |  |   (Data Layer)  |  |    |
|    |         |             |              |  +-----------------+  |    |
|    |         | Uses        |              |          |            |    |
|    |         v             |              |          | Provides   |    |
|    |  +-----------------+  |   Invoke     |  +-----------------+  |    |
|    |  |    Tool Use     |--|--------------|->|     Tools       |  |    |
|    |  +-----------------+  |   Tools      |  | (Action Layer)  |  |    |
|    |         ^             |              |  +-----------------+  |    |
|    |         | Guided by   |              |          |            |    |
|    |         |             |              |          | Executes   |    |
|    |  +-----------------+  |   Get        |  +-----------------+  |    |
|    |  |  User Selection |<-|--------------|->|    Prompts      |  |    |
|    |  +-----------------+  |   Prompts    |  | (Template Layer)|  |    |
|    |                       |              |  +-----------------+  |    |
|    +-----------------------+              +-----------------------+    |
|                                                                        |
+-----------------------------------------------------------------------+

Data Flow:
  Resources  -->  Provide context TO the LLM
  Tools      <--  Called BY the LLM to perform actions
  Prompts    -->  Guide user interactions WITH the LLM
```

### How Components Work Together

```
+------------------------------------------------------------------+
|                    TYPICAL WORKFLOW                               |
+------------------------------------------------------------------+
|                                                                   |
|  1. USER selects a PROMPT                                         |
|     +--------+         +------------------+                       |
|     |  User  |-------->| "Analyze my code"|                       |
|     +--------+         +------------------+                       |
|                               |                                   |
|                               v                                   |
|  2. CLIENT loads RESOURCES for context                            |
|     +------------------+    +------------------+                   |
|     | source_code.py   |    | project_config   |                   |
|     +------------------+    +------------------+                   |
|                               |                                   |
|                               v                                   |
|  3. LLM processes and decides to use TOOLS                        |
|     +------------------+    +------------------+                   |
|     | run_linter()     |    | search_issues()  |                   |
|     +------------------+    +------------------+                   |
|                               |                                   |
|                               v                                   |
|  4. Results returned to USER                                      |
|     +------------------------------------------+                  |
|     | "Found 3 issues: missing docstrings..." |                   |
|     +------------------------------------------+                  |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Client vs Server Capabilities

MCP uses a capability negotiation system where clients and servers declare what features they support.

### Server Capabilities

```json
{
  "capabilities": {
    "resources": {
      "subscribe": true,
      "listChanged": true
    },
    "tools": {
      "listChanged": true
    },
    "prompts": {
      "listChanged": true
    },
    "logging": {}
  }
}
```

| Capability | Description |
|------------|-------------|
| `resources` | Server can expose resources |
| `resources.subscribe` | Clients can subscribe to resource changes |
| `resources.listChanged` | Server can notify when resource list changes |
| `tools` | Server can expose tools |
| `tools.listChanged` | Server can notify when tool list changes |
| `prompts` | Server can expose prompts |
| `prompts.listChanged` | Server can notify when prompt list changes |
| `logging` | Server can send log messages |

### Client Capabilities

```json
{
  "capabilities": {
    "roots": {
      "listChanged": true
    },
    "sampling": {}
  }
}
```

| Capability | Description |
|------------|-------------|
| `roots` | Client can provide filesystem roots |
| `roots.listChanged` | Client can notify when roots change |
| `sampling` | Client supports LLM sampling requests from server |

### Capability Negotiation Flow

```
+------------------------------------------------------------------+
|                 CAPABILITY NEGOTIATION                            |
+------------------------------------------------------------------+
|                                                                   |
|    CLIENT                                  SERVER                 |
|      |                                       |                    |
|      |  1. Initialize Request                |                    |
|      |  (client capabilities)                |                    |
|      |-------------------------------------->|                    |
|      |                                       |                    |
|      |  2. Initialize Response               |                    |
|      |  (server capabilities)                |                    |
|      |<--------------------------------------|                    |
|      |                                       |                    |
|      |  3. Both sides now know what          |                    |
|      |     features are available            |                    |
|      |                                       |                    |
|      |  4. Only use negotiated capabilities  |                    |
|      |<------------------------------------->|                    |
|      |                                       |                    |
+------------------------------------------------------------------+
```

---

## When to Use Which Component

### Decision Tree

```
+------------------------------------------------------------------+
|                    COMPONENT SELECTION                            |
+------------------------------------------------------------------+
|                                                                   |
|                    What do you need?                              |
|                          |                                        |
|          +---------------+---------------+                        |
|          |               |               |                        |
|          v               v               v                        |
|    +----------+    +----------+    +------------+                 |
|    | CONTEXT  |    | ACTION   |    | WORKFLOW   |                 |
|    | for LLM  |    | by LLM   |    | for User   |                 |
|    +----------+    +----------+    +------------+                 |
|          |               |               |                        |
|          v               v               v                        |
|    +----------+    +----------+    +------------+                 |
|    | RESOURCE |    |   TOOL   |    |   PROMPT   |                 |
|    +----------+    +----------+    +------------+                 |
|                                                                   |
+------------------------------------------------------------------+
```

### Use Resources When:

- You need to provide **static or semi-static data** to the LLM
- The data should be **read-only** from the LLM's perspective
- You want the client to **cache** the data
- Examples:
  - Configuration files
  - Documentation
  - Database schemas
  - API specifications

### Use Tools When:

- You need to **execute actions** based on LLM decisions
- The operation has **side effects** (writes, updates, deletes)
- You need **real-time or dynamic** data
- The operation requires **parameters** from the conversation
- Examples:
  - Running database queries
  - Sending API requests
  - File operations
  - Calculations

### Use Prompts When:

- You want to define **reusable interaction patterns**
- The workflow should be **user-selectable**
- You need **parameterized templates** for common tasks
- You want to **standardize** how users interact with the LLM
- Examples:
  - Code review checklist
  - Bug report template
  - Data analysis workflow
  - Documentation generator

---

## Component Comparison Table

| Aspect | Resources | Tools | Prompts |
|--------|-----------|-------|---------|
| **Purpose** | Provide context | Execute actions | Guide interactions |
| **Direction** | Server -> Client | Client -> Server | Server -> User |
| **Invoked by** | Client/LLM reads | LLM calls | User selects |
| **State** | Read-only | Can modify | Template only |
| **Caching** | Encouraged | Not cached | Cached |
| **Parameters** | None (URI only) | JSON Schema | Arguments |
| **Real-time** | Via subscriptions | Per invocation | Static |
| **Typical use** | Files, configs | APIs, queries | Workflows |

---

## Summary

```
+------------------------------------------------------------------+
|                      KEY TAKEAWAYS                                |
+------------------------------------------------------------------+
|                                                                   |
|  1. RESOURCES = Data/Context (What the LLM knows)                 |
|     - Read-only, URI-addressed, cacheable                         |
|     - Use for: files, configs, documentation, schemas             |
|                                                                   |
|  2. TOOLS = Actions/Functions (What the LLM can do)               |
|     - Executable, parameterized, can have side effects            |
|     - Use for: API calls, queries, computations, modifications    |
|                                                                   |
|  3. PROMPTS = Templates/Workflows (How users interact)            |
|     - User-selectable, parameterized, reusable                    |
|     - Use for: workflows, templates, guided interactions          |
|                                                                   |
|  All three work together to create powerful MCP integrations!     |
|                                                                   |
+------------------------------------------------------------------+
```

---

## Next Steps

In the following sections, we'll dive deep into each component:

1. [Resources](./_02_resources.md) - Detailed resource implementation
2. [Tools](./_03_tools.md) - Building effective tools
3. [Prompts](./_04_prompts.md) - Creating prompt templates
4. [Sampling](./_05_sampling.md) - Server-initiated LLM requests
5. [Hands-on Lab](./_06_components_hands_on.ipynb) - Practical exercises
