# Module 2.1: Transport Layer Overview

## Introduction

The **transport layer** in MCP is the foundation that enables communication between clients and servers. It handles the low-level details of sending and receiving messages, allowing the higher-level protocol logic to focus on what matters: exchanging structured data between AI applications and external systems.

```
+===========================================================================+
|                        WHAT IS THE TRANSPORT LAYER?                       |
+===========================================================================+
|                                                                           |
|  The transport layer is the communication infrastructure that carries     |
|  MCP messages between clients and servers. It abstracts away the          |
|  physical medium of communication (pipes, sockets, HTTP) so that the      |
|  protocol logic remains consistent regardless of how data moves.          |
|                                                                           |
+===========================================================================+
```

## Role of Transport in the MCP Protocol Stack

MCP follows a **layered architecture**, similar to the OSI or TCP/IP models. Each layer has specific responsibilities:

```
+-----------------------------------------------------------------------------+
|                         MCP PROTOCOL STACK                                  |
+-----------------------------------------------------------------------------+
|                                                                             |
|    +-------------------------------------------------------------------+    |
|    |                    APPLICATION LAYER                               |    |
|    |  - Tools, Resources, Prompts, Sampling                             |    |
|    |  - Business logic and capabilities                                 |    |
|    +-------------------------------------------------------------------+    |
|                                    |                                        |
|                                    v                                        |
|    +-------------------------------------------------------------------+    |
|    |                    PROTOCOL LAYER                                  |    |
|    |  - JSON-RPC 2.0 message format                                     |    |
|    |  - Request/Response/Notification patterns                          |    |
|    |  - Method routing and error handling                               |    |
|    +-------------------------------------------------------------------+    |
|                                    |                                        |
|                                    v                                        |
|    +-------------------------------------------------------------------+    |
|    |                    TRANSPORT LAYER                                 |    |
|    |  - Message framing and delivery                                    |    |
|    |  - Connection management                                           |    |
|    |  - Supported: stdio, HTTP/SSE, WebSocket                           |    |
|    +-------------------------------------------------------------------+    |
|                                    |                                        |
|                                    v                                        |
|    +-------------------------------------------------------------------+    |
|    |                    PHYSICAL LAYER                                  |    |
|    |  - Actual bytes over pipes, sockets, network                       |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
+-----------------------------------------------------------------------------+
```

### Layer Responsibilities

| Layer | Responsibility | Example |
|-------|---------------|---------|
| **Application** | Define capabilities (tools, resources) | `@mcp.tool()` decorator |
| **Protocol** | Format and route messages | JSON-RPC 2.0 requests |
| **Transport** | Deliver messages reliably | stdio, HTTP/SSE |
| **Physical** | Move raw bytes | Unix pipes, TCP sockets |

## Separation of Concerns

One of the most important design principles in MCP is the **separation between transport and protocol**. This means:

```
+-----------------------------------------------------------------------------+
|                    SEPARATION OF CONCERNS                                   |
+-----------------------------------------------------------------------------+
|                                                                             |
|    TRANSPORT CONCERNS:                    PROTOCOL CONCERNS:                |
|    +-----------------------+              +-----------------------+         |
|    | - How to connect      |              | - Message structure   |         |
|    | - How to send bytes   |              | - Method names        |         |
|    | - How to receive bytes|              | - Parameter schemas   |         |
|    | - Connection health   |              | - Response formats    |         |
|    | - Reconnection logic  |              | - Error codes         |         |
|    +-----------------------+              +-----------------------+         |
|                                                                             |
|                        INDEPENDENT OF EACH OTHER                            |
|                                                                             |
|    +-------------------------------------------------------------------+    |
|    |                                                                   |    |
|    |   The same JSON-RPC message can travel over:                      |    |
|    |                                                                   |    |
|    |   - stdio (local subprocess)                                      |    |
|    |   - HTTP + SSE (remote server)                                    |    |
|    |   - WebSocket (bidirectional streaming)                           |    |
|    |                                                                   |    |
|    |   ...and the protocol layer doesn't need to know which!           |    |
|    |                                                                   |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
+-----------------------------------------------------------------------------+
```

### Why This Matters

```python
# Example: Same tool works regardless of transport

from fastmcp import FastMCP

mcp = FastMCP("My Server")

@mcp.tool()
def calculate_sum(a: int, b: int) -> int:
    """Add two numbers together."""
    return a + b

# This tool can be accessed via:
# 1. stdio: python server.py
# 2. HTTP/SSE: uvicorn server:app
# 3. WebSocket: (with appropriate adapter)

# The tool code NEVER changes - only the transport configuration does!
```

## MCP Transport Architecture

Here's how messages flow through the MCP architecture:

```
+-----------------------------------------------------------------------------+
|                        MCP MESSAGE FLOW                                     |
+-----------------------------------------------------------------------------+
|                                                                             |
|    CLIENT SIDE                                         SERVER SIDE          |
|    -----------                                         -----------          |
|                                                                             |
|    +--------------+                                   +--------------+      |
|    |   LLM /      |                                   |   MCP        |      |
|    |   Agent      |                                   |   Server     |      |
|    +------+-------+                                   +------+-------+      |
|           |                                                  ^              |
|           | 1. Request tool                                  | 6. Execute   |
|           v                                                  |     tool     |
|    +------+-------+                                   +------+-------+      |
|    |   MCP        |                                   |   Protocol   |      |
|    |   Client     |                                   |   Handler    |      |
|    +------+-------+                                   +------+-------+      |
|           |                                                  ^              |
|           | 2. Create JSON-RPC                               | 5. Parse     |
|           |    message                                       |    JSON-RPC  |
|           v                                                  |              |
|    +------+-------+                                   +------+-------+      |
|    |   Transport  |  3. Send bytes over transport    |   Transport  |      |
|    |   (client)   |--------------------------------->|   (server)   |      |
|    +--------------+         4. Receive bytes         +--------------+      |
|                                                                             |
|    Response flows back the same path in reverse                             |
|                                                                             |
+-----------------------------------------------------------------------------+
```

## Available Transports in MCP

MCP supports multiple transport mechanisms, each suited for different use cases:

```
+-----------------------------------------------------------------------------+
|                        TRANSPORT OPTIONS                                    |
+-----------------------------------------------------------------------------+
|                                                                             |
|    +-------------------+-------------------+-------------------+             |
|    |      STDIO        |    HTTP + SSE     |    WebSocket      |             |
|    +-------------------+-------------------+-------------------+             |
|    |                   |                   |                   |             |
|    |  stdin/stdout     |  POST requests +  |  Full duplex      |             |
|    |  pipes            |  SSE streaming    |  streaming        |             |
|    |                   |                   |                   |             |
|    |  Local processes  |  Remote servers   |  Real-time apps   |             |
|    |  CLI tools        |  Web services     |  Live updates     |             |
|    |  Development      |  Production       |  Bidirectional    |             |
|    |                   |                   |                   |             |
|    +-------------------+-------------------+-------------------+             |
|                                                                             |
+-----------------------------------------------------------------------------+
```

### Quick Comparison

| Transport | Direction | Best For | Complexity |
|-----------|-----------|----------|------------|
| **stdio** | Bidirectional | Local subprocess, CLI | Low |
| **HTTP/SSE** | HTTP POST + SSE stream | Remote servers, web | Medium |
| **WebSocket** | Full duplex | Real-time, high-frequency | High |

## Transport-Agnostic Design Benefits

The transport-agnostic design of MCP provides several key advantages:

```
+-----------------------------------------------------------------------------+
|                    BENEFITS OF TRANSPORT ABSTRACTION                        |
+-----------------------------------------------------------------------------+
|                                                                             |
|    1. FLEXIBILITY                                                           |
|    +---------------------------------------------------------------+        |
|    |  Choose the right transport for your deployment scenario      |        |
|    |  - Development: stdio (simple, fast iteration)                |        |
|    |  - Production: HTTP/SSE (scalable, standard)                  |        |
|    |  - Real-time: WebSocket (low latency)                         |        |
|    +---------------------------------------------------------------+        |
|                                                                             |
|    2. CODE REUSABILITY                                                      |
|    +---------------------------------------------------------------+        |
|    |  Server logic written once, deployed anywhere                 |        |
|    |  - Same tools work across all transports                      |        |
|    |  - No transport-specific code in business logic               |        |
|    +---------------------------------------------------------------+        |
|                                                                             |
|    3. TESTABILITY                                                           |
|    +---------------------------------------------------------------+        |
|    |  Test with stdio locally, deploy with HTTP/SSE                |        |
|    |  - Easy debugging with stdio (just read pipes)                |        |
|    |  - Same tests work regardless of transport                    |        |
|    +---------------------------------------------------------------+        |
|                                                                             |
|    4. FUTURE-PROOFING                                                       |
|    +---------------------------------------------------------------+        |
|    |  New transports can be added without changing protocol        |        |
|    |  - gRPC transport? Just implement the transport interface     |        |
|    |  - QUIC transport? Same deal                                  |        |
|    +---------------------------------------------------------------+        |
|                                                                             |
+-----------------------------------------------------------------------------+
```

## Transport Interface Contract

All MCP transports must implement a common interface:

```
+-----------------------------------------------------------------------------+
|                    TRANSPORT INTERFACE                                      |
+-----------------------------------------------------------------------------+
|                                                                             |
|    abstract class Transport:                                                |
|                                                                             |
|        +---------------------------+                                        |
|        |  connect()                |  Establish connection                  |
|        +---------------------------+                                        |
|                    |                                                        |
|                    v                                                        |
|        +---------------------------+                                        |
|        |  send(message: bytes)     |  Send message to peer                  |
|        +---------------------------+                                        |
|                    |                                                        |
|                    v                                                        |
|        +---------------------------+                                        |
|        |  receive() -> bytes       |  Receive message from peer             |
|        +---------------------------+                                        |
|                    |                                                        |
|                    v                                                        |
|        +---------------------------+                                        |
|        |  close()                  |  Graceful shutdown                     |
|        +---------------------------+                                        |
|                                                                             |
|    Properties:                                                              |
|        - is_connected: bool                                                 |
|        - transport_type: str                                                |
|                                                                             |
+-----------------------------------------------------------------------------+
```

## How Transport Fits with JSON-RPC

MCP uses JSON-RPC 2.0 for message formatting. The transport layer is responsible for:

```
+-----------------------------------------------------------------------------+
|                    TRANSPORT + JSON-RPC                                     |
+-----------------------------------------------------------------------------+
|                                                                             |
|    JSON-RPC Message:                                                        |
|    +-------------------------------------------------------------------+    |
|    | {                                                                 |    |
|    |   "jsonrpc": "2.0",                                               |    |
|    |   "id": 1,                                                        |    |
|    |   "method": "tools/call",                                         |    |
|    |   "params": {                                                     |    |
|    |     "name": "calculate_sum",                                      |    |
|    |     "arguments": {"a": 5, "b": 3}                                 |    |
|    |   }                                                               |    |
|    | }                                                                 |    |
|    +-------------------------------------------------------------------+    |
|                              |                                              |
|                              v                                              |
|    +-------------------------------------------------------------------+    |
|    |                    TRANSPORT LAYER                                |    |
|    |                                                                   |    |
|    |  1. Serialize to bytes (UTF-8 encoded JSON)                       |    |
|    |  2. Add framing (newline for stdio, HTTP headers for HTTP)        |    |
|    |  3. Send over physical medium                                     |    |
|    |  4. Receive response bytes                                        |    |
|    |  5. Remove framing                                                |    |
|    |  6. Deserialize to message                                        |    |
|    |                                                                   |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
+-----------------------------------------------------------------------------+
```

## Summary

| Concept | Description |
|---------|-------------|
| **Transport Layer** | Handles message delivery between client and server |
| **Protocol Layer** | Handles message format and routing (JSON-RPC 2.0) |
| **Separation** | Transport and protocol are independent |
| **Transports** | stdio, HTTP/SSE, WebSocket |
| **Benefit** | Write once, deploy anywhere |

## What's Next

In the following sections, we'll dive deep into each transport mechanism:

1. **stdio Transport** - Standard input/output for local processes
2. **HTTP/SSE Transport** - Web-based communication for remote servers
3. **Connection Lifecycle** - How connections are established and maintained

---

**Next:** [stdio Transport](./_02_stdio_transport.md)
