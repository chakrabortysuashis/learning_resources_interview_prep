# Module 2.2: stdio Transport

## What is stdio Transport?

The **stdio transport** (Standard Input/Output) is the simplest and most fundamental transport mechanism in MCP. It uses the standard Unix/Windows streams - stdin (standard input) and stdout (standard output) - to exchange messages between a client and server process.

```
+===========================================================================+
|                         STDIO TRANSPORT                                   |
+===========================================================================+
|                                                                           |
|    stdio = Standard Input/Output                                          |
|                                                                           |
|    A transport mechanism where:                                           |
|    - Client WRITES messages to server's stdin                             |
|    - Server WRITES responses to its stdout (client reads this)            |
|    - Messages are newline-delimited JSON                                  |
|                                                                           |
|    Think of it as "piping" JSON messages between two processes            |
|                                                                           |
+===========================================================================+
```

## How stdin/stdout Communication Works

In a typical stdio-based MCP setup, the client spawns the server as a subprocess and communicates through pipes:

```
+-----------------------------------------------------------------------------+
|                    STDIO COMMUNICATION MODEL                                |
+-----------------------------------------------------------------------------+
|                                                                             |
|                       OPERATING SYSTEM                                      |
|                       ----------------                                      |
|                                                                             |
|    +-------------------+         PIPES          +-------------------+       |
|    |   CLIENT PROCESS  |                        |   SERVER PROCESS  |       |
|    |                   |                        |                   |       |
|    |  +-------------+  |    stdin pipe          |  +-------------+  |       |
|    |  |   Write to  |  |----------------------->|  |  Read from  |  |       |
|    |  |   server    |  |    (client output      |  |  stdin      |  |       |
|    |  +-------------+  |     = server stdin)    |  +-------------+  |       |
|    |                   |                        |                   |       |
|    |  +-------------+  |    stdout pipe         |  +-------------+  |       |
|    |  |  Read from  |  |<-----------------------|  |  Write to   |  |       |
|    |  |  server     |  |    (server stdout      |  |  stdout     |  |       |
|    |  +-------------+  |     = client input)    |  +-------------+  |       |
|    |                   |                        |                   |       |
|    +-------------------+                        +-------------------+       |
|                                                                             |
|    Note: stderr is typically used for logging/debugging only                |
|                                                                             |
+-----------------------------------------------------------------------------+
```

### Message Flow Detail

```
+-----------------------------------------------------------------------------+
|                    STDIO MESSAGE EXCHANGE                                   |
+-----------------------------------------------------------------------------+
|                                                                             |
|    CLIENT                                                SERVER             |
|    ------                                                ------             |
|                                                                             |
|    1. Spawn server as subprocess                                            |
|       subprocess.Popen(["python", "server.py"])                             |
|                                                                             |
|    2. Send request via stdin                                                |
|       |                                                                     |
|       |  {"jsonrpc":"2.0","id":1,"method":"initialize",...}\n               |
|       +-------------------------------------------------------->            |
|                                                                             |
|    3. Server reads from stdin, processes request                            |
|                                                                             |
|    4. Server sends response via stdout                                      |
|                                                          |                  |
|       <--------------------------------------------------+                  |
|       {"jsonrpc":"2.0","id":1,"result":{...}}\n                             |
|                                                                             |
|    5. Client reads response from server's stdout                            |
|                                                                             |
|    [Repeat for each message exchange]                                       |
|                                                                             |
+-----------------------------------------------------------------------------+
```

## Message Framing in stdio

With stdio transport, messages are **newline-delimited**. Each JSON-RPC message is followed by a newline character (`\n`):

```
+-----------------------------------------------------------------------------+
|                    MESSAGE FRAMING                                          |
+-----------------------------------------------------------------------------+
|                                                                             |
|    Raw bytes over stdin/stdout:                                             |
|                                                                             |
|    {"jsonrpc":"2.0","id":1,"method":"tools/list","params":{}}\n             |
|    {"jsonrpc":"2.0","id":2,"method":"tools/call","params":{...}}\n          |
|    {"jsonrpc":"2.0","id":3,"method":"resources/list","params":{}}\n         |
|                                                                             |
|    +-------------------------------------------------------------------+    |
|    |  Each message is:                                                 |    |
|    |  1. A complete, valid JSON object                                 |    |
|    |  2. Terminated with a newline character                           |    |
|    |  3. UTF-8 encoded                                                 |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
|    Parser logic:                                                            |
|    while True:                                                              |
|        line = stdin.readline()    # Blocks until newline                    |
|        if line:                                                             |
|            message = json.loads(line)                                       |
|            process(message)                                                 |
|                                                                             |
+-----------------------------------------------------------------------------+
```

## Use Cases for stdio Transport

stdio transport is ideal for several scenarios:

```
+-----------------------------------------------------------------------------+
|                    WHEN TO USE STDIO                                        |
+-----------------------------------------------------------------------------+
|                                                                             |
|    1. LOCAL PROCESSES                                                       |
|    +-------------------------------------------------------------------+    |
|    |  When MCP server runs as a subprocess on the same machine         |    |
|    |                                                                   |    |
|    |  Examples:                                                        |    |
|    |  - Code analysis tools                                            |    |
|    |  - File system utilities                                          |    |
|    |  - Local database connectors                                      |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
|    2. COMMAND-LINE TOOLS                                                    |
|    +-------------------------------------------------------------------+    |
|    |  MCP servers integrated into CLI workflows                        |    |
|    |                                                                   |    |
|    |  Examples:                                                        |    |
|    |  - Git operations server                                          |    |
|    |  - Shell command executor                                         |    |
|    |  - Package manager interface                                      |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
|    3. DEVELOPMENT AND TESTING                                               |
|    +-------------------------------------------------------------------+    |
|    |  Quick iteration during development                               |    |
|    |                                                                   |    |
|    |  Benefits:                                                        |    |
|    |  - No network configuration needed                                |    |
|    |  - Easy debugging (just read the pipes)                           |    |
|    |  - Simple process management                                      |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
|    4. SANDBOXED ENVIRONMENTS                                                |
|    +-------------------------------------------------------------------+    |
|    |  When network access is restricted                                |    |
|    |                                                                   |    |
|    |  Examples:                                                        |    |
|    |  - Docker containers without network                              |    |
|    |  - Air-gapped systems                                             |    |
|    |  - Security-sensitive applications                                |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
+-----------------------------------------------------------------------------+
```

## Pros and Cons of stdio Transport

```
+-----------------------------------------------------------------------------+
|                    STDIO PROS AND CONS                                      |
+-----------------------------------------------------------------------------+
|                                                                             |
|    +--------------------------------+  +--------------------------------+   |
|    |           PROS                 |  |           CONS                 |   |
|    +--------------------------------+  +--------------------------------+   |
|    |                                |  |                                |   |
|    | + Simple to implement          |  | - Local only (same machine)    |   |
|    |   No networking code needed    |  |   Can't use over network       |   |
|    |                                |  |                                |   |
|    | + No port management           |  | - One client per server        |   |
|    |   No conflicts with other apps |  |   Process is tied to client    |   |
|    |                                |  |                                |   |
|    | + Fast startup                 |  | - Process lifecycle mgmt       |   |
|    |   Just spawn a process         |  |   Client must manage server    |   |
|    |                                |  |                                |   |
|    | + Easy debugging               |  | - No built-in auth             |   |
|    |   Inspect stdin/stdout easily  |  |   Relies on OS process model   |   |
|    |                                |  |                                |   |
|    | + Secure by default            |  | - No load balancing            |   |
|    |   No network exposure          |  |   Can't scale horizontally     |   |
|    |                                |  |                                |   |
|    | + Cross-platform               |  | - stderr for logging only      |   |
|    |   Works on Unix and Windows    |  |   Need separate log handling   |   |
|    |                                |  |                                |   |
|    +--------------------------------+  +--------------------------------+   |
|                                                                             |
+-----------------------------------------------------------------------------+
```

## Data Flow Diagrams

### Request-Response Flow

```
+-----------------------------------------------------------------------------+
|                    REQUEST-RESPONSE OVER STDIO                              |
+-----------------------------------------------------------------------------+
|                                                                             |
|    CLIENT                               SERVER                              |
|    ======                               ======                              |
|                                                                             |
|    +------------------+                 +------------------+                 |
|    | Create request   |                 |                  |                 |
|    | JSON-RPC message |                 |                  |                 |
|    +--------+---------+                 |                  |                 |
|             |                           |                  |                 |
|             v                           |                  |                 |
|    +------------------+                 |                  |                 |
|    | Serialize to     |                 |                  |                 |
|    | JSON + newline   |                 |                  |                 |
|    +--------+---------+                 |                  |                 |
|             |                           |                  |                 |
|             | Write to subprocess stdin |                  |                 |
|             +-------------------------->+ Read from stdin  |                 |
|             |                           +--------+---------+                 |
|             |                                    |                           |
|             |                           +--------v---------+                 |
|             |                           | Parse JSON       |                 |
|             |                           | message          |                 |
|             |                           +--------+---------+                 |
|             |                                    |                           |
|             |                           +--------v---------+                 |
|             |                           | Execute method   |                 |
|             |                           | (tool/resource)  |                 |
|             |                           +--------+---------+                 |
|             |                                    |                           |
|             |                           +--------v---------+                 |
|             |                           | Create response  |                 |
|             |                           | JSON-RPC message |                 |
|             |                           +--------+---------+                 |
|             |                                    |                           |
|    +--------+---------+ Read from stdout         |                           |
|    | Parse JSON       |<-------------------------+                           |
|    | response         |  Write to stdout         |                           |
|    +--------+---------+                          |                           |
|             |                                    |                           |
|             v                                    |                           |
|    +------------------+                          |                           |
|    | Return result    |                          |                           |
|    | to application   |                          |                           |
|    +------------------+                          |                           |
|                                                                             |
+-----------------------------------------------------------------------------+
```

### Notification Flow (No Response)

```
+-----------------------------------------------------------------------------+
|                    NOTIFICATION OVER STDIO                                  |
+-----------------------------------------------------------------------------+
|                                                                             |
|    For notifications (no id field), no response is expected:                |
|                                                                             |
|    CLIENT                               SERVER                              |
|    ======                               ======                              |
|                                                                             |
|    {"jsonrpc":"2.0","method":"notifications/initialized"}\n                 |
|    -------------------------------------------------->                      |
|                                                       |                     |
|                                                       v                     |
|                                              +------------------+           |
|                                              | Process          |           |
|                                              | notification     |           |
|                                              | (no response)    |           |
|                                              +------------------+           |
|                                                                             |
|    NOTE: Notifications have no "id" field, so server doesn't respond        |
|                                                                             |
+-----------------------------------------------------------------------------+
```

### Server-Initiated Messages

```
+-----------------------------------------------------------------------------+
|                    SERVER-TO-CLIENT NOTIFICATIONS                           |
+-----------------------------------------------------------------------------+
|                                                                             |
|    Servers can also send unsolicited notifications:                         |
|                                                                             |
|    CLIENT                               SERVER                              |
|    ======                               ======                              |
|                                                                             |
|                                         [Tool list changes]                 |
|                                              |                              |
|                   <--------------------------+                              |
|    {"jsonrpc":"2.0","method":"notifications/tools/list_changed"}\n          |
|                                                                             |
|    +------------------+                                                     |
|    | Handle           |                                                     |
|    | notification     |                                                     |
|    | (refresh tools)  |                                                     |
|    +------------------+                                                     |
|                                                                             |
|    Client must continuously read stdout to receive server notifications     |
|                                                                             |
+-----------------------------------------------------------------------------+
```

## Code Example: stdio-based MCP Server

### Server Implementation

```python
#!/usr/bin/env python3
"""
A simple stdio-based MCP server example.
Run this file directly: python stdio_server.py
"""

import sys
import json
import asyncio
from typing import Any
from fastmcp import FastMCP

# Create the MCP server instance
mcp = FastMCP(
    name="Stdio Example Server",
    version="1.0.0"
)

# ----- Define Tools -----

@mcp.tool()
def add_numbers(a: float, b: float) -> float:
    """
    Add two numbers together.
    
    Args:
        a: First number
        b: Second number
    
    Returns:
        The sum of a and b
    """
    return a + b


@mcp.tool()
def multiply_numbers(a: float, b: float) -> float:
    """
    Multiply two numbers together.
    
    Args:
        a: First number
        b: Second number
    
    Returns:
        The product of a and b
    """
    return a * b


@mcp.tool()
def get_system_info() -> dict:
    """
    Get basic system information.
    
    Returns:
        Dictionary with system details
    """
    import platform
    return {
        "os": platform.system(),
        "os_version": platform.version(),
        "python_version": platform.python_version(),
        "machine": platform.machine()
    }


# ----- Define Resources -----

@mcp.resource("config://server")
def get_server_config() -> str:
    """
    Get server configuration as JSON string.
    """
    config = {
        "name": "Stdio Example Server",
        "version": "1.0.0",
        "transport": "stdio",
        "capabilities": ["tools", "resources"]
    }
    return json.dumps(config, indent=2)


# ----- Main Entry Point -----

if __name__ == "__main__":
    # Run the server using stdio transport
    # FastMCP automatically handles stdin/stdout communication
    mcp.run(transport="stdio")
```

### Client Implementation

```python
#!/usr/bin/env python3
"""
A simple stdio-based MCP client example.
This client spawns the server as a subprocess.
"""

import asyncio
import subprocess
import json
import sys


class StdioMCPClient:
    """Simple MCP client that communicates via stdio."""
    
    def __init__(self, server_command: list[str]):
        self.server_command = server_command
        self.process = None
        self.request_id = 0
    
    async def start(self):
        """Start the server subprocess."""
        self.process = await asyncio.create_subprocess_exec(
            *self.server_command,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        print(f"Started server process (PID: {self.process.pid})")
    
    async def send_request(self, method: str, params: dict = None) -> dict:
        """Send a JSON-RPC request and wait for response."""
        self.request_id += 1
        
        request = {
            "jsonrpc": "2.0",
            "id": self.request_id,
            "method": method,
            "params": params or {}
        }
        
        # Serialize and send
        message = json.dumps(request) + "\n"
        self.process.stdin.write(message.encode())
        await self.process.stdin.drain()
        
        # Read response
        response_line = await self.process.stdout.readline()
        response = json.loads(response_line.decode())
        
        return response
    
    async def close(self):
        """Terminate the server subprocess."""
        if self.process:
            self.process.terminate()
            await self.process.wait()
            print("Server process terminated")


async def main():
    # Create client pointing to the server script
    client = StdioMCPClient(["python", "stdio_server.py"])
    
    try:
        # Start the server
        await client.start()
        
        # Initialize the connection
        init_response = await client.send_request("initialize", {
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": {
                "name": "Example Client",
                "version": "1.0.0"
            }
        })
        print(f"Initialize response: {json.dumps(init_response, indent=2)}")
        
        # List available tools
        tools_response = await client.send_request("tools/list")
        print(f"Tools: {json.dumps(tools_response, indent=2)}")
        
        # Call a tool
        result = await client.send_request("tools/call", {
            "name": "add_numbers",
            "arguments": {"a": 5, "b": 3}
        })
        print(f"5 + 3 = {result['result']['content'][0]['text']}")
        
    finally:
        await client.close()


if __name__ == "__main__":
    asyncio.run(main())
```

## stdio Transport Configuration

When using FastMCP, stdio is often the default transport. Here's how to configure it:

```python
from fastmcp import FastMCP

mcp = FastMCP("My Server")

# Option 1: Explicit stdio transport
mcp.run(transport="stdio")

# Option 2: Default behavior (usually stdio)
mcp.run()

# Option 3: Command-line override
# python server.py --transport stdio
```

### Environment Variables

```bash
# Some servers support configuration via environment
export MCP_TRANSPORT=stdio
export MCP_LOG_LEVEL=debug

python server.py
```

## Best Practices for stdio Transport

```
+-----------------------------------------------------------------------------+
|                    BEST PRACTICES                                           |
+-----------------------------------------------------------------------------+
|                                                                             |
|    1. LOGGING TO STDERR                                                     |
|    +-------------------------------------------------------------------+    |
|    |  Never print to stdout - it corrupts the message stream!          |    |
|    |                                                                   |    |
|    |  WRONG:  print("Debug message")                                   |    |
|    |  RIGHT:  print("Debug message", file=sys.stderr)                  |    |
|    |  RIGHT:  logging.debug("Debug message")  # with stderr handler    |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
|    2. PROPER ERROR HANDLING                                                 |
|    +-------------------------------------------------------------------+    |
|    |  Always respond with JSON-RPC errors, never crash                 |    |
|    |                                                                   |    |
|    |  try:                                                             |    |
|    |      result = process_request(request)                            |    |
|    |  except Exception as e:                                           |    |
|    |      result = {"jsonrpc": "2.0", "id": id, "error": {...}}        |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
|    3. GRACEFUL SHUTDOWN                                                     |
|    +-------------------------------------------------------------------+    |
|    |  Handle EOF (stdin close) gracefully                              |    |
|    |                                                                   |    |
|    |  while True:                                                      |    |
|    |      line = stdin.readline()                                      |    |
|    |      if not line:  # EOF - client disconnected                    |    |
|    |          break                                                    |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
|    4. BUFFER MANAGEMENT                                                     |
|    +-------------------------------------------------------------------+    |
|    |  Flush output buffers after writing                               |    |
|    |                                                                   |    |
|    |  stdout.write(message)                                            |    |
|    |  stdout.flush()  # Ensure message is sent immediately             |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
+-----------------------------------------------------------------------------+
```

## Debugging stdio Communication

```bash
# Method 1: Use tee to log messages
python server.py 2>&1 | tee server.log

# Method 2: Use a debug proxy
# Create a script that logs all messages passing through

# Method 3: Enable MCP debug logging
export MCP_DEBUG=1
python server.py

# Method 4: Use MCP Inspector (recommended)
npx @modelcontextprotocol/inspector python server.py
```

## Summary

| Aspect | Details |
|--------|---------|
| **What** | Communication via stdin/stdout pipes |
| **How** | Newline-delimited JSON messages |
| **When** | Local processes, CLI tools, development |
| **Pros** | Simple, fast, secure, no networking |
| **Cons** | Local only, single client, process management |

---

**Previous:** [Transport Overview](./_01_transport_overview.md) | **Next:** [HTTP/SSE Transport](./_03_http_sse_transport.md)
