# Module 2.4: Connection Lifecycle

## Introduction

Understanding the MCP connection lifecycle is crucial for building reliable MCP clients and servers. This module covers the complete sequence from connection establishment to graceful shutdown, including error handling and recovery mechanisms.

```
+===========================================================================+
|                     CONNECTION LIFECYCLE OVERVIEW                         |
+===========================================================================+
|                                                                           |
|    +-------------+    +---------------+    +-----------+    +----------+  |
|    | Transport   |--->| Initialize    |--->| Active    |--->| Shutdown |  |
|    | Connect     |    | Handshake     |    | Session   |    |          |  |
|    +-------------+    +---------------+    +-----------+    +----------+  |
|                                                                           |
|    1. Connect      2. Capability       3. Normal         4. Graceful     |
|       transport       exchange            operation         termination  |
|                                                                           |
+===========================================================================+
```

## Connection Initialization Sequence

The MCP connection follows a strict initialization sequence that must be completed before any tool or resource operations:

```
+-----------------------------------------------------------------------------+
|                    INITIALIZATION SEQUENCE                                  |
+-----------------------------------------------------------------------------+
|                                                                             |
|    CLIENT                                                SERVER             |
|    ======                                                ======             |
|                                                                             |
|    1. TRANSPORT CONNECTION                                                  |
|    +-------------------------------------------------------------------+    |
|    |                                                                   |    |
|    |   [stdio]   Client spawns server as subprocess                    |    |
|    |             stdin/stdout pipes connected                          |    |
|    |                                                                   |    |
|    |   [HTTP/SSE] Client establishes SSE connection                    |    |
|    |              GET /sse -> 200 OK (text/event-stream)               |    |
|    |              Receives endpoint event with POST URL                |    |
|    |                                                                   |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
|    2. INITIALIZE REQUEST (Client -> Server)                                 |
|    +-------------------------------------------------------------------+    |
|    |                                                                   |    |
|    |   {                                                               |    |
|    |     "jsonrpc": "2.0",                                             |    |
|    |     "id": 1,                                                      |    |
|    |     "method": "initialize",                                       |    |
|    |     "params": {                                                   |    |
|    |       "protocolVersion": "2024-11-05",                            |    |
|    |       "capabilities": {                                           |    |
|    |         "roots": { "listChanged": true },                         |    |
|    |         "sampling": {}                                            |    |
|    |       },                                                          |    |
|    |       "clientInfo": {                                             |    |
|    |         "name": "MyClient",                                       |    |
|    |         "version": "1.0.0"                                        |    |
|    |       }                                                           |    |
|    |     }                                                             |    |
|    |   }                                                               |    |
|    |                                                                   |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
|    3. INITIALIZE RESPONSE (Server -> Client)                                |
|    +-------------------------------------------------------------------+    |
|    |                                                                   |    |
|    |   {                                                               |    |
|    |     "jsonrpc": "2.0",                                             |    |
|    |     "id": 1,                                                      |    |
|    |     "result": {                                                   |    |
|    |       "protocolVersion": "2024-11-05",                            |    |
|    |       "capabilities": {                                           |    |
|    |         "tools": { "listChanged": true },                         |    |
|    |         "resources": { "subscribe": true, "listChanged": true },  |    |
|    |         "prompts": { "listChanged": true }                        |    |
|    |       },                                                          |    |
|    |       "serverInfo": {                                             |    |
|    |         "name": "MyServer",                                       |    |
|    |         "version": "2.0.0"                                        |    |
|    |       }                                                           |    |
|    |     }                                                             |    |
|    |   }                                                               |    |
|    |                                                                   |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
|    4. INITIALIZED NOTIFICATION (Client -> Server)                           |
|    +-------------------------------------------------------------------+    |
|    |                                                                   |    |
|    |   {                                                               |    |
|    |     "jsonrpc": "2.0",                                             |    |
|    |     "method": "notifications/initialized"                         |    |
|    |   }                                                               |    |
|    |                                                                   |    |
|    |   Note: This is a notification (no id), so no response expected   |    |
|    |                                                                   |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
|    5. SESSION READY                                                         |
|    +-------------------------------------------------------------------+    |
|    |                                                                   |    |
|    |   Both sides can now exchange tools/resources/prompts requests    |    |
|    |                                                                   |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
+-----------------------------------------------------------------------------+
```

### Initialization Sequence Diagram (ASCII)

```
+-----------------------------------------------------------------------------+
|                    INITIALIZATION SEQUENCE DIAGRAM                          |
+-----------------------------------------------------------------------------+
|                                                                             |
|    CLIENT                                                SERVER             |
|       |                                                     |               |
|       |  [1] Transport Connect (stdio spawn or SSE GET)     |               |
|       |---------------------------------------------------->|               |
|       |                                                     |               |
|       |  [2] initialize request                             |               |
|       |  {"method": "initialize", "params": {...}}          |               |
|       |---------------------------------------------------->|               |
|       |                                                     |               |
|       |                    [Server validates version,       |               |
|       |                     prepares capabilities]          |               |
|       |                                                     |               |
|       |  [3] initialize response                            |               |
|       |  {"result": {"protocolVersion": "...", ...}}        |               |
|       |<----------------------------------------------------|               |
|       |                                                     |               |
|       |  [4] notifications/initialized                      |               |
|       |  {"method": "notifications/initialized"}            |               |
|       |---------------------------------------------------->|               |
|       |                                                     |               |
|       |  ================== SESSION ACTIVE ================  |               |
|       |                                                     |               |
|       |  [5] tools/list, resources/read, etc.               |               |
|       |<--------------------------------------------------->|               |
|       |                                                     |               |
|                                                                             |
+-----------------------------------------------------------------------------+
```

## Capability Exchange

During initialization, both sides advertise their capabilities. This determines what features are available during the session:

```
+-----------------------------------------------------------------------------+
|                    CAPABILITY EXCHANGE                                      |
+-----------------------------------------------------------------------------+
|                                                                             |
|    CLIENT CAPABILITIES (sent in initialize request):                        |
|    +-------------------------------------------------------------------+    |
|    |                                                                   |    |
|    |  {                                                                |    |
|    |    "roots": {                                                     |    |
|    |      "listChanged": true    // Client can handle root changes    |    |
|    |    },                                                             |    |
|    |    "sampling": {}           // Client supports sampling requests  |    |
|    |  }                                                                |    |
|    |                                                                   |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
|    SERVER CAPABILITIES (returned in initialize response):                   |
|    +-------------------------------------------------------------------+    |
|    |                                                                   |    |
|    |  {                                                                |    |
|    |    "tools": {                                                     |    |
|    |      "listChanged": true    // Server notifies when tools change  |    |
|    |    },                                                             |    |
|    |    "resources": {                                                 |    |
|    |      "subscribe": true,     // Client can subscribe to resources  |    |
|    |      "listChanged": true    // Server notifies resource changes   |    |
|    |    },                                                             |    |
|    |    "prompts": {                                                   |    |
|    |      "listChanged": true    // Server notifies prompt changes     |    |
|    |    },                                                             |    |
|    |    "logging": {}            // Server supports logging            |    |
|    |  }                                                                |    |
|    |                                                                   |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
|    CAPABILITY NEGOTIATION:                                                  |
|    +-------------------------------------------------------------------+    |
|    |                                                                   |    |
|    |  +-------------+                           +-------------+        |    |
|    |  |   CLIENT    |                           |   SERVER    |        |    |
|    |  +-------------+                           +-------------+        |    |
|    |  | supports:   |                           | supports:   |        |    |
|    |  | - roots     |                           | - tools     |        |    |
|    |  | - sampling  |                           | - resources |        |    |
|    |  +-------------+                           | - prompts   |        |    |
|    |        |                                   | - logging   |        |    |
|    |        |       Exchange Capabilities       +-------------+        |    |
|    |        +---------------------------------->      |                |    |
|    |        <----------------------------------+      |                |    |
|    |        |                                         |                |    |
|    |        |    EFFECTIVE SESSION CAPABILITIES       |                |    |
|    |        |    +-----------------------------+      |                |    |
|    |        |    | Client can:                 |      |                |    |
|    |        |    | - List/call tools           |      |                |    |
|    |        |    | - Read resources            |      |                |    |
|    |        |    | - Subscribe to resources    |      |                |    |
|    |        |    | - List/get prompts          |      |                |    |
|    |        |    |                             |      |                |    |
|    |        |    | Server can:                 |      |                |    |
|    |        |    | - Request sampling          |      |                |    |
|    |        |    | - Send list_changed events  |      |                |    |
|    |        |    +-----------------------------+      |                |    |
|    |                                                                   |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
+-----------------------------------------------------------------------------+
```

## Session Management

Once initialized, the session enters the active phase where normal operations occur:

```
+-----------------------------------------------------------------------------+
|                    SESSION MANAGEMENT                                       |
+-----------------------------------------------------------------------------+
|                                                                             |
|    SESSION STATES:                                                          |
|    +-------------------------------------------------------------------+    |
|    |                                                                   |    |
|    |  +---------------+    +---------------+    +---------------+      |    |
|    |  | CONNECTING    |--->| INITIALIZING  |--->|    ACTIVE     |      |    |
|    |  |               |    |               |    |               |      |    |
|    |  | Transport     |    | Handshake     |    | Normal ops    |      |    |
|    |  | being set up  |    | in progress   |    | allowed       |      |    |
|    |  +---------------+    +---------------+    +-------+-------+      |    |
|    |                                                    |              |    |
|    |                                                    v              |    |
|    |                                            +---------------+      |    |
|    |                                            |   CLOSING     |      |    |
|    |                                            |               |      |    |
|    |                                            | Shutdown in   |      |    |
|    |                                            | progress      |      |    |
|    |                                            +-------+-------+      |    |
|    |                                                    |              |    |
|    |                                                    v              |    |
|    |                                            +---------------+      |    |
|    |                                            |    CLOSED     |      |    |
|    |                                            |               |      |    |
|    |                                            | Session ended |      |    |
|    |                                            +---------------+      |    |
|    |                                                                   |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
|    SESSION DURING ACTIVE STATE:                                             |
|    +-------------------------------------------------------------------+    |
|    |                                                                   |    |
|    |  CLIENT                                         SERVER            |    |
|    |     |                                              |              |    |
|    |     |  tools/list                                  |              |    |
|    |     |--------------------------------------------->|              |    |
|    |     |<---------------------------------------------|              |    |
|    |     |                                              |              |    |
|    |     |  tools/call {name: "my_tool", args: {...}}   |              |    |
|    |     |--------------------------------------------->|              |    |
|    |     |<---------------------------------------------|              |    |
|    |     |                                              |              |    |
|    |     |  resources/read {uri: "file://..."}          |              |    |
|    |     |--------------------------------------------->|              |    |
|    |     |<---------------------------------------------|              |    |
|    |     |                                              |              |    |
|    |     |  notifications/tools/list_changed            |              |    |
|    |     |<---------------------------------------------|              |    |
|    |     |                                              |              |    |
|    |     |  (Client refreshes tool list)                |              |    |
|    |     |  tools/list                                  |              |    |
|    |     |--------------------------------------------->|              |    |
|    |     |<---------------------------------------------|              |    |
|    |     |                                              |              |    |
|    |                                                                   |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
+-----------------------------------------------------------------------------+
```

### Session Context

```
+-----------------------------------------------------------------------------+
|                    SESSION CONTEXT                                          |
+-----------------------------------------------------------------------------+
|                                                                             |
|    Each MCP session maintains context:                                      |
|                                                                             |
|    +-------------------------------------------------------------------+    |
|    |                        SESSION OBJECT                             |    |
|    +-------------------------------------------------------------------+    |
|    |                                                                   |    |
|    |  session_id:        "abc123-def456"                               |    |
|    |                                                                   |    |
|    |  client_info:                                                     |    |
|    |    name:            "MyClient"                                    |    |
|    |    version:         "1.0.0"                                       |    |
|    |                                                                   |    |
|    |  server_info:                                                     |    |
|    |    name:            "MyServer"                                    |    |
|    |    version:         "2.0.0"                                       |    |
|    |                                                                   |    |
|    |  protocol_version:  "2024-11-05"                                  |    |
|    |                                                                   |    |
|    |  client_capabilities:                                             |    |
|    |    roots:           {listChanged: true}                           |    |
|    |    sampling:        {}                                            |    |
|    |                                                                   |    |
|    |  server_capabilities:                                             |    |
|    |    tools:           {listChanged: true}                           |    |
|    |    resources:       {subscribe: true, listChanged: true}          |    |
|    |    prompts:         {listChanged: true}                           |    |
|    |                                                                   |    |
|    |  state:             ACTIVE                                        |    |
|    |                                                                   |    |
|    |  created_at:        2024-01-15T10:30:00Z                          |    |
|    |                                                                   |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
+-----------------------------------------------------------------------------+
```

## Graceful Shutdown

Proper shutdown ensures all pending operations complete and resources are released:

```
+-----------------------------------------------------------------------------+
|                    GRACEFUL SHUTDOWN SEQUENCE                               |
+-----------------------------------------------------------------------------+
|                                                                             |
|    CLIENT-INITIATED SHUTDOWN:                                               |
|    +-------------------------------------------------------------------+    |
|    |                                                                   |    |
|    |  CLIENT                                         SERVER            |    |
|    |     |                                              |              |    |
|    |     |  [1] Stop sending new requests               |              |    |
|    |     |                                              |              |    |
|    |     |  [2] Wait for pending responses              |              |    |
|    |     |<---------------------------------------------|              |    |
|    |     |       (final responses)                      |              |    |
|    |     |                                              |              |    |
|    |     |  [3] Close transport                         |              |    |
|    |     |                                              |              |    |
|    |     |  [stdio] Close stdin pipe                    |              |    |
|    |     |          Server detects EOF                  |              |    |
|    |     |                                              |              |    |
|    |     |  [HTTP/SSE] Close SSE connection             |              |    |
|    |     |             Server detects disconnect        |              |    |
|    |     |                                              |              |    |
|    |     |  [4] Server cleans up session                |              |    |
|    |     |                                              X              |    |
|    |     X                                                             |    |
|    |                                                                   |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
|    SERVER-INITIATED SHUTDOWN:                                               |
|    +-------------------------------------------------------------------+    |
|    |                                                                   |    |
|    |  CLIENT                                         SERVER            |    |
|    |     |                                              |              |    |
|    |     |  [1] Server decides to shut down             |              |    |
|    |     |                                              |              |    |
|    |     |  [2] notifications/shutdown (optional)       |              |    |
|    |     |<---------------------------------------------|              |    |
|    |     |                                              |              |    |
|    |     |  [3] Server stops accepting requests         |              |    |
|    |     |                                              |              |    |
|    |     |  [4] Server completes pending work           |              |    |
|    |     |                                              |              |    |
|    |     |  [5] Server closes transport                 |              |    |
|    |     |                                              |              |    |
|    |     |  [stdio] Server closes stdout                |              |    |
|    |     |          Client detects EOF                  |              |    |
|    |     |                                              |              |    |
|    |     |  [HTTP/SSE] Server closes SSE stream         |              |    |
|    |     |             Client detects disconnect        |              |    |
|    |     |                                              |              |    |
|    |     X                                              X              |    |
|    |                                                                   |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
+-----------------------------------------------------------------------------+
```

### Shutdown Sequence Diagram

```
+-----------------------------------------------------------------------------+
|                    SHUTDOWN SEQUENCE DIAGRAM                                |
+-----------------------------------------------------------------------------+
|                                                                             |
|    CLEAN SHUTDOWN (CLIENT-INITIATED):                                       |
|                                                                             |
|    CLIENT                              SERVER                 TIME          |
|       |                                   |                    |            |
|       |  [Application requests close]     |                    |            |
|       |                                   |                    v            |
|       |  [Drain pending requests]         |                                 |
|       |  (wait for outstanding responses) |                                 |
|       |                                   |                                 |
|       |  [Send close signal]              |                                 |
|       |---------------------------------->|                                 |
|       |                                   |                                 |
|       |                    [Server acknowledges]                            |
|       |                    [Cleans up resources]                            |
|       |                                   |                                 |
|       |  [Connection closed]              |                                 |
|       X                                   X                                 |
|                                                                             |
|                                                                             |
|    ABNORMAL SHUTDOWN (CONNECTION LOST):                                     |
|                                                                             |
|    CLIENT                              SERVER                 TIME          |
|       |                                   |                    |            |
|       |         X---X Network Failure X---X                    v            |
|       |                                   |                                 |
|       |  [Detect timeout/error]           |  [Detect timeout/error]         |
|       |                                   |                                 |
|       |  [Mark session as disconnected]   |  [Mark session as disconnected] |
|       |                                   |                                 |
|       |  [Optional: Attempt reconnect]    |  [Cleanup session after timeout]|
|       |                                   |                                 |
|       X                                   X                                 |
|                                                                             |
+-----------------------------------------------------------------------------+
```

## Error Recovery

MCP includes mechanisms for handling and recovering from errors:

```
+-----------------------------------------------------------------------------+
|                    ERROR RECOVERY                                           |
+-----------------------------------------------------------------------------+
|                                                                             |
|    ERROR TYPES:                                                             |
|    +-------------------------------------------------------------------+    |
|    |                                                                   |    |
|    |  1. TRANSPORT ERRORS (connection level)                           |    |
|    |     - Connection timeout                                          |    |
|    |     - Connection reset                                            |    |
|    |     - Network unreachable                                         |    |
|    |                                                                   |    |
|    |  2. PROTOCOL ERRORS (message level)                               |    |
|    |     - Invalid JSON                                                |    |
|    |     - Unknown method                                              |    |
|    |     - Invalid params                                              |    |
|    |                                                                   |    |
|    |  3. APPLICATION ERRORS (tool/resource level)                      |    |
|    |     - Tool execution failed                                       |    |
|    |     - Resource not found                                          |    |
|    |     - Permission denied                                           |    |
|    |                                                                   |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
|    ERROR HANDLING STRATEGIES:                                               |
|    +-------------------------------------------------------------------+    |
|    |                                                                   |    |
|    |  TRANSPORT ERRORS:                                                |    |
|    |  +-------------------------------------------------------------+  |    |
|    |  |  1. Detect error (timeout, connection reset)                |  |    |
|    |  |  2. Mark session as disconnected                            |  |    |
|    |  |  3. Attempt reconnection with exponential backoff           |  |    |
|    |  |  4. Re-initialize session if reconnect succeeds             |  |    |
|    |  |  5. Report failure to application if max retries exceeded   |  |    |
|    |  +-------------------------------------------------------------+  |    |
|    |                                                                   |    |
|    |  PROTOCOL ERRORS:                                                 |    |
|    |  +-------------------------------------------------------------+  |    |
|    |  |  Server returns JSON-RPC error response:                    |  |    |
|    |  |                                                             |  |    |
|    |  |  {                                                          |  |    |
|    |  |    "jsonrpc": "2.0",                                        |  |    |
|    |  |    "id": 1,                                                 |  |    |
|    |  |    "error": {                                               |  |    |
|    |  |      "code": -32600,                                        |  |    |
|    |  |      "message": "Invalid Request",                          |  |    |
|    |  |      "data": {"details": "Missing required field 'method'"} |  |    |
|    |  |    }                                                        |  |    |
|    |  |  }                                                          |  |    |
|    |  +-------------------------------------------------------------+  |    |
|    |                                                                   |    |
|    |  APPLICATION ERRORS:                                              |    |
|    |  +-------------------------------------------------------------+  |    |
|    |  |  Tool/resource errors are returned in result with isError:  |  |    |
|    |  |                                                             |  |    |
|    |  |  {                                                          |  |    |
|    |  |    "jsonrpc": "2.0",                                        |  |    |
|    |  |    "id": 1,                                                 |  |    |
|    |  |    "result": {                                              |  |    |
|    |  |      "content": [...],                                      |  |    |
|    |  |      "isError": true                                        |  |    |
|    |  |    }                                                        |  |    |
|    |  |  }                                                          |  |    |
|    |  +-------------------------------------------------------------+  |    |
|    |                                                                   |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
+-----------------------------------------------------------------------------+
```

### Reconnection Logic

```
+-----------------------------------------------------------------------------+
|                    RECONNECTION SEQUENCE                                    |
+-----------------------------------------------------------------------------+
|                                                                             |
|    CLIENT                                                SERVER             |
|       |                                                     |               |
|       |  [Connection lost]                                  |               |
|       X- - - - - - - - - - - - - - - - - - - - - - - - - - -X               |
|       |                                                     |               |
|       |  [Wait 1 second]                                    |               |
|       |                                                     |               |
|       |  [Attempt 1] Connect                                |               |
|       |---------------------------------------------------->X FAIL          |
|       |                                                     |               |
|       |  [Wait 2 seconds] (exponential backoff)             |               |
|       |                                                     |               |
|       |  [Attempt 2] Connect                                |               |
|       |---------------------------------------------------->X FAIL          |
|       |                                                     |               |
|       |  [Wait 4 seconds]                                   |               |
|       |                                                     |               |
|       |  [Attempt 3] Connect                                |               |
|       |---------------------------------------------------->|  SUCCESS      |
|       |                                                     |               |
|       |  [Re-initialize session]                            |               |
|       |  {"method": "initialize", ...}                      |               |
|       |---------------------------------------------------->|               |
|       |<----------------------------------------------------|               |
|       |                                                     |               |
|       |  {"method": "notifications/initialized"}            |               |
|       |---------------------------------------------------->|               |
|       |                                                     |               |
|       |  [Session restored, resume operations]              |               |
|       |                                                     |               |
|                                                                             |
|    EXPONENTIAL BACKOFF FORMULA:                                             |
|    +-------------------------------------------------------------------+    |
|    |  delay = min(base_delay * (2 ^ attempt), max_delay)               |    |
|    |                                                                   |    |
|    |  Example with base_delay=1s, max_delay=30s:                       |    |
|    |  Attempt 1: 1s                                                    |    |
|    |  Attempt 2: 2s                                                    |    |
|    |  Attempt 3: 4s                                                    |    |
|    |  Attempt 4: 8s                                                    |    |
|    |  Attempt 5: 16s                                                   |    |
|    |  Attempt 6+: 30s (capped at max)                                  |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
+-----------------------------------------------------------------------------+
```

## Complete Lifecycle Diagram

```
+-----------------------------------------------------------------------------+
|                    COMPLETE MCP CONNECTION LIFECYCLE                        |
+-----------------------------------------------------------------------------+
|                                                                             |
|                           +------------------+                              |
|                           |      START       |                              |
|                           +--------+---------+                              |
|                                    |                                        |
|                                    v                                        |
|                           +------------------+                              |
|                           | TRANSPORT SETUP  |                              |
|                           |                  |                              |
|                           | - stdio: spawn   |                              |
|                           | - SSE: connect   |                              |
|                           +--------+---------+                              |
|                                    |                                        |
|                      +-------------+-------------+                          |
|                      |                           |                          |
|                      v                           v                          |
|              +-------+-------+           +-------+-------+                  |
|              |    SUCCESS    |           |    FAILURE    |                  |
|              +-------+-------+           +-------+-------+                  |
|                      |                           |                          |
|                      v                           v                          |
|              +-------+-------+           +-------+-------+                  |
|              |  INITIALIZE   |           |    RETRY?     |                  |
|              |               |           +-------+-------+                  |
|              | Send request  |                   |                          |
|              | Wait response |           +-------+-------+                  |
|              +-------+-------+           |       |       |                  |
|                      |                   v       v       v                  |
|        +-------------+-------------+    Yes     No    Max                   |
|        |             |             |     |       |    retries               |
|        v             v             v     |       |       |                  |
|    +---+---+     +---+---+     +---+---+ |       v       v                  |
|    |SUCCESS|     |VERSION|     |TIMEOUT| |   +---+---+ +---+---+            |
|    +---+---+     |MISMATCH     +---+---+ |   | ABORT | | ERROR |            |
|        |        +---+---+         |      |   +-------+ +-------+            |
|        |             |            |      |                                  |
|        v             v            +------+                                  |
|    +---+---+     +---+---+              (retry with backoff)                |
|    | SEND  |     | ERROR |                                                  |
|    |INIT'D |     +-------+                                                  |
|    +---+---+                                                                |
|        |                                                                    |
|        v                                                                    |
|    +---+---+                                                                |
|    | ACTIVE|<--------------------------------------------------------+      |
|    |SESSION|                                                         |      |
|    +---+---+                                                         |      |
|        |                                                             |      |
|        +---> [Normal operations: tools, resources, prompts]          |      |
|        |                                                             |      |
|        +---> [Handle notifications from server]                      |      |
|        |                                                             |      |
|        +---> [Connection error] --> [Reconnect] --(success)----------+      |
|        |                                 |                                  |
|        |                                 +---(failure)---> [ERROR]          |
|        |                                                                    |
|        +---> [Shutdown requested]                                           |
|                    |                                                        |
|                    v                                                        |
|            +-------+-------+                                                |
|            |    CLOSING    |                                                |
|            |               |                                                |
|            | - Drain queue |                                                |
|            | - Send close  |                                                |
|            | - Cleanup     |                                                |
|            +-------+-------+                                                |
|                    |                                                        |
|                    v                                                        |
|            +-------+-------+                                                |
|            |    CLOSED     |                                                |
|            +---------------+                                                |
|                                                                             |
+-----------------------------------------------------------------------------+
```

## Code Example: Lifecycle Management

```python
"""
Example: MCP Client with full lifecycle management
"""

import asyncio
import json
from enum import Enum
from dataclasses import dataclass
from typing import Optional, Callable


class SessionState(Enum):
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    INITIALIZING = "initializing"
    ACTIVE = "active"
    CLOSING = "closing"
    CLOSED = "closed"


@dataclass
class SessionInfo:
    session_id: str
    protocol_version: str
    client_info: dict
    server_info: dict
    client_capabilities: dict
    server_capabilities: dict
    state: SessionState


class MCPClientWithLifecycle:
    """MCP Client with proper lifecycle management."""
    
    def __init__(
        self,
        server_command: list[str],
        max_retries: int = 5,
        base_delay: float = 1.0,
        max_delay: float = 30.0
    ):
        self.server_command = server_command
        self.max_retries = max_retries
        self.base_delay = base_delay
        self.max_delay = max_delay
        
        self.state = SessionState.DISCONNECTED
        self.session: Optional[SessionInfo] = None
        self.process = None
        self.request_id = 0
        self._on_state_change: Optional[Callable] = None
    
    def on_state_change(self, callback: Callable):
        """Register a callback for state changes."""
        self._on_state_change = callback
    
    def _set_state(self, new_state: SessionState):
        """Update state and notify listeners."""
        old_state = self.state
        self.state = new_state
        if self._on_state_change:
            self._on_state_change(old_state, new_state)
    
    async def connect(self) -> bool:
        """Connect to server with retry logic."""
        for attempt in range(self.max_retries):
            try:
                self._set_state(SessionState.CONNECTING)
                
                # Start subprocess
                self.process = await asyncio.create_subprocess_exec(
                    *self.server_command,
                    stdin=asyncio.subprocess.PIPE,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                
                # Initialize session
                self._set_state(SessionState.INITIALIZING)
                await self._initialize()
                
                self._set_state(SessionState.ACTIVE)
                return True
                
            except Exception as e:
                print(f"Connection attempt {attempt + 1} failed: {e}")
                
                if attempt < self.max_retries - 1:
                    delay = min(
                        self.base_delay * (2 ** attempt),
                        self.max_delay
                    )
                    print(f"Retrying in {delay} seconds...")
                    await asyncio.sleep(delay)
                else:
                    self._set_state(SessionState.DISCONNECTED)
                    return False
        
        return False
    
    async def _initialize(self):
        """Perform MCP initialization handshake."""
        # Send initialize request
        init_response = await self._send_request("initialize", {
            "protocolVersion": "2024-11-05",
            "capabilities": {
                "roots": {"listChanged": True},
                "sampling": {}
            },
            "clientInfo": {
                "name": "LifecycleClient",
                "version": "1.0.0"
            }
        })
        
        # Validate response
        if "error" in init_response:
            raise Exception(f"Initialize failed: {init_response['error']}")
        
        result = init_response["result"]
        
        # Store session info
        self.session = SessionInfo(
            session_id=f"session-{self.request_id}",
            protocol_version=result["protocolVersion"],
            client_info={"name": "LifecycleClient", "version": "1.0.0"},
            server_info=result.get("serverInfo", {}),
            client_capabilities={"roots": {"listChanged": True}},
            server_capabilities=result.get("capabilities", {}),
            state=SessionState.ACTIVE
        )
        
        # Send initialized notification
        await self._send_notification("notifications/initialized")
    
    async def _send_request(self, method: str, params: dict = None) -> dict:
        """Send a JSON-RPC request."""
        self.request_id += 1
        request = {
            "jsonrpc": "2.0",
            "id": self.request_id,
            "method": method,
            "params": params or {}
        }
        
        message = json.dumps(request) + "\n"
        self.process.stdin.write(message.encode())
        await self.process.stdin.drain()
        
        response_line = await self.process.stdout.readline()
        return json.loads(response_line.decode())
    
    async def _send_notification(self, method: str, params: dict = None):
        """Send a JSON-RPC notification (no response expected)."""
        notification = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params or {}
        }
        
        message = json.dumps(notification) + "\n"
        self.process.stdin.write(message.encode())
        await self.process.stdin.drain()
    
    async def call_tool(self, name: str, arguments: dict) -> dict:
        """Call a tool on the server."""
        if self.state != SessionState.ACTIVE:
            raise Exception(f"Cannot call tool in state: {self.state}")
        
        return await self._send_request("tools/call", {
            "name": name,
            "arguments": arguments
        })
    
    async def close(self):
        """Graceful shutdown."""
        if self.state == SessionState.CLOSED:
            return
        
        self._set_state(SessionState.CLOSING)
        
        try:
            # Wait briefly for any pending operations
            await asyncio.sleep(0.1)
            
            # Terminate process
            if self.process:
                self.process.terminate()
                await self.process.wait()
        finally:
            self._set_state(SessionState.CLOSED)


# Usage example
async def main():
    client = MCPClientWithLifecycle(["python", "server.py"])
    
    # Track state changes
    client.on_state_change(
        lambda old, new: print(f"State: {old.value} -> {new.value}")
    )
    
    try:
        if await client.connect():
            print(f"Connected! Server: {client.session.server_info}")
            
            # Use the client
            result = await client.call_tool("my_tool", {"arg": "value"})
            print(f"Result: {result}")
    finally:
        await client.close()


if __name__ == "__main__":
    asyncio.run(main())
```

## Summary

| Phase | Description | Key Actions |
|-------|-------------|-------------|
| **Transport Connect** | Establish communication channel | stdio: spawn process; HTTP/SSE: open connection |
| **Initialize** | Exchange capabilities | Send initialize request, receive capabilities |
| **Initialized** | Confirm ready state | Send initialized notification |
| **Active** | Normal operation | Tools, resources, prompts |
| **Shutdown** | Clean termination | Drain pending, close transport |
| **Error Recovery** | Handle failures | Retry with backoff, re-initialize |

---

**Previous:** [HTTP/SSE Transport](./_03_http_sse_transport.md) | **Next:** [Transport Examples](./_05_transport_examples.ipynb)
