# Module 2.3: HTTP + SSE Transport

## Introduction

The **HTTP + SSE (Server-Sent Events)** transport is the primary transport mechanism for remote MCP servers. It combines standard HTTP for client-to-server requests with SSE for server-to-client streaming, enabling full bidirectional communication over the web.

```
+===========================================================================+
|                        HTTP + SSE TRANSPORT                               |
+===========================================================================+
|                                                                           |
|    HTTP/SSE transport combines two technologies:                          |
|                                                                           |
|    +---------------------------+   +---------------------------+          |
|    |       HTTP POST           |   |    Server-Sent Events     |          |
|    +---------------------------+   +---------------------------+          |
|    | Client -> Server          |   | Server -> Client          |          |
|    | Request/Response          |   | One-way streaming         |          |
|    | Synchronous               |   | Asynchronous              |          |
|    +---------------------------+   +---------------------------+          |
|                                                                           |
|    Together they provide full bidirectional MCP communication             |
|                                                                           |
+===========================================================================+
```

## What is Server-Sent Events (SSE)?

Server-Sent Events is a standard web technology that enables servers to push data to clients over a persistent HTTP connection:

```
+-----------------------------------------------------------------------------+
|                    WHAT IS SSE?                                             |
+-----------------------------------------------------------------------------+
|                                                                             |
|    Traditional HTTP:                                                        |
|    +------------------+                    +------------------+              |
|    |     CLIENT       |     Request        |     SERVER       |              |
|    |                  | -----------------> |                  |              |
|    |                  |     Response       |                  |              |
|    |                  | <----------------- |                  |              |
|    +------------------+   (connection closes)   +--------------+              |
|                                                                             |
|                                                                             |
|    Server-Sent Events:                                                      |
|    +------------------+                    +------------------+              |
|    |     CLIENT       |     GET /events    |     SERVER       |              |
|    |                  | -----------------> |                  |              |
|    |                  |     data: msg1     |                  |              |
|    |                  | <----------------- |                  |              |
|    |                  |     data: msg2     |                  |              |
|    |                  | <----------------- |                  |              |
|    |                  |     data: msg3     |  (connection     |              |
|    |                  | <----------------- |   stays open)    |              |
|    |                  |        ...         |                  |              |
|    +------------------+                    +------------------+              |
|                                                                             |
|    Key characteristics:                                                     |
|    - Persistent connection (HTTP long-polling)                              |
|    - Server pushes events to client                                         |
|    - Text-based event stream format                                         |
|    - Automatic reconnection built into browser EventSource API              |
|                                                                             |
+-----------------------------------------------------------------------------+
```

## How HTTP/SSE Works in MCP

MCP uses HTTP/SSE in a specific pattern to achieve bidirectional communication:

```
+-----------------------------------------------------------------------------+
|                    MCP HTTP/SSE ARCHITECTURE                                |
+-----------------------------------------------------------------------------+
|                                                                             |
|    CLIENT                                                SERVER             |
|    ======                                                ======             |
|                                                                             |
|    1. Establish SSE connection (for receiving responses)                    |
|    +------------------+       GET /sse                +------------------+  |
|    |                  | ----------------------------> |                  |  |
|    |                  |       Connection: keep-alive  |                  |  |
|    |                  |       Content-Type: text/     |                  |  |
|    |                  | <---------------------------- |  event-stream   |  |
|    |                  |                               |                  |  |
|    |  SSE Connection  |       (stays open)            |                  |  |
|    |  (receives msgs) |                               |                  |  |
|    +------------------+                               +------------------+  |
|                                                                             |
|    2. Send requests via HTTP POST                                           |
|    +------------------+       POST /message           +------------------+  |
|    |                  | ----------------------------> |                  |  |
|    |                  |       Content-Type:           |                  |  |
|    |                  |       application/json        |                  |  |
|    |                  |                               |                  |  |
|    |                  |       202 Accepted            |                  |  |
|    |                  | <---------------------------- |                  |  |
|    +------------------+                               +------------------+  |
|                                                                             |
|    3. Receive response via SSE stream                                       |
|    +------------------+                               +------------------+  |
|    |                  |       data: {"jsonrpc":...}   |                  |  |
|    |                  | <---------------------------- |                  |  |
|    +------------------+       (via SSE connection)    +------------------+  |
|                                                                             |
+-----------------------------------------------------------------------------+
```

### Message Flow Detail

```
+-----------------------------------------------------------------------------+
|                    COMPLETE HTTP/SSE MESSAGE FLOW                           |
+-----------------------------------------------------------------------------+
|                                                                             |
|    CLIENT                                                SERVER             |
|    ------                                                ------             |
|                                                                             |
|    [1] GET /sse HTTP/1.1                                                    |
|        Accept: text/event-stream                                            |
|        ------------------------------------------------>                    |
|                                                                             |
|                            HTTP/1.1 200 OK                                  |
|                            Content-Type: text/event-stream                  |
|                            Cache-Control: no-cache                          |
|        <------------------------------------------------                    |
|                            event: endpoint                                  |
|                            data: {"uri": "/message?sessionId=abc123"}       |
|        <------------------------------------------------                    |
|                                                                             |
|    [2] POST /message?sessionId=abc123 HTTP/1.1                              |
|        Content-Type: application/json                                       |
|        Body: {"jsonrpc":"2.0","id":1,"method":"initialize",...}             |
|        ------------------------------------------------>                    |
|                                                                             |
|                            HTTP/1.1 202 Accepted                            |
|        <------------------------------------------------                    |
|                                                                             |
|    [3]                     event: message                                   |
|                            data: {"jsonrpc":"2.0","id":1,"result":{...}}    |
|        <------------------------------------------------                    |
|                            (Response delivered via SSE)                     |
|                                                                             |
|    [4] POST /message?sessionId=abc123 HTTP/1.1                              |
|        Body: {"jsonrpc":"2.0","id":2,"method":"tools/call",...}             |
|        ------------------------------------------------>                    |
|                                                                             |
|    [5]                     event: message                                   |
|                            data: {"jsonrpc":"2.0","id":2,"result":{...}}    |
|        <------------------------------------------------                    |
|                                                                             |
+-----------------------------------------------------------------------------+
```

## SSE Event Format

Server-Sent Events use a simple text-based format:

```
+-----------------------------------------------------------------------------+
|                    SSE EVENT FORMAT                                         |
+-----------------------------------------------------------------------------+
|                                                                             |
|    Each event consists of fields followed by a blank line:                  |
|                                                                             |
|    +-------------------------------------------------------------------+    |
|    | event: message                                                    |    |
|    | data: {"jsonrpc":"2.0","id":1,"result":{"tools":[...]}}           |    |
|    |                                                                   |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
|    Fields:                                                                  |
|    +---------------+--------------------------------------------------+    |
|    | Field         | Purpose                                          |    |
|    +---------------+--------------------------------------------------+    |
|    | event:        | Event type (optional, default is "message")      |    |
|    | data:         | Event payload (can span multiple lines)          |    |
|    | id:           | Event ID for reconnection (optional)             |    |
|    | retry:        | Reconnection time in ms (optional)               |    |
|    +---------------+--------------------------------------------------+    |
|                                                                             |
|    MCP uses these event types:                                              |
|    +---------------+--------------------------------------------------+    |
|    | endpoint      | Tells client where to POST messages              |    |
|    | message       | JSON-RPC response or notification                |    |
|    +---------------+--------------------------------------------------+    |
|                                                                             |
|    Multi-line data example:                                                 |
|    +-------------------------------------------------------------------+    |
|    | event: message                                                    |    |
|    | data: {"jsonrpc":"2.0",                                           |    |
|    | data:  "id": 1,                                                   |    |
|    | data:  "result": {"content": "Hello!"}}                           |    |
|    |                                                                   |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
+-----------------------------------------------------------------------------+
```

## HTTP Endpoints

MCP HTTP/SSE servers expose specific endpoints:

```
+-----------------------------------------------------------------------------+
|                    MCP HTTP ENDPOINTS                                       |
+-----------------------------------------------------------------------------+
|                                                                             |
|    +-------------------------------------------------------------------+    |
|    |  GET /sse                                                         |    |
|    +-------------------------------------------------------------------+    |
|    |  Purpose: Establish SSE connection for receiving messages         |    |
|    |  Response: text/event-stream                                      |    |
|    |  First event: endpoint with POST URL                              |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
|    +-------------------------------------------------------------------+    |
|    |  POST /message (or URL from endpoint event)                       |    |
|    +-------------------------------------------------------------------+    |
|    |  Purpose: Send JSON-RPC requests to server                        |    |
|    |  Body: JSON-RPC message                                           |    |
|    |  Response: 202 Accepted (actual response via SSE)                 |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
|    Session management (via query parameter or header):                      |
|    +-------------------------------------------------------------------+    |
|    |  /message?sessionId=abc123                                        |    |
|    |  or                                                               |    |
|    |  X-MCP-Session: abc123                                            |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
+-----------------------------------------------------------------------------+
```

## Connection Management

```
+-----------------------------------------------------------------------------+
|                    CONNECTION LIFECYCLE                                     |
+-----------------------------------------------------------------------------+
|                                                                             |
|    1. CONNECTION ESTABLISHMENT                                              |
|    +-------------------------------------------------------------------+    |
|    |                                                                   |    |
|    |  Client            Network              Server                    |    |
|    |    |                  |                   |                       |    |
|    |    |  GET /sse        |                   |                       |    |
|    |    |----------------->|------------------>|                       |    |
|    |    |                  |    200 OK         |                       |    |
|    |    |<-----------------|<------------------|                       |    |
|    |    |                  |                   |                       |    |
|    |    |  (SSE connection established)        |                       |    |
|    |                                                                   |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
|    2. HEARTBEAT / KEEP-ALIVE                                                |
|    +-------------------------------------------------------------------+    |
|    |                                                                   |    |
|    |  Server sends periodic comments (: ping) to keep connection open  |    |
|    |                                                                   |    |
|    |    Client            Network              Server                  |    |
|    |    |                  |                   |                       |    |
|    |    |                  |    : ping         |                       |    |
|    |    |<-----------------|<------------------|  (every 30s)          |    |
|    |    |                  |    : ping         |                       |    |
|    |    |<-----------------|<------------------|                       |    |
|    |                                                                   |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
|    3. RECONNECTION                                                          |
|    +-------------------------------------------------------------------+    |
|    |                                                                   |    |
|    |  If connection drops, client auto-reconnects:                     |    |
|    |                                                                   |    |
|    |    Client            Network              Server                  |    |
|    |    |                  X (disconnect)      |                       |    |
|    |    |                  |                   |                       |    |
|    |    |  (wait retry ms) |                   |                       |    |
|    |    |                  |                   |                       |    |
|    |    |  GET /sse        |                   |                       |    |
|    |    |  Last-Event-ID: 42                   |                       |    |
|    |    |----------------->|------------------>|                       |    |
|    |    |                  |   Resume from 43  |                       |    |
|    |    |<-----------------|<------------------|                       |    |
|    |                                                                   |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
|    4. GRACEFUL SHUTDOWN                                                     |
|    +-------------------------------------------------------------------+    |
|    |                                                                   |    |
|    |  Either side can close:                                           |    |
|    |                                                                   |    |
|    |  Client close: Simply stop reading SSE stream                     |    |
|    |  Server close: Send final event, then close connection            |    |
|    |                                                                   |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
+-----------------------------------------------------------------------------+
```

## When to Use HTTP/SSE vs stdio

```
+-----------------------------------------------------------------------------+
|                    TRANSPORT SELECTION GUIDE                                |
+-----------------------------------------------------------------------------+
|                                                                             |
|    USE HTTP/SSE WHEN:                       USE STDIO WHEN:                 |
|    +---------------------------------+      +-----------------------------+ |
|    | - Server runs remotely          |      | - Server runs locally       | |
|    | - Multiple clients needed       |      | - Single client only        | |
|    | - Web deployment required       |      | - CLI tool integration      | |
|    | - Load balancing needed         |      | - Simple testing            | |
|    | - Cloud/container deployment    |      | - Air-gapped environment    | |
|    | - Cross-network communication   |      | - Subprocess architecture   | |
|    | - Authentication required       |      | - No network available      | |
|    +---------------------------------+      +-----------------------------+ |
|                                                                             |
|    +-------------------------------------------------------------------+    |
|    |                    COMPARISON TABLE                               |    |
|    +-------------------------------------------------------------------+    |
|    | Feature              | HTTP/SSE          | stdio                 |    |
|    +----------------------+-------------------+-----------------------+    |
|    | Location             | Local or remote   | Local only            |    |
|    | Multiple clients     | Yes               | No                    |    |
|    | Network required     | Yes               | No                    |    |
|    | Authentication       | Built-in (HTTP)   | OS-level              |    |
|    | Load balancing       | Yes               | No                    |    |
|    | Complexity           | Medium            | Low                   |    |
|    | Firewall friendly    | Yes (port 80/443) | N/A                   |    |
|    | Browser compatible   | Yes               | No                    |    |
|    | Debugging            | HTTP tools        | Pipe inspection       |    |
|    +----------------------+-------------------+-----------------------+    |
|                                                                             |
+-----------------------------------------------------------------------------+
```

## Code Example: HTTP/SSE Server with FastMCP

### Server Implementation

```python
#!/usr/bin/env python3
"""
HTTP/SSE-based MCP server example using FastMCP.
Run with: uvicorn http_sse_server:app --host 0.0.0.0 --port 8000
"""

from fastmcp import FastMCP
import httpx
from datetime import datetime

# Create MCP server
mcp = FastMCP(
    name="HTTP SSE Example Server",
    version="1.0.0"
)

# ----- Define Tools -----

@mcp.tool()
def get_current_time(timezone: str = "UTC") -> str:
    """
    Get the current time in a specified timezone.
    
    Args:
        timezone: Timezone name (e.g., 'UTC', 'US/Eastern')
    
    Returns:
        Current time as a formatted string
    """
    from datetime import datetime
    import pytz
    
    try:
        tz = pytz.timezone(timezone)
        current_time = datetime.now(tz)
        return current_time.strftime("%Y-%m-%d %H:%M:%S %Z")
    except Exception as e:
        return f"Error: {str(e)}"


@mcp.tool()
async def fetch_url(url: str) -> dict:
    """
    Fetch content from a URL.
    
    Args:
        url: The URL to fetch
    
    Returns:
        Dictionary with status code and content preview
    """
    async with httpx.AsyncClient() as client:
        response = await client.get(url, follow_redirects=True)
        return {
            "status_code": response.status_code,
            "content_type": response.headers.get("content-type", "unknown"),
            "content_preview": response.text[:500] if response.text else ""
        }


@mcp.tool()
def calculate_statistics(numbers: list[float]) -> dict:
    """
    Calculate basic statistics for a list of numbers.
    
    Args:
        numbers: List of numbers to analyze
    
    Returns:
        Dictionary with mean, median, min, max, and sum
    """
    if not numbers:
        return {"error": "Empty list provided"}
    
    sorted_nums = sorted(numbers)
    n = len(sorted_nums)
    
    return {
        "count": n,
        "sum": sum(sorted_nums),
        "mean": sum(sorted_nums) / n,
        "median": sorted_nums[n // 2] if n % 2 == 1 
                  else (sorted_nums[n // 2 - 1] + sorted_nums[n // 2]) / 2,
        "min": min(sorted_nums),
        "max": max(sorted_nums)
    }


# ----- Define Resources -----

@mcp.resource("info://server")
def server_info() -> str:
    """Get server information."""
    return f"""
Server: HTTP SSE Example Server
Version: 1.0.0
Transport: HTTP/SSE
Started: {datetime.now().isoformat()}
"""


@mcp.resource("help://tools")
def tools_help() -> str:
    """Get help information about available tools."""
    return """
Available Tools:
================

1. get_current_time(timezone="UTC")
   - Returns the current time in specified timezone
   
2. fetch_url(url)
   - Fetches content from a URL (async)
   
3. calculate_statistics(numbers)
   - Calculates basic statistics for a list of numbers
"""


# Create the ASGI application for HTTP/SSE
app = mcp.http_app()


# Alternative: Run directly with built-in server
if __name__ == "__main__":
    # This uses uvicorn internally
    mcp.run(transport="sse", host="0.0.0.0", port=8000)
```

### Client Implementation

```python
#!/usr/bin/env python3
"""
HTTP/SSE-based MCP client example.
Connects to a remote MCP server via HTTP + SSE.
"""

import asyncio
import httpx
import json
from typing import AsyncIterator


class HTTPSSEClient:
    """MCP client that communicates via HTTP/SSE."""
    
    def __init__(self, base_url: str):
        self.base_url = base_url.rstrip('/')
        self.session_id = None
        self.message_endpoint = None
        self.request_id = 0
        self.pending_requests = {}
        self._sse_task = None
    
    async def connect(self):
        """Establish SSE connection and get message endpoint."""
        # Start SSE listener in background
        self._sse_task = asyncio.create_task(self._listen_sse())
        
        # Wait for endpoint event
        for _ in range(50):  # 5 second timeout
            if self.message_endpoint:
                break
            await asyncio.sleep(0.1)
        
        if not self.message_endpoint:
            raise TimeoutError("Failed to receive endpoint from SSE")
        
        print(f"Connected to {self.base_url}")
        print(f"Message endpoint: {self.message_endpoint}")
    
    async def _listen_sse(self):
        """Listen for SSE events from server."""
        async with httpx.AsyncClient(timeout=None) as client:
            async with client.stream("GET", f"{self.base_url}/sse") as response:
                event_type = None
                data_lines = []
                
                async for line in response.aiter_lines():
                    line = line.strip()
                    
                    if line.startswith("event:"):
                        event_type = line[6:].strip()
                    elif line.startswith("data:"):
                        data_lines.append(line[5:].strip())
                    elif line == "" and data_lines:
                        # End of event
                        data = "\n".join(data_lines)
                        await self._handle_event(event_type or "message", data)
                        event_type = None
                        data_lines = []
    
    async def _handle_event(self, event_type: str, data: str):
        """Handle an incoming SSE event."""
        if event_type == "endpoint":
            endpoint_info = json.loads(data)
            self.message_endpoint = endpoint_info.get("uri")
        elif event_type == "message":
            message = json.loads(data)
            msg_id = message.get("id")
            if msg_id in self.pending_requests:
                self.pending_requests[msg_id].set_result(message)
    
    async def send_request(self, method: str, params: dict = None) -> dict:
        """Send a JSON-RPC request via HTTP POST."""
        self.request_id += 1
        request_id = self.request_id
        
        request = {
            "jsonrpc": "2.0",
            "id": request_id,
            "method": method,
            "params": params or {}
        }
        
        # Create future for response
        future = asyncio.get_event_loop().create_future()
        self.pending_requests[request_id] = future
        
        # Send POST request
        async with httpx.AsyncClient() as client:
            url = f"{self.base_url}{self.message_endpoint}"
            response = await client.post(url, json=request)
            
            if response.status_code not in (200, 202):
                raise Exception(f"HTTP error: {response.status_code}")
        
        # Wait for response via SSE
        result = await asyncio.wait_for(future, timeout=30.0)
        del self.pending_requests[request_id]
        
        return result
    
    async def close(self):
        """Close the connection."""
        if self._sse_task:
            self._sse_task.cancel()
            try:
                await self._sse_task
            except asyncio.CancelledError:
                pass


async def main():
    client = HTTPSSEClient("http://localhost:8000")
    
    try:
        await client.connect()
        
        # Initialize
        init_response = await client.send_request("initialize", {
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": {
                "name": "HTTP SSE Client",
                "version": "1.0.0"
            }
        })
        print(f"Initialized: {json.dumps(init_response, indent=2)}")
        
        # List tools
        tools = await client.send_request("tools/list")
        print(f"\nAvailable tools: {json.dumps(tools, indent=2)}")
        
        # Call a tool
        result = await client.send_request("tools/call", {
            "name": "get_current_time",
            "arguments": {"timezone": "UTC"}
        })
        print(f"\nCurrent time: {result}")
        
    finally:
        await client.close()


if __name__ == "__main__":
    asyncio.run(main())
```

## Security Considerations

```
+-----------------------------------------------------------------------------+
|                    HTTP/SSE SECURITY                                        |
+-----------------------------------------------------------------------------+
|                                                                             |
|    1. AUTHENTICATION                                                        |
|    +-------------------------------------------------------------------+    |
|    |  Use standard HTTP authentication:                                |    |
|    |  - Bearer tokens (Authorization: Bearer <token>)                  |    |
|    |  - API keys (X-API-Key: <key>)                                    |    |
|    |  - OAuth 2.0                                                      |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
|    2. HTTPS (TLS)                                                           |
|    +-------------------------------------------------------------------+    |
|    |  Always use HTTPS in production:                                  |    |
|    |  - Encrypts all data in transit                                   |    |
|    |  - Prevents man-in-the-middle attacks                             |    |
|    |  - Required for secure authentication                             |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
|    3. CORS (Cross-Origin Resource Sharing)                                  |
|    +-------------------------------------------------------------------+    |
|    |  Configure CORS headers appropriately:                            |    |
|    |  - Access-Control-Allow-Origin                                    |    |
|    |  - Access-Control-Allow-Methods                                   |    |
|    |  - Access-Control-Allow-Headers                                   |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
|    4. RATE LIMITING                                                         |
|    +-------------------------------------------------------------------+    |
|    |  Implement rate limiting to prevent abuse:                        |    |
|    |  - Per-client request limits                                      |    |
|    |  - Concurrent connection limits                                   |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
|    5. INPUT VALIDATION                                                      |
|    +-------------------------------------------------------------------+    |
|    |  Validate all incoming JSON-RPC messages:                         |    |
|    |  - Check message structure                                        |    |
|    |  - Validate method names                                          |    |
|    |  - Sanitize parameters                                            |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
+-----------------------------------------------------------------------------+
```

## Deployment Considerations

```
+-----------------------------------------------------------------------------+
|                    DEPLOYMENT ARCHITECTURE                                  |
+-----------------------------------------------------------------------------+
|                                                                             |
|    Production deployment with load balancer:                                |
|                                                                             |
|    +----------+                                                             |
|    | Client 1 |----+                                                        |
|    +----------+    |      +----------------+                                |
|                    |      |                |      +-----------------+       |
|    +----------+    +----->| Load Balancer  |----->| MCP Server 1    |       |
|    | Client 2 |---------->| (sticky        |      +-----------------+       |
|    +----------+    +----->|  sessions)     |                                |
|                    |      |                |      +-----------------+       |
|    +----------+    |      +----------------+----->| MCP Server 2    |       |
|    | Client 3 |----+                             +-----------------+       |
|    +----------+                                                             |
|                                                                             |
|    Important: SSE connections are stateful!                                 |
|    - Use sticky sessions (session affinity)                                 |
|    - Or use session state store (Redis)                                     |
|                                                                             |
|    +-------------------------------------------------------------------+    |
|    |  Container deployment (Docker/Kubernetes):                        |    |
|    |                                                                   |    |
|    |  +-------------+    +-------------+    +-------------+            |    |
|    |  | MCP Pod 1   |    | MCP Pod 2   |    | MCP Pod 3   |            |    |
|    |  | Port 8000   |    | Port 8000   |    | Port 8000   |            |    |
|    |  +-------------+    +-------------+    +-------------+            |    |
|    |         |                 |                 |                     |    |
|    |         +--------+--------+--------+--------+                     |    |
|    |                  |                                                |    |
|    |           +------v------+                                         |    |
|    |           | K8s Service |                                         |    |
|    |           | (ClusterIP) |                                         |    |
|    |           +------+------+                                         |    |
|    |                  |                                                |    |
|    |           +------v------+                                         |    |
|    |           |   Ingress   |                                         |    |
|    |           | (HTTPS/SSL) |                                         |    |
|    |           +-------------+                                         |    |
|    |                                                                   |    |
|    +-------------------------------------------------------------------+    |
|                                                                             |
+-----------------------------------------------------------------------------+
```

## Summary

| Aspect | Details |
|--------|---------|
| **What** | HTTP POST for requests + SSE for responses/notifications |
| **How** | Client POSTs JSON-RPC, receives responses via SSE stream |
| **When** | Remote servers, web deployment, multiple clients |
| **Pros** | Standard web tech, scalable, firewall-friendly |
| **Cons** | More complex, requires persistent connection management |

---

**Previous:** [stdio Transport](./_02_stdio_transport.md) | **Next:** [Connection Lifecycle](./_04_connection_lifecycle.md)
