# Tools with FastMCP

## Module 5.3: Building Powerful Tools

---

## Overview

Tools are the primary way LLMs interact with your MCP server to perform actions. In FastMCP, tools are defined using the `@mcp.tool()` decorator, which automatically handles schema generation, validation, and response formatting.

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         TOOL EXECUTION FLOW                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   Client Request          FastMCP Processing           Your Function        │
│   ──────────────          ──────────────────           ─────────────        │
│                                                                             │
│   tools/call      ──▶    1. Validate params    ──▶    def my_tool():       │
│   {                      2. Convert types              # Your code         │
│     name: "my_tool"      3. Call function             return result        │
│     arguments: {...}     4. Format response                                 │
│   }                                                                         │
│                                                                             │
│                   ◀──    5. Return result      ◀──                          │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## The @mcp.tool() Decorator

### Basic Syntax

```python
from fastmcp import FastMCP

mcp = FastMCP("Tool Server")

@mcp.tool()
def my_tool(param1: str, param2: int) -> str:
    """Tool description shown to the LLM."""
    return f"Result: {param1}, {param2}"
```

### Decorator Parameters

```python
@mcp.tool(
    name: str = None,        # Override function name
    description: str = None  # Override docstring description
)
```

### Customizing Tool Name and Description

```python
# Default: uses function name and docstring
@mcp.tool()
def calculate_sum(a: int, b: int) -> int:
    """Calculate the sum of two numbers."""
    return a + b
# Tool name: "calculate_sum"
# Description: "Calculate the sum of two numbers."

# Custom name and description
@mcp.tool(name="add", description="Add two integers together")
def calculate_sum(a: int, b: int) -> int:
    """This docstring is ignored when description is provided."""
    return a + b
# Tool name: "add"
# Description: "Add two integers together"
```

---

## Parameter Types and Validation

FastMCP automatically converts Python type hints to JSON Schema for validation.

### Supported Types

```python
from typing import Optional, List, Dict, Any, Union, Literal
from datetime import datetime
from enum import Enum

# Basic types
@mcp.tool()
def basic_types(
    text: str,           # "type": "string"
    number: int,         # "type": "integer"  
    decimal: float,      # "type": "number"
    flag: bool           # "type": "boolean"
) -> str:
    """Tool with basic parameter types."""
    return f"{text}, {number}, {decimal}, {flag}"

# Optional parameters (with defaults)
@mcp.tool()
def optional_params(
    required: str,
    optional: str = "default",
    maybe_none: Optional[str] = None
) -> str:
    """Tool with optional parameters."""
    return f"{required}, {optional}, {maybe_none}"

# List and Dict types
@mcp.tool()
def complex_types(
    items: list[str],           # "type": "array", "items": {"type": "string"}
    mapping: dict[str, int],    # "type": "object"
    any_list: list              # "type": "array"
) -> str:
    """Tool with complex types."""
    return str(items)

# Enum for restricted values
class Priority(Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"

@mcp.tool()
def with_enum(
    priority: Priority
) -> str:
    """Tool using enum for restricted values."""
    return f"Priority set to: {priority.value}"

# Literal for inline restricted values
@mcp.tool()
def with_literal(
    status: Literal["pending", "active", "completed"]
) -> str:
    """Tool using Literal for restricted values."""
    return f"Status: {status}"
```

### Type Conversion Reference

| Python Type | JSON Schema | Example Value |
|-------------|-------------|---------------|
| `str` | `"type": "string"` | `"hello"` |
| `int` | `"type": "integer"` | `42` |
| `float` | `"type": "number"` | `3.14` |
| `bool` | `"type": "boolean"` | `true` |
| `list[str]` | `"type": "array", "items": {"type": "string"}` | `["a", "b"]` |
| `dict[str, Any]` | `"type": "object"` | `{"key": "value"}` |
| `Optional[str]` | `"type": "string"` (not required) | `"text"` or `null` |
| `Literal["a", "b"]` | `"type": "string", "enum": ["a", "b"]` | `"a"` |
| `Enum` | `"type": "string", "enum": [...]` | `"value"` |

---

## Docstrings as Descriptions

FastMCP uses docstrings to generate tool and parameter descriptions.

### Simple Docstring

```python
@mcp.tool()
def send_email(to: str, subject: str, body: str) -> str:
    """Send an email to a recipient."""
    return f"Email sent to {to}"
```

### Detailed Docstring with Parameter Descriptions

```python
@mcp.tool()
def create_user(
    username: str,
    email: str,
    role: str = "user"
) -> str:
    """
    Create a new user in the system.
    
    This tool creates a user account with the specified details.
    The user will receive a welcome email after creation.
    
    Args:
        username: The unique username for the account (3-20 characters)
        email: Valid email address for the user
        role: User role - either "user" or "admin" (default: "user")
    
    Returns:
        A confirmation message with the user ID
    
    Example:
        create_user("john_doe", "john@example.com", "admin")
    """
    # Implementation
    user_id = f"user_{hash(username) % 10000}"
    return f"User created: {username} (ID: {user_id})"
```

### Google Style Docstrings

```python
@mcp.tool()
def search_database(
    query: str,
    table: str,
    limit: int = 100
) -> str:
    """
    Search the database with a query.
    
    Executes a search query against the specified table and returns
    matching results up to the specified limit.
    
    Args:
        query: SQL-like search query string
        table: Name of the table to search
        limit: Maximum number of results to return (default: 100)
    
    Returns:
        JSON string containing the search results
    
    Raises:
        ValueError: If the table name is invalid
    """
    return f"Searching {table} for '{query}' (limit: {limit})"
```

---

## Return Types

FastMCP handles various return types automatically.

### String Returns (Most Common)

```python
@mcp.tool()
def simple_return() -> str:
    """Return a simple string."""
    return "This is the result"
```

### Numeric Returns

```python
@mcp.tool()
def calculate(a: float, b: float) -> float:
    """Calculate and return a number."""
    return a * b  # Automatically converted to string in response
```

### Dictionary Returns

```python
@mcp.tool()
def get_user_info(user_id: str) -> dict:
    """Get user information as a dictionary."""
    return {
        "id": user_id,
        "name": "John Doe",
        "email": "john@example.com"
    }
    # Returns as JSON string
```

### List Returns

```python
@mcp.tool()
def list_files(directory: str) -> list[str]:
    """List files in a directory."""
    return ["file1.txt", "file2.txt", "file3.txt"]
    # Returns as JSON array string
```

### Complex Object Returns

```python
from dataclasses import dataclass
import json

@dataclass
class SearchResult:
    id: str
    title: str
    score: float

@mcp.tool()
def search(query: str) -> str:
    """Search and return structured results."""
    results = [
        SearchResult("1", "First Result", 0.95),
        SearchResult("2", "Second Result", 0.87)
    ]
    # Convert to serializable format
    return json.dumps([
        {"id": r.id, "title": r.title, "score": r.score}
        for r in results
    ], indent=2)
```

---

## Async Tools

FastMCP fully supports async tools for I/O-bound operations.

### Basic Async Tool

```python
import asyncio

@mcp.tool()
async def async_greeting(name: str) -> str:
    """Greet someone asynchronously."""
    await asyncio.sleep(0.1)  # Simulate async operation
    return f"Hello, {name}!"
```

### HTTP Requests with httpx

```python
import httpx

@mcp.tool()
async def fetch_url(url: str) -> str:
    """
    Fetch content from a URL.
    
    Args:
        url: The URL to fetch (must start with http:// or https://)
    
    Returns:
        The response text or error message
    """
    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(url, timeout=10.0)
            response.raise_for_status()
            return response.text[:5000]  # Limit response size
    except httpx.TimeoutException:
        return f"Error: Request to {url} timed out"
    except httpx.HTTPError as e:
        return f"Error fetching URL: {e}"
```

### Database Operations

```python
import aiosqlite

@mcp.tool()
async def query_database(sql: str) -> str:
    """
    Execute a read-only SQL query.
    
    Args:
        sql: The SQL query to execute (SELECT only)
    
    Returns:
        Query results as JSON
    """
    if not sql.strip().upper().startswith("SELECT"):
        return "Error: Only SELECT queries are allowed"
    
    try:
        async with aiosqlite.connect("database.db") as db:
            async with db.execute(sql) as cursor:
                rows = await cursor.fetchall()
                columns = [desc[0] for desc in cursor.description]
                results = [dict(zip(columns, row)) for row in rows]
                return json.dumps(results, indent=2)
    except Exception as e:
        return f"Database error: {e}"
```

### Parallel Async Operations

```python
import asyncio
import httpx

@mcp.tool()
async def fetch_multiple_urls(urls: list[str]) -> str:
    """
    Fetch content from multiple URLs in parallel.
    
    Args:
        urls: List of URLs to fetch
    
    Returns:
        Results from all URLs
    """
    async def fetch_one(client: httpx.AsyncClient, url: str) -> dict:
        try:
            response = await client.get(url, timeout=10.0)
            return {"url": url, "status": response.status_code, "success": True}
        except Exception as e:
            return {"url": url, "error": str(e), "success": False}
    
    async with httpx.AsyncClient() as client:
        tasks = [fetch_one(client, url) for url in urls]
        results = await asyncio.gather(*tasks)
    
    return json.dumps(results, indent=2)
```

---

## Error Handling in Tools

### Raising Exceptions

FastMCP converts exceptions to error responses automatically:

```python
@mcp.tool()
def divide(a: float, b: float) -> float:
    """
    Divide a by b.
    
    Args:
        a: Dividend
        b: Divisor (cannot be zero)
    
    Returns:
        Result of division
    """
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b
```

### Returning Error Messages

For graceful error handling, return error messages:

```python
@mcp.tool()
def safe_divide(a: float, b: float) -> str:
    """
    Safely divide a by b with error handling.
    
    Args:
        a: Dividend
        b: Divisor
    
    Returns:
        Result or error message
    """
    if b == 0:
        return "Error: Cannot divide by zero"
    return str(a / b)
```

### Comprehensive Error Handling

```python
import traceback

@mcp.tool()
def process_file(filepath: str) -> str:
    """
    Process a file with comprehensive error handling.
    
    Args:
        filepath: Path to the file to process
    
    Returns:
        Processing result or detailed error
    """
    try:
        with open(filepath, 'r') as f:
            content = f.read()
        
        # Process content
        result = content.upper()
        return f"Processed {len(content)} characters"
    
    except FileNotFoundError:
        return f"Error: File not found: {filepath}"
    except PermissionError:
        return f"Error: Permission denied: {filepath}"
    except UnicodeDecodeError:
        return f"Error: File is not valid UTF-8 text"
    except Exception as e:
        # Log the full traceback for debugging
        traceback.print_exc()
        return f"Unexpected error: {type(e).__name__}: {e}"
```

### Validation Before Processing

```python
import re

@mcp.tool()
def send_email(to: str, subject: str, body: str) -> str:
    """
    Send an email with validation.
    
    Args:
        to: Recipient email address
        subject: Email subject line
        body: Email body content
    
    Returns:
        Success or error message
    """
    # Validate email format
    email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    if not re.match(email_pattern, to):
        return f"Error: Invalid email address: {to}"
    
    # Validate subject
    if len(subject) > 200:
        return "Error: Subject line too long (max 200 characters)"
    
    if not subject.strip():
        return "Error: Subject cannot be empty"
    
    # Validate body
    if len(body) > 10000:
        return "Error: Email body too long (max 10000 characters)"
    
    # Send email (simulated)
    return f"Email sent successfully to {to}"
```

---

## Multiple Code Examples

### Example 1: File Operations Tool

```python
import os
from pathlib import Path

@mcp.tool()
def list_directory(
    path: str = ".",
    pattern: str = "*",
    include_hidden: bool = False
) -> str:
    """
    List files in a directory.
    
    Args:
        path: Directory path to list (default: current directory)
        pattern: Glob pattern to filter files (default: all files)
        include_hidden: Whether to include hidden files (default: false)
    
    Returns:
        List of files matching the criteria
    """
    try:
        dir_path = Path(path)
        if not dir_path.exists():
            return f"Error: Directory not found: {path}"
        if not dir_path.is_dir():
            return f"Error: Not a directory: {path}"
        
        files = []
        for item in dir_path.glob(pattern):
            if not include_hidden and item.name.startswith('.'):
                continue
            
            item_type = "dir" if item.is_dir() else "file"
            size = item.stat().st_size if item.is_file() else 0
            files.append({
                "name": item.name,
                "type": item_type,
                "size": size
            })
        
        return json.dumps(files, indent=2)
    
    except PermissionError:
        return f"Error: Permission denied: {path}"
    except Exception as e:
        return f"Error: {e}"


@mcp.tool()
def read_file(filepath: str, max_lines: int = 100) -> str:
    """
    Read contents of a text file.
    
    Args:
        filepath: Path to the file to read
        max_lines: Maximum number of lines to read (default: 100)
    
    Returns:
        File contents or error message
    """
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            lines = []
            for i, line in enumerate(f):
                if i >= max_lines:
                    lines.append(f"\n... (truncated at {max_lines} lines)")
                    break
                lines.append(line)
            return ''.join(lines)
    
    except FileNotFoundError:
        return f"Error: File not found: {filepath}"
    except UnicodeDecodeError:
        return f"Error: File is not valid UTF-8 text"
    except Exception as e:
        return f"Error reading file: {e}"


@mcp.tool()
def write_file(filepath: str, content: str, append: bool = False) -> str:
    """
    Write content to a file.
    
    Args:
        filepath: Path to the file to write
        content: Content to write
        append: Whether to append to existing file (default: overwrite)
    
    Returns:
        Success or error message
    """
    try:
        mode = 'a' if append else 'w'
        with open(filepath, mode, encoding='utf-8') as f:
            f.write(content)
        
        action = "appended to" if append else "written to"
        return f"Successfully {action} {filepath}"
    
    except PermissionError:
        return f"Error: Permission denied: {filepath}"
    except Exception as e:
        return f"Error writing file: {e}"
```

### Example 2: Data Processing Tools

```python
import json
import csv
from io import StringIO

@mcp.tool()
def parse_json(json_string: str) -> str:
    """
    Parse and validate JSON data.
    
    Args:
        json_string: JSON string to parse
    
    Returns:
        Formatted JSON or error message
    """
    try:
        data = json.loads(json_string)
        return json.dumps(data, indent=2)
    except json.JSONDecodeError as e:
        return f"Invalid JSON: {e}"


@mcp.tool()
def csv_to_json(csv_data: str, has_header: bool = True) -> str:
    """
    Convert CSV data to JSON format.
    
    Args:
        csv_data: CSV string data
        has_header: Whether the CSV has a header row (default: true)
    
    Returns:
        JSON array of objects or arrays
    """
    try:
        reader = csv.reader(StringIO(csv_data))
        rows = list(reader)
        
        if not rows:
            return "[]"
        
        if has_header:
            headers = rows[0]
            data = [dict(zip(headers, row)) for row in rows[1:]]
        else:
            data = rows
        
        return json.dumps(data, indent=2)
    
    except Exception as e:
        return f"Error parsing CSV: {e}"


@mcp.tool()
def filter_data(
    json_data: str,
    field: str,
    value: str,
    operator: Literal["equals", "contains", "startswith", "endswith"] = "equals"
) -> str:
    """
    Filter JSON array data by a field value.
    
    Args:
        json_data: JSON array string
        field: Field name to filter on
        value: Value to match
        operator: Comparison operator (equals, contains, startswith, endswith)
    
    Returns:
        Filtered JSON array
    """
    try:
        data = json.loads(json_data)
        
        if not isinstance(data, list):
            return "Error: Input must be a JSON array"
        
        def matches(item: dict) -> bool:
            if field not in item:
                return False
            
            item_value = str(item[field])
            if operator == "equals":
                return item_value == value
            elif operator == "contains":
                return value in item_value
            elif operator == "startswith":
                return item_value.startswith(value)
            elif operator == "endswith":
                return item_value.endswith(value)
            return False
        
        filtered = [item for item in data if matches(item)]
        return json.dumps(filtered, indent=2)
    
    except json.JSONDecodeError:
        return "Error: Invalid JSON input"
    except Exception as e:
        return f"Error filtering data: {e}"
```

### Example 3: Calculator Tools with History

```python
from dataclasses import dataclass
from typing import List
import math

# Global calculation history
calculation_history: List[dict] = []

@mcp.tool()
def calculate(expression: str) -> str:
    """
    Evaluate a mathematical expression.
    
    Supports: +, -, *, /, **, sqrt(), sin(), cos(), tan(), log(), abs()
    
    Args:
        expression: Mathematical expression to evaluate
    
    Returns:
        Calculation result
    """
    # Safe evaluation with limited functions
    allowed_names = {
        'sqrt': math.sqrt,
        'sin': math.sin,
        'cos': math.cos,
        'tan': math.tan,
        'log': math.log,
        'log10': math.log10,
        'abs': abs,
        'pow': pow,
        'pi': math.pi,
        'e': math.e
    }
    
    try:
        # Remove any dangerous characters
        safe_expr = expression.replace('^', '**')
        
        # Evaluate with restricted namespace
        result = eval(safe_expr, {"__builtins__": {}}, allowed_names)
        
        # Store in history
        calculation_history.append({
            "expression": expression,
            "result": result
        })
        
        return str(result)
    
    except ZeroDivisionError:
        return "Error: Division by zero"
    except Exception as e:
        return f"Error: Invalid expression - {e}"


@mcp.tool()
def get_calculation_history(limit: int = 10) -> str:
    """
    Get recent calculation history.
    
    Args:
        limit: Maximum number of entries to return (default: 10)
    
    Returns:
        Recent calculations as JSON
    """
    recent = calculation_history[-limit:]
    return json.dumps(recent, indent=2)


@mcp.tool()
def clear_calculation_history() -> str:
    """Clear all calculation history."""
    global calculation_history
    count = len(calculation_history)
    calculation_history = []
    return f"Cleared {count} calculations from history"
```

### Example 4: API Integration Tool

```python
import httpx
from typing import Optional

@mcp.tool()
async def api_request(
    url: str,
    method: Literal["GET", "POST", "PUT", "DELETE"] = "GET",
    headers: Optional[str] = None,
    body: Optional[str] = None,
    timeout: int = 30
) -> str:
    """
    Make an HTTP API request.
    
    Args:
        url: The URL to request
        method: HTTP method (GET, POST, PUT, DELETE)
        headers: Optional JSON string of headers
        body: Optional request body (for POST/PUT)
        timeout: Request timeout in seconds (default: 30)
    
    Returns:
        Response status and body
    """
    try:
        # Parse headers if provided
        request_headers = {}
        if headers:
            try:
                request_headers = json.loads(headers)
            except json.JSONDecodeError:
                return "Error: Invalid headers JSON"
        
        # Parse body if provided
        request_body = None
        if body and method in ["POST", "PUT"]:
            request_body = body
        
        async with httpx.AsyncClient() as client:
            response = await client.request(
                method=method,
                url=url,
                headers=request_headers,
                content=request_body,
                timeout=timeout
            )
            
            # Format response
            result = {
                "status_code": response.status_code,
                "headers": dict(response.headers),
                "body": response.text[:5000]  # Limit response size
            }
            
            if len(response.text) > 5000:
                result["truncated"] = True
                result["full_length"] = len(response.text)
            
            return json.dumps(result, indent=2)
    
    except httpx.TimeoutException:
        return f"Error: Request timed out after {timeout}s"
    except httpx.ConnectError:
        return f"Error: Could not connect to {url}"
    except Exception as e:
        return f"Error: {e}"
```

---

## Best Practices Summary

### 1. Naming Conventions

```python
# Good: Clear, action-oriented names
@mcp.tool()
def create_user(...): ...

@mcp.tool()
def search_documents(...): ...

@mcp.tool()
def validate_email(...): ...

# Avoid: Vague or unclear names
@mcp.tool()
def do_stuff(...): ...

@mcp.tool()
def process(...): ...
```

### 2. Documentation

```python
# Good: Comprehensive docstring
@mcp.tool()
def send_notification(
    user_id: str,
    message: str,
    priority: Literal["low", "normal", "high"] = "normal"
) -> str:
    """
    Send a notification to a user.
    
    Args:
        user_id: The unique identifier of the user
        message: Notification message (max 500 characters)
        priority: Notification priority level (default: normal)
    
    Returns:
        Confirmation with notification ID
    """
    ...
```

### 3. Type Safety

```python
# Good: Explicit types
@mcp.tool()
def calculate_total(prices: list[float], tax_rate: float = 0.0) -> float:
    ...

# Avoid: Any or untyped
@mcp.tool()
def calculate_total(prices, tax_rate=0.0):
    ...
```

### 4. Error Handling

```python
# Good: Graceful error handling
@mcp.tool()
def divide(a: float, b: float) -> str:
    """Divide a by b."""
    if b == 0:
        return "Error: Cannot divide by zero"
    return str(a / b)

# Also good: Raising with clear message
@mcp.tool()
def divide(a: float, b: float) -> float:
    """Divide a by b."""
    if b == 0:
        raise ValueError("Cannot divide by zero - please provide a non-zero divisor")
    return a / b
```

### 5. Input Validation

```python
@mcp.tool()
def create_user(username: str, email: str) -> str:
    """Create a new user."""
    # Validate inputs
    if len(username) < 3:
        return "Error: Username must be at least 3 characters"
    if len(username) > 50:
        return "Error: Username must be at most 50 characters"
    if "@" not in email:
        return "Error: Invalid email address"
    
    # Proceed with creation
    return f"User {username} created"
```

---

## Summary

| Concept | Implementation |
|---------|----------------|
| **Basic Tool** | `@mcp.tool()` decorator |
| **Custom Name** | `@mcp.tool(name="custom_name")` |
| **Description** | Docstring or `description=` parameter |
| **Parameters** | Python type hints |
| **Optional Params** | Default values: `param: str = "default"` |
| **Async Tool** | `async def tool_name(...)` |
| **Error Handling** | Return error strings or raise exceptions |

---

## Next Steps

- [Resources with FastMCP](_04_resources_with_fastmcp.md) - Exposing data to LLMs
- [Prompts with FastMCP](_05_prompts_with_fastmcp.md) - Creating prompt templates
