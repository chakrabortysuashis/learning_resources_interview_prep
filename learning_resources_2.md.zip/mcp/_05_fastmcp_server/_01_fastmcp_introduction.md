# FastMCP Introduction

## Module 5.1: Understanding FastMCP

---

## What is FastMCP?

**FastMCP** is a high-level Python framework that simplifies building Model Context Protocol (MCP) servers. It provides a clean, decorator-based API that abstracts away the complexity of the underlying MCP SDK, allowing developers to focus on building functionality rather than protocol mechanics.

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         FastMCP OVERVIEW                                     │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│    Your Code                FastMCP                    MCP Protocol         │
│    ─────────                ───────                    ────────────         │
│                                                                             │
│    @mcp.tool()         ┌──────────────┐          ┌──────────────────┐       │
│    def add(a, b):  ──▶ │   FastMCP    │    ──▶   │  tools/call      │       │
│        return a+b      │   Framework  │          │  JSON-RPC        │       │
│                        │              │          │  Messages        │       │
│    @mcp.resource()     │  - Routing   │          │                  │       │
│    def get_data():  ──▶│  - Validation│    ──▶   │  resources/read  │       │
│        return data     │  - Transport │          │                  │       │
│                        │  - Lifecycle │          │                  │       │
│    @mcp.prompt()       │              │          │                  │       │
│    def chat():      ──▶│              │    ──▶   │  prompts/get     │       │
│        return msgs     └──────────────┘          └──────────────────┘       │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

FastMCP was created to provide a "FastAPI-like" experience for MCP server development - minimal boilerplate, intuitive decorators, and automatic schema generation.

---

## Why Use FastMCP Over Raw MCP SDK?

### The Problem with Low-Level MCP SDK

Building an MCP server with the raw MCP SDK requires:
- Manual message handling
- Explicit schema definitions
- Transport setup and management
- Request/response correlation
- Error handling boilerplate

### FastMCP Solution

FastMCP abstracts all of this into simple decorators:

```python
# Raw MCP SDK approach (simplified, but still verbose)
from mcp.server import Server
from mcp.types import Tool, TextContent

server = Server("my-server")

@server.list_tools()
async def list_tools():
    return [
        Tool(
            name="add_numbers",
            description="Add two numbers together",
            inputSchema={
                "type": "object",
                "properties": {
                    "a": {"type": "number", "description": "First number"},
                    "b": {"type": "number", "description": "Second number"}
                },
                "required": ["a", "b"]
            }
        )
    ]

@server.call_tool()
async def call_tool(name: str, arguments: dict):
    if name == "add_numbers":
        result = arguments["a"] + arguments["b"]
        return [TextContent(type="text", text=str(result))]
    raise ValueError(f"Unknown tool: {name}")
```

```python
# FastMCP approach - same functionality
from fastmcp import FastMCP

mcp = FastMCP("my-server")

@mcp.tool()
def add_numbers(a: float, b: float) -> float:
    """Add two numbers together."""
    return a + b
```

The FastMCP version is:
- **80% less code**
- **Self-documenting** (docstrings become descriptions)
- **Type-safe** (Python type hints become JSON schemas)
- **Automatic validation** (parameters are validated before your function runs)

---

## Key Features and Benefits

### 1. Decorator-Based API

```python
@mcp.tool()      # Define tools (functions the LLM can call)
@mcp.resource()  # Define resources (data the LLM can read)
@mcp.prompt()    # Define prompts (conversation templates)
```

### 2. Automatic Schema Generation

FastMCP automatically generates JSON schemas from Python type hints:

```python
@mcp.tool()
def search_users(
    query: str,           # Required string parameter
    limit: int = 10,      # Optional with default
    active: bool = True   # Optional boolean
) -> list[dict]:
    """Search for users in the database."""
    ...
```

Generated schema:
```json
{
  "name": "search_users",
  "description": "Search for users in the database.",
  "inputSchema": {
    "type": "object",
    "properties": {
      "query": {"type": "string"},
      "limit": {"type": "integer", "default": 10},
      "active": {"type": "boolean", "default": true}
    },
    "required": ["query"]
  }
}
```

### 3. Multiple Transport Support

```python
# Run via stdio (for CLI integration like Claude Desktop)
mcp.run()

# Run via HTTP with SSE (for web clients)
mcp.run(transport="sse", port=8000)
```

### 4. Built-in Validation

FastMCP validates inputs before your function executes:

```python
@mcp.tool()
def divide(a: float, b: float) -> float:
    """Divide a by b."""
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b

# If called with b="not a number", FastMCP returns a validation error
# before your code even runs
```

### 5. Async Support

```python
@mcp.tool()
async def fetch_data(url: str) -> str:
    """Fetch data from a URL asynchronously."""
    async with httpx.AsyncClient() as client:
        response = await client.get(url)
        return response.text
```

### 6. Context and Dependencies

```python
from fastmcp import FastMCP, Context

@mcp.tool()
async def log_action(ctx: Context, message: str) -> str:
    """Log an action with context."""
    await ctx.info(f"Action logged: {message}")
    return f"Logged: {message}"
```

---

## Comparison: FastMCP vs Low-Level MCP SDK

| Feature | FastMCP | Raw MCP SDK |
|---------|---------|-------------|
| **Learning Curve** | Low - familiar decorator pattern | Medium - requires protocol knowledge |
| **Boilerplate** | Minimal | Significant |
| **Schema Definition** | Automatic from type hints | Manual JSON Schema |
| **Validation** | Built-in | Manual implementation |
| **Error Handling** | Automatic conversion | Manual error responses |
| **Transport Setup** | One-liner | Manual configuration |
| **Async Support** | Native | Native |
| **Flexibility** | High-level abstraction | Full protocol control |
| **Use Case** | Most MCP servers | Custom protocol extensions |

### When to Use FastMCP

- Building new MCP servers quickly
- Standard tools, resources, and prompts
- Rapid prototyping
- Production servers with typical requirements

### When to Use Raw MCP SDK

- Need fine-grained control over protocol messages
- Implementing custom MCP extensions
- Non-standard transport requirements
- Educational purposes (understanding the protocol)

---

## Installation and Setup

### Prerequisites

- Python 3.10 or higher
- pip or uv package manager

### Installation Methods

#### Using pip

```bash
pip install fastmcp
```

#### Using uv (recommended for faster installs)

```bash
uv pip install fastmcp
```

#### Install with all dependencies

```bash
pip install "fastmcp[all]"
```

### Verify Installation

```python
import fastmcp
print(f"FastMCP version: {fastmcp.__version__}")
```

### Development Setup

For development with additional tools:

```bash
# Create a virtual environment
python -m venv mcp-env

# Activate it
# Windows:
mcp-env\Scripts\activate
# Linux/Mac:
source mcp-env/bin/activate

# Install FastMCP with dev dependencies
pip install fastmcp httpx uvicorn
```

---

## Project Structure

A typical FastMCP project structure:

```
my_mcp_server/
├── server.py           # Main server file
├── tools/              # Tool implementations
│   ├── __init__.py
│   ├── math_tools.py
│   └── file_tools.py
├── resources/          # Resource definitions
│   ├── __init__.py
│   └── config.py
├── prompts/            # Prompt templates
│   ├── __init__.py
│   └── templates.py
├── requirements.txt    # Dependencies
└── README.md           # Documentation
```

### Minimal Server Example

```python
# server.py
from fastmcp import FastMCP

# Create the server instance
mcp = FastMCP(
    name="My MCP Server",
    version="1.0.0"
)

# Define a simple tool
@mcp.tool()
def hello(name: str = "World") -> str:
    """Say hello to someone."""
    return f"Hello, {name}!"

# Define a simple resource
@mcp.resource("info://server")
def server_info() -> str:
    """Get server information."""
    return "My MCP Server v1.0.0"

# Run the server
if __name__ == "__main__":
    mcp.run()
```

---

## Quick Start: Your First FastMCP Server

Let's build a simple calculator server step by step:

### Step 1: Create the Server

```python
# calculator_server.py
from fastmcp import FastMCP

# Initialize FastMCP with a name
mcp = FastMCP("Calculator Server")
```

### Step 2: Add Tools

```python
@mcp.tool()
def add(a: float, b: float) -> float:
    """Add two numbers together."""
    return a + b

@mcp.tool()
def subtract(a: float, b: float) -> float:
    """Subtract b from a."""
    return a - b

@mcp.tool()
def multiply(a: float, b: float) -> float:
    """Multiply two numbers."""
    return a * b

@mcp.tool()
def divide(a: float, b: float) -> float:
    """Divide a by b."""
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b
```

### Step 3: Add a Resource

```python
@mcp.resource("calculator://history")
def get_history() -> str:
    """Get calculation history."""
    return "No calculations yet. Use the tools to perform operations."
```

### Step 4: Run the Server

```python
if __name__ == "__main__":
    # Run via stdio (default)
    mcp.run()
    
    # Or run via HTTP:
    # mcp.run(transport="sse", port=8000)
```

### Complete Server

```python
# calculator_server.py
from fastmcp import FastMCP

mcp = FastMCP("Calculator Server")

@mcp.tool()
def add(a: float, b: float) -> float:
    """Add two numbers together."""
    return a + b

@mcp.tool()
def subtract(a: float, b: float) -> float:
    """Subtract b from a."""
    return a - b

@mcp.tool()
def multiply(a: float, b: float) -> float:
    """Multiply two numbers."""
    return a * b

@mcp.tool()
def divide(a: float, b: float) -> float:
    """Divide a by b."""
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b

@mcp.resource("calculator://history")
def get_history() -> str:
    """Get calculation history."""
    return "No calculations yet."

if __name__ == "__main__":
    mcp.run()
```

### Test with MCP Inspector

```bash
# Install the inspector
npm install -g @modelcontextprotocol/inspector

# Run your server with the inspector
mcp-inspector python calculator_server.py
```

---

## Summary

FastMCP provides a developer-friendly interface for building MCP servers:

| Concept | FastMCP Approach |
|---------|------------------|
| **Server Creation** | `FastMCP("name")` |
| **Tools** | `@mcp.tool()` decorator |
| **Resources** | `@mcp.resource("uri")` decorator |
| **Prompts** | `@mcp.prompt()` decorator |
| **Running** | `mcp.run()` or `mcp.run(transport="sse")` |

In the next section, we'll dive deeper into creating your first server with detailed configuration options.

---

## Next Steps

- [Creating Your First Server](_02_creating_your_first_server.md) - Detailed server setup
- [Tools with FastMCP](_03_tools_with_fastmcp.md) - Building powerful tools
- [Resources with FastMCP](_04_resources_with_fastmcp.md) - Exposing data
