# Prompts with FastMCP

## Module 5.5: Creating Prompt Templates

---

## Overview

Prompts in MCP are pre-defined message templates that help LLMs interact with your server in specific, useful ways. Unlike tools (which perform actions) or resources (which provide data), prompts guide the conversation structure and provide context for specific tasks.

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        MCP PROMPTS FLOW                                      │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   Client                   MCP Server                   LLM                 │
│   ──────                   ──────────                   ───                 │
│                                                                             │
│   1. prompts/list  ──▶     Return available            User sees prompt    │
│                            prompts list                 options             │
│                                                                             │
│   2. prompts/get   ──▶     Return prompt               Prompt messages     │
│      {name, args}          messages                    sent to LLM         │
│                                                                             │
│   3.               ◀──     Messages with               LLM processes       │
│                            context/instructions        the prompt          │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### When to Use Prompts

| Use Case | Example |
|----------|---------|
| **Task Templates** | "Summarize this document" |
| **Guided Workflows** | "Help me debug this error" |
| **Context Setting** | "Act as a code reviewer" |
| **Multi-step Tasks** | "Analyze and report on data" |
| **Standardized Interactions** | "Generate unit tests for..." |

---

## The @mcp.prompt() Decorator

### Basic Syntax

```python
from fastmcp import FastMCP

mcp = FastMCP("Prompt Server")

@mcp.prompt()
def code_review() -> str:
    """Review code for best practices and potential issues."""
    return """Please review the following code for:
1. Code quality and readability
2. Potential bugs or errors
3. Performance issues
4. Security vulnerabilities
5. Best practices

Provide specific suggestions for improvement."""
```

### Decorator Parameters

```python
@mcp.prompt(
    name: str = None,        # Override function name
    description: str = None  # Override docstring description
)
```

### Custom Name and Description

```python
@mcp.prompt(name="review", description="Perform a comprehensive code review")
def code_review_prompt() -> str:
    """This docstring is ignored when description is provided."""
    return "Please review the code..."
```

---

## Prompt Arguments

Prompts can accept arguments to customize their content dynamically.

### Basic Arguments

```python
@mcp.prompt()
def greet_user(name: str) -> str:
    """Generate a personalized greeting."""
    return f"""Hello {name}! 

I'm your AI assistant. How can I help you today?

I can help with:
- Answering questions
- Writing and editing content
- Analyzing data
- Coding assistance

What would you like to work on?"""
```

### Multiple Arguments

```python
@mcp.prompt()
def analyze_code(language: str, focus: str = "general") -> str:
    """
    Generate a prompt for code analysis.
    
    Args:
        language: Programming language of the code
        focus: Analysis focus (general, performance, security, style)
    """
    focus_instructions = {
        "general": "Look for bugs, code quality, and best practices.",
        "performance": "Focus on performance optimizations and efficiency.",
        "security": "Identify security vulnerabilities and risks.",
        "style": "Check coding style, naming conventions, and readability."
    }
    
    instruction = focus_instructions.get(focus, focus_instructions["general"])
    
    return f"""Please analyze the following {language} code.

Focus: {focus.capitalize()} Analysis
Instructions: {instruction}

After analysis, provide:
1. A summary of findings
2. Specific issues with line references
3. Recommended fixes
4. Overall code quality rating (1-10)"""
```

### Arguments with Validation

```python
from typing import Literal

@mcp.prompt()
def generate_tests(
    language: Literal["python", "javascript", "typescript", "java"],
    framework: str = "default",
    coverage: Literal["unit", "integration", "e2e"] = "unit"
) -> str:
    """
    Generate test cases for code.
    
    Args:
        language: Programming language
        framework: Test framework to use
        coverage: Type of test coverage
    """
    frameworks = {
        "python": "pytest",
        "javascript": "jest",
        "typescript": "jest",
        "java": "JUnit"
    }
    
    if framework == "default":
        framework = frameworks.get(language, "generic")
    
    return f"""Generate {coverage} tests for the following {language} code.

Test Framework: {framework}
Coverage Type: {coverage.upper()}

Requirements:
1. Write comprehensive test cases
2. Include edge cases
3. Add descriptive test names
4. Include setup and teardown if needed
5. Aim for high code coverage

Output the tests in proper {framework} format."""
```

---

## Multi-Message Prompts

Prompts can return multiple messages to set up complex conversations.

### Returning a List of Messages

```python
from fastmcp.prompts import UserMessage, AssistantMessage

@mcp.prompt()
def debug_session(error_type: str) -> list:
    """
    Start a debugging session for a specific error type.
    
    Args:
        error_type: Type of error (syntax, runtime, logic, performance)
    """
    return [
        UserMessage(content=f"I'm encountering a {error_type} error in my code."),
        AssistantMessage(content=f"""I'll help you debug this {error_type} error. To assist effectively, please provide:

1. **The error message** - Copy the exact error text
2. **Relevant code** - The code section where the error occurs
3. **Context** - What you were trying to accomplish
4. **Steps to reproduce** - How to trigger the error

Once you share these details, I'll analyze the issue and guide you through fixing it.""")
    ]
```

### Complex Multi-Turn Setup

```python
@mcp.prompt()
def code_interview(difficulty: str = "medium", topic: str = "algorithms") -> list:
    """
    Set up a coding interview practice session.
    
    Args:
        difficulty: Problem difficulty (easy, medium, hard)
        topic: Topic area (algorithms, data structures, system design)
    """
    difficulty_desc = {
        "easy": "straightforward problem suitable for beginners",
        "medium": "moderately challenging problem requiring good understanding",
        "hard": "complex problem requiring advanced techniques"
    }
    
    return [
        UserMessage(content=f"I want to practice a {difficulty} {topic} problem."),
        AssistantMessage(content=f"""Great! Let's do a {difficulty} {topic} problem.

**Interview Format:**
- I'll present a problem
- You can ask clarifying questions
- Think through your approach before coding
- I'll provide hints if you get stuck
- After solving, we'll discuss optimizations

**Difficulty Level:** {difficulty.capitalize()}
This will be a {difficulty_desc[difficulty]}.

**Ready?** Say "yes" to receive the problem, or let me know if you'd like a different topic."""),
        UserMessage(content="Yes, I'm ready."),
        AssistantMessage(content=f"""Here's your {topic} problem:

**[PROBLEM WILL BE INSERTED HERE]**

Take a moment to:
1. Understand the problem statement
2. Ask any clarifying questions
3. Think about edge cases
4. Consider the time and space complexity you're aiming for

When you're ready, walk me through your approach before coding.""")
    ]
```

---

## Dynamic Prompt Generation

Generate prompts based on runtime data.

### Data-Driven Prompts

```python
# Simulated data store
DOCUMENTS_DB = {
    "doc1": {"title": "Project Proposal", "content": "..."},
    "doc2": {"title": "Technical Spec", "content": "..."},
    "doc3": {"title": "User Guide", "content": "..."}
}

@mcp.prompt()
def summarize_document(doc_id: str) -> str:
    """
    Generate a summarization prompt for a specific document.
    
    Args:
        doc_id: Document ID to summarize
    """
    if doc_id not in DOCUMENTS_DB:
        return f"Error: Document '{doc_id}' not found. Available: {list(DOCUMENTS_DB.keys())}"
    
    doc = DOCUMENTS_DB[doc_id]
    
    return f"""Please summarize the following document:

**Title:** {doc['title']}

**Content:**
{doc['content']}

Provide:
1. A brief summary (2-3 sentences)
2. Key points (bullet list)
3. Any action items mentioned
4. Questions or unclear areas"""
```

### Context-Aware Prompts

```python
import os
from datetime import datetime

@mcp.prompt()
def daily_standup() -> str:
    """Generate a daily standup prompt with current context."""
    current_time = datetime.now()
    day_name = current_time.strftime("%A")
    date_str = current_time.strftime("%B %d, %Y")
    
    # Customize based on day
    if current_time.weekday() == 0:  # Monday
        extra = "\n\nSince it's Monday, also briefly mention anything from last week that carried over."
    elif current_time.weekday() == 4:  # Friday
        extra = "\n\nSince it's Friday, include any items that need attention before the weekend."
    else:
        extra = ""
    
    return f"""Daily Standup - {day_name}, {date_str}

Please share your standup update:

1. **What did you accomplish yesterday?**
   - List completed tasks
   - Note any PRs merged or reviewed

2. **What are you working on today?**
   - Current focus areas
   - Estimated completion times

3. **Any blockers or concerns?**
   - Dependencies on others
   - Technical challenges
   - Resource needs{extra}

Keep it concise - aim for 2-3 bullet points per section."""
```

### Template-Based Prompts

```python
PROMPT_TEMPLATES = {
    "bug_report": """
**Bug Report Analysis**

Please analyze this bug report and provide:

1. **Root Cause Analysis**
   - What likely caused this bug?
   - What components are affected?

2. **Impact Assessment**
   - Severity level (Critical/High/Medium/Low)
   - Users affected
   - Business impact

3. **Resolution Plan**
   - Recommended fix approach
   - Testing requirements
   - Rollout considerations

Bug Details:
{details}
""",
    "feature_request": """
**Feature Request Review**

Evaluate this feature request:

1. **Feasibility**
   - Technical complexity
   - Required resources
   - Time estimate

2. **Value Assessment**
   - User benefit
   - Business value
   - Strategic alignment

3. **Recommendation**
   - Priority level
   - Implementation approach
   - Dependencies

Feature Details:
{details}
""",
    "code_migration": """
**Code Migration Guide**

Help with migrating code:

From: {source}
To: {target}

Provide:
1. Key differences between versions
2. Breaking changes to watch for
3. Step-by-step migration plan
4. Testing checklist
"""
}

@mcp.prompt()
def from_template(template: str, **kwargs) -> str:
    """
    Generate a prompt from a predefined template.
    
    Args:
        template: Template name (bug_report, feature_request, code_migration)
        **kwargs: Template variables
    """
    if template not in PROMPT_TEMPLATES:
        available = ", ".join(PROMPT_TEMPLATES.keys())
        return f"Unknown template: {template}. Available: {available}"
    
    try:
        return PROMPT_TEMPLATES[template].format(**kwargs)
    except KeyError as e:
        return f"Missing required variable: {e}"
```

---

## Practical Examples

### Example 1: Writing Assistant Prompts

```python
from fastmcp import FastMCP

mcp = FastMCP("Writing Assistant")

@mcp.prompt()
def improve_writing(style: str = "professional") -> str:
    """
    Prompt to improve written content.
    
    Args:
        style: Writing style (professional, casual, academic, creative)
    """
    style_guides = {
        "professional": "Clear, concise, and business-appropriate",
        "casual": "Friendly, conversational, and approachable",
        "academic": "Formal, well-cited, and scholarly",
        "creative": "Engaging, vivid, and expressive"
    }
    
    guide = style_guides.get(style, style_guides["professional"])
    
    return f"""Please improve the following text.

**Target Style:** {style.capitalize()}
**Guideline:** {guide}

Improvements to make:
1. Fix grammar and spelling errors
2. Improve clarity and flow
3. Enhance word choice
4. Adjust tone to match the target style
5. Optimize sentence structure

Provide:
- The improved version
- A brief explanation of key changes
- Any suggestions for further improvement"""


@mcp.prompt()
def generate_outline(content_type: str, topic: str) -> str:
    """
    Generate a content outline.
    
    Args:
        content_type: Type of content (article, blog, report, presentation)
        topic: The topic to outline
    """
    structures = {
        "article": ["Introduction", "Background", "Main Points (3-5)", "Analysis", "Conclusion"],
        "blog": ["Hook", "Introduction", "Main Content", "Key Takeaways", "Call to Action"],
        "report": ["Executive Summary", "Introduction", "Methodology", "Findings", "Recommendations", "Conclusion"],
        "presentation": ["Title Slide", "Agenda", "Introduction", "Main Sections (3-4)", "Summary", "Q&A"]
    }
    
    structure = structures.get(content_type, structures["article"])
    structure_text = "\n".join([f"- {s}" for s in structure])
    
    return f"""Create a detailed outline for a {content_type} about: {topic}

**Suggested Structure:**
{structure_text}

For each section, provide:
1. Main heading
2. 2-3 sub-points or bullet points
3. Estimated word count or time (for presentations)

Consider:
- Target audience
- Key messages
- Supporting evidence or examples
- Logical flow"""


@mcp.prompt()
def proofread(check_level: str = "standard") -> str:
    """
    Proofread content with specified thoroughness.
    
    Args:
        check_level: Level of checking (quick, standard, thorough)
    """
    checks = {
        "quick": ["Spelling", "Basic grammar", "Obvious errors"],
        "standard": ["Spelling", "Grammar", "Punctuation", "Clarity", "Consistency"],
        "thorough": ["Spelling", "Grammar", "Punctuation", "Style", "Tone", 
                    "Clarity", "Consistency", "Fact-checking suggestions", "Readability"]
    }
    
    check_list = checks.get(check_level, checks["standard"])
    check_text = "\n".join([f"- {c}" for c in check_list])
    
    return f"""Please proofread the following content.

**Check Level:** {check_level.capitalize()}

**Items to Check:**
{check_text}

For each issue found:
1. Quote the original text
2. Explain the issue
3. Provide the correction
4. (Optional) Explain why

At the end, provide:
- Total issues found by category
- Overall quality assessment
- Suggestions for improvement"""
```

### Example 2: Developer Prompts

```python
mcp = FastMCP("Developer Assistant")

@mcp.prompt()
def explain_code(detail_level: str = "medium") -> str:
    """
    Explain code with varying detail levels.
    
    Args:
        detail_level: How detailed (brief, medium, detailed)
    """
    instructions = {
        "brief": "Provide a 2-3 sentence summary of what the code does.",
        "medium": "Explain the code's purpose, main components, and how they work together.",
        "detailed": "Provide a line-by-line explanation with comments on design decisions, patterns used, and potential improvements."
    }
    
    return f"""Please explain the following code.

**Detail Level:** {detail_level.capitalize()}
**Instructions:** {instructions.get(detail_level, instructions['medium'])}

Include:
- What the code does (purpose)
- How it works (mechanism)
- Key concepts used
- Any notable patterns or techniques

{f"Also note: Input/output expectations, edge cases handled, and complexity analysis." if detail_level == "detailed" else ""}"""


@mcp.prompt()
def refactor_code(goal: str = "readability") -> str:
    """
    Refactor code with a specific goal.
    
    Args:
        goal: Refactoring goal (readability, performance, maintainability, testability)
    """
    goals = {
        "readability": {
            "focus": "Clear names, simple logic, good comments",
            "techniques": ["Rename variables/functions", "Extract methods", "Simplify conditionals", "Add comments"]
        },
        "performance": {
            "focus": "Speed and efficiency",
            "techniques": ["Optimize algorithms", "Reduce complexity", "Cache results", "Minimize allocations"]
        },
        "maintainability": {
            "focus": "Easy to modify and extend",
            "techniques": ["Apply SOLID principles", "Reduce coupling", "Add abstractions", "Document interfaces"]
        },
        "testability": {
            "focus": "Easy to test in isolation",
            "techniques": ["Dependency injection", "Pure functions", "Interface segregation", "Mock-friendly design"]
        }
    }
    
    goal_info = goals.get(goal, goals["readability"])
    techniques = "\n".join([f"- {t}" for t in goal_info["techniques"]])
    
    return f"""Please refactor the following code.

**Goal:** {goal.capitalize()}
**Focus:** {goal_info['focus']}

**Suggested Techniques:**
{techniques}

Provide:
1. The refactored code
2. Explanation of changes made
3. Benefits of the changes
4. Any trade-offs to consider

Ensure the refactored code maintains the same functionality."""


@mcp.prompt()
def api_design(style: str = "rest") -> str:
    """
    Design an API endpoint.
    
    Args:
        style: API style (rest, graphql, grpc)
    """
    conventions = {
        "rest": "RESTful conventions (resources, HTTP methods, status codes)",
        "graphql": "GraphQL schema design (types, queries, mutations)",
        "grpc": "gRPC service definition (Protocol Buffers)"
    }
    
    return f"""Design an API for the described functionality.

**Style:** {style.upper()}
**Conventions:** {conventions.get(style, conventions['rest'])}

Provide:
1. Endpoint/Operation definitions
2. Request/Response schemas
3. Authentication requirements
4. Error handling
5. Example requests and responses

Consider:
- RESTful principles (for REST)
- Versioning strategy
- Rate limiting
- Documentation format"""
```

### Example 3: Analysis Prompts

```python
mcp = FastMCP("Analysis Assistant")

@mcp.prompt()
def data_analysis(analysis_type: str = "exploratory") -> str:
    """
    Analyze data with a specific approach.
    
    Args:
        analysis_type: Type of analysis (exploratory, statistical, predictive)
    """
    approaches = {
        "exploratory": {
            "goal": "Understand the data and find patterns",
            "steps": ["Summary statistics", "Data types and distributions", "Missing values", "Outliers", "Correlations", "Visualizations"]
        },
        "statistical": {
            "goal": "Test hypotheses and quantify relationships",
            "steps": ["Hypothesis formulation", "Test selection", "Assumptions check", "Statistical tests", "Effect sizes", "Confidence intervals"]
        },
        "predictive": {
            "goal": "Build models to predict outcomes",
            "steps": ["Feature engineering", "Model selection", "Training/validation split", "Model training", "Evaluation metrics", "Predictions"]
        }
    }
    
    approach = approaches.get(analysis_type, approaches["exploratory"])
    steps = "\n".join([f"{i+1}. {s}" for i, s in enumerate(approach["steps"])])
    
    return f"""Perform {analysis_type} data analysis.

**Goal:** {approach['goal']}

**Analysis Steps:**
{steps}

For each step, provide:
- What you found
- Key insights
- Visualizations (describe or suggest)
- Implications

Conclude with:
- Summary of key findings
- Recommendations
- Limitations of the analysis
- Suggested next steps"""


@mcp.prompt()
def competitive_analysis(industry: str = "technology") -> str:
    """
    Perform competitive analysis.
    
    Args:
        industry: Industry context
    """
    return f"""Perform a competitive analysis in the {industry} industry.

**Analysis Framework:**

1. **Market Overview**
   - Market size and growth
   - Key trends
   - Regulatory factors

2. **Competitor Identification**
   - Direct competitors
   - Indirect competitors
   - Emerging players

3. **Comparative Analysis**
   - Product/service offerings
   - Pricing strategies
   - Target markets
   - Strengths and weaknesses

4. **Competitive Positioning**
   - Unique value propositions
   - Market share estimates
   - Brand positioning

5. **Strategic Insights**
   - Opportunities
   - Threats
   - Recommended strategies

Present findings in a structured format with supporting data where available."""


@mcp.prompt()
def root_cause_analysis() -> str:
    """Perform root cause analysis on a problem."""
    return """Perform a Root Cause Analysis (RCA) on the described problem.

**Analysis Methodology:**

1. **Problem Statement**
   - Clear description of the issue
   - Impact and scope
   - Timeline of events

2. **Data Gathering**
   - What do we know?
   - What evidence do we have?
   - What's missing?

3. **Cause Analysis (5 Whys)**
   - Why did this happen? (Level 1)
   - Why? (Level 2)
   - Why? (Level 3)
   - Why? (Level 4)
   - Why? (Root Cause)

4. **Fishbone Diagram Categories**
   - People
   - Process
   - Technology
   - Environment
   - Materials/Data

5. **Root Cause Identification**
   - Primary root cause(s)
   - Contributing factors
   - Evidence supporting each

6. **Recommendations**
   - Immediate actions
   - Long-term solutions
   - Preventive measures
   - Success metrics

Document findings clearly with evidence for each conclusion."""
```

---

## Best Practices

### 1. Clear Purpose

```python
# Good: Specific, focused prompt
@mcp.prompt()
def security_audit() -> str:
    """Audit code for security vulnerabilities."""
    return "Review the code for OWASP Top 10 vulnerabilities..."

# Avoid: Vague, unfocused prompt
@mcp.prompt()
def review() -> str:
    """Review stuff."""
    return "Please review..."
```

### 2. Structured Output Requests

```python
@mcp.prompt()
def structured_analysis() -> str:
    """Request structured analysis output."""
    return """Analyze and provide output in this format:

**Summary:** (2-3 sentences)

**Key Findings:**
1. Finding one
2. Finding two
3. Finding three

**Recommendations:**
- Recommendation one
- Recommendation two

**Next Steps:**
1. Step one
2. Step two"""
```

### 3. Context Setting

```python
@mcp.prompt()
def expert_mode(domain: str) -> str:
    """Set expert context for specialized tasks."""
    return f"""You are an expert {domain} specialist.

In this conversation:
- Use technical terminology appropriate for {domain}
- Assume I have professional knowledge in this field
- Provide detailed, nuanced analysis
- Reference industry standards and best practices
- Be direct and skip basic explanations

Ready for your {domain} questions and tasks."""
```

### 4. Argument Validation

```python
@mcp.prompt()
def validated_prompt(
    level: Literal["beginner", "intermediate", "advanced"] = "intermediate",
    format: Literal["text", "code", "diagram"] = "text"
) -> str:
    """Prompt with validated arguments."""
    return f"Explain at {level} level using {format} format..."
```

---

## Summary

| Concept | Implementation |
|---------|----------------|
| **Basic Prompt** | `@mcp.prompt()` returning `str` |
| **With Arguments** | `def prompt(arg: str) -> str` |
| **Custom Name** | `@mcp.prompt(name="custom")` |
| **Multi-Message** | Return `list` of `UserMessage`/`AssistantMessage` |
| **Validated Args** | Use `Literal` type hints |
| **Dynamic Content** | Generate based on runtime data |

---

## Next Steps

- [Context and Dependencies](_06_context_and_dependencies.md) - Advanced server features
- [Complete Server Example](_07_fastmcp_complete_server.ipynb) - Putting it all together
