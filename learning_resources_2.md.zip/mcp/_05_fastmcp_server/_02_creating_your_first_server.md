# Creating Your First FastMCP Server

## Module 5.2: Server Setup and Configuration

---

## Basic FastMCP Server Structure

Every FastMCP server follows a simple pattern:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    FastMCP SERVER STRUCTURE                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   1. Import          from fastmcp import FastMCP                            │
│         │                                                                   │
│         ▼                                                                   │
│   2. Initialize      mcp = FastMCP("Server Name")                           │
│         │                                                                   │
│         ▼                                                                   │
│   3. Define          @mcp.tool()                                            │
│      Components      @mcp.resource()                                        │
│                      @mcp.prompt()                                          │
│         │                                                                   │
│         ▼                                                                   │
│   4. Run             mcp.run()                                              │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Minimal Server

```python
from fastmcp import FastMCP

# Create server instance
mcp = FastMCP("Minimal Server")

# Define at least one component (tool, resource, or prompt)
@mcp.tool()
def ping() -> str:
    """Check if the server is running."""
    return "pong"

# Run the server
if __name__ == "__main__":
    mcp.run()
```

---

## The FastMCP Class

The `FastMCP` class is the core of your server. It manages registration, routing, and transport.

### Constructor Signature

```python
from fastmcp import FastMCP

mcp = FastMCP(
    name: str = "FastMCP",           # Server name (required)
    instructions: str | None = None,  # Instructions for LLM
    version: str = "0.1.0",          # Server version
    **settings                        # Additional settings
)
```

### Parameters Explained

| Parameter | Type | Description |
|-----------|------|-------------|
| `name` | `str` | Human-readable server name, shown to clients |
| `instructions` | `str` | Optional instructions that help the LLM understand how to use your server |
| `version` | `str` | Semantic version string |

### Example with All Options

```python
from fastmcp import FastMCP

mcp = FastMCP(
    name="Data Analytics Server",
    instructions="""
    This server provides data analytics capabilities.
    Use the 'analyze_data' tool for statistical analysis.
    Use the 'query_database' tool for SQL queries.
    Resources provide access to cached datasets.
    """,
    version="2.1.0"
)
```

### Server Instance Methods

```python
# Register components
mcp.tool()          # Decorator to register a tool
mcp.resource()      # Decorator to register a resource
mcp.prompt()        # Decorator to register a prompt

# Run the server
mcp.run()           # Start the server

# Access registered components
mcp.list_tools()    # Get all registered tools
mcp.list_resources() # Get all registered resources
mcp.list_prompts()  # Get all registered prompts
```

---

## Running Servers: stdio vs HTTP

FastMCP supports multiple transport methods for different use cases.

### Transport Comparison

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      TRANSPORT OPTIONS                                       │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   STDIO Transport                    HTTP/SSE Transport                     │
│   ────────────────                   ──────────────────                     │
│                                                                             │
│   ┌──────────┐     stdin/stdout     ┌──────────┐                            │
│   │  Client  │◀───────────────────▶ │  Server  │                            │
│   │(Claude   │      (pipes)         │ (Python) │                            │
│   │ Desktop) │                      └──────────┘                            │
│   └──────────┘                                                              │
│                                                                             │
│   Best for:                          Best for:                              │
│   - Claude Desktop                   - Web clients                          │
│   - CLI tools                        - Multiple clients                     │
│   - Single client                    - Remote access                        │
│   - Local integration                - Development/testing                  │
│                                                                             │
│   ┌──────────┐     HTTP + SSE       ┌──────────┐                            │
│   │  Client  │◀───────────────────▶ │  Server  │                            │
│   │  (Any)   │    POST + Events     │ (uvicorn)│                            │
│   └──────────┘                      └──────────┘                            │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### STDIO Transport (Default)

STDIO is the default transport, ideal for local integrations:

```python
from fastmcp import FastMCP

mcp = FastMCP("My Server")

@mcp.tool()
def hello() -> str:
    """Say hello."""
    return "Hello!"

if __name__ == "__main__":
    # Default: runs via stdio
    mcp.run()
```

**Use STDIO when:**
- Integrating with Claude Desktop
- Building CLI tools
- Single client connections
- Maximum simplicity

### HTTP/SSE Transport

For web clients or multiple connections:

```python
from fastmcp import FastMCP

mcp = FastMCP("Web Server")

@mcp.tool()
def hello() -> str:
    """Say hello."""
    return "Hello!"

if __name__ == "__main__":
    # Run via HTTP with Server-Sent Events
    mcp.run(transport="sse", host="0.0.0.0", port=8000)
```

**SSE Transport Options:**

| Option | Default | Description |
|--------|---------|-------------|
| `host` | `"127.0.0.1"` | Host address to bind |
| `port` | `8000` | Port number |
| `log_level` | `"info"` | Logging level |

**Use HTTP/SSE when:**
- Building web applications
- Need multiple concurrent clients
- Remote access is required
- Testing with HTTP tools

### Running with Different Transports

```python
import sys
from fastmcp import FastMCP

mcp = FastMCP("Flexible Server")

@mcp.tool()
def greet(name: str) -> str:
    """Greet someone."""
    return f"Hello, {name}!"

if __name__ == "__main__":
    # Check command line argument
    if len(sys.argv) > 1 and sys.argv[1] == "--http":
        print("Starting HTTP server on port 8000...")
        mcp.run(transport="sse", port=8000)
    else:
        print("Starting stdio server...")
        mcp.run()
```

---

## Server Configuration Options

### Environment-Based Configuration

```python
import os
from fastmcp import FastMCP

mcp = FastMCP(
    name=os.getenv("MCP_SERVER_NAME", "Default Server"),
    version=os.getenv("MCP_VERSION", "1.0.0")
)

@mcp.tool()
def get_env(key: str) -> str:
    """Get an environment variable."""
    return os.getenv(key, f"Variable '{key}' not found")

if __name__ == "__main__":
    port = int(os.getenv("MCP_PORT", "8000"))
    transport = os.getenv("MCP_TRANSPORT", "stdio")
    
    if transport == "sse":
        mcp.run(transport="sse", port=port)
    else:
        mcp.run()
```

### Logging Configuration

```python
import logging
from fastmcp import FastMCP

# Configure logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

mcp = FastMCP("Logged Server")

@mcp.tool()
def process_data(data: str) -> str:
    """Process some data with logging."""
    logger.info(f"Processing data: {data[:50]}...")
    result = data.upper()
    logger.info(f"Processing complete")
    return result

if __name__ == "__main__":
    logger.info("Starting server...")
    mcp.run()
```

---

## Step-by-Step Guide: Building a Notes Server

Let's build a practical notes management server step by step.

### Step 1: Project Setup

```bash
# Create project directory
mkdir notes_server
cd notes_server

# Create virtual environment
python -m venv venv
source venv/bin/activate  # or venv\Scripts\activate on Windows

# Install FastMCP
pip install fastmcp
```

### Step 2: Create the Server File

```python
# notes_server.py
from fastmcp import FastMCP
from datetime import datetime
from typing import Optional

# Initialize the server
mcp = FastMCP(
    name="Notes Server",
    instructions="""
    This server manages personal notes.
    - Use 'create_note' to create new notes
    - Use 'list_notes' to see all notes
    - Use 'get_note' to read a specific note
    - Use 'delete_note' to remove a note
    - Access 'notes://all' resource for a summary
    """,
    version="1.0.0"
)
```

### Step 3: Add Data Storage

```python
# In-memory storage (in production, use a database)
notes_db: dict[str, dict] = {}
```

### Step 4: Add Tools

```python
@mcp.tool()
def create_note(title: str, content: str, tags: Optional[str] = None) -> str:
    """
    Create a new note.
    
    Args:
        title: The title of the note
        content: The note content
        tags: Optional comma-separated tags
    
    Returns:
        Confirmation message with note ID
    """
    note_id = f"note_{len(notes_db) + 1}"
    notes_db[note_id] = {
        "title": title,
        "content": content,
        "tags": tags.split(",") if tags else [],
        "created": datetime.now().isoformat(),
        "updated": datetime.now().isoformat()
    }
    return f"Note created with ID: {note_id}"


@mcp.tool()
def list_notes() -> str:
    """
    List all notes.
    
    Returns:
        A formatted list of all notes with their IDs and titles
    """
    if not notes_db:
        return "No notes found. Create one with 'create_note'."
    
    lines = ["Notes:"]
    for note_id, note in notes_db.items():
        tags = ", ".join(note["tags"]) if note["tags"] else "none"
        lines.append(f"  - {note_id}: {note['title']} (tags: {tags})")
    return "\n".join(lines)


@mcp.tool()
def get_note(note_id: str) -> str:
    """
    Get the full content of a note.
    
    Args:
        note_id: The ID of the note to retrieve
    
    Returns:
        The full note content and metadata
    """
    if note_id not in notes_db:
        return f"Note '{note_id}' not found. Use 'list_notes' to see available notes."
    
    note = notes_db[note_id]
    return f"""
Title: {note['title']}
Created: {note['created']}
Updated: {note['updated']}
Tags: {', '.join(note['tags']) if note['tags'] else 'none'}

Content:
{note['content']}
"""


@mcp.tool()
def update_note(note_id: str, content: str) -> str:
    """
    Update the content of an existing note.
    
    Args:
        note_id: The ID of the note to update
        content: The new content
    
    Returns:
        Confirmation message
    """
    if note_id not in notes_db:
        return f"Note '{note_id}' not found."
    
    notes_db[note_id]["content"] = content
    notes_db[note_id]["updated"] = datetime.now().isoformat()
    return f"Note '{note_id}' updated successfully."


@mcp.tool()
def delete_note(note_id: str) -> str:
    """
    Delete a note.
    
    Args:
        note_id: The ID of the note to delete
    
    Returns:
        Confirmation message
    """
    if note_id not in notes_db:
        return f"Note '{note_id}' not found."
    
    title = notes_db[note_id]["title"]
    del notes_db[note_id]
    return f"Note '{note_id}' ({title}) deleted successfully."


@mcp.tool()
def search_notes(query: str) -> str:
    """
    Search notes by title or content.
    
    Args:
        query: Search term to look for
    
    Returns:
        List of matching notes
    """
    query_lower = query.lower()
    matches = []
    
    for note_id, note in notes_db.items():
        if (query_lower in note["title"].lower() or 
            query_lower in note["content"].lower()):
            matches.append(f"  - {note_id}: {note['title']}")
    
    if not matches:
        return f"No notes found matching '{query}'."
    
    return f"Notes matching '{query}':\n" + "\n".join(matches)
```

### Step 5: Add Resources

```python
@mcp.resource("notes://all")
def get_all_notes_summary() -> str:
    """Get a summary of all notes."""
    if not notes_db:
        return "No notes in the system."
    
    summary = [f"Total notes: {len(notes_db)}\n"]
    for note_id, note in notes_db.items():
        summary.append(f"[{note_id}] {note['title']}")
    return "\n".join(summary)


@mcp.resource("notes://stats")
def get_notes_stats() -> str:
    """Get statistics about notes."""
    if not notes_db:
        return "No notes to analyze."
    
    total = len(notes_db)
    all_tags = []
    total_chars = 0
    
    for note in notes_db.values():
        all_tags.extend(note["tags"])
        total_chars += len(note["content"])
    
    unique_tags = list(set(all_tags))
    avg_length = total_chars // total if total > 0 else 0
    
    return f"""
Notes Statistics:
- Total notes: {total}
- Unique tags: {len(unique_tags)}
- Tags: {', '.join(unique_tags) if unique_tags else 'none'}
- Average note length: {avg_length} characters
"""
```

### Step 6: Add Prompts

```python
@mcp.prompt()
def summarize_notes() -> str:
    """Generate a summary prompt for all notes."""
    if not notes_db:
        return "There are no notes to summarize."
    
    notes_text = []
    for note_id, note in notes_db.items():
        notes_text.append(f"## {note['title']}\n{note['content']}")
    
    return f"""Please summarize the following notes:

{chr(10).join(notes_text)}

Provide a brief overview of the main topics and key points."""


@mcp.prompt()
def organize_by_topic() -> str:
    """Generate a prompt to organize notes by topic."""
    return """Please analyze all available notes and suggest a way to organize 
them by topic. Consider creating categories and identifying related notes that 
could be merged or linked together."""
```

### Step 7: Complete Server File

```python
# notes_server.py - Complete version
from fastmcp import FastMCP
from datetime import datetime
from typing import Optional

# Initialize the server
mcp = FastMCP(
    name="Notes Server",
    instructions="""
    This server manages personal notes.
    - Use 'create_note' to create new notes
    - Use 'list_notes' to see all notes  
    - Use 'get_note' to read a specific note
    - Use 'search_notes' to find notes
    - Use 'update_note' to modify a note
    - Use 'delete_note' to remove a note
    - Access 'notes://all' resource for a summary
    - Access 'notes://stats' for statistics
    """,
    version="1.0.0"
)

# In-memory storage
notes_db: dict[str, dict] = {}

# === TOOLS ===

@mcp.tool()
def create_note(title: str, content: str, tags: Optional[str] = None) -> str:
    """Create a new note with optional tags (comma-separated)."""
    note_id = f"note_{len(notes_db) + 1}"
    notes_db[note_id] = {
        "title": title,
        "content": content,
        "tags": tags.split(",") if tags else [],
        "created": datetime.now().isoformat(),
        "updated": datetime.now().isoformat()
    }
    return f"Note created with ID: {note_id}"

@mcp.tool()
def list_notes() -> str:
    """List all notes with their IDs and titles."""
    if not notes_db:
        return "No notes found."
    
    lines = ["Notes:"]
    for note_id, note in notes_db.items():
        lines.append(f"  - {note_id}: {note['title']}")
    return "\n".join(lines)

@mcp.tool()
def get_note(note_id: str) -> str:
    """Get the full content of a note by its ID."""
    if note_id not in notes_db:
        return f"Note '{note_id}' not found."
    
    note = notes_db[note_id]
    return f"Title: {note['title']}\n\n{note['content']}"

@mcp.tool()
def update_note(note_id: str, content: str) -> str:
    """Update the content of an existing note."""
    if note_id not in notes_db:
        return f"Note '{note_id}' not found."
    
    notes_db[note_id]["content"] = content
    notes_db[note_id]["updated"] = datetime.now().isoformat()
    return f"Note '{note_id}' updated."

@mcp.tool()
def delete_note(note_id: str) -> str:
    """Delete a note by its ID."""
    if note_id not in notes_db:
        return f"Note '{note_id}' not found."
    
    del notes_db[note_id]
    return f"Note '{note_id}' deleted."

@mcp.tool()
def search_notes(query: str) -> str:
    """Search notes by title or content."""
    matches = [
        f"  - {nid}: {n['title']}"
        for nid, n in notes_db.items()
        if query.lower() in n["title"].lower() or query.lower() in n["content"].lower()
    ]
    return f"Matches:\n" + "\n".join(matches) if matches else "No matches found."

# === RESOURCES ===

@mcp.resource("notes://all")
def get_all_notes_summary() -> str:
    """Summary of all notes."""
    if not notes_db:
        return "No notes."
    return "\n".join([f"[{nid}] {n['title']}" for nid, n in notes_db.items()])

@mcp.resource("notes://stats")
def get_notes_stats() -> str:
    """Statistics about notes."""
    return f"Total notes: {len(notes_db)}"

# === PROMPTS ===

@mcp.prompt()
def summarize_notes() -> str:
    """Prompt to summarize all notes."""
    return "Please summarize all the notes in this system."

# === MAIN ===

if __name__ == "__main__":
    import sys
    
    if "--http" in sys.argv:
        print("Starting HTTP server on http://localhost:8000")
        mcp.run(transport="sse", port=8000)
    else:
        mcp.run()
```

### Step 8: Run and Test

```bash
# Run via stdio
python notes_server.py

# Or run via HTTP
python notes_server.py --http

# Test with MCP Inspector
npx @modelcontextprotocol/inspector python notes_server.py
```

---

## Integrating with Claude Desktop

To use your server with Claude Desktop, add it to the configuration:

### Configuration File Location

- **macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`
- **Windows**: `%APPDATA%\Claude\claude_desktop_config.json`

### Configuration Example

```json
{
  "mcpServers": {
    "notes": {
      "command": "python",
      "args": ["/full/path/to/notes_server.py"]
    }
  }
}
```

### Using with Virtual Environment

```json
{
  "mcpServers": {
    "notes": {
      "command": "/full/path/to/venv/bin/python",
      "args": ["/full/path/to/notes_server.py"]
    }
  }
}
```

---

## Best Practices

### 1. Server Naming

```python
# Good: Descriptive names
mcp = FastMCP("GitHub Issue Tracker")
mcp = FastMCP("Database Query Service")

# Avoid: Generic names
mcp = FastMCP("Server")
mcp = FastMCP("MCP")
```

### 2. Instructions

```python
# Good: Clear, helpful instructions
mcp = FastMCP(
    name="Email Server",
    instructions="""
    Manage emails through this server.
    
    Available operations:
    - send_email: Send a new email
    - list_inbox: View incoming emails
    - search_emails: Find specific emails
    
    Note: All email addresses must be valid.
    Rate limit: 10 emails per minute.
    """
)
```

### 3. Version Management

```python
# Use semantic versioning
mcp = FastMCP(name="My Server", version="1.0.0")  # Initial release
mcp = FastMCP(name="My Server", version="1.1.0")  # New feature
mcp = FastMCP(name="My Server", version="1.1.1")  # Bug fix
mcp = FastMCP(name="My Server", version="2.0.0")  # Breaking change
```

### 4. Error Handling

```python
@mcp.tool()
def safe_operation(value: str) -> str:
    """Perform a safe operation with error handling."""
    try:
        # Your logic here
        result = process(value)
        return f"Success: {result}"
    except ValueError as e:
        return f"Invalid value: {e}"
    except Exception as e:
        return f"Error: {e}"
```

---

## Summary

| Concept | Implementation |
|---------|----------------|
| **Create Server** | `mcp = FastMCP("Name", instructions="...", version="1.0.0")` |
| **Run stdio** | `mcp.run()` |
| **Run HTTP** | `mcp.run(transport="sse", port=8000)` |
| **Add Tool** | `@mcp.tool()` decorator |
| **Add Resource** | `@mcp.resource("uri://path")` decorator |
| **Add Prompt** | `@mcp.prompt()` decorator |

---

## Next Steps

- [Tools with FastMCP](_03_tools_with_fastmcp.md) - Deep dive into building tools
- [Resources with FastMCP](_04_resources_with_fastmcp.md) - Exposing data effectively
