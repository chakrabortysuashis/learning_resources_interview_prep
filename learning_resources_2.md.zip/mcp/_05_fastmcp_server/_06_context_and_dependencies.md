# Context and Dependencies in FastMCP

## Module 5.6: Advanced Server Features

---

## Overview

FastMCP provides advanced features for building production-ready servers, including context injection, dependency management, logging, progress reporting, and lifecycle events. These features help you build more sophisticated and maintainable MCP servers.

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    ADVANCED FastMCP FEATURES                                 │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                         SERVER LIFECYCLE                             │   │
│   │  startup ──▶ running (handling requests) ──▶ shutdown               │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│   ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐            │
│   │    Context      │  │  Dependencies   │  │   Lifecycle     │            │
│   │                 │  │                 │  │                 │            │
│   │ - Request info  │  │ - DB connection │  │ - Startup hook  │            │
│   │ - Logging       │  │ - API clients   │  │ - Shutdown hook │            │
│   │ - Progress      │  │ - Config        │  │ - State mgmt    │            │
│   │ - Metadata      │  │ - Services      │  │ - Cleanup       │            │
│   └─────────────────┘  └─────────────────┘  └─────────────────┘            │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Using Context in FastMCP

The `Context` object provides access to runtime information and server capabilities within your tools, resources, and prompts.

### Importing and Using Context

```python
from fastmcp import FastMCP, Context

mcp = FastMCP("Context Demo")

@mcp.tool()
async def my_tool(ctx: Context, message: str) -> str:
    """A tool that uses context."""
    # Context is automatically injected when declared as a parameter
    await ctx.info(f"Processing message: {message}")
    return f"Processed: {message}"
```

### Context Capabilities

The `Context` object provides several useful methods:

```python
@mcp.tool()
async def context_demo(ctx: Context) -> str:
    """Demonstrate context capabilities."""
    
    # Logging at different levels
    await ctx.debug("Debug message - detailed info for debugging")
    await ctx.info("Info message - general information")
    await ctx.warning("Warning message - potential issues")
    await ctx.error("Error message - something went wrong")
    
    # Report progress for long-running operations
    await ctx.report_progress(0.0, "Starting...")
    await ctx.report_progress(0.5, "Halfway done...")
    await ctx.report_progress(1.0, "Complete!")
    
    # Access request metadata
    request_id = ctx.request_id  # Unique identifier for this request
    
    return "Context demonstration complete"
```

### Logging with Context

```python
import asyncio

@mcp.tool()
async def process_data(ctx: Context, data: str) -> str:
    """Process data with detailed logging."""
    
    await ctx.info(f"Starting to process {len(data)} characters")
    
    try:
        # Simulate processing
        await ctx.debug("Validating input...")
        if not data.strip():
            await ctx.warning("Input data is empty or whitespace only")
            return "Warning: Empty input"
        
        await ctx.debug("Processing data...")
        result = data.upper()
        
        await ctx.info(f"Processing complete. Output: {len(result)} characters")
        return result
        
    except Exception as e:
        await ctx.error(f"Processing failed: {str(e)}")
        raise
```

### Progress Reporting

For long-running operations, report progress to keep the client informed:

```python
@mcp.tool()
async def long_operation(ctx: Context, items: list[str]) -> str:
    """Process multiple items with progress reporting."""
    total = len(items)
    results = []
    
    await ctx.report_progress(0.0, f"Starting to process {total} items")
    
    for i, item in enumerate(items):
        # Process item
        processed = item.upper()
        results.append(processed)
        
        # Report progress
        progress = (i + 1) / total
        await ctx.report_progress(progress, f"Processed {i + 1}/{total} items")
        
        # Simulate work
        await asyncio.sleep(0.1)
    
    await ctx.report_progress(1.0, "All items processed")
    return f"Processed {total} items: {results}"


@mcp.tool()
async def download_files(ctx: Context, urls: list[str]) -> str:
    """Download files with progress tracking."""
    import httpx
    
    total = len(urls)
    downloaded = []
    
    await ctx.report_progress(0.0, f"Preparing to download {total} files")
    
    async with httpx.AsyncClient() as client:
        for i, url in enumerate(urls):
            await ctx.info(f"Downloading: {url}")
            
            try:
                response = await client.get(url)
                downloaded.append({
                    "url": url,
                    "status": response.status_code,
                    "size": len(response.content)
                })
            except Exception as e:
                await ctx.warning(f"Failed to download {url}: {e}")
                downloaded.append({
                    "url": url,
                    "error": str(e)
                })
            
            progress = (i + 1) / total
            await ctx.report_progress(progress, f"Downloaded {i + 1}/{total}")
    
    return json.dumps(downloaded, indent=2)
```

---

## Dependency Injection

FastMCP supports dependency injection for sharing resources across tools and managing complex dependencies.

### Basic Dependency Pattern

```python
from fastmcp import FastMCP
from dataclasses import dataclass
from typing import Optional

# Define a service class
@dataclass
class DatabaseService:
    connection_string: str
    
    async def query(self, sql: str) -> list:
        # Simulated database query
        return [{"id": 1, "name": "Test"}]
    
    async def close(self):
        # Close connection
        pass

# Create the service
db_service = DatabaseService(connection_string="postgresql://localhost/mydb")

mcp = FastMCP("DI Demo")

@mcp.tool()
async def query_users() -> str:
    """Query users using injected database service."""
    results = await db_service.query("SELECT * FROM users")
    return json.dumps(results)
```

### Using Lifespan for Dependencies

For dependencies that need initialization and cleanup:

```python
from fastmcp import FastMCP
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from typing import Optional
import httpx

@dataclass
class AppState:
    """Shared application state."""
    db: Optional[object] = None
    http_client: Optional[httpx.AsyncClient] = None
    config: dict = field(default_factory=dict)

# Global state object
app_state = AppState()

@asynccontextmanager
async def lifespan(server):
    """Manage application lifecycle."""
    # Startup
    print("Starting server...")
    
    # Initialize resources
    app_state.http_client = httpx.AsyncClient()
    app_state.config = {"api_key": "xxx", "environment": "production"}
    
    # Simulate database connection
    app_state.db = {"connected": True}
    
    print("Server started")
    
    yield  # Server is running
    
    # Shutdown
    print("Shutting down server...")
    
    # Cleanup resources
    if app_state.http_client:
        await app_state.http_client.aclose()
    
    print("Server stopped")

mcp = FastMCP("Lifespan Demo", lifespan=lifespan)

@mcp.tool()
async def fetch_external_data(url: str) -> str:
    """Fetch data using the shared HTTP client."""
    if not app_state.http_client:
        return "Error: HTTP client not initialized"
    
    try:
        response = await app_state.http_client.get(url)
        return response.text[:1000]
    except Exception as e:
        return f"Error: {e}"

@mcp.tool()
def get_config() -> str:
    """Get application configuration."""
    return json.dumps(app_state.config, indent=2)
```

### Service Registry Pattern

```python
from fastmcp import FastMCP
from typing import Protocol, runtime_checkable
from dataclasses import dataclass

# Define service interfaces
@runtime_checkable
class StorageService(Protocol):
    async def save(self, key: str, data: str) -> bool: ...
    async def load(self, key: str) -> Optional[str]: ...
    async def delete(self, key: str) -> bool: ...

# Implement services
@dataclass
class InMemoryStorage:
    """In-memory storage implementation."""
    _data: dict = None
    
    def __post_init__(self):
        self._data = {}
    
    async def save(self, key: str, data: str) -> bool:
        self._data[key] = data
        return True
    
    async def load(self, key: str) -> Optional[str]:
        return self._data.get(key)
    
    async def delete(self, key: str) -> bool:
        if key in self._data:
            del self._data[key]
            return True
        return False

# Service registry
class ServiceRegistry:
    def __init__(self):
        self._services = {}
    
    def register(self, name: str, service: object):
        self._services[name] = service
    
    def get(self, name: str) -> object:
        return self._services.get(name)

# Initialize registry
registry = ServiceRegistry()
registry.register("storage", InMemoryStorage())

mcp = FastMCP("Service Registry Demo")

@mcp.tool()
async def save_data(key: str, value: str) -> str:
    """Save data to storage."""
    storage = registry.get("storage")
    if not storage:
        return "Error: Storage service not available"
    
    success = await storage.save(key, value)
    return f"Data saved: {success}"

@mcp.tool()
async def load_data(key: str) -> str:
    """Load data from storage."""
    storage = registry.get("storage")
    if not storage:
        return "Error: Storage service not available"
    
    data = await storage.load(key)
    if data is None:
        return f"No data found for key: {key}"
    return data
```

---

## Accessing Request Metadata

Context provides access to request-specific metadata:

```python
@mcp.tool()
async def request_info(ctx: Context) -> str:
    """Get information about the current request."""
    info = {
        "request_id": ctx.request_id,
        # Add any other available metadata
    }
    
    await ctx.info(f"Request info: {info}")
    return json.dumps(info, indent=2)
```

---

## Logging and Progress Reporting

### Structured Logging Pattern

```python
import logging
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s'
)
logger = logging.getLogger("mcp_server")

mcp = FastMCP("Logging Demo")

@mcp.tool()
async def structured_operation(ctx: Context, operation: str, data: str) -> str:
    """Perform an operation with structured logging."""
    
    # Log operation start
    start_time = datetime.now()
    logger.info(f"Operation started", extra={
        "operation": operation,
        "data_size": len(data),
        "timestamp": start_time.isoformat()
    })
    
    await ctx.info(f"Starting {operation}")
    
    try:
        # Perform operation
        await ctx.report_progress(0.5, f"Executing {operation}...")
        result = f"Processed: {data.upper()}"
        
        # Log success
        duration = (datetime.now() - start_time).total_seconds()
        logger.info(f"Operation completed", extra={
            "operation": operation,
            "duration_seconds": duration,
            "result_size": len(result)
        })
        
        await ctx.info(f"Completed {operation} in {duration:.2f}s")
        return result
        
    except Exception as e:
        # Log error
        logger.error(f"Operation failed", extra={
            "operation": operation,
            "error": str(e),
            "error_type": type(e).__name__
        })
        
        await ctx.error(f"Failed {operation}: {e}")
        raise
```

### Progress Reporter Pattern

```python
class ProgressReporter:
    """Helper class for reporting progress."""
    
    def __init__(self, ctx: Context, total_steps: int, task_name: str = "Task"):
        self.ctx = ctx
        self.total = total_steps
        self.current = 0
        self.task_name = task_name
    
    async def step(self, description: str = ""):
        """Report completion of one step."""
        self.current += 1
        progress = self.current / self.total
        message = f"{self.task_name}: Step {self.current}/{self.total}"
        if description:
            message += f" - {description}"
        await self.ctx.report_progress(progress, message)
    
    async def complete(self):
        """Mark task as complete."""
        await self.ctx.report_progress(1.0, f"{self.task_name}: Complete")


@mcp.tool()
async def multi_step_task(ctx: Context, items: list[str]) -> str:
    """Execute a multi-step task with progress tracking."""
    
    # Create progress reporter
    reporter = ProgressReporter(ctx, len(items) + 2, "Processing")
    
    # Step 1: Validate
    await ctx.debug("Validating input...")
    await reporter.step("Validating input")
    
    # Step 2: Process each item
    results = []
    for item in items:
        processed = item.strip().upper()
        results.append(processed)
        await reporter.step(f"Processed: {item[:20]}...")
    
    # Step 3: Finalize
    await ctx.debug("Finalizing results...")
    await reporter.step("Finalizing")
    await reporter.complete()
    
    return json.dumps(results)
```

---

## Lifespan Events

Lifespan events allow you to run code during server startup and shutdown.

### Basic Lifespan

```python
from contextlib import asynccontextmanager
from fastmcp import FastMCP

@asynccontextmanager
async def app_lifespan(server):
    """Manage application lifecycle."""
    
    # === STARTUP ===
    print("Server starting...")
    
    # Initialize resources
    resources = {
        "initialized_at": datetime.now().isoformat(),
        "status": "ready"
    }
    
    print(f"Resources initialized: {resources}")
    
    yield resources  # Server is running
    
    # === SHUTDOWN ===
    print("Server shutting down...")
    
    # Cleanup
    resources["status"] = "stopped"
    print("Cleanup complete")

mcp = FastMCP("Lifespan Demo", lifespan=app_lifespan)
```

### Advanced Lifespan with Database

```python
from contextlib import asynccontextmanager
import aiosqlite

# Shared database connection
db_connection = None

@asynccontextmanager
async def database_lifespan(server):
    """Manage database connection lifecycle."""
    global db_connection
    
    # Startup: Connect to database
    print("Connecting to database...")
    db_connection = await aiosqlite.connect("app.db")
    
    # Create tables if needed
    await db_connection.execute("""
        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY,
            title TEXT NOT NULL,
            completed BOOLEAN DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    await db_connection.commit()
    
    print("Database connected and initialized")
    
    yield
    
    # Shutdown: Close database
    print("Closing database connection...")
    if db_connection:
        await db_connection.close()
        db_connection = None
    print("Database connection closed")

mcp = FastMCP("Database App", lifespan=database_lifespan)

@mcp.tool()
async def add_task(title: str) -> str:
    """Add a new task."""
    if not db_connection:
        return "Error: Database not connected"
    
    await db_connection.execute(
        "INSERT INTO tasks (title) VALUES (?)",
        (title,)
    )
    await db_connection.commit()
    return f"Task added: {title}"

@mcp.tool()
async def list_tasks() -> str:
    """List all tasks."""
    if not db_connection:
        return "Error: Database not connected"
    
    async with db_connection.execute("SELECT * FROM tasks") as cursor:
        rows = await cursor.fetchall()
        tasks = [{"id": r[0], "title": r[1], "completed": bool(r[2])} for r in rows]
        return json.dumps(tasks, indent=2)
```

### Lifespan with Multiple Resources

```python
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
import httpx

@dataclass
class ServerResources:
    """Container for all server resources."""
    http_client: Optional[httpx.AsyncClient] = None
    cache: dict = field(default_factory=dict)
    config: dict = field(default_factory=dict)
    start_time: Optional[datetime] = None

resources = ServerResources()

@asynccontextmanager
async def multi_resource_lifespan(server):
    """Initialize and cleanup multiple resources."""
    global resources
    
    # Initialize all resources
    print("Initializing server resources...")
    
    resources.start_time = datetime.now()
    resources.http_client = httpx.AsyncClient(timeout=30.0)
    resources.config = {
        "max_cache_size": 1000,
        "environment": "production"
    }
    resources.cache = {}
    
    print("Resources initialized")
    
    yield
    
    # Cleanup all resources
    print("Cleaning up resources...")
    
    if resources.http_client:
        await resources.http_client.aclose()
    
    resources.cache.clear()
    
    print("Resources cleaned up")

mcp = FastMCP("Multi-Resource Server", lifespan=multi_resource_lifespan)

@mcp.tool()
def get_uptime() -> str:
    """Get server uptime."""
    if not resources.start_time:
        return "Server not initialized"
    
    uptime = datetime.now() - resources.start_time
    return f"Server uptime: {uptime}"

@mcp.tool()
def cache_get(key: str) -> str:
    """Get value from cache."""
    value = resources.cache.get(key)
    if value is None:
        return f"Key '{key}' not found in cache"
    return value

@mcp.tool()
def cache_set(key: str, value: str) -> str:
    """Set value in cache."""
    if len(resources.cache) >= resources.config.get("max_cache_size", 1000):
        return "Error: Cache is full"
    
    resources.cache[key] = value
    return f"Cached: {key}"
```

---

## Complete Example: Production-Ready Server

```python
from fastmcp import FastMCP, Context
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional
import json
import asyncio
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("production_server")

# Application state
@dataclass
class AppState:
    start_time: Optional[datetime] = None
    request_count: int = 0
    cache: dict = field(default_factory=dict)
    config: dict = field(default_factory=dict)

state = AppState()

@asynccontextmanager
async def production_lifespan(server):
    """Production server lifecycle management."""
    global state
    
    logger.info("Production server starting...")
    
    # Initialize state
    state.start_time = datetime.now()
    state.request_count = 0
    state.config = {
        "version": "1.0.0",
        "environment": "production",
        "max_cache_entries": 500
    }
    
    logger.info("Server initialized")
    
    yield
    
    logger.info("Server shutting down...")
    
    # Log final stats
    uptime = datetime.now() - state.start_time
    logger.info(f"Final stats: {state.request_count} requests, {uptime} uptime")
    
    # Cleanup
    state.cache.clear()
    
    logger.info("Server stopped")

# Create server
mcp = FastMCP(
    name="Production Server",
    instructions="""
    This is a production-ready MCP server demonstrating:
    - Context usage for logging and progress
    - Dependency injection patterns
    - Lifecycle management
    - Request tracking
    """,
    version="1.0.0",
    lifespan=production_lifespan
)

# === TOOLS ===

@mcp.tool()
async def process_data(ctx: Context, data: str, operation: str = "transform") -> str:
    """
    Process data with full context support.
    
    Args:
        data: Input data to process
        operation: Operation type (transform, analyze, validate)
    """
    global state
    state.request_count += 1
    
    await ctx.info(f"Processing request #{state.request_count}")
    
    try:
        await ctx.report_progress(0.2, f"Starting {operation}...")
        
        if operation == "transform":
            result = data.upper()
        elif operation == "analyze":
            result = json.dumps({"length": len(data), "words": len(data.split())})
        elif operation == "validate":
            result = "valid" if data.strip() else "invalid: empty"
        else:
            return f"Unknown operation: {operation}"
        
        await ctx.report_progress(0.8, "Finalizing...")
        await ctx.report_progress(1.0, "Complete")
        
        await ctx.info(f"Request #{state.request_count} completed successfully")
        return result
        
    except Exception as e:
        await ctx.error(f"Request #{state.request_count} failed: {e}")
        raise

@mcp.tool()
async def batch_process(ctx: Context, items: list[str]) -> str:
    """
    Process multiple items with progress tracking.
    
    Args:
        items: List of items to process
    """
    global state
    state.request_count += 1
    
    total = len(items)
    await ctx.info(f"Batch processing {total} items")
    
    results = []
    for i, item in enumerate(items):
        processed = item.strip().upper()
        results.append(processed)
        
        progress = (i + 1) / total
        await ctx.report_progress(progress, f"Processed {i + 1}/{total}")
        await asyncio.sleep(0.05)  # Simulate work
    
    await ctx.info(f"Batch complete: {total} items processed")
    return json.dumps(results)

@mcp.tool()
def get_server_stats() -> str:
    """Get current server statistics."""
    if not state.start_time:
        return json.dumps({"status": "not_started"})
    
    uptime = datetime.now() - state.start_time
    return json.dumps({
        "status": "running",
        "uptime_seconds": uptime.total_seconds(),
        "request_count": state.request_count,
        "cache_entries": len(state.cache),
        "config": state.config
    }, indent=2)

@mcp.tool()
def cache_operation(action: str, key: str = "", value: str = "") -> str:
    """
    Perform cache operations.
    
    Args:
        action: Cache action (get, set, delete, clear)
        key: Cache key (for get, set, delete)
        value: Cache value (for set)
    """
    if action == "get":
        cached = state.cache.get(key)
        return cached if cached else f"Key '{key}' not found"
    
    elif action == "set":
        if len(state.cache) >= state.config.get("max_cache_entries", 500):
            return "Error: Cache is full"
        state.cache[key] = value
        return f"Cached: {key}"
    
    elif action == "delete":
        if key in state.cache:
            del state.cache[key]
            return f"Deleted: {key}"
        return f"Key '{key}' not found"
    
    elif action == "clear":
        count = len(state.cache)
        state.cache.clear()
        return f"Cleared {count} entries"
    
    return f"Unknown action: {action}"

# === RESOURCES ===

@mcp.resource("status://health")
def get_health() -> str:
    """Get server health status."""
    return json.dumps({
        "status": "healthy" if state.start_time else "not_started",
        "timestamp": datetime.now().isoformat()
    })

@mcp.resource("status://config")
def get_config() -> str:
    """Get server configuration."""
    return json.dumps(state.config, indent=2)

# === PROMPTS ===

@mcp.prompt()
def debug_session() -> str:
    """Start a debugging session."""
    return f"""You are connected to a production MCP server.

Current status:
- Uptime: {(datetime.now() - state.start_time).total_seconds():.0f}s
- Requests: {state.request_count}
- Cache: {len(state.cache)} entries

Available operations:
- process_data: Transform, analyze, or validate data
- batch_process: Process multiple items
- get_server_stats: View server statistics
- cache_operation: Manage the cache

How can I help you debug today?"""

# === MAIN ===

if __name__ == "__main__":
    import sys
    
    if "--http" in sys.argv:
        logger.info("Starting HTTP server...")
        mcp.run(transport="sse", port=8000)
    else:
        logger.info("Starting stdio server...")
        mcp.run()
```

---

## Summary

| Feature | Implementation |
|---------|----------------|
| **Context Injection** | `async def tool(ctx: Context, ...)` |
| **Logging** | `await ctx.info/debug/warning/error(message)` |
| **Progress** | `await ctx.report_progress(0.5, "message")` |
| **Lifespan** | `FastMCP("name", lifespan=async_context_manager)` |
| **Startup Code** | Code before `yield` in lifespan |
| **Shutdown Code** | Code after `yield` in lifespan |
| **Shared State** | Global objects or class instances |

---

## Next Steps

- [Complete Server Example](_07_fastmcp_complete_server.ipynb) - Build a full-featured server
