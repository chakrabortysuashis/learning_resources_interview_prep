# Resources with FastMCP

## Module 5.4: Exposing Data to LLMs

---

## Overview

Resources in MCP are read-only data endpoints that LLMs can access. Unlike tools (which perform actions), resources provide data that the LLM can read and use in its responses. Think of resources as the "GET endpoints" of your MCP server.

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       RESOURCES vs TOOLS                                     │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   RESOURCES (Read Data)              TOOLS (Perform Actions)                │
│   ─────────────────────              ──────────────────────                 │
│                                                                             │
│   ┌─────────────┐                    ┌─────────────┐                        │
│   │ LLM Client  │                    │ LLM Client  │                        │
│   └──────┬──────┘                    └──────┬──────┘                        │
│          │ resources/read                   │ tools/call                    │
│          ▼                                  ▼                               │
│   ┌─────────────┐                    ┌─────────────┐                        │
│   │  Resource   │──▶ Returns data    │    Tool     │──▶ Performs action    │
│   │ (Passive)   │   (text, JSON)     │  (Active)   │   Returns result      │
│   └─────────────┘                    └─────────────┘                        │
│                                                                             │
│   Examples:                          Examples:                              │
│   - Configuration files              - Send email                           │
│   - Database records                 - Create user                          │
│   - Log contents                     - Execute query                        │
│   - System status                    - Deploy application                   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## The @mcp.resource() Decorator

### Basic Syntax

```python
from fastmcp import FastMCP

mcp = FastMCP("Resource Server")

@mcp.resource("config://app")
def get_app_config() -> str:
    """Get the application configuration."""
    return '{"debug": true, "version": "1.0.0"}'
```

### Decorator Parameters

```python
@mcp.resource(
    uri: str,                    # Required: Resource URI
    name: str = None,            # Optional: Display name
    description: str = None,     # Optional: Override docstring
    mime_type: str = "text/plain"  # Optional: Content type
)
```

### URI Format

Resources are identified by URIs following this pattern:

```
scheme://path[/subpath]

Examples:
- config://app
- file://documents/readme.txt
- data://users/123
- logs://server/2024-01-15
```

---

## URI Patterns and Templates

### Static URIs

Static URIs point to fixed resources:

```python
@mcp.resource("config://database")
def get_database_config() -> str:
    """Database connection configuration."""
    return json.dumps({
        "host": "localhost",
        "port": 5432,
        "database": "myapp"
    })

@mcp.resource("status://health")
def get_health_status() -> str:
    """System health status."""
    return "OK"

@mcp.resource("info://server")
def get_server_info() -> str:
    """Server information."""
    return json.dumps({
        "name": "My MCP Server",
        "version": "1.0.0",
        "uptime": "3h 24m"
    })
```

### URI Schemes

Common URI schemes used in MCP resources:

| Scheme | Purpose | Example |
|--------|---------|---------|
| `config://` | Configuration data | `config://database` |
| `file://` | File contents | `file://docs/readme.md` |
| `data://` | Application data | `data://users/profile` |
| `logs://` | Log entries | `logs://app/errors` |
| `status://` | System status | `status://services` |
| `info://` | Information | `info://about` |
| `cache://` | Cached data | `cache://results` |
| `template://` | Templates | `template://email/welcome` |

---

## Dynamic Resources with Parameters

FastMCP supports URI templates for dynamic resources.

### Basic Template

```python
@mcp.resource("users://{user_id}")
def get_user(user_id: str) -> str:
    """
    Get user information by ID.
    
    Args:
        user_id: The unique user identifier
    
    Returns:
        User details as JSON
    """
    # In production, fetch from database
    users = {
        "1": {"name": "Alice", "email": "alice@example.com"},
        "2": {"name": "Bob", "email": "bob@example.com"}
    }
    
    if user_id not in users:
        return json.dumps({"error": f"User {user_id} not found"})
    
    return json.dumps(users[user_id])
```

### Multiple Parameters

```python
@mcp.resource("logs://{service}/{date}")
def get_service_logs(service: str, date: str) -> str:
    """
    Get logs for a specific service on a specific date.
    
    Args:
        service: Service name (e.g., 'api', 'web', 'worker')
        date: Date in YYYY-MM-DD format
    
    Returns:
        Log entries for that service and date
    """
    return f"Logs for {service} on {date}:\n[2024-01-15 10:00] Service started\n[2024-01-15 10:05] Request processed"


@mcp.resource("data://{database}/{table}")
def get_table_schema(database: str, table: str) -> str:
    """
    Get the schema for a database table.
    
    Args:
        database: Database name
        table: Table name
    
    Returns:
        Table schema information
    """
    return json.dumps({
        "database": database,
        "table": table,
        "columns": [
            {"name": "id", "type": "integer", "primary": True},
            {"name": "name", "type": "varchar(100)"},
            {"name": "created_at", "type": "timestamp"}
        ]
    })
```

### Nested Path Parameters

```python
@mcp.resource("files://{path:path}")
def read_file(path: str) -> str:
    """
    Read a file from the filesystem.
    
    Args:
        path: File path (e.g., 'documents/report.txt')
    
    Returns:
        File contents
    """
    from pathlib import Path
    
    base_dir = Path("./data")
    file_path = base_dir / path
    
    # Security check: ensure path is within base_dir
    try:
        file_path.resolve().relative_to(base_dir.resolve())
    except ValueError:
        return "Error: Access denied - path outside allowed directory"
    
    if not file_path.exists():
        return f"Error: File not found: {path}"
    
    return file_path.read_text()
```

---

## Resource MIME Types

FastMCP supports specifying MIME types for resources:

### Common MIME Types

```python
# Plain text (default)
@mcp.resource("readme://main", mime_type="text/plain")
def get_readme() -> str:
    """Get the README content."""
    return "# My Project\n\nWelcome to my project."

# JSON data
@mcp.resource("api://config", mime_type="application/json")
def get_api_config() -> str:
    """Get API configuration."""
    return json.dumps({"api_key": "xxx", "endpoint": "https://api.example.com"})

# HTML content
@mcp.resource("docs://intro", mime_type="text/html")
def get_docs_intro() -> str:
    """Get introduction documentation."""
    return """
    <html>
        <head><title>Introduction</title></head>
        <body>
            <h1>Welcome</h1>
            <p>This is the introduction.</p>
        </body>
    </html>
    """

# Markdown
@mcp.resource("docs://guide", mime_type="text/markdown")
def get_guide() -> str:
    """Get the user guide."""
    return """
# User Guide

## Getting Started

1. Install the package
2. Configure your settings
3. Run the application

## Features

- Feature A
- Feature B
"""

# CSV data
@mcp.resource("export://users", mime_type="text/csv")
def export_users() -> str:
    """Export users as CSV."""
    return "id,name,email\n1,Alice,alice@example.com\n2,Bob,bob@example.com"

# XML data
@mcp.resource("data://feed", mime_type="application/xml")
def get_feed() -> str:
    """Get RSS feed."""
    return """<?xml version="1.0"?>
<rss version="2.0">
    <channel>
        <title>My Feed</title>
        <item><title>Post 1</title></item>
    </channel>
</rss>"""
```

### MIME Type Reference

| MIME Type | Use Case |
|-----------|----------|
| `text/plain` | Plain text content (default) |
| `application/json` | JSON data |
| `text/html` | HTML documents |
| `text/markdown` | Markdown content |
| `text/csv` | CSV data |
| `application/xml` | XML documents |
| `application/yaml` | YAML configuration |

---

## Async Resources

Resources can be asynchronous for I/O-bound operations:

### Basic Async Resource

```python
import asyncio

@mcp.resource("status://live")
async def get_live_status() -> str:
    """Get live system status."""
    await asyncio.sleep(0.1)  # Simulate async check
    return json.dumps({"status": "healthy", "timestamp": datetime.now().isoformat()})
```

### Async Database Resource

```python
import aiosqlite

@mcp.resource("data://users/all", mime_type="application/json")
async def get_all_users() -> str:
    """Get all users from database."""
    async with aiosqlite.connect("database.db") as db:
        async with db.execute("SELECT id, name, email FROM users") as cursor:
            rows = await cursor.fetchall()
            users = [{"id": r[0], "name": r[1], "email": r[2]} for r in rows]
            return json.dumps(users, indent=2)
```

### Async HTTP Resource

```python
import httpx

@mcp.resource("external://weather")
async def get_weather() -> str:
    """Get current weather from external API."""
    async with httpx.AsyncClient() as client:
        try:
            response = await client.get(
                "https://api.weather.example.com/current",
                timeout=10.0
            )
            return response.text
        except Exception as e:
            return json.dumps({"error": str(e)})


@mcp.resource("external://news/{category}")
async def get_news(category: str) -> str:
    """Get news by category from external API."""
    async with httpx.AsyncClient() as client:
        try:
            response = await client.get(
                f"https://api.news.example.com/{category}",
                timeout=10.0
            )
            return response.text
        except Exception as e:
            return json.dumps({"error": str(e)})
```

---

## Code Examples for Different Resource Types

### Example 1: Configuration Resources

```python
from fastmcp import FastMCP
import json
import os

mcp = FastMCP("Config Server")

# Application configuration
APP_CONFIG = {
    "name": "My Application",
    "version": "2.1.0",
    "environment": os.getenv("APP_ENV", "development"),
    "features": {
        "dark_mode": True,
        "notifications": True,
        "analytics": False
    }
}

DATABASE_CONFIG = {
    "host": os.getenv("DB_HOST", "localhost"),
    "port": int(os.getenv("DB_PORT", "5432")),
    "database": os.getenv("DB_NAME", "myapp"),
    "ssl": True
}

@mcp.resource("config://app", mime_type="application/json")
def get_app_config() -> str:
    """Get main application configuration."""
    return json.dumps(APP_CONFIG, indent=2)


@mcp.resource("config://database", mime_type="application/json")
def get_database_config() -> str:
    """Get database configuration (sensitive data redacted)."""
    safe_config = {**DATABASE_CONFIG}
    # Redact sensitive information
    safe_config["host"] = "****"
    return json.dumps(safe_config, indent=2)


@mcp.resource("config://features", mime_type="application/json")
def get_features() -> str:
    """Get feature flags."""
    return json.dumps(APP_CONFIG["features"], indent=2)


@mcp.resource("config://environment")
def get_environment() -> str:
    """Get current environment name."""
    return APP_CONFIG["environment"]
```

### Example 2: File System Resources

```python
from pathlib import Path
import mimetypes

mcp = FastMCP("File Server")

BASE_DIR = Path("./documents")

@mcp.resource("files://list")
def list_files() -> str:
    """List all files in the documents directory."""
    if not BASE_DIR.exists():
        return json.dumps({"error": "Documents directory not found"})
    
    files = []
    for item in BASE_DIR.rglob("*"):
        if item.is_file():
            files.append({
                "path": str(item.relative_to(BASE_DIR)),
                "size": item.stat().st_size,
                "modified": item.stat().st_mtime
            })
    
    return json.dumps(files, indent=2)


@mcp.resource("files://read/{filepath:path}")
def read_file(filepath: str) -> str:
    """
    Read a file's contents.
    
    Args:
        filepath: Relative path to the file
    """
    file_path = BASE_DIR / filepath
    
    # Security: ensure within base directory
    try:
        file_path.resolve().relative_to(BASE_DIR.resolve())
    except ValueError:
        return "Error: Access denied"
    
    if not file_path.exists():
        return f"Error: File not found: {filepath}"
    
    if not file_path.is_file():
        return f"Error: Not a file: {filepath}"
    
    try:
        return file_path.read_text()
    except UnicodeDecodeError:
        return f"Error: File is not text: {filepath}"


@mcp.resource("files://stats/{filepath:path}", mime_type="application/json")
def get_file_stats(filepath: str) -> str:
    """
    Get statistics about a file.
    
    Args:
        filepath: Relative path to the file
    """
    file_path = BASE_DIR / filepath
    
    if not file_path.exists():
        return json.dumps({"error": f"File not found: {filepath}"})
    
    stat = file_path.stat()
    mime_type, _ = mimetypes.guess_type(str(file_path))
    
    return json.dumps({
        "path": filepath,
        "size_bytes": stat.st_size,
        "created": stat.st_ctime,
        "modified": stat.st_mtime,
        "mime_type": mime_type or "unknown"
    }, indent=2)
```

### Example 3: Database Resources

```python
import json
from typing import Dict, List
from datetime import datetime

mcp = FastMCP("Database Server")

# Simulated database
USERS_DB: Dict[str, dict] = {
    "1": {"id": "1", "name": "Alice", "email": "alice@example.com", "role": "admin"},
    "2": {"id": "2", "name": "Bob", "email": "bob@example.com", "role": "user"},
    "3": {"id": "3", "name": "Charlie", "email": "charlie@example.com", "role": "user"}
}

ORDERS_DB: List[dict] = [
    {"id": "ord1", "user_id": "1", "amount": 99.99, "status": "completed"},
    {"id": "ord2", "user_id": "2", "amount": 49.99, "status": "pending"},
    {"id": "ord3", "user_id": "1", "amount": 149.99, "status": "shipped"}
]


@mcp.resource("db://users", mime_type="application/json")
def get_all_users() -> str:
    """Get all users from the database."""
    return json.dumps(list(USERS_DB.values()), indent=2)


@mcp.resource("db://users/{user_id}", mime_type="application/json")
def get_user(user_id: str) -> str:
    """
    Get a specific user by ID.
    
    Args:
        user_id: The user's unique identifier
    """
    if user_id not in USERS_DB:
        return json.dumps({"error": f"User not found: {user_id}"})
    return json.dumps(USERS_DB[user_id], indent=2)


@mcp.resource("db://users/{user_id}/orders", mime_type="application/json")
def get_user_orders(user_id: str) -> str:
    """
    Get all orders for a specific user.
    
    Args:
        user_id: The user's unique identifier
    """
    if user_id not in USERS_DB:
        return json.dumps({"error": f"User not found: {user_id}"})
    
    user_orders = [o for o in ORDERS_DB if o["user_id"] == user_id]
    return json.dumps(user_orders, indent=2)


@mcp.resource("db://orders", mime_type="application/json")
def get_all_orders() -> str:
    """Get all orders from the database."""
    return json.dumps(ORDERS_DB, indent=2)


@mcp.resource("db://orders/{order_id}", mime_type="application/json")
def get_order(order_id: str) -> str:
    """
    Get a specific order by ID.
    
    Args:
        order_id: The order's unique identifier
    """
    order = next((o for o in ORDERS_DB if o["id"] == order_id), None)
    if not order:
        return json.dumps({"error": f"Order not found: {order_id}"})
    return json.dumps(order, indent=2)


@mcp.resource("db://stats", mime_type="application/json")
def get_database_stats() -> str:
    """Get database statistics."""
    return json.dumps({
        "users_count": len(USERS_DB),
        "orders_count": len(ORDERS_DB),
        "total_revenue": sum(o["amount"] for o in ORDERS_DB),
        "last_updated": datetime.now().isoformat()
    }, indent=2)
```

### Example 4: Log Resources

```python
from datetime import datetime, timedelta
import random

mcp = FastMCP("Log Server")

# Simulated log storage
def generate_sample_logs(count: int = 50) -> list:
    """Generate sample log entries."""
    levels = ["DEBUG", "INFO", "WARNING", "ERROR"]
    services = ["api", "web", "worker", "database"]
    messages = [
        "Request processed successfully",
        "User logged in",
        "Database query executed",
        "Cache miss",
        "Connection timeout",
        "Rate limit exceeded",
        "File not found",
        "Authentication failed"
    ]
    
    logs = []
    base_time = datetime.now()
    
    for i in range(count):
        timestamp = base_time - timedelta(minutes=i * 2)
        logs.append({
            "timestamp": timestamp.isoformat(),
            "level": random.choice(levels),
            "service": random.choice(services),
            "message": random.choice(messages),
            "request_id": f"req_{i:05d}"
        })
    
    return logs

LOG_ENTRIES = generate_sample_logs(100)


@mcp.resource("logs://all", mime_type="application/json")
def get_all_logs() -> str:
    """Get all log entries (limited to most recent 100)."""
    return json.dumps(LOG_ENTRIES[:100], indent=2)


@mcp.resource("logs://recent/{count}")
def get_recent_logs(count: str) -> str:
    """
    Get the most recent N log entries.
    
    Args:
        count: Number of entries to return
    """
    try:
        n = min(int(count), 100)  # Cap at 100
    except ValueError:
        return json.dumps({"error": "Invalid count"})
    
    return json.dumps(LOG_ENTRIES[:n], indent=2)


@mcp.resource("logs://level/{level}")
def get_logs_by_level(level: str) -> str:
    """
    Get log entries filtered by level.
    
    Args:
        level: Log level (DEBUG, INFO, WARNING, ERROR)
    """
    level_upper = level.upper()
    if level_upper not in ["DEBUG", "INFO", "WARNING", "ERROR"]:
        return json.dumps({"error": f"Invalid level: {level}"})
    
    filtered = [l for l in LOG_ENTRIES if l["level"] == level_upper]
    return json.dumps(filtered, indent=2)


@mcp.resource("logs://service/{service}")
def get_logs_by_service(service: str) -> str:
    """
    Get log entries for a specific service.
    
    Args:
        service: Service name (api, web, worker, database)
    """
    filtered = [l for l in LOG_ENTRIES if l["service"] == service]
    if not filtered:
        return json.dumps({"error": f"No logs found for service: {service}"})
    return json.dumps(filtered, indent=2)


@mcp.resource("logs://errors", mime_type="application/json")
def get_error_logs() -> str:
    """Get all ERROR level log entries."""
    errors = [l for l in LOG_ENTRIES if l["level"] == "ERROR"]
    return json.dumps(errors, indent=2)


@mcp.resource("logs://summary", mime_type="application/json")
def get_log_summary() -> str:
    """Get a summary of log entries by level and service."""
    summary = {
        "total": len(LOG_ENTRIES),
        "by_level": {},
        "by_service": {}
    }
    
    for log in LOG_ENTRIES:
        # Count by level
        level = log["level"]
        summary["by_level"][level] = summary["by_level"].get(level, 0) + 1
        
        # Count by service
        service = log["service"]
        summary["by_service"][service] = summary["by_service"].get(service, 0) + 1
    
    return json.dumps(summary, indent=2)
```

### Example 5: System Status Resources

```python
import platform
import psutil  # pip install psutil
from datetime import datetime

mcp = FastMCP("System Monitor")


@mcp.resource("system://info", mime_type="application/json")
def get_system_info() -> str:
    """Get basic system information."""
    return json.dumps({
        "platform": platform.system(),
        "platform_version": platform.version(),
        "architecture": platform.machine(),
        "processor": platform.processor(),
        "python_version": platform.python_version(),
        "hostname": platform.node()
    }, indent=2)


@mcp.resource("system://cpu", mime_type="application/json")
def get_cpu_info() -> str:
    """Get CPU usage information."""
    return json.dumps({
        "percent": psutil.cpu_percent(interval=0.1),
        "count": psutil.cpu_count(),
        "count_logical": psutil.cpu_count(logical=True),
        "freq_mhz": psutil.cpu_freq().current if psutil.cpu_freq() else None
    }, indent=2)


@mcp.resource("system://memory", mime_type="application/json")
def get_memory_info() -> str:
    """Get memory usage information."""
    mem = psutil.virtual_memory()
    return json.dumps({
        "total_gb": round(mem.total / (1024**3), 2),
        "available_gb": round(mem.available / (1024**3), 2),
        "used_gb": round(mem.used / (1024**3), 2),
        "percent": mem.percent
    }, indent=2)


@mcp.resource("system://disk", mime_type="application/json")
def get_disk_info() -> str:
    """Get disk usage information."""
    partitions = []
    for partition in psutil.disk_partitions():
        try:
            usage = psutil.disk_usage(partition.mountpoint)
            partitions.append({
                "device": partition.device,
                "mountpoint": partition.mountpoint,
                "total_gb": round(usage.total / (1024**3), 2),
                "used_gb": round(usage.used / (1024**3), 2),
                "free_gb": round(usage.free / (1024**3), 2),
                "percent": usage.percent
            })
        except PermissionError:
            continue
    return json.dumps(partitions, indent=2)


@mcp.resource("system://health")
def get_health_status() -> str:
    """Get overall system health status."""
    cpu_ok = psutil.cpu_percent(interval=0.1) < 90
    mem_ok = psutil.virtual_memory().percent < 90
    
    if cpu_ok and mem_ok:
        status = "healthy"
    elif cpu_ok or mem_ok:
        status = "degraded"
    else:
        status = "critical"
    
    return json.dumps({
        "status": status,
        "timestamp": datetime.now().isoformat(),
        "checks": {
            "cpu": "ok" if cpu_ok else "high",
            "memory": "ok" if mem_ok else "high"
        }
    }, indent=2)
```

---

## Best Practices

### 1. URI Design

```python
# Good: Clear, hierarchical URIs
@mcp.resource("users://all")
@mcp.resource("users://{id}")
@mcp.resource("users://{id}/orders")

# Avoid: Flat, unclear URIs
@mcp.resource("all_users")
@mcp.resource("user_data")
```

### 2. Error Handling

```python
@mcp.resource("data://{id}")
def get_data(id: str) -> str:
    """Get data with proper error handling."""
    if not id.isalnum():
        return json.dumps({"error": "Invalid ID format"})
    
    data = fetch_from_database(id)
    if data is None:
        return json.dumps({"error": f"Data not found: {id}"})
    
    return json.dumps(data)
```

### 3. MIME Type Consistency

```python
# Always specify MIME type for structured data
@mcp.resource("api://data", mime_type="application/json")
def get_api_data() -> str:
    """Returns JSON data."""
    return json.dumps({"key": "value"})
```

### 4. Security Considerations

```python
# Validate and sanitize parameters
@mcp.resource("files://{path:path}")
def read_file(path: str) -> str:
    """Read file with security checks."""
    # Prevent path traversal
    safe_path = Path(path).resolve()
    allowed_dir = Path("./public").resolve()
    
    if not str(safe_path).startswith(str(allowed_dir)):
        return "Error: Access denied"
    
    return safe_path.read_text()
```

---

## Summary

| Concept | Implementation |
|---------|----------------|
| **Basic Resource** | `@mcp.resource("uri://path")` |
| **Dynamic Resource** | `@mcp.resource("uri://{param}")` |
| **MIME Type** | `@mcp.resource("uri://path", mime_type="application/json")` |
| **Async Resource** | `async def get_resource()` |
| **Multiple Params** | `@mcp.resource("uri://{param1}/{param2}")` |
| **Path Params** | `@mcp.resource("uri://{filepath:path}")` |

---

## Next Steps

- [Prompts with FastMCP](_05_prompts_with_fastmcp.md) - Creating prompt templates
- [Context and Dependencies](_06_context_and_dependencies.md) - Advanced server features
