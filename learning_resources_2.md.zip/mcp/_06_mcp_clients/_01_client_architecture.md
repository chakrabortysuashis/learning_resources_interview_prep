# MCP Client Architecture

## Module 6.1: Understanding MCP Clients

---

## What is an MCP Client?

An **MCP Client** is the counterpart to an MCP Server in the Model Context Protocol architecture. While servers expose capabilities (tools, resources, prompts), clients consume these capabilities and make them available to AI models or applications.

```
+-----------------------------------------------------------------------------+
|                        MCP CLIENT-SERVER ARCHITECTURE                        |
+-----------------------------------------------------------------------------+
|                                                                             |
|   +-------------------+          MCP Protocol          +------------------+ |
|   |                   |  <=========================>   |                  | |
|   |    MCP CLIENT     |        JSON-RPC over          |   MCP SERVER     | |
|   |                   |      stdio / SSE / WS          |                  | |
|   +-------------------+                                +------------------+ |
|          |                                                    |             |
|          |  Capabilities                            Provides  |             |
|          |  Discovery                               Features  |             |
|          v                                                    v             |
|   +-------------------+                              +------------------+   |
|   | - List tools      |                              | - Tools          |   |
|   | - Call tools      |                              | - Resources      |   |
|   | - Read resources  |                              | - Prompts        |   |
|   | - Get prompts     |                              | - Sampling       |   |
|   +-------------------+                              +------------------+   |
|                                                                             |
+-----------------------------------------------------------------------------+
```

---

## Role of MCP Clients

### Primary Responsibilities

1. **Connection Management**: Establish and maintain connections to MCP servers
2. **Capability Discovery**: Discover available tools, resources, and prompts
3. **Request Handling**: Send requests to servers and process responses
4. **Session Management**: Manage client-side session state
5. **Protocol Compliance**: Ensure proper JSON-RPC communication

```
+-----------------------------------------------------------------------------+
|                         MCP CLIENT RESPONSIBILITIES                          |
+-----------------------------------------------------------------------------+
|                                                                             |
|                          +-------------------+                               |
|                          |    MCP CLIENT     |                               |
|                          +-------------------+                               |
|                                   |                                         |
|        +------------+-------------+-------------+------------+              |
|        |            |             |             |            |              |
|        v            v             v             v            v              |
|   +---------+ +---------+ +-----------+ +---------+ +-----------+           |
|   |Connect  | |Discover | |  Execute  | | Manage  | | Handle    |           |
|   |to       | |Server   | |  Tool     | | Session | | Responses |           |
|   |Servers  | |Features | |  Calls    | | State   | | & Errors  |           |
|   +---------+ +---------+ +-----------+ +---------+ +-----------+           |
|                                                                             |
+-----------------------------------------------------------------------------+
```

### Client Use Cases

| Use Case | Description | Example |
|----------|-------------|---------|
| **AI Assistants** | Enable LLMs to use external tools | Claude Desktop, ChatGPT |
| **IDE Integrations** | Connect code editors to MCP tools | VS Code extensions |
| **Automation** | Build automated workflows | CI/CD pipelines |
| **Custom Applications** | Integrate MCP into your apps | Custom chatbots |

---

## Client Capabilities

When a client connects to a server, it can declare its capabilities. These tell the server what features the client supports.

### Standard Client Capabilities

```python
# Client capabilities structure
{
    "roots": {
        "listChanged": True  # Client can handle root list changes
    },
    "sampling": {}           # Client supports sampling requests from server
}
```

### Capability Negotiation Flow

```
+-----------------------------------------------------------------------------+
|                        CAPABILITY NEGOTIATION                                |
+-----------------------------------------------------------------------------+
|                                                                             |
|    CLIENT                                                         SERVER    |
|       |                                                              |      |
|       |  1. initialize (client_info, capabilities)                   |      |
|       |------------------------------------------------------------->|      |
|       |                                                              |      |
|       |  2. initialize response (server_info, capabilities)          |      |
|       |<-------------------------------------------------------------|      |
|       |                                                              |      |
|       |  3. initialized notification                                 |      |
|       |------------------------------------------------------------->|      |
|       |                                                              |      |
|       |            [ Session is now established ]                    |      |
|       |                                                              |      |
+-----------------------------------------------------------------------------+
```

### Capability Details

```
+-------------------+------------------------------------------+---------------+
|    Capability     |              Description                 |    Client     |
+-------------------+------------------------------------------+---------------+
| roots.listChanged | Handle filesystem root change             | Optional      |
|                   | notifications from server                |               |
+-------------------+------------------------------------------+---------------+
| sampling          | Support server-initiated sampling         | Optional      |
|                   | requests (server asks client to          |               |
|                   | generate LLM completions)                |               |
+-------------------+------------------------------------------+---------------+
| experimental      | Support for experimental protocol         | Optional      |
|                   | features (varies by implementation)      |               |
+-------------------+------------------------------------------+---------------+
```

---

## How Clients Discover Server Features

After the initialization handshake, clients discover server capabilities through list methods.

### Discovery Methods

```
+-----------------------------------------------------------------------------+
|                       FEATURE DISCOVERY PROCESS                              |
+-----------------------------------------------------------------------------+
|                                                                             |
|    CLIENT                                                         SERVER    |
|       |                                                              |      |
|       |  tools/list                                                  |      |
|       |------------------------------------------------------------->|      |
|       |  { tools: [{ name, description, inputSchema }, ...] }        |      |
|       |<-------------------------------------------------------------|      |
|       |                                                              |      |
|       |  resources/list                                              |      |
|       |------------------------------------------------------------->|      |
|       |  { resources: [{ uri, name, mimeType }, ...] }               |      |
|       |<-------------------------------------------------------------|      |
|       |                                                              |      |
|       |  prompts/list                                                |      |
|       |------------------------------------------------------------->|      |
|       |  { prompts: [{ name, description, arguments }, ...] }        |      |
|       |<-------------------------------------------------------------|      |
|       |                                                              |      |
+-----------------------------------------------------------------------------+
```

### Discovery Code Example

```python
# Discovering server features as a client
async def discover_server_features(client):
    """Discover all features exposed by an MCP server."""
    
    # List available tools
    tools_response = await client.list_tools()
    print("Available Tools:")
    for tool in tools_response.tools:
        print(f"  - {tool.name}: {tool.description}")
    
    # List available resources
    resources_response = await client.list_resources()
    print("\nAvailable Resources:")
    for resource in resources_response.resources:
        print(f"  - {resource.uri}: {resource.name}")
    
    # List available prompts
    prompts_response = await client.list_prompts()
    print("\nAvailable Prompts:")
    for prompt in prompts_response.prompts:
        print(f"  - {prompt.name}: {prompt.description}")
```

---

## Client-Side Session Management

MCP clients manage sessions to maintain state and handle the connection lifecycle.

### Session Lifecycle

```
+-----------------------------------------------------------------------------+
|                         SESSION LIFECYCLE                                    |
+-----------------------------------------------------------------------------+
|                                                                             |
|   +-------------+     +--------------+     +------------+     +-----------+ |
|   |   CREATED   | --> | INITIALIZING | --> |   ACTIVE   | --> |  CLOSED   | |
|   +-------------+     +--------------+     +------------+     +-----------+ |
|         |                    |                   |                  |       |
|         v                    v                   v                  v       |
|   - Transport        - Send init        - Send requests     - Cleanup      |
|     established        request          - Handle             - Close        |
|   - No protocol      - Await             notifications        transport    |
|     messages yet       response         - Maintain state                   |
|                                                                             |
+-----------------------------------------------------------------------------+
```

### Session State Management

```python
class MCPClientSession:
    """Manages MCP client session state."""
    
    def __init__(self):
        self.state = "created"
        self.server_info = None
        self.server_capabilities = None
        self.cached_tools = None
        self.cached_resources = None
    
    async def initialize(self, transport):
        """Initialize the session with a server."""
        self.state = "initializing"
        
        # Send initialize request
        response = await transport.send_request(
            "initialize",
            {
                "protocolVersion": "2024-11-05",
                "capabilities": {"sampling": {}},
                "clientInfo": {
                    "name": "MyClient",
                    "version": "1.0.0"
                }
            }
        )
        
        # Store server information
        self.server_info = response.get("serverInfo")
        self.server_capabilities = response.get("capabilities")
        
        # Send initialized notification
        await transport.send_notification("initialized", {})
        
        self.state = "active"
        return response
    
    async def close(self):
        """Close the session gracefully."""
        self.state = "closed"
        # Cleanup resources
```

---

## Client Architecture Patterns

### Pattern 1: Single Server Client

The simplest pattern - one client connects to one server.

```
+-----------------------------------------------------------------------------+
|                       SINGLE SERVER CLIENT                                   |
+-----------------------------------------------------------------------------+
|                                                                             |
|                    +-------------------+                                     |
|                    |   Application     |                                     |
|                    +-------------------+                                     |
|                            |                                                 |
|                            v                                                 |
|                    +-------------------+                                     |
|                    |    MCP Client     |                                     |
|                    +-------------------+                                     |
|                            |                                                 |
|                            | stdio / SSE                                     |
|                            v                                                 |
|                    +-------------------+                                     |
|                    |    MCP Server     |                                     |
|                    | (e.g., Filesystem)|                                     |
|                    +-------------------+                                     |
|                                                                             |
+-----------------------------------------------------------------------------+
```

### Pattern 2: Multi-Server Client

A client that connects to multiple servers simultaneously.

```
+-----------------------------------------------------------------------------+
|                       MULTI-SERVER CLIENT                                    |
+-----------------------------------------------------------------------------+
|                                                                             |
|                      +-------------------+                                   |
|                      |   Application     |                                   |
|                      +-------------------+                                   |
|                              |                                               |
|                              v                                               |
|                      +-------------------+                                   |
|                      |  Multi-Server     |                                   |
|                      |   MCP Client      |                                   |
|                      +-------------------+                                   |
|                     /         |          \                                   |
|                    /          |           \                                  |
|                   v           v            v                                 |
|          +-----------+  +-----------+  +-----------+                        |
|          |  Server 1 |  |  Server 2 |  |  Server 3 |                        |
|          | Filesystem|  | Database  |  |    API    |                        |
|          +-----------+  +-----------+  +-----------+                        |
|                                                                             |
+-----------------------------------------------------------------------------+
```

### Pattern 3: Agent-Based Client

An LLM agent uses MCP clients to access tools.

```
+-----------------------------------------------------------------------------+
|                       AGENT-BASED CLIENT                                     |
+-----------------------------------------------------------------------------+
|                                                                             |
|   +-----------------------------------------------------------------------+ |
|   |                         LLM Agent (e.g., LangChain)                   | |
|   +-----------------------------------------------------------------------+ |
|           |                        |                        |               |
|           v                        v                        v               |
|   +---------------+        +---------------+        +---------------+       |
|   | MCP Client 1  |        | MCP Client 2  |        | MCP Client 3  |       |
|   +---------------+        +---------------+        +---------------+       |
|           |                        |                        |               |
|           v                        v                        v               |
|   +---------------+        +---------------+        +---------------+       |
|   |  Weather      |        |  Calculator   |        |  File System  |       |
|   |  Server       |        |  Server       |        |  Server       |       |
|   +---------------+        +---------------+        +---------------+       |
|                                                                             |
+-----------------------------------------------------------------------------+
```

---

## Client Request/Response Flow

### Tool Execution Flow

```
+-----------------------------------------------------------------------------+
|                         TOOL EXECUTION FLOW                                  |
+-----------------------------------------------------------------------------+
|                                                                             |
|  APPLICATION      MCP CLIENT           TRANSPORT           MCP SERVER       |
|       |                |                    |                    |          |
|       | call_tool()    |                    |                    |          |
|       |--------------->|                    |                    |          |
|       |                |  JSON-RPC request  |                    |          |
|       |                |------------------->|                    |          |
|       |                |                    | tools/call         |          |
|       |                |                    |------------------->|          |
|       |                |                    |                    |          |
|       |                |                    |   Execute tool     |          |
|       |                |                    |      logic         |          |
|       |                |                    |                    |          |
|       |                |                    | JSON-RPC response  |          |
|       |                |                    |<-------------------|          |
|       |                | Parse response     |                    |          |
|       |                |<-------------------|                    |          |
|       |  ToolResult    |                    |                    |          |
|       |<---------------|                    |                    |          |
|       |                |                    |                    |          |
+-----------------------------------------------------------------------------+
```

### Resource Reading Flow

```
+-----------------------------------------------------------------------------+
|                       RESOURCE READING FLOW                                  |
+-----------------------------------------------------------------------------+
|                                                                             |
|  APPLICATION      MCP CLIENT           TRANSPORT           MCP SERVER       |
|       |                |                    |                    |          |
|       | read_resource()|                    |                    |          |
|       |--------------->|                    |                    |          |
|       |                | resources/read     |                    |          |
|       |                | { uri: "..." }     |                    |          |
|       |                |------------------->|                    |          |
|       |                |                    |------------------->|          |
|       |                |                    |                    |          |
|       |                |                    |   Fetch resource   |          |
|       |                |                    |      content       |          |
|       |                |                    |                    |          |
|       |                |                    | { contents: [...] }|          |
|       |                |                    |<-------------------|          |
|       |                |<-------------------|                    |          |
|       | ResourceContent|                    |                    |          |
|       |<---------------|                    |                    |          |
|       |                |                    |                    |          |
+-----------------------------------------------------------------------------+
```

---

## Error Handling in Clients

### Error Categories

| Error Type | Description | Handling Strategy |
|------------|-------------|-------------------|
| **Transport Error** | Connection failed, timeout | Retry with backoff |
| **Protocol Error** | Invalid JSON-RPC | Log and report |
| **Server Error** | Server-side exception | Surface to user |
| **Validation Error** | Invalid request params | Fix parameters |

### Error Handling Example

```python
from mcp import ClientError, TransportError

async def safe_tool_call(client, tool_name, arguments):
    """Call a tool with proper error handling."""
    try:
        result = await client.call_tool(tool_name, arguments)
        return {"success": True, "result": result}
    
    except TransportError as e:
        # Connection or communication error
        return {
            "success": False,
            "error_type": "transport",
            "message": f"Failed to communicate: {e}"
        }
    
    except ClientError as e:
        # Protocol-level error
        return {
            "success": False,
            "error_type": "protocol",
            "message": f"Protocol error: {e}"
        }
    
    except Exception as e:
        # Unexpected error
        return {
            "success": False,
            "error_type": "unknown",
            "message": f"Unexpected error: {e}"
        }
```

---

## Summary

| Concept | Description |
|---------|-------------|
| **MCP Client** | Consumes capabilities from MCP servers |
| **Capabilities** | Features the client supports (roots, sampling) |
| **Discovery** | Finding available tools/resources/prompts |
| **Session** | Stateful connection between client and server |
| **Multi-Server** | Connecting to multiple servers simultaneously |

---

## Next Steps

- [MCP Python Client](_02_mcp_python_client.md) - Using the official Python SDK
- [LangChain MCP Adapter](_03_langchain_mcp_adapter.md) - Integrating with LangChain
- [Building Agents with MCP](_04_building_agents_with_mcp.md) - Creating AI agents
