# Building Agents with MCP

## Module 6.4: Integrating MCP with LangChain Agents

---

## Introduction

This module covers how to build intelligent AI agents that leverage MCP tools through LangChain. We'll explore ReAct agents, tool calling patterns, and best practices for production-ready agent workflows.

```
+-----------------------------------------------------------------------------+
|                        AGENT + MCP ARCHITECTURE                              |
+-----------------------------------------------------------------------------+
|                                                                             |
|   +-----------------------------------------------------------------------+ |
|   |                           LLM AGENT                                   | |
|   |                                                                       | |
|   |   +-------------+    +---------------+    +----------------------+    | |
|   |   |   Observe   | -> |    Think      | -> |    Act (Tool Call)   |    | |
|   |   +-------------+    +---------------+    +----------------------+    | |
|   |         ^                                           |                 | |
|   |         |                                           v                 | |
|   |         +-------------------------------------------+                 | |
|   |                      Feedback Loop                                    | |
|   +-----------------------------------------------------------------------+ |
|                                    |                                        |
|                                    | Tool Invocation                        |
|                                    v                                        |
|   +-----------------------------------------------------------------------+ |
|   |                        MCP TOOL LAYER                                 | |
|   |                                                                       | |
|   |   +-----------+    +-----------+    +-----------+    +-----------+   | |
|   |   | Calculator|    | Filesystem|    | Database  |    | API       |   | |
|   |   | Server    |    | Server    |    | Server    |    | Server    |   | |
|   |   +-----------+    +-----------+    +-----------+    +-----------+   | |
|   |                                                                       | |
|   +-----------------------------------------------------------------------+ |
|                                                                             |
+-----------------------------------------------------------------------------+
```

---

## ReAct Agents with MCP Tools

### What is a ReAct Agent?

ReAct (Reasoning + Acting) is an agent paradigm where the LLM:
1. **Reasons** about what to do
2. **Acts** by calling tools
3. **Observes** the results
4. **Repeats** until the task is complete

```
+-----------------------------------------------------------------------------+
|                           ReAct AGENT LOOP                                   |
+-----------------------------------------------------------------------------+
|                                                                             |
|   User Query: "What's 25% of the file count in /documents?"                 |
|                                                                             |
|   +-------------------------------------------------------------------+     |
|   | THOUGHT: I need to count files in /documents first                |     |
|   +-------------------------------------------------------------------+     |
|                                    |                                        |
|                                    v                                        |
|   +-------------------------------------------------------------------+     |
|   | ACTION: list_files(path="/documents")                             |     |
|   +-------------------------------------------------------------------+     |
|                                    |                                        |
|                                    v                                        |
|   +-------------------------------------------------------------------+     |
|   | OBSERVATION: Found 40 files                                       |     |
|   +-------------------------------------------------------------------+     |
|                                    |                                        |
|                                    v                                        |
|   +-------------------------------------------------------------------+     |
|   | THOUGHT: Now I need to calculate 25% of 40                        |     |
|   +-------------------------------------------------------------------+     |
|                                    |                                        |
|                                    v                                        |
|   +-------------------------------------------------------------------+     |
|   | ACTION: multiply(a=40, b=0.25)                                    |     |
|   +-------------------------------------------------------------------+     |
|                                    |                                        |
|                                    v                                        |
|   +-------------------------------------------------------------------+     |
|   | OBSERVATION: 10.0                                                 |     |
|   +-------------------------------------------------------------------+     |
|                                    |                                        |
|                                    v                                        |
|   +-------------------------------------------------------------------+     |
|   | FINAL ANSWER: 25% of the 40 files is 10 files.                    |     |
|   +-------------------------------------------------------------------+     |
|                                                                             |
+-----------------------------------------------------------------------------+
```

### Building a ReAct Agent with MCP Tools

```python
"""
Build a ReAct agent using MCP tools with LangChain.
"""

import asyncio
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_anthropic import ChatAnthropic
from langgraph.prebuilt import create_react_agent

async def create_mcp_react_agent():
    """Create a ReAct agent with MCP tools."""
    
    # Configure MCP servers
    servers = {
        "calculator": {
            "command": "python",
            "args": ["servers/calculator_server.py"],
            "transport": "stdio"
        },
        "filesystem": {
            "command": "python",
            "args": ["servers/filesystem_server.py"],
            "transport": "stdio"
        }
    }
    
    async with MultiServerMCPClient(servers) as client:
        # Get MCP tools as LangChain tools
        tools = client.get_tools()
        
        # Create the LLM
        llm = ChatAnthropic(
            model="claude-sonnet-4-20250514",
            temperature=0  # Deterministic for tool calling
        )
        
        # Create the ReAct agent
        agent = create_react_agent(llm, tools)
        
        # Run the agent
        result = await agent.ainvoke({
            "messages": [
                ("user", "List all Python files in /src and count them")
            ]
        })
        
        return result


if __name__ == "__main__":
    result = asyncio.run(create_mcp_react_agent())
    print(result)
```

---

## Tool Calling with LLMs

### How Tool Calling Works

```
+-----------------------------------------------------------------------------+
|                          TOOL CALLING FLOW                                   |
+-----------------------------------------------------------------------------+
|                                                                             |
|   1. USER MESSAGE                                                           |
|      "Add 15 and 27"                                                        |
|                                                                             |
|   2. LLM RESPONSE (with tool_calls)                                         |
|      {                                                                      |
|        "content": "",                                                       |
|        "tool_calls": [{                                                     |
|          "id": "call_abc123",                                               |
|          "name": "add",                                                     |
|          "args": {"a": 15, "b": 27}                                         |
|        }]                                                                   |
|      }                                                                      |
|                                                                             |
|   3. TOOL EXECUTION                                                         |
|      tool.invoke({"a": 15, "b": 27})  ->  42                                |
|                                                                             |
|   4. TOOL RESULT MESSAGE                                                    |
|      ToolMessage(content="42", tool_call_id="call_abc123")                  |
|                                                                             |
|   5. FINAL LLM RESPONSE                                                     |
|      "The sum of 15 and 27 is 42."                                          |
|                                                                             |
+-----------------------------------------------------------------------------+
```

### Manual Tool Calling Implementation

```python
"""
Manual tool calling with MCP tools.
"""

import asyncio
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_anthropic import ChatAnthropic
from langchain_core.messages import HumanMessage, ToolMessage

async def manual_tool_calling():
    """Demonstrate manual tool calling workflow."""
    
    servers = {
        "tools": {
            "command": "python",
            "args": ["my_server.py"],
            "transport": "stdio"
        }
    }
    
    async with MultiServerMCPClient(servers) as client:
        tools = client.get_tools()
        
        # Create LLM with tools
        llm = ChatAnthropic(model="claude-sonnet-4-20250514")
        llm_with_tools = llm.bind_tools(tools)
        
        # Initial message
        messages = [HumanMessage(content="Calculate 100 divided by 4")]
        
        # First LLM call - may return tool calls
        response = await llm_with_tools.ainvoke(messages)
        messages.append(response)
        
        # Process tool calls if any
        while response.tool_calls:
            for tool_call in response.tool_calls:
                # Find the matching tool
                tool = next(
                    (t for t in tools if t.name == tool_call["name"]),
                    None
                )
                
                if tool:
                    # Execute the tool
                    result = await tool.ainvoke(tool_call["args"])
                    
                    # Add tool result to messages
                    messages.append(
                        ToolMessage(
                            content=str(result),
                            tool_call_id=tool_call["id"]
                        )
                    )
            
            # Get next response
            response = await llm_with_tools.ainvoke(messages)
            messages.append(response)
        
        # Final response without tool calls
        return response.content


if __name__ == "__main__":
    result = asyncio.run(manual_tool_calling())
    print(f"Result: {result}")
```

---

## Building a Complete Agent Workflow

### Agent Architecture

```
+-----------------------------------------------------------------------------+
|                      COMPLETE AGENT WORKFLOW                                 |
+-----------------------------------------------------------------------------+
|                                                                             |
|   +--------------------+                                                    |
|   |    User Input      |                                                    |
|   +--------------------+                                                    |
|            |                                                                 |
|            v                                                                 |
|   +--------------------+     +------------------------+                     |
|   | Input Processing   | --> | Context Augmentation   |                     |
|   | - Parse request    |     | - Add system prompt    |                     |
|   | - Validate input   |     | - Include history      |                     |
|   +--------------------+     +------------------------+                     |
|            |                                                                 |
|            v                                                                 |
|   +--------------------------------------------------------+               |
|   |                    AGENT LOOP                          |               |
|   |                                                        |               |
|   |   +-----------+    +-----------+    +-----------+     |               |
|   |   |   LLM     | -> | Tool Call | -> |  Execute  |     |               |
|   |   | Reasoning |    | Decision  |    |   Tools   |     |               |
|   |   +-----------+    +-----------+    +-----------+     |               |
|   |        ^                                  |            |               |
|   |        +----------------------------------+            |               |
|   |                                                        |               |
|   +--------------------------------------------------------+               |
|            |                                                                 |
|            v                                                                 |
|   +--------------------+                                                    |
|   | Output Processing  |                                                    |
|   | - Format response  |                                                    |
|   | - Validate output  |                                                    |
|   +--------------------+                                                    |
|            |                                                                 |
|            v                                                                 |
|   +--------------------+                                                    |
|   |   Final Response   |                                                    |
|   +--------------------+                                                    |
|                                                                             |
+-----------------------------------------------------------------------------+
```

### Complete Agent Implementation

```python
"""
Complete agent workflow with MCP tools.
"""

import asyncio
from typing import Optional
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_anthropic import ChatAnthropic
from langchain_core.messages import HumanMessage, SystemMessage, AIMessage
from langgraph.prebuilt import create_react_agent
from langgraph.checkpoint.memory import MemorySaver

# Configuration
SYSTEM_PROMPT = """You are a helpful assistant with access to various tools.
Use the tools available to help users accomplish their tasks.

Guidelines:
1. Think step by step before acting
2. Use tools when necessary, but don't overuse them
3. Provide clear explanations of what you're doing
4. If a tool fails, try alternative approaches
"""

class MCPAgent:
    """A complete agent implementation using MCP tools."""
    
    def __init__(
        self,
        server_configs: dict,
        model: str = "claude-sonnet-4-20250514",
        system_prompt: str = SYSTEM_PROMPT
    ):
        self.server_configs = server_configs
        self.model = model
        self.system_prompt = system_prompt
        self.client = None
        self.agent = None
        self.memory = MemorySaver()
    
    async def __aenter__(self):
        """Set up the agent with MCP tools."""
        # Create multi-server client
        self.client = MultiServerMCPClient(self.server_configs)
        await self.client.__aenter__()
        
        # Get tools
        tools = self.client.get_tools()
        
        # Create LLM
        llm = ChatAnthropic(
            model=self.model,
            temperature=0
        )
        
        # Create the agent with memory
        self.agent = create_react_agent(
            llm,
            tools,
            checkpointer=self.memory
        )
        
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Clean up resources."""
        if self.client:
            await self.client.__aexit__(exc_type, exc_val, exc_tb)
    
    async def chat(
        self,
        message: str,
        thread_id: str = "default",
        max_iterations: int = 10
    ) -> str:
        """
        Send a message to the agent and get a response.
        
        Args:
            message: User's message
            thread_id: Conversation thread ID for memory
            max_iterations: Maximum tool calling iterations
            
        Returns:
            Agent's response as a string
        """
        # Prepare the input
        inputs = {
            "messages": [
                SystemMessage(content=self.system_prompt),
                HumanMessage(content=message)
            ]
        }
        
        # Configuration for this run
        config = {
            "configurable": {"thread_id": thread_id},
            "recursion_limit": max_iterations
        }
        
        # Run the agent
        result = await self.agent.ainvoke(inputs, config)
        
        # Extract the final response
        final_message = result["messages"][-1]
        
        if isinstance(final_message, AIMessage):
            return final_message.content
        
        return str(final_message)
    
    def get_available_tools(self) -> list[str]:
        """Get list of available tool names."""
        if self.client:
            return [tool.name for tool in self.client.get_tools()]
        return []


async def run_agent_demo():
    """Demonstrate the complete agent workflow."""
    
    # Configure MCP servers
    servers = {
        "math": {
            "command": "python",
            "args": ["servers/math_server.py"],
            "transport": "stdio"
        },
        "files": {
            "command": "python",
            "args": ["servers/file_server.py"],
            "transport": "stdio"
        },
        "web": {
            "url": "http://localhost:8000/sse",
            "transport": "sse"
        }
    }
    
    async with MCPAgent(servers) as agent:
        print("Available tools:", agent.get_available_tools())
        print("=" * 60)
        
        # Example conversations
        queries = [
            "What is 15% of 200?",
            "List all files in the /data directory",
            "Calculate the total size of all .txt files",
        ]
        
        for query in queries:
            print(f"\nUser: {query}")
            response = await agent.chat(query)
            print(f"Agent: {response}")
            print("-" * 40)


if __name__ == "__main__":
    asyncio.run(run_agent_demo())
```

---

## Advanced Agent Patterns

### Pattern 1: Specialized Agents

Create agents specialized for specific tasks:

```python
"""
Specialized agents for different domains.
"""

from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_anthropic import ChatAnthropic
from langgraph.prebuilt import create_react_agent

async def create_specialized_agents():
    """Create specialized agents for different tasks."""
    
    # Math specialist servers
    math_servers = {
        "calculator": {
            "command": "python",
            "args": ["math_server.py"],
            "transport": "stdio"
        }
    }
    
    # File specialist servers
    file_servers = {
        "filesystem": {
            "command": "python",
            "args": ["filesystem_server.py"],
            "transport": "stdio"
        }
    }
    
    agents = {}
    
    # Create math specialist
    async with MultiServerMCPClient(math_servers) as math_client:
        math_tools = math_client.get_tools()
        math_llm = ChatAnthropic(model="claude-sonnet-4-20250514")
        agents["math"] = create_react_agent(
            math_llm,
            math_tools,
            state_modifier="You are a math specialist. Only use tools for mathematical operations."
        )
    
    # Create file specialist
    async with MultiServerMCPClient(file_servers) as file_client:
        file_tools = file_client.get_tools()
        file_llm = ChatAnthropic(model="claude-sonnet-4-20250514")
        agents["files"] = create_react_agent(
            file_llm,
            file_tools,
            state_modifier="You are a file management specialist. Help users with file operations."
        )
    
    return agents
```

### Pattern 2: Agent with Fallback

```python
"""
Agent with fallback handling for tool failures.
"""

import asyncio
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_anthropic import ChatAnthropic
from langchain_core.messages import HumanMessage, ToolMessage

async def agent_with_fallback():
    """Agent that handles tool failures gracefully."""
    
    servers = {
        "primary": {
            "command": "python",
            "args": ["primary_server.py"],
            "transport": "stdio"
        }
    }
    
    async with MultiServerMCPClient(servers) as client:
        tools = client.get_tools()
        llm = ChatAnthropic(model="claude-sonnet-4-20250514")
        llm_with_tools = llm.bind_tools(tools)
        
        messages = [HumanMessage(content="Process the data file")]
        response = await llm_with_tools.ainvoke(messages)
        messages.append(response)
        
        max_retries = 3
        
        while response.tool_calls:
            for tool_call in response.tool_calls:
                tool = next(
                    (t for t in tools if t.name == tool_call["name"]),
                    None
                )
                
                result = None
                error_message = None
                
                # Retry logic
                for attempt in range(max_retries):
                    try:
                        if tool:
                            result = await tool.ainvoke(tool_call["args"])
                            break
                    except Exception as e:
                        error_message = str(e)
                        await asyncio.sleep(0.5 * (attempt + 1))
                
                # Add result or error to messages
                if result is not None:
                    messages.append(
                        ToolMessage(
                            content=str(result),
                            tool_call_id=tool_call["id"]
                        )
                    )
                else:
                    messages.append(
                        ToolMessage(
                            content=f"Tool failed after {max_retries} attempts: {error_message}",
                            tool_call_id=tool_call["id"]
                        )
                    )
            
            response = await llm_with_tools.ainvoke(messages)
            messages.append(response)
        
        return response.content
```

### Pattern 3: Streaming Agent

```python
"""
Streaming agent for real-time responses.
"""

from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_anthropic import ChatAnthropic
from langgraph.prebuilt import create_react_agent

async def streaming_agent():
    """Agent with streaming output."""
    
    servers = {
        "tools": {
            "command": "python",
            "args": ["server.py"],
            "transport": "stdio"
        }
    }
    
    async with MultiServerMCPClient(servers) as client:
        tools = client.get_tools()
        llm = ChatAnthropic(model="claude-sonnet-4-20250514", streaming=True)
        agent = create_react_agent(llm, tools)
        
        inputs = {"messages": [("user", "Calculate something complex")]}
        
        # Stream the agent's execution
        async for event in agent.astream_events(inputs, version="v2"):
            kind = event["event"]
            
            if kind == "on_chat_model_stream":
                # Stream LLM output
                chunk = event["data"]["chunk"]
                if chunk.content:
                    print(chunk.content, end="", flush=True)
            
            elif kind == "on_tool_start":
                # Tool is starting
                print(f"\n[Calling tool: {event['name']}]")
            
            elif kind == "on_tool_end":
                # Tool completed
                print(f"[Tool result: {event['data']['output'][:100]}...]")
        
        print()  # Final newline


if __name__ == "__main__":
    asyncio.run(streaming_agent())
```

---

## Best Practices

### 1. Tool Organization

```python
# Group tools by functionality
def organize_tools(tools):
    """Organize tools into functional groups."""
    groups = {
        "math": [],
        "file": [],
        "web": [],
        "database": [],
        "other": []
    }
    
    for tool in tools:
        name = tool.name.lower()
        
        if any(kw in name for kw in ["add", "subtract", "multiply", "divide", "calc"]):
            groups["math"].append(tool)
        elif any(kw in name for kw in ["file", "read", "write", "list", "dir"]):
            groups["file"].append(tool)
        elif any(kw in name for kw in ["http", "fetch", "api", "web"]):
            groups["web"].append(tool)
        elif any(kw in name for kw in ["query", "sql", "db", "database"]):
            groups["database"].append(tool)
        else:
            groups["other"].append(tool)
    
    return groups
```

### 2. Error Handling Strategy

```python
# Comprehensive error handling
async def safe_tool_execution(tool, args, max_retries=3):
    """Execute a tool with retries and error handling."""
    
    errors = []
    
    for attempt in range(max_retries):
        try:
            result = await tool.ainvoke(args)
            return {"success": True, "result": result}
        except TimeoutError:
            errors.append(f"Attempt {attempt + 1}: Timeout")
        except ValueError as e:
            # Don't retry validation errors
            return {"success": False, "error": f"Validation error: {e}"}
        except Exception as e:
            errors.append(f"Attempt {attempt + 1}: {e}")
    
    return {
        "success": False,
        "error": f"Failed after {max_retries} attempts",
        "details": errors
    }
```

### 3. Rate Limiting

```python
import asyncio
from collections import deque
from datetime import datetime

class RateLimiter:
    """Rate limiter for tool calls."""
    
    def __init__(self, calls_per_minute: int = 60):
        self.calls_per_minute = calls_per_minute
        self.call_times = deque()
    
    async def acquire(self):
        """Wait if rate limit exceeded."""
        now = datetime.now()
        
        # Remove calls older than 1 minute
        while self.call_times and (now - self.call_times[0]).seconds >= 60:
            self.call_times.popleft()
        
        # Wait if at limit
        if len(self.call_times) >= self.calls_per_minute:
            wait_time = 60 - (now - self.call_times[0]).seconds
            await asyncio.sleep(wait_time)
        
        self.call_times.append(now)


# Usage with tools
rate_limiter = RateLimiter(calls_per_minute=30)

async def rate_limited_tool_call(tool, args):
    await rate_limiter.acquire()
    return await tool.ainvoke(args)
```

### 4. Logging and Observability

```python
import logging
from functools import wraps

logger = logging.getLogger("mcp_agent")

def log_tool_call(func):
    """Decorator to log tool calls."""
    @wraps(func)
    async def wrapper(tool, args):
        logger.info(f"Calling tool: {tool.name}")
        logger.debug(f"Arguments: {args}")
        
        try:
            result = await func(tool, args)
            logger.info(f"Tool {tool.name} completed successfully")
            logger.debug(f"Result: {result}")
            return result
        except Exception as e:
            logger.error(f"Tool {tool.name} failed: {e}")
            raise
    
    return wrapper


@log_tool_call
async def execute_tool(tool, args):
    return await tool.ainvoke(args)
```

---

## Summary

| Pattern | Use Case | Key Feature |
|---------|----------|-------------|
| **ReAct Agent** | General reasoning tasks | Think-Act-Observe loop |
| **Manual Tool Calling** | Fine-grained control | Explicit message management |
| **Specialized Agents** | Domain-specific tasks | Focused tool sets |
| **Streaming Agent** | Real-time feedback | Progressive output |
| **Agent with Fallback** | Reliability | Retry and error handling |

---

## Next Steps

- [LangChain MCP Examples](_05_langchain_mcp_examples.ipynb) - Hands-on notebook with working code
