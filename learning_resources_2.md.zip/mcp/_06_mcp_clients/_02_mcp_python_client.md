# MCP Python Client

## Module 6.2: Using the Official MCP Python SDK as a Client

---

## Introduction

The official MCP Python SDK provides comprehensive client functionality for connecting to and interacting with MCP servers. This module covers how to use the SDK to build MCP clients.

```
+-----------------------------------------------------------------------------+
|                       MCP PYTHON SDK CLIENT                                  |
+-----------------------------------------------------------------------------+
|                                                                             |
|                        +---------------------+                               |
|                        |   Your Application  |                               |
|                        +---------------------+                               |
|                                  |                                           |
|                                  v                                           |
|   +-------------------------------------------------------------+           |
|   |                    MCP Python SDK                            |           |
|   |  +---------------+  +---------------+  +------------------+  |           |
|   |  | ClientSession |  |   Transport   |  | Type Definitions |  |           |
|   |  +---------------+  +---------------+  +------------------+  |           |
|   +-------------------------------------------------------------+           |
|                                  |                                           |
|                                  v                                           |
|                        +---------------------+                               |
|                        |     MCP Server      |                               |
|                        +---------------------+                               |
|                                                                             |
+-----------------------------------------------------------------------------+
```

---

## Installation

### Install the MCP SDK

```bash
# Using pip
pip install mcp

# Using uv (faster)
uv pip install mcp

# With all extras
pip install "mcp[all]"
```

### Verify Installation

```python
import mcp
print(f"MCP SDK version: {mcp.__version__}")
```

---

## Client Session Basics

### The ClientSession Class

The `ClientSession` class is the core interface for MCP client functionality.

```python
from mcp import ClientSession
from mcp.client.stdio import stdio_client
from mcp.client.sse import sse_client

# ClientSession provides:
# - initialize()       : Start the session
# - list_tools()       : Get available tools
# - call_tool()        : Execute a tool
# - list_resources()   : Get available resources
# - read_resource()    : Read resource content
# - list_prompts()     : Get available prompts
# - get_prompt()       : Get a specific prompt
```

---

## Connecting to Servers

### Method 1: Stdio Transport

Connect to servers that communicate via standard input/output.

```python
import asyncio
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

async def connect_stdio():
    """Connect to an MCP server via stdio."""
    
    # Define server parameters
    server_params = StdioServerParameters(
        command="python",
        args=["path/to/your/server.py"],
        env=None  # Optional: environment variables
    )
    
    # Create the stdio client connection
    async with stdio_client(server_params) as (read, write):
        # Create a client session
        async with ClientSession(read, write) as session:
            # Initialize the session
            await session.initialize()
            
            # Now you can use the session
            tools = await session.list_tools()
            print(f"Found {len(tools.tools)} tools")

# Run the async function
asyncio.run(connect_stdio())
```

### Method 2: SSE Transport (Server-Sent Events)

Connect to servers that expose an HTTP/SSE endpoint.

```python
import asyncio
from mcp import ClientSession
from mcp.client.sse import sse_client

async def connect_sse():
    """Connect to an MCP server via SSE."""
    
    # SSE endpoint URL
    server_url = "http://localhost:8000/sse"
    
    # Create the SSE client connection
    async with sse_client(server_url) as (read, write):
        # Create a client session
        async with ClientSession(read, write) as session:
            # Initialize the session
            await session.initialize()
            
            # Now you can use the session
            tools = await session.list_tools()
            print(f"Found {len(tools.tools)} tools")

asyncio.run(connect_sse())
```

### Method 3: Streamable HTTP Transport

For newer servers supporting the streamable HTTP transport.

```python
import asyncio
from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client

async def connect_streamable_http():
    """Connect to an MCP server via streamable HTTP."""
    
    server_url = "http://localhost:8000/mcp"
    
    async with streamablehttp_client(server_url) as (read, write, _):
        async with ClientSession(read, write) as session:
            await session.initialize()
            tools = await session.list_tools()
            print(f"Found {len(tools.tools)} tools")

asyncio.run(connect_streamable_http())
```

---

## Listing Available Tools, Resources, and Prompts

### List Tools

```python
async def list_server_tools(session: ClientSession):
    """List all tools available from the server."""
    
    # Get the list of tools
    tools_response = await session.list_tools()
    
    print("=" * 60)
    print("AVAILABLE TOOLS")
    print("=" * 60)
    
    for tool in tools_response.tools:
        print(f"\nTool: {tool.name}")
        print(f"  Description: {tool.description}")
        print(f"  Input Schema: {tool.inputSchema}")
    
    return tools_response.tools
```

### List Resources

```python
async def list_server_resources(session: ClientSession):
    """List all resources available from the server."""
    
    # Get the list of resources
    resources_response = await session.list_resources()
    
    print("=" * 60)
    print("AVAILABLE RESOURCES")
    print("=" * 60)
    
    for resource in resources_response.resources:
        print(f"\nResource: {resource.name}")
        print(f"  URI: {resource.uri}")
        print(f"  MIME Type: {resource.mimeType}")
        if resource.description:
            print(f"  Description: {resource.description}")
    
    return resources_response.resources
```

### List Prompts

```python
async def list_server_prompts(session: ClientSession):
    """List all prompts available from the server."""
    
    # Get the list of prompts
    prompts_response = await session.list_prompts()
    
    print("=" * 60)
    print("AVAILABLE PROMPTS")
    print("=" * 60)
    
    for prompt in prompts_response.prompts:
        print(f"\nPrompt: {prompt.name}")
        print(f"  Description: {prompt.description}")
        if prompt.arguments:
            print("  Arguments:")
            for arg in prompt.arguments:
                required = "(required)" if arg.required else "(optional)"
                print(f"    - {arg.name} {required}: {arg.description}")
    
    return prompts_response.prompts
```

---

## Calling Tools

### Basic Tool Call

```python
async def call_tool_example(session: ClientSession):
    """Example of calling a tool."""
    
    # Call a tool with arguments
    result = await session.call_tool(
        name="add_numbers",
        arguments={
            "a": 10,
            "b": 5
        }
    )
    
    # Process the result
    print("Tool Result:")
    for content in result.content:
        if content.type == "text":
            print(f"  Text: {content.text}")
        elif content.type == "image":
            print(f"  Image: {content.mimeType}")
        elif content.type == "resource":
            print(f"  Resource: {content.resource.uri}")
    
    # Check if there was an error
    if result.isError:
        print("Tool execution resulted in an error")
    
    return result
```

### Tool Call with Error Handling

```python
async def safe_call_tool(
    session: ClientSession,
    tool_name: str,
    arguments: dict
) -> dict:
    """Call a tool with comprehensive error handling."""
    
    try:
        result = await session.call_tool(
            name=tool_name,
            arguments=arguments
        )
        
        # Extract text content
        text_results = []
        for content in result.content:
            if content.type == "text":
                text_results.append(content.text)
        
        return {
            "success": not result.isError,
            "content": text_results,
            "raw_result": result
        }
    
    except Exception as e:
        return {
            "success": False,
            "error": str(e),
            "content": []
        }


# Usage
async def main(session):
    result = await safe_call_tool(
        session,
        "search_files",
        {"query": "*.py", "path": "/src"}
    )
    
    if result["success"]:
        print("Results:", result["content"])
    else:
        print("Error:", result.get("error", "Unknown error"))
```

---

## Reading Resources

### Read a Single Resource

```python
async def read_resource_example(session: ClientSession, uri: str):
    """Read content from a resource."""
    
    # Read the resource
    result = await session.read_resource(uri)
    
    print(f"Reading resource: {uri}")
    print("-" * 40)
    
    # Process contents
    for content in result.contents:
        if hasattr(content, 'text'):
            print(f"Text content:\n{content.text}")
        elif hasattr(content, 'blob'):
            print(f"Binary content: {len(content.blob)} bytes")
        
        print(f"MIME type: {content.mimeType}")
    
    return result
```

### Read Multiple Resources

```python
async def read_multiple_resources(
    session: ClientSession,
    uris: list[str]
) -> dict:
    """Read multiple resources and collect results."""
    
    results = {}
    
    for uri in uris:
        try:
            result = await session.read_resource(uri)
            
            # Collect text content
            text_content = []
            for content in result.contents:
                if hasattr(content, 'text'):
                    text_content.append(content.text)
            
            results[uri] = {
                "success": True,
                "content": text_content
            }
        
        except Exception as e:
            results[uri] = {
                "success": False,
                "error": str(e)
            }
    
    return results


# Usage
async def main(session):
    resources = await read_multiple_resources(
        session,
        [
            "file:///config/settings.json",
            "db://users/schema",
            "api://weather/current"
        ]
    )
    
    for uri, result in resources.items():
        if result["success"]:
            print(f"{uri}: {result['content'][:100]}...")
        else:
            print(f"{uri}: Error - {result['error']}")
```

---

## Working with Prompts

### Get a Prompt

```python
async def get_prompt_example(
    session: ClientSession,
    prompt_name: str,
    arguments: dict = None
):
    """Get a prompt template with optional arguments."""
    
    # Get the prompt
    result = await session.get_prompt(
        name=prompt_name,
        arguments=arguments or {}
    )
    
    print(f"Prompt: {prompt_name}")
    print("-" * 40)
    
    # Print the messages
    for message in result.messages:
        print(f"Role: {message.role}")
        if hasattr(message.content, 'text'):
            print(f"Content: {message.content.text}")
        print()
    
    return result


# Usage
async def main(session):
    # Get a code review prompt
    prompt = await get_prompt_example(
        session,
        "code_review",
        {"language": "python", "style": "detailed"}
    )
```

---

## Handling Responses

### Response Types

```python
from mcp.types import (
    TextContent,
    ImageContent,
    EmbeddedResource,
    CallToolResult,
    ReadResourceResult
)

def process_tool_result(result: CallToolResult):
    """Process different types of tool results."""
    
    processed = {
        "text": [],
        "images": [],
        "resources": [],
        "is_error": result.isError
    }
    
    for content in result.content:
        if isinstance(content, TextContent):
            processed["text"].append(content.text)
        
        elif isinstance(content, ImageContent):
            processed["images"].append({
                "data": content.data,
                "mime_type": content.mimeType
            })
        
        elif isinstance(content, EmbeddedResource):
            processed["resources"].append({
                "uri": content.resource.uri,
                "content": content.resource.text if hasattr(content.resource, 'text') else None
            })
    
    return processed
```

### Streaming Responses (for long-running operations)

```python
async def handle_progress_notifications(session: ClientSession):
    """Handle progress notifications from long-running tool calls."""
    
    # Set up notification handler
    async def on_progress(notification):
        print(f"Progress: {notification.progress}/{notification.total}")
        print(f"Message: {notification.message}")
    
    # Register the handler (implementation varies by SDK version)
    # session.on_notification("$/progress", on_progress)
    
    # Make a long-running tool call
    result = await session.call_tool(
        name="process_large_file",
        arguments={"file": "large_dataset.csv"}
    )
    
    return result
```

---

## Complete Client Example

### Full Working Example

```python
"""
Complete MCP Client Example
Demonstrates connecting to a server and using all features.
"""

import asyncio
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


class MCPClientExample:
    """A complete MCP client example."""
    
    def __init__(self, server_command: str, server_args: list):
        self.server_params = StdioServerParameters(
            command=server_command,
            args=server_args
        )
        self.session = None
    
    async def connect(self):
        """Connect to the MCP server."""
        self._stdio_context = stdio_client(self.server_params)
        self._read, self._write = await self._stdio_context.__aenter__()
        
        self._session_context = ClientSession(self._read, self._write)
        self.session = await self._session_context.__aenter__()
        
        # Initialize the session
        init_result = await self.session.initialize()
        
        print(f"Connected to: {init_result.serverInfo.name}")
        print(f"Version: {init_result.serverInfo.version}")
        print(f"Capabilities: {init_result.capabilities}")
        
        return init_result
    
    async def disconnect(self):
        """Disconnect from the server."""
        if self._session_context:
            await self._session_context.__aexit__(None, None, None)
        if self._stdio_context:
            await self._stdio_context.__aexit__(None, None, None)
    
    async def discover_features(self):
        """Discover all server features."""
        features = {
            "tools": [],
            "resources": [],
            "prompts": []
        }
        
        # List tools
        tools_result = await self.session.list_tools()
        features["tools"] = [
            {"name": t.name, "description": t.description}
            for t in tools_result.tools
        ]
        
        # List resources
        resources_result = await self.session.list_resources()
        features["resources"] = [
            {"uri": r.uri, "name": r.name}
            for r in resources_result.resources
        ]
        
        # List prompts
        prompts_result = await self.session.list_prompts()
        features["prompts"] = [
            {"name": p.name, "description": p.description}
            for p in prompts_result.prompts
        ]
        
        return features
    
    async def call_tool(self, name: str, arguments: dict):
        """Call a tool and return the result."""
        result = await self.session.call_tool(name, arguments)
        
        # Extract text content
        text_results = []
        for content in result.content:
            if content.type == "text":
                text_results.append(content.text)
        
        return {
            "success": not result.isError,
            "results": text_results
        }
    
    async def read_resource(self, uri: str):
        """Read a resource and return its content."""
        result = await self.session.read_resource(uri)
        
        contents = []
        for content in result.contents:
            if hasattr(content, 'text'):
                contents.append(content.text)
        
        return contents


async def main():
    """Main function demonstrating client usage."""
    
    # Create client for a calculator server
    client = MCPClientExample(
        server_command="python",
        server_args=["calculator_server.py"]
    )
    
    try:
        # Connect
        await client.connect()
        
        # Discover features
        features = await client.discover_features()
        print("\n=== Available Features ===")
        print(f"Tools: {[t['name'] for t in features['tools']]}")
        print(f"Resources: {[r['uri'] for r in features['resources']]}")
        print(f"Prompts: {[p['name'] for p in features['prompts']]}")
        
        # Call a tool
        print("\n=== Calling 'add' tool ===")
        result = await client.call_tool("add", {"a": 10, "b": 20})
        print(f"Result: {result}")
        
        # Read a resource
        print("\n=== Reading resource ===")
        if features["resources"]:
            content = await client.read_resource(features["resources"][0]["uri"])
            print(f"Content: {content}")
    
    finally:
        # Disconnect
        await client.disconnect()


if __name__ == "__main__":
    asyncio.run(main())
```

---

## Best Practices

### 1. Always Use Context Managers

```python
# Good - uses context managers
async with stdio_client(params) as (read, write):
    async with ClientSession(read, write) as session:
        await session.initialize()
        # ... use session

# Bad - manual cleanup required
read, write = await create_connection(params)
session = ClientSession(read, write)
# ... use session
await session.close()  # Easy to forget!
```

### 2. Handle Initialization Properly

```python
async def safe_initialize(session: ClientSession):
    """Initialize with proper error handling."""
    try:
        result = await session.initialize()
        return {"success": True, "info": result}
    except Exception as e:
        return {"success": False, "error": str(e)}
```

### 3. Cache Feature Lists

```python
class CachingClient:
    """Client that caches feature lists."""
    
    def __init__(self, session: ClientSession):
        self.session = session
        self._tools_cache = None
        self._resources_cache = None
    
    async def get_tools(self, refresh: bool = False):
        if self._tools_cache is None or refresh:
            result = await self.session.list_tools()
            self._tools_cache = result.tools
        return self._tools_cache
```

---

## Summary

| Feature | Method | Description |
|---------|--------|-------------|
| **Connect (stdio)** | `stdio_client()` | Connect to stdio-based server |
| **Connect (SSE)** | `sse_client()` | Connect to HTTP/SSE server |
| **Initialize** | `session.initialize()` | Start the session |
| **List Tools** | `session.list_tools()` | Get available tools |
| **Call Tool** | `session.call_tool()` | Execute a tool |
| **List Resources** | `session.list_resources()` | Get available resources |
| **Read Resource** | `session.read_resource()` | Read resource content |
| **List Prompts** | `session.list_prompts()` | Get available prompts |
| **Get Prompt** | `session.get_prompt()` | Get prompt messages |

---

## Next Steps

- [LangChain MCP Adapter](_03_langchain_mcp_adapter.md) - Convert MCP tools for LangChain
- [Building Agents with MCP](_04_building_agents_with_mcp.md) - Create AI agents using MCP
