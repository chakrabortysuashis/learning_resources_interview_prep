# LangChain MCP Adapter

## Module 6.3: Integrating MCP with LangChain

---

## What is langchain-mcp-adapters?

**langchain-mcp-adapters** is an official package that provides seamless integration between MCP (Model Context Protocol) servers and the LangChain ecosystem. It converts MCP tools into LangChain-compatible tools, enabling you to use any MCP server with LangChain agents.

```
+-----------------------------------------------------------------------------+
|                    LANGCHAIN-MCP-ADAPTERS ARCHITECTURE                       |
+-----------------------------------------------------------------------------+
|                                                                             |
|   +-------------------+                           +-------------------+     |
|   |   LangChain       |                           |    MCP Servers    |     |
|   |   Agent/Chain     |                           |                   |     |
|   +-------------------+                           +-------------------+     |
|           |                                               ^                 |
|           |  Uses LangChain Tools                         |                 |
|           v                                               |                 |
|   +-------------------------------------------------------+-------+         |
|   |                 langchain-mcp-adapters                        |         |
|   |                                                               |         |
|   |  +-------------------+    +-------------------+               |         |
|   |  | MultiServerMCP    |    | MCPToolkit        |               |         |
|   |  | Client            |    | (Tool Conversion) |               |         |
|   |  +-------------------+    +-------------------+               |         |
|   |                                                               |         |
|   +---------------------------------------------------------------+         |
|                                                                             |
|   Converts MCP tools to LangChain BaseTool format                           |
|                                                                             |
+-----------------------------------------------------------------------------+
```

---

## Why Use langchain-mcp-adapters?

### The Integration Challenge

MCP servers expose tools in the MCP format:
- JSON Schema-based input definitions
- Specific content types (TextContent, ImageContent)
- Session-based connections

LangChain expects tools in its format:
- Pydantic models for inputs
- BaseTool subclasses
- Specific invoke/ainvoke interfaces

### The Solution

langchain-mcp-adapters bridges this gap:

```
+-----------------------------------------------------------------------------+
|                        TOOL CONVERSION FLOW                                  |
+-----------------------------------------------------------------------------+
|                                                                             |
|   MCP Tool Definition                      LangChain Tool                   |
|   -------------------                      --------------                   |
|                                                                             |
|   {                                        class AddTool(BaseTool):         |
|     "name": "add",                           name = "add"                   |
|     "description": "Add nums",               description = "Add nums"      |
|     "inputSchema": {           ======>       args_schema = AddInput        |
|       "properties": {                                                       |
|         "a": {"type": "number"},             def _run(self, a, b):         |
|         "b": {"type": "number"}                return mcp_call(a, b)       |
|       }                                                                     |
|     }                                                                       |
|   }                                                                         |
|                                                                             |
+-----------------------------------------------------------------------------+
```

---

## Installation and Setup

### Install the Package

```bash
# Install langchain-mcp-adapters
pip install langchain-mcp-adapters

# Install with LangChain
pip install langchain-mcp-adapters langchain langchain-anthropic

# Or using uv
uv pip install langchain-mcp-adapters langchain langchain-anthropic
```

### Required Dependencies

```bash
# Full setup for MCP + LangChain development
pip install \
    langchain-mcp-adapters \
    langchain \
    langchain-core \
    langchain-anthropic \
    mcp \
    python-dotenv
```

### Environment Setup

```python
# .env file
ANTHROPIC_API_KEY=your_api_key_here
```

```python
# Load environment variables
from dotenv import load_dotenv
load_dotenv()
```

---

## Converting MCP Tools to LangChain Tools

### Basic Conversion

```python
from langchain_mcp_adapters.tools import load_mcp_tools
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

async def get_langchain_tools():
    """Load MCP tools as LangChain tools."""
    
    # Server parameters
    server_params = StdioServerParameters(
        command="python",
        args=["my_mcp_server.py"]
    )
    
    # Connect and load tools
    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            
            # Convert MCP tools to LangChain tools
            tools = await load_mcp_tools(session)
            
            print(f"Loaded {len(tools)} tools:")
            for tool in tools:
                print(f"  - {tool.name}: {tool.description}")
            
            return tools
```

### Understanding the Converted Tool

```python
# After conversion, each tool is a LangChain BaseTool

async def examine_converted_tool(session):
    """Examine a converted MCP tool."""
    
    tools = await load_mcp_tools(session)
    
    for tool in tools:
        print(f"Tool Name: {tool.name}")
        print(f"Description: {tool.description}")
        print(f"Args Schema: {tool.args_schema.schema()}")
        print(f"Return Direct: {tool.return_direct}")
        print("-" * 40)
```

---

## MultiServerMCPClient Usage

The `MultiServerMCPClient` is the recommended way to work with MCP servers in LangChain. It manages connections to multiple servers and provides unified access to all tools.

### Basic Usage

```python
from langchain_mcp_adapters.client import MultiServerMCPClient

async def basic_multi_server():
    """Basic MultiServerMCPClient usage."""
    
    # Create the multi-server client
    async with MultiServerMCPClient(
        {
            "math": {
                "command": "python",
                "args": ["math_server.py"],
                "transport": "stdio"
            }
        }
    ) as client:
        # Get all tools from all connected servers
        tools = client.get_tools()
        
        print(f"Available tools: {[t.name for t in tools]}")
```

### Configuration Options

```python
from langchain_mcp_adapters.client import MultiServerMCPClient

# Configuration structure
server_config = {
    # Server name (your choice)
    "server_name": {
        # For stdio transport
        "command": "python",           # Command to run
        "args": ["server.py"],         # Command arguments
        "transport": "stdio",          # Transport type
        "env": {"KEY": "value"},       # Optional environment variables
        
        # OR for SSE transport
        "url": "http://localhost:8000/sse",
        "transport": "sse",
        
        # OR for streamable HTTP transport
        "url": "http://localhost:8000/mcp",
        "transport": "streamable_http"
    }
}
```

### Complete Example with Configuration

```python
from langchain_mcp_adapters.client import MultiServerMCPClient

async def configured_multi_server():
    """MultiServerMCPClient with full configuration."""
    
    # Define multiple server configurations
    servers = {
        # Calculator server via stdio
        "calculator": {
            "command": "python",
            "args": ["servers/calculator_server.py"],
            "transport": "stdio"
        },
        
        # File system server via stdio
        "filesystem": {
            "command": "python",
            "args": ["servers/filesystem_server.py"],
            "transport": "stdio",
            "env": {
                "ROOT_PATH": "/home/user/documents"
            }
        },
        
        # Weather API server via SSE
        "weather": {
            "url": "http://localhost:8000/sse",
            "transport": "sse"
        }
    }
    
    async with MultiServerMCPClient(servers) as client:
        # Get all tools from all servers
        all_tools = client.get_tools()
        
        print("=" * 60)
        print("TOOLS FROM ALL SERVERS")
        print("=" * 60)
        
        for tool in all_tools:
            print(f"\n{tool.name}")
            print(f"  Description: {tool.description}")
```

---

## Connecting to Multiple MCP Servers

### Architecture

```
+-----------------------------------------------------------------------------+
|                      MULTI-SERVER CONNECTION                                 |
+-----------------------------------------------------------------------------+
|                                                                             |
|                     +------------------------+                               |
|                     |  MultiServerMCPClient  |                               |
|                     +------------------------+                               |
|                              |                                               |
|          +-------------------+-------------------+                           |
|          |                   |                   |                           |
|          v                   v                   v                           |
|   +-----------+       +-----------+       +-----------+                     |
|   | Session 1 |       | Session 2 |       | Session 3 |                     |
|   | (stdio)   |       | (stdio)   |       | (sse)     |                     |
|   +-----------+       +-----------+       +-----------+                     |
|          |                   |                   |                           |
|          v                   v                   v                           |
|   +-----------+       +-----------+       +-----------+                     |
|   | Calculator|       | Filesystem|       | Weather   |                     |
|   | Server    |       | Server    |       | Server    |                     |
|   +-----------+       +-----------+       +-----------+                     |
|                                                                             |
|   All tools are collected and exposed as LangChain tools                    |
|                                                                             |
+-----------------------------------------------------------------------------+
```

### Connecting to Multiple Servers

```python
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_anthropic import ChatAnthropic

async def multi_server_agent():
    """Create an agent with tools from multiple MCP servers."""
    
    # Configure multiple servers
    servers = {
        "math": {
            "command": "python",
            "args": ["math_server.py"],
            "transport": "stdio"
        },
        "search": {
            "command": "python", 
            "args": ["search_server.py"],
            "transport": "stdio"
        },
        "database": {
            "url": "http://localhost:9000/sse",
            "transport": "sse"
        }
    }
    
    async with MultiServerMCPClient(servers) as client:
        # Get tools from all servers
        tools = client.get_tools()
        
        # Group tools by server (based on naming convention)
        print("\n=== Tools by Server ===")
        for tool in tools:
            print(f"  {tool.name}: {tool.description[:50]}...")
        
        # Create an LLM
        llm = ChatAnthropic(model="claude-sonnet-4-20250514")
        
        # Bind tools to the LLM
        llm_with_tools = llm.bind_tools(tools)
        
        # The agent can now use tools from all servers
        response = await llm_with_tools.ainvoke(
            "Calculate 15 * 7 and then search for information about the result"
        )
        
        return response
```

### Handling Server-Specific Configuration

```python
from langchain_mcp_adapters.client import MultiServerMCPClient
import os

async def production_multi_server():
    """Production-ready multi-server configuration."""
    
    # Load configurations from environment or config file
    servers = {
        "internal_api": {
            "command": "python",
            "args": ["internal_api_server.py"],
            "transport": "stdio",
            "env": {
                "API_KEY": os.getenv("INTERNAL_API_KEY"),
                "API_URL": os.getenv("INTERNAL_API_URL")
            }
        },
        "external_service": {
            "url": os.getenv("EXTERNAL_MCP_URL"),
            "transport": "sse"
        },
        "local_tools": {
            "command": "npx",
            "args": ["-y", "@modelcontextprotocol/server-filesystem", "/data"],
            "transport": "stdio"
        }
    }
    
    # Filter out servers with missing configuration
    valid_servers = {
        name: config 
        for name, config in servers.items()
        if all(v is not None for v in config.values())
    }
    
    async with MultiServerMCPClient(valid_servers) as client:
        tools = client.get_tools()
        print(f"Connected to {len(valid_servers)} servers")
        print(f"Total tools available: {len(tools)}")
        return tools
```

---

## Detailed Code Examples

### Example 1: Simple Tool Usage

```python
"""
Simple example: Load MCP tools and use them with LangChain.
"""

import asyncio
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_anthropic import ChatAnthropic
from langchain_core.messages import HumanMessage

async def simple_tool_usage():
    """Use MCP tools with a basic LangChain workflow."""
    
    # Configure the MCP server
    servers = {
        "calculator": {
            "command": "python",
            "args": ["calculator_server.py"],
            "transport": "stdio"
        }
    }
    
    async with MultiServerMCPClient(servers) as client:
        # Get the tools
        tools = client.get_tools()
        
        # Create the LLM with tools
        llm = ChatAnthropic(model="claude-sonnet-4-20250514")
        llm_with_tools = llm.bind_tools(tools)
        
        # Ask a question that requires tool use
        messages = [HumanMessage(content="What is 123 + 456?")]
        
        # Get the response (may include tool calls)
        response = await llm_with_tools.ainvoke(messages)
        
        print("Response:", response)
        
        # If the LLM wants to call a tool
        if response.tool_calls:
            for tool_call in response.tool_calls:
                print(f"Tool: {tool_call['name']}")
                print(f"Args: {tool_call['args']}")
                
                # Find and execute the tool
                tool = next(t for t in tools if t.name == tool_call['name'])
                result = await tool.ainvoke(tool_call['args'])
                print(f"Result: {result}")


if __name__ == "__main__":
    asyncio.run(simple_tool_usage())
```

### Example 2: Multi-Server Integration

```python
"""
Multi-server example: Connect to multiple MCP servers simultaneously.
"""

import asyncio
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_anthropic import ChatAnthropic

async def multi_server_integration():
    """Integrate multiple MCP servers with LangChain."""
    
    # Configure multiple MCP servers
    servers = {
        # Math operations server
        "math": {
            "command": "python",
            "args": ["servers/math_server.py"],
            "transport": "stdio"
        },
        # String manipulation server  
        "strings": {
            "command": "python",
            "args": ["servers/string_server.py"],
            "transport": "stdio"
        },
        # Date/time utilities server
        "datetime": {
            "command": "python",
            "args": ["servers/datetime_server.py"],
            "transport": "stdio"
        }
    }
    
    async with MultiServerMCPClient(servers) as client:
        # Get all tools
        tools = client.get_tools()
        
        # Display available tools grouped by functionality
        print("=" * 60)
        print("AVAILABLE TOOLS FROM ALL SERVERS")
        print("=" * 60)
        
        for tool in tools:
            print(f"\n{tool.name}")
            print(f"  {tool.description}")
        
        # Create an agent that can use all tools
        llm = ChatAnthropic(
            model="claude-sonnet-4-20250514",
            temperature=0
        )
        
        llm_with_tools = llm.bind_tools(tools)
        
        # Complex query requiring multiple tools
        query = """
        I need to:
        1. Calculate 15% of 250
        2. Convert the result to uppercase text
        3. Get the current timestamp
        
        Please help me with these tasks.
        """
        
        response = await llm_with_tools.ainvoke(query)
        
        # Process tool calls
        for tool_call in response.tool_calls:
            tool_name = tool_call['name']
            tool_args = tool_call['args']
            
            # Find the matching tool
            tool = next((t for t in tools if t.name == tool_name), None)
            
            if tool:
                result = await tool.ainvoke(tool_args)
                print(f"\n{tool_name}({tool_args}) = {result}")


if __name__ == "__main__":
    asyncio.run(multi_server_integration())
```

### Example 3: Error Handling

```python
"""
Error handling example: Robust MCP-LangChain integration.
"""

import asyncio
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_anthropic import ChatAnthropic
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def robust_mcp_integration():
    """MCP integration with comprehensive error handling."""
    
    servers = {
        "primary": {
            "command": "python",
            "args": ["primary_server.py"],
            "transport": "stdio"
        },
        "backup": {
            "url": "http://localhost:8000/sse",
            "transport": "sse"
        }
    }
    
    try:
        async with MultiServerMCPClient(servers) as client:
            tools = client.get_tools()
            
            if not tools:
                logger.warning("No tools available from any server")
                return None
            
            logger.info(f"Loaded {len(tools)} tools successfully")
            
            # Create LLM with tools
            llm = ChatAnthropic(model="claude-sonnet-4-20250514")
            llm_with_tools = llm.bind_tools(tools)
            
            # Execute with error handling
            try:
                response = await llm_with_tools.ainvoke(
                    "Perform a calculation for me: 100 / 0"
                )
                
                # Handle tool calls
                for tool_call in response.tool_calls:
                    tool = next(
                        (t for t in tools if t.name == tool_call['name']),
                        None
                    )
                    
                    if tool:
                        try:
                            result = await tool.ainvoke(tool_call['args'])
                            logger.info(f"Tool {tool_call['name']} result: {result}")
                        except Exception as tool_error:
                            logger.error(f"Tool execution failed: {tool_error}")
                
                return response
                
            except Exception as invoke_error:
                logger.error(f"LLM invocation failed: {invoke_error}")
                raise
                
    except ConnectionError as conn_error:
        logger.error(f"Failed to connect to MCP servers: {conn_error}")
        raise
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        raise


if __name__ == "__main__":
    asyncio.run(robust_mcp_integration())
```

### Example 4: Tool Filtering and Selection

```python
"""
Tool filtering example: Select specific tools from MCP servers.
"""

import asyncio
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_core.tools import BaseTool

def filter_tools(
    tools: list[BaseTool],
    include_patterns: list[str] = None,
    exclude_patterns: list[str] = None
) -> list[BaseTool]:
    """Filter tools based on name patterns."""
    
    filtered = tools
    
    # Include only tools matching patterns
    if include_patterns:
        filtered = [
            t for t in filtered
            if any(pattern in t.name for pattern in include_patterns)
        ]
    
    # Exclude tools matching patterns
    if exclude_patterns:
        filtered = [
            t for t in filtered
            if not any(pattern in t.name for pattern in exclude_patterns)
        ]
    
    return filtered


async def selective_tool_loading():
    """Load and filter MCP tools selectively."""
    
    servers = {
        "all_tools": {
            "command": "python",
            "args": ["comprehensive_server.py"],
            "transport": "stdio"
        }
    }
    
    async with MultiServerMCPClient(servers) as client:
        all_tools = client.get_tools()
        
        print(f"Total tools available: {len(all_tools)}")
        
        # Filter for math-related tools only
        math_tools = filter_tools(
            all_tools,
            include_patterns=["add", "subtract", "multiply", "divide", "calc"]
        )
        print(f"Math tools: {[t.name for t in math_tools]}")
        
        # Filter for file tools, excluding delete operations
        safe_file_tools = filter_tools(
            all_tools,
            include_patterns=["file", "read", "write"],
            exclude_patterns=["delete", "remove", "rm"]
        )
        print(f"Safe file tools: {[t.name for t in safe_file_tools]}")
        
        # Use only the filtered tools with an agent
        from langchain_anthropic import ChatAnthropic
        
        llm = ChatAnthropic(model="claude-sonnet-4-20250514")
        
        # Math-only agent
        math_agent = llm.bind_tools(math_tools)
        
        # Safe file agent
        file_agent = llm.bind_tools(safe_file_tools)
        
        return {
            "math_agent": math_agent,
            "file_agent": file_agent
        }


if __name__ == "__main__":
    asyncio.run(selective_tool_loading())
```

---

## Configuration Reference

### Server Configuration Options

| Option | Type | Transport | Description |
|--------|------|-----------|-------------|
| `command` | string | stdio | Command to execute |
| `args` | list | stdio | Command arguments |
| `env` | dict | stdio | Environment variables |
| `url` | string | sse, streamable_http | Server URL |
| `transport` | string | all | Transport type |

### Transport Types

| Transport | Use Case | Configuration |
|-----------|----------|---------------|
| `stdio` | Local servers, CLI tools | `command`, `args`, `env` |
| `sse` | HTTP servers with SSE | `url` |
| `streamable_http` | Modern HTTP servers | `url` |

---

## Summary

| Feature | Description |
|---------|-------------|
| **langchain-mcp-adapters** | Bridge between MCP and LangChain |
| **load_mcp_tools** | Convert MCP tools to LangChain tools |
| **MultiServerMCPClient** | Manage multiple MCP server connections |
| **Tool Conversion** | Automatic schema translation |
| **Multi-Server** | Connect to many servers simultaneously |

---

## Next Steps

- [Building Agents with MCP](_04_building_agents_with_mcp.md) - Create intelligent agents
- [LangChain MCP Examples](_05_langchain_mcp_examples.ipynb) - Hands-on notebook
