# Model Context Protocol (MCP) - Complete Course

## Course Overview

This course provides a comprehensive guide to the **Model Context Protocol (MCP)** - an open protocol that standardizes how AI applications connect to external data sources and tools. By the end of this course, you'll be able to build MCP servers using FastMCP, integrate them with clients using LangChain, and convert existing FastAPI applications to MCP.

## What You'll Learn

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        MCP LEARNING PATH                                     │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐                   │
│  │ Foundations  │───▶│  Protocol    │───▶│  Components  │                   │
│  │ (Modules 1-2)│    │ (Module 3)   │    │ (Module 4)   │                   │
│  └──────────────┘    └──────────────┘    └──────────────┘                   │
│         │                                       │                            │
│         ▼                                       ▼                            │
│  ┌──────────────────────────────────────────────────────────────────┐       │
│  │                    Practical Implementation                       │       │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌──────────┐ │       │
│  │  │ FastMCP     │  │ MCP Clients │  │ FastAPI →   │  │ Testing  │ │       │
│  │  │ Server (5)  │  │ (6)         │  │ MCP (7)     │  │ (8)      │ │       │
│  │  └─────────────┘  └─────────────┘  └─────────────┘  └──────────┘ │       │
│  └──────────────────────────────────────────────────────────────────┘       │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Module Structure

| Module | Folder | Description |
|--------|--------|-------------|
| 1 | `_01_introduction_to_mcp` | What is MCP, why it's needed, JSON-RPC basics |
| 2 | `_02_transport_layer` | Communication transports: stdio, HTTP/SSE, WebSocket |
| 3 | `_03_protocol_fundamentals` | Message formats, request/response patterns, lifecycle |
| 4 | `_04_mcp_components` | Resources, Tools, Prompts, and Sampling primitives |
| 5 | `_05_fastmcp_server` | Building MCP servers with FastMCP framework |
| 6 | `_06_mcp_clients` | Client implementation with LangChain MCP adapter |
| 7 | `_07_fastapi_to_mcp` | Converting existing FastAPI apps to MCP servers |
| 8 | `_08_testing_mcp_servers` | Testing with MCP Inspector, Postman, and automation |

## Prerequisites

- Python 3.10+
- Basic understanding of:
  - Python async/await
  - REST APIs
  - JSON format
  - (Optional) LangChain basics

## Installation

```bash
# Create virtual environment
python -m venv mcp-env
source mcp-env/bin/activate  # Linux/Mac
# or
mcp-env\Scripts\activate  # Windows

# Install required packages
pip install fastmcp langchain-mcp-adapters mcp httpx uvicorn fastapi
```

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           MCP ARCHITECTURE                                   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│    ┌─────────────────┐                      ┌─────────────────┐             │
│    │   MCP CLIENT    │                      │   MCP SERVER    │             │
│    │                 │                      │                 │             │
│    │  ┌───────────┐  │    JSON-RPC 2.0      │  ┌───────────┐  │             │
│    │  │  LLM /    │  │◀────────────────────▶│  │ Resources │  │             │
│    │  │  Agent    │  │                      │  └───────────┘  │             │
│    │  └───────────┘  │                      │                 │             │
│    │                 │     Transport        │  ┌───────────┐  │             │
│    │  ┌───────────┐  │  ┌─────────────┐     │  │   Tools   │  │             │
│    │  │  Client   │◀─┼──│ stdio/HTTP/ │─────┼─▶│           │  │             │
│    │  │  SDK      │  │  │ SSE/WebSocket│     │  └───────────┘  │             │
│    │  └───────────┘  │  └─────────────┘     │                 │             │
│    │                 │                      │  ┌───────────┐  │             │
│    └─────────────────┘                      │  │  Prompts  │  │             │
│                                             │  └───────────┘  │             │
│                                             │                 │             │
│                                             └─────────────────┘             │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Key Technologies Covered

| Technology | Purpose | Documentation |
|------------|---------|---------------|
| **FastMCP** | High-level Python framework for building MCP servers | [FastMCP Docs](https://gofastmcp.com) |
| **MCP SDK** | Official Python SDK for MCP | [MCP SDK](https://github.com/modelcontextprotocol/python-sdk) |
| **LangChain MCP Adapter** | Connect MCP servers to LangChain agents | [LangChain MCP](https://github.com/langchain-ai/langchain-mcp-adapters) |
| **MCP Inspector** | Testing and debugging tool for MCP servers | [Inspector](https://github.com/modelcontextprotocol/inspector) |

## How to Use This Course

1. **Follow the module order** - Each module builds on concepts from previous ones
2. **Run the code examples** - All `.ipynb` files are executable Jupyter notebooks
3. **Read the markdown files** - They contain diagrams and explanations
4. **Build projects** - Each module has practical exercises

## Quick Start Example

Here's a taste of what you'll build:

```python
# A simple MCP server with FastMCP
from fastmcp import FastMCP

mcp = FastMCP("My First Server")

@mcp.tool()
def greet(name: str) -> str:
    """Greet a user by name."""
    return f"Hello, {name}! Welcome to MCP."

@mcp.resource("config://app")
def get_config() -> str:
    """Get application configuration."""
    return "{'version': '1.0', 'debug': true}"

if __name__ == "__main__":
    mcp.run()
```

## Course Author

This course was created as a comprehensive learning resource for developers looking to understand and implement the Model Context Protocol in their AI applications.

---

**Let's begin with Module 1: Introduction to MCP** → [_01_introduction_to_mcp](_01_introduction_to_mcp/)
