# Step-by-Step FastAPI to MCP Conversion

## Table of Contents
1. [Introduction](#introduction)
2. [The FastAPI Application](#the-fastapi-application)
3. [Step 1: Analyze the API Structure](#step-1-analyze-the-api-structure)
4. [Step 2: Set Up the MCP Project](#step-2-set-up-the-mcp-project)
5. [Step 3: Convert Endpoints to Tools](#step-3-convert-endpoints-to-tools)
6. [Step 4: Convert Data Endpoints to Resources](#step-4-convert-data-endpoints-to-resources)
7. [Step 5: Handle State and Dependencies](#step-5-handle-state-and-dependencies)
8. [Step 6: Translate Error Handling](#step-6-translate-error-handling)
9. [Step 7: Add Lifespan Management](#step-7-add-lifespan-management)
10. [Complete Before and After](#complete-before-and-after)
11. [Summary](#summary)

---

## Introduction

This guide walks through the complete conversion of a realistic FastAPI application to an MCP server. We'll convert a **Task Management API** with CRUD operations, user management, and search functionality.

```
+-----------------------------------------------------------------------+
|                    CONVERSION PROCESS OVERVIEW                         |
+-----------------------------------------------------------------------+
|                                                                        |
|   STEP 1          STEP 2          STEP 3          STEP 4              |
|   +------+        +------+        +------+        +------+            |
|   |Analyze| -----> |Setup | -----> |Convert| -----> |Convert|          |
|   | API   |        | MCP  |        |Endpoints     | Data  |            |
|   +------+        +------+        | to Tools     | to Res|            |
|                                   +------+        +------+            |
|                                                                        |
|   STEP 5          STEP 6          STEP 7                              |
|   +------+        +------+        +------+                            |
|   |Handle | -----> |Translate ----> |Add    |                          |
|   |State  |        |Errors |        |Lifespan                          |
|   +------+        +------+        +------+                            |
|                                                                        |
+-----------------------------------------------------------------------+
```

---

## The FastAPI Application

Here's our starting point - a complete FastAPI task management API:

```python
# fastapi_app.py - Original FastAPI Application
from fastapi import FastAPI, HTTPException, Query, Depends
from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime
from enum import Enum

app = FastAPI(
    title="Task Manager API",
    description="A REST API for managing tasks and projects",
    version="1.0.0"
)

# ============== MODELS ==============

class Priority(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"

class TaskStatus(str, Enum):
    TODO = "todo"
    IN_PROGRESS = "in_progress"
    DONE = "done"

class TaskCreate(BaseModel):
    title: str = Field(..., min_length=1, max_length=200)
    description: str = Field(default="", max_length=1000)
    priority: Priority = Priority.MEDIUM
    project_id: Optional[int] = None

class TaskUpdate(BaseModel):
    title: Optional[str] = Field(None, min_length=1, max_length=200)
    description: Optional[str] = Field(None, max_length=1000)
    priority: Optional[Priority] = None
    status: Optional[TaskStatus] = None

class Task(BaseModel):
    id: int
    title: str
    description: str
    priority: Priority
    status: TaskStatus
    project_id: Optional[int]
    created_at: datetime
    updated_at: datetime

class ProjectCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    description: str = ""

class Project(BaseModel):
    id: int
    name: str
    description: str
    created_at: datetime

# ============== DATABASE (in-memory) ==============

tasks_db: dict[int, dict] = {}
projects_db: dict[int, dict] = {}
task_counter = 0
project_counter = 0

# ============== CONFIG ==============

APP_CONFIG = {
    "version": "1.0.0",
    "max_tasks_per_project": 100,
    "default_priority": "medium",
    "features": {
        "projects_enabled": True,
        "search_enabled": True,
        "export_enabled": False
    }
}

# ============== ENDPOINTS ==============

# ----- Configuration -----
@app.get("/config")
async def get_config() -> dict:
    """Get application configuration."""
    return APP_CONFIG

# ----- Projects -----
@app.post("/projects", response_model=Project)
async def create_project(project: ProjectCreate) -> Project:
    """Create a new project."""
    global project_counter
    project_counter += 1
    
    now = datetime.now()
    new_project = {
        "id": project_counter,
        "name": project.name,
        "description": project.description,
        "created_at": now
    }
    projects_db[project_counter] = new_project
    return Project(**new_project)

@app.get("/projects", response_model=List[Project])
async def list_projects() -> List[Project]:
    """List all projects."""
    return [Project(**p) for p in projects_db.values()]

@app.get("/projects/{project_id}", response_model=Project)
async def get_project(project_id: int) -> Project:
    """Get a project by ID."""
    if project_id not in projects_db:
        raise HTTPException(status_code=404, detail="Project not found")
    return Project(**projects_db[project_id])

@app.delete("/projects/{project_id}")
async def delete_project(project_id: int) -> dict:
    """Delete a project and all its tasks."""
    if project_id not in projects_db:
        raise HTTPException(status_code=404, detail="Project not found")
    
    # Delete associated tasks
    tasks_to_delete = [
        tid for tid, task in tasks_db.items() 
        if task.get("project_id") == project_id
    ]
    for tid in tasks_to_delete:
        del tasks_db[tid]
    
    del projects_db[project_id]
    return {"message": f"Project {project_id} and {len(tasks_to_delete)} tasks deleted"}

# ----- Tasks -----
@app.post("/tasks", response_model=Task)
async def create_task(task: TaskCreate) -> Task:
    """Create a new task."""
    global task_counter
    
    # Validate project exists if specified
    if task.project_id and task.project_id not in projects_db:
        raise HTTPException(status_code=400, detail="Project not found")
    
    task_counter += 1
    now = datetime.now()
    
    new_task = {
        "id": task_counter,
        "title": task.title,
        "description": task.description,
        "priority": task.priority.value,
        "status": TaskStatus.TODO.value,
        "project_id": task.project_id,
        "created_at": now,
        "updated_at": now
    }
    tasks_db[task_counter] = new_task
    return Task(**new_task)

@app.get("/tasks", response_model=List[Task])
async def list_tasks(
    status: Optional[TaskStatus] = Query(None, description="Filter by status"),
    priority: Optional[Priority] = Query(None, description="Filter by priority"),
    project_id: Optional[int] = Query(None, description="Filter by project"),
    limit: int = Query(50, ge=1, le=100, description="Maximum results"),
    offset: int = Query(0, ge=0, description="Skip N results")
) -> List[Task]:
    """List tasks with optional filters."""
    tasks = list(tasks_db.values())
    
    # Apply filters
    if status:
        tasks = [t for t in tasks if t["status"] == status.value]
    if priority:
        tasks = [t for t in tasks if t["priority"] == priority.value]
    if project_id is not None:
        tasks = [t for t in tasks if t.get("project_id") == project_id]
    
    # Pagination
    tasks = tasks[offset:offset + limit]
    
    return [Task(**t) for t in tasks]

@app.get("/tasks/{task_id}", response_model=Task)
async def get_task(task_id: int) -> Task:
    """Get a task by ID."""
    if task_id not in tasks_db:
        raise HTTPException(status_code=404, detail="Task not found")
    return Task(**tasks_db[task_id])

@app.put("/tasks/{task_id}", response_model=Task)
async def update_task(task_id: int, update: TaskUpdate) -> Task:
    """Update a task."""
    if task_id not in tasks_db:
        raise HTTPException(status_code=404, detail="Task not found")
    
    task = tasks_db[task_id]
    
    if update.title is not None:
        task["title"] = update.title
    if update.description is not None:
        task["description"] = update.description
    if update.priority is not None:
        task["priority"] = update.priority.value
    if update.status is not None:
        task["status"] = update.status.value
    
    task["updated_at"] = datetime.now()
    
    return Task(**task)

@app.delete("/tasks/{task_id}")
async def delete_task(task_id: int) -> dict:
    """Delete a task."""
    if task_id not in tasks_db:
        raise HTTPException(status_code=404, detail="Task not found")
    
    del tasks_db[task_id]
    return {"message": f"Task {task_id} deleted"}

# ----- Search -----
@app.get("/search")
async def search_tasks(
    q: str = Query(..., min_length=1, description="Search query"),
    include_completed: bool = Query(True, description="Include completed tasks")
) -> List[Task]:
    """Search tasks by title or description."""
    query = q.lower()
    results = []
    
    for task in tasks_db.values():
        if query in task["title"].lower() or query in task["description"].lower():
            if include_completed or task["status"] != "done":
                results.append(Task(**task))
    
    return results

# ----- Statistics -----
@app.get("/stats")
async def get_statistics() -> dict:
    """Get task statistics."""
    total = len(tasks_db)
    by_status = {}
    by_priority = {}
    
    for task in tasks_db.values():
        status = task["status"]
        priority = task["priority"]
        by_status[status] = by_status.get(status, 0) + 1
        by_priority[priority] = by_priority.get(priority, 0) + 1
    
    return {
        "total_tasks": total,
        "by_status": by_status,
        "by_priority": by_priority,
        "total_projects": len(projects_db)
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
```

---

## Step 1: Analyze the API Structure

Before converting, we analyze which endpoints become tools vs resources.

```
+-----------------------------------------------------------------------+
|                    ENDPOINT ANALYSIS                                   |
+-----------------------------------------------------------------------+
|                                                                        |
|   ENDPOINT                    TYPE        CONVERTS TO                  |
|   ================================================================    |
|                                                                        |
|   GET  /config               Static      Resource (config://app)       |
|   ----------------------------------------------------------------    |
|   POST /projects             Action      Tool (create_project)         |
|   GET  /projects             Query       Tool (list_projects)          |
|   GET  /projects/{id}        Query       Tool (get_project)            |
|   DELETE /projects/{id}      Action      Tool (delete_project)         |
|   ----------------------------------------------------------------    |
|   POST /tasks                Action      Tool (create_task)            |
|   GET  /tasks                Query+Filter Tool (list_tasks)            |
|   GET  /tasks/{id}           Query       Tool (get_task)               |
|   PUT  /tasks/{id}           Action      Tool (update_task)            |
|   DELETE /tasks/{id}         Action      Tool (delete_task)            |
|   ----------------------------------------------------------------    |
|   GET  /search               Query       Tool (search_tasks)           |
|   GET  /stats                Dynamic     Tool (get_statistics)         |
|                                                                        |
+-----------------------------------------------------------------------+
```

### Conversion Decision Matrix

| Endpoint | Has Side Effects? | Has Filters? | Decision |
|----------|-------------------|--------------|----------|
| GET /config | No | No | **Resource** |
| POST /projects | Yes | No | **Tool** |
| GET /projects | No | No | **Tool** (could be resource but consistency) |
| DELETE /projects/{id} | Yes | No | **Tool** |
| POST /tasks | Yes | No | **Tool** |
| GET /tasks | No | Yes | **Tool** (filters need params) |
| PUT /tasks/{id} | Yes | No | **Tool** |
| GET /search | No | Yes | **Tool** |
| GET /stats | No | No | **Tool** (dynamic calculation) |

---

## Step 2: Set Up the MCP Project

Create the MCP project structure:

```
mcp_task_manager/
    __init__.py
    server.py          # Main MCP server
    models.py          # Shared Pydantic models
    database.py        # In-memory database
    tools/
        __init__.py
        projects.py    # Project tools
        tasks.py       # Task tools
        search.py      # Search tools
    resources/
        __init__.py
        config.py      # Configuration resource
```

### Initial Setup Code

```python
# mcp_task_manager/server.py
from fastmcp import FastMCP
from contextlib import asynccontextmanager

# Create MCP server
mcp = FastMCP(
    "Task Manager",
    description="MCP server for managing tasks and projects"
)
```

```python
# mcp_task_manager/database.py
from datetime import datetime

# Shared state
tasks_db: dict[int, dict] = {}
projects_db: dict[int, dict] = {}
task_counter = 0
project_counter = 0

def reset_database():
    """Reset database to initial state."""
    global tasks_db, projects_db, task_counter, project_counter
    tasks_db = {}
    projects_db = {}
    task_counter = 0
    project_counter = 0
```

```python
# mcp_task_manager/models.py
from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime
from enum import Enum

class Priority(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"

class TaskStatus(str, Enum):
    TODO = "todo"
    IN_PROGRESS = "in_progress"
    DONE = "done"

# Models remain the same for internal use
```

---

## Step 3: Convert Endpoints to Tools

### Side-by-Side: Create Task

```
+-----------------------------------------------------------------------+
|                    CREATE TASK: BEFORE & AFTER                         |
+-----------------------------------------------------------------------+

FASTAPI (BEFORE):
==================

@app.post("/tasks", response_model=Task)
async def create_task(task: TaskCreate) -> Task:
    """Create a new task."""
    global task_counter
    
    if task.project_id and task.project_id not in projects_db:
        raise HTTPException(status_code=400, detail="Project not found")
    
    task_counter += 1
    now = datetime.now()
    
    new_task = {
        "id": task_counter,
        "title": task.title,
        "description": task.description,
        "priority": task.priority.value,
        "status": TaskStatus.TODO.value,
        "project_id": task.project_id,
        "created_at": now,
        "updated_at": now
    }
    tasks_db[task_counter] = new_task
    return Task(**new_task)

+-----------------------------------------------------------------------+

MCP (AFTER):
============

from mcp import McpError
from mcp.types import ErrorCode
from database import tasks_db, projects_db

@mcp.tool()
def create_task(
    title: str,
    description: str = "",
    priority: str = "medium",
    project_id: int = None
) -> dict:
    """Create a new task in the task manager.
    
    Args:
        title: The title of the task (required)
        description: Detailed description of the task
        priority: Task priority - low, medium, or high
        project_id: Optional ID of the project this task belongs to
    
    Returns:
        The created task with its assigned ID and timestamps
    """
    global task_counter
    
    # Validate priority
    if priority not in ["low", "medium", "high"]:
        raise McpError(
            ErrorCode.InvalidParams,
            f"Invalid priority: {priority}. Use low, medium, or high."
        )
    
    # Validate project exists if specified
    if project_id is not None and project_id not in projects_db:
        raise McpError(
            ErrorCode.InvalidParams,
            f"Project {project_id} not found"
        )
    
    task_counter += 1
    now = datetime.now().isoformat()
    
    new_task = {
        "id": task_counter,
        "title": title,
        "description": description,
        "priority": priority,
        "status": "todo",
        "project_id": project_id,
        "created_at": now,
        "updated_at": now
    }
    tasks_db[task_counter] = new_task
    return new_task

+-----------------------------------------------------------------------+
```

### Side-by-Side: Update Task

```
+-----------------------------------------------------------------------+
|                    UPDATE TASK: BEFORE & AFTER                         |
+-----------------------------------------------------------------------+

FASTAPI (BEFORE):
==================

@app.put("/tasks/{task_id}", response_model=Task)
async def update_task(task_id: int, update: TaskUpdate) -> Task:
    """Update a task."""
    if task_id not in tasks_db:
        raise HTTPException(status_code=404, detail="Task not found")
    
    task = tasks_db[task_id]
    
    if update.title is not None:
        task["title"] = update.title
    if update.description is not None:
        task["description"] = update.description
    if update.priority is not None:
        task["priority"] = update.priority.value
    if update.status is not None:
        task["status"] = update.status.value
    
    task["updated_at"] = datetime.now()
    return Task(**task)

+-----------------------------------------------------------------------+

MCP (AFTER):
============

@mcp.tool()
def update_task(
    task_id: int,
    title: str = None,
    description: str = None,
    priority: str = None,
    status: str = None
) -> dict:
    """Update an existing task.
    
    Args:
        task_id: The ID of the task to update
        title: New title (optional)
        description: New description (optional)
        priority: New priority - low, medium, or high (optional)
        status: New status - todo, in_progress, or done (optional)
    
    Returns:
        The updated task
    """
    if task_id not in tasks_db:
        raise McpError(
            ErrorCode.InvalidParams,
            f"Task {task_id} not found"
        )
    
    task = tasks_db[task_id]
    
    # Validate and apply updates
    if title is not None:
        task["title"] = title
    if description is not None:
        task["description"] = description
    if priority is not None:
        if priority not in ["low", "medium", "high"]:
            raise McpError(
                ErrorCode.InvalidParams,
                f"Invalid priority: {priority}"
            )
        task["priority"] = priority
    if status is not None:
        if status not in ["todo", "in_progress", "done"]:
            raise McpError(
                ErrorCode.InvalidParams,
                f"Invalid status: {status}"
            )
        task["status"] = status
    
    task["updated_at"] = datetime.now().isoformat()
    return task

+-----------------------------------------------------------------------+
```

### Side-by-Side: List Tasks with Filters

```
+-----------------------------------------------------------------------+
|                    LIST TASKS: BEFORE & AFTER                          |
+-----------------------------------------------------------------------+

FASTAPI (BEFORE):
==================

@app.get("/tasks", response_model=List[Task])
async def list_tasks(
    status: Optional[TaskStatus] = Query(None),
    priority: Optional[Priority] = Query(None),
    project_id: Optional[int] = Query(None),
    limit: int = Query(50, ge=1, le=100),
    offset: int = Query(0, ge=0)
) -> List[Task]:
    """List tasks with optional filters."""
    tasks = list(tasks_db.values())
    
    if status:
        tasks = [t for t in tasks if t["status"] == status.value]
    if priority:
        tasks = [t for t in tasks if t["priority"] == priority.value]
    if project_id is not None:
        tasks = [t for t in tasks if t.get("project_id") == project_id]
    
    tasks = tasks[offset:offset + limit]
    return [Task(**t) for t in tasks]

+-----------------------------------------------------------------------+

MCP (AFTER):
============

@mcp.tool()
def list_tasks(
    status: str = None,
    priority: str = None,
    project_id: int = None,
    limit: int = 50,
    offset: int = 0
) -> list:
    """List all tasks with optional filtering and pagination.
    
    Args:
        status: Filter by status (todo, in_progress, done)
        priority: Filter by priority (low, medium, high)
        project_id: Filter by project ID
        limit: Maximum number of tasks to return (1-100, default 50)
        offset: Number of tasks to skip for pagination
    
    Returns:
        List of tasks matching the filter criteria
    """
    # Validate pagination
    limit = max(1, min(100, limit))
    offset = max(0, offset)
    
    tasks = list(tasks_db.values())
    
    # Apply filters
    if status:
        if status not in ["todo", "in_progress", "done"]:
            raise McpError(
                ErrorCode.InvalidParams,
                f"Invalid status: {status}"
            )
        tasks = [t for t in tasks if t["status"] == status]
    
    if priority:
        if priority not in ["low", "medium", "high"]:
            raise McpError(
                ErrorCode.InvalidParams,
                f"Invalid priority: {priority}"
            )
        tasks = [t for t in tasks if t["priority"] == priority]
    
    if project_id is not None:
        tasks = [t for t in tasks if t.get("project_id") == project_id]
    
    # Pagination
    return tasks[offset:offset + limit]

+-----------------------------------------------------------------------+
```

---

## Step 4: Convert Data Endpoints to Resources

### Configuration Resource

```
+-----------------------------------------------------------------------+
|                    CONFIG: BEFORE & AFTER                              |
+-----------------------------------------------------------------------+

FASTAPI (BEFORE):
==================

APP_CONFIG = {
    "version": "1.0.0",
    "max_tasks_per_project": 100,
    "default_priority": "medium",
    "features": {
        "projects_enabled": True,
        "search_enabled": True,
        "export_enabled": False
    }
}

@app.get("/config")
async def get_config() -> dict:
    """Get application configuration."""
    return APP_CONFIG

+-----------------------------------------------------------------------+

MCP (AFTER):
============

import json

APP_CONFIG = {
    "version": "1.0.0",
    "max_tasks_per_project": 100,
    "default_priority": "medium",
    "features": {
        "projects_enabled": True,
        "search_enabled": True,
        "export_enabled": False
    }
}

@mcp.resource("config://app")
def get_app_config() -> str:
    """Application configuration including version and feature flags."""
    return json.dumps(APP_CONFIG, indent=2)

@mcp.resource("config://features")
def get_features() -> str:
    """Feature flags for the application."""
    return json.dumps(APP_CONFIG["features"], indent=2)

+-----------------------------------------------------------------------+
```

---

## Step 5: Handle State and Dependencies

### FastAPI Dependency Injection vs MCP Patterns

```
+-----------------------------------------------------------------------+
|                    DEPENDENCY HANDLING                                 |
+-----------------------------------------------------------------------+

FASTAPI PATTERN (with Depends):
================================

from fastapi import Depends
from sqlalchemy.orm import Session

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.post("/tasks")
async def create_task(
    task: TaskCreate,
    db: Session = Depends(get_db)
):
    ...

+-----------------------------------------------------------------------+

MCP PATTERN (with Lifespan):
=============================

from fastmcp import FastMCP
from contextlib import asynccontextmanager

# Database connection stored in module scope
db_connection = None

@asynccontextmanager
async def lifespan(mcp):
    """Manage server lifecycle."""
    global db_connection
    
    # Startup: Initialize database
    print("Starting server, connecting to database...")
    db_connection = create_database_connection()
    
    yield  # Server runs here
    
    # Shutdown: Cleanup
    print("Shutting down, closing database...")
    if db_connection:
        db_connection.close()

mcp = FastMCP("Task Manager", lifespan=lifespan)

@mcp.tool()
def create_task(title: str) -> dict:
    """Create a task using the shared database connection."""
    # Use db_connection directly
    result = db_connection.execute(...)
    return result

+-----------------------------------------------------------------------+
```

### Using Context for Request-Scoped Data

```python
from fastmcp import FastMCP, Context

mcp = FastMCP("Task Manager")

@mcp.tool()
async def create_task(title: str, ctx: Context) -> dict:
    """Create a task with request context.
    
    Args:
        title: The task title
        ctx: Request context (injected automatically)
    """
    # Access request metadata via context
    request_id = ctx.request_id  # If available
    
    # Log with context
    await ctx.info(f"Creating task: {title}")
    
    # Progress reporting for long operations
    await ctx.report_progress(0.5, "Validating task...")
    
    # Create task...
    task = {"id": 1, "title": title}
    
    await ctx.report_progress(1.0, "Task created")
    return task
```

---

## Step 6: Translate Error Handling

### Error Mapping Reference

```
+-----------------------------------------------------------------------+
|                    ERROR TRANSLATION                                   |
+-----------------------------------------------------------------------+

HTTP Status Code          MCP ErrorCode              Usage
================          =============              =====

400 Bad Request    --->   InvalidParams             Bad input data
401 Unauthorized   --->   InvalidRequest            Auth required
403 Forbidden      --->   InvalidRequest            Permission denied
404 Not Found      --->   InvalidParams             Resource not found
409 Conflict       --->   InvalidParams             Duplicate/conflict
422 Unprocessable  --->   InvalidParams             Validation failed
500 Internal Error --->   InternalError             Server error

+-----------------------------------------------------------------------+
```

### Converting Error Handling

```
+-----------------------------------------------------------------------+
|                    ERROR HANDLING: BEFORE & AFTER                      |
+-----------------------------------------------------------------------+

FASTAPI (BEFORE):
==================

@app.delete("/projects/{project_id}")
async def delete_project(project_id: int) -> dict:
    if project_id not in projects_db:
        raise HTTPException(
            status_code=404,
            detail="Project not found"
        )
    
    # Check for tasks
    task_count = sum(
        1 for t in tasks_db.values()
        if t.get("project_id") == project_id
    )
    
    if task_count > 0:
        raise HTTPException(
            status_code=409,
            detail=f"Cannot delete: project has {task_count} tasks"
        )
    
    del projects_db[project_id]
    return {"message": "Project deleted"}

+-----------------------------------------------------------------------+

MCP (AFTER):
============

from mcp import McpError
from mcp.types import ErrorCode

@mcp.tool()
def delete_project(project_id: int, force: bool = False) -> str:
    """Delete a project.
    
    Args:
        project_id: The ID of the project to delete
        force: If True, also delete all tasks in the project
    
    Returns:
        Confirmation message
    """
    if project_id not in projects_db:
        raise McpError(
            ErrorCode.InvalidParams,
            f"Project {project_id} not found"
        )
    
    # Check for tasks
    project_tasks = [
        tid for tid, t in tasks_db.items()
        if t.get("project_id") == project_id
    ]
    
    if project_tasks and not force:
        raise McpError(
            ErrorCode.InvalidParams,
            f"Cannot delete: project has {len(project_tasks)} tasks. "
            f"Use force=True to delete anyway."
        )
    
    # Delete tasks if forcing
    if force:
        for tid in project_tasks:
            del tasks_db[tid]
    
    del projects_db[project_id]
    
    if project_tasks:
        return f"Project {project_id} and {len(project_tasks)} tasks deleted"
    return f"Project {project_id} deleted"

+-----------------------------------------------------------------------+
```

---

## Step 7: Add Lifespan Management

### Complete Lifespan Setup

```python
# mcp_task_manager/server.py - Complete Implementation
from fastmcp import FastMCP
from contextlib import asynccontextmanager
from datetime import datetime
import json

# Database state
tasks_db: dict[int, dict] = {}
projects_db: dict[int, dict] = {}
task_counter = 0
project_counter = 0
server_start_time = None

@asynccontextmanager
async def lifespan(mcp):
    """Manage server lifecycle."""
    global server_start_time
    
    # ===== STARTUP =====
    print("=" * 50)
    print("Task Manager MCP Server Starting...")
    print("=" * 50)
    
    server_start_time = datetime.now()
    
    # Load any persisted data (example)
    # load_data_from_file()
    
    # Initialize connections (example)
    # await connect_to_database()
    
    print(f"Server ready at {server_start_time.isoformat()}")
    print("=" * 50)
    
    yield  # Server runs here
    
    # ===== SHUTDOWN =====
    print("=" * 50)
    print("Task Manager MCP Server Shutting Down...")
    
    # Save data before shutdown (example)
    # save_data_to_file()
    
    # Close connections (example)
    # await disconnect_from_database()
    
    uptime = datetime.now() - server_start_time
    print(f"Server was up for {uptime}")
    print("=" * 50)

# Create MCP server with lifespan
mcp = FastMCP(
    "Task Manager",
    description="MCP server for managing tasks and projects",
    lifespan=lifespan
)

# ===== RESOURCES =====

APP_CONFIG = {
    "version": "1.0.0",
    "max_tasks_per_project": 100,
    "features": {"projects": True, "search": True}
}

@mcp.resource("config://app")
def get_config() -> str:
    """Application configuration."""
    return json.dumps(APP_CONFIG, indent=2)

@mcp.resource("info://server")
def get_server_info() -> str:
    """Server runtime information."""
    return json.dumps({
        "name": "Task Manager",
        "started_at": server_start_time.isoformat() if server_start_time else None,
        "task_count": len(tasks_db),
        "project_count": len(projects_db)
    }, indent=2)

# ===== TOOLS =====
# (All tool definitions here...)

if __name__ == "__main__":
    mcp.run()
```

---

## Complete Before and After

Here's the complete converted MCP server:

```python
# mcp_server.py - Complete MCP Implementation
from fastmcp import FastMCP
from mcp import McpError
from mcp.types import ErrorCode
from contextlib import asynccontextmanager
from datetime import datetime
from typing import Optional
import json

# ============== DATABASE ==============
tasks_db: dict[int, dict] = {}
projects_db: dict[int, dict] = {}
task_counter = 0
project_counter = 0

# ============== CONFIG ==============
APP_CONFIG = {
    "version": "1.0.0",
    "max_tasks_per_project": 100,
    "default_priority": "medium",
    "features": {
        "projects_enabled": True,
        "search_enabled": True,
        "export_enabled": False
    }
}

# ============== LIFESPAN ==============
@asynccontextmanager
async def lifespan(mcp):
    print("Task Manager MCP Server starting...")
    yield
    print("Task Manager MCP Server shutting down...")

# ============== CREATE SERVER ==============
mcp = FastMCP(
    "Task Manager",
    description="MCP server for managing tasks and projects",
    lifespan=lifespan
)

# ============== RESOURCES ==============

@mcp.resource("config://app")
def get_app_config() -> str:
    """Application configuration including version and feature flags."""
    return json.dumps(APP_CONFIG, indent=2)

# ============== PROJECT TOOLS ==============

@mcp.tool()
def create_project(name: str, description: str = "") -> dict:
    """Create a new project.
    
    Args:
        name: The name of the project
        description: Optional project description
    
    Returns:
        The created project with ID and timestamp
    """
    global project_counter
    project_counter += 1
    
    project = {
        "id": project_counter,
        "name": name,
        "description": description,
        "created_at": datetime.now().isoformat()
    }
    projects_db[project_counter] = project
    return project

@mcp.tool()
def list_projects() -> list:
    """List all projects.
    
    Returns:
        List of all projects
    """
    return list(projects_db.values())

@mcp.tool()
def get_project(project_id: int) -> dict:
    """Get a project by ID.
    
    Args:
        project_id: The ID of the project
    
    Returns:
        The project details
    """
    if project_id not in projects_db:
        raise McpError(ErrorCode.InvalidParams, f"Project {project_id} not found")
    return projects_db[project_id]

@mcp.tool()
def delete_project(project_id: int, force: bool = False) -> str:
    """Delete a project.
    
    Args:
        project_id: The ID of the project to delete
        force: If True, also delete all tasks in the project
    
    Returns:
        Confirmation message
    """
    if project_id not in projects_db:
        raise McpError(ErrorCode.InvalidParams, f"Project {project_id} not found")
    
    project_tasks = [tid for tid, t in tasks_db.items() 
                     if t.get("project_id") == project_id]
    
    if project_tasks and not force:
        raise McpError(
            ErrorCode.InvalidParams,
            f"Project has {len(project_tasks)} tasks. Use force=True to delete."
        )
    
    for tid in project_tasks:
        del tasks_db[tid]
    del projects_db[project_id]
    
    return f"Project {project_id} deleted" + (
        f" along with {len(project_tasks)} tasks" if project_tasks else ""
    )

# ============== TASK TOOLS ==============

@mcp.tool()
def create_task(
    title: str,
    description: str = "",
    priority: str = "medium",
    project_id: int = None
) -> dict:
    """Create a new task.
    
    Args:
        title: The title of the task
        description: Detailed description
        priority: Priority level (low, medium, high)
        project_id: Optional project ID
    
    Returns:
        The created task
    """
    global task_counter
    
    if priority not in ["low", "medium", "high"]:
        raise McpError(ErrorCode.InvalidParams, f"Invalid priority: {priority}")
    
    if project_id is not None and project_id not in projects_db:
        raise McpError(ErrorCode.InvalidParams, f"Project {project_id} not found")
    
    task_counter += 1
    now = datetime.now().isoformat()
    
    task = {
        "id": task_counter,
        "title": title,
        "description": description,
        "priority": priority,
        "status": "todo",
        "project_id": project_id,
        "created_at": now,
        "updated_at": now
    }
    tasks_db[task_counter] = task
    return task

@mcp.tool()
def list_tasks(
    status: str = None,
    priority: str = None,
    project_id: int = None,
    limit: int = 50,
    offset: int = 0
) -> list:
    """List tasks with optional filters.
    
    Args:
        status: Filter by status (todo, in_progress, done)
        priority: Filter by priority (low, medium, high)
        project_id: Filter by project
        limit: Max results (1-100)
        offset: Skip N results
    
    Returns:
        List of matching tasks
    """
    limit = max(1, min(100, limit))
    offset = max(0, offset)
    
    tasks = list(tasks_db.values())
    
    if status:
        tasks = [t for t in tasks if t["status"] == status]
    if priority:
        tasks = [t for t in tasks if t["priority"] == priority]
    if project_id is not None:
        tasks = [t for t in tasks if t.get("project_id") == project_id]
    
    return tasks[offset:offset + limit]

@mcp.tool()
def get_task(task_id: int) -> dict:
    """Get a task by ID.
    
    Args:
        task_id: The ID of the task
    
    Returns:
        The task details
    """
    if task_id not in tasks_db:
        raise McpError(ErrorCode.InvalidParams, f"Task {task_id} not found")
    return tasks_db[task_id]

@mcp.tool()
def update_task(
    task_id: int,
    title: str = None,
    description: str = None,
    priority: str = None,
    status: str = None
) -> dict:
    """Update an existing task.
    
    Args:
        task_id: The ID of the task to update
        title: New title (optional)
        description: New description (optional)
        priority: New priority (optional)
        status: New status (optional)
    
    Returns:
        The updated task
    """
    if task_id not in tasks_db:
        raise McpError(ErrorCode.InvalidParams, f"Task {task_id} not found")
    
    task = tasks_db[task_id]
    
    if title is not None:
        task["title"] = title
    if description is not None:
        task["description"] = description
    if priority is not None:
        if priority not in ["low", "medium", "high"]:
            raise McpError(ErrorCode.InvalidParams, f"Invalid priority: {priority}")
        task["priority"] = priority
    if status is not None:
        if status not in ["todo", "in_progress", "done"]:
            raise McpError(ErrorCode.InvalidParams, f"Invalid status: {status}")
        task["status"] = status
    
    task["updated_at"] = datetime.now().isoformat()
    return task

@mcp.tool()
def delete_task(task_id: int) -> str:
    """Delete a task.
    
    Args:
        task_id: The ID of the task to delete
    
    Returns:
        Confirmation message
    """
    if task_id not in tasks_db:
        raise McpError(ErrorCode.InvalidParams, f"Task {task_id} not found")
    
    del tasks_db[task_id]
    return f"Task {task_id} deleted"

# ============== SEARCH TOOLS ==============

@mcp.tool()
def search_tasks(query: str, include_completed: bool = True) -> list:
    """Search tasks by title or description.
    
    Args:
        query: Search query string
        include_completed: Include completed tasks in results
    
    Returns:
        List of matching tasks
    """
    if not query:
        raise McpError(ErrorCode.InvalidParams, "Search query cannot be empty")
    
    query_lower = query.lower()
    results = []
    
    for task in tasks_db.values():
        if query_lower in task["title"].lower() or query_lower in task["description"].lower():
            if include_completed or task["status"] != "done":
                results.append(task)
    
    return results

@mcp.tool()
def get_statistics() -> dict:
    """Get task and project statistics.
    
    Returns:
        Statistics including counts by status and priority
    """
    by_status = {}
    by_priority = {}
    
    for task in tasks_db.values():
        status = task["status"]
        priority = task["priority"]
        by_status[status] = by_status.get(status, 0) + 1
        by_priority[priority] = by_priority.get(priority, 0) + 1
    
    return {
        "total_tasks": len(tasks_db),
        "total_projects": len(projects_db),
        "by_status": by_status,
        "by_priority": by_priority
    }

if __name__ == "__main__":
    mcp.run()
```

---

## Summary

```
+-----------------------------------------------------------------------+
|                         KEY TAKEAWAYS                                  |
+-----------------------------------------------------------------------+
|                                                                        |
|  STEP 1: ANALYZE                                                       |
|  - Identify which endpoints become tools vs resources                  |
|  - Map dependencies and shared state                                   |
|                                                                        |
|  STEP 2: SETUP                                                         |
|  - Create FastMCP server instance                                      |
|  - Organize code into logical modules                                  |
|                                                                        |
|  STEP 3: CONVERT ENDPOINTS                                             |
|  - @app.post/put/delete -> @mcp.tool()                                |
|  - Flatten request body into parameters                                |
|  - Keep docstrings for AI understanding                                |
|                                                                        |
|  STEP 4: CONVERT DATA                                                  |
|  - Static GET endpoints -> @mcp.resource()                            |
|  - Return JSON-serialized strings                                      |
|                                                                        |
|  STEP 5: HANDLE STATE                                                  |
|  - FastAPI Depends() -> Module-level state + lifespan                 |
|  - Use Context for request-scoped operations                          |
|                                                                        |
|  STEP 6: TRANSLATE ERRORS                                              |
|  - HTTPException -> McpError                                           |
|  - Map HTTP codes to MCP ErrorCodes                                    |
|                                                                        |
|  STEP 7: ADD LIFESPAN                                                  |
|  - Setup/teardown in lifespan context manager                         |
|  - Initialize connections, load data on startup                        |
|                                                                        |
+-----------------------------------------------------------------------+
```

---

## Next Steps

- [Hybrid Approach](./_04_hybrid_approach.md) - Run FastAPI and MCP together
- [Practical Notebook](./_05_fastapi_to_mcp_practical.ipynb) - Hands-on conversion exercise
- [Advanced Conversion](./_06_advanced_conversion.ipynb) - Complex patterns with database

---

*Following these steps systematically ensures a clean, maintainable conversion.*
