# Hybrid Approach: FastAPI and MCP Side by Side

## Table of Contents
1. [Introduction](#introduction)
2. [Why Hybrid?](#why-hybrid)
3. [Architecture Options](#architecture-options)
4. [Option 1: Separate Services](#option-1-separate-services)
5. [Option 2: Mounting MCP on FastAPI](#option-2-mounting-mcp-on-fastapi)
6. [Option 3: Shared Business Logic](#option-3-shared-business-logic)
7. [When Hybrid Makes Sense](#when-hybrid-makes-sense)
8. [Best Practices](#best-practices)
9. [Summary](#summary)

---

## Introduction

A hybrid approach runs both FastAPI (REST API) and MCP (AI protocol) simultaneously, serving different types of clients from the same codebase. This allows gradual migration and supports diverse client needs.

```
+-----------------------------------------------------------------------+
|                    HYBRID ARCHITECTURE OVERVIEW                        |
+-----------------------------------------------------------------------+
|                                                                        |
|                         SHARED BUSINESS LOGIC                          |
|                        +-------------------+                           |
|                        |  Core Functions   |                           |
|                        |  Data Access      |                           |
|                        |  Validation       |                           |
|                        +--------+----------+                           |
|                                 |                                      |
|              +------------------+------------------+                   |
|              |                                     |                   |
|              v                                     v                   |
|     +----------------+                    +----------------+           |
|     |    FastAPI     |                    |   MCP Server   |           |
|     |  REST Endpoint |                    |     Tools      |           |
|     +-------+--------+                    +-------+--------+           |
|             |                                     |                    |
|             v                                     v                    |
|     +----------------+                    +----------------+           |
|     | Browser/Mobile |                    |   AI Agents    |           |
|     | HTTP Clients   |                    |  Claude/LLM    |           |
|     +----------------+                    +----------------+           |
|                                                                        |
+-----------------------------------------------------------------------+
```

---

## Why Hybrid?

### The Challenge

```
+-----------------------------------------------------------------------+
|                    THE HYBRID DILEMMA                                  |
+-----------------------------------------------------------------------+
|                                                                        |
|   You have an existing FastAPI service...                             |
|                                                                        |
|   +-------------+     HTTP      +-------------+     +-------------+   |
|   |   Browser   | ------------> |             | --> |  Database   |   |
|   +-------------+               |   FastAPI   |     +-------------+   |
|   +-------------+               |   Server    |     +-------------+   |
|   |   Mobile    | ------------> |             | --> |  External   |   |
|   +-------------+               +-------------+     |    APIs     |   |
|                                                     +-------------+   |
|                                                                        |
|   ...and now you want AI integration too!                             |
|                                                                        |
|   +-------------+       ???     +-------------+                       |
|   |  AI Agent   | ------------> |      ?      |                       |
|   +-------------+               +-------------+                       |
|                                                                        |
|   OPTIONS:                                                             |
|   1. Add custom AI adapter (complex, non-standard)                    |
|   2. Convert entirely to MCP (breaks existing clients)                |
|   3. Run BOTH FastAPI + MCP (hybrid approach)                         |
|                                                                        |
+-----------------------------------------------------------------------+
```

### Benefits of Hybrid

| Benefit | Description |
|---------|-------------|
| **Gradual Migration** | Convert endpoints incrementally without breaking changes |
| **Client Diversity** | Serve both traditional and AI clients |
| **Shared Logic** | One codebase for business rules |
| **Risk Mitigation** | Keep existing API while adding MCP |
| **Feature Parity** | Same functionality available via both protocols |

---

## Architecture Options

### Overview of Options

```
+-----------------------------------------------------------------------+
|                    THREE HYBRID ARCHITECTURES                          |
+-----------------------------------------------------------------------+
|                                                                        |
|   OPTION 1: SEPARATE SERVICES                                          |
|   +-----------+     +-----------+                                      |
|   |  FastAPI  |     |    MCP    |     Two separate processes          |
|   |  :8000    |     |  :stdio   |     Shared database/state           |
|   +-----------+     +-----------+                                      |
|                                                                        |
|   OPTION 2: MOUNTED MCP                                                |
|   +-------------------------+                                          |
|   |       FastAPI           |         MCP mounted as route             |
|   |  /api/* -> REST         |         Single process                   |
|   |  /mcp/* -> MCP (SSE)    |         Shared memory state              |
|   +-------------------------+                                          |
|                                                                        |
|   OPTION 3: SHARED LOGIC LIBRARY                                       |
|   +-------------------------+                                          |
|   |    Business Logic Lib   |         Core logic in shared module      |
|   +-------------------------+         Both import and use it           |
|   |  FastAPI  |     | MCP   |                                          |
|   +-----------+     +-------+                                          |
|                                                                        |
+-----------------------------------------------------------------------+
```

---

## Option 1: Separate Services

### Architecture

Two completely separate services sharing a database or external state:

```
+-----------------------------------------------------------------------+
|                    OPTION 1: SEPARATE SERVICES                         |
+-----------------------------------------------------------------------+
|                                                                        |
|   Process 1                              Process 2                     |
|   +-------------------+                  +-------------------+         |
|   |     FastAPI       |                  |    MCP Server     |         |
|   |                   |                  |                   |         |
|   | @app.get("/users")|                  | @mcp.tool()       |         |
|   | @app.post("/task")|                  | def list_users()  |         |
|   |                   |                  | def create_task() |         |
|   +--------+----------+                  +--------+----------+         |
|            |                                      |                    |
|            |          +------------------+        |                    |
|            +--------->|     Database     |<-------+                    |
|                       |   (PostgreSQL)   |                             |
|                       +------------------+                             |
|                                                                        |
|   PROS:                              CONS:                             |
|   - Complete isolation               - Two deployments                 |
|   - Independent scaling              - Code duplication risk           |
|   - Easy to understand               - State sync challenges           |
|                                                                        |
+-----------------------------------------------------------------------+
```

### Implementation

**FastAPI Service (fastapi_service.py):**
```python
from fastapi import FastAPI, HTTPException
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

app = FastAPI(title="Task Manager API")

# Shared database connection
DATABASE_URL = "postgresql://user:pass@localhost/tasks"
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(bind=engine)

@app.post("/tasks")
async def create_task(title: str, description: str = ""):
    """Create a task via REST API."""
    db = SessionLocal()
    try:
        task = Task(title=title, description=description)
        db.add(task)
        db.commit()
        db.refresh(task)
        return {"id": task.id, "title": task.title}
    finally:
        db.close()

@app.get("/tasks")
async def list_tasks():
    """List all tasks via REST API."""
    db = SessionLocal()
    try:
        tasks = db.query(Task).all()
        return [{"id": t.id, "title": t.title} for t in tasks]
    finally:
        db.close()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
```

**MCP Service (mcp_service.py):**
```python
from fastmcp import FastMCP
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

mcp = FastMCP("Task Manager")

# Same database connection
DATABASE_URL = "postgresql://user:pass@localhost/tasks"
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(bind=engine)

@mcp.tool()
def create_task(title: str, description: str = "") -> dict:
    """Create a task via MCP.
    
    Args:
        title: Task title
        description: Task description
    
    Returns:
        The created task
    """
    db = SessionLocal()
    try:
        task = Task(title=title, description=description)
        db.add(task)
        db.commit()
        db.refresh(task)
        return {"id": task.id, "title": task.title}
    finally:
        db.close()

@mcp.tool()
def list_tasks() -> list:
    """List all tasks via MCP.
    
    Returns:
        List of all tasks
    """
    db = SessionLocal()
    try:
        tasks = db.query(Task).all()
        return [{"id": t.id, "title": t.title} for t in tasks]
    finally:
        db.close()

if __name__ == "__main__":
    mcp.run()
```

**Running Both:**
```bash
# Terminal 1: FastAPI
python fastapi_service.py

# Terminal 2: MCP (stdio)
python mcp_service.py
```

---

## Option 2: Mounting MCP on FastAPI

### Architecture

MCP server mounted as an SSE endpoint within FastAPI:

```
+-----------------------------------------------------------------------+
|                    OPTION 2: MOUNTED MCP                               |
+-----------------------------------------------------------------------+
|                                                                        |
|   Single Process                                                       |
|   +---------------------------------------------------------------+   |
|   |                        FastAPI Application                     |   |
|   |                                                                |   |
|   |  +------------------+    +------------------+                  |   |
|   |  |  REST Endpoints  |    |   MCP Endpoint   |                  |   |
|   |  |                  |    |                  |                  |   |
|   |  |  /api/tasks      |    |  /mcp (SSE)      |                  |   |
|   |  |  /api/users      |    |  /mcp/sse        |                  |   |
|   |  |  /api/projects   |    |                  |                  |   |
|   |  +--------+---------+    +--------+---------+                  |   |
|   |           |                       |                            |   |
|   |           +----------+------------+                            |   |
|   |                      |                                         |   |
|   |           +----------v----------+                              |   |
|   |           |   Shared State      |                              |   |
|   |           |   (in-memory or DB) |                              |   |
|   |           +---------------------+                              |   |
|   +---------------------------------------------------------------+   |
|                                                                        |
|   PROS:                              CONS:                             |
|   - Single deployment                - More complex setup              |
|   - Shared memory state              - Requires SSE transport          |
|   - One port                         - Coupled lifecycle               |
|                                                                        |
+-----------------------------------------------------------------------+
```

### Implementation

**Combined Application (hybrid_app.py):**
```python
from fastapi import FastAPI, HTTPException
from fastmcp import FastMCP
from fastmcp.server.sse import SseServerTransport
from starlette.routing import Mount
from datetime import datetime
import json

# ============== SHARED STATE ==============
tasks_db: dict[int, dict] = {}
task_counter = 0

# ============== FASTAPI APP ==============
app = FastAPI(
    title="Hybrid Task Manager",
    description="REST API with MCP support"
)

# ============== MCP SERVER ==============
mcp = FastMCP("Task Manager MCP")

# ============== SHARED BUSINESS LOGIC ==============

def _create_task(title: str, description: str = "") -> dict:
    """Core business logic for creating a task."""
    global task_counter
    task_counter += 1
    
    task = {
        "id": task_counter,
        "title": title,
        "description": description,
        "status": "todo",
        "created_at": datetime.now().isoformat()
    }
    tasks_db[task_counter] = task
    return task

def _get_task(task_id: int) -> dict:
    """Core business logic for getting a task."""
    if task_id not in tasks_db:
        return None
    return tasks_db[task_id]

def _list_tasks() -> list:
    """Core business logic for listing tasks."""
    return list(tasks_db.values())

def _delete_task(task_id: int) -> bool:
    """Core business logic for deleting a task."""
    if task_id not in tasks_db:
        return False
    del tasks_db[task_id]
    return True

# ============== FASTAPI ENDPOINTS ==============

@app.post("/api/tasks")
async def create_task_rest(title: str, description: str = ""):
    """Create a task via REST API."""
    return _create_task(title, description)

@app.get("/api/tasks")
async def list_tasks_rest():
    """List tasks via REST API."""
    return _list_tasks()

@app.get("/api/tasks/{task_id}")
async def get_task_rest(task_id: int):
    """Get a task via REST API."""
    task = _get_task(task_id)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    return task

@app.delete("/api/tasks/{task_id}")
async def delete_task_rest(task_id: int):
    """Delete a task via REST API."""
    if not _delete_task(task_id):
        raise HTTPException(status_code=404, detail="Task not found")
    return {"message": "Task deleted"}

# ============== MCP TOOLS ==============

@mcp.tool()
def create_task(title: str, description: str = "") -> dict:
    """Create a new task.
    
    Args:
        title: The task title
        description: Optional task description
    
    Returns:
        The created task
    """
    return _create_task(title, description)

@mcp.tool()
def list_tasks() -> list:
    """List all tasks.
    
    Returns:
        List of all tasks
    """
    return _list_tasks()

@mcp.tool()
def get_task(task_id: int) -> dict:
    """Get a task by ID.
    
    Args:
        task_id: The ID of the task
    
    Returns:
        The task details
    """
    from mcp import McpError
    from mcp.types import ErrorCode
    
    task = _get_task(task_id)
    if not task:
        raise McpError(ErrorCode.InvalidParams, f"Task {task_id} not found")
    return task

@mcp.tool()
def delete_task(task_id: int) -> str:
    """Delete a task.
    
    Args:
        task_id: The ID of the task to delete
    
    Returns:
        Confirmation message
    """
    from mcp import McpError
    from mcp.types import ErrorCode
    
    if not _delete_task(task_id):
        raise McpError(ErrorCode.InvalidParams, f"Task {task_id} not found")
    return f"Task {task_id} deleted"

# ============== MOUNT MCP ON FASTAPI ==============

# Create SSE transport for MCP
sse_transport = SseServerTransport("/mcp/messages")

# Mount SSE endpoint
app.mount("/mcp", sse_transport.get_app())

# Startup event to connect MCP to transport
@app.on_event("startup")
async def startup():
    """Connect MCP server to SSE transport on startup."""
    await sse_transport.connect(mcp._server)

@app.on_event("shutdown")
async def shutdown():
    """Cleanup on shutdown."""
    pass

# ============== HEALTH CHECK ==============

@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "rest_api": "available",
        "mcp": "available",
        "tasks_count": len(tasks_db)
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
```

**Usage:**
```bash
# Run the hybrid server
python hybrid_app.py

# REST API available at:
# - POST http://localhost:8000/api/tasks
# - GET  http://localhost:8000/api/tasks
# - GET  http://localhost:8000/api/tasks/{id}
# - DELETE http://localhost:8000/api/tasks/{id}

# MCP available at:
# - SSE endpoint: http://localhost:8000/mcp/sse
# - Messages endpoint: http://localhost:8000/mcp/messages
```

---

## Option 3: Shared Business Logic

### Architecture

Core business logic in a separate module, imported by both FastAPI and MCP:

```
+-----------------------------------------------------------------------+
|                    OPTION 3: SHARED LOGIC LIBRARY                      |
+-----------------------------------------------------------------------+
|                                                                        |
|                    +---------------------------+                       |
|                    |    business_logic.py      |                       |
|                    |                           |                       |
|                    |  class TaskService:       |                       |
|                    |    def create_task()      |                       |
|                    |    def get_task()         |                       |
|                    |    def list_tasks()       |                       |
|                    |    def delete_task()      |                       |
|                    |                           |                       |
|                    +-------------+-------------+                       |
|                                  |                                     |
|                    +-------------+-------------+                       |
|                    |                           |                       |
|         +----------v----------+    +----------v----------+            |
|         |   fastapi_app.py    |    |    mcp_server.py    |            |
|         |                     |    |                     |            |
|         | from business_logic |    | from business_logic |            |
|         | import TaskService  |    | import TaskService  |            |
|         |                     |    |                     |            |
|         | @app.post("/tasks") |    | @mcp.tool()         |            |
|         | def create():       |    | def create_task():  |            |
|         |   svc.create_task() |    |   svc.create_task() |            |
|         +---------------------+    +---------------------+            |
|                                                                        |
|   PROS:                              CONS:                             |
|   - Clean separation                 - Requires careful design         |
|   - Testable business logic          - State sharing complexity        |
|   - DRY principle                    - Dependency management           |
|                                                                        |
+-----------------------------------------------------------------------+
```

### Implementation

**Project Structure:**
```
task_manager/
    __init__.py
    business_logic/
        __init__.py
        models.py
        services.py
        database.py
    fastapi_app/
        __init__.py
        main.py
        routes.py
    mcp_server/
        __init__.py
        server.py
        tools.py
```

**Business Logic Layer (business_logic/services.py):**
```python
# task_manager/business_logic/services.py
from datetime import datetime
from typing import Optional, List
from dataclasses import dataclass

@dataclass
class Task:
    id: int
    title: str
    description: str
    status: str
    created_at: str
    updated_at: str

class TaskNotFoundError(Exception):
    """Raised when a task is not found."""
    pass

class ValidationError(Exception):
    """Raised when validation fails."""
    pass

class TaskService:
    """Core business logic for task management."""
    
    def __init__(self):
        self._tasks: dict[int, dict] = {}
        self._counter = 0
    
    def create_task(
        self, 
        title: str, 
        description: str = "",
        priority: str = "medium"
    ) -> dict:
        """Create a new task.
        
        Args:
            title: Task title (required)
            description: Task description
            priority: Task priority (low, medium, high)
        
        Returns:
            Created task dictionary
        
        Raises:
            ValidationError: If title is empty or priority is invalid
        """
        # Validation
        if not title or not title.strip():
            raise ValidationError("Title cannot be empty")
        
        if priority not in ["low", "medium", "high"]:
            raise ValidationError(f"Invalid priority: {priority}")
        
        self._counter += 1
        now = datetime.now().isoformat()
        
        task = {
            "id": self._counter,
            "title": title.strip(),
            "description": description,
            "priority": priority,
            "status": "todo",
            "created_at": now,
            "updated_at": now
        }
        self._tasks[self._counter] = task
        return task
    
    def get_task(self, task_id: int) -> dict:
        """Get a task by ID.
        
        Args:
            task_id: The task ID
        
        Returns:
            Task dictionary
        
        Raises:
            TaskNotFoundError: If task doesn't exist
        """
        if task_id not in self._tasks:
            raise TaskNotFoundError(f"Task {task_id} not found")
        return self._tasks[task_id]
    
    def list_tasks(
        self,
        status: Optional[str] = None,
        priority: Optional[str] = None,
        limit: int = 50,
        offset: int = 0
    ) -> List[dict]:
        """List tasks with optional filters.
        
        Args:
            status: Filter by status
            priority: Filter by priority
            limit: Maximum results
            offset: Skip N results
        
        Returns:
            List of task dictionaries
        """
        tasks = list(self._tasks.values())
        
        if status:
            tasks = [t for t in tasks if t["status"] == status]
        if priority:
            tasks = [t for t in tasks if t["priority"] == priority]
        
        return tasks[offset:offset + limit]
    
    def update_task(
        self,
        task_id: int,
        title: Optional[str] = None,
        description: Optional[str] = None,
        status: Optional[str] = None,
        priority: Optional[str] = None
    ) -> dict:
        """Update a task.
        
        Args:
            task_id: The task ID
            title: New title (optional)
            description: New description (optional)
            status: New status (optional)
            priority: New priority (optional)
        
        Returns:
            Updated task dictionary
        
        Raises:
            TaskNotFoundError: If task doesn't exist
            ValidationError: If values are invalid
        """
        task = self.get_task(task_id)  # Raises if not found
        
        if title is not None:
            if not title.strip():
                raise ValidationError("Title cannot be empty")
            task["title"] = title.strip()
        
        if description is not None:
            task["description"] = description
        
        if status is not None:
            if status not in ["todo", "in_progress", "done"]:
                raise ValidationError(f"Invalid status: {status}")
            task["status"] = status
        
        if priority is not None:
            if priority not in ["low", "medium", "high"]:
                raise ValidationError(f"Invalid priority: {priority}")
            task["priority"] = priority
        
        task["updated_at"] = datetime.now().isoformat()
        return task
    
    def delete_task(self, task_id: int) -> bool:
        """Delete a task.
        
        Args:
            task_id: The task ID
        
        Returns:
            True if deleted
        
        Raises:
            TaskNotFoundError: If task doesn't exist
        """
        if task_id not in self._tasks:
            raise TaskNotFoundError(f"Task {task_id} not found")
        del self._tasks[task_id]
        return True
    
    def get_statistics(self) -> dict:
        """Get task statistics.
        
        Returns:
            Statistics dictionary
        """
        by_status = {}
        by_priority = {}
        
        for task in self._tasks.values():
            by_status[task["status"]] = by_status.get(task["status"], 0) + 1
            by_priority[task["priority"]] = by_priority.get(task["priority"], 0) + 1
        
        return {
            "total": len(self._tasks),
            "by_status": by_status,
            "by_priority": by_priority
        }

# Singleton instance for sharing state
_service_instance = None

def get_task_service() -> TaskService:
    """Get the shared TaskService instance."""
    global _service_instance
    if _service_instance is None:
        _service_instance = TaskService()
    return _service_instance
```

**FastAPI App (fastapi_app/main.py):**
```python
# task_manager/fastapi_app/main.py
from fastapi import FastAPI, HTTPException, Query
from typing import Optional

from ..business_logic.services import (
    get_task_service,
    TaskNotFoundError,
    ValidationError
)

app = FastAPI(title="Task Manager REST API")
service = get_task_service()

@app.post("/tasks")
async def create_task(
    title: str,
    description: str = "",
    priority: str = "medium"
):
    """Create a task via REST."""
    try:
        return service.create_task(title, description, priority)
    except ValidationError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/tasks")
async def list_tasks(
    status: Optional[str] = Query(None),
    priority: Optional[str] = Query(None),
    limit: int = Query(50, ge=1, le=100),
    offset: int = Query(0, ge=0)
):
    """List tasks via REST."""
    return service.list_tasks(status, priority, limit, offset)

@app.get("/tasks/{task_id}")
async def get_task(task_id: int):
    """Get a task via REST."""
    try:
        return service.get_task(task_id)
    except TaskNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))

@app.put("/tasks/{task_id}")
async def update_task(
    task_id: int,
    title: Optional[str] = None,
    description: Optional[str] = None,
    status: Optional[str] = None,
    priority: Optional[str] = None
):
    """Update a task via REST."""
    try:
        return service.update_task(task_id, title, description, status, priority)
    except TaskNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.delete("/tasks/{task_id}")
async def delete_task(task_id: int):
    """Delete a task via REST."""
    try:
        service.delete_task(task_id)
        return {"message": f"Task {task_id} deleted"}
    except TaskNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))

@app.get("/stats")
async def get_statistics():
    """Get task statistics via REST."""
    return service.get_statistics()
```

**MCP Server (mcp_server/server.py):**
```python
# task_manager/mcp_server/server.py
from fastmcp import FastMCP
from mcp import McpError
from mcp.types import ErrorCode
from typing import Optional

from ..business_logic.services import (
    get_task_service,
    TaskNotFoundError,
    ValidationError
)

mcp = FastMCP("Task Manager MCP")
service = get_task_service()

@mcp.tool()
def create_task(
    title: str,
    description: str = "",
    priority: str = "medium"
) -> dict:
    """Create a new task.
    
    Args:
        title: The task title (required)
        description: Task description
        priority: Priority level (low, medium, high)
    
    Returns:
        The created task
    """
    try:
        return service.create_task(title, description, priority)
    except ValidationError as e:
        raise McpError(ErrorCode.InvalidParams, str(e))

@mcp.tool()
def list_tasks(
    status: Optional[str] = None,
    priority: Optional[str] = None,
    limit: int = 50,
    offset: int = 0
) -> list:
    """List tasks with optional filters.
    
    Args:
        status: Filter by status (todo, in_progress, done)
        priority: Filter by priority (low, medium, high)
        limit: Maximum results (1-100)
        offset: Skip N results
    
    Returns:
        List of matching tasks
    """
    return service.list_tasks(status, priority, limit, offset)

@mcp.tool()
def get_task(task_id: int) -> dict:
    """Get a task by ID.
    
    Args:
        task_id: The task ID
    
    Returns:
        The task details
    """
    try:
        return service.get_task(task_id)
    except TaskNotFoundError as e:
        raise McpError(ErrorCode.InvalidParams, str(e))

@mcp.tool()
def update_task(
    task_id: int,
    title: Optional[str] = None,
    description: Optional[str] = None,
    status: Optional[str] = None,
    priority: Optional[str] = None
) -> dict:
    """Update an existing task.
    
    Args:
        task_id: The task ID
        title: New title (optional)
        description: New description (optional)
        status: New status (optional)
        priority: New priority (optional)
    
    Returns:
        The updated task
    """
    try:
        return service.update_task(task_id, title, description, status, priority)
    except TaskNotFoundError as e:
        raise McpError(ErrorCode.InvalidParams, str(e))
    except ValidationError as e:
        raise McpError(ErrorCode.InvalidParams, str(e))

@mcp.tool()
def delete_task(task_id: int) -> str:
    """Delete a task.
    
    Args:
        task_id: The task ID
    
    Returns:
        Confirmation message
    """
    try:
        service.delete_task(task_id)
        return f"Task {task_id} deleted successfully"
    except TaskNotFoundError as e:
        raise McpError(ErrorCode.InvalidParams, str(e))

@mcp.tool()
def get_statistics() -> dict:
    """Get task statistics.
    
    Returns:
        Statistics including counts by status and priority
    """
    return service.get_statistics()

if __name__ == "__main__":
    mcp.run()
```

---

## When Hybrid Makes Sense

### Decision Matrix

```
+-----------------------------------------------------------------------+
|                    WHEN TO USE HYBRID                                  |
+-----------------------------------------------------------------------+
|                                                                        |
|   SCENARIO                                    RECOMMENDATION           |
|   ========================================================            |
|                                                                        |
|   Existing REST API + want AI features       Hybrid (Option 2 or 3)   |
|                                                                        |
|   New project, only AI clients               Pure MCP                  |
|                                                                        |
|   New project, only human clients            Pure FastAPI              |
|                                                                        |
|   Enterprise app, both client types          Hybrid (Option 3)         |
|                                                                        |
|   Microservices, some need AI                Hybrid (Option 1)         |
|                                                                        |
|   Gradual migration from REST to MCP         Hybrid (any option)       |
|                                                                        |
|   Complex state management needs             Hybrid (Option 2 or 3)    |
|                                                                        |
+-----------------------------------------------------------------------+
```

### Use Case Examples

| Use Case | Best Option | Rationale |
|----------|-------------|-----------|
| Add AI to existing production API | Option 3 | Minimal risk, shared logic |
| Small team, quick deployment | Option 2 | Single deployment, simple |
| Large enterprise, multiple teams | Option 1 | Independent scaling |
| Need real-time state sync | Option 2 | Shared memory |
| Different deployment targets | Option 1 | Flexibility |

---

## Best Practices

### Shared State Management

```
+-----------------------------------------------------------------------+
|                    STATE MANAGEMENT BEST PRACTICES                     |
+-----------------------------------------------------------------------+
|                                                                        |
|   DO:                                                                  |
|   - Use a database for persistent state                               |
|   - Use singleton services for in-memory state                        |
|   - Keep business logic stateless when possible                       |
|   - Use transactions for consistency                                   |
|                                                                        |
|   DON'T:                                                               |
|   - Duplicate state in FastAPI and MCP                                |
|   - Use global variables without proper management                    |
|   - Forget about concurrency issues                                   |
|   - Mix transport concerns with business logic                        |
|                                                                        |
+-----------------------------------------------------------------------+
```

### Error Handling

```python
# BEST PRACTICE: Unified error translation

def handle_service_error(func):
    """Decorator for FastAPI endpoints."""
    @functools.wraps(func)
    async def wrapper(*args, **kwargs):
        try:
            return await func(*args, **kwargs)
        except TaskNotFoundError as e:
            raise HTTPException(status_code=404, detail=str(e))
        except ValidationError as e:
            raise HTTPException(status_code=400, detail=str(e))
    return wrapper

def handle_mcp_error(func):
    """Decorator for MCP tools."""
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except TaskNotFoundError as e:
            raise McpError(ErrorCode.InvalidParams, str(e))
        except ValidationError as e:
            raise McpError(ErrorCode.InvalidParams, str(e))
    return wrapper
```

### Testing Strategy

```
+-----------------------------------------------------------------------+
|                    TESTING HYBRID APPLICATIONS                         |
+-----------------------------------------------------------------------+
|                                                                        |
|   LAYER                  TEST TYPE              TOOLS                  |
|   ==============================================================      |
|                                                                        |
|   Business Logic         Unit Tests            pytest                  |
|                                                                        |
|   FastAPI Endpoints      Integration Tests     TestClient              |
|                                                                        |
|   MCP Tools              Integration Tests     MCP Client SDK          |
|                                                                        |
|   Full System            E2E Tests             Both clients            |
|                                                                        |
|   EXAMPLE:                                                             |
|                                                                        |
|   # Test business logic independently                                  |
|   def test_create_task():                                             |
|       service = TaskService()                                          |
|       task = service.create_task("Test")                              |
|       assert task["title"] == "Test"                                  |
|                                                                        |
|   # Test that both interfaces return the same result                  |
|   def test_parity():                                                   |
|       rest_result = client.post("/tasks", json={"title": "Test"})    |
|       mcp_result = mcp_client.call_tool("create_task", title="Test") |
|       assert rest_result["title"] == mcp_result["title"]             |
|                                                                        |
+-----------------------------------------------------------------------+
```

---

## Summary

```
+-----------------------------------------------------------------------+
|                         KEY TAKEAWAYS                                  |
+-----------------------------------------------------------------------+
|                                                                        |
|  OPTION 1: SEPARATE SERVICES                                           |
|  - Two independent processes                                           |
|  - Share database for state                                            |
|  - Best for: microservices, independent scaling                        |
|                                                                        |
|  OPTION 2: MOUNTED MCP                                                 |
|  - Single process, MCP mounted on FastAPI                             |
|  - Share memory state directly                                         |
|  - Best for: small teams, simple deployments                          |
|                                                                        |
|  OPTION 3: SHARED LOGIC                                                |
|  - Core logic in separate module                                       |
|  - Both interfaces import and use it                                  |
|  - Best for: enterprise, testability, maintainability                 |
|                                                                        |
|  BEST PRACTICES:                                                       |
|  - Keep business logic separate from transport                        |
|  - Use consistent error handling patterns                             |
|  - Test at all layers (unit, integration, E2E)                        |
|  - Design for stateless operations when possible                      |
|                                                                        |
+-----------------------------------------------------------------------+
```

---

## Next Steps

- [Practical Notebook](./_05_fastapi_to_mcp_practical.ipynb) - Hands-on hybrid implementation
- [Advanced Conversion](./_06_advanced_conversion.ipynb) - Complex patterns with databases

---

*Choose the hybrid approach that fits your architecture and team needs.*
