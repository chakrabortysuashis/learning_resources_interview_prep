# FastAPI to MCP Conversion Patterns

## Table of Contents
1. [Introduction](#introduction)
2. [Pattern 1: Endpoints to Tools](#pattern-1-endpoints-to-tools)
3. [Pattern 2: Data Endpoints to Resources](#pattern-2-data-endpoints-to-resources)
4. [Pattern 3: Query Parameters to Tool Arguments](#pattern-3-query-parameters-to-tool-arguments)
5. [Pattern 4: Response Models to Return Types](#pattern-4-response-models-to-return-types)
6. [Pattern 5: Handling Authentication](#pattern-5-handling-authentication)
7. [Pattern 6: Error Handling](#pattern-6-error-handling)
8. [Summary](#summary)

---

## Introduction

This document covers the essential patterns for converting FastAPI applications to MCP servers. Each pattern addresses a specific aspect of the conversion process with clear before/after examples.

```
+-----------------------------------------------------------------------+
|                    CONVERSION PATTERNS OVERVIEW                        |
+-----------------------------------------------------------------------+
|                                                                        |
|   Pattern 1: Endpoints -> Tools                                        |
|   +-------------------+          +-------------------+                 |
|   | @app.post("/...")  | ------> | @mcp.tool()       |                 |
|   +-------------------+          +-------------------+                 |
|                                                                        |
|   Pattern 2: Data Endpoints -> Resources                               |
|   +-------------------+          +-------------------+                 |
|   | @app.get("/data")  | ------> | @mcp.resource()   |                 |
|   +-------------------+          +-------------------+                 |
|                                                                        |
|   Pattern 3: Query Params -> Tool Arguments                           |
|   +-------------------+          +-------------------+                 |
|   | Query(default=...) | ------> | param: type = ... |                 |
|   +-------------------+          +-------------------+                 |
|                                                                        |
|   Pattern 4: Response Models -> Return Types                          |
|   +-------------------+          +-------------------+                 |
|   | -> ResponseModel   | ------> | -> dict/str       |                 |
|   +-------------------+          +-------------------+                 |
|                                                                        |
|   Pattern 5: Auth -> Context/Middleware                               |
|   +-------------------+          +-------------------+                 |
|   | Depends(auth)      | ------> | Context + Lifespan|                 |
|   +-------------------+          +-------------------+                 |
|                                                                        |
|   Pattern 6: Errors -> McpError                                       |
|   +-------------------+          +-------------------+                 |
|   | HTTPException      | ------> | McpError          |                 |
|   +-------------------+          +-------------------+                 |
|                                                                        |
+-----------------------------------------------------------------------+
```

---

## Pattern 1: Endpoints to Tools

### Overview

MCP tools are the equivalent of FastAPI action endpoints (POST, PUT, DELETE, and dynamic GET). Tools represent actions that an AI can invoke.

```
+-----------------------------------------------------------------------+
|                    PATTERN 1: ENDPOINTS TO TOOLS                       |
+-----------------------------------------------------------------------+
|                                                                        |
|   FASTAPI                              MCP                             |
|   +---------------------------+        +---------------------------+   |
|   | HTTP Endpoint             |        | MCP Tool                  |   |
|   |                           |        |                           |   |
|   | - POST, PUT, DELETE, GET  |  --->  | - @mcp.tool() decorator   |   |
|   | - URL path routing        |        | - Function name           |   |
|   | - Request body            |        | - Function parameters     |   |
|   | - Response JSON           |        | - Return value            |   |
|   +---------------------------+        +---------------------------+   |
|                                                                        |
+-----------------------------------------------------------------------+
```

### Example 1: Simple POST Endpoint

**FastAPI (Before):**
```python
from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

class TaskCreate(BaseModel):
    title: str
    description: str = ""

class Task(BaseModel):
    id: int
    title: str
    description: str
    completed: bool = False

tasks_db = []

@app.post("/tasks", response_model=Task)
async def create_task(task: TaskCreate) -> Task:
    """Create a new task in the task list."""
    new_task = Task(
        id=len(tasks_db) + 1,
        title=task.title,
        description=task.description
    )
    tasks_db.append(new_task)
    return new_task
```

**MCP (After):**
```python
from fastmcp import FastMCP

mcp = FastMCP("Task Manager")

tasks_db = []

@mcp.tool()
def create_task(title: str, description: str = "") -> dict:
    """Create a new task in the task list.
    
    Args:
        title: The title of the task
        description: Optional description of the task
    
    Returns:
        The created task with its assigned ID
    """
    task = {
        "id": len(tasks_db) + 1,
        "title": title,
        "description": description,
        "completed": False
    }
    tasks_db.append(task)
    return task
```

### Example 2: PUT Endpoint with Path Parameter

**FastAPI (Before):**
```python
@app.put("/tasks/{task_id}", response_model=Task)
async def update_task(task_id: int, task: TaskCreate) -> Task:
    """Update an existing task."""
    for i, t in enumerate(tasks_db):
        if t.id == task_id:
            updated = Task(
                id=task_id,
                title=task.title,
                description=task.description,
                completed=t.completed
            )
            tasks_db[i] = updated
            return updated
    raise HTTPException(status_code=404, detail="Task not found")
```

**MCP (After):**
```python
from mcp import McpError
from mcp.types import ErrorCode

@mcp.tool()
def update_task(task_id: int, title: str, description: str = "") -> dict:
    """Update an existing task.
    
    Args:
        task_id: The ID of the task to update
        title: The new title for the task
        description: The new description for the task
    
    Returns:
        The updated task
    """
    for i, task in enumerate(tasks_db):
        if task["id"] == task_id:
            tasks_db[i]["title"] = title
            tasks_db[i]["description"] = description
            return tasks_db[i]
    raise McpError(ErrorCode.InvalidParams, f"Task {task_id} not found")
```

### Example 3: DELETE Endpoint

**FastAPI (Before):**
```python
@app.delete("/tasks/{task_id}")
async def delete_task(task_id: int) -> dict:
    """Delete a task by ID."""
    for i, task in enumerate(tasks_db):
        if task.id == task_id:
            tasks_db.pop(i)
            return {"message": f"Task {task_id} deleted"}
    raise HTTPException(status_code=404, detail="Task not found")
```

**MCP (After):**
```python
@mcp.tool()
def delete_task(task_id: int) -> str:
    """Delete a task by ID.
    
    Args:
        task_id: The ID of the task to delete
    
    Returns:
        Confirmation message
    """
    for i, task in enumerate(tasks_db):
        if task["id"] == task_id:
            tasks_db.pop(i)
            return f"Task {task_id} deleted successfully"
    raise McpError(ErrorCode.InvalidParams, f"Task {task_id} not found")
```

---

## Pattern 2: Data Endpoints to Resources

### Overview

MCP resources represent read-only data that AI clients can access. They're ideal for static configuration, reference data, or information that doesn't change frequently.

```
+-----------------------------------------------------------------------+
|                    PATTERN 2: DATA TO RESOURCES                        |
+-----------------------------------------------------------------------+
|                                                                        |
|   When to use Resources vs Tools:                                      |
|                                                                        |
|   RESOURCES (read-only data)           TOOLS (actions/dynamic data)   |
|   +------------------------+           +------------------------+      |
|   | - Configuration        |           | - Create/Update/Delete |      |
|   | - Reference data       |           | - Dynamic queries      |      |
|   | - Static content       |           | - Computations         |      |
|   | - Documentation        |           | - External API calls   |      |
|   | - Schema information   |           | - Filtered searches    |      |
|   +------------------------+           +------------------------+      |
|                                                                        |
+-----------------------------------------------------------------------+
```

### Example 1: Configuration Endpoint

**FastAPI (Before):**
```python
from fastapi import FastAPI

app = FastAPI()

CONFIG = {
    "version": "1.0.0",
    "environment": "production",
    "features": {
        "dark_mode": True,
        "notifications": True
    }
}

@app.get("/config")
async def get_config() -> dict:
    """Get application configuration."""
    return CONFIG
```

**MCP (After):**
```python
from fastmcp import FastMCP
import json

mcp = FastMCP("Config Server")

CONFIG = {
    "version": "1.0.0",
    "environment": "production",
    "features": {
        "dark_mode": True,
        "notifications": True
    }
}

@mcp.resource("config://app")
def get_config() -> str:
    """Get application configuration."""
    return json.dumps(CONFIG, indent=2)
```

### Example 2: Static Data with Parameter

**FastAPI (Before):**
```python
USERS_DB = {
    1: {"id": 1, "name": "Alice", "role": "admin"},
    2: {"id": 2, "name": "Bob", "role": "user"},
    3: {"id": 3, "name": "Charlie", "role": "user"}
}

@app.get("/users/{user_id}")
async def get_user(user_id: int) -> dict:
    """Get user by ID."""
    if user_id not in USERS_DB:
        raise HTTPException(status_code=404, detail="User not found")
    return USERS_DB[user_id]
```

**MCP (After):**
```python
USERS_DB = {
    1: {"id": 1, "name": "Alice", "role": "admin"},
    2: {"id": 2, "name": "Bob", "role": "user"},
    3: {"id": 3, "name": "Charlie", "role": "user"}
}

@mcp.resource("users://{user_id}")
def get_user(user_id: int) -> str:
    """Get user by ID.
    
    Args:
        user_id: The ID of the user to retrieve
    """
    if user_id not in USERS_DB:
        return json.dumps({"error": f"User {user_id} not found"})
    return json.dumps(USERS_DB[user_id])
```

### Example 3: List All Items

**FastAPI (Before):**
```python
@app.get("/users")
async def list_users() -> list:
    """Get all users."""
    return list(USERS_DB.values())
```

**MCP (After) - As Resource:**
```python
@mcp.resource("users://all")
def list_all_users() -> str:
    """Get all users in the system."""
    return json.dumps(list(USERS_DB.values()), indent=2)
```

**MCP (After) - As Tool (if filtering is needed):**
```python
@mcp.tool()
def list_users(role: str = None) -> list:
    """Get users, optionally filtered by role.
    
    Args:
        role: Filter users by role (admin, user, etc.)
    
    Returns:
        List of users matching the criteria
    """
    users = list(USERS_DB.values())
    if role:
        users = [u for u in users if u["role"] == role]
    return users
```

---

## Pattern 3: Query Parameters to Tool Arguments

### Overview

FastAPI query parameters map directly to MCP tool function arguments. The key is preserving type hints, defaults, and descriptions.

```
+-----------------------------------------------------------------------+
|                    PATTERN 3: QUERY PARAMS TO ARGUMENTS                |
+-----------------------------------------------------------------------+
|                                                                        |
|   FASTAPI                              MCP                             |
|                                                                        |
|   @app.get("/search")                  @mcp.tool()                     |
|   async def search(                    def search(                     |
|       query: str,                          query: str,                 |
|       limit: int = 10,          --->       limit: int = 10,           |
|       offset: int = 0                      offset: int = 0             |
|   ):                                   ):                              |
|                                                                        |
|   - Query() -> direct param            - Function parameter            |
|   - Default values preserved           - Default values preserved      |
|   - Type hints preserved               - Type hints preserved          |
|                                                                        |
+-----------------------------------------------------------------------+
```

### Example 1: Simple Query Parameters

**FastAPI (Before):**
```python
from fastapi import FastAPI, Query

app = FastAPI()

@app.get("/search")
async def search_items(
    query: str = Query(..., description="Search query"),
    limit: int = Query(10, ge=1, le=100, description="Max results"),
    offset: int = Query(0, ge=0, description="Skip N results")
) -> list:
    """Search for items matching the query."""
    # Simulate search
    results = [f"Result {i} for '{query}'" for i in range(offset, offset + limit)]
    return results
```

**MCP (After):**
```python
from fastmcp import FastMCP

mcp = FastMCP("Search Server")

@mcp.tool()
def search_items(
    query: str,
    limit: int = 10,
    offset: int = 0
) -> list:
    """Search for items matching the query.
    
    Args:
        query: Search query string
        limit: Maximum number of results to return (1-100)
        offset: Number of results to skip
    
    Returns:
        List of matching items
    """
    # Validate manually (FastMCP doesn't have Query validators)
    limit = max(1, min(100, limit))
    offset = max(0, offset)
    
    results = [f"Result {i} for '{query}'" for i in range(offset, offset + limit)]
    return results
```

### Example 2: Multiple Optional Parameters

**FastAPI (Before):**
```python
from datetime import date
from typing import Optional

@app.get("/events")
async def get_events(
    start_date: Optional[date] = Query(None, description="Filter by start date"),
    end_date: Optional[date] = Query(None, description="Filter by end date"),
    category: Optional[str] = Query(None, description="Filter by category"),
    is_public: bool = Query(True, description="Include only public events")
) -> list:
    """Get events with optional filters."""
    events = get_all_events()  # hypothetical function
    
    if start_date:
        events = [e for e in events if e["date"] >= start_date]
    if end_date:
        events = [e for e in events if e["date"] <= end_date]
    if category:
        events = [e for e in events if e["category"] == category]
    if is_public is not None:
        events = [e for e in events if e["is_public"] == is_public]
    
    return events
```

**MCP (After):**
```python
from typing import Optional

@mcp.tool()
def get_events(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    category: Optional[str] = None,
    is_public: bool = True
) -> list:
    """Get events with optional filters.
    
    Args:
        start_date: Filter by start date (YYYY-MM-DD format)
        end_date: Filter by end date (YYYY-MM-DD format)
        category: Filter by event category
        is_public: If True, include only public events
    
    Returns:
        List of events matching the filters
    """
    from datetime import datetime
    
    events = get_all_events()
    
    if start_date:
        start = datetime.strptime(start_date, "%Y-%m-%d").date()
        events = [e for e in events if e["date"] >= start]
    if end_date:
        end = datetime.strptime(end_date, "%Y-%m-%d").date()
        events = [e for e in events if e["date"] <= end]
    if category:
        events = [e for e in events if e["category"] == category]
    events = [e for e in events if e["is_public"] == is_public]
    
    return events
```

### Example 3: Path + Query Parameters Combined

**FastAPI (Before):**
```python
@app.get("/users/{user_id}/posts")
async def get_user_posts(
    user_id: int,
    status: str = Query("published", description="Filter by status"),
    limit: int = Query(20, description="Max posts to return")
) -> list:
    """Get posts for a specific user."""
    posts = get_posts_by_user(user_id)
    posts = [p for p in posts if p["status"] == status]
    return posts[:limit]
```

**MCP (After):**
```python
@mcp.tool()
def get_user_posts(
    user_id: int,
    status: str = "published",
    limit: int = 20
) -> list:
    """Get posts for a specific user.
    
    Args:
        user_id: The ID of the user
        status: Filter posts by status (published, draft, archived)
        limit: Maximum number of posts to return
    
    Returns:
        List of posts for the user
    """
    posts = get_posts_by_user(user_id)
    posts = [p for p in posts if p["status"] == status]
    return posts[:limit]
```

---

## Pattern 4: Response Models to Return Types

### Overview

FastAPI uses Pydantic models for response validation and documentation. In MCP, return types are simpler - typically dict, list, or str (for resources).

```
+-----------------------------------------------------------------------+
|                    PATTERN 4: RESPONSE MODELS TO RETURNS               |
+-----------------------------------------------------------------------+
|                                                                        |
|   FASTAPI                              MCP                             |
|                                                                        |
|   class User(BaseModel):               # Option 1: Return dict         |
|       id: int                          @mcp.tool()                     |
|       name: str                        def get_user() -> dict:         |
|       email: str                           return {"id": 1, ...}       |
|                                                                        |
|   @app.get("/user")          --->      # Option 2: Return Pydantic    |
|   async def get_user()                 @mcp.tool()                     |
|       -> User:                         def get_user() -> User:         |
|       return User(...)                     return User(...)            |
|                                        # (FastMCP serializes it)       |
|                                                                        |
+-----------------------------------------------------------------------+
```

### Example 1: Simple Response Model

**FastAPI (Before):**
```python
from pydantic import BaseModel
from typing import List

class Product(BaseModel):
    id: int
    name: str
    price: float
    in_stock: bool

@app.get("/products/{product_id}", response_model=Product)
async def get_product(product_id: int) -> Product:
    """Get a product by ID."""
    return Product(
        id=product_id,
        name="Sample Product",
        price=29.99,
        in_stock=True
    )
```

**MCP (After) - Option 1: Return dict:**
```python
@mcp.tool()
def get_product(product_id: int) -> dict:
    """Get a product by ID.
    
    Args:
        product_id: The ID of the product
    
    Returns:
        Product details including id, name, price, and stock status
    """
    return {
        "id": product_id,
        "name": "Sample Product",
        "price": 29.99,
        "in_stock": True
    }
```

**MCP (After) - Option 2: Keep Pydantic (FastMCP handles serialization):**
```python
from pydantic import BaseModel

class Product(BaseModel):
    id: int
    name: str
    price: float
    in_stock: bool

@mcp.tool()
def get_product(product_id: int) -> Product:
    """Get a product by ID.
    
    Args:
        product_id: The ID of the product
    
    Returns:
        Product details
    """
    return Product(
        id=product_id,
        name="Sample Product",
        price=29.99,
        in_stock=True
    )
```

### Example 2: List Response

**FastAPI (Before):**
```python
from typing import List

@app.get("/products", response_model=List[Product])
async def list_products() -> List[Product]:
    """Get all products."""
    return [
        Product(id=1, name="Product 1", price=10.0, in_stock=True),
        Product(id=2, name="Product 2", price=20.0, in_stock=False),
    ]
```

**MCP (After):**
```python
@mcp.tool()
def list_products() -> list:
    """Get all products.
    
    Returns:
        List of all available products
    """
    return [
        {"id": 1, "name": "Product 1", "price": 10.0, "in_stock": True},
        {"id": 2, "name": "Product 2", "price": 20.0, "in_stock": False},
    ]
```

### Example 3: Nested Response Model

**FastAPI (Before):**
```python
class Address(BaseModel):
    street: str
    city: str
    country: str

class UserWithAddress(BaseModel):
    id: int
    name: str
    address: Address

@app.get("/users/{user_id}/full", response_model=UserWithAddress)
async def get_user_full(user_id: int) -> UserWithAddress:
    """Get user with full address details."""
    return UserWithAddress(
        id=user_id,
        name="John Doe",
        address=Address(
            street="123 Main St",
            city="New York",
            country="USA"
        )
    )
```

**MCP (After):**
```python
@mcp.tool()
def get_user_full(user_id: int) -> dict:
    """Get user with full address details.
    
    Args:
        user_id: The ID of the user
    
    Returns:
        User details including nested address information
    """
    return {
        "id": user_id,
        "name": "John Doe",
        "address": {
            "street": "123 Main St",
            "city": "New York",
            "country": "USA"
        }
    }
```

---

## Pattern 5: Handling Authentication

### Overview

Authentication in FastAPI typically uses dependencies. In MCP, authentication is handled at the transport level or through context.

```
+-----------------------------------------------------------------------+
|                    PATTERN 5: AUTHENTICATION                           |
+-----------------------------------------------------------------------+
|                                                                        |
|   FASTAPI                              MCP                             |
|                                                                        |
|   @app.get("/protected")               Option 1: Transport-level auth |
|   async def protected(                 - HTTP headers on SSE          |
|       user: User = Depends(            - Environment variables        |
|           get_current_user             - Config file                  |
|       )                                                                |
|   ):                            --->   Option 2: Context-based        |
|       ...                              @mcp.tool()                     |
|                                        def protected(ctx: Context):   |
|   - OAuth2/JWT in headers                  user = ctx.get_user()      |
|   - Dependency injection               Option 3: Per-tool auth        |
|   - Per-request validation             - API key as parameter         |
|                                        - Token in lifespan             |
|                                                                        |
+-----------------------------------------------------------------------+
```

### Example 1: API Key Authentication

**FastAPI (Before):**
```python
from fastapi import FastAPI, Header, HTTPException

app = FastAPI()

async def verify_api_key(x_api_key: str = Header(...)):
    if x_api_key != "secret-key-123":
        raise HTTPException(status_code=401, detail="Invalid API key")
    return x_api_key

@app.get("/protected")
async def protected_endpoint(api_key: str = Depends(verify_api_key)):
    """Access protected resource."""
    return {"message": "You have access!", "key_used": api_key[:4] + "..."}
```

**MCP (After) - Environment Variable Approach:**
```python
from fastmcp import FastMCP
import os

mcp = FastMCP("Protected Server")

# API key loaded from environment at startup
API_KEY = os.environ.get("API_KEY", "secret-key-123")
authenticated = False

@mcp.tool()
def authenticate(api_key: str) -> str:
    """Authenticate with an API key.
    
    Args:
        api_key: Your API key
    
    Returns:
        Authentication status message
    """
    global authenticated
    if api_key == API_KEY:
        authenticated = True
        return "Authentication successful"
    raise McpError(ErrorCode.InvalidParams, "Invalid API key")

@mcp.tool()
def protected_endpoint() -> dict:
    """Access protected resource (requires authentication).
    
    Returns:
        Protected resource data
    """
    if not authenticated:
        raise McpError(ErrorCode.InvalidRequest, "Please authenticate first")
    return {"message": "You have access!"}
```

### Example 2: Context-Based Authentication

**FastAPI (Before):**
```python
from fastapi.security import OAuth2PasswordBearer

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

async def get_current_user(token: str = Depends(oauth2_scheme)):
    user = decode_token(token)  # hypothetical
    if not user:
        raise HTTPException(status_code=401, detail="Invalid token")
    return user

@app.get("/me")
async def get_me(user: User = Depends(get_current_user)):
    """Get current user profile."""
    return user
```

**MCP (After) - Using Lifespan Context:**
```python
from fastmcp import FastMCP, Context
from contextlib import asynccontextmanager

# Store authenticated user in server state
server_state = {"current_user": None}

@asynccontextmanager
async def lifespan(mcp):
    # Setup: could load credentials from config
    print("Server starting, ready for authentication")
    yield
    # Cleanup
    print("Server shutting down")

mcp = FastMCP("Auth Server", lifespan=lifespan)

@mcp.tool()
def login(username: str, password: str) -> dict:
    """Login with username and password.
    
    Args:
        username: Your username
        password: Your password
    
    Returns:
        Login result with user info
    """
    # Validate credentials (simplified)
    if username == "admin" and password == "secret":
        server_state["current_user"] = {"id": 1, "username": username, "role": "admin"}
        return {"message": "Login successful", "user": server_state["current_user"]}
    raise McpError(ErrorCode.InvalidParams, "Invalid credentials")

@mcp.tool()
def get_me() -> dict:
    """Get current user profile.
    
    Returns:
        Current authenticated user's profile
    """
    user = server_state.get("current_user")
    if not user:
        raise McpError(ErrorCode.InvalidRequest, "Not authenticated. Please login first.")
    return user

@mcp.tool()
def logout() -> str:
    """Logout the current user.
    
    Returns:
        Logout confirmation
    """
    server_state["current_user"] = None
    return "Logged out successfully"
```

### Example 3: Role-Based Access Control

**FastAPI (Before):**
```python
def require_role(required_role: str):
    async def role_checker(user: User = Depends(get_current_user)):
        if user.role != required_role:
            raise HTTPException(status_code=403, detail="Insufficient permissions")
        return user
    return role_checker

@app.delete("/users/{user_id}")
async def delete_user(
    user_id: int,
    admin: User = Depends(require_role("admin"))
):
    """Delete a user (admin only)."""
    return {"message": f"User {user_id} deleted by {admin.username}"}
```

**MCP (After):**
```python
def require_role(required_role: str):
    """Helper to check user role."""
    user = server_state.get("current_user")
    if not user:
        raise McpError(ErrorCode.InvalidRequest, "Not authenticated")
    if user.get("role") != required_role:
        raise McpError(
            ErrorCode.InvalidRequest, 
            f"This action requires {required_role} role"
        )
    return user

@mcp.tool()
def delete_user(user_id: int) -> dict:
    """Delete a user (admin only).
    
    Args:
        user_id: The ID of the user to delete
    
    Returns:
        Deletion confirmation
    """
    admin = require_role("admin")
    # Perform deletion...
    return {"message": f"User {user_id} deleted by {admin['username']}"}
```

---

## Pattern 6: Error Handling

### Overview

FastAPI uses HTTPException for errors. MCP uses McpError with specific error codes defined by the protocol.

```
+-----------------------------------------------------------------------+
|                    PATTERN 6: ERROR HANDLING                           |
+-----------------------------------------------------------------------+
|                                                                        |
|   FASTAPI HTTP Codes                   MCP Error Codes                 |
|   +------------------+                 +---------------------------+   |
|   | 400 Bad Request  | ------------->  | InvalidParams             |   |
|   | 401 Unauthorized | ------------->  | InvalidRequest            |   |
|   | 403 Forbidden    | ------------->  | InvalidRequest            |   |
|   | 404 Not Found    | ------------->  | InvalidParams / custom    |   |
|   | 500 Server Error | ------------->  | InternalError             |   |
|   +------------------+                 +---------------------------+   |
|                                                                        |
+-----------------------------------------------------------------------+
```

### MCP Error Codes Reference

| MCP Error Code | HTTP Equivalent | When to Use |
|----------------|-----------------|-------------|
| `ErrorCode.ParseError` | 400 | Invalid JSON |
| `ErrorCode.InvalidRequest` | 400/401/403 | Bad request structure, auth issues |
| `ErrorCode.MethodNotFound` | 404 | Unknown method called |
| `ErrorCode.InvalidParams` | 400/404 | Invalid parameters, resource not found |
| `ErrorCode.InternalError` | 500 | Server-side errors |

### Example 1: Not Found Error

**FastAPI (Before):**
```python
@app.get("/items/{item_id}")
async def get_item(item_id: int):
    """Get item by ID."""
    item = items_db.get(item_id)
    if not item:
        raise HTTPException(
            status_code=404,
            detail=f"Item with ID {item_id} not found"
        )
    return item
```

**MCP (After):**
```python
from mcp import McpError
from mcp.types import ErrorCode

@mcp.tool()
def get_item(item_id: int) -> dict:
    """Get item by ID.
    
    Args:
        item_id: The ID of the item to retrieve
    
    Returns:
        The item details
    """
    item = items_db.get(item_id)
    if not item:
        raise McpError(
            ErrorCode.InvalidParams,
            f"Item with ID {item_id} not found"
        )
    return item
```

### Example 2: Validation Error

**FastAPI (Before):**
```python
@app.post("/orders")
async def create_order(quantity: int, product_id: int):
    """Create a new order."""
    if quantity < 1:
        raise HTTPException(
            status_code=400,
            detail="Quantity must be at least 1"
        )
    if quantity > 100:
        raise HTTPException(
            status_code=400,
            detail="Quantity cannot exceed 100"
        )
    product = products_db.get(product_id)
    if not product:
        raise HTTPException(
            status_code=404,
            detail=f"Product {product_id} not found"
        )
    # Create order...
    return {"order_id": 123, "quantity": quantity, "product": product}
```

**MCP (After):**
```python
@mcp.tool()
def create_order(quantity: int, product_id: int) -> dict:
    """Create a new order.
    
    Args:
        quantity: Number of items to order (1-100)
        product_id: The ID of the product to order
    
    Returns:
        The created order details
    """
    # Validation errors
    if quantity < 1:
        raise McpError(
            ErrorCode.InvalidParams,
            "Quantity must be at least 1"
        )
    if quantity > 100:
        raise McpError(
            ErrorCode.InvalidParams,
            "Quantity cannot exceed 100"
        )
    
    product = products_db.get(product_id)
    if not product:
        raise McpError(
            ErrorCode.InvalidParams,
            f"Product {product_id} not found"
        )
    
    # Create order...
    return {"order_id": 123, "quantity": quantity, "product": product}
```

### Example 3: Generic Error Handler Pattern

**FastAPI (Before):**
```python
from fastapi import FastAPI
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException

app = FastAPI()

@app.exception_handler(StarletteHTTPException)
async def http_exception_handler(request, exc):
    return JSONResponse(
        status_code=exc.status_code,
        content={"error": exc.detail}
    )

@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request, exc):
    return JSONResponse(
        status_code=422,
        content={"error": "Validation failed", "details": exc.errors()}
    )
```

**MCP (After) - Wrapper Pattern:**
```python
from functools import wraps
from mcp import McpError
from mcp.types import ErrorCode

def handle_errors(func):
    """Decorator to convert exceptions to McpError."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except McpError:
            raise  # Re-raise MCP errors as-is
        except ValueError as e:
            raise McpError(ErrorCode.InvalidParams, str(e))
        except PermissionError as e:
            raise McpError(ErrorCode.InvalidRequest, f"Permission denied: {e}")
        except Exception as e:
            raise McpError(ErrorCode.InternalError, f"Internal error: {e}")
    return wrapper

@mcp.tool()
@handle_errors
def risky_operation(data: str) -> dict:
    """Perform a risky operation that might fail.
    
    Args:
        data: Input data to process
    
    Returns:
        Processed result
    """
    if not data:
        raise ValueError("Data cannot be empty")
    # ... operation that might raise various exceptions
    return {"result": process_data(data)}
```

---

## Summary

```
+-----------------------------------------------------------------------+
|                         KEY TAKEAWAYS                                  |
+-----------------------------------------------------------------------+
|                                                                        |
|  PATTERN 1: ENDPOINTS TO TOOLS                                        |
|  - POST/PUT/DELETE endpoints become @mcp.tool() functions             |
|  - Path params become function arguments                              |
|  - Keep docstrings - they guide AI behavior                           |
|                                                                        |
|  PATTERN 2: DATA TO RESOURCES                                         |
|  - Static/config GET endpoints become @mcp.resource()                 |
|  - Dynamic queries should remain as tools                             |
|  - Resources return strings (JSON serialized)                         |
|                                                                        |
|  PATTERN 3: QUERY PARAMS TO ARGUMENTS                                 |
|  - Query parameters become function parameters                        |
|  - Preserve type hints and defaults                                   |
|  - Document in docstring (replaces Query description)                 |
|                                                                        |
|  PATTERN 4: RESPONSE MODELS                                           |
|  - Can return dict/list directly                                      |
|  - Can keep Pydantic models (FastMCP serializes)                      |
|  - Resources return str (JSON format)                                 |
|                                                                        |
|  PATTERN 5: AUTHENTICATION                                            |
|  - Use environment variables or config files                          |
|  - Implement login/logout tools if needed                             |
|  - Store auth state in server state                                   |
|                                                                        |
|  PATTERN 6: ERROR HANDLING                                            |
|  - HTTPException -> McpError                                          |
|  - Map HTTP codes to MCP ErrorCodes                                   |
|  - Use wrapper decorators for consistency                             |
|                                                                        |
+-----------------------------------------------------------------------+
```

---

## Next Steps

- [Step-by-Step Conversion](./_03_step_by_step_conversion.md) - Complete walkthrough
- [Hybrid Approach](./_04_hybrid_approach.md) - Run both together
- [Practical Notebook](./_05_fastapi_to_mcp_practical.ipynb) - Hands-on conversion

---

*Master these patterns to efficiently convert any FastAPI application to MCP.*
