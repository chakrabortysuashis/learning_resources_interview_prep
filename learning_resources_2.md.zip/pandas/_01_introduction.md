# Introduction to Pandas

## What is Pandas?

Think of Pandas as **Excel for Python**! It's a tool that lets you work with data in tables (rows and columns) using code instead of clicking.

**Why use Pandas?**
- Handle thousands of rows in seconds
- Automate repetitive tasks
- Clean messy data easily
- Works great with other Python tools

## Installation

```bash
pip install pandas
```

## Importing Pandas

```python
import pandas as pd  # "pd" is the standard nickname
```

## Two Main Data Structures

### 1. Series - A Single Column

Think of it as a **single column** in a spreadsheet.

```
Index | Value
------|-------
  0   |  85
  1   |  92
  2   |  78
  3   |  95
```

```python
grades = pd.Series([85, 92, 78, 95])
```

### 2. DataFrame - A Full Table

Think of it as an **entire spreadsheet** with multiple columns.

```
   | Name    | Math | Science
---|---------|------|--------
 0 | Alice   |  85  |   90
 1 | Bob     |  92  |   88
 2 | Charlie |  78  |   95
```

```python
students = pd.DataFrame({
    'Name': ['Alice', 'Bob', 'Charlie'],
    'Math': [85, 92, 78],
    'Science': [90, 88, 95]
})
```

## Series vs DataFrame - Quick Comparison

| Feature    | Series              | DataFrame                |
|------------|---------------------|--------------------------|
| Dimensions | 1D (one column)     | 2D (rows and columns)    |
| Like       | A single list       | A spreadsheet/table      |
| Has Index  | Yes                 | Yes                      |
| Has Columns| No (just values)    | Yes (multiple columns)   |

## Your First Pandas Code

```python
import pandas as pd

# Create a simple DataFrame
my_data = pd.DataFrame({
    'Student': ['Emma', 'Liam', 'Sophia'],
    'Score': [95, 88, 92]
})

print(my_data)
```

**Output:**
```
  Student  Score
0    Emma     95
1    Liam     88
2   Sophia     92
```

## Key Takeaways

1. Pandas = Working with tables in Python
2. Series = One column
3. DataFrame = Full table (multiple columns)
4. Always import as: `import pandas as pd`

## Try It Yourself

1. Install pandas: `pip install pandas`
2. Open Python and type: `import pandas as pd`
3. Create your first Series: `pd.Series([1, 2, 3])`

---
*Next: We'll dive deeper into Series!*
