# GroupBy Operations

## What is GroupBy?

GroupBy is like sorting your data into piles and then doing calculations on each pile.

**Example:** You have student scores. You want the average score for each grade level (9th, 10th, 11th, 12th).

Think of it as: **Split - Apply - Combine**
1. **Split** data into groups
2. **Apply** a function to each group
3. **Combine** results back together

## Basic GroupBy

```python
import pandas as pd

df = pd.DataFrame({
    'Student': ['Alice', 'Bob', 'Charlie', 'Diana', 'Eve', 'Frank'],
    'Grade': [10, 10, 11, 11, 12, 12],
    'Score': [85, 92, 78, 88, 95, 82]
})
```

```
  Student  Grade  Score
0   Alice     10     85
1     Bob     10     92
2 Charlie     11     78
3   Diana     11     88
4     Eve     12     95
5   Frank     12     82
```

```python
# Group by Grade and get average score
df.groupby('Grade')['Score'].mean()
```

**Output:**
```
Grade
10    88.5
11    83.0
12    88.5
Name: Score, dtype: float64
```

## Common Aggregation Functions

| Function | What It Does |
|----------|--------------|
| `.mean()` | Average |
| `.sum()` | Total |
| `.count()` | Number of items |
| `.min()` | Smallest value |
| `.max()` | Largest value |
| `.std()` | Standard deviation |
| `.first()` | First value in group |
| `.last()` | Last value in group |

## Multiple Aggregations with agg()

```python
# Get multiple stats at once
df.groupby('Grade')['Score'].agg(['mean', 'min', 'max', 'count'])
```

**Output:**
```
       mean  min  max  count
Grade                       
10     88.5   85   92      2
11     83.0   78   88      2
12     88.5   82   95      2
```

## Grouping by Multiple Columns

```python
df = pd.DataFrame({
    'Store': ['A', 'A', 'B', 'B', 'A', 'B'],
    'Product': ['Apple', 'Banana', 'Apple', 'Banana', 'Apple', 'Apple'],
    'Sales': [100, 150, 200, 100, 120, 180]
})

# Group by both Store AND Product
df.groupby(['Store', 'Product'])['Sales'].sum()
```

**Output:**
```
Store  Product
A      Apple      220
       Banana     150
B      Apple      380
       Banana     100
Name: Sales, dtype: int64
```

## Transform - Keep Original Shape

Sometimes you want to add a group calculation back to your original data.

```python
# Add average score for each grade level
df['Grade_Avg'] = df.groupby('Grade')['Score'].transform('mean')
```

**Before:**
```
  Student  Grade  Score
0   Alice     10     85
1     Bob     10     92
```

**After:**
```
  Student  Grade  Score  Grade_Avg
0   Alice     10     85       88.5
1     Bob     10     92       88.5
```

## Filter Groups

Keep only groups that meet a condition.

```python
# Keep only grades where average score > 85
df.groupby('Grade').filter(lambda x: x['Score'].mean() > 85)
```

## Named Aggregations (Clean Output)

```python
df.groupby('Grade').agg(
    avg_score = ('Score', 'mean'),
    top_score = ('Score', 'max'),
    num_students = ('Score', 'count')
)
```

**Output:**
```
       avg_score  top_score  num_students
Grade                                     
10          88.5         92             2
11          83.0         88             2
12          88.5         95             2
```

## Real-World Example: Sales Data

```python
sales = pd.DataFrame({
    'Date': ['2024-01-01', '2024-01-01', '2024-01-02', '2024-01-02'],
    'Product': ['Laptop', 'Phone', 'Laptop', 'Phone'],
    'Region': ['East', 'East', 'West', 'West'],
    'Revenue': [1000, 500, 1200, 600]
})

# Total revenue by product
sales.groupby('Product')['Revenue'].sum()

# Average revenue by region
sales.groupby('Region')['Revenue'].mean()

# Revenue by product AND region
sales.groupby(['Product', 'Region'])['Revenue'].sum()
```

## Before and After

### Example: Student Performance by Class

**Before (raw data):**
```
    Class  Student  Score
0  Math    Alice     85
1  Math    Bob       92
2  Science Alice     88
3  Science Bob       95
```

**Code:**
```python
df.groupby('Class').agg({
    'Score': ['mean', 'max'],
    'Student': 'count'
})
```

**After (grouped summary):**
```
        Score       Student
         mean  max    count
Class                      
Math     88.5   92        2
Science  91.5   95        2
```

## Common Mistakes

| Mistake | Problem | Fix |
|---------|---------|-----|
| Forgetting column after groupby | Groups all columns | `df.groupby('A')['B'].mean()` |
| Using wrong function | Error or wrong result | Check available agg functions |
| Expecting DataFrame, getting Series | Different output types | Use `[['col']]` or `.reset_index()` |

## Try It Yourself

1. Create sales data with Store, Product, and Amount
2. Find total sales per store
3. Find average sales per product
4. Find max sale for each store-product combination
5. Use transform to add store average to each row

## Key Takeaways

1. GroupBy = Split-Apply-Combine
2. Basic: `df.groupby('col')['value'].mean()`
3. Multiple stats: `.agg(['mean', 'sum', 'count'])`
4. Multiple groups: `groupby(['col1', 'col2'])`
5. Transform: adds group calculation back to original data
6. Named agg: clean column names in output

---
*Next: Merging and joining DataFrames!*
