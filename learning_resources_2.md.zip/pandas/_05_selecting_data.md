# Selecting Data with loc and iloc

## The Big Picture

Think of selecting data like finding a seat in a movie theater:
- **loc** = "Row A, Seat 5" (using labels/names)
- **iloc** = "3rd row, 2nd seat from left" (using position numbers)

## Sample Data

```python
import pandas as pd

df = pd.DataFrame({
    'Name': ['Alice', 'Bob', 'Charlie', 'Diana'],
    'Math': [92, 85, 78, 95],
    'Science': [88, 90, 85, 92],
    'English': [95, 82, 88, 90]
}, index=['A', 'B', 'C', 'D'])
```

```
   Name  Math  Science  English
A  Alice   92       88       95
B    Bob   85       90       82
C Charlie   78       85       88
D  Diana   95       92       90
```

## Using iloc (Integer Location)

**iloc** uses position numbers (0, 1, 2...)

### Single Cell

```python
df.iloc[0, 1]     # Row 0, Column 1 = 92 (Alice's Math)
df.iloc[2, 3]     # Row 2, Column 3 = 88 (Charlie's English)
```

### Single Row

```python
df.iloc[0]        # First row (Alice's data)
df.iloc[-1]       # Last row (Diana's data)
```

### Single Column

```python
df.iloc[:, 1]     # All rows, column 1 (Math scores)
df.iloc[:, 0]     # All rows, column 0 (Names)
```

### Multiple Rows/Columns

```python
df.iloc[0:2]           # First 2 rows
df.iloc[0:2, 1:3]      # First 2 rows, columns 1-2
df.iloc[[0, 2]]        # Rows 0 and 2 (skipping row 1)
df.iloc[:, [1, 3]]     # All rows, columns 1 and 3
```

## Using loc (Label Location)

**loc** uses labels (names, not positions)

### Single Cell

```python
df.loc['A', 'Math']      # Alice's Math score = 92
df.loc['C', 'English']   # Charlie's English = 88
```

### Single Row

```python
df.loc['A']         # Alice's entire row
df.loc['D']         # Diana's entire row
```

### Single Column

```python
df.loc[:, 'Math']       # All Math scores
df.loc[:, 'Name']       # All names
```

### Multiple Rows/Columns

```python
df.loc['A':'C']                    # Rows A through C (inclusive!)
df.loc['A':'C', 'Math':'Science']  # Rows A-C, columns Math-Science
df.loc[['A', 'C']]                 # Just rows A and C
df.loc[:, ['Name', 'English']]     # All rows, Name and English columns
```

## Key Difference: Slicing

| Type | Code | Result |
|------|------|--------|
| iloc | `df.iloc[0:2]` | Rows 0, 1 (excludes 2) |
| loc | `df.loc['A':'C']` | Rows A, B, C (includes C!) |

## Quick Reference Table

| Want to get... | iloc (by position) | loc (by label) |
|----------------|-------------------|----------------|
| First row | `df.iloc[0]` | `df.loc['A']` |
| Last row | `df.iloc[-1]` | N/A |
| First column | `df.iloc[:, 0]` | `df.loc[:, 'Name']` |
| Cell at row 0, col 1 | `df.iloc[0, 1]` | `df.loc['A', 'Math']` |
| First 3 rows | `df.iloc[0:3]` | `df.loc['A':'C']` |

## Selecting Columns (Simple Way)

```python
# Single column
df['Math']              # Returns Series
df[['Math']]            # Returns DataFrame

# Multiple columns
df[['Name', 'Math', 'Science']]
```

## Visual Example

**Original DataFrame:**
```
   Name  Math  Science  English
A  Alice   92       88       95
B    Bob   85       90       82
C Charlie   78       85       88
D  Diana   95       92       90
```

**df.iloc[1:3, 1:3]** (rows 1-2, columns 1-2):
```
   Math  Science
B    85       90
C    78       85
```

**df.loc['B':'D', 'Math':'Science']** (rows B-D, columns Math-Science):
```
   Math  Science
B    85       90
C    78       85
D    95       92
```

## Common Mistakes

| Mistake | Problem | Fix |
|---------|---------|-----|
| `df.loc[0]` with numeric index | May work, but confusing | Use `iloc[0]` for position |
| `df.iloc['A']` | iloc needs integers | Use `loc['A']` for labels |
| Forgetting `:` | Returns Series, not DataFrame | Use `df.iloc[0:1]` for DataFrame |
| loc slice excludes end | That's iloc behavior | loc includes the end! |

## Try It Yourself

1. Create a DataFrame of 4 students with 3 subjects
2. Use iloc to get the first student's scores
3. Use loc to get a specific student by name
4. Select just the Math and Science columns

## Key Takeaways

1. **iloc** = select by position (0, 1, 2...)
2. **loc** = select by label (names)
3. iloc excludes the end in slices: `[0:2]` = rows 0, 1
4. loc includes the end in slices: `['A':'C']` = rows A, B, C
5. Use `:` to mean "all" (all rows or all columns)

---
*Next: Filtering data with conditions!*
