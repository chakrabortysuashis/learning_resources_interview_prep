# Handling Missing Data

## What is Missing Data?

Real-world data often has gaps - empty cells, "N/A", or "unknown" values. In Pandas, missing data appears as `NaN` (Not a Number) or `None`.

Think of it like a survey where someone skipped a question!

## Creating Data with Missing Values

```python
import pandas as pd
import numpy as np

df = pd.DataFrame({
    'Name': ['Alice', 'Bob', 'Charlie', 'Diana'],
    'Age': [15, np.nan, 17, 16],  # Bob's age is missing
    'Score': [85, 90, np.nan, 78]  # Charlie's score is missing
})
```

```
      Name   Age  Score
0    Alice  15.0   85.0
1      Bob   NaN   90.0
2  Charlie  17.0    NaN
3    Diana  16.0   78.0
```

## Detecting Missing Data

### Check for Missing Values

```python
# Returns True/False for each cell
df.isna()  # or df.isnull() (same thing)
```

```
    Name    Age  Score
0  False  False  False
1  False   True  False
2  False  False   True
3  False  False  False
```

### Count Missing Values

```python
# Count NaN in each column
df.isna().sum()
```

```
Name     0
Age      1
Score    1
dtype: int64
```

### Check if ANY Missing

```python
# Any missing in the whole DataFrame?
df.isna().any().any()  # Returns True or False

# Any missing in each column?
df.isna().any()
```

## Handling Missing Data - 3 Options

### Option 1: Remove Rows with Missing Data (dropna)

```python
# Remove rows that have ANY missing value
df_clean = df.dropna()
```

**Before:**
```
      Name   Age  Score
0    Alice  15.0   85.0
1      Bob   NaN   90.0
2  Charlie  17.0    NaN
3    Diana  16.0   78.0
```

**After:**
```
      Name   Age  Score
0    Alice  15.0   85.0
3    Diana  16.0   78.0
```

**More dropna options:**
```python
# Drop only if ALL values are missing
df.dropna(how='all')

# Drop only if specific column is missing
df.dropna(subset=['Age'])

# Require at least 2 non-missing values
df.dropna(thresh=2)
```

### Option 2: Fill Missing Values (fillna)

```python
# Fill all NaN with 0
df_filled = df.fillna(0)

# Fill with different values per column
df_filled = df.fillna({'Age': 16, 'Score': 75})

# Fill with the mean
df['Age'] = df['Age'].fillna(df['Age'].mean())

# Fill with the previous value (forward fill)
df_filled = df.fillna(method='ffill')

# Fill with the next value (backward fill)
df_filled = df.fillna(method='bfill')
```

### Option 3: Interpolate (Estimate)

For numeric data, estimate missing values based on surrounding values.

```python
df['Score'] = df['Score'].interpolate()
```

**Before:**
```
Score: [85, 90, NaN, 78]
```

**After interpolate:**
```
Score: [85, 90, 84, 78]  # NaN becomes average of 90 and 78
```

## Quick Reference

| Task | Code |
|------|------|
| Check for NaN | `df.isna()` |
| Count NaN per column | `df.isna().sum()` |
| Total NaN count | `df.isna().sum().sum()` |
| Remove rows with NaN | `df.dropna()` |
| Fill NaN with value | `df.fillna(0)` |
| Fill with mean | `df['col'].fillna(df['col'].mean())` |
| Forward fill | `df.fillna(method='ffill')` |
| Interpolate | `df.interpolate()` |

## Before and After Examples

### Example 1: Fill Missing Scores with Average

**Before:**
```
   Name  Score
0  Alice   85.0
1    Bob    NaN
2  Charlie 90.0
```

**Code:** `df['Score'] = df['Score'].fillna(df['Score'].mean())`

**After:**
```
   Name  Score
0  Alice   85.0
1    Bob   87.5
2  Charlie 90.0
```

### Example 2: Drop Rows with Missing Age

**Before:**
```
   Name   Age
0  Alice  15.0
1    Bob   NaN
2  Charlie 17.0
```

**Code:** `df.dropna(subset=['Age'])`

**After:**
```
   Name   Age
0  Alice  15.0
2  Charlie 17.0
```

## When to Use Each Method

| Situation | Best Method |
|-----------|-------------|
| Few missing values | `dropna()` - just remove them |
| Important rows, can't delete | `fillna()` - fill with mean/median |
| Time series data | `interpolate()` or `ffill()` |
| Need a placeholder | `fillna(0)` or `fillna('Unknown')` |

## Common Mistakes

| Mistake | Problem | Fix |
|---------|---------|-----|
| `df.dropna()` alone | Doesn't modify df | `df = df.dropna()` |
| Filling text with numbers | Confusing data | Fill text columns with 'Unknown' |
| Using mean on categories | Doesn't make sense | Use mode() for categories |

## Try It Yourself

1. Create a DataFrame with some NaN values
2. Count how many missing values you have
3. Try dropna() and see what happens
4. Try fillna() with different values
5. Try interpolate() on numeric data

## Key Takeaways

1. Missing data shows as `NaN` or `None`
2. Detect with `isna()` and `isna().sum()`
3. Remove with `dropna()`
4. Fill with `fillna(value)` or `fillna(method='ffill')`
5. Estimate with `interpolate()`
6. Choose method based on your data and needs!

---
*Next: Working with data types!*
