# Merging and Joining DataFrames

## Why Merge?

Real data often lives in multiple tables. Like having:
- One table with student names and IDs
- Another table with test scores and student IDs

You need to combine them to see which student got which score!

## The Four Types of Joins

Think of joining two tables like matching students to their lockers:

| Join Type | What It Does |
|-----------|--------------|
| **inner** | Only keeps matches (both tables have it) |
| **left** | Keep ALL from left table, match from right |
| **right** | Keep ALL from right table, match from left |
| **outer** | Keep EVERYTHING from both tables |

## Basic Merge

```python
import pandas as pd

# Table 1: Students
students = pd.DataFrame({
    'ID': [1, 2, 3, 4],
    'Name': ['Alice', 'Bob', 'Charlie', 'Diana']
})

# Table 2: Scores
scores = pd.DataFrame({
    'ID': [1, 2, 3, 5],  # Note: ID 5 exists but not in students!
    'Score': [85, 92, 78, 88]
})

# Merge on 'ID'
result = pd.merge(students, scores, on='ID')
```

**Students:**
```
   ID     Name
0   1    Alice
1   2      Bob
2   3  Charlie
3   4    Diana
```

**Scores:**
```
   ID  Score
0   1     85
1   2     92
2   3     78
3   5     88
```

**Result (inner join - default):**
```
   ID     Name  Score
0   1    Alice     85
1   2      Bob     92
2   3  Charlie     78
```
*Diana (ID 4) and Score for ID 5 are dropped - no match!*

## Different Join Types

### Inner Join (Default)

```python
pd.merge(students, scores, on='ID', how='inner')
```
Only rows that match in BOTH tables.

### Left Join

```python
pd.merge(students, scores, on='ID', how='left')
```

**Result:**
```
   ID     Name  Score
0   1    Alice   85.0
1   2      Bob   92.0
2   3  Charlie   78.0
3   4    Diana    NaN  <- Diana kept, no score found
```

### Right Join

```python
pd.merge(students, scores, on='ID', how='right')
```

**Result:**
```
   ID     Name  Score
0   1    Alice     85
1   2      Bob     92
2   3  Charlie     78
3   5      NaN     88  <- Score kept, no student found
```

### Outer Join

```python
pd.merge(students, scores, on='ID', how='outer')
```

**Result:**
```
   ID     Name  Score
0   1    Alice   85.0
1   2      Bob   92.0
2   3  Charlie   78.0
3   4    Diana    NaN  <- From students only
4   5      NaN   88.0  <- From scores only
```

## Different Column Names

What if the columns have different names?

```python
students = pd.DataFrame({
    'StudentID': [1, 2, 3],
    'Name': ['Alice', 'Bob', 'Charlie']
})

scores = pd.DataFrame({
    'ID': [1, 2, 3],
    'Score': [85, 92, 78]
})

# Use left_on and right_on
pd.merge(students, scores, left_on='StudentID', right_on='ID')
```

## Concatenating DataFrames

### Stack Vertically (Add Rows)

```python
df1 = pd.DataFrame({'Name': ['Alice', 'Bob'], 'Score': [85, 92]})
df2 = pd.DataFrame({'Name': ['Charlie', 'Diana'], 'Score': [78, 95]})

# Stack on top of each other
combined = pd.concat([df1, df2])
```

**Result:**
```
      Name  Score
0    Alice     85
1      Bob     92
0  Charlie     78
1    Diana     95
```

### Reset Index After Concat

```python
combined = pd.concat([df1, df2], ignore_index=True)
```

**Result:**
```
      Name  Score
0    Alice     85
1      Bob     92
2  Charlie     78
3    Diana     95
```

### Stack Horizontally (Add Columns)

```python
pd.concat([df1, df2], axis=1)
```

## Using join()

If your DataFrames share an index:

```python
df1 = pd.DataFrame({'A': [1, 2]}, index=['a', 'b'])
df2 = pd.DataFrame({'B': [3, 4]}, index=['a', 'b'])

df1.join(df2)
```

## Visual Summary

### Merge Types

```
INNER: Only matching rows
  Left:  [1, 2, 3]
  Right: [2, 3, 4]
  Result: [2, 3]

LEFT: All left + matching right
  Left:  [1, 2, 3]
  Right: [2, 3, 4]
  Result: [1, 2, 3]

RIGHT: All right + matching left
  Left:  [1, 2, 3]
  Right: [2, 3, 4]
  Result: [2, 3, 4]

OUTER: Everything
  Left:  [1, 2, 3]
  Right: [2, 3, 4]
  Result: [1, 2, 3, 4]
```

## Common Mistakes

| Mistake | Problem | Fix |
|---------|---------|-----|
| Wrong column name in `on=` | KeyError | Check column names match |
| Duplicate rows after merge | Many-to-many match | Clean duplicates first |
| Forgetting `how=` | Gets inner join | Specify join type explicitly |

## Try It Yourself

1. Create a 'products' DataFrame with ProductID and ProductName
2. Create an 'orders' DataFrame with OrderID, ProductID, and Quantity
3. Merge them to see product names with quantities
4. Try different join types and see what changes

## Key Takeaways

1. `merge()` combines DataFrames like a database JOIN
2. **inner**: Only matches
3. **left**: All from left, matches from right
4. **right**: All from right, matches from left
5. **outer**: Everything
6. `concat()` stacks DataFrames vertically or horizontally
7. Always check for unexpected duplicates after merging!

---
*Next: Sorting and ranking your data!*
