# Filtering Data

## What is Filtering?

Filtering means getting only the rows that match certain conditions. Like searching "Show me only students with A grades."

## Boolean Conditions

### Basic Comparison

```python
import pandas as pd

df = pd.DataFrame({
    'Name': ['Alice', 'Bob', 'Charlie', 'Diana'],
    'Age': [15, 17, 16, 15],
    'Score': [92, 78, 85, 95]
})
```

```python
# Create a True/False condition
df['Score'] > 80
```

**Output:**
```
0     True
1    False
2     True
3     True
Name: Score, dtype: bool
```

### Apply the Filter

```python
# Get only rows where Score > 80
high_scorers = df[df['Score'] > 80]
print(high_scorers)
```

**Output:**
```
      Name  Age  Score
0    Alice   15     92
2  Charlie   16     85
3    Diana   15     95
```

## Common Operators

| Operator | Meaning | Example |
|----------|---------|---------|
| `>` | Greater than | `df['Age'] > 16` |
| `<` | Less than | `df['Score'] < 60` |
| `>=` | Greater or equal | `df['Age'] >= 15` |
| `<=` | Less or equal | `df['Score'] <= 100` |
| `==` | Equals | `df['Name'] == 'Alice'` |
| `!=` | Not equals | `df['Grade'] != 'F'` |

## Multiple Conditions

### AND - Both must be true

Use `&` (not `and`)

```python
# Age >= 16 AND Score > 80
df[(df['Age'] >= 16) & (df['Score'] > 80)]
```

### OR - Either can be true

Use `|` (not `or`)

```python
# Age < 16 OR Score > 90
df[(df['Age'] < 16) | (df['Score'] > 90)]
```

### NOT - Opposite

Use `~`

```python
# Everyone who is NOT 15 years old
df[~(df['Age'] == 15)]
```

**Important:** Always use parentheses around each condition!

## The query() Method

An easier way to write filters using strings:

```python
# Same as df[df['Score'] > 80]
df.query('Score > 80')

# Multiple conditions
df.query('Age >= 16 and Score > 80')

# Using variables
min_score = 85
df.query('Score >= @min_score')  # @ references Python variable
```

## Using isin() for Multiple Values

Check if value is in a list:

```python
# Find Alice or Diana
df[df['Name'].isin(['Alice', 'Diana'])]

# Find ages 15 or 17
df[df['Age'].isin([15, 17])]
```

## String Filtering

```python
df = pd.DataFrame({
    'Name': ['Alice Smith', 'Bob Jones', 'Charlie Brown'],
    'Email': ['alice@gmail.com', 'bob@yahoo.com', 'charlie@gmail.com']
})

# Names that contain 'li'
df[df['Name'].str.contains('li')]

# Emails that start with 'a'
df[df['Email'].str.startswith('a')]

# Emails that end with 'gmail.com'
df[df['Email'].str.endswith('gmail.com')]
```

## Before and After Examples

### Example 1: Find Failing Students

**Before:**
```
      Name  Score
0    Alice     92
1      Bob     58
2  Charlie     45
3    Diana     85
```

**Code:** `df[df['Score'] < 60]`

**After:**
```
      Name  Score
1      Bob     58
2  Charlie     45
```

### Example 2: High School Juniors with Good Grades

**Before:**
```
      Name  Age  Grade
0    Alice   16     A
1      Bob   17     B
2  Charlie   16     C
3    Diana   17     A
```

**Code:** `df[(df['Age'] >= 16) & (df['Grade'] == 'A')]`

**After:**
```
      Name  Age Grade
0    Alice   16     A
3    Diana   17     A
```

## Common Mistakes

| Mistake | Problem | Fix |
|---------|---------|-----|
| `df['Score'] > 80 and df['Age'] > 15` | Can't use `and` | Use `&` |
| `df[df['Score'] > 80 & df['Age'] > 15]` | Missing parentheses | `(df['Score'] > 80) & (df['Age'] > 15)` |
| `df['Name'] = 'Alice'` | Single `=` is assignment | Use `==` for comparison |

## Try It Yourself

1. Create a DataFrame of 5 students with Name, Age, and Score
2. Filter to show only students who scored above 85
3. Filter to show students who are 16+ years old AND scored above 80
4. Use `isin()` to find specific students by name

## Key Takeaways

1. Filter with `df[condition]`
2. Use `&` for AND, `|` for OR, `~` for NOT
3. Always use parentheses with multiple conditions
4. `query()` is easier for complex filters
5. `isin()` checks if value is in a list
6. String methods: `.str.contains()`, `.str.startswith()`, `.str.endswith()`

---
*Next: Adding and removing columns!*
