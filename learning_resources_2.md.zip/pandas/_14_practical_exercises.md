# Practical Exercises

## How to Use This Section

Each exercise has:
1. A real-world scenario
2. Sample data
3. Tasks to complete
4. Hints if you get stuck
5. Solutions (try first before looking!)

---

## Exercise 1: Class Grade Book

### Scenario
You're helping a teacher analyze class performance.

### Data
```python
import pandas as pd

grades = pd.DataFrame({
    'Student': ['Alice', 'Bob', 'Charlie', 'Diana', 'Eve', 'Frank', 'Grace', 'Henry'],
    'Math': [92, 78, 85, 95, 67, 88, 91, 72],
    'Science': [88, 82, 90, 92, 70, 85, 89, 75],
    'English': [95, 75, 88, 90, 72, 82, 94, 68],
    'History': [89, 80, 82, 88, 65, 78, 92, 70]
})
```

### Tasks
1. Calculate each student's average score across all subjects
2. Find who has the highest average
3. Find which subject has the lowest class average
4. Count how many students passed each subject (>= 70)
5. Create a 'Status' column: 'Honor Roll' if average >= 90, 'Pass' if >= 60, else 'Needs Help'

### Hints
- Use `mean(axis=1)` for row averages
- Use `idxmax()` to find the index of the maximum value
- Use `apply()` for the Status column

---

## Exercise 2: Store Sales Analysis

### Scenario
You manage a small store and need to analyze daily sales.

### Data
```python
sales = pd.DataFrame({
    'Date': pd.date_range('2024-01-01', periods=10),
    'Product': ['Laptop', 'Phone', 'Tablet', 'Laptop', 'Phone', 
                'Tablet', 'Laptop', 'Phone', 'Tablet', 'Laptop'],
    'Quantity': [2, 5, 3, 1, 8, 4, 3, 6, 2, 2],
    'Unit_Price': [999, 699, 399, 999, 699, 399, 999, 699, 399, 999],
    'Customer_Type': ['Business', 'Individual', 'Individual', 'Business', 'Individual',
                      'Business', 'Individual', 'Business', 'Individual', 'Business']
})
```

### Tasks
1. Add a 'Total' column (Quantity * Unit_Price)
2. Find total revenue by product
3. Find average order value by customer type
4. Which day had the highest sales?
5. Calculate total revenue and average daily revenue

### Hints
- Use `groupby()` for aggregations
- Use `sort_values()` to find highest
- Extract day with `dt.day_name()`

---

## Exercise 3: Student Attendance

### Scenario
Track student attendance and identify patterns.

### Data
```python
attendance = pd.DataFrame({
    'Student': ['Alice', 'Bob', 'Charlie', 'Alice', 'Bob', 'Charlie'] * 5,
    'Week': [1, 1, 1, 2, 2, 2, 3, 3, 3, 4, 4, 4, 5, 5, 5] * 2,
    'Days_Present': [5, 4, 5, 5, 3, 5, 4, 5, 5, 5, 2, 4, 5, 4, 5] * 2,
    'Days_Absent': [0, 1, 0, 0, 2, 0, 1, 0, 0, 0, 3, 1, 0, 1, 0] * 2
})
attendance = attendance.head(15)  # Take first 15 rows
```

### Tasks
1. Calculate total days present for each student
2. Find who has the best attendance (highest total present)
3. Calculate attendance percentage: Days_Present / (Days_Present + Days_Absent) * 100
4. Flag students with attendance below 80%
5. Find which week had the most absences

### Hints
- Use `groupby('Student')` for per-student stats
- Use `transform()` to add group calculations back
- Use boolean filtering for flagging

---

## Exercise 4: Survey Data Cleaning

### Scenario
Clean messy survey data for analysis.

### Data
```python
import numpy as np

survey = pd.DataFrame({
    'Response_ID': [1, 2, 3, 4, 5, 6, 7, 8],
    'Age': ['25', '32', 'twenty-seven', '41', np.nan, '38', '29', 'N/A'],
    'Satisfaction': [8, 9, 7, np.nan, 8, 10, 6, 9],
    'Would_Recommend': ['Yes', 'yes', 'YES', 'No', 'yes', 'NO', np.nan, 'Yes'],
    'Comments': ['Great!', '', 'Needs improvement', 'N/A', 'Loved it', np.nan, 'OK', 'Amazing']
})
```

### Tasks
1. Convert Age to numeric (invalid values become NaN)
2. Fill missing Satisfaction with the mean
3. Standardize Would_Recommend to 'Yes' or 'No'
4. Replace empty strings and 'N/A' in Comments with 'No comment'
5. Count how many complete responses (no NaN in any column)

### Hints
- Use `pd.to_numeric(errors='coerce')`
- Use `str.lower()` and `str.title()` for standardizing
- Use `replace()` for text replacements

---

## Exercise 5: Sports League Standings

### Scenario
Calculate and display league standings.

### Data
```python
games = pd.DataFrame({
    'Home_Team': ['Tigers', 'Bears', 'Eagles', 'Tigers', 'Bears', 'Eagles'],
    'Away_Team': ['Bears', 'Eagles', 'Tigers', 'Eagles', 'Tigers', 'Bears'],
    'Home_Score': [3, 2, 1, 4, 2, 3],
    'Away_Score': [2, 2, 3, 1, 3, 1]
})
```

### Tasks
1. Determine winner of each game (or 'Draw')
2. Calculate total wins for each team
3. Calculate total points for each team (win=3, draw=1, loss=0)
4. Create a standings table sorted by points
5. Calculate goal difference for each team

### Hints
- Use `apply()` with a function to determine winner
- Concatenate home and away results
- Use `groupby()` to aggregate by team

---

## Solutions

### Exercise 1 Solution

```python
# 1. Calculate average
grades['Average'] = grades[['Math', 'Science', 'English', 'History']].mean(axis=1)

# 2. Highest average
top_student = grades.loc[grades['Average'].idxmax(), 'Student']
print(f"Top student: {top_student}")

# 3. Lowest subject average
subjects = ['Math', 'Science', 'English', 'History']
subject_avgs = grades[subjects].mean()
lowest_subject = subject_avgs.idxmin()
print(f"Lowest average subject: {lowest_subject}")

# 4. Passing count per subject
for subject in subjects:
    passing = (grades[subject] >= 70).sum()
    print(f"{subject}: {passing} passed")

# 5. Status column
def get_status(avg):
    if avg >= 90:
        return 'Honor Roll'
    elif avg >= 60:
        return 'Pass'
    else:
        return 'Needs Help'

grades['Status'] = grades['Average'].apply(get_status)
```

### Exercise 2 Solution

```python
# 1. Total column
sales['Total'] = sales['Quantity'] * sales['Unit_Price']

# 2. Revenue by product
print(sales.groupby('Product')['Total'].sum())

# 3. Average by customer type
print(sales.groupby('Customer_Type')['Total'].mean())

# 4. Highest sales day
best_day = sales.loc[sales['Total'].idxmax(), 'Date']
print(f"Best day: {best_day}")

# 5. Total and average revenue
print(f"Total: ${sales['Total'].sum():,}")
print(f"Daily average: ${sales['Total'].mean():,.2f}")
```

### Exercise 3 Solution

```python
# 1. Total present per student
print(attendance.groupby('Student')['Days_Present'].sum())

# 2. Best attendance
best = attendance.groupby('Student')['Days_Present'].sum().idxmax()
print(f"Best attendance: {best}")

# 3. Attendance percentage
attendance['Total_Days'] = attendance['Days_Present'] + attendance['Days_Absent']
attendance['Attendance_Pct'] = (attendance['Days_Present'] / attendance['Total_Days'] * 100)

# 4. Flag low attendance
attendance['Low_Attendance'] = attendance['Attendance_Pct'] < 80

# 5. Most absences by week
print(attendance.groupby('Week')['Days_Absent'].sum().idxmax())
```

### Exercise 4 Solution

```python
# 1. Convert Age
survey['Age'] = pd.to_numeric(survey['Age'], errors='coerce')

# 2. Fill Satisfaction
survey['Satisfaction'] = survey['Satisfaction'].fillna(survey['Satisfaction'].mean())

# 3. Standardize Would_Recommend
survey['Would_Recommend'] = survey['Would_Recommend'].str.lower().map(
    {'yes': 'Yes', 'no': 'No'}
)

# 4. Clean Comments
survey['Comments'] = survey['Comments'].replace(['', 'N/A', np.nan], 'No comment')

# 5. Complete responses
complete = survey.dropna().shape[0]
print(f"Complete responses: {complete}")
```

### Exercise 5 Solution

```python
# 1. Determine winner
def get_winner(row):
    if row['Home_Score'] > row['Away_Score']:
        return row['Home_Team']
    elif row['Away_Score'] > row['Home_Score']:
        return row['Away_Team']
    else:
        return 'Draw'

games['Winner'] = games.apply(get_winner, axis=1)

# 2-4. Calculate standings
teams = set(games['Home_Team'].tolist() + games['Away_Team'].tolist())
standings = []

for team in teams:
    wins = (games['Winner'] == team).sum()
    draws = ((games['Winner'] == 'Draw') & 
             ((games['Home_Team'] == team) | (games['Away_Team'] == team))).sum()
    points = wins * 3 + draws
    standings.append({'Team': team, 'Wins': wins, 'Draws': draws, 'Points': points})

standings_df = pd.DataFrame(standings).sort_values('Points', ascending=False)
print(standings_df)
```

---

## Congratulations!

You've completed the Pandas learning materials! You now know how to:

- Create and manipulate DataFrames
- Read and write data files
- Select, filter, and transform data
- Handle missing values
- Group and aggregate data
- Merge multiple datasets
- Apply custom functions

Keep practicing with your own data projects!
