# DataFrame Basics

## What is a DataFrame?

A DataFrame is like a **spreadsheet** or **table** - it has rows and columns. Think of it as multiple Series side by side.

```
   | Name    | Age | Grade
---|---------|-----|------
 0 | Alice   | 15  |  A
 1 | Bob     | 16  |  B
 2 | Charlie | 15  |  A
```

## Creating DataFrames

### Method 1: From a Dictionary (Most Common)

Each key becomes a column name, values become the column data.

```python
import pandas as pd

students = pd.DataFrame({
    'Name': ['Alice', 'Bob', 'Charlie'],
    'Age': [15, 16, 15],
    'Grade': ['A', 'B', 'A']
})
print(students)
```

**Output:**
```
      Name  Age Grade
0    Alice   15     A
1      Bob   16     B
2  Charlie   15     A
```

### Method 2: From a List of Dictionaries

Each dictionary becomes a row.

```python
students = pd.DataFrame([
    {'Name': 'Alice', 'Age': 15, 'Grade': 'A'},
    {'Name': 'Bob', 'Age': 16, 'Grade': 'B'},
    {'Name': 'Charlie', 'Age': 15, 'Grade': 'A'}
])
```

### Method 3: From a List of Lists

```python
data = [
    ['Alice', 15, 'A'],
    ['Bob', 16, 'B'],
    ['Charlie', 15, 'A']
]

students = pd.DataFrame(data, columns=['Name', 'Age', 'Grade'])
```

## Viewing Your Data

### First/Last Rows

```python
df.head()      # First 5 rows
df.head(3)     # First 3 rows
df.tail()      # Last 5 rows
df.tail(2)     # Last 2 rows
```

### Quick Info

| Method | What It Shows |
|--------|---------------|
| `df.shape` | (rows, columns) |
| `df.columns` | Column names |
| `df.index` | Row labels |
| `df.dtypes` | Data type of each column |
| `df.info()` | Overview of DataFrame |
| `df.describe()` | Statistics for number columns |

**Example:**
```python
print(students.shape)     # (3, 3)
print(students.columns)   # Index(['Name', 'Age', 'Grade'], dtype='object')
```

## Accessing Columns

### Single Column (Returns Series)

```python
# Both ways work:
names = students['Name']
names = students.Name  # Only works if column name has no spaces
```

### Multiple Columns (Returns DataFrame)

```python
subset = students[['Name', 'Grade']]
```

## Accessing Rows

### By Position with `.iloc[]`

```python
students.iloc[0]      # First row
students.iloc[2]      # Third row
students.iloc[-1]     # Last row
students.iloc[0:2]    # First 2 rows
```

### By Label with `.loc[]`

```python
students.loc[0]       # Row with index 0
students.loc[0:2]     # Rows 0, 1, and 2 (inclusive!)
```

## Quick Example: Basketball Team

```python
team = pd.DataFrame({
    'Player': ['LeBron', 'Curry', 'Durant', 'Giannis'],
    'Points': [27, 30, 29, 28],
    'Team': ['Lakers', 'Warriors', 'Suns', 'Bucks']
})

print(team)
print()
print(f"Total rows: {len(team)}")
print(f"Columns: {list(team.columns)}")
print(f"Average points: {team['Points'].mean()}")
```

## Before and After: Dictionary to DataFrame

**Before (Dictionary):**
```python
data = {
    'Name': ['Alice', 'Bob'],
    'Score': [95, 88]
}
# Hard to view, no built-in analysis
```

**After (DataFrame):**
```
   Name  Score
0  Alice    95
1    Bob    88
# Easy to view, analyze, filter, and export!
```

## Common Mistakes

| Mistake | Problem | Fix |
|---------|---------|-----|
| `df['Name', 'Age']` | Wrong syntax | Use double brackets: `df[['Name', 'Age']]` |
| `df.columns()` | columns is not a method | Remove parentheses: `df.columns` |
| Unequal list lengths | All columns must have same length | Check your data |

## Try It Yourself

1. Create a DataFrame of your 5 favorite movies with: Title, Year, Rating
2. Use `.head(3)` to see the first 3
3. Get just the 'Title' column
4. Find the average Rating

## Key Takeaways

1. DataFrame = table with rows and columns
2. Create from dict: `pd.DataFrame({'col1': [...], 'col2': [...]})`
3. View with: `.head()`, `.tail()`, `.shape`, `.info()`
4. Single column: `df['column']`
5. Multiple columns: `df[['col1', 'col2']]`

---
*Next: Reading data from files!*
