# Data Types in Pandas

## Why Data Types Matter

Imagine trying to calculate the average of "85", "90", "75" - they look like numbers but might be stored as text! Pandas won't let you do math on text.

## Common Data Types

| Type | Name in Pandas | Examples |
|------|----------------|----------|
| Integer | `int64` | 1, 42, -5 |
| Decimal | `float64` | 3.14, 9.99 |
| Text | `object` | "Alice", "Hello" |
| True/False | `bool` | True, False |
| Date/Time | `datetime64` | 2024-01-15 |
| Category | `category` | "Red", "Blue", "Green" |

## Checking Data Types

```python
import pandas as pd

df = pd.DataFrame({
    'Name': ['Alice', 'Bob'],
    'Age': [15, 16],
    'Score': [85.5, 92.0],
    'Passed': [True, True]
})

# See all data types
print(df.dtypes)
```

**Output:**
```
Name       object
Age         int64
Score     float64
Passed       bool
dtype: object
```

## Converting Data Types

### Using astype()

```python
# Convert Age to float
df['Age'] = df['Age'].astype(float)

# Convert Score to integer
df['Score'] = df['Score'].astype(int)

# Convert to string
df['Age'] = df['Age'].astype(str)
```

### Converting to Numbers

```python
# pd.to_numeric - smart number conversion
df['Price'] = pd.to_numeric(df['Price'])

# Handle errors (when some values can't convert)
df['Price'] = pd.to_numeric(df['Price'], errors='coerce')  # Bad values become NaN
df['Price'] = pd.to_numeric(df['Price'], errors='ignore')  # Keep original if error
```

### Converting to Dates

```python
# pd.to_datetime - parse date strings
df['Date'] = pd.to_datetime(df['Date'])

# Specify format for speed
df['Date'] = pd.to_datetime(df['Date'], format='%Y-%m-%d')

# Common date formats:
# %Y-%m-%d = 2024-01-15
# %d/%m/%Y = 15/01/2024
# %m/%d/%Y = 01/15/2024
```

## Before and After Examples

### Example 1: Numbers Stored as Text

**Before:**
```
   Price
0   $100
1   $250
2   $175
dtype: object (text!)
```

**Code:**
```python
df['Price'] = df['Price'].str.replace('$', '').astype(float)
```

**After:**
```
   Price
0  100.0
1  250.0
2  175.0
dtype: float64
```

### Example 2: Dates as Text

**Before:**
```
      Date_String
0  January 15, 2024
1  February 20, 2024
dtype: object
```

**Code:**
```python
df['Date'] = pd.to_datetime(df['Date_String'])
```

**After:**
```
       Date
0 2024-01-15
1 2024-02-20
dtype: datetime64[ns]
```

## Working with Categories

Categories are great for data with repeated values (like colors, grades, etc.)

```python
# Convert to category
df['Grade'] = df['Grade'].astype('category')

# Benefits:
# 1. Uses less memory
# 2. Can define an order
df['Grade'] = pd.Categorical(df['Grade'], 
                             categories=['F', 'D', 'C', 'B', 'A'],
                             ordered=True)

# Now you can compare!
df[df['Grade'] > 'C']  # Gets B and A grades
```

## Quick Reference

| Task | Code |
|------|------|
| Check types | `df.dtypes` |
| Convert to int | `df['col'].astype(int)` |
| Convert to float | `df['col'].astype(float)` |
| Convert to string | `df['col'].astype(str)` |
| Smart number conversion | `pd.to_numeric(df['col'])` |
| Parse dates | `pd.to_datetime(df['col'])` |
| Convert to category | `df['col'].astype('category')` |

## Common Problems and Solutions

| Problem | Solution |
|---------|----------|
| "could not convert string to float" | Remove non-numeric characters first |
| Numbers have commas | `df['col'].str.replace(',', '')` then convert |
| Dates in wrong format | Use `format=` parameter in to_datetime |
| Float has .0 you don't want | Convert to int: `astype(int)` |

## Working with Date Types

Once you have datetime, you can extract parts:

```python
df['Date'] = pd.to_datetime(df['Date'])

df['Year'] = df['Date'].dt.year
df['Month'] = df['Date'].dt.month
df['Day'] = df['Date'].dt.day
df['DayOfWeek'] = df['Date'].dt.day_name()
```

## Common Mistakes

| Mistake | Problem | Fix |
|---------|---------|-----|
| `astype(int)` with NaN | Error - can't have NaN in int | Use float or `Int64` (nullable) |
| `astype(int)` with text | Error | Use `pd.to_numeric` first |
| Wrong date format | Parsing errors | Specify `format=` |

## Try It Yourself

1. Create a DataFrame with a "Price" column containing "$100", "$200"
2. Remove the "$" and convert to float
3. Create a "Date" column with dates as strings
4. Convert it to datetime

## Key Takeaways

1. Check types with `df.dtypes`
2. Convert with `astype(type)`
3. Smart number conversion: `pd.to_numeric()`
4. Parse dates: `pd.to_datetime()`
5. Categories save memory for repeated values
6. Use `errors='coerce'` to handle bad data

---
*Next: GroupBy operations - analyzing groups of data!*
