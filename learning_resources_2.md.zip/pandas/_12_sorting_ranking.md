# Sorting and Ranking

## Sorting Data

### Sort by One Column

```python
import pandas as pd

df = pd.DataFrame({
    'Name': ['Charlie', 'Alice', 'Bob', 'Diana'],
    'Score': [78, 92, 85, 88],
    'Age': [16, 15, 17, 15]
})
```

**Original:**
```
      Name  Score  Age
0  Charlie     78   16
1    Alice     92   15
2      Bob     85   17
3    Diana     88   15
```

```python
# Sort by Score (low to high)
df.sort_values('Score')
```

**Sorted by Score:**
```
      Name  Score  Age
0  Charlie     78   16
2      Bob     85   17
3    Diana     88   15
1    Alice     92   15
```

### Sort Descending (High to Low)

```python
df.sort_values('Score', ascending=False)
```

**Result:**
```
      Name  Score  Age
1    Alice     92   15
3    Diana     88   15
2      Bob     85   17
0  Charlie     78   16
```

### Sort by Multiple Columns

```python
# Sort by Age, then by Score (both ascending)
df.sort_values(['Age', 'Score'])

# Sort by Age ascending, Score descending
df.sort_values(['Age', 'Score'], ascending=[True, False])
```

### Sort by Index

```python
# Sort by row index
df.sort_index()

# Sort by column names
df.sort_index(axis=1)
```

## Ranking Data

Ranking assigns a position (1st, 2nd, 3rd...) based on values.

```python
df = pd.DataFrame({
    'Name': ['Alice', 'Bob', 'Charlie', 'Diana'],
    'Score': [92, 85, 78, 85]  # Note: Bob and Diana tied!
})

df['Rank'] = df['Score'].rank(ascending=False)
```

**Result:**
```
      Name  Score  Rank
0    Alice     92   1.0
1      Bob     85   2.5  <- Tied with Diana
2  Charlie     78   4.0
3    Diana     85   2.5  <- Tied with Bob
```

### Handling Ties

| Method | What It Does | Example (scores: 85, 85) |
|--------|--------------|--------------------------|
| `'average'` | Average of tied ranks (default) | 2.5, 2.5 |
| `'min'` | Lowest rank | 2, 2 |
| `'max'` | Highest rank | 3, 3 |
| `'first'` | By position in data | 2, 3 |
| `'dense'` | Like min, no gaps | 2, 2 (next is 3) |

```python
# Different methods
df['Rank_Min'] = df['Score'].rank(ascending=False, method='min')
df['Rank_Dense'] = df['Score'].rank(ascending=False, method='dense')
```

## Practical Examples

### Top N Values

```python
# Get top 3 scores
top_3 = df.nlargest(3, 'Score')

# Get bottom 3 scores
bottom_3 = df.nsmallest(3, 'Score')
```

### Percentile Rank

```python
# What percentile is each score?
df['Percentile'] = df['Score'].rank(pct=True) * 100
```

## Before and After Examples

### Example 1: Leaderboard

**Before (unsorted):**
```
    Player  Points
0    Alex     150
1  Jordan     200
2     Sam     175
3  Taylor     200
```

**Code:** `df.sort_values('Points', ascending=False)`

**After (sorted leaderboard):**
```
    Player  Points
1  Jordan     200
3  Taylor     200
2     Sam     175
0    Alex     150
```

### Example 2: Adding Rank Column

**Before:**
```
   Name  Score
0  Alice    92
1    Bob    85
2  Charlie  78
```

**Code:** `df['Rank'] = df['Score'].rank(ascending=False, method='dense').astype(int)`

**After:**
```
   Name  Score  Rank
0  Alice    92     1
1    Bob    85     2
2  Charlie  78     3
```

## Quick Reference

| Task | Code |
|------|------|
| Sort ascending | `df.sort_values('col')` |
| Sort descending | `df.sort_values('col', ascending=False)` |
| Sort by multiple | `df.sort_values(['col1', 'col2'])` |
| Sort index | `df.sort_index()` |
| Top N | `df.nlargest(n, 'col')` |
| Bottom N | `df.nsmallest(n, 'col')` |
| Add rank | `df['Rank'] = df['col'].rank()` |
| Rank high to low | `df['col'].rank(ascending=False)` |
| Dense ranking | `df['col'].rank(method='dense')` |

## Common Mistakes

| Mistake | Problem | Fix |
|---------|---------|-----|
| Sort doesn't stick | `sort_values()` returns new df | Assign back: `df = df.sort_values(...)` |
| Wrong order with multiple cols | Both ascending by default | Use `ascending=[True, False]` |
| Rank shows floats | Default behavior for ties | Use `.astype(int)` or `method='dense'` |

## Try It Yourself

1. Create a DataFrame with names and scores
2. Sort by score from highest to lowest
3. Get the top 3 students
4. Add a rank column
5. Try different ranking methods for ties

## Key Takeaways

1. `sort_values('col')` - sort by column
2. `ascending=False` - high to low
3. Multiple columns: `sort_values(['col1', 'col2'])`
4. `rank()` - add position numbers
5. Handle ties with `method='dense'` or `method='min'`
6. `nlargest()` and `nsmallest()` - quick top/bottom N

---
*Next: Apply functions to transform your data!*
