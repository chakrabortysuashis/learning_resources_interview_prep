# Adding and Removing Columns

## Adding New Columns

### Method 1: Direct Assignment

```python
import pandas as pd

df = pd.DataFrame({
    'Name': ['Alice', 'Bob', 'Charlie'],
    'Math': [85, 92, 78],
    'Science': [90, 88, 95]
})
```

**Before:**
```
      Name  Math  Science
0    Alice    85       90
1      Bob    92       88
2  Charlie    78       95
```

```python
# Add a new column with the same value for all rows
df['Grade'] = 'A'

# Add a column with calculated values
df['Average'] = (df['Math'] + df['Science']) / 2
```

**After:**
```
      Name  Math  Science Grade  Average
0    Alice    85       90     A     87.5
1      Bob    92       88     A     90.0
2  Charlie    78       95     A     86.5
```

### Method 2: Using assign()

Creates a new DataFrame (doesn't modify original).

```python
df_new = df.assign(
    Total = df['Math'] + df['Science'],
    Passed = df['Math'] >= 60
)
```

### Method 3: Insert at Specific Position

```python
# Insert 'ID' column at position 0 (first column)
df.insert(0, 'ID', [1, 2, 3])
```

**Result:**
```
   ID     Name  Math  Science
0   1    Alice    85       90
1   2      Bob    92       88
2   3  Charlie    78       95
```

## Adding Columns with Conditions

```python
# Add Pass/Fail based on score
df['Status'] = ['Pass' if x >= 60 else 'Fail' for x in df['Math']]

# Or using numpy
import numpy as np
df['Status'] = np.where(df['Math'] >= 60, 'Pass', 'Fail')
```

## Removing Columns

### Method 1: drop() - Recommended

```python
# Remove one column
df = df.drop('Grade', axis=1)

# Remove multiple columns
df = df.drop(['Grade', 'Average'], axis=1)

# Or use columns parameter
df = df.drop(columns=['Grade', 'Average'])
```

### Method 2: del - Permanent

```python
del df['Grade']  # Deletes immediately, can't undo!
```

### Method 3: pop() - Remove and Return

```python
# Remove column and save it to a variable
removed_column = df.pop('Grade')
```

## Renaming Columns

```python
# Rename specific columns
df = df.rename(columns={'Math': 'Math_Score', 'Science': 'Science_Score'})

# Rename all columns at once
df.columns = ['Student', 'Math', 'Sci']
```

## Reordering Columns

```python
# Specify new order
df = df[['Name', 'Science', 'Math']]  # Put Science before Math

# Move one column to the end
cols = [c for c in df.columns if c != 'Math'] + ['Math']
df = df[cols]
```

## Quick Reference

| Task | Code |
|------|------|
| Add column | `df['new_col'] = values` |
| Add calculated column | `df['sum'] = df['a'] + df['b']` |
| Add constant value | `df['status'] = 'Active'` |
| Insert at position | `df.insert(0, 'col', values)` |
| Remove column | `df.drop('col', axis=1)` |
| Remove multiple | `df.drop(['a', 'b'], axis=1)` |
| Delete permanently | `del df['col']` |
| Rename columns | `df.rename(columns={'old': 'new'})` |

## Before and After Examples

### Adding a Calculated Column

**Before:**
```
      Name  Price  Quantity
0   Apple    1.5        10
1  Banana    0.5        25
2  Orange    2.0         8
```

**Code:** `df['Total'] = df['Price'] * df['Quantity']`

**After:**
```
      Name  Price  Quantity  Total
0   Apple    1.5        10   15.0
1  Banana    0.5        25   12.5
2  Orange    2.0         8   16.0
```

### Removing a Column

**Before:**
```
   ID     Name  Score  Temp_Data
0   1    Alice     85      xxx
1   2      Bob     92      yyy
```

**Code:** `df = df.drop('Temp_Data', axis=1)`

**After:**
```
   ID     Name  Score
0   1    Alice     85
1   2      Bob     92
```

## Common Mistakes

| Mistake | Problem | Fix |
|---------|---------|-----|
| `df.drop('col')` | Missing axis | Add `axis=1` for columns |
| Forgetting `df = df.drop(...)` | drop() returns new df | Assign result back |
| `df['new'] = [1, 2]` with 3 rows | Length mismatch | Match number of rows |

## Try It Yourself

1. Create a DataFrame with Name, Math, and English scores
2. Add a 'Total' column (Math + English)
3. Add an 'Average' column
4. Add a 'Pass' column (True if Average >= 60)
5. Remove the 'Total' column

## Key Takeaways

1. Add column: `df['new_col'] = values`
2. Calculated column: `df['sum'] = df['a'] + df['b']`
3. Remove: `df.drop('col', axis=1)` or `df.drop(columns='col')`
4. `del df['col']` - permanent, no undo
5. Always remember `axis=1` means columns!

---
*Next: Handling missing data!*
