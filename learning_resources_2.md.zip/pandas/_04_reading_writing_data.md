# Reading and Writing Data

## Why Read from Files?

Real data comes from files, not typing everything by hand! Pandas can read:
- CSV files (like Excel exports)
- Excel files (.xlsx)
- JSON files (from web APIs)
- And many more!

## Reading CSV Files

CSV = Comma Separated Values. It's the most common data format.

### Basic Read

```python
import pandas as pd

# Read a CSV file
df = pd.read_csv('students.csv')
print(df)
```

### Common Parameters

```python
# Skip the first row (maybe it's a title, not headers)
df = pd.read_csv('data.csv', skiprows=1)

# Custom column names
df = pd.read_csv('data.csv', names=['Name', 'Age', 'Score'])

# Use a specific column as the index
df = pd.read_csv('data.csv', index_col='ID')

# Only read certain columns
df = pd.read_csv('data.csv', usecols=['Name', 'Score'])

# Handle missing values
df = pd.read_csv('data.csv', na_values=['N/A', 'missing', '-'])
```

## Writing CSV Files

```python
# Save DataFrame to CSV
df.to_csv('output.csv')

# Without the index column
df.to_csv('output.csv', index=False)

# With custom separator
df.to_csv('output.txt', sep='\t')  # Tab-separated
```

### Before and After: Saving Data

**Before (in Python only):**
```python
students = pd.DataFrame({...})
# Data exists only while program runs
```

**After (saved to file):**
```
students.csv is now on your computer!
You can open it in Excel, share it, or load it later.
```

## Reading Excel Files

```python
# Read Excel file (requires openpyxl: pip install openpyxl)
df = pd.read_excel('grades.xlsx')

# Read specific sheet
df = pd.read_excel('grades.xlsx', sheet_name='Sheet2')

# Read by sheet index (0 = first sheet)
df = pd.read_excel('grades.xlsx', sheet_name=0)
```

## Writing Excel Files

```python
# Save to Excel
df.to_excel('output.xlsx', index=False)

# Save multiple sheets
with pd.ExcelWriter('report.xlsx') as writer:
    df1.to_excel(writer, sheet_name='Students')
    df2.to_excel(writer, sheet_name='Grades')
```

## Reading JSON Files

JSON is common for web data and APIs.

```python
# Read JSON file
df = pd.read_json('data.json')

# Read from a URL
df = pd.read_json('https://api.example.com/data')
```

### JSON Format Example

```json
[
    {"Name": "Alice", "Age": 15, "Grade": "A"},
    {"Name": "Bob", "Age": 16, "Grade": "B"}
]
```

## Writing JSON Files

```python
# Save to JSON
df.to_json('output.json')

# Pretty format (readable)
df.to_json('output.json', indent=2, orient='records')
```

## Quick Reference Table

| Task | Code |
|------|------|
| Read CSV | `pd.read_csv('file.csv')` |
| Write CSV | `df.to_csv('file.csv', index=False)` |
| Read Excel | `pd.read_excel('file.xlsx')` |
| Write Excel | `df.to_excel('file.xlsx', index=False)` |
| Read JSON | `pd.read_json('file.json')` |
| Write JSON | `df.to_json('file.json')` |

## Common Mistakes

| Mistake | Problem | Fix |
|---------|---------|-----|
| File not found | Wrong path | Use full path or check filename |
| Encoding error | Special characters | Add `encoding='utf-8'` |
| Wrong delimiter | Data in one column | Use `sep=';'` or `sep='\t'` |
| Missing openpyxl | Excel error | `pip install openpyxl` |

## Try It Yourself

1. Create a DataFrame with your friends' info
2. Save it to a CSV file
3. Close Python and reopen
4. Read the CSV file back
5. Verify the data is the same!

```python
# Step 1-2: Create and save
friends = pd.DataFrame({
    'Name': ['Alex', 'Jordan', 'Sam'],
    'Age': [15, 16, 15]
})
friends.to_csv('my_friends.csv', index=False)

# Step 4: Read it back
loaded_friends = pd.read_csv('my_friends.csv')
print(loaded_friends)
```

## Key Takeaways

1. `pd.read_csv()` - Read CSV files
2. `df.to_csv()` - Save to CSV (use `index=False`)
3. `pd.read_excel()` - Read Excel (needs openpyxl)
4. `pd.read_json()` - Read JSON files
5. Always check your file path if you get errors!

---
*Next: Selecting specific data from your DataFrame!*
