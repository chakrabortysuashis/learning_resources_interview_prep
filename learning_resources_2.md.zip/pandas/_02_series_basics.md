# Series Basics

## What is a Series?

A Series is like a **single column** from a spreadsheet. It has:
- **Values** (the data)
- **Index** (labels for each value, like row numbers)

## Creating a Series

### From a List

```python
import pandas as pd

# Simple list of numbers
scores = pd.Series([95, 88, 76, 92])
print(scores)
```

**Output:**
```
0    95
1    88
2    76
3    92
dtype: int64
```

### With Custom Index

```python
# Using names as index instead of numbers
scores = pd.Series([95, 88, 76, 92], 
                   index=['Alice', 'Bob', 'Charlie', 'Diana'])
print(scores)
```

**Output:**
```
Alice      95
Bob        88
Charlie    76
Diana      92
dtype: int64
```

### From a Dictionary

```python
# Dictionary automatically uses keys as index
grades = pd.Series({
    'Math': 92,
    'Science': 88,
    'English': 95,
    'History': 79
})
print(grades)
```

## Accessing Values (Indexing)

### By Position (like a list)

```python
scores = pd.Series([95, 88, 76, 92])

print(scores[0])      # First value: 95
print(scores[2])      # Third value: 76
print(scores[-1])     # Last value: 92
```

### By Label (custom index)

```python
scores = pd.Series([95, 88, 76], index=['Alice', 'Bob', 'Charlie'])

print(scores['Alice'])     # 95
print(scores['Charlie'])   # 76
```

### Multiple Values

```python
# Get multiple values at once
print(scores[['Alice', 'Charlie']])
```

**Output:**
```
Alice      95
Charlie    76
dtype: int64
```

## Series Operations

### Math with Entire Series

```python
scores = pd.Series([80, 90, 70, 85])

# Add 5 bonus points to everyone
print(scores + 5)

# Double all scores
print(scores * 2)

# Check who passed (>= 75)
print(scores >= 75)
```

### Useful Methods

| Method       | What It Does                  | Example              |
|--------------|-------------------------------|----------------------|
| `.sum()`     | Add all values                | `scores.sum()`       |
| `.mean()`    | Average                       | `scores.mean()`      |
| `.max()`     | Highest value                 | `scores.max()`       |
| `.min()`     | Lowest value                  | `scores.min()`       |
| `.count()`   | Number of values              | `scores.count()`     |
| `.describe()`| Summary statistics            | `scores.describe()`  |

**Example:**
```python
scores = pd.Series([85, 92, 78, 95, 88])

print(f"Total: {scores.sum()}")      # 438
print(f"Average: {scores.mean()}")   # 87.6
print(f"Highest: {scores.max()}")    # 95
print(f"Lowest: {scores.min()}")     # 78
```

## Filtering a Series

```python
scores = pd.Series([85, 92, 78, 95, 60])

# Get only scores above 80
high_scores = scores[scores > 80]
print(high_scores)
```

**Output:**
```
0    85
1    92
3    95
dtype: int64
```

## Common Mistakes

| Mistake | Problem | Fix |
|---------|---------|-----|
| `scores[5]` when only 4 items | Index out of range | Check with `len(scores)` first |
| `scores['Alice']` with numeric index | KeyError | Use position `scores[0]` instead |
| Forgetting `pd.Series()` | Creates regular list | Always wrap with `pd.Series()` |

## Try It Yourself

1. Create a Series of your last 5 test scores
2. Find the average using `.mean()`
3. Filter to show only scores above 85
4. Add 3 bonus points to all scores

## Key Takeaways

1. Series = single column with index
2. Access by position `[0]` or label `['name']`
3. Math operations apply to all values
4. Use `.mean()`, `.sum()`, `.max()` for quick stats
5. Filter with `series[condition]`

---
*Next: DataFrames - working with full tables!*
