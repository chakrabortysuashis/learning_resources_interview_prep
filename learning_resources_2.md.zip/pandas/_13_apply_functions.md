# Apply Functions

## What is apply()?

`apply()` lets you run your own custom function on every row or column. It's like saying "do THIS to each value."

## The Three Methods

| Method | Works On | Use Case |
|--------|----------|----------|
| `apply()` | Series or DataFrame | Custom functions on columns/rows |
| `map()` | Series only | Transform each value |
| `applymap()` | DataFrame | Transform EVERY cell |

## Using apply() on a Series

```python
import pandas as pd

scores = pd.Series([75, 88, 92, 65, 78])

# Create a function
def pass_or_fail(score):
    if score >= 70:
        return 'Pass'
    else:
        return 'Fail'

# Apply it to each value
results = scores.apply(pass_or_fail)
```

**Before:**
```
0    75
1    88
2    92
3    65
4    78
```

**After:**
```
0    Pass
1    Pass
2    Pass
3    Fail
4    Pass
```

## Using Lambda Functions

Lambda = a quick one-line function.

```python
# Same as above, but shorter
scores.apply(lambda x: 'Pass' if x >= 70 else 'Fail')

# Add 10 bonus points
scores.apply(lambda x: x + 10)

# Convert to letter grade
scores.apply(lambda x: 'A' if x >= 90 else 'B' if x >= 80 else 'C' if x >= 70 else 'F')
```

## Using apply() on a DataFrame

### Apply to Each Column

```python
df = pd.DataFrame({
    'Math': [85, 92, 78],
    'Science': [90, 88, 95],
    'English': [88, 82, 90]
})

# Get the max of each column
df.apply(max)
```

**Result:**
```
Math       92
Science    95
English    90
```

### Apply to Each Row

```python
# Get the average of each student (row)
df.apply(lambda row: row.mean(), axis=1)
```

**Result:**
```
0    87.67
1    87.33
2    87.67
```

## Using map() on a Series

`map()` is great for replacing values based on a dictionary.

```python
grades = pd.Series(['A', 'B', 'A', 'C', 'B'])

# Map letter grades to numbers
grade_points = grades.map({'A': 4.0, 'B': 3.0, 'C': 2.0, 'D': 1.0, 'F': 0.0})
```

**Before:**
```
0    A
1    B
2    A
3    C
4    B
```

**After:**
```
0    4.0
1    3.0
2    4.0
3    2.0
4    3.0
```

## Using map() with Functions

```python
names = pd.Series(['alice', 'bob', 'charlie'])

# Capitalize each name
names.map(str.upper)
# Result: ['ALICE', 'BOB', 'CHARLIE']

# Custom function
names.map(lambda x: x.title())
# Result: ['Alice', 'Bob', 'Charlie']
```

## Real-World Examples

### Example 1: Grade Calculator

```python
df = pd.DataFrame({
    'Name': ['Alice', 'Bob', 'Charlie'],
    'Score': [92, 78, 85]
})

def get_grade(score):
    if score >= 90: return 'A'
    elif score >= 80: return 'B'
    elif score >= 70: return 'C'
    elif score >= 60: return 'D'
    else: return 'F'

df['Grade'] = df['Score'].apply(get_grade)
```

**Result:**
```
      Name  Score Grade
0    Alice     92     A
1      Bob     78     C
2  Charlie     85     B
```

### Example 2: Text Cleaning

```python
df = pd.DataFrame({
    'Email': ['ALICE@EMAIL.COM', 'bob@Email.COM', 'Charlie@email.com']
})

# Standardize to lowercase
df['Email_Clean'] = df['Email'].apply(str.lower)
```

### Example 3: Multiple Columns at Once

```python
df = pd.DataFrame({
    'First': ['John', 'Jane', 'Bob'],
    'Last': ['Doe', 'Smith', 'Jones']
})

# Create full name from row
df['Full_Name'] = df.apply(lambda row: f"{row['First']} {row['Last']}", axis=1)
```

**Result:**
```
  First   Last   Full_Name
0  John    Doe    John Doe
1  Jane  Smith  Jane Smith
2   Bob  Jones   Bob Jones
```

## apply() vs map() vs Vectorized

```python
# All three do the same thing:

# 1. Vectorized (fastest!)
df['doubled'] = df['Score'] * 2

# 2. apply()
df['doubled'] = df['Score'].apply(lambda x: x * 2)

# 3. map()
df['doubled'] = df['Score'].map(lambda x: x * 2)
```

**When to use which:**
- Simple math: Use vectorized operations (fastest)
- Complex logic: Use apply()
- Replace values from dict: Use map()

## Common Mistakes

| Mistake | Problem | Fix |
|---------|---------|-----|
| Forgetting `axis=1` | Applies to columns, not rows | Add `axis=1` for row operations |
| Complex function errors | Hard to debug | Test function separately first |
| Using apply when vectorized works | Slow | Use built-in operations when possible |

## Try It Yourself

1. Create a DataFrame with names and scores
2. Write a function to add letter grades
3. Use apply to add a 'Grade' column
4. Use map to convert grades to GPA points

## Key Takeaways

1. `apply()` - Run function on each column (or row with `axis=1`)
2. `map()` - Transform Series values (great with dictionaries)
3. Lambda functions - Quick one-liners: `lambda x: x * 2`
4. Prefer vectorized operations when possible (faster!)
5. Use `axis=1` to apply across rows instead of columns

---
*Next: Practice with real-world exercises!*
