param(
    [Parameter(Position=0)]
    [ValidateSet("opus", "sonnet")]
    [string]$Model = "sonnet"
)

# Enable Microsoft Foundry integration
$env:CLAUDE_CODE_USE_FOUNDRY = "1"

# Model configurations
$configs = @{
    "opus" = @{
        ApiKey = "45693962254144e09cfef75fd4093335"
        BaseUrl = "https://nprdpraiagents2309168131.services.ai.azure.com/anthropic"
    }
    "sonnet" = @{
        ApiKey = "3GK60kZufhpY82r2yJ2UFj4B2CoTdFKRBOxN2Gwr0ESq9u5X0xh3JQQJ99CHACYeBjFXJ3w3AAAAACOGale8"
        BaseUrl = "https://apprentice-ai.services.ai.azure.com/anthropic"
    }
}

# Set environment variables based on selected model
$env:ANTHROPIC_FOUNDRY_API_KEY = $configs[$Model].ApiKey
$env:ANTHROPIC_FOUNDRY_BASE_URL = $configs[$Model].BaseUrl

# Model deployment names
$env:ANTHROPIC_DEFAULT_SONNET_MODEL = "claude-sonnet-5"
$env:ANTHROPIC_DEFAULT_OPUS_MODEL = "claude-opus-4-5"

Write-Host "Switched to $($Model.ToUpper()) configuration!" -ForegroundColor Green
Write-Host "Base URL: $($configs[$Model].BaseUrl)" -ForegroundColor Cyan
