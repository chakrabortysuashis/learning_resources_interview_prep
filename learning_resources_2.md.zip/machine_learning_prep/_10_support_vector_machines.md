# Support Vector Machines (SVM)

## What is SVM?

Support Vector Machine is a **supervised learning algorithm** that finds the optimal hyperplane to separate classes with **maximum margin**.

```
                        y
                        │
                        │    ○  ○        ← Class 2
                        │      ○  ○
                        │    ○    ○
                        │         ╱────── Hyperplane
                        │       ╱
                        │     ╱  ○ ← Support Vector
                        │   ╱
                        │ ╱   ●  ← Support Vector
                        │●  ●
                        │  ●  ●          ← Class 1
                        │●    ●  ●
                        │
                        └────────────────────── x
```

---

## The Maximum Margin Principle

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Why Maximum Margin?                                       │
│                                                             │
│   Small Margin:              Large Margin:                  │
│                                                             │
│    ○ ○   ╱   ● ●              ○ ○       ● ●                 │
│      ○  ╱  ●                    ○     ╱   ●                 │
│        ╱ ●                         ╱ ╱ ╱     ●              │
│       ╱                          ╱ ╱ ╱                      │
│                               Margin                        │
│                                                             │
│   Less robust to             More robust, better            │
│   new data points            generalization                 │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Mathematical Formulation

### Linear SVM

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Hyperplane: w·x + b = 0                                   │
│                                                             │
│   Decision boundaries:                                      │
│     w·x + b = +1   (positive class boundary)                │
│     w·x + b = -1   (negative class boundary)                │
│                                                             │
│   Margin width = 2 / ||w||                                  │
│                                                             │
│   GOAL: Maximize 2/||w||  ⟺  Minimize ||w||²/2             │
│                                                             │
│   Subject to: yᵢ(w·xᵢ + b) ≥ 1  for all samples            │
│               (all samples on correct side)                 │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Visual: Margin and Support Vectors

```
                            w·x + b = +1
                               ╱
              ○  ○           ╱    Margin = 2/||w||
                ○          ╱    ◄──────────────────►
                  ◉ ← ───╱───── w·x + b = 0 (hyperplane)
                       ╱
                     ╱───── w·x + b = -1
                   ╱
                ◉ ← Support Vector
               ●  ●
             ●    ●
             
    ◉ = Support Vectors (points ON the margin)
    Only these matter for the decision boundary!
```

---

## Soft Margin SVM (C Parameter)

Real data isn't always linearly separable. Soft margin allows some misclassification.

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Objective: Minimize  ½||w||² + C × Σξᵢ                    │
│                                                             │
│   Where:                                                    │
│     ξᵢ = slack variable (how far point violates margin)     │
│     C = regularization parameter                            │
│                                                             │
│   Subject to: yᵢ(w·xᵢ + b) ≥ 1 - ξᵢ                        │
│               ξᵢ ≥ 0                                        │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Effect of C Parameter

```
Small C (soft margin):              Large C (hard margin):

     ○  ○    ╱   ●                       ○  ○  ╱ ●
       ○   ╱      ●                        ○ ╱    ●
         ╱   ●                           ╱    ●
       ╱    ← allows violations        ╱●
      ● ╱                              ╱ ← tries to classify
                                           all correctly
                                           
    Wider margin                     Narrower margin
    More regularization              Less regularization
    May underfit                     May overfit
```

---

## The Kernel Trick

### Why Kernels?

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Problem: Data not linearly separable in original space    │
│                                                             │
│   Original Space:                  Higher Dimension:        │
│                                                             │
│       │  ●●●●                          │        ● ● ●       │
│       │ ○○○○○○                         │       ○○○○○○       │
│       │  ●●●●                          │  ●●●●              │
│       └─────────                       └─────────────       │
│                                                             │
│   Can't separate with             Can separate with         │
│   a line!                         a hyperplane!             │
│                                                             │
└─────────────────────────────────────────────────────────────┘

The Kernel Trick: Compute inner products in high-dimensional
space WITHOUT actually transforming the data!

    K(x, x') = φ(x)·φ(x')
    
    We never compute φ(x) explicitly - just the inner product!
```

### Common Kernels

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   LINEAR KERNEL:                                            │
│   K(x, x') = x·x'                                           │
│   Use when: Data is linearly separable, high dimensions     │
│                                                             │
│   POLYNOMIAL KERNEL:                                        │
│   K(x, x') = (γ·x·x' + r)ᵈ                                  │
│   Use when: Interaction between features matters            │
│   Parameters: degree d, gamma γ, coef r                     │
│                                                             │
│   RBF (GAUSSIAN) KERNEL:  ← Most popular!                   │
│   K(x, x') = exp(-γ||x - x'||²)                             │
│   Use when: No prior knowledge, non-linear boundary         │
│   Parameters: gamma γ (inverse of radius)                   │
│                                                             │
│   SIGMOID KERNEL:                                           │
│   K(x, x') = tanh(γ·x·x' + r)                               │
│   Similar to neural network                                 │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### RBF Kernel: Gamma Effect

```
Small γ (large radius):             Large γ (small radius):

       ○○         ●●                      ○○         ●●
      ○○○        ●●●                     ○○○        ●●●
     (    smooth    )                   (complex boundary)
      ╲            ╱                     ╲  ╱╲  ╱╲  ╱
       ╲          ╱                       ╲╱  ╲╱  ╲╱
        ╲        ╱                        
                                         
    Smoother decision                Complex, wiggly
    boundary (underfit)              boundary (overfit)
```

---

## SVM for Multiclass

SVM is inherently binary. For multiclass:

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   ONE-VS-REST (OVR):                                        │
│   • Train K classifiers: Class k vs all others              │
│   • Predict: Class with highest score                       │
│   • K classifiers for K classes                             │
│                                                             │
│   ONE-VS-ONE (OVO):                                         │
│   • Train K(K-1)/2 classifiers: Each pair of classes        │
│   • Predict: Majority voting                                │
│   • More classifiers, but each trained on less data         │
│                                                             │
└─────────────────────────────────────────────────────────────┘

Example with 3 classes (A, B, C):

OVR:                        OVO:
├── A vs (B,C)              ├── A vs B
├── B vs (A,C)              ├── A vs C
└── C vs (A,B)              └── B vs C

3 classifiers               3 classifiers
```

---

## SVM for Regression (SVR)

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Instead of maximizing margin between classes,             │
│   create an ε-tube around predictions                       │
│                                                             │
│        y                                                    │
│        │     ●                                              │
│        │   ●   ╱──────── ε-tube                            │
│        │  ● ╱ε╱●                                            │
│        │ ╱──╱●                                              │
│        │╱ε╱                                                 │
│        │╱   ●                                               │
│        │  ●                                                 │
│        └────────────────── x                                │
│                                                             │
│   Goal: Fit line with most points inside ε-tube             │
│   Points outside contribute to loss                         │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Advantages and Disadvantages

```
┌─────────────────────────────────────────────────────────────┐
│   ✅ ADVANTAGES                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│   • Effective in high-dimensional spaces                    │
│   • Works well when dimensions > samples                    │
│   • Memory efficient (only support vectors stored)          │
│   • Versatile (different kernel functions)                  │
│   • Robust to overfitting in high dimensions                │
│                                                             │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│   ❌ DISADVANTAGES                                          │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│   • Slow for large datasets O(n² to n³)                    │
│   • Sensitive to feature scaling                            │
│   • Choosing right kernel is tricky                         │
│   • Not directly provides probabilities                     │
│   • Difficult to interpret (black box)                      │
│   • Poor with noisy data (overlapping classes)              │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Key Hyperparameters

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   C (Regularization):                                       │
│   • Small C: More regularization, wider margin              │
│   • Large C: Less regularization, smaller margin            │
│   • Default: 1.0                                            │
│                                                             │
│   kernel:                                                   │
│   • 'linear': Linear decision boundary                      │
│   • 'rbf': Non-linear (default, most common)                │
│   • 'poly': Polynomial features                             │
│                                                             │
│   gamma (for RBF/poly):                                     │
│   • Small: Large radius, smooth boundary                    │
│   • Large: Small radius, complex boundary                   │
│   • 'scale': 1/(n_features × X.var())                       │
│   • 'auto': 1/n_features                                    │
│                                                             │
│   degree (for poly):                                        │
│   • Degree of polynomial kernel                             │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Python Implementation

```python
from sklearn.svm import SVC, SVR
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.pipeline import Pipeline
import numpy as np

# IMPORTANT: Always scale features for SVM!
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Linear SVM
svm_linear = SVC(kernel='linear', C=1.0)
svm_linear.fit(X_train_scaled, y_train)

# RBF SVM
svm_rbf = SVC(kernel='rbf', C=1.0, gamma='scale')
svm_rbf.fit(X_train_scaled, y_train)

# Get support vectors
print(f"Number of support vectors: {len(svm_rbf.support_vectors_)}")

# Probabilities (requires probability=True)
svm_proba = SVC(kernel='rbf', probability=True)
svm_proba.fit(X_train_scaled, y_train)
probabilities = svm_proba.predict_proba(X_test_scaled)

# Pipeline (recommended approach)
pipe = Pipeline([
    ('scaler', StandardScaler()),
    ('svm', SVC(kernel='rbf'))
])

# Hyperparameter tuning
param_grid = {
    'svm__C': [0.1, 1, 10, 100],
    'svm__gamma': ['scale', 'auto', 0.1, 0.01]
}

grid_search = GridSearchCV(pipe, param_grid, cv=5, scoring='accuracy')
grid_search.fit(X_train, y_train)

print(f"Best parameters: {grid_search.best_params_}")
print(f"Best CV score: {grid_search.best_score_:.3f}")

# SVR (Regression)
svr = SVR(kernel='rbf', C=1.0, epsilon=0.1)
svr.fit(X_train_scaled, y_train_continuous)
```

### Decision Boundary Visualization

```python
import matplotlib.pyplot as plt
import numpy as np

def plot_decision_boundary(model, X, y):
    # Create mesh grid
    x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
    y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    xx, yy = np.meshgrid(np.arange(x_min, x_max, 0.02),
                         np.arange(y_min, y_max, 0.02))
    
    # Predict on mesh
    Z = model.predict(np.c_[xx.ravel(), yy.ravel()])
    Z = Z.reshape(xx.shape)
    
    # Plot
    plt.contourf(xx, yy, Z, alpha=0.4)
    plt.scatter(X[:, 0], X[:, 1], c=y, edgecolors='k')
    
    # Mark support vectors
    plt.scatter(model.support_vectors_[:, 0],
                model.support_vectors_[:, 1],
                s=100, facecolors='none', edgecolors='k',
                linewidths=2, label='Support Vectors')
    plt.legend()
    plt.show()
```

---

## Interview Questions

### Q1: What are support vectors?
**Answer:** Support vectors are the data points that lie closest to the decision boundary (on the margin). They are the critical elements that define the hyperplane. Removing other points wouldn't change the decision boundary, but removing support vectors would.

### Q2: Why is feature scaling important for SVM?
**Answer:** SVM uses distances to compute margins. Features on larger scales will dominate the distance calculation, leading to poor decision boundaries. Scaling ensures all features contribute equally.

### Q3: How do you choose between different kernels?
**Answer:**
- **Linear:** Start here for high-dimensional data or when n_features > n_samples
- **RBF:** Default choice for non-linear data, works well in most cases
- **Polynomial:** When feature interactions matter
- Use cross-validation to compare

### Q4: What happens when C is very large or very small?
**Answer:**
- **Large C:** Tries to classify all points correctly, may overfit (hard margin)
- **Small C:** Allows more misclassification, wider margin, may underfit (soft margin)

### Q5: How does SVM handle multiclass classification?
**Answer:** Using One-vs-Rest (OVR) or One-vs-One (OVO) strategies. OVR trains K classifiers (one per class vs all others). OVO trains K(K-1)/2 classifiers (each pair of classes).

---

## Quick Reference

```
┌─────────────────────────────────────────────────────────────┐
│                   SVM CHEAT SHEET                           │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  CORE IDEA                                                  │
│  • Find hyperplane with maximum margin                      │
│  • Only support vectors matter                              │
│                                                             │
│  KEY PARAMETERS                                             │
│  C:     Regularization (small=soft, large=hard margin)      │
│  gamma: RBF influence (small=smooth, large=complex)         │
│  kernel: linear, rbf (default), poly                        │
│                                                             │
│  PREPROCESSING                                              │
│  • ALWAYS scale features (StandardScaler)                   │
│                                                             │
│  WHEN TO USE                                                │
│  • High-dimensional data                                    │
│  • Clear margin of separation                               │
│  • Medium-sized datasets (slow for large)                   │
│                                                             │
│  KERNEL CHOICE                                              │
│  • Linear: n_features >> n_samples                          │
│  • RBF: Default, most cases                                 │
│  • Poly: Feature interactions                               │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```
