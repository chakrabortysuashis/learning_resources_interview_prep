# Bias-Variance Tradeoff

## Understanding the Tradeoff

The bias-variance tradeoff is a fundamental concept that explains the **sources of prediction error** in machine learning models.

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Total Error = Bias² + Variance + Irreducible Error        │
│                                                             │
│   • Bias: Error from wrong assumptions (systematic)         │
│   • Variance: Error from sensitivity to training data       │
│   • Irreducible: Noise inherent in the problem              │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Visual: Target Analogy

```
                    LOW VARIANCE              HIGH VARIANCE
                 (Consistent shots)        (Scattered shots)
              
              ┌───────────────────┐    ┌───────────────────┐
              │         ┌─┐       │    │     ●         ●   │
  LOW         │         │●│       │    │           ●       │
  BIAS        │         │●│       │    │       ●     ●     │
  (Accurate)  │         │●│       │    │         ●         │
              │         └─┘       │    │                   │
              │      (Center)     │    │    (Around center)│
              └───────────────────┘    └───────────────────┘
                    IDEAL!              OVERFITTING
              
              ┌───────────────────┐    ┌───────────────────┐
              │     ┌─┐           │    │  ●            ●   │
  HIGH        │     │●│           │    │       ●           │
  BIAS        │     │●│           │    │   ●               │
  (Off-target)│     │●│           │    │         ●     ●   │
              │     └─┘           │    │                   │
              │  (Off to side)    │    │   (All over)      │
              └───────────────────┘    └───────────────────┘
                 UNDERFITTING         WORST CASE
```

---

## Mathematical Definition

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   For a model f̂ predicting target y = f(x) + ε:             │
│                                                             │
│   Expected Error:                                           │
│   E[(y - f̂(x))²] = [Bias(f̂(x))]² + Var(f̂(x)) + σ²          │
│                                                             │
│   where:                                                    │
│   • Bias(f̂(x)) = E[f̂(x)] - f(x)                            │
│     "How far is average prediction from true value?"        │
│                                                             │
│   • Var(f̂(x)) = E[(f̂(x) - E[f̂(x)])²]                       │
│     "How much do predictions vary across datasets?"         │
│                                                             │
│   • σ² = Var(ε)                                             │
│     "Irreducible noise in the data"                         │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## The Tradeoff Curve

```
     Error
        │
        │                             
        │ ╲                        ╱
        │  ╲                      ╱
        │   ╲                    ╱
        │    ╲  Total Error     ╱
        │     ╲               ╱
        │      ╲    ╱╲       ╱  Variance
        │       ╲  ╱  ╲     ╱
        │        ╲╱    ╲   ╱
        │        ╱╲     ╲ ╱
        │       ╱  ╲     ●  ← Optimal Complexity
        │      ╱    ╲   ╱
        │     ╱      ╲ ╱
        │    ╱  Bias  ╲
        │   ╱          ╲
        │  ╱            ╲
        └─────────────────────────────────────────
             Simple                Complex
                    Model Complexity
                    
        ←─ UNDERFITTING ─→←─── OVERFITTING ───→
           High Bias            High Variance
           Low Variance         Low Bias
```

---

## Underfitting vs Overfitting

### Underfitting (High Bias)

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Model is too SIMPLE to capture the underlying pattern     │
│                                                             │
│   True relationship: y = x² + noise                         │
│                                                             │
│        y                                                    │
│        │              ●                                     │
│        │           ●     ●                                  │
│        │       ●           ●                                │
│        │  ●─────────────────── Linear model                 │
│        │●                      (can't capture curve)        │
│        └────────────────────────── x                        │
│                                                             │
│   Symptoms:                                                 │
│   • High training error                                     │
│   • High test error                                         │
│   • Simple model, few parameters                            │
│                                                             │
│   Solutions:                                                │
│   • Use more complex model                                  │
│   • Add more features                                       │
│   • Reduce regularization                                   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Overfitting (High Variance)

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Model is too COMPLEX, fits noise in training data         │
│                                                             │
│   True relationship: y = x² + noise                         │
│                                                             │
│        y                                                    │
│        │        ╱╲    ●                                     │
│        │      ●╱  ╲  ╱●                                     │
│        │     ╱     ╲╱   ╲●                                  │
│        │   ●╱            ╲                                  │
│        │  ╱  Overfit model (wiggly, follows noise)          │
│        └────────────────────────── x                        │
│                                                             │
│   Symptoms:                                                 │
│   • Low training error                                      │
│   • High test error (gap between train/test)                │
│   • Complex model, many parameters                          │
│                                                             │
│   Solutions:                                                │
│   • More training data                                      │
│   • Regularization (L1, L2, dropout)                        │
│   • Simpler model                                           │
│   • Cross-validation                                        │
│   • Early stopping                                          │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Learning Curves

Learning curves show how training and validation error change with training set size.

### High Bias (Underfitting)

```
     Error
        │
        │●●●●●●●●●●●●●●●●●●●●●●●●●  Validation error
        │                            (high, plateaus)
        │
        │○○○○○○○○○○○○○○○○○○○○○○○○○  Training error
        │                            (high, similar to val)
        │
        └─────────────────────────────────────────
              Training Set Size
              
    • Both errors converge to HIGH value
    • Gap between them is SMALL
    • More data WON'T help much
    • Need more complex model
```

### High Variance (Overfitting)

```
     Error
        │
        │●                          Validation error
        │ ●                          (high initially)
        │  ●●
        │    ●●●
        │       ●●●●●●●●●●●●●●●●●●  (decreases with data)
        │
        │○○○○○○○○○○○○○○○○○○○○○○○○○  Training error
        │                            (low, big gap)
        │
        └─────────────────────────────────────────
              Training Set Size
              
    • Large GAP between train and validation
    • Training error is LOW
    • Validation error DECREASES with more data
    • More data WILL help!
```

### Good Fit

```
     Error
        │
        │●                          
        │ ●●
        │   ●●●●●●●●●●●●●●●●●●●●●  Validation error
        │                           (converges to low)
        │○○○○
        │    ○○○○○○○○○○○○○○○○○○○○  Training error
        │                           (small gap)
        │
        └─────────────────────────────────────────
              Training Set Size
              
    • Both converge to LOW value
    • Small gap between them
    • Sweet spot achieved!
```

---

## Model Complexity Examples

```
┌─────────────────────────────────────────────────────────────┐
│                    MODEL COMPLEXITY SPECTRUM                │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  SIMPLE (High Bias)           COMPLEX (High Variance)       │
│  ←──────────────────────────────────────────────────→       │
│                                                             │
│  Linear Regression            Polynomial (degree 15)        │
│  Single Decision Stump        Deep Decision Tree            │
│  Logistic Regression          Neural Net (many layers)      │
│  1-Nearest Neighbor           1-Nearest Neighbor*           │
│  High Regularization          Low/No Regularization         │
│                                                             │
│  *Note: KNN is special - K=1 has HIGH variance,            │
│         K=N has HIGH bias                                   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Polynomial Regression Example

```
Data: y = x² + noise

Degree 1 (Underfit):      Degree 2 (Just Right):    Degree 15 (Overfit):
      y                         y                         y
      │                         │                         │  ╱╲
      │    ●  ●                 │      ●                  │ ●  ●╲
      │  ●      ●               │   ●     ●               │╱    ╲●
      │●          ●             │  ●       ●              ●
      │──────────────           │ ●─────────●             │
      └────────────             └────────────             └────────────
           x                         x                         x
           
      High Bias                 Low Bias                  Low Bias
      Low Variance              Low Variance              High Variance
      
      Train Error: HIGH         Train Error: LOW          Train Error: VERY LOW
      Test Error: HIGH          Test Error: LOW           Test Error: HIGH
```

---

## Strategies to Balance Bias-Variance

### Reducing Bias (Fix Underfitting)

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│  1. Increase model complexity                               │
│     • More layers/neurons (neural nets)                     │
│     • Higher polynomial degree                              │
│     • Deeper trees                                          │
│                                                             │
│  2. Add more features                                       │
│     • Feature engineering                                   │
│     • Polynomial features                                   │
│     • Interaction terms                                     │
│                                                             │
│  3. Reduce regularization                                   │
│     • Lower λ in Ridge/Lasso                                │
│     • Lower dropout rate                                    │
│                                                             │
│  4. Train longer                                            │
│     • More epochs                                           │
│     • Until convergence                                     │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Reducing Variance (Fix Overfitting)

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│  1. Get more training data                                  │
│     • Most effective solution                               │
│     • Data augmentation                                     │
│                                                             │
│  2. Reduce model complexity                                 │
│     • Fewer parameters                                      │
│     • Shallower networks/trees                              │
│     • Feature selection                                     │
│                                                             │
│  3. Add regularization                                      │
│     • L1/L2 regularization                                  │
│     • Dropout                                               │
│     • Batch normalization                                   │
│                                                             │
│  4. Early stopping                                          │
│     • Stop when validation error increases                  │
│                                                             │
│  5. Ensemble methods                                        │
│     • Bagging (Random Forest)                               │
│     • Reduces variance through averaging                    │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Ensemble Methods and Bias-Variance

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   BAGGING (Bootstrap Aggregating)                           │
│   ─────────────────────────────                             │
│   • Train multiple models on different subsets              │
│   • Average predictions                                     │
│   • REDUCES VARIANCE (keeps bias same)                      │
│   • Example: Random Forest                                  │
│                                                             │
│   Model1 ─┐                                                 │
│   Model2 ─┼─→ Average ─→ Final Prediction                   │
│   Model3 ─┘                                                 │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│   BOOSTING                                                  │
│   ────────                                                  │
│   • Train models sequentially, focus on errors              │
│   • Each model corrects previous mistakes                   │
│   • REDUCES BIAS (may increase variance slightly)           │
│   • Example: XGBoost, AdaBoost                              │
│                                                             │
│   Model1 ─→ errors ─→ Model2 ─→ errors ─→ Model3 ─→ ...    │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Python: Diagnosing Bias-Variance

```python
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import learning_curve
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures
from sklearn.pipeline import make_pipeline

def plot_learning_curve(estimator, X, y, title):
    """Plot learning curves to diagnose bias-variance"""
    train_sizes, train_scores, val_scores = learning_curve(
        estimator, X, y, 
        train_sizes=np.linspace(0.1, 1.0, 10),
        cv=5, scoring='neg_mean_squared_error'
    )
    
    train_mean = -train_scores.mean(axis=1)
    train_std = train_scores.std(axis=1)
    val_mean = -val_scores.mean(axis=1)
    val_std = val_scores.std(axis=1)
    
    plt.figure(figsize=(10, 6))
    plt.plot(train_sizes, train_mean, label='Training error')
    plt.plot(train_sizes, val_mean, label='Validation error')
    plt.fill_between(train_sizes, train_mean - train_std, 
                     train_mean + train_std, alpha=0.1)
    plt.fill_between(train_sizes, val_mean - val_std, 
                     val_mean + val_std, alpha=0.1)
    plt.xlabel('Training Set Size')
    plt.ylabel('Error')
    plt.title(title)
    plt.legend()
    plt.show()

# Generate data
np.random.seed(42)
X = np.linspace(0, 10, 100).reshape(-1, 1)
y = 2*X.ravel()**2 + np.random.randn(100) * 10

# High Bias model
linear_model = LinearRegression()
plot_learning_curve(linear_model, X, y, "Linear Model (High Bias)")

# Good model
poly2_model = make_pipeline(PolynomialFeatures(2), LinearRegression())
plot_learning_curve(poly2_model, X, y, "Polynomial Degree 2 (Good Fit)")

# High Variance model
poly15_model = make_pipeline(PolynomialFeatures(15), LinearRegression())
plot_learning_curve(poly15_model, X, y, "Polynomial Degree 15 (High Variance)")
```

---

## Interview Questions

### Q1: Explain the bias-variance tradeoff in simple terms.
**Answer:** Bias is error from oversimplification (model can't capture pattern). Variance is error from over-sensitivity to training data (model captures noise). Simple models have high bias, low variance. Complex models have low bias, high variance. The goal is finding the sweet spot that minimizes total error.

### Q2: You trained a model with low training error but high test error. What's happening?
**Answer:** This is classic overfitting (high variance). The model memorized training data including noise, but doesn't generalize. Solutions: more data, regularization, simpler model, dropout, early stopping.

### Q3: How do ensemble methods affect bias and variance?
**Answer:**
- **Bagging** (e.g., Random Forest): Reduces variance by averaging multiple models
- **Boosting** (e.g., XGBoost): Reduces bias by sequentially correcting errors
- Both can achieve low bias AND low variance when tuned properly

### Q4: How can you diagnose whether your model has high bias or high variance?
**Answer:** Plot learning curves:
- **High bias:** Both training and validation errors are high, similar, and plateau early
- **High variance:** Low training error, high validation error, large gap between them

### Q5: Why does adding more data help with overfitting but not underfitting?
**Answer:** More data gives the model more examples of the true pattern, making it harder to memorize noise (reduces variance). However, if the model is too simple, it can't capture the pattern regardless of how much data you provide (bias remains high).

---

## Quick Reference

```
┌─────────────────────────────────────────────────────────────┐
│             BIAS-VARIANCE CHEAT SHEET                       │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  SYMPTOMS                                                   │
│  ────────                                                   │
│  High Bias:     Train error ≈ Val error (both HIGH)         │
│  High Variance: Train error << Val error (big GAP)          │
│  Good Fit:      Train error ≈ Val error (both LOW)          │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  FIXES                                                      │
│  ─────                                                      │
│  High Bias:     More features, complex model, less reg      │
│  High Variance: More data, regularization, simpler model    │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ENSEMBLE EFFECTS                                           │
│  ────────────────                                           │
│  Bagging:   ↓ Variance (averaging)                          │
│  Boosting:  ↓ Bias (sequential error correction)            │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```
