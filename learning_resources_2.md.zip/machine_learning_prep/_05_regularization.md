# Regularization

## What is Regularization?

Regularization is a technique to **prevent overfitting** by adding a penalty term to the cost function, discouraging complex models.

```
                Without Regularization           With Regularization
                   (Overfitting)                 (Just Right)
    y               y                              y
    │     ●        │      ●                        │      ●
    │    /╲ ●      │    / ╲ ●                      │     ╱  ╲●
    │   ●  ╲       │   ●   ╲                       │   ●     ╲
    │  /    ●╲     │  /     ●╲                     │  /       ●
    │ ●      ╲ ●   │ ●       ╲●                    │ ●         ●
    │/        ╲    │/          ╲                   │/           
    └────────────  └────────────                   └────────────
         x              x                               x
    
    Complex model            Simpler, smoother curve
    follows noise            captures true pattern
```

---

## The Bias-Variance Tradeoff

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Total Error = Bias² + Variance + Irreducible Error        │
│                                                             │
│   BIAS: Error from wrong assumptions (underfitting)         │
│         → High bias = model too simple                      │
│                                                             │
│   VARIANCE: Error from sensitivity to training data         │
│         → High variance = model too complex (overfitting)   │
│                                                             │
└─────────────────────────────────────────────────────────────┘

    Error
      │
      │ ╲  Total Error    ╱
      │  ╲               ╱
      │   ╲             ╱ Variance
      │    ╲    ╱╲     ╱
      │     ╲  ╱  ╲   ╱
      │      ╲╱    ╲ ╱
      │      ╱╲     ●  ← Optimal (sweet spot)
      │     ╱  ╲   ╱
      │    ╱ Bias╲╱
      │   ╱
      └────────────────────────────── Model Complexity
          Simple          Complex
```

### Visual: Bias vs Variance

```
                    High Bias              Low Bias
                    (Underfitting)         (Well-fitted)
                    
               ┌────────────────┐    ┌────────────────┐
   Low         │  ○             │    │       ●        │
   Variance    │     ○          │    │      ● ●       │
               │  ○    ○        │    │     ● ● ●      │
               │       ⊕ center │    │       ⊕        │
               └────────────────┘    └────────────────┘
               Consistent but         Consistent AND
               wrong (misses target)  accurate (hits target)
               
               ┌────────────────┐    ┌────────────────┐
   High        │●      ○        │    │    ●     ○     │
   Variance    │           ○    │    │  ○    ●        │
               │   ○            │    │      ○    ●    │
               │      ⊕    ○    │    │    ●   ⊕   ○   │
               └────────────────┘    └────────────────┘
               Scattered AND         Scattered around
               wrong                 the target (overfitting)
```

---

## Types of Regularization

### L2 Regularization (Ridge / Weight Decay)

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   J_ridge = J(w) + λ × Σ wⱼ²                                │
│                      j                                      │
│                                                             │
│   where:                                                    │
│     J(w) = original cost function                           │
│     λ    = regularization strength (hyperparameter)         │
│     wⱼ   = model weights                                    │
│                                                             │
│   Effect:                                                   │
│   • Shrinks weights toward zero (but not exactly zero)      │
│   • All features retained, but with smaller coefficients    │
│   • Handles multicollinearity well                          │
│                                                             │
└─────────────────────────────────────────────────────────────┘

Geometric Interpretation:
        w₂
         │      Original loss contours
         │    ╱  (elliptical)
         │  ╱   
         │╱     ● Original optimum
      ───●──────────── w₁
         │╲   
         │  ╲  ● Ridge optimum (closer to origin)
         │    ╲
         │      L2 constraint (circle)
```

### L1 Regularization (Lasso)

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   J_lasso = J(w) + λ × Σ |wⱼ|                               │
│                       j                                     │
│                                                             │
│   Effect:                                                   │
│   • Can make weights EXACTLY zero                           │
│   • Performs automatic feature selection                    │
│   • Produces sparse models                                  │
│                                                             │
└─────────────────────────────────────────────────────────────┘

Geometric Interpretation:
        w₂
         │      Original loss contours
         │    ╱
         │  ╱   ● Original optimum
         │╱    
      ───◇──────────── w₁  ← Lasso tends to hit corners
         │╲                  (makes weights exactly 0)
         │  ╲  
         │    ╲
         │      L1 constraint (diamond)
```

### Elastic Net (L1 + L2)

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   J_elastic = J(w) + λ₁ Σ|wⱼ| + λ₂ Σwⱼ²                    │
│                                                             │
│   Or equivalently:                                          │
│   J = J(w) + λ[α Σ|wⱼ| + (1-α) Σwⱼ²]                       │
│                                                             │
│   where α ∈ [0,1] balances L1 and L2                        │
│                                                             │
│   Benefits:                                                 │
│   • Feature selection (from L1)                             │
│   • Handles correlated features (from L2)                   │
│   • More flexible                                           │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Comparison: L1 vs L2

```
┌─────────────────────────────────────────────────────────────┐
│                     L1 vs L2 COMPARISON                     │
├──────────────────┬──────────────────────┬───────────────────┤
│     Aspect       │    L1 (Lasso)        │   L2 (Ridge)      │
├──────────────────┼──────────────────────┼───────────────────┤
│ Penalty term     │ λ Σ|wⱼ|              │ λ Σwⱼ²            │
│ Geometry         │ Diamond (L1 norm)    │ Circle (L2 norm)  │
│ Solution         │ Sparse (zeros)       │ Dense (small)     │
│ Feature select   │ Yes (automatic)      │ No                │
│ Correlated feats │ Selects one          │ Shrinks all       │
│ Stability        │ Less stable          │ More stable       │
│ Computation      │ No closed form       │ Has closed form   │
│ Use case         │ Feature selection    │ Prevent overfit   │
└──────────────────┴──────────────────────┴───────────────────┘
```

### Example: Coefficient Shrinkage

```
Original coefficients:    w = [4.5, 3.2, 0.1, 2.8, 0.05]

After L2 (λ=0.5):         w = [3.6, 2.6, 0.08, 2.2, 0.04]
                          (All shrunk proportionally)

After L1 (λ=0.5):         w = [3.8, 2.5, 0.0, 2.1, 0.0]
                          (Small weights → exactly zero)
```

---

## Regularization Strength (λ)

```
     λ = 0 (No regularization)         λ too large
     
     y                                  y
     │    ●╲  ╱●                        │  ●     ●
     │      ●                           │     ●
     │   ●╱   ╲●                        │  ───────────  (horizontal line)
     │  ●       ●                       │●          ●
     └────────────                      └────────────
          x                                  x
     
     Overfitting                        Underfitting
     High variance                      High bias
     
                    ↓
                    
              λ just right
              
               y
               │    ●╲    ╱●
               │      ╲  ╱
               │   ●   ╲╱  ●
               │  ●     ╲   ●
               └────────────
                    x
               
               Good fit!
```

### Choosing λ (Cross-Validation)

```
Validation Error
       │
       │●                               
       │ ●                              
       │  ●                             
       │    ●                           
       │      ●                         
       │        ●  ● ← Optimal λ        
       │           ●                    
       │             ●  ●               
       │                  ●  ●  ●       
       └─────────────────────────────── λ
       0    0.01   0.1    1    10   100
       
       Small λ: overfitting
       Large λ: underfitting
```

---

## Other Regularization Techniques

### Dropout (Neural Networks)

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   During training, randomly "drop" neurons with prob p      │
│                                                             │
│   Standard Network:          With Dropout (p=0.5):          │
│                                                             │
│   ○───○───○                  ○   ╳   ○                      │
│    ╲ ╱ ╲ ╱                    ╲     ╱                       │
│     ○   ○      ────►          ╳   ○                        │
│    ╱ ╲ ╱ ╲                       ╱ ╲                        │
│   ○───○───○                  ○   ╳   ○                      │
│                                                             │
│   ╳ = dropped neuron (output set to 0)                      │
│                                                             │
│   Effect: Prevents co-adaptation of neurons                 │
│           Forces network to learn redundant representations │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Early Stopping

```
      Loss
       │
       │    ── Training loss
       │    -- Validation loss
       │
       │ ●
       │  ●                         ●────●────●  (overfitting)
       │   ●                    ●──●
       │    ●               ●──●
       │     ●          ●──●         ← Stop here!
       │      ●●    ●──●                (validation increases)
       │        ●●●●
       │         ────────────────────
       └─────────────────────────────────── Epochs
                        ↑
                   Best model
```

### Data Augmentation

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Original Image:    Augmented Versions:                    │
│                                                             │
│   ┌─────────┐       ┌─────────┐  ┌─────────┐  ┌─────────┐  │
│   │   🐱    │  →    │   🐱    │  │   🐱    │  │    🐱   │  │
│   │         │       │(rotated)│  │(flipped)│  │(cropped)│  │
│   └─────────┘       └─────────┘  └─────────┘  └─────────┘  │
│                                                             │
│   Types:                                                    │
│   • Rotation, flipping, scaling                             │
│   • Color jittering                                         │
│   • Random cropping                                         │
│   • Noise addition                                          │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Batch Normalization

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Normalizes activations within each mini-batch:            │
│                                                             │
│              x - μ_batch                                    │
│   x_norm = ──────────────                                   │
│             √(σ²_batch + ε)                                 │
│                                                             │
│   y = γ × x_norm + β   (learnable parameters)               │
│                                                             │
│   Benefits:                                                 │
│   • Reduces internal covariate shift                        │
│   • Acts as regularizer (noise from batch statistics)       │
│   • Allows higher learning rates                            │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Python Implementation

```python
from sklearn.linear_model import Ridge, Lasso, ElasticNet
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import cross_val_score
import numpy as np

# Generate sample data
np.random.seed(42)
X = np.random.randn(100, 10)
y = 3*X[:, 0] + 2*X[:, 1] + 0.5*X[:, 2] + np.random.randn(100)*0.5

# Scale features (important for regularization!)
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Ridge Regression (L2)
ridge = Ridge(alpha=1.0)  # alpha = λ
ridge.fit(X_scaled, y)
print(f"Ridge coefficients: {ridge.coef_}")

# Lasso Regression (L1)
lasso = Lasso(alpha=0.1)
lasso.fit(X_scaled, y)
print(f"Lasso coefficients: {lasso.coef_}")
print(f"Non-zero coefficients: {np.sum(lasso.coef_ != 0)}")

# Elastic Net
elastic = ElasticNet(alpha=0.1, l1_ratio=0.5)  # l1_ratio = α
elastic.fit(X_scaled, y)
print(f"Elastic Net coefficients: {elastic.coef_}")

# Cross-validation to find best alpha
from sklearn.linear_model import RidgeCV, LassoCV

ridge_cv = RidgeCV(alphas=[0.01, 0.1, 1, 10, 100])
ridge_cv.fit(X_scaled, y)
print(f"Best Ridge alpha: {ridge_cv.alpha_}")

lasso_cv = LassoCV(alphas=[0.001, 0.01, 0.1, 1])
lasso_cv.fit(X_scaled, y)
print(f"Best Lasso alpha: {lasso_cv.alpha_}")
```

### From Scratch Implementation

```python
class RidgeRegressionScratch:
    def __init__(self, alpha=1.0):
        self.alpha = alpha
        
    def fit(self, X, y):
        # Add bias term
        X_b = np.c_[np.ones(X.shape[0]), X]
        n_features = X_b.shape[1]
        
        # Closed-form solution: w = (XᵀX + λI)⁻¹Xᵀy
        identity = np.eye(n_features)
        identity[0, 0] = 0  # Don't regularize bias
        
        self.weights = np.linalg.inv(
            X_b.T @ X_b + self.alpha * identity
        ) @ X_b.T @ y
        
    def predict(self, X):
        X_b = np.c_[np.ones(X.shape[0]), X]
        return X_b @ self.weights


class LassoRegressionScratch:
    def __init__(self, alpha=1.0, n_iterations=1000, lr=0.01):
        self.alpha = alpha
        self.n_iterations = n_iterations
        self.lr = lr
        
    def soft_threshold(self, x, threshold):
        """Soft thresholding function for L1"""
        return np.sign(x) * np.maximum(np.abs(x) - threshold, 0)
        
    def fit(self, X, y):
        n_samples, n_features = X.shape
        self.weights = np.zeros(n_features)
        self.bias = 0
        
        for _ in range(self.n_iterations):
            y_pred = X @ self.weights + self.bias
            
            # Gradient for MSE
            dw = (1/n_samples) * X.T @ (y_pred - y)
            db = (1/n_samples) * np.sum(y_pred - y)
            
            # Update with soft thresholding (proximal gradient)
            self.weights = self.soft_threshold(
                self.weights - self.lr * dw,
                self.lr * self.alpha
            )
            self.bias -= self.lr * db
            
    def predict(self, X):
        return X @ self.weights + self.bias
```

---

## Interview Questions

### Q1: What is the difference between L1 and L2 regularization?
**Answer:**
- **L1 (Lasso):** Adds |w| penalty, creates sparse solutions (some weights = 0), performs feature selection
- **L2 (Ridge):** Adds w² penalty, shrinks all weights towards zero but doesn't eliminate them, more stable

### Q2: Why does L1 create sparse solutions?
**Answer:** The L1 constraint region (diamond shape) has corners on the axes. When the loss function contours intersect this region, they often hit corners, setting some weights exactly to zero. L2's circular constraint has no corners, so intersections don't land on axes.

### Q3: When would you use Elastic Net?
**Answer:** Use Elastic Net when:
- You have correlated features (L1 would randomly pick one)
- You want feature selection (from L1) with stability (from L2)
- Number of features > number of samples

### Q4: How does dropout work as regularization?
**Answer:** Dropout randomly sets neurons to zero during training (typically 20-50% of neurons). This:
- Prevents co-adaptation of neurons
- Forces the network to learn redundant representations
- Effectively trains an ensemble of sub-networks
- At inference, all neurons are used but outputs are scaled

### Q5: Why is feature scaling important for regularization?
**Answer:** Regularization penalizes weights equally. If features have different scales, larger-scale features will have smaller weights to compensate, and get penalized less. Scaling ensures fair penalty across all features.

---

## Quick Reference

```
┌─────────────────────────────────────────────────────────────┐
│              REGULARIZATION CHEAT SHEET                     │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  L1 (Lasso):  J + λΣ|w|     → Feature selection, sparse     │
│  L2 (Ridge):  J + λΣw²      → Shrinkage, handles multicollin│
│  Elastic:     J + λ₁Σ|w| + λ₂Σw²  → Best of both           │
│                                                             │
│  Dropout:     Randomly zero neurons (neural nets)           │
│  Early Stop:  Stop when validation error increases          │
│  Data Aug:    Artificially increase training data           │
│  Batch Norm:  Normalize layer inputs                        │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  When to use:                                               │
│  • Many features, few samples  → L1 or Elastic Net          │
│  • Multicollinearity          → L2                          │
│  • Feature selection needed   → L1                          │
│  • Deep networks              → Dropout + BatchNorm         │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```
