# Gradient Descent & Optimization

## What is Gradient Descent?

Gradient Descent is an **optimization algorithm** used to minimize a function by iteratively moving in the direction of steepest descent (negative gradient).

```
                    Cost Function J(w)
                          │
                     100 ─┤  ●  ← Start here
                          │   ╲
                      80 ─┤    ╲
                          │     ╲
                      60 ─┤      ╲
                          │       ╲
                      40 ─┤        ╲
                          │         ╲
                      20 ─┤          ●  ← After iterations
                          │           ╲
                       0 ─┤            ●  ← Global minimum
                          │
                          └────────────────────────────
                                      w (weight)
```

---

## The Algorithm

### Mathematical Formulation

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Repeat until convergence:                                 │
│                                                             │
│                    ∂J(w)                                    │
│       w = w - α × ─────                                     │
│                     ∂w                                      │
│                                                             │
│   Components:                                               │
│     w    = current parameter value                          │
│     α    = learning rate (step size)                        │
│     ∂J/∂w = gradient (slope of cost function)               │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Intuition: Rolling Ball Analogy

```
                    Mountain (Cost Surface)
                         /\
                        /  \    ● Ball (current position)
                       /    \  ↙
                      /      ↓    Gravity pulls down
                     /        \     (negative gradient)
                    /          \
                   /            \
                  /──────────────\
                        Valley (Minimum)
```

---

## Learning Rate (α)

The learning rate controls the step size at each iteration.

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│  TOO SMALL (α = 0.0001)       JUST RIGHT (α = 0.01)        │
│                                                             │
│       ●                            ●                        │
│        ╲                            ╲                       │
│         ╲                            ╲                      │
│          ╲                            ╲                     │
│           ╲                            ╲                    │
│            ╲                            ●                   │
│             ╲                            (converges)        │
│              ╲                                              │
│    (very slow)                                              │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  TOO LARGE (α = 1.0)                                        │
│                                                             │
│       ●                 ●                                   │
│        ╲               ╱                                    │
│         ╲             ╱                                     │
│          ╲           ╱                                      │
│           ╲         ╱                                       │
│            ●───────●                                        │
│    (oscillates, may diverge!)                               │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Typical Learning Rates
- Start with: 0.1, 0.01, 0.001
- Common range: 10⁻⁶ to 1
- Use learning rate schedulers for better convergence

---

## Types of Gradient Descent

### 1. Batch Gradient Descent

Uses **all** training examples for each update.

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   For each iteration:                                       │
│       gradient = (1/m) Σᵢ ∇J(wᵢ) for ALL samples           │
│       w = w - α × gradient                                  │
│                                                             │
│   Pros: ✓ Stable convergence                                │
│         ✓ Guaranteed to converge to global min (convex)     │
│                                                             │
│   Cons: ✗ Slow for large datasets                           │
│         ✗ Requires entire dataset in memory                 │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### 2. Stochastic Gradient Descent (SGD)

Uses **one** random training example per update.

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   For each iteration:                                       │
│       Pick random sample (xᵢ, yᵢ)                           │
│       gradient = ∇J(xᵢ, yᵢ)                                 │
│       w = w - α × gradient                                  │
│                                                             │
│   Pros: ✓ Fast updates                                      │
│         ✓ Can escape local minima                           │
│         ✓ Works with streaming data                         │
│                                                             │
│   Cons: ✗ Noisy updates (high variance)                     │
│         ✗ May not converge exactly to minimum               │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### 3. Mini-Batch Gradient Descent (Most Common)

Uses a **batch** of training examples (typically 32, 64, 128, 256).

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   For each iteration:                                       │
│       Pick batch of b samples                               │
│       gradient = (1/b) Σᵢ ∇J(xᵢ) for batch                 │
│       w = w - α × gradient                                  │
│                                                             │
│   Pros: ✓ Best of both worlds                               │
│         ✓ Utilizes GPU parallelism                          │
│         ✓ Stable enough for convergence                     │
│                                                             │
│   Typical batch sizes: 32, 64, 128, 256                     │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Comparison Visualization

```
Cost J(w)
    │
    │╲ Batch (smooth path)
    │ ╲
    │  ╲         ╱╲╱╲   SGD (noisy path)
    │   ╲       ╱    ╲
    │    ╲     ╱      ╲
    │     ╲   ╱        ↘ Mini-batch (balanced)
    │      ╲ ╱
    │       ●  minimum
    └────────────────────────── iterations
```

---

## Advanced Optimizers

### 1. Momentum

Accelerates SGD by adding a fraction of the previous update.

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   v = β × v + (1-β) × gradient    (velocity)                │
│   w = w - α × v                                             │
│                                                             │
│   β = momentum coefficient (typically 0.9)                   │
│                                                             │
└─────────────────────────────────────────────────────────────┘

Intuition: Ball rolling downhill gains momentum

Without Momentum:          With Momentum:
      ↓                         ↓
    ← →                       ╲ ↓
      ↓                         ↓↓
    ← →   (oscillates)          ↓  (accelerates in
      ↓                         ↓   consistent direction)
      ●                         ●
```

### 2. RMSprop

Adapts learning rate based on recent gradient magnitudes.

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   s = β × s + (1-β) × gradient²   (moving avg of squared)   │
│                 gradient                                    │
│   w = w - α × ─────────────                                 │
│               √(s + ε)                                      │
│                                                             │
│   Reduces learning rate for frequently updated parameters   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### 3. Adam (Adaptive Moment Estimation) ⭐ Most Popular

Combines Momentum + RMSprop.

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   m = β₁ × m + (1-β₁) × gradient       (1st moment - mean)  │
│   v = β₂ × v + (1-β₂) × gradient²      (2nd moment - var)   │
│                                                             │
│   m̂ = m / (1 - β₁ᵗ)                    (bias correction)    │
│   v̂ = v / (1 - β₂ᵗ)                                         │
│                                                             │
│              m̂                                              │
│   w = w - α ─────                                           │
│            √v̂ + ε                                           │
│                                                             │
│   Default: β₁=0.9, β₂=0.999, ε=10⁻⁸                         │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Optimizer Comparison

```
                    Convergence Path Comparison
                    
                    Start
                      ●
                     ╱│╲
                    ╱ │ ╲
                   ╱  │  ╲
         SGD ────╱   │   ╲───── RMSprop
                ╱    │    ╲
               ╱     │     ╲
              ╱   Adam│      ╲
             ╱     ↓  ↓       ╲
            ╱      ↓  ↓        ╲
           ●────── ↓  ● ────────●
                   Minimum
                   
        SGD: Slow, oscillates
        Adam: Fast, direct path
        RMSprop: Adaptive but no momentum
```

---

## Gradient Computation

### For Linear Regression

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Cost: J(w,b) = (1/2m) Σ(ŷᵢ - yᵢ)²                        │
│                                                             │
│   Gradients:                                                │
│                                                             │
│   ∂J/∂w = (1/m) Σ(ŷᵢ - yᵢ) × xᵢ                            │
│                                                             │
│   ∂J/∂b = (1/m) Σ(ŷᵢ - yᵢ)                                 │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Gradient Descent Steps

```
Iteration 1:
  x = [1, 2, 3], y = [2, 4, 6]
  w = 0 (initial)
  
  ŷ = w × x = [0, 0, 0]
  error = ŷ - y = [-2, -4, -6]
  gradient = (1/3) × (-2×1 + -4×2 + -6×3) = -9.33
  
  w_new = 0 - 0.1 × (-9.33) = 0.933

Iteration 2:
  ŷ = 0.933 × x = [0.93, 1.87, 2.80]
  error = [-1.07, -2.13, -3.20]
  gradient = -4.67
  
  w_new = 0.933 - 0.1 × (-4.67) = 1.40

... continues until convergence to w ≈ 2
```

---

## Convergence Criteria

```
┌─────────────────────────────────────────────────────────────┐
│                  STOPPING CONDITIONS                        │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│ 1. Maximum iterations reached                               │
│    if iteration > max_iterations: stop                      │
│                                                             │
│ 2. Gradient magnitude below threshold                       │
│    if ||∇J|| < ε: stop                                      │
│                                                             │
│ 3. Change in loss below threshold                           │
│    if |J(t) - J(t-1)| < ε: stop                             │
│                                                             │
│ 4. Change in parameters below threshold                     │
│    if ||w(t) - w(t-1)|| < ε: stop                           │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Learning Rate Scheduling

### Common Schedules

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│ 1. Step Decay                                               │
│    α = α₀ × drop^(floor(epoch/step_size))                   │
│    Example: Halve LR every 10 epochs                        │
│                                                             │
│ 2. Exponential Decay                                        │
│    α = α₀ × e^(-decay_rate × epoch)                         │
│                                                             │
│ 3. Cosine Annealing                                         │
│    α = α_min + 0.5(α_max - α_min)(1 + cos(πt/T))            │
│                                                             │
│ 4. Warm Restarts                                            │
│    Reset LR periodically to escape local minima             │
│                                                             │
└─────────────────────────────────────────────────────────────┘

Learning Rate
    │
α₀ ─┤●                              Step Decay
    │ ●●●●
    │      ●●●●
    │           ●●●●
    │                ●●●●
    └────────────────────────────── Epochs
```

---

## Python Implementation

```python
import numpy as np

class GradientDescent:
    def __init__(self, learning_rate=0.01, n_iterations=1000, 
                 optimizer='sgd', momentum=0.9, beta1=0.9, beta2=0.999):
        self.lr = learning_rate
        self.n_iterations = n_iterations
        self.optimizer = optimizer
        self.momentum = momentum
        self.beta1 = beta1
        self.beta2 = beta2
        
    def fit(self, X, y):
        n_samples, n_features = X.shape
        self.weights = np.zeros(n_features)
        self.bias = 0
        self.losses = []
        
        # Initialize optimizer variables
        v_w, v_b = 0, 0  # Momentum
        m_w, m_b = 0, 0  # Adam first moment
        s_w, s_b = 0, 0  # Adam second moment
        
        for t in range(1, self.n_iterations + 1):
            # Forward pass
            y_pred = np.dot(X, self.weights) + self.bias
            
            # Compute gradients
            dw = (1/n_samples) * np.dot(X.T, (y_pred - y))
            db = (1/n_samples) * np.sum(y_pred - y)
            
            if self.optimizer == 'sgd':
                self.weights -= self.lr * dw
                self.bias -= self.lr * db
                
            elif self.optimizer == 'momentum':
                v_w = self.momentum * v_w + (1 - self.momentum) * dw
                v_b = self.momentum * v_b + (1 - self.momentum) * db
                self.weights -= self.lr * v_w
                self.bias -= self.lr * v_b
                
            elif self.optimizer == 'adam':
                # First moment (mean)
                m_w = self.beta1 * m_w + (1 - self.beta1) * dw
                m_b = self.beta1 * m_b + (1 - self.beta1) * db
                
                # Second moment (variance)
                s_w = self.beta2 * s_w + (1 - self.beta2) * (dw ** 2)
                s_b = self.beta2 * s_b + (1 - self.beta2) * (db ** 2)
                
                # Bias correction
                m_w_corrected = m_w / (1 - self.beta1 ** t)
                m_b_corrected = m_b / (1 - self.beta1 ** t)
                s_w_corrected = s_w / (1 - self.beta2 ** t)
                s_b_corrected = s_b / (1 - self.beta2 ** t)
                
                # Update
                self.weights -= self.lr * m_w_corrected / (np.sqrt(s_w_corrected) + 1e-8)
                self.bias -= self.lr * m_b_corrected / (np.sqrt(s_b_corrected) + 1e-8)
            
            # Track loss
            loss = np.mean((y_pred - y) ** 2)
            self.losses.append(loss)
            
    def predict(self, X):
        return np.dot(X, self.weights) + self.bias
```

---

## Interview Questions

### Q1: What is the difference between Batch, Stochastic, and Mini-batch GD?
**Answer:**
- **Batch:** Uses all samples per update (stable but slow)
- **Stochastic:** Uses 1 sample per update (fast but noisy)
- **Mini-batch:** Uses a batch of samples (balanced approach)

### Q2: Why might gradient descent get stuck?
**Answer:**
- **Local minima:** Converges to a non-global minimum
- **Saddle points:** Gradient is zero but not a minimum
- **Plateaus:** Very flat regions with tiny gradients
- **Vanishing gradients:** In deep networks

### Q3: How does Adam combine Momentum and RMSprop?
**Answer:** Adam maintains both:
- First moment (momentum): Running average of gradients
- Second moment (RMSprop): Running average of squared gradients
- Uses bias correction for both moments

### Q4: How do you choose the learning rate?
**Answer:**
- Start with standard values (0.001, 0.01, 0.1)
- Use learning rate finder (gradually increase and plot loss)
- Use schedulers (step decay, cosine annealing)
- Try adaptive methods (Adam) which are less sensitive

### Q5: What is gradient clipping and when is it used?
**Answer:** Gradient clipping limits gradient magnitudes to prevent exploding gradients in RNNs/deep networks:
```python
# Clip by value
gradient = np.clip(gradient, -threshold, threshold)

# Clip by norm
norm = np.linalg.norm(gradient)
if norm > threshold:
    gradient = gradient * threshold / norm
```

---

## Quick Reference

```
┌─────────────────────────────────────────────────────────────┐
│                 OPTIMIZER CHEAT SHEET                       │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  SGD        : w = w - α∇J                                   │
│  Momentum   : v = βv + ∇J; w = w - αv                       │
│  RMSprop    : s = βs + ∇J²; w = w - α∇J/√s                  │
│  Adam       : Momentum + RMSprop (most recommended)         │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  When to use what:                                          │
│  • Simple problems    → SGD with momentum                   │
│  • Deep learning      → Adam (default choice)               │
│  • Sparse gradients   → Adam, RMSprop                       │
│  • Final fine-tuning  → SGD (often generalizes better)      │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```
