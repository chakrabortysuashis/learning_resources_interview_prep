# Clustering Algorithms

## What is Clustering?

Clustering is an **unsupervised learning** technique that groups similar data points together without predefined labels.

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Before Clustering:              After Clustering:         │
│                                                             │
│     ●   ○    ▲                   (●●●)                      │
│    ●  ○  ▲   ●                    ● ●    (○○○)              │
│      ○  ▲  ●                            ○  ○                │
│     ○  ▲   ●  ●                     (▲▲▲)   ○               │
│       ▲  ●                          ▲  ▲                    │
│     ▲  ▲                              ▲                     │
│                                                             │
│   Just data points              3 clusters identified       │
│   (no labels)                                               │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## K-Means Clustering

### The Algorithm

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   1. Choose K (number of clusters)                          │
│   2. Initialize K centroids randomly                        │
│   3. Repeat until convergence:                              │
│      a) ASSIGN each point to nearest centroid               │
│      b) UPDATE centroids to mean of assigned points         │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Visual Step-by-Step

```
Step 1: Initialize            Step 2: Assign              Step 3: Update
random centroids              to nearest                  centroids

     ×                           ×                           ×
  ●  ●  ●                     ●  ●  ●                     ●  ●  ●
    ●  ●         →           ╱  ●  ●╲        →              ●  ×
      ●                     ╱     ●  ╲                        ●
  ○  ○  ○                  ○  ○  ×  ○                     ○  ×  ○
    ○  ○  ×                  ○╲ ○ ╱○                        ○  ○
                               ╲ ╱
                                
× = centroid               Points assigned            Centroids moved
                          to clusters                 to cluster means

                    ↓ Repeat until no change ↓
```

### Mathematical Objective

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Minimize Within-Cluster Sum of Squares (WCSS):            │
│                                                             │
│   J = Σ   Σ    ||x - μₖ||²                                  │
│       k  x∈Cₖ                                               │
│                                                             │
│   Where:                                                    │
│   Cₖ = set of points in cluster k                           │
│   μₖ = centroid of cluster k                                │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Choosing K: The Elbow Method

```
   WCSS (Inertia)
       │
       │●
       │
       │ ●
       │
       │  ●
       │    ●  ← Elbow point (optimal K)
       │      ●●●●●●●●●●●●●
       │
       └─────────────────────────── K
         1   2   3   4   5   6   7

The "elbow" is where adding more clusters 
doesn't significantly reduce WCSS.
```

### Silhouette Score

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   For each point:                                           │
│                                                             │
│   a = avg distance to points in SAME cluster                │
│   b = avg distance to points in NEAREST other cluster       │
│                                                             │
│            b - a                                            │
│   s = ───────────                                           │
│        max(a, b)                                            │
│                                                             │
│   Range: [-1, 1]                                            │
│   • s ≈ 1: Point well-matched to cluster                    │
│   • s ≈ 0: Point on border of clusters                      │
│   • s ≈ -1: Point may be in wrong cluster                   │
│                                                             │
│   Higher average silhouette = better clustering             │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## K-Means Limitations

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   1. MUST specify K in advance                              │
│                                                             │
│   2. Sensitive to initialization                            │
│      ┌─────────────┐    ┌─────────────┐                     │
│      │●●●  ×  ○○○  │    │  ×          │  Different          │
│      │  ●    ○  ○  │ vs │●●●    ○○○   │  initial centroids  │
│      │    ×        │    │  ●  ×  ○  ○ │  → different result │
│      └─────────────┘    └─────────────┘                     │
│                                                             │
│   3. Assumes spherical clusters                             │
│      ╭──────╮                                               │
│      │●●●●●●│  ← K-Means can't find                         │
│      │      │     elongated clusters                        │
│      ╰──────╯                                               │
│                                                             │
│   4. Sensitive to outliers                                  │
│                                                             │
│   5. Equal-sized clusters assumed                           │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### K-Means++: Better Initialization

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Instead of random initialization:                         │
│                                                             │
│   1. Choose first centroid randomly                         │
│   2. For each remaining centroid:                           │
│      - Calculate distance D(x) to nearest centroid          │
│      - Choose next centroid with probability ∝ D(x)²        │
│                                                             │
│   This spreads initial centroids apart → better results     │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Hierarchical Clustering

### Agglomerative (Bottom-Up)

```
Start: Each point is own cluster
      ●   ●   ●   ●   ●

Step 1: Merge closest pair
      (● ●)  ●   ●   ●

Step 2: Continue merging
      (● ●)  (● ●)  ●

Step 3: Continue...
      ((● ●)(● ●))  ●

Step 4: All in one cluster
      (((● ●)(● ●)) ●)
```

### Dendrogram

```
                    ┌──────────────────────────────────────┐
                    │                                      │
Distance       ─────┼──────────────────┐                   │
                    │                  │                   │
               ─────┼───────┐          │                   │
                    │       │          │                   │
               ─────┼──┐    │     ┌────┼────┐              │
                    │  │    │     │    │    │              │
                    A  B    C     D    E    F
                    
Cut here ─────────────────────────────────── → 3 clusters: (AB), (C), (DEF)
```

### Linkage Methods

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   SINGLE LINKAGE (Minimum):                                 │
│   d(A,B) = min distance between any points                  │
│   • Can create "chaining" effect                            │
│   • Good for elongated clusters                             │
│                                                             │
│   COMPLETE LINKAGE (Maximum):                               │
│   d(A,B) = max distance between any points                  │
│   • Creates compact clusters                                │
│   • Sensitive to outliers                                   │
│                                                             │
│   AVERAGE LINKAGE:                                          │
│   d(A,B) = average of all pairwise distances                │
│   • Compromise between single and complete                  │
│                                                             │
│   WARD'S METHOD:                                            │
│   Minimize increase in total within-cluster variance        │
│   • Creates spherical clusters                              │
│   • Most commonly used                                      │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## DBSCAN (Density-Based)

### Concept

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Parameters:                                               │
│   ε (eps): Neighborhood radius                              │
│   minPts: Minimum points to form dense region               │
│                                                             │
│   Point types:                                              │
│   • CORE: Has ≥ minPts within ε                            │
│   • BORDER: Within ε of core point                         │
│   • NOISE: Neither core nor border                         │
│                                                             │
└─────────────────────────────────────────────────────────────┘

    ●─────────● ← Core points
   ╱│╲       ╱│╲   (many neighbors in ε)
  ●─●─●     ●─●─●
     ╲│╱       │
      ○        ○ ← Border points
                   (near core)
         ◇
         ↑
       Noise
    (no neighbors)
```

### Advantages over K-Means

```
K-Means:                        DBSCAN:

  ●●●   ●●●                       ●●●   ●●●
   ●     ●                         ●     ●
         ╱────╮                          
    ●●● │ ○○○ │  Can't handle       ●●●   ○○○  Handles
     ●  │  ○  │  arbitrary           ●     ○   arbitrary
        ╰─────╯  shapes!                       shapes!
        
  Must specify K               Finds K automatically
  Sensitive to outliers        Identifies outliers
```

---

## Comparison of Clustering Methods

```
┌──────────────┬───────────────────────────────────────────────┐
│   Method     │   Best For                                    │
├──────────────┼───────────────────────────────────────────────┤
│  K-Means     │ Spherical clusters, known K, large datasets   │
│  Hierarchical│ Explore cluster hierarchy, small-medium data  │
│  DBSCAN      │ Arbitrary shapes, unknown K, noise/outliers   │
│  GMM         │ Soft clustering, elliptical clusters          │
└──────────────┴───────────────────────────────────────────────┘
```

```
                     Cluster Shape
                     
    Spherical    Elliptical    Arbitrary
         │           │             │
         │  K-Means  │    GMM      │   DBSCAN
         │  ◉◉◉      │   ⬭⬭⬭      │   ~~~
         │  ◉◉◉      │   ⬭⬭⬭      │   ~~~
         │           │             │
```

---

## Gaussian Mixture Models (GMM)

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Assumes data is generated from K Gaussian distributions   │
│                                                             │
│   P(x) = Σ πₖ × N(x | μₖ, Σₖ)                              │
│          k                                                  │
│                                                             │
│   Where:                                                    │
│   πₖ = mixing coefficient (weight of cluster k)             │
│   μₖ = mean of cluster k                                    │
│   Σₖ = covariance matrix of cluster k                       │
│                                                             │
│   Uses Expectation-Maximization (EM) algorithm              │
│                                                             │
└─────────────────────────────────────────────────────────────┘

K-Means vs GMM:

K-Means: Hard assignment        GMM: Soft assignment
Point → 1 cluster              Point → probability per cluster

   ●●●|○○○                        ●●●...○○○
      |                              ↑
      |                        P(cluster1)=0.6
   Hard boundary               P(cluster2)=0.4
```

---

## Python Implementation

```python
from sklearn.cluster import KMeans, DBSCAN, AgglomerativeClustering
from sklearn.mixture import GaussianMixture
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
import numpy as np

# Always scale for clustering!
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# K-Means
kmeans = KMeans(n_clusters=3, init='k-means++', n_init=10, random_state=42)
labels = kmeans.fit_predict(X_scaled)
centroids = kmeans.cluster_centers_
inertia = kmeans.inertia_  # WCSS

# Elbow method
inertias = []
K_range = range(1, 11)
for k in K_range:
    km = KMeans(n_clusters=k, random_state=42)
    km.fit(X_scaled)
    inertias.append(km.inertia_)

plt.plot(K_range, inertias, 'bo-')
plt.xlabel('K')
plt.ylabel('Inertia (WCSS)')
plt.title('Elbow Method')
plt.show()

# Silhouette score
for k in range(2, 11):
    km = KMeans(n_clusters=k, random_state=42)
    labels = km.fit_predict(X_scaled)
    score = silhouette_score(X_scaled, labels)
    print(f"K={k}: Silhouette Score = {score:.3f}")

# DBSCAN
dbscan = DBSCAN(eps=0.5, min_samples=5)
labels = dbscan.fit_predict(X_scaled)
n_clusters = len(set(labels)) - (1 if -1 in labels else 0)
n_noise = list(labels).count(-1)
print(f"Clusters: {n_clusters}, Noise points: {n_noise}")

# Hierarchical
hierarchical = AgglomerativeClustering(n_clusters=3, linkage='ward')
labels = hierarchical.fit_predict(X_scaled)

# Plot dendrogram
from scipy.cluster.hierarchy import dendrogram, linkage
Z = linkage(X_scaled, method='ward')
plt.figure(figsize=(10, 5))
dendrogram(Z)
plt.show()

# GMM (soft clustering)
gmm = GaussianMixture(n_components=3, covariance_type='full')
gmm.fit(X_scaled)
labels = gmm.predict(X_scaled)
probabilities = gmm.predict_proba(X_scaled)  # Soft assignments
```

### K-Means From Scratch

```python
import numpy as np

class KMeansScratch:
    def __init__(self, n_clusters=3, max_iters=100, tol=1e-4):
        self.n_clusters = n_clusters
        self.max_iters = max_iters
        self.tol = tol
        
    def fit(self, X):
        n_samples, n_features = X.shape
        
        # Initialize centroids (K-Means++)
        self.centroids = self._init_centroids_plus_plus(X)
        
        for _ in range(self.max_iters):
            # Assign points to nearest centroid
            self.labels = self._assign_clusters(X)
            
            # Update centroids
            new_centroids = np.array([
                X[self.labels == k].mean(axis=0) 
                for k in range(self.n_clusters)
            ])
            
            # Check convergence
            if np.sum((new_centroids - self.centroids) ** 2) < self.tol:
                break
                
            self.centroids = new_centroids
        
        return self
    
    def _init_centroids_plus_plus(self, X):
        centroids = [X[np.random.randint(len(X))]]
        
        for _ in range(1, self.n_clusters):
            # Distance to nearest centroid
            dists = np.min([
                np.sum((X - c) ** 2, axis=1) 
                for c in centroids
            ], axis=0)
            
            # Choose with probability proportional to distance²
            probs = dists / dists.sum()
            new_idx = np.random.choice(len(X), p=probs)
            centroids.append(X[new_idx])
        
        return np.array(centroids)
    
    def _assign_clusters(self, X):
        distances = np.sqrt([
            np.sum((X - c) ** 2, axis=1) 
            for c in self.centroids
        ])
        return np.argmin(distances, axis=0)
    
    def predict(self, X):
        return self._assign_clusters(X)
```

---

## Interview Questions

### Q1: How do you choose the number of clusters?
**Answer:**
- **Elbow method:** Plot WCSS vs K, find the "elbow"
- **Silhouette score:** Higher is better, range [-1, 1]
- **Domain knowledge:** Sometimes you know expected clusters
- **Gap statistic:** Compare to random uniform distribution

### Q2: What are the limitations of K-Means?
**Answer:**
- Must specify K in advance
- Assumes spherical, equal-sized clusters
- Sensitive to initialization (use K-Means++)
- Sensitive to outliers
- Only finds convex clusters

### Q3: When would you use DBSCAN over K-Means?
**Answer:**
- Unknown number of clusters
- Non-spherical cluster shapes
- Presence of outliers/noise
- Varying cluster densities (though DBSCAN struggles here too)

### Q4: What is the difference between hard and soft clustering?
**Answer:**
- **Hard:** Each point belongs to exactly one cluster (K-Means)
- **Soft:** Each point has probability of belonging to each cluster (GMM)

### Q5: How does hierarchical clustering differ from K-Means?
**Answer:**
- Creates a tree of clusters (dendrogram)
- Can choose number of clusters after fitting
- No random initialization
- More computationally expensive O(n³)
- Can use different linkage methods

---

## Quick Reference

```
┌─────────────────────────────────────────────────────────────┐
│              CLUSTERING CHEAT SHEET                         │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  K-MEANS                                                    │
│  • Simple, fast, scalable                                   │
│  • Spherical clusters, need K                               │
│  • Use K-Means++, scale features                            │
│                                                             │
│  DBSCAN                                                     │
│  • Arbitrary shapes, finds outliers                         │
│  • Parameters: eps, min_samples                             │
│  • Doesn't need K                                           │
│                                                             │
│  HIERARCHICAL                                               │
│  • Dendrogram, choose K after                               │
│  • Linkage: single, complete, average, ward                 │
│  • Expensive for large data                                 │
│                                                             │
│  GMM                                                        │
│  • Soft clustering (probabilities)                          │
│  • Elliptical clusters                                      │
│  • More flexible than K-Means                               │
│                                                             │
│  EVALUATION                                                 │
│  • Elbow method (WCSS)                                      │
│  • Silhouette score ([-1, 1], higher better)                │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```
