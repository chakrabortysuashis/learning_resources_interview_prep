# Neural Networks & Deep Learning

## What is a Neural Network?

A neural network is a computational model inspired by biological neurons, consisting of interconnected layers that learn patterns from data.

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   INPUT        HIDDEN           HIDDEN           OUTPUT     │
│   LAYER        LAYER 1          LAYER 2          LAYER      │
│                                                             │
│    (x₁)────────(○)──────────────(○)──────────────(ŷ₁)      │
│          ╲   ╱    ╲          ╱    ╲          ╱              │
│    (x₂)────×────────(○)────×────────(○)────×────────(ŷ₂)   │
│          ╱   ╲    ╱          ╲    ╱          ╲              │
│    (x₃)────────(○)──────────────(○)──────────────(ŷ₃)      │
│                                                             │
│   Each connection has a weight (w)                          │
│   Each node (except input) has a bias (b)                   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## The Neuron (Perceptron)

### Single Neuron

```
                    INPUTS              WEIGHTS
                      │                    │
                x₁ ───┤──── × w₁ ─────────┐
                      │                    │
                x₂ ───┤──── × w₂ ─────────┼──► Σ (weighted sum)
                      │                    │         │
                x₃ ───┤──── × w₃ ─────────┘         │
                      │                              │ + bias (b)
                bias ─┘                              │
                                                     ▼
                                              ┌─────────────┐
                                              │ Activation  │
                                              │  Function   │
                                              │    f(z)     │
                                              └──────┬──────┘
                                                     │
                                                     ▼
                                                  OUTPUT
```

### Mathematical Formula

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   z = w₁x₁ + w₂x₂ + ... + wₙxₙ + b                          │
│     = wᵀx + b                                               │
│                                                             │
│   output = f(z)   where f = activation function             │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Activation Functions

### Why Activation Functions?

```
Without activation:
  Layer 1: z₁ = W₁x
  Layer 2: z₂ = W₂z₁ = W₂W₁x = Wx (still linear!)
  
Multiple linear layers = one linear layer!

Activation functions add NON-LINEARITY
```

### Common Activation Functions

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   SIGMOID: σ(z) = 1 / (1 + e⁻ᶻ)                             │
│                                                             │
│        1 ─┤──────────────●●●●●●                             │
│           │           ●●●                                   │
│      0.5 ─┤         ●●                                      │
│           │       ●●                                        │
│        0 ─┤●●●●●●●                                          │
│           └─────────────────────                            │
│                                                             │
│   Range: (0, 1)                                             │
│   Use: Output layer for binary classification               │
│   Problem: Vanishing gradients                              │
│                                                             │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   TANH: tanh(z) = (eᶻ - e⁻ᶻ) / (eᶻ + e⁻ᶻ)                  │
│                                                             │
│        1 ─┤──────────────●●●●●●                             │
│           │           ●●●                                   │
│        0 ─┤─────────●●─────────                             │
│           │       ●●                                        │
│       -1 ─┤●●●●●●●                                          │
│           └─────────────────────                            │
│                                                             │
│   Range: (-1, 1)                                            │
│   Centered around 0 (better than sigmoid)                   │
│   Still has vanishing gradient                              │
│                                                             │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   ReLU: f(z) = max(0, z)    ★ Most Popular!                │
│                                                             │
│           │            ╱                                    │
│           │          ╱                                      │
│           │        ╱                                        │
│        0 ─┤───────●                                         │
│           │                                                 │
│           └─────────────────────                            │
│                                                             │
│   Range: [0, ∞)                                             │
│   Fast, simple, no vanishing gradient for z > 0            │
│   Problem: "Dying ReLU" (neurons stuck at 0)                │
│                                                             │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   LEAKY ReLU: f(z) = max(αz, z)  where α ≈ 0.01            │
│                                                             │
│           │            ╱                                    │
│           │          ╱                                      │
│        0 ─┼────────●╱                                       │
│           │      ╱                                          │
│           │    ╱  (small slope for z < 0)                   │
│           └─────────────────────                            │
│                                                             │
│   Fixes dying ReLU problem                                  │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Activation Function Comparison

```
┌──────────┬────────────┬────────────────────────────────────┐
│ Function │   Range    │   Use Case                         │
├──────────┼────────────┼────────────────────────────────────┤
│ Sigmoid  │  (0, 1)    │ Binary classification output       │
│ Softmax  │  (0, 1)    │ Multi-class classification output  │
│ Tanh     │  (-1, 1)   │ Hidden layers (older)              │
│ ReLU     │  [0, ∞)    │ Hidden layers (default)            │
│ LeakyReLU│  (-∞, ∞)   │ Hidden layers (robust)             │
│ Linear   │  (-∞, ∞)   │ Regression output                  │
└──────────┴────────────┴────────────────────────────────────┘
```

---

## Forward Propagation

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Input → Layer 1 → Layer 2 → ... → Output                  │
│                                                             │
│   For each layer l:                                         │
│                                                             │
│   z⁽ˡ⁾ = W⁽ˡ⁾ × a⁽ˡ⁻¹⁾ + b⁽ˡ⁾                              │
│   a⁽ˡ⁾ = f(z⁽ˡ⁾)                                            │
│                                                             │
│   where:                                                    │
│     W⁽ˡ⁾ = weights of layer l                               │
│     b⁽ˡ⁾ = biases of layer l                                │
│     a⁽ˡ⁾ = activations (output) of layer l                  │
│     f = activation function                                 │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Example: 2-Layer Network

```
Input: x = [x₁, x₂]

Layer 1:
  z⁽¹⁾ = W⁽¹⁾x + b⁽¹⁾
  a⁽¹⁾ = ReLU(z⁽¹⁾)

Layer 2 (Output):
  z⁽²⁾ = W⁽²⁾a⁽¹⁾ + b⁽²⁾
  ŷ = σ(z⁽²⁾)    (sigmoid for binary classification)
```

---

## Backpropagation

### The Chain Rule

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Goal: Find ∂L/∂w for each weight to update it            │
│                                                             │
│   Chain Rule:                                               │
│                                                             │
│   ∂L    ∂L    ∂a    ∂z                                      │
│   ── = ── × ── × ──                                         │
│   ∂w    ∂a    ∂z    ∂w                                      │
│                                                             │
│   Propagate errors BACKWARD from output to input            │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Visual: Error Propagation

```
Forward Pass:
  x ──────► [Layer 1] ──────► [Layer 2] ──────► ŷ ──► Loss
                                                       │
                                                       │
Backward Pass:                                         │
  ∂L/∂W₁ ◄── [Layer 1] ◄────── [Layer 2] ◄────── ∂L/∂ŷ◄┘
  
  Gradients flow backwards through the network
```

---

## Training Process

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   1. Initialize weights (random, Xavier, He)                │
│                                                             │
│   2. For each epoch:                                        │
│      For each batch:                                        │
│        a) Forward pass: compute ŷ                           │
│        b) Compute loss: L(ŷ, y)                             │
│        c) Backward pass: compute gradients                  │
│        d) Update weights: w = w - α × ∂L/∂w                │
│                                                             │
│   3. Repeat until convergence or max epochs                 │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Loss Functions

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   BINARY CLASSIFICATION (Binary Cross-Entropy):             │
│   L = -[y·log(ŷ) + (1-y)·log(1-ŷ)]                         │
│                                                             │
│   MULTI-CLASS (Categorical Cross-Entropy):                  │
│   L = -Σ yₖ·log(ŷₖ)                                        │
│        k                                                    │
│                                                             │
│   REGRESSION (Mean Squared Error):                          │
│   L = (1/n) Σ(y - ŷ)²                                      │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Common Architectures

### Feedforward (MLP)

```
Input → Dense → Dense → ... → Output

• Fully connected layers
• Good for tabular data
• Simple, foundational
```

### Convolutional Neural Network (CNN)

```
Input → Conv → Pool → Conv → Pool → Flatten → Dense → Output

• Spatial feature extraction
• Image processing
• Translation invariance
```

### Recurrent Neural Network (RNN)

```
        ┌────────┐
        │  h(t)  │
        └────┬───┘
             │◄──────────┐
     ┌───────┴───────┐   │
     │               │   │
x(t)─┤   RNN Cell    ├───┴──► y(t)
     │               │
     └───────────────┘
     
• Sequential data
• Memory of past inputs
• Text, time series
```

---

## Regularization Techniques

### Dropout

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Training: Randomly "drop" neurons (set to 0)              │
│                                                             │
│   Standard:              With Dropout (p=0.5):              │
│                                                             │
│   ○───○───○              ○   ╳   ○                          │
│    ╲ ╱ ╲ ╱                ╲     ╱                           │
│     ○   ○       →         ╳   ○                            │
│    ╱ ╲ ╱ ╲                   ╱ ╲                            │
│   ○───○───○              ○   ╳   ○                          │
│                                                             │
│   ╳ = dropped (output = 0)                                  │
│                                                             │
│   Inference: Use all neurons, scale by (1-p)                │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Batch Normalization

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Normalize activations within each mini-batch:             │
│                                                             │
│           x - μ_batch                                       │
│   x̂ = ─────────────────                                     │
│        √(σ²_batch + ε)                                      │
│                                                             │
│   y = γ × x̂ + β   (learnable parameters)                   │
│                                                             │
│   Benefits:                                                 │
│   • Faster training (higher learning rates)                 │
│   • Acts as regularization                                  │
│   • Reduces internal covariate shift                        │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Weight Initialization

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Bad: All zeros                                            │
│   → All neurons learn same thing (symmetry problem)         │
│                                                             │
│   Bad: Large random                                         │
│   → Vanishing/exploding gradients                           │
│                                                             │
│   XAVIER (Glorot): For sigmoid/tanh                         │
│   W ~ N(0, √(2 / (n_in + n_out)))                          │
│                                                             │
│   HE: For ReLU                                              │
│   W ~ N(0, √(2 / n_in))                                    │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Python Implementation

```python
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
import numpy as np

# Simple MLP for classification
model = keras.Sequential([
    layers.Dense(128, activation='relu', input_shape=(input_dim,)),
    layers.Dropout(0.3),
    layers.Dense(64, activation='relu'),
    layers.Dropout(0.3),
    layers.Dense(32, activation='relu'),
    layers.Dense(num_classes, activation='softmax')
])

# Compile
model.compile(
    optimizer='adam',
    loss='sparse_categorical_crossentropy',
    metrics=['accuracy']
)

# Summary
model.summary()

# Train
history = model.fit(
    X_train, y_train,
    epochs=50,
    batch_size=32,
    validation_split=0.2,
    callbacks=[
        keras.callbacks.EarlyStopping(patience=5, restore_best_weights=True)
    ]
)

# Evaluate
test_loss, test_acc = model.evaluate(X_test, y_test)

# PyTorch version
import torch
import torch.nn as nn

class MLP(nn.Module):
    def __init__(self, input_dim, num_classes):
        super().__init__()
        self.layers = nn.Sequential(
            nn.Linear(input_dim, 128),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(64, num_classes)
        )
    
    def forward(self, x):
        return self.layers(x)

model = MLP(input_dim, num_classes)
criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

# Training loop
for epoch in range(epochs):
    model.train()
    for batch_x, batch_y in dataloader:
        optimizer.zero_grad()
        outputs = model(batch_x)
        loss = criterion(outputs, batch_y)
        loss.backward()
        optimizer.step()
```

---

## Interview Questions

### Q1: Why do we need non-linear activation functions?
**Answer:** Without non-linearity, multiple layers collapse into one linear transformation (W₂W₁x = Wx). Non-linear activations allow the network to learn complex, non-linear patterns.

### Q2: What is the vanishing gradient problem?
**Answer:** When gradients become very small (near 0) during backpropagation, weights barely update. Happens with sigmoid/tanh where derivatives are small for large inputs. ReLU helps avoid this.

### Q3: What is the difference between batch, mini-batch, and stochastic gradient descent?
**Answer:**
- **Batch:** Use all data per update (slow, stable)
- **Stochastic:** Use 1 sample per update (fast, noisy)
- **Mini-batch:** Use batch of samples (balanced, GPU-efficient)

### Q4: How does dropout prevent overfitting?
**Answer:** Randomly zeroing neurons forces the network to learn redundant representations. No neuron can rely on others. At inference, this ensemble effect improves generalization.

### Q5: What is the purpose of batch normalization?
**Answer:** Normalizes layer inputs to have zero mean and unit variance. Benefits: faster training (higher learning rates), regularization effect, reduces internal covariate shift.

---

## Quick Reference

```
┌─────────────────────────────────────────────────────────────┐
│             NEURAL NETWORKS CHEAT SHEET                     │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ACTIVATIONS                                                │
│  ReLU:    Hidden layers (default)                           │
│  Sigmoid: Binary output                                     │
│  Softmax: Multi-class output                                │
│  Linear:  Regression output                                 │
│                                                             │
│  REGULARIZATION                                             │
│  Dropout:    0.2-0.5 for hidden layers                      │
│  BatchNorm:  After linear, before activation                │
│  L2:         Weight decay in optimizer                      │
│                                                             │
│  INITIALIZATION                                             │
│  Xavier:  sigmoid/tanh                                      │
│  He:      ReLU                                              │
│                                                             │
│  TRAINING TIPS                                              │
│  • Start with small network, increase                       │
│  • Use Adam optimizer (learning rate ~0.001)                │
│  • Early stopping + validation set                          │
│  • Batch size: 32-256                                       │
│  • Scale input features                                     │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```
