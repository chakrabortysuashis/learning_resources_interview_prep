# Evaluation Metrics

## Why Metrics Matter

Different problems require different metrics. Accuracy alone can be misleading!

```
Example: Fraud Detection (1% fraud rate)

Model A: Always predicts "Not Fraud"
Accuracy = 99% ✓  (but catches 0 frauds!)

Model B: Catches 80% of frauds
Accuracy = 98%    (but actually useful!)

                    Accuracy is MISLEADING here!
```

---

## Classification Metrics

### The Confusion Matrix

```
┌─────────────────────────────────────────────────────────────┐
│                     CONFUSION MATRIX                        │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│                        PREDICTED                            │
│                    Negative    Positive                     │
│              ┌────────────┬────────────┐                    │
│              │            │            │                    │
│    Negative  │    TN      │    FP      │  ← Type I Error    │
│              │ (Correct)  │ (False     │    (False Alarm)   │
│  ACTUAL      │            │  Alarm)    │                    │
│              ├────────────┼────────────┤                    │
│              │            │            │                    │
│    Positive  │    FN      │    TP      │  ← Type II Error   │
│              │ (Missed!)  │ (Correct)  │    (Missed)        │
│              │            │            │                    │
│              └────────────┴────────────┘                    │
│                                                             │
│   TN = True Negative    FP = False Positive                 │
│   FN = False Negative   TP = True Positive                  │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Visual Example

```
Spam Detection:
                      Predicted
                   Not Spam    Spam
              ┌───────────┬───────────┐
    Not Spam  │    850    │    50     │  50 legitimate emails
     (Actual) │    (TN)   │   (FP)    │  marked as spam
              ├───────────┼───────────┤
       Spam   │    20     │    80     │  20 spam emails
     (Actual) │    (FN)   │   (TP)    │  got through
              └───────────┴───────────┘
```

---

### Core Metrics Formulas

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│                    TP + TN                                  │
│   ACCURACY = ─────────────────                              │
│              TP + TN + FP + FN                              │
│                                                             │
│   "Overall, how often is the classifier correct?"           │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│                    TP                                       │
│   PRECISION = ───────────                                   │
│                TP + FP                                      │
│                                                             │
│   "Of all PREDICTED positives, how many are actually pos?"  │
│   → High precision = few false alarms                       │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│                    TP                                       │
│   RECALL = ───────────── (also called Sensitivity/TPR)      │
│              TP + FN                                        │
│                                                             │
│   "Of all ACTUAL positives, how many did we find?"          │
│   → High recall = few missed positives                      │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│              2 × Precision × Recall                         │
│   F1 SCORE = ────────────────────────                       │
│               Precision + Recall                            │
│                                                             │
│   "Harmonic mean of precision and recall"                   │
│   → Balances both, penalizes extremes                       │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Calculation Example

```
From the spam example:
   TP = 80, TN = 850, FP = 50, FN = 20

   Accuracy  = (80 + 850) / (80 + 850 + 50 + 20) = 930/1000 = 93%
   
   Precision = 80 / (80 + 50) = 80/130 = 61.5%
               "61.5% of emails marked as spam were actually spam"
   
   Recall    = 80 / (80 + 20) = 80/100 = 80%
               "We caught 80% of all spam"
   
   F1 Score  = 2 × (0.615 × 0.80) / (0.615 + 0.80) = 69.6%
```

---

### Precision vs Recall Tradeoff

```
                                      High Recall
                                         │
                    ┌────────────────────┼────────────────────┐
                    │                    │                    │
                    │   Medical          │    Spam            │
                    │   Diagnosis        │    Detection       │
                    │                    │                    │
                    │  "Don't miss       │   "Don't miss      │
    High            │   cancer!"         │    spam, but       │
    Precision ──────┼────────────────────┼──── ok if some     │
                    │                    │    legit marked"   │
                    │   Legal            │                    │
                    │   Document         │    Search          │
                    │   Review           │    Engines         │
                    │                    │                    │
                    │  "Only show        │   "Show all        │
                    │   relevant ones"   │    relevant"       │
                    │                    │                    │
                    └────────────────────┴────────────────────┘
                                      Low Recall
```

### F-beta Score

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│              (1 + β²) × Precision × Recall                  │
│   F_β = ───────────────────────────────────                 │
│           β² × Precision + Recall                           │
│                                                             │
│   β < 1: Favor precision (F0.5)                             │
│   β = 1: Balance both (F1)                                  │
│   β > 1: Favor recall (F2)                                  │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## ROC Curve and AUC

### Understanding ROC

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   True Positive Rate (TPR) = TP / (TP + FN) = Recall        │
│   False Positive Rate (FPR) = FP / (FP + TN)                │
│                                                             │
│   ROC Curve: Plot TPR vs FPR at different thresholds        │
│                                                             │
└─────────────────────────────────────────────────────────────┘

     TPR (Recall)
        │
      1 ┤            ●●●●●●●●●●●●●●●●  Perfect classifier
        │          ●                   (AUC = 1.0)
        │        ●
    0.8 ┤      ●
        │     ●
    0.6 ┤   ●          ╱ Good model
        │  ●         ╱   (AUC = 0.85)
    0.4 ┤ ●        ╱
        │●       ╱
    0.2 ┤      ╱     ╱  Random classifier
        │    ╱     ╱    (AUC = 0.5)
      0 ┼───╱────╱─────────────────────
        0  0.2  0.4  0.6  0.8   1
                    FPR
```

### AUC (Area Under Curve)

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   AUC = Area Under the ROC Curve                            │
│                                                             │
│   Interpretation:                                           │
│   • AUC = 1.0  → Perfect classifier                         │
│   • AUC = 0.5  → Random guessing                            │
│   • AUC < 0.5  → Worse than random (flip predictions!)      │
│                                                             │
│   Meaning:                                                  │
│   "Probability that model ranks a random positive           │
│    higher than a random negative"                           │
│                                                             │
│   Guidelines:                                               │
│   • 0.9 - 1.0  : Excellent                                  │
│   • 0.8 - 0.9  : Good                                       │
│   • 0.7 - 0.8  : Fair                                       │
│   • 0.6 - 0.7  : Poor                                       │
│   • 0.5 - 0.6  : Fail                                       │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Precision-Recall Curve

Better than ROC for **imbalanced datasets**.

```
     Precision
        │
      1 ┤●●●●●●●●
        │        ●●●
    0.8 ┤           ●●●
        │              ●●
    0.6 ┤                ●●●
        │                   ●●●
    0.4 ┤                      ●●●
        │                         ●●
    0.2 ┤                           ●●●
        │                              ●
      0 ┼───────────────────────────────────
        0  0.2  0.4  0.6  0.8   1
                   Recall

   Area Under PR Curve (AUC-PR):
   • Better for imbalanced classes
   • Random classifier has AUC-PR ≈ positive class ratio
```

---

## Regression Metrics

### Mean Squared Error (MSE)

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│              1   n                                          │
│   MSE = ─────── Σ (yᵢ - ŷᵢ)²                               │
│              n  i=1                                         │
│                                                             │
│   Properties:                                               │
│   • Penalizes large errors more (squared)                   │
│   • Always positive                                         │
│   • Units are squared (e.g., $²)                            │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Root Mean Squared Error (RMSE)

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   RMSE = √MSE                                               │
│                                                             │
│   Properties:                                               │
│   • Same units as target variable                           │
│   • Interpretable (average error magnitude)                 │
│   • Still penalizes large errors                            │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Mean Absolute Error (MAE)

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│              1   n                                          │
│   MAE = ─────── Σ |yᵢ - ŷᵢ|                                 │
│              n  i=1                                         │
│                                                             │
│   Properties:                                               │
│   • Less sensitive to outliers                              │
│   • Same units as target                                    │
│   • Treats all errors equally                               │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### R-squared (R²)

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│              Σ(yᵢ - ŷᵢ)²                                    │
│   R² = 1 - ─────────────                                    │
│              Σ(yᵢ - ȳ)²                                     │
│                                                             │
│   Interpretation:                                           │
│   • Proportion of variance explained by model               │
│   • R² = 1: Perfect predictions                             │
│   • R² = 0: Model = just predicting mean                    │
│   • R² < 0: Model worse than predicting mean                │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Comparison

```
┌──────────┬───────────────────────────────────────────────────┐
│  Metric  │  When to Use                                      │
├──────────┼───────────────────────────────────────────────────┤
│  MSE     │  When large errors are particularly bad           │
│  RMSE    │  Same as MSE, but interpretable units             │
│  MAE     │  When outliers should not dominate                │
│  R²      │  To explain variance, compare models              │
│  MAPE    │  When relative error matters (percentage)         │
└──────────┴───────────────────────────────────────────────────┘
```

---

## Multiclass Metrics

### Averaging Methods

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│  For K classes, compute metric per class then combine:      │
│                                                             │
│  MACRO AVERAGE:                                             │
│  ───────────────                                            │
│  • Simple average across classes                            │
│  • Treats all classes equally                               │
│  • macro_precision = (P₁ + P₂ + P₃) / 3                     │
│                                                             │
│  MICRO AVERAGE:                                             │
│  ───────────────                                            │
│  • Aggregate TP, FP, FN across all classes                  │
│  • Favors majority classes                                  │
│  • micro_precision = Σ TPᵢ / Σ(TPᵢ + FPᵢ)                  │
│                                                             │
│  WEIGHTED AVERAGE:                                          │
│  ─────────────────                                          │
│  • Weight by class frequency                                │
│  • weighted = Σ(nᵢ × Pᵢ) / N                               │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Example

```
Class A (100 samples): Precision = 0.90
Class B (50 samples):  Precision = 0.80
Class C (50 samples):  Precision = 0.70

Macro:    (0.90 + 0.80 + 0.70) / 3 = 0.80
Weighted: (100×0.90 + 50×0.80 + 50×0.70) / 200 = 0.825
```

---

## Choosing the Right Metric

```
┌─────────────────────────────────────────────────────────────┐
│                    METRIC SELECTION GUIDE                   │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  BALANCED CLASSES?                                          │
│  ├── Yes → Accuracy is fine                                 │
│  └── No  → Use F1, AUC-PR, Weighted metrics                 │
│                                                             │
│  COST OF ERRORS?                                            │
│  ├── False Positive costly → Optimize Precision             │
│  │   (Spam filter: don't mark legit as spam)                │
│  └── False Negative costly → Optimize Recall                │
│      (Cancer detection: don't miss cancer)                  │
│                                                             │
│  NEED PROBABILITY RANKING?                                  │
│  ├── Yes → Use AUC-ROC                                      │
│  └── No  → Use threshold-based metrics                      │
│                                                             │
│  REGRESSION?                                                │
│  ├── Outliers matter → Use MSE/RMSE                         │
│  ├── Outliers shouldn't dominate → Use MAE                  │
│  └── Compare models → Use R²                                │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Python Implementation

```python
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report, roc_auc_score,
    roc_curve, precision_recall_curve, mean_squared_error,
    mean_absolute_error, r2_score
)
import numpy as np
import matplotlib.pyplot as plt

# Sample classification data
y_true = np.array([0, 0, 1, 1, 0, 1, 1, 0, 1, 1])
y_pred = np.array([0, 1, 1, 1, 0, 0, 1, 0, 1, 1])
y_prob = np.array([0.1, 0.4, 0.8, 0.9, 0.2, 0.3, 0.7, 0.1, 0.85, 0.95])

# Basic metrics
print(f"Accuracy:  {accuracy_score(y_true, y_pred):.3f}")
print(f"Precision: {precision_score(y_true, y_pred):.3f}")
print(f"Recall:    {recall_score(y_true, y_pred):.3f}")
print(f"F1 Score:  {f1_score(y_true, y_pred):.3f}")
print(f"ROC-AUC:   {roc_auc_score(y_true, y_prob):.3f}")

# Confusion matrix
print("\nConfusion Matrix:")
print(confusion_matrix(y_true, y_pred))

# Full report
print("\nClassification Report:")
print(classification_report(y_true, y_pred))

# Plot ROC curve
fpr, tpr, thresholds = roc_curve(y_true, y_prob)
plt.figure(figsize=(8, 6))
plt.plot(fpr, tpr, label=f'ROC (AUC = {roc_auc_score(y_true, y_prob):.2f})')
plt.plot([0, 1], [0, 1], 'k--', label='Random')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC Curve')
plt.legend()
plt.show()

# Regression metrics example
y_true_reg = np.array([3, 5, 2.5, 7, 4])
y_pred_reg = np.array([2.8, 5.2, 2.1, 7.5, 4.2])

print(f"\nMSE:  {mean_squared_error(y_true_reg, y_pred_reg):.3f}")
print(f"RMSE: {np.sqrt(mean_squared_error(y_true_reg, y_pred_reg)):.3f}")
print(f"MAE:  {mean_absolute_error(y_true_reg, y_pred_reg):.3f}")
print(f"R²:   {r2_score(y_true_reg, y_pred_reg):.3f}")
```

---

## Interview Questions

### Q1: When would you use precision vs recall?
**Answer:**
- **Precision** when false positives are costly (spam filter - don't want legit emails marked spam)
- **Recall** when false negatives are costly (disease detection - don't want to miss cases)

### Q2: Why is accuracy misleading for imbalanced datasets?
**Answer:** With 99% negative class, a model predicting all negatives gets 99% accuracy but is useless. Use F1, AUC-PR, or balanced accuracy instead.

### Q3: What's the difference between ROC-AUC and PR-AUC?
**Answer:**
- **ROC-AUC:** Shows TPR vs FPR, good for balanced classes
- **PR-AUC:** Shows Precision vs Recall, better for imbalanced classes because it focuses on positive class performance

### Q4: When would you use MAE over RMSE?
**Answer:** Use MAE when outliers shouldn't dominate the error metric. RMSE squares errors, penalizing large errors more. MAE treats all errors equally.

### Q5: What does an R² of 0.7 mean?
**Answer:** The model explains 70% of the variance in the target variable. The remaining 30% is unexplained variance (noise, missing features, etc.).

---

## Quick Reference

```
┌─────────────────────────────────────────────────────────────┐
│               METRICS CHEAT SHEET                           │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  CLASSIFICATION                                             │
│  Accuracy  = (TP+TN) / Total                                │
│  Precision = TP / (TP+FP)  "Of predicted pos, % correct"    │
│  Recall    = TP / (TP+FN)  "Of actual pos, % found"         │
│  F1        = 2PR / (P+R)   "Balance of P and R"             │
│  AUC-ROC   = Area under ROC curve (ranking ability)         │
│                                                             │
│  REGRESSION                                                 │
│  MSE  = Σ(y-ŷ)² / n     "Penalizes large errors"           │
│  RMSE = √MSE            "Same units as y"                   │
│  MAE  = Σ|y-ŷ| / n      "Robust to outliers"               │
│  R²   = 1 - SS_res/SS_tot "Variance explained"              │
│                                                             │
│  WHEN TO USE WHAT                                           │
│  Imbalanced     → F1, AUC-PR, Weighted                      │
│  FP costly      → Precision                                 │
│  FN costly      → Recall                                    │
│  Outliers exist → MAE                                       │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```
