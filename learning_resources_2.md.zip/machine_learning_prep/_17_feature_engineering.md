# Feature Engineering

## What is Feature Engineering?

Feature engineering is the process of using domain knowledge to create, transform, and select features that improve model performance.

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   "Coming up with features is difficult, time-consuming,   │
│    requires expert knowledge. Applied machine learning      │
│    is basically feature engineering."                       │
│                                            - Andrew Ng      │
│                                                             │
└─────────────────────────────────────────────────────────────┘

Raw Data                    Engineered Features
┌────────────────┐          ┌────────────────────────────┐
│ timestamp      │    →     │ hour, day_of_week, weekend │
│ 2023-06-15     │          │ month, quarter, is_holiday │
│ 14:30:00       │          │                            │
└────────────────┘          └────────────────────────────┘
```

---

## Types of Features

### Numerical Features

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   CONTINUOUS: Can take any value                            │
│   • Price, temperature, height                              │
│                                                             │
│   DISCRETE: Countable values                                │
│   • Number of rooms, items purchased                        │
│                                                             │
│   TRANSFORMATIONS:                                          │
│   • Scaling (StandardScaler, MinMaxScaler)                  │
│   • Log transform (for skewed data)                         │
│   • Box-Cox transform                                       │
│   • Polynomial features                                     │
│   • Binning/Discretization                                  │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Categorical Features

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   NOMINAL: No order (color, city, country)                  │
│   ORDINAL: Has order (size: S < M < L < XL)                 │
│                                                             │
│   ENCODING METHODS:                                         │
│   • Label Encoding (ordinal)                                │
│   • One-Hot Encoding (nominal)                              │
│   • Target Encoding                                         │
│   • Frequency Encoding                                      │
│   • Binary Encoding                                         │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Handling Numerical Features

### Scaling

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   STANDARDIZATION (Z-score):                                │
│              x - μ                                          │
│   x_scaled = ─────                                          │
│                σ                                            │
│   Range: (-∞, +∞), Mean=0, Std=1                            │
│   Use: Most algorithms                                      │
│                                                             │
│   MIN-MAX SCALING:                                          │
│              x - min                                        │
│   x_scaled = ─────────                                      │
│              max - min                                      │
│   Range: [0, 1]                                             │
│   Use: Neural networks, bounded algorithms                  │
│                                                             │
│   ROBUST SCALING:                                           │
│              x - median                                     │
│   x_scaled = ──────────────                                 │
│                 IQR                                         │
│   Use: When outliers present                                │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Log Transform

```
Problem: Highly skewed data

Before:                     After log(x):
   │                           │
   │█                          │    █ █ █
   │█                          │  █ █   █
   │█ █                        │█ █       █
   │█ █ █ █ █ █ . . .          │█           █ █
   └────────────────           └──────────────────
   
Reduces skewness, makes distribution more normal
```

### Binning/Discretization

```
Age (continuous) → Age Groups (categorical)

[0-17]   → "Child"
[18-35]  → "Young Adult"
[36-55]  → "Middle Age"
[56+]    → "Senior"

Benefits:
• Handles non-linear relationships
• Reduces noise
• More interpretable
```

---

## Handling Categorical Features

### Label Encoding

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Size: ["S", "M", "L", "XL"]                               │
│          ↓                                                  │
│         [0,  1,  2,  3]                                     │
│                                                             │
│   ⚠️ Only for ORDINAL categories!                          │
│   Implies S < M < L < XL (order matters)                    │
│                                                             │
│   Don't use for: ["Red", "Blue", "Green"]                   │
│   (Would imply Red < Blue < Green - wrong!)                 │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### One-Hot Encoding

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Color: ["Red", "Blue", "Green"]                           │
│                                                             │
│          Color_Red  Color_Blue  Color_Green                 │
│   Red       1          0           0                        │
│   Blue      0          1           0                        │
│   Green     0          0           1                        │
│                                                             │
│   ✓ No ordinal assumption                                   │
│   ⚠️ High cardinality = many columns (dimensionality)       │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Target Encoding

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Replace category with mean of target for that category    │
│                                                             │
│   City        Target(Price)      Encoded                    │
│   NYC         [100, 120, 110]    → 110                      │
│   LA          [80, 90, 85]       → 85                       │
│   Chicago     [70, 75, 80]       → 75                       │
│                                                             │
│   ⚠️ Risk of data leakage!                                  │
│   Solution: Use K-fold target encoding                      │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Handling Missing Values

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   1. DELETION                                               │
│      • Drop rows with missing values                        │
│      • Only if small % missing AND MCAR                     │
│                                                             │
│   2. IMPUTATION                                             │
│      • Mean/Median/Mode (simple)                            │
│      • Forward/Backward fill (time series)                  │
│      • KNN imputation (similar samples)                     │
│      • Model-based (predict missing values)                 │
│                                                             │
│   3. INDICATOR                                              │
│      • Create binary column: is_feature_missing             │
│      • Missingness itself may be informative!               │
│                                                             │
└─────────────────────────────────────────────────────────────┘

Example: Add missing indicator
┌───────┬───────────┬──────────────────┐
│  Age  │ Age_filled│ Age_was_missing  │
├───────┼───────────┼──────────────────┤
│  25   │    25     │        0         │
│  NaN  │    35     │        1         │  ← Median=35 + flag
│  45   │    45     │        0         │
└───────┴───────────┴──────────────────┘
```

---

## Creating New Features

### Date/Time Features

```
timestamp: "2023-06-15 14:30:00"
                    │
    ┌───────────────┼───────────────┐
    ▼               ▼               ▼
  Date            Time           Derived
  ─────           ────           ───────
  year            hour           is_weekend
  month           minute         is_holiday
  day             second         day_of_week
  quarter                        day_of_year
  week_of_year                   time_of_day (morning/afternoon/night)
                                 days_since_event
```

### Text Features

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Raw text: "Great product! Works perfectly."               │
│                                                             │
│   EXTRACTED FEATURES:                                       │
│   • Length: 35                                              │
│   • Word count: 4                                           │
│   • Has exclamation: True                                   │
│   • Sentiment score: 0.8                                    │
│   • TF-IDF vector: [0.2, 0.1, 0.3, ...]                    │
│   • Word embeddings                                         │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Interaction Features

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Creating features from combinations:                      │
│                                                             │
│   • price_per_sqft = price / square_feet                    │
│   • age_x_income = age × income                             │
│   • ratio = feature_a / feature_b                           │
│   • difference = feature_a - feature_b                      │
│                                                             │
│   Polynomial features:                                      │
│   [x₁, x₂] → [1, x₁, x₂, x₁², x₁x₂, x₂²]                   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Aggregation Features

```
For grouped data (e.g., user transactions):

user_id | transaction_amount
------------------------
  1     |     100
  1     |     150
  1     |     200
  2     |      50
  2     |     100

Aggregated features per user:
user_id | sum    | mean  | max  | min  | count | std
-------------------------------------------------
  1     | 450    | 150   | 200  | 100  |   3   | 50
  2     | 150    |  75   | 100  |  50  |   2   | 35
```

---

## Feature Selection

### 1. Filter Methods

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Score features independently, select top K                │
│                                                             │
│   CORRELATION:                                              │
│   • Pearson (linear)                                        │
│   • Spearman (monotonic)                                    │
│   • Remove highly correlated features (redundant)           │
│                                                             │
│   STATISTICAL TESTS:                                        │
│   • Chi-squared (categorical target)                        │
│   • ANOVA F-value (numerical features, categorical target)  │
│   • Mutual Information                                      │
│                                                             │
│   VARIANCE THRESHOLD:                                       │
│   • Remove low-variance features                            │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### 2. Wrapper Methods

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Use model performance to select features                  │
│                                                             │
│   FORWARD SELECTION:                                        │
│   Start empty, add one feature at a time                    │
│   [] → [A] → [A,C] → [A,C,D] → ...                         │
│                                                             │
│   BACKWARD ELIMINATION:                                     │
│   Start with all, remove one at a time                      │
│   [A,B,C,D] → [A,B,D] → [A,D] → ...                        │
│                                                             │
│   RECURSIVE FEATURE ELIMINATION (RFE):                      │
│   Train model, remove least important, repeat               │
│                                                             │
│   ⚠️ Expensive: Trains many models                         │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### 3. Embedded Methods

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Feature selection built into model training               │
│                                                             │
│   L1 REGULARIZATION (LASSO):                                │
│   • Drives coefficients to exactly zero                     │
│   • Automatic feature selection                             │
│                                                             │
│   TREE-BASED IMPORTANCE:                                    │
│   • Random Forest feature_importances_                      │
│   • Based on impurity decrease                              │
│                                                             │
│   PERMUTATION IMPORTANCE:                                   │
│   • Shuffle feature, measure performance drop               │
│   • Model-agnostic                                          │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Python Implementation

```python
import pandas as pd
import numpy as np
from sklearn.preprocessing import (
    StandardScaler, MinMaxScaler, LabelEncoder, 
    OneHotEncoder, PolynomialFeatures
)
from sklearn.impute import SimpleImputer, KNNImputer
from sklearn.feature_selection import (
    SelectKBest, f_classif, mutual_info_classif,
    RFE, SelectFromModel
)
from sklearn.ensemble import RandomForestClassifier

# --- SCALING ---
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_train)

# --- ENCODING ---
# One-Hot
encoder = OneHotEncoder(sparse=False, handle_unknown='ignore')
X_encoded = encoder.fit_transform(X[['category_column']])

# Or with pandas
X_encoded = pd.get_dummies(df, columns=['category'], drop_first=True)

# Target Encoding (careful with leakage!)
def target_encode(train, test, col, target):
    means = train.groupby(col)[target].mean()
    train_encoded = train[col].map(means)
    test_encoded = test[col].map(means)
    # Fill missing with global mean
    global_mean = train[target].mean()
    test_encoded = test_encoded.fillna(global_mean)
    return train_encoded, test_encoded

# --- MISSING VALUES ---
# Simple imputation
imputer = SimpleImputer(strategy='median')
X_imputed = imputer.fit_transform(X)

# KNN imputation
knn_imputer = KNNImputer(n_neighbors=5)
X_imputed = knn_imputer.fit_transform(X)

# Add missing indicator
df['feature_missing'] = df['feature'].isna().astype(int)
df['feature'] = df['feature'].fillna(df['feature'].median())

# --- DATE FEATURES ---
df['datetime'] = pd.to_datetime(df['timestamp'])
df['year'] = df['datetime'].dt.year
df['month'] = df['datetime'].dt.month
df['day_of_week'] = df['datetime'].dt.dayofweek
df['hour'] = df['datetime'].dt.hour
df['is_weekend'] = df['day_of_week'].isin([5, 6]).astype(int)

# --- POLYNOMIAL FEATURES ---
poly = PolynomialFeatures(degree=2, include_bias=False)
X_poly = poly.fit_transform(X)

# --- FEATURE SELECTION ---
# Filter: SelectKBest
selector = SelectKBest(f_classif, k=10)
X_selected = selector.fit_transform(X, y)
selected_features = X.columns[selector.get_support()]

# Wrapper: RFE
rfe = RFE(RandomForestClassifier(), n_features_to_select=10)
rfe.fit(X, y)
selected_features = X.columns[rfe.support_]

# Embedded: SelectFromModel (L1)
from sklearn.linear_model import LogisticRegression
lasso = LogisticRegression(penalty='l1', solver='liblinear')
selector = SelectFromModel(lasso)
X_selected = selector.fit_transform(X, y)

# Feature importance
rf = RandomForestClassifier()
rf.fit(X, y)
importance = pd.DataFrame({
    'feature': X.columns,
    'importance': rf.feature_importances_
}).sort_values('importance', ascending=False)
```

---

## Interview Questions

### Q1: Why is feature scaling important?
**Answer:** Many algorithms (SVM, KNN, gradient descent) use distances or gradients. Features on larger scales dominate. Scaling ensures equal contribution. Tree-based methods don't need scaling.

### Q2: One-hot vs Label encoding: when to use which?
**Answer:**
- **One-hot:** Nominal categories (no order) - color, city
- **Label:** Ordinal categories (has order) - size, rating
- One-hot for most ML models; label encoding may work for trees

### Q3: What is target leakage and how to avoid it?
**Answer:** Target leakage occurs when information about the target "leaks" into features. Examples:
- Using target to create features (without proper CV)
- Future information in time series
- Avoid: Always split before preprocessing, use pipelines

### Q4: How do you handle high-cardinality categorical features?
**Answer:**
- Target encoding (with proper CV)
- Frequency encoding
- Embedding (for neural networks)
- Group rare categories as "Other"
- Hash encoding

### Q5: How do you decide which features to create?
**Answer:**
- Domain knowledge (most important!)
- Exploratory Data Analysis (patterns, correlations)
- Try common transformations (log, ratios, interactions)
- Let tree models show important features
- Iterate based on model performance

---

## Quick Reference

```
┌─────────────────────────────────────────────────────────────┐
│            FEATURE ENGINEERING CHEAT SHEET                  │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  SCALING                                                    │
│  StandardScaler: Most algorithms                            │
│  MinMaxScaler:   Neural networks, bounded [0,1]             │
│  RobustScaler:   Outliers present                           │
│                                                             │
│  ENCODING                                                   │
│  One-Hot:  Nominal categories (no order)                    │
│  Label:    Ordinal categories (has order)                   │
│  Target:   High cardinality (use CV!)                       │
│                                                             │
│  MISSING VALUES                                             │
│  • Mean/Median imputation                                   │
│  • Add missing indicator column                             │
│  • KNN imputation for more sophisticated                    │
│                                                             │
│  NEW FEATURES                                               │
│  • Date parts (hour, day, month, weekend)                   │
│  • Ratios and differences                                   │
│  • Aggregations (mean, sum, count per group)                │
│  • Polynomial features                                      │
│  • Domain-specific knowledge                                │
│                                                             │
│  SELECTION                                                  │
│  • Correlation analysis (remove redundant)                  │
│  • Tree importance                                          │
│  • L1 regularization                                        │
│  • RFE for wrapper selection                                │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```
