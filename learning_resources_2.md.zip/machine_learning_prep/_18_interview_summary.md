# ML Interview Quick Reference & Common Questions

## Algorithm Selection Guide

```
┌─────────────────────────────────────────────────────────────┐
│                 WHICH ALGORITHM TO USE?                     │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  PROBLEM TYPE                                               │
│  ├── Regression                                             │
│  │   ├── Linear relationship? → Linear/Ridge/Lasso         │
│  │   ├── Complex patterns? → Random Forest, XGBoost        │
│  │   └── Need interpretability? → Linear, Decision Tree    │
│  │                                                          │
│  ├── Classification                                         │
│  │   ├── Binary, probabilities? → Logistic Regression      │
│  │   ├── Many features? → SVM (linear), Naive Bayes        │
│  │   ├── Tabular data? → XGBoost, Random Forest           │
│  │   └── Image/Text/Audio? → Deep Learning (CNN/RNN)       │
│  │                                                          │
│  └── Clustering                                             │
│      ├── Know K? → K-Means                                  │
│      ├── Unknown K, arbitrary shape? → DBSCAN              │
│      └── Need hierarchy? → Hierarchical clustering          │
│                                                             │
│  DATA SIZE                                                  │
│  ├── Small (< 1K) → Simple models, regularization          │
│  ├── Medium (1K-100K) → Most algorithms work               │
│  └── Large (> 100K) → SGD, Neural Networks, XGBoost        │
│                                                             │
│  INTERPRETABILITY NEEDED?                                   │
│  ├── Yes → Linear models, Decision Trees, SHAP values     │
│  └── No → Ensembles, Neural Networks                       │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Top 20 Interview Questions

### 1. Bias-Variance Tradeoff

**Q: Explain the bias-variance tradeoff.**

```
Total Error = Bias² + Variance + Irreducible Error

• BIAS: Error from simplifying assumptions (underfitting)
  - High bias: Model too simple, misses patterns
  
• VARIANCE: Error from sensitivity to training data (overfitting)
  - High variance: Model memorizes noise, poor generalization
  
• TRADEOFF: Reducing one often increases the other
  - Simple models: High bias, low variance
  - Complex models: Low bias, high variance
  - Goal: Find the sweet spot
```

---

### 2. Overfitting vs Underfitting

**Q: How do you detect and prevent overfitting?**

```
DETECTION:
• Training error << Validation error (big gap)
• Performance degrades on new data

PREVENTION:
• More training data
• Regularization (L1, L2, dropout)
• Simpler model (fewer parameters)
• Cross-validation
• Early stopping
• Data augmentation
```

---

### 3. Gradient Descent

**Q: Explain gradient descent and its variants.**

```
CONCEPT: Iteratively update weights in direction of steepest descent

w = w - α × ∂L/∂w

VARIANTS:
• Batch GD: All samples per update (stable, slow)
• SGD: 1 sample per update (fast, noisy)
• Mini-batch: Batch of samples (balanced, GPU-friendly)

ADVANCED:
• Momentum: Accelerates in consistent direction
• Adam: Adaptive learning rates per parameter (most popular)
```

---

### 4. Regularization

**Q: What is regularization and what's the difference between L1 and L2?**

```
PURPOSE: Prevent overfitting by penalizing model complexity

L1 (LASSO): λΣ|w|
• Creates sparse solutions (some weights = 0)
• Feature selection
• Diamond constraint shape

L2 (RIDGE): λΣw²
• Shrinks weights toward zero (never exactly 0)
• Handles multicollinearity
• Circle constraint shape

CHOOSE L1: When feature selection needed
CHOOSE L2: When all features may be useful
ELASTIC NET: Combines both
```

---

### 5. Cross-Validation

**Q: Why use cross-validation?**

```
• Single split depends on random chance
• CV uses all data for both training and validation
• Provides mean AND variance of performance
• More reliable estimate of generalization

TYPES:
• K-Fold: Standard (K=5 or 10)
• Stratified: Maintains class proportions
• Time Series: Respects temporal order
• Nested: Hyperparameter tuning + evaluation
```

---

### 6. Evaluation Metrics

**Q: When would you use precision vs recall?**

```
PRECISION = TP / (TP + FP)
"Of predicted positives, how many are correct?"
→ Use when FALSE POSITIVES are costly
→ Example: Spam filter (don't mark legit as spam)

RECALL = TP / (TP + FN)
"Of actual positives, how many did we find?"
→ Use when FALSE NEGATIVES are costly
→ Example: Cancer detection (don't miss cancer)

F1 SCORE = 2 × P × R / (P + R)
→ Balance of both
→ Use with imbalanced classes
```

---

### 7. Handling Imbalanced Data

**Q: How do you handle imbalanced datasets?**

```
TECHNIQUES:
1. Resampling
   • Oversample minority (SMOTE)
   • Undersample majority
   
2. Class Weights
   • Give minority class higher weight
   
3. Different Metrics
   • Use F1, AUC-PR instead of accuracy
   
4. Threshold Adjustment
   • Don't use 0.5; tune threshold
   
5. Ensemble Methods
   • Balanced Random Forest
```

---

### 8. Feature Scaling

**Q: Why is feature scaling important?**

```
ALGORITHMS THAT NEED SCALING:
• Gradient-based (Neural Networks)
• Distance-based (KNN, SVM, K-Means)
• Regularization (coefficients comparable)

DON'T NEED SCALING:
• Tree-based (Random Forest, XGBoost)

METHODS:
• StandardScaler: Z-score, mean=0, std=1
• MinMaxScaler: Range [0, 1]
• RobustScaler: Uses median/IQR (outliers)
```

---

### 9. Decision Trees vs Random Forest

**Q: Why is Random Forest better than a single Decision Tree?**

```
SINGLE TREE:
• Prone to overfitting
• High variance (sensitive to data changes)
• Unstable

RANDOM FOREST:
• Ensemble of trees (bagging)
• Each tree trained on bootstrap sample
• Each split considers random subset of features
• Averaging reduces variance
• More stable and generalizable
```

---

### 10. XGBoost

**Q: What makes XGBoost so effective?**

```
KEY FEATURES:
1. Gradient Boosting + Regularization
   • L1/L2 on leaf weights

2. Second-order gradients
   • Uses Hessian for better optimization

3. Efficient implementation
   • Parallel tree building
   • Handles sparse data

4. Built-in handling
   • Missing values
   • Early stopping

5. Hyperparameter tuning
   • Learning rate, depth, subsample, etc.
```

---

### 11. SVM

**Q: What are support vectors?**

```
SUPPORT VECTORS: Data points on or closest to the margin

• Only these points determine the decision boundary
• Removing other points doesn't change the hyperplane
• Sparse representation (memory efficient)

KERNEL TRICK:
• Maps data to higher dimension without computing it
• Enables non-linear decision boundaries
• Common: RBF, polynomial

C PARAMETER:
• Small C: Wider margin, more regularization
• Large C: Narrower margin, less regularization
```

---

### 12. Naive Bayes

**Q: Why is it called "naive"?**

```
NAIVE ASSUMPTION: Features are conditionally independent given class

P(X|C) = P(x₁|C) × P(x₂|C) × ... × P(xₙ|C)

WHY "NAIVE"?
• Real-world features are often correlated
• Assumption is rarely true

WHY IT WORKS ANYWAY?
• Classification only needs correct ranking
• Errors often cancel out
• Simple and fast
• Works well for text classification
```

---

### 13. Neural Networks

**Q: What is the vanishing gradient problem?**

```
PROBLEM:
• Gradients become very small during backpropagation
• Early layers barely update
• Training stalls

CAUSE:
• Sigmoid/tanh derivatives < 1
• Multiplying many small numbers → ~0

SOLUTIONS:
• ReLU activation (gradient = 1 for x > 0)
• Batch normalization
• Residual connections (skip connections)
• Proper weight initialization (Xavier, He)
```

---

### 14. PCA

**Q: What is PCA and when would you use it?**

```
PCA: Find directions of maximum variance

STEPS:
1. Center data (subtract mean)
2. Compute covariance matrix
3. Find eigenvectors/eigenvalues
4. Project onto top k eigenvectors

USE CASES:
• Dimensionality reduction
• Noise reduction
• Visualization (2D/3D)
• Preprocessing for ML

LIMITATIONS:
• Only captures linear relationships
• Requires scaling
• Components hard to interpret
```

---

### 15. K-Means Clustering

**Q: How does K-Means work and what are its limitations?**

```
ALGORITHM:
1. Initialize K centroids randomly
2. Assign points to nearest centroid
3. Update centroids to cluster means
4. Repeat until convergence

LIMITATIONS:
• Must specify K in advance
• Sensitive to initialization (use K-Means++)
• Assumes spherical clusters
• Sensitive to outliers
• Can't find non-convex clusters

CHOOSING K:
• Elbow method (WCSS)
• Silhouette score
• Domain knowledge
```

---

### 16. Ensemble Methods

**Q: Bagging vs Boosting?**

```
BAGGING (e.g., Random Forest):
• Train models in PARALLEL
• Bootstrap samples
• Average predictions
• REDUCES VARIANCE
• Less prone to overfit

BOOSTING (e.g., XGBoost):
• Train models SEQUENTIALLY
• Each focuses on previous errors
• Weighted combination
• REDUCES BIAS
• Can overfit (needs regularization)
```

---

### 17. Feature Engineering

**Q: What's the most important thing in feature engineering?**

```
"Applied ML is basically feature engineering" - Andrew Ng

KEY PRINCIPLES:
1. Domain knowledge is crucial
2. Understand your data (EDA)
3. Transform non-linear relationships (log, poly)
4. Create meaningful interactions
5. Handle missing values thoughtfully
6. Remove redundant features

COMMON TECHNIQUES:
• Date features (hour, day, weekend)
• Aggregations (mean, count per group)
• Ratios and differences
• Binning continuous variables
• One-hot encoding categories
```

---

### 18. Learning Rate

**Q: How do you choose the learning rate?**

```
TOO SMALL: Slow convergence, may get stuck
TOO LARGE: Oscillates, may diverge

STRATEGIES:
1. Start with common values (0.1, 0.01, 0.001)
2. Learning rate finder (increase until loss spikes)
3. Learning rate scheduling:
   • Step decay
   • Cosine annealing
   • Warm restarts
4. Use Adam (adaptive per parameter)
```

---

### 19. Train/Test/Validation

**Q: Why do we need a validation set separate from test set?**

```
TRAINING SET: Learn parameters (weights)
VALIDATION SET: Tune hyperparameters, choose model
TEST SET: Final unbiased performance estimate

WHY SEPARATE VALIDATION?
• If we tune on test set, we "leak" test info
• Test performance becomes optimistic
• Validation allows model selection without bias

NESTED CV:
• Inner loop: Tune hyperparameters
• Outer loop: Unbiased evaluation
```

---

### 20. Handling Missing Data

**Q: How do you handle missing values?**

```
UNDERSTAND TYPE:
• MCAR: Missing Completely at Random
• MAR: Missing at Random (depends on observed)
• MNAR: Missing Not at Random (depends on unobserved)

STRATEGIES:
1. Deletion (if small % and MCAR)
2. Imputation:
   • Mean/Median/Mode (simple)
   • KNN imputation (similar samples)
   • Model-based (predict missing)
3. Missing indicator (missingness is information)
4. Multiple imputation (uncertainty estimation)
```

---

## Quick Comparison Tables

### Algorithms Complexity

```
┌──────────────────┬───────────────┬───────────────┐
│    Algorithm     │   Training    │  Prediction   │
├──────────────────┼───────────────┼───────────────┤
│ Linear Regression│    O(np²)     │     O(p)      │
│ Logistic Regress │  O(np) iter   │     O(p)      │
│ Decision Tree    │  O(np log n)  │   O(depth)    │
│ Random Forest    │  O(tnp log n) │  O(t×depth)   │
│ SVM              │  O(n²) - O(n³)│   O(sv × p)   │
│ KNN              │     O(1)      │   O(np)       │
│ K-Means          │  O(nkdi)      │    O(kp)      │
│ Neural Network   │  O(n×params)  │   O(params)   │
└──────────────────┴───────────────┴───────────────┘
n=samples, p=features, k=clusters, t=trees, d=depth
```

### When to Use What

```
┌────────────────────┬────────────────────────────────────────┐
│ Situation          │ Algorithm                              │
├────────────────────┼────────────────────────────────────────┤
│ Baseline           │ Logistic/Linear Regression             │
│ Tabular data       │ XGBoost, Random Forest                 │
│ Text classification│ Naive Bayes, BERT                      │
│ Image recognition  │ CNN                                    │
│ Sequence data      │ RNN, LSTM, Transformer                 │
│ Small data         │ Simple models, regularization          │
│ High dimensions    │ SVM, Naive Bayes, L1 regularization    │
│ Interpretability   │ Linear models, Decision Trees          │
│ Fast prediction    │ Logistic Regression, Naive Bayes       │
└────────────────────┴────────────────────────────────────────┘
```

---

## Final Tips

```
┌─────────────────────────────────────────────────────────────┐
│                   INTERVIEW TIPS                            │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│ 1. UNDERSTAND THE PROBLEM                                   │
│    • What type? (classification, regression, clustering)    │
│    • What metrics matter? (business context)                │
│    • What are the constraints? (latency, interpretability)  │
│                                                             │
│ 2. START SIMPLE                                             │
│    • Baseline model first                                   │
│    • Then iterate with complexity                           │
│                                                             │
│ 3. KNOW YOUR ALGORITHMS                                     │
│    • Assumptions                                            │
│    • Hyperparameters                                        │
│    • When they fail                                         │
│                                                             │
│ 4. PRACTICAL EXPERIENCE                                     │
│    • Kaggle competitions                                    │
│    • Personal projects                                      │
│    • Real-world edge cases                                  │
│                                                             │
│ 5. COMMUNICATE CLEARLY                                      │
│    • Explain intuition, not just formulas                   │
│    • Use examples                                           │
│    • Acknowledge tradeoffs                                  │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

**Good luck with your interview!**
