# Introduction to Machine Learning

## What is Machine Learning?

Machine Learning is a subset of Artificial Intelligence that enables systems to **learn patterns from data** and make decisions without being explicitly programmed.

```
┌─────────────────────────────────────────────────────────────┐
│                    ARTIFICIAL INTELLIGENCE                  │
│  ┌───────────────────────────────────────────────────────┐  │
│  │              MACHINE LEARNING                         │  │
│  │  ┌─────────────────────────────────────────────────┐  │  │
│  │  │           DEEP LEARNING                         │  │  │
│  │  │  (Neural Networks with many layers)             │  │  │
│  │  └─────────────────────────────────────────────────┘  │  │
│  └───────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

---

## Types of Machine Learning

### 1. Supervised Learning
**Definition:** Learning from labeled data (input-output pairs)

```
Training Data:
┌──────────────┬────────────┐
│   Input X    │  Output Y  │
├──────────────┼────────────┤
│ House 2000sqft│  $300,000 │  ← Labels provided
│ House 1500sqft│  $225,000 │
│ House 3000sqft│  $450,000 │
└──────────────┴────────────┘
         │
         ▼
    ┌─────────┐
    │  Model  │  ← Learns mapping f(X) → Y
    └─────────┘
         │
         ▼
New Input: 2500sqft → Predicts: $375,000
```

**Types:**
- **Regression:** Predicting continuous values (price, temperature)
- **Classification:** Predicting discrete categories (spam/not spam, cat/dog)

**Common Algorithms:**
- Linear Regression
- Logistic Regression
- Decision Trees
- Random Forest
- SVM
- Neural Networks

---

### 2. Unsupervised Learning
**Definition:** Learning patterns from unlabeled data

```
Input Data (No Labels):
┌──────────────────────────┐
│  ● ●    ●               │
│   ● ●  ●                │
│              ■ ■  ■     │
│               ■ ■       │
│  ▲ ▲                    │
│   ▲  ▲                  │
└──────────────────────────┘
         │
         ▼
    ┌─────────┐
    │  Model  │  ← Discovers hidden patterns
    └─────────┘
         │
         ▼
Clusters Found:
┌──────────────────────────┐
│ (●●●●●)  (■■■■■)  (▲▲▲▲) │
│ Cluster1  Cluster2  Cluster3│
└──────────────────────────┘
```

**Types:**
- **Clustering:** Grouping similar data points (K-Means, DBSCAN)
- **Dimensionality Reduction:** Reducing features (PCA, t-SNE)
- **Association:** Finding rules (Apriori, Market Basket Analysis)

---

### 3. Reinforcement Learning
**Definition:** Learning through trial and error with rewards/penalties

```
┌─────────────────────────────────────────────────┐
│                                                 │
│    ┌─────────┐    Action    ┌─────────────┐    │
│    │  Agent  │ ───────────► │ Environment │    │
│    │ (Model) │              │  (World)    │    │
│    └─────────┘              └─────────────┘    │
│         ▲                          │           │
│         │      State + Reward      │           │
│         └──────────────────────────┘           │
│                                                 │
└─────────────────────────────────────────────────┘

Goal: Maximize cumulative reward over time
```

**Examples:**
- Game playing (Chess, Go, Atari)
- Robotics
- Autonomous vehicles
- Recommendation systems

---

## Key ML Terminology

| Term | Definition | Example |
|------|------------|---------|
| **Features (X)** | Input variables | House size, bedrooms, location |
| **Labels (Y)** | Target variable | House price |
| **Training Set** | Data used to train model | 80% of data |
| **Test Set** | Data used to evaluate model | 20% of data |
| **Model** | Mathematical function learned | f(X) = wX + b |
| **Parameters** | Values learned during training | Weights, biases |
| **Hyperparameters** | Values set before training | Learning rate, epochs |
| **Overfitting** | Model memorizes training data | Poor generalization |
| **Underfitting** | Model too simple | High error on both sets |

---

## The ML Pipeline

```
┌────────────────────────────────────────────────────────────────────┐
│                        ML WORKFLOW                                  │
└────────────────────────────────────────────────────────────────────┘
     │
     ▼
┌─────────────┐    ┌─────────────┐    ┌─────────────┐    ┌──────────┐
│ 1. Problem  │───►│ 2. Data     │───►│ 3. Feature  │───►│ 4. Model │
│ Definition  │    │ Collection  │    │ Engineering │    │ Selection│
└─────────────┘    └─────────────┘    └─────────────┘    └──────────┘
                                                              │
     ┌────────────────────────────────────────────────────────┘
     ▼
┌─────────────┐    ┌─────────────┐    ┌─────────────┐    ┌──────────┐
│ 5. Model    │───►│ 6. Model    │───►│ 7. Model    │───►│ 8. Deploy│
│ Training    │    │ Evaluation  │    │ Tuning      │    │ & Monitor│
└─────────────┘    └─────────────┘    └─────────────┘    └──────────┘
```

---

## Interview Questions

### Q1: What's the difference between supervised and unsupervised learning?
**Answer:** Supervised learning uses labeled data to learn a mapping from inputs to outputs. Unsupervised learning finds hidden patterns in unlabeled data without predefined outputs.

### Q2: What is the difference between classification and regression?
**Answer:** Classification predicts discrete categories (spam/not spam), while regression predicts continuous values (price, temperature).

### Q3: What is overfitting and how do you prevent it?
**Answer:** Overfitting occurs when a model learns noise in training data, performing well on training but poorly on new data. Prevention methods:
- More training data
- Regularization (L1/L2)
- Cross-validation
- Dropout (neural networks)
- Early stopping
- Simpler models

### Q4: What is the bias-variance tradeoff?
**Answer:** 
- **Bias:** Error from oversimplified assumptions (underfitting)
- **Variance:** Error from sensitivity to small fluctuations (overfitting)
- **Tradeoff:** Reducing one often increases the other; goal is to find the sweet spot

```
Error
  │
  │   Total Error
  │   ╲     ╱
  │    ╲   ╱
  │     ╲ ╱
  │      ╳  ← Optimal complexity
  │     ╱ ╲
  │ Bias   Variance
  │────────────────────► Model Complexity
     Simple      Complex
```

---

## Quick Reference Card

```
┌─────────────────────────────────────────────────────────────┐
│                    ML CHEAT SHEET                           │
├─────────────────────────────────────────────────────────────┤
│ SUPERVISED                                                  │
│   ├── Regression: Linear, Polynomial, Ridge, Lasso         │
│   └── Classification: Logistic, SVM, Trees, KNN            │
├─────────────────────────────────────────────────────────────┤
│ UNSUPERVISED                                                │
│   ├── Clustering: K-Means, DBSCAN, Hierarchical            │
│   └── Dimensionality: PCA, t-SNE, LDA                      │
├─────────────────────────────────────────────────────────────┤
│ REINFORCEMENT                                               │
│   └── Q-Learning, Deep Q-Networks, Policy Gradient         │
└─────────────────────────────────────────────────────────────┘
```
