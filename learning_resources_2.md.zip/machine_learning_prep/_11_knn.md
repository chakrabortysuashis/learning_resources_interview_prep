# K-Nearest Neighbors (KNN)

## What is KNN?

K-Nearest Neighbors is a **non-parametric, lazy learning** algorithm that makes predictions based on the K closest training examples.

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   "Tell me who your neighbors are, and I'll tell you       │
│    who you are"                                             │
│                                                             │
│   • Non-parametric: No assumptions about data distribution  │
│   • Lazy learning: No training phase, stores all data       │
│   • Instance-based: Uses actual instances for prediction    │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## How KNN Works

### Classification

```
Step 1: Choose K (number of neighbors)

Step 2: For a new point, find K nearest neighbors

            │
        ○   │   ●  ●
          ○ │ ●
        ○   │    ●
      ○  ○  │  ?    ← New point
            │   ●
        ○   │ ●   ●
            │

Step 3: Count votes from neighbors (K=3)

            │
            │      ╱─────╲
        ○   │   ●(│ ●     │
          ○ │ ● (│        │
        ○   │    │●       │
      ○  ○  │  ? │  ← 2 ●, 1 ○
            │   ●│       ╱
        ○   │ ●  │╲─────╱
            │
            
Step 4: Predict majority class → ● (Class 1)
```

### Regression

```
For regression, instead of voting:
  
  ŷ = (1/K) Σ yᵢ   (average of K neighbors' values)
  
  Or weighted average:
  ŷ = Σ wᵢyᵢ / Σ wᵢ   where wᵢ = 1/distance
```

---

## Distance Metrics

### Euclidean Distance (L2)

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   d(x, y) = √[Σ(xᵢ - yᵢ)²]                                 │
│                                                             │
│   "Straight line" distance                                  │
│                                                             │
│        y                                                    │
│        │     ●B                                             │
│        │    /│                                              │
│        │   / │  d = √[(x₂-x₁)² + (y₂-y₁)²]                 │
│        │  /  │                                              │
│        │ ●A──┘                                              │
│        └──────────── x                                      │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Manhattan Distance (L1)

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   d(x, y) = Σ|xᵢ - yᵢ|                                     │
│                                                             │
│   "City block" distance                                     │
│                                                             │
│        y                                                    │
│        │     ●B                                             │
│        │     │                                              │
│        │     │  d = |x₂-x₁| + |y₂-y₁|                      │
│        │     │                                              │
│        │ ●A──┘                                              │
│        └──────────── x                                      │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Minkowski Distance (General)

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   d(x, y) = (Σ|xᵢ - yᵢ|^p)^(1/p)                           │
│                                                             │
│   p = 1: Manhattan                                          │
│   p = 2: Euclidean                                          │
│   p → ∞: Chebyshev (max difference)                        │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Distance Comparison

```
              ●B (4,3)
             /│╲
            / │ ╲
           /  │  ╲
          /   │   ╲ Chebyshev = max(4,3) = 4
Euclidean = 5 │    ╲
         /    │     
        ●A────┘ Manhattan = 4+3 = 7
       (0,0)
```

---

## Choosing K

```
K=1 (overfitting):              K=too large (underfitting):

    │ ●  ○    ●                     │ ●  ○    ●
    │   ●  ○                        │   ●  ○
    │ ○    ●                        │ ○    ●
    │   ?                           │   ?
    │ ●  ○  ●                       │ ●  ○  ●
                                    
  Complex, noisy                  Too smooth, ignores
  decision boundary               local structure

            ↓
        
K optimal (cross-validated):

    │ ●  ○    ●
    │   ●  ○
    │ ○    ●
    │   ?
    │ ●  ○  ●
    
  Good balance!
```

### Guidelines for Choosing K

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   • Start with K = √n (where n = number of samples)         │
│   • Use odd K for binary classification (avoid ties)        │
│   • Use cross-validation to find optimal K                  │
│   • Plot error vs K (elbow method)                          │
│                                                             │
│   Error                                                     │
│     │                                                       │
│     │●                                                      │
│     │ ●●                                                    │
│     │   ●●●●●●● ← Optimal K (elbow)                        │
│     │          ●●●●●●●●                                     │
│     │                                                       │
│     └───────────────────── K                                │
│       1  3  5  7  9  11  ...                                │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Weighted KNN

### Problem with Simple Voting

```
K=5 example:
           ○ (close)
          ╱
        ╱
      ? ──── ○ (close)
        ╲
          ● (close)
            ╲
              ● (far)
                ╲
                  ● (very far)

Simple voting: 3 ● vs 2 ○ → Predict ●
But ○ neighbors are CLOSER!
```

### Solution: Distance-Weighted Voting

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Weight by inverse distance:                               │
│                                                             │
│   wᵢ = 1 / d(x, xᵢ)                                         │
│                                                             │
│   Or inverse squared:                                       │
│   wᵢ = 1 / d(x, xᵢ)²                                        │
│                                                             │
│   Closer neighbors have MORE influence                      │
│                                                             │
└─────────────────────────────────────────────────────────────┘

Example:
  ○ at distance 1: weight = 1/1 = 1.0
  ○ at distance 2: weight = 1/2 = 0.5
  ● at distance 3: weight = 1/3 = 0.33
  ● at distance 5: weight = 1/5 = 0.20
  ● at distance 8: weight = 1/8 = 0.125

  ○ total: 1.0 + 0.5 = 1.5
  ● total: 0.33 + 0.20 + 0.125 = 0.655

  Predict: ○ (higher weighted vote)
```

---

## Feature Scaling

### Why Scaling is Critical

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Without scaling:                                          │
│                                                             │
│   Feature 1: Age (20-80)                                    │
│   Feature 2: Salary (20000-150000)                          │
│                                                             │
│   d = √[(age₂-age₁)² + (salary₂-salary₁)²]                 │
│     = √[(30)² + (50000)²]                                   │
│     ≈ √[900 + 2500000000]                                   │
│     ≈ salary difference only!                               │
│                                                             │
│   Age becomes IRRELEVANT because salary dominates!          │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Solution: Normalize/Standardize

```
Min-Max Scaling:           StandardScaler:
                           
     x - min                    x - μ
x' = ─────────             x' = ───────
     max - min                    σ

Range: [0, 1]              Mean = 0, Std = 1
```

---

## Curse of Dimensionality

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   In high dimensions, ALL points become equidistant!        │
│                                                             │
│   As dimensions increase:                                   │
│   • Distance to nearest ≈ distance to farthest             │
│   • Data becomes sparse                                     │
│   • KNN loses meaning                                       │
│                                                             │
└─────────────────────────────────────────────────────────────┘

          Ratio of max to min distance
          │
        1 ┤                    ●●●●●●●●●
          │                ●●●
          │            ●●●
          │         ●●
          │      ●●
          │   ●●
          │●●
          └──────────────────────────────────
             1    10   100  1000
                   Dimensions
                   
         As d → ∞, ratio → 1 (all distances equal!)
```

### Solutions

```
• Dimensionality reduction (PCA, feature selection)
• Use only relevant features
• Increase sample size exponentially with dimensions
```

---

## Advantages and Disadvantages

```
┌─────────────────────────────────────────────────────────────┐
│   ✅ ADVANTAGES                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│   • Simple, easy to understand                              │
│   • No training phase (lazy learning)                       │
│   • Naturally handles multiclass                            │
│   • No assumptions about data distribution                  │
│   • Easily adapts to new data                               │
│   • Works well with small datasets                          │
│                                                             │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│   ❌ DISADVANTAGES                                          │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│   • Slow prediction (compute distance to ALL points)        │
│   • High memory (store entire dataset)                      │
│   • Sensitive to irrelevant features                        │
│   • Sensitive to feature scaling                            │
│   • Curse of dimensionality                                 │
│   • Sensitive to imbalanced classes                         │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Speeding Up KNN

### KD-Tree

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Organizes points in a binary tree for faster search       │
│                                                             │
│        │                     [x < 5?]                       │
│    ●   │   ●                 /      \                       │
│        │                  Yes        No                     │
│    ●   │       ●       [y < 3?]   [y < 4?]                  │
│        │                /    \     /    \                   │
│    ────┼────────       ●     ●    ●     ●                   │
│        │                                                    │
│                                                             │
│   Average: O(log n) instead of O(n)                         │
│   Works well for low dimensions (< 20)                      │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Ball Tree

```
Works better for high dimensions
Organizes points in nested hyper-spheres
```

### Approximate Nearest Neighbors (ANN)

```
Libraries: FAISS, Annoy, ScaNN
Trade some accuracy for speed
Essential for large-scale applications
```

---

## Python Implementation

```python
from sklearn.neighbors import KNeighborsClassifier, KNeighborsRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import cross_val_score, GridSearchCV
from sklearn.pipeline import Pipeline
import numpy as np
import matplotlib.pyplot as plt

# Always scale for KNN!
pipe = Pipeline([
    ('scaler', StandardScaler()),
    ('knn', KNeighborsClassifier())
])

# Find optimal K
k_range = range(1, 31)
cv_scores = []

for k in k_range:
    pipe.set_params(knn__n_neighbors=k)
    scores = cross_val_score(pipe, X, y, cv=5, scoring='accuracy')
    cv_scores.append(scores.mean())

# Plot K vs accuracy
plt.plot(k_range, cv_scores)
plt.xlabel('K')
plt.ylabel('Cross-Validation Accuracy')
plt.title('KNN: Choosing K')
plt.show()

# Grid search for hyperparameters
param_grid = {
    'knn__n_neighbors': [3, 5, 7, 9, 11],
    'knn__weights': ['uniform', 'distance'],
    'knn__metric': ['euclidean', 'manhattan']
}

grid = GridSearchCV(pipe, param_grid, cv=5, scoring='accuracy')
grid.fit(X_train, y_train)

print(f"Best params: {grid.best_params_}")
print(f"Best score: {grid.best_score_:.3f}")

# Final model
knn = KNeighborsClassifier(
    n_neighbors=5,
    weights='distance',
    metric='euclidean',
    algorithm='auto'  # Chooses best: brute, kd_tree, or ball_tree
)
```

### From Scratch Implementation

```python
import numpy as np
from collections import Counter

class KNNClassifier:
    def __init__(self, k=3, weights='uniform'):
        self.k = k
        self.weights = weights
        
    def fit(self, X, y):
        self.X_train = X
        self.y_train = y
        
    def euclidean_distance(self, x1, x2):
        return np.sqrt(np.sum((x1 - x2) ** 2))
    
    def predict(self, X):
        predictions = [self._predict(x) for x in X]
        return np.array(predictions)
    
    def _predict(self, x):
        # Compute distances to all training points
        distances = [self.euclidean_distance(x, x_train) 
                     for x_train in self.X_train]
        
        # Get indices of k nearest
        k_indices = np.argsort(distances)[:self.k]
        k_labels = self.y_train[k_indices]
        k_distances = np.array(distances)[k_indices]
        
        if self.weights == 'uniform':
            # Simple majority vote
            most_common = Counter(k_labels).most_common(1)
            return most_common[0][0]
        else:  # distance weighted
            # Weight by inverse distance
            weights = 1 / (k_distances + 1e-8)  # Add small value to avoid division by zero
            class_weights = {}
            for label, weight in zip(k_labels, weights):
                class_weights[label] = class_weights.get(label, 0) + weight
            return max(class_weights, key=class_weights.get)
```

---

## Interview Questions

### Q1: Is KNN a parametric or non-parametric algorithm?
**Answer:** Non-parametric. It doesn't learn fixed parameters during training. The model IS the entire training dataset. It makes no assumptions about data distribution.

### Q2: Why is KNN called a lazy learner?
**Answer:** Because it doesn't have a training phase. It simply stores the training data and does all computation during prediction time. This contrasts with eager learners like neural networks that learn during training.

### Q3: How does K affect bias and variance?
**Answer:**
- **K=1:** Low bias, high variance (overfitting)
- **K=N:** High bias, low variance (underfitting, always predicts majority)
- **Optimal K:** Balance between the two

### Q4: Why is scaling important for KNN?
**Answer:** KNN uses distances. Features on larger scales will dominate the distance calculation. Without scaling, features with small ranges become irrelevant.

### Q5: How would you handle a large dataset with KNN?
**Answer:**
- Use approximate nearest neighbors (FAISS, Annoy)
- Use KD-tree or Ball-tree for moderate dimensions
- Dimensionality reduction (PCA)
- Subsample the data
- Use a different algorithm for very large data

---

## Quick Reference

```
┌─────────────────────────────────────────────────────────────┐
│                    KNN CHEAT SHEET                          │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ALGORITHM                                                  │
│  1. Store training data                                     │
│  2. Find K nearest neighbors                                │
│  3. Vote (classification) or average (regression)           │
│                                                             │
│  KEY HYPERPARAMETERS                                        │
│  K:       Number of neighbors (start with √n)               │
│  weights: 'uniform' or 'distance'                           │
│  metric:  'euclidean', 'manhattan', etc.                    │
│                                                             │
│  PREPROCESSING                                              │
│  • ALWAYS scale features                                    │
│  • Consider dimensionality reduction                        │
│                                                             │
│  TIPS                                                       │
│  • Use odd K for binary classification                      │
│  • Cross-validate to find optimal K                         │
│  • Use weighted voting for better results                   │
│  • Beware curse of dimensionality                           │
│                                                             │
│  COMPLEXITY                                                 │
│  Training: O(1) - just store                                │
│  Prediction: O(n×d) brute force, O(log n) with tree         │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```
