# Naive Bayes

## What is Naive Bayes?

Naive Bayes is a **probabilistic classifier** based on Bayes' theorem with the "naive" assumption of feature independence.

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   "Given the evidence (features), what's the probability    │
│    of each class?"                                          │
│                                                             │
│   Example: Email Classification                             │
│                                                             │
│   Features: contains "free", "winner", "click"              │
│                                                             │
│   P(spam | features) vs P(not spam | features)              │
│                                                             │
│   Predict class with higher probability                     │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Bayes' Theorem

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│                P(X|C) × P(C)                                │
│   P(C|X) = ─────────────────                                │
│                  P(X)                                       │
│                                                             │
│   Where:                                                    │
│   P(C|X)  = Posterior  (probability of class given features)│
│   P(X|C)  = Likelihood (probability of features given class)│
│   P(C)    = Prior      (probability of class)               │
│   P(X)    = Evidence   (probability of features)            │
│                                                             │
└─────────────────────────────────────────────────────────────┘

Visual:
                    Prior knowledge
                         ↓
    ┌─────────────────────────────────────┐
    │         P(C) × P(X|C)               │
    │  P(C|X) = ───────────────           │
    │              P(X)                   │
    │              ↑                      │
    │         Normalizer                  │
    └─────────────────────────────────────┘
                    ↓
             Posterior probability
```

---

## The Naive Assumption

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   NAIVE ASSUMPTION: Features are independent given class    │
│                                                             │
│   P(X|C) = P(x₁|C) × P(x₂|C) × P(x₃|C) × ... × P(xₙ|C)     │
│                                                             │
│   This simplifies computation enormously!                   │
│                                                             │
└─────────────────────────────────────────────────────────────┘

Example: Email spam detection
  Features: x₁="free", x₂="winner", x₃="money"
  
  Without independence:
    P("free","winner","money" | spam) = ??? (need huge dataset)
    
  With independence:
    P("free"|spam) × P("winner"|spam) × P("money"|spam)
    = 0.8 × 0.6 × 0.7 = 0.336
```

### Why "Naive"?

```
Reality:                         Assumption:

  "free" ←→ "money"               "free"    "money"
      ↕                              ↓         ↓
   "winner"                       Independent  Independent
   
Features ARE correlated          We PRETEND they're not
in real world                    (works surprisingly well!)
```

---

## The Classifier

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   For classification, we compare posteriors:                │
│                                                             │
│   ŷ = argmax P(C=c) × ∏ P(xᵢ|C=c)                          │
│         c           i                                       │
│                                                             │
│   Note: P(X) is same for all classes, so we ignore it!      │
│                                                             │
└─────────────────────────────────────────────────────────────┘

Example: Is email spam?

P(spam) × P("free"|spam) × P("click"|spam) × P("win"|spam)
= 0.3 × 0.8 × 0.7 × 0.6 = 0.1008

P(not spam) × P("free"|not spam) × P("click"|not spam) × P("win"|not spam)
= 0.7 × 0.1 × 0.2 × 0.1 = 0.0014

0.1008 > 0.0014 → Predict SPAM
```

---

## Types of Naive Bayes

### 1. Gaussian Naive Bayes

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   For CONTINUOUS features                                   │
│                                                             │
│   Assumes features follow Gaussian (normal) distribution:   │
│                                                             │
│              1              (x - μc)²                       │
│   P(x|C) = ─────── × exp(- ──────────)                      │
│            √(2πσc²)          2σc²                           │
│                                                             │
│   Parameters: mean μc and variance σc² for each feature     │
│               per class                                     │
│                                                             │
└─────────────────────────────────────────────────────────────┘

Visual:
                Class 0              Class 1
    P(x)        ╱╲                    ╱╲
               ╱  ╲                  ╱  ╲
              ╱    ╲                ╱    ╲
            ─╱──────╲──────────────╱──────╲──
               μ₀                     μ₁
```

### 2. Multinomial Naive Bayes

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   For DISCRETE features (counts)                            │
│   Common for TEXT CLASSIFICATION                            │
│                                                             │
│   Features: word counts or term frequencies                 │
│                                                             │
│                    count(word, class) + α                   │
│   P(word|class) = ────────────────────────────              │
│                   total_words(class) + α × vocab_size       │
│                                                             │
│   α = smoothing parameter (Laplace smoothing)               │
│                                                             │
└─────────────────────────────────────────────────────────────┘

Example: Document with word counts
  Document: "free money free"
  
  P(spam|doc) ∝ P(spam) × P("free"|spam)² × P("money"|spam)
```

### 3. Bernoulli Naive Bayes

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   For BINARY features (presence/absence)                    │
│                                                             │
│   Features: Does word appear? (0 or 1)                      │
│                                                             │
│   P(x|C) = P(i|C)^xᵢ × (1 - P(i|C))^(1-xᵢ)                 │
│                                                             │
│   Penalizes ABSENCE of features (unlike Multinomial)        │
│                                                             │
└─────────────────────────────────────────────────────────────┘

Example: Short text classification
  Features: [contains "free"?, contains "click"?]
  
  Bernoulli considers that "money" is ABSENT
  (which may be informative)
```

### Comparison

```
┌────────────────┬─────────────────────────────────────────────┐
│     Type       │         Use Case                            │
├────────────────┼─────────────────────────────────────────────┤
│   Gaussian     │ Continuous features, real-valued data       │
│   Multinomial  │ Text classification, word counts            │
│   Bernoulli    │ Binary features, short texts                │
└────────────────┴─────────────────────────────────────────────┘
```

---

## Laplace Smoothing

### The Zero Probability Problem

```
Problem: What if a word never appears in training for a class?

  P("bitcoin"|spam) = 0  (never seen in spam training data)
  
  P(spam|"free bitcoin") = P(spam) × P("free"|spam) × P("bitcoin"|spam)
                         = 0.3 × 0.8 × 0
                         = 0   ← Everything becomes zero!
```

### Solution: Add-α Smoothing

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│                    count(word, class) + α                   │
│   P(word|class) = ────────────────────────────              │
│                   total(class) + α × |vocabulary|           │
│                                                             │
│   α = 1: Laplace smoothing                                  │
│   α < 1: Lidstone smoothing                                 │
│                                                             │
└─────────────────────────────────────────────────────────────┘

Example with α=1:
  "bitcoin" count in spam = 0
  Total words in spam = 1000
  Vocabulary size = 10000
  
  P("bitcoin"|spam) = (0 + 1) / (1000 + 1×10000)
                    = 1/11000 ≈ 0.00009
                    
  Now it's small but NOT zero!
```

---

## Log Probabilities

### The Underflow Problem

```
Multiplying many small probabilities:

P(class|doc) ∝ 0.3 × 0.01 × 0.02 × 0.001 × 0.05 × ...
             = 0.00000000003 × ...
             → Eventually becomes 0 (underflow!)
```

### Solution: Use Log Probabilities

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   log P(C|X) = log P(C) + Σ log P(xᵢ|C)                    │
│                                                             │
│   Converts products to sums!                                │
│                                                             │
└─────────────────────────────────────────────────────────────┘

Instead of:  0.3 × 0.01 × 0.02 = 0.00006
Use:         log(0.3) + log(0.01) + log(0.02)
           = -1.2 + (-4.6) + (-3.9)
           = -9.7  ← Manageable number!
```

---

## Text Classification Example

```
Training Data:
┌───────────────────────────────────────┬──────────┐
│              Document                 │  Class   │
├───────────────────────────────────────┼──────────┤
│ "free money winner"                   │   spam   │
│ "free free click now"                 │   spam   │
│ "meeting tomorrow office"             │  not spam│
│ "project deadline update"             │  not spam│
└───────────────────────────────────────┴──────────┘

Calculate:
  P(spam) = 2/4 = 0.5
  P(not spam) = 2/4 = 0.5
  
  Word counts:
  spam: free=3, money=1, winner=1, click=1, now=1 (total=7)
  not spam: meeting=1, tomorrow=1, office=1, project=1, 
            deadline=1, update=1 (total=6)
  
  With Laplace smoothing (vocab_size=11):
  P("free"|spam) = (3+1)/(7+11) = 4/18 = 0.22
  P("free"|not spam) = (0+1)/(6+11) = 1/17 = 0.06

New document: "free money"
  P(spam|doc) ∝ 0.5 × 0.22 × 0.11 = 0.012
  P(not spam|doc) ∝ 0.5 × 0.06 × 0.06 = 0.002
  
  Predict: SPAM (0.012 > 0.002)
```

---

## Advantages and Disadvantages

```
┌─────────────────────────────────────────────────────────────┐
│   ✅ ADVANTAGES                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│   • Fast training and prediction                            │
│   • Works well with high-dimensional data                   │
│   • Works well with small training sets                     │
│   • Not sensitive to irrelevant features                    │
│   • Handles missing values naturally                        │
│   • Good baseline for text classification                   │
│   • Probabilistic predictions                               │
│                                                             │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│   ❌ DISADVANTAGES                                          │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│   • Independence assumption rarely holds                    │
│   • Poor probability estimates (but good ranking)           │
│   • Zero-frequency problem (needs smoothing)                │
│   • Cannot learn feature interactions                       │
│   • Assumes feature distribution (Gaussian, etc.)           │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Python Implementation

```python
from sklearn.naive_bayes import (
    GaussianNB, MultinomialNB, BernoulliNB
)
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report

# Gaussian Naive Bayes (continuous features)
gnb = GaussianNB()
gnb.fit(X_train, y_train)
y_pred = gnb.predict(X_test)

# For text classification
texts = ["free money winner", "meeting tomorrow", ...]
labels = [1, 0, ...]  # 1=spam, 0=not spam

# Vectorize text
vectorizer = CountVectorizer()
X = vectorizer.fit_transform(texts)

# Multinomial NB (word counts)
mnb = MultinomialNB(alpha=1.0)  # alpha = Laplace smoothing
mnb.fit(X_train, y_train)

# Bernoulli NB (binary features)
bnb = BernoulliNB(alpha=1.0, binarize=0.0)
bnb.fit(X_train, y_train)

# With TF-IDF
tfidf = TfidfVectorizer()
X_tfidf = tfidf.fit_transform(texts)

# Get probabilities
proba = mnb.predict_proba(X_test)

# See feature log probabilities
feature_log_prob = mnb.feature_log_prob_
# Shape: (n_classes, n_features)
```

### From Scratch: Gaussian NB

```python
import numpy as np

class GaussianNBScratch:
    def fit(self, X, y):
        self.classes = np.unique(y)
        self.n_classes = len(self.classes)
        self.n_features = X.shape[1]
        
        # Calculate mean, variance, and prior for each class
        self.mean = np.zeros((self.n_classes, self.n_features))
        self.var = np.zeros((self.n_classes, self.n_features))
        self.prior = np.zeros(self.n_classes)
        
        for idx, c in enumerate(self.classes):
            X_c = X[y == c]
            self.mean[idx, :] = X_c.mean(axis=0)
            self.var[idx, :] = X_c.var(axis=0)
            self.prior[idx] = X_c.shape[0] / X.shape[0]
    
    def _gaussian_pdf(self, x, mean, var):
        """Calculate Gaussian probability density"""
        eps = 1e-10  # Prevent division by zero
        coef = 1 / np.sqrt(2 * np.pi * var + eps)
        exponent = np.exp(-(x - mean)**2 / (2 * var + eps))
        return coef * exponent
    
    def _predict_single(self, x):
        posteriors = []
        
        for idx, c in enumerate(self.classes):
            prior = np.log(self.prior[idx])
            # Sum of log likelihoods (not product)
            likelihood = np.sum(np.log(
                self._gaussian_pdf(x, self.mean[idx], self.var[idx])
            ))
            posterior = prior + likelihood
            posteriors.append(posterior)
        
        return self.classes[np.argmax(posteriors)]
    
    def predict(self, X):
        return np.array([self._predict_single(x) for x in X])
```

---

## Interview Questions

### Q1: What is the "naive" assumption in Naive Bayes?
**Answer:** The assumption that all features are conditionally independent given the class. This means P(x₁,x₂|C) = P(x₁|C) × P(x₂|C). While rarely true in practice, this simplification makes the algorithm efficient and often works well.

### Q2: Why does Naive Bayes work well despite the independence assumption?
**Answer:**
- For classification, we only need to RANK classes, not get exact probabilities
- Even if probabilities are wrong, the ranking can still be correct
- Independence assumption gives equal "errors" to all classes
- Works especially well when features are actually somewhat independent

### Q3: What is Laplace smoothing and why is it needed?
**Answer:** Laplace smoothing adds α (usually 1) to all counts to avoid zero probabilities. Without it, a single unseen feature makes the entire class probability zero, regardless of other evidence.

### Q4: When would you use Multinomial vs Gaussian vs Bernoulli NB?
**Answer:**
- **Gaussian:** Continuous features (real-valued data)
- **Multinomial:** Count data, especially word frequencies in text
- **Bernoulli:** Binary features, presence/absence, short texts

### Q5: How do you handle continuous features in Naive Bayes?
**Answer:**
- Use Gaussian NB (assumes normal distribution per class)
- Discretize into bins
- Use kernel density estimation
- Gaussian is most common and works well in practice

---

## Quick Reference

```
┌─────────────────────────────────────────────────────────────┐
│               NAIVE BAYES CHEAT SHEET                       │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  CORE FORMULA                                               │
│  P(C|X) ∝ P(C) × ∏ P(xᵢ|C)                                 │
│                                                             │
│  TYPES                                                      │
│  Gaussian:     Continuous features, assumes normal dist     │
│  Multinomial:  Word counts, text classification             │
│  Bernoulli:    Binary features, presence/absence            │
│                                                             │
│  KEY TECHNIQUES                                             │
│  • Laplace smoothing (avoid zero probability)               │
│  • Log probabilities (avoid underflow)                      │
│                                                             │
│  COMMON USES                                                │
│  • Spam detection                                           │
│  • Text classification                                      │
│  • Sentiment analysis                                       │
│  • Document categorization                                  │
│                                                             │
│  WHEN TO USE                                                │
│  • Text data, high dimensions                               │
│  • Small training set                                       │
│  • Need fast training/prediction                            │
│  • Good baseline to compare against                         │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```
