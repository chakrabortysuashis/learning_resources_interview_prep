# Logistic Regression

## What is Logistic Regression?

Logistic Regression is a **supervised learning algorithm** for **binary classification**. Despite its name, it's used for classification, not regression.

```
                    Probability
                        │
                     1.0├────────────────────●●●●●●
                        │                   ╱
                     0.8├                  ╱
                        │                 ╱
                     0.6├                ╱
                        │               ╱
                     0.5├─────────────●───── Decision boundary
                        │            ╱
                     0.4├           ╱
                        │          ╱
                     0.2├         ╱
                        │        ╱
                     0.0├●●●●●●●╱
                        │
                        └─────────────────────────────
                        -6    -3     0     3     6
                              z = wᵀx + b
```

---

## Why Not Linear Regression for Classification?

```
Linear Regression for Classification:    Logistic Regression:
                                        
    y                                       P(y=1)
    │    ●●●                                │    ●●●●
  2 ─┤  ●   ╲                            1.0├────────●
    │ ●      ╲  (line can go               │       ╱
  1 ─┼────●───●──── outside 0-1!)      0.5 ├──────●───
    │      ╲                               │     ╱
  0 ─┼──●────●──●                       0.0├●●●●╱
    │ ●       ╲                            │
 -1 ─┤         ● (negative probability?)    └───────────
    └────────────                              x
    
Problems:                               Solution:
• Output not bounded                    • Output bounded [0,1]
• Can exceed 1 or go negative          • Represents probability
• Linear boundary                       • S-shaped curve (sigmoid)
```

---

## The Sigmoid Function

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│                        1                                    │
│   σ(z) = ─────────────────                                  │
│           1 + e⁻ᶻ                                           │
│                                                             │
│   Properties:                                               │
│   • Output range: (0, 1)                                    │
│   • σ(0) = 0.5                                              │
│   • σ(∞) → 1                                                │
│   • σ(-∞) → 0                                               │
│   • Derivative: σ'(z) = σ(z)(1 - σ(z))                      │
│                                                             │
└─────────────────────────────────────────────────────────────┘

         σ(z)
           │
        1 ─┤                    ●────────
           │                  ●
      0.75─┤                ●
           │              ●
       0.5─┤─────────────●───────────────
           │           ●
      0.25─┤         ●
           │       ●
         0─┤──────●
           │
           └──────────────────────────────── z
              -4   -2    0    2    4
```

---

## The Model

### Forward Pass

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Step 1: Linear combination                                │
│           z = wᵀx + b = w₁x₁ + w₂x₂ + ... + wₙxₙ + b       │
│                                                             │
│   Step 2: Apply sigmoid                                     │
│           ŷ = σ(z) = P(y=1|x)                               │
│                                                             │
│   Step 3: Make prediction                                   │
│           class = 1 if ŷ ≥ 0.5 else 0                       │
│                                                             │
└─────────────────────────────────────────────────────────────┘

Visual Pipeline:
┌───────┐      ┌───────────┐      ┌─────────┐      ┌──────────┐
│   X   │─────►│ z = wᵀx+b │─────►│  σ(z)   │─────►│ŷ ∈ (0,1) │
│ Input │      │  Linear   │      │ Sigmoid │      │  Output  │
└───────┘      └───────────┘      └─────────┘      └──────────┘
```

---

## Decision Boundary

The decision boundary is where P(y=1) = 0.5, which means z = 0.

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Decision boundary: wᵀx + b = 0                            │
│                                                             │
│   For 2D (two features x₁, x₂):                             │
│   w₁x₁ + w₂x₂ + b = 0                                       │
│                                                             │
│   Solving for x₂:                                           │
│   x₂ = -(w₁/w₂)x₁ - (b/w₂)                                  │
│                                                             │
└─────────────────────────────────────────────────────────────┘

    x₂
     │        ●  ●
     │    ●  ●  ●
     │  ●  ●      Decision boundary
     │    ●  ╱  (linear line)
     │      ╱
     │    ╱  ○  ○
     │  ╱  ○  ○
     │╱  ○ ○
     └────────────────── x₁
     
   ● = Class 1 (y=1)
   ○ = Class 0 (y=0)
```

---

## Cost Function

### Why Not MSE?

MSE with sigmoid creates a **non-convex** function with many local minima.

```
MSE Loss Surface:                  Cross-Entropy Loss Surface:
     J                                   J
     │ ●     ●                           │ ●
     │  ╲   ╱ ╲                          │  ╲
     │   ╲ ╱   ╲  Local                  │   ╲
     │    ●     ● minima                 │    ╲
     │           ╲                       │     ╲
     │            ●                      │      ●  Global min
     └────────────                       └────────────
          w                                   w
    (Non-convex - bad!)              (Convex - good!)
```

### Binary Cross-Entropy (Log Loss)

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   For single sample:                                        │
│   L(ŷ, y) = -[y·log(ŷ) + (1-y)·log(1-ŷ)]                   │
│                                                             │
│   For all samples:                                          │
│            1   m                                            │
│   J(w) = - ─  Σ [yᵢ·log(ŷᵢ) + (1-yᵢ)·log(1-ŷᵢ)]           │
│            m  i=1                                           │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Intuition Behind Log Loss

```
When y = 1 (actual positive):
  Loss = -log(ŷ)
  
  If ŷ = 0.99 → Loss = -log(0.99) ≈ 0.01 ✓ (low loss, good!)
  If ŷ = 0.01 → Loss = -log(0.01) ≈ 4.6  ✗ (high loss, bad!)
  
     Loss
      │
      │●
    4 ─┤ ●
      │  ●
    3 ─┤   ●
      │    ●
    2 ─┤     ●
      │       ●
    1 ─┤         ●
      │            ●●●
    0 ─┤               ●●●●●●
      └────────────────────────
        0   0.2  0.4  0.6  0.8  1
                    ŷ (prediction)
                    
When y = 0 (actual negative):
  Loss = -log(1-ŷ)
  
  If ŷ = 0.01 → Loss ≈ 0.01 ✓ (low loss, good!)
  If ŷ = 0.99 → Loss ≈ 4.6  ✗ (high loss, bad!)
```

---

## Gradient Computation

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   ∂J      1   m                                             │
│   ── = ─────  Σ (ŷᵢ - yᵢ) · xᵢ                             │
│   ∂w      m  i=1                                            │
│                                                             │
│   ∂J      1   m                                             │
│   ── = ─────  Σ (ŷᵢ - yᵢ)                                   │
│   ∂b      m  i=1                                            │
│                                                             │
│   Note: Same form as linear regression!                     │
│   (But ŷ = σ(wᵀx + b) instead of wᵀx + b)                  │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Multiclass Classification

### One-vs-Rest (OvR) / One-vs-All (OvA)

Train K binary classifiers, one for each class.

```
For 3 classes (A, B, C):

Classifier 1: A vs (B, C)  →  P(A)
Classifier 2: B vs (A, C)  →  P(B)  
Classifier 3: C vs (A, B)  →  P(C)

Final prediction: class with highest probability
```

### Softmax Regression (Multinomial Logistic)

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│                    e^(zₖ)                                   │
│   P(y=k|x) = ──────────────                                 │
│               Σⱼ e^(zⱼ)                                     │
│                                                             │
│   where zₖ = wₖᵀx + bₖ                                      │
│                                                             │
│   Properties:                                               │
│   • All probabilities sum to 1                              │
│   • Output is a probability distribution                    │
│                                                             │
└─────────────────────────────────────────────────────────────┘

Example:
  z = [2.0, 1.0, 0.1]
  
  e^z = [7.39, 2.72, 1.11]
  sum = 11.22
  
  softmax(z) = [0.659, 0.242, 0.099]
                 ↑
              Highest → Predict class 0
```

---

## Regularization

### L2 Regularization (Ridge)

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   J_regularized = J(w) + (λ/2m) Σ wⱼ²                       │
│                                                             │
│   Effect: Penalizes large weights                           │
│           Prevents overfitting                              │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### L1 Regularization (Lasso)

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   J_regularized = J(w) + (λ/m) Σ |wⱼ|                       │
│                                                             │
│   Effect: Can make weights exactly zero                     │
│           Performs feature selection                        │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Python Implementation

```python
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report

# Sample data
X = np.array([[1, 2], [2, 3], [3, 4], [4, 5], 
              [5, 6], [1, 0], [2, 1], [3, 2], [4, 3], [5, 4]])
y = np.array([0, 0, 0, 0, 0, 1, 1, 1, 1, 1])

# Train model
model = LogisticRegression()
model.fit(X, y)

# Predict
predictions = model.predict(X)
probabilities = model.predict_proba(X)

print(f"Accuracy: {accuracy_score(y, predictions)}")
print(f"Coefficients: {model.coef_}")
print(f"Intercept: {model.intercept_}")
```

### From Scratch Implementation

```python
class LogisticRegressionScratch:
    def __init__(self, learning_rate=0.01, n_iterations=1000):
        self.lr = learning_rate
        self.n_iterations = n_iterations
        self.weights = None
        self.bias = None
        
    def sigmoid(self, z):
        # Clip to prevent overflow
        z = np.clip(z, -500, 500)
        return 1 / (1 + np.exp(-z))
    
    def fit(self, X, y):
        n_samples, n_features = X.shape
        
        # Initialize parameters
        self.weights = np.zeros(n_features)
        self.bias = 0
        
        # Gradient descent
        for _ in range(self.n_iterations):
            # Forward pass
            z = np.dot(X, self.weights) + self.bias
            y_pred = self.sigmoid(z)
            
            # Compute gradients
            dw = (1/n_samples) * np.dot(X.T, (y_pred - y))
            db = (1/n_samples) * np.sum(y_pred - y)
            
            # Update parameters
            self.weights -= self.lr * dw
            self.bias -= self.lr * db
            
    def predict_proba(self, X):
        z = np.dot(X, self.weights) + self.bias
        return self.sigmoid(z)
    
    def predict(self, X, threshold=0.5):
        return (self.predict_proba(X) >= threshold).astype(int)
```

---

## Evaluation Metrics

```
┌─────────────────────────────────────────────────────────────┐
│                  CONFUSION MATRIX                           │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│                       Predicted                             │
│                    Neg       Pos                            │
│              ┌──────────┬──────────┐                        │
│         Neg  │    TN    │    FP    │  ← Type I Error        │
│  Actual      ├──────────┼──────────┤                        │
│         Pos  │    FN    │    TP    │  ← Type II Error       │
│              └──────────┴──────────┘                        │
│                                                             │
│  Accuracy  = (TP + TN) / (TP + TN + FP + FN)               │
│  Precision = TP / (TP + FP)    "Of predicted pos, % correct"│
│  Recall    = TP / (TP + FN)    "Of actual pos, % found"     │
│  F1 Score  = 2 × (Precision × Recall) / (P + R)            │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Interview Questions

### Q1: Why use sigmoid instead of threshold?
**Answer:** Sigmoid provides:
- Continuous probabilities (not just 0/1)
- Differentiable function for gradient descent
- Interpretable output as probability
- Smooth decision boundary

### Q2: What if classes are imbalanced?
**Answer:**
- Adjust class weights in the algorithm
- Use SMOTE or undersampling
- Use metrics like F1, AUC-ROC instead of accuracy
- Adjust decision threshold

### Q3: When would logistic regression fail?
**Answer:**
- Non-linearly separable data (use kernel methods or neural networks)
- Very high dimensional sparse data (may need regularization)
- Complex feature interactions (need feature engineering)
- Highly imbalanced datasets (need special handling)

### Q4: What is the difference between sigmoid and softmax?
**Answer:**
- **Sigmoid:** For binary classification, outputs single probability P(y=1)
- **Softmax:** For multiclass, outputs K probabilities that sum to 1

### Q5: How do you interpret logistic regression coefficients?
**Answer:** Each coefficient represents the change in log-odds for a one-unit change in the feature:
- Positive coefficient → increases probability of class 1
- e^(coefficient) = odds ratio

---

## Quick Reference

```
┌─────────────────────────────────────────────────────────────┐
│             LOGISTIC REGRESSION CHEAT SHEET                 │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Model:        ŷ = σ(wᵀx + b) = 1/(1 + e^(-(wᵀx + b)))     │
│                                                             │
│  Loss:         -[y·log(ŷ) + (1-y)·log(1-ŷ)]                │
│                                                             │
│  Gradient:     (ŷ - y) · x                                  │
│                                                             │
│  Decision:     y = 1 if ŷ ≥ 0.5, else y = 0                │
│                                                             │
│  Multiclass:   Use Softmax (one-hot encoding)              │
│                                                             │
│  Regularization: Add λ||w||² (L2) or λ||w||₁ (L1)          │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```
