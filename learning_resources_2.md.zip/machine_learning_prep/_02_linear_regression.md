# Linear Regression

## What is Linear Regression?

Linear Regression is a **supervised learning algorithm** that models the relationship between a dependent variable (Y) and one or more independent variables (X) by fitting a linear equation.

```
                    Price ($)
                        │
                     400├           ●
                        │         ●
                     300├       ●    ← Data points
                        │     ●
                     200├   ●   ════════ Best fit line
                        │ ●
                     100├●
                        │
                        └──────────────────────────
                          500  1000 1500 2000 2500
                                   Size (sqft)
```

---

## Simple Linear Regression

### The Equation

```
┌─────────────────────────────────────────┐
│                                         │
│        y = mx + b                       │
│                                         │
│   or in ML notation:                    │
│                                         │
│        ŷ = w₁x + w₀                     │
│                                         │
│   where:                                │
│     ŷ  = predicted value                │
│     x  = input feature                  │
│     w₁ = weight (slope)                 │
│     w₀ = bias (y-intercept)             │
│                                         │
└─────────────────────────────────────────┘
```

### Visual Intuition

```
         y
         │     
         │           /
         │         /   ← slope (w₁) = rise/run
         │       /
         │     /
    w₀ ──┼───●       ← y-intercept (bias)
         │  
         └────────────────── x
```

---

## Multiple Linear Regression

When you have multiple features:

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   ŷ = w₀ + w₁x₁ + w₂x₂ + w₃x₃ + ... + wₙxₙ                 │
│                                                             │
│   In vector notation:                                       │
│                                                             │
│   ŷ = Xw                                                    │
│                                                             │
│   where:                                                    │
│     X = feature matrix [m samples × n features]             │
│     w = weight vector [n × 1]                               │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

**Example:** Predicting house price
```
Price = w₀ + w₁(size) + w₂(bedrooms) + w₃(age) + w₄(location_score)
```

---

## Cost Function (Loss Function)

### Mean Squared Error (MSE)

The goal is to minimize the error between predictions and actual values.

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│              1   m                                          │
│   J(w) = ─────  Σ  (ŷᵢ - yᵢ)²                              │
│              m  i=1                                         │
│                                                             │
│   where:                                                    │
│     m = number of samples                                   │
│     ŷᵢ = predicted value for sample i                       │
│     yᵢ = actual value for sample i                          │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Visual: Why Squared Error?

```
         y                     ●  actual
         │                    /│
         │        ●──────────○ │ ← error (ŷ - y)
         │       /  predicted │
         │      /             │
         │     ●──────────────○
         │    /               
         │   ●────○           
         │  /                 
         └────────────────────────── x
         
Squaring the error:
1. Makes all errors positive
2. Penalizes larger errors more
3. Makes the function differentiable
```

---

## Finding Optimal Weights

### Method 1: Normal Equation (Closed-Form Solution)

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│         w = (XᵀX)⁻¹ Xᵀy                                     │
│                                                             │
│   Pros:                                                     │
│     • No iteration needed                                   │
│     • No hyperparameters                                    │
│                                                             │
│   Cons:                                                     │
│     • Slow when n (features) is large: O(n³)               │
│     • Requires matrix inverse (may not exist)              │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Method 2: Gradient Descent (Iterative)

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Repeat until convergence:                                 │
│                                                             │
│              ∂J                                             │
│   w = w - α ────                                            │
│              ∂w                                             │
│                                                             │
│   where α = learning rate                                   │
│                                                             │
└─────────────────────────────────────────────────────────────┘

Cost J(w)
    │
    │ ●  start
    │  ╲
    │   ╲
    │    ╲
    │     ╲
    │      ╲
    │       ●──── minimum (optimal w)
    └────────────────────────── w
```

---

## Assumptions of Linear Regression

```
┌─────────────────────────────────────────────────────────────┐
│                  5 KEY ASSUMPTIONS                          │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│ 1. LINEARITY                                                │
│    Relationship between X and Y is linear                   │
│    Check: Scatter plot, residual plot                       │
│                                                             │
│ 2. INDEPENDENCE                                             │
│    Observations are independent of each other               │
│    Check: Durbin-Watson test                                │
│                                                             │
│ 3. HOMOSCEDASTICITY                                         │
│    Constant variance of residuals                           │
│    Check: Residual vs. fitted plot                          │
│                                                             │
│ 4. NORMALITY                                                │
│    Residuals are normally distributed                       │
│    Check: Q-Q plot, histogram of residuals                  │
│                                                             │
│ 5. NO MULTICOLLINEARITY                                     │
│    Features are not highly correlated                       │
│    Check: VIF (Variance Inflation Factor)                   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Residual Analysis

```
Good (Homoscedastic)          Bad (Heteroscedastic)
       │                            │
       │  ●   ●    ●               │         ●  ●
       │    ●   ●                  │       ●
    0 ─┼───●──●───●────           0─┼──●──●────────
       │  ●    ●   ●               │ ●
       │    ●    ●                 │●
       └────────────────           └────────────────
         Fitted Values               Fitted Values
```

---

## Evaluation Metrics

### R-squared (Coefficient of Determination)

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│              SS_res         Σ(yᵢ - ŷᵢ)²                     │
│   R² = 1 - ────────  = 1 - ──────────────                   │
│              SS_tot         Σ(yᵢ - ȳ)²                      │
│                                                             │
│   Interpretation:                                           │
│     R² = 0.85 → Model explains 85% of variance              │
│     R² = 1.00 → Perfect fit                                 │
│     R² = 0.00 → Model explains nothing                      │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Other Metrics

| Metric | Formula | Use Case |
|--------|---------|----------|
| **MSE** | Σ(y - ŷ)² / n | General purpose |
| **RMSE** | √MSE | Same units as y |
| **MAE** | Σ\|y - ŷ\| / n | Less sensitive to outliers |
| **Adjusted R²** | 1 - (1-R²)(n-1)/(n-p-1) | Multiple features |

---

## Python Implementation

```python
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score

# Sample data
X = np.array([[1000], [1500], [2000], [2500], [3000]])
y = np.array([150000, 225000, 300000, 375000, 450000])

# Split data
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Train model
model = LinearRegression()
model.fit(X_train, y_train)

# Predictions
y_pred = model.predict(X_test)

# Evaluate
print(f"Coefficient (w₁): {model.coef_[0]}")
print(f"Intercept (w₀): {model.intercept_}")
print(f"R² Score: {r2_score(y_test, y_pred)}")
print(f"RMSE: {np.sqrt(mean_squared_error(y_test, y_pred))}")
```

### From Scratch Implementation

```python
class LinearRegressionScratch:
    def __init__(self, learning_rate=0.01, n_iterations=1000):
        self.lr = learning_rate
        self.n_iterations = n_iterations
        self.weights = None
        self.bias = None
        
    def fit(self, X, y):
        n_samples, n_features = X.shape
        
        # Initialize parameters
        self.weights = np.zeros(n_features)
        self.bias = 0
        
        # Gradient descent
        for _ in range(self.n_iterations):
            y_pred = np.dot(X, self.weights) + self.bias
            
            # Compute gradients
            dw = (1/n_samples) * np.dot(X.T, (y_pred - y))
            db = (1/n_samples) * np.sum(y_pred - y)
            
            # Update parameters
            self.weights -= self.lr * dw
            self.bias -= self.lr * db
            
    def predict(self, X):
        return np.dot(X, self.weights) + self.bias
```

---

## Interview Questions

### Q1: What are the assumptions of linear regression?
**Answer:** Linearity, independence, homoscedasticity, normality of residuals, and no multicollinearity.

### Q2: How do you handle multicollinearity?
**Answer:**
- Remove one of the correlated features
- Use PCA to reduce dimensions
- Use regularization (Ridge/Lasso)
- Check VIF and remove features with VIF > 5-10

### Q3: When would you use MSE vs MAE?
**Answer:**
- **MSE:** When large errors are particularly undesirable (penalizes outliers more)
- **MAE:** When you want robustness to outliers (treats all errors equally)

### Q4: What is the difference between R² and Adjusted R²?
**Answer:** R² always increases when adding features, even useless ones. Adjusted R² penalizes adding irrelevant features, making it better for multiple regression.

### Q5: Can linear regression be used for classification?
**Answer:** Technically possible but not recommended because:
- Output is not bounded between 0 and 1
- Can produce values outside class range
- Better to use logistic regression for classification

---

## Common Pitfalls

```
┌─────────────────────────────────────────────────────────────┐
│                    ⚠️ WATCH OUT FOR                         │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│ 1. Not checking assumptions                                 │
│    → Always visualize data first                            │
│                                                             │
│ 2. Ignoring outliers                                        │
│    → Can dramatically skew the line                         │
│                                                             │
│ 3. Extrapolating beyond data range                          │
│    → Model only valid within training range                 │
│                                                             │
│ 4. Confusing correlation with causation                     │
│    → Linear regression shows correlation, not causation     │
│                                                             │
│ 5. Not scaling features in multiple regression              │
│    → Features on different scales affect interpretation     │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```
