# Decision Trees

## What is a Decision Tree?

A Decision Tree is a **supervised learning algorithm** that makes predictions by learning a series of if-then-else decision rules from the data.

```
                        Is Age > 30?
                       /            \
                     Yes             No
                     /                \
            Is Income > 50K?       Is Student?
            /        \               /        \
          Yes        No            Yes        No
          /           \             /           \
     [Buy: Yes]   [Buy: No]   [Buy: Yes]   [Buy: No]
```

---

## Anatomy of a Decision Tree

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   ROOT NODE:    First decision (most important split)       │
│        ↓                                                    │
│   INTERNAL NODES: Decision points (if-then rules)           │
│        ↓                                                    │
│   BRANCHES:     Outcomes of decisions                       │
│        ↓                                                    │
│   LEAF NODES:   Final predictions (classes/values)          │
│                                                             │
└─────────────────────────────────────────────────────────────┘

                    ┌──────────┐
                    │  Root    │ ← Root Node (Feature A > 5?)
                    │  Node    │
                    └────┬─────┘
                    ╱         ╲
               Yes ╱           ╲ No
                 ╱               ╲
        ┌────────┴────┐    ┌─────┴───────┐
        │  Internal   │    │  Internal   │ ← Internal Nodes
        │   Node 1    │    │   Node 2    │
        └──────┬──────┘    └──────┬──────┘
              ╱ ╲                 ╱ ╲
            ╱     ╲             ╱     ╲
       ┌───┴───┐ ┌─┴───┐  ┌───┴───┐ ┌─┴───┐
       │Leaf 1 │ │Leaf 2│  │Leaf 3 │ │Leaf 4│ ← Leaf Nodes
       │Class A│ │Class B│  │Class A│ │Class B│   (Predictions)
       └───────┘ └──────┘  └───────┘ └──────┘
```

---

## How Trees Split: Impurity Measures

The goal is to find splits that create the **purest** child nodes (all same class).

### For Classification

#### Gini Impurity

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Gini(D) = 1 - Σ pᵢ²                                       │
│                 i                                           │
│                                                             │
│   where pᵢ = proportion of class i in dataset D            │
│                                                             │
│   Range: [0, 0.5] for binary                                │
│   • 0 = pure (all one class)                                │
│   • 0.5 = maximum impurity (50-50 split)                    │
│                                                             │
└─────────────────────────────────────────────────────────────┘

Example:
  Dataset: 60% Class A, 40% Class B
  Gini = 1 - (0.6² + 0.4²) = 1 - (0.36 + 0.16) = 0.48
  
  Pure dataset: 100% Class A
  Gini = 1 - (1.0² + 0²) = 0  ← Perfectly pure!
```

#### Entropy (Information Gain)

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Entropy(D) = - Σ pᵢ × log₂(pᵢ)                           │
│                  i                                          │
│                                                             │
│   Range: [0, 1] for binary                                  │
│   • 0 = pure (all one class)                                │
│   • 1 = maximum impurity (50-50 split)                      │
│                                                             │
│   Information Gain = Entropy(parent) - Weighted Entropy(children)│
│                                                             │
└─────────────────────────────────────────────────────────────┘

Example:
  Dataset: 50% Class A, 50% Class B
  Entropy = -(0.5×log₂(0.5) + 0.5×log₂(0.5))
          = -(0.5×(-1) + 0.5×(-1))
          = 1  ← Maximum uncertainty
```

### Visual: Gini vs Entropy

```
  Impurity
      │
    1 ┤ ●                              ● Entropy
      │   ●                          ●
  0.8 ┤     ●                      ●
      │       ●                  ●
  0.6 ┤         ●              ●
      │           ●          ●
  0.5 ┤─────────────●──────●─────────── Maximum Gini
      │               ●  ●
  0.4 ┤                 ●
      │              Gini
  0.2 ┤
      │
    0 ┼──────────────────────────────────
      0    0.2   0.4   0.5   0.6   0.8   1
                    p (proportion of class 1)
```

### For Regression

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Variance Reduction:                                       │
│                                                             │
│   Var(D) = (1/n) Σ (yᵢ - ȳ)²                               │
│                                                             │
│   Split Quality = Var(parent) - Weighted Var(children)      │
│                                                             │
│   Prediction at leaf = mean of y values                     │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Building a Tree: ID3/CART Algorithm

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   ALGORITHM:                                                │
│                                                             │
│   1. Start with all data at root                            │
│                                                             │
│   2. For each feature:                                      │
│      - Calculate impurity reduction for each possible split │
│      - Select best split (highest reduction)                │
│                                                             │
│   3. Split data into child nodes                            │
│                                                             │
│   4. Recursively repeat for each child                      │
│                                                             │
│   5. Stop when:                                             │
│      - Node is pure (all same class)                        │
│      - Max depth reached                                    │
│      - Min samples per node reached                         │
│      - No impurity improvement                              │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Example: Finding Best Split

```
Data: Age and Buy (Yes/No)
┌───────┬─────┐
│  Age  │ Buy │
├───────┼─────┤
│  25   │ No  │
│  30   │ No  │
│  35   │ Yes │
│  40   │ Yes │
│  45   │ Yes │
└───────┴─────┘

Try split at Age = 32:
  Left child (Age ≤ 32):  [No, No]     → 100% No  → Gini = 0
  Right child (Age > 32): [Yes, Yes, Yes] → 100% Yes → Gini = 0
  
  Weighted Gini = (2/5)×0 + (3/5)×0 = 0  ← Perfect split!
```

---

## Hyperparameters

```
┌─────────────────────────────────────────────────────────────┐
│                 IMPORTANT HYPERPARAMETERS                   │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│   max_depth:                                                │
│   • Maximum depth of tree                                   │
│   • Lower = less overfit, higher bias                       │
│   • Typical: 3-10                                           │
│                                                             │
│   min_samples_split:                                        │
│   • Minimum samples to split a node                         │
│   • Higher = less overfit                                   │
│   • Typical: 2-20                                           │
│                                                             │
│   min_samples_leaf:                                         │
│   • Minimum samples in a leaf node                          │
│   • Higher = smoother predictions                           │
│   • Typical: 1-10                                           │
│                                                             │
│   max_features:                                             │
│   • Number of features to consider per split                │
│   • Lower = more randomness, less overfit                   │
│                                                             │
│   criterion:                                                │
│   • 'gini' or 'entropy' (classification)                    │
│   • 'squared_error' (regression)                            │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Effect of max_depth

```
max_depth = 1 (stump):        max_depth = 3:             max_depth = ∞ (overfit):
                                                          
       ┌─┐                           ┌─┐                        ┌─┐
       │ │                          ╱   ╲                      ╱   ╲
      ╱   ╲                       ┌┴┐   ┌┴┐                 ┌─┴─┐  ┌┴┐
    [A]   [B]                    ╱   ╲ ╱   ╲               ╱ ╲   ╱  ╲ ╱╲
                               [A] [A][B] [B]            ...many levels...
                               
   High Bias                  Good Balance               High Variance
   (Underfits)                                          (Overfits)
```

---

## Pruning

### Why Prune?

```
Full tree (overfits):               Pruned tree:
                                    
        ┌───┐                           ┌───┐
       ╱     ╲                         ╱     ╲
    ┌──┴──┐ ┌─┴──┐                  [A]     [B]
   ╱   ╲  ╱  ╲  ╲                   
  ╱ ╲  ╱╲ ╱╲  ╱╲                  Simpler, generalizes better!
 [A][A][B][B][A][B]              
 
 Memorizes training data
```

### Pre-pruning vs Post-pruning

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   PRE-PRUNING (Early Stopping):                             │
│   • Stop growing tree early                                 │
│   • Set max_depth, min_samples_split, etc.                  │
│   • Faster, but may underfit                                │
│                                                             │
│   POST-PRUNING:                                             │
│   • Grow full tree, then remove branches                    │
│   • Use validation set to decide                            │
│   • Cost-Complexity Pruning (ccp_alpha)                     │
│   • More accurate, but slower                               │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Feature Importance

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Feature importance = Total impurity decrease              │
│                        from splits on that feature          │
│                                                             │
│   Normalized to sum to 1                                    │
│                                                             │
└─────────────────────────────────────────────────────────────┘

Example output:
┌─────────────────────┬────────────┐
│      Feature        │ Importance │
├─────────────────────┼────────────┤
│ Income              │    0.45    │ ████████████████████
│ Age                 │    0.30    │ █████████████
│ Education           │    0.15    │ ██████
│ Marital Status      │    0.10    │ ████
└─────────────────────┴────────────┘
```

---

## Advantages and Disadvantages

```
┌─────────────────────────────────────────────────────────────┐
│   ✅ ADVANTAGES                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│   • Easy to understand and interpret (visualize!)           │
│   • No feature scaling needed                               │
│   • Handles both numerical and categorical data             │
│   • Can capture non-linear relationships                    │
│   • Built-in feature selection                              │
│   • Fast prediction (O(depth))                              │
│                                                             │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│   ❌ DISADVANTAGES                                          │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│   • Prone to overfitting                                    │
│   • High variance (small data changes → different tree)     │
│   • Biased towards features with many levels                │
│   • Cannot extrapolate (predict outside training range)     │
│   • Greedy algorithm (locally optimal, not globally)        │
│   • Unstable (solved by ensemble methods)                   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Python Implementation

```python
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor
from sklearn.tree import plot_tree, export_text
from sklearn.model_selection import train_test_split
from sklearn.datasets import load_iris
import matplotlib.pyplot as plt

# Load data
iris = load_iris()
X, y = iris.data, iris.target
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# Train classifier
clf = DecisionTreeClassifier(
    max_depth=3,
    min_samples_split=5,
    min_samples_leaf=2,
    criterion='gini'
)
clf.fit(X_train, y_train)

# Evaluate
print(f"Training accuracy: {clf.score(X_train, y_train):.3f}")
print(f"Test accuracy: {clf.score(X_test, y_test):.3f}")

# Feature importance
for name, importance in zip(iris.feature_names, clf.feature_importances_):
    print(f"{name}: {importance:.3f}")

# Visualize tree
plt.figure(figsize=(20, 10))
plot_tree(clf, feature_names=iris.feature_names, 
          class_names=iris.target_names, filled=True, rounded=True)
plt.show()

# Text representation
print(export_text(clf, feature_names=iris.feature_names))
```

### From Scratch Implementation

```python
import numpy as np

class DecisionTreeNode:
    def __init__(self, feature=None, threshold=None, left=None, 
                 right=None, value=None):
        self.feature = feature       # Feature index for split
        self.threshold = threshold   # Threshold value for split
        self.left = left            # Left child
        self.right = right          # Right child
        self.value = value          # Prediction value (for leaf)

class DecisionTreeScratch:
    def __init__(self, max_depth=10, min_samples_split=2):
        self.max_depth = max_depth
        self.min_samples_split = min_samples_split
        self.root = None
        
    def gini(self, y):
        """Calculate Gini impurity"""
        classes = np.unique(y)
        n = len(y)
        gini = 1.0
        for c in classes:
            p = np.sum(y == c) / n
            gini -= p ** 2
        return gini
    
    def best_split(self, X, y):
        """Find best feature and threshold to split on"""
        best_gain = -1
        best_feature = None
        best_threshold = None
        
        n_samples, n_features = X.shape
        parent_gini = self.gini(y)
        
        for feature in range(n_features):
            thresholds = np.unique(X[:, feature])
            
            for threshold in thresholds:
                left_mask = X[:, feature] <= threshold
                right_mask = ~left_mask
                
                if np.sum(left_mask) == 0 or np.sum(right_mask) == 0:
                    continue
                
                # Calculate weighted Gini of children
                n_left = np.sum(left_mask)
                n_right = np.sum(right_mask)
                
                gini_left = self.gini(y[left_mask])
                gini_right = self.gini(y[right_mask])
                
                weighted_gini = (n_left/n_samples) * gini_left + \
                               (n_right/n_samples) * gini_right
                
                gain = parent_gini - weighted_gini
                
                if gain > best_gain:
                    best_gain = gain
                    best_feature = feature
                    best_threshold = threshold
                    
        return best_feature, best_threshold
    
    def build_tree(self, X, y, depth=0):
        """Recursively build the tree"""
        n_samples, n_features = X.shape
        n_classes = len(np.unique(y))
        
        # Stopping conditions
        if (depth >= self.max_depth or 
            n_classes == 1 or 
            n_samples < self.min_samples_split):
            leaf_value = np.argmax(np.bincount(y))
            return DecisionTreeNode(value=leaf_value)
        
        # Find best split
        best_feature, best_threshold = self.best_split(X, y)
        
        if best_feature is None:
            leaf_value = np.argmax(np.bincount(y))
            return DecisionTreeNode(value=leaf_value)
        
        # Split data
        left_mask = X[:, best_feature] <= best_threshold
        right_mask = ~left_mask
        
        # Recursively build children
        left_child = self.build_tree(X[left_mask], y[left_mask], depth + 1)
        right_child = self.build_tree(X[right_mask], y[right_mask], depth + 1)
        
        return DecisionTreeNode(feature=best_feature, threshold=best_threshold,
                               left=left_child, right=right_child)
    
    def fit(self, X, y):
        self.root = self.build_tree(X, y)
        
    def predict_sample(self, x, node):
        """Predict single sample"""
        if node.value is not None:
            return node.value
        
        if x[node.feature] <= node.threshold:
            return self.predict_sample(x, node.left)
        else:
            return self.predict_sample(x, node.right)
    
    def predict(self, X):
        return np.array([self.predict_sample(x, self.root) for x in X])
```

---

## Interview Questions

### Q1: What is the difference between Gini and Entropy?
**Answer:** Both measure impurity, but:
- **Gini:** Faster to compute (no log), ranges [0, 0.5]
- **Entropy:** Based on information theory, ranges [0, 1]
- In practice, they produce similar results

### Q2: Why are decision trees prone to overfitting?
**Answer:** They can grow until each leaf has one sample, perfectly memorizing training data. The greedy splitting creates complex boundaries that don't generalize. Solution: pruning, depth limits, ensembles.

### Q3: How does a decision tree handle missing values?
**Answer:** Options include:
- Surrogate splits (CART): Use backup features that correlate with primary
- Send to majority branch
- Create a separate branch for missing
- Impute before training

### Q4: Why can't decision trees extrapolate?
**Answer:** Predictions are averages of training samples in leaf nodes. If new data is outside the training range, it falls into the nearest leaf, predicting a value within the training range.

### Q5: What makes Random Forest better than a single tree?
**Answer:** Random Forest trains many trees on bootstrap samples with random feature subsets, then averages predictions. This reduces variance while maintaining low bias, solving the instability problem of single trees.

---

## Quick Reference

```
┌─────────────────────────────────────────────────────────────┐
│             DECISION TREE CHEAT SHEET                       │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  SPLITTING CRITERIA                                         │
│  Classification: Gini = 1 - Σpᵢ²                           │
│                  Entropy = -Σpᵢlog(pᵢ)                      │
│  Regression:     Variance reduction                         │
│                                                             │
│  KEY HYPERPARAMETERS                                        │
│  max_depth:         Control tree depth                      │
│  min_samples_split: Min samples to split                    │
│  min_samples_leaf:  Min samples in leaf                     │
│                                                             │
│  PREVENT OVERFITTING                                        │
│  • Limit depth (max_depth)                                  │
│  • Require more samples (min_samples_*)                     │
│  • Post-pruning (ccp_alpha)                                 │
│  • Use ensembles (Random Forest, Gradient Boosting)         │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```
