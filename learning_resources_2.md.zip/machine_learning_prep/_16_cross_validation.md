# Cross-Validation & Model Selection

## Why Cross-Validation?

Cross-validation provides a robust estimate of model performance by using different portions of data for training and validation.

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   PROBLEM with single train/test split:                     │
│                                                             │
│   • Performance depends on which data is in test set        │
│   • May get "lucky" or "unlucky" split                      │
│   • Wastes data (test set not used for training)            │
│                                                             │
│   SOLUTION: Cross-Validation                                │
│                                                             │
│   • Use ALL data for both training and validation           │
│   • Get multiple performance estimates                      │
│   • More reliable model assessment                          │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## K-Fold Cross-Validation

### The Process

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   5-Fold Cross-Validation:                                  │
│                                                             │
│   Data: [████████████████████████████████████████]          │
│                                                             │
│   Fold 1: [TEST][TRAIN][TRAIN][TRAIN][TRAIN] → Score 1      │
│   Fold 2: [TRAIN][TEST][TRAIN][TRAIN][TRAIN] → Score 2      │
│   Fold 3: [TRAIN][TRAIN][TEST][TRAIN][TRAIN] → Score 3      │
│   Fold 4: [TRAIN][TRAIN][TRAIN][TEST][TRAIN] → Score 4      │
│   Fold 5: [TRAIN][TRAIN][TRAIN][TRAIN][TEST] → Score 5      │
│                                                             │
│   Final Score = (Score1 + Score2 + ... + Score5) / 5        │
│   ± Standard Deviation                                      │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Choosing K

```
K = 5 (common):
  • 80% train, 20% test each fold
  • Good balance of bias/variance
  
K = 10 (also common):
  • 90% train, 10% test each fold
  • Lower bias, more computation
  
K = n (Leave-One-Out):
  • (n-1) train, 1 test each fold
  • Very low bias, high variance, expensive

     Bias
      │
      │●  K=n (LOOCV)
      │
      │  ●  K=10
      │
      │    ●  K=5
      │
      │      ●●●  K=2,3
      └──────────────────── Variance
        Low              High
```

---

## Types of Cross-Validation

### 1. K-Fold

```
Standard K-Fold (K=5):

Fold 1: |▓▓▓|░░░░░░░░░░|
Fold 2: |░░░|▓▓▓|░░░░░░|
Fold 3: |░░░░░░|▓▓▓|░░░|
Fold 4: |░░░░░░░░░|▓▓▓|░|
Fold 5: |░░░░░░░░░░░░|▓▓▓|

▓ = Validation  ░ = Training
```

### 2. Stratified K-Fold (for Classification)

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Maintains class proportions in each fold                  │
│                                                             │
│   Original: 70% Class A, 30% Class B                        │
│                                                             │
│   Each fold also has: ~70% Class A, ~30% Class B            │
│                                                             │
│   IMPORTANT for imbalanced datasets!                        │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### 3. Leave-One-Out (LOOCV)

```
n samples, n folds:

Fold 1: [VAL][TRAIN][TRAIN]...[TRAIN]
Fold 2: [TRAIN][VAL][TRAIN]...[TRAIN]
...
Fold n: [TRAIN][TRAIN]...[TRAIN][VAL]

• Each sample is validation exactly once
• Very expensive: O(n) model fits
• Low bias, high variance
```

### 4. Time Series Split

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   For time-ordered data: NEVER use future to predict past!  │
│                                                             │
│   Fold 1: [TRAIN][VAL][    ]                                │
│   Fold 2: [TRAIN][TRAIN][VAL]                               │
│   Fold 3: [TRAIN][TRAIN][TRAIN][VAL]                        │
│                                                             │
│   Training ALWAYS before validation in time                 │
│                                                             │
└─────────────────────────────────────────────────────────────┘

Time ───────────────────────────────────────►
      [TRAIN        |VAL  ]
      [TRAIN             |VAL  ]
      [TRAIN                  |VAL  ]
```

### 5. Group K-Fold

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   When samples belong to groups that shouldn't be split     │
│                                                             │
│   Example: Multiple images from same patient                │
│                                                             │
│   Patient 1: [img1, img2, img3] → All in same fold          │
│   Patient 2: [img4, img5]       → All in same fold          │
│                                                             │
│   Prevents data leakage between train/validation            │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Nested Cross-Validation

### The Problem

```
If you use CV for both:
  1. Hyperparameter tuning
  2. Model evaluation

You're overfitting to your validation set!
```

### Solution: Nested CV

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   OUTER LOOP (Model Evaluation):                            │
│   ┌───────────────────────────────────────────────────────┐ │
│   │ Fold 1: Test [###]  Train [-------------]             │ │
│   │                           │                           │ │
│   │         INNER LOOP (Hyperparameter Tuning):           │ │
│   │         ┌─────────────────────────────────┐           │ │
│   │         │ Inner Fold 1: [###][--------]   │           │ │
│   │         │ Inner Fold 2: [---][###][----]  │           │ │
│   │         │ Inner Fold 3: [-------][###]    │           │ │
│   │         │ → Best hyperparameters          │           │ │
│   │         └─────────────────────────────────┘           │ │
│   │                                                       │ │
│   │         Train on all inner data with best params      │ │
│   │         Evaluate on outer test fold → Score 1         │ │
│   │                                                       │ │
│   │ Fold 2: Train [###]  Test [-------------]             │ │
│   │         ... same inner CV ...             → Score 2   │ │
│   │                                                       │ │
│   │ ...                                                   │ │
│   └───────────────────────────────────────────────────────┘ │
│                                                             │
│   Final: Average of outer scores                            │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Hyperparameter Tuning

### Grid Search

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Try ALL combinations of parameters                        │
│                                                             │
│   param_grid = {                                            │
│       'C': [0.1, 1, 10],                                    │
│       'gamma': [0.01, 0.1, 1]                               │
│   }                                                         │
│                                                             │
│   Combinations: 3 × 3 = 9                                   │
│                                                             │
│           gamma=0.01  gamma=0.1  gamma=1                    │
│   C=0.1      ●           ●          ●                       │
│   C=1        ●           ●          ●                       │
│   C=10       ●           ●          ●                       │
│                                                             │
│   Exhaustive but expensive!                                 │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Random Search

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Sample random combinations                                │
│                                                             │
│   param_distributions = {                                   │
│       'C': uniform(0.1, 100),                               │
│       'gamma': uniform(0.001, 1)                            │
│   }                                                         │
│                                                             │
│           gamma                                             │
│             │      ●                                        │
│             │  ●        ●                                   │
│             │       ●                                       │
│             │    ●     ●   ●                                │
│             │  ●                                            │
│             └──────────────────── C                         │
│                                                             │
│   More efficient for large parameter spaces!                │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Bayesian Optimization

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Intelligently chooses next parameters based on           │
│   previous results                                          │
│                                                             │
│   1. Fit surrogate model (Gaussian Process)                 │
│   2. Find promising regions                                 │
│   3. Sample there                                           │
│   4. Update and repeat                                      │
│                                                             │
│   Best for expensive evaluations (deep learning)            │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Validation Strategies Summary

```
┌──────────────────┬──────────────────────────────────────────┐
│    Strategy      │    Use Case                              │
├──────────────────┼──────────────────────────────────────────┤
│ Train/Test Split │ Large data, quick evaluation             │
│ K-Fold           │ Standard choice, medium data             │
│ Stratified K-Fold│ Classification, imbalanced data          │
│ LOOCV            │ Small data, expensive training OK        │
│ Time Series Split│ Time-ordered data                        │
│ Group K-Fold     │ Grouped samples (same subject)           │
│ Nested CV        │ Hyperparameter tuning + evaluation       │
└──────────────────┴──────────────────────────────────────────┘
```

---

## Python Implementation

```python
from sklearn.model_selection import (
    cross_val_score, cross_validate,
    KFold, StratifiedKFold, LeaveOneOut, TimeSeriesSplit,
    GroupKFold, GridSearchCV, RandomizedSearchCV
)
from sklearn.ensemble import RandomForestClassifier
import numpy as np

# Basic cross-validation
model = RandomForestClassifier(random_state=42)
scores = cross_val_score(model, X, y, cv=5, scoring='accuracy')
print(f"Accuracy: {scores.mean():.3f} ± {scores.std():.3f}")

# Multiple metrics
cv_results = cross_validate(
    model, X, y, cv=5,
    scoring=['accuracy', 'precision', 'recall', 'f1'],
    return_train_score=True
)
for metric in ['accuracy', 'precision', 'recall', 'f1']:
    test_scores = cv_results[f'test_{metric}']
    print(f"{metric}: {test_scores.mean():.3f} ± {test_scores.std():.3f}")

# Stratified K-Fold (maintains class proportions)
skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
for train_idx, val_idx in skf.split(X, y):
    X_train, X_val = X[train_idx], X[val_idx]
    y_train, y_val = y[train_idx], y[val_idx]
    # Train and evaluate...

# Time Series Split
tscv = TimeSeriesSplit(n_splits=5)
for train_idx, val_idx in tscv.split(X):
    X_train, X_val = X[train_idx], X[val_idx]
    # Train and evaluate...

# Grid Search with CV
param_grid = {
    'n_estimators': [100, 200, 300],
    'max_depth': [5, 10, 15, None],
    'min_samples_split': [2, 5, 10]
}

grid_search = GridSearchCV(
    RandomForestClassifier(random_state=42),
    param_grid,
    cv=5,
    scoring='accuracy',
    n_jobs=-1,
    verbose=1
)
grid_search.fit(X_train, y_train)

print(f"Best parameters: {grid_search.best_params_}")
print(f"Best CV score: {grid_search.best_score_:.3f}")
print(f"Test score: {grid_search.score(X_test, y_test):.3f}")

# Random Search (more efficient)
from scipy.stats import randint, uniform

param_distributions = {
    'n_estimators': randint(100, 500),
    'max_depth': randint(3, 20),
    'min_samples_split': randint(2, 20)
}

random_search = RandomizedSearchCV(
    RandomForestClassifier(random_state=42),
    param_distributions,
    n_iter=50,  # Number of random combinations
    cv=5,
    scoring='accuracy',
    random_state=42,
    n_jobs=-1
)
random_search.fit(X_train, y_train)

# Nested Cross-Validation
from sklearn.model_selection import cross_val_score

inner_cv = StratifiedKFold(n_splits=3, shuffle=True, random_state=42)
outer_cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

# GridSearchCV in the inner loop
grid_search = GridSearchCV(
    RandomForestClassifier(random_state=42),
    param_grid,
    cv=inner_cv,
    scoring='accuracy'
)

# Cross-validation in the outer loop
nested_scores = cross_val_score(grid_search, X, y, cv=outer_cv, scoring='accuracy')
print(f"Nested CV Accuracy: {nested_scores.mean():.3f} ± {nested_scores.std():.3f}")
```

---

## Interview Questions

### Q1: Why do we need cross-validation instead of a single train/test split?
**Answer:** A single split gives one estimate that depends on the random split. Cross-validation gives multiple estimates, providing mean and variance of performance. It uses all data for both training and validation.

### Q2: When would you use Stratified K-Fold?
**Answer:** For classification problems, especially with imbalanced classes. It maintains the class distribution in each fold, ensuring representative validation sets.

### Q3: What is data leakage in cross-validation?
**Answer:** When information from validation/test data leaks into training. Examples:
- Preprocessing on full data before splitting
- Using future data in time series
- Same subject's samples in train and validation

### Q4: Grid Search vs Random Search: when to use which?
**Answer:**
- **Grid Search:** Small parameter space, need exhaustive search
- **Random Search:** Large parameter space, limited time budget. Studies show it often finds good solutions faster.

### Q5: What is nested cross-validation and when is it needed?
**Answer:** Nested CV uses an inner loop for hyperparameter tuning and outer loop for unbiased performance estimation. Needed when you want to both tune hyperparameters AND get an honest estimate of generalization performance.

---

## Quick Reference

```
┌─────────────────────────────────────────────────────────────┐
│            CROSS-VALIDATION CHEAT SHEET                     │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  CHOOSING K                                                 │
│  K=5:  Standard, good balance                               │
│  K=10: More accurate, more computation                      │
│  LOOCV: Small data, maximum train data                      │
│                                                             │
│  WHICH CV TO USE                                            │
│  Classification:    StratifiedKFold                         │
│  Time Series:       TimeSeriesSplit                         │
│  Grouped Data:      GroupKFold                              │
│  General:           KFold                                   │
│                                                             │
│  HYPERPARAMETER SEARCH                                      │
│  GridSearchCV:      Exhaustive, small space                 │
│  RandomizedSearchCV: Efficient, large space                 │
│  Bayesian:          Expensive evaluations                   │
│                                                             │
│  AVOID DATA LEAKAGE                                         │
│  • Preprocessing inside CV (use Pipeline)                   │
│  • No future data in time series                            │
│  • Keep groups together                                     │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```
