# Ensemble Methods

## The Big Picture: Why Ensembles?

Imagine you're trying to guess how many jellybeans are in a jar...

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│    THE JELLYBEAN EXPERIMENT                                                 │
│    ═══════════════════════════════════════════════════════════════════════  │
│                                                                             │
│         🫙                                                                  │
│        /==\        Ask ONE person:          Ask 100 people:                 │
│       |    |       "500 jellybeans!"        Guesses: 400, 520, 480,         │
│       |::::| ◄──── (might be way off)       510, 490, 505, 495...           │
│       |::::|                                                                │
│       |::::|                                Average = 498                   │
│        \==/                                 (very close to truth: 500!)     │
│                                                                             │
│    This is called "The Wisdom of Crowds"                                    │
│    Individual errors CANCEL OUT when you combine many opinions!             │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

**Ensemble Learning = Getting multiple models to "vote" instead of trusting just one**

---

## Real-World Analogies

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   SINGLE MODEL                           ENSEMBLE                           │
│   ════════════                           ════════════════════               │
│                                                                             │
│   Like asking ONE doctor                 Like getting a medical panel       │
│   ┌──────────┐                          ┌──────────┐                       │
│   │  Doctor  │──► "You have X"          │ Doctor 1 │──┐                    │
│   └──────────┘                          │ Doctor 2 │──┼──► Team Decision   │
│   (Hope they're right!)                 │ Doctor 3 │──┘                    │
│                                         └──────────┘                       │
│                                         (Multiple expert opinions)          │
│                                                                             │
│   ─────────────────────────────────────────────────────────────────────     │
│                                                                             │
│   Like ONE judge in a talent show       Like a panel of judges             │
│   ┌───────┐                             ┌───────┐┌───────┐┌───────┐        │
│   │   8   │                             │   7   ││   8   ││   9   │        │
│   └───────┘                             └───────┘└───────┘└───────┘        │
│   (Biased? Mood?)                       Average = 8 (fair!)                 │
│                                                                             │
│   ─────────────────────────────────────────────────────────────────────     │
│                                                                             │
│   Like betting on ONE horse             Like betting on TOP 3 horses        │
│   (high risk!)                          (safer, still profitable)           │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## The Three Main Types of Ensembles

```
                            ENSEMBLE METHODS
                                  ║
        ╔═════════════════════════╬═════════════════════════╗
        ║                         ║                         ║
        ▼                         ▼                         ▼
   ┌─────────┐              ┌─────────┐              ┌─────────┐
   │ BAGGING │              │BOOSTING │              │STACKING │
   │(Parallel)│             │(Sequential)│           │(Layered)│
   └─────────┘              └─────────┘              └─────────┘
        │                         │                         │
        ▼                         ▼                         ▼
   
   "Many students                "Learn from               "Best students
    do exam                       mistakes,                 become teachers
    independently,                keep improving"           for final answer"
    average scores"
   
        │                         │                         │
        ▼                         ▼                         ▼
   Random Forest              XGBoost                    Stacking
   Extra Trees               LightGBM                   Blending
                             CatBoost
                             AdaBoost
```

---

# PART 1: BAGGING (Bootstrap Aggregating)

## The Classroom Analogy

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   BAGGING IS LIKE: Having different study groups take the same test        │
│   ══════════════════════════════════════════════════════════════════════    │
│                                                                             │
│   Original Class Roster:  [Alice, Bob, Carol, David, Emma, Frank]           │
│                                                                             │
│                     ┌─────────────────────────────────┐                     │
│                     │    BOOTSTRAP SAMPLING           │                     │
│                     │    (Pick randomly WITH          │                     │
│                     │     replacement - same          │                     │
│                     │     person can be picked        │                     │
│                     │     multiple times!)            │                     │
│                     └─────────────────────────────────┘                     │
│                                    │                                        │
│           ┌────────────────────────┼────────────────────────┐               │
│           │                        │                        │               │
│           ▼                        ▼                        ▼               │
│                                                                             │
│    Study Group 1             Study Group 2             Study Group 3        │
│    ┌──────────────┐          ┌──────────────┐          ┌──────────────┐     │
│    │ Alice        │          │ Bob          │          │ Alice        │     │
│    │ Bob          │          │ Bob (again!) │          │ Carol        │     │
│    │ Carol        │          │ David        │          │ Carol (again!)│    │
│    │ Emma         │          │ Emma         │          │ David        │     │
│    │ Emma (again!)│          │ Frank        │          │ Frank        │     │
│    │ Frank        │          │ Frank (again!)│         │ Frank (again!)│    │
│    └──────────────┘          └──────────────┘          └──────────────┘     │
│           │                        │                        │               │
│           ▼                        ▼                        ▼               │
│                                                                             │
│    Each group develops          Each group develops       Each group        │
│    their OWN understanding      their OWN understanding   develops          │
│    and answers the test         and answers the test      their OWN...      │
│           │                        │                        │               │
│           │      Test Answer: A    │     Test Answer: B     │  Answer: A    │
│           │                        │                        │               │
│           └────────────────────────┼────────────────────────┘               │
│                                    │                                        │
│                                    ▼                                        │
│                          ┌─────────────────┐                                │
│                          │   FINAL VOTE    │                                │
│                          │   A: 2 votes    │                                │
│                          │   B: 1 vote     │                                │
│                          │                 │                                │
│                          │   Winner: A!    │                                │
│                          └─────────────────┘                                │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Why Does Bagging Work?

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   MATH MAGIC (in simple terms):                                             │
│   ═════════════════════════════                                             │
│                                                                             │
│   If ONE model makes errors with variance σ² (spread of errors)             │
│                                                                             │
│   Then AVERAGE of m models has variance: σ² / m                             │
│                                                                             │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                                                                     │   │
│   │    1 Model:         Errors spread: ████████████████ (σ²)           │   │
│   │                                                                     │   │
│   │    10 Models Avg:   Errors spread: ██ (σ²/10 = much smaller!)      │   │
│   │                                                                     │   │
│   │    100 Models Avg:  Errors spread: █ (σ²/100 = tiny!)              │   │
│   │                                                                     │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│   VISUAL EXAMPLE:                                                           │
│                                                                             │
│   Target: ◎                                                                 │
│                                                                             │
│   Single Model:                    Many Models Averaged:                    │
│   (might miss badly)               (errors cancel out!)                     │
│                                                                             │
│       ╭───────────╮                    ╭───────────╮                        │
│       │     X     │                    │           │                        │
│       │       ◎   │                    │     ◎X    │  ◄─ X is close!        │
│       │  X        │                    │           │                        │
│       │        X  │                    │           │                        │
│       ╰───────────╯                    ╰───────────╯                        │
│       (scattered)                      (centered!)                          │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Random Forest: Bagging + Extra Randomness

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   RANDOM FOREST = Bagging (random samples) + Random Feature Selection      │
│   ═══════════════════════════════════════════════════════════════════════   │
│                                                                             │
│   Analogy: Imagine training different TYPES of doctors                      │
│                                                                             │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                                                                     │   │
│   │   All features available: [Blood Pressure, Temperature, Weight,    │   │
│   │                            Heart Rate, Age, Blood Sugar]           │   │
│   │                                                                     │   │
│   │   Tree 1 can only see:    Tree 2 can only see:    Tree 3 sees:     │   │
│   │   ┌─────────────────┐     ┌─────────────────┐     ┌────────────┐   │   │
│   │   │ Blood Pressure  │     │ Temperature     │     │ Weight     │   │   │
│   │   │ Temperature     │     │ Heart Rate      │     │ Age        │   │   │
│   │   │ Age             │     │ Blood Sugar     │     │ Heart Rate │   │   │
│   │   └─────────────────┘     └─────────────────┘     └────────────┘   │   │
│   │   (like a specialist)     (different specialist)  (another one)    │   │
│   │                                                                     │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│   WHY? Each tree becomes an "expert" in different aspects!                  │
│   When they vote together, they cover all angles.                           │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Random Forest Visual

```
                           🌲 RANDOM FOREST 🌲
                           
        ╔═══════════════════════════════════════════════════════╗
        ║                   YOUR DATA                           ║
        ║   [🧑 Alice, 25, Fever, Cough, ...]                  ║
        ╚════════════════════════╦══════════════════════════════╝
                                 ║
         ┌───────────────────────╬───────────────────────┐
         │                       │                       │
    Bootstrap 1             Bootstrap 2             Bootstrap 3
    (random subset)         (random subset)         (random subset)
         │                       │                       │
         ▼                       ▼                       ▼
    ┌─────────┐             ┌─────────┐             ┌─────────┐
    │  🌲     │             │  🌲     │             │  🌲     │
    │ Tree 1  │             │ Tree 2  │             │ Tree 3  │
    │ (sees   │             │ (sees   │             │ (sees   │
    │ features│             │ features│             │ features│
    │ A,B,C)  │             │ B,D,E)  │             │ A,E,F)  │
    └────┬────┘             └────┬────┘             └────┬────┘
         │                       │                       │
    Prediction:             Prediction:             Prediction:
      "Flu"                   "Cold"                   "Flu"
         │                       │                       │
         └───────────────────────┼───────────────────────┘
                                 │
                                 ▼
                    ┌────────────────────────┐
                    │      VOTE COUNT        │
                    │                        │
                    │   🗳️ Flu: 2 votes      │
                    │   🗳️ Cold: 1 vote     │
                    │                        │
                    │   ━━━━━━━━━━━━━━━━━━   │
                    │   Final Answer: FLU    │
                    └────────────────────────┘
```

### Out-of-Bag (OOB) Score: Free Validation!

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   OOB: The "Left Out" Students                                              │
│   ════════════════════════════                                              │
│                                                                             │
│   When creating bootstrap samples, ~37% of data is LEFT OUT each time       │
│   (because we sample WITH replacement)                                      │
│                                                                             │
│   Original: [A, B, C, D, E, F, G, H, I, J]                                  │
│                                                                             │
│   Bootstrap 1: [A, A, C, D, D, F, H, H, I, J]  ──► Left out: B, E, G        │
│   Bootstrap 2: [B, C, C, E, F, F, G, I, J, J]  ──► Left out: A, D, H        │
│   Bootstrap 3: [A, B, D, D, E, G, G, H, I, I]  ──► Left out: C, F, J        │
│                                                                             │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                                                                     │   │
│   │   For sample "B":                                                   │   │
│   │   - B was OUT-OF-BAG for Tree 1 and Tree 3                         │   │
│   │   - Ask Tree 1 and Tree 3 to predict B                             │   │
│   │   - Average their predictions                                       │   │
│   │   - Compare to B's TRUE label                                       │   │
│   │                                                                     │   │
│   │   Do this for ALL samples → OOB Error ≈ Test Error                 │   │
│   │   NO NEED FOR SEPARATE VALIDATION SET!                              │   │
│   │                                                                     │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

# PART 2: BOOSTING

## The Coaching Analogy

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   BOOSTING IS LIKE: A Coach Training a Team Over Multiple Sessions          │
│   ═════════════════════════════════════════════════════════════════════     │
│                                                                             │
│   SESSION 1: Everyone practices equally                                     │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │   Player:  Amy    Bob    Carol   Dan    Eve                         │   │
│   │   Practice                                                          │   │
│   │   time:     ⬤     ⬤       ⬤      ⬤     ⬤    (equal time)          │   │
│   │                                                                     │   │
│   │   Result:    ✓     ✗       ✓      ✗     ✓                          │   │
│   │            (good) (bad)  (good) (bad) (good)                        │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│   SESSION 2: Focus MORE on players who struggled!                           │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │   Player:  Amy    Bob    Carol   Dan    Eve                         │   │
│   │   Practice                                                          │   │
│   │   time:     ○     ⬤⬤⬤     ○     ⬤⬤⬤    ○   (more for Bob & Dan!)   │   │
│   │                                                                     │   │
│   │   Result:    ✓     ✓       ✓      ✗     ✓                          │   │
│   │            (good) (better!)(good) (still bad)                       │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│   SESSION 3: Even MORE focus on Dan!                                        │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │   Player:  Amy    Bob    Carol   Dan    Eve                         │   │
│   │   Practice                                                          │   │
│   │   time:     ○      ○       ○     ⬤⬤⬤⬤⬤  ○   (intensive for Dan!)   │   │
│   │                                                                     │   │
│   │   Result:    ✓     ✓       ✓      ✓     ✓   (everyone good!)        │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│   FINAL TEAM = Combination of all sessions' learnings!                      │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Visual: How Boosting Learns Step by Step

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   CLASSIFICATION EXAMPLE: Separating ● (positive) from ○ (negative)         │
│   ═══════════════════════════════════════════════════════════════════════   │
│                                                                             │
│   ROUND 1: First weak model (a simple line)                                 │
│   ┌─────────────────┐                                                       │
│   │                 │       Model 1 draws a horizontal line                 │
│   │  ●    ○    ○    │       ─────────────────────────────────               │
│   │       ●    ○    │                                                       │
│   │═══════════════  │  ◄── This line separates most, but...                │
│   │  ●    ●    ○    │                                                       │
│   │                 │       ❌ Misclassified: 2 dots below line             │
│   └─────────────────┘                                                       │
│                                                                             │
│   Errors are weighted MORE for next round!                                  │
│                                                                             │
│   ROUND 2: Second model focuses on the mistakes                             │
│   ┌─────────────────┐                                                       │
│   │                 │       Model 2 focuses on errors from Round 1          │
│   │  ●    ○    ○    │       (the ● below the line get MORE weight)         │
│   │       ●    ○    │                                                       │
│   │  ●    │    ○    │                                                       │
│   │       │●        │  ◄── Draws a VERTICAL line to catch those!           │
│   │       │         │                                                       │
│   └─────────────────┘                                                       │
│                                                                             │
│   COMBINED: Models 1 + 2 together                                           │
│   ┌─────────────────┐                                                       │
│   │       ║         │                                                       │
│   │  ●    ║ ○    ○  │       Two simple lines combined                       │
│   │       ║●    ○   │       ─────────────────────────────                   │
│   │═══════╬═════════│  ◄── Now we separate everything correctly!           │
│   │  ●    ║●    ○   │                                                       │
│   │       ║         │                                                       │
│   └─────────────────┘                                                       │
│                                                                             │
│   KEY INSIGHT: Many WEAK models combined = One STRONG model!                │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## AdaBoost: The Original Booster

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   AdaBoost = "Adaptive Boosting"                                            │
│   ════════════════════════════════                                          │
│                                                                             │
│   The Algorithm (in plain English):                                         │
│   ─────────────────────────────────                                         │
│                                                                             │
│   1. START: Give every sample EQUAL weight (everyone matters the same)      │
│                                                                             │
│      Sample:    A    B    C    D    E                                       │
│      Weight:   0.2  0.2  0.2  0.2  0.2  (all equal, sum = 1)               │
│                                                                             │
│   2. TRAIN weak model #1 (like a decision stump - single split)             │
│                                                                             │
│   3. CHECK which samples it got WRONG                                       │
│                                                                             │
│      Sample:    A    B    C    D    E                                       │
│      Result:    ✓    ✗    ✓    ✓    ✗                                      │
│                                                                             │
│   4. INCREASE weight of wrong samples, DECREASE weight of correct ones      │
│                                                                             │
│      Sample:    A    B    C    D    E                                       │
│      Weight:   0.1  0.3  0.1  0.1  0.3  ◄── B and E now matter MORE!       │
│                                                                             │
│   5. TRAIN weak model #2 (paying more attention to B and E)                 │
│                                                                             │
│   6. REPEAT until you have many models                                      │
│                                                                             │
│   7. COMBINE: Good models get more voting power, bad models get less        │
│                                                                             │
│      ┌────────────────────────────────────────────────────────────────┐     │
│      │                                                                │     │
│      │   Model 1 (90% accurate): Gets 2.0 voting power               │     │
│      │   Model 2 (75% accurate): Gets 0.8 voting power               │     │
│      │   Model 3 (60% accurate): Gets 0.3 voting power               │     │
│      │   Model 4 (50% accurate): Gets 0.0 voting power (ignored!)    │     │
│      │                                                                │     │
│      │   Final = sign(2.0×M1 + 0.8×M2 + 0.3×M3 + 0.0×M4)            │     │
│      │                                                                │     │
│      └────────────────────────────────────────────────────────────────┘     │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Gradient Boosting: Learning from Mistakes

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   GRADIENT BOOSTING: Predicting the ERRORS                                  │
│   ═══════════════════════════════════════════                               │
│                                                                             │
│   Analogy: A student taking a test, then studying their mistakes            │
│   ────────────────────────────────────────────────────────────────          │
│                                                                             │
│   ROUND 1: Make a simple prediction (like "guess the average")              │
│                                                                             │
│   ┌───────────────────────────────────────────────────────────────────┐     │
│   │   Actual House Prices:    $100K   $200K   $150K   $300K           │     │
│   │   Model 1 predicts:       $190K   $190K   $190K   $190K (avg)     │     │
│   │   ─────────────────────────────────────────────────────────────   │     │
│   │   Errors (Residuals):     -$90K   +$10K   -$40K   +$110K          │     │
│   └───────────────────────────────────────────────────────────────────┘     │
│                                                                             │
│   ROUND 2: Train a new model to PREDICT these errors!                       │
│                                                                             │
│   ┌───────────────────────────────────────────────────────────────────┐     │
│   │   Target for Model 2:     -$90K   +$10K   -$40K   +$110K          │     │
│   │   Model 2 learns:         -$70K   +$20K   -$30K   +$80K           │     │
│   │   ─────────────────────────────────────────────────────────────   │     │
│   │   Combined (M1 + M2):     $120K   $210K   $160K   $270K           │     │
│   │   New Errors:             -$20K   +$10K   +$10K   -$30K (smaller!)│     │
│   └───────────────────────────────────────────────────────────────────┘     │
│                                                                             │
│   ROUND 3: Train Model 3 to predict the NEW (smaller) errors               │
│                                                                             │
│   ┌───────────────────────────────────────────────────────────────────┐     │
│   │   Target for Model 3:     -$20K   +$10K   +$10K   -$30K           │     │
│   │   Model 3 learns:         -$18K   +$8K    +$12K   -$25K           │     │
│   │   ─────────────────────────────────────────────────────────────   │     │
│   │   Combined (M1+M2+M3):    $102K   $218K   $172K   $245K           │     │
│   │   Final Errors:           +$2K    +$18K   +$22K   -$55K (even     │     │
│   │                                                     smaller!)     │     │
│   └───────────────────────────────────────────────────────────────────┘     │
│                                                                             │
│   Visual:                                                                   │
│                                                                             │
│   Error size after each round:                                              │
│                                                                             │
│   Round 1: ████████████████████████████████ (big errors)                   │
│   Round 2: ████████████████ (smaller errors)                               │
│   Round 3: ████████ (even smaller)                                         │
│   Round 4: ████ (tiny errors!)                                             │
│                                                                             │
│   Each round chips away at the errors!                                      │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## XGBoost, LightGBM, CatBoost: The Modern Champions

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│                    THE KAGGLE COMPETITION WINNERS                           │
│                    ══════════════════════════════                           │
│                                                                             │
│   These are "supercharged" versions of Gradient Boosting!                   │
│                                                                             │
│   ╔═════════════════════════════════════════════════════════════════════╗   │
│   ║                          XGBoost                                    ║   │
│   ║                    "eXtreme Gradient Boosting"                      ║   │
│   ╠═════════════════════════════════════════════════════════════════════╣   │
│   ║  ⭐ The original champion (2014)                                    ║   │
│   ║  ⭐ Adds "regularization" (prevents overfitting)                    ║   │
│   ║  ⭐ Uses smarter math (2nd order gradients)                         ║   │
│   ║  ⭐ Handles missing values automatically                            ║   │
│   ║  ⭐ Parallel tree building                                          ║   │
│   ╚═════════════════════════════════════════════════════════════════════╝   │
│                                                                             │
│   ╔═════════════════════════════════════════════════════════════════════╗   │
│   ║                         LightGBM                                    ║   │
│   ║                   "Light Gradient Boosting Machine"                 ║   │
│   ╠═════════════════════════════════════════════════════════════════════╣   │
│   ║  🚀 MUCH FASTER than XGBoost                                        ║   │
│   ║  🚀 Uses less memory                                                ║   │
│   ║  🚀 Best for HUGE datasets (millions of rows)                       ║   │
│   ║  🚀 "Leaf-wise" growth (smarter tree building)                      ║   │
│   ╚═════════════════════════════════════════════════════════════════════╝   │
│                                                                             │
│   ╔═════════════════════════════════════════════════════════════════════╗   │
│   ║                         CatBoost                                    ║   │
│   ║                  "Categorical Boosting" (by Yandex)                 ║   │
│   ╠═════════════════════════════════════════════════════════════════════╣   │
│   ║  🐱 Best for CATEGORICAL data (colors, countries, types)           ║   │
│   ║  🐱 Works great "out of the box" (less tuning needed)              ║   │
│   ║  🐱 Handles categories WITHOUT manual encoding                      ║   │
│   ║  🐱 "Ordered boosting" (reduces overfitting)                        ║   │
│   ╚═════════════════════════════════════════════════════════════════════╝   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Tree Growth: Level-wise vs Leaf-wise

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   HOW TREES GROW (XGBoost vs LightGBM)                                      │
│   ═══════════════════════════════════════                                   │
│                                                                             │
│   LEVEL-WISE (XGBoost default):        LEAF-WISE (LightGBM):                │
│   "Grow all branches at same level"    "Grow the best branch first"         │
│                                                                             │
│         Step 1:          ○                    Step 1:        ○              │
│                         / \                                 / \             │
│         Step 2:        ○   ○                  Step 2:      ○   ○            │
│                       /\   /\                              /\               │
│         Step 3:      ○ ○  ○ ○                 Step 3:     ○  ○              │
│                                                          /\                 │
│                                               Step 4:   ○  ○                │
│                                                                             │
│   Like building a pyramid                  Like a tree growing towards      │
│   layer by layer                           the sunlight                     │
│                                                                             │
│   ✅ Balanced, safer                       ✅ Faster convergence            │
│   ❌ Can be slower                         ❌ Can overfit more              │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

# PART 3: STACKING

## The Expert Panel Analogy

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   STACKING IS LIKE: A Team of Specialists + One Manager                     │
│   ═════════════════════════════════════════════════════                     │
│                                                                             │
│                        PATIENT DIAGNOSIS                                    │
│                              │                                              │
│         ┌────────────────────┼────────────────────┐                         │
│         │                    │                    │                         │
│         ▼                    ▼                    ▼                         │
│   ┌───────────┐        ┌───────────┐        ┌───────────┐                   │
│   │ Cardiolog │        │ Neurolog  │        │ General   │                   │
│   │ ist       │        │ ist       │        │ Practitnr │                   │
│   │           │        │           │        │           │                   │
│   │ "Heart    │        │ "Could be │        │ "Looks    │                   │
│   │  disease" │        │  stress"  │        │  like flu"│                   │
│   │ (90% sure)│        │ (70% sure)│        │ (60% sure)│                   │
│   └─────┬─────┘        └─────┬─────┘        └─────┬─────┘                   │
│         │                    │                    │                         │
│         │                    │                    │                         │
│         └────────────────────┼────────────────────┘                         │
│                              │                                              │
│                              ▼                                              │
│                    ┌───────────────────┐                                    │
│                    │   CHIEF DOCTOR    │                                    │
│                    │   (Meta-Model)    │                                    │
│                    │                   │                                    │
│                    │ "Given that the   │                                    │
│                    │ cardiologist is   │                                    │
│                    │ very confident    │                                    │
│                    │ and usually right │                                    │
│                    │ in these cases..."│                                    │
│                    │                   │                                    │
│                    │ FINAL: Heart      │                                    │
│                    │ Disease           │                                    │
│                    └───────────────────┘                                    │
│                                                                             │
│   The "Chief Doctor" (meta-model) has LEARNED:                              │
│   - When to trust the cardiologist                                          │
│   - When the GP is actually right                                           │
│   - How to weigh different opinions                                         │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Stacking Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│                          STACKING ARCHITECTURE                              │
│                          ════════════════════                               │
│                                                                             │
│   LEVEL 0: BASE MODELS (different algorithms)                               │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                                                                     │   │
│   │ ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐             │   │
│   │ │  Random  │  │ Gradient │  │   SVM    │  │   KNN    │             │   │
│   │ │  Forest  │  │ Boosting │  │          │  │          │             │   │
│   │ └────┬─────┘  └────┬─────┘  └────┬─────┘  └────┬─────┘             │   │
│   │      │             │             │             │                    │   │
│   │      ▼             ▼             ▼             ▼                    │   │
│   │   Pred: 0.8     Pred: 0.7     Pred: 0.9     Pred: 0.6              │   │
│   │                                                                     │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                              │                                              │
│                              ▼                                              │
│   NEW FEATURE SET: [0.8, 0.7, 0.9, 0.6]                                    │
│                              │                                              │
│                              ▼                                              │
│   LEVEL 1: META-MODEL                                                       │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                                                                     │   │
│   │      ┌────────────────────────────────────────────┐                │   │
│   │      │         Logistic Regression                │                │   │
│   │      │   (learns optimal combination of Level 0)  │                │   │
│   │      │                                            │                │   │
│   │      │   "When RF says 0.8+ AND SVM says 0.9+,   │                │   │
│   │      │    always predict positive"                │                │   │
│   │      └──────────────────┬─────────────────────────┘                │   │
│   │                         │                                          │   │
│   └─────────────────────────┼───────────────────────────────────────────┘   │
│                             ▼                                               │
│                    FINAL PREDICTION: 0.85                                   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

# COMPARISON: Bagging vs Boosting vs Stacking

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│                    THE BIG COMPARISON CHART                                 │
│   ═══════════════════════════════════════════════════════════════════════   │
│                                                                             │
│   ┌──────────────┬─────────────────┬─────────────────┬─────────────────┐   │
│   │              │     BAGGING     │    BOOSTING     │    STACKING     │   │
│   ├──────────────┼─────────────────┼─────────────────┼─────────────────┤   │
│   │              │                 │                 │                 │   │
│   │  How it      │  Train models   │  Train models   │  Train diverse  │   │
│   │  works       │  in PARALLEL    │  SEQUENTIALLY   │  models, then   │   │
│   │              │  on different   │  each fixing    │  train a meta-  │   │
│   │              │  data subsets   │  prior errors   │  model on top   │   │
│   │              │                 │                 │                 │   │
│   ├──────────────┼─────────────────┼─────────────────┼─────────────────┤   │
│   │              │                 │                 │                 │   │
│   │  Analogy     │  Ask many       │  Coach trains   │  Panel of       │   │
│   │              │  friends for    │  players on     │  experts +      │   │
│   │              │  opinions,      │  weaknesses     │  manager makes  │   │
│   │              │  take average   │  repeatedly     │  final call     │   │
│   │              │                 │                 │                 │   │
│   ├──────────────┼─────────────────┼─────────────────┼─────────────────┤   │
│   │              │                 │                 │                 │   │
│   │  Main        │  REDUCES        │  REDUCES        │  Learns BEST    │   │
│   │  benefit     │  VARIANCE       │  BIAS           │  COMBINATION    │   │
│   │              │  (less overfit) │  (more accurate)│  of models      │   │
│   │              │                 │                 │                 │   │
│   ├──────────────┼─────────────────┼─────────────────┼─────────────────┤   │
│   │              │                 │                 │                 │   │
│   │  Risk        │  Low            │  Higher         │  Medium         │   │
│   │  of overfit  │  (averaging     │  (focus on hard │  (meta-model    │   │
│   │              │  helps)         │  cases can      │  can overfit)   │   │
│   │              │                 │  overfit)       │                 │   │
│   │              │                 │                 │                 │   │
│   ├──────────────┼─────────────────┼─────────────────┼─────────────────┤   │
│   │              │                 │                 │                 │   │
│   │  Training    │  FAST           │  SLOW           │  SLOWEST        │   │
│   │  speed       │  (parallel)     │  (sequential)   │  (multi-level)  │   │
│   │              │                 │                 │                 │   │
│   ├──────────────┼─────────────────┼─────────────────┼─────────────────┤   │
│   │              │                 │                 │                 │   │
│   │  Example     │  Random Forest  │  XGBoost        │  Stacking       │   │
│   │              │  Extra Trees    │  LightGBM       │  Classifier     │   │
│   │              │                 │  CatBoost       │                 │   │
│   │              │                 │                 │                 │   │
│   └──────────────┴─────────────────┴─────────────────┴─────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

# VISUAL SUMMARY: When to Use What

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│                    DECISION FLOWCHART                                       │
│   ═══════════════════════════════════════════════════════════════════════   │
│                                                                             │
│                     Start Here!                                             │
│                         │                                                   │
│                         ▼                                                   │
│              ┌─────────────────────┐                                        │
│              │ Want a quick, solid │                                        │
│              │ baseline?           │                                        │
│              └──────────┬──────────┘                                        │
│                         │                                                   │
│            Yes ◄────────┼────────► No                                       │
│             │           │           │                                       │
│             ▼                       ▼                                       │
│    ┌─────────────────┐    ┌─────────────────┐                               │
│    │ RANDOM FOREST   │    │ Need maximum    │                               │
│    │                 │    │ accuracy?       │                               │
│    │ ✓ Easy to use   │    └────────┬────────┘                               │
│    │ ✓ Hard to break │             │                                        │
│    │ ✓ Good baseline │   Yes ◄─────┼─────► No                               │
│    └─────────────────┘    │        │        │                               │
│                           ▼                 ▼                               │
│              ┌─────────────────┐   ┌─────────────────┐                      │
│              │ XGBOOST or      │   │ Interpretability│                      │
│              │ LIGHTGBM        │   │ important?      │                      │
│              │                 │   └────────┬────────┘                      │
│              │ • Tune carefully│            │                               │
│              │ • Use early stop│   Yes ◄────┼────► No                       │
│              │ • Best results! │    │       │       │                       │
│              └─────────────────┘    ▼               ▼                       │
│                                 ┌─────────────┐  ┌─────────────┐            │
│                                 │ Single Tree │  │ STACKING    │            │
│                                 │ or RF with  │  │             │            │
│                                 │ few trees   │  │ For Kaggle  │            │
│                                 └─────────────┘  │ competitions│            │
│                                                  └─────────────┘            │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Python Implementation

```python
from sklearn.ensemble import (
    RandomForestClassifier, RandomForestRegressor,
    GradientBoostingClassifier, AdaBoostClassifier,
    StackingClassifier, VotingClassifier
)
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.model_selection import cross_val_score
import xgboost as xgb
import lightgbm as lgb

# ============================================
# RANDOM FOREST (Bagging)
# ============================================
rf = RandomForestClassifier(
    n_estimators=100,        # Number of trees (more = better, but slower)
    max_depth=10,            # How deep each tree can grow
    max_features='sqrt',     # Random features per split
    min_samples_split=5,     # Minimum samples to split a node
    oob_score=True,          # Free validation score!
    random_state=42
)
rf.fit(X_train, y_train)
print(f"OOB Score: {rf.oob_score_:.3f}")
print(f"Feature Importances: {rf.feature_importances_}")

# ============================================
# GRADIENT BOOSTING
# ============================================
gb = GradientBoostingClassifier(
    n_estimators=100,        # Number of boosting rounds
    learning_rate=0.1,       # How much each tree contributes (smaller = safer)
    max_depth=3,             # Keep shallow! (boosting uses weak learners)
    min_samples_split=5,
    random_state=42
)
gb.fit(X_train, y_train)

# ============================================
# XGBOOST (The Champion)
# ============================================
xgb_model = xgb.XGBClassifier(
    n_estimators=100,
    learning_rate=0.1,
    max_depth=5,
    subsample=0.8,           # Use 80% of data per tree (prevents overfit)
    colsample_bytree=0.8,    # Use 80% of features per tree
    reg_alpha=0.1,           # L1 regularization
    reg_lambda=1.0,          # L2 regularization
    random_state=42
)
xgb_model.fit(X_train, y_train)

# ============================================
# LIGHTGBM (Fast!)
# ============================================
lgb_model = lgb.LGBMClassifier(
    n_estimators=100,
    learning_rate=0.1,
    max_depth=-1,            # No limit (uses num_leaves instead)
    num_leaves=31,           # Maximum leaves per tree
    random_state=42
)
lgb_model.fit(X_train, y_train)

# ============================================
# VOTING (Simple Ensemble)
# ============================================
voting = VotingClassifier(
    estimators=[('rf', rf), ('gb', gb), ('xgb', xgb_model)],
    voting='soft'            # Use probabilities (better than hard voting)
)
voting.fit(X_train, y_train)

# ============================================
# STACKING (Advanced Ensemble)
# ============================================
stacking = StackingClassifier(
    estimators=[
        ('rf', RandomForestClassifier(n_estimators=50)),
        ('gb', GradientBoostingClassifier(n_estimators=50)),
        ('svm', SVC(probability=True))
    ],
    final_estimator=LogisticRegression(),  # Meta-model
    cv=5                     # Use 5-fold CV to avoid data leakage
)
stacking.fit(X_train, y_train)
```

---

## Interview Questions

### Q1: What's the difference between bagging and boosting?
**Answer:**
```
BAGGING                              BOOSTING
═══════                              ════════
• Train models in PARALLEL           • Train models SEQUENTIALLY
• Each model is INDEPENDENT          • Each model DEPENDS on previous
• Equal weights for all samples      • Higher weights for hard samples
• REDUCES VARIANCE                   • REDUCES BIAS
• Less prone to overfitting          • More prone to overfitting
• Example: Random Forest             • Example: XGBoost
```

### Q2: Why does Random Forest use random feature selection?
**Answer:**
Without random features, if one feature is super important (like "income" for predicting loan default), ALL trees would split on it first → all trees become very similar → averaging doesn't help much!

With random features, different trees become "specialists" in different aspects → more diverse → better ensemble.

### Q3: How does XGBoost prevent overfitting?
**Answer:**
5 main ways:
1. **Regularization** (L1/L2 penalties on leaf weights)
2. **Learning rate** (shrinkage - each tree contributes less)
3. **Subsampling** rows and columns
4. **Early stopping** (stop when validation stops improving)
5. **Max depth limits** (keep trees shallow)

### Q4: When would you choose LightGBM over XGBoost?
**Answer:**
- **Large datasets** (millions of rows) → LightGBM is MUCH faster
- **Memory constraints** → LightGBM uses less memory
- **Quick experiments** → LightGBM trains faster
- Keep XGBoost for smaller datasets where you need every bit of accuracy

### Q5: What is the Out-of-Bag score?
**Answer:**
When creating bootstrap samples, ~37% of data is LEFT OUT each time. These "out-of-bag" samples are used to estimate test error WITHOUT needing a separate validation set!

Each sample is predicted by only the trees that DIDN'T train on it → gives honest estimate of generalization.

---

## Quick Reference Cheat Sheet

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    ENSEMBLE METHODS CHEAT SHEET                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  🌲 RANDOM FOREST (Bagging)                                                 │
│  • Many trees, different data samples, random features                      │
│  • Reduces VARIANCE (prevents overfitting)                                  │
│  • Parallel training (fast!)                                                │
│  • Great baseline, hard to mess up                                          │
│                                                                             │
│  🚀 XGBOOST / LIGHTGBM (Boosting)                                           │
│  • Sequential, each model fixes previous errors                             │
│  • Reduces BIAS (improves accuracy)                                         │
│  • Use learning_rate + early_stopping to prevent overfit                    │
│  • Best performance when tuned properly                                     │
│                                                                             │
│  📊 STACKING                                                                │
│  • Train diverse base models                                                │
│  • Train meta-model on base predictions                                     │
│  • Use K-fold CV to avoid data leakage!                                     │
│  • Competition-winning technique                                            │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│  RULE OF THUMB FOR INTERVIEWS:                                              │
│  1. Start with Random Forest (robust baseline)                              │
│  2. Move to XGBoost/LightGBM for better performance                         │
│  3. Stack models only for competitions (diminishing returns)                │
└─────────────────────────────────────────────────────────────────────────────┘
```
