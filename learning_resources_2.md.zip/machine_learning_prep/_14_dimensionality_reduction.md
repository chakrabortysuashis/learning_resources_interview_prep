# Dimensionality Reduction (PCA & More)

## What is Dimensionality Reduction?

Dimensionality reduction transforms high-dimensional data into a lower-dimensional space while preserving important information.

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Original: 100 features        Reduced: 10 features        │
│   ┌─────────────────────┐       ┌─────────────┐             │
│   │ x₁ x₂ x₃ ... x₁₀₀  │  ──►  │ z₁ z₂ ... z₁₀│            │
│   └─────────────────────┘       └─────────────┘             │
│                                                             │
│   WHY?                                                      │
│   • Reduce computational cost                               │
│   • Remove noise/redundancy                                 │
│   • Visualization (2D/3D)                                   │
│   • Combat curse of dimensionality                          │
│   • Feature extraction                                      │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Principal Component Analysis (PCA)

### The Big Picture

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   PCA finds the directions (principal components) that      │
│   capture the MAXIMUM VARIANCE in the data                  │
│                                                             │
│                y                                            │
│                │    ●                                       │
│                │  ●  ●╲ PC1 (most variance)                 │
│                │ ●  ●  ╲                                    │
│                │●  ●  ●─╲────────                           │
│                │ ●  ●  ╱                                    │
│                │●  ●  ╱ PC2 (second most)                   │
│                │  ●  ╱                                      │
│                └────────────────── x                        │
│                                                             │
│   PC1 ⟂ PC2 (perpendicular/orthogonal)                     │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Mathematical Foundation

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Goal: Find projection that maximizes variance             │
│                                                             │
│   1. Center the data: X_centered = X - mean(X)              │
│                                                             │
│   2. Compute covariance matrix: C = XᵀX / (n-1)            │
│                                                             │
│   3. Find eigenvalues and eigenvectors of C                 │
│                                                             │
│   4. Sort eigenvectors by eigenvalue (descending)           │
│                                                             │
│   5. Top k eigenvectors = k principal components            │
│                                                             │
│   6. Project: Z = X × W  (W = matrix of eigenvectors)       │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Eigenvalues and Explained Variance

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Eigenvalue λᵢ = variance captured by component i          │
│                                                             │
│                    λᵢ                                       │
│   Explained ratio = ────                                    │
│                    Σλⱼ                                      │
│                                                             │
└─────────────────────────────────────────────────────────────┘

Scree Plot:
   Explained
   Variance
      │
  40% ├●
      │
  25% ├  ●
      │
  15% ├    ●
      │
   8% ├      ●●●●●●
      │
      └──────────────────── Component
         1  2  3  4  5  6...

Cumulative:
   Total
  Variance
      │
 100% ├─────────────────●●●●●●
      │              ●●●
  80% ├          ●●●   ← Keep components until ~95%
      │        ●●
  60% ├      ●
      │    ●
  40% ├●●
      └──────────────────── Component
         1  2  3  4  5  6...
```

---

## PCA Step-by-Step Example

```
Original data (2D → 1D):

    y
    │    ●(4,3)
    │  ●(3,2)
    │●(2,1)
    │●(1,0)
    └───────────── x

Step 1: Center the data
    Mean: (2.5, 1.5)
    Centered: (-1.5,-1.5), (-0.5,-0.5), (0.5,0.5), (1.5,1.5)

Step 2: Covariance matrix
    C = [1.67  1.67]
        [1.67  1.67]

Step 3: Eigenvectors/values
    λ₁ = 3.33, v₁ = [0.707, 0.707]  (diagonal direction)
    λ₂ = 0,    v₂ = [-0.707, 0.707] (no variance!)

Step 4: Project onto PC1 (1D)
    New data: [-2.12, -0.71, 0.71, 2.12]
    
    All variance preserved in 1 dimension!
```

---

## Choosing Number of Components

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   METHODS:                                                  │
│                                                             │
│   1. Explained variance threshold (e.g., keep 95%)          │
│      n_components = number to reach 95% variance            │
│                                                             │
│   2. Elbow method (scree plot)                              │
│      Look for "elbow" where variance drops off              │
│                                                             │
│   3. Kaiser criterion                                       │
│      Keep components with eigenvalue > 1                    │
│                                                             │
│   4. Cross-validation                                       │
│      Use downstream task performance                        │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## PCA for Visualization

```
High-dimensional data → 2D/3D visualization

MNIST digits (784D → 2D):

              PC2
               │
          0000 │  1111
         0  0 0│ 1  1 1
               │
    7777777────┼────────── PC1
          7    │      2222
               │    2   2 2
               │     22
               │

Different digit classes separate in PCA space!
```

---

## PCA Limitations

```
┌─────────────────────────────────────────────────────────────┐
│   ⚠️ LIMITATIONS                                            │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│   1. LINEAR only                                            │
│      Cannot capture non-linear relationships                │
│                                                             │
│   2. Sensitive to scaling                                   │
│      MUST standardize features first                        │
│                                                             │
│   3. Maximum variance ≠ most useful                         │
│      High variance direction might be noise                 │
│                                                             │
│   4. Components hard to interpret                           │
│      PC1 = 0.3*x₁ + 0.5*x₂ + ... (what does this mean?)    │
│                                                             │
│   5. Orthogonality constraint                               │
│      Components must be perpendicular                       │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Other Dimensionality Reduction Methods

### t-SNE (t-Distributed Stochastic Neighbor Embedding)

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   NON-LINEAR method for VISUALIZATION                       │
│                                                             │
│   • Preserves LOCAL structure (neighbors stay neighbors)    │
│   • Great for visualizing clusters                          │
│   • Computationally expensive                               │
│   • NOT for dimensionality reduction for ML                 │
│   • Results vary with perplexity parameter                  │
│                                                             │
└─────────────────────────────────────────────────────────────┘

PCA vs t-SNE on MNIST:

PCA (linear):                  t-SNE (non-linear):
     ●●●                            ●●●
   ●●●●●●●                         ●●●●●
  ●●●●●●●●●                           ○○○○○
    ○○○○○○                              ○○○
     ○○○                               ▲▲▲
  (Overlapping)                    (Clear clusters!)
```

### LDA (Linear Discriminant Analysis)

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   SUPERVISED dimensionality reduction                       │
│                                                             │
│   • Uses class labels!                                      │
│   • Maximizes class separation, not variance                │
│   • Max k-1 components (k = number of classes)              │
│                                                             │
│   PCA: Max variance           LDA: Max class separation     │
│                                                             │
│     ● ●│○ ○                      ● ●  │  ○ ○                │
│    ● ●─┼─○ ○     vs             ● ●   │   ○ ○               │
│     ● ●│○ ○                      ● ●  │  ○ ○                │
│        │                              │                     │
│   (variance axis)              (separation axis)            │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### UMAP (Uniform Manifold Approximation and Projection)

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   Modern alternative to t-SNE                               │
│                                                             │
│   • FASTER than t-SNE                                       │
│   • Better preserves global structure                       │
│   • Can be used for general dimensionality reduction        │
│   • Works well with large datasets                          │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Comparison

```
┌──────────┬────────────────────────────────────────────────────┐
│  Method  │  Use Case                                          │
├──────────┼────────────────────────────────────────────────────┤
│  PCA     │  Linear reduction, preprocessing, feature extract  │
│  t-SNE   │  Visualization only (2D/3D), cluster exploration   │
│  UMAP    │  Visualization + reduction, faster than t-SNE      │
│  LDA     │  Classification preprocessing (uses labels)        │
│  Kernel  │  Non-linear PCA, when linear fails                 │
│   PCA    │                                                    │
└──────────┴────────────────────────────────────────────────────┘
```

---

## Python Implementation

```python
from sklearn.decomposition import PCA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.manifold import TSNE
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
import numpy as np

# ALWAYS scale before PCA!
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# PCA
pca = PCA(n_components=0.95)  # Keep 95% variance
X_pca = pca.fit_transform(X_scaled)

print(f"Original dimensions: {X.shape[1]}")
print(f"Reduced dimensions: {X_pca.shape[1]}")
print(f"Explained variance ratio: {pca.explained_variance_ratio_}")
print(f"Total variance explained: {sum(pca.explained_variance_ratio_):.2f}")

# Scree plot
pca_full = PCA()
pca_full.fit(X_scaled)

plt.figure(figsize=(10, 4))

plt.subplot(1, 2, 1)
plt.bar(range(1, len(pca_full.explained_variance_ratio_) + 1),
        pca_full.explained_variance_ratio_)
plt.xlabel('Principal Component')
plt.ylabel('Explained Variance Ratio')
plt.title('Scree Plot')

plt.subplot(1, 2, 2)
plt.plot(range(1, len(pca_full.explained_variance_ratio_) + 1),
         np.cumsum(pca_full.explained_variance_ratio_), 'bo-')
plt.axhline(y=0.95, color='r', linestyle='--')
plt.xlabel('Number of Components')
plt.ylabel('Cumulative Explained Variance')
plt.title('Cumulative Variance')
plt.show()

# t-SNE (for visualization only)
tsne = TSNE(n_components=2, perplexity=30, random_state=42)
X_tsne = tsne.fit_transform(X_scaled)

plt.scatter(X_tsne[:, 0], X_tsne[:, 1], c=y, cmap='viridis')
plt.title('t-SNE Visualization')
plt.show()

# LDA (supervised)
lda = LinearDiscriminantAnalysis(n_components=2)
X_lda = lda.fit_transform(X_scaled, y)

# UMAP
# pip install umap-learn
import umap
reducer = umap.UMAP(n_components=2, random_state=42)
X_umap = reducer.fit_transform(X_scaled)
```

### PCA From Scratch

```python
import numpy as np

class PCAScratch:
    def __init__(self, n_components):
        self.n_components = n_components
        
    def fit(self, X):
        # Center the data
        self.mean = np.mean(X, axis=0)
        X_centered = X - self.mean
        
        # Compute covariance matrix
        cov_matrix = np.cov(X_centered.T)
        
        # Compute eigenvalues and eigenvectors
        eigenvalues, eigenvectors = np.linalg.eig(cov_matrix)
        
        # Sort by eigenvalue (descending)
        idx = np.argsort(eigenvalues)[::-1]
        eigenvalues = eigenvalues[idx]
        eigenvectors = eigenvectors[:, idx]
        
        # Store top k components
        self.components = eigenvectors[:, :self.n_components].T
        self.explained_variance = eigenvalues[:self.n_components]
        self.explained_variance_ratio = (
            eigenvalues[:self.n_components] / np.sum(eigenvalues)
        )
        
        return self
    
    def transform(self, X):
        X_centered = X - self.mean
        return np.dot(X_centered, self.components.T)
    
    def fit_transform(self, X):
        self.fit(X)
        return self.transform(X)
    
    def inverse_transform(self, X_reduced):
        return np.dot(X_reduced, self.components) + self.mean
```

---

## Interview Questions

### Q1: What is the difference between PCA and LDA?
**Answer:**
- **PCA:** Unsupervised, maximizes variance, ignores class labels
- **LDA:** Supervised, maximizes class separability, uses labels
- PCA: Find directions of most variance
- LDA: Find directions that best separate classes

### Q2: Why must you standardize data before PCA?
**Answer:** PCA finds directions of maximum variance. Features on larger scales will dominate. Standardizing ensures all features contribute equally to the principal components.

### Q3: How do you choose the number of components?
**Answer:**
- Keep components explaining 95% (or desired) cumulative variance
- Look for "elbow" in scree plot
- Use cross-validation with downstream task
- Kaiser criterion (eigenvalue > 1)

### Q4: When would you use t-SNE vs PCA?
**Answer:**
- **PCA:** Feature reduction for ML, linear relationships, reconstruction
- **t-SNE:** Visualization only, non-linear cluster structure, exploring data

### Q5: What are the limitations of PCA?
**Answer:**
- Only captures linear relationships
- Sensitive to scaling
- High variance ≠ most useful (might be noise)
- Components are linear combinations (hard to interpret)
- Assumes orthogonal components

---

## Quick Reference

```
┌─────────────────────────────────────────────────────────────┐
│          DIMENSIONALITY REDUCTION CHEAT SHEET               │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  PCA                                                        │
│  • Unsupervised, linear                                     │
│  • Maximize variance                                        │
│  • MUST scale features first                                │
│  • Use for: preprocessing, noise reduction, compression     │
│                                                             │
│  t-SNE                                                      │
│  • Non-linear, for visualization only                       │
│  • Preserves local structure                                │
│  • Slow, non-deterministic                                  │
│  • Tune perplexity (5-50)                                   │
│                                                             │
│  UMAP                                                       │
│  • Non-linear, faster than t-SNE                            │
│  • Better global structure                                  │
│  • Can be used for reduction + visualization                │
│                                                             │
│  LDA                                                        │
│  • Supervised (uses labels)                                 │
│  • Maximize class separation                                │
│  • Max n_classes - 1 components                             │
│                                                             │
│  CHOOSING COMPONENTS                                        │
│  • Keep 95% cumulative variance                             │
│  • Elbow in scree plot                                      │
│  • Cross-validate with task                                 │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```
