# Categorical Plots in Seaborn

## What are Categorical Plots?

Categorical plots show data organized by **categories** (groups). They answer questions like:
- How do different groups compare?
- Which category has higher/lower values?
- How is data spread within each group?

## The Five Main Categorical Plots

| Plot | What It Shows | Best For |
|------|--------------|----------|
| `boxplot` | Summary stats (median, quartiles) | Quick statistical comparison |
| `violinplot` | Distribution shape + stats | Seeing data distribution |
| `swarmplot` | Every individual point | Small datasets, exact values |
| `stripplot` | Points with random scatter | Larger datasets |
| `countplot` | Count of items in each category | Frequency comparison |

---

## 1. boxplot - Box and Whisker Plot

Shows the **five-number summary**: minimum, Q1, median, Q3, maximum.

### When to Use
- Comparing distributions across categories
- Finding outliers (unusual values)
- Quick statistical summary

### Basic Example
```python
import seaborn as sns
import matplotlib.pyplot as plt

tips = sns.load_dataset('tips')

sns.boxplot(data=tips, x='day', y='total_bill')
plt.title('Spending by Day')
plt.show()
```

### Reading a Box Plot
```
    |----| Maximum (excluding outliers)
    |    |
 ---|----| Q3 (75th percentile)
|   |    |
|   |----|  Median (50th percentile)
|   |    |
 ---|----| Q1 (25th percentile)
    |    |
    |----| Minimum (excluding outliers)
    
    o      Outliers (dots beyond whiskers)
```

### Key Parameters
```python
sns.boxplot(
    data=tips,
    x='day',
    y='total_bill',
    hue='sex',          # Color by category
    palette='Set2',     # Color scheme
    width=0.6,          # Box width
    linewidth=1.5       # Border thickness
)
```

### Pro Tips
- Box = middle 50% of data (IQR = Q3 - Q1)
- Whiskers = 1.5 * IQR beyond the box
- Points outside whiskers = outliers
- Great for comparing multiple groups at once

---

## 2. violinplot - Violin Plot

Combines a box plot with a KDE (density curve) on each side.

### When to Use
- You want to see the SHAPE of distribution
- Comparing distributions across categories
- When boxplot hides important patterns

### Basic Example
```python
sns.violinplot(data=tips, x='day', y='total_bill')
plt.title('Bill Distribution by Day')
plt.show()
```

### Key Parameters
```python
sns.violinplot(
    data=tips,
    x='day',
    y='total_bill',
    hue='sex',
    split=True,        # Split violin by hue (saves space!)
    inner='box',       # 'box', 'stick', 'point', or None
    palette='coolwarm'
)
```

### Pro Tips
- Wider = more data points at that value
- `split=True` is great for comparing two groups
- `inner='box'` shows the box plot inside
- Shows bimodal (two-peak) distributions that boxplot hides!

---

## 3. swarmplot - Swarm Plot

Shows **every single data point**, arranged to avoid overlap.

### When to Use
- Small to medium datasets (under 200 points per category)
- You want to see exact distribution of points
- Looking for patterns or clusters

### Basic Example
```python
sns.swarmplot(data=tips, x='day', y='total_bill')
plt.title('Every Bill, By Day')
plt.show()
```

### Key Parameters
```python
sns.swarmplot(
    data=tips,
    x='day',
    y='total_bill',
    hue='time',        # Color by category
    size=5,            # Point size
    palette='Dark2'
)
```

### Pro Tips
- Shows EVERY data point - no hiding!
- Gets slow/messy with many points
- Great combined with violinplot or boxplot
- Points spread horizontally to avoid overlap

---

## 4. stripplot - Strip Plot

Shows individual points with **random horizontal scatter**.

### When to Use
- Medium to large datasets
- When swarmplot is too slow
- Quick view of data distribution

### Basic Example
```python
sns.stripplot(data=tips, x='day', y='total_bill')
plt.title('Bills by Day (Strip Plot)')
plt.show()
```

### Key Parameters
```python
sns.stripplot(
    data=tips,
    x='day',
    y='total_bill',
    jitter=0.2,        # Amount of horizontal spread
    alpha=0.5,         # Transparency (for overlapping points)
    size=4             # Point size
)
```

### Pro Tips
- `jitter` controls horizontal spread (0 = no spread)
- Use `alpha` when points overlap
- Faster than swarmplot for large datasets
- Points can overlap (unlike swarmplot)

---

## 5. countplot - Count Plot

Shows the **count (frequency)** of each category.

### When to Use
- Counting how many items in each category
- Comparing frequencies/proportions
- Bar chart for categorical data

### Basic Example
```python
sns.countplot(data=tips, x='day')
plt.title('Number of Meals by Day')
plt.show()
```

### Key Parameters
```python
sns.countplot(
    data=tips,
    x='day',
    hue='sex',         # Color by category
    palette='pastel',
    order=['Thur', 'Fri', 'Sat', 'Sun']  # Custom order
)
```

### Pro Tips
- Like a histogram for categorical data
- Use `hue` to stack/compare subgroups
- `order` parameter controls bar order
- Great for showing class imbalance in data

---

## Combining Plots (Super Powerful!)

One of Seaborn's best tricks is **layering plots**:

```python
# Violin + Swarm - See shape AND exact points
sns.violinplot(data=tips, x='day', y='total_bill', inner=None, alpha=0.3)
sns.swarmplot(data=tips, x='day', y='total_bill', color='black', size=3)
plt.title('Distribution Shape + Individual Points')
plt.show()
```

```python
# Box + Strip - Summary stats + data points
sns.boxplot(data=tips, x='day', y='total_bill', width=0.5)
sns.stripplot(data=tips, x='day', y='total_bill', color='red', alpha=0.3)
plt.title('Box Plot with Data Points')
plt.show()
```

---

## Comparison: Matplotlib vs Seaborn

### Matplotlib Box Plot
```python
import matplotlib.pyplot as plt

# Group data manually
data_by_day = [tips[tips['day']==d]['total_bill'] for d in ['Thur','Fri','Sat','Sun']]
plt.boxplot(data_by_day, labels=['Thur','Fri','Sat','Sun'])
plt.ylabel('Total Bill')
plt.title('Matplotlib Box Plot')
plt.show()
```

### Seaborn Box Plot
```python
sns.boxplot(data=tips, x='day', y='total_bill')
plt.title('Seaborn Box Plot')
plt.show()
```

**Seaborn wins:** One line, automatic grouping, easy `hue` parameter!

---

## Quick Reference

| Task | Code |
|------|------|
| Box plot by category | `sns.boxplot(data=df, x='cat', y='num')` |
| Box plot with groups | `sns.boxplot(data=df, x='cat', y='num', hue='group')` |
| Violin plot | `sns.violinplot(data=df, x='cat', y='num')` |
| Split violin | `sns.violinplot(data=df, x='cat', y='num', hue='g', split=True)` |
| Show all points | `sns.swarmplot(data=df, x='cat', y='num')` |
| Points with jitter | `sns.stripplot(data=df, x='cat', y='num')` |
| Count categories | `sns.countplot(data=df, x='cat')` |
| Count with subgroups | `sns.countplot(data=df, x='cat', hue='group')` |

---

## Summary

- **boxplot**: Quick statistical summary with outliers
- **violinplot**: Shows distribution shape (wide = more data)
- **swarmplot**: Every point, no overlap (small data)
- **stripplot**: Every point with jitter (larger data)
- **countplot**: Bar chart of counts

**Key insight:** These plots reveal:
- Which groups have higher/lower values
- How spread out each group is
- Whether distributions are similar or different
- Outliers (unusual values)

**Next:** Relational Plots for relationships between variables!
