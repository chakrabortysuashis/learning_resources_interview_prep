# Regression Plots in Seaborn

## What are Regression Plots?

Regression plots show the **relationship between variables** AND fit a line through the data. They help answer:
- Is there a trend in the data?
- How strong is the relationship?
- Can we predict one variable from another?

## The Main Regression Plots

| Plot | What It Shows | Best For |
|------|--------------|----------|
| `regplot` | Scatter + regression line | Simple relationships |
| `lmplot` | Faceted regression plots | Comparing groups |
| `residplot` | Residuals (errors) | Checking model fit |

---

## 1. regplot - Regression Plot

Shows a scatter plot with a **best-fit line** through the data.

### When to Use
- You want to see the trend in your data
- Checking if a linear relationship exists
- Simple before/after prediction visualization

### Basic Example
```python
import seaborn as sns
import matplotlib.pyplot as plt

tips = sns.load_dataset('tips')

sns.regplot(data=tips, x='total_bill', y='tip')
plt.title('Tips vs Total Bill with Regression Line')
plt.show()
```

### What the Plot Shows
- **Dots** = actual data points
- **Line** = best fit (shows the trend)
- **Shaded area** = confidence interval (uncertainty)

### Key Parameters
```python
sns.regplot(
    data=tips,
    x='total_bill',
    y='tip',
    ci=95,              # Confidence interval (95% default, None to hide)
    scatter_kws={'alpha': 0.5},  # Scatter plot options
    line_kws={'color': 'red'}    # Line options
)
```

### Pro Tips
- The line shows the "average" trend
- Shaded band = we're 95% confident the true line is in here
- `ci=None` removes the confidence band
- Check if points follow the line (or scatter randomly)

---

## 2. lmplot - Linear Model Plot (Figure-Level)

Like `regplot`, but can create **multiple plots** for different groups.

### When to Use
- Comparing regression across categories
- Creating faceted regression plots
- You need more figure control

### Basic Example
```python
sns.lmplot(data=tips, x='total_bill', y='tip')
plt.show()
```

### The Power: Comparing Groups
```python
# Different color for each time
sns.lmplot(data=tips, x='total_bill', y='tip', hue='time')
plt.show()

# Separate plots for each day
sns.lmplot(data=tips, x='total_bill', y='tip', col='day')
plt.show()
```

### Key Parameters
```python
sns.lmplot(
    data=tips,
    x='total_bill',
    y='tip',
    hue='smoker',      # Different line for each group
    col='time',        # Separate plots in columns
    row='sex',         # Separate plots in rows
    height=4,          # Height of each plot
    aspect=1.2,        # Width = height * aspect
    ci=95              # Confidence interval
)
```

---

## 3. residplot - Residual Plot

Shows the **residuals** (errors) - the difference between actual values and predicted values.

### When to Use
- Checking if a linear model is appropriate
- Looking for patterns in errors
- Model diagnostics

### Basic Example
```python
sns.residplot(data=tips, x='total_bill', y='tip')
plt.title('Residuals: Are Errors Random?')
plt.ylabel('Residuals')
plt.show()
```

### Reading a Residual Plot
- **Good**: Points randomly scattered around zero
- **Bad**: Points show a pattern (curve, funnel, etc.)

```
GOOD (random scatter)       BAD (pattern = linear not appropriate)
     .  .                          .    .
   .   .  .                      .   .
 ---.---.---.---             ----.-----.----
     .  .                    .    .
   .    .                       .
```

---

## 4. Polynomial and Lowess Regression

Sometimes data isn't linear!

### Polynomial Regression
```python
# Fit a curve instead of a line
sns.regplot(data=tips, x='total_bill', y='tip', order=2)  # Quadratic
sns.regplot(data=tips, x='total_bill', y='tip', order=3)  # Cubic
```

### LOWESS (Locally Weighted)
```python
# Flexible curve that follows the data
sns.regplot(data=tips, x='total_bill', y='tip', lowess=True)
```

LOWESS is great when you're not sure what shape the relationship has.

---

## 5. Logistic Regression (for Yes/No outcomes)

When your y-variable is binary (0 or 1, True or False):

```python
# Example: Does total bill predict big tip (>$3)?
tips['big_tip'] = (tips['tip'] > 3).astype(int)

sns.regplot(data=tips, x='total_bill', y='big_tip', logistic=True)
plt.title('Probability of Big Tip by Total Bill')
plt.ylabel('Probability of Big Tip')
plt.show()
```

---

## Comparison: Matplotlib vs Seaborn

### Matplotlib (LOTS of work!)
```python
import numpy as np
from scipy import stats

# Calculate regression
slope, intercept, r, p, se = stats.linregress(tips['total_bill'], tips['tip'])

# Create plot
plt.scatter(tips['total_bill'], tips['tip'])
x_line = np.linspace(tips['total_bill'].min(), tips['total_bill'].max(), 100)
y_line = slope * x_line + intercept
plt.plot(x_line, y_line, color='red')
plt.xlabel('Total Bill')
plt.ylabel('Tip')
plt.show()
```

### Seaborn (ONE line!)
```python
sns.regplot(data=tips, x='total_bill', y='tip')
plt.show()
```

---

## Interpreting Regression Plots

### Strong Relationship
- Points cluster tightly around the line
- Small confidence band
- Clear direction (up or down)

### Weak Relationship
- Points scattered far from line
- Wide confidence band
- Hard to see clear trend

### No Relationship
- Line is nearly flat
- Points scattered everywhere
- Very wide confidence band

---

## Quick Reference

| Task | Code |
|------|------|
| Basic regression | `sns.regplot(data=df, x='x', y='y')` |
| No confidence band | `sns.regplot(data=df, x='x', y='y', ci=None)` |
| Polynomial fit | `sns.regplot(data=df, x='x', y='y', order=2)` |
| LOWESS (flexible) | `sns.regplot(data=df, x='x', y='y', lowess=True)` |
| Logistic (binary y) | `sns.regplot(data=df, x='x', y='y', logistic=True)` |
| Compare groups | `sns.lmplot(data=df, x='x', y='y', hue='group')` |
| Faceted regression | `sns.lmplot(data=df, x='x', y='y', col='group')` |
| Check residuals | `sns.residplot(data=df, x='x', y='y')` |

---

## Summary

- **regplot**: Scatter + regression line (simple, axes-level)
- **lmplot**: Scatter + regression with faceting (figure-level)
- **residplot**: Check if linear model is appropriate

**Key insights these plots reveal:**
- Direction of relationship (positive/negative)
- Strength of relationship (tight vs scattered)
- Whether a line is appropriate (check residuals!)
- Differences between groups

**Important:** A regression line doesn't prove causation! Just because X and Y are related doesn't mean X causes Y.

**Next:** Pair Plots and FacetGrid for multi-variable analysis!
