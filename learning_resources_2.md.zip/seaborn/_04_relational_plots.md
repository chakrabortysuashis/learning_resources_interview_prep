# Relational Plots in Seaborn

## What are Relational Plots?

Relational plots show **relationships between two numeric variables**. They answer questions like:
- Does one variable increase when another increases?
- Is there a pattern or trend in the data?
- How do different groups compare in their relationships?

## The Three Main Relational Plots

| Plot | What It Shows | Best For |
|------|--------------|----------|
| `scatterplot` | Points showing x,y pairs | Finding relationships |
| `lineplot` | Connected points (usually time) | Trends over time |
| `relplot` | Flexible figure-level plot | Faceted comparisons |

---

## 1. scatterplot - Scatter Plot

Shows each data point as a dot at its (x, y) position.

### When to Use
- You want to see if two variables are related
- Looking for patterns, clusters, or outliers
- Comparing continuous (numeric) variables

### Basic Example
```python
import seaborn as sns
import matplotlib.pyplot as plt

tips = sns.load_dataset('tips')

sns.scatterplot(data=tips, x='total_bill', y='tip')
plt.title('Do Bigger Bills Get Bigger Tips?')
plt.show()
```

### Adding More Dimensions
```python
# Color by category
sns.scatterplot(data=tips, x='total_bill', y='tip', hue='day')

# Size by value
sns.scatterplot(data=tips, x='total_bill', y='tip', size='size')

# Shape by category
sns.scatterplot(data=tips, x='total_bill', y='tip', style='smoker')

# All together!
sns.scatterplot(data=tips, x='total_bill', y='tip', 
                hue='day', size='size', style='smoker')
```

### Key Parameters
```python
sns.scatterplot(
    data=tips,
    x='total_bill',
    y='tip',
    hue='day',         # Color by category
    size='size',       # Size by value
    style='smoker',    # Shape by category
    palette='Set2',    # Color scheme
    alpha=0.7,         # Transparency
    sizes=(20, 200)    # Min and max point size
)
```

### Pro Tips
- `hue` = color (categories or continuous)
- `size` = point size (usually continuous values)
- `style` = point shape (categories only)
- Use `alpha` when points overlap
- Look for patterns: linear, curved, clusters

---

## 2. lineplot - Line Plot

Connects points with lines. Best for showing **change over time** or ordered data.

### When to Use
- Data has a natural order (time, sequence)
- You want to show trends
- Comparing trends between groups

### Basic Example
```python
flights = sns.load_dataset('flights')

sns.lineplot(data=flights, x='year', y='passengers')
plt.title('Airline Passengers Over Time')
plt.show()
```

### Key Parameters
```python
sns.lineplot(
    data=flights,
    x='year',
    y='passengers',
    hue='month',       # Different line for each group
    style='month',     # Different line style
    markers=True,      # Show data points
    dashes=True,       # Use dashed lines for style
    errorbar='sd'      # Show standard deviation (or 'ci' for confidence)
)
```

### Understanding Error Bands
When you have multiple values for each x:
- Seaborn automatically shows the **mean** (average)
- Shaded band = uncertainty (confidence interval or std dev)
- Set `errorbar=None` to remove the band

### Pro Tips
- Great for time series data
- `markers=True` shows actual data points
- `errorbar='sd'` shows spread, `errorbar='ci'` shows confidence
- Lines should connect meaningful sequences (time, order)

---

## 3. relplot - Relational Plot (Figure-Level)

`relplot` is a **flexible, figure-level** function that can create scatter or line plots, and easily split into grids.

### When to Use
- You want to compare relationships across categories
- Creating grids of plots
- You need more control over the figure

### Basic Example
```python
# As scatterplot
sns.relplot(data=tips, x='total_bill', y='tip', kind='scatter')

# As lineplot
sns.relplot(data=flights, x='year', y='passengers', kind='line')
```

### The Power of Faceting
```python
# Separate plots for each day
sns.relplot(data=tips, x='total_bill', y='tip', col='day')

# Grid: columns by time, rows by smoker
sns.relplot(data=tips, x='total_bill', y='tip', 
            col='time', row='smoker')
```

### Key Parameters
```python
sns.relplot(
    data=tips,
    x='total_bill',
    y='tip',
    kind='scatter',    # 'scatter' or 'line'
    hue='day',         # Color by category
    col='time',        # Separate columns
    row='smoker',      # Separate rows
    col_wrap=2,        # Max columns before wrapping
    height=4,          # Height of each subplot
    aspect=1.2         # Width = height * aspect
)
```

---

## Comparison: Matplotlib vs Seaborn

### Matplotlib Scatter Plot
```python
import matplotlib.pyplot as plt

# Basic scatter
plt.scatter(tips['total_bill'], tips['tip'])
plt.xlabel('Total Bill')
plt.ylabel('Tip')
plt.title('Matplotlib Scatter')
plt.show()

# With color groups - requires manual work!
for day in tips['day'].unique():
    subset = tips[tips['day'] == day]
    plt.scatter(subset['total_bill'], subset['tip'], label=day)
plt.legend()
plt.show()
```

### Seaborn Scatter Plot
```python
# One line for colored groups!
sns.scatterplot(data=tips, x='total_bill', y='tip', hue='day')
plt.show()
```

**Seaborn wins:** Automatic coloring, legends, and better defaults!

---

## Interpreting Scatter Plots

### Pattern Types
```
POSITIVE CORRELATION        NEGATIVE CORRELATION       NO CORRELATION
   /                           \                          . . .
  /                             \                        . . .
 /    (as x↑, y↑)                \  (as x↑, y↓)        . . .  (no pattern)
```

### What to Look For
- **Direction**: Does y increase or decrease with x?
- **Strength**: How tight are points to the pattern?
- **Shape**: Is the pattern linear (straight) or curved?
- **Outliers**: Any points far from the pattern?
- **Clusters**: Are there distinct groups?

---

## Quick Reference

| Task | Code |
|------|------|
| Basic scatter | `sns.scatterplot(data=df, x='x', y='y')` |
| Colored scatter | `sns.scatterplot(data=df, x='x', y='y', hue='group')` |
| Sized points | `sns.scatterplot(data=df, x='x', y='y', size='value')` |
| Basic line | `sns.lineplot(data=df, x='x', y='y')` |
| Multiple lines | `sns.lineplot(data=df, x='x', y='y', hue='group')` |
| Line with markers | `sns.lineplot(data=df, x='x', y='y', markers=True)` |
| Faceted scatter | `sns.relplot(data=df, x='x', y='y', col='group')` |
| Faceted line | `sns.relplot(data=df, x='x', y='y', kind='line', col='group')` |

---

## Summary

- **scatterplot**: Show relationship between two numeric variables
- **lineplot**: Show trends over time/sequence (with error bands)
- **relplot**: Create grids of scatter or line plots

**Key insights these plots reveal:**
- Correlations (positive, negative, none)
- Trends over time
- Differences between groups
- Outliers and clusters
- Strength of relationships

**Next:** Matrix Plots for heatmaps and correlation matrices!
