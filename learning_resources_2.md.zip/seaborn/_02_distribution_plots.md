# Distribution Plots in Seaborn

## What are Distribution Plots?

Distribution plots show **how your data is spread out**. They answer questions like:
- What's the most common value?
- Are values clustered together or spread apart?
- Are there any unusual values (outliers)?

## The Four Main Distribution Plots

| Plot | What It Shows | Best For |
|------|--------------|----------|
| `histplot` | Bars showing count in each range | Most common, easy to understand |
| `kdeplot` | Smooth curve showing density | Seeing the overall shape |
| `rugplot` | Tiny lines for each data point | Small datasets, exact values |
| `displot` | Flexible figure-level plot | Combining multiple distributions |

---

## 1. histplot - Histogram

A histogram divides your data into "bins" (ranges) and counts how many values fall in each bin.

### When to Use
- You want to see how data is distributed
- You're starting your analysis (first plot to try!)
- You want to find the most common values

### Basic Example
```python
import seaborn as sns
import matplotlib.pyplot as plt

tips = sns.load_dataset('tips')

sns.histplot(data=tips, x='total_bill')
plt.title('Distribution of Total Bills')
plt.show()
```

### Key Parameters
```python
sns.histplot(
    data=tips, 
    x='total_bill',
    bins=20,           # Number of bars (default: auto)
    kde=True,          # Add smooth density curve
    color='coral',     # Bar color
    edgecolor='white'  # Bar border color
)
```

### Pro Tips
- **bins=** controls detail level: more bins = more detail
- **kde=True** adds a smooth curve on top (best of both worlds!)
- Too few bins can hide patterns, too many creates noise

---

## 2. kdeplot - Kernel Density Estimate

KDE creates a **smooth curve** showing where your data is concentrated. Think of it as a smoothed-out histogram.

### When to Use
- You want a smooth, continuous view of distribution
- You're comparing multiple distributions
- You want to see the "shape" of data clearly

### Basic Example
```python
sns.kdeplot(data=tips, x='total_bill')
plt.title('Density of Total Bills')
plt.show()
```

### Comparing Groups
```python
sns.kdeplot(data=tips, x='total_bill', hue='time')
plt.title('Bill Distribution: Lunch vs Dinner')
plt.show()
```

### Key Parameters
```python
sns.kdeplot(
    data=tips,
    x='total_bill',
    fill=True,         # Fill under the curve
    alpha=0.5,         # Transparency (0-1)
    linewidth=2,       # Curve thickness
    bw_adjust=0.5      # Smoothness (lower = more detail)
)
```

### Pro Tips
- **fill=True** makes it easier to see and compare areas
- **bw_adjust** controls smoothness: 0.5 = more bumpy, 2 = smoother
- Great for comparing 2-3 groups on same plot

---

## 3. rugplot - Rug Plot

A rug plot shows a **tiny line for each data point** along the axis. It's like seeing the actual data beneath a histogram.

### When to Use
- You have a small dataset (under 100 points)
- You want to see exact value locations
- You're adding detail to another plot

### Basic Example
```python
sns.rugplot(data=tips, x='total_bill')
plt.title('Each Line = One Bill')
plt.show()
```

### Combined with KDE (Common Pattern)
```python
sns.kdeplot(data=tips, x='total_bill')
sns.rugplot(data=tips, x='total_bill', alpha=0.5)
plt.title('Density with Actual Data Points')
plt.show()
```

### Key Parameters
```python
sns.rugplot(
    data=tips,
    x='total_bill',
    height=0.1,        # Line height (0-1)
    alpha=0.5,         # Transparency
    color='red'        # Line color
)
```

### Pro Tips
- Best used WITH other plots, not alone
- Reduce alpha when you have many data points
- Shows clusters and gaps clearly

---

## 4. displot - Distribution Plot (Figure-Level)

`displot` is a **flexible, figure-level** function that can create histograms, KDE plots, or ECDF plots, and easily split by categories.

### When to Use
- You want to compare distributions across categories
- You want multiple plots in a grid
- You need more control over the figure

### Basic Example
```python
sns.displot(data=tips, x='total_bill', kind='hist')
plt.show()
```

### Multiple Groups with col/row
```python
# Create separate plots for each day
sns.displot(data=tips, x='total_bill', col='day', col_wrap=2)
plt.show()
```

### Key Parameters
```python
sns.displot(
    data=tips,
    x='total_bill',
    kind='kde',        # 'hist', 'kde', or 'ecdf'
    hue='time',        # Color by category
    col='day',         # Separate columns for each value
    row='smoker',      # Separate rows for each value
    col_wrap=2,        # Max columns before wrapping
    height=4,          # Height of each subplot
    aspect=1.2         # Width = height * aspect
)
```

### Pro Tips
- Use `kind=` to switch between histogram, kde, and ecdf
- `col=` and `row=` create faceted plots (grid of plots)
- Returns a FacetGrid object (not an Axes)

---

## Comparison: Matplotlib vs Seaborn

### Matplotlib Histogram
```python
import matplotlib.pyplot as plt

plt.hist(tips['total_bill'], bins=20, edgecolor='black')
plt.xlabel('Total Bill')
plt.ylabel('Frequency')
plt.title('Histogram with Matplotlib')
plt.show()
```

### Seaborn Histogram
```python
sns.histplot(data=tips, x='total_bill', bins=20)
plt.title('Histogram with Seaborn')
plt.show()
```

**Seaborn advantage:** Automatically handles DataFrames, better defaults, easy `hue` parameter!

---

## Quick Reference

| Task | Code |
|------|------|
| Basic histogram | `sns.histplot(data=df, x='col')` |
| Histogram with density | `sns.histplot(data=df, x='col', kde=True)` |
| Smooth density curve | `sns.kdeplot(data=df, x='col')` |
| Filled density | `sns.kdeplot(data=df, x='col', fill=True)` |
| Compare groups | `sns.kdeplot(data=df, x='col', hue='group')` |
| Show raw data | `sns.rugplot(data=df, x='col')` |
| Grid of plots | `sns.displot(data=df, x='col', col='group')` |

---

## Summary

- **histplot**: Bars counting values in ranges (most common)
- **kdeplot**: Smooth curve showing density (for shape)
- **rugplot**: Tiny marks for each data point (for detail)
- **displot**: Flexible function for any distribution plot

**Key insight:** Distribution plots reveal patterns like:
- Normal distribution (bell curve)
- Skewed data (tail on one side)
- Multiple peaks (different groups?)
- Outliers (unusual values)

**Next:** Categorical Plots for comparing groups!
