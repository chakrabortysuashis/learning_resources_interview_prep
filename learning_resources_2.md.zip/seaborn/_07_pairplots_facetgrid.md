# Pair Plots and FacetGrid in Seaborn

## What are These Tools?

These are **multi-plot** tools that create many charts at once to explore data from different angles.

| Tool | What It Does | Best For |
|------|-------------|----------|
| `pairplot` | Matrix of all variable combinations | Exploring relationships |
| `FacetGrid` | Grid of plots split by categories | Comparing groups |
| `catplot` | Categorical plots with faceting | Category comparisons |

---

## 1. pairplot - Pair Plot

Creates a **matrix of plots** showing every combination of numeric variables.

### When to Use
- You want to see ALL relationships at once
- Starting exploratory data analysis
- Looking for patterns across multiple variables

### Basic Example
```python
import seaborn as sns
import matplotlib.pyplot as plt

iris = sns.load_dataset('iris')

sns.pairplot(iris)
plt.show()
```

### Reading a Pair Plot
- **Diagonal**: Distribution of each variable
- **Off-diagonal**: Scatter plots of variable pairs
- **Upper triangle**: Mirror of lower triangle

### Key Parameters
```python
sns.pairplot(
    iris,
    hue='species',       # Color by category
    palette='Set2',      # Color scheme
    diag_kind='kde',     # 'hist' or 'kde' on diagonal
    corner=True,         # Only show lower triangle
    markers=['o', 's', 'D'],  # Different markers per hue
    height=2.5           # Size of each subplot
)
```

### Pro Tips
- `hue` colors by category - reveals group differences
- `corner=True` removes redundant upper triangle
- `diag_kind='kde'` shows smooth density on diagonal
- Works best with 3-6 numeric variables (more = too crowded)

---

## 2. FacetGrid - Create Custom Grid Layouts

`FacetGrid` gives you **complete control** over grid layouts.

### When to Use
- You want custom plots in a grid
- Comparing same plot across categories
- More control than built-in functions provide

### Basic Example
```python
tips = sns.load_dataset('tips')

# Create the grid
g = sns.FacetGrid(tips, col='time', row='smoker')

# Map a plot function to each cell
g.map(sns.histplot, 'total_bill')

plt.show()
```

### Step-by-Step Process
1. **Create FacetGrid** with row/col categories
2. **Map** a plotting function to fill cells
3. **Customize** titles, labels, etc.

### Key Parameters
```python
g = sns.FacetGrid(
    tips,
    col='day',           # Columns split by day
    row='time',          # Rows split by time
    hue='smoker',        # Color within each plot
    col_wrap=2,          # Max columns before wrapping
    height=4,            # Height of each plot
    aspect=1.2,          # Width = height * aspect
    margin_titles=True   # Titles on margins
)
```

### Common Mapping Functions
```python
# Histograms
g.map(sns.histplot, 'total_bill')

# Scatter plots
g.map(sns.scatterplot, 'total_bill', 'tip')

# KDE plots
g.map(sns.kdeplot, 'total_bill', fill=True)

# Custom functions work too!
g.map(plt.scatter, 'total_bill', 'tip')
```

---

## 3. catplot - Categorical Plot with Faceting

Combines categorical plots with faceting in one easy function.

### When to Use
- Creating box/violin/strip plots split by categories
- Comparing distributions across groups
- One-line faceted categorical plots

### Basic Example
```python
sns.catplot(data=tips, x='day', y='total_bill', kind='box')
plt.show()
```

### Faceted Categorical Plots
```python
# Box plots split by time
sns.catplot(data=tips, x='day', y='total_bill', 
            kind='box', col='time')
plt.show()

# Violin plots in a grid
sns.catplot(data=tips, x='day', y='total_bill',
            kind='violin', col='time', row='smoker')
plt.show()
```

### Available Plot Kinds
| Kind | Description |
|------|-------------|
| `'strip'` | Strip plot |
| `'swarm'` | Swarm plot |
| `'box'` | Box plot |
| `'violin'` | Violin plot |
| `'boxen'` | Enhanced box plot |
| `'point'` | Point plot (means + error bars) |
| `'bar'` | Bar plot (means + error bars) |
| `'count'` | Count plot |

---

## 4. PairGrid - Custom Pair Plot Layouts

Like `FacetGrid`, but for variable pairs (more control than `pairplot`).

### When to Use
- You want different plots in different parts of the pair matrix
- Custom diagonal, upper, and lower triangle plots

### Example: Different Plots in Each Region
```python
g = sns.PairGrid(iris, hue='species')
g.map_upper(sns.scatterplot)          # Upper: scatter
g.map_lower(sns.kdeplot)               # Lower: density
g.map_diag(sns.histplot)               # Diagonal: histogram
g.add_legend()
plt.show()
```

---

## Comparison: pairplot vs PairGrid

### pairplot (Simple)
```python
# One line, standard options
sns.pairplot(iris, hue='species')
```

### PairGrid (Flexible)
```python
# Multiple lines, full control
g = sns.PairGrid(iris, hue='species')
g.map_upper(sns.scatterplot)
g.map_lower(sns.kdeplot)
g.map_diag(sns.histplot)
g.add_legend()
```

**Use `pairplot` for quick exploration, `PairGrid` for custom layouts.**

---

## Quick Reference

| Task | Code |
|------|------|
| Basic pair plot | `sns.pairplot(df)` |
| Colored pair plot | `sns.pairplot(df, hue='group')` |
| Lower triangle only | `sns.pairplot(df, corner=True)` |
| KDE on diagonal | `sns.pairplot(df, diag_kind='kde')` |
| Basic FacetGrid | `g = sns.FacetGrid(df, col='cat'); g.map(sns.histplot, 'x')` |
| FacetGrid scatter | `g.map(sns.scatterplot, 'x', 'y')` |
| Basic catplot | `sns.catplot(data=df, x='cat', y='val', kind='box')` |
| Faceted catplot | `sns.catplot(data=df, x='cat', y='val', kind='box', col='group')` |

---

## Summary

- **pairplot**: See all variable pairs at once (quick exploration)
- **FacetGrid**: Custom grid of any plot type (flexible)
- **catplot**: Categorical plots with easy faceting (convenient)
- **PairGrid**: Custom pair plots (full control)

**Key insights these tools reveal:**
- Relationships between ALL variables
- How patterns differ across groups
- Outliers and clusters in multi-dimensional data
- Variable interactions

**Pro Tip:** Start with `pairplot` to explore, then use `FacetGrid` or `PairGrid` for publication-quality figures!

**Next:** Styling and Themes to make your plots beautiful!
