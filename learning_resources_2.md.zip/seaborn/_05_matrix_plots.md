# Matrix Plots in Seaborn

## What are Matrix Plots?

Matrix plots display data in a **grid format** using colors. They're perfect for:
- Showing relationships between many variables at once
- Visualizing correlation matrices
- Displaying any 2D data as colored cells

## The Main Matrix Plot: heatmap

| Feature | Description |
|---------|-------------|
| `heatmap` | Colored grid showing values |
| Colors | Represent values (dark/light = low/high) |
| Annotations | Optional numbers in cells |
| Best for | Correlation matrices, pivot tables |

---

## 1. Basic Heatmap

A heatmap colors cells based on their values.

### Basic Example
```python
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd

# Create sample data
data = pd.DataFrame({
    'A': [1, 2, 3],
    'B': [4, 5, 6],
    'C': [7, 8, 9]
})

sns.heatmap(data)
plt.title('Basic Heatmap')
plt.show()
```

### Reading a Heatmap
- **Darker colors** = Lower values
- **Lighter colors** = Higher values
- **Color bar** on right shows the scale

---

## 2. Correlation Heatmaps

The most common use: showing how variables relate to each other.

### What is Correlation?
- **+1** = Perfect positive (both increase together)
- **0** = No relationship
- **-1** = Perfect negative (one up, other down)

### Creating a Correlation Heatmap
```python
# Load data
tips = sns.load_dataset('tips')

# Calculate correlations (only for numeric columns)
correlation = tips.select_dtypes(include='number').corr()

# Create heatmap
sns.heatmap(correlation, annot=True)
plt.title('Correlation Matrix')
plt.show()
```

### Key Parameters
```python
sns.heatmap(
    correlation,
    annot=True,           # Show numbers in cells
    fmt='.2f',            # Number format (2 decimal places)
    cmap='coolwarm',      # Color scheme
    center=0,             # Center color at 0
    vmin=-1, vmax=1,      # Color scale limits
    linewidths=0.5,       # Lines between cells
    square=True           # Square cells
)
```

---

## 3. Common Color Maps (cmap)

Choose the right colors for your data:

| Color Map | Best For | Example |
|-----------|----------|---------|
| `coolwarm` | Correlation (negative to positive) | Blue → White → Red |
| `viridis` | Sequential data | Purple → Green → Yellow |
| `Blues` | All positive values | Light → Dark blue |
| `RdYlGn` | Good/bad (red=bad, green=good) | Red → Yellow → Green |
| `YlOrRd` | Heat/intensity | Yellow → Orange → Red |

### Correlation-Specific Tip
For correlations, use `center=0` so:
- Zero = neutral color (white)
- Positive = one color (red)
- Negative = opposite color (blue)

---

## 4. Annotations and Formatting

### Show Values in Cells
```python
# Basic annotations
sns.heatmap(correlation, annot=True)

# Formatted annotations
sns.heatmap(correlation, annot=True, fmt='.2f')  # 2 decimal places
sns.heatmap(correlation, annot=True, fmt='.0f')  # No decimals
sns.heatmap(correlation, annot=True, fmt='.1%')  # As percentage
```

### Customize Annotation Appearance
```python
sns.heatmap(
    correlation,
    annot=True,
    annot_kws={'size': 12, 'weight': 'bold'}  # Font settings
)
```

---

## 5. Pivot Tables and Heatmaps

Pivot tables reorganize data - perfect for heatmaps!

### Example: Flights Data
```python
flights = sns.load_dataset('flights')

# Create pivot table (rows=months, columns=years, values=passengers)
flights_pivot = flights.pivot(index='month', columns='year', values='passengers')

# Create heatmap
sns.heatmap(flights_pivot, cmap='YlOrRd')
plt.title('Airline Passengers by Month and Year')
plt.show()
```

---

## 6. Masking (Hiding Parts)

Sometimes you only want to show part of a matrix:

### Show Only Lower Triangle (Correlation)
```python
import numpy as np

# Calculate correlation
corr = tips.select_dtypes(include='number').corr()

# Create mask for upper triangle
mask = np.triu(np.ones_like(corr, dtype=bool))

# Apply mask
sns.heatmap(corr, mask=mask, annot=True, cmap='coolwarm')
plt.title('Lower Triangle Only')
plt.show()
```

This removes duplicate information (correlation matrix is symmetric).

---

## Comparison: Basic vs Enhanced Heatmap

### Basic (Default)
```python
sns.heatmap(correlation)
```

### Enhanced (Production-Ready)
```python
plt.figure(figsize=(10, 8))
sns.heatmap(
    correlation,
    annot=True,
    fmt='.2f',
    cmap='coolwarm',
    center=0,
    linewidths=0.5,
    square=True,
    cbar_kws={'shrink': 0.8}
)
plt.title('Correlation Matrix', fontsize=14)
plt.tight_layout()
plt.show()
```

---

## Quick Reference

| Task | Code |
|------|------|
| Basic heatmap | `sns.heatmap(data)` |
| With annotations | `sns.heatmap(data, annot=True)` |
| Format numbers | `sns.heatmap(data, annot=True, fmt='.2f')` |
| Change colors | `sns.heatmap(data, cmap='coolwarm')` |
| Center at zero | `sns.heatmap(data, center=0)` |
| Add gridlines | `sns.heatmap(data, linewidths=0.5)` |
| Square cells | `sns.heatmap(data, square=True)` |
| Mask upper triangle | `sns.heatmap(data, mask=mask)` |

---

## When to Use Heatmaps

**Good for:**
- Correlation matrices (which variables relate?)
- Time-based patterns (months vs years)
- Pivot tables (comparing categories)
- Any 2D numeric data

**Not good for:**
- Precise value reading (hard to tell exact numbers)
- Very large matrices (too many cells)
- Non-numeric data

---

## Summary

- **Heatmaps** show values as colors in a grid
- **Correlation heatmaps** are the most common use
- Use `annot=True` to show actual values
- Choose `cmap` based on your data type
- Use `center=0` for correlation matrices
- `mask` can hide redundant information

**Key insight:** Heatmaps help you quickly spot:
- Strong relationships (bright/dark colors)
- Patterns across rows/columns
- Outliers (cells that stand out)

**Next:** Regression Plots for statistical relationships!
