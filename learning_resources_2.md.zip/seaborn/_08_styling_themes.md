# Styling and Themes in Seaborn

## Why Styling Matters

Good styling makes your plots:
- **Easier to read** - Clear, professional appearance
- **More impactful** - Right colors draw attention
- **Consistent** - Unified look across all plots

## The Four Main Styling Functions

| Function | What It Controls |
|----------|------------------|
| `set_theme()` | Everything at once (recommended) |
| `set_style()` | Background, grid, axes |
| `set_palette()` | Colors used in plots |
| `set_context()` | Size of elements (labels, lines) |

---

## 1. set_theme() - The All-in-One Solution

Sets style, palette, and context all at once. **Use this first!**

### Basic Usage
```python
import seaborn as sns

sns.set_theme()  # Use Seaborn's nice defaults
```

### With Parameters
```python
sns.set_theme(
    style='whitegrid',      # Background style
    palette='deep',         # Color palette
    context='notebook',     # Size preset
    font_scale=1.2          # Make text bigger
)
```

### Reset to Default
```python
sns.reset_defaults()  # Back to original
# or
sns.set_theme()       # Back to Seaborn defaults
```

---

## 2. set_style() - Background and Grid

Controls the overall look of the plot background.

### Five Built-in Styles

| Style | Description | Best For |
|-------|-------------|----------|
| `'darkgrid'` | Gray background + white grid | Default, general use |
| `'whitegrid'` | White background + gray grid | Comparing values |
| `'dark'` | Gray background, no grid | Filled plots (heatmaps) |
| `'white'` | White background, no grid | Clean, minimal look |
| `'ticks'` | White + ticks on axes | Publication figures |

### Usage
```python
sns.set_style('whitegrid')

# Or with customization
sns.set_style('whitegrid', {
    'grid.linestyle': '--',
    'axes.edgecolor': 'gray'
})
```

### Temporary Style (within a block)
```python
with sns.axes_style('darkgrid'):
    # This plot uses darkgrid
    sns.lineplot(data=df, x='x', y='y')

# Plots outside the block use original style
```

---

## 3. set_palette() - Colors

Controls the colors used for different categories.

### Built-in Palettes

**Categorical (for distinct groups):**
| Palette | Description |
|---------|-------------|
| `'deep'` | Rich, saturated colors (default) |
| `'muted'` | Softer colors |
| `'pastel'` | Light, pastel colors |
| `'bright'` | Vivid colors |
| `'dark'` | Darker shades |
| `'colorblind'` | Accessible to colorblind viewers |

**Sequential (for ordered data):**
- `'Blues'`, `'Greens'`, `'Reds'` - Single color gradients
- `'viridis'`, `'plasma'` - Perceptually uniform

**Diverging (for data with a center point):**
- `'coolwarm'` - Blue to red
- `'RdYlGn'` - Red to yellow to green

### Usage
```python
# Set globally
sns.set_palette('colorblind')

# Or for a single plot
sns.barplot(data=df, x='x', y='y', palette='pastel')
```

### Custom Palettes
```python
# List of specific colors
custom = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4']
sns.set_palette(custom)

# Generate palette from color map
palette = sns.color_palette('husl', 8)  # 8 colors from husl
```

---

## 4. set_context() - Size and Scale

Controls the size of plot elements for different uses.

### Four Built-in Contexts

| Context | Element Size | Best For |
|---------|--------------|----------|
| `'paper'` | Smallest | Print publications |
| `'notebook'` | Medium (default) | Jupyter notebooks |
| `'talk'` | Large | Presentations |
| `'poster'` | Largest | Posters, large displays |

### Usage
```python
sns.set_context('talk')  # Bigger for presentations

# With fine-tuning
sns.set_context('talk', font_scale=1.5, rc={'lines.linewidth': 3})
```

---

## 5. Practical Examples

### Style Comparison
```python
import matplotlib.pyplot as plt

styles = ['darkgrid', 'whitegrid', 'dark', 'white', 'ticks']

for style in styles:
    sns.set_style(style)
    plt.figure(figsize=(6, 4))
    sns.lineplot(data=tips, x='total_bill', y='tip')
    plt.title(f"Style: {style}")
    plt.show()
```

### Palette Comparison
```python
palettes = ['deep', 'muted', 'pastel', 'bright', 'colorblind']

for palette in palettes:
    plt.figure(figsize=(8, 4))
    sns.barplot(data=tips, x='day', y='total_bill', palette=palette)
    plt.title(f"Palette: {palette}")
    plt.show()
```

### Context Comparison
```python
contexts = ['paper', 'notebook', 'talk', 'poster']

for context in contexts:
    sns.set_context(context)
    plt.figure(figsize=(6, 4))
    sns.lineplot(data=flights, x='year', y='passengers')
    plt.title(f"Context: {context}")
    plt.show()
```

---

## 6. Removing Spines (Borders)

Spines are the lines around the plot. Remove them for cleaner looks:

```python
sns.set_style('white')

plt.figure(figsize=(8, 5))
sns.barplot(data=tips, x='day', y='total_bill')

# Remove top and right spines
sns.despine()

# Or remove specific spines
sns.despine(left=True, bottom=True)
```

---

## 7. Quick Reference

### Common Combinations

**For Presentations:**
```python
sns.set_theme(style='whitegrid', context='talk', palette='bright')
```

**For Publications:**
```python
sns.set_theme(style='ticks', context='paper', palette='colorblind')
sns.despine()
```

**For Dark Mode:**
```python
sns.set_theme(style='darkgrid', palette='pastel')
```

**For Data Exploration:**
```python
sns.set_theme()  # Defaults are great!
```

### Cheat Sheet

| Task | Code |
|------|------|
| Nice defaults | `sns.set_theme()` |
| Change style | `sns.set_style('whitegrid')` |
| Change colors | `sns.set_palette('colorblind')` |
| Bigger text | `sns.set_context('talk')` |
| Remove borders | `sns.despine()` |
| Reset everything | `sns.reset_defaults()` |

---

## 8. Pro Tips

1. **Start with `set_theme()`** - It sets good defaults
2. **Use `colorblind` palette** for accessibility
3. **Match context to output** - 'talk' for slides, 'paper' for prints
4. **`despine()` makes plots cleaner** - Try it!
5. **Consistency matters** - Use same style across all plots
6. **Test on intended medium** - Colors look different on screen vs print

---

## Summary

| Function | Controls | Default |
|----------|----------|---------|
| `set_theme()` | Everything | Seaborn defaults |
| `set_style()` | Background/grid | 'darkgrid' |
| `set_palette()` | Colors | 'deep' |
| `set_context()` | Size | 'notebook' |

**Recommended workflow:**
1. Call `sns.set_theme()` at the start
2. Adjust style, palette, or context as needed
3. Use `despine()` for publication-quality plots
4. Reset with `sns.reset_defaults()` if needed

**Next:** Practical Exercises to apply everything you've learned!
