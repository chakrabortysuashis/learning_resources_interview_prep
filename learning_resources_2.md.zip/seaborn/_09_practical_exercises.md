# Practical Exercises: Real-World Statistical Visualization

## About These Exercises

Now it's time to apply everything you've learned! These exercises use real-world scenarios to practice creating meaningful statistical visualizations.

**Tips for Success:**
1. Read the question carefully - what insight are we looking for?
2. Choose the right plot type for the data and question
3. Add proper titles and labels
4. Think about what story the visualization tells

---

## Exercise Set 1: Restaurant Tipping Analysis (tips dataset)

### Exercise 1.1: Distribution Analysis
**Question:** What is the distribution of tips, and how does it differ between lunch and dinner?

**Create:**
1. A histogram of tips with KDE overlay
2. Separate histograms comparing lunch vs dinner

**What to look for:** Is the distribution normal? Are dinner tips higher?

---

### Exercise 1.2: Tipping Patterns by Day
**Question:** Which day has the highest tips? Is there more variability on certain days?

**Create:**
1. A box plot of tips by day
2. Add a swarm plot overlay to show individual data points

**What to look for:** Median values, spread, outliers

---

### Exercise 1.3: Tip Percentage Analysis
**Question:** Do people tip a consistent percentage regardless of bill size?

**Steps:**
1. Calculate tip percentage: `tip_pct = (tip / total_bill) * 100`
2. Create a scatter plot of total_bill vs tip_pct
3. Add a regression line

**What to look for:** Does tip percentage decrease as bills increase?

---

### Exercise 1.4: Multi-Variable Analysis
**Question:** How do multiple factors (day, time, smoker status) affect tipping?

**Create:**
1. A faceted violin plot: day on x-axis, tips on y-axis
2. Facet by time (columns) and smoker (rows)
3. Color by sex

---

## Exercise Set 2: Titanic Survival Analysis (titanic dataset)

### Exercise 2.1: Survival by Class
**Question:** Did passenger class affect survival rates?

**Create:**
1. A count plot showing survival (hue) by class
2. Calculate and visualize survival percentages

**What to look for:** Did first class passengers survive more?

---

### Exercise 2.2: Age Distribution
**Question:** What was the age distribution of passengers? Did it differ by class?

**Create:**
1. Overlapping KDE plots of age by class
2. Add vertical lines for median age of each class

**What to look for:** Were higher classes older or younger?

---

### Exercise 2.3: Survival Factors
**Question:** Which factors most strongly predicted survival?

**Create:**
1. A heatmap of survival rates by class AND sex
2. A faceted bar plot showing survival by age group and class

**Hint:** Create age groups: Child (<18), Adult (18-60), Senior (60+)

---

### Exercise 2.4: Family Size Impact
**Question:** Did traveling with family affect survival?

**Steps:**
1. Create family_size = sibsp + parch + 1
2. Visualize survival rates by family size
3. Compare solo travelers vs families

---

## Exercise Set 3: Penguin Species Analysis (penguins dataset)

### Exercise 3.1: Species Identification
**Question:** Can we identify penguin species based on physical measurements?

**Create:**
1. A pair plot of all numeric variables colored by species
2. Identify which measurements best separate the species

---

### Exercise 3.2: Island Distribution
**Question:** How are penguin species distributed across islands?

**Create:**
1. A grouped bar chart showing species count by island
2. A heatmap of species vs island

**What to look for:** Do certain species live on specific islands?

---

### Exercise 3.3: Sexual Dimorphism
**Question:** Are there size differences between male and female penguins?

**Create:**
1. Split violin plots of body mass by species and sex
2. Calculate the percentage difference in mass between sexes

---

### Exercise 3.4: Correlation Analysis
**Question:** Which body measurements are most correlated?

**Create:**
1. A correlation heatmap (masked lower triangle)
2. Scatter plots with regression lines for the top 2 correlations

---

## Exercise Set 4: Flight Passenger Trends (flights dataset)

### Exercise 4.1: Seasonal Patterns
**Question:** Are there seasonal patterns in airline travel?

**Create:**
1. A line plot of passengers by month (averaged across years)
2. Identify peak and low travel months

---

### Exercise 4.2: Growth Over Time
**Question:** How did airline travel grow over the years?

**Create:**
1. A line plot of total yearly passengers
2. A heatmap showing passengers by month and year

---

### Exercise 4.3: Month-to-Month Comparison
**Question:** Which months show the most consistent growth year over year?

**Create:**
1. Faceted line plots (one per month) showing year trend
2. Identify months with stable vs variable growth

---

## Exercise Set 5: Comprehensive Dashboard

### Final Challenge: Create a Dashboard
**Goal:** Create a comprehensive visual analysis of ONE dataset.

**Requirements:**
1. At least 4 different plot types
2. Proper styling (consistent theme)
3. Clear titles and labels
4. Written interpretation of findings

**Suggested Layout:**
- Distribution plot (how data is spread)
- Comparison plot (how groups differ)
- Relationship plot (how variables relate)
- Summary visualization (key insight)

---

## Quick Reference: Choosing the Right Plot

| Question Type | Best Plot Types |
|--------------|-----------------|
| Distribution of one variable | histplot, kdeplot, boxplot |
| Compare groups | boxplot, violinplot, barplot |
| Relationship between two variables | scatterplot, regplot |
| Trends over time | lineplot |
| Categorical counts | countplot |
| Correlations | heatmap |
| Multi-variable exploration | pairplot, FacetGrid |

---

## Checklist for Every Visualization

- [ ] Does the title explain what the plot shows?
- [ ] Are axis labels clear and include units?
- [ ] Is the right plot type used for the data?
- [ ] Are colors meaningful (not just decorative)?
- [ ] Can someone understand it without explanation?
- [ ] Does it answer the question being asked?

---

## Solutions Approach

For each exercise:
1. **Load the data** and explore it briefly
2. **Plan your visualization** - what plot type? what variables?
3. **Create the basic plot**
4. **Enhance** with proper styling, titles, labels
5. **Interpret** - what does the visualization tell us?

Good luck! Remember: the goal is not just to make a plot, but to **discover and communicate insights** from data!
