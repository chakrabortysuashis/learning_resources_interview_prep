# Introduction to Seaborn

## What is Seaborn?

Seaborn is a Python library that makes creating beautiful statistical charts **super easy**. Think of it as Matplotlib's cooler, easier-to-use cousin!

**Key Points:**
- Built on top of Matplotlib (uses it behind the scenes)
- Makes pretty graphs with less code
- Great for exploring data and finding patterns
- Comes with built-in datasets to practice with

## Seaborn vs Matplotlib: What's the Difference?

| Feature | Matplotlib | Seaborn |
|---------|-----------|---------|
| Code needed | More code | Less code |
| Default looks | Basic | Beautiful |
| Statistical plots | Manual work | Built-in |
| Learning curve | Steeper | Easier |
| Customization | Very flexible | Less flexible |

**Think of it this way:**
- **Matplotlib** = Building a house from scratch with raw materials
- **Seaborn** = Using pre-built, beautiful room kits

## When to Use Each?

**Use Seaborn when:**
- You want quick, beautiful statistical plots
- You're exploring data
- You need to show relationships between variables
- You want professional-looking graphs fast

**Use Matplotlib when:**
- You need very specific customizations
- You're making non-statistical charts
- You need full control over every element

## Built-in Datasets

Seaborn comes with practice datasets so you can learn without finding your own data!

| Dataset | Description | Best For Learning |
|---------|-------------|-------------------|
| `tips` | Restaurant tips data | Scatter plots, distributions |
| `titanic` | Titanic passenger data | Categorical plots |
| `iris` | Flower measurements | Pair plots, clustering |
| `penguins` | Penguin measurements | All plot types |
| `diamonds` | Diamond prices & features | Large dataset practice |
| `flights` | Monthly airline passengers | Heatmaps, time series |

## Installation

```bash
pip install seaborn
```

## Basic Import Pattern

```python
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd

# Load a built-in dataset
tips = sns.load_dataset('tips')

# Create a plot
sns.histplot(data=tips, x='total_bill')
plt.show()
```

## Pro Tips

1. **Always import both**: `import seaborn as sns` and `import matplotlib.pyplot as plt`
2. **Use `sns` as the shortcut** - everyone does this!
3. **Start with built-in datasets** - no data cleaning needed
4. **Call `plt.show()`** at the end to display your plot

## Quick Reference: Your First Plot

```python
import seaborn as sns
import matplotlib.pyplot as plt

# Load data
tips = sns.load_dataset('tips')

# Create plot (just ONE line!)
sns.scatterplot(data=tips, x='total_bill', y='tip')

# Show it
plt.title('Tips vs Total Bill')
plt.show()
```

**That's it!** You just made a beautiful scatter plot in 4 lines of code!

---

## Summary

- Seaborn = Easy, beautiful statistical visualizations
- Built on Matplotlib (they work together)
- Comes with practice datasets
- Less code = faster results
- Perfect for data exploration

**Next:** Let's learn about Distribution Plots!
