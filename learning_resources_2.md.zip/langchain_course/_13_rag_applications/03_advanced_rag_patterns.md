# Module 13.3: Advanced RAG Patterns

## Introduction

Basic RAG pipelines have predictable failure modes. This module covers advanced techniques that address these limitations: Parent Document Retriever, HyDE (Hypothetical Document Embeddings), Query Transformation, and other production-ready patterns.

---

## Why Advanced RAG?

### The Limitations of Naive RAG

```
                    NAIVE RAG FAILURE MODES

1. CHUNKING DESTROYS CONTEXT
   +----------------------------------------+
   | "The company was founded in 1995 by"   | <- Chunk 1
   +----------------------------------------+
   | "John Smith, who had a vision of..."   | <- Chunk 2 (loses context!)
   +----------------------------------------+

2. VOCABULARY MISMATCH
   Query: "vacation policy"
   Docs:  "PTO guidelines", "time-off procedures", "leave benefits"
   Result: Relevant docs NOT retrieved!

3. COMPLEX QUERIES
   Query: "Compare the Q1 and Q2 revenue, then explain the trend"
   Problem: Single retrieval can't handle multi-step reasoning

4. REDUNDANT RETRIEVAL
   Retrieved: [Doc about X, Another doc about X, Third doc about X, ...]
   Problem: No diversity, missing other relevant information
```

### Advanced RAG Solution Landscape

```
+==============================================================================+
|                      ADVANCED RAG TECHNIQUES MAP                             |
+==============================================================================+
|                                                                              |
|  PRE-RETRIEVAL                     RETRIEVAL             POST-RETRIEVAL     |
|  +------------------+         +------------------+    +------------------+   |
|  | Query Transform  |         | Hybrid Search    |    | Reranking        |   |
|  | - Multi-query    |   -->   | - Semantic       | -> | - Cross-encoder  |   |
|  | - HyDE           |         | - Keyword (BM25) |    | - LLM-based      |   |
|  | - Step-back      |         | - Ensemble       |    |                  |   |
|  +------------------+         +------------------+    +------------------+   |
|                                      |                        |              |
|                                      v                        v              |
|  INDEXING                     +------------------+    +------------------+   |
|  +------------------+         | Multi-vector     |    | Compression      |   |
|  | Parent-child     |         | - Summary + full |    | - Extract key    |   |
|  | - Small chunks   |         | - Questions      |    |   passages       |   |
|  |   for retrieval  |         | - Hypothetical   |    | - Summarize      |   |
|  | - Large for gen  |         +------------------+    +------------------+   |
|  +------------------+                                                        |
|                                                                              |
+==============================================================================+
```

---

## Pattern 1: Parent Document Retriever

### The Problem with Fixed Chunk Sizes

```
SMALL CHUNKS:                      LARGE CHUNKS:
+--------+                         +------------------------+
| Chunk  | Precise retrieval       | Large Chunk            | Better context
+--------+ but loses context       |                        | but imprecise
+--------+                         |                        | retrieval
| Chunk  |                         |                        |
+--------+                         +------------------------+
```

### Parent Document Retriever Solution

```
                    PARENT DOCUMENT RETRIEVER

+============================================================================+
|                                                                            |
|  Original Document (Parent)                                                |
|  +----------------------------------------------------------------------+ |
|  | "LangChain is a framework for developing applications powered by     | |
|  |  language models. It provides tools for prompt management, chains,   | |
|  |  agents, and memory. The framework supports multiple LLM providers   | |
|  |  including OpenAI, Anthropic, and local models..."                   | |
|  +----------------------------------------------------------------------+ |
|       |                                                                    |
|       | Split into small chunks for retrieval                              |
|       v                                                                    |
|  +----------------+  +----------------+  +----------------+                |
|  | Child Chunk 1  |  | Child Chunk 2  |  | Child Chunk 3  |                |
|  | "LangChain is  |  | "tools for     |  | "supports      |                |
|  |  a framework"  |  |  prompt mgmt"  |  |  multiple LLM" |                |
|  +----------------+  +----------------+  +----------------+                |
|       |                    |                    |                          |
|       v                    v                    v                          |
|  [Embedded]           [Embedded]           [Embedded]                      |
|                                                                            |
|  RETRIEVAL FLOW:                                                           |
|  Query: "What LLM providers does LangChain support?"                       |
|       |                                                                    |
|       v                                                                    |
|  Match: Child Chunk 3 (highest similarity)                                 |
|       |                                                                    |
|       v                                                                    |
|  Return: Full Parent Document (complete context!)                          |
|                                                                            |
+============================================================================+
```

### Implementation

```python
from langchain.retrievers import ParentDocumentRetriever
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import Chroma
from langchain.storage import InMemoryStore
from langchain_openai import OpenAIEmbeddings


def create_parent_document_retriever(documents: list):
    """Create a parent document retriever."""
    
    # Child splitter: small chunks for precise retrieval
    child_splitter = RecursiveCharacterTextSplitter(
        chunk_size=400,
        chunk_overlap=50
    )
    
    # Parent splitter: larger chunks for context
    # If not specified, returns full documents
    parent_splitter = RecursiveCharacterTextSplitter(
        chunk_size=2000,
        chunk_overlap=200
    )
    
    # Vector store for child chunks
    vectorstore = Chroma(
        collection_name="child_chunks",
        embedding_function=OpenAIEmbeddings()
    )
    
    # Document store for parent chunks
    docstore = InMemoryStore()
    
    # Create retriever
    retriever = ParentDocumentRetriever(
        vectorstore=vectorstore,
        docstore=docstore,
        child_splitter=child_splitter,
        parent_splitter=parent_splitter,
    )
    
    # Add documents
    retriever.add_documents(documents)
    
    return retriever


# Usage
from langchain_community.document_loaders import WebBaseLoader

loader = WebBaseLoader("https://docs.langchain.com/docs/")
docs = loader.load()

retriever = create_parent_document_retriever(docs)

# Query - retrieves small chunk, returns large parent
results = retriever.invoke("What is LangChain?")
print(f"Retrieved {len(results)} parent documents")
for doc in results:
    print(f"Content length: {len(doc.page_content)} characters")
```

### When to Use Parent Document Retriever

```
+==============================================================================+
|                    PARENT DOCUMENT RETRIEVER USE CASES                       |
+==============================================================================+
| Use When                          | Don't Use When                           |
+===================================+==========================================+
| Documents have complex structure  | Documents are already small              |
| Context is important for answers  | Precise, atomic answers needed           |
| FAQ/documentation Q&A             | Simple factoid retrieval                 |
| Legal/policy documents            | Real-time, low-latency requirements      |
| Research papers with arguments    | Memory-constrained environments          |
+==============================================================================+
```

---

## Pattern 2: HyDE (Hypothetical Document Embeddings)

### The Vocabulary Mismatch Problem

```
PROBLEM: Query and document use different vocabulary

User Query: "How do I take time off?"
    |
    v
Embedding: [0.12, -0.34, 0.56, ...]

Documents in Vector Store:
- "PTO Policy Guidelines" --> [0.45, -0.12, 0.23, ...]  (low similarity!)
- "Leave of Absence Procedures" --> [0.38, -0.18, 0.29, ...]
- "Vacation Request Form" --> [0.52, -0.21, 0.31, ...]

Result: Poor retrieval due to vocabulary mismatch
```

### HyDE Solution

```
                           HyDE WORKFLOW

+============================================================================+
|                                                                            |
|  User Query: "How do I take time off?"                                     |
|       |                                                                    |
|       v                                                                    |
|  +------------------------------------------------------------------+     |
|  |                     LLM Generation                                |     |
|  |  "Generate a hypothetical document that would answer this query"  |     |
|  +------------------------------------------------------------------+     |
|       |                                                                    |
|       v                                                                    |
|  Hypothetical Document:                                                    |
|  "To request time off, employees should submit a PTO request through      |
|   the HR portal at least two weeks in advance. The request will be        |
|   reviewed by your manager. Vacation days are accrued at a rate of..."    |
|       |                                                                    |
|       v                                                                    |
|  Embedding: [0.48, -0.15, 0.27, ...]  <-- Much closer to actual docs!     |
|       |                                                                    |
|       v                                                                    |
|  Retrieve documents similar to the hypothetical document                   |
|       |                                                                    |
|       v                                                                    |
|  Actual Documents Retrieved:                                               |
|  - "PTO Policy Guidelines"                                                 |
|  - "Vacation Request Form"                                                 |
|                                                                            |
+============================================================================+
```

### Implementation

```python
from langchain.chains import HypotheticalDocumentEmbedder
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate


def create_hyde_embeddings():
    """Create HyDE embeddings."""
    
    # Base embeddings
    base_embeddings = OpenAIEmbeddings(model="text-embedding-3-small")
    
    # LLM for generating hypothetical documents
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    
    # Create HyDE embeddings
    hyde_embeddings = HypotheticalDocumentEmbedder.from_llm(
        llm=llm,
        base_embeddings=base_embeddings,
        prompt_key="web_search"  # Built-in prompt for web-style answers
    )
    
    return hyde_embeddings


# Custom HyDE with specific prompt
def create_custom_hyde_embeddings(domain: str = "technical documentation"):
    """Create HyDE with custom prompt for specific domain."""
    
    from langchain_core.runnables import RunnablePassthrough, RunnableLambda
    
    base_embeddings = OpenAIEmbeddings(model="text-embedding-3-small")
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    
    # Custom prompt for domain-specific hypothetical documents
    hyde_prompt = ChatPromptTemplate.from_template("""
You are an expert in {domain}. 
Given the question below, write a detailed passage that would answer it.
The passage should be written as if it were extracted from official documentation.

Question: {question}

Passage:
""")
    
    def generate_hypothetical_doc(query: str) -> str:
        """Generate a hypothetical document for the query."""
        response = llm.invoke(
            hyde_prompt.format(domain=domain, question=query)
        )
        return response.content
    
    def embed_with_hyde(query: str) -> list:
        """Embed using HyDE."""
        hypothetical_doc = generate_hypothetical_doc(query)
        return base_embeddings.embed_query(hypothetical_doc)
    
    return embed_with_hyde


# Usage with vector store
from langchain_community.vectorstores import FAISS

# Create vector store with regular embeddings
embeddings = OpenAIEmbeddings(model="text-embedding-3-small")
vectorstore = FAISS.from_documents(documents, embeddings)

# Create HyDE embeddings for querying
hyde_embed = create_custom_hyde_embeddings("HR policies")

# Manual HyDE retrieval
def hyde_retrieve(query: str, k: int = 4):
    """Retrieve using HyDE."""
    hyde_vector = hyde_embed(query)
    results = vectorstore.similarity_search_by_vector(hyde_vector, k=k)
    return results

results = hyde_retrieve("How do I take time off?")
```

### HyDE Considerations

```
+==============================================================================+
|                           HyDE TRADE-OFFS                                    |
+==============================================================================+
| Advantages                         | Disadvantages                           |
+====================================+=========================================+
| Better vocabulary matching         | Adds LLM call latency                   |
| Works well for complex queries     | Increased cost (LLM + embedding)        |
| Improves recall significantly      | Hypothetical doc may be inaccurate      |
| No training required               | Not suitable for real-time apps         |
+------------------------------------+-----------------------------------------+
| BEST FOR:                          | AVOID FOR:                              |
| - Abstract queries                 | - Simple factoid queries                |
| - Domain-specific terminology      | - Low-latency requirements              |
| - When recall is critical          | - High-volume applications              |
+==============================================================================+
```

---

## Pattern 3: Query Transformation

### Multi-Query Retrieval

```
                    MULTI-QUERY RETRIEVAL

Original Query: "What are the benefits of using LangChain?"
       |
       v
+------------------------------------------------------------------+
|                     LLM Query Generator                           |
|  "Generate 3 different versions of this question"                 |
+------------------------------------------------------------------+
       |
       v
Generated Queries:
1. "What advantages does LangChain provide for LLM development?"
2. "Why should developers choose LangChain framework?"
3. "What problems does LangChain solve?"
       |
       +---> Retrieve docs for Query 1 --> [Doc A, Doc B]
       |
       +---> Retrieve docs for Query 2 --> [Doc C, Doc D]
       |
       +---> Retrieve docs for Query 3 --> [Doc B, Doc E]
       |
       v
Merge & Deduplicate: [Doc A, Doc B, Doc C, Doc D, Doc E]
```

### Implementation

```python
from langchain.retrievers.multi_query import MultiQueryRetriever
from langchain_openai import ChatOpenAI
from langchain_community.vectorstores import FAISS


def create_multi_query_retriever(vectorstore):
    """Create a multi-query retriever."""
    
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    
    retriever = MultiQueryRetriever.from_llm(
        retriever=vectorstore.as_retriever(search_kwargs={"k": 3}),
        llm=llm
    )
    
    return retriever


# Custom multi-query with logging
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import LineListOutputParser
import logging

logging.basicConfig(level=logging.INFO)


def create_custom_multi_query_retriever(vectorstore):
    """Multi-query retriever with custom prompt."""
    
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    
    # Custom prompt for query generation
    query_prompt = ChatPromptTemplate.from_template("""
You are an AI assistant helping to improve document retrieval.
Given the user question below, generate 3 different versions that capture 
different aspects or phrasings of the same question.

Each version should:
1. Use different vocabulary
2. Approach the question from a different angle
3. Be specific enough for good retrieval

Original question: {question}

Generate 3 alternative questions, one per line:
""")
    
    # Parser to split output into list
    output_parser = LineListOutputParser()
    
    # Chain to generate queries
    query_chain = query_prompt | llm | output_parser
    
    def get_relevant_docs(query: str):
        """Retrieve docs using multiple query variants."""
        # Generate query variants
        queries = query_chain.invoke({"question": query})
        queries = [query] + queries[:3]  # Original + 3 variants
        
        logging.info(f"Generated queries: {queries}")
        
        # Retrieve for each query
        all_docs = []
        seen_contents = set()
        
        for q in queries:
            docs = vectorstore.similarity_search(q, k=3)
            for doc in docs:
                if doc.page_content not in seen_contents:
                    all_docs.append(doc)
                    seen_contents.add(doc.page_content)
        
        return all_docs[:6]  # Return top 6 unique docs
    
    return get_relevant_docs


# Usage
retriever = create_multi_query_retriever(vectorstore)
docs = retriever.invoke("What are the benefits of LangChain?")
```

### Step-Back Prompting

```
                    STEP-BACK PROMPTING

Specific Query: "What was the GDP of France in Q2 2024?"
       |
       v
+------------------------------------------------------------------+
|                     Step-Back Generator                           |
|  "What is a more general question that would help answer this?"   |
+------------------------------------------------------------------+
       |
       v
Step-Back Query: "What are France's economic indicators and GDP trends?"
       |
       +---> Retrieve broader context about French economy
       |
       v
Combined Context: General economic context + Specific data
       |
       v
Better Answer: More informed, contextualized response
```

### Implementation

```python
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough, RunnableParallel


def create_step_back_chain(vectorstore):
    """Create a step-back prompting chain."""
    
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    retriever = vectorstore.as_retriever(search_kwargs={"k": 4})
    
    # Step-back prompt
    step_back_prompt = ChatPromptTemplate.from_template("""
You are an expert at generating abstract, higher-level questions.
Given the specific question below, generate a more general "step-back" question 
that would provide useful background context for answering the original question.

Original question: {question}

Step-back question:
""")
    
    # Generate step-back question
    step_back_chain = step_back_prompt | llm | StrOutputParser()
    
    # Final answer prompt
    answer_prompt = ChatPromptTemplate.from_template("""
You are an expert assistant. Use the following context to answer the question.
The context includes both general background information and specific details.

General Background Context:
{step_back_context}

Specific Context:
{specific_context}

Question: {question}

Answer:
""")
    
    def format_docs(docs):
        return "\n\n".join(doc.page_content for doc in docs)
    
    # Full chain
    chain = (
        {
            "question": RunnablePassthrough(),
            "step_back_question": step_back_chain,
        }
        | RunnableParallel(
            question=lambda x: x["question"],
            step_back_context=lambda x: format_docs(retriever.invoke(x["step_back_question"])),
            specific_context=lambda x: format_docs(retriever.invoke(x["question"])),
        )
        | answer_prompt
        | llm
        | StrOutputParser()
    )
    
    return chain


# Usage
chain = create_step_back_chain(vectorstore)
answer = chain.invoke("What was Apple's revenue in Q3 2024?")
```

### Query Decomposition

```
                    QUERY DECOMPOSITION

Complex Query: "Compare LangChain and LlamaIndex for building RAG applications"
       |
       v
+------------------------------------------------------------------+
|                     Query Decomposer                              |
|  "Break this into simpler sub-questions"                          |
+------------------------------------------------------------------+
       |
       v
Sub-questions:
1. "What is LangChain and its key features for RAG?"
2. "What is LlamaIndex and its key features for RAG?"
3. "What are the differences between LangChain and LlamaIndex?"
       |
       +---> Answer sub-question 1 --> "LangChain is..."
       +---> Answer sub-question 2 --> "LlamaIndex is..."
       +---> Answer sub-question 3 --> "Key differences include..."
       |
       v
Synthesize: Combine answers into comprehensive comparison
```

### Implementation

```python
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI
from langchain_core.output_parsers import StrOutputParser
import json


def create_query_decomposition_chain(vectorstore):
    """Create a query decomposition chain."""
    
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    retriever = vectorstore.as_retriever(search_kwargs={"k": 3})
    
    # Decomposition prompt
    decompose_prompt = ChatPromptTemplate.from_template("""
You are an expert at breaking down complex questions into simpler sub-questions.

Given the complex question below, decompose it into 2-4 simpler sub-questions
that, when answered together, would provide a complete answer to the original.

Return the sub-questions as a JSON array of strings.

Complex question: {question}

Sub-questions (JSON array):
""")
    
    # Sub-question answering prompt
    subq_prompt = ChatPromptTemplate.from_template("""
Answer the following question based on the context provided.

Context:
{context}

Question: {question}

Answer:
""")
    
    # Synthesis prompt
    synthesis_prompt = ChatPromptTemplate.from_template("""
You have answered several sub-questions to address a complex question.
Synthesize these answers into a comprehensive response.

Original Question: {original_question}

Sub-questions and Answers:
{sub_answers}

Comprehensive Answer:
""")
    
    def format_docs(docs):
        return "\n\n".join(doc.page_content for doc in docs)
    
    def decompose_and_answer(question: str) -> str:
        """Decompose question, answer parts, and synthesize."""
        
        # Step 1: Decompose
        decomposition = llm.invoke(
            decompose_prompt.format(question=question)
        ).content
        
        try:
            sub_questions = json.loads(decomposition)
        except json.JSONDecodeError:
            # Fallback: treat as single question
            sub_questions = [question]
        
        # Step 2: Answer each sub-question
        sub_answers = []
        for sq in sub_questions:
            docs = retriever.invoke(sq)
            context = format_docs(docs)
            answer = llm.invoke(
                subq_prompt.format(context=context, question=sq)
            ).content
            sub_answers.append(f"Q: {sq}\nA: {answer}")
        
        # Step 3: Synthesize
        combined_answers = "\n\n".join(sub_answers)
        final_answer = llm.invoke(
            synthesis_prompt.format(
                original_question=question,
                sub_answers=combined_answers
            )
        ).content
        
        return final_answer
    
    return decompose_and_answer


# Usage
decompose_chain = create_query_decomposition_chain(vectorstore)
answer = decompose_chain("Compare LangChain and LlamaIndex for RAG")
```

---

## Pattern 4: Reranking

### Why Reranking?

```
                    RERANKING PIPELINE

Initial Retrieval (fast but imprecise):
Query --> Vector Search --> [Doc1, Doc2, Doc3, Doc4, Doc5, ...]
                                 |
                                 v
                     (may have irrelevant docs)

Reranking (slower but precise):
[Doc1, Doc2, Doc3, Doc4, Doc5] --> Cross-Encoder --> [Doc3, Doc1, Doc5, Doc2, Doc4]
                                        |
                                        v
                            (reordered by relevance)

Final Selection:
Top-k after reranking --> [Doc3, Doc1, Doc5] --> LLM
```

### Implementation

```python
from langchain.retrievers import ContextualCompressionRetriever
from langchain.retrievers.document_compressors import CrossEncoderReranker
from langchain_community.cross_encoders import HuggingFaceCrossEncoder


def create_reranking_retriever(vectorstore, top_n: int = 4):
    """Create a retriever with cross-encoder reranking."""
    
    # Base retriever - retrieve more docs than needed
    base_retriever = vectorstore.as_retriever(
        search_kwargs={"k": 20}  # Fetch many candidates
    )
    
    # Cross-encoder model for reranking
    model = HuggingFaceCrossEncoder(model_name="cross-encoder/ms-marco-MiniLM-L-6-v2")
    
    # Reranker compressor
    compressor = CrossEncoderReranker(
        model=model,
        top_n=top_n  # Return top N after reranking
    )
    
    # Contextual compression retriever
    reranking_retriever = ContextualCompressionRetriever(
        base_compressor=compressor,
        base_retriever=base_retriever
    )
    
    return reranking_retriever


# LLM-based reranking (more expensive but potentially better)
from langchain.retrievers.document_compressors import LLMChainFilter
from langchain_openai import ChatOpenAI


def create_llm_reranking_retriever(vectorstore, top_n: int = 4):
    """Create a retriever with LLM-based reranking."""
    
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    
    base_retriever = vectorstore.as_retriever(search_kwargs={"k": 10})
    
    # LLM filter - filters out irrelevant docs
    compressor = LLMChainFilter.from_llm(llm)
    
    compression_retriever = ContextualCompressionRetriever(
        base_compressor=compressor,
        base_retriever=base_retriever
    )
    
    return compression_retriever


# Usage
retriever = create_reranking_retriever(vectorstore, top_n=4)
docs = retriever.invoke("What is LangChain?")
```

### Two-Stage Reranking

```python
def create_two_stage_reranker(vectorstore):
    """Two-stage reranking for better latency/quality tradeoff."""
    
    # Stage 1: Fast, lightweight reranker
    fast_model = HuggingFaceCrossEncoder(
        model_name="cross-encoder/ms-marco-TinyBERT-L-2-v2"
    )
    
    # Stage 2: Slower, more accurate reranker
    accurate_model = HuggingFaceCrossEncoder(
        model_name="cross-encoder/ms-marco-MiniLM-L-12-v2"
    )
    
    base_retriever = vectorstore.as_retriever(search_kwargs={"k": 50})
    
    def two_stage_retrieve(query: str, final_k: int = 4):
        """Retrieve with two-stage reranking."""
        
        # Initial retrieval
        docs = base_retriever.invoke(query)
        
        # Stage 1: Fast rerank to top 15
        scores_1 = fast_model.score([(query, doc.page_content) for doc in docs])
        ranked_1 = sorted(zip(docs, scores_1), key=lambda x: x[1], reverse=True)[:15]
        
        # Stage 2: Accurate rerank to final_k
        docs_stage2 = [doc for doc, _ in ranked_1]
        scores_2 = accurate_model.score([(query, doc.page_content) for doc in docs_stage2])
        ranked_2 = sorted(zip(docs_stage2, scores_2), key=lambda x: x[1], reverse=True)[:final_k]
        
        return [doc for doc, _ in ranked_2]
    
    return two_stage_retrieve
```

---

## Pattern 5: Hybrid Search

### Combining Semantic and Keyword Search

```
                    HYBRID SEARCH ARCHITECTURE

Query: "langchain python tutorial"
       |
       +------------------+------------------+
       |                                     |
       v                                     v
+----------------+                  +----------------+
| Semantic       |                  | Keyword        |
| Search         |                  | Search (BM25)  |
+----------------+                  +----------------+
| Uses embeddings|                  | Uses TF-IDF    |
| Good for:      |                  | Good for:      |
| - Concepts     |                  | - Exact terms  |
| - Synonyms     |                  | - Names        |
| - Context      |                  | - Codes        |
+----------------+                  +----------------+
       |                                     |
       v                                     v
[Doc2, Doc5, Doc1]              [Doc1, Doc3, Doc7]
       |                                     |
       +------------------+------------------+
                          |
                          v
              +----------------------+
              | Reciprocal Rank      |
              | Fusion (RRF)         |
              +----------------------+
                          |
                          v
              [Doc1, Doc2, Doc5, Doc3, Doc7]
              (Combined, deduplicated, ranked)
```

### Implementation

```python
from langchain.retrievers import EnsembleRetriever
from langchain_community.retrievers import BM25Retriever
from langchain_community.vectorstores import FAISS
from langchain_openai import OpenAIEmbeddings


def create_hybrid_retriever(documents: list, k: int = 4):
    """Create a hybrid retriever combining semantic and keyword search."""
    
    # Semantic retriever (vector-based)
    embeddings = OpenAIEmbeddings(model="text-embedding-3-small")
    vectorstore = FAISS.from_documents(documents, embeddings)
    semantic_retriever = vectorstore.as_retriever(search_kwargs={"k": k})
    
    # Keyword retriever (BM25)
    bm25_retriever = BM25Retriever.from_documents(documents)
    bm25_retriever.k = k
    
    # Ensemble with equal weights
    ensemble_retriever = EnsembleRetriever(
        retrievers=[semantic_retriever, bm25_retriever],
        weights=[0.5, 0.5]  # Equal importance
    )
    
    return ensemble_retriever


# Weighted hybrid based on query type
def create_adaptive_hybrid_retriever(documents: list):
    """Hybrid retriever that adapts weights based on query."""
    
    embeddings = OpenAIEmbeddings(model="text-embedding-3-small")
    vectorstore = FAISS.from_documents(documents, embeddings)
    
    bm25_retriever = BM25Retriever.from_documents(documents)
    bm25_retriever.k = 6
    
    def classify_query(query: str) -> tuple:
        """Classify query and return weights."""
        # Simple heuristics (could use LLM for better classification)
        query_lower = query.lower()
        
        # Technical/exact terms -> favor keyword search
        if any(term in query_lower for term in ['error', 'exception', 'version', 'api']):
            return (0.3, 0.7)  # More keyword
        
        # Conceptual questions -> favor semantic search
        if any(term in query_lower for term in ['how', 'why', 'explain', 'difference']):
            return (0.7, 0.3)  # More semantic
        
        # Default: balanced
        return (0.5, 0.5)
    
    def adaptive_retrieve(query: str, k: int = 4):
        """Retrieve with adaptive weights."""
        semantic_weight, keyword_weight = classify_query(query)
        
        semantic_docs = vectorstore.similarity_search(query, k=k)
        keyword_docs = bm25_retriever.invoke(query)
        
        # Simple RRF-style fusion
        doc_scores = {}
        
        for i, doc in enumerate(semantic_docs):
            score = semantic_weight / (i + 1)
            doc_scores[doc.page_content] = doc_scores.get(doc.page_content, 0) + score
        
        for i, doc in enumerate(keyword_docs):
            score = keyword_weight / (i + 1)
            doc_scores[doc.page_content] = doc_scores.get(doc.page_content, 0) + score
        
        # Sort by combined score
        all_docs = semantic_docs + keyword_docs
        unique_docs = {doc.page_content: doc for doc in all_docs}
        sorted_docs = sorted(
            unique_docs.values(),
            key=lambda d: doc_scores.get(d.page_content, 0),
            reverse=True
        )
        
        return sorted_docs[:k]
    
    return adaptive_retrieve


# Usage
hybrid_retriever = create_hybrid_retriever(documents, k=4)
docs = hybrid_retriever.invoke("langchain python tutorial")
```

---

## Pattern Comparison and Selection Guide

```
+==============================================================================+
|                    ADVANCED RAG PATTERN SELECTION GUIDE                      |
+==============================================================================+
| Pattern                  | Use When                    | Latency | Cost      |
+==========================+=============================+=========+===========+
| Parent Document          | Need full context for       | Low     | Low       |
|                          | generation, docs are long   |         |           |
+--------------------------+-----------------------------+---------+-----------+
| HyDE                     | Vocabulary mismatch,        | High    | Medium    |
|                          | abstract queries            |         |           |
+--------------------------+-----------------------------+---------+-----------+
| Multi-Query              | Improve recall, queries     | Medium  | Medium    |
|                          | have multiple aspects       |         |           |
+--------------------------+-----------------------------+---------+-----------+
| Step-Back Prompting      | Complex questions needing   | High    | Medium    |
|                          | background context          |         |           |
+--------------------------+-----------------------------+---------+-----------+
| Query Decomposition      | Multi-part questions,       | High    | High      |
|                          | comparisons                 |         |           |
+--------------------------+-----------------------------+---------+-----------+
| Reranking                | Precision critical,         | Medium  | Low-Med   |
|                          | can afford extra latency    |         |           |
+--------------------------+-----------------------------+---------+-----------+
| Hybrid Search            | Mixed query types,          | Low     | Low       |
|                          | exact + semantic matching   |         |           |
+==========================+=============================+=========+===========+

COMBINATION RECOMMENDATIONS:
- High Quality: HyDE + Reranking
- Balanced: Multi-Query + Hybrid + Reranking  
- Low Latency: Parent Document + Hybrid
- Complex Queries: Query Decomposition + Reranking
```

---

## Summary

Advanced RAG patterns address the limitations of naive RAG:

1. **Parent Document Retriever**: Small chunks for retrieval, large chunks for context
2. **HyDE**: Generate hypothetical documents to bridge vocabulary gap
3. **Query Transformation**: Multi-query, step-back, decomposition for better recall
4. **Reranking**: Cross-encoder or LLM-based precision improvement
5. **Hybrid Search**: Combine semantic and keyword search for robustness

Choose patterns based on your specific requirements for latency, cost, and quality.

---

## References

- [RAG Is Not Dead: Advanced Retrieval Patterns 2026](https://dev.to/young_gao/rag-is-not-dead-advanced-retrieval-patterns-that-actually-work-in-2026-2gbo)
- [Query Transformation: HyDE](https://theneuralbase.com/rag-fundamentals/learn/intermediate/query-transformation-hyde/)
- [H-RAG: Hierarchical Parent-Child Retrieval](https://arxiv.org/pdf/2605.00631)
- [RAG Query Augmentation](https://apxml.com/courses/optimizing-rag-for-production/chapter-2-advanced-retrieval-optimization/query-augmentation-rag)
