# Module 13.2: Building a Basic RAG Pipeline

## Overview

This module provides a step-by-step guide to building a RAG (Retrieval-Augmented Generation) pipeline using LangChain. We'll cover each component in detail with practical code examples.

---

## RAG Pipeline Architecture

```
                    BASIC RAG PIPELINE FLOW
+============================================================================+
|                                                                            |
|  STEP 1: LOAD          STEP 2: SPLIT         STEP 3: EMBED                |
|  +-----------+         +-----------+         +-----------+                |
|  | Documents | ------> |  Chunks   | ------> |  Vectors  |                |
|  +-----------+         +-----------+         +-----------+                |
|       |                      |                     |                       |
|       v                      v                     v                       |
|  [PDF, Web,           [500 char chunks      [1536-dim vectors             |
|   TXT files]           with overlap]         per chunk]                   |
|                                                    |                       |
|                                                    v                       |
|  STEP 4: STORE                                                            |
|  +------------------+                                                     |
|  |   Vector Store   | <-- Store embeddings + metadata                     |
|  | (FAISS/Chroma)   |                                                     |
|  +--------+---------+                                                     |
|           |                                                               |
|  =========|============= INDEXING COMPLETE ===============================|
|           |                                                               |
|  STEP 5: RETRIEVE      STEP 6: GENERATE                                   |
|  +-----------+         +-----------+         +-----------+                |
|  |   Query   | ------> | Retrieved | ------> |  Response |                |
|  +-----------+         |  Context  |         +-----------+                |
|                        +-----------+                                       |
|                                                                            |
+============================================================================+
```

---

## Step 1: Document Loading

### Understanding Document Loaders

Document loaders extract text content from various file formats and sources.

```python
from langchain_community.document_loaders import (
    PyPDFLoader,
    TextLoader,
    WebBaseLoader,
    DirectoryLoader,
    UnstructuredMarkdownLoader,
    CSVLoader,
)

# Load a single PDF
pdf_loader = PyPDFLoader("documents/report.pdf")
pdf_docs = pdf_loader.load()

# Load a text file
text_loader = TextLoader("documents/notes.txt")
text_docs = text_loader.load()

# Load from web URL
web_loader = WebBaseLoader("https://example.com/article")
web_docs = web_loader.load()

# Load entire directory
dir_loader = DirectoryLoader(
    "documents/",
    glob="**/*.txt",
    loader_cls=TextLoader
)
all_docs = dir_loader.load()
```

### Document Structure

```python
# Each loaded document has this structure
from langchain_core.documents import Document

doc = Document(
    page_content="The actual text content of the document...",
    metadata={
        "source": "documents/report.pdf",
        "page": 1,
        "total_pages": 10,
        # Additional metadata varies by loader
    }
)

# Access properties
print(doc.page_content)  # The text
print(doc.metadata)      # Source info
```

### Common Document Loaders

```
+==============================================================================+
|                        DOCUMENT LOADER REFERENCE                             |
+==============================================================================+
| Loader                    | Use Case              | Key Parameters           |
+===========================+=======================+==========================+
| PyPDFLoader               | PDF files             | file_path                |
| PDFPlumberLoader          | Complex PDFs          | file_path                |
| TextLoader                | Plain text            | file_path, encoding      |
| CSVLoader                 | CSV data              | file_path, csv_args      |
| UnstructuredMarkdownLoader| Markdown files        | file_path                |
| WebBaseLoader             | Web pages             | web_path                 |
| RecursiveUrlLoader        | Crawl websites        | url, max_depth           |
| GitLoader                 | Git repositories      | repo_path, branch        |
| NotionDBLoader            | Notion databases      | integration_token        |
| JSONLoader                | JSON files            | file_path, jq_schema     |
+==============================================================================+
```

### Best Practices for Loading

```python
import os
from langchain_community.document_loaders import (
    PyPDFLoader,
    TextLoader,
    DirectoryLoader,
)

def load_documents(source_path: str) -> list:
    """Load documents with proper error handling."""
    documents = []
    
    if os.path.isfile(source_path):
        # Single file
        if source_path.endswith('.pdf'):
            loader = PyPDFLoader(source_path)
        elif source_path.endswith('.txt'):
            loader = TextLoader(source_path, encoding='utf-8')
        else:
            raise ValueError(f"Unsupported file type: {source_path}")
        
        documents = loader.load()
    
    elif os.path.isdir(source_path):
        # Directory of files
        # Load PDFs
        pdf_loader = DirectoryLoader(
            source_path,
            glob="**/*.pdf",
            loader_cls=PyPDFLoader,
            show_progress=True
        )
        documents.extend(pdf_loader.load())
        
        # Load text files
        txt_loader = DirectoryLoader(
            source_path,
            glob="**/*.txt",
            loader_cls=TextLoader,
            show_progress=True
        )
        documents.extend(txt_loader.load())
    
    print(f"Loaded {len(documents)} documents")
    return documents
```

---

## Step 2: Text Splitting

### Why Split Documents?

```
PROBLEM: Documents are too large for embedding models and context windows

+------------------------------------------+
|          Original Document               |
|   (10,000+ tokens - too large!)          |
+------------------------------------------+
                    |
                    v
+----------+  +----------+  +----------+  +----------+
| Chunk 1  |  | Chunk 2  |  | Chunk 3  |  | Chunk N  |
| 500 tok  |  | 500 tok  |  | 500 tok  |  | 500 tok  |
+----------+  +----------+  +----------+  +----------+
     |             |             |             |
     v             v             v             v
 Embedded      Embedded      Embedded      Embedded
```

### Text Splitter Types

```python
from langchain_text_splitters import (
    RecursiveCharacterTextSplitter,
    CharacterTextSplitter,
    TokenTextSplitter,
    MarkdownHeaderTextSplitter,
    HTMLHeaderTextSplitter,
)

# 1. RecursiveCharacterTextSplitter (RECOMMENDED for most cases)
# Splits recursively using a hierarchy of separators
recursive_splitter = RecursiveCharacterTextSplitter(
    chunk_size=1000,           # Max characters per chunk
    chunk_overlap=200,         # Overlap between chunks
    length_function=len,       # How to measure length
    separators=["\n\n", "\n", " ", ""]  # Split hierarchy
)

# 2. CharacterTextSplitter
# Simple splitting by a single separator
char_splitter = CharacterTextSplitter(
    separator="\n\n",
    chunk_size=1000,
    chunk_overlap=200
)

# 3. TokenTextSplitter
# Split by token count (useful for strict token limits)
token_splitter = TokenTextSplitter(
    chunk_size=500,            # Max tokens per chunk
    chunk_overlap=50           # Token overlap
)

# 4. MarkdownHeaderTextSplitter
# Preserves markdown structure
md_splitter = MarkdownHeaderTextSplitter(
    headers_to_split_on=[
        ("#", "Header 1"),
        ("##", "Header 2"),
        ("###", "Header 3"),
    ]
)
```

### Chunking Strategies Visualized

```
              CHUNKING STRATEGY COMPARISON

Original Text:
"# Introduction
 This is the introduction paragraph about AI.
 
 ## Background  
 AI has evolved significantly over the years.
 Machine learning is a subset of AI.
 
 ## Applications
 AI is used in healthcare, finance, and more."

+==============================================================================+
| RecursiveCharacterTextSplitter (chunk_size=100, overlap=20)                 |
+------------------------------------------------------------------------------+
| Chunk 1: "# Introduction\nThis is the introduction paragraph about AI."     |
| Chunk 2: "about AI.\n\n## Background\nAI has evolved significantly..."      |
| Chunk 3: "significantly over the years.\nMachine learning is a subset..."   |
| Chunk 4: "subset of AI.\n\n## Applications\nAI is used in healthcare..."    |
+==============================================================================+

+==============================================================================+
| MarkdownHeaderTextSplitter                                                  |
+------------------------------------------------------------------------------+
| Chunk 1: "This is the introduction paragraph about AI."                     |
|          metadata: {"Header 1": "Introduction"}                             |
| Chunk 2: "AI has evolved significantly over the years..."                   |
|          metadata: {"Header 1": "Introduction", "Header 2": "Background"}   |
| Chunk 3: "AI is used in healthcare, finance, and more."                     |
|          metadata: {"Header 1": "Introduction", "Header 2": "Applications"} |
+==============================================================================+
```

### Optimal Chunk Size Guidelines

```
+==============================================================================+
|                    CHUNK SIZE RECOMMENDATIONS                                |
+==============================================================================+
| Use Case                  | Chunk Size    | Overlap  | Rationale            |
+===========================+===============+==========+======================+
| General Q&A               | 500-1000      | 100-200  | Balance context/     |
|                           |               |          | precision            |
| Technical documentation   | 1000-1500     | 200-300  | Preserve code blocks |
| Legal documents           | 500-800       | 100-150  | Precise citations    |
| Conversational/FAQ        | 200-500       | 50-100   | Short, focused       |
| Research papers           | 1000-2000     | 200-400  | Preserve arguments   |
+==============================================================================+

Rule of Thumb: 
- Chunk size: 10-20% of context window
- Overlap: 10-20% of chunk size
```

### Complete Splitting Example

```python
from langchain_text_splitters import RecursiveCharacterTextSplitter

def split_documents(documents: list, chunk_size: int = 1000, chunk_overlap: int = 200) -> list:
    """Split documents into chunks with metadata preservation."""
    
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        length_function=len,
        add_start_index=True,  # Track position in original doc
    )
    
    chunks = splitter.split_documents(documents)
    
    # Add chunk index to metadata
    for i, chunk in enumerate(chunks):
        chunk.metadata["chunk_index"] = i
    
    print(f"Split {len(documents)} documents into {len(chunks)} chunks")
    return chunks

# Usage
documents = load_documents("documents/")
chunks = split_documents(documents, chunk_size=1000, chunk_overlap=200)
```

---

## Step 3: Embedding

### Understanding Embeddings

```
                    EMBEDDING PROCESS

Text: "LangChain is a framework for building LLM applications"
                            |
                            v
                   +------------------+
                   | Embedding Model  |
                   | (e.g., OpenAI    |
                   |  text-embedding- |
                   |  3-small)        |
                   +------------------+
                            |
                            v
Vector: [0.023, -0.156, 0.089, ..., 0.045]  (1536 dimensions)

Similar texts --> Similar vectors --> Close in vector space
```

### Embedding Model Options

```python
# OpenAI Embeddings (most common)
from langchain_openai import OpenAIEmbeddings

openai_embeddings = OpenAIEmbeddings(
    model="text-embedding-3-small",  # or "text-embedding-3-large"
    # dimensions=1536,  # Optional: reduce dimensions
)

# HuggingFace Embeddings (open source)
from langchain_huggingface import HuggingFaceEmbeddings

hf_embeddings = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-MiniLM-L6-v2",
    model_kwargs={'device': 'cpu'},
    encode_kwargs={'normalize_embeddings': True}
)

# Cohere Embeddings
from langchain_cohere import CohereEmbeddings

cohere_embeddings = CohereEmbeddings(
    model="embed-english-v3.0",
    cohere_api_key="your-api-key"
)
```

### Embedding Model Comparison

```
+==============================================================================+
|                      EMBEDDING MODEL COMPARISON                              |
+==============================================================================+
| Model                          | Dimensions | Speed    | Quality  | Cost    |
+================================+============+==========+==========+=========+
| text-embedding-3-small         | 1536       | Fast     | Good     | Low     |
| text-embedding-3-large         | 3072       | Medium   | Best     | Medium  |
| all-MiniLM-L6-v2 (HuggingFace) | 384        | Very Fast| Good     | Free    |
| bge-large-en-v1.5              | 1024       | Medium   | Very Good| Free    |
| embed-english-v3.0 (Cohere)    | 1024       | Fast     | Very Good| Medium  |
+==============================================================================+
```

### Testing Embeddings

```python
from langchain_openai import OpenAIEmbeddings
import numpy as np

embeddings = OpenAIEmbeddings(model="text-embedding-3-small")

# Embed a single text
text = "LangChain is a framework for LLM applications"
vector = embeddings.embed_query(text)
print(f"Vector dimension: {len(vector)}")  # 1536

# Embed multiple texts (batch)
texts = [
    "LangChain helps build AI applications",
    "Python is a programming language",
    "LangChain simplifies LLM development"
]
vectors = embeddings.embed_documents(texts)

# Calculate similarity
def cosine_similarity(v1, v2):
    return np.dot(v1, v2) / (np.linalg.norm(v1) * np.linalg.norm(v2))

# Similar topics should have higher similarity
sim_0_2 = cosine_similarity(vectors[0], vectors[2])  # Both about LangChain
sim_0_1 = cosine_similarity(vectors[0], vectors[1])  # Different topics
print(f"LangChain texts similarity: {sim_0_2:.3f}")  # ~0.85
print(f"Different topics similarity: {sim_0_1:.3f}")  # ~0.65
```

---

## Step 4: Vector Store

### Creating a Vector Store

```python
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS, Chroma

# Initialize embeddings
embeddings = OpenAIEmbeddings(model="text-embedding-3-small")

# Option 1: FAISS (in-memory, fast)
vectorstore = FAISS.from_documents(
    documents=chunks,
    embedding=embeddings
)

# Option 2: Chroma (persistent, feature-rich)
vectorstore = Chroma.from_documents(
    documents=chunks,
    embedding=embeddings,
    persist_directory="./chroma_db"  # Persist to disk
)
```

### Vector Store Operations

```python
# Add more documents
new_chunks = [...]
vectorstore.add_documents(new_chunks)

# Similarity search
results = vectorstore.similarity_search(
    query="What is LangChain?",
    k=4  # Return top 4 results
)

# Similarity search with scores
results_with_scores = vectorstore.similarity_search_with_score(
    query="What is LangChain?",
    k=4
)
for doc, score in results_with_scores:
    print(f"Score: {score:.3f} | Content: {doc.page_content[:50]}...")

# Search with metadata filter
filtered_results = vectorstore.similarity_search(
    query="What is LangChain?",
    k=4,
    filter={"source": "docs/intro.pdf"}
)

# Save and load (FAISS)
vectorstore.save_local("faiss_index")
loaded_vectorstore = FAISS.load_local(
    "faiss_index",
    embeddings,
    allow_dangerous_deserialization=True
)
```

### Vector Store Comparison

```
+==============================================================================+
|                       VECTOR STORE COMPARISON                                |
+==============================================================================+
| Feature          | FAISS      | Chroma     | Pinecone   | Weaviate          |
+==================+============+============+============+===================+
| Type             | In-memory  | Embedded   | Cloud      | Cloud/Self-hosted |
| Persistence      | Manual     | Automatic  | Automatic  | Automatic         |
| Scalability      | Medium     | Medium     | High       | High              |
| Metadata Filter  | Limited    | Good       | Excellent  | Excellent         |
| Hybrid Search    | No         | No         | Yes        | Yes               |
| Setup Complexity | Low        | Low        | Medium     | Medium            |
| Cost             | Free       | Free       | Pay-per-use| Pay/Free tier     |
| Best For         | Prototypes | Development| Production | Production        |
+==============================================================================+
```

---

## Step 5: Retrieval

### Creating a Retriever

```python
# Basic retriever from vector store
retriever = vectorstore.as_retriever(
    search_type="similarity",  # or "mmr", "similarity_score_threshold"
    search_kwargs={
        "k": 4,  # Number of documents to retrieve
    }
)

# Retrieve documents
docs = retriever.invoke("What is LangChain?")
for doc in docs:
    print(doc.page_content[:100])
```

### Retrieval Strategies

```
                    RETRIEVAL STRATEGIES

1. SIMILARITY SEARCH (Default)
   - Returns k most similar documents
   - Fast and simple
   
   Query --> [Doc1, Doc2, Doc3, Doc4]  (by similarity score)

2. MMR (Maximum Marginal Relevance)
   - Balances relevance with diversity
   - Avoids redundant results
   
   Query --> [Doc1, Doc5, Doc8, Doc3]  (diverse + relevant)

3. SIMILARITY SCORE THRESHOLD
   - Only returns docs above a threshold
   - Useful when quality matters more than quantity
   
   Query --> [Doc1, Doc2]  (only if score > 0.8)
```

```python
# MMR Retriever (diversity + relevance)
mmr_retriever = vectorstore.as_retriever(
    search_type="mmr",
    search_kwargs={
        "k": 4,
        "fetch_k": 20,      # Fetch more, then select diverse subset
        "lambda_mult": 0.5  # 0 = max diversity, 1 = max relevance
    }
)

# Score threshold retriever
threshold_retriever = vectorstore.as_retriever(
    search_type="similarity_score_threshold",
    search_kwargs={
        "score_threshold": 0.7,  # Minimum similarity score
        "k": 10                   # Max documents
    }
)
```

### Advanced Retrievers

```python
from langchain.retrievers import (
    ContextualCompressionRetriever,
    MultiQueryRetriever,
    EnsembleRetriever,
)
from langchain.retrievers.document_compressors import LLMChainExtractor
from langchain_community.retrievers import BM25Retriever
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(model="gpt-4o-mini")

# 1. Multi-Query Retriever
# Generates multiple query variations for better recall
multi_query_retriever = MultiQueryRetriever.from_llm(
    retriever=vectorstore.as_retriever(),
    llm=llm
)

# 2. Contextual Compression
# Compresses retrieved docs to only relevant parts
compressor = LLMChainExtractor.from_llm(llm)
compression_retriever = ContextualCompressionRetriever(
    base_compressor=compressor,
    base_retriever=vectorstore.as_retriever()
)

# 3. Ensemble Retriever (Hybrid Search)
# Combines semantic search with keyword search
bm25_retriever = BM25Retriever.from_documents(chunks)
bm25_retriever.k = 4

ensemble_retriever = EnsembleRetriever(
    retrievers=[vectorstore.as_retriever(), bm25_retriever],
    weights=[0.5, 0.5]  # Equal weights
)
```

---

## Step 6: Generation

### Building the RAG Chain

```python
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough

# Initialize LLM
llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)

# Create prompt template
prompt = ChatPromptTemplate.from_template("""
Answer the question based only on the following context. If you cannot answer 
the question based on the context, say "I don't have enough information to 
answer this question."

Context:
{context}

Question: {question}

Answer:
""")

# Helper function to format documents
def format_docs(docs):
    return "\n\n".join(doc.page_content for doc in docs)

# Build the RAG chain
rag_chain = (
    {
        "context": retriever | format_docs,
        "question": RunnablePassthrough()
    }
    | prompt
    | llm
    | StrOutputParser()
)

# Use the chain
response = rag_chain.invoke("What is LangChain?")
print(response)
```

### RAG Chain with Sources

```python
from langchain_core.runnables import RunnableParallel

# Chain that returns both answer and source documents
rag_chain_with_sources = RunnableParallel(
    {
        "context": retriever,
        "question": RunnablePassthrough()
    }
).assign(
    answer=lambda x: (
        prompt.format(context=format_docs(x["context"]), question=x["question"])
        | llm
        | StrOutputParser()
    ).invoke({})
)

# Get response with sources
result = rag_chain_with_sources.invoke("What is LangChain?")
print("Answer:", result["answer"])
print("\nSources:")
for doc in result["context"]:
    print(f"  - {doc.metadata.get('source', 'Unknown')}")
```

---

## Complete RAG Pipeline

### Putting It All Together

```python
"""
Complete Basic RAG Pipeline Implementation
"""

from langchain_community.document_loaders import PyPDFLoader, DirectoryLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain_community.vectorstores import FAISS
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough
import os


class BasicRAGPipeline:
    """A basic RAG pipeline for document Q&A."""
    
    def __init__(
        self,
        embedding_model: str = "text-embedding-3-small",
        llm_model: str = "gpt-4o-mini",
        chunk_size: int = 1000,
        chunk_overlap: int = 200,
    ):
        self.embeddings = OpenAIEmbeddings(model=embedding_model)
        self.llm = ChatOpenAI(model=llm_model, temperature=0)
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.vectorstore = None
        self.retriever = None
        self.rag_chain = None
    
    def load_documents(self, source_path: str) -> list:
        """Load documents from file or directory."""
        if os.path.isfile(source_path):
            if source_path.endswith('.pdf'):
                loader = PyPDFLoader(source_path)
            else:
                raise ValueError(f"Unsupported file type: {source_path}")
            documents = loader.load()
        elif os.path.isdir(source_path):
            loader = DirectoryLoader(
                source_path,
                glob="**/*.pdf",
                loader_cls=PyPDFLoader,
                show_progress=True
            )
            documents = loader.load()
        else:
            raise ValueError(f"Invalid path: {source_path}")
        
        print(f"Loaded {len(documents)} documents")
        return documents
    
    def split_documents(self, documents: list) -> list:
        """Split documents into chunks."""
        splitter = RecursiveCharacterTextSplitter(
            chunk_size=self.chunk_size,
            chunk_overlap=self.chunk_overlap,
            add_start_index=True
        )
        chunks = splitter.split_documents(documents)
        print(f"Created {len(chunks)} chunks")
        return chunks
    
    def create_vectorstore(self, chunks: list) -> None:
        """Create vector store from chunks."""
        self.vectorstore = FAISS.from_documents(
            documents=chunks,
            embedding=self.embeddings
        )
        print("Vector store created")
    
    def setup_retriever(self, k: int = 4) -> None:
        """Set up the retriever."""
        if self.vectorstore is None:
            raise ValueError("Vector store not initialized")
        
        self.retriever = self.vectorstore.as_retriever(
            search_type="similarity",
            search_kwargs={"k": k}
        )
    
    def build_chain(self) -> None:
        """Build the RAG chain."""
        prompt = ChatPromptTemplate.from_template("""
You are a helpful assistant that answers questions based on the provided context.

Instructions:
1. Answer the question using ONLY the information in the context
2. If the context doesn't contain the answer, say "I don't have enough information"
3. Be concise but thorough
4. If relevant, mention which part of the context supports your answer

Context:
{context}

Question: {question}

Answer:
""")
        
        def format_docs(docs):
            return "\n\n---\n\n".join(
                f"[Source: {doc.metadata.get('source', 'Unknown')}]\n{doc.page_content}"
                for doc in docs
            )
        
        self.rag_chain = (
            {
                "context": self.retriever | format_docs,
                "question": RunnablePassthrough()
            }
            | prompt
            | self.llm
            | StrOutputParser()
        )
    
    def index(self, source_path: str) -> None:
        """Full indexing pipeline."""
        documents = self.load_documents(source_path)
        chunks = self.split_documents(documents)
        self.create_vectorstore(chunks)
        self.setup_retriever()
        self.build_chain()
        print("Indexing complete!")
    
    def query(self, question: str) -> str:
        """Query the RAG system."""
        if self.rag_chain is None:
            raise ValueError("RAG chain not initialized. Run index() first.")
        return self.rag_chain.invoke(question)
    
    def save(self, path: str) -> None:
        """Save vector store to disk."""
        if self.vectorstore:
            self.vectorstore.save_local(path)
            print(f"Vector store saved to {path}")
    
    def load(self, path: str) -> None:
        """Load vector store from disk."""
        self.vectorstore = FAISS.load_local(
            path,
            self.embeddings,
            allow_dangerous_deserialization=True
        )
        self.setup_retriever()
        self.build_chain()
        print(f"Vector store loaded from {path}")


# Usage Example
if __name__ == "__main__":
    # Initialize pipeline
    rag = BasicRAGPipeline(
        embedding_model="text-embedding-3-small",
        llm_model="gpt-4o-mini",
        chunk_size=1000,
        chunk_overlap=200
    )
    
    # Index documents
    rag.index("documents/")
    
    # Query
    questions = [
        "What is the main topic of the documents?",
        "Can you summarize the key points?",
        "What are the conclusions?"
    ]
    
    for question in questions:
        print(f"\nQ: {question}")
        answer = rag.query(question)
        print(f"A: {answer}")
    
    # Save for later use
    rag.save("my_vectorstore")
```

---

## Best Practices Summary

### Indexing Phase

```
+==============================================================================+
|                       INDEXING BEST PRACTICES                                |
+==============================================================================+
| Step          | Best Practice                    | Why                       |
+===============+==================================+===========================+
| Loading       | Handle encoding errors           | Avoid corrupted data      |
|               | Preserve metadata                | Enable filtering later    |
|               | Use appropriate loaders          | Better text extraction    |
+---------------+----------------------------------+---------------------------+
| Splitting     | Use RecursiveCharacterSplitter   | Respects natural boundaries|
|               | Add overlap (10-20%)             | Preserve context at edges |
|               | Track chunk positions            | Enable source attribution |
+---------------+----------------------------------+---------------------------+
| Embedding     | Match model to use case          | Balance cost/quality      |
|               | Batch embed for efficiency       | Reduce API calls          |
|               | Normalize embeddings             | Consistent similarity     |
+---------------+----------------------------------+---------------------------+
| Storage       | Choose right vector store        | Match scale and features  |
|               | Persist to disk                  | Avoid re-indexing         |
|               | Add metadata indexes             | Enable filtering          |
+==============================================================================+
```

### Retrieval Phase

```
+==============================================================================+
|                       RETRIEVAL BEST PRACTICES                               |
+==============================================================================+
| Aspect        | Best Practice                    | Why                       |
+===============+==================================+===========================+
| k value       | Start with 3-5, tune based on    | Balance context/relevance |
|               | evaluation                       |                           |
+---------------+----------------------------------+---------------------------+
| Search type   | Use MMR for diverse results      | Avoid redundancy          |
|               | Use threshold for quality        | Filter low-quality matches|
+---------------+----------------------------------+---------------------------+
| Hybrid search | Combine semantic + keyword       | Handle exact matches      |
|               |                                  | and synonyms              |
+---------------+----------------------------------+---------------------------+
| Reranking     | Add cross-encoder reranker       | Improve precision         |
|               | for production                   |                           |
+==============================================================================+
```

---

## Summary

In this module, we covered:

1. **Document Loading**: Extracting text from various sources
2. **Text Splitting**: Breaking documents into optimal chunks
3. **Embedding**: Converting text to vector representations
4. **Vector Storage**: Storing and indexing embeddings
5. **Retrieval**: Finding relevant documents for queries
6. **Generation**: Producing answers using retrieved context

The basic RAG pipeline provides a foundation that can be extended with advanced patterns covered in the next module.

---

## References

- [LangChain RAG Tutorial](https://leanware.co/insights/langchain-rag-tutorial-build-retrieval-augmented-generation-from-scratch)
- [The Only RAG Tutorial You Need in 2026](https://shantun.medium.com/the-only-rag-tutorial-you-need-in-2026-document-loading-chunking-embeddings-retrieval-with-b313fdc473b8)
- [LangChain Documentation](https://docs.langchain.com/oss/python/langchain/rag)
