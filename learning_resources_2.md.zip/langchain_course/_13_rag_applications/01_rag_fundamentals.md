# Module 13.1: RAG Fundamentals

## Introduction to Retrieval-Augmented Generation (RAG)

Retrieval-Augmented Generation (RAG) is a hybrid AI architecture that combines the strengths of large language models (LLMs) with external knowledge retrieval. Instead of relying solely on a model's internal training data, RAG dynamically retrieves relevant documents from a knowledge base and incorporates them into the generation process.

## Why RAG Matters

### The Problem with Pure LLMs

```
+------------------+     +------------------+
|   User Query     | --> |      LLM         | --> Response (may hallucinate)
+------------------+     +------------------+
                              |
                              v
                    [Only trained knowledge]
                    [Outdated information]
                    [No private data access]
```

**Limitations of standalone LLMs:**
- Knowledge cutoff date (training data is static)
- Cannot access private/proprietary data
- Prone to hallucinations on domain-specific topics
- No way to cite sources
- Cannot be easily updated with new information

### The RAG Solution

```
+------------------+     +------------------+     +------------------+
|   User Query     | --> |    Retriever     | --> |  Relevant Docs   |
+------------------+     +------------------+     +------------------+
                                                          |
                                                          v
                         +------------------+     +------------------+
                         |    Response      | <-- |   LLM + Context  |
                         +------------------+     +------------------+
```

**RAG advantages:**
- Access to up-to-date information
- Grounded responses with citations
- Works with private/proprietary data
- Reduced hallucinations
- Easy to update knowledge base
- More cost-effective than fine-tuning

---

## RAG Architecture Overview

### End-to-End RAG Pipeline

```
                           RAG ARCHITECTURE DIAGRAM
+============================================================================+
|                                                                            |
|  +------------------+                                                      |
|  |   DATA SOURCES   |                                                      |
|  +------------------+                                                      |
|  | - PDFs           |                                                      |
|  | - Web Pages      |                                                      |
|  | - Databases      |                                                      |
|  | - APIs           |                                                      |
|  | - Documents      |                                                      |
|  +--------+---------+                                                      |
|           |                                                                |
|           v                                                                |
|  +------------------+     +------------------+     +------------------+    |
|  | Document Loader  | --> | Text Splitter    | --> | Embedding Model  |    |
|  +------------------+     +------------------+     +------------------+    |
|                                                           |                |
|                                                           v                |
|                                                  +------------------+      |
|                                                  |  Vector Store    |      |
|                                                  | (FAISS/Chroma/   |      |
|                                                  |  Pinecone)       |      |
|                                                  +--------+---------+      |
|                                                           |                |
|  INDEXING PHASE ==========================================|=============== |
|  RETRIEVAL PHASE =========================================|=============== |
|                                                           |                |
|  +------------------+                                     |                |
|  |   User Query     |                                     |                |
|  +--------+---------+                                     |                |
|           |                                               |                |
|           v                                               v                |
|  +------------------+     +------------------+     +------------------+    |
|  | Query Embedding  | --> |   Retriever      | --> | Relevant Chunks  |    |
|  +------------------+     +------------------+     +------------------+    |
|                                                           |                |
|                                                           v                |
|                           +------------------+     +------------------+    |
|                           |   LLM Response   | <-- | Prompt + Context |    |
|                           +------------------+     +------------------+    |
|                                                                            |
+============================================================================+
```

### Two Main Phases

#### 1. Indexing Phase (Offline)

```python
# Conceptual flow of indexing
documents = load_documents(source)           # Load raw documents
chunks = split_documents(documents)          # Split into chunks
embeddings = embed_chunks(chunks)            # Convert to vectors
vector_store.add(embeddings, chunks)         # Store in vector DB
```

**Steps:**
1. **Load**: Ingest documents from various sources (PDFs, web, databases)
2. **Split**: Break documents into smaller, manageable chunks
3. **Embed**: Convert text chunks into vector representations
4. **Store**: Save vectors in a vector database for efficient retrieval

#### 2. Retrieval Phase (Online)

```python
# Conceptual flow of retrieval
query_embedding = embed(user_query)          # Embed the query
relevant_docs = vector_store.search(         # Find similar docs
    query_embedding, k=5
)
context = format_context(relevant_docs)      # Format for prompt
response = llm.generate(query, context)      # Generate response
```

**Steps:**
1. **Query**: User submits a question
2. **Embed**: Convert query to vector representation
3. **Retrieve**: Find most similar document chunks
4. **Generate**: LLM produces answer using retrieved context

---

## When to Use RAG

### Ideal RAG Use Cases

```
+==============================================================================+
|                         RAG DECISION MATRIX                                  |
+==============================================================================+
| Use Case                    | RAG Fit | Why                                  |
+=============================+=========+======================================+
| Q&A over documents          |   +++   | Perfect for grounded responses       |
| Customer support chatbots   |   +++   | Access to product docs, FAQs         |
| Legal/compliance queries    |   +++   | Cite specific regulations            |
| Internal knowledge bases    |   +++   | Private company data                 |
| Research assistants         |   ++    | Search across papers/reports         |
| Code documentation Q&A      |   ++    | Navigate large codebases             |
| Real-time information       |   ++    | News, stock prices, weather          |
+-----------------------------+---------+--------------------------------------+
| Creative writing            |   -     | No external knowledge needed         |
| General chat                |   -     | LLM knowledge sufficient             |
| Math/reasoning              |   -     | Logic, not retrieval                 |
+==============================================================================+
```

### Decision Framework: When to Choose RAG

```
                    Should You Use RAG?
                           |
                           v
          +--------------------------------+
          | Does your use case require     |
          | access to specific documents   |
          | or private data?               |
          +----------------+---------------+
                           |
              +------------+------------+
              |                         |
             YES                        NO
              |                         |
              v                         v
   +--------------------+    +--------------------+
   | Is the information |    | Does the LLM need  |
   | too large for      |    | up-to-date info?   |
   | context window?    |    +----------+---------+
   +----------+---------+               |
              |                +--------+--------+
    +---------+---------+      |                 |
    |                   |     YES                NO
   YES                  NO     |                 |
    |                   |      v                 v
    v                   v    USE RAG      Consider:
  USE RAG         Consider:              - Fine-tuning
                  - Long context         - Prompt engineering
                  - Prompt stuffing      - Base LLM
```

### RAG vs Fine-Tuning vs Prompt Engineering

| Aspect | RAG | Fine-Tuning | Prompt Engineering |
|--------|-----|-------------|-------------------|
| **Cost** | Medium (embedding + retrieval) | High (training compute) | Low |
| **Update frequency** | Easy (update docs) | Hard (retrain) | Easy |
| **Data privacy** | Good (data stays local) | Risk (in model weights) | Good |
| **Hallucination control** | High (grounded) | Medium | Low |
| **Setup complexity** | Medium | High | Low |
| **Best for** | Knowledge-intensive tasks | Style/behavior changes | Simple tasks |

---

## Core RAG Components

### 1. Document Loaders

Document loaders extract text from various sources:

```
+------------------+     +------------------+
|   Data Sources   | --> | Document Loader  | --> Raw Text
+------------------+     +------------------+

Supported formats:
- PDF (PyPDFLoader, PDFPlumber)
- Web (WebBaseLoader, RecursiveUrlLoader)
- Office (Docx2txtLoader, UnstructuredExcelLoader)
- Code (TextLoader, NotebookLoader)
- Databases (SQLDatabaseLoader)
- APIs (GitHubLoader, NotionDBLoader)
```

### 2. Text Splitters

Text splitters divide documents into chunks:

```
                    CHUNKING STRATEGIES
+==============================================================+
|                                                              |
|  Original Document:                                          |
|  "The quick brown fox jumps over the lazy dog. The dog      |
|   was sleeping peacefully. Suddenly, the fox appeared..."    |
|                                                              |
|  +--------------------------------------------------------+  |
|  | Fixed-Size Chunking (chunk_size=50, overlap=10)        |  |
|  +--------------------------------------------------------+  |
|  | Chunk 1: "The quick brown fox jumps over the lazy dog" |  |
|  | Chunk 2: "lazy dog. The dog was sleeping peacefully"   |  |
|  | Chunk 3: "peacefully. Suddenly, the fox appeared..."   |  |
|  +--------------------------------------------------------+  |
|                                                              |
|  +--------------------------------------------------------+  |
|  | Semantic Chunking (by sentence)                        |  |
|  +--------------------------------------------------------+  |
|  | Chunk 1: "The quick brown fox jumps over the lazy dog."|  |
|  | Chunk 2: "The dog was sleeping peacefully."            |  |
|  | Chunk 3: "Suddenly, the fox appeared..."               |  |
|  +--------------------------------------------------------+  |
|                                                              |
+==============================================================+
```

**Common splitters:**
- `RecursiveCharacterTextSplitter` - Best general-purpose splitter
- `TokenTextSplitter` - Split by token count
- `MarkdownTextSplitter` - Respects markdown structure
- `HTMLHeaderTextSplitter` - Preserves HTML hierarchy
- `SemanticChunker` - Groups semantically similar content

### 3. Embedding Models

Embedding models convert text to vectors:

```
+------------------+     +------------------+     +------------------+
|   Text Chunk     | --> | Embedding Model  | --> |   Vector         |
| "LangChain is a" |     | (OpenAI/HuggingF)|     | [0.12, -0.34,    |
| "framework..."   |     +------------------+     |  0.56, ...]      |
+------------------+                              +------------------+
                                                  (1536 dimensions)
```

**Popular embedding models:**
- `OpenAIEmbeddings` - text-embedding-3-large/small
- `HuggingFaceEmbeddings` - Open-source options
- `CohereEmbeddings` - Cohere's embed models
- `GoogleGenerativeAIEmbeddings` - Google's models

### 4. Vector Stores

Vector stores enable efficient similarity search:

```
                    VECTOR STORE COMPARISON
+==============================================================+
| Store       | Type      | Best For           | Scalability   |
+=============+===========+====================+===============+
| FAISS       | Local     | Development, POCs  | Medium        |
| Chroma      | Local/    | Quick prototyping  | Medium        |
|             | Embedded  |                    |               |
| Pinecone    | Cloud     | Production apps    | High          |
| Weaviate    | Cloud/    | Hybrid search      | High          |
|             | Self-host |                    |               |
| Qdrant      | Cloud/    | High performance   | High          |
|             | Self-host |                    |               |
| pgvector    | Database  | Existing Postgres  | Medium-High   |
+==============================================================+
```

### 5. Retrievers

Retrievers find relevant documents:

```
Query: "What is LangChain?"
         |
         v
+------------------+     +------------------+
|    Retriever     | --> | Top-K Documents  |
+------------------+     +------------------+
|                  |     | 1. "LangChain is |
| Strategies:      |     |    a framework.."|
| - Similarity     |     | 2. "LangChain    |
| - MMR            |     |    provides..."  |
| - Hybrid         |     | 3. "Using        |
| - Contextual     |     |    LangChain..." |
+------------------+     +------------------+
```

---

## Common RAG Pitfalls

### 1. Poor Chunking

```
PROBLEM: Chunks split in wrong places
+-----------------------------------------+
| "The answer to the question is"  | <-- Chunk 1
+-----------------------------------------+
| "42, which represents the meaning| <-- Chunk 2 (context lost!)
| of life."                        |
+-----------------------------------------+

SOLUTION: Use overlap and semantic boundaries
+-----------------------------------------+
| "The answer to the question is   | <-- Chunk 1 (with overlap)
|  42, which represents..."        |
+-----------------------------------------+
```

### 2. Retrieval Failures

```
PROBLEM: Relevant docs not retrieved

User Query: "What's the company vacation policy?"
Retrieved:  [HR policies about sick leave, benefits overview, ...]
Missing:    [Vacation policy document]  <-- Vocabulary mismatch!

SOLUTIONS:
- Query expansion/rewriting
- HyDE (Hypothetical Document Embeddings)
- Hybrid search (semantic + keyword)
- Better embeddings
```

### 3. Context Window Overflow

```
PROBLEM: Too much context stuffed into prompt

+------------------+
| Retrieved Docs   |  50,000 tokens
| + System Prompt  |   1,000 tokens
| + User Query     |     100 tokens
+------------------+
        |
        v
+------------------+
| Context Window   |  <- Only 8,000 tokens!
| OVERFLOW!        |
+------------------+

SOLUTIONS:
- Reduce k (fewer retrieved docs)
- Summarize retrieved content
- Use reranking to filter
- Map-reduce for large contexts
```

### 4. Hallucinations Despite RAG

```
PROBLEM: LLM ignores context or adds information

Context: "Product X costs $99"
Query:   "What's the price of Product X?"
Response: "Product X costs $99, and it comes with a 30-day warranty"
                                    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                                    Not in context! Hallucination!

SOLUTIONS:
- Stronger grounding prompts
- Citation requirements
- Faithfulness evaluation
- Answer verification chains
```

---

## Production RAG Considerations

### Architecture for Scale

```
                    PRODUCTION RAG ARCHITECTURE
+============================================================================+
|                                                                            |
|  +------------------+     +------------------+     +------------------+    |
|  |  Load Balancer   | --> |   API Gateway    | --> |  Rate Limiter    |    |
|  +------------------+     +------------------+     +------------------+    |
|                                                           |                |
|                                   +-----------------------+                |
|                                   |                                        |
|                                   v                                        |
|  +------------------+     +------------------+     +------------------+    |
|  |  Query Cache     | <-- |  RAG Service     | --> |  Embedding       |    |
|  | (Redis/Memcache) |     | (Containerized)  |     |  Service         |    |
|  +------------------+     +------------------+     +------------------+    |
|                                   |                                        |
|                   +---------------+---------------+                        |
|                   |               |               |                        |
|                   v               v               v                        |
|  +------------------+  +------------------+  +------------------+          |
|  |  Vector Store    |  |   Reranker       |  |   LLM Service    |          |
|  |  (Distributed)   |  |   Service        |  | (OpenAI/Claude)  |          |
|  +------------------+  +------------------+  +------------------+          |
|                                                                            |
|  +------------------+  +------------------+  +------------------+          |
|  |  Monitoring      |  |   Logging        |  |   Evaluation     |          |
|  | (Prometheus)     |  | (ELK Stack)      |  | (RAGAS/Custom)   |          |
|  +------------------+  +------------------+  +------------------+          |
|                                                                            |
+============================================================================+
```

### Key Production Considerations

| Aspect | Consideration | Solution |
|--------|---------------|----------|
| **Latency** | Retrieval + LLM adds delay | Caching, async processing, smaller models |
| **Cost** | Embedding + LLM API costs | Batch processing, caching, model selection |
| **Scalability** | Vector DB growth | Sharding, distributed vector stores |
| **Reliability** | API failures | Fallbacks, retries, circuit breakers |
| **Security** | Data privacy | Access controls, encryption, audit logs |
| **Monitoring** | Track performance | Metrics, logging, alerting |
| **Updates** | Keep knowledge fresh | Incremental indexing, version control |

### Metrics to Track

```
+------------------+     +------------------+     +------------------+
|   Retrieval      |     |   Generation     |     |   End-to-End     |
|   Metrics        |     |   Metrics        |     |   Metrics        |
+------------------+     +------------------+     +------------------+
| - Precision@k    |     | - Faithfulness   |     | - Latency (P50,  |
| - Recall@k       |     | - Relevancy      |     |   P95, P99)      |
| - MRR            |     | - Groundedness   |     | - User           |
| - NDCG           |     | - Fluency        |     |   satisfaction   |
| - Retrieval time |     | - Generation     |     | - Task success   |
|                  |     |   time           |     |   rate           |
+------------------+     +------------------+     +------------------+
```

---

## Summary

RAG is a powerful paradigm that combines the knowledge retrieval capabilities of search systems with the generation capabilities of LLMs. Key takeaways:

1. **RAG solves real problems**: outdated knowledge, hallucinations, private data access
2. **Two phases**: Indexing (offline) and Retrieval (online)
3. **Core components**: Loaders, Splitters, Embeddings, Vector Stores, Retrievers
4. **Use RAG when**: You need grounded responses from specific documents
5. **Avoid common pitfalls**: Poor chunking, retrieval failures, context overflow
6. **Production requires**: Caching, monitoring, evaluation, and scaling strategies

In the next module, we'll build a basic RAG pipeline step by step.

---

## References

- [LangChain RAG Documentation](https://docs.langchain.com/oss/python/langchain/rag)
- [RAG in 2026: A Practical Blueprint](https://dev.to/suraj_khaitan_f893c243958/-rag-in-2026-a-practical-blueprint-for-retrieval-augmented-generation-16pp)
- [Build Reliable RAG Applications in 2026](https://dev.to/pavanbelagatti/learn-how-to-build-reliable-rag-applications-in-2026-1b7p)
- [The Complete Guide to RAG Systems 2026](https://nerdleveltech.com/guides/rag-systems)
