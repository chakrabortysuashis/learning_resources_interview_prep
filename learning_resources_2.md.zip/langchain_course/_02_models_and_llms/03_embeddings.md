# Module 02: Text Embeddings in LangChain

## Table of Contents
1. [What are Embeddings?](#what-are-embeddings)
2. [How Embeddings Work](#how-embeddings-work)
3. [OpenAIEmbeddings](#openaiembeddings)
4. [HuggingFaceEmbeddings](#huggingfaceembeddings)
5. [Other Embedding Providers](#other-embedding-providers)
6. [Embedding Comparison](#embedding-comparison)
7. [Vector Stores Integration](#vector-stores-integration)
8. [Best Practices](#best-practices)

---

## What are Embeddings?

Embeddings are dense vector representations of text that capture semantic meaning. They convert words, sentences, or documents into numerical vectors where similar content is positioned closer together in vector space.

### Embedding Visualization

```
+------------------------------------------------------------------+
|                    TEXT TO VECTOR SPACE                          |
+------------------------------------------------------------------+
|                                                                  |
|   "king"  ------>  [0.21, -0.45, 0.78, ..., 0.12]  (1536 dims)  |
|   "queen" ------>  [0.19, -0.42, 0.81, ..., 0.15]  (similar!)   |
|   "apple" ------>  [0.85, 0.23, -0.12, ..., 0.67]  (different)  |
|                                                                  |
|   Vector Space:                                                  |
|                                                                  |
|           queen *                                                |
|                   * king                                         |
|                                                                  |
|                                                                  |
|                                         * apple                  |
|                                                                  |
|   (Similar meanings = close in space)                           |
|                                                                  |
+------------------------------------------------------------------+
```

### Use Cases for Embeddings

```
+------------------------------------------------------------------+
|                    EMBEDDING USE CASES                           |
+------------------------------------------------------------------+
|                                                                  |
|   1. SEMANTIC SEARCH                                             |
|      Query: "How to cook pasta" --> Find relevant recipes        |
|                                                                  |
|   2. RAG (Retrieval Augmented Generation)                        |
|      Embed documents --> Store --> Retrieve for LLM context      |
|                                                                  |
|   3. SIMILARITY COMPARISON                                       |
|      Compare documents, detect duplicates, clustering            |
|                                                                  |
|   4. RECOMMENDATION SYSTEMS                                      |
|      Find similar products, articles, content                    |
|                                                                  |
|   5. CLASSIFICATION                                              |
|      Group texts by semantic similarity                          |
|                                                                  |
+------------------------------------------------------------------+
```

---

## How Embeddings Work

### The Embedding Pipeline

```
+------------------------------------------------------------------+
|                    EMBEDDING PIPELINE                            |
+------------------------------------------------------------------+
|                                                                  |
|   +---------+     +------------+     +-------------+             |
|   | Input   | --> | Tokenizer  | --> | Embedding   |             |
|   | Text    |     |            |     | Model       |             |
|   +---------+     +------------+     +-------------+             |
|                                            |                     |
|                                            v                     |
|                                     +-------------+              |
|                                     | Dense       |              |
|                                     | Vector      |              |
|                                     | [f1, f2,...]|              |
|                                     +-------------+              |
|                                                                  |
|   Example:                                                       |
|   "Machine learning is great"                                    |
|        |                                                         |
|        v                                                         |
|   ["Machine", "learning", "is", "great"]                        |
|        |                                                         |
|        v                                                         |
|   [0.023, -0.156, 0.892, 0.445, ..., 0.067]  (1536 dimensions)  |
|                                                                  |
+------------------------------------------------------------------+
```

### Similarity Calculation

```python
import numpy as np

def cosine_similarity(vec1, vec2):
    """Calculate cosine similarity between two vectors."""
    dot_product = np.dot(vec1, vec2)
    norm1 = np.linalg.norm(vec1)
    norm2 = np.linalg.norm(vec2)
    return dot_product / (norm1 * norm2)

# Similarity ranges from -1 to 1
# 1.0 = identical meaning
# 0.0 = unrelated
# -1.0 = opposite meaning (rare in practice)
```

---

## OpenAIEmbeddings

OpenAI's embedding models are widely used for production applications due to their quality and ease of use.

### Installation

```bash
pip install langchain-openai
```

### Basic Setup

```python
import os
from langchain_openai import OpenAIEmbeddings

os.environ["OPENAI_API_KEY"] = "your-api-key"

# Initialize with default model (text-embedding-3-small)
embeddings = OpenAIEmbeddings()

# Or specify model explicitly
embeddings = OpenAIEmbeddings(
    model="text-embedding-3-large",  # Higher quality, more dimensions
    dimensions=1536,                  # Reduce dimensions (optional)
)
```

### Available Models

```
+------------------------------------------------------------------+
|                    OPENAI EMBEDDING MODELS                       |
+------------------------------------------------------------------+
|                                                                  |
| Model                    | Dimensions | Price/1M tokens | Use    |
|--------------------------|------------|-----------------|--------|
| text-embedding-3-small   | 1536       | $0.02           | Default|
| text-embedding-3-large   | 3072       | $0.13           | Quality|
| text-embedding-ada-002   | 1536       | $0.10           | Legacy |
|                                                                  |
| Note: text-embedding-3-* support dimension reduction             |
|                                                                  |
+------------------------------------------------------------------+
```

### Code Examples

```python
from langchain_openai import OpenAIEmbeddings

embeddings = OpenAIEmbeddings(model="text-embedding-3-small")

# Embed a single text
text = "Machine learning is a subset of artificial intelligence."
vector = embeddings.embed_query(text)
print(f"Vector dimensions: {len(vector)}")  # 1536
print(f"First 5 values: {vector[:5]}")

# Embed multiple documents
documents = [
    "Python is a programming language.",
    "JavaScript is used for web development.",
    "Machine learning requires data.",
]
vectors = embeddings.embed_documents(documents)
print(f"Number of vectors: {len(vectors)}")  # 3
print(f"Each vector has {len(vectors[0])} dimensions")

# Async embedding
import asyncio

async def async_embed():
    vector = await embeddings.aembed_query("Hello world")
    return vector

result = asyncio.run(async_embed())
```

### Dimension Reduction

```python
from langchain_openai import OpenAIEmbeddings

# Full dimensions (3072 for large model)
full_embeddings = OpenAIEmbeddings(model="text-embedding-3-large")

# Reduced dimensions (faster storage, lower cost, slight quality trade-off)
reduced_embeddings = OpenAIEmbeddings(
    model="text-embedding-3-large",
    dimensions=1024  # Reduce from 3072 to 1024
)

text = "Test sentence"
full_vec = full_embeddings.embed_query(text)
reduced_vec = reduced_embeddings.embed_query(text)

print(f"Full: {len(full_vec)} dimensions")      # 3072
print(f"Reduced: {len(reduced_vec)} dimensions") # 1024
```

---

## HuggingFaceEmbeddings

HuggingFace provides open-source embedding models that can run locally without API costs.

### Installation

```bash
pip install langchain-huggingface sentence-transformers
```

### Basic Setup

```python
from langchain_huggingface import HuggingFaceEmbeddings

# Default model: all-MiniLM-L6-v2 (384 dimensions)
embeddings = HuggingFaceEmbeddings()

# Or specify a different model
embeddings = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-mpnet-base-v2",  # 768 dims
    model_kwargs={'device': 'cpu'},  # or 'cuda' for GPU
    encode_kwargs={'normalize_embeddings': True}  # L2 normalize
)
```

### Popular Models

```
+------------------------------------------------------------------+
|                 HUGGINGFACE EMBEDDING MODELS                     |
+------------------------------------------------------------------+
|                                                                  |
| Model                           | Dims | Quality | Speed | Size  |
|---------------------------------|------|---------|-------|-------|
| all-MiniLM-L6-v2               | 384  | Good    | Fast  | 80MB  |
| all-mpnet-base-v2              | 768  | Better  | Med   | 420MB |
| bge-large-en-v1.5              | 1024 | Best    | Slow  | 1.3GB |
| bge-small-en-v1.5              | 384  | Good    | Fast  | 130MB |
| e5-large-v2                    | 1024 | Best    | Slow  | 1.3GB |
| multilingual-e5-large          | 1024 | Best    | Slow  | 2.2GB |
|                                                                  |
+------------------------------------------------------------------+
```

### Code Examples

```python
from langchain_huggingface import HuggingFaceEmbeddings

# Using default model (all-MiniLM-L6-v2)
embeddings = HuggingFaceEmbeddings()

# Embed text
text = "Machine learning is fascinating."
vector = embeddings.embed_query(text)
print(f"Dimensions: {len(vector)}")  # 384

# Embed documents
docs = ["Python is great.", "I love coding."]
vectors = embeddings.embed_documents(docs)

# Using BGE models (recommended for high quality)
bge_embeddings = HuggingFaceEmbeddings(
    model_name="BAAI/bge-large-en-v1.5",
    encode_kwargs={'normalize_embeddings': True}
)

# BGE models work best with a query prefix
query_vector = bge_embeddings.embed_query("What is machine learning?")
```

### GPU Acceleration

```python
from langchain_huggingface import HuggingFaceEmbeddings
import torch

# Check GPU availability
device = 'cuda' if torch.cuda.is_available() else 'cpu'
print(f"Using device: {device}")

# Initialize with GPU
embeddings = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-mpnet-base-v2",
    model_kwargs={'device': device}
)

# Batch processing is much faster on GPU
large_docs = ["Document " + str(i) for i in range(1000)]
vectors = embeddings.embed_documents(large_docs)  # Fast with GPU
```

### Using Inference Endpoints

```python
from langchain_huggingface import HuggingFaceEndpointEmbeddings

# Use HuggingFace Inference API (no local compute needed)
embeddings = HuggingFaceEndpointEmbeddings(
    model="sentence-transformers/all-MiniLM-L6-v2",
    task="feature-extraction",
    huggingfacehub_api_token="your-hf-token"
)

vector = embeddings.embed_query("Hello world")
```

---

## Other Embedding Providers

### Google Embeddings

```python
from langchain_google_genai import GoogleGenerativeAIEmbeddings

embeddings = GoogleGenerativeAIEmbeddings(
    model="models/embedding-001",
    google_api_key="your-api-key"
)

vector = embeddings.embed_query("Hello world")
```

### Cohere Embeddings

```python
from langchain_cohere import CohereEmbeddings

embeddings = CohereEmbeddings(
    model="embed-english-v3.0",
    cohere_api_key="your-api-key"
)

# Cohere supports input types
vector = embeddings.embed_query("search query")
doc_vectors = embeddings.embed_documents(["document text"])
```

### Ollama (Local)

```python
from langchain_ollama import OllamaEmbeddings

# Run locally with Ollama
embeddings = OllamaEmbeddings(
    model="nomic-embed-text"  # or "mxbai-embed-large"
)

vector = embeddings.embed_query("Hello world")
```

---

## Embedding Comparison

### Feature Comparison

```
+------------------------------------------------------------------+
|                EMBEDDING PROVIDER COMPARISON                     |
+------------------------------------------------------------------+
|                                                                  |
| Feature           | OpenAI    | HuggingFace | Google   | Cohere |
|-------------------|-----------|-------------|----------|--------|
| Cloud Hosted      | Yes       | Optional    | Yes      | Yes    |
| Local Deployment  | No        | Yes         | No       | No     |
| API Cost          | $0.02/1M  | Free*       | Free**   | $0.10  |
| Max Dimensions    | 3072      | 1024+       | 768      | 1024   |
| GPU Required      | No        | Optional    | No       | No     |
| Multilingual      | Good      | Excellent   | Good     | Good   |
| Setup Complexity  | Easy      | Medium      | Easy     | Easy   |
|                                                                  |
| * Free for local, Inference API has limits                       |
| ** Free tier available, paid for high volume                     |
|                                                                  |
+------------------------------------------------------------------+
```

### Quality vs Cost Trade-off

```
+------------------------------------------------------------------+
|                    QUALITY VS COST SPECTRUM                      |
+------------------------------------------------------------------+
|                                                                  |
|   Quality                                                        |
|      ^                                                           |
|      |                                                           |
|      |          * OpenAI text-embedding-3-large                  |
|      |      * BGE-large-en    * Cohere embed-v3                 |
|      |  * E5-large                                               |
|      |                                                           |
|      |      * OpenAI text-embedding-3-small                      |
|      |  * all-mpnet-base                                         |
|      |                                                           |
|      |  * all-MiniLM-L6 (fast, free)                            |
|      +-------------------------------------------------> Cost    |
|      Free                                            $$$         |
|                                                                  |
+------------------------------------------------------------------+
```

### Benchmark Comparison

```python
# Simple benchmark script
import time
from langchain_openai import OpenAIEmbeddings
from langchain_huggingface import HuggingFaceEmbeddings

def benchmark_embedding(embeddings, name, texts):
    start = time.time()
    vectors = embeddings.embed_documents(texts)
    elapsed = time.time() - start
    
    print(f"{name}:")
    print(f"  Time: {elapsed:.2f}s")
    print(f"  Dimensions: {len(vectors[0])}")
    print(f"  Texts/second: {len(texts)/elapsed:.1f}")
    return vectors

# Test texts
test_texts = ["Sample text " + str(i) for i in range(100)]

# OpenAI (requires API key)
openai_emb = OpenAIEmbeddings(model="text-embedding-3-small")
benchmark_embedding(openai_emb, "OpenAI", test_texts)

# HuggingFace (local)
hf_emb = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
benchmark_embedding(hf_emb, "HuggingFace", test_texts)
```

---

## Vector Stores Integration

Embeddings are typically stored in vector databases for efficient similarity search.

### Integration Architecture

```
+------------------------------------------------------------------+
|                    RAG ARCHITECTURE WITH EMBEDDINGS              |
+------------------------------------------------------------------+
|                                                                  |
|   INDEXING PHASE:                                                |
|   +----------+     +------------+     +---------------+          |
|   | Documents| --> | Embedding  | --> | Vector Store  |          |
|   |          |     | Model      |     | (FAISS/Chroma)|          |
|   +----------+     +------------+     +---------------+          |
|                                                                  |
|   QUERY PHASE:                                                   |
|   +----------+     +------------+     +---------------+          |
|   | Query    | --> | Embedding  | --> | Similarity    |          |
|   |          |     | Model      |     | Search        |          |
|   +----------+     +------------+     +---------------+          |
|                                             |                    |
|                                             v                    |
|                                     +---------------+            |
|                                     | Top K Results |            |
|                                     +---------------+            |
|                                                                  |
+------------------------------------------------------------------+
```

### FAISS Example

```python
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document

# Initialize embeddings
embeddings = OpenAIEmbeddings(model="text-embedding-3-small")

# Create documents
documents = [
    Document(page_content="Python is a programming language.", metadata={"source": "wiki"}),
    Document(page_content="JavaScript runs in browsers.", metadata={"source": "wiki"}),
    Document(page_content="Machine learning uses algorithms.", metadata={"source": "book"}),
]

# Create vector store
vectorstore = FAISS.from_documents(documents, embeddings)

# Similarity search
results = vectorstore.similarity_search("What is Python?", k=2)
for doc in results:
    print(f"Content: {doc.page_content}")
    print(f"Metadata: {doc.metadata}")
    print("---")

# Save and load
vectorstore.save_local("faiss_index")
loaded_vectorstore = FAISS.load_local("faiss_index", embeddings)
```

### Chroma Example

```python
from langchain_openai import OpenAIEmbeddings
from langchain_chroma import Chroma

embeddings = OpenAIEmbeddings()

# Create persistent vector store
vectorstore = Chroma(
    collection_name="my_collection",
    embedding_function=embeddings,
    persist_directory="./chroma_db"
)

# Add documents
vectorstore.add_texts(
    texts=["Document 1", "Document 2"],
    metadatas=[{"source": "a"}, {"source": "b"}]
)

# Search with score
results = vectorstore.similarity_search_with_score("query", k=3)
for doc, score in results:
    print(f"Score: {score:.4f} - {doc.page_content}")
```

---

## Best Practices

### 1. Choose the Right Model

```python
# Decision flowchart in code
def choose_embedding_model(requirements):
    """
    Requirements:
    - budget: "free", "low", "medium", "high"
    - quality: "basic", "good", "best"
    - local: bool (must run locally)
    - multilingual: bool
    """
    
    if requirements.get("local"):
        if requirements.get("quality") == "best":
            return "BAAI/bge-large-en-v1.5"
        return "sentence-transformers/all-MiniLM-L6-v2"
    
    if requirements.get("budget") == "free":
        return "sentence-transformers/all-MiniLM-L6-v2"
    
    if requirements.get("quality") == "best":
        return "text-embedding-3-large"
    
    return "text-embedding-3-small"  # Default: good quality, reasonable cost
```

### 2. Consistent Embedding Models

```python
# IMPORTANT: Always use the same model for indexing and querying!

# Wrong - will give poor results
index_embeddings = OpenAIEmbeddings(model="text-embedding-3-large")
query_embeddings = OpenAIEmbeddings(model="text-embedding-3-small")  # Different!

# Correct - same model for both
embeddings = OpenAIEmbeddings(model="text-embedding-3-small")
# Use `embeddings` for both indexing and querying
```

### 3. Batch Processing

```python
from langchain_openai import OpenAIEmbeddings

embeddings = OpenAIEmbeddings()

# Inefficient: One API call per document
vectors = []
for doc in documents:
    vec = embeddings.embed_query(doc)  # Multiple API calls
    vectors.append(vec)

# Efficient: Batch embedding
vectors = embeddings.embed_documents(documents)  # Single API call
```

### 4. Caching Embeddings

```python
from langchain.embeddings import CacheBackedEmbeddings
from langchain.storage import LocalFileStore
from langchain_openai import OpenAIEmbeddings

# Create base embeddings
base_embeddings = OpenAIEmbeddings()

# Create a local file store for caching
store = LocalFileStore("./embedding_cache")

# Wrap with caching
cached_embeddings = CacheBackedEmbeddings.from_bytes_store(
    base_embeddings,
    store,
    namespace="openai-embeddings"
)

# First call: computes and caches
vector1 = cached_embeddings.embed_query("Hello world")

# Second call: returns from cache (no API call)
vector2 = cached_embeddings.embed_query("Hello world")
```

### 5. Text Preprocessing

```python
def preprocess_for_embedding(text: str) -> str:
    """Clean text before embedding for better results."""
    # Remove excessive whitespace
    text = " ".join(text.split())
    
    # Remove very long texts (truncate)
    max_chars = 8000  # Approximate token limit
    if len(text) > max_chars:
        text = text[:max_chars]
    
    # Optional: lowercase for case-insensitive matching
    # text = text.lower()
    
    return text

# Usage
documents = [preprocess_for_embedding(doc) for doc in raw_documents]
vectors = embeddings.embed_documents(documents)
```

### 6. Error Handling

```python
from langchain_openai import OpenAIEmbeddings
from tenacity import retry, stop_after_attempt, wait_exponential

embeddings = OpenAIEmbeddings()

@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=4, max=10))
def safe_embed(texts):
    """Embed with retry logic."""
    try:
        return embeddings.embed_documents(texts)
    except Exception as e:
        print(f"Embedding error: {e}")
        raise

# Handle empty inputs
def embed_safely(texts):
    if not texts:
        return []
    texts = [t for t in texts if t and t.strip()]  # Filter empty strings
    if not texts:
        return []
    return safe_embed(texts)
```

---

## Summary

| Provider | Best For | Dimensions | Cost |
|----------|----------|------------|------|
| **OpenAI** | Production, ease of use | 1536/3072 | $0.02-0.13/1M |
| **HuggingFace** | Local deployment, privacy | 384-1024 | Free (local) |
| **Google** | Google ecosystem | 768 | Free tier |
| **Cohere** | Multilingual, search | 1024 | $0.10/1M |
| **Ollama** | Fully local, privacy | Varies | Free |

### Key Takeaways

1. **Embeddings convert text to vectors** for semantic similarity operations
2. **Use the same model** for indexing and querying
3. **OpenAI embeddings** are easy to use and high quality
4. **HuggingFace embeddings** are free and run locally
5. **Batch processing** and **caching** significantly reduce costs
6. **Vector stores** (FAISS, Chroma) enable efficient similarity search

---

## Next Steps

Continue to [04_model_configuration.ipynb](./04_model_configuration.ipynb) to explore model configuration parameters in practice.
