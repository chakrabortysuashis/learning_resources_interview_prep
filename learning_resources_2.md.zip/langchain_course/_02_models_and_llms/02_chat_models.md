# Module 02: Chat Models in LangChain

## Table of Contents
1. [Introduction to Chat Models](#introduction-to-chat-models)
2. [ChatOpenAI](#chatopenai)
3. [ChatAnthropic](#chatanthropic)
4. [ChatGoogleGenerativeAI](#chatgooglegenerativeai)
5. [Provider Comparison](#provider-comparison)
6. [Unified Interface](#unified-interface)
7. [Best Practices](#best-practices)

---

## Introduction to Chat Models

Chat models in LangChain are wrappers around conversational AI APIs that accept a list of messages and return a response message. They implement a common interface that allows seamless switching between providers.

### Message Architecture

```
+------------------------------------------------------------------+
|                    CHAT MODEL MESSAGE FLOW                       |
+------------------------------------------------------------------+
|                                                                  |
|   +-------------+     +-------------+     +-------------+        |
|   | System      |     | Human       |     | AI          |        |
|   | Message     |     | Message     |     | Message     |        |
|   +-------------+     +-------------+     +-------------+        |
|         |                   |                   |                |
|         v                   v                   v                |
|   +-----------------------------------------------------+       |
|   |              CHAT MODEL (e.g., GPT-4o)              |       |
|   +-----------------------------------------------------+       |
|                             |                                    |
|                             v                                    |
|                    +------------------+                          |
|                    |  AIMessage       |                          |
|                    |  (Response)      |                          |
|                    +------------------+                          |
|                                                                  |
+------------------------------------------------------------------+
```

### Message Types

```python
from langchain_core.messages import (
    SystemMessage,    # Instructions for the AI
    HumanMessage,     # User input
    AIMessage,        # AI response
    ToolMessage,      # Tool/function call results
)

messages = [
    SystemMessage(content="You are a helpful coding assistant."),
    HumanMessage(content="How do I reverse a list in Python?"),
    AIMessage(content="You can use list[::-1] or list.reverse()"),
    HumanMessage(content="Which is faster?"),
]
```

---

## ChatOpenAI

OpenAI's chat models include GPT-4o, GPT-4 Turbo, and GPT-4o-mini.

### Installation

```bash
pip install langchain-openai
```

### Basic Setup

```python
import os
from langchain_openai import ChatOpenAI

# Set API key via environment variable
os.environ["OPENAI_API_KEY"] = "your-api-key"

# Initialize the model
chat = ChatOpenAI(
    model="gpt-4o",              # Model name
    temperature=0.7,              # Creativity (0-2)
    max_tokens=1000,              # Max response length
    timeout=30,                   # Request timeout
    max_retries=2,                # Retry on failure
)
```

### Available Models (2026)

```
+------------------------------------------------------------------+
|                    OPENAI MODEL HIERARCHY                        |
+------------------------------------------------------------------+
|                                                                  |
|   FLAGSHIP                                                       |
|   +------------------+    +------------------+                   |
|   | GPT-4o           |    | GPT-4 Turbo      |                   |
|   | (Omni - Latest)  |    | (128K context)   |                   |
|   | Multimodal       |    | JSON mode        |                   |
|   +------------------+    +------------------+                   |
|                                                                  |
|   EFFICIENT                                                      |
|   +------------------+    +------------------+                   |
|   | GPT-4o-mini      |    | GPT-3.5 Turbo    |                   |
|   | (Cost-effective) |    | (Legacy)         |                   |
|   | Fast, capable    |    | Still available  |                   |
|   +------------------+    +------------------+                   |
|                                                                  |
+------------------------------------------------------------------+
```

### Code Examples

```python
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage

# Basic invocation
chat = ChatOpenAI(model="gpt-4o", temperature=0)

response = chat.invoke([
    SystemMessage(content="You are a Python expert."),
    HumanMessage(content="Explain list comprehensions in one sentence.")
])
print(response.content)

# Streaming
for chunk in chat.stream("Count from 1 to 5"):
    print(chunk.content, end="", flush=True)

# Async invocation
import asyncio

async def async_chat():
    response = await chat.ainvoke("What is 2+2?")
    return response.content

result = asyncio.run(async_chat())

# Batch processing
responses = chat.batch([
    [HumanMessage(content="What is Python?")],
    [HumanMessage(content="What is JavaScript?")],
])
```

### Function/Tool Calling

```python
from langchain_openai import ChatOpenAI
from langchain_core.tools import tool

@tool
def get_weather(location: str) -> str:
    """Get weather for a location."""
    return f"The weather in {location} is sunny, 72F"

chat = ChatOpenAI(model="gpt-4o").bind_tools([get_weather])

response = chat.invoke("What's the weather in San Francisco?")
print(response.tool_calls)
# [{'name': 'get_weather', 'args': {'location': 'San Francisco'}, 'id': '...'}]
```

---

## ChatAnthropic

Anthropic's Claude models are known for safety, long context windows, and strong coding capabilities.

### Installation

```bash
pip install langchain-anthropic
```

### Basic Setup

```python
import os
from langchain_anthropic import ChatAnthropic

os.environ["ANTHROPIC_API_KEY"] = "your-api-key"

chat = ChatAnthropic(
    model="claude-sonnet-4-5-20250929",  # Latest Sonnet
    temperature=0.7,
    max_tokens=4096,
    timeout=60,
    max_retries=2,
)
```

### Available Models (2026)

```
+------------------------------------------------------------------+
|                  ANTHROPIC CLAUDE MODEL FAMILY                   |
+------------------------------------------------------------------+
|                                                                  |
|   CLAUDE 4 SERIES (Latest)                                       |
|   +------------------+    +------------------+                   |
|   | Claude 4 Opus    |    | Claude 4 Sonnet  |                   |
|   | (Most capable)   |    | (Balanced)       |                   |
|   | Complex tasks    |    | Best value       |                   |
|   +------------------+    +------------------+                   |
|                                                                  |
|   CLAUDE 3.5 SERIES                                              |
|   +------------------+    +------------------+                   |
|   | Claude 3.5       |    | Claude 3.5 Haiku |                   |
|   | Sonnet           |    | (Fastest)        |                   |
|   | (Great for code) |    | High throughput  |                   |
|   +------------------+    +------------------+                   |
|                                                                  |
|   Context Window: Up to 200K tokens for all models               |
|                                                                  |
+------------------------------------------------------------------+
```

### Code Examples

```python
from langchain_anthropic import ChatAnthropic
from langchain_core.messages import HumanMessage, SystemMessage

# Basic usage
chat = ChatAnthropic(model="claude-sonnet-4-5-20250929", temperature=0)

response = chat.invoke([
    SystemMessage(content="You are a helpful assistant."),
    HumanMessage(content="Explain quantum computing simply.")
])
print(response.content)

# Token counting (unique to Anthropic)
messages = [HumanMessage(content="Hello, how are you?")]
token_count = chat.get_num_tokens_from_messages(messages)
print(f"Token count: {token_count}")

# Extended thinking (Claude 4+)
chat_with_thinking = ChatAnthropic(
    model="claude-sonnet-4-5-20250929",
    max_tokens=16000,
)
# Note: Extended thinking is enabled automatically for complex reasoning tasks

# Streaming
for chunk in chat.stream("Write a haiku about programming"):
    print(chunk.content, end="", flush=True)
```

### Tool Use with Claude

```python
from langchain_anthropic import ChatAnthropic
from langchain_core.tools import tool

@tool
def calculator(expression: str) -> float:
    """Evaluate a mathematical expression."""
    return eval(expression)

chat = ChatAnthropic(model="claude-sonnet-4-5-20250929").bind_tools([calculator])

response = chat.invoke("What is (15 * 7) + 23?")
print(response.tool_calls)
```

---

## ChatGoogleGenerativeAI

Google's Gemini models offer multimodal capabilities and extremely long context windows.

### Installation

```bash
pip install langchain-google-genai
```

### Basic Setup

```python
import os
from langchain_google_genai import ChatGoogleGenerativeAI

os.environ["GOOGLE_API_KEY"] = "your-api-key"

chat = ChatGoogleGenerativeAI(
    model="gemini-2.0-flash",     # Fast, capable model
    temperature=0.7,
    max_tokens=None,              # No limit (model decides)
    timeout=30,
    max_retries=2,
)
```

### Available Models (2026)

```
+------------------------------------------------------------------+
|                    GOOGLE GEMINI MODEL FAMILY                    |
+------------------------------------------------------------------+
|                                                                  |
|   GEMINI 3.X SERIES (Latest - August 2026)                       |
|   +------------------+    +------------------+                   |
|   | Gemini 3.7 Flash |    | Gemini 3.1 Pro   |                   |
|   | (General purpose)|    | (Preview)        |                   |
|   | Fast & capable   |    | Advanced reason. |                   |
|   +------------------+    +------------------+                   |
|                                                                  |
|   GEMINI 2.X SERIES                                              |
|   +------------------+    +------------------+                   |
|   | Gemini 2.0 Flash |    | Gemini 2.0 Pro   |                   |
|   | (Production)     |    | (Higher quality) |                   |
|   | 1M+ context      |    | Complex tasks    |                   |
|   +------------------+    +------------------+                   |
|                                                                  |
|   COST-OPTIMIZED                                                 |
|   +------------------+                                           |
|   | Gemini 3.5       |                                           |
|   | Flash-Lite       |                                           |
|   | (High volume)    |                                           |
|   +------------------+                                           |
|                                                                  |
+------------------------------------------------------------------+
```

### Code Examples

```python
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.messages import HumanMessage

# Basic usage
chat = ChatGoogleGenerativeAI(model="gemini-2.0-flash", temperature=0)

response = chat.invoke("What are the benefits of renewable energy?")
print(response.content)

# Multimodal (image + text)
import base64

def encode_image(image_path):
    with open(image_path, "rb") as f:
        return base64.b64encode(f.read()).decode()

image_data = encode_image("diagram.png")

response = chat.invoke([
    HumanMessage(content=[
        {"type": "text", "text": "What's in this image?"},
        {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{image_data}"}}
    ])
])

# Using Vertex AI backend (enterprise)
import os
os.environ["GOOGLE_GENAI_USE_VERTEXAI"] = "true"
os.environ["GOOGLE_CLOUD_PROJECT"] = "your-project-id"

vertex_chat = ChatGoogleGenerativeAI(model="gemini-2.0-flash")
```

### Safety Settings

```python
from langchain_google_genai import ChatGoogleGenerativeAI

# Configure safety settings
chat = ChatGoogleGenerativeAI(
    model="gemini-2.0-flash",
    safety_settings={
        "HARM_CATEGORY_HARASSMENT": "BLOCK_ONLY_HIGH",
        "HARM_CATEGORY_HATE_SPEECH": "BLOCK_ONLY_HIGH",
    }
)
```

---

## Provider Comparison

### Feature Comparison Matrix

```
+------------------------------------------------------------------+
|                    PROVIDER FEATURE COMPARISON                   |
+------------------------------------------------------------------+
|                                                                  |
| Feature          | OpenAI      | Anthropic    | Google          |
|------------------|-------------|--------------|-----------------|
| Best Model       | GPT-4o      | Claude 4 Opus| Gemini Pro      |
| Context Window   | 128K        | 200K         | 1M+             |
| Multimodal       | Yes         | Yes          | Yes             |
| Tool Calling     | Excellent   | Excellent    | Good            |
| Streaming        | Yes         | Yes          | Yes             |
| JSON Mode        | Native      | Via prompts  | Native          |
| Token Counting   | Estimate    | Exact API    | Estimate        |
| Vision           | Yes         | Yes          | Yes             |
| Audio            | Yes (GPT-4o)| No           | Yes             |
|                                                                  |
+------------------------------------------------------------------+
```

### Pricing Comparison (2026 Estimates)

```
+------------------------------------------------------------------+
|                    COST PER 1M TOKENS (USD)                      |
+------------------------------------------------------------------+
|                                                                  |
| Model                    | Input    | Output   | Notes           |
|--------------------------|----------|----------|-----------------|
| GPT-4o                   | $2.50    | $10.00   | Flagship        |
| GPT-4o-mini              | $0.15    | $0.60    | Best value      |
| Claude 4 Sonnet          | $3.00    | $15.00   | Balanced        |
| Claude 3.5 Haiku         | $0.25    | $1.25    | Fast & cheap    |
| Gemini 2.0 Flash         | $0.075   | $0.30    | Very affordable |
| Gemini 3.7 Flash         | $0.10    | $0.40    | Latest flash    |
|                                                                  |
| Note: Prices are approximate and subject to change              |
|                                                                  |
+------------------------------------------------------------------+
```

### Use Case Recommendations

```
+------------------------------------------------------------------+
|                    USE CASE DECISION MATRIX                      |
+------------------------------------------------------------------+
|                                                                  |
|   USE CASE                    RECOMMENDED MODEL                  |
|   --------------------------------------------------------       |
|   High-volume chatbot    -->  GPT-4o-mini / Gemini Flash         |
|   Code generation        -->  Claude 3.5 Sonnet / GPT-4o         |
|   Document analysis      -->  Claude 4 (200K context)            |
|   Massive documents      -->  Gemini (1M+ context)               |
|   Complex reasoning      -->  Claude 4 Opus / GPT-4o             |
|   Multimodal (images)    -->  GPT-4o / Gemini Flash              |
|   Cost-sensitive         -->  Gemini Flash / Claude Haiku        |
|   Safety-critical        -->  Claude (built-in safety)           |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Unified Interface

### Using init_chat_model

LangChain provides `init_chat_model` for provider-agnostic initialization.

```python
from langchain.chat_models import init_chat_model

# OpenAI
openai_chat = init_chat_model("gpt-4o", model_provider="openai")

# Anthropic
anthropic_chat = init_chat_model("claude-sonnet-4-5-20250929", model_provider="anthropic")

# Google
google_chat = init_chat_model("gemini-2.0-flash", model_provider="google_genai")

# All use the same interface!
for chat in [openai_chat, anthropic_chat, google_chat]:
    response = chat.invoke("Hello!")
    print(response.content)
```

### Configurable Alternatives

```python
from langchain_anthropic import ChatAnthropic
from langchain_openai import ChatOpenAI
from langchain_core.runnables import ConfigurableField

# Create a configurable model
model = ChatAnthropic(model="claude-sonnet-4-5-20250929").configurable_alternatives(
    ConfigurableField(id="llm"),
    default_key="anthropic",
    openai=ChatOpenAI(model="gpt-4o"),
    openai_mini=ChatOpenAI(model="gpt-4o-mini"),
)

# Use default (Anthropic)
response = model.invoke("Hello")

# Switch to OpenAI at runtime
response = model.with_config(configurable={"llm": "openai"}).invoke("Hello")

# Switch to mini for cost savings
response = model.with_config(configurable={"llm": "openai_mini"}).invoke("Hello")
```

---

## Best Practices

### 1. Environment Variables

```python
# .env file
OPENAI_API_KEY=sk-...
ANTHROPIC_API_KEY=sk-ant-...
GOOGLE_API_KEY=...

# Load in code
from dotenv import load_dotenv
load_dotenv()

# Models will automatically use these
chat = ChatOpenAI(model="gpt-4o")  # Uses OPENAI_API_KEY
```

### 2. Error Handling and Retries

```python
from langchain_openai import ChatOpenAI
from langchain_anthropic import ChatAnthropic
import time

# Built-in retries
chat = ChatOpenAI(
    model="gpt-4o",
    max_retries=3,          # Automatic exponential backoff
    request_timeout=30,      # Per-request timeout
)

# Fallback chain
primary = ChatOpenAI(model="gpt-4o")
fallback = ChatAnthropic(model="claude-sonnet-4-5-20250929")
backup = ChatOpenAI(model="gpt-4o-mini")

robust_chat = primary.with_fallbacks([fallback, backup])

# Will try GPT-4o -> Claude -> GPT-4o-mini
response = robust_chat.invoke("Hello")
```

### 3. Rate Limiting

```python
import asyncio
from langchain_openai import ChatOpenAI

chat = ChatOpenAI(model="gpt-4o")

async def rate_limited_calls(prompts, rate_limit=10):
    """Process prompts with rate limiting."""
    results = []
    for i, prompt in enumerate(prompts):
        if i > 0 and i % rate_limit == 0:
            await asyncio.sleep(1)  # Wait 1 second every 10 requests
        result = await chat.ainvoke(prompt)
        results.append(result)
    return results
```

### 4. Caching

```python
from langchain.cache import InMemoryCache
from langchain.globals import set_llm_cache
from langchain_openai import ChatOpenAI

# Enable caching globally
set_llm_cache(InMemoryCache())

chat = ChatOpenAI(model="gpt-4o")

# First call - hits the API
response1 = chat.invoke("What is 2+2?")

# Second identical call - returns cached result (no API call)
response2 = chat.invoke("What is 2+2?")
```

### 5. Logging and Debugging

```python
import langchain
from langchain_openai import ChatOpenAI

# Enable debug mode
langchain.debug = True

chat = ChatOpenAI(model="gpt-4o")
response = chat.invoke("Hello")  # Will print detailed logs

# Or use verbose mode on the model
chat = ChatOpenAI(model="gpt-4o", verbose=True)
```

---

## Summary

| Provider | Package | Key Strength | Best For |
|----------|---------|--------------|----------|
| **OpenAI** | `langchain-openai` | Versatility, function calling | General purpose |
| **Anthropic** | `langchain-anthropic` | Safety, long context | Document analysis, code |
| **Google** | `langchain-google-genai` | Multimodal, huge context | Large documents, vision |

All providers implement the same LangChain interface, making it easy to:
- Switch between providers without code changes
- Implement fallback chains for reliability
- Configure alternatives at runtime
- Compare performance and costs

---

## Next Steps

Continue to [03_embeddings.md](./03_embeddings.md) to learn about text embeddings for semantic search and RAG applications.
