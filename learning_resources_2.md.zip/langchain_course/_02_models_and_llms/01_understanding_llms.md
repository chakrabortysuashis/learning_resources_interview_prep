# Module 02: Understanding Large Language Models (LLMs)

## Table of Contents
1. [What are LLMs?](#what-are-llms)
2. [How LLMs Work](#how-llms-work)
3. [LLMs in LangChain Context](#llms-in-langchain-context)
4. [Types of Language Models](#types-of-language-models)
5. [Key Concepts](#key-concepts)
6. [Best Practices](#best-practices)

---

## What are LLMs?

Large Language Models (LLMs) are deep learning models trained on massive amounts of text data to understand and generate human-like text. They use transformer architectures and have billions of parameters that encode linguistic patterns, factual knowledge, and reasoning capabilities.

### Architecture Overview

```
+------------------------------------------------------------------+
|                    LARGE LANGUAGE MODEL (LLM)                    |
+------------------------------------------------------------------+
|                                                                  |
|   +------------------+    +------------------+    +------------+ |
|   |   Input Layer    |    | Transformer Blocks|    |  Output    | |
|   |   (Tokenizer)    |--->| (Self-Attention) |--->|  Layer     | |
|   +------------------+    +------------------+    +------------+ |
|                                                                  |
|   "Hello, how are"   -->  [Neural Processing]  -->  "you today?" |
|                                                                  |
+------------------------------------------------------------------+
           ^                                              |
           |              Training Data                   |
           +----------------------------------------------+
                    (Billions of tokens)
```

### Key Characteristics

| Characteristic | Description |
|---------------|-------------|
| **Scale** | Billions of parameters (GPT-4: ~1.8T, Claude 3: undisclosed) |
| **Training Data** | Trained on internet text, books, code, conversations |
| **Capabilities** | Text generation, summarization, translation, reasoning |
| **Context Window** | Amount of text the model can "see" at once |

---

## How LLMs Work

### The Token Processing Pipeline

```
+--------+     +------------+     +---------------+     +--------+
| Input  | --> | Tokenizer  | --> |  Embedding    | --> | Trans- |
| Text   |     | (Split to  |     |  Layer        |     | former |
|        |     |  tokens)   |     |  (Vectors)    |     | Blocks |
+--------+     +------------+     +---------------+     +--------+
                                                             |
                                                             v
+--------+     +------------+     +---------------+     +--------+
| Output | <-- | De-token-  | <-- |  Softmax      | <-- | Atten- |
| Text   |     | izer       |     |  (Probs)      |     | tion   |
+--------+     +------------+     +---------------+     +--------+
```

### Step-by-Step Process

1. **Tokenization**: Text is split into tokens (words, subwords, or characters)
   ```
   "Hello world" -> ["Hello", " world"] -> [15496, 995]
   ```

2. **Embedding**: Tokens are converted to dense vectors
   ```
   [15496] -> [0.023, -0.156, 0.892, ..., 0.045]  # 1536 dimensions
   ```

3. **Attention Mechanism**: Model determines which tokens are relevant to each other
   ```
   "The cat sat on the mat because it was tired"
                                    ^
                        "it" attends to "cat" (not "mat")
   ```

4. **Generation**: Model predicts the next token probability distribution
   ```
   Input: "The capital of France is"
   Output probabilities: {"Paris": 0.95, "Lyon": 0.02, "London": 0.01, ...}
   ```

---

## LLMs in LangChain Context

LangChain provides a unified interface to work with various LLM providers, abstracting away provider-specific details while maintaining access to advanced features.

### LangChain Model Abstraction

```
+------------------------------------------------------------------+
|                      YOUR APPLICATION                            |
+------------------------------------------------------------------+
                              |
                              v
+------------------------------------------------------------------+
|                   LANGCHAIN ABSTRACTION LAYER                    |
|                                                                  |
|   +------------------+  +------------------+  +----------------+ |
|   | BaseChatModel    |  | BaseEmbeddings   |  | BaseRetriever  | |
|   +------------------+  +------------------+  +----------------+ |
|                                                                  |
+------------------------------------------------------------------+
          |                       |                       |
          v                       v                       v
+----------------+    +------------------+    +------------------+
|   OpenAI API   |    |  Anthropic API   |    |   Google API     |
| (GPT-4, GPT-4o)|    | (Claude 3/4)     |    | (Gemini 2/3)     |
+----------------+    +------------------+    +------------------+
```

### Two Types of Language Model Interfaces

LangChain distinguishes between two model interfaces:

#### 1. LLMs (Legacy/Completion Models)
```python
from langchain_openai import OpenAI

# Completion-style (text in, text out)
llm = OpenAI(model="gpt-3.5-turbo-instruct")
response = llm.invoke("Complete this sentence: The sky is")
# Output: "blue and full of clouds..."
```

#### 2. Chat Models (Recommended)
```python
from langchain_openai import ChatOpenAI

# Message-based (structured conversation)
chat = ChatOpenAI(model="gpt-4o")
response = chat.invoke([
    {"role": "system", "content": "You are a helpful assistant."},
    {"role": "user", "content": "What is the capital of France?"}
])
# Output: AIMessage(content="The capital of France is Paris.")
```

### Why Chat Models are Preferred

| Feature | LLMs (Completion) | Chat Models |
|---------|------------------|-------------|
| Message Structure | Plain text | Role-based messages |
| System Instructions | Embedded in prompt | Dedicated system message |
| Multi-turn Conversations | Manual management | Native support |
| Modern Model Support | Limited | Full support |
| Tool/Function Calling | Limited | Native support |

---

## Types of Language Models

### Model Categories by Size and Capability

```
+------------------------------------------------------------------+
|                    MODEL SIZE SPECTRUM                           |
+------------------------------------------------------------------+
|                                                                  |
|  SMALL (<10B)        MEDIUM (10-100B)       LARGE (>100B)       |
|  +------------+      +---------------+      +---------------+   |
|  | Gemini     |      | Claude 3      |      | GPT-4         |   |
|  | Flash Lite |      | Haiku         |      | Claude 3 Opus |   |
|  | Llama 3 8B |      | Mistral Medium|      | Gemini Ultra  |   |
|  +------------+      +---------------+      +---------------+   |
|       |                    |                      |             |
|       v                    v                      v             |
|  Fast, Cheap         Balanced               Powerful, Expensive |
|  Limited Reasoning   Good for Most Tasks   Complex Reasoning    |
|                                                                  |
+------------------------------------------------------------------+
```

### Provider Comparison (2026)

| Provider | Models | Strengths | Context Window |
|----------|--------|-----------|----------------|
| **OpenAI** | GPT-4o, GPT-4 Turbo | Versatile, function calling | 128K tokens |
| **Anthropic** | Claude 4, Claude 3.5 Sonnet | Safety, long context, coding | 200K tokens |
| **Google** | Gemini 3.7 Flash, Gemini Pro | Multimodal, long context | 1M+ tokens |
| **Meta** | Llama 3.2, Llama 3.1 | Open source, self-hostable | 128K tokens |
| **Mistral** | Mistral Large, Mixtral | European, efficient | 32K-128K tokens |

---

## Key Concepts

### 1. Context Window

The maximum number of tokens a model can process in a single request.

```
+------------------------------------------------------------------+
|                    CONTEXT WINDOW VISUALIZATION                  |
+------------------------------------------------------------------+
|                                                                  |
|   GPT-4 Turbo:    [==================================] 128K      |
|   Claude 3:       [==========================================] 200K|
|   Gemini 1.5:     [==========================================...] 1M+|
|                                                                  |
|   Average Book:   [=====] ~100K tokens                          |
|   Typical Chat:   [=] ~2K tokens                                |
|                                                                  |
+------------------------------------------------------------------+
```

### 2. Tokens vs Words

```python
# Rough approximation
1 token ~= 0.75 words (English)
1 token ~= 4 characters

# Example
"Hello, how are you today?" = 6 tokens
"Supercalifragilisticexpialidocious" = 9 tokens (split into subwords)
```

### 3. Temperature and Sampling

```
Temperature Controls Randomness
+------------------------------------------------------------------+
|                                                                  |
|   Temperature = 0.0        Temperature = 0.7      Temperature = 1.5|
|   +------------+           +------------+         +------------+ |
|   | Determin-  |           | Balanced   |         | Creative   | |
|   | istic      |           | Creativity |         | Chaotic    | |
|   +------------+           +------------+         +------------+ |
|                                                                  |
|   "The answer             "The answer            "The answer    |
|    is 42."                 is 42, the             is cosmic     |
|                            ultimate               banana!"      |
|                            number."                              |
+------------------------------------------------------------------+
```

### 4. Streaming vs Non-Streaming

```python
# Non-streaming: Wait for complete response
response = chat.invoke("Tell me a story")
print(response.content)  # Prints all at once after generation completes

# Streaming: Get tokens as they're generated
for chunk in chat.stream("Tell me a story"):
    print(chunk.content, end="", flush=True)  # Prints progressively
```

---

## Best Practices

### 1. Model Selection Guidelines

```
+------------------------------------------------------------------+
|                    MODEL SELECTION FLOWCHART                     |
+------------------------------------------------------------------+
|                                                                  |
|                      What's your use case?                       |
|                             |                                    |
|          +------------------+------------------+                 |
|          |                  |                  |                 |
|          v                  v                  v                 |
|    +----------+      +------------+      +------------+         |
|    | Simple   |      | Complex    |      | Creative   |         |
|    | Tasks    |      | Reasoning  |      | Tasks      |         |
|    +----------+      +------------+      +------------+         |
|          |                  |                  |                 |
|          v                  v                  v                 |
|    Gemini Flash      GPT-4/Claude 4      Claude Sonnet          |
|    GPT-4o-mini       Opus                GPT-4                   |
|    (Low cost)        (High capability)   (Balanced)             |
|                                                                  |
+------------------------------------------------------------------+
```

### 2. Cost Optimization Strategies

```python
# Strategy 1: Use smaller models for simple tasks
simple_chat = ChatOpenAI(model="gpt-4o-mini")  # $0.15/1M input tokens
complex_chat = ChatOpenAI(model="gpt-4o")       # $2.50/1M input tokens

# Strategy 2: Implement caching
from langchain.cache import InMemoryCache
from langchain.globals import set_llm_cache

set_llm_cache(InMemoryCache())

# Strategy 3: Limit output tokens
chat = ChatOpenAI(model="gpt-4o", max_tokens=500)

# Strategy 4: Use streaming for long outputs (better UX, same cost)
for chunk in chat.stream("Write an essay"):
    print(chunk.content, end="")
```

### 3. Error Handling

```python
from langchain_openai import ChatOpenAI
from langchain_core.runnables import RunnableWithFallbacks

# Primary and fallback models
primary = ChatOpenAI(model="gpt-4o")
fallback = ChatOpenAI(model="gpt-4o-mini")

# Automatic fallback on errors
robust_chain = primary.with_fallbacks([fallback])

try:
    response = robust_chain.invoke("Hello")
except Exception as e:
    print(f"All models failed: {e}")
```

### 4. Security Considerations

```python
# NEVER hardcode API keys
import os

# Good: Use environment variables
chat = ChatOpenAI(
    model="gpt-4o",
    api_key=os.environ.get("OPENAI_API_KEY")
)

# Good: Use .env files with python-dotenv
from dotenv import load_dotenv
load_dotenv()

# Bad: Hardcoded keys
# chat = ChatOpenAI(api_key="sk-abc123...")  # NEVER DO THIS
```

---

## Summary

- **LLMs** are neural networks trained on massive text data to understand and generate language
- **LangChain** provides a unified interface to work with multiple LLM providers
- **Chat Models** are the modern, preferred interface (vs legacy completion LLMs)
- **Key parameters**: temperature, max_tokens, context window
- **Choose models** based on task complexity, cost, and latency requirements
- **Always** use environment variables for API keys and implement error handling

---

## Next Steps

Continue to [02_chat_models.md](./02_chat_models.md) to learn about specific chat model implementations in LangChain.
