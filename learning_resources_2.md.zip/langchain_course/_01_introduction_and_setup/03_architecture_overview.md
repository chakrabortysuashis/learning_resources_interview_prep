# Module 01: LangChain Architecture Overview

## High-Level Architecture

LangChain follows a layered architecture designed for modularity, composability, 
and flexibility. Understanding this architecture will help you build better 
applications and troubleshoot issues.

```
+======================================================================+
||                     LangChain Architecture                         ||
+======================================================================+
|                                                                      |
|   +------------------------+    +------------------------+           |
|   |     LangSmith          |    |      LangGraph         |           |
|   |   (Observability)      |    |   (Orchestration)      |           |
|   +------------------------+    +------------------------+           |
|                     \                    /                           |
|                      \                  /                            |
|                       v                v                             |
|   +-------------------------------------------------------+          |
|   |                      langchain                        |          |
|   |   (High-level helpers: chains, agents, retrieval)     |          |
|   +-------------------------------------------------------+          |
|                              |                                       |
|                              v                                       |
|   +-------------------------------------------------------+          |
|   |                   langchain-core                      |          |
|   |   (Base abstractions, LCEL, Runnables)                |          |
|   +-------------------------------------------------------+          |
|           |              |              |              |             |
|           v              v              v              v             |
|   +-----------+  +-----------+  +-----------+  +-------------+       |
|   | langchain |  | langchain |  | langchain |  | langchain   |       |
|   | -openai   |  | -anthropic|  | -google   |  | -community  |       |
|   +-----------+  +-----------+  +-----------+  +-------------+       |
|           |              |              |              |             |
|           v              v              v              v             |
|   +-------------------------------------------------------+          |
|   |              External Services & APIs                 |          |
|   |   (OpenAI API, Claude API, Vector DBs, Tools, etc.)   |          |
|   +-------------------------------------------------------+          |
|                                                                      |
+======================================================================+
```

## Core Components Deep Dive

### The Runnable Interface

Everything in LangChain implements the `Runnable` interface. This is the 
foundational abstraction that enables composition.

```
+======================================================================+
||                    Runnable Interface                              ||
+======================================================================+
|                                                                      |
|                        +------------------+                          |
|                        |     Runnable     |                          |
|                        +------------------+                          |
|                        | invoke()         |  Single input/output     |
|                        | batch()          |  Multiple inputs         |
|                        | stream()         |  Streaming output        |
|                        | ainvoke()        |  Async invoke            |
|                        | abatch()         |  Async batch             |
|                        | astream()        |  Async stream            |
|                        +------------------+                          |
|                                 ^                                    |
|                                 |                                    |
|         +-----------------------+-----------------------+            |
|         |                       |                       |            |
|  +------+------+         +------+------+        +-------+-----+      |
|  | ChatModels  |         |   Prompts   |        |   Chains    |      |
|  +-------------+         +-------------+        +-------------+      |
|  | ChatOpenAI  |         | ChatPrompt  |        | LCEL Chain  |      |
|  | ChatAnthropic|        | FewShot     |        | Legacy Chain|      |
|  +-------------+         +-------------+        +-------------+      |
|                                                                      |
+======================================================================+
```

### LangChain Expression Language (LCEL)

LCEL is the modern way to compose chains. It uses the pipe (`|`) operator 
to connect components.

```
+======================================================================+
||                        LCEL Pipeline                               ||
+======================================================================+
|                                                                      |
|   Input                                                              |
|     |                                                                |
|     v                                                                |
|   +------------------+                                               |
|   |  PromptTemplate  |    "Tell me a joke about {topic}"             |
|   +------------------+                                               |
|     |                                                                |
|     | (formatted prompt)                                             |
|     v                                                                |
|   +------------------+                                               |
|   |    ChatModel     |    ChatOpenAI(model="gpt-4o-mini")            |
|   +------------------+                                               |
|     |                                                                |
|     | (AIMessage with content)                                       |
|     v                                                                |
|   +------------------+                                               |
|   |  OutputParser    |    StrOutputParser()                          |
|   +------------------+                                               |
|     |                                                                |
|     v                                                                |
|   Output (string)                                                    |
|                                                                      |
|   Code: chain = prompt | model | parser                              |
|                                                                      |
+======================================================================+
```

### Message Types

LangChain standardizes messages across all providers:

```
+======================================================================+
||                       Message Types                                ||
+======================================================================+
|                                                                      |
|   +------------------+    +------------------+                       |
|   |  SystemMessage   |    |  HumanMessage    |                       |
|   +------------------+    +------------------+                       |
|   | Sets the context |    | User input       |                       |
|   | and behavior     |    | and questions    |                       |
|   +------------------+    +------------------+                       |
|                                                                      |
|   +------------------+    +------------------+                       |
|   |   AIMessage      |    |   ToolMessage    |                       |
|   +------------------+    +------------------+                       |
|   | Model response   |    | Tool/function    |                       |
|   | and tool calls   |    | execution result |                       |
|   +------------------+    +------------------+                       |
|                                                                      |
|   Example Conversation:                                              |
|   +---------------------------------------------------------------+  |
|   | SystemMessage: "You are a helpful assistant."                 |  |
|   | HumanMessage: "What's the weather in NYC?"                    |  |
|   | AIMessage: [tool_call: get_weather(location="NYC")]           |  |
|   | ToolMessage: "72F, sunny"                                     |  |
|   | AIMessage: "The weather in NYC is 72F and sunny."             |  |
|   +---------------------------------------------------------------+  |
|                                                                      |
+======================================================================+
```

## Model Architecture

### Chat Models vs LLMs

```
+======================================================================+
||                  Model Types Comparison                            ||
+======================================================================+
|                                                                      |
|   +----------------------------+  +----------------------------+     |
|   |       Chat Models          |  |          LLMs              |     |
|   |       (Recommended)        |  |       (Legacy)             |     |
|   +----------------------------+  +----------------------------+     |
|   |                            |  |                            |     |
|   | Input: List[Message]       |  | Input: string              |     |
|   | Output: AIMessage          |  | Output: string             |     |
|   |                            |  |                            |     |
|   | - Structured conversation  |  | - Simple completion        |     |
|   | - Tool calling support     |  | - No message structure     |     |
|   | - System prompts           |  | - Being deprecated         |     |
|   |                            |  |                            |     |
|   | Examples:                  |  | Examples:                  |     |
|   | - ChatOpenAI               |  | - OpenAI (legacy)          |     |
|   | - ChatAnthropic            |  | - text-davinci-003         |     |
|   | - ChatGoogleGenerativeAI   |  |                            |     |
|   +----------------------------+  +----------------------------+     |
|                                                                      |
+======================================================================+
```

### Model Initialization Patterns

```
+======================================================================+
||                Model Initialization                                ||
+======================================================================+
|                                                                      |
|   Method 1: Direct Import (Most Common)                              |
|   +---------------------------------------------------------------+  |
|   | from langchain_openai import ChatOpenAI                       |  |
|   | model = ChatOpenAI(model="gpt-4o-mini")                       |  |
|   +---------------------------------------------------------------+  |
|                                                                      |
|   Method 2: Universal Initializer (Provider-Agnostic)                |
|   +---------------------------------------------------------------+  |
|   | from langchain.chat_models import init_chat_model             |  |
|   | model = init_chat_model("gpt-4o-mini", model_provider="openai")|  |
|   +---------------------------------------------------------------+  |
|                                                                      |
|   Method 3: With Configuration                                       |
|   +---------------------------------------------------------------+  |
|   | model = ChatOpenAI(                                           |  |
|   |     model="gpt-4o-mini",                                      |  |
|   |     temperature=0.7,                                          |  |
|   |     max_tokens=1000,                                          |  |
|   |     timeout=30,                                               |  |
|   |     max_retries=2                                             |  |
|   | )                                                             |  |
|   +---------------------------------------------------------------+  |
|                                                                      |
+======================================================================+
```

## Prompt Architecture

### Prompt Template Hierarchy

```
+======================================================================+
||                  Prompt Template Types                             ||
+======================================================================+
|                                                                      |
|                    +---------------------+                           |
|                    |   BasePromptTemplate|                           |
|                    +---------------------+                           |
|                             ^                                        |
|                             |                                        |
|           +-----------------+-----------------+                      |
|           |                                   |                      |
|  +--------+--------+              +-----------+-----------+          |
|  | PromptTemplate  |              | ChatPromptTemplate    |          |
|  | (String output) |              | (Message list output) |          |
|  +-----------------+              +-----------------------+          |
|                                              ^                       |
|                                              |                       |
|                               +--------------+--------------+        |
|                               |                             |        |
|                    +----------+----------+     +------------+------+ |
|                    | FewShotPromptTemplate|    | PipelinePrompt    | |
|                    +---------------------+     +--------------+----+ |
|                                                                      |
+======================================================================+
```

### ChatPromptTemplate Structure

```
+======================================================================+
||                ChatPromptTemplate Components                       ||
+======================================================================+
|                                                                      |
|   ChatPromptTemplate.from_messages([                                 |
|       +----------------------------------------------------------+   |
|       | ("system", "You are a {role}. {instructions}")           |   |
|       +----------------------------------------------------------+   |
|                                 |                                    |
|       +----------------------------------------------------------+   |
|       | ("human", "{user_input}")                                |   |
|       +----------------------------------------------------------+   |
|                                 |                                    |
|       +----------------------------------------------------------+   |
|       | ("ai", "Previous response...")  # Optional history       |   |
|       +----------------------------------------------------------+   |
|   ])                                                                 |
|                                                                      |
|   Variables: {role}, {instructions}, {user_input}                    |
|                                                                      |
|   Usage:                                                             |
|   prompt.invoke({                                                    |
|       "role": "helpful assistant",                                   |
|       "instructions": "Be concise.",                                 |
|       "user_input": "What is LangChain?"                             |
|   })                                                                 |
|                                                                      |
+======================================================================+
```

## Chain Architecture

### LCEL vs Legacy Chains

```
+======================================================================+
||                      Chain Comparison                              ||
+======================================================================+
|                                                                      |
|   LCEL (Modern - Recommended)         Legacy (Being Deprecated)      |
|   +---------------------------+       +---------------------------+  |
|   |                           |       |                           |  |
|   | chain = (                 |       | from langchain.chains     |  |
|   |     prompt                |       |   import LLMChain         |  |
|   |     | model               |       |                           |  |
|   |     | parser              |       | chain = LLMChain(         |  |
|   | )                         |       |     llm=model,            |  |
|   |                           |       |     prompt=prompt         |  |
|   | # Composable              |       | )                         |  |
|   | # Streaming built-in      |       |                           |  |
|   | # Type hints work         |       | # Less flexible           |  |
|   |                           |       | # Harder to customize     |  |
|   +---------------------------+       +---------------------------+  |
|                                                                      |
+======================================================================+
```

### Complex LCEL Patterns

```
+======================================================================+
||                    LCEL Patterns                                   ||
+======================================================================+
|                                                                      |
|   1. Sequential Chain                                                |
|   +---------------------------------------------------------------+  |
|   |   chain = prompt1 | model | parser | prompt2 | model | parser |  |
|   +---------------------------------------------------------------+  |
|                                                                      |
|   2. Parallel Execution (RunnableParallel)                           |
|   +---------------------------------------------------------------+  |
|   |                    +----------+                               |  |
|   |                    |  Input   |                               |  |
|   |                    +----+-----+                               |  |
|   |                         |                                     |  |
|   |           +-------------+-------------+                       |  |
|   |           |                           |                       |  |
|   |     +-----v-----+               +-----v-----+                 |  |
|   |     |  Branch A |               |  Branch B |                 |  |
|   |     +-----------+               +-----------+                 |  |
|   |           |                           |                       |  |
|   |           +-------------+-------------+                       |  |
|   |                         |                                     |  |
|   |                   +-----v-----+                               |  |
|   |                   |  Combine  |                               |  |
|   |                   +-----------+                               |  |
|   +---------------------------------------------------------------+  |
|                                                                      |
|   Code:                                                              |
|   from langchain_core.runnables import RunnableParallel              |
|                                                                      |
|   chain = RunnableParallel(                                          |
|       summary=prompt1 | model,                                       |
|       translation=prompt2 | model                                    |
|   )                                                                  |
|                                                                      |
|   3. Conditional Routing (RunnableBranch)                            |
|   +---------------------------------------------------------------+  |
|   |                    +----------+                               |  |
|   |                    |  Input   |                               |  |
|   |                    +----+-----+                               |  |
|   |                         |                                     |  |
|   |                   +-----v-----+                               |  |
|   |                   | Condition |                               |  |
|   |                   +-----+-----+                               |  |
|   |                         |                                     |  |
|   |              +----------+----------+                          |  |
|   |              |                     |                          |  |
|   |        +-----v-----+         +-----v-----+                    |  |
|   |        |  True     |         |  False    |                    |  |
|   |        +-----------+         +-----------+                    |  |
|   +---------------------------------------------------------------+  |
|                                                                      |
+======================================================================+
```

## Retrieval Architecture (RAG)

### RAG Pipeline

```
+======================================================================+
||                    RAG Architecture                                ||
+======================================================================+
|                                                                      |
|   +----------------+                                                 |
|   |   Documents    |  (PDFs, web pages, databases, etc.)             |
|   +-------+--------+                                                 |
|           |                                                          |
|           v                                                          |
|   +-------+--------+                                                 |
|   | Document Loader|  (PyPDFLoader, WebBaseLoader, etc.)             |
|   +-------+--------+                                                 |
|           |                                                          |
|           v                                                          |
|   +-------+--------+                                                 |
|   | Text Splitter  |  (RecursiveCharacterTextSplitter)               |
|   +-------+--------+                                                 |
|           |                                                          |
|           | chunks                                                   |
|           v                                                          |
|   +-------+--------+                                                 |
|   | Embedding Model|  (OpenAIEmbeddings, etc.)                       |
|   +-------+--------+                                                 |
|           |                                                          |
|           | vectors                                                  |
|           v                                                          |
|   +-------+--------+                                                 |
|   |  Vector Store  |  (FAISS, Chroma, Pinecone, etc.)                |
|   +-------+--------+                                                 |
|           |                                                          |
|           | similar docs                                             |
|           v                                                          |
|   +-------+--------+        +----------------+                       |
|   |   Retriever    | <------|     Query      |                       |
|   +-------+--------+        +----------------+                       |
|           |                                                          |
|           | context                                                  |
|           v                                                          |
|   +------------------+                                               |
|   |      LLM         |  Generate answer with context                 |
|   +------------------+                                               |
|           |                                                          |
|           v                                                          |
|   +------------------+                                               |
|   |     Response     |                                               |
|   +------------------+                                               |
|                                                                      |
+======================================================================+
```

### RAG Chain with LCEL

```python
# RAG Chain Architecture in Code

from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_community.vectorstores import FAISS

# Components
embeddings = OpenAIEmbeddings()
vectorstore = FAISS.from_texts(texts, embeddings)
retriever = vectorstore.as_retriever()
model = ChatOpenAI()

prompt = ChatPromptTemplate.from_template("""
Answer based on the context:
Context: {context}
Question: {question}
""")

# RAG Chain
chain = (
    {"context": retriever, "question": RunnablePassthrough()}
    | prompt
    | model
)
```

## Agent Architecture

### Tool-Calling Flow

```
+======================================================================+
||                    Agent Architecture                              ||
+======================================================================+
|                                                                      |
|   User Query                                                         |
|       |                                                              |
|       v                                                              |
|   +-------------------+                                              |
|   |      Agent        |                                              |
|   | (LLM + Tools)     |                                              |
|   +-------------------+                                              |
|       |                                                              |
|       | Reason about query                                           |
|       v                                                              |
|   +-------------------+        +-------------------+                 |
|   | Decision Point    | ------>| Direct Response   |                 |
|   | Need tool?        |   No   | (no tool needed)  |                 |
|   +-------------------+        +-------------------+                 |
|       | Yes                                                          |
|       v                                                              |
|   +-------------------+                                              |
|   |  Select Tool      |                                              |
|   |  + Arguments      |                                              |
|   +-------------------+                                              |
|       |                                                              |
|       v                                                              |
|   +-------------------+                                              |
|   |  Execute Tool     |                                              |
|   +-------------------+                                              |
|       |                                                              |
|       | Tool result                                                  |
|       v                                                              |
|   +-------------------+                                              |
|   | Process Result    |--+                                           |
|   | More tools needed?|  |                                           |
|   +-------------------+  | Yes (loop back)                           |
|       |                  |                                           |
|       | No               |                                           |
|       v                  |                                           |
|   +-------------------+  |                                           |
|   | Final Response    |<-+                                           |
|   +-------------------+                                              |
|                                                                      |
+======================================================================+
```

### Tool Definition

```
+======================================================================+
||                      Tool Structure                                ||
+======================================================================+
|                                                                      |
|   +---------------------------------------------------------------+  |
|   |                         Tool                                  |  |
|   +---------------------------------------------------------------+  |
|   | name: str              # Unique identifier                    |  |
|   | description: str       # What the tool does (for LLM)         |  |
|   | args_schema: BaseModel # Pydantic model for arguments         |  |
|   | func: Callable         # The actual function to run           |  |
|   +---------------------------------------------------------------+  |
|                                                                      |
|   Example:                                                           |
|   +---------------------------------------------------------------+  |
|   | @tool                                                         |  |
|   | def search_web(query: str) -> str:                            |  |
|   |     """Search the web for current information."""             |  |
|   |     # implementation                                          |  |
|   |     return results                                            |  |
|   +---------------------------------------------------------------+  |
|                                                                      |
+======================================================================+
```

## Memory Architecture

### Memory Types

```
+======================================================================+
||                    Memory Types                                    ||
+======================================================================+
|                                                                      |
|   +----------------------------+                                     |
|   |   ConversationBuffer       |    Stores all messages              |
|   |   Memory                   |    (Simple but grows large)         |
|   +----------------------------+                                     |
|                                                                      |
|   +----------------------------+                                     |
|   |   ConversationSummary      |    Summarizes old messages          |
|   |   Memory                   |    (Constant size, loses detail)    |
|   +----------------------------+                                     |
|                                                                      |
|   +----------------------------+                                     |
|   |   ConversationBuffer       |    Keeps last K messages            |
|   |   WindowMemory             |    (Fixed size, drops old)          |
|   +----------------------------+                                     |
|                                                                      |
|   +----------------------------+                                     |
|   |   EntityMemory             |    Tracks entities mentioned        |
|   |                            |    (Good for entity-focused apps)   |
|   +----------------------------+                                     |
|                                                                      |
|   Modern Approach (LangGraph):                                       |
|   +----------------------------+                                     |
|   |   State Management         |    Explicit state in graph          |
|   |   with Checkpointing       |    (Most flexible and scalable)     |
|   +----------------------------+                                     |
|                                                                      |
+======================================================================+
```

## Package Dependencies

### Dependency Graph

```
+======================================================================+
||                  Package Dependencies                              ||
+======================================================================+
|                                                                      |
|                         langsmith                                    |
|                            ^                                         |
|                            | (optional)                              |
|                            |                                         |
|   langgraph -------> langchain -------> langchain-core               |
|                            |                 ^                       |
|                            |                 |                       |
|                            v                 |                       |
|                   langchain-community        |                       |
|                            |                 |                       |
|                            v                 |                       |
|                   +-----------------+        |                       |
|                   | Provider Pkgs   |--------+                       |
|                   +-----------------+                                |
|                   | langchain-openai|                                |
|                   | langchain-anthropic                              |
|                   | langchain-google-genai                           |
|                   | etc.            |                                |
|                   +-----------------+                                |
|                            |                                         |
|                            v                                         |
|                   +-----------------+                                |
|                   | Provider SDKs   |                                |
|                   +-----------------+                                |
|                   | openai          |                                |
|                   | anthropic       |                                |
|                   | google-generativeai                              |
|                   +-----------------+                                |
|                                                                      |
+======================================================================+
```

## Data Flow Summary

```
+======================================================================+
||                Complete Data Flow                                  ||
+======================================================================+
|                                                                      |
|   User Input                                                         |
|       |                                                              |
|       +----> [Prompt Template] ----> Formatted Messages              |
|                                           |                          |
|                                           v                          |
|                                    [Chat Model] <---- API Key        |
|                                           |                          |
|                   +------- Tool Call? ----+---- No ----+             |
|                   |                                    |             |
|                   v                                    |             |
|              [Tool Execution]                          |             |
|                   |                                    |             |
|                   v                                    v             |
|              Tool Result ----> [Model Again] <------- |              |
|                                      |                               |
|                                      v                               |
|                              [Output Parser]                         |
|                                      |                               |
|                                      v                               |
|                              Structured Output                       |
|                                      |                               |
|                                      v                               |
|   Optional: +---- [Memory Store] <---+                               |
|             |                                                        |
|             +---> [LangSmith Trace]                                  |
|                                                                      |
+======================================================================+
```

## Summary

LangChain's architecture is built on these key principles:

1. **Composability**: The Runnable interface enables mixing and matching components
2. **Provider Agnosticism**: Core abstractions work with any LLM provider
3. **Modularity**: Install only what you need
4. **Extensibility**: Easy to add custom components
5. **Observability**: Built-in tracing via LangSmith

Understanding this architecture helps you:
- Choose the right components for your use case
- Debug issues by understanding data flow
- Extend LangChain with custom implementations
- Optimize performance by knowing where bottlenecks occur

---

## Sources

- [LangChain Core Architecture Explained](https://apxml.com/courses/building-llm-apps-with-langchain/chapter-1-intro-to-langchain-framework/langchain-core-architecture)
- [The New LangChain Architecture](https://www.langchain.com/blog/the-new-langchain-architecture-langchain-core-v0-1-langchain-community-and-a-path-to-langchain-v0-1)
- [The Complete LangChain Ecosystem - GeeksforGeeks](https://www.geeksforgeeks.org/artificial-intelligence/the-complete-langchain-ecosystem/)
- [LangChain Python API Reference](https://python.langchain.com/api_reference)

---

**Previous: [02_installation_guide.md](02_installation_guide.md)** | **Next: [04_first_langchain_app.ipynb](04_first_langchain_app.ipynb)**
