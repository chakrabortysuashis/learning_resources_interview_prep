# Module 01: Installation Guide

## Prerequisites

Before installing LangChain, ensure you have the following:

```
+------------------------------------------------------------------+
|                       Prerequisites                              |
+------------------------------------------------------------------+
|                                                                  |
|  +-------------------+    +-------------------+                  |
|  |  Python 3.9+      |    |  pip 21.0+        |                  |
|  |  (3.11 or 3.12    |    |  (or poetry/uv)   |                  |
|  |   recommended)    |    |                   |                  |
|  +-------------------+    +-------------------+                  |
|                                                                  |
|  +-------------------+    +-------------------+                  |
|  |  Virtual Env      |    |  API Keys         |                  |
|  |  (venv, conda,    |    |  (OpenAI, Claude, |                  |
|  |   poetry)         |    |   etc.)           |                  |
|  +-------------------+    +-------------------+                  |
|                                                                  |
+------------------------------------------------------------------+
```

> **Note**: Python 3.8 reached end-of-life in October 2024 and is no longer 
> supported by LangChain 0.3.x.

## Quick Start Installation

### Step 1: Create a Virtual Environment

```bash
# Create a new directory for your project
mkdir langchain-project
cd langchain-project

# Create a virtual environment
python -m venv venv

# Activate the virtual environment
# On Windows:
venv\Scripts\activate

# On macOS/Linux:
source venv/bin/activate
```

### Step 2: Install LangChain Core Packages

```bash
# Install the main langchain package
pip install langchain

# This automatically installs:
# - langchain-core
# - langchain-text-splitters
# - Other core dependencies
```

### Step 3: Install Provider Package(s)

Install the package for your LLM provider:

```bash
# For OpenAI (GPT-4, GPT-3.5, etc.)
pip install langchain-openai

# For Anthropic (Claude)
pip install langchain-anthropic

# For Google (Gemini)
pip install langchain-google-genai

# For local models via Ollama
pip install langchain-ollama

# For AWS Bedrock
pip install langchain-aws

# For HuggingFace
pip install langchain-huggingface
```

## Installation Options

### Option A: Minimal Installation

For basic LLM interactions only:

```bash
pip install langchain-core langchain-openai
```

This gives you:
- Core abstractions
- OpenAI model support
- LCEL (LangChain Expression Language)

### Option B: Standard Installation

For most use cases including chains and retrieval:

```bash
pip install langchain langchain-openai langchain-community
```

This adds:
- Pre-built chains
- Retrieval helpers
- Community integrations

### Option C: Full Installation

For all features including agents and vector stores:

```bash
pip install langchain langchain-openai langchain-community langgraph
```

This adds:
- LangGraph for stateful agents
- Complex workflow support

## Environment-Specific Setup

### Using Conda

```bash
# Create a new conda environment
conda create -n langchain-env python=3.11
conda activate langchain-env

# Install LangChain
pip install langchain langchain-openai
```

### Using Poetry

```bash
# Initialize a new project
poetry init

# Add LangChain dependencies
poetry add langchain langchain-openai

# If you need development tools
poetry add --group dev pytest jupyter ipykernel
```

### Using uv (Fast Python Package Installer)

```bash
# Create a new project
uv init langchain-project
cd langchain-project

# Add dependencies
uv add langchain langchain-openai
```

## API Key Setup

### Understanding API Keys

```
+------------------------------------------------------------------+
|                    API Key Flow                                  |
+------------------------------------------------------------------+
|                                                                  |
|    Your Code                                                     |
|        |                                                         |
|        v                                                         |
|    +-------------------+                                         |
|    | LangChain reads   |                                         |
|    | environment       |                                         |
|    | variables         |                                         |
|    +-------------------+                                         |
|        |                                                         |
|        v                                                         |
|    +-------------------+                                         |
|    | Provider SDK      |                                         |
|    | authenticates     |                                         |
|    +-------------------+                                         |
|        |                                                         |
|        v                                                         |
|    +-------------------+                                         |
|    | LLM Provider API  |                                         |
|    | (OpenAI, Claude)  |                                         |
|    +-------------------+                                         |
|                                                                  |
+------------------------------------------------------------------+
```

### Setting Environment Variables

#### Method 1: Using .env File (Recommended)

Create a `.env` file in your project root:

```bash
# .env file
OPENAI_API_KEY=sk-your-openai-key-here
ANTHROPIC_API_KEY=sk-ant-your-anthropic-key-here
GOOGLE_API_KEY=your-google-key-here
LANGSMITH_API_KEY=your-langsmith-key-here
```

Load the environment variables in your code:

```python
# Install python-dotenv
# pip install python-dotenv

from dotenv import load_dotenv
import os

# Load environment variables from .env file
load_dotenv()

# Now you can use the keys
openai_key = os.getenv("OPENAI_API_KEY")
```

> **IMPORTANT**: Add `.env` to your `.gitignore` file to prevent 
> accidentally committing API keys!

```bash
# .gitignore
.env
.env.local
*.env
```

#### Method 2: System Environment Variables

**Windows (PowerShell):**
```powershell
$env:OPENAI_API_KEY = "sk-your-key-here"
# Or permanently:
[Environment]::SetEnvironmentVariable("OPENAI_API_KEY", "sk-your-key-here", "User")
```

**Windows (Command Prompt):**
```cmd
set OPENAI_API_KEY=sk-your-key-here
# Or permanently via System Properties > Environment Variables
```

**macOS/Linux:**
```bash
export OPENAI_API_KEY="sk-your-key-here"

# Add to ~/.bashrc or ~/.zshrc for persistence:
echo 'export OPENAI_API_KEY="sk-your-key-here"' >> ~/.bashrc
source ~/.bashrc
```

#### Method 3: Pass Keys Directly (Not Recommended for Production)

```python
from langchain_openai import ChatOpenAI

# Direct key passing (avoid in production)
model = ChatOpenAI(
    model="gpt-4o-mini",
    api_key="sk-your-key-here"  # Not recommended!
)
```

### Getting API Keys

| Provider | Where to Get | Environment Variable |
|----------|--------------|---------------------|
| OpenAI | [platform.openai.com/api-keys](https://platform.openai.com/api-keys) | `OPENAI_API_KEY` |
| Anthropic | [console.anthropic.com](https://console.anthropic.com) | `ANTHROPIC_API_KEY` |
| Google | [aistudio.google.com](https://aistudio.google.com/app/apikey) | `GOOGLE_API_KEY` |
| LangSmith | [smith.langchain.com](https://smith.langchain.com) | `LANGSMITH_API_KEY` |
| HuggingFace | [huggingface.co/settings/tokens](https://huggingface.co/settings/tokens) | `HUGGINGFACEHUB_API_TOKEN` |

## Jupyter Notebook Setup

### Installing Jupyter

```bash
# Install Jupyter
pip install jupyter ipykernel

# Register your virtual environment as a Jupyter kernel
python -m ipykernel install --user --name=langchain-env --display-name="LangChain Env"

# Start Jupyter
jupyter notebook
```

### VS Code Setup

1. Install the "Jupyter" extension in VS Code
2. Create a new `.ipynb` file
3. Select your virtual environment kernel
4. Start coding!

## Verifying Installation

Run this script to verify everything is working:

```python
# verify_installation.py

import sys
print(f"Python version: {sys.version}")

# Check core packages
try:
    import langchain
    print(f"langchain version: {langchain.__version__}")
except ImportError:
    print("langchain not installed")

try:
    import langchain_core
    print(f"langchain-core version: {langchain_core.__version__}")
except ImportError:
    print("langchain-core not installed")

# Check provider packages
try:
    import langchain_openai
    print(f"langchain-openai version: {langchain_openai.__version__}")
except ImportError:
    print("langchain-openai not installed")

try:
    import langchain_anthropic
    print(f"langchain-anthropic version: {langchain_anthropic.__version__}")
except ImportError:
    print("langchain-anthropic not installed (optional)")

# Check environment variables
import os
providers = [
    ("OPENAI_API_KEY", "OpenAI"),
    ("ANTHROPIC_API_KEY", "Anthropic"),
    ("GOOGLE_API_KEY", "Google"),
]

print("\nAPI Key Status:")
for env_var, provider in providers:
    status = "Set" if os.getenv(env_var) else "Not set"
    print(f"  {provider}: {status}")
```

## Common Installation Issues

### Issue 1: Pydantic Version Conflicts

**Symptom**: `ValidationError` or import errors related to Pydantic

**Solution**:
```bash
# LangChain 0.3.x requires Pydantic v2
pip install "pydantic>=2.0,<3.0"

# Check for conflicting packages
pip list | grep pydantic
```

### Issue 2: Old pip Version

**Symptom**: Dependency resolution errors

**Solution**:
```bash
# Upgrade pip
python -m pip install --upgrade pip

# Also upgrade setuptools
pip install --upgrade setuptools wheel
```

### Issue 3: SSL Certificate Errors

**Symptom**: `CERTIFICATE_VERIFY_FAILED` errors

**Solution**:
```bash
# On macOS, run:
/Applications/Python\ 3.11/Install\ Certificates.command

# Or install certifi
pip install --upgrade certifi
```

### Issue 4: Import Errors After Installation

**Symptom**: `ModuleNotFoundError: No module named 'langchain'`

**Solution**:
```bash
# Ensure you're in the right virtual environment
which python  # Should point to your venv

# Reinstall
pip uninstall langchain langchain-core
pip install langchain
```

### Issue 5: Provider Package Not Found

**Symptom**: `ImportError: cannot import name 'ChatOpenAI' from 'langchain'`

**Solution**:
```python
# OLD (deprecated in 0.2+)
from langchain.chat_models import ChatOpenAI  # Wrong!

# NEW (correct)
from langchain_openai import ChatOpenAI  # Correct!
```

## Package Compatibility Matrix

```
+------------------------------------------------------------------+
|                 Compatibility Matrix                             |
+------------------------------------------------------------------+
|                                                                  |
|  LangChain Version    Python    Pydantic    Notes                |
|  ------------------   -------   ---------   ------------------   |
|  0.3.x (current)      3.9+      v2 only     Python 3.8 dropped   |
|  0.2.x                3.8+      v1 & v2     Deprecation warnings |
|  0.1.x                3.8+      v1 & v2     Package split        |
|  0.0.x (legacy)       3.8+      v1          Monolithic package   |
|                                                                  |
+------------------------------------------------------------------+
```

## Development Environment Recommendations

### Recommended Project Structure

```
langchain-project/
+-- .env                    # API keys (gitignored)
+-- .gitignore              # Git ignore rules
+-- requirements.txt        # Dependencies
+-- pyproject.toml          # Project config (if using Poetry)
+-- README.md               # Project documentation
+-- src/
|   +-- __init__.py
|   +-- chains/
|   +-- agents/
|   +-- tools/
+-- notebooks/
|   +-- experiments.ipynb
+-- tests/
    +-- test_chains.py
```

### Sample requirements.txt

```txt
# Core LangChain packages
langchain>=0.3.0
langchain-core>=0.3.0
langchain-community>=0.3.0

# Provider packages (choose what you need)
langchain-openai>=0.2.0
langchain-anthropic>=0.2.0

# Orchestration
langgraph>=0.2.0

# Utilities
python-dotenv>=1.0.0

# For Jupyter notebooks
jupyter>=1.0.0
ipykernel>=6.0.0

# For development
pytest>=8.0.0
black>=24.0.0
```

### Installing from requirements.txt

```bash
pip install -r requirements.txt
```

## Offline/Air-Gapped Installation

For environments without internet access:

```bash
# On a machine with internet, download packages
pip download langchain langchain-openai -d ./packages

# Transfer the packages folder to the offline machine

# Install from local packages
pip install --no-index --find-links=./packages langchain langchain-openai
```

## Docker Setup

### Basic Dockerfile

```dockerfile
FROM python:3.11-slim

WORKDIR /app

# Copy requirements
COPY requirements.txt .

# Install dependencies
RUN pip install --no-cache-dir -r requirements.txt

# Copy application code
COPY . .

# Run the application
CMD ["python", "main.py"]
```

### Docker Compose with Environment Variables

```yaml
# docker-compose.yml
version: '3.8'

services:
  langchain-app:
    build: .
    environment:
      - OPENAI_API_KEY=${OPENAI_API_KEY}
      - ANTHROPIC_API_KEY=${ANTHROPIC_API_KEY}
    volumes:
      - .:/app
```

## Summary Checklist

```
+------------------------------------------------------------------+
|                Installation Checklist                            |
+------------------------------------------------------------------+
|                                                                  |
|  [ ] Python 3.9+ installed                                       |
|  [ ] Virtual environment created and activated                   |
|  [ ] pip upgraded to latest version                              |
|  [ ] langchain package installed                                 |
|  [ ] At least one provider package installed                     |
|  [ ] .env file created with API keys                             |
|  [ ] .gitignore updated to exclude .env                          |
|  [ ] python-dotenv installed for loading .env                    |
|  [ ] Jupyter kernel registered (if using notebooks)              |
|  [ ] Installation verified with test script                      |
|                                                                  |
+------------------------------------------------------------------+
```

---

## Sources

- [Install LangChain - Official Docs](https://docs.langchain.com/oss/python/langchain/install)
- [How to Install LangChain: Complete Python Setup Guide](https://latenode.com/blog/ai-frameworks-technical-infrastructure/langchain-setup-tools-agents-memory/how-to-install-langchain-complete-python-setup-guide-troubleshooting-2025)
- [Announcing LangChain v0.3](https://blog.langchain.com/announcing-langchain-v0-3/)
- [LangChain Python API Reference](https://python.langchain.com/api_reference)

---

**Previous: [01_what_is_langchain.md](01_what_is_langchain.md)** | **Next: [03_architecture_overview.md](03_architecture_overview.md)**
