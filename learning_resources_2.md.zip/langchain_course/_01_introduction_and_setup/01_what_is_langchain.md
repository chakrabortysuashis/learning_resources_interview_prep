# Module 01: What is LangChain?

## Overview

LangChain is an open-source framework designed to simplify the development of applications
powered by Large Language Models (LLMs). It provides a standardized interface for working
with various AI models and tools, making it easier to build context-aware reasoning
applications.

```
+------------------------------------------------------------------+
|                         LangChain                                |
|                                                                  |
|   "A framework for developing applications powered by LLMs"      |
|                                                                  |
|   +------------------+  +------------------+  +----------------+ |
|   |   LLM Providers  |  |   Data Sources   |  |     Tools      | |
|   |  (OpenAI, Claude |  |  (Documents,     |  |  (Search, APIs,| |
|   |   Gemini, etc.)  |  |   Databases)     |  |   Calculators) | |
|   +--------+---------+  +--------+---------+  +-------+--------+ |
|            |                     |                    |          |
|            +---------------------+--------------------+          |
|                                  |                               |
|                    +-------------v--------------+                |
|                    |    Your Application        |                |
|                    |  (Chatbots, Agents, RAG)   |                |
|                    +----------------------------+                |
+------------------------------------------------------------------+
```

## Why LangChain?

### The Problem LangChain Solves

Building LLM applications involves many challenges:

1. **Model Abstraction**: Different LLM providers have different APIs
2. **Context Management**: LLMs have token limits and need context optimization
3. **Tool Integration**: Connecting LLMs with external tools and data sources
4. **Memory**: Maintaining conversation history across interactions
5. **Orchestration**: Chaining multiple LLM calls and operations together

### How LangChain Helps

```
WITHOUT LangChain:                    WITH LangChain:
+------------------+                  +------------------+
|  OpenAI API      |                  |                  |
+------------------+                  |   LangChain      |
|  Different code  |                  |   Unified API    |
+------------------+                  |                  |
                                      |  model = init_   |
+------------------+                  |  chat_model(     |
|  Anthropic API   |                  |    "openai",     |
+------------------+                  |    model="gpt-4" |
|  Different code  |                  |  )               |
+------------------+                  |                  |
                                      |  # Same code     |
+------------------+                  |  # works for     |
|  Google API      |                  |  # any provider  |
+------------------+                  +------------------+
|  Different code  |
+------------------+
```

## The LangChain Ecosystem

LangChain is organized into several packages, each serving a specific purpose:

```
+------------------------------------------------------------------+
|                    LangChain Ecosystem                           |
+------------------------------------------------------------------+
|                                                                  |
|  +-------------------------+                                     |
|  |    langchain-core       |  <-- Base abstractions & LCEL       |
|  |  (Foundation Layer)     |      (LangChain Expression Lang)    |
|  +-------------------------+                                     |
|              ^                                                   |
|              |                                                   |
|  +-----------+-------------+------------+                        |
|  |           |             |            |                        |
|  v           v             v            v                        |
|  +--------+  +-----------+ +----------+ +------------+           |
|  |langchn |  |langchain- | |langchain-| |langchain-  |           |
|  |        |  |openai     | |anthropic | |community   |           |
|  +--------+  +-----------+ +----------+ +------------+           |
|  High-level  Provider      Provider     Third-party              |
|  helpers     package       package      integrations             |
|                                                                  |
|  +-------------------------+                                     |
|  |       LangGraph         |  <-- Orchestration framework        |
|  |  (Stateful workflows)   |      for complex agents             |
|  +-------------------------+                                     |
|                                                                  |
|  +-------------------------+                                     |
|  |       LangSmith         |  <-- Observability & evaluation     |
|  |  (Debugging & tracing)  |      platform                       |
|  +-------------------------+                                     |
|                                                                  |
+------------------------------------------------------------------+
```

### Package Breakdown

#### 1. langchain-core

The foundation of the ecosystem. Contains:

- **Base abstractions**: Chat models, embeddings, vector stores, retrievers
- **LangChain Expression Language (LCEL)**: A declarative way to compose chains
- **Messages**: Standardized message formats (Human, AI, System, Tool)
- **Output parsers**: Convert LLM outputs to structured data

```python
# langchain-core provides these base classes
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
```

#### 2. langchain

The main package providing high-level helpers:

- **Chains**: Pre-built sequences of LLM operations
- **Agents**: Autonomous systems that can use tools
- **Retrieval helpers**: RAG (Retrieval Augmented Generation) utilities
- **init_chat_model**: Universal model initialization

```python
# langchain provides orchestration helpers
from langchain.chains import LLMChain
from langchain.agents import create_tool_calling_agent
```

#### 3. Provider Packages

Lightweight, vendor-specific packages:

| Package | Provider | Purpose |
|---------|----------|---------|
| `langchain-openai` | OpenAI | GPT models, embeddings |
| `langchain-anthropic` | Anthropic | Claude models |
| `langchain-google-genai` | Google | Gemini models |
| `langchain-aws` | AWS | Bedrock, S3 |
| `langchain-huggingface` | HuggingFace | Open-source models |
| `langchain-pinecone` | Pinecone | Vector database |
| `langchain-chroma` | Chroma | Vector database |

```python
# Each provider has its own package
from langchain_openai import ChatOpenAI
from langchain_anthropic import ChatAnthropic
from langchain_google_genai import ChatGoogleGenerativeAI
```

#### 4. langchain-community

The catch-all package for community-maintained integrations:

- Document loaders (PDF, HTML, CSV, etc.)
- Vector stores
- Tools and toolkits
- Retrievers
- Niche integrations

```python
# Community integrations
from langchain_community.document_loaders import PyPDFLoader
from langchain_community.vectorstores import FAISS
from langchain_community.tools import DuckDuckGoSearchRun
```

#### 5. LangGraph

Orchestration framework for building stateful applications:

- Multi-agent systems
- Complex workflows with cycles
- Human-in-the-loop interactions
- Persistent state management

```python
from langgraph.graph import StateGraph
from langgraph.prebuilt import create_react_agent
```

#### 6. LangSmith

Observability and evaluation platform:

- Trace LLM calls
- Debug chains and agents
- Run evaluations
- Monitor production applications

## Core Components

LangChain applications are built from six primary component categories:

```
+------------------------------------------------------------------+
|                     Core Components                              |
+------------------------------------------------------------------+
|                                                                  |
|  1. MODELS           2. PROMPTS          3. CHAINS               |
|  +-------------+     +-------------+     +-------------+         |
|  | LLMs        |     | Templates   |     | Sequential  |         |
|  | Chat Models |     | Few-shot    |     | Router      |         |
|  | Embeddings  |     | Selectors   |     | Transform   |         |
|  +-------------+     +-------------+     +-------------+         |
|                                                                  |
|  4. RETRIEVAL        5. MEMORY           6. AGENTS               |
|  +-------------+     +-------------+     +-------------+         |
|  | Loaders     |     | Buffer      |     | Tools       |         |
|  | Splitters   |     | Summary     |     | Toolkits    |         |
|  | Vector DBs  |     | Entity      |     | Executors   |         |
|  +-------------+     +-------------+     +-------------+         |
|                                                                  |
+------------------------------------------------------------------+
```

### 1. Models

The AI models that power your application:

- **LLMs**: Text completion models
- **Chat Models**: Conversational models (most commonly used)
- **Embeddings**: Convert text to numerical vectors

### 2. Prompts

Templates and tools for constructing inputs:

- **Prompt Templates**: Reusable prompt structures with variables
- **Few-shot Prompts**: Include examples in prompts
- **Example Selectors**: Dynamically choose relevant examples

### 3. Chains

Sequences of operations:

- **LCEL Chains**: Modern, declarative composition
- **Legacy Chains**: Pre-built chain classes (being deprecated)

### 4. Retrieval

Connect LLMs to your data:

- **Document Loaders**: Load data from various sources
- **Text Splitters**: Break documents into chunks
- **Vector Stores**: Store and search embeddings
- **Retrievers**: Fetch relevant documents

### 5. Memory

Maintain context across interactions:

- **Conversation Buffer**: Store full conversation history
- **Conversation Summary**: Summarize past interactions
- **Entity Memory**: Track specific entities mentioned

### 6. Agents

Autonomous systems that decide actions:

- **Tools**: Functions the agent can call
- **Toolkits**: Collections of related tools
- **Agent Executors**: Run agent loops

## Key Concepts

### LangChain Expression Language (LCEL)

LCEL is a declarative way to compose chains using the pipe (`|`) operator:

```python
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_openai import ChatOpenAI

# Create a simple chain with LCEL
prompt = ChatPromptTemplate.from_template("Tell me a joke about {topic}")
model = ChatOpenAI(model="gpt-4o-mini")
output_parser = StrOutputParser()

# Compose with the pipe operator
chain = prompt | model | output_parser

# Run the chain
result = chain.invoke({"topic": "programming"})
```

### Runnable Interface

All LangChain components implement a standard `Runnable` interface:

```
+------------------------------------------------------------------+
|                    Runnable Interface                            |
+------------------------------------------------------------------+
|                                                                  |
|   invoke(input)          -> Single input, single output          |
|   batch([inputs])        -> Multiple inputs, multiple outputs    |
|   stream(input)          -> Single input, streaming output       |
|   ainvoke(input)         -> Async version of invoke              |
|   abatch([inputs])       -> Async version of batch               |
|   astream(input)         -> Async version of stream              |
|                                                                  |
+------------------------------------------------------------------+
```

## Version History

| Version | Release | Key Changes |
|---------|---------|-------------|
| 0.1.x | Jan 2024 | Package reorganization (core, community, providers) |
| 0.2.x | Mid 2024 | Pydantic v2 migration, deprecation warnings |
| 0.3.x | Late 2024 | Python 3.8 EOL, Pydantic v1 support removed |

## What You Can Build

LangChain enables building various AI-powered applications:

```
+------------------------------------------------------------------+
|                   Application Types                              |
+------------------------------------------------------------------+
|                                                                  |
|  +-------------------+    +-------------------+                  |
|  |   Chatbots        |    |   Q&A Systems     |                  |
|  |   - Customer      |    |   - Document Q&A  |                  |
|  |     support       |    |   - Knowledge     |                  |
|  |   - Assistants    |    |     bases         |                  |
|  +-------------------+    +-------------------+                  |
|                                                                  |
|  +-------------------+    +-------------------+                  |
|  |   RAG Apps        |    |   Agents          |                  |
|  |   - Search with   |    |   - Task          |                  |
|  |     context       |    |     automation    |                  |
|  |   - Semantic      |    |   - Tool usage    |                  |
|  |     search        |    |   - Research      |                  |
|  +-------------------+    +-------------------+                  |
|                                                                  |
|  +-------------------+    +-------------------+                  |
|  |   Data Analysis   |    |   Code Gen        |                  |
|  |   - Summarization |    |   - Code review   |                  |
|  |   - Extraction    |    |   - Documentation |                  |
|  |   - Classification|    |   - Conversion    |                  |
|  +-------------------+    +-------------------+                  |
|                                                                  |
+------------------------------------------------------------------+
```

## Summary

LangChain provides:

1. **Unified Abstraction**: One interface for many LLM providers
2. **Modular Architecture**: Use only what you need
3. **Composability**: Build complex applications from simple components
4. **Rich Ecosystem**: Hundreds of integrations out of the box
5. **Production Ready**: Tools for debugging, tracing, and monitoring

---

## Sources

- [Announcing LangChain v0.3](https://blog.langchain.com/announcing-langchain-v0-3/)
- [LangChain Python API Reference](https://python.langchain.com/api_reference)
- [LangChain Core Architecture Explained](https://apxml.com/courses/building-llm-apps-with-langchain/chapter-1-intro-to-langchain-framework/langchain-core-architecture)
- [The Complete LangChain Ecosystem - GeeksforGeeks](https://www.geeksforgeeks.org/artificial-intelligence/the-complete-langchain-ecosystem/)
- [LangChain Python integrations](https://docs.langchain.com/oss/python/integrations/providers/overview)
- [The New LangChain Architecture](https://www.langchain.com/blog/the-new-langchain-architecture-langchain-core-v0-1-langchain-community-and-a-path-to-langchain-v0-1)

---

**Next: [02_installation_guide.md](02_installation_guide.md)**
