# Module 10: Text Splitters - Why Text Splitting Matters

## Introduction

Text splitting (also called "chunking") is one of the most critical yet often overlooked steps in building effective RAG (Retrieval-Augmented Generation) systems. How you split your documents directly impacts retrieval quality, context relevance, and ultimately, the quality of your LLM's responses.

---

## Why Do We Need Text Splitting?

### The Core Problem

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         LARGE DOCUMENT                                  │
│  (10,000+ tokens - too large for embedding models and context windows)  │
└─────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
                           TEXT SPLITTING
                                    │
                    ┌───────────────┼───────────────┐
                    ▼               ▼               ▼
              ┌──────────┐   ┌──────────┐   ┌──────────┐
              │ Chunk 1  │   │ Chunk 2  │   │ Chunk 3  │
              │ 512 tok  │   │ 512 tok  │   │ 512 tok  │
              └──────────┘   └──────────┘   └──────────┘
                    │               │               │
                    ▼               ▼               ▼
              ┌──────────┐   ┌──────────┐   ┌──────────┐
              │Embedding │   │Embedding │   │Embedding │
              │  Vector  │   │  Vector  │   │  Vector  │
              └──────────┘   └──────────┘   └──────────┘
```

### Key Reasons for Text Splitting

1. **Embedding Model Limitations**: Most embedding models have a maximum input length (typically 512-8192 tokens)
2. **LLM Context Windows**: Even with large context windows, retrieving focused, relevant chunks is more effective
3. **Semantic Precision**: Smaller, focused chunks lead to more precise similarity matching
4. **Cost Efficiency**: Processing smaller chunks reduces token usage and costs

---

## The RAG Pipeline and Chunking

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          RAG PIPELINE OVERVIEW                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   INDEXING PHASE                                                            │
│   ┌──────────┐    ┌──────────────┐    ┌──────────────┐    ┌─────────────┐  │
│   │  Load    │───▶│    SPLIT     │───▶│   Embed      │───▶│   Store     │  │
│   │Documents │    │   (Chunk)    │    │   Chunks     │    │ in VectorDB │  │
│   └──────────┘    └──────────────┘    └──────────────┘    └─────────────┘  │
│                          ▲                                                  │
│                          │                                                  │
│                    CRITICAL STEP                                            │
│                                                                             │
│   RETRIEVAL PHASE                                                           │
│   ┌──────────┐    ┌──────────────┐    ┌──────────────┐    ┌─────────────┐  │
│   │  User    │───▶│   Embed      │───▶│  Similarity  │───▶│  Return     │  │
│   │  Query   │    │   Query      │    │   Search     │    │  Top-K      │  │
│   └──────────┘    └──────────────┘    └──────────────┘    └─────────────┘  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Chunking Strategies Overview

### 1. Fixed-Size Chunking
Split text into chunks of a fixed number of characters or tokens.

```
┌─────────────────────────────────────────────────────────────────────┐
│ "The quick brown fox jumps over the lazy dog. The fox is clever."  │
└─────────────────────────────────────────────────────────────────────┘
                              │
              Fixed size = 30 characters
                              │
         ┌────────────────────┼────────────────────┐
         ▼                    ▼                    ▼
    ┌──────────┐        ┌──────────┐        ┌──────────┐
    │"The quick│        │"jumps ove│        │"g. The fo│
    │ brown fox│        │r the lazy│        │x is cleve│
    └──────────┘        └──────────┘        └──────────┘
    
    Problem: Cuts words and sentences mid-way!
```

### 2. Recursive Character Splitting
Attempts to split on natural boundaries (paragraphs, sentences, words).

```
┌─────────────────────────────────────────────────────────────────────┐
│ "The quick brown fox jumps over the lazy dog. The fox is clever."  │
└─────────────────────────────────────────────────────────────────────┘
                              │
              Try split on: \n\n → \n → . → " " → ""
                              │
                    ┌─────────┴─────────┐
                    ▼                   ▼
           ┌────────────────┐   ┌────────────────┐
           │"The quick brown│   │"The fox is     │
           │fox jumps over  │   │clever."        │
           │the lazy dog."  │   │                │
           └────────────────┘   └────────────────┘
    
    Better: Preserves sentence boundaries!
```

### 3. Semantic Chunking
Uses embeddings to detect semantic shifts in content.

```
┌─────────────────────────────────────────────────────────────────────┐
│ Document about: Python (programming) → Python (snake) → Java       │
└─────────────────────────────────────────────────────────────────────┘
                              │
              Analyze semantic similarity between sentences
                              │
         ┌────────────────────┼────────────────────┐
         ▼                    ▼                    ▼
    ┌──────────┐        ┌──────────┐        ┌──────────┐
    │ Python   │        │  Python  │        │  Java    │
    │ (coding) │        │  (snake) │        │ (coding) │
    │ content  │        │  content │        │ content  │
    └──────────┘        └──────────┘        └──────────┘
    
    Best: Chunks based on meaning!
```

### 4. Document-Structure-Aware Splitting
Respects document structure (headers, sections, code blocks).

```
    ┌──────────────────────────────────────┐
    │ # Chapter 1: Introduction            │
    │ Content about intro...               │
    │                                      │
    │ ## Section 1.1: Background           │
    │ Content about background...          │
    │                                      │
    │ # Chapter 2: Methods                 │
    │ Content about methods...             │
    └──────────────────────────────────────┘
                     │
         Structure-aware splitting
                     │
         ┌───────────┼───────────┐
         ▼           ▼           ▼
    ┌─────────┐ ┌─────────┐ ┌─────────┐
    │Chapter 1│ │Section  │ │Chapter 2│
    │  Intro  │ │  1.1    │ │ Methods │
    └─────────┘ └─────────┘ └─────────┘
```

---

## Chunk Size Considerations

### The Goldilocks Problem

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        CHUNK SIZE TRADE-OFFS                                │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  TOO SMALL (< 128 tokens)           TOO LARGE (> 1024 tokens)              │
│  ┌─────────────────────┐            ┌─────────────────────┐                │
│  │ - Loses context     │            │ - Noisy embeddings  │                │
│  │ - Incomplete ideas  │            │ - Mixed topics      │                │
│  │ - High retrieval    │            │ - Poor precision    │                │
│  │   overhead          │            │ - Wastes context    │                │
│  │ - Fragmented info   │            │   window            │                │
│  └─────────────────────┘            └─────────────────────┘                │
│                                                                             │
│                        JUST RIGHT (256-512 tokens)                         │
│                        ┌─────────────────────┐                             │
│                        │ - Complete thoughts │                             │
│                        │ - Focused topics    │                             │
│                        │ - Good embeddings   │                             │
│                        │ - Balanced recall   │                             │
│                        └─────────────────────┘                             │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Recommended Chunk Sizes by Use Case

| Use Case | Chunk Size | Overlap | Rationale |
|----------|------------|---------|-----------|
| **Factual Q&A** | 128-256 tokens | 10-20% | Precise, focused answers |
| **General RAG** | 400-512 tokens | 50-100 tokens | Benchmark-validated default |
| **Complex Analysis** | 512-1024 tokens | 100-200 tokens | More context for reasoning |
| **Code Documentation** | 500-1000 chars | 100-200 chars | Preserve function definitions |
| **Legal/Technical** | 256-512 tokens | 50-100 tokens | Precise clause retrieval |

### 2026 Benchmark Results

According to recent benchmarks:
- **512 tokens with 50-100 token overlap** scored **69% accuracy** in real-document tests
- **Recursive character splitting** at 400 tokens achieves **85-90% recall**
- **Semantic chunking** reaches **91-92% recall** but with higher computational cost

---

## The Impact of Poor Chunking

### Problem 1: Cutting Across Semantic Boundaries

```
BEFORE (Bad chunking):
┌────────────────────────────────────────┐
│ Chunk 1: "...the patient exhibited     │
│ symptoms of fever and headache. The"   │  ← Sentence cut mid-way!
└────────────────────────────────────────┘
┌────────────────────────────────────────┐
│ Chunk 2: "diagnosis was confirmed      │
│ through blood tests which showed..."   │  ← Missing context!
└────────────────────────────────────────┘

Query: "What symptoms did the patient have?"
Result: Chunk 1 retrieved but diagnosis context lost!
```

### Problem 2: Mixed Topics in Single Chunk

```
BEFORE (Bad chunking):
┌────────────────────────────────────────┐
│ Chunk: "Python is a programming        │
│ language created by Guido van Rossum.  │  
│ The python snake is found in Asia and  │  ← Two completely different topics!
│ Africa. Java is another programming    │
│ language developed by Sun..."          │
└────────────────────────────────────────┘

Query: "What is Python used for?"
Result: Noisy embedding, poor retrieval!
```

---

## Overlap Strategy

### Why Overlap Matters

```
WITHOUT OVERLAP:
┌──────────────┐ ┌──────────────┐ ┌──────────────┐
│   Chunk 1    │ │   Chunk 2    │ │   Chunk 3    │
│ "The patient │ │ "tests. The  │ │ "treatment   │
│ had various  │ │ diagnosis    │ │ plan was     │
│ symptoms and │ │ confirmed    │ │ implemented" │
│ underwent"   │ │ the"         │ │              │
└──────────────┘ └──────────────┘ └──────────────┘
                ↑                ↑
           Information lost at boundaries!

WITH OVERLAP (20%):
┌──────────────────┐
│     Chunk 1      │
│  "The patient    │
│   had various    │
│   symptoms and   │
│   underwent"     │
└────────┬─────────┘
         │ OVERLAP
    ┌────┴───────────────┐
    │      Chunk 2       │
    │  "symptoms and     │
    │   underwent tests. │
    │   The diagnosis    │
    │   confirmed the"   │
    └────────┬───────────┘
             │ OVERLAP
        ┌────┴───────────────┐
        │      Chunk 3       │
        │  "diagnosis        │
        │   confirmed the    │
        │   treatment plan   │
        │   was implemented" │
        └────────────────────┘

Context preserved across boundaries!
```

### Overlap Guidelines

| Chunk Size | Recommended Overlap | Percentage |
|------------|---------------------|------------|
| 256 tokens | 25-50 tokens | 10-20% |
| 512 tokens | 50-100 tokens | 10-20% |
| 1000 tokens | 100-200 tokens | 10-20% |

**Note**: A January 2026 study found that overlap provided no measurable benefit in some configurations with SPLADE retrieval. Always test for your specific use case.

---

## Choosing the Right Strategy

### Decision Flow Chart

```
                    ┌─────────────────────────┐
                    │   What type of content? │
                    └───────────┬─────────────┘
                                │
          ┌─────────────────────┼─────────────────────┐
          ▼                     ▼                     ▼
    ┌───────────┐        ┌───────────┐        ┌───────────┐
    │Plain Text │        │   Code    │        │ Markdown/ │
    │ Documents │        │   Files   │        │   HTML    │
    └─────┬─────┘        └─────┬─────┘        └─────┬─────┘
          │                    │                    │
          ▼                    ▼                    ▼
┌─────────────────┐   ┌─────────────────┐   ┌─────────────────┐
│ Is semantic     │   │ Use Language-   │   │ Use Markdown/   │
│ coherence       │   │ specific        │   │ HTML splitter   │
│ critical?       │   │ code splitter   │   │                 │
└────────┬────────┘   └─────────────────┘   └─────────────────┘
         │
    ┌────┴────┐
    ▼         ▼
  ┌───┐     ┌───┐
  │Yes│     │No │
  └─┬─┘     └─┬─┘
    │         │
    ▼         ▼
┌─────────┐ ┌─────────────────┐
│Semantic │ │Recursive        │
│Chunker  │ │Character        │
│         │ │TextSplitter     │
└─────────┘ └─────────────────┘
```

---

## Key Takeaways

1. **Start with RecursiveCharacterTextSplitter** - It's the recommended default for most use cases

2. **Default to 400-512 tokens** with 10-20% overlap as your baseline

3. **Smaller chunks (128-256)** for factual Q&A, **larger chunks (512-1024)** for complex analysis

4. **Test and validate** - The optimal configuration depends on your specific documents and queries

5. **Consider semantic chunking** when dealing with documents where topics shift mid-paragraph

6. **Use language-specific splitters** for code to preserve function and class boundaries

---

## LangChain Text Splitters Package

```python
# Installation
pip install langchain-text-splitters

# Available splitters
from langchain_text_splitters import (
    CharacterTextSplitter,
    RecursiveCharacterTextSplitter,
    TokenTextSplitter,
    MarkdownTextSplitter,
    HTMLHeaderTextSplitter,
    PythonCodeTextSplitter,
    # ... and more
)

# Experimental (semantic)
from langchain_experimental.text_splitter import SemanticChunker
```

---

## Next Steps

In the following lessons, we'll dive deep into:
- **02**: Character-based splitters (CharacterTextSplitter, RecursiveCharacterTextSplitter)
- **03**: Semantic chunking with SemanticChunker
- **04**: Language-specific code splitters
- **05**: Hands-on comparison of different splitters
- **06**: Advanced techniques: custom splitters and overlap strategies

---

## References

- [LangChain Text Splitter Documentation](https://docs.langchain.com/oss/python/integrations/splitters)
- [Best Chunking Strategies for RAG 2026](https://www.firecrawl.dev/blog/best-chunking-strategies-rag)
- [RAG Chunking Strategies Benchmark Guide 2026](https://www.premai.io/blog/rag-chunking-strategies-the-2026-benchmark-guide/)
- [Unstructured: Chunking for RAG Best Practices](https://unstructured.io/blog/chunking-for-rag-best-practices)
