# Module 10: Semantic Text Splitters

## Introduction

Semantic chunking represents the next evolution in text splitting - instead of splitting on arbitrary character boundaries, it uses **embeddings to detect semantic shifts** in content and creates chunks that maintain topical coherence. This is particularly valuable for RAG applications where retrieval quality depends on chunk relevance.

---

## The Problem with Character-Based Splitting

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    Why Semantic Splitting Matters                           │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   Character-Based Splitting:                                                │
│   ┌─────────────────────────────────────────────────────────────────────┐  │
│   │  "Python is a programming language created by Guido van Rossum.    │  │
│   │   It is widely used for web development. [CHUNK BOUNDARY] The      │  │
│   │   python snake is found in tropical regions of Africa and Asia.    │  │
│   │   It is a non-venomous constrictor..."                             │  │
│   └─────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
│   Result: Programming and zoology content MIXED in same chunk!             │
│                                                                             │
│   Semantic Splitting:                                                       │
│   ┌──────────────────────────────┐   ┌──────────────────────────────┐     │
│   │  "Python is a programming    │   │  "The python snake is found  │     │
│   │   language created by Guido  │   │   in tropical regions of     │     │
│   │   van Rossum. It is widely   │   │   Africa and Asia. It is a   │     │
│   │   used for web development." │   │   non-venomous constrictor." │     │
│   └──────────────────────────────┘   └──────────────────────────────┘     │
│          Programming Context              Zoology Context                   │
│                                                                             │
│   Result: Semantically coherent chunks!                                     │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## SemanticChunker Overview

### How It Works

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    SemanticChunker Algorithm                                │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   Step 1: Split text into sentences                                         │
│   ┌─────────────────────────────────────────────────────────────────────┐  │
│   │ [S1] [S2] [S3] [S4] [S5] [S6] [S7] [S8] [S9] [S10]                  │  │
│   └─────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
│   Step 2: Generate embeddings for each sentence                            │
│   ┌─────────────────────────────────────────────────────────────────────┐  │
│   │ [E1] [E2] [E3] [E4] [E5] [E6] [E7] [E8] [E9] [E10]                  │  │
│   │  ↓    ↓    ↓    ↓    ↓    ↓    ↓    ↓    ↓    ↓                    │  │
│   └─────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
│   Step 3: Calculate semantic distance between adjacent sentences           │
│   ┌─────────────────────────────────────────────────────────────────────┐  │
│   │     0.1  0.15  0.2  0.8   0.1  0.2  0.9  0.15  0.1                  │  │
│   │      ↓    ↓     ↓    ↓     ↓    ↓    ↓    ↓     ↓                   │  │
│   │ [S1]─[S2]─[S3]─[S4]│[S5]─[S6]─[S7]│[S8]─[S9]─[S10]                 │  │
│   │                    ↑              ↑                                  │  │
│   │              HIGH DISTANCE   HIGH DISTANCE                          │  │
│   │              = BREAKPOINT    = BREAKPOINT                           │  │
│   └─────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
│   Step 4: Create chunks at breakpoints                                      │
│   ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐           │
│   │  Chunk 1        │  │  Chunk 2        │  │  Chunk 3        │           │
│   │  [S1][S2][S3]   │  │  [S5][S6][S7]   │  │  [S8][S9][S10]  │           │
│   │  [S4]           │  │                 │  │                 │           │
│   └─────────────────┘  └─────────────────┘  └─────────────────┘           │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Installation

```python
# SemanticChunker is in the experimental package
pip install langchain-experimental

# You also need an embedding model
pip install langchain-openai
# or
pip install sentence-transformers
```

### Basic Usage

```python
from langchain_experimental.text_splitter import SemanticChunker
from langchain_openai import OpenAIEmbeddings

# Initialize embeddings
embeddings = OpenAIEmbeddings()

# Create semantic chunker
semantic_chunker = SemanticChunker(
    embeddings=embeddings,
    breakpoint_threshold_type="percentile",  # How to determine breakpoints
    breakpoint_threshold_amount=95           # 95th percentile
)

# Sample text with distinct topics
text = """
Machine learning is a subset of artificial intelligence that enables systems 
to learn from data. It includes supervised learning where models learn from 
labeled examples. Deep learning is a type of machine learning using neural 
networks with multiple layers.

The python snake is one of the largest snakes in the world. Found primarily 
in Africa and Asia, pythons are non-venomous constrictors. They can grow up 
to 20 feet in length and are known for their distinctive patterns.

Natural language processing allows computers to understand human language. 
Techniques like tokenization, parsing, and named entity recognition are 
fundamental to NLP systems.
"""

# Split the text
chunks = semantic_chunker.split_text(text)

for i, chunk in enumerate(chunks):
    print(f"Chunk {i+1}:")
    print(chunk)
    print("-" * 50)
```

---

## Breakpoint Threshold Types

The SemanticChunker offers several methods to determine where semantic shifts occur:

### 1. Percentile-Based (Default)

```python
# Split when semantic distance exceeds the Nth percentile
semantic_chunker = SemanticChunker(
    embeddings=embeddings,
    breakpoint_threshold_type="percentile",
    breakpoint_threshold_amount=95  # 95th percentile of distances
)
```

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       Percentile-Based Breakpoints                          │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   Sentence Distances: [0.1, 0.15, 0.2, 0.8, 0.1, 0.2, 0.9, 0.15, 0.1]     │
│                                                                             │
│   95th Percentile = 0.85                                                    │
│                                                                             │
│   Breakpoints at: 0.8 (close to threshold), 0.9 (exceeds threshold)        │
│                                                                             │
│   Visual:                                                                   │
│   1.0 ┤                                                                    │
│       │                           ┌─┐                                      │
│   0.9 ┤                           │ │     Breakpoint threshold (95th)      │
│       │              ┌─┐          │ │  ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─       │
│   0.8 ┤              │ │          │ │                                      │
│       │              │ │          │ │                                      │
│   0.5 ┤              │ │          │ │                                      │
│       │       ┌─┐    │ │    ┌─┐   │ │                                      │
│   0.2 ┤    ┌─┐│ │    │ │ ┌─┐│ │   │ │ ┌─┐  ┌─┐                            │
│   0.1 ┤ ┌─┐│ ││ │    │ │ │ ││ │   │ │ │ │  │ │                            │
│   0.0 ┼─┴─┴┴─┴┴─┴────┴─┴─┴─┴┴─┴───┴─┴─┴─┴──┴─┴──────────────────────      │
│         1  2  3  4    5  6  7     8  9 10                                  │
│                    ↑           ↑                                           │
│                    BREAK       BREAK                                        │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 2. Standard Deviation

```python
# Split when distance exceeds mean + N standard deviations
semantic_chunker = SemanticChunker(
    embeddings=embeddings,
    breakpoint_threshold_type="standard_deviation",
    breakpoint_threshold_amount=1.5  # 1.5 std deviations above mean
)
```

### 3. Interquartile Range (IQR)

```python
# Split when distance exceeds Q3 + N * IQR
semantic_chunker = SemanticChunker(
    embeddings=embeddings,
    breakpoint_threshold_type="interquartile",
    breakpoint_threshold_amount=1.5  # 1.5 * IQR above Q3
)
```

### Comparison of Threshold Methods

| Method | Best For | Sensitivity |
|--------|----------|-------------|
| **Percentile** | General use, balanced splits | Adjustable (higher % = fewer breaks) |
| **Standard Deviation** | Documents with consistent style | Sensitive to outliers |
| **Interquartile** | Documents with varying complexity | Robust to outliers |

---

## Using Different Embedding Models

### OpenAI Embeddings

```python
from langchain_openai import OpenAIEmbeddings

embeddings = OpenAIEmbeddings(
    model="text-embedding-3-small"  # or "text-embedding-3-large"
)

semantic_chunker = SemanticChunker(embeddings=embeddings)
```

### HuggingFace Embeddings (Local)

```python
from langchain_community.embeddings import HuggingFaceEmbeddings

# Free, local embedding model
embeddings = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-MiniLM-L6-v2"
)

semantic_chunker = SemanticChunker(embeddings=embeddings)
```

### Sentence Transformers

```python
from langchain_community.embeddings import SentenceTransformerEmbeddings

embeddings = SentenceTransformerEmbeddings(
    model_name="all-mpnet-base-v2"
)

semantic_chunker = SemanticChunker(embeddings=embeddings)
```

---

## Complete Example: Semantic RAG Pipeline

```python
from langchain_experimental.text_splitter import SemanticChunker
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import Chroma
from langchain_core.documents import Document

# 1. Initialize embeddings
embeddings = OpenAIEmbeddings()

# 2. Create semantic chunker
semantic_chunker = SemanticChunker(
    embeddings=embeddings,
    breakpoint_threshold_type="percentile",
    breakpoint_threshold_amount=90
)

# 3. Load and split document
document_text = """
Introduction to Data Science

Data science combines statistics, programming, and domain expertise to extract 
insights from data. It involves collecting, cleaning, and analyzing large 
datasets to make informed decisions.

Machine Learning Fundamentals

Machine learning is a core component of data science. Supervised learning uses 
labeled data to train models, while unsupervised learning finds patterns in 
unlabeled data. Common algorithms include decision trees, random forests, 
and neural networks.

The History of Computing

The history of computing dates back to ancient times with the abacus. Modern 
computing began with Charles Babbage's analytical engine in the 1830s. The 
first electronic computers were developed in the 1940s during World War II.

Python for Data Analysis

Python has become the preferred language for data science due to libraries 
like pandas, numpy, and scikit-learn. Its readable syntax and extensive 
ecosystem make it ideal for data manipulation and visualization.
"""

# Split semantically
chunks = semantic_chunker.split_text(document_text)

# Create documents with metadata
documents = [
    Document(
        page_content=chunk,
        metadata={"chunk_id": i, "source": "data_science_guide.txt"}
    )
    for i, chunk in enumerate(chunks)
]

# 4. Store in vector database
vectorstore = Chroma.from_documents(
    documents=documents,
    embedding=embeddings,
    persist_directory="./semantic_chroma_db"
)

# 5. Query the vectorstore
query = "What programming language is best for data science?"
results = vectorstore.similarity_search(query, k=2)

print("Query:", query)
print("\nRelevant chunks:")
for i, doc in enumerate(results):
    print(f"\n{i+1}. (Chunk ID: {doc.metadata['chunk_id']})")
    print(doc.page_content[:200] + "...")
```

---

## Semantic Chunking vs Character Splitting

### Visual Comparison

```
┌─────────────────────────────────────────────────────────────────────────────┐
│              RecursiveCharacterTextSplitter vs SemanticChunker              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   Input: Article about Machine Learning AND History of Computing           │
│   (Total: 2000 characters)                                                  │
│                                                                             │
│   RecursiveCharacterTextSplitter (chunk_size=500):                         │
│   ┌────────────┐ ┌────────────┐ ┌────────────┐ ┌────────────┐             │
│   │ Chunk 1    │ │ Chunk 2    │ │ Chunk 3    │ │ Chunk 4    │             │
│   │ ML content │ │ ML + Hist  │ │ History    │ │ History    │             │
│   │ 500 chars  │ │ MIXED!     │ │ content    │ │ content    │             │
│   └────────────┘ └────────────┘ └────────────┘ └────────────┘             │
│                       ↑                                                     │
│                 Topic boundary                                              │
│                 ignored!                                                    │
│                                                                             │
│   SemanticChunker:                                                         │
│   ┌────────────────────────┐ ┌────────────────────────┐                   │
│   │      Chunk 1           │ │      Chunk 2           │                   │
│   │   Machine Learning     │ │   History of Computing │                   │
│   │      content           │ │      content           │                   │
│   │    (variable size)     │ │    (variable size)     │                   │
│   └────────────────────────┘ └────────────────────────┘                   │
│                                                                             │
│   Chunks align with topic boundaries!                                       │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Performance Comparison

| Metric | RecursiveCharacterTextSplitter | SemanticChunker |
|--------|-------------------------------|-----------------|
| **Retrieval Recall** | 85-90% | 91-92% |
| **Processing Speed** | Very fast | Slower (requires embeddings) |
| **Cost** | Free | Embedding API costs |
| **Chunk Size Control** | Precise | Variable |
| **Topic Coherence** | Moderate | High |
| **Best For** | General use, cost-sensitive | Quality-critical RAG |

---

## When to Use Semantic Chunking

### Good Use Cases

1. **Documents with topic shifts**
   - Wikipedia articles
   - Research papers
   - News compilations

2. **Dense HTML/web content**
   - Scraped web pages
   - Documentation sites

3. **Quality-critical RAG applications**
   - Customer support systems
   - Legal document analysis
   - Medical information retrieval

### When NOT to Use

1. **Highly structured documents** (use structure-aware splitters)
2. **Code files** (use language-specific splitters)
3. **Cost-sensitive applications** (embedding costs add up)
4. **Real-time processing** (slower than character splitting)

---

## Advanced Configuration

### Combining with Size Constraints

```python
from langchain_experimental.text_splitter import SemanticChunker
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings

embeddings = OpenAIEmbeddings()

# First pass: semantic splitting
semantic_chunker = SemanticChunker(
    embeddings=embeddings,
    breakpoint_threshold_type="percentile",
    breakpoint_threshold_amount=85
)

# Second pass: ensure max size
size_splitter = RecursiveCharacterTextSplitter(
    chunk_size=1000,
    chunk_overlap=100
)

# Two-stage splitting
text = "Your long document here..."
semantic_chunks = semantic_chunker.split_text(text)

# Ensure no chunk exceeds size limit
final_chunks = []
for chunk in semantic_chunks:
    if len(chunk) > 1000:
        # Further split large chunks
        sub_chunks = size_splitter.split_text(chunk)
        final_chunks.extend(sub_chunks)
    else:
        final_chunks.append(chunk)

print(f"Semantic chunks: {len(semantic_chunks)}")
print(f"Final chunks (size-limited): {len(final_chunks)}")
```

### Custom Buffer Size

```python
# Add surrounding context to each sentence before embedding
semantic_chunker = SemanticChunker(
    embeddings=embeddings,
    breakpoint_threshold_type="percentile",
    breakpoint_threshold_amount=90,
    buffer_size=1  # Include 1 sentence before and after
)
```

---

## Best Practices

### 1. Choose the Right Embedding Model

```python
# For quality: Use larger embedding models
embeddings = OpenAIEmbeddings(model="text-embedding-3-large")

# For cost: Use efficient local models
from langchain_community.embeddings import HuggingFaceEmbeddings
embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
```

### 2. Tune Breakpoint Threshold

```python
# More chunks (lower threshold)
semantic_chunker = SemanticChunker(
    embeddings=embeddings,
    breakpoint_threshold_type="percentile",
    breakpoint_threshold_amount=70  # More sensitive
)

# Fewer chunks (higher threshold)
semantic_chunker = SemanticChunker(
    embeddings=embeddings,
    breakpoint_threshold_type="percentile",
    breakpoint_threshold_amount=95  # Less sensitive
)
```

### 3. Handle Variable Chunk Sizes

```python
# Post-process to ensure minimum chunk size
MIN_CHUNK_SIZE = 100

chunks = semantic_chunker.split_text(text)
processed_chunks = []

current_chunk = ""
for chunk in chunks:
    if len(current_chunk) + len(chunk) < MIN_CHUNK_SIZE:
        current_chunk += " " + chunk
    else:
        if current_chunk:
            processed_chunks.append(current_chunk.strip())
        current_chunk = chunk

if current_chunk:
    processed_chunks.append(current_chunk.strip())
```

---

## Key Takeaways

1. **SemanticChunker uses embeddings** to detect topic shifts and create coherent chunks

2. **Three threshold types**: percentile, standard deviation, and interquartile range

3. **Higher retrieval quality** (91-92% recall) compared to character splitting (85-90%)

4. **Trade-off**: Better quality but slower and costs more (embedding API calls)

5. **Best for**: Documents with clear topic shifts, quality-critical RAG applications

6. **Still experimental**: Located in `langchain_experimental` package

7. **Combine with size constraints** when you need both semantic coherence and size limits

---

## References

- [SemanticChunker - LangChain Experimental](https://deepwiki.com/langchain-ai/langchain-experimental/3.2-semanticchunker)
- [Semantic Chunking for RAG](https://medium.com/the-ai-forum/semantic-chunking-for-rag-f4733025d5f5)
- [Best Chunking Strategies for RAG 2026](https://www.firecrawl.dev/blog/best-chunking-strategies-rag)
- [LangChain OpenTutorial - SemanticChunker](https://langchain-opentutorial.gitbook.io/langchain-opentutorial/07-textsplitter/04-semanticchunker)
- [GitHub Issue: SemanticChunker Migration](https://github.com/langchain-ai/langchain/issues/35553)
