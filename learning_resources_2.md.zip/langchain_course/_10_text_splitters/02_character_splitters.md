# Module 10: Character-Based Text Splitters

## Introduction

Character-based splitters are the foundational text splitting tools in LangChain. They divide text based on character counts and separator patterns. This lesson covers the two most important character splitters: `CharacterTextSplitter` and `RecursiveCharacterTextSplitter`.

---

## Installation

```python
# Install the text splitters package
pip install langchain-text-splitters

# Import the splitters
from langchain_text_splitters import (
    CharacterTextSplitter,
    RecursiveCharacterTextSplitter
)
```

---

## CharacterTextSplitter

### Overview

The `CharacterTextSplitter` is the simplest splitter - it divides text into chunks of a fixed character length using a specified separator.

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       CharacterTextSplitter                                 │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   Input Text                                                                │
│   ┌─────────────────────────────────────────────────────────────────────┐  │
│   │ "Paragraph 1 about topic A.\n\nParagraph 2 about topic B.\n\n..."   │  │
│   └─────────────────────────────────────────────────────────────────────┘  │
│                                    │                                        │
│                           Split on separator: "\n\n"                        │
│                                    │                                        │
│              ┌─────────────────────┼─────────────────────┐                  │
│              ▼                     ▼                     ▼                  │
│   ┌─────────────────┐   ┌─────────────────┐   ┌─────────────────┐          │
│   │  Paragraph 1    │   │  Paragraph 2    │   │  Paragraph 3    │          │
│   │  about topic A  │   │  about topic B  │   │  about topic C  │          │
│   └─────────────────┘   └─────────────────┘   └─────────────────┘          │
│                                                                             │
│   Note: Splits ONLY on the specified separator                              │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Basic Usage

```python
from langchain_text_splitters import CharacterTextSplitter

# Create the splitter
text_splitter = CharacterTextSplitter(
    separator="\n\n",      # Split on double newlines (paragraphs)
    chunk_size=1000,       # Maximum characters per chunk
    chunk_overlap=200,     # Overlap between chunks
    length_function=len,   # Function to measure chunk length
    is_separator_regex=False  # Whether separator is a regex pattern
)

# Sample text
text = """
First paragraph with important information about machine learning.
This continues with more details about neural networks.

Second paragraph discusses natural language processing.
It covers topics like tokenization and embeddings.

Third paragraph focuses on computer vision applications.
Object detection and image classification are mentioned.
"""

# Split the text
chunks = text_splitter.split_text(text)

# Print results
for i, chunk in enumerate(chunks):
    print(f"Chunk {i+1} ({len(chunk)} chars):")
    print(chunk)
    print("-" * 50)
```

### Key Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `separator` | str | "\n\n" | Character(s) to split on |
| `chunk_size` | int | 4000 | Maximum characters per chunk |
| `chunk_overlap` | int | 200 | Characters to overlap between chunks |
| `length_function` | callable | len | Function to measure length |
| `is_separator_regex` | bool | False | Treat separator as regex |
| `keep_separator` | bool | False | Keep separator in chunks |

### Using Regex Separators

```python
# Split on multiple punctuation marks
text_splitter = CharacterTextSplitter(
    separator=r"[.!?]+\s+",  # Split on sentence endings
    chunk_size=500,
    chunk_overlap=50,
    is_separator_regex=True
)

text = "This is sentence one. This is sentence two! Is this sentence three? Yes it is."
chunks = text_splitter.split_text(text)
```

### When to Use CharacterTextSplitter

**Good for:**
- Simple, uniform documents
- FAQ-style content
- Short text snippets
- When you know the exact separator pattern

**Not ideal for:**
- Complex documents with varying structure
- Code files
- Documents requiring semantic coherence

---

## RecursiveCharacterTextSplitter

### Overview

The `RecursiveCharacterTextSplitter` is **the recommended splitter for generic text**. It recursively tries to split text on a list of separators, starting with the largest semantic units (paragraphs) and working down to smaller ones (characters).

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    RecursiveCharacterTextSplitter                           │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   Default Separators (in order):                                            │
│   ┌─────────────────────────────────────────────────────────────────────┐  │
│   │  ["\n\n", "\n", " ", ""]                                            │  │
│   │     │       │     │    │                                            │  │
│   │     ▼       ▼     ▼    ▼                                            │  │
│   │  Paragraph→Line→Word→Character                                      │  │
│   └─────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
│   Algorithm:                                                                │
│   ┌─────────────────────────────────────────────────────────────────────┐  │
│   │  1. Try splitting on "\n\n" (paragraphs)                            │  │
│   │  2. If chunk still too large, try "\n" (lines)                      │  │
│   │  3. If still too large, try " " (words)                             │  │
│   │  4. Last resort: split on "" (characters)                           │  │
│   └─────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
│   Result: Preserves semantic structure as much as possible!                 │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Visual Example of Recursive Splitting

```
Original Text (too large for chunk_size=100):
┌──────────────────────────────────────────────────────────────────────────┐
│ "Machine learning is a subset of AI.\n\nDeep learning uses neural       │
│ networks.\n\nNLP processes human language."                              │
└──────────────────────────────────────────────────────────────────────────┘

Step 1: Try split on "\n\n" (paragraphs)
┌────────────────────────┐ ┌────────────────────────┐ ┌──────────────────┐
│"Machine learning is a  │ │"Deep learning uses     │ │"NLP processes    │
│ subset of AI."         │ │ neural networks."      │ │ human language." │
└────────────────────────┘ └────────────────────────┘ └──────────────────┘
         42 chars                  35 chars                  26 chars

All chunks under 100 chars - DONE!

---

If a paragraph was > 100 chars:
┌────────────────────────────────────────────────────────────────────────────┐
│ "Machine learning is a subset of artificial intelligence.\nIt includes    │
│ supervised learning.\nIt also includes unsupervised learning."            │
└────────────────────────────────────────────────────────────────────────────┘
                                   150 chars - too large!

Step 2: Try split on "\n" (lines)
┌─────────────────────────────────────────────┐ ┌──────────────────────────┐
│"Machine learning is a subset of artificial  │ │"It includes supervised   │
│ intelligence."                              │ │ learning."               │
└─────────────────────────────────────────────┘ └──────────────────────────┘
┌─────────────────────────────────────────────┐
│"It also includes unsupervised learning."    │
└─────────────────────────────────────────────┘

All chunks under 100 chars - DONE!
```

### Basic Usage

```python
from langchain_text_splitters import RecursiveCharacterTextSplitter

# Create the splitter with default separators
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=1000,
    chunk_overlap=200,
    length_function=len,
    is_separator_regex=False,
)

# Sample document
document = """
# Introduction to Machine Learning

Machine learning is a branch of artificial intelligence (AI) that focuses on 
building applications that learn from data and improve their accuracy over time 
without being programmed to do so.

## Types of Machine Learning

### Supervised Learning
In supervised learning, the algorithm learns from labeled training data, and 
makes predictions based on that data. Examples include:
- Classification
- Regression

### Unsupervised Learning
Unsupervised learning uses machine learning algorithms to analyze and cluster 
unlabeled datasets. Examples include:
- Clustering
- Dimensionality reduction

### Reinforcement Learning
Reinforcement learning is a type of machine learning where an agent learns to 
make decisions by performing actions and observing the results.
"""

# Split the text
chunks = text_splitter.split_text(document)

for i, chunk in enumerate(chunks):
    print(f"Chunk {i+1} ({len(chunk)} chars):")
    print(chunk[:100] + "..." if len(chunk) > 100 else chunk)
    print("-" * 50)
```

### Custom Separators

```python
# For Markdown documents
markdown_splitter = RecursiveCharacterTextSplitter(
    separators=[
        "\n## ",      # H2 headers
        "\n### ",     # H3 headers  
        "\n#### ",    # H4 headers
        "\n\n",       # Paragraphs
        "\n",         # Lines
        " ",          # Words
        ""            # Characters
    ],
    chunk_size=1000,
    chunk_overlap=200
)

# For structured text
structured_splitter = RecursiveCharacterTextSplitter(
    separators=[
        "\n---\n",    # Horizontal rules
        "\n\n\n",     # Triple newlines
        "\n\n",       # Paragraphs
        "\n",         # Lines
        ". ",         # Sentences
        ", ",         # Clauses
        " ",          # Words
        ""            # Characters
    ],
    chunk_size=500,
    chunk_overlap=50
)
```

### Splitting Documents (not just text)

```python
from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter

# Create documents with metadata
documents = [
    Document(
        page_content="This is the content of document 1...",
        metadata={"source": "doc1.pdf", "page": 1}
    ),
    Document(
        page_content="This is the content of document 2...",
        metadata={"source": "doc2.pdf", "page": 1}
    )
]

text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=500,
    chunk_overlap=50
)

# Split documents - metadata is preserved!
split_docs = text_splitter.split_documents(documents)

for doc in split_docs:
    print(f"Source: {doc.metadata['source']}")
    print(f"Content: {doc.page_content[:50]}...")
    print("-" * 30)
```

---

## Comparison: Character vs Recursive

```
┌─────────────────────────────────────────────────────────────────────────────┐
│              CharacterTextSplitter vs RecursiveCharacterTextSplitter        │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   Input: "Hello world.\n\nThis is a test.\nAnother line here."             │
│                                                                             │
│   CharacterTextSplitter (separator="\n\n", chunk_size=30):                 │
│   ┌─────────────────────────────────────────────────────────────────────┐  │
│   │ Result: ["Hello world.", "This is a test.\nAnother line here."]    │  │
│   │         - Only splits on "\n\n"                                     │  │
│   │         - Second chunk might exceed size (not enforced)             │  │
│   └─────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
│   RecursiveCharacterTextSplitter (chunk_size=30):                          │
│   ┌─────────────────────────────────────────────────────────────────────┐  │
│   │ Result: ["Hello world.", "This is a test.", "Another line here."]   │  │
│   │         - First tries "\n\n", then "\n"                             │  │
│   │         - Ensures all chunks respect size limit                     │  │
│   └─────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Feature Comparison

| Feature | CharacterTextSplitter | RecursiveCharacterTextSplitter |
|---------|----------------------|-------------------------------|
| **Separator** | Single separator | Multiple separators (hierarchy) |
| **Splitting Logic** | Simple split | Recursive, adaptive |
| **Semantic Preservation** | Low | High |
| **Speed** | Faster | Slightly slower |
| **Use Case** | Simple text | General-purpose (recommended) |
| **Chunk Size Enforcement** | May exceed | Strictly enforced |

---

## Best Practices

### 1. Choosing Chunk Size

```python
# For embedding models with 512 token limit
# Rule of thumb: 1 token ≈ 4 characters (English)
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=2000,      # ~500 tokens
    chunk_overlap=200     # ~50 tokens
)

# For factual Q&A (smaller chunks, more precision)
qa_splitter = RecursiveCharacterTextSplitter(
    chunk_size=500,       # ~125 tokens
    chunk_overlap=50
)

# For complex reasoning (larger chunks, more context)
reasoning_splitter = RecursiveCharacterTextSplitter(
    chunk_size=4000,      # ~1000 tokens
    chunk_overlap=400
)
```

### 2. Using Token-Based Length

```python
import tiktoken

# Create a token counter for GPT models
def tiktoken_len(text):
    encoding = tiktoken.get_encoding("cl100k_base")
    return len(encoding.encode(text))

# Use token-based length function
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=512,           # Now in tokens!
    chunk_overlap=50,
    length_function=tiktoken_len
)
```

### 3. Handling Different Document Types

```python
# For legal documents (preserve clauses)
legal_splitter = RecursiveCharacterTextSplitter(
    separators=[
        "\nArticle ",
        "\nSection ",
        "\n\n",
        "\n",
        ". ",
        " ",
        ""
    ],
    chunk_size=1000,
    chunk_overlap=100
)

# For scientific papers
scientific_splitter = RecursiveCharacterTextSplitter(
    separators=[
        "\n## ",          # Major sections
        "\n### ",         # Subsections
        "\n\n",           # Paragraphs
        "\n",             # Lines
        ". ",             # Sentences
        " ",              # Words
        ""
    ],
    chunk_size=1500,
    chunk_overlap=150
)
```

---

## Complete Example: RAG Pipeline with Text Splitting

```python
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import TextLoader
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import Chroma

# 1. Load document
loader = TextLoader("document.txt")
documents = loader.load()

# 2. Split documents
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=1000,
    chunk_overlap=200,
    length_function=len,
    separators=["\n\n", "\n", " ", ""]
)
splits = text_splitter.split_documents(documents)

print(f"Split {len(documents)} documents into {len(splits)} chunks")

# 3. Create embeddings and store in vector database
embeddings = OpenAIEmbeddings()
vectorstore = Chroma.from_documents(
    documents=splits,
    embedding=embeddings
)

# 4. Retrieve relevant chunks
query = "What is machine learning?"
relevant_docs = vectorstore.similarity_search(query, k=3)

for doc in relevant_docs:
    print(f"Content: {doc.page_content[:100]}...")
    print(f"Metadata: {doc.metadata}")
    print("-" * 50)
```

---

## Common Pitfalls and Solutions

### Pitfall 1: Ignoring Chunk Overlap

```python
# BAD: No overlap - information at boundaries is lost
bad_splitter = RecursiveCharacterTextSplitter(
    chunk_size=500,
    chunk_overlap=0  # No overlap!
)

# GOOD: 10-20% overlap preserves context
good_splitter = RecursiveCharacterTextSplitter(
    chunk_size=500,
    chunk_overlap=50  # 10% overlap
)
```

### Pitfall 2: Chunk Size Too Small

```python
# BAD: Chunks too small lose context
bad_splitter = RecursiveCharacterTextSplitter(
    chunk_size=100,  # Way too small!
    chunk_overlap=10
)

# GOOD: Reasonable chunk size
good_splitter = RecursiveCharacterTextSplitter(
    chunk_size=500,  # Good starting point
    chunk_overlap=50
)
```

### Pitfall 3: Not Preserving Metadata

```python
from langchain_core.documents import Document

# Always include relevant metadata
doc = Document(
    page_content="Content here...",
    metadata={
        "source": "filename.pdf",
        "page": 1,
        "section": "Introduction",
        "author": "John Doe"
    }
)

# Metadata is automatically preserved when splitting
splits = text_splitter.split_documents([doc])
# Each split will have the same metadata!
```

---

## Key Takeaways

1. **Start with RecursiveCharacterTextSplitter** - It's the recommended default for most text

2. **CharacterTextSplitter** is simpler but less intelligent about preserving meaning

3. **Default separators** ["\n\n", "\n", " ", ""] work well for most documents

4. **Customize separators** based on your document structure (Markdown, legal, scientific)

5. **Always use overlap** (10-20% of chunk size) to preserve context across boundaries

6. **Consider token-based length** for accurate alignment with embedding/LLM limits

7. **Preserve metadata** when splitting documents for better traceability

---

## References

- [LangChain RecursiveCharacterTextSplitter Reference](https://reference.langchain.com/python/langchain-text-splitters/character/RecursiveCharacterTextSplitter)
- [LangChain Text Splitters Documentation](https://docs.langchain.com/oss/python/integrations/splitters)
- [Understanding RecursiveCharacterTextSplitter - DEV Community](https://dev.to/eteimz/understanding-langchains-recursivecharactertextsplitter-2846)
- [LangChain OpenTutorial - RecursiveCharacterTextSplitter](https://langchain-opentutorial.gitbook.io/langchain-opentutorial/07-textsplitter/02-recursivecharactertextsplitter)
