# Module 07: Tools and Agents - Part 3
# Agents Overview

## Table of Contents
1. [What Are Agents?](#what-are-agents)
2. [The ReAct Pattern](#the-react-pattern)
3. [Agent Types and Evolution](#agent-types-and-evolution)
4. [Agent Executors](#agent-executors)
5. [LangGraph: The Modern Approach](#langgraph-the-modern-approach)
6. [Agents vs Chains: When to Use Which](#agents-vs-chains-when-to-use-which)
7. [Agent Debugging Techniques](#agent-debugging-techniques)

---

## What Are Agents?

An agent is an intelligent system powered by an LLM that can **make decisions dynamically** instead of following a fixed sequence. Unlike traditional chains, agents can:

- Analyze context and decide what action to take
- Use external tools or APIs
- Reason step-by-step until a goal is reached
- Adapt their approach based on intermediate results

### Agents vs Chains: The Core Difference

```
CHAIN (Static Workflow)
=======================
Input --> Step 1 --> Step 2 --> Step 3 --> Output
              |          |          |
              v          v          v
         [Fixed]    [Fixed]    [Fixed]
         
         
AGENT (Dynamic Workflow)  
========================
Input --> Reason --> Act --> Observe --> Reason --> ... --> Output
              |        |         |           |
              v        v         v           v
          [Dynamic] [Tool]  [Result]   [Decide if
           choice   call    analysis    done or
                                       continue]
```

### Mental Model

Think of the difference this way:
- **Chain**: A production line - input goes in, output comes out, every step predetermined
- **Agent**: An assistant that plans, executes, and rethinks its approach when necessary

---

## The ReAct Pattern

ReAct stands for **Re**asoning and **Act**ing. It's the fundamental pattern most LangChain agents follow.

### The ReAct Loop

```
+------------------+
|   User Query     |
+--------+---------+
         |
         v
+--------+---------+
|                  |
|     THOUGHT      |  <-- LLM reasons about what to do
|                  |
+--------+---------+
         |
         v
+--------+---------+
|                  |
|      ACTION      |  <-- LLM selects a tool and inputs
|                  |
+--------+---------+
         |
         v
+--------+---------+
|                  |
|   OBSERVATION    |  <-- Tool executes, returns result
|                  |
+--------+---------+
         |
         v
+--------+---------+
|   Is the goal    |
|    achieved?     |
+--------+---------+
    |          |
   YES         NO
    |          |
    v          +-------> Back to THOUGHT
+--------+
| Final  |
| Answer |
+--------+
```

### ReAct in Action: Example Trace

```
USER: What is the population of Tokyo divided by the population of London?

THOUGHT: I need to find the population of Tokyo and London, then divide them.
         Let me start by searching for Tokyo's population.

ACTION: search
ACTION INPUT: "Tokyo population 2026"

OBSERVATION: Tokyo has a population of approximately 13.96 million people.

THOUGHT: Good, I have Tokyo's population. Now I need London's population.

ACTION: search  
ACTION INPUT: "London population 2026"

OBSERVATION: London has a population of approximately 8.8 million people.

THOUGHT: Now I have both populations. Tokyo: 13.96 million, London: 8.8 million.
         Let me calculate the division.

ACTION: calculator
ACTION INPUT: 13.96 / 8.8

OBSERVATION: 1.586

THOUGHT: I have the answer. The population of Tokyo divided by London is 
         approximately 1.59, meaning Tokyo has about 1.59 times the 
         population of London.

FINAL ANSWER: The population of Tokyo (approximately 13.96 million) divided 
by the population of London (approximately 8.8 million) is about 1.59. 
This means Tokyo has roughly 59% more people than London.
```

---

## Agent Types and Evolution

### Historical Agent Types (Legacy)

LangChain originally provided several pre-built agent types:

| Agent Type | Description | Status |
|------------|-------------|--------|
| `ZERO_SHOT_REACT_DESCRIPTION` | ReAct agent using tool descriptions | Legacy |
| `CONVERSATIONAL_REACT_DESCRIPTION` | ReAct with conversation memory | Legacy |
| `OPENAI_FUNCTIONS` | Uses OpenAI function calling | Legacy |
| `OPENAI_MULTI_FUNCTIONS` | Multiple function calls per turn | Legacy |
| `STRUCTURED_CHAT_ZERO_SHOT_REACT_DESCRIPTION` | Structured outputs | Legacy |

### Modern Approach (2026)

```
+-------------------------------------------------------------------+
|                      LANGCHAIN EVOLUTION                          |
+-------------------------------------------------------------------+
|                                                                   |
|   LEGACY (v0.x)              CURRENT (v1.x+)                      |
|   ============               ==============                       |
|                                                                   |
|   AgentExecutor    ------>   LangGraph                            |
|   Agent Types      ------>   create_react_agent()                 |
|   initialize_agent ------>   Custom StateGraphs                   |
|                                                                   |
|   LangChain now recommends LangGraph for production agents.       |
|   The old patterns are in 'langchain-classic' package.            |
|                                                                   |
+-------------------------------------------------------------------+
```

### The Modern Stack

```python
# LEGACY approach (still works but not recommended)
from langchain.agents import initialize_agent, AgentType

# MODERN approach (recommended)
from langgraph.prebuilt import create_react_agent
# OR
from langgraph.graph import StateGraph  # For full control
```

---

## Agent Executors

### What is an AgentExecutor?

The `AgentExecutor` is the runtime that manages the agent loop:

```
AgentExecutor
=============
    +-------------------+
    |   Agent           |  <-- Decides what to do
    +-------------------+
    |   Tools           |  <-- Available actions
    +-------------------+
    |   Memory          |  <-- Optional conversation history
    +-------------------+
    |   Callbacks       |  <-- Logging and monitoring
    +-------------------+
    |   Max Iterations  |  <-- Safety limit
    +-------------------+
    |   Error Handling  |  <-- Graceful failures
    +-------------------+
```

### Legacy AgentExecutor Example

```python
from langchain.agents import AgentExecutor, create_react_agent
from langchain_openai import ChatOpenAI
from langchain.tools import Tool
from langchain import hub

# Setup
llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)

tools = [
    Tool(
        name="search",
        func=lambda q: "Search result for: " + q,
        description="Search the web for information",
    ),
]

# Get a prompt template
prompt = hub.pull("hwchase17/react")

# Create the agent
agent = create_react_agent(llm, tools, prompt)

# Create the executor
agent_executor = AgentExecutor(
    agent=agent,
    tools=tools,
    verbose=True,          # Show reasoning
    max_iterations=10,     # Prevent infinite loops
    handle_parsing_errors=True,
)

# Run
result = agent_executor.invoke({"input": "What is the weather in Tokyo?"})
```

---

## LangGraph: The Modern Approach

LangGraph is now the **recommended way** to build agents in LangChain. It provides explicit control over the agent loop as a graph.

### Why LangGraph?

| Feature | AgentExecutor | LangGraph |
|---------|---------------|-----------|
| Control over loop | Limited | Full |
| Custom branching | No | Yes |
| State persistence | Basic | Advanced |
| Human-in-the-loop | Difficult | Built-in |
| Parallel tool calls | Limited | Native |
| Debugging | Basic | Excellent |
| Production-ready | Legacy | Yes |

### LangGraph Agent Architecture

```
                    +------------------+
                    |   START          |
                    +--------+---------+
                             |
                             v
                    +--------+---------+
                    |                  |
              +---->|   Agent Node     |<----+
              |     |  (LLM Decision)  |     |
              |     +--------+---------+     |
              |              |               |
              |     +--------+--------+      |
              |     |                 |      |
              |    Tool            No Tool   |
              |    Calls           Calls     |
              |     |                 |      |
              |     v                 v      |
              |  +--+--+        +-----+-----+
              |  |Tools|        |   END     |
              |  |Node |        +-----------+
              |  +--+--+
              |     |
              +-----+
            (loop back with results)
```

### Basic LangGraph Agent

```python
from langgraph.prebuilt import create_react_agent
from langchain_openai import ChatOpenAI
from langchain_core.tools import tool

# Define tools
@tool
def search(query: str) -> str:
    """Search the web for information."""
    return f"Search results for: {query}"

@tool
def calculator(expression: str) -> str:
    """Evaluate a math expression."""
    return str(eval(expression))

# Create model
model = ChatOpenAI(model="gpt-4o-mini", temperature=0)

# Create agent with LangGraph
agent = create_react_agent(model, [search, calculator])

# Run
result = agent.invoke({
    "messages": [("user", "What is 15 * 23?")]
})
```

### Custom LangGraph Agent

```python
from langgraph.graph import StateGraph, END
from langgraph.prebuilt import ToolNode
from typing import TypedDict, Annotated
from langchain_core.messages import BaseMessage
import operator

# Define state
class AgentState(TypedDict):
    messages: Annotated[list[BaseMessage], operator.add]

# Define nodes
def call_model(state: AgentState):
    messages = state["messages"]
    response = model.bind_tools(tools).invoke(messages)
    return {"messages": [response]}

def should_continue(state: AgentState):
    last_message = state["messages"][-1]
    if last_message.tool_calls:
        return "tools"
    return END

# Build graph
workflow = StateGraph(AgentState)
workflow.add_node("agent", call_model)
workflow.add_node("tools", ToolNode(tools))

workflow.set_entry_point("agent")
workflow.add_conditional_edges("agent", should_continue, {"tools": "tools", END: END})
workflow.add_edge("tools", "agent")

# Compile
agent = workflow.compile()
```

---

## Agents vs Chains: When to Use Which

### Decision Matrix

```
+------------------------------------------------------------------+
|                    DECISION FLOWCHART                            |
+------------------------------------------------------------------+
|                                                                  |
|   Is the workflow...                                             |
|                                                                  |
|   1. Linear with fixed steps?                                    |
|      YES --> Use a Chain (LCEL)                                  |
|      NO  --> Continue to question 2                              |
|                                                                  |
|   2. Requires dynamic tool selection?                            |
|      YES --> Use an Agent                                        |
|      NO  --> Continue to question 3                              |
|                                                                  |
|   3. Needs branching, loops, or human approval?                  |
|      YES --> Use LangGraph                                       |
|      NO  --> Chain might suffice                                 |
|                                                                  |
|   4. Requires state persistence across sessions?                 |
|      YES --> Use LangGraph with checkpointing                    |
|      NO  --> Simple agent or chain                               |
|                                                                  |
+------------------------------------------------------------------+
```

### Use Cases Comparison

| Scenario | Use Chain | Use Agent |
|----------|-----------|-----------|
| Summarize a document | Yes | No |
| Answer questions from a database | Maybe | Yes |
| Multi-step research task | No | Yes |
| Fixed data transformation pipeline | Yes | No |
| Interactive customer support | No | Yes |
| Generate content from template | Yes | No |
| Dynamic API orchestration | No | Yes |

### Code Comparison

```python
# CHAIN: Fixed steps, predictable flow
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI
from langchain_core.output_parsers import StrOutputParser

chain = (
    ChatPromptTemplate.from_template("Summarize: {text}")
    | ChatOpenAI()
    | StrOutputParser()
)
result = chain.invoke({"text": "..."})

# AGENT: Dynamic, tool-using, adaptive
from langgraph.prebuilt import create_react_agent

agent = create_react_agent(model, tools)
result = agent.invoke({"messages": [("user", "Research and summarize...")]})
```

---

## Agent Debugging Techniques

### 1. Verbose Mode

The simplest debugging approach:

```python
# Legacy AgentExecutor
agent_executor = AgentExecutor(
    agent=agent,
    tools=tools,
    verbose=True,  # Shows all reasoning steps
)

# LangGraph - use callbacks
from langchain.callbacks import StdOutCallbackHandler

result = agent.invoke(
    {"messages": messages},
    config={"callbacks": [StdOutCallbackHandler()]}
)
```

### 2. LangSmith Tracing

Production-grade debugging and monitoring:

```python
import os

# Set environment variables
os.environ["LANGCHAIN_TRACING_V2"] = "true"
os.environ["LANGCHAIN_API_KEY"] = "your-api-key"
os.environ["LANGCHAIN_PROJECT"] = "my-agent-project"

# All agent runs are now automatically traced!
result = agent.invoke({"messages": messages})

# View traces at: https://smith.langchain.com
```

### 3. Custom Callbacks

For fine-grained control:

```python
from langchain.callbacks.base import BaseCallbackHandler

class DebugCallbackHandler(BaseCallbackHandler):
    def on_llm_start(self, serialized, prompts, **kwargs):
        print(f"[LLM START] Prompts: {prompts[:100]}...")
    
    def on_llm_end(self, response, **kwargs):
        print(f"[LLM END] Response: {response.generations[0][0].text[:100]}...")
    
    def on_tool_start(self, serialized, input_str, **kwargs):
        print(f"[TOOL START] {serialized.get('name')}: {input_str}")
    
    def on_tool_end(self, output, **kwargs):
        print(f"[TOOL END] Output: {output[:100]}...")
    
    def on_agent_action(self, action, **kwargs):
        print(f"[ACTION] Tool: {action.tool}, Input: {action.tool_input}")

# Use the callback
result = agent.invoke(
    {"messages": messages},
    config={"callbacks": [DebugCallbackHandler()]}
)
```

### 4. Debugging Diagram

```
+-------------------------------------------------------------------+
|                    DEBUGGING WORKFLOW                             |
+-------------------------------------------------------------------+
|                                                                   |
|   1. QUICK DEBUG (Development)                                    |
|      +---> verbose=True                                           |
|      +---> Print statements in tools                              |
|      +---> Check intermediate_steps                               |
|                                                                   |
|   2. DETAILED DEBUG (Investigation)                               |
|      +---> Custom callbacks                                       |
|      +---> Logging at each step                                   |
|      +---> State inspection                                       |
|                                                                   |
|   3. PRODUCTION DEBUG (Monitoring)                                |
|      +---> LangSmith tracing                                      |
|      +---> Metrics collection                                     |
|      +---> Error alerting                                         |
|                                                                   |
+-------------------------------------------------------------------+
```

### Common Debugging Issues

| Issue | Symptoms | Solution |
|-------|----------|----------|
| Infinite loop | Agent keeps calling tools | Set `max_iterations`, check tool outputs |
| Wrong tool selected | Agent uses inappropriate tool | Improve tool descriptions |
| Parsing errors | Agent output malformed | Use `handle_parsing_errors=True` |
| Hallucinated tools | Agent calls non-existent tools | Ensure tool names are clear |
| Poor reasoning | Agent gives wrong answers | Use better model, improve prompts |

---

## Summary

| Concept | Key Takeaway |
|---------|--------------|
| **Agents** | Dynamic systems that reason and act autonomously |
| **ReAct** | Think -> Act -> Observe -> Repeat pattern |
| **AgentExecutor** | Legacy runtime for agent loops |
| **LangGraph** | Modern, recommended approach for agents |
| **Chains vs Agents** | Chains for fixed flows, Agents for dynamic tasks |
| **Debugging** | Use verbose mode, callbacks, and LangSmith |

---

## Next Steps

In the next notebook, we'll implement tool calling with `bind_tools()` and see how models interact with tools in practice.

---

## References

- [LangChain Agents Complete Guide](https://leanware.co/insights/langchain-agents-complete-guide-in-2025)
- [Building LangChain Agents: Tools, AgentExecutor, and the ReAct Loop](https://callsphere.ai/blog/building-langchain-agents-tools-agentexecutor-react-loop)
- [LangGraph vs LangChain: Which to Use](https://www.spheron.network/blog/langgraph-vs-langchain/)
- [How to Debug LangChain Applications](https://oneuptime.com/blog/post/2026-01-28-debug-langchain-applications/view)
- [Debugging Deep Agents with LangSmith](https://www.langchain.com/blog/debugging-deep-agents-with-langsmith)
- [LangSmith Guide](https://www.ai.cc/blogs/how-to-use-langsmith-2026-complete-guide/)
