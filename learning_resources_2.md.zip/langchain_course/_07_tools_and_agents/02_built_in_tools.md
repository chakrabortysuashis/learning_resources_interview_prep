# Module 07: Tools and Agents - Part 2
# Built-in Tools in LangChain

## Table of Contents
1. [Overview of Built-in Tools](#overview-of-built-in-tools)
2. [Search Tools](#search-tools)
3. [Calculator and Math Tools](#calculator-and-math-tools)
4. [Wikipedia Tool](#wikipedia-tool)
5. [Python REPL Tool](#python-repl-tool)
6. [File and Shell Tools](#file-and-shell-tools)
7. [API and Request Tools](#api-and-request-tools)
8. [Tool Selection Guide](#tool-selection-guide)

---

## Overview of Built-in Tools

LangChain provides a rich collection of pre-built tools in the `langchain_community.tools` package. These tools are production-ready and cover common use cases like searching, calculations, and data retrieval.

### Tool Categories

```
+---------------------+---------------------+---------------------+
|   SEARCH TOOLS      |   COMPUTATION       |   DATA ACCESS       |
+---------------------+---------------------+---------------------+
| - DuckDuckGo        | - Calculator        | - Wikipedia         |
| - Google Search     | - Python REPL       | - ArXiv             |
| - Google Serper     | - Wolfram Alpha     | - PubMed            |
| - Bing Search       | - LLM Math          | - Wikidata          |
| - SerpAPI           |                     | - OpenWeatherMap    |
| - Tavily Search     |                     |                     |
+---------------------+---------------------+---------------------+
|   FILE SYSTEM       |   COMMUNICATION     |   UTILITIES         |
+---------------------+---------------------+---------------------+
| - Read File         | - Gmail             | - Shell/Bash        |
| - Write File        | - Slack             | - Human Input       |
| - List Directory    | - Zapier NLA        | - Requests (HTTP)   |
| - Copy File         |                     | - JSON Tools        |
+---------------------+---------------------+---------------------+
```

### Installation

Most built-in tools require the `langchain-community` package:

```bash
pip install langchain-community

# Additional packages for specific tools
pip install duckduckgo-search    # DuckDuckGo
pip install google-search-results # SerpAPI
pip install wikipedia            # Wikipedia
pip install arxiv                # ArXiv
pip install numexpr              # Calculator
```

---

## Search Tools

### DuckDuckGo Search

Free, no API key required - great for development:

```python
from langchain_community.tools import DuckDuckGoSearchRun, DuckDuckGoSearchResults

# Basic search - returns text summary
search = DuckDuckGoSearchRun()
result = search.invoke("LangChain latest features 2026")
print(result)

# Detailed search - returns structured results
search_results = DuckDuckGoSearchResults(num_results=5)
results = search_results.invoke("Python AI frameworks comparison")
print(results)
```

### Google Serper API

Fast and reliable Google search results:

```python
import os
from langchain_community.utilities import GoogleSerperAPIWrapper
from langchain_community.tools import Tool

os.environ["SERPER_API_KEY"] = "your-api-key"

search = GoogleSerperAPIWrapper()

# Wrap as a tool
serper_tool = Tool(
    name="google_search",
    description="Search Google for recent information and news",
    func=search.run,
)

result = serper_tool.invoke("latest AI developments 2026")
```

### Tavily Search (Recommended for AI Agents)

Optimized for AI agent use with fact-checking:

```python
import os
from langchain_community.tools.tavily_search import TavilySearchResults

os.environ["TAVILY_API_KEY"] = "your-api-key"

tavily_search = TavilySearchResults(
    max_results=5,
    search_depth="advanced",  # "basic" or "advanced"
    include_answer=True,
    include_raw_content=True,
)

results = tavily_search.invoke("What is LangGraph and how does it work?")
```

### Search Tool Comparison

| Tool | API Key | Speed | Accuracy | Best For |
|------|---------|-------|----------|----------|
| DuckDuckGo | No | Medium | Good | Development, free tier |
| Serper | Yes | Fast | Excellent | Production Google search |
| Tavily | Yes | Fast | Excellent | AI agents, fact-checking |
| SerpAPI | Yes | Fast | Excellent | Multi-engine search |

---

## Calculator and Math Tools

### LLM Math Chain

Combines LLM reasoning with calculation:

```python
from langchain_community.tools import LLMMathChain
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)

# Note: LLMMathChain is being deprecated in favor of tool-calling
llm_math = LLMMathChain.from_llm(llm, verbose=True)
result = llm_math.invoke("What is 15% of 847?")
```

### Calculator Tool (numexpr)

Direct mathematical expression evaluation:

```python
from langchain_community.tools import Tool
from langchain_community.utilities import WikipediaAPIWrapper
import numexpr as ne

def calculate(expression: str) -> str:
    """Evaluate a mathematical expression using numexpr."""
    try:
        # Safe evaluation using numexpr
        result = ne.evaluate(expression)
        return str(result)
    except Exception as e:
        return f"Error: {str(e)}"

calculator_tool = Tool(
    name="calculator",
    description="Useful for evaluating mathematical expressions. Input should be a valid mathematical expression like '2 + 2' or '(5 * 10) / 2'.",
    func=calculate,
)

# Examples
print(calculator_tool.invoke("2 ** 10"))  # 1024
print(calculator_tool.invoke("(100 * 0.15) + 50"))  # 65.0
```

### Python REPL for Complex Calculations

For calculations requiring logic or imports:

```python
from langchain_community.tools import PythonREPLTool

python_repl = PythonREPLTool()

# Complex calculation with imports
code = """
import math
radius = 5
area = math.pi * radius ** 2
circumference = 2 * math.pi * radius
print(f"Area: {area:.2f}")
print(f"Circumference: {circumference:.2f}")
"""

result = python_repl.invoke(code)
print(result)
```

---

## Wikipedia Tool

Access Wikipedia's vast knowledge base:

```python
from langchain_community.tools import WikipediaQueryRun
from langchain_community.utilities import WikipediaAPIWrapper

# Basic usage
wikipedia = WikipediaQueryRun(
    api_wrapper=WikipediaAPIWrapper(
        top_k_results=3,      # Number of pages to fetch
        doc_content_chars_max=4000,  # Max characters per page
    )
)

result = wikipedia.invoke("LangChain framework")
print(result)
```

### Wikipedia with Custom Configuration

```python
from langchain_community.utilities import WikipediaAPIWrapper

api_wrapper = WikipediaAPIWrapper(
    top_k_results=2,
    doc_content_chars_max=2000,
    lang="en",  # Language code
)

# Get page summaries
docs = api_wrapper.load("Machine Learning")
for doc in docs:
    print(f"Title: {doc.metadata['title']}")
    print(f"Summary: {doc.metadata['summary'][:200]}...")
    print("---")
```

---

## Python REPL Tool

Execute Python code dynamically:

```python
from langchain_community.tools import PythonREPLTool

# WARNING: This tool executes arbitrary code - use with caution!
repl = PythonREPLTool()

# Data analysis example
code = """
data = [23, 45, 12, 67, 34, 89, 21, 56]
mean = sum(data) / len(data)
sorted_data = sorted(data)
median = sorted_data[len(data)//2]
print(f"Mean: {mean}")
print(f"Median: {median}")
print(f"Max: {max(data)}")
print(f"Min: {min(data)}")
"""

result = repl.invoke(code)
print(result)
```

### Security Considerations

```
+------------------------------------------------------------------+
|                     PYTHON REPL SECURITY                         |
+------------------------------------------------------------------+
|                                                                  |
|  WARNING: The Python REPL tool executes arbitrary code!          |
|                                                                  |
|  DO:                                                             |
|  - Use in sandboxed environments                                 |
|  - Validate input before execution                               |
|  - Set resource limits (memory, time)                            |
|  - Use for trusted internal workflows only                       |
|                                                                  |
|  DON'T:                                                          |
|  - Expose to untrusted user input                                |
|  - Run in production without sandboxing                          |
|  - Allow file system or network access                           |
|                                                                  |
+------------------------------------------------------------------+
```

---

## File and Shell Tools

### File Management Tools

```python
from langchain_community.tools.file_management import (
    ReadFileTool,
    WriteFileTool,
    ListDirectoryTool,
    CopyFileTool,
    MoveFileTool,
    FileSearchTool,
)

# Read a file
read_tool = ReadFileTool()
content = read_tool.invoke({"file_path": "data/config.json"})

# Write to a file
write_tool = WriteFileTool()
write_tool.invoke({
    "file_path": "output/result.txt",
    "text": "Analysis complete. Results: ...",
})

# List directory contents
list_tool = ListDirectoryTool()
files = list_tool.invoke({"dir_path": "data/"})

# Search for files
search_tool = FileSearchTool()
matches = search_tool.invoke({
    "dir_path": ".",
    "pattern": "*.py",
})
```

### Shell Tool

```python
from langchain_community.tools import ShellTool

# WARNING: Executes shell commands - use with extreme caution!
shell = ShellTool()

# Safe commands only
result = shell.invoke("ls -la")
print(result)

# Check disk space
result = shell.invoke("df -h")
print(result)
```

---

## API and Request Tools

### Requests Tool

Make HTTP requests to APIs:

```python
from langchain_community.tools import RequestsGetTool, RequestsPostTool
from langchain_community.utilities import TextRequestsWrapper

requests_wrapper = TextRequestsWrapper()

# GET requests
get_tool = RequestsGetTool(requests_wrapper=requests_wrapper)
response = get_tool.invoke("https://api.example.com/data")

# POST requests
post_tool = RequestsPostTool(requests_wrapper=requests_wrapper)
response = post_tool.invoke({
    "url": "https://api.example.com/submit",
    "data": {"key": "value"},
})
```

### JSON Tools

Process and query JSON data:

```python
from langchain_community.tools.json.tool import JsonSpec, JsonListKeysTool, JsonGetValueTool

# Define JSON specification
json_data = {
    "users": [
        {"name": "Alice", "age": 30},
        {"name": "Bob", "age": 25},
    ],
    "metadata": {
        "version": "1.0",
        "count": 2,
    }
}

spec = JsonSpec(dict_=json_data, max_value_length=500)

# List keys at a path
list_keys = JsonListKeysTool(spec=spec)
keys = list_keys.invoke("")  # Root level keys

# Get value at a path
get_value = JsonGetValueTool(spec=spec)
users = get_value.invoke("users")
```

---

## Tool Selection Guide

### Decision Tree

```
                    What do you need to do?
                            |
            +---------------+---------------+
            |               |               |
         Search         Compute          Access
            |               |             Data
            |               |               |
    +-------+-------+   +---+---+      +---+---+
    |       |       |   |       |      |       |
  Web    Docs   News  Math   Code   Wiki   APIs
    |       |       |   |       |      |       |
Tavily  ArXiv  Serper Calc  REPL  Wiki  Requests
DuckDuck PubMed        Wolfram    data
```

### Quick Reference Table

| Use Case | Recommended Tool | Package |
|----------|------------------|---------|
| Web search (free) | DuckDuckGoSearchRun | duckduckgo-search |
| Web search (production) | TavilySearchResults | tavily-python |
| Math calculations | Calculator (numexpr) | numexpr |
| Complex calculations | PythonREPLTool | Built-in |
| Knowledge lookup | WikipediaQueryRun | wikipedia |
| Academic papers | ArxivQueryRun | arxiv |
| File operations | File management tools | Built-in |
| HTTP requests | RequestsGetTool | requests |
| Execute shell | ShellTool | Built-in |

### Creating a Toolkit

Combine multiple tools for an agent:

```python
from langchain_community.tools import (
    DuckDuckGoSearchRun,
    WikipediaQueryRun,
    PythonREPLTool,
)
from langchain_community.utilities import WikipediaAPIWrapper
from langchain_core.tools import tool

# Initialize built-in tools
search = DuckDuckGoSearchRun()
wikipedia = WikipediaQueryRun(api_wrapper=WikipediaAPIWrapper())
python_repl = PythonREPLTool()

# Add a custom tool
@tool
def get_current_date() -> str:
    """Get the current date and time."""
    from datetime import datetime
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# Combine into a toolkit
tools = [
    search,
    wikipedia,
    python_repl,
    get_current_date,
]

# Now these tools can be passed to an agent
# agent = create_react_agent(llm, tools, prompt)
```

---

## Summary

| Category | Key Tools | API Key Required |
|----------|-----------|------------------|
| **Search** | DuckDuckGo, Tavily, Serper | DuckDuckGo: No, Others: Yes |
| **Math** | Calculator, Python REPL | No |
| **Knowledge** | Wikipedia, ArXiv, PubMed | No |
| **Files** | Read/Write/List/Copy/Move | No |
| **HTTP** | Requests Get/Post | No |
| **Shell** | ShellTool | No |

---

## Next Steps

In the next section, we'll explore Agents - the intelligent systems that use these tools to accomplish complex tasks autonomously.

---

## References

- [LangChain Tools Documentation](https://docs.langchain.com/oss/python/langchain/tools)
- [Tools in LangChain With Examples](https://www.netjstech.com/2026/05/tools-in-langchain-with-examples.html)
- [Available Tools for LangChain Agents](https://apxml.com/courses/python-llm-workflows/chapter-5-advanced-langchain-chains-agents/langchain-agent-tools)
- [LangChain Wikipedia Tool Reference](https://reference.langchain.com/python/langchain-community/tools/wikipedia/tool)
