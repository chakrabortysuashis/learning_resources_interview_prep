# Module 07: Tools and Agents - Part 1
# Understanding Tools in LangChain

## Table of Contents
1. [What Are Tools?](#what-are-tools)
2. [The @tool Decorator](#the-tool-decorator)
3. [StructuredTool](#structuredtool)
4. [Tool Creation Best Practices](#tool-creation-best-practices)
5. [Tool Anatomy and Schema](#tool-anatomy-and-schema)

---

## What Are Tools?

Tools are interfaces that allow LLMs to interact with the external world. Just like you might use a calculator for math or a search engine for finding information, LLMs use tools for specific tasks they cannot perform on their own.

### Why Tools Matter

```
+-------------------+     +-------------------+     +-------------------+
|                   |     |                   |     |                   |
|   User Question   | --> |   LLM Reasoning   | --> |   Tool Execution  |
|                   |     |                   |     |                   |
+-------------------+     +-------------------+     +-------------------+
                                   |                        |
                                   v                        v
                          +-------------------+     +-------------------+
                          |                   |     |                   |
                          |   Tool Selection  |     |   External API    |
                          |                   |     |   Database        |
                          +-------------------+     |   Calculator      |
                                                    |   Search Engine   |
                                                    +-------------------+
```

Tools extend LLM capabilities by:
- **Accessing real-time data** (search engines, APIs)
- **Performing calculations** (math operations)
- **Interacting with databases** (SQL queries)
- **Executing code** (Python REPL)
- **Managing files** (read/write operations)

### Tool Components

Every LangChain tool has three essential components:

| Component | Description | Example |
|-----------|-------------|---------|
| **Name** | Unique identifier for the tool | `"calculate"` |
| **Description** | What the tool does (read by LLM) | `"Useful for math calculations"` |
| **Args Schema** | Input parameters and their types | `{"expression": str}` |

---

## The @tool Decorator

The `@tool` decorator is the simplest and most common way to create a LangChain tool. It transforms a regular Python function into an LLM-compatible tool.

### Basic Usage

```python
from langchain_core.tools import tool

@tool
def multiply(a: int, b: int) -> int:
    """Multiply two numbers together.
    
    Args:
        a: The first number to multiply.
        b: The second number to multiply.
    
    Returns:
        The product of a and b.
    """
    return a * b

# Inspect the tool
print(f"Name: {multiply.name}")
print(f"Description: {multiply.description}")
print(f"Args Schema: {multiply.args_schema.schema()}")
```

### Key Points About @tool

1. **Function name becomes tool name**: `multiply` function creates a tool named `"multiply"`
2. **Docstring becomes description**: The LLM reads this to understand when to use the tool
3. **Type hints define args schema**: `a: int, b: int` tells LLM what inputs are expected
4. **Args section is parsed**: Parameter descriptions under `Args:` are extracted

### Decorator Parameters

```python
from langchain_core.tools import tool

@tool(
    name="custom_calculator",           # Override the function name
    return_direct=False,                # If True, return tool output directly
    args_schema=None,                   # Custom Pydantic schema (optional)
    infer_schema=True,                  # Auto-generate schema from type hints
)
def calculate(expression: str) -> str:
    """Evaluate a mathematical expression."""
    return str(eval(expression))
```

### Handling Complex Arguments with Pydantic

For complex input validation, use Pydantic models:

```python
from langchain_core.tools import tool
from pydantic import BaseModel, Field
from typing import List

class SearchInput(BaseModel):
    """Schema for search tool input."""
    query: str = Field(description="The search query")
    max_results: int = Field(default=5, description="Maximum results to return")
    filters: List[str] = Field(default=[], description="Optional filters")

@tool(args_schema=SearchInput)
def advanced_search(query: str, max_results: int = 5, filters: List[str] = []) -> str:
    """Perform an advanced search with filters.
    
    Args:
        query: The search query string.
        max_results: Maximum number of results (default: 5).
        filters: Optional list of filters to apply.
    
    Returns:
        Search results as a formatted string.
    """
    # Implementation here
    return f"Searching for '{query}' with {max_results} results and filters: {filters}"
```

---

## StructuredTool

`StructuredTool` provides more control over tool configuration than the `@tool` decorator. Use it when you need custom validation, error handling, or complex parameter rules.

### Creating with StructuredTool.from_function

```python
from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field

class CalculatorInput(BaseModel):
    """Input schema for calculator."""
    expression: str = Field(description="Mathematical expression to evaluate")

def calculate_func(expression: str) -> str:
    """Evaluate a mathematical expression."""
    try:
        result = eval(expression)
        return f"Result: {result}"
    except Exception as e:
        return f"Error: {str(e)}"

calculator = StructuredTool.from_function(
    func=calculate_func,
    name="calculator",
    description="Useful for evaluating mathematical expressions",
    args_schema=CalculatorInput,
    return_direct=False,
    handle_tool_error=True,  # Handle errors gracefully
)
```

### Subclassing BaseTool

For maximum control, subclass `BaseTool`:

```python
from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field
from typing import Type, Optional

class WeatherInput(BaseModel):
    """Input for weather tool."""
    city: str = Field(description="City name to get weather for")
    units: str = Field(default="celsius", description="Temperature units")

class WeatherTool(BaseTool):
    """Tool for getting weather information."""
    
    name: str = "get_weather"
    description: str = "Get the current weather for a specified city"
    args_schema: Type[BaseModel] = WeatherInput
    return_direct: bool = False
    
    def _run(self, city: str, units: str = "celsius") -> str:
        """Synchronous implementation."""
        # Your implementation here
        return f"Weather in {city}: 22 degrees {units}"
    
    async def _arun(self, city: str, units: str = "celsius") -> str:
        """Asynchronous implementation."""
        # Your async implementation here
        return f"Weather in {city}: 22 degrees {units}"

# Create instance
weather_tool = WeatherTool()
```

### Comparison: @tool vs StructuredTool vs BaseTool

```
+-------------------+------------------+------------------+------------------+
|     Feature       |     @tool        |  StructuredTool  |    BaseTool      |
+-------------------+------------------+------------------+------------------+
| Ease of use       |     Easiest      |     Medium       |     Most work    |
| Control level     |     Basic        |     Medium       |     Full         |
| Custom validation |     Limited      |     Yes          |     Yes          |
| Async support     |     Auto         |     Auto         |     Manual       |
| Error handling    |     Basic        |     Configurable |     Full control |
| Best for          |     Simple tools |     Medium       |     Complex      |
+-------------------+------------------+------------------+------------------+
```

---

## Tool Creation Best Practices

### 1. Write Clear Descriptions

The description is what the LLM reads to decide when to use a tool:

```python
# BAD - Vague description
@tool
def search(query: str) -> str:
    """Search for stuff."""
    pass

# GOOD - Clear, specific description
@tool
def search_knowledge_base(query: str) -> str:
    """Search the company knowledge base for policy documents and FAQs.
    
    Use this tool when the user asks about company policies, procedures,
    or frequently asked questions. Do NOT use for general web searches.
    
    Args:
        query: The search query - be specific and use relevant keywords.
    
    Returns:
        Relevant documents and their excerpts.
    """
    pass
```

### 2. Use Precise Type Hints

```python
from typing import List, Optional, Dict, Any

# BAD - Missing type hints
@tool
def process_data(data):
    """Process data."""
    pass

# GOOD - Complete type hints
@tool
def process_data(
    data: Dict[str, Any],
    filters: Optional[List[str]] = None,
    limit: int = 100
) -> Dict[str, Any]:
    """Process structured data with optional filtering.
    
    Args:
        data: Dictionary containing the data to process.
        filters: Optional list of field names to filter by.
        limit: Maximum number of results to return (default: 100).
    
    Returns:
        Processed data dictionary with results and metadata.
    """
    pass
```

### 3. Handle Errors Gracefully

```python
@tool
def divide_numbers(a: float, b: float) -> str:
    """Divide two numbers.
    
    Args:
        a: The dividend (number to be divided).
        b: The divisor (number to divide by).
    
    Returns:
        The quotient or an error message if division fails.
    """
    try:
        if b == 0:
            return "Error: Cannot divide by zero"
        result = a / b
        return f"Result: {result}"
    except Exception as e:
        return f"Error performing division: {str(e)}"
```

### 4. Keep Tools Focused

```python
# BAD - Tool does too many things
@tool
def do_everything(action: str, data: str) -> str:
    """Search, calculate, or fetch data based on action."""
    if action == "search":
        # search logic
        pass
    elif action == "calculate":
        # calculation logic
        pass
    # etc.

# GOOD - Single responsibility
@tool
def search_documents(query: str) -> str:
    """Search documents in the knowledge base."""
    pass

@tool
def calculate_expression(expression: str) -> str:
    """Evaluate a mathematical expression."""
    pass
```

---

## Tool Anatomy and Schema

### Understanding Tool Schema

When you create a tool, LangChain generates a JSON schema that the LLM uses:

```python
from langchain_core.tools import tool
import json

@tool
def get_stock_price(symbol: str, include_history: bool = False) -> str:
    """Get the current stock price for a given symbol.
    
    Args:
        symbol: The stock ticker symbol (e.g., 'AAPL', 'GOOGL').
        include_history: Whether to include 30-day price history.
    
    Returns:
        Current price and optional historical data.
    """
    return f"Stock price for {symbol}"

# View the generated schema
print(json.dumps(get_stock_price.args_schema.schema(), indent=2))
```

Output:
```json
{
  "title": "get_stock_priceSchema",
  "type": "object",
  "properties": {
    "symbol": {
      "title": "Symbol",
      "description": "The stock ticker symbol (e.g., 'AAPL', 'GOOGL').",
      "type": "string"
    },
    "include_history": {
      "title": "Include History",
      "description": "Whether to include 30-day price history.",
      "default": false,
      "type": "boolean"
    }
  },
  "required": ["symbol"]
}
```

### Tool Invocation Flow

```
+-------------------+
|   LLM receives    |
|   tool schemas    |
+--------+----------+
         |
         v
+-------------------+
|   LLM decides to  |
|   call a tool     |
+--------+----------+
         |
         v
+-------------------+
|   LLM generates   |
|   tool call JSON  |
+--------+----------+
         |
         v
+-------------------+
|   LangChain       |
|   validates args  |
+--------+----------+
         |
         v
+-------------------+
|   Tool function   |
|   executes        |
+--------+----------+
         |
         v
+-------------------+
|   Result returned |
|   to LLM          |
+-------------------+
```

---

## Summary

| Concept | Key Takeaway |
|---------|--------------|
| **Tools** | Interfaces for LLMs to interact with external systems |
| **@tool decorator** | Simplest way to create tools from Python functions |
| **StructuredTool** | More control via `from_function()` method |
| **BaseTool** | Full control via subclassing for complex tools |
| **Descriptions** | Critical for LLM to understand when/how to use tools |
| **Type hints** | Define the args schema automatically |
| **Error handling** | Always handle errors gracefully in tools |

---

## Next Steps

In the next section, we'll explore the built-in tools that LangChain provides out of the box, including search, calculator, Wikipedia, and more.

---

## References

- [LangChain Tools Documentation](https://docs.langchain.com/oss/python/langchain/tools)
- [Structured Tools Blog](https://www.langchain.com/blog/structured-tools)
- [Create Custom Tools Tutorial](https://langchain-tutorials.github.io/create-custom-tools-langchain-agents-tutorial/)
- [@tool decorator patterns](https://theneuralbase.com/langchain-advanced/learn/intermediate/tool-decorator-patterns/)
