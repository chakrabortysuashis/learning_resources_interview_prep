# Module 06: Runnables and LCEL
## 03 - Runnable Primitives

---

## Introduction

LangChain provides several **Runnable primitives** - foundational building blocks that enable flexible chain construction. These primitives allow you to pass data through unchanged, transform data with custom functions, and execute multiple operations in parallel.

```
+--------------------+--------------------+--------------------+
| RunnablePassthrough| RunnableLambda     | RunnableParallel   |
+--------------------+--------------------+--------------------+
| Pass data through  | Custom transforms  | Parallel execution |
| unchanged or add   | using Python       | of multiple        |
| extra keys         | functions          | runnables          |
+--------------------+--------------------+--------------------+
```

---

## RunnablePassthrough

### What is RunnablePassthrough?

`RunnablePassthrough` behaves like an identity function - it passes inputs through unchanged. However, it can also be configured to add additional keys to the output when the input is a dictionary.

### Basic Usage

```python
from langchain_core.runnables import RunnablePassthrough

# Create a passthrough
passthrough = RunnablePassthrough()

# Input passes through unchanged
result = passthrough.invoke("hello")
print(result)  # "hello"

result = passthrough.invoke({"name": "Alice"})
print(result)  # {"name": "Alice"}
```

### ASCII Flow Diagram

```
RunnablePassthrough (Basic):

    Input -----------------> Output (unchanged)
    "hello"                  "hello"
    {"a": 1}                 {"a": 1}


RunnablePassthrough.assign() (With Additional Keys):

    Input: {"question": "What is AI?"}
           |
           v
    +------+------+
    |  Original   |  +  |  Computed   |
    |    Keys     |     |    Keys     |
    +------+------+     +------+------+
           |                   |
           v                   v
    Output: {"question": "What is AI?", "length": 11}
```

### Using assign() to Add Keys

The `assign()` method creates a new dictionary that includes all original keys plus computed values:

```python
from langchain_core.runnables import RunnablePassthrough

# Add computed keys to the input
chain = RunnablePassthrough.assign(
    uppercased=lambda x: x["text"].upper(),
    length=lambda x: len(x["text"])
)

result = chain.invoke({"text": "hello world"})
print(result)
# {
#     "text": "hello world",
#     "length": 11,
#     "uppercased": "HELLO WORLD"
# }
```

### Common Use Cases

#### 1. Preserving Original Input in Chains

```python
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough, RunnableParallel

# Chain that keeps the original question alongside the answer
chain = RunnableParallel(
    question=RunnablePassthrough(),  # Keep original input
    answer=(
        ChatPromptTemplate.from_template("Answer: {question}")
        | ChatOpenAI(model="gpt-4o")
        | StrOutputParser()
    )
)

result = chain.invoke({"question": "What is Python?"})
# result["question"] = {"question": "What is Python?"}
# result["answer"] = "Python is a programming language..."
```

#### 2. Adding Context to RAG Chains

```python
from langchain_core.runnables import RunnablePassthrough, RunnableParallel

def get_relevant_docs(query):
    # Simulate retrieval
    return ["Doc 1 content", "Doc 2 content"]

# RAG chain pattern
chain = (
    RunnableParallel(
        context=lambda x: "\n".join(get_relevant_docs(x["question"])),
        question=RunnablePassthrough()
    )
    | prompt
    | model
    | parser
)
```

#### 3. Using itemgetter for Clean Key Access

```python
from operator import itemgetter
from langchain_core.runnables import RunnablePassthrough

# Use itemgetter for cleaner syntax
chain = RunnablePassthrough.assign(
    context=itemgetter("question") | retriever,
    formatted_date=lambda x: x["date"].strftime("%Y-%m-%d")
)
```

---

## RunnableLambda

### What is RunnableLambda?

`RunnableLambda` converts any Python callable (function, lambda, or method) into a Runnable that can be used in LCEL chains.

### Basic Usage

```python
from langchain_core.runnables import RunnableLambda

# From a lambda
double = RunnableLambda(lambda x: x * 2)
print(double.invoke(5))  # 10

# From a function
def add_greeting(name: str) -> str:
    return f"Hello, {name}!"

greeter = RunnableLambda(add_greeting)
print(greeter.invoke("Alice"))  # "Hello, Alice!"
```

### ASCII Flow Diagram

```
RunnableLambda:

    Input -----> [Python Function] -----> Output
      5            lambda x: x*2            10
    "Bob"          add_greeting()       "Hello, Bob!"


In a Chain:

    +--------+     +---------------+     +---------+
    | prompt | --> | RunnableLambda| --> |  model  |
    +--------+     | (transform)   |     +---------+
                   +---------------+
```

### Advanced Usage

#### 1. Processing Model Output

```python
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda

def extract_bullet_points(text: str) -> list[str]:
    """Extract bullet points from text."""
    lines = text.split('\n')
    return [line.strip('- ').strip() for line in lines if line.strip().startswith('-')]

chain = (
    ChatPromptTemplate.from_template("List 3 facts about {topic} as bullet points")
    | ChatOpenAI(model="gpt-4o")
    | RunnableLambda(lambda msg: msg.content)
    | RunnableLambda(extract_bullet_points)
)

facts = chain.invoke({"topic": "Python"})
# ["Python was created by Guido van Rossum", ...]
```

#### 2. Data Validation

```python
from langchain_core.runnables import RunnableLambda

def validate_input(data: dict) -> dict:
    """Validate input data before processing."""
    if "question" not in data:
        raise ValueError("Input must contain 'question' key")
    if len(data["question"]) < 3:
        raise ValueError("Question must be at least 3 characters")
    return data

validated_chain = (
    RunnableLambda(validate_input)
    | prompt
    | model
    | parser
)
```

#### 3. Async Functions

```python
from langchain_core.runnables import RunnableLambda
import asyncio

async def async_process(data: str) -> str:
    await asyncio.sleep(0.1)  # Simulate async operation
    return data.upper()

# RunnableLambda handles async automatically
async_runnable = RunnableLambda(async_process)

# Use with ainvoke
result = await async_runnable.ainvoke("hello")  # "HELLO"
```

#### 4. Using Decorators

```python
from langchain_core.runnables import RunnableLambda

# Decorator style
@RunnableLambda
def format_output(data: dict) -> str:
    return f"Name: {data['name']}, Age: {data['age']}"

result = format_output.invoke({"name": "Alice", "age": 30})
# "Name: Alice, Age: 30"
```

### Error Handling in RunnableLambda

```python
from langchain_core.runnables import RunnableLambda

def safe_divide(data: dict) -> float:
    try:
        return data["numerator"] / data["denominator"]
    except ZeroDivisionError:
        return float("inf")
    except KeyError as e:
        raise ValueError(f"Missing key: {e}")

safe_divider = RunnableLambda(safe_divide)

print(safe_divider.invoke({"numerator": 10, "denominator": 2}))   # 5.0
print(safe_divider.invoke({"numerator": 10, "denominator": 0}))   # inf
```

---

## RunnableParallel

### What is RunnableParallel?

`RunnableParallel` executes multiple Runnables in parallel on the same input, returning a dictionary of results. This is essential for performance optimization and building complex data flows.

### Basic Usage

```python
from langchain_core.runnables import RunnableParallel, RunnableLambda

# Define parallel operations
parallel = RunnableParallel(
    doubled=RunnableLambda(lambda x: x * 2),
    squared=RunnableLambda(lambda x: x ** 2),
    original=RunnableLambda(lambda x: x)
)

result = parallel.invoke(5)
print(result)
# {"doubled": 10, "squared": 25, "original": 5}
```

### ASCII Flow Diagram

```
RunnableParallel Execution:

                    +---> [Runnable A] ---> result_a ---+
                    |                                    |
    Input ---+------+---> [Runnable B] ---> result_b ---+---> {"a": result_a,
             |      |                                    |      "b": result_b,
             |      +---> [Runnable C] ---> result_c ---+       "c": result_c}
             |
             +---- Same input sent to all branches


Parallel Timing Diagram:

    Time --->

    Runnable A: [====]
    Runnable B: [========]      All run simultaneously
    Runnable C: [======]
                        ^
                        |
                   Total time = max(A, B, C)
                   NOT A + B + C (sequential)
```

### Dictionary Shorthand

You can use a dictionary directly instead of `RunnableParallel()`:

```python
from langchain_core.runnables import RunnableParallel

# These are equivalent:
parallel1 = RunnableParallel(
    upper=lambda x: x.upper(),
    lower=lambda x: x.lower()
)

parallel2 = {
    "upper": lambda x: x.upper(),
    "lower": lambda x: x.lower()
}  # Automatically converted to RunnableParallel in LCEL

# In a chain
chain = some_runnable | {"a": chain1, "b": chain2} | next_runnable
```

### Common Patterns

#### Pattern 1: Multi-Model Comparison

```python
from langchain_openai import ChatOpenAI
from langchain_anthropic import ChatAnthropic
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnableParallel

prompt = ChatPromptTemplate.from_template("Explain {topic} simply")
parser = StrOutputParser()

# Compare responses from different models
comparison_chain = RunnableParallel(
    gpt4=prompt | ChatOpenAI(model="gpt-4o") | parser,
    claude=prompt | ChatAnthropic(model="claude-3-5-sonnet-20241022") | parser
)

results = comparison_chain.invoke({"topic": "quantum computing"})
print("GPT-4:", results["gpt4"])
print("Claude:", results["claude"])
```

#### Pattern 2: RAG with Context and Question

```python
from langchain_core.runnables import RunnableParallel, RunnablePassthrough

def retrieve_docs(question: str) -> str:
    # Simulate retrieval
    return "Retrieved context about " + question

rag_chain = (
    RunnableParallel(
        context=lambda x: retrieve_docs(x["question"]),
        question=lambda x: x["question"]
    )
    | ChatPromptTemplate.from_template(
        "Context: {context}\n\nQuestion: {question}\n\nAnswer:"
    )
    | ChatOpenAI(model="gpt-4o")
    | StrOutputParser()
)

answer = rag_chain.invoke({"question": "What is LangChain?"})
```

#### Pattern 3: Parallel Processing with Aggregation

```python
from langchain_core.runnables import RunnableParallel, RunnableLambda

def analyze_sentiment(text: str) -> str:
    return "positive"  # Simplified

def extract_entities(text: str) -> list:
    return ["entity1", "entity2"]  # Simplified

def count_words(text: str) -> int:
    return len(text.split())

# Parallel analysis
analysis_chain = RunnableParallel(
    sentiment=RunnableLambda(analyze_sentiment),
    entities=RunnableLambda(extract_entities),
    word_count=RunnableLambda(count_words)
)

# Aggregate results
def aggregate(results: dict) -> str:
    return f"""
    Analysis Results:
    - Sentiment: {results['sentiment']}
    - Entities: {', '.join(results['entities'])}
    - Word Count: {results['word_count']}
    """

full_chain = analysis_chain | RunnableLambda(aggregate)

report = full_chain.invoke("LangChain is an amazing framework for AI.")
print(report)
```

#### Pattern 4: Conditional Parallel Execution

```python
from langchain_core.runnables import RunnableParallel, RunnableLambda

def maybe_translate(data: dict) -> dict:
    """Only translate if not in English."""
    if data.get("language") != "en":
        data["translated"] = translate(data["text"])
    return data

# Parallel with conditional logic
chain = RunnableParallel(
    processed=RunnableLambda(maybe_translate),
    metadata=RunnableLambda(lambda x: {"length": len(x["text"])})
)
```

---

## Combining Primitives

The real power comes from combining these primitives:

### Example: Complete Processing Pipeline

```python
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import (
    RunnablePassthrough,
    RunnableLambda,
    RunnableParallel
)

# Custom processing functions
def preprocess(text: str) -> str:
    return text.strip().lower()

def postprocess(response: str) -> dict:
    return {
        "response": response,
        "word_count": len(response.split()),
        "char_count": len(response)
    }

# Build the pipeline
pipeline = (
    # Step 1: Preprocess and preserve original
    RunnableParallel(
        processed=RunnableLambda(lambda x: preprocess(x["text"])),
        original=RunnablePassthrough()
    )
    # Step 2: Generate response
    | RunnablePassthrough.assign(
        response=(
            RunnableLambda(lambda x: {"text": x["processed"]})
            | ChatPromptTemplate.from_template("Summarize: {text}")
            | ChatOpenAI(model="gpt-4o")
            | StrOutputParser()
        )
    )
    # Step 3: Postprocess
    | RunnableLambda(lambda x: {
        **x,
        "stats": postprocess(x["response"])
    })
)

result = pipeline.invoke({"text": "  HELLO WORLD, this is a test.  "})
```

### Example: Multi-Stage Document Processing

```python
from langchain_core.runnables import (
    RunnablePassthrough,
    RunnableLambda,
    RunnableParallel
)

# Stage 1: Parse document
parse_stage = RunnableParallel(
    title=RunnableLambda(lambda x: x.split('\n')[0]),
    body=RunnableLambda(lambda x: '\n'.join(x.split('\n')[1:])),
    raw=RunnablePassthrough()
)

# Stage 2: Analyze content
analyze_stage = RunnableParallel(
    summary=lambda x: summarize(x["body"]),
    keywords=lambda x: extract_keywords(x["body"]),
    metadata=lambda x: {"title": x["title"], "length": len(x["body"])}
)

# Stage 3: Format output
format_stage = RunnableLambda(lambda x: {
    "processed": True,
    "summary": x["summary"],
    "keywords": x["keywords"],
    **x["metadata"]
})

# Complete pipeline
document_processor = parse_stage | analyze_stage | format_stage
```

---

## Performance Considerations

### RunnableParallel Performance

```python
import time
from langchain_core.runnables import RunnableParallel, RunnableLambda

def slow_operation_a(x):
    time.sleep(1)  # Simulates 1 second operation
    return x * 2

def slow_operation_b(x):
    time.sleep(1)  # Simulates 1 second operation
    return x * 3

# Sequential: ~2 seconds
start = time.time()
result_a = slow_operation_a(5)
result_b = slow_operation_b(5)
print(f"Sequential: {time.time() - start:.2f}s")  # ~2.00s

# Parallel: ~1 second
parallel = RunnableParallel(
    a=RunnableLambda(slow_operation_a),
    b=RunnableLambda(slow_operation_b)
)
start = time.time()
result = parallel.invoke(5)
print(f"Parallel: {time.time() - start:.2f}s")    # ~1.00s
```

### Batch Processing

All primitives support batch operations:

```python
from langchain_core.runnables import RunnableParallel, RunnableLambda

parallel = RunnableParallel(
    doubled=RunnableLambda(lambda x: x * 2),
    squared=RunnableLambda(lambda x: x ** 2)
)

# Batch process multiple inputs
results = parallel.batch([1, 2, 3, 4, 5])
# [
#     {"doubled": 2, "squared": 1},
#     {"doubled": 4, "squared": 4},
#     {"doubled": 6, "squared": 9},
#     ...
# ]
```

---

## Quick Reference Table

| Primitive | Purpose | Input | Output |
|-----------|---------|-------|--------|
| `RunnablePassthrough()` | Pass input unchanged | Any | Same as input |
| `RunnablePassthrough.assign()` | Add computed keys | Dict | Dict with extra keys |
| `RunnableLambda(fn)` | Custom transformation | Depends on fn | Depends on fn |
| `RunnableParallel({...})` | Parallel execution | Any | Dict of results |

### Import Reference

```python
from langchain_core.runnables import (
    RunnablePassthrough,
    RunnableLambda,
    RunnableParallel,
)
from operator import itemgetter  # Useful with RunnablePassthrough
```

---

## Summary

- **RunnablePassthrough**: Identity function, optionally adds computed keys with `assign()`
- **RunnableLambda**: Converts any Python function into a Runnable for use in chains
- **RunnableParallel**: Executes multiple Runnables simultaneously, returning a dictionary

These primitives are the building blocks for creating sophisticated LCEL chains with custom logic, parallel processing, and flexible data transformations.

---

## Sources

- [LangChain Runnables Reference](https://reference.langchain.com/python/langchain-core/runnables)
- [RunnablePassthrough API Reference](https://api.python.langchain.com/en/latest/core/runnables/langchain_core.runnables.passthrough.RunnablePassthrough.html)
- [How to Use Runnable in LangChain - Medium](https://medium.com/data-and-beyond/runnable-and-its-types-in-langchain-3b7a1ccfc922)
- [Runnables in LangChain - Medium](https://medium.com/@adarishanmukh15501/runnables-in-langchain-0c5630335685)
- [Understanding LangChain Runnables - Mirascope](https://mirascope.com/blog/langchain-runnables)
