# Module 06: Runnables and LCEL
## 02 - LangChain Expression Language (LCEL) Basics

---

## Introduction

**LangChain Expression Language (LCEL)** is a declarative domain-specific language (DSL) that provides a standardized method for composing LangChain components into chains. Introduced in Q3 2023, LCEL has become the recommended approach for building chains, superseding the traditional `LLMChain` and other legacy chain classes.

```
Traditional (Deprecated):
    chain = LLMChain(llm=model, prompt=prompt)

LCEL (Recommended):
    chain = prompt | model | parser
```

---

## What is LCEL?

LCEL uses the **pipe operator (`|`)** to connect components, similar to Unix shell pipelines:

```
+---------+     +---------+     +---------+
|  Input  | --> | Step 1  | --> | Step 2  | --> Output
+---------+     +---------+     +---------+
                    |               |
                    +-------+-------+
                            |
                    Pipe Operator (|)
```

### Key Characteristics

| Characteristic | Description |
|----------------|-------------|
| **Declarative** | You describe *what* you want, not *how* to do it |
| **Composable** | Small, reusable components combine into complex pipelines |
| **Consistent** | Same chain works with sync, async, streaming, or batch |
| **Optimized** | Built-in parallelism and lazy evaluation |

---

## The Pipe Operator (`|`)

The pipe operator is the core of LCEL. It connects two Runnables where the output of the left side becomes the input of the right side.

### Basic Syntax

```python
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

# Define components
prompt = ChatPromptTemplate.from_template("Tell me a joke about {topic}")
model = ChatOpenAI(model="gpt-4o")
parser = StrOutputParser()

# Connect with pipe operator
chain = prompt | model | parser
#       ------   -----   ------
#       Step 1   Step 2  Step 3

# Use the chain
result = chain.invoke({"topic": "programming"})
print(result)
```

### How the Pipe Operator Works

```
chain = prompt | model | parser

Step-by-step execution:

1. Input: {"topic": "programming"}
         |
         v
2. prompt.invoke({"topic": "programming"})
   Output: ChatPromptValue("Tell me a joke about programming")
         |
         v
3. model.invoke(ChatPromptValue)
   Output: AIMessage(content="Why do programmers...")
         |
         v
4. parser.invoke(AIMessage)
   Output: "Why do programmers prefer dark mode?..."
         |
         v
5. Final Result: "Why do programmers prefer dark mode?..."
```

---

## Building Your First LCEL Chain

### Step 1: Import Components

```python
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
```

### Step 2: Create Individual Components

```python
# Prompt template - formats user input
prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a helpful assistant that speaks like a pirate."),
    ("human", "{question}")
])

# Language model - generates response
model = ChatOpenAI(model="gpt-4o", temperature=0.7)

# Output parser - extracts string from AIMessage
parser = StrOutputParser()
```

### Step 3: Compose with Pipe Operator

```python
# Create the chain
pirate_chain = prompt | model | parser
```

### Step 4: Execute the Chain

```python
# Using invoke()
response = pirate_chain.invoke({"question": "What's the weather like today?"})
print(response)
# Output: "Ahoy, matey! I be not able to check the weather..."

# Using stream()
for chunk in pirate_chain.stream({"question": "Tell me about the ocean"}):
    print(chunk, end="", flush=True)

# Using batch()
questions = [
    {"question": "What is gold?"},
    {"question": "What is a ship?"},
]
responses = pirate_chain.batch(questions)
```

---

## LCEL Data Flow

Understanding how data flows through an LCEL chain is crucial:

```
                        LCEL Chain Data Flow
                        ====================

Input Dict               Prompt                  Model                Parser
{"topic": "AI"}   -->   ChatPromptValue   -->   AIMessage   -->   String
     |                        |                     |                |
     |                        |                     |                |
     v                        v                     v                v
+----------+           +------------+         +-----------+     +--------+
| Variable |   --->    | Formatted  |  --->   | Generated |---> | Clean  |
| Mapping  |           | Messages   |         | Response  |     | Output |
+----------+           +------------+         +-----------+     +--------+
```

### Type Transformations

| Component | Input Type | Output Type |
|-----------|------------|-------------|
| `ChatPromptTemplate` | `Dict[str, Any]` | `ChatPromptValue` |
| `ChatOpenAI` | `ChatPromptValue` or `List[Message]` | `AIMessage` |
| `StrOutputParser` | `AIMessage` | `str` |

---

## Common LCEL Patterns

### Pattern 1: Simple Q&A Chain

```python
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

chain = (
    ChatPromptTemplate.from_template("Answer briefly: {question}")
    | ChatOpenAI(model="gpt-4o")
    | StrOutputParser()
)

answer = chain.invoke({"question": "What is LCEL?"})
```

### Pattern 2: Chain with JSON Output

```python
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import JsonOutputParser
from pydantic import BaseModel

class Joke(BaseModel):
    setup: str
    punchline: str

parser = JsonOutputParser(pydantic_object=Joke)

chain = (
    ChatPromptTemplate.from_template(
        "Tell me a joke about {topic}.\n{format_instructions}"
    ).partial(format_instructions=parser.get_format_instructions())
    | ChatOpenAI(model="gpt-4o")
    | parser
)

joke = chain.invoke({"topic": "programming"})
print(f"Setup: {joke['setup']}")
print(f"Punchline: {joke['punchline']}")
```

### Pattern 3: Multi-Step Chain

```python
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

model = ChatOpenAI(model="gpt-4o")

# Step 1: Generate an idea
idea_chain = (
    ChatPromptTemplate.from_template("Generate a creative idea about {topic}")
    | model
    | StrOutputParser()
)

# Step 2: Expand on the idea
expand_chain = (
    ChatPromptTemplate.from_template("Expand on this idea: {idea}")
    | model
    | StrOutputParser()
)

# Combine chains
def generate_and_expand(topic: str) -> str:
    idea = idea_chain.invoke({"topic": topic})
    expanded = expand_chain.invoke({"idea": idea})
    return expanded

result = generate_and_expand("sustainable energy")
```

### Pattern 4: Chain with Memory Context

```python
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.output_parsers import StrOutputParser
from langchain_core.messages import HumanMessage, AIMessage

prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a helpful assistant."),
    MessagesPlaceholder(variable_name="history"),
    ("human", "{input}")
])

chain = prompt | ChatOpenAI(model="gpt-4o") | StrOutputParser()

# Maintain conversation history
history = []

def chat(user_input: str) -> str:
    response = chain.invoke({"history": history, "input": user_input})
    history.append(HumanMessage(content=user_input))
    history.append(AIMessage(content=response))
    return response

print(chat("Hi, my name is Alice"))
print(chat("What's my name?"))  # Will remember "Alice"
```

---

## LCEL vs Traditional Chains

### Traditional Approach (Deprecated)

```python
# Old way - DON'T USE
from langchain.chains import LLMChain

chain = LLMChain(
    llm=model,
    prompt=prompt,
    output_parser=parser
)
result = chain.run(topic="AI")
```

### LCEL Approach (Recommended)

```python
# New way - USE THIS
chain = prompt | model | parser
result = chain.invoke({"topic": "AI"})
```

### Comparison Table

| Feature | Traditional Chain | LCEL |
|---------|-------------------|------|
| Syntax | Verbose, OOP-style | Concise, functional |
| Streaming | Manual setup | Built-in |
| Async | Manual setup | Built-in |
| Batch | Manual setup | Built-in |
| Composability | Limited | First-class |
| Debugging | Harder | Easier with LangSmith |

---

## Understanding Input/Output Requirements

### Matching Types Between Components

For the pipe operator to work, the output type of one component must be compatible with the input type of the next:

```
Valid Chain:
    prompt (outputs ChatPromptValue) | model (accepts ChatPromptValue) ✓

Invalid Chain:
    parser (outputs str) | model (expects Messages) ✗
```

### Common Component Signatures

```python
# Prompt Templates
ChatPromptTemplate:
    Input:  Dict[str, Any]
    Output: ChatPromptValue

# Language Models
ChatOpenAI:
    Input:  ChatPromptValue | List[BaseMessage] | str
    Output: AIMessage

# Output Parsers
StrOutputParser:
    Input:  AIMessage
    Output: str

JsonOutputParser:
    Input:  AIMessage
    Output: Dict | Pydantic Model
```

---

## Debugging LCEL Chains

### Using LangSmith (Recommended)

```python
import os
os.environ["LANGCHAIN_TRACING_V2"] = "true"
os.environ["LANGCHAIN_API_KEY"] = "your-api-key"

# Now all chain executions are traced in LangSmith
result = chain.invoke({"topic": "debugging"})
```

### Manual Inspection

```python
from langchain_core.runnables import RunnableLambda

def debug_step(x):
    print(f"Debug: {type(x)} = {x}")
    return x

debug = RunnableLambda(debug_step)

# Insert debug step between components
chain = prompt | debug | model | debug | parser

result = chain.invoke({"topic": "testing"})
```

### Viewing Chain Structure

```python
# Print the chain structure
print(chain)

# Get input/output schemas
print("Input Schema:", chain.input_schema.schema())
print("Output Schema:", chain.output_schema.schema())
```

---

## Best Practices

### 1. Use Parentheses for Readability

```python
# Good - clear structure
chain = (
    prompt
    | model
    | parser
)

# Also good - single line for simple chains
chain = prompt | model | parser
```

### 2. Name Your Chains for Tracing

```python
result = chain.invoke(
    {"topic": "best practices"},
    config={"run_name": "joke_generator"}
)
```

### 3. Handle Errors Gracefully

```python
from langchain_core.runnables import RunnableLambda

def safe_parse(text):
    try:
        return parser.parse(text)
    except Exception as e:
        return {"error": str(e)}

safe_chain = prompt | model | RunnableLambda(safe_parse)
```

### 4. Keep Chains Focused

```python
# Good - single responsibility
summarize_chain = summarize_prompt | model | parser
translate_chain = translate_prompt | model | parser

# Use them separately or compose as needed
```

---

## Quick Reference

### LCEL Operators

| Operator | Meaning | Example |
|----------|---------|---------|
| `\|` | Pipe/compose | `prompt \| model` |
| `RunnableParallel({})` | Parallel execution | `{"a": chain1, "b": chain2}` |

### Common Imports

```python
# Core
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser, JsonOutputParser
from langchain_core.runnables import (
    RunnablePassthrough,
    RunnableLambda,
    RunnableParallel,
)

# Models
from langchain_openai import ChatOpenAI
from langchain_anthropic import ChatAnthropic

# Messages
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
```

---

## Summary

LCEL provides a clean, declarative way to build LangChain applications:

1. **Pipe operator (`|`)** connects components sequentially
2. **Data flows** from left to right through the chain
3. **All Runnable methods** (invoke, batch, stream) work automatically
4. **Type compatibility** between components is essential
5. **Supersedes traditional chains** like LLMChain

LCEL is the foundation for building modern LangChain applications and understanding it is essential for working with the framework effectively.

---

## Sources

- [LangChain Expression Language - Pinecone](https://www.pinecone.io/learn/series/langchain/langchain-expression-language/)
- [What Is LCEL - Cobus Greyling](https://cobusgreyling.medium.com/what-is-langchain-expression-language-lcel-8a828c38b37d)
- [LCEL Interface - LangChain OpenTutorial](https://langchain-opentutorial.gitbook.io/langchain-opentutorial/01-basic/07-lcel-interface)
- [LangChain Complete Guide 2026](https://devops.gheware.com/blog/posts/langchain-complete-guide-2026.html)
- [LangChain LCEL - Aurelio AI](https://www.aurelio.ai/learn/langchain-lcel)
