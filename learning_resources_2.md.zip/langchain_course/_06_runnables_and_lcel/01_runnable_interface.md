# Module 06: Runnables and LCEL
## 01 - Understanding the Runnable Interface

---

## Introduction

The **Runnable** interface is the foundational abstraction in LangChain that provides a standardized protocol for all components. Every major component in LangChain - from chat models to prompts to chains - implements the Runnable interface without modification.

```
+-------------------+
|     Runnable      |
|   (Base Class)    |
+-------------------+
         |
    implements
         |
    +----+----+----+----+----+
    |    |    |    |    |    |
    v    v    v    v    v    v
Prompt Model Parser Retriever Chain Tool
```

---

## What is a Runnable?

A **Runnable** is any object that knows how to:
1. Take an **input**
2. Produce an **output**
3. Optionally provide **streaming** and **batch** execution

### Key Properties

Every Runnable exposes schematic information:

| Property | Description |
|----------|-------------|
| `input_schema` | Pydantic schema describing valid inputs |
| `output_schema` | Pydantic schema describing the output type |
| `config_schema()` | Method returning configuration options |

```python
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate

# Check input/output schemas
model = ChatOpenAI()
print(model.input_schema.schema())
print(model.output_schema.schema())

prompt = ChatPromptTemplate.from_template("Tell me about {topic}")
print(prompt.input_schema.schema())
```

---

## The Three Core Methods

Every Runnable provides three primary synchronous methods:

```
+------------------+------------------+------------------+
|     invoke()     |     batch()      |     stream()     |
+------------------+------------------+------------------+
|  Single Input    |  Multiple Inputs |  Token-by-Token  |
|  Single Output   |  List of Outputs |  Chunked Output  |
|  Synchronous     |  Parallel Exec   |  Real-time       |
+------------------+------------------+------------------+
```

### 1. invoke() - Single Execution

The most basic method. Takes a single input and returns a single output.

```python
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage

model = ChatOpenAI(model="gpt-4o")

# invoke() with a single input
result = model.invoke([HumanMessage(content="What is LangChain?")])
print(result.content)
```

**When to use:** 
- Simple, one-off executions
- Debugging and testing
- When you need the complete response before proceeding

---

### 2. batch() - Parallel Execution

Processes multiple inputs in parallel using a thread pool executor.

```python
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage

model = ChatOpenAI(model="gpt-4o")

# batch() with multiple inputs
messages = [
    [HumanMessage(content="What is Python?")],
    [HumanMessage(content="What is JavaScript?")],
    [HumanMessage(content="What is Rust?")]
]

results = model.batch(messages)
for r in results:
    print(r.content[:100], "...")
```

**Configuration Options:**

```python
# Control parallelism with max_concurrency
results = model.batch(
    messages,
    config={"max_concurrency": 2}  # Limit to 2 parallel calls
)
```

**When to use:**
- Processing multiple independent inputs
- Improving throughput for IO-bound operations
- Bulk processing tasks

---

### 3. stream() - Streaming Output

Yields output chunks as they become available. Essential for real-time user interfaces.

```python
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage

model = ChatOpenAI(model="gpt-4o")

# stream() for real-time output
for chunk in model.stream([HumanMessage(content="Write a haiku about coding")]):
    print(chunk.content, end="", flush=True)
```

**Important Production Note:**
> `stream()` yields string chunks that may split mid-token (especially with streaming LLMs). Always concatenate or join chunks before processing the complete result.

```python
# Safe streaming with accumulation
full_response = ""
for chunk in model.stream([HumanMessage(content="Explain recursion")]):
    full_response += chunk.content
    print(chunk.content, end="", flush=True)

# Now full_response contains the complete text
print(f"\n\nTotal length: {len(full_response)}")
```

**When to use:**
- Chat interfaces requiring real-time feedback
- Long-running generations where users expect progress
- Reducing perceived latency

---

## Async Methods

Each synchronous method has an async counterpart:

| Sync Method | Async Method | Use Case |
|-------------|--------------|----------|
| `invoke()` | `ainvoke()` | Async single execution |
| `batch()` | `abatch()` | Async parallel execution |
| `stream()` | `astream()` | Async streaming |

```python
import asyncio
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage

model = ChatOpenAI(model="gpt-4o")

async def async_example():
    # Async invoke
    result = await model.ainvoke([HumanMessage(content="Hello!")])
    print(result.content)
    
    # Async batch
    messages = [
        [HumanMessage(content="What is 2+2?")],
        [HumanMessage(content="What is 3+3?")]
    ]
    results = await model.abatch(messages)
    for r in results:
        print(r.content)
    
    # Async stream
    async for chunk in model.astream([HumanMessage(content="Count to 5")]):
        print(chunk.content, end="", flush=True)

# Run the async function
asyncio.run(async_example())
```

---

## Method Comparison

```
                    invoke()              batch()               stream()
                    --------              -------               --------
Input:              Single                List[Single]          Single
Output:             Complete              List[Complete]        Iterator[Chunk]
Execution:          Sequential            Parallel (threads)    Sequential (yields)
Latency:            Wait for all          Wait for all          First token fast
Memory:             Full response         All responses         Chunk at a time

ASCII Flow Diagram:

invoke():
    Input -----> [Runnable] -----> Complete Output

batch():
    Input1 ----+
    Input2 ----+----> [Runnable Pool] -----> [Output1, Output2, Output3]
    Input3 ----+

stream():
    Input -----> [Runnable] --chunk1--> --chunk2--> --chunk3--> ...
```

---

## The Config Parameter

All methods accept an optional `config` dictionary:

```python
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage

model = ChatOpenAI(model="gpt-4o")

# Using config for tracing and debugging
config = {
    "run_name": "my_custom_run",          # Name for tracing
    "tags": ["production", "chat"],        # Tags for filtering
    "metadata": {"user_id": "12345"},      # Custom metadata
    "max_concurrency": 5,                  # Parallel limit (batch)
    "callbacks": [],                       # Custom callbacks
}

result = model.invoke(
    [HumanMessage(content="Hello!")],
    config=config
)
```

### Config Options Reference

| Option | Type | Description |
|--------|------|-------------|
| `run_name` | `str` | Custom name for the run (useful in LangSmith) |
| `tags` | `List[str]` | Tags for categorizing runs |
| `metadata` | `Dict` | Arbitrary metadata attached to the run |
| `max_concurrency` | `int` | Maximum parallel executions (batch only) |
| `callbacks` | `List[Callback]` | Custom callback handlers |
| `configurable` | `Dict` | Runtime configuration for configurable runnables |

---

## Practical Examples

### Example 1: Building a Simple Q&A with invoke()

```python
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

# Create components
prompt = ChatPromptTemplate.from_template(
    "Answer the following question concisely: {question}"
)
model = ChatOpenAI(model="gpt-4o")
parser = StrOutputParser()

# Build chain using pipe operator (LCEL)
chain = prompt | model | parser

# Use invoke
answer = chain.invoke({"question": "What is the capital of France?"})
print(answer)  # "Paris"
```

### Example 2: Batch Processing Documents

```python
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

prompt = ChatPromptTemplate.from_template("Summarize this text: {text}")
model = ChatOpenAI(model="gpt-4o")
parser = StrOutputParser()

chain = prompt | model | parser

# Process multiple documents in parallel
documents = [
    {"text": "Document 1 content..."},
    {"text": "Document 2 content..."},
    {"text": "Document 3 content..."},
]

summaries = chain.batch(documents, config={"max_concurrency": 3})
for i, summary in enumerate(summaries):
    print(f"Summary {i+1}: {summary[:50]}...")
```

### Example 3: Streaming Chat Interface

```python
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

prompt = ChatPromptTemplate.from_template("You are a helpful assistant. {question}")
model = ChatOpenAI(model="gpt-4o", streaming=True)
parser = StrOutputParser()

chain = prompt | model | parser

# Stream response to user
print("Assistant: ", end="")
for chunk in chain.stream({"question": "Tell me a story about a robot"}):
    print(chunk, end="", flush=True)
print()  # Newline at end
```

---

## Best Practices

### 1. Choose the Right Method

```python
# Use invoke() for simple operations
result = chain.invoke(single_input)

# Use batch() for multiple independent operations
results = chain.batch(list_of_inputs)

# Use stream() for user-facing applications
for chunk in chain.stream(input):
    display_to_user(chunk)
```

### 2. Handle Streaming Properly

```python
# WRONG: Assuming chunk boundaries are meaningful
for chunk in model.stream(input):
    process_word(chunk)  # Chunks may split mid-word!

# RIGHT: Accumulate then process
full_text = ""
for chunk in model.stream(input):
    full_text += chunk.content
    # Display progressively
    print(chunk.content, end="", flush=True)
# Process complete text
final_result = process(full_text)
```

### 3. Use Config for Observability

```python
# Always add context for debugging
result = chain.invoke(
    {"question": "..."},
    config={
        "run_name": "user_query",
        "tags": ["production"],
        "metadata": {"session_id": session_id}
    }
)
```

### 4. Consider Async for Web Applications

```python
# In FastAPI or similar frameworks
from fastapi import FastAPI
from fastapi.responses import StreamingResponse

app = FastAPI()

@app.post("/chat")
async def chat(question: str):
    async def generate():
        async for chunk in chain.astream({"question": question}):
            yield chunk
    return StreamingResponse(generate())
```

---

## Summary

| Concept | Description |
|---------|-------------|
| **Runnable** | Base protocol implemented by all LangChain components |
| **invoke()** | Single input/output, synchronous execution |
| **batch()** | Multiple inputs processed in parallel |
| **stream()** | Real-time output with iterator of chunks |
| **ainvoke/abatch/astream** | Async versions for non-blocking operations |
| **config** | Optional dict for tracing, tags, and execution control |

The Runnable interface provides a consistent way to interact with all LangChain components, enabling seamless composition and predictable behavior across different types of operations.

---

## Sources

- [LangChain Runnable Reference](https://reference.langchain.com/python/langchain-core/runnables/base/Runnable)
- [LangChain batch() Documentation](https://reference.langchain.com/python/langchain-core/runnables/base/Runnable/batch)
- [Understanding LangChain Runnables - Mirascope](https://mirascope.com/blog/langchain-runnables)
- [Runnable Protocol Tutorial - The Neural Base](https://theneuralbase.com/langchain-advanced/learn/beginner/runnable-protocol-invoke-stream-batch/)
