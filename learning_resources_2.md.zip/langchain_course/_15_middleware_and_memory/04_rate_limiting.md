# Module 15.4: Rate Limiting, Retry Logic, and Backoff Strategies

## Introduction

When building production LLM applications, you will inevitably encounter rate limits. LLM providers impose limits on requests per minute (RPM) and tokens per minute (TPM) to ensure fair usage and system stability. This module covers strategies to handle rate limits gracefully.

## Understanding Rate Limits

### Common Rate Limit Types

```
+----------------------------------+
|        Rate Limit Types          |
+----------------------------------+
|                                  |
|  1. Requests Per Minute (RPM)    |
|     - Limits API call frequency  |
|     - Typically 60-10000 RPM     |
|                                  |
|  2. Tokens Per Minute (TPM)      |
|     - Limits total token usage   |
|     - Typically 40K-2M TPM       |
|                                  |
|  3. Requests Per Day (RPD)       |
|     - Daily quota limits         |
|     - Often for free tiers       |
|                                  |
|  4. Concurrent Requests          |
|     - Parallel request limits    |
|                                  |
+----------------------------------+
```

### What Happens When You Hit a Rate Limit

```
Request --> API Gateway --> Rate Limit Check
                                  |
                     +------------+------------+
                     |                         |
                  ALLOWED                   BLOCKED
                     |                         |
                     v                         v
               Process Request         Return 429 Error
                     |                         |
                     v                         v
               200 OK Response         "Too Many Requests"
                                       Retry-After: 30s
```

### 429 Error Response Example

```python
# HTTP 429 Too Many Requests
{
    "error": {
        "message": "Rate limit reached for gpt-4o in organization org-xxx on tokens per min. Limit: 40000, Used: 39500, Requested: 1000.",
        "type": "tokens",
        "param": None,
        "code": "rate_limit_exceeded"
    }
}

# Response Headers
# Retry-After: 30
# x-ratelimit-limit-requests: 10000
# x-ratelimit-remaining-requests: 0
# x-ratelimit-reset-requests: 6ms
```

---

## Retry Strategies Overview

### Strategy Comparison

```
+----------------+------------------+------------------+------------------+
|   Strategy     |   Fixed Delay    | Exponential      | Exponential +    |
|                |                  | Backoff          | Jitter           |
+----------------+------------------+------------------+------------------+
| Retry 1        |     2s           |     1s           |   0.8s - 1.2s    |
| Retry 2        |     2s           |     2s           |   1.6s - 2.4s    |
| Retry 3        |     2s           |     4s           |   3.2s - 4.8s    |
| Retry 4        |     2s           |     8s           |   6.4s - 9.6s    |
| Retry 5        |     2s           |    16s           |  12.8s - 19.2s   |
+----------------+------------------+------------------+------------------+
| Thundering     |     HIGH         |    MEDIUM        |      LOW         |
| Herd Risk      |                  |                  |                  |
+----------------+------------------+------------------+------------------+
| Best For       | Simple cases,    | General use      | Production,      |
|                | predictable load |                  | high concurrency |
+----------------+------------------+------------------+------------------+
```

### Thundering Herd Problem

```
WITHOUT JITTER:
All retries at exactly 4s:
    
Time: 0s    4s
      |     |
      v     v
    [===]  [===][===][===][===][===]  <-- All hit at once!
    Error!  Server overwhelmed again!


WITH JITTER:
Retries spread across 3.2s - 4.8s:

Time: 0s    3.2s  3.6s  4.0s  4.4s  4.8s
      |     |     |     |     |     |
      v     v     v     v     v     v
    [===]  [=]   [=]   [=]   [=]   [=]   <-- Spread out!
    Error!  Server handles gracefully
```

---

## LangChain Built-in Retry Support

### Using .with_retry()

```python
from langchain_openai import ChatOpenAI
from langchain_core.runnables import RunnableConfig

# Create LLM with retry configuration
llm = ChatOpenAI(
    model="gpt-4o",
    max_retries=5,
    request_timeout=60
)

# Add retry wrapper to any runnable
chain_with_retry = (
    llm
    .with_retry(
        stop_after_attempt=3,
        wait_exponential_jitter=True,  # Add jitter
        retry_if_exception_type=(Exception,),  # Retry on any exception
    )
)

# Use normally - retries are automatic
response = chain_with_retry.invoke("Hello, world!")
```

### Configuring Retry Parameters

```python
from langchain_openai import ChatOpenAI

# Full retry configuration
llm = ChatOpenAI(
    model="gpt-4o",
    temperature=0,
    # Retry configuration
    max_retries=5,           # Maximum retry attempts
    request_timeout=60,       # Timeout per request in seconds
)

# With LCEL retry wrapper
chain = (
    llm
    .with_retry(
        stop_after_attempt=5,
        wait_exponential_multiplier=1,    # Base wait time in seconds
        wait_exponential_max=30,          # Maximum wait time
        retry_if_exception_type=(
            Exception,  # Retry on rate limits
        )
    )
)
```

---

## Using Tenacity for Advanced Retry Logic

### Basic Tenacity Setup

```python
from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception_type,
    before_sleep_log
)
from langchain_openai import ChatOpenAI
import logging
import openai

# Set up logging to see retry attempts
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@retry(
    stop=stop_after_attempt(5),
    wait=wait_exponential(multiplier=1, min=1, max=60),
    retry=retry_if_exception_type(openai.RateLimitError),
    before_sleep=before_sleep_log(logger, logging.WARNING)
)
def call_llm_with_retry(prompt: str) -> str:
    """Call LLM with exponential backoff retry."""
    llm = ChatOpenAI(model="gpt-4o", max_retries=0)  # Disable built-in retry
    response = llm.invoke(prompt)
    return response.content

# Usage
result = call_llm_with_retry("What is the meaning of life?")
```

### Tenacity with Jitter

```python
from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential_jitter,
    retry_if_exception_type
)
import openai

@retry(
    stop=stop_after_attempt(5),
    wait=wait_exponential_jitter(
        initial=1,      # Start with 1 second
        max=60,         # Cap at 60 seconds
        exp_base=2,     # Double each time
        jitter=5        # Add up to 5 seconds of random jitter
    ),
    retry=retry_if_exception_type(openai.RateLimitError)
)
def call_with_jitter(prompt: str) -> str:
    """Call with exponential backoff and jitter."""
    llm = ChatOpenAI(model="gpt-4o", max_retries=0)
    return llm.invoke(prompt).content
```

### Respecting Retry-After Headers

```python
from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception_type
)
import openai
import time

class RetryAfterWait:
    """Custom wait strategy that respects Retry-After header."""
    
    def __init__(self, fallback_wait=wait_exponential(multiplier=1, max=60)):
        self.fallback_wait = fallback_wait
        self.retry_after = None
    
    def __call__(self, retry_state):
        # Check if we have a Retry-After value from the last exception
        exc = retry_state.outcome.exception()
        
        if hasattr(exc, 'response') and exc.response is not None:
            retry_after = exc.response.headers.get('retry-after')
            if retry_after:
                try:
                    return float(retry_after)
                except ValueError:
                    pass
        
        # Fall back to exponential backoff
        return self.fallback_wait(retry_state)

@retry(
    stop=stop_after_attempt(5),
    wait=RetryAfterWait(),
    retry=retry_if_exception_type(openai.RateLimitError)
)
def call_respecting_retry_after(prompt: str) -> str:
    """Call LLM, respecting Retry-After header if present."""
    llm = ChatOpenAI(model="gpt-4o", max_retries=0)
    return llm.invoke(prompt).content
```

---

## Proactive Rate Limiting

### Token Bucket Algorithm

```
+------------------------------------------+
|          Token Bucket Concept            |
+------------------------------------------+
|                                          |
|  Bucket Capacity: 100 tokens             |
|  Refill Rate: 10 tokens/second           |
|                                          |
|  [=========]  Full (100 tokens)          |
|  [======   ]  After 40-token request     |
|  [=======  ]  1 second later (+10)       |
|  [========]   2 seconds later (+10)      |
|                                          |
|  If request needs more tokens than       |
|  available: WAIT until refilled          |
|                                          |
+------------------------------------------+
```

### Implementation with aiolimiter

```python
from aiolimiter import AsyncLimiter
from langchain_openai import ChatOpenAI
import asyncio

# Create rate limiter: 50 requests per minute
rate_limiter = AsyncLimiter(50, 60)  # 50 tokens, 60 second window

async def rate_limited_call(prompt: str) -> str:
    """Make rate-limited async LLM call."""
    async with rate_limiter:
        llm = ChatOpenAI(model="gpt-4o")
        response = await llm.ainvoke(prompt)
        return response.content

async def process_batch(prompts: list[str]) -> list[str]:
    """Process batch of prompts with rate limiting."""
    tasks = [rate_limited_call(prompt) for prompt in prompts]
    return await asyncio.gather(*tasks)

# Usage
async def main():
    prompts = [f"Question {i}" for i in range(100)]
    results = await process_batch(prompts)
    print(f"Processed {len(results)} prompts")

asyncio.run(main())
```

### Synchronous Rate Limiting

```python
from ratelimit import limits, sleep_and_retry
from langchain_openai import ChatOpenAI

# 60 calls per minute
CALLS_PER_MINUTE = 60
ONE_MINUTE = 60

@sleep_and_retry
@limits(calls=CALLS_PER_MINUTE, period=ONE_MINUTE)
def rate_limited_llm_call(prompt: str) -> str:
    """Synchronous rate-limited LLM call."""
    llm = ChatOpenAI(model="gpt-4o")
    response = llm.invoke(prompt)
    return response.content

# Usage - automatically waits if rate exceeded
for i in range(100):
    result = rate_limited_llm_call(f"Process item {i}")
    print(f"Processed: {result[:50]}...")
```

---

## Production Rate Limiting Patterns

### Pattern 1: Circuit Breaker

```python
from datetime import datetime, timedelta
from typing import Optional
import threading

class CircuitBreaker:
    """
    Circuit breaker pattern for API calls.
    
    States:
    - CLOSED: Normal operation, requests pass through
    - OPEN: Too many failures, requests blocked
    - HALF_OPEN: Testing if service recovered
    """
    
    def __init__(
        self,
        failure_threshold: int = 5,
        recovery_timeout: int = 60,
        half_open_max_calls: int = 3
    ):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.half_open_max_calls = half_open_max_calls
        
        self.failures = 0
        self.last_failure_time: Optional[datetime] = None
        self.state = "CLOSED"
        self.half_open_calls = 0
        self._lock = threading.Lock()
    
    def can_execute(self) -> bool:
        """Check if request should be allowed."""
        with self._lock:
            if self.state == "CLOSED":
                return True
            
            if self.state == "OPEN":
                # Check if recovery timeout has passed
                if datetime.now() - self.last_failure_time > timedelta(seconds=self.recovery_timeout):
                    self.state = "HALF_OPEN"
                    self.half_open_calls = 0
                    return True
                return False
            
            if self.state == "HALF_OPEN":
                if self.half_open_calls < self.half_open_max_calls:
                    self.half_open_calls += 1
                    return True
                return False
        
        return False
    
    def record_success(self):
        """Record a successful call."""
        with self._lock:
            if self.state == "HALF_OPEN":
                self.half_open_calls += 1
                if self.half_open_calls >= self.half_open_max_calls:
                    # Recovered - close the circuit
                    self.state = "CLOSED"
                    self.failures = 0
            elif self.state == "CLOSED":
                self.failures = 0
    
    def record_failure(self):
        """Record a failed call."""
        with self._lock:
            self.failures += 1
            self.last_failure_time = datetime.now()
            
            if self.state == "HALF_OPEN":
                # Still failing - reopen circuit
                self.state = "OPEN"
            elif self.failures >= self.failure_threshold:
                self.state = "OPEN"

# Usage with LangChain
from langchain_openai import ChatOpenAI

circuit_breaker = CircuitBreaker(failure_threshold=5, recovery_timeout=60)

def call_with_circuit_breaker(prompt: str) -> str:
    """Make LLM call with circuit breaker protection."""
    if not circuit_breaker.can_execute():
        raise Exception("Circuit breaker is OPEN - service unavailable")
    
    try:
        llm = ChatOpenAI(model="gpt-4o", max_retries=2)
        response = llm.invoke(prompt)
        circuit_breaker.record_success()
        return response.content
    except Exception as e:
        circuit_breaker.record_failure()
        raise
```

### Pattern 2: Request Queue with Backpressure

```python
import asyncio
from collections import deque
from dataclasses import dataclass
from typing import Any, Callable
import time

@dataclass
class QueuedRequest:
    prompt: str
    future: asyncio.Future
    enqueue_time: float

class RateLimitedQueue:
    """
    Request queue with rate limiting and backpressure.
    """
    
    def __init__(
        self,
        max_requests_per_second: float = 1.0,
        max_queue_size: int = 100,
        request_timeout: float = 30.0
    ):
        self.max_rps = max_requests_per_second
        self.max_queue_size = max_queue_size
        self.request_timeout = request_timeout
        
        self.queue: deque[QueuedRequest] = deque()
        self.last_request_time = 0.0
        self._running = False
        self._worker_task = None
    
    async def start(self):
        """Start the queue worker."""
        self._running = True
        self._worker_task = asyncio.create_task(self._worker())
    
    async def stop(self):
        """Stop the queue worker."""
        self._running = False
        if self._worker_task:
            await self._worker_task
    
    async def enqueue(self, prompt: str) -> str:
        """Add request to queue and wait for result."""
        if len(self.queue) >= self.max_queue_size:
            raise Exception(f"Queue full ({self.max_queue_size} requests)")
        
        future = asyncio.get_event_loop().create_future()
        request = QueuedRequest(
            prompt=prompt,
            future=future,
            enqueue_time=time.time()
        )
        self.queue.append(request)
        
        try:
            return await asyncio.wait_for(future, timeout=self.request_timeout)
        except asyncio.TimeoutError:
            # Remove from queue if still there
            try:
                self.queue.remove(request)
            except ValueError:
                pass
            raise Exception("Request timed out in queue")
    
    async def _worker(self):
        """Process requests from queue."""
        from langchain_openai import ChatOpenAI
        llm = ChatOpenAI(model="gpt-4o")
        
        while self._running or self.queue:
            if not self.queue:
                await asyncio.sleep(0.1)
                continue
            
            # Rate limiting
            now = time.time()
            time_since_last = now - self.last_request_time
            min_interval = 1.0 / self.max_rps
            
            if time_since_last < min_interval:
                await asyncio.sleep(min_interval - time_since_last)
            
            # Process request
            request = self.queue.popleft()
            self.last_request_time = time.time()
            
            try:
                response = await llm.ainvoke(request.prompt)
                request.future.set_result(response.content)
            except Exception as e:
                request.future.set_exception(e)

# Usage
async def main():
    queue = RateLimitedQueue(max_requests_per_second=2)
    await queue.start()
    
    try:
        # Process multiple requests
        tasks = [
            queue.enqueue(f"Question {i}")
            for i in range(10)
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                print(f"Request {i} failed: {result}")
            else:
                print(f"Request {i}: {result[:50]}...")
    finally:
        await queue.stop()

asyncio.run(main())
```

### Pattern 3: Adaptive Rate Limiting

```python
import time
from typing import Optional

class AdaptiveRateLimiter:
    """
    Dynamically adjusts rate based on API responses.
    
    - Increases rate when requests succeed
    - Decreases rate when rate limits hit
    """
    
    def __init__(
        self,
        initial_rps: float = 1.0,
        min_rps: float = 0.1,
        max_rps: float = 10.0,
        increase_factor: float = 1.1,
        decrease_factor: float = 0.5
    ):
        self.current_rps = initial_rps
        self.min_rps = min_rps
        self.max_rps = max_rps
        self.increase_factor = increase_factor
        self.decrease_factor = decrease_factor
        
        self.last_request_time = 0.0
        self.consecutive_successes = 0
        self.success_threshold = 10  # Increase rate after N successes
    
    def wait_if_needed(self):
        """Block until next request is allowed."""
        now = time.time()
        min_interval = 1.0 / self.current_rps
        elapsed = now - self.last_request_time
        
        if elapsed < min_interval:
            time.sleep(min_interval - elapsed)
        
        self.last_request_time = time.time()
    
    def record_success(self):
        """Record successful request."""
        self.consecutive_successes += 1
        
        if self.consecutive_successes >= self.success_threshold:
            # Gradually increase rate
            new_rps = self.current_rps * self.increase_factor
            self.current_rps = min(new_rps, self.max_rps)
            self.consecutive_successes = 0
            print(f"Rate increased to {self.current_rps:.2f} RPS")
    
    def record_rate_limit(self, retry_after: Optional[float] = None):
        """Record rate limit hit."""
        self.consecutive_successes = 0
        
        # Decrease rate
        new_rps = self.current_rps * self.decrease_factor
        self.current_rps = max(new_rps, self.min_rps)
        print(f"Rate decreased to {self.current_rps:.2f} RPS")
        
        # If retry_after provided, wait that long
        if retry_after:
            time.sleep(retry_after)

# Usage
from langchain_openai import ChatOpenAI
import openai

limiter = AdaptiveRateLimiter(initial_rps=2.0)

def adaptive_llm_call(prompt: str) -> str:
    """Make LLM call with adaptive rate limiting."""
    limiter.wait_if_needed()
    
    try:
        llm = ChatOpenAI(model="gpt-4o", max_retries=0)
        response = llm.invoke(prompt)
        limiter.record_success()
        return response.content
    except openai.RateLimitError as e:
        # Extract retry_after if available
        retry_after = None
        if hasattr(e, 'response') and e.response:
            retry_after = e.response.headers.get('retry-after')
            if retry_after:
                retry_after = float(retry_after)
        
        limiter.record_rate_limit(retry_after)
        raise
```

---

## Monitoring and Observability

### Metrics to Track

```python
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List
import threading
import time

@dataclass
class RateLimitMetrics:
    """Track rate limiting metrics for observability."""
    
    total_requests: int = 0
    successful_requests: int = 0
    rate_limited_requests: int = 0
    retries: int = 0
    total_retry_wait_time: float = 0.0
    
    # Time series data
    requests_per_minute: Dict[str, int] = field(default_factory=dict)
    errors_per_minute: Dict[str, int] = field(default_factory=dict)
    
    _lock: threading.Lock = field(default_factory=threading.Lock)
    
    def record_request(self, success: bool, retry_count: int = 0, wait_time: float = 0.0):
        """Record a request and its outcome."""
        with self._lock:
            self.total_requests += 1
            
            if success:
                self.successful_requests += 1
            else:
                self.rate_limited_requests += 1
            
            self.retries += retry_count
            self.total_retry_wait_time += wait_time
            
            # Time series
            minute_key = datetime.now().strftime("%Y-%m-%d %H:%M")
            self.requests_per_minute[minute_key] = self.requests_per_minute.get(minute_key, 0) + 1
            
            if not success:
                self.errors_per_minute[minute_key] = self.errors_per_minute.get(minute_key, 0) + 1
    
    def get_stats(self) -> dict:
        """Get current statistics."""
        with self._lock:
            success_rate = (
                self.successful_requests / self.total_requests * 100
                if self.total_requests > 0 else 0
            )
            avg_retries = (
                self.retries / self.rate_limited_requests
                if self.rate_limited_requests > 0 else 0
            )
            
            return {
                "total_requests": self.total_requests,
                "success_rate": f"{success_rate:.1f}%",
                "rate_limited_count": self.rate_limited_requests,
                "total_retries": self.retries,
                "avg_retries_per_failure": f"{avg_retries:.1f}",
                "total_wait_time_seconds": f"{self.total_retry_wait_time:.1f}",
            }

# Global metrics instance
metrics = RateLimitMetrics()

# Usage in LLM calls
def monitored_llm_call(prompt: str) -> str:
    """LLM call with metrics tracking."""
    start_time = time.time()
    retry_count = 0
    wait_time = 0.0
    
    from tenacity import retry, stop_after_attempt, wait_exponential
    import openai
    
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, max=30)
    )
    def _call():
        nonlocal retry_count, wait_time
        try:
            llm = ChatOpenAI(model="gpt-4o", max_retries=0)
            return llm.invoke(prompt)
        except openai.RateLimitError:
            retry_count += 1
            raise
    
    try:
        response = _call()
        wait_time = time.time() - start_time - 0.5  # Approximate actual API time
        metrics.record_request(success=True, retry_count=retry_count, wait_time=wait_time)
        return response.content
    except Exception:
        metrics.record_request(success=False, retry_count=retry_count, wait_time=wait_time)
        raise

# Check metrics periodically
print(metrics.get_stats())
```

---

## Configuration Best Practices

### Environment-Based Configuration

```python
import os
from dataclasses import dataclass

@dataclass
class RateLimitConfig:
    """Rate limit configuration from environment."""
    
    max_retries: int = int(os.getenv("LLM_MAX_RETRIES", "5"))
    request_timeout: int = int(os.getenv("LLM_REQUEST_TIMEOUT", "60"))
    retry_min_seconds: int = int(os.getenv("LLM_RETRY_MIN_SECONDS", "1"))
    retry_max_seconds: int = int(os.getenv("LLM_RETRY_MAX_SECONDS", "60"))
    max_requests_per_minute: int = int(os.getenv("LLM_MAX_RPM", "60"))

config = RateLimitConfig()

# Use in LLM initialization
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(
    model="gpt-4o",
    max_retries=config.max_retries,
    request_timeout=config.request_timeout
)
```

### LangSmith Configuration

```python
import os

# Configure LangSmith batch settings to avoid rate limits
os.environ["LANGCHAIN_RUN_BATCH_SIZE"] = "50"
os.environ["LANGCHAIN_RUN_BATCH_INTERVAL"] = "5.0"

# This prevents overwhelming LangSmith with trace data
# Default limit is 1,000 runs/minute
```

---

## Summary: Rate Limiting Checklist

### Development Environment
- [ ] Enable verbose logging to see retry attempts
- [ ] Use lower retry counts for faster feedback
- [ ] Consider caching to reduce API calls

### Production Environment
- [ ] Implement exponential backoff with jitter
- [ ] Respect Retry-After headers
- [ ] Set appropriate retry limits (3-5 attempts)
- [ ] Implement circuit breaker for cascading failures
- [ ] Add request queuing for burst traffic
- [ ] Monitor rate limit metrics
- [ ] Set up alerts for high rate limit rates

### Code Checklist
```python
# Production LLM configuration
llm = ChatOpenAI(
    model="gpt-4o",
    max_retries=5,              # Reasonable retry count
    request_timeout=60,          # Timeout per request
    temperature=0                # Deterministic for caching
)

# With retry wrapper for additional control
chain = (
    llm
    .with_retry(
        stop_after_attempt=5,
        wait_exponential_jitter=True
    )
)
```

---

## References

- [LangChain Rate Limit Handling](https://js.langchain.com/docs/troubleshooting/errors/MODEL_RATE_LIMIT/)
- [Exponential Backoff Configuration](https://theneuralbase.com/langchain-advanced/learn/intermediate/exponential-backoff-config/)
- [LangChain Rate Limit Fix Guide 2026](https://markaicode.com/errors/langchain-rate-limit-exceeded-fix/)
- [Async Rate Limit Handling](https://theneuralbase.com/langchain/learn/advanced/rate-limit-handling-in-async-context/)
- [LangSmith Rate Limit Solutions](https://markaicode.com/errors/langsmith-rate-limit-fix/)
