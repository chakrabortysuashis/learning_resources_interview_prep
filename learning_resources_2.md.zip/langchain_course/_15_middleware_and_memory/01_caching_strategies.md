# Module 15.1: LangChain Caching Strategies

## Introduction

Caching is a critical optimization technique for LLM applications that can significantly reduce costs, improve latency, and enhance user experience. LangChain provides multiple caching implementations suited for different deployment scenarios.

## Why Cache LLM Responses?

### Benefits of Caching

1. **Cost Reduction**: Avoid redundant API calls to LLM providers
2. **Latency Improvement**: Return cached responses in milliseconds vs seconds
3. **Rate Limit Mitigation**: Reduce pressure on API rate limits
4. **Consistency**: Return identical responses for identical inputs
5. **Offline Capability**: Serve cached responses during API outages

### When to Use Caching

- FAQ or knowledge base queries with predictable questions
- Development and testing environments
- Batch processing with repeated prompts
- High-traffic applications with common queries

---

## Caching Architecture Overview

```
+------------------+     +-------------------+     +------------------+
|                  |     |                   |     |                  |
|   User Request   +---->+   Cache Lookup    +---->+   Cache Hit?     |
|                  |     |                   |     |                  |
+------------------+     +-------------------+     +--------+---------+
                                                           |
                         +----------------------------------+
                         |                                  |
                         v                                  v
                  +------+------+                    +------+------+
                  |             |                    |             |
                  |  Cache Hit  |                    | Cache Miss  |
                  |             |                    |             |
                  +------+------+                    +------+------+
                         |                                  |
                         v                                  v
                  +------+------+                    +------+------+
                  |   Return    |                    |   Call LLM  |
                  |   Cached    |                    |   Provider  |
                  |  Response   |                    |             |
                  +-------------+                    +------+------+
                                                           |
                                                           v
                                                    +------+------+
                                                    |   Store in  |
                                                    |    Cache    |
                                                    +------+------+
                                                           |
                                                           v
                                                    +------+------+
                                                    |   Return    |
                                                    |  Response   |
                                                    +-------------+
```

---

## Cache Types Comparison

| Feature | InMemoryCache | SQLiteCache | RedisCache | RedisSemanticCache |
|---------|---------------|-------------|------------|-------------------|
| **Persistence** | No | Yes | Yes | Yes |
| **Shared Access** | No (process-local) | Yes (file-based) | Yes (distributed) | Yes (distributed) |
| **Scalability** | Single process | Single machine | Multi-server | Multi-server |
| **Lookup Type** | Exact match | Exact match | Exact match | Semantic similarity |
| **Setup Complexity** | Minimal | Low | Medium | Medium-High |
| **Memory Usage** | High (unbounded) | Low (disk) | Configurable | Configurable |
| **Best For** | Development, CLI tools | Single-server apps | Production, distributed | Flexible matching |
| **Cost Savings** | Up to 90% | Up to 90% | Up to 90% | Up to 95% |

---

## 1. InMemoryCache

### Overview

InMemoryCache stores LLM responses in a Python dictionary keyed by the input prompt hash. It's the simplest caching option, ideal for development and single-process applications.

### Architecture

```
+------------------+
|   Python Process |
|                  |
|  +------------+  |
|  |   Dict     |  |
|  | {hash:resp}|  |
|  +------------+  |
|                  |
+------------------+
        |
        | Process-local only
        | Lost on restart
        v
```

### Implementation

```python
from langchain_core.globals import set_llm_cache
from langchain_core.caches import InMemoryCache
from langchain_openai import ChatOpenAI

# Enable in-memory caching globally
set_llm_cache(InMemoryCache())

# Initialize the LLM
llm = ChatOpenAI(model="gpt-4o", temperature=0)

# First call - hits the API
response1 = llm.invoke("What is the capital of France?")
print(f"First call: {response1.content}")

# Second call - returns from cache (instant)
response2 = llm.invoke("What is the capital of France?")
print(f"Second call (cached): {response2.content}")
```

### Key Characteristics

- **Cache Key**: Computed from ALL parameters (prompt, temperature, model, etc.)
- **Scope**: Process-local only
- **Lifetime**: Until process termination
- **Thread Safety**: Not thread-safe by default

### Limitations

```python
# IMPORTANT: Different parameters = different cache keys

# These are DIFFERENT cache entries:
llm.invoke("What is AI?", temperature=0)      # Cache key A
llm.invoke("What is AI?", temperature=0.1)    # Cache key B (different!)
llm.invoke("What is AI?", max_tokens=100)     # Cache key C (different!)
```

### When to Use

- Development and testing
- CLI tools and scripts
- Batch processing jobs
- Benchmarking and evaluation

### When NOT to Use

- Long-running services (memory grows unbounded)
- Multi-worker deployments (each worker has separate cache)
- Production web services

---

## 2. SQLiteCache

### Overview

SQLiteCache persists cached responses to a SQLite database file, providing durability across process restarts while remaining simple to set up.

### Architecture

```
+------------------+     +------------------+     +------------------+
|   Worker 1       |     |   Worker 2       |     |   Worker 3       |
+--------+---------+     +--------+---------+     +--------+---------+
         |                        |                        |
         +------------------------+------------------------+
                                  |
                                  v
                         +--------+--------+
                         |                 |
                         |  SQLite File    |
                         | (.langchain.db) |
                         |                 |
                         +-----------------+
```

### Implementation

```python
from langchain_community.cache import SQLiteCache
from langchain_core.globals import set_llm_cache
from langchain_openai import ChatOpenAI

# Set up SQLite cache with custom path
set_llm_cache(SQLiteCache(database_path=".langchain_cache.db"))

# Initialize LLM
llm = ChatOpenAI(model="gpt-4o", temperature=0)

# Responses are now persisted to disk
response = llm.invoke("Explain quantum computing")
```

### Advanced Configuration

```python
from langchain_community.cache import SQLiteCache

# Custom database configuration
cache = SQLiteCache(
    database_path="/var/cache/langchain/llm_cache.db"
)

# The SQLite schema:
# CREATE TABLE IF NOT EXISTS full_llm_cache (
#     prompt TEXT,
#     llm TEXT,
#     idx INTEGER,
#     response TEXT,
#     PRIMARY KEY (prompt, llm, idx)
# )
```

### Managing Cache Size

```python
import sqlite3

def get_cache_stats(db_path=".langchain.db"):
    """Get statistics about the cache."""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Count entries
    cursor.execute("SELECT COUNT(*) FROM full_llm_cache")
    count = cursor.fetchone()[0]
    
    # Get database size
    cursor.execute("SELECT page_count * page_size FROM pragma_page_count(), pragma_page_size()")
    size_bytes = cursor.fetchone()[0]
    
    conn.close()
    return {"entries": count, "size_mb": size_bytes / (1024 * 1024)}

def clear_cache(db_path=".langchain.db"):
    """Clear all cached entries."""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM full_llm_cache")
    cursor.execute("VACUUM")  # Reclaim disk space
    conn.commit()
    conn.close()

def clear_old_entries(db_path=".langchain.db", days=30):
    """Clear entries older than specified days (requires timestamp column)."""
    # Note: Default schema doesn't include timestamps
    # You would need a custom implementation for time-based expiry
    pass
```

### Advantages

- Persists across restarts
- No external dependencies
- Single file deployment
- ACID compliant

### Limitations

- File locking can be a bottleneck
- Not suitable for distributed deployments
- No built-in TTL/expiry

---

## 3. RedisCache

### Overview

RedisCache provides distributed caching using Redis as the backend, ideal for production deployments with multiple servers or workers.

### Architecture

```
+------------------+     +------------------+     +------------------+
|   Server 1       |     |   Server 2       |     |   Server 3       |
|   Worker 1-N     |     |   Worker 1-N     |     |   Worker 1-N     |
+--------+---------+     +--------+---------+     +--------+---------+
         |                        |                        |
         +------------------------+------------------------+
                                  |
                                  v
                         +--------+--------+
                         |                 |
                         |  Redis Cluster  |
                         |   (Distributed) |
                         |                 |
                         +-----------------+
```

### Implementation

```python
from langchain_redis import RedisCache
from langchain_core.globals import set_llm_cache
from langchain_openai import ChatOpenAI
import redis

# Connect to Redis
redis_client = redis.Redis(
    host="localhost",
    port=6379,
    db=0,
    decode_responses=True
)

# Set up Redis cache
set_llm_cache(RedisCache(redis_client=redis_client))

# Initialize LLM
llm = ChatOpenAI(model="gpt-4o", temperature=0)

# Responses are now cached in Redis
response = llm.invoke("What are the benefits of microservices?")
```

### Production Configuration

```python
from langchain_redis import RedisCache
from langchain_core.globals import set_llm_cache
import redis

# Production Redis configuration
redis_client = redis.Redis(
    host="redis-cluster.internal",
    port=6379,
    password="your-secure-password",
    ssl=True,
    ssl_cert_reqs="required",
    socket_timeout=5.0,
    socket_connect_timeout=5.0,
    retry_on_timeout=True,
    health_check_interval=30,
    decode_responses=True
)

# Configure cache with TTL
cache = RedisCache(
    redis_client=redis_client,
    ttl=3600  # Cache entries expire after 1 hour
)

set_llm_cache(cache)
```

### Async Redis Cache

```python
from langchain_redis import AsyncRedisCache
from langchain_core.globals import set_llm_cache
import redis.asyncio as redis

# Async Redis client
async_redis = redis.Redis(
    host="localhost",
    port=6379,
    decode_responses=True
)

# Set up async cache
set_llm_cache(AsyncRedisCache(redis_client=async_redis))
```

### Cache Management

```python
import redis

def get_redis_cache_stats(redis_client):
    """Get cache statistics from Redis."""
    info = redis_client.info("memory")
    keys = redis_client.dbsize()
    
    return {
        "total_keys": keys,
        "used_memory_mb": info["used_memory"] / (1024 * 1024),
        "peak_memory_mb": info["used_memory_peak"] / (1024 * 1024),
    }

def clear_langchain_cache(redis_client, pattern="langchain:*"):
    """Clear all LangChain cache entries."""
    cursor = 0
    deleted = 0
    while True:
        cursor, keys = redis_client.scan(cursor, match=pattern, count=100)
        if keys:
            redis_client.delete(*keys)
            deleted += len(keys)
        if cursor == 0:
            break
    return deleted

def set_cache_ttl(redis_client, pattern="langchain:*", ttl_seconds=3600):
    """Set TTL on existing cache entries."""
    cursor = 0
    updated = 0
    while True:
        cursor, keys = redis_client.scan(cursor, match=pattern, count=100)
        for key in keys:
            redis_client.expire(key, ttl_seconds)
            updated += 1
        if cursor == 0:
            break
    return updated
```

---

## 4. RedisSemanticCache

### Overview

RedisSemanticCache uses vector embeddings to find semantically similar queries, returning cached responses even when the exact prompt differs. This can dramatically increase cache hit rates.

### Architecture

```
+------------------+
|  User Query      |
| "What is ML?"    |
+--------+---------+
         |
         v
+--------+---------+
|  Generate        |
|  Embedding       |
+--------+---------+
         |
         v
+--------+---------+
|  Vector Search   |
|  in Redis        |
+--------+---------+
         |
         v
+--------+---------+
|  Similar Query?  |
|  "What is        |
|  machine         |
|  learning?"      |
+--------+---------+
         |
         | Threshold check
         v
+--------+---------+
|  Return Cached   |
|  Response        |
+------------------+
```

### Implementation

```python
from langchain_redis import RedisSemanticCache
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain_core.globals import set_llm_cache
import redis

# Initialize embeddings model
embeddings = OpenAIEmbeddings(model="text-embedding-3-small")

# Redis client
redis_client = redis.Redis(host="localhost", port=6379)

# Set up semantic cache
semantic_cache = RedisSemanticCache(
    redis_client=redis_client,
    embeddings=embeddings,
    score_threshold=0.85  # Similarity threshold (0-1)
)

set_llm_cache(semantic_cache)

# Initialize LLM
llm = ChatOpenAI(model="gpt-4o", temperature=0)

# First query
response1 = llm.invoke("What is machine learning?")

# Similar query - will hit cache!
response2 = llm.invoke("Can you explain ML?")  # Semantic match!

# Different query - cache miss
response3 = llm.invoke("What is the weather today?")
```

### Tuning Similarity Threshold

```python
# High threshold (0.95): Very strict matching
# - Only nearly identical queries match
# - Lower cache hit rate
# - Higher accuracy

semantic_cache_strict = RedisSemanticCache(
    redis_client=redis_client,
    embeddings=embeddings,
    score_threshold=0.95  # Strict
)

# Low threshold (0.70): Loose matching
# - More queries match
# - Higher cache hit rate
# - May return less relevant responses

semantic_cache_loose = RedisSemanticCache(
    redis_client=redis_client,
    embeddings=embeddings,
    score_threshold=0.70  # Loose
)

# Recommended: 0.85-0.90 for most use cases
semantic_cache_balanced = RedisSemanticCache(
    redis_client=redis_client,
    embeddings=embeddings,
    score_threshold=0.87
)
```

### Cost Analysis

```python
"""
Semantic Cache Cost Analysis

Standard Cache:
- Unique queries: 10,000
- Cache hit rate: 20% (only exact matches)
- API calls: 8,000
- Cost at $0.01/1K tokens: ~$80

Semantic Cache:
- Unique queries: 10,000
- Cache hit rate: 60% (semantic matches)
- API calls: 4,000
- Embedding calls: 10,000 (for lookup)
- Cost at $0.01/1K tokens + $0.0001/1K embedding tokens: ~$41

Savings: ~49%
"""
```

---

## 5. Custom Caching Strategies

### Hybrid Cache (Memory + Persistent)

```python
from langchain_core.caches import BaseCache
from langchain_core.outputs import Generation
from typing import Optional, Sequence
import hashlib
import json

class HybridCache(BaseCache):
    """Two-tier cache: fast in-memory L1 + persistent Redis L2."""
    
    def __init__(self, redis_client, max_memory_entries=1000):
        self.redis_client = redis_client
        self.memory_cache = {}
        self.max_memory_entries = max_memory_entries
        self.access_order = []
    
    def _get_key(self, prompt: str, llm_string: str) -> str:
        """Generate cache key from prompt and LLM config."""
        content = f"{prompt}:{llm_string}"
        return hashlib.sha256(content.encode()).hexdigest()
    
    def lookup(self, prompt: str, llm_string: str) -> Optional[Sequence[Generation]]:
        """Look up in L1 (memory) then L2 (Redis)."""
        key = self._get_key(prompt, llm_string)
        
        # L1: Memory lookup
        if key in self.memory_cache:
            self._update_access(key)
            return self.memory_cache[key]
        
        # L2: Redis lookup
        cached = self.redis_client.get(f"llm_cache:{key}")
        if cached:
            generations = self._deserialize(cached)
            # Promote to L1
            self._add_to_memory(key, generations)
            return generations
        
        return None
    
    def update(self, prompt: str, llm_string: str, return_val: Sequence[Generation]) -> None:
        """Store in both L1 and L2."""
        key = self._get_key(prompt, llm_string)
        
        # L1: Memory
        self._add_to_memory(key, return_val)
        
        # L2: Redis (with 1 hour TTL)
        serialized = self._serialize(return_val)
        self.redis_client.setex(f"llm_cache:{key}", 3600, serialized)
    
    def _add_to_memory(self, key: str, value):
        """Add to memory cache with LRU eviction."""
        if len(self.memory_cache) >= self.max_memory_entries:
            # Evict least recently used
            oldest = self.access_order.pop(0)
            del self.memory_cache[oldest]
        
        self.memory_cache[key] = value
        self._update_access(key)
    
    def _update_access(self, key: str):
        """Update access order for LRU."""
        if key in self.access_order:
            self.access_order.remove(key)
        self.access_order.append(key)
    
    def _serialize(self, generations: Sequence[Generation]) -> str:
        return json.dumps([{"text": g.text, "info": g.generation_info} for g in generations])
    
    def _deserialize(self, data: str) -> Sequence[Generation]:
        items = json.loads(data)
        return [Generation(text=item["text"], generation_info=item["info"]) for item in items]
    
    def clear(self, **kwargs) -> None:
        """Clear both cache layers."""
        self.memory_cache.clear()
        self.access_order.clear()
        # Clear Redis keys matching pattern
        for key in self.redis_client.scan_iter("llm_cache:*"):
            self.redis_client.delete(key)
```

### Conditional Caching

```python
from langchain_core.caches import BaseCache
from langchain_core.outputs import Generation
from typing import Optional, Sequence, Callable

class ConditionalCache(BaseCache):
    """Cache that only stores responses meeting certain criteria."""
    
    def __init__(
        self,
        underlying_cache: BaseCache,
        should_cache: Callable[[str, Sequence[Generation]], bool]
    ):
        self.cache = underlying_cache
        self.should_cache = should_cache
    
    def lookup(self, prompt: str, llm_string: str) -> Optional[Sequence[Generation]]:
        return self.cache.lookup(prompt, llm_string)
    
    def update(self, prompt: str, llm_string: str, return_val: Sequence[Generation]) -> None:
        # Only cache if condition is met
        if self.should_cache(prompt, return_val):
            self.cache.update(prompt, llm_string, return_val)
    
    def clear(self, **kwargs) -> None:
        self.cache.clear(**kwargs)

# Example: Only cache responses that are reasonably long
def long_response_filter(prompt: str, generations: Sequence[Generation]) -> bool:
    if not generations:
        return False
    # Only cache if response is at least 100 characters
    return len(generations[0].text) >= 100

# Example: Don't cache error-like responses
def no_error_filter(prompt: str, generations: Sequence[Generation]) -> bool:
    if not generations:
        return False
    text = generations[0].text.lower()
    error_indicators = ["i cannot", "i'm unable", "error", "sorry"]
    return not any(indicator in text for indicator in error_indicators)
```

---

## Cost Optimization Strategies

### 1. Cache Warming

```python
from langchain_openai import ChatOpenAI
from langchain_core.globals import set_llm_cache
from langchain_core.caches import InMemoryCache

async def warm_cache(llm, common_queries: list[str]):
    """Pre-populate cache with common queries."""
    for query in common_queries:
        try:
            await llm.ainvoke(query)
            print(f"Cached: {query[:50]}...")
        except Exception as e:
            print(f"Failed to cache: {query[:50]}... Error: {e}")

# Example usage
common_queries = [
    "What are your business hours?",
    "How do I reset my password?",
    "What is your return policy?",
    "How do I contact support?",
]

llm = ChatOpenAI(model="gpt-4o", temperature=0)
set_llm_cache(InMemoryCache())

# Warm cache at startup
import asyncio
asyncio.run(warm_cache(llm, common_queries))
```

### 2. Cache Hit Rate Monitoring

```python
from langchain_core.caches import BaseCache
from langchain_core.outputs import Generation
from typing import Optional, Sequence
import time

class MonitoredCache(BaseCache):
    """Wrapper that tracks cache performance metrics."""
    
    def __init__(self, underlying_cache: BaseCache):
        self.cache = underlying_cache
        self.hits = 0
        self.misses = 0
        self.total_lookup_time = 0
        self.total_update_time = 0
    
    def lookup(self, prompt: str, llm_string: str) -> Optional[Sequence[Generation]]:
        start = time.time()
        result = self.cache.lookup(prompt, llm_string)
        self.total_lookup_time += time.time() - start
        
        if result:
            self.hits += 1
        else:
            self.misses += 1
        
        return result
    
    def update(self, prompt: str, llm_string: str, return_val: Sequence[Generation]) -> None:
        start = time.time()
        self.cache.update(prompt, llm_string, return_val)
        self.total_update_time += time.time() - start
    
    def get_stats(self) -> dict:
        total = self.hits + self.misses
        return {
            "hits": self.hits,
            "misses": self.misses,
            "hit_rate": self.hits / total if total > 0 else 0,
            "total_requests": total,
            "avg_lookup_time_ms": (self.total_lookup_time / total * 1000) if total > 0 else 0,
            "avg_update_time_ms": (self.total_update_time / self.misses * 1000) if self.misses > 0 else 0,
        }
    
    def clear(self, **kwargs) -> None:
        self.cache.clear(**kwargs)

# Usage
from langchain_core.caches import InMemoryCache
from langchain_core.globals import set_llm_cache

monitored = MonitoredCache(InMemoryCache())
set_llm_cache(monitored)

# ... use LLM ...

# Check performance
stats = monitored.get_stats()
print(f"Cache hit rate: {stats['hit_rate']:.2%}")
print(f"Estimated cost savings: ${stats['hits'] * 0.01:.2f}")  # Rough estimate
```

---

## Best Practices Summary

### Development Environment
```python
# Use InMemoryCache for fast iteration
from langchain_core.caches import InMemoryCache
set_llm_cache(InMemoryCache())
```

### Single-Server Production
```python
# Use SQLiteCache for persistence without external dependencies
from langchain_community.cache import SQLiteCache
set_llm_cache(SQLiteCache(database_path="/var/cache/langchain/llm.db"))
```

### Distributed Production
```python
# Use RedisCache for multi-server deployments
from langchain_redis import RedisCache
import redis
redis_client = redis.Redis(host="redis.internal", port=6379, ssl=True)
set_llm_cache(RedisCache(redis_client=redis_client, ttl=3600))
```

### High Cache Hit Rate Requirements
```python
# Use RedisSemanticCache for semantic matching
from langchain_redis import RedisSemanticCache
from langchain_openai import OpenAIEmbeddings
semantic_cache = RedisSemanticCache(
    redis_client=redis_client,
    embeddings=OpenAIEmbeddings(),
    score_threshold=0.87
)
set_llm_cache(semantic_cache)
```

---

## Summary

| Scenario | Recommended Cache | Key Configuration |
|----------|-------------------|-------------------|
| Development | InMemoryCache | None needed |
| CLI Tools | InMemoryCache | None needed |
| Single Server | SQLiteCache | Set database path |
| Multi-Server | RedisCache | Configure TTL, connection pool |
| FAQ/Support | RedisSemanticCache | Tune similarity threshold |
| High Volume | HybridCache | L1 size, L2 TTL |

---

## References

- [LangChain Caching Documentation](https://langchain-doc.readthedocs.io/en/latest/modules/llms/examples/llm_caching.html)
- [LangChain Redis Partner Package](https://redis.io/blog/langchain-redis-partner-package/)
- [LangChain Community Cache Reference](https://reference.langchain.com/v0.3/python/community/cache.html)
- [InMemoryCache Guide](https://theneuralbase.com/langchain/learn/advanced/inmemorycache-caching-identical-prompts/)
