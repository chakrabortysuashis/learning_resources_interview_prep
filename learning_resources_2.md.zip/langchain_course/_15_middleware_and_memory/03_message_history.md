# Module 15.3: Chat Message History and Persistence

## Introduction

Chat message history is the foundation of conversational AI applications. Unlike high-level memory abstractions, message history focuses on the raw storage and retrieval of conversation messages. This module covers persistence patterns for production-ready chat applications.

## The Statelessness Challenge

LLM APIs are fundamentally stateless:

```
+-------------+          +-------------+          +-------------+
|  Request 1  |          |  Request 2  |          |  Request 3  |
|  "Hi!"      |          |  "My name"  |          |  "What's my |
|             |          |  "is Bob"   |          |   name?"    |
+------+------+          +------+------+          +------+------+
       |                        |                        |
       v                        v                        v
+------+------+          +------+------+          +------+------+
|   LLM API   |          |   LLM API   |          |   LLM API   |
| (Stateless) |          | (Stateless) |          | (Stateless) |
+------+------+          +------+------+          +------+------+
       |                        |                        |
       v                        v                        v
   "Hello!"               "Nice to meet            "I don't 
                           you, Bob!"               know"
                                                      ^
                                                      |
                                            No memory of "Bob"!
```

**Solution**: You must manage conversation history yourself.

---

## Message History Architecture

### Core Components

```
+------------------------------------------+
|            Application Layer             |
+------------------------------------------+
                    |
                    v
+------------------------------------------+
|       RunnableWithMessageHistory         |
|    (Orchestrates history management)     |
+------------------------------------------+
                    |
                    v
+------------------------------------------+
|         BaseChatMessageHistory           |
|      (Abstract interface for storage)    |
+------------------------------------------+
          |                    |
          v                    v
+------------------+  +------------------+
| InMemoryChatMsg  |  | Persistent Store |
|    History       |  | (Redis/Postgres/ |
| (Development)    |  |  MongoDB/etc.)   |
+------------------+  +------------------+
```

### Message Types

```python
from langchain_core.messages import (
    HumanMessage,      # User input
    AIMessage,         # Model response
    SystemMessage,     # System instructions
    FunctionMessage,   # Function call results (legacy)
    ToolMessage,       # Tool call results
)

# Example conversation structure
messages = [
    SystemMessage(content="You are a helpful assistant."),
    HumanMessage(content="What is the weather?"),
    AIMessage(content="I don't have access to real-time weather data."),
    HumanMessage(content="Can you help me with Python?"),
    AIMessage(content="Of course! What do you need help with?"),
]
```

---

## InMemoryChatMessageHistory

### Overview

The simplest implementation - stores messages in a Python list. Perfect for development but loses data on process restart.

### Basic Usage

```python
from langchain_core.chat_history import InMemoryChatMessageHistory
from langchain_core.messages import HumanMessage, AIMessage

# Create history instance
history = InMemoryChatMessageHistory()

# Add messages
history.add_user_message("Hello!")
history.add_ai_message("Hi there! How can I help you?")

# Or add message objects directly
history.add_message(HumanMessage(content="What's 2+2?"))
history.add_message(AIMessage(content="2+2 equals 4."))

# Retrieve all messages
print(history.messages)

# Clear history
history.clear()
```

### Session Management Pattern

```python
from langchain_core.chat_history import InMemoryChatMessageHistory
from typing import Dict

class SessionManager:
    """Manages multiple chat sessions in memory."""
    
    def __init__(self):
        self._sessions: Dict[str, InMemoryChatMessageHistory] = {}
    
    def get_session(self, session_id: str) -> InMemoryChatMessageHistory:
        """Get or create a session."""
        if session_id not in self._sessions:
            self._sessions[session_id] = InMemoryChatMessageHistory()
        return self._sessions[session_id]
    
    def delete_session(self, session_id: str) -> bool:
        """Delete a session."""
        if session_id in self._sessions:
            del self._sessions[session_id]
            return True
        return False
    
    def list_sessions(self) -> list[str]:
        """List all active session IDs."""
        return list(self._sessions.keys())

# Usage
sessions = SessionManager()
history = sessions.get_session("user_123")
history.add_user_message("Hello!")
```

### Limitations

```
+-------------------+     +-------------------+
|     Pod 1         |     |     Pod 2         |
|                   |     |                   |
| InMemoryHistory   |     | InMemoryHistory   |
| session_123: [...]|     | session_123: []   |  <- Different data!
|                   |     |                   |
+-------------------+     +-------------------+
        ^                         ^
        |                         |
   User request             User request
   (session_123)            (session_123)
        |                         |
   Load balancer routes to different pods = INCONSISTENT STATE
```

---

## Persistent Message History

### Why Persistence Matters

```
Without Persistence:
- Server restart = all conversations lost
- Multiple servers = inconsistent state
- No audit trail
- No conversation analytics

With Persistence:
- Conversations survive restarts
- Shared state across servers
- Full audit trail
- Analytics and insights possible
```

---

## RedisChatMessageHistory

### Overview

Redis provides fast, distributed message storage ideal for production deployments.

### Architecture

```
+------------------+     +------------------+     +------------------+
|   Server 1       |     |   Server 2       |     |   Server 3       |
|   (Worker Pool)  |     |   (Worker Pool)  |     |   (Worker Pool)  |
+--------+---------+     +--------+---------+     +--------+---------+
         |                        |                        |
         +------------------------+------------------------+
                                  |
                                  v
                         +--------+--------+
                         |                 |
                         |  Redis Cluster  |
                         |                 |
                         | session_123:[   |
                         |   msg1, msg2,   |
                         |   msg3, ...     |
                         | ]               |
                         +-----------------+
```

### Implementation

```python
from langchain_community.chat_message_histories import RedisChatMessageHistory
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_openai import ChatOpenAI
from langchain_core.runnables.history import RunnableWithMessageHistory

# Redis connection URL
REDIS_URL = "redis://localhost:6379"

def get_redis_history(session_id: str) -> RedisChatMessageHistory:
    """Factory function for Redis message history."""
    return RedisChatMessageHistory(
        session_id=session_id,
        url=REDIS_URL,
        ttl=3600,  # Messages expire after 1 hour
        key_prefix="chat:"  # Namespace for keys
    )

# Build the chain
prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a helpful assistant."),
    MessagesPlaceholder(variable_name="history"),
    ("human", "{input}")
])

llm = ChatOpenAI(model="gpt-4o")
chain = prompt | llm

# Wrap with history
with_history = RunnableWithMessageHistory(
    chain,
    get_redis_history,
    input_messages_key="input",
    history_messages_key="history"
)

# Use the chain
config = {"configurable": {"session_id": "user_abc_123"}}

response = with_history.invoke(
    {"input": "My name is Alice"},
    config=config
)
print(response.content)

# Later, same session maintains context
response = with_history.invoke(
    {"input": "What's my name?"},
    config=config
)
print(response.content)  # "Your name is Alice"
```

### Advanced Redis Configuration

```python
from langchain_community.chat_message_histories import RedisChatMessageHistory
import redis

# Production Redis with connection pool
redis_pool = redis.ConnectionPool(
    host="redis.internal.company.com",
    port=6379,
    password="secure_password",
    db=0,
    max_connections=50,
    socket_timeout=5.0,
    socket_connect_timeout=5.0,
    retry_on_timeout=True,
    ssl=True,
    ssl_cert_reqs="required"
)

def get_production_redis_history(session_id: str) -> RedisChatMessageHistory:
    """Production-grade Redis history with connection pooling."""
    return RedisChatMessageHistory(
        session_id=session_id,
        url=None,  # Don't use URL when providing client
        redis_client=redis.Redis(connection_pool=redis_pool),
        ttl=7200,  # 2 hour session
        key_prefix="prod:chat:"
    )
```

### Redis Data Structure

```
Redis Key: "chat:user_abc_123"
Redis Type: LIST

Structure:
[
  "{\"type\": \"human\", \"content\": \"My name is Alice\", \"timestamp\": ...}",
  "{\"type\": \"ai\", \"content\": \"Nice to meet you, Alice!\", \"timestamp\": ...}",
  "{\"type\": \"human\", \"content\": \"What's my name?\", \"timestamp\": ...}",
  "{\"type\": \"ai\", \"content\": \"Your name is Alice.\", \"timestamp\": ...}"
]
```

---

## PostgresChatMessageHistory

### Overview

PostgreSQL provides ACID-compliant storage with rich querying capabilities, ideal when you need conversation analytics or audit trails.

### Architecture

```
+------------------------------------------+
|           Application Servers            |
+------------------------------------------+
                    |
                    v
+------------------------------------------+
|         PostgreSQL Database              |
+------------------------------------------+
|                                          |
|  Table: chat_message_history             |
|  +------------------------------------+  |
|  | id | session_id | message | ts     |  |
|  |----|------------|---------|--------|  |
|  | 1  | user_123   | {...}   | 10:00  |  |
|  | 2  | user_123   | {...}   | 10:01  |  |
|  | 3  | user_456   | {...}   | 10:02  |  |
|  +------------------------------------+  |
|                                          |
+------------------------------------------+
```

### Implementation

```python
from langchain_postgres import PostgresChatMessageHistory
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_openai import ChatOpenAI
from langchain_core.runnables.history import RunnableWithMessageHistory
import psycopg

# Database connection string
DATABASE_URL = "postgresql://user:password@localhost:5432/chatdb"

# Create the table (run once)
def create_tables():
    """Create required tables for chat history."""
    with psycopg.connect(DATABASE_URL) as conn:
        PostgresChatMessageHistory.create_tables(conn, "chat_history")

def get_postgres_history(session_id: str) -> PostgresChatMessageHistory:
    """Factory function for Postgres message history."""
    return PostgresChatMessageHistory(
        table_name="chat_history",
        session_id=session_id,
        sync_connection=psycopg.connect(DATABASE_URL)
    )

# Build chain with history
prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a customer support agent for TechCorp."),
    MessagesPlaceholder(variable_name="history"),
    ("human", "{input}")
])

llm = ChatOpenAI(model="gpt-4o")
chain = prompt | llm

with_history = RunnableWithMessageHistory(
    chain,
    get_postgres_history,
    input_messages_key="input",
    history_messages_key="history"
)

# Usage
config = {"configurable": {"session_id": "support_ticket_789"}}
response = with_history.invoke({"input": "I need help with my order"}, config=config)
```

### Async Postgres History

```python
from langchain_postgres import PostgresChatMessageHistory
import psycopg
from psycopg_pool import AsyncConnectionPool

# Async connection pool
async_pool = AsyncConnectionPool(
    conninfo=DATABASE_URL,
    min_size=5,
    max_size=20
)

async def get_async_postgres_history(session_id: str) -> PostgresChatMessageHistory:
    """Async Postgres history with connection pooling."""
    async with async_pool.connection() as conn:
        return PostgresChatMessageHistory(
            table_name="chat_history",
            session_id=session_id,
            async_connection=conn
        )
```

### Analytics Queries

```sql
-- Count messages per session
SELECT session_id, COUNT(*) as message_count
FROM chat_history
GROUP BY session_id
ORDER BY message_count DESC;

-- Average conversation length
SELECT AVG(msg_count) as avg_messages
FROM (
    SELECT session_id, COUNT(*) as msg_count
    FROM chat_history
    GROUP BY session_id
) subquery;

-- Messages per hour (for load analysis)
SELECT 
    DATE_TRUNC('hour', created_at) as hour,
    COUNT(*) as messages
FROM chat_history
GROUP BY DATE_TRUNC('hour', created_at)
ORDER BY hour;

-- Find sessions mentioning specific topics
SELECT DISTINCT session_id
FROM chat_history
WHERE message->>'content' ILIKE '%refund%';
```

---

## MongoDBChatMessageHistory

### Overview

MongoDB provides flexible document storage with native JSON support.

### Implementation

```python
from langchain_mongodb import MongoDBChatMessageHistory
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_openai import ChatOpenAI
from langchain_core.runnables.history import RunnableWithMessageHistory

MONGODB_URI = "mongodb://localhost:27017"

def get_mongodb_history(session_id: str) -> MongoDBChatMessageHistory:
    """Factory function for MongoDB message history."""
    return MongoDBChatMessageHistory(
        connection_string=MONGODB_URI,
        database_name="chat_app",
        collection_name="conversations",
        session_id=session_id
    )

# Build chain
prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a helpful assistant."),
    MessagesPlaceholder(variable_name="history"),
    ("human", "{input}")
])

llm = ChatOpenAI(model="gpt-4o")
chain = prompt | llm

with_history = RunnableWithMessageHistory(
    chain,
    get_mongodb_history,
    input_messages_key="input",
    history_messages_key="history"
)
```

### MongoDB Document Structure

```javascript
// Document in MongoDB
{
    "_id": ObjectId("..."),
    "SessionId": "user_123",
    "History": [
        {
            "type": "human",
            "content": "Hello!",
            "additional_kwargs": {}
        },
        {
            "type": "ai", 
            "content": "Hi! How can I help?",
            "additional_kwargs": {}
        }
    ]
}
```

---

## Message Trimming Strategies

### Token-Based Trimming

```python
from langchain_core.messages import trim_messages, SystemMessage
from langchain_openai import ChatOpenAI

# Create a trimmer
trimmer = trim_messages(
    max_tokens=1000,
    strategy="last",  # Keep most recent messages
    token_counter=ChatOpenAI(model="gpt-4o"),
    include_system=True,  # Always include system message
    start_on="human",  # Ensure we start on a human message
    allow_partial=False  # Don't cut messages in half
)

# Example messages
messages = [
    SystemMessage(content="You are a helpful assistant."),
    HumanMessage(content="Question 1..."),
    AIMessage(content="Answer 1..." * 100),  # Long answer
    HumanMessage(content="Question 2..."),
    AIMessage(content="Answer 2..." * 100),  # Long answer
    HumanMessage(content="Question 3..."),
]

# Trim to fit token budget
trimmed = trimmer.invoke(messages)
print(f"Original: {len(messages)} messages")
print(f"Trimmed: {len(trimmed)} messages")
```

### Count-Based Trimming

```python
from langchain_core.messages import trim_messages

# Keep last N messages
trimmer = trim_messages(
    max_tokens=10,  # This becomes message count when no token_counter
    strategy="last",
    include_system=True,
)
```

### Custom Trimming Logic

```python
from langchain_core.messages import BaseMessage, SystemMessage
from typing import List

def smart_trim(
    messages: List[BaseMessage],
    max_messages: int = 20,
    preserve_system: bool = True
) -> List[BaseMessage]:
    """
    Custom trimming that:
    1. Always preserves system message
    2. Keeps first user message (often contains important context)
    3. Keeps last N messages
    """
    if len(messages) <= max_messages:
        return messages
    
    result = []
    
    # Preserve system message
    if preserve_system and messages and isinstance(messages[0], SystemMessage):
        result.append(messages[0])
        messages = messages[1:]
        max_messages -= 1
    
    # Keep first exchange if it exists
    if len(messages) >= 2:
        result.extend(messages[:2])
        messages = messages[2:]
        max_messages -= 2
    
    # Keep last N messages
    if messages:
        result.extend(messages[-max_messages:])
    
    return result
```

---

## The RunnableWithMessageHistory Pattern

### Complete Implementation

```python
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.runnables.history import RunnableWithMessageHistory
from langchain_core.chat_history import BaseChatMessageHistory
from langchain_openai import ChatOpenAI
from typing import Callable

def create_conversation_chain(
    get_session_history: Callable[[str], BaseChatMessageHistory],
    system_prompt: str = "You are a helpful assistant.",
    model: str = "gpt-4o"
):
    """Create a production-ready conversation chain with history."""
    
    prompt = ChatPromptTemplate.from_messages([
        ("system", system_prompt),
        MessagesPlaceholder(variable_name="history"),
        ("human", "{input}")
    ])
    
    llm = ChatOpenAI(model=model, temperature=0.7)
    chain = prompt | llm
    
    return RunnableWithMessageHistory(
        chain,
        get_session_history,
        input_messages_key="input",
        history_messages_key="history"
    )

# Usage with Redis
from langchain_community.chat_message_histories import RedisChatMessageHistory

def redis_history_factory(session_id: str):
    return RedisChatMessageHistory(session_id=session_id, url="redis://localhost:6379")

conversation = create_conversation_chain(
    get_session_history=redis_history_factory,
    system_prompt="You are a helpful customer service agent."
)

# Invoke with session
config = {"configurable": {"session_id": "customer_123"}}
response = conversation.invoke({"input": "I have a question about my bill"}, config=config)
```

### Multi-Key Configuration

```python
from langchain_core.runnables.history import RunnableWithMessageHistory
from langchain_community.chat_message_histories import RedisChatMessageHistory

def get_history_with_user_and_conversation(
    user_id: str,
    conversation_id: str
) -> RedisChatMessageHistory:
    """Support multiple users with multiple conversations each."""
    session_key = f"{user_id}:{conversation_id}"
    return RedisChatMessageHistory(
        session_id=session_key,
        url="redis://localhost:6379"
    )

# Chain with multi-key config
with_history = RunnableWithMessageHistory(
    chain,
    get_history_with_user_and_conversation,
    input_messages_key="input",
    history_messages_key="history",
    history_factory_config=[
        {"configurable_key": "user_id"},
        {"configurable_key": "conversation_id"}
    ]
)

# Usage
config = {
    "configurable": {
        "user_id": "user_456",
        "conversation_id": "conv_789"
    }
}

response = with_history.invoke({"input": "Hello!"}, config=config)
```

---

## Best Practices

### 1. Use add_messages for Bulk Operations

```python
from langchain_core.messages import HumanMessage, AIMessage

# BAD: Multiple round trips
history.add_user_message("Hello")
history.add_ai_message("Hi!")
history.add_user_message("How are you?")
history.add_ai_message("I'm good!")

# GOOD: Single operation
history.add_messages([
    HumanMessage(content="Hello"),
    AIMessage(content="Hi!"),
    HumanMessage(content="How are you?"),
    AIMessage(content="I'm good!")
])
```

### 2. Implement Session Expiry

```python
from langchain_community.chat_message_histories import RedisChatMessageHistory

# Redis with TTL
history = RedisChatMessageHistory(
    session_id="session_123",
    url="redis://localhost:6379",
    ttl=3600  # Expire after 1 hour of inactivity
)
```

### 3. Handle Token Limits

```python
from langchain_core.messages import trim_messages
from langchain_openai import ChatOpenAI

def get_trimmed_history(session_id: str, max_tokens: int = 2000):
    """Get history with automatic trimming."""
    raw_history = get_redis_history(session_id)
    
    trimmer = trim_messages(
        max_tokens=max_tokens,
        strategy="last",
        token_counter=ChatOpenAI(model="gpt-4o"),
        include_system=True
    )
    
    return trimmer.invoke(raw_history.messages)
```

### 4. Implement History Summarization

```python
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage

async def summarize_and_compact(
    history: BaseChatMessageHistory,
    llm: ChatOpenAI,
    max_messages: int = 20
):
    """Summarize older messages when history gets too long."""
    messages = history.messages
    
    if len(messages) <= max_messages:
        return  # No action needed
    
    # Messages to summarize (older ones)
    to_summarize = messages[:-max_messages]
    
    # Messages to keep (recent ones)
    to_keep = messages[-max_messages:]
    
    # Generate summary
    summary_prompt = f"""Summarize this conversation concisely, preserving key facts and decisions:
    
{chr(10).join([f'{m.type}: {m.content}' for m in to_summarize])}
"""
    
    summary_response = await llm.ainvoke([HumanMessage(content=summary_prompt)])
    
    # Clear and rebuild history
    history.clear()
    
    # Add summary as system context
    history.add_message(SystemMessage(
        content=f"Previous conversation summary: {summary_response.content}"
    ))
    
    # Add recent messages
    history.add_messages(to_keep)
```

---

## Persistence Backend Comparison

| Backend | Latency | Scalability | Durability | Query Support | Best For |
|---------|---------|-------------|------------|---------------|----------|
| InMemory | ~0ms | Single process | None | Basic | Development |
| Redis | 1-5ms | High (cluster) | Optional (RDB/AOF) | Limited | High-performance production |
| PostgreSQL | 5-20ms | High (replicas) | Full ACID | Rich SQL | Analytics, audit trails |
| MongoDB | 3-10ms | High (sharding) | Configurable | Rich queries | Flexible schemas |
| SQLite | 1-10ms | Single machine | File-based | SQL | Single-server apps |

---

## Summary

1. **Development**: Use `InMemoryChatMessageHistory` for quick iteration
2. **Production**: Use `RedisChatMessageHistory` for speed or `PostgresChatMessageHistory` for durability
3. **Always use `RunnableWithMessageHistory`**: The modern LCEL pattern for managing conversation state
4. **Implement trimming**: Prevent context window overflow with `trim_messages`
5. **Consider TTL**: Sessions should expire to manage storage

---

## References

- [LangChain Short-term Memory Documentation](https://docs.langchain.com/oss/python/langchain/short-term-memory)
- [LangChain Chat History Reference](https://reference.langchain.com/python/langchain-core/chat_history)
- [PostgresChatMessageHistory Guide](https://hexacluster.ai/blog/postgres-for-chat-history-langchain-postgres-postgreschatmessagehistory)
- [InMemoryChatMessageHistory vs Persistent Storage](https://theneuralbase.com/langchain/learn/intermediate/inmemorychatmessagehistory-vs-persistent-storage/)
