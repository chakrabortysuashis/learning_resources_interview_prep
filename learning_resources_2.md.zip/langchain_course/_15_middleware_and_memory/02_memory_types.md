# Module 15.2: LangChain Memory Types

## Introduction

Memory is essential for building conversational AI applications that maintain context across multiple interactions. LangChain provides various memory implementations, each with different trade-offs between context fidelity, token usage, and computational cost.

## The Stateless Problem

LLM APIs are inherently stateless - each API call is independent with no memory of previous interactions. This creates a challenge for conversational applications:

```
+-------------+     +-------------+     +-------------+
|   Turn 1    |     |   Turn 2    |     |   Turn 3    |
| "Hi, I'm    |     | "What's my  |     | "Remember,  |
|   Alice"    |     |   name?"    |     |  I'm Alice!"|
+------+------+     +------+------+     +------+------+
       |                   |                   |
       v                   v                   v
+------+------+     +------+------+     +------+------+
|   LLM API   |     |   LLM API   |     |   LLM API   |
|  (no state) |     |  (no state) |     |  (no state) |
+------+------+     +------+------+     +------+------+
       |                   |                   |
       v                   v                   v
   "Nice to          "I don't            "Got it,
    meet you!"        know"               Alice!"
```

Memory solves this by explicitly passing conversation history with each request.

---

## Memory Architecture Overview

```
+------------------+
|   User Message   |
+--------+---------+
         |
         v
+--------+---------+
|   Load Memory    |
|   (History)      |
+--------+---------+
         |
         v
+--------+---------+
|   Combine with   |
|   User Input     |
+--------+---------+
         |
         v
+--------+---------+
|    LLM Call      |
+--------+---------+
         |
         v
+--------+---------+
|  Save to Memory  |
|  (Update History)|
+--------+---------+
         |
         v
+--------+---------+
|   AI Response    |
+------------------+
```

---

## Memory Types Comparison

| Memory Type | Token Usage | Context Loss | Best For | Complexity |
|-------------|-------------|--------------|----------|------------|
| ConversationBufferMemory | High (grows linearly) | None | Short conversations | Low |
| ConversationBufferWindowMemory | Medium (fixed) | Recent only | Most use cases | Low |
| ConversationSummaryMemory | Low-Medium | Details lost | Long conversations | Medium |
| ConversationSummaryBufferMemory | Medium | Balanced | Production apps | Medium |
| ConversationTokenBufferMemory | Controlled | Recent only | Token-sensitive apps | Low |
| ConversationEntityMemory | Medium | Relationships | Entity-tracking | High |

---

## 1. ConversationBufferMemory

### Overview

The simplest memory type - stores the complete conversation history verbatim. Every message is preserved, making it ideal when full context is essential.

### Token Growth Visualization

```
Turn 1:  [====]                          ~100 tokens
Turn 2:  [========]                      ~200 tokens
Turn 3:  [============]                  ~300 tokens
Turn 4:  [================]              ~400 tokens
...
Turn 20: [======================...===]  ~2000 tokens
                    ^
                    |
         LINEAR GROWTH - Eventually exceeds context window!
```

### Implementation (Legacy Pattern)

```python
from langchain.memory import ConversationBufferMemory
from langchain_openai import ChatOpenAI
from langchain.chains import ConversationChain

# Initialize memory
memory = ConversationBufferMemory(
    return_messages=True,  # Return as message objects
    memory_key="history"   # Key used in prompt template
)

# Create conversation chain
llm = ChatOpenAI(model="gpt-4o", temperature=0.7)
conversation = ConversationChain(
    llm=llm,
    memory=memory,
    verbose=True
)

# Interact
response1 = conversation.predict(input="Hi, my name is Alice!")
print(response1)

response2 = conversation.predict(input="What's my name?")
print(response2)  # Should correctly recall "Alice"

# Inspect memory
print(memory.buffer)
```

### Modern LCEL Pattern (Recommended)

```python
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_openai import ChatOpenAI
from langchain_core.chat_history import InMemoryChatMessageHistory
from langchain_core.runnables.history import RunnableWithMessageHistory

# Store for session histories
store = {}

def get_session_history(session_id: str):
    if session_id not in store:
        store[session_id] = InMemoryChatMessageHistory()
    return store[session_id]

# Define prompt with history placeholder
prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a helpful assistant."),
    MessagesPlaceholder(variable_name="history"),
    ("human", "{input}")
])

# Create chain
llm = ChatOpenAI(model="gpt-4o")
chain = prompt | llm

# Wrap with message history
with_history = RunnableWithMessageHistory(
    chain,
    get_session_history,
    input_messages_key="input",
    history_messages_key="history"
)

# Use with session
config = {"configurable": {"session_id": "user_123"}}

response1 = with_history.invoke(
    {"input": "My name is Alice"},
    config=config
)
print(response1.content)

response2 = with_history.invoke(
    {"input": "What's my name?"},
    config=config
)
print(response2.content)  # "Your name is Alice"
```

### Advantages

- Complete conversation fidelity
- Simple to implement
- No information loss
- Good for debugging

### Disadvantages

- Unlimited token growth
- Eventually exceeds context window
- Expensive for long conversations
- Increased latency

### When to Use

- Short, focused conversations (< 10 turns)
- Debugging and development
- When every detail matters
- Customer support with limited interaction

---

## 2. ConversationBufferWindowMemory

### Overview

Maintains only the last K interactions, creating a sliding window of recent conversation history.

### Token Usage Visualization

```
Turn 1:  [====]              
Turn 2:  [====][====]        
Turn 3:  [====][====][====]  <- Window size = 3
Turn 4:       [====][====][====]  <- Turn 1 dropped
Turn 5:            [====][====][====]  <- Turn 2 dropped
...
         ^--- Always maintains fixed token budget
```

### Implementation

```python
from langchain.memory import ConversationBufferWindowMemory
from langchain_openai import ChatOpenAI
from langchain.chains import ConversationChain

# Keep only last 5 exchanges
memory = ConversationBufferWindowMemory(
    k=5,  # Number of interactions to keep
    return_messages=True,
    memory_key="history"
)

llm = ChatOpenAI(model="gpt-4o", temperature=0.7)
conversation = ConversationChain(
    llm=llm,
    memory=memory,
    verbose=True
)

# Simulate many turns
for i in range(10):
    response = conversation.predict(input=f"This is message number {i}")

# Memory only contains last 5 turns
print(f"Memory contains {len(memory.buffer)} messages")
```

### Modern LCEL with Trimming

```python
from langchain_core.messages import trim_messages
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_openai import ChatOpenAI
from langchain_core.chat_history import InMemoryChatMessageHistory
from langchain_core.runnables.history import RunnableWithMessageHistory

# Message trimmer - keep last 10 messages
trimmer = trim_messages(
    max_tokens=1000,  # Or use count
    strategy="last",
    token_counter=ChatOpenAI(model="gpt-4o"),
    include_system=True,
    start_on="human"
)

# Session store
store = {}

def get_session_history(session_id: str):
    if session_id not in store:
        store[session_id] = InMemoryChatMessageHistory()
    return store[session_id]

prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a helpful assistant."),
    MessagesPlaceholder(variable_name="history"),
    ("human", "{input}")
])

llm = ChatOpenAI(model="gpt-4o")

# Chain with trimming
chain = (
    {"history": lambda x: trimmer.invoke(x.get("history", [])), "input": lambda x: x["input"]}
    | prompt
    | llm
)

with_history = RunnableWithMessageHistory(
    chain,
    get_session_history,
    input_messages_key="input",
    history_messages_key="history"
)
```

### Advantages

- Predictable token usage
- Good balance of context and cost
- Simple to understand
- Works well for most use cases

### Disadvantages

- Early context is lost forever
- May forget important early information
- Abrupt cutoff (no gradual degradation)

### When to Use

- General-purpose chatbots
- When recent context is most important
- Predictable cost requirements
- Medium-length conversations

---

## 3. ConversationSummaryMemory

### Overview

Instead of storing raw messages, this memory type maintains a running summary of the conversation. An LLM is used to generate and update the summary.

### Architecture

```
+------------------+
|   New Message    |
+--------+---------+
         |
         v
+--------+---------+     +------------------+
|  Current Summary |---->|   LLM Call       |
|  "User discussed |     |  (Summarizer)    |
|   project X..."  |     +--------+---------+
+------------------+              |
                                  v
                         +--------+---------+
                         |  Updated Summary |
                         |  "User discussed |
                         |   project X and  |
                         |   asked about Y" |
                         +------------------+
```

### Token Usage Comparison

```
Buffer Memory (10 turns):
[Full Turn 1][Full Turn 2][Full Turn 3]...[Full Turn 10]
= ~1500 tokens

Summary Memory (10 turns):
[Condensed Summary of all 10 turns]
= ~200-300 tokens

Savings: 80-90% for long conversations!
```

### Implementation

```python
from langchain.memory import ConversationSummaryMemory
from langchain_openai import ChatOpenAI
from langchain.chains import ConversationChain

# LLM for summarization
llm = ChatOpenAI(model="gpt-4o", temperature=0)

# Initialize summary memory (requires LLM)
memory = ConversationSummaryMemory(
    llm=llm,
    return_messages=True,
    memory_key="history"
)

conversation = ConversationChain(
    llm=llm,
    memory=memory,
    verbose=True
)

# Have a conversation
conversation.predict(input="I'm working on a machine learning project for fraud detection.")
conversation.predict(input="We're using a Random Forest classifier with 100 estimators.")
conversation.predict(input="Our current accuracy is 95% but we want to improve recall.")

# View the summary instead of full history
print("Current Summary:")
print(memory.buffer)
```

### Custom Summary Prompt

```python
from langchain.memory import ConversationSummaryMemory
from langchain_openai import ChatOpenAI
from langchain_core.prompts import PromptTemplate

# Custom summarization prompt
SUMMARY_PROMPT = PromptTemplate(
    input_variables=["summary", "new_lines"],
    template="""Progressively summarize the conversation, focusing on:
1. Key decisions made
2. Action items
3. Important facts mentioned

Current summary:
{summary}

New lines of conversation:
{new_lines}

New summary:"""
)

llm = ChatOpenAI(model="gpt-4o", temperature=0)

memory = ConversationSummaryMemory(
    llm=llm,
    prompt=SUMMARY_PROMPT,
    return_messages=True
)
```

### Advantages

- Dramatic token savings for long conversations
- Scales to very long interactions
- Preserves key information
- Graceful degradation of detail

### Disadvantages

- Details are lost in summarization
- Additional LLM calls for summarization
- Latency from summarization step
- Summary quality depends on summarizer LLM

### When to Use

- Very long conversations
- When gist matters more than exact words
- Cost-sensitive applications
- Session-spanning interactions

---

## 4. ConversationSummaryBufferMemory

### Overview

A hybrid approach: keeps recent messages verbatim while summarizing older ones. Provides the best of both worlds - detailed recent context with compressed historical context.

### Architecture

```
+-----------------------------------------+
|              Memory Structure           |
+-----------------------------------------+
|                                         |
|  +---------------+  +----------------+  |
|  |   SUMMARY     |  |  RECENT BUFFER |  |
|  |   (Older)     |  |  (Verbatim)    |  |
|  |               |  |                |  |
|  | "User asked   |  | Turn N-2: ...  |  |
|  |  about ML..." |  | Turn N-1: ...  |  |
|  |               |  | Turn N: ...    |  |
|  +---------------+  +----------------+  |
|         ^                   ^           |
|         |                   |           |
|   Compressed            Full detail     |
|   (saves tokens)       (recent context) |
+-----------------------------------------+
```

### Token Budget Visualization

```
Token Budget: 1000 tokens total

[Summary: ~200 tokens][Recent Messages: ~800 tokens]
       ^                        ^
       |                        |
   Older context           Last K messages
   (compressed)            (full detail)

When buffer exceeds limit:
- Oldest messages summarized
- Summary updated
- Buffer trimmed
```

### Implementation

```python
from langchain.memory import ConversationSummaryBufferMemory
from langchain_openai import ChatOpenAI
from langchain.chains import ConversationChain

llm = ChatOpenAI(model="gpt-4o", temperature=0)

# Hybrid memory with 1000 token buffer limit
memory = ConversationSummaryBufferMemory(
    llm=llm,
    max_token_limit=1000,  # When exceeded, oldest messages are summarized
    return_messages=True,
    memory_key="history"
)

conversation = ConversationChain(
    llm=llm,
    memory=memory,
    verbose=True
)

# Early messages will eventually be summarized
for i in range(20):
    response = conversation.predict(
        input=f"Let's discuss point {i} of our project plan in detail."
    )

# Check structure
print("Moving Summary:", memory.moving_summary_buffer)
print("Buffer Messages:", len(memory.buffer))
```

### Advantages

- Best balance of context and efficiency
- Recent context preserved exactly
- Older context still accessible (summarized)
- Predictable token budget

### Disadvantages

- More complex than simple buffers
- Summarization adds latency
- Configuration tuning required

### When to Use

- Production chatbots
- Medium to long conversations
- When both recent detail and history matter
- Default choice for most applications

---

## 5. ConversationTokenBufferMemory

### Overview

Similar to window memory but limits by token count rather than message count. More precise control over context window usage.

### Implementation

```python
from langchain.memory import ConversationTokenBufferMemory
from langchain_openai import ChatOpenAI
from langchain.chains import ConversationChain

llm = ChatOpenAI(model="gpt-4o", temperature=0)

# Limit to 500 tokens of history
memory = ConversationTokenBufferMemory(
    llm=llm,  # Used for token counting
    max_token_limit=500,
    return_messages=True,
    memory_key="history"
)

conversation = ConversationChain(
    llm=llm,
    memory=memory,
    verbose=True
)

# Messages automatically pruned to stay under 500 tokens
response = conversation.predict(input="Tell me a long story about AI.")
```

### Advantages

- Precise token budget control
- Accounts for variable message lengths
- Prevents context overflow

### Disadvantages

- Requires token counting (slight overhead)
- Still loses early context

### When to Use

- Strict token budget requirements
- Variable-length messages
- API cost optimization

---

## 6. ConversationEntityMemory

### Overview

Tracks specific entities (people, places, concepts) mentioned in the conversation, maintaining structured knowledge about them.

### Architecture

```
+------------------+
|  Conversation    |
+--------+---------+
         |
         v
+--------+---------+
|  Entity Extractor|
|  (LLM-powered)   |
+--------+---------+
         |
         v
+--------+---------------------------+
|         Entity Store               |
+------------------------------------+
| Entity: "Alice"                    |
| - Role: Project Manager            |
| - Works at: TechCorp               |
| - Mentioned: Turn 1, 5, 8          |
+------------------------------------+
| Entity: "Project X"                |
| - Type: ML Project                 |
| - Status: In Progress              |
| - Team Size: 5 people              |
+------------------------------------+
```

### Implementation

```python
from langchain.memory import ConversationEntityMemory
from langchain_openai import ChatOpenAI
from langchain.chains import ConversationChain

llm = ChatOpenAI(model="gpt-4o", temperature=0)

memory = ConversationEntityMemory(
    llm=llm,
    return_messages=True
)

conversation = ConversationChain(
    llm=llm,
    memory=memory,
    verbose=True
)

# Discuss entities
conversation.predict(input="I work with Alice at TechCorp. She's our project manager.")
conversation.predict(input="Our project, called Phoenix, aims to reduce fraud by 50%.")
conversation.predict(input="Bob from the data team is helping Alice with the ML models.")

# Query entities
print("Entities tracked:")
print(memory.entity_store.store)

# The model can now answer questions about these entities
response = conversation.predict(input="What do you know about Alice?")
print(response)
```

### Advantages

- Structured knowledge extraction
- Good for entity-heavy conversations
- Enables complex reasoning about relationships
- Compact storage of relevant facts

### Disadvantages

- Higher complexity
- More LLM calls for extraction
- May miss nuanced information

### When to Use

- Customer support (tracking user details)
- Knowledge management
- Complex multi-entity discussions
- CRM-like applications

---

## Modern Memory Patterns (LCEL)

### The RunnableWithMessageHistory Pattern

```python
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_openai import ChatOpenAI
from langchain_core.chat_history import BaseChatMessageHistory
from langchain_core.runnables.history import RunnableWithMessageHistory
from langchain_community.chat_message_histories import RedisChatMessageHistory

def get_session_history(session_id: str) -> BaseChatMessageHistory:
    """Factory function for session histories."""
    return RedisChatMessageHistory(
        session_id=session_id,
        url="redis://localhost:6379"
    )

prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a helpful AI assistant."),
    MessagesPlaceholder(variable_name="history"),
    ("human", "{input}")
])

llm = ChatOpenAI(model="gpt-4o")
chain = prompt | llm

# Wrap with history management
conversation = RunnableWithMessageHistory(
    chain,
    get_session_history,
    input_messages_key="input",
    history_messages_key="history"
)

# Use with different sessions
config_user1 = {"configurable": {"session_id": "user_001"}}
config_user2 = {"configurable": {"session_id": "user_002"}}

# Each user has separate history
response1 = conversation.invoke({"input": "I'm User 1"}, config=config_user1)
response2 = conversation.invoke({"input": "I'm User 2"}, config=config_user2)
```

### Memory with Streaming

```python
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_openai import ChatOpenAI
from langchain_core.chat_history import InMemoryChatMessageHistory
from langchain_core.runnables.history import RunnableWithMessageHistory

store = {}

def get_history(session_id: str):
    if session_id not in store:
        store[session_id] = InMemoryChatMessageHistory()
    return store[session_id]

prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a helpful assistant."),
    MessagesPlaceholder(variable_name="history"),
    ("human", "{input}")
])

llm = ChatOpenAI(model="gpt-4o", streaming=True)
chain = prompt | llm

with_history = RunnableWithMessageHistory(
    chain,
    get_history,
    input_messages_key="input",
    history_messages_key="history"
)

# Stream with memory
config = {"configurable": {"session_id": "stream_session"}}

for chunk in with_history.stream({"input": "Tell me a joke"}, config=config):
    print(chunk.content, end="", flush=True)
```

---

## Memory Selection Guide

### Decision Tree

```
START
  |
  v
Is the conversation short (< 10 turns)?
  |
  +-- YES --> ConversationBufferMemory
  |
  +-- NO
        |
        v
      Do you need exact recall of recent messages?
        |
        +-- YES --> Is token budget critical?
        |             |
        |             +-- YES --> ConversationTokenBufferMemory
        |             |
        |             +-- NO --> ConversationBufferWindowMemory
        |
        +-- NO
              |
              v
            Is historical context important?
              |
              +-- YES --> ConversationSummaryBufferMemory (RECOMMENDED)
              |
              +-- NO --> ConversationSummaryMemory
```

### Production Recommendation

For most production applications, **ConversationSummaryBufferMemory** or the **LCEL + RunnableWithMessageHistory** pattern with message trimming provides the best balance:

```python
# Production-ready memory setup
from langchain_core.messages import trim_messages
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_openai import ChatOpenAI
from langchain_community.chat_message_histories import RedisChatMessageHistory
from langchain_core.runnables.history import RunnableWithMessageHistory

# Token-based trimmer
trimmer = trim_messages(
    max_tokens=2000,
    strategy="last",
    token_counter=ChatOpenAI(model="gpt-4o"),
    include_system=True,
)

def get_redis_history(session_id: str):
    return RedisChatMessageHistory(
        session_id=session_id,
        url="redis://localhost:6379",
        ttl=3600  # 1 hour session expiry
    )

prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a helpful customer service agent."),
    MessagesPlaceholder(variable_name="history"),
    ("human", "{input}")
])

llm = ChatOpenAI(model="gpt-4o", temperature=0.7)

chain = prompt | llm

conversation = RunnableWithMessageHistory(
    chain,
    get_redis_history,
    input_messages_key="input",
    history_messages_key="history"
)
```

---

## Summary

| Memory Type | Token Growth | Information Loss | LLM Overhead | Production Use |
|-------------|--------------|------------------|--------------|----------------|
| Buffer | Linear (unbounded) | None | None | Dev only |
| BufferWindow | Fixed | Older turns | None | Good |
| Summary | Sublinear | Details | Per turn | Good |
| SummaryBuffer | Bounded | Controlled | As needed | Excellent |
| TokenBuffer | Fixed (precise) | Older turns | Token counting | Good |
| Entity | Moderate | Non-entity info | Per turn | Specialized |

---

## References

- [Pinecone: Conversational Memory for LLMs](https://www.pinecone.io/learn/series/langchain/langchain-conversational-memory/)
- [LangChain ConversationBufferMemory Guide](https://latenode.com/blog/ai-frameworks-technical-infrastructure/langchain-setup-tools-agents-memory/langchain-conversationbuffer-memory-complete-implementation-guide-code-examples-2025)
- [LangChain Memory Reference](https://reference.langchain.com/python/langchain-classic/memory/buffer/ConversationBufferMemory)
- [Aurelio AI: LangChain Conversational Memory](https://www.aurelio.ai/learn/langchain-conversational-memory)
