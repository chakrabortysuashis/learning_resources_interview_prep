# Module 12: Retrievers - Part 2: Vector Store Retriever

## Introduction

The **VectorStoreRetriever** is the most common type of retriever in LangChain. It wraps a vector store and provides a standard retriever interface for semantic search operations.

## How Vector Store Retrieval Works

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    VECTOR STORE RETRIEVAL PIPELINE                          │
└─────────────────────────────────────────────────────────────────────────────┘

  ┌─────────┐    ┌────────────┐    ┌─────────────┐    ┌────────────────┐
  │  Query  │───▶│ Embedding  │───▶│   Vector    │───▶│   Top-K        │
  │ (text)  │    │   Model    │    │   Search    │    │   Documents    │
  └─────────┘    └────────────┘    └─────────────┘    └────────────────┘
                      │                   │
                      ▼                   ▼
               ┌────────────┐     ┌─────────────────┐
               │ Query      │     │  Vector Store   │
               │ Vector     │     │  (Chroma,       │
               │ [0.2, 0.8] │     │  Pinecone, etc) │
               └────────────┘     └─────────────────┘

  Distance Metrics:
  ─────────────────
  • Cosine Similarity: angle between vectors (most common)
  • Euclidean Distance: straight-line distance
  • Dot Product: magnitude-aware similarity
```

## Creating a VectorStoreRetriever

### The `as_retriever()` Method

Every vector store in LangChain has an `as_retriever()` method that converts it to a retriever:

```python
from langchain_community.vectorstores import Chroma
from langchain_openai import OpenAIEmbeddings

# Create embeddings model
embeddings = OpenAIEmbeddings()

# Sample documents
texts = [
    "LangChain is a framework for building LLM applications.",
    "Retrievers find relevant documents for a query.",
    "Vector stores use embeddings for semantic search.",
    "RAG combines retrieval with generation.",
    "Embeddings convert text to numerical vectors."
]

# Create vector store
vectorstore = Chroma.from_texts(
    texts=texts,
    embedding=embeddings,
    collection_name="my_collection"
)

# Convert to retriever
retriever = vectorstore.as_retriever()

# Use the retriever
docs = retriever.invoke("How does semantic search work?")
```

## Search Types

LangChain supports several search types through the `search_type` parameter:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         SEARCH TYPES COMPARISON                             │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐
│   SIMILARITY    │  │      MMR        │  │  SIMILARITY     │
│                 │  │                 │  │  SCORE THRESHOLD│
├─────────────────┤  ├─────────────────┤  ├─────────────────┤
│ Returns top-k   │  │ Balances        │  │ Returns docs    │
│ most similar    │  │ relevance with  │  │ above a minimum │
│ documents       │  │ diversity       │  │ similarity score│
├─────────────────┤  ├─────────────────┤  ├─────────────────┤
│ Fast & simple   │  │ Reduces         │  │ Quality control │
│                 │  │ redundancy      │  │                 │
├─────────────────┤  ├─────────────────┤  ├─────────────────┤
│ May return      │  │ Better coverage │  │ Variable number │
│ similar docs    │  │ of topics       │  │ of results      │
└─────────────────┘  └─────────────────┘  └─────────────────┘
```

### 1. Similarity Search (Default)

Returns the `k` most similar documents based on vector distance:

```python
# Basic similarity search
retriever = vectorstore.as_retriever(
    search_type="similarity",  # This is the default
    search_kwargs={"k": 4}     # Return 4 documents
)

docs = retriever.invoke("What is LangChain?")
```

### 2. Maximum Marginal Relevance (MMR)

MMR balances relevance with diversity to avoid returning redundant documents:

```python
# MMR search
retriever = vectorstore.as_retriever(
    search_type="mmr",
    search_kwargs={
        "k": 4,                # Final number of documents to return
        "fetch_k": 20,         # Fetch this many, then select k diverse ones
        "lambda_mult": 0.5     # 0 = max diversity, 1 = max relevance
    }
)

docs = retriever.invoke("What is LangChain?")
```

#### How MMR Works

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    MMR (Maximum Marginal Relevance)                         │
└─────────────────────────────────────────────────────────────────────────────┘

Step 1: Fetch fetch_k documents (e.g., 20)
        ┌───┬───┬───┬───┬───┬───┬───┬───┬───┬───┐
        │ 1 │ 2 │ 3 │ 4 │ 5 │ 6 │ 7 │ 8 │...│20 │  (sorted by relevance)
        └───┴───┴───┴───┴───┴───┴───┴───┴───┴───┘

Step 2: Iteratively select k documents (e.g., 4)

        For each selection:
        Score = lambda * Relevance - (1-lambda) * max(Similarity to selected)

        ┌─────────────────────────────────────────┐
        │  lambda = 0.5 (balanced)                │
        │                                         │
        │  High relevance ────────┐               │
        │                         ├──▶ Selected   │
        │  Low similarity to  ────┘               │
        │  already selected                       │
        └─────────────────────────────────────────┘

Step 3: Return k diverse, relevant documents
        ┌───┬───┬───┬───┐
        │ 1 │ 3 │ 7 │12 │  (diverse set)
        └───┴───┴───┴───┘
```

### 3. Similarity Score Threshold

Returns only documents that meet a minimum similarity threshold:

```python
# Similarity with score threshold
retriever = vectorstore.as_retriever(
    search_type="similarity_score_threshold",
    search_kwargs={
        "score_threshold": 0.7,  # Only return docs with score >= 0.7
        "k": 10                  # Maximum to return (if threshold met)
    }
)

docs = retriever.invoke("What is LangChain?")
# May return 0-10 documents depending on matches
```

## Search Parameters (search_kwargs)

The `search_kwargs` dictionary allows fine-grained control:

```python
# Comprehensive example
retriever = vectorstore.as_retriever(
    search_type="similarity",
    search_kwargs={
        # Number of results
        "k": 5,
        
        # Metadata filtering (depends on vector store)
        "filter": {
            "category": "technology",
            "year": {"$gte": 2023}
        },
        
        # Include similarity scores (if supported)
        # "include_metadata": True,
    }
)
```

### Metadata Filtering Examples

Different vector stores have different filter syntaxes:

```python
# Chroma filtering
retriever = vectorstore.as_retriever(
    search_kwargs={
        "k": 5,
        "filter": {"source": "docs.txt"}
    }
)

# Pinecone filtering
retriever = vectorstore.as_retriever(
    search_kwargs={
        "k": 5,
        "filter": {
            "category": {"$eq": "tech"},
            "price": {"$lt": 100}
        }
    }
)

# Multiple conditions (Chroma)
retriever = vectorstore.as_retriever(
    search_kwargs={
        "k": 5,
        "where": {
            "$and": [
                {"category": {"$eq": "tech"}},
                {"year": {"$gte": 2023}}
            ]
        }
    }
)
```

## Practical Examples

### Example 1: Basic RAG Setup

```python
from langchain_community.vectorstores import Chroma
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough

# Setup
embeddings = OpenAIEmbeddings()
llm = ChatOpenAI(model="gpt-4")

# Create vector store with documents
docs = [
    "The capital of France is Paris.",
    "The Eiffel Tower is 330 meters tall.",
    "France is known for wine and cheese.",
    "Paris has a population of about 2 million."
]

vectorstore = Chroma.from_texts(docs, embeddings)

# Create retriever
retriever = vectorstore.as_retriever(
    search_type="mmr",
    search_kwargs={"k": 2, "fetch_k": 4}
)

# Create RAG chain
prompt = ChatPromptTemplate.from_template("""
Answer the question based on the context below.

Context: {context}

Question: {question}

Answer:
""")

def format_docs(docs):
    return "\n\n".join(doc.page_content for doc in docs)

rag_chain = (
    {"context": retriever | format_docs, "question": RunnablePassthrough()}
    | prompt
    | llm
    | StrOutputParser()
)

# Query
response = rag_chain.invoke("Tell me about Paris")
print(response)
```

### Example 2: Multi-Index Retrieval

```python
from langchain_community.vectorstores import Chroma
from langchain_openai import OpenAIEmbeddings

embeddings = OpenAIEmbeddings()

# Create separate collections for different document types
tech_docs = ["AI is transforming industries", "Machine learning needs data"]
legal_docs = ["Contracts must be signed", "Laws vary by jurisdiction"]

tech_store = Chroma.from_texts(tech_docs, embeddings, collection_name="tech")
legal_store = Chroma.from_texts(legal_docs, embeddings, collection_name="legal")

# Create retrievers with different configurations
tech_retriever = tech_store.as_retriever(
    search_kwargs={"k": 3}
)

legal_retriever = legal_store.as_retriever(
    search_kwargs={"k": 2}  # Fewer results for legal docs
)

# Use based on context
query = "How does AI work?"
if "legal" in query.lower() or "law" in query.lower():
    docs = legal_retriever.invoke(query)
else:
    docs = tech_retriever.invoke(query)
```

### Example 3: Retriever with Score Filtering

```python
from langchain_community.vectorstores import FAISS
from langchain_openai import OpenAIEmbeddings

embeddings = OpenAIEmbeddings()

texts = [
    "Python is a programming language",
    "Java is also a programming language", 
    "The weather is sunny today",
    "Programming requires logical thinking"
]

vectorstore = FAISS.from_texts(texts, embeddings)

# Only return high-confidence matches
retriever = vectorstore.as_retriever(
    search_type="similarity_score_threshold",
    search_kwargs={
        "score_threshold": 0.75,
        "k": 5
    }
)

# Query about programming - should return relevant docs
docs = retriever.invoke("What is Python?")
print(f"Found {len(docs)} relevant documents")

# Query about unrelated topic - may return fewer/no docs
docs = retriever.invoke("What is the stock market?")
print(f"Found {len(docs)} relevant documents")
```

## Search Type Comparison

| Feature | Similarity | MMR | Score Threshold |
|---------|------------|-----|-----------------|
| **Speed** | Fast | Slower (2-pass) | Fast |
| **Diversity** | Low | High | Low |
| **Predictable count** | Yes (always k) | Yes (always k) | No (0 to k) |
| **Quality control** | None | Diversity-based | Score-based |
| **Best for** | Simple queries | Broad topics | Quality-critical apps |

## When to Use Each Search Type

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                     SEARCH TYPE SELECTION GUIDE                             │
└─────────────────────────────────────────────────────────────────────────────┘

    ┌───────────────────────────────────────┐
    │ Do you need guaranteed result count?  │
    └───────────────────────────────────────┘
                    │
         ┌──────────┴──────────┐
         │ Yes                 │ No
         ▼                     ▼
    ┌─────────────┐     ┌─────────────────────┐
    │ Need topic  │     │ similarity_score_   │
    │ diversity?  │     │ threshold           │
    └─────────────┘     │ (quality > quantity)│
         │              └─────────────────────┘
    ┌────┴────┐
    │Yes     │No
    ▼         ▼
┌───────┐ ┌──────────┐
│  MMR  │ │similarity│
│       │ │ (fastest)│
└───────┘ └──────────┘
```

## Performance Optimization Tips

### 1. Choose the Right `k` Value

```python
# Too low: might miss relevant docs
retriever = vectorstore.as_retriever(search_kwargs={"k": 1})  # Risky

# Too high: slow + noise
retriever = vectorstore.as_retriever(search_kwargs={"k": 100})  # Wasteful

# Sweet spot: usually 3-10 depending on use case
retriever = vectorstore.as_retriever(search_kwargs={"k": 5})  # Balanced
```

### 2. Use Metadata Filters to Narrow Search

```python
# Without filter: searches entire corpus
retriever = vectorstore.as_retriever(search_kwargs={"k": 5})

# With filter: searches subset (faster + more relevant)
retriever = vectorstore.as_retriever(
    search_kwargs={
        "k": 5,
        "filter": {"category": "technology", "date": {"$gte": "2024-01-01"}}
    }
)
```

### 3. Tune MMR Parameters

```python
# More diverse results (less redundancy)
retriever = vectorstore.as_retriever(
    search_type="mmr",
    search_kwargs={
        "k": 5,
        "fetch_k": 50,     # Larger pool to select from
        "lambda_mult": 0.3  # Favor diversity
    }
)

# More relevant results (accept some redundancy)
retriever = vectorstore.as_retriever(
    search_type="mmr",
    search_kwargs={
        "k": 5,
        "fetch_k": 10,     # Smaller pool
        "lambda_mult": 0.8  # Favor relevance
    }
)
```

### 4. Use Async for Concurrent Retrieval

```python
import asyncio

async def retrieve_multiple(retriever, queries):
    """Retrieve for multiple queries concurrently."""
    tasks = [retriever.ainvoke(q) for q in queries]
    results = await asyncio.gather(*tasks)
    return dict(zip(queries, results))

# Usage
queries = ["What is AI?", "How do embeddings work?", "What is RAG?"]
results = asyncio.run(retrieve_multiple(retriever, queries))
```

## Common Issues and Solutions

### Issue 1: No Results Returned

```python
# Problem: threshold too high
retriever = vectorstore.as_retriever(
    search_type="similarity_score_threshold",
    search_kwargs={"score_threshold": 0.99}  # Too strict
)

# Solution: lower threshold
retriever = vectorstore.as_retriever(
    search_type="similarity_score_threshold", 
    search_kwargs={"score_threshold": 0.5}  # More lenient
)
```

### Issue 2: Redundant Results

```python
# Problem: similar documents returned
# Solution: use MMR
retriever = vectorstore.as_retriever(
    search_type="mmr",
    search_kwargs={"k": 5, "fetch_k": 20, "lambda_mult": 0.5}
)
```

### Issue 3: Irrelevant Results

```python
# Problem: returning unrelated documents
# Solution 1: Add metadata filters
retriever = vectorstore.as_retriever(
    search_kwargs={"k": 5, "filter": {"topic": "relevant_topic"}}
)

# Solution 2: Use score threshold
retriever = vectorstore.as_retriever(
    search_type="similarity_score_threshold",
    search_kwargs={"score_threshold": 0.7}
)
```

## Summary

- `as_retriever()` converts any vector store to a retriever
- **Similarity search**: fast, returns exactly k results
- **MMR**: balances relevance with diversity
- **Score threshold**: quality control, variable result count
- Use `search_kwargs` to configure k, filters, and other parameters
- Choose search type based on your specific needs

## Next Steps

In the next section, we'll explore **MultiQueryRetriever** which uses an LLM to generate multiple query variations for better recall.

---

## References

- [LangChain VectorStore Retriever](https://reference.langchain.com/python/langchain-core/retrievers)
- [Retriever Integrations](https://docs.langchain.com/oss/python/integrations/retrievers)
- [Retrievers in LangChain](https://medium.com/@adatiyavinayshaileshbhai/retrievers-in-langchain-the-art-of-finding-the-right-stuff-732dea9f0e9b)
