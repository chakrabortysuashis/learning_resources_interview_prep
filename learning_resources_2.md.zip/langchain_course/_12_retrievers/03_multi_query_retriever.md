# Module 12: Retrievers - Part 3: MultiQueryRetriever

## Introduction

The **MultiQueryRetriever** addresses a fundamental limitation of distance-based similarity search: user queries are often ambiguous or don't directly match the language used in the documents. By generating multiple query variations, MultiQueryRetriever significantly improves recall.

## The Problem with Single Queries

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    THE SINGLE QUERY PROBLEM                                 │
└─────────────────────────────────────────────────────────────────────────────┘

User Query: "How do I make my code faster?"

    ┌────────────────────────────────────────────────────────────────────┐
    │  Documents in Vector Store                                         │
    ├────────────────────────────────────────────────────────────────────┤
    │  [x] "Performance optimization techniques for Python"              │
    │  [x] "Reducing algorithmic complexity from O(n^2) to O(n log n)"  │
    │  [x] "Caching strategies for improved response times"              │
    │  [ ] "How to make code faster" (exact match - rare!)               │
    └────────────────────────────────────────────────────────────────────┘

    Problem: User's casual phrasing doesn't match technical document language
    Result: Relevant documents may be missed!
```

## How MultiQueryRetriever Works

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    MULTI-QUERY RETRIEVAL PIPELINE                           │
└─────────────────────────────────────────────────────────────────────────────┘

                          ┌──────────────┐
                          │ User Query   │
                          │ "How do I    │
                          │ make code    │
                          │ faster?"     │
                          └──────┬───────┘
                                 │
                                 ▼
                    ┌────────────────────────┐
                    │         LLM            │
                    │  (Query Generation)    │
                    └────────────────────────┘
                                 │
            ┌────────────────────┼────────────────────┐
            ▼                    ▼                    ▼
    ┌───────────────┐   ┌───────────────┐   ┌───────────────┐
    │ Query 1:      │   │ Query 2:      │   │ Query 3:      │
    │"Performance   │   │"Code          │   │"Speed up      │
    │ optimization" │   │ efficiency"   │   │ execution"    │
    └───────┬───────┘   └───────┬───────┘   └───────┬───────┘
            │                   │                   │
            ▼                   ▼                   ▼
    ┌───────────────┐   ┌───────────────┐   ┌───────────────┐
    │  Retriever    │   │  Retriever    │   │  Retriever    │
    │  Search       │   │  Search       │   │  Search       │
    └───────┬───────┘   └───────┬───────┘   └───────┬───────┘
            │                   │                   │
            └───────────────────┼───────────────────┘
                                │
                                ▼
                    ┌────────────────────────┐
                    │   Combine & Dedupe     │
                    │   (Union of Results)   │
                    └────────────────────────┘
                                │
                                ▼
                    ┌────────────────────────┐
                    │   Final Document Set   │
                    │   (Higher Recall!)     │
                    └────────────────────────┘
```

## Basic Usage

### Creating a MultiQueryRetriever

```python
from langchain.retrievers.multi_query import MultiQueryRetriever
from langchain_community.vectorstores import Chroma
from langchain_openai import ChatOpenAI, OpenAIEmbeddings

# Setup base components
embeddings = OpenAIEmbeddings()
llm = ChatOpenAI(model="gpt-4", temperature=0)

# Create vector store with sample documents
texts = [
    "Performance optimization techniques include caching and indexing.",
    "Algorithmic complexity affects execution speed significantly.",
    "Profiling tools help identify bottlenecks in code.",
    "Memory management is crucial for fast applications.",
    "Parallel processing can speed up computation-heavy tasks."
]

vectorstore = Chroma.from_texts(texts, embeddings)
base_retriever = vectorstore.as_retriever(search_kwargs={"k": 3})

# Create MultiQueryRetriever
multi_query_retriever = MultiQueryRetriever.from_llm(
    retriever=base_retriever,
    llm=llm
)

# Use it
docs = multi_query_retriever.invoke("How do I make my code faster?")
print(f"Retrieved {len(docs)} unique documents")
```

### What Happens Behind the Scenes

When you call `invoke()`, the MultiQueryRetriever:

1. Sends your query to the LLM with a prompt to generate variations
2. Receives multiple query versions (typically 3-5)
3. Runs each query through the base retriever
4. Combines results and removes duplicates
5. Returns the unique document set

```python
# Example of generated queries for "How do I make my code faster?"
# Query 1: "What are techniques for code performance optimization?"
# Query 2: "How can I improve the execution speed of my program?"
# Query 3: "What strategies exist for writing efficient code?"
```

## Custom Query Generation

### Using a Custom Prompt

You can customize how queries are generated:

```python
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import LineListOutputParser

# Custom prompt for query generation
QUERY_PROMPT = PromptTemplate(
    input_variables=["question"],
    template="""You are an AI language model assistant. Your task is to generate 5
different versions of the given user question to retrieve relevant documents from
a vector database. By generating multiple perspectives on the user question, your
goal is to help the user overcome some of the limitations of distance-based
similarity search.

Provide these alternative questions separated by newlines.
Original question: {question}""",
)

# Create retriever with custom prompt
multi_query_retriever = MultiQueryRetriever.from_llm(
    retriever=base_retriever,
    llm=llm,
    prompt=QUERY_PROMPT
)
```

### Domain-Specific Query Generation

```python
# For a medical knowledge base
MEDICAL_QUERY_PROMPT = PromptTemplate(
    input_variables=["question"],
    template="""You are a medical information assistant. Generate 4 alternative 
versions of the following patient question. Include:
- A version using clinical/medical terminology
- A version using layman's terms
- A version focusing on symptoms
- A version focusing on treatments

Original question: {question}

Alternative questions (one per line):""",
)

# For a legal document search
LEGAL_QUERY_PROMPT = PromptTemplate(
    input_variables=["question"],
    template="""You are a legal research assistant. Generate 4 alternative 
search queries for the following legal question. Include:
- A version using formal legal terminology
- A version referencing relevant statutes or case law concepts
- A version focusing on the legal principle involved
- A version in plain language

Original question: {question}

Alternative queries (one per line):""",
)
```

## Configuring Query Count

```python
from langchain_core.prompts import PromptTemplate

# Generate more queries for better recall
MANY_QUERIES_PROMPT = PromptTemplate(
    input_variables=["question"],
    template="""Generate 7 different versions of this question for search:

Question: {question}

Versions (one per line):"""
)

# Generate fewer queries for faster processing
FEW_QUERIES_PROMPT = PromptTemplate(
    input_variables=["question"],  
    template="""Generate 2 alternative phrasings of this question:

Question: {question}

Alternatives (one per line):"""
)
```

## Logging and Debugging

### Viewing Generated Queries

```python
import logging

# Enable logging to see generated queries
logging.basicConfig()
logging.getLogger("langchain.retrievers.multi_query").setLevel(logging.DEBUG)

# Now when you run retrieval, you'll see the generated queries
docs = multi_query_retriever.invoke("How do I make my code faster?")

# Output will include:
# DEBUG:langchain.retrievers.multi_query:Generated queries: 
# ['What are code performance optimization techniques?',
#  'How can I speed up my program execution?',
#  'What methods improve code efficiency?']
```

### Custom Logging

```python
from langchain_core.callbacks import BaseCallbackHandler

class QueryLoggingHandler(BaseCallbackHandler):
    """Custom callback to log retrieval operations."""
    
    def on_retriever_start(self, serialized, query, **kwargs):
        print(f"Searching for: {query}")
    
    def on_retriever_end(self, documents, **kwargs):
        print(f"Found {len(documents)} documents")

# Use with callbacks
docs = multi_query_retriever.invoke(
    "How do I make my code faster?",
    config={"callbacks": [QueryLoggingHandler()]}
)
```

## Advanced Configuration

### Combining with Other Retrievers

```python
from langchain.retrievers import EnsembleRetriever

# Create base retrievers with different configurations
similarity_retriever = vectorstore.as_retriever(
    search_type="similarity",
    search_kwargs={"k": 5}
)

mmr_retriever = vectorstore.as_retriever(
    search_type="mmr",
    search_kwargs={"k": 5, "fetch_k": 20}
)

# Create MultiQueryRetrievers
multi_similarity = MultiQueryRetriever.from_llm(
    retriever=similarity_retriever,
    llm=llm
)

multi_mmr = MultiQueryRetriever.from_llm(
    retriever=mmr_retriever,
    llm=llm
)

# Combine them
ensemble = EnsembleRetriever(
    retrievers=[multi_similarity, multi_mmr],
    weights=[0.5, 0.5]
)
```

### Async Usage

```python
import asyncio

async def async_multi_query_retrieve(query):
    """Async retrieval with MultiQueryRetriever."""
    docs = await multi_query_retriever.ainvoke(query)
    return docs

# Run async
docs = asyncio.run(async_multi_query_retrieve("How do I make my code faster?"))
```

### With Metadata Filtering

```python
# Base retriever with metadata filter
filtered_retriever = vectorstore.as_retriever(
    search_kwargs={
        "k": 5,
        "filter": {"category": "performance"}
    }
)

# MultiQueryRetriever on top of filtered retriever
multi_query_filtered = MultiQueryRetriever.from_llm(
    retriever=filtered_retriever,
    llm=llm
)
```

## Performance Considerations

### Trade-offs

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    MULTIQUERY TRADE-OFFS                                    │
└─────────────────────────────────────────────────────────────────────────────┘

                    ┌─────────────────────────────────┐
                    │        Benefits                 │
                    ├─────────────────────────────────┤
                    │  + Higher recall                │
                    │  + Handles ambiguous queries    │
                    │  + Bridges vocabulary gap       │
                    │  + More comprehensive results   │
                    └─────────────────────────────────┘

                    ┌─────────────────────────────────┐
                    │        Costs                    │
                    ├─────────────────────────────────┤
                    │  - Additional LLM call          │
                    │  - Higher latency               │
                    │  - More API costs               │
                    │  - Multiple retrieval calls     │
                    └─────────────────────────────────┘

    Balance: Use when recall is critical, skip for simple/fast queries
```

### Optimization Strategies

```python
# 1. Use a smaller/faster model for query generation
from langchain_openai import ChatOpenAI

fast_llm = ChatOpenAI(
    model="gpt-3.5-turbo",  # Faster and cheaper than gpt-4
    temperature=0
)

multi_query_retriever = MultiQueryRetriever.from_llm(
    retriever=base_retriever,
    llm=fast_llm
)

# 2. Generate fewer queries when speed matters
FEW_QUERIES_PROMPT = PromptTemplate(
    input_variables=["question"],
    template="Generate 2 search queries for: {question}\nQueries:"
)

# 3. Cache query generation for repeated queries
from langchain.globals import set_llm_cache
from langchain_community.cache import InMemoryCache

set_llm_cache(InMemoryCache())
```

### When to Use MultiQueryRetriever

| Scenario | Use MultiQuery? | Reason |
|----------|-----------------|--------|
| User queries are often vague | Yes | Generates clearer alternatives |
| Domain has specialized vocabulary | Yes | Bridges terminology gap |
| Need maximum recall | Yes | Broader search coverage |
| Low latency required | No | LLM call adds latency |
| Simple, clear queries | No | Overhead not justified |
| Cost-sensitive application | Maybe | Balance cost vs recall |

## Complete Example: RAG with MultiQueryRetriever

```python
from langchain.retrievers.multi_query import MultiQueryRetriever
from langchain_community.vectorstores import Chroma
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough, RunnableParallel

# Setup
embeddings = OpenAIEmbeddings()
llm = ChatOpenAI(model="gpt-4", temperature=0)

# Load documents (example)
documents = [
    "Python's list comprehensions are faster than traditional for loops.",
    "Use generators for memory-efficient iteration over large datasets.",
    "The functools.lru_cache decorator provides automatic memoization.",
    "NumPy operations are vectorized and much faster than pure Python.",
    "Profiling with cProfile helps identify performance bottlenecks.",
    "Async/await patterns improve I/O-bound operation performance.",
    "Just-in-time compilation with Numba accelerates numerical code.",
]

# Create vector store
vectorstore = Chroma.from_texts(documents, embeddings)
base_retriever = vectorstore.as_retriever(search_kwargs={"k": 3})

# Create MultiQueryRetriever
multi_query_retriever = MultiQueryRetriever.from_llm(
    retriever=base_retriever,
    llm=llm
)

# RAG prompt
rag_prompt = ChatPromptTemplate.from_template("""
Answer the question based on the following context. If the context doesn't 
contain enough information, say so.

Context:
{context}

Question: {question}

Answer:
""")

def format_docs(docs):
    return "\n\n".join(f"- {doc.page_content}" for doc in docs)

# Build RAG chain
rag_chain = (
    RunnableParallel(
        context=multi_query_retriever | format_docs,
        question=RunnablePassthrough()
    )
    | rag_prompt
    | llm
    | StrOutputParser()
)

# Query
response = rag_chain.invoke("How can I make my Python code run faster?")
print(response)
```

## Comparison with Standard Retriever

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                STANDARD vs MULTI-QUERY RETRIEVER                            │
└─────────────────────────────────────────────────────────────────────────────┘

Query: "How do I make my code faster?"

Standard Retriever:
───────────────────
    Query ──▶ Single Search ──▶ 3 documents

    Results:
    1. "Profiling with cProfile helps identify performance bottlenecks."
    2. "The functools.lru_cache decorator provides automatic memoization."
    3. "Async/await patterns improve I/O-bound operation performance."


MultiQueryRetriever:
────────────────────
    Query ──▶ LLM Expansion ──▶ 3 queries ──▶ 3 searches ──▶ 7 unique docs

    Generated Queries:
    • "Performance optimization techniques in programming"
    • "How to improve code execution speed"
    • "Best practices for writing efficient code"

    Results (deduplicated):
    1. "Python's list comprehensions are faster than traditional for loops."
    2. "Use generators for memory-efficient iteration over large datasets."
    3. "The functools.lru_cache decorator provides automatic memoization."
    4. "NumPy operations are vectorized and much faster than pure Python."
    5. "Profiling with cProfile helps identify performance bottlenecks."
    6. "Async/await patterns improve I/O-bound operation performance."
    7. "Just-in-time compilation with Numba accelerates numerical code."

    = 133% more relevant documents retrieved!
```

## Summary

- **MultiQueryRetriever** generates multiple query variations using an LLM
- Significantly improves **recall** for ambiguous or colloquial queries
- Use **custom prompts** to control query generation style
- Enable **logging** to debug and understand generated queries
- Consider the **latency/cost trade-off** when deciding to use it
- Best suited for scenarios where **comprehensive retrieval** is important

## Next Steps

In the next section, we'll explore **ContextualCompressionRetriever** which focuses on improving precision by filtering and reranking retrieved documents.

---

## References

- [MultiQueryRetriever API Reference](https://api.python.langchain.com/en/latest/retrievers/langchain.retrievers.multi_query.MultiQueryRetriever.html)
- [LangChain MultiQueryRetriever Guide](https://www.kaggle.com/code/ksmooi/langchain-multiqueryretriever-quick-reference)
- [MultiQueryRetriever for Query Expansion](https://theneuralbase.com/langchain-advanced/learn/intermediate/multiqueryretriever-for-query-expansion/)
- [Using Advanced Retrievers in LangChain](https://www.comet.com/site/blog/using-advanced-retrievers-in-langchain/)
