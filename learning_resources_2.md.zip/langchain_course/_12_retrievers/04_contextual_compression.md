# Module 12: Retrievers - Part 4: Contextual Compression Retriever

## Introduction

The **ContextualCompressionRetriever** improves retrieval precision by post-processing retrieved documents. Instead of returning entire documents that may contain irrelevant sections, it extracts or filters to return only the most relevant content for the specific query.

## The Problem: Noisy Retrieval

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    THE NOISY RETRIEVAL PROBLEM                              │
└─────────────────────────────────────────────────────────────────────────────┘

Query: "What is the capital of France?"

Retrieved Document (500 words):
┌─────────────────────────────────────────────────────────────────────────────┐
│  France, officially the French Republic, is a country located primarily     │
│  in Western Europe. It also includes overseas territories in the Americas,  │
│  the Atlantic, Pacific and Indian Oceans. France borders Belgium,           │
│  Luxembourg, Germany, Switzerland, Monaco, Italy, Andorra and Spain.        │
│  [... 200 more words about geography ...]                                   │
│                                                                             │
│  ★ The capital and largest city is Paris, with a population of 2.1 million.│
│                                                                             │
│  [... 200 more words about economy and culture ...]                         │
└─────────────────────────────────────────────────────────────────────────────┘

Problem: Only 1 sentence is relevant, but the entire document is passed to LLM!
- Wastes tokens (cost)
- Dilutes signal with noise
- May confuse the LLM
```

## How Contextual Compression Works

```
┌─────────────────────────────────────────────────────────────────────────────┐
│              CONTEXTUAL COMPRESSION PIPELINE                                │
└─────────────────────────────────────────────────────────────────────────────┘

                    ┌─────────────┐
                    │   Query     │
                    └──────┬──────┘
                           │
                           ▼
                    ┌─────────────────┐
                    │ Base Retriever  │
                    │ (e.g., Vector)  │
                    └────────┬────────┘
                             │
                             ▼
                    ┌─────────────────┐
                    │  Raw Documents  │
                    │  (may be noisy) │
                    └────────┬────────┘
                             │
                             ▼
            ┌────────────────────────────────┐
            │       Document Compressor      │
            │  ┌──────────────────────────┐  │
            │  │ For each document:       │  │
            │  │ - Extract relevant parts │  │
            │  │ - Or filter entirely     │  │
            │  │ - Context: query + doc   │  │
            │  └──────────────────────────┘  │
            └────────────────┬───────────────┘
                             │
                             ▼
                    ┌─────────────────┐
                    │  Compressed     │
                    │  Documents      │
                    │  (relevant only)│
                    └─────────────────┘
```

## Types of Document Compressors

### Compressor Taxonomy

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    COMPRESSOR TYPES                                         │
└─────────────────────────────────────────────────────────────────────────────┘

                        Document Compressors
                               │
          ┌────────────────────┼────────────────────┐
          ▼                    ▼                    ▼
    ┌───────────┐        ┌───────────┐        ┌───────────┐
    │ Extractors│        │  Filters  │        │ Rerankers │
    │           │        │           │        │           │
    │ Extract   │        │ Remove    │        │ Reorder   │
    │ relevant  │        │ irrelevant│        │ by        │
    │ parts     │        │ documents │        │ relevance │
    └───────────┘        └───────────┘        └───────────┘
         │                    │                    │
         ▼                    ▼                    ▼
    LLMChain           LLMChainFilter        Cohere Rerank
    Extractor          EmbeddingsFilter      Cross-Encoder
                       DocumentFilter        BGE Reranker
```

## Basic Usage

### Using LLMChainExtractor

The `LLMChainExtractor` uses an LLM to extract only relevant portions from each document:

```python
from langchain.retrievers import ContextualCompressionRetriever
from langchain.retrievers.document_compressors import LLMChainExtractor
from langchain_community.vectorstores import Chroma
from langchain_openai import ChatOpenAI, OpenAIEmbeddings

# Setup
embeddings = OpenAIEmbeddings()
llm = ChatOpenAI(model="gpt-4", temperature=0)

# Create vector store
texts = [
    """France is a country in Western Europe. It has many famous landmarks 
    including the Eiffel Tower and the Louvre Museum. The capital and largest 
    city is Paris, which has a population of about 2.1 million people. France 
    is known for its wine, cheese, and fashion industry.""",
    
    """Germany is the largest economy in Europe. Its capital is Berlin. 
    Germany is famous for its automotive industry including BMW and Mercedes.""",
    
    """The United Kingdom consists of England, Scotland, Wales, and Northern 
    Ireland. London is the capital city. The UK has a constitutional monarchy."""
]

vectorstore = Chroma.from_texts(texts, embeddings)
base_retriever = vectorstore.as_retriever(search_kwargs={"k": 3})

# Create compressor
compressor = LLMChainExtractor.from_llm(llm)

# Create ContextualCompressionRetriever
compression_retriever = ContextualCompressionRetriever(
    base_compressor=compressor,
    base_retriever=base_retriever
)

# Query
docs = compression_retriever.invoke("What is the capital of France?")

for doc in docs:
    print(f"Content: {doc.page_content}")
    print("---")

# Output: Only relevant parts are extracted
# Content: The capital and largest city is Paris, which has a population of about 2.1 million people.
```

### Using LLMChainFilter

The `LLMChainFilter` removes entire documents that aren't relevant:

```python
from langchain.retrievers.document_compressors import LLMChainFilter

# Create filter (instead of extractor)
filter_compressor = LLMChainFilter.from_llm(llm)

compression_retriever = ContextualCompressionRetriever(
    base_compressor=filter_compressor,
    base_retriever=base_retriever
)

docs = compression_retriever.invoke("What is the capital of France?")
# Returns only documents that are relevant to France
# Germany and UK documents are filtered out
```

### Using EmbeddingsFilter

A faster, cheaper alternative using embedding similarity:

```python
from langchain.retrievers.document_compressors import EmbeddingsFilter

# Create embeddings-based filter
embeddings_filter = EmbeddingsFilter(
    embeddings=embeddings,
    similarity_threshold=0.76  # Filter docs below this threshold
)

compression_retriever = ContextualCompressionRetriever(
    base_compressor=embeddings_filter,
    base_retriever=base_retriever
)

docs = compression_retriever.invoke("What is the capital of France?")
```

## Reranking with Cross-Encoders

Cross-encoders provide the most accurate relevance scoring by processing query-document pairs together:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│              BI-ENCODER vs CROSS-ENCODER                                    │
└─────────────────────────────────────────────────────────────────────────────┘

Bi-Encoder (used in initial retrieval):
────────────────────────────────────────
    Query ──▶ Encoder ──▶ Query Vector    ─┐
                                           ├──▶ Cosine Similarity
    Doc ────▶ Encoder ──▶ Doc Vector      ─┘

    + Fast: vectors computed independently
    - Less accurate: no query-doc interaction


Cross-Encoder (used in reranking):
──────────────────────────────────
    [Query, Doc] ──▶ Joint Encoder ──▶ Relevance Score

    + More accurate: sees query and doc together
    - Slower: must process each pair
    
    Solution: Use bi-encoder to get top-N, then cross-encoder to rerank
```

### Using Cohere Reranker

```python
from langchain_cohere import CohereRerank

# Create Cohere reranker
reranker = CohereRerank(
    model="rerank-english-v3.0",
    top_n=5  # Return top 5 after reranking
)

compression_retriever = ContextualCompressionRetriever(
    base_compressor=reranker,
    base_retriever=base_retriever
)

# The retriever will:
# 1. Get documents from base_retriever
# 2. Rerank them using Cohere
# 3. Return top_n most relevant
docs = compression_retriever.invoke("What is the capital of France?")
```

### Using Open-Source Cross-Encoders

```python
from langchain.retrievers.document_compressors import CrossEncoderReranker
from langchain_community.cross_encoders import HuggingFaceCrossEncoder

# Load cross-encoder model
cross_encoder = HuggingFaceCrossEncoder(
    model_name="cross-encoder/ms-marco-MiniLM-L-6-v2"
)

# Create reranker
reranker = CrossEncoderReranker(
    model=cross_encoder,
    top_n=5
)

compression_retriever = ContextualCompressionRetriever(
    base_compressor=reranker,
    base_retriever=base_retriever
)
```

## Pipeline Compressors

Combine multiple compressors in a pipeline:

```python
from langchain.retrievers.document_compressors import DocumentCompressorPipeline
from langchain_community.document_transformers import EmbeddingsRedundantFilter
from langchain.retrievers.document_compressors import EmbeddingsFilter

# Create pipeline components
redundant_filter = EmbeddingsRedundantFilter(embeddings=embeddings)
relevance_filter = EmbeddingsFilter(
    embeddings=embeddings, 
    similarity_threshold=0.76
)

# Combine into pipeline
pipeline_compressor = DocumentCompressorPipeline(
    transformers=[
        redundant_filter,   # Remove duplicates first
        relevance_filter    # Then filter by relevance
    ]
)

compression_retriever = ContextualCompressionRetriever(
    base_compressor=pipeline_compressor,
    base_retriever=base_retriever
)
```

## Advanced: Splitter + Filter Pipeline

Split documents into smaller chunks before filtering for better precision:

```python
from langchain.retrievers.document_compressors import DocumentCompressorPipeline
from langchain_text_splitters import CharacterTextSplitter
from langchain.retrievers.document_compressors import EmbeddingsFilter

# Text splitter to break documents into smaller chunks
splitter = CharacterTextSplitter(
    chunk_size=300,
    chunk_overlap=50,
    separator=". "
)

# Embeddings filter
relevance_filter = EmbeddingsFilter(
    embeddings=embeddings,
    similarity_threshold=0.76
)

# Pipeline: split, then filter
pipeline_compressor = DocumentCompressorPipeline(
    transformers=[splitter, relevance_filter]
)

compression_retriever = ContextualCompressionRetriever(
    base_compressor=pipeline_compressor,
    base_retriever=base_retriever
)

# Now even large documents are split and only relevant chunks returned
docs = compression_retriever.invoke("What is the capital of France?")
```

## Compressor Comparison

| Compressor | Speed | Cost | Accuracy | Best For |
|------------|-------|------|----------|----------|
| **LLMChainExtractor** | Slow | High | High | Extracting relevant passages |
| **LLMChainFilter** | Slow | High | High | Binary relevance decisions |
| **EmbeddingsFilter** | Fast | Low | Medium | Quick filtering |
| **CohereRerank** | Medium | Medium | Very High | Production reranking |
| **CrossEncoderReranker** | Medium | Free | High | Self-hosted reranking |
| **Pipeline** | Varies | Varies | High | Complex workflows |

## Complete Example: Production Retrieval Pipeline

```python
from langchain.retrievers import ContextualCompressionRetriever
from langchain.retrievers.document_compressors import DocumentCompressorPipeline
from langchain_community.document_transformers import EmbeddingsRedundantFilter
from langchain_cohere import CohereRerank
from langchain_community.vectorstores import Chroma
from langchain_openai import OpenAIEmbeddings
from langchain.retrievers import EnsembleRetriever
from langchain_community.retrievers import BM25Retriever

# Setup
embeddings = OpenAIEmbeddings()

# Sample documents
documents = [
    "Python is a high-level programming language known for readability.",
    "Python supports multiple programming paradigms including OOP.",
    "Python's list comprehensions provide concise syntax for creating lists.",
    "Machine learning libraries like TensorFlow and PyTorch use Python.",
    "Python is widely used in data science and scientific computing.",
    "JavaScript is the language of the web, running in browsers.",
]

# Create vector store
vectorstore = Chroma.from_texts(documents, embeddings)
vector_retriever = vectorstore.as_retriever(search_kwargs={"k": 10})

# Create BM25 retriever
bm25_retriever = BM25Retriever.from_texts(documents)
bm25_retriever.k = 10

# Create ensemble retriever (hybrid search)
ensemble_retriever = EnsembleRetriever(
    retrievers=[vector_retriever, bm25_retriever],
    weights=[0.5, 0.5]
)

# Create compression pipeline
redundant_filter = EmbeddingsRedundantFilter(embeddings=embeddings)
reranker = CohereRerank(model="rerank-english-v3.0", top_n=5)

pipeline_compressor = DocumentCompressorPipeline(
    transformers=[redundant_filter, reranker]
)

# Final retriever: Ensemble + Compression
final_retriever = ContextualCompressionRetriever(
    base_compressor=pipeline_compressor,
    base_retriever=ensemble_retriever
)

# Query
docs = final_retriever.invoke("What is Python used for?")

print(f"Retrieved {len(docs)} highly relevant documents:")
for i, doc in enumerate(docs, 1):
    print(f"{i}. {doc.page_content}")
```

## Error Handling

Common issues and solutions:

```python
from langchain.retrievers import ContextualCompressionRetriever
from langchain.retrievers.document_compressors import LLMChainExtractor

try:
    docs = compression_retriever.invoke(query)
except Exception as e:
    # Handle extraction/reranking errors
    print(f"Compression failed: {e}")
    # Fallback to base retriever
    docs = base_retriever.invoke(query)

# Validate results
if not docs:
    print("No documents survived compression - check thresholds")
    # Option 1: Lower similarity threshold
    # Option 2: Retrieve more initial documents
    # Option 3: Fall back to base retriever
```

## Performance Optimization

### 1. Choose the Right Compressor

```python
# For speed-critical applications: EmbeddingsFilter
fast_compressor = EmbeddingsFilter(
    embeddings=embeddings,
    similarity_threshold=0.7
)

# For accuracy-critical applications: Reranker
accurate_compressor = CohereRerank(
    model="rerank-english-v3.0",
    top_n=5
)

# For cost-sensitive applications: Open-source cross-encoder
free_compressor = CrossEncoderReranker(
    model=HuggingFaceCrossEncoder("cross-encoder/ms-marco-MiniLM-L-6-v2"),
    top_n=5
)
```

### 2. Optimize Initial Retrieval

```python
# Retrieve more documents initially, then compress
base_retriever = vectorstore.as_retriever(
    search_kwargs={"k": 20}  # Get 20, compress to 5
)

reranker = CohereRerank(top_n=5)

compression_retriever = ContextualCompressionRetriever(
    base_compressor=reranker,
    base_retriever=base_retriever
)
```

### 3. Async Processing

```python
import asyncio

async def async_compress_retrieve(query):
    """Async retrieval with compression."""
    docs = await compression_retriever.ainvoke(query)
    return docs

# Concurrent queries
queries = ["Query 1", "Query 2", "Query 3"]
tasks = [async_compress_retrieve(q) for q in queries]
results = await asyncio.gather(*tasks)
```

## When to Use Contextual Compression

```
┌─────────────────────────────────────────────────────────────────────────────┐
│              WHEN TO USE CONTEXTUAL COMPRESSION                             │
└─────────────────────────────────────────────────────────────────────────────┘

Use ContextualCompressionRetriever when:

    [x] Documents are long and only parts are relevant
    [x] Initial retrieval returns some irrelevant documents
    [x] Token costs are a concern (shorter context = fewer tokens)
    [x] You need precise, focused answers
    [x] Quality matters more than speed

Skip ContextualCompressionRetriever when:

    [ ] Documents are already short/focused
    [ ] Speed is critical
    [ ] Budget for additional API calls is limited
    [ ] Initial retrieval quality is already high
```

## Summary

- **ContextualCompressionRetriever** improves precision by post-processing
- **LLMChainExtractor**: Extracts relevant passages (most accurate, slowest)
- **LLMChainFilter**: Removes irrelevant documents entirely
- **EmbeddingsFilter**: Fast, cheap filtering by similarity
- **Rerankers** (Cohere, Cross-Encoder): Best for final ranking
- Use **pipelines** to combine multiple compression steps
- Balance accuracy, speed, and cost based on your requirements

## Next Steps

In the next section, we'll explore **EnsembleRetriever** for combining multiple retrieval strategies.

---

## References

- [ContextualCompressionRetriever API](https://reference.langchain.com/python/langchain-classic/retrievers/contextual_compression/ContextualCompressionRetriever)
- [LangChain Contextual Compression Guide](https://adhdecode.com/articles/langchain/langchain-contextual-compression-retrieval/)
- [RAG Advanced Retrieval Patterns 2026](https://dev.to/young_gao/rag-is-not-dead-advanced-retrieval-patterns-that-actually-work-in-2026-2gbo)
- [LangChain ContextualCompressionRetriever Error Guide](https://theneuralbase.com/reranking/errors/langchain-contextualcompressionretriever-error/)
