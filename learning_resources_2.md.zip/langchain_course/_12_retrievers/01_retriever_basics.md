# Module 12: Retrievers - Part 1: Retriever Basics

## Introduction to Retrievers

A **retriever** is an interface that returns documents given an unstructured query. It is more general than a vector store - while vector stores can serve as the backbone of a retriever, retrievers don't need to store documents, only retrieve them.

## The Retrieval Pipeline

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        RETRIEVAL PIPELINE                                   │
└─────────────────────────────────────────────────────────────────────────────┘

     ┌──────────┐      ┌───────────────┐      ┌──────────────┐
     │  Query   │──────│   Retriever   │──────│  Documents   │
     │ (string) │      │  Interface    │      │ List[Doc]    │
     └──────────┘      └───────────────┘      └──────────────┘
                              │
                              ▼
          ┌───────────────────────────────────────┐
          │         Document Sources              │
          ├───────────────────────────────────────┤
          │  • Vector Stores (Chroma, Pinecone)  │
          │  • APIs (Wikipedia, Arxiv, PubMed)   │
          │  • Databases (SQL, Elasticsearch)    │
          │  • Custom Sources                    │
          └───────────────────────────────────────┘
```

## The BaseRetriever Interface

All retrievers in LangChain inherit from `BaseRetriever`, which follows the standard **Runnable** interface. This means you can use standard methods like `invoke()`, `ainvoke()`, `batch()`, and `abatch()`.

### Core Methods

```python
from langchain_core.retrievers import BaseRetriever
from langchain_core.documents import Document
from typing import List

class BaseRetriever:
    """Abstract base class for document retrieval systems."""
    
    def invoke(self, input: str, config=None) -> List[Document]:
        """Retrieve documents for a query (synchronous)."""
        pass
    
    async def ainvoke(self, input: str, config=None) -> List[Document]:
        """Retrieve documents for a query (asynchronous)."""
        pass
    
    def batch(self, inputs: List[str], config=None) -> List[List[Document]]:
        """Retrieve documents for multiple queries."""
        pass
    
    def _get_relevant_documents(self, query: str) -> List[Document]:
        """Core method to implement in custom retrievers."""
        raise NotImplementedError
```

### Document Structure

Each retrieved document has:
- `page_content`: The actual text content
- `metadata`: Optional dictionary with source info (filename, URL, etc.)

```python
from langchain_core.documents import Document

doc = Document(
    page_content="LangChain is a framework for building LLM applications.",
    metadata={
        "source": "langchain_docs.pdf",
        "page": 1,
        "author": "LangChain Team"
    }
)

print(doc.page_content)  # The text
print(doc.metadata)       # {'source': 'langchain_docs.pdf', ...}
```

## Using a Retriever

### Basic Usage

```python
from langchain_community.vectorstores import Chroma
from langchain_openai import OpenAIEmbeddings

# Create a vector store
embeddings = OpenAIEmbeddings()
vectorstore = Chroma.from_texts(
    texts=["LangChain is great", "Retrievers find documents"],
    embedding=embeddings
)

# Convert to retriever
retriever = vectorstore.as_retriever()

# Query the retriever
docs = retriever.invoke("What is LangChain?")

for doc in docs:
    print(f"Content: {doc.page_content}")
    print(f"Metadata: {doc.metadata}")
    print("---")
```

### Async Usage

```python
import asyncio

async def async_retrieve():
    docs = await retriever.ainvoke("What is LangChain?")
    return docs

# Run async
docs = asyncio.run(async_retrieve())
```

### Batch Processing

```python
queries = [
    "What is LangChain?",
    "How do retrievers work?",
    "What are embeddings?"
]

# Process multiple queries at once
results = retriever.batch(queries)

for query, docs in zip(queries, results):
    print(f"Query: {query}")
    print(f"Found {len(docs)} documents")
    print("---")
```

## Creating a Custom Retriever

To create a custom retriever, extend `BaseRetriever` and implement `_get_relevant_documents`:

```python
from langchain_core.retrievers import BaseRetriever
from langchain_core.documents import Document
from typing import List
import requests

class WikipediaRetriever(BaseRetriever):
    """Custom retriever that fetches from Wikipedia API."""
    
    max_results: int = 3
    
    def _get_relevant_documents(self, query: str) -> List[Document]:
        """Fetch Wikipedia articles matching the query."""
        # Wikipedia API endpoint
        url = "https://en.wikipedia.org/w/api.php"
        params = {
            "action": "query",
            "list": "search",
            "srsearch": query,
            "format": "json",
            "srlimit": self.max_results
        }
        
        response = requests.get(url, params=params)
        data = response.json()
        
        documents = []
        for result in data.get("query", {}).get("search", []):
            doc = Document(
                page_content=result["snippet"],
                metadata={
                    "title": result["title"],
                    "pageid": result["pageid"],
                    "source": "wikipedia"
                }
            )
            documents.append(doc)
        
        return documents

# Usage
wiki_retriever = WikipediaRetriever(max_results=5)
docs = wiki_retriever.invoke("machine learning")
```

## Types of Retrievers

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         RETRIEVER TAXONOMY                                  │
└─────────────────────────────────────────────────────────────────────────────┘

                           ┌──────────────┐
                           │ BaseRetriever│
                           └──────┬───────┘
                                  │
        ┌─────────────┬───────────┼───────────┬─────────────┐
        ▼             ▼           ▼           ▼             ▼
┌───────────────┐ ┌───────────┐ ┌─────────┐ ┌───────────┐ ┌──────────┐
│ VectorStore   │ │ Multi-    │ │ Self-   │ │ Contextual│ │ Ensemble │
│ Retriever     │ │ Query     │ │ Query   │ │ Compress  │ │ Retriever│
└───────────────┘ └───────────┘ └─────────┘ └───────────┘ └──────────┘
       │                │            │            │             │
       ▼                ▼            ▼            ▼             ▼
  Similarity      Query         Metadata      Reranking    Combine
  Search          Expansion     Filtering     & Filtering  Methods
```

### Retriever Categories

| Category | Examples | Use Case |
|----------|----------|----------|
| **Vector-Based** | VectorStoreRetriever | General semantic search |
| **Query Enhancement** | MultiQueryRetriever | Better recall via query expansion |
| **Metadata-Aware** | SelfQueryRetriever | Filtering by document attributes |
| **Post-Processing** | ContextualCompressionRetriever | Improving precision |
| **Hybrid** | EnsembleRetriever | Combining multiple strategies |
| **External API** | WikipediaRetriever, ArxivRetriever | Domain-specific sources |

## Retriever Comparison Table

| Retriever | Recall | Precision | Latency | Complexity | Best For |
|-----------|--------|-----------|---------|------------|----------|
| VectorStore | Medium | Medium | Low | Low | General RAG |
| MultiQuery | High | Medium | Medium | Medium | Ambiguous queries |
| SelfQuery | Medium | High | Medium | Medium | Structured metadata |
| Contextual Compression | Medium | High | High | High | Noisy documents |
| Ensemble | High | High | Medium | Medium | Production systems |

## When to Use Each Retriever

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    RETRIEVER SELECTION GUIDE                                │
└─────────────────────────────────────────────────────────────────────────────┘

    Start Here
        │
        ▼
    ┌───────────────────────────┐
    │ Do you have structured    │────Yes──▶ SelfQueryRetriever
    │ metadata to filter on?    │          (metadata filtering)
    └───────────────────────────┘
        │ No
        ▼
    ┌───────────────────────────┐
    │ Are user queries often    │────Yes──▶ MultiQueryRetriever
    │ ambiguous or complex?     │          (query expansion)
    └───────────────────────────┘
        │ No
        ▼
    ┌───────────────────────────┐
    │ Do you need to combine    │────Yes──▶ EnsembleRetriever
    │ keyword + semantic search?│          (hybrid search)
    └───────────────────────────┘
        │ No
        ▼
    ┌───────────────────────────┐
    │ Are retrieved docs noisy  │────Yes──▶ ContextualCompression
    │ with irrelevant content?  │          (reranking)
    └───────────────────────────┘
        │ No
        ▼
    VectorStoreRetriever
    (simple & effective)
```

## Best Practices

### 1. Start Simple
Begin with a basic VectorStoreRetriever before adding complexity:

```python
# Start here
retriever = vectorstore.as_retriever(search_kwargs={"k": 4})

# Only add complexity if needed
```

### 2. Configure Search Parameters

```python
# Control number of results
retriever = vectorstore.as_retriever(
    search_kwargs={
        "k": 10,                    # Number of documents to return
        "score_threshold": 0.5,    # Minimum similarity score
        "filter": {"category": "tech"}  # Metadata filter
    }
)
```

### 3. Use Callbacks for Debugging

```python
from langchain_core.callbacks import StdOutCallbackHandler

docs = retriever.invoke(
    "What is LangChain?",
    config={"callbacks": [StdOutCallbackHandler()]}
)
```

### 4. Handle Empty Results

```python
docs = retriever.invoke(query)

if not docs:
    # Fallback strategy
    docs = fallback_retriever.invoke(query)
    # Or return a helpful message
```

## Performance Optimization Tips

1. **Batch queries** when possible to reduce overhead
2. **Use async methods** (`ainvoke`, `abatch`) for concurrent retrieval
3. **Set appropriate `k` values** - don't retrieve more than needed
4. **Add metadata filters** to narrow search space
5. **Cache embeddings** for frequently used queries
6. **Use score thresholds** to filter low-quality results

## Summary

- Retrievers are the bridge between user queries and document sources
- They follow the Runnable interface with `invoke()`, `ainvoke()`, `batch()`
- Documents have `page_content` and `metadata`
- Choose your retriever based on your specific needs
- Start simple and add complexity only when necessary

## Next Steps

In the next section, we'll dive deep into **VectorStoreRetriever** and explore different search types like similarity search and MMR (Maximal Marginal Relevance).

---

## References

- [LangChain Retrievers Documentation](https://docs.langchain.com/oss/python/integrations/retrievers)
- [BaseRetriever API Reference](https://api.python.langchain.com/en/latest/core/retrievers/langchain_core.retrievers.BaseRetriever.html)
- [LangChain GitHub - retrievers.py](https://github.com/langchain-ai/langchain/blob/master/libs/core/langchain_core/retrievers.py)
