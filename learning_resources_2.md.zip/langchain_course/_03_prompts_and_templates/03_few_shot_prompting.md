# Module 03: Prompts and Templates

## 03 - Few-Shot Prompting and Example Selectors

---

## Table of Contents
1. [What is Few-Shot Prompting?](#what-is-few-shot-prompting)
2. [FewShotPromptTemplate](#fewshotprompttemplate)
3. [Example Selectors](#example-selectors)
4. [Types of Example Selectors](#types-of-example-selectors)
5. [FewShotChatMessagePromptTemplate](#fewshotchatmessageprompttemplate)
6. [Real-World Applications](#real-world-applications)
7. [Best Practices](#best-practices)

---

## What is Few-Shot Prompting?

**Few-shot prompting** is a technique where you provide the model with examples of the desired input-output behavior before asking it to perform a task. This helps the model understand the pattern and produce more accurate results.

```
┌─────────────────────────────────────────────────────────────────┐
│                    PROMPTING SPECTRUM                           │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ZERO-SHOT              FEW-SHOT              MANY-SHOT         │
│  ──────────             ─────────             ─────────         │
│  No examples            2-5 examples          Many examples     │
│                                                                  │
│  ┌────────────┐        ┌────────────┐        ┌────────────┐    │
│  │ Task only  │   →    │ Task +     │   →    │ Task +     │    │
│  │            │        │ Examples   │        │ Dataset    │    │
│  └────────────┘        └────────────┘        └────────────┘    │
│                                                                  │
│  "Translate            "Example:              Fine-tuning       │
│   'hello' to            'hello' → 'hola'     or RAG             │
│   Spanish"              'goodbye' → 'adiós'                     │
│                         Now translate                           │
│                         'thank you'"                            │
│                                                                  │
│  Less accurate    →    More accurate    →    Most accurate     │
│  Less context     →    Moderate context →    Most context      │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Why Few-Shot Works

```
┌─────────────────────────────────────────────────────────────────┐
│               HOW FEW-SHOT LEARNING WORKS                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│   1. PATTERN RECOGNITION                                        │
│      ┌─────────────────────────────────────────────────────┐   │
│      │  Example 1: Input → Output                          │   │
│      │  Example 2: Input → Output                          │   │
│      │  Example 3: Input → Output                          │   │
│      │  ─────────────────────────                          │   │
│      │  Model learns: "Ah, this is the pattern!"          │   │
│      └─────────────────────────────────────────────────────┘   │
│                                                                  │
│   2. FORMAT UNDERSTANDING                                       │
│      ┌─────────────────────────────────────────────────────┐   │
│      │  Examples show:                                      │   │
│      │  - Expected output structure                        │   │
│      │  - Level of detail                                  │   │
│      │  - Tone and style                                   │   │
│      │  - Edge case handling                               │   │
│      └─────────────────────────────────────────────────────┘   │
│                                                                  │
│   3. CONTEXT TRANSFER                                          │
│      ┌─────────────────────────────────────────────────────┐   │
│      │  New Input → Apply learned pattern → Correct Output │   │
│      └─────────────────────────────────────────────────────┘   │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## FewShotPromptTemplate

`FewShotPromptTemplate` is a LangChain class that structures few-shot prompts with examples.

### Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│              FewShotPromptTemplate STRUCTURE                    │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│   ┌─────────────────────────────────────────────────────────┐  │
│   │                    PREFIX                                │  │
│   │  "You are a helpful assistant. Here are some examples:" │  │
│   └─────────────────────────────┬───────────────────────────┘  │
│                                 │                               │
│                                 ▼                               │
│   ┌─────────────────────────────────────────────────────────┐  │
│   │                   EXAMPLES                               │  │
│   │  ┌────────────────────────────────────────────────────┐ │  │
│   │  │ Example 1: Word: happy → Antonym: sad              │ │  │
│   │  └────────────────────────────────────────────────────┘ │  │
│   │  ┌────────────────────────────────────────────────────┐ │  │
│   │  │ Example 2: Word: tall → Antonym: short             │ │  │
│   │  └────────────────────────────────────────────────────┘ │  │
│   │  ┌────────────────────────────────────────────────────┐ │  │
│   │  │ Example 3: Word: fast → Antonym: slow              │ │  │
│   │  └────────────────────────────────────────────────────┘ │  │
│   └─────────────────────────────┬───────────────────────────┘  │
│                                 │                               │
│                                 ▼                               │
│   ┌─────────────────────────────────────────────────────────┐  │
│   │                    SUFFIX                                │  │
│   │  "Now, provide the antonym for: Word: {input}"          │  │
│   └─────────────────────────────────────────────────────────┘  │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Basic Implementation

```python
from langchain_core.prompts import PromptTemplate, FewShotPromptTemplate

# Step 1: Define your examples
examples = [
    {"word": "happy", "antonym": "sad"},
    {"word": "tall", "antonym": "short"},
    {"word": "fast", "antonym": "slow"},
    {"word": "young", "antonym": "old"},
]

# Step 2: Create the example template
example_template = PromptTemplate(
    input_variables=["word", "antonym"],
    template="Word: {word}\nAntonym: {antonym}"
)

# Step 3: Create the FewShotPromptTemplate
few_shot_prompt = FewShotPromptTemplate(
    examples=examples,
    example_prompt=example_template,
    prefix="Give the antonym of every input word.\n",
    suffix="\nWord: {input}\nAntonym:",
    input_variables=["input"],
    example_separator="\n\n"
)

# Step 4: Format with new input
prompt = few_shot_prompt.format(input="bright")
print(prompt)
```

**Output:**
```
Give the antonym of every input word.

Word: happy
Antonym: sad

Word: tall
Antonym: short

Word: fast
Antonym: slow

Word: young
Antonym: old

Word: bright
Antonym:
```

### Complete Example with LLM

```python
from langchain_core.prompts import PromptTemplate, FewShotPromptTemplate
from langchain_openai import ChatOpenAI

# Examples for sentiment classification
examples = [
    {
        "text": "I love this product! It exceeded all my expectations.",
        "sentiment": "POSITIVE"
    },
    {
        "text": "Terrible experience. Would not recommend.",
        "sentiment": "NEGATIVE"
    },
    {
        "text": "It's okay, nothing special but does the job.",
        "sentiment": "NEUTRAL"
    },
    {
        "text": "Absolutely fantastic! Best purchase ever!",
        "sentiment": "POSITIVE"
    },
]

example_template = PromptTemplate(
    input_variables=["text", "sentiment"],
    template="Text: {text}\nSentiment: {sentiment}"
)

few_shot_prompt = FewShotPromptTemplate(
    examples=examples,
    example_prompt=example_template,
    prefix="Classify the sentiment of the following text as POSITIVE, NEGATIVE, or NEUTRAL.\n\nExamples:",
    suffix="\nText: {input_text}\nSentiment:",
    input_variables=["input_text"],
    example_separator="\n\n"
)

# Create chain
llm = ChatOpenAI(model="gpt-4", temperature=0)
chain = few_shot_prompt | llm

# Classify new text
response = chain.invoke({"input_text": "The product arrived damaged but customer service was helpful."})
print(response.content)  # Likely: NEUTRAL or MIXED
```

---

## Example Selectors

**Example Selectors** dynamically choose the most relevant examples for a given input, rather than using all examples every time.

```
┌─────────────────────────────────────────────────────────────────┐
│                 WHY USE EXAMPLE SELECTORS?                      │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  PROBLEM: Token Limits                                          │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  100 examples × 50 tokens = 5000 tokens just for examples│   │
│  │  + System prompt + User input = TOKEN LIMIT EXCEEDED!   │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  PROBLEM: Irrelevant Examples                                   │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  Query: "How to cook pasta?"                            │   │
│  │  Examples about: car repair, legal advice, math...      │   │
│  │  Result: Confused model, poor responses                 │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  SOLUTION: Example Selectors                                    │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  ┌─────────────┐    ┌──────────────┐    ┌────────────┐ │   │
│  │  │ All Examples│ →  │ Selector     │ →  │ Best 3-5   │ │   │
│  │  │ (hundreds)  │    │ (semantic/   │    │ Examples   │ │   │
│  │  │             │    │  length/etc) │    │            │ │   │
│  │  └─────────────┘    └──────────────┘    └────────────┘ │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## Types of Example Selectors

### 1. SemanticSimilarityExampleSelector

Selects examples most semantically similar to the input using embeddings and vector similarity.

```
┌─────────────────────────────────────────────────────────────────┐
│            SemanticSimilarityExampleSelector                    │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│   INPUT: "How do I make pasta?"                                 │
│                                                                  │
│   ┌───────────────────────────────────────────────────────┐    │
│   │                 VECTOR STORE                           │    │
│   │  ┌─────────────────────────────────────────────────┐  │    │
│   │  │ "How to bake bread" ──────────── similarity: 0.7│  │    │
│   │  │ "Best pizza recipe" ──────────── similarity: 0.85│ │    │
│   │  │ "Car maintenance tips" ───────── similarity: 0.2│  │    │
│   │  │ "Cooking spaghetti guide" ────── similarity: 0.95│ │    │
│   │  │ "Python programming" ─────────── similarity: 0.1│  │    │
│   │  └─────────────────────────────────────────────────┘  │    │
│   └───────────────────────────────────────────────────────┘    │
│                           │                                     │
│                           ▼                                     │
│   SELECTED (top k=2):                                          │
│   1. "Cooking spaghetti guide" (0.95)                          │
│   2. "Best pizza recipe" (0.85)                                │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

```python
from langchain_core.prompts import PromptTemplate, FewShotPromptTemplate
from langchain_core.example_selectors import SemanticSimilarityExampleSelector
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS

# Define examples
examples = [
    {"question": "How do I make pasta?", "answer": "Boil water, add pasta, cook for 8-10 minutes..."},
    {"question": "How do I bake bread?", "answer": "Mix flour, yeast, water, let rise, then bake..."},
    {"question": "How do I fix a flat tire?", "answer": "Jack up the car, remove lug nuts, replace tire..."},
    {"question": "How do I write a Python function?", "answer": "Use 'def' keyword, name, parameters..."},
    {"question": "How do I make pizza?", "answer": "Prepare dough, add sauce and toppings, bake..."},
]

# Create embeddings
embeddings = OpenAIEmbeddings()

# Create the selector
example_selector = SemanticSimilarityExampleSelector.from_examples(
    examples=examples,
    embeddings=embeddings,
    vectorstore_cls=FAISS,
    k=2  # Select top 2 most similar examples
)

# Create the example prompt
example_prompt = PromptTemplate(
    input_variables=["question", "answer"],
    template="Question: {question}\nAnswer: {answer}"
)

# Create FewShotPromptTemplate with selector
few_shot_prompt = FewShotPromptTemplate(
    example_selector=example_selector,  # Use selector instead of examples
    example_prompt=example_prompt,
    prefix="Answer the following question based on these examples:\n",
    suffix="\nQuestion: {input}\nAnswer:",
    input_variables=["input"]
)

# Format - will select relevant examples automatically
prompt = few_shot_prompt.format(input="How do I cook rice?")
# Will select cooking-related examples, not programming or car repair!
```

### 2. LengthBasedExampleSelector

Selects examples based on length constraints to fit within token limits.

```
┌─────────────────────────────────────────────────────────────────┐
│              LengthBasedExampleSelector                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│   MAX LENGTH: 100 words                                         │
│                                                                  │
│   EXAMPLES:                                                     │
│   ┌────────────────────────────────────────────────────────┐   │
│   │ Example 1: 20 words  ✓  Running total: 20              │   │
│   │ Example 2: 25 words  ✓  Running total: 45              │   │
│   │ Example 3: 30 words  ✓  Running total: 75              │   │
│   │ Example 4: 35 words  ✗  Would exceed 100!              │   │
│   │ Example 5: 15 words  ✓  Running total: 90              │   │
│   └────────────────────────────────────────────────────────┘   │
│                                                                  │
│   SELECTED: Examples 1, 2, 3, 5 (90 words total)               │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

```python
from langchain_core.prompts import PromptTemplate, FewShotPromptTemplate
from langchain_core.example_selectors import LengthBasedExampleSelector

examples = [
    {"input": "happy", "output": "sad"},
    {"input": "tall", "output": "short"},
    {"input": "energetic", "output": "lethargic"},
    {"input": "sunny", "output": "gloomy"},
    {"input": "fast", "output": "slow"},
]

example_prompt = PromptTemplate(
    input_variables=["input", "output"],
    template="Input: {input}\nOutput: {output}"
)

# Create length-based selector
example_selector = LengthBasedExampleSelector(
    examples=examples,
    example_prompt=example_prompt,
    max_length=50,  # Maximum length in words
    get_text_length=lambda x: len(x.split())  # Custom length function
)

few_shot_prompt = FewShotPromptTemplate(
    example_selector=example_selector,
    example_prompt=example_prompt,
    prefix="Give the antonym of every input.\n",
    suffix="\nInput: {adjective}\nOutput:",
    input_variables=["adjective"]
)

# Short input = more examples included
short_prompt = few_shot_prompt.format(adjective="big")

# Long input = fewer examples to stay under limit
long_prompt = few_shot_prompt.format(
    adjective="extraordinarily magnificent"
)
```

### 3. MaxMarginalRelevanceExampleSelector (MMR)

Balances relevance with diversity to avoid redundant examples.

```
┌─────────────────────────────────────────────────────────────────┐
│          MaxMarginalRelevanceExampleSelector                    │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│   GOAL: Select RELEVANT but DIVERSE examples                   │
│                                                                  │
│   INPUT: "Italian food recipes"                                 │
│                                                                  │
│   WITHOUT MMR (just similarity):                                │
│   ┌─────────────────────────────────────────────────────────┐  │
│   │ 1. "How to make spaghetti" (0.95)                       │  │
│   │ 2. "How to cook pasta"     (0.93)  ← Redundant!        │  │
│   │ 3. "Spaghetti carbonara"   (0.91)  ← Redundant!        │  │
│   └─────────────────────────────────────────────────────────┘  │
│                                                                  │
│   WITH MMR (similarity + diversity):                           │
│   ┌─────────────────────────────────────────────────────────┐  │
│   │ 1. "How to make spaghetti" (relevant + novel)          │  │
│   │ 2. "Pizza dough recipe"    (relevant + diverse)        │  │
│   │ 3. "Italian dessert tips"  (relevant + diverse)        │  │
│   └─────────────────────────────────────────────────────────┘  │
│                                                                  │
│   RESULT: Better coverage of the topic!                        │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

```python
from langchain_core.example_selectors import MaxMarginalRelevanceExampleSelector
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS

examples = [
    {"query": "How to make pasta?", "answer": "Boil water..."},
    {"query": "How to cook spaghetti?", "answer": "Similar to pasta..."},
    {"query": "Best pizza recipe", "answer": "Make dough..."},
    {"query": "Italian desserts", "answer": "Tiramisu is popular..."},
    {"query": "Pasta carbonara", "answer": "Use eggs and bacon..."},
]

# MMR selector balances relevance and diversity
mmr_selector = MaxMarginalRelevanceExampleSelector.from_examples(
    examples=examples,
    embeddings=OpenAIEmbeddings(),
    vectorstore_cls=FAISS,
    k=3,  # Select 3 examples
    fetch_k=10  # Consider top 10 before applying MMR
)

# Select examples - will be relevant AND diverse
selected = mmr_selector.select_examples({"query": "Italian cooking tips"})
```

### 4. NGramOverlapExampleSelector

Selects based on n-gram overlap between input and examples.

```python
from langchain_community.example_selectors import NGramOverlapExampleSelector
from langchain_core.prompts import PromptTemplate

examples = [
    {"input": "How do I cook rice?", "output": "Rinse rice, add water, boil..."},
    {"input": "What is machine learning?", "output": "ML is a subset of AI..."},
    {"input": "How to make fried rice?", "output": "Cook rice, add vegetables..."},
]

example_prompt = PromptTemplate(
    input_variables=["input", "output"],
    template="Q: {input}\nA: {output}"
)

# N-gram based selection
ngram_selector = NGramOverlapExampleSelector(
    examples=examples,
    example_prompt=example_prompt,
    threshold=0.0  # Minimum overlap threshold
)

# "rice" appears in input, so rice-related examples will be selected
selected = ngram_selector.select_examples({"input": "Best way to prepare rice"})
```

### Selector Comparison

| Selector | Best For | Requires | Speed |
|----------|----------|----------|-------|
| Semantic Similarity | Finding conceptually similar examples | Embeddings + Vector Store | Medium |
| Length Based | Token limit management | Nothing extra | Fast |
| MMR | Diverse, non-redundant examples | Embeddings + Vector Store | Medium |
| N-Gram Overlap | Keyword matching | Nothing extra | Fast |

---

## FewShotChatMessagePromptTemplate

For chat models, use `FewShotChatMessagePromptTemplate` to create few-shot examples in message format.

```python
from langchain_core.prompts import (
    ChatPromptTemplate,
    FewShotChatMessagePromptTemplate,
)

# Examples as conversation turns
examples = [
    {"input": "2+2", "output": "4"},
    {"input": "5*3", "output": "15"},
    {"input": "10/2", "output": "5"},
]

# Template for each example (human asks, AI answers)
example_prompt = ChatPromptTemplate.from_messages([
    ("human", "{input}"),
    ("ai", "{output}")
])

# Create few-shot chat template
few_shot_prompt = FewShotChatMessagePromptTemplate(
    examples=examples,
    example_prompt=example_prompt,
)

# Combine with system message and final human input
final_prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a calculator. Compute the result of math expressions."),
    few_shot_prompt,
    ("human", "{input}")
])

# Format
messages = final_prompt.format_messages(input="7+8")
```

**Resulting messages:**
```python
[
    SystemMessage(content="You are a calculator..."),
    HumanMessage(content="2+2"),
    AIMessage(content="4"),
    HumanMessage(content="5*3"),
    AIMessage(content="15"),
    HumanMessage(content="10/2"),
    AIMessage(content="5"),
    HumanMessage(content="7+8")  # New input
]
```

### With Example Selector

```python
from langchain_core.prompts import ChatPromptTemplate, FewShotChatMessagePromptTemplate
from langchain_core.example_selectors import SemanticSimilarityExampleSelector
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import Chroma

# Diverse examples
examples = [
    {"input": "What's the capital of France?", "output": "Paris"},
    {"input": "Solve: 5 + 7", "output": "12"},
    {"input": "Translate 'hello' to Spanish", "output": "Hola"},
    {"input": "What's the capital of Japan?", "output": "Tokyo"},
    {"input": "Solve: 10 * 3", "output": "30"},
]

# Semantic selector
selector = SemanticSimilarityExampleSelector.from_examples(
    examples=examples,
    embeddings=OpenAIEmbeddings(),
    vectorstore_cls=Chroma,
    k=2
)

example_prompt = ChatPromptTemplate.from_messages([
    ("human", "{input}"),
    ("ai", "{output}")
])

few_shot_prompt = FewShotChatMessagePromptTemplate(
    example_selector=selector,
    example_prompt=example_prompt,
    input_variables=["input"]
)

final_prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a helpful assistant."),
    few_shot_prompt,
    ("human", "{input}")
])

# Geography question → selects geography examples
geo_messages = final_prompt.format_messages(input="What's the capital of Germany?")

# Math question → selects math examples
math_messages = final_prompt.format_messages(input="Calculate 8 * 4")
```

---

## Real-World Applications

### Application 1: Structured Data Extraction

```python
from langchain_core.prompts import PromptTemplate, FewShotPromptTemplate
from langchain_openai import ChatOpenAI
import json

# Examples of text → structured data extraction
examples = [
    {
        "text": "John Smith is a 32-year-old software engineer from New York.",
        "json": '{"name": "John Smith", "age": 32, "profession": "software engineer", "location": "New York"}'
    },
    {
        "text": "Sarah Johnson, 28, works as a data scientist in San Francisco.",
        "json": '{"name": "Sarah Johnson", "age": 28, "profession": "data scientist", "location": "San Francisco"}'
    },
    {
        "text": "Mike Brown is a 45 year old doctor based in Chicago.",
        "json": '{"name": "Mike Brown", "age": 45, "profession": "doctor", "location": "Chicago"}'
    }
]

example_prompt = PromptTemplate(
    input_variables=["text", "json"],
    template="Text: {text}\nJSON: {json}"
)

extraction_prompt = FewShotPromptTemplate(
    examples=examples,
    example_prompt=example_prompt,
    prefix="Extract structured information from text into JSON format.\n",
    suffix="\nText: {input_text}\nJSON:",
    input_variables=["input_text"]
)

llm = ChatOpenAI(model="gpt-4", temperature=0)
chain = extraction_prompt | llm

result = chain.invoke({
    "input_text": "Emily Davis is a 35-year-old marketing manager living in Boston."
})
print(result.content)
# Output: {"name": "Emily Davis", "age": 35, "profession": "marketing manager", "location": "Boston"}
```

### Application 2: Code Generation with Style

```python
from langchain_core.prompts import PromptTemplate, FewShotPromptTemplate
from langchain_core.example_selectors import SemanticSimilarityExampleSelector
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS

# Code examples following specific style
examples = [
    {
        "task": "Create a function to calculate factorial",
        "code": '''def calculate_factorial(n: int) -> int:
    """Calculate the factorial of a non-negative integer.
    
    Args:
        n: Non-negative integer
        
    Returns:
        Factorial of n
        
    Raises:
        ValueError: If n is negative
    """
    if n < 0:
        raise ValueError("n must be non-negative")
    if n <= 1:
        return 1
    return n * calculate_factorial(n - 1)'''
    },
    {
        "task": "Create a function to check if a number is prime",
        "code": '''def is_prime(n: int) -> bool:
    """Check if a number is prime.
    
    Args:
        n: Integer to check
        
    Returns:
        True if n is prime, False otherwise
    """
    if n < 2:
        return False
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False
    return True'''
    },
]

selector = SemanticSimilarityExampleSelector.from_examples(
    examples=examples,
    embeddings=OpenAIEmbeddings(),
    vectorstore_cls=FAISS,
    k=1
)

example_prompt = PromptTemplate(
    input_variables=["task", "code"],
    template="Task: {task}\n```python\n{code}\n```"
)

code_prompt = FewShotPromptTemplate(
    example_selector=selector,
    example_prompt=example_prompt,
    prefix="Generate Python code following this style (type hints, docstrings, error handling):\n",
    suffix="\nTask: {task}\n```python",
    input_variables=["task"]
)
```

### Application 3: Customer Intent Classification

```python
from langchain_core.prompts import ChatPromptTemplate, FewShotChatMessagePromptTemplate

# Intent classification examples
examples = [
    {"message": "I want to cancel my subscription", "intent": "CANCELLATION"},
    {"message": "How much does the premium plan cost?", "intent": "PRICING_INQUIRY"},
    {"message": "My payment didn't go through", "intent": "BILLING_ISSUE"},
    {"message": "Can I get a refund?", "intent": "REFUND_REQUEST"},
    {"message": "How do I change my password?", "intent": "ACCOUNT_HELP"},
    {"message": "Your product is amazing!", "intent": "POSITIVE_FEEDBACK"},
    {"message": "I want to upgrade my plan", "intent": "UPGRADE_REQUEST"},
]

example_prompt = ChatPromptTemplate.from_messages([
    ("human", "{message}"),
    ("ai", "Intent: {intent}")
])

few_shot = FewShotChatMessagePromptTemplate(
    examples=examples,
    example_prompt=example_prompt
)

intent_prompt = ChatPromptTemplate.from_messages([
    ("system", """You are an intent classifier for customer support.
Classify messages into one of these intents:
- CANCELLATION
- PRICING_INQUIRY
- BILLING_ISSUE
- REFUND_REQUEST
- ACCOUNT_HELP
- POSITIVE_FEEDBACK
- UPGRADE_REQUEST
- OTHER

Respond with only the intent label."""),
    few_shot,
    ("human", "{message}")
])
```

---

## Best Practices

### 1. Quality Over Quantity

```
┌─────────────────────────────────────────────────────────────────┐
│              EXAMPLE SELECTION GUIDELINES                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  QUALITY EXAMPLES:                                              │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  ✓ Representative of the task                           │   │
│  │  ✓ Cover edge cases                                     │   │
│  │  ✓ Demonstrate desired output format                    │   │
│  │  ✓ Show consistent style/tone                           │   │
│  │  ✓ Include diverse scenarios                            │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  OPTIMAL NUMBER:                                                │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  Simple tasks:  2-3 examples                            │   │
│  │  Medium tasks:  4-5 examples                            │   │
│  │  Complex tasks: 5-7 examples (with selector)            │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  TOO MANY EXAMPLES → Token waste, confusion                    │
│  TOO FEW EXAMPLES  → Pattern not clear                         │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### 2. Example Diversity

```python
# BAD: All similar examples
bad_examples = [
    {"input": "happy", "output": "sad"},
    {"input": "joyful", "output": "unhappy"},  # Too similar to happy
    {"input": "cheerful", "output": "gloomy"},  # Too similar
]

# GOOD: Diverse examples
good_examples = [
    {"input": "happy", "output": "sad"},       # Emotion
    {"input": "tall", "output": "short"},      # Physical
    {"input": "fast", "output": "slow"},       # Speed
    {"input": "ancient", "output": "modern"},  # Time
    {"input": "wealthy", "output": "poor"},    # Status
]
```

### 3. Consistent Formatting

```python
# GOOD: Consistent format across all examples
examples = [
    {"question": "What is 2+2?", "reasoning": "2+2 equals 4", "answer": "4"},
    {"question": "What is 5*3?", "reasoning": "5*3 equals 15", "answer": "15"},
    {"question": "What is 10/2?", "reasoning": "10/2 equals 5", "answer": "5"},
]

# All examples follow the same structure
example_prompt = PromptTemplate(
    input_variables=["question", "reasoning", "answer"],
    template="""Question: {question}
Reasoning: {reasoning}
Answer: {answer}"""
)
```

### 4. Use Selectors for Large Example Sets

```python
# When you have many examples, ALWAYS use a selector
if len(examples) > 10:
    # Use semantic similarity for relevance
    selector = SemanticSimilarityExampleSelector.from_examples(
        examples=examples,
        embeddings=OpenAIEmbeddings(),
        vectorstore_cls=FAISS,
        k=5
    )
    
    few_shot = FewShotPromptTemplate(
        example_selector=selector,  # Dynamic selection
        example_prompt=example_prompt,
        ...
    )
else:
    # For small sets, static examples are fine
    few_shot = FewShotPromptTemplate(
        examples=examples,  # All examples
        example_prompt=example_prompt,
        ...
    )
```

---

## Common Pitfalls

### 1. Inconsistent Example Format
```python
# BAD: Inconsistent formats
examples = [
    {"input": "hello", "output": "HELLO"},
    {"text": "world", "result": "WORLD"},  # Different keys!
]

# GOOD: Consistent format
examples = [
    {"input": "hello", "output": "HELLO"},
    {"input": "world", "output": "WORLD"},
]
```

### 2. Forgetting Example Separator
```python
# BAD: Examples run together
# Example1: hello → HOLLOExample2: world → WORLD

# GOOD: Clear separation
few_shot = FewShotPromptTemplate(
    examples=examples,
    example_prompt=example_prompt,
    example_separator="\n\n---\n\n",  # Clear visual separator
    ...
)
```

### 3. Not Handling Edge Cases
```python
# Include edge case examples
examples = [
    # Normal cases
    {"input": "hello", "output": "HELLO"},
    # Edge cases
    {"input": "", "output": ""},  # Empty input
    {"input": "Hello World", "output": "HELLO WORLD"},  # Multiple words
    {"input": "hello123", "output": "HELLO123"},  # Mixed alphanumeric
]
```

---

## Summary

```
┌─────────────────────────────────────────────────────────────────┐
│                    KEY TAKEAWAYS                                │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  FEW-SHOT PROMPTING:                                           │
│  - Provide examples to teach the model patterns                │
│  - More accurate than zero-shot for complex tasks              │
│  - Balance between too few and too many examples               │
│                                                                  │
│  EXAMPLE SELECTORS:                                             │
│  - SemanticSimilarity: Best matching examples                  │
│  - LengthBased: Fit within token limits                        │
│  - MMR: Relevance + diversity                                  │
│  - NGramOverlap: Keyword-based matching                        │
│                                                                  │
│  BEST PRACTICES:                                                │
│  - Use 3-5 high-quality, diverse examples                      │
│  - Maintain consistent formatting                              │
│  - Use selectors for large example sets                        │
│  - Include edge cases in examples                              │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## Next Steps

In the next lesson, we'll explore **Prompt Composition** - combining multiple prompts and using partial prompts for modular prompt design.

---

## References

- [LangChain Few Shot Examples Documentation](https://langchain-doc.readthedocs.io/en/latest/modules/prompts/examples/few_shot_examples.html)
- [FewShotPromptTemplate Reference](https://reference.langchain.com/javascript/langchain-core/prompts/FewShotPromptTemplate)
- [LangChain Example Selectors](https://pub.aimind.so/langchain-in-chains-6-example-selectors-310f47b4cdf3)
- [How to Use Few Shot Examples in LangChain](https://js.langchain.com/docs/how_to/few_shot_examples/)
