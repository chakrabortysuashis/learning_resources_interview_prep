# Module 03: Prompts and Templates

## 02 - PromptTemplate and ChatPromptTemplate

---

## Table of Contents
1. [PromptTemplate Deep Dive](#prompttemplate-deep-dive)
2. [ChatPromptTemplate Deep Dive](#chatprompttemplate-deep-dive)
3. [Message Types in LangChain](#message-types-in-langchain)
4. [Template Creation Methods](#template-creation-methods)
5. [Variable Handling](#variable-handling)
6. [Real-World Examples](#real-world-examples)
7. [Best Practices](#best-practices)

---

## PromptTemplate Deep Dive

`PromptTemplate` is the foundational class for creating string-based prompts. It uses simple variable substitution with f-string syntax.

### Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                  PromptTemplate FLOW                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│   ┌────────────────────────────────────────────┐               │
│   │           TEMPLATE DEFINITION               │               │
│   │  "Explain {topic} to a {audience} audience" │               │
│   └────────────────────┬───────────────────────┘               │
│                        │                                        │
│                        ▼                                        │
│   ┌────────────────────────────────────────────┐               │
│   │           INPUT VARIABLES                   │               │
│   │  topic = "machine learning"                │               │
│   │  audience = "beginner"                     │               │
│   └────────────────────┬───────────────────────┘               │
│                        │                                        │
│                        ▼                                        │
│   ┌────────────────────────────────────────────┐               │
│   │           FORMATTED STRING                  │               │
│   │  "Explain machine learning to a beginner   │               │
│   │   audience"                                │               │
│   └────────────────────┬───────────────────────┘               │
│                        │                                        │
│                        ▼                                        │
│   ┌────────────────────────────────────────────┐               │
│   │           LLM (Completion Model)            │               │
│   │  Returns: "Machine learning is like..."    │               │
│   └────────────────────────────────────────────┘               │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Basic Usage

```python
from langchain_core.prompts import PromptTemplate

# Method 1: Using from_template() - Infers variables automatically
template = PromptTemplate.from_template(
    "Explain {topic} in simple terms for a {audience}."
)

# Method 2: Explicit declaration
template = PromptTemplate(
    input_variables=["topic", "audience"],
    template="Explain {topic} in simple terms for a {audience}."
)

# Format the template
prompt = template.format(topic="quantum computing", audience="high school student")
print(prompt)
# Output: "Explain quantum computing in simple terms for a high school student."
```

### Template with Invoke (LCEL)

```python
from langchain_core.prompts import PromptTemplate
from langchain_openai import ChatOpenAI

# Create template
template = PromptTemplate.from_template(
    "What are 3 interesting facts about {topic}?"
)

# Create model
llm = ChatOpenAI(model="gpt-4")

# Chain them using LCEL (LangChain Expression Language)
chain = template | llm

# Invoke the chain
response = chain.invoke({"topic": "octopuses"})
print(response.content)
```

---

## ChatPromptTemplate Deep Dive

`ChatPromptTemplate` is designed for chat-based models that expect structured message formats with roles (system, human, assistant).

### Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│               ChatPromptTemplate FLOW                           │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│   ┌─────────────────────────────────────────────────────────┐  │
│   │                MESSAGE TEMPLATES                         │  │
│   │                                                          │  │
│   │  ┌──────────────────────────────────────────────────┐   │  │
│   │  │ SYSTEM: "You are a {role} expert"                │   │  │
│   │  └──────────────────────────────────────────────────┘   │  │
│   │                         │                               │  │
│   │  ┌──────────────────────────────────────────────────┐   │  │
│   │  │ HUMAN: "Explain {topic} to me"                   │   │  │
│   │  └──────────────────────────────────────────────────┘   │  │
│   │                                                          │  │
│   └─────────────────────────────┬───────────────────────────┘  │
│                                 │                               │
│                                 ▼                               │
│   ┌─────────────────────────────────────────────────────────┐  │
│   │              INPUT VARIABLES                             │  │
│   │  role = "Python programming"                            │  │
│   │  topic = "decorators"                                   │  │
│   └─────────────────────────────┬───────────────────────────┘  │
│                                 │                               │
│                                 ▼                               │
│   ┌─────────────────────────────────────────────────────────┐  │
│   │              FORMATTED MESSAGES                          │  │
│   │  [                                                       │  │
│   │    SystemMessage("You are a Python programming expert") │  │
│   │    HumanMessage("Explain decorators to me")             │  │
│   │  ]                                                       │  │
│   └─────────────────────────────┬───────────────────────────┘  │
│                                 │                               │
│                                 ▼                               │
│   ┌─────────────────────────────────────────────────────────┐  │
│   │              CHAT MODEL (GPT-4, Claude)                  │  │
│   │  Returns: AIMessage("Decorators are functions that...")  │  │
│   └─────────────────────────────────────────────────────────┘  │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Basic Usage

```python
from langchain_core.prompts import ChatPromptTemplate

# Method 1: Using from_messages() with tuples
chat_template = ChatPromptTemplate.from_messages([
    ("system", "You are a helpful {role} assistant."),
    ("human", "{user_input}")
])

# Method 2: Using from_messages() with explicit types
from langchain_core.prompts import SystemMessagePromptTemplate, HumanMessagePromptTemplate

chat_template = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template("You are a helpful {role} assistant."),
    HumanMessagePromptTemplate.from_template("{user_input}")
])

# Format to messages
messages = chat_template.format_messages(
    role="coding",
    user_input="How do I reverse a list in Python?"
)
```

### Complete Example with Chat Model

```python
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI

# Define the chat template
chat_template = ChatPromptTemplate.from_messages([
    ("system", """You are an expert {domain} tutor. 
    You explain concepts clearly with examples.
    Adjust your explanation for a {level} level student."""),
    ("human", "Please explain: {question}")
])

# Create the model
llm = ChatOpenAI(model="gpt-4", temperature=0.7)

# Create the chain
chain = chat_template | llm

# Invoke
response = chain.invoke({
    "domain": "mathematics",
    "level": "beginner",
    "question": "What is the Pythagorean theorem?"
})

print(response.content)
```

---

## Message Types in LangChain

LangChain supports several message types that map to chat model roles:

```
┌─────────────────────────────────────────────────────────────────┐
│                    MESSAGE TYPES                                │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  SystemMessage / ("system", "...")                       │   │
│  │  ─────────────────────────────────────                  │   │
│  │  Sets the AI's behavior, personality, and constraints    │   │
│  │  Example: "You are a helpful coding assistant"          │   │
│  │  ALWAYS FIRST in the message list                       │   │
│  └─────────────────────────────────────────────────────────┘   │
│                           │                                     │
│                           ▼                                     │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  HumanMessage / ("human", "...") / ("user", "...")      │   │
│  │  ─────────────────────────────────────────────          │   │
│  │  User's input or question                               │   │
│  │  Example: "How do I sort a list?"                       │   │
│  └─────────────────────────────────────────────────────────┘   │
│                           │                                     │
│                           ▼                                     │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  AIMessage / ("ai", "...") / ("assistant", "...")       │   │
│  │  ─────────────────────────────────────────────          │   │
│  │  Previous AI responses (for conversation history)       │   │
│  │  Example: "Here's how to sort: list.sort()"             │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  Message Order: [system, human, ai, human, ai, ...]            │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Message Types Reference

| Type | Tuple Shorthand | Purpose |
|------|-----------------|---------|
| `SystemMessage` | `("system", "...")` | Define AI behavior |
| `HumanMessage` | `("human", "...")` or `("user", "...")` | User input |
| `AIMessage` | `("ai", "...")` or `("assistant", "...")` | AI responses |

### Example: Multi-turn Conversation Template

```python
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder

# Template with conversation history
chat_template = ChatPromptTemplate.from_messages([
    ("system", "You are a helpful assistant specializing in {domain}."),
    MessagesPlaceholder(variable_name="chat_history"),  # Dynamic history
    ("human", "{user_input}")
])

# Example usage with history
from langchain_core.messages import HumanMessage, AIMessage

history = [
    HumanMessage(content="What is Python?"),
    AIMessage(content="Python is a programming language known for its simplicity."),
]

messages = chat_template.format_messages(
    domain="programming",
    chat_history=history,
    user_input="What are its main features?"
)
```

---

## Template Creation Methods

### Method Comparison

```
┌─────────────────────────────────────────────────────────────────┐
│              TEMPLATE CREATION METHODS                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  1. from_template() - Quick and simple                         │
│     ┌─────────────────────────────────────────────────────┐    │
│     │ PromptTemplate.from_template("Hello {name}!")       │    │
│     │ - Auto-detects variables                            │    │
│     │ - Best for simple cases                             │    │
│     └─────────────────────────────────────────────────────┘    │
│                                                                  │
│  2. Constructor - Full control                                  │
│     ┌─────────────────────────────────────────────────────┐    │
│     │ PromptTemplate(                                     │    │
│     │     input_variables=["name"],                       │    │
│     │     template="Hello {name}!",                       │    │
│     │     validate_template=True                          │    │
│     │ )                                                   │    │
│     │ - Explicit variable declaration                     │    │
│     │ - Better for production code                        │    │
│     └─────────────────────────────────────────────────────┘    │
│                                                                  │
│  3. from_messages() - For chat templates                       │
│     ┌─────────────────────────────────────────────────────┐    │
│     │ ChatPromptTemplate.from_messages([                  │    │
│     │     ("system", "You are {role}"),                   │    │
│     │     ("human", "{input}")                            │    │
│     │ ])                                                  │    │
│     │ - Creates structured conversations                  │    │
│     │ - Required for chat models                          │    │
│     └─────────────────────────────────────────────────────┘    │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Code Examples

```python
from langchain_core.prompts import PromptTemplate, ChatPromptTemplate

# ----- PromptTemplate Methods -----

# Method 1: from_template (infers variables)
simple_template = PromptTemplate.from_template(
    "Write a {length} story about {topic}."
)

# Method 2: Constructor (explicit)
explicit_template = PromptTemplate(
    input_variables=["length", "topic"],
    template="Write a {length} story about {topic}.",
    validate_template=True,  # Validates variables match
    template_format="f-string"  # Default, safest option
)

# Method 3: from_file (load from external file)
# file: templates/story.txt contains "Write a {length} story about {topic}."
file_template = PromptTemplate.from_file("templates/story.txt")


# ----- ChatPromptTemplate Methods -----

# Method 1: from_messages with tuples
chat_simple = ChatPromptTemplate.from_messages([
    ("system", "You are helpful."),
    ("human", "{question}")
])

# Method 2: from_template (single message shortcut)
chat_single = ChatPromptTemplate.from_template("{question}")
# Creates: [HumanMessage(content=question)]

# Method 3: Programmatic construction
from langchain_core.prompts import (
    SystemMessagePromptTemplate,
    HumanMessagePromptTemplate
)

system_template = SystemMessagePromptTemplate.from_template(
    "You are a {profession}."
)
human_template = HumanMessagePromptTemplate.from_template(
    "{question}"
)

chat_programmatic = ChatPromptTemplate.from_messages([
    system_template,
    human_template
])
```

---

## Variable Handling

### Automatic vs Explicit Variables

```python
from langchain_core.prompts import PromptTemplate

# Automatic detection
auto_template = PromptTemplate.from_template(
    "Hello {name}, welcome to {place}!"
)
print(auto_template.input_variables)  # ['name', 'place']

# Explicit declaration (recommended for production)
explicit_template = PromptTemplate(
    input_variables=["name", "place"],
    template="Hello {name}, welcome to {place}!"
)
```

### Partial Variables

Partial variables let you pre-fill some values while leaving others for later:

```
┌─────────────────────────────────────────────────────────────────┐
│                  PARTIAL VARIABLES FLOW                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│   ORIGINAL TEMPLATE                                             │
│   ┌─────────────────────────────────────────────────────────┐  │
│   │  "Today is {date}. {name} wants to learn about {topic}" │  │
│   │  Variables: [date, name, topic]                         │  │
│   └─────────────────────────────┬───────────────────────────┘  │
│                                 │                               │
│                                 ▼                               │
│   PARTIAL (pre-fill date)                                       │
│   ┌─────────────────────────────────────────────────────────┐  │
│   │  partial_template = template.partial(date="2026-09-13") │  │
│   │  Remaining Variables: [name, topic]                     │  │
│   └─────────────────────────────┬───────────────────────────┘  │
│                                 │                               │
│                                 ▼                               │
│   FORMAT (fill remaining)                                       │
│   ┌─────────────────────────────────────────────────────────┐  │
│   │  result = partial_template.format(name="Alice",         │  │
│   │                                   topic="Python")       │  │
│   │  Output: "Today is 2026-09-13. Alice wants to learn    │  │
│   │           about Python"                                │  │
│   └─────────────────────────────────────────────────────────┘  │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

```python
from langchain_core.prompts import PromptTemplate
from datetime import datetime

# Template with partial variable
template = PromptTemplate(
    input_variables=["name", "topic"],
    partial_variables={"date": datetime.now().strftime("%Y-%m-%d")},
    template="Date: {date}\nHello {name}, let's discuss {topic}."
)

# Only need to provide name and topic
result = template.format(name="Alice", topic="AI")
print(result)
# Output: Date: 2026-09-13
#         Hello Alice, let's discuss AI.

# Alternative: Use partial() method
base_template = PromptTemplate.from_template(
    "Date: {date}\nHello {name}, let's discuss {topic}."
)

# Create a partial version
partial_template = base_template.partial(date="2026-09-13")
print(partial_template.input_variables)  # ['name', 'topic']
```

### Dynamic Partial Variables (Functions)

```python
from langchain_core.prompts import PromptTemplate
from datetime import datetime

# Function that returns current time
def get_current_time():
    return datetime.now().strftime("%H:%M:%S")

# Template with dynamic partial
template = PromptTemplate(
    input_variables=["user_query"],
    partial_variables={"current_time": get_current_time},
    template="[{current_time}] User asked: {user_query}"
)

# Each format call gets fresh time
print(template.format(user_query="What's the weather?"))
# Output: [14:32:15] User asked: What's the weather?
```

---

## Real-World Examples

### Example 1: Customer Support Bot

```python
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_openai import ChatOpenAI

# Professional customer support template
support_template = ChatPromptTemplate.from_messages([
    ("system", """You are a customer support representative for {company_name}.

Your responsibilities:
- Be polite, professional, and empathetic
- Provide accurate information about our products/services
- Escalate to human support when necessary
- Never make promises you can't keep

Company policies:
{company_policies}

Current date: {current_date}"""),
    MessagesPlaceholder(variable_name="chat_history"),
    ("human", "{customer_message}")
])

# Usage
llm = ChatOpenAI(model="gpt-4")
chain = support_template | llm

response = chain.invoke({
    "company_name": "TechCorp",
    "company_policies": "30-day return policy, 24/7 support available",
    "current_date": "2026-09-13",
    "chat_history": [],
    "customer_message": "I want to return my laptop"
})
```

### Example 2: Code Review Assistant

```python
from langchain_core.prompts import ChatPromptTemplate

code_review_template = ChatPromptTemplate.from_messages([
    ("system", """You are an expert code reviewer specializing in {language}.
    
Review the code for:
1. Bugs and potential errors
2. Security vulnerabilities
3. Performance issues
4. Code style and best practices
5. Documentation completeness

Provide specific, actionable feedback."""),
    ("human", """Please review this {language} code:

```{language}
{code}
```

Focus particularly on: {focus_areas}""")
])

# Usage
messages = code_review_template.format_messages(
    language="Python",
    code="""
def get_user(id):
    query = f"SELECT * FROM users WHERE id = {id}"
    return db.execute(query)
""",
    focus_areas="security and SQL injection vulnerabilities"
)
```

### Example 3: Content Generator

```python
from langchain_core.prompts import ChatPromptTemplate

content_template = ChatPromptTemplate.from_messages([
    ("system", """You are a professional content writer.

Writing Style: {style}
Target Audience: {audience}
Tone: {tone}
Word Count Target: {word_count}

Always include:
- Engaging introduction
- Clear structure with headings
- Actionable takeaways
- Call to action"""),
    ("human", "Write a {content_type} about: {topic}")
])

# Generate a blog post
messages = content_template.format_messages(
    style="informative and engaging",
    audience="software developers",
    tone="professional but friendly",
    word_count="800",
    content_type="blog post",
    topic="Getting Started with LangChain"
)
```

---

## Best Practices

### 1. System Message Design

```
┌─────────────────────────────────────────────────────────────────┐
│            SYSTEM MESSAGE BEST PRACTICES                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  STRUCTURE YOUR SYSTEM MESSAGE:                                 │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  1. ROLE DEFINITION                                      │   │
│  │     "You are an expert Python developer..."              │   │
│  │                                                          │   │
│  │  2. CAPABILITIES                                         │   │
│  │     "You can: review code, explain concepts..."          │   │
│  │                                                          │   │
│  │  3. CONSTRAINTS                                          │   │
│  │     "You must: provide examples, cite sources..."        │   │
│  │     "You must not: execute code, access external..."     │   │
│  │                                                          │   │
│  │  4. OUTPUT FORMAT                                        │   │
│  │     "Respond in markdown with code blocks..."            │   │
│  │                                                          │   │
│  │  5. CONTEXT (if needed)                                  │   │
│  │     "Current date: {date}, User level: {level}..."       │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### 2. Template Organization

```python
# templates/support.py
from langchain_core.prompts import ChatPromptTemplate

SUPPORT_TEMPLATE = ChatPromptTemplate.from_messages([
    ("system", """You are a support agent for {company}..."""),
    ("human", "{query}")
])

# templates/review.py
CODE_REVIEW_TEMPLATE = ChatPromptTemplate.from_messages([
    ("system", """You are a code reviewer..."""),
    ("human", "Review: {code}")
])

# main.py
from templates.support import SUPPORT_TEMPLATE
from templates.review import CODE_REVIEW_TEMPLATE
```

### 3. Validation

```python
from langchain_core.prompts import PromptTemplate

# Always validate in production
template = PromptTemplate(
    input_variables=["name", "topic"],
    template="Hello {name}, let's discuss {topic}.",
    validate_template=True  # Raises error if variables don't match
)

# Custom validation
def validate_inputs(template, **kwargs):
    """Validate inputs before formatting."""
    missing = set(template.input_variables) - set(kwargs.keys())
    if missing:
        raise ValueError(f"Missing required variables: {missing}")
    
    extra = set(kwargs.keys()) - set(template.input_variables)
    if extra:
        print(f"Warning: Extra variables ignored: {extra}")
    
    return template.format(**{k: v for k, v in kwargs.items() 
                             if k in template.input_variables})
```

### 4. Error Handling

```python
from langchain_core.prompts import PromptTemplate

def safe_format(template: PromptTemplate, **kwargs) -> str:
    """Safely format template with error handling."""
    try:
        return template.format(**kwargs)
    except KeyError as e:
        missing_var = str(e).strip("'")
        raise ValueError(
            f"Missing required variable: {missing_var}. "
            f"Required: {template.input_variables}"
        )
    except Exception as e:
        raise RuntimeError(f"Template formatting failed: {e}")

# Usage
template = PromptTemplate.from_template("Hello {name}!")
try:
    result = safe_format(template, wrong_var="test")
except ValueError as e:
    print(f"Error: {e}")
```

---

## Common Pitfalls

### 1. Message Order Matters

```python
# WRONG: Human message before system
wrong_template = ChatPromptTemplate.from_messages([
    ("human", "Hi!"),
    ("system", "You are helpful.")  # System should be first!
])

# CORRECT: System first, then human
correct_template = ChatPromptTemplate.from_messages([
    ("system", "You are helpful."),
    ("human", "Hi!")
])
```

### 2. Variable Name Conflicts

```python
# WRONG: Variable name 'input' conflicts with Python built-in
bad_template = PromptTemplate.from_template("Process this: {input}")

# BETTER: Use descriptive names
good_template = PromptTemplate.from_template("Process this: {user_input}")
```

### 3. Escaping Braces

```python
# WRONG: Unescaped braces
# PromptTemplate.from_template("Use JSON: {key: value}")  # Error!

# CORRECT: Double braces to escape
template = PromptTemplate.from_template(
    "Use JSON format: {{key: value}}, then add {user_data}"
)
# Output: "Use JSON format: {key: value}, then add ..."
```

---

## Summary

```
┌─────────────────────────────────────────────────────────────────┐
│               PROMPTTEMPLATE vs CHATPROMPTTEMPLATE              │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  PromptTemplate                 ChatPromptTemplate              │
│  ─────────────────             ─────────────────────            │
│  - String output               - Message list output            │
│  - Simple text prompts         - Role-based messages            │
│  - Completion models           - Chat models (GPT-4, Claude)    │
│  - Single turn                 - Multi-turn conversations       │
│                                                                  │
│  WHEN TO USE WHAT:                                              │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Simple text generation → PromptTemplate                  │   │
│  │ Chat/conversation     → ChatPromptTemplate               │   │
│  │ System instructions   → ChatPromptTemplate               │   │
│  │ History/context       → ChatPromptTemplate + Placeholder │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  KEY METHODS:                                                   │
│  - from_template()  : Quick creation, auto-detect variables    │
│  - from_messages()  : Create chat templates from message list  │
│  - format()         : Returns formatted string                 │
│  - format_messages(): Returns list of Message objects          │
│  - partial()        : Pre-fill some variables                  │
│  - invoke()         : Use with chains (LCEL)                   │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## Next Steps

In the next lesson, we'll explore **FewShotPromptTemplate** and **Example Selectors** to create prompts that learn from examples.

---

## References

- [LangChain ChatPromptTemplate Reference](https://reference.langchain.com/python/langchain-core/prompts/chat/ChatPromptTemplate)
- [LangChain Chat Prompts Module](https://reference.langchain.com/python/langchain-core/prompts/chat)
- [How to Build Chat Applications with LangChain](https://oneuptime.com/blog/post/2026-02-02-langchain-chat-applications/view)
- [A Guide to Prompt Templates in LangChain](https://mirascope.com/blog/langchain-prompt-template)
