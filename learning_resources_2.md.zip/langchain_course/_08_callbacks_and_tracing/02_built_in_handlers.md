# Module 08: Callbacks and Tracing

## 02 - Built-in Callback Handlers

### Overview

LangChain ships a set of ready-to-use callback handlers in `langchain_core.callbacks` and `langchain_community.callbacks` that cover common observability and debugging scenarios.

---

### Handler Categories

```
+----------------------------------------------------------------+
|                    Built-in Callback Handlers                   |
+----------------------------------------------------------------+
|                                                                 |
|  Core Handlers (langchain_core.callbacks)                       |
|  +----------------------------------------------------------+  |
|  |  - StdOutCallbackHandler     (console logging)           |  |
|  |  - StreamingStdOutCallbackHandler (token streaming)      |  |
|  +----------------------------------------------------------+  |
|                                                                 |
|  Community Handlers (langchain_community.callbacks)             |
|  +----------------------------------------------------------+  |
|  |  - FileCallbackHandler       (file logging)              |  |
|  |  - WandbCallbackHandler      (Weights & Biases)          |  |
|  |  - AimCallbackHandler        (Aim tracking)              |  |
|  |  - MlflowCallbackHandler     (MLflow tracking)           |  |
|  |  - ArizeCallbackHandler      (Arize AI)                  |  |
|  |  - ContextCallbackHandler    (Context.ai)                |  |
|  +----------------------------------------------------------+  |
|                                                                 |
+----------------------------------------------------------------+
```

---

### StdOutCallbackHandler

The simplest callback handler - prints execution events to standard output. Ideal for notebooks, development, tests, and CI pipelines.

#### Import and Basic Usage

```python
from langchain_core.callbacks import StdOutCallbackHandler
from langchain_openai import ChatOpenAI

# Create handler
handler = StdOutCallbackHandler()

# Attach to LLM
llm = ChatOpenAI(model="gpt-4", callbacks=[handler])

# Or pass at invocation
response = llm.invoke("What is the capital of France?", callbacks=[handler])
```

#### Example Output

```
> Entering new LLMChain chain...
Prompt after formatting:
What is the capital of France?

> Finished chain.
```

#### With Chains (LCEL)

```python
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.callbacks import StdOutCallbackHandler
from langchain_openai import ChatOpenAI

prompt = ChatPromptTemplate.from_template("Tell me about {topic}")
llm = ChatOpenAI(model="gpt-4")
parser = StrOutputParser()

chain = prompt | llm | parser

# With verbose callback
handler = StdOutCallbackHandler()
result = chain.invoke(
    {"topic": "quantum computing"},
    config={"callbacks": [handler]}
)
```

#### Configuration Options

```python
# StdOutCallbackHandler has minimal configuration
handler = StdOutCallbackHandler()

# Key attributes (inherited from BaseCallbackHandler)
handler.raise_error = False  # Whether to raise exceptions
handler.run_inline = False   # Whether to run inline vs async
```

---

### StreamingStdOutCallbackHandler

Streams LLM tokens to stdout as they are generated. Essential for real-time user feedback in chat applications.

#### Basic Usage

```python
from langchain_core.callbacks import StreamingStdOutCallbackHandler
from langchain_openai import ChatOpenAI

# Create streaming handler
handler = StreamingStdOutCallbackHandler()

# Enable streaming on the model
llm = ChatOpenAI(
    model="gpt-4",
    streaming=True,
    callbacks=[handler]
)

# Tokens print as they arrive
response = llm.invoke("Write a haiku about programming")
```

#### Output Behavior

```
# Tokens appear progressively:
Code | flows | like | water |
| Through | circuits | cold | and | bright |
| Bugs | hide | in | the | dark |
```

#### Custom Token Handling

```python
from langchain_core.callbacks import BaseCallbackHandler

class CustomStreamingHandler(BaseCallbackHandler):
    """Custom streaming with formatting."""
    
    def __init__(self, prefix: str = ""):
        self.prefix = prefix
        self.tokens = []
    
    def on_llm_new_token(self, token: str, **kwargs) -> None:
        """Handle each new token."""
        self.tokens.append(token)
        print(f"{self.prefix}{token}", end="", flush=True)
    
    def on_llm_end(self, response, **kwargs) -> None:
        """Handle completion."""
        print()  # New line at end
        print(f"Total tokens: {len(self.tokens)}")
```

#### Streaming with Async

```python
import asyncio
from langchain_core.callbacks import AsyncCallbackHandler
from langchain_openai import ChatOpenAI

class AsyncStreamingHandler(AsyncCallbackHandler):
    """Async-friendly streaming handler."""
    
    async def on_llm_new_token(self, token: str, **kwargs) -> None:
        print(token, end="", flush=True)
        await asyncio.sleep(0)  # Yield control

async def main():
    handler = AsyncStreamingHandler()
    llm = ChatOpenAI(model="gpt-4", streaming=True)
    
    response = await llm.ainvoke(
        "Explain recursion",
        config={"callbacks": [handler]}
    )

asyncio.run(main())
```

---

### FileCallbackHandler

Writes callback events to a file for persistent logging. Useful for audit trails and post-hoc analysis.

#### Basic Setup

```python
from langchain_community.callbacks import FileCallbackHandler
from langchain_openai import ChatOpenAI

# Create handler with file path
handler = FileCallbackHandler("langchain_logs.txt")

llm = ChatOpenAI(model="gpt-4", callbacks=[handler])
response = llm.invoke("What is machine learning?")
```

#### Log File Format

```
# langchain_logs.txt
[2026-09-13 10:30:45] on_llm_start: {"name": "ChatOpenAI", "model": "gpt-4"}
[2026-09-13 10:30:45] prompts: ["What is machine learning?"]
[2026-09-13 10:30:47] on_llm_end: {"token_usage": {"prompt_tokens": 6, "completion_tokens": 150}}
```

#### Advanced File Handler Configuration

```python
from langchain_community.callbacks import FileCallbackHandler
import os
from datetime import datetime

# Create timestamped log file
log_dir = "logs"
os.makedirs(log_dir, exist_ok=True)
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
log_file = f"{log_dir}/langchain_{timestamp}.log"

handler = FileCallbackHandler(log_file)
```

#### Custom File Handler with Rotation

```python
from langchain_core.callbacks import BaseCallbackHandler
from logging.handlers import RotatingFileHandler
import logging
import json

class RotatingFileCallbackHandler(BaseCallbackHandler):
    """File handler with log rotation."""
    
    def __init__(
        self,
        filename: str,
        max_bytes: int = 10_000_000,  # 10MB
        backup_count: int = 5
    ):
        self.logger = logging.getLogger("langchain_callbacks")
        self.logger.setLevel(logging.INFO)
        
        handler = RotatingFileHandler(
            filename,
            maxBytes=max_bytes,
            backupCount=backup_count
        )
        formatter = logging.Formatter(
            '%(asctime)s - %(levelname)s - %(message)s'
        )
        handler.setFormatter(formatter)
        self.logger.addHandler(handler)
    
    def on_llm_start(self, serialized, prompts, **kwargs):
        self.logger.info(f"LLM Start: {json.dumps({'prompts': prompts})}")
    
    def on_llm_end(self, response, **kwargs):
        usage = response.llm_output.get("token_usage", {})
        self.logger.info(f"LLM End: {json.dumps(usage)}")
    
    def on_llm_error(self, error, **kwargs):
        self.logger.error(f"LLM Error: {str(error)}")
```

---

### Combining Multiple Handlers

```python
from langchain_core.callbacks import (
    StdOutCallbackHandler,
    StreamingStdOutCallbackHandler
)
from langchain_community.callbacks import FileCallbackHandler
from langchain_openai import ChatOpenAI

# Create multiple handlers
handlers = [
    StdOutCallbackHandler(),           # Console logging
    FileCallbackHandler("logs.txt"),   # File logging
]

# Attach all handlers
llm = ChatOpenAI(model="gpt-4", callbacks=handlers)

# Or via config for streaming
streaming_handlers = [
    StreamingStdOutCallbackHandler(),
    FileCallbackHandler("stream_logs.txt"),
]

llm_streaming = ChatOpenAI(
    model="gpt-4",
    streaming=True,
    callbacks=streaming_handlers
)
```

---

### Handler Decision Matrix

```
+------------------------+------------------+------------------+------------------+
|      Use Case          |    StdOut        |   Streaming      |     File         |
+------------------------+------------------+------------------+------------------+
| Development/Debug      |       Yes        |       No         |      Maybe       |
| Jupyter Notebooks      |       Yes        |       Yes        |       No         |
| CI/CD Pipelines        |       Yes        |       No         |      Yes         |
| Real-time Chat UI      |       No         |       Yes        |       No         |
| Production Logging     |       No         |       No         |      Yes         |
| Audit Trail            |       No         |       No         |      Yes         |
| Token Streaming        |       No         |       Yes        |       No         |
| Performance Testing    |      Maybe       |       No         |      Yes         |
+------------------------+------------------+------------------+------------------+
```

---

### Community Integration Handlers

#### Weights & Biases (WandB)

```python
from langchain_community.callbacks import WandbCallbackHandler
import wandb

# Initialize W&B
wandb.init(project="langchain-project")

# Create handler
handler = WandbCallbackHandler(
    job_type="inference",
    project="langchain-project"
)

llm = ChatOpenAI(model="gpt-4", callbacks=[handler])
```

#### MLflow

```python
from langchain_community.callbacks import MlflowCallbackHandler
import mlflow

# Set tracking URI
mlflow.set_tracking_uri("http://localhost:5000")

# Create handler
handler = MlflowCallbackHandler()

llm = ChatOpenAI(model="gpt-4", callbacks=[handler])
```

#### Aim

```python
from langchain_community.callbacks import AimCallbackHandler
from aim import Run

# Create Aim run
run = Run()

# Create handler
handler = AimCallbackHandler(run=run)

llm = ChatOpenAI(model="gpt-4", callbacks=[handler])
```

---

### Handler Event Coverage

```
+----------------------+----------+-----------+----------+
|        Event         | StdOut   | Streaming | File     |
+----------------------+----------+-----------+----------+
| on_llm_start         |    X     |           |    X     |
| on_llm_end           |    X     |           |    X     |
| on_llm_new_token     |          |     X     |          |
| on_llm_error         |    X     |           |    X     |
| on_chain_start       |    X     |           |    X     |
| on_chain_end         |    X     |           |    X     |
| on_chain_error       |    X     |           |    X     |
| on_tool_start        |    X     |           |    X     |
| on_tool_end          |    X     |           |    X     |
| on_retriever_start   |    X     |           |    X     |
| on_retriever_end     |    X     |           |    X     |
| on_agent_action      |    X     |           |    X     |
| on_agent_finish      |    X     |           |    X     |
+----------------------+----------+-----------+----------+
```

---

### Best Practices

1. **Development**: Use `StdOutCallbackHandler` for quick debugging
2. **Streaming Apps**: Use `StreamingStdOutCallbackHandler` with `streaming=True`
3. **Production**: Use `FileCallbackHandler` with log rotation
4. **Experiment Tracking**: Use WandB, MLflow, or Aim handlers
5. **Combine Handlers**: Multiple handlers can work together
6. **Async Routes**: Always use async handlers in async applications

---

### Complete Example

```python
from langchain_core.callbacks import (
    StdOutCallbackHandler,
    StreamingStdOutCallbackHandler
)
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_openai import ChatOpenAI

# Development setup with multiple handlers
def create_development_chain():
    """Chain with verbose logging for development."""
    
    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are a helpful assistant."),
        ("human", "{question}")
    ])
    
    llm = ChatOpenAI(
        model="gpt-4",
        streaming=True,
        callbacks=[
            StdOutCallbackHandler(),
            StreamingStdOutCallbackHandler()
        ]
    )
    
    chain = prompt | llm | StrOutputParser()
    return chain

# Usage
chain = create_development_chain()
result = chain.invoke({"question": "What is deep learning?"})
```

---

### Next Steps

- **03_langsmith_integration.md**: Production-grade tracing with LangSmith
- **04_custom_callbacks.ipynb**: Build specialized callback handlers
- **05_debugging_tracing.ipynb**: Advanced debugging techniques

---

### References

- [StdOutCallbackHandler API](https://api.python.langchain.com/en/latest/callbacks/langchain_core.callbacks.stdout.StdOutCallbackHandler.html)
- [StreamingStdOutCallbackHandler API](https://python.langchain.com/api_reference/core/callbacks/langchain_core.callbacks.streaming_stdout.StreamingStdOutCallbackHandler.html)
- [LangChain Community Callbacks](https://reference.langchain.com/python/langchain-community/callbacks)
