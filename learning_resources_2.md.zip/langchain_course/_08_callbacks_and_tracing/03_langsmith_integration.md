# Module 08: Callbacks and Tracing

## 03 - LangSmith Integration for Production Tracing

### What is LangSmith?

LangSmith is a platform built by the LangChain team that provides integrated tooling for tracing, monitoring, debugging, testing, evaluating, and collecting feedback for LLM applications. It offers deep visibility into the inner workings of your chains without requiring code changes.

---

### Why LangSmith?

```
+------------------------------------------------------------------+
|                    The LLM Observability Problem                  |
+------------------------------------------------------------------+
|                                                                   |
|  Without Tracing:                    With LangSmith:              |
|  +---------------------------+      +---------------------------+ |
|  |  User Query               |      |  User Query               | |
|  |       |                   |      |       |                   | |
|  |       v                   |      |       v                   | |
|  |  [BLACK BOX]              |      |  Chain Start (logged)     | |
|  |       |                   |      |       |                   | |
|  |       ?                   |      |       v                   | |
|  |       ?                   |      |  Prompt Formatting        | |
|  |       ?                   |      |       |                   | |
|  |       v                   |      |       v                   | |
|  |  Bad Response             |      |  LLM Call (tokens, cost)  | |
|  |  (Why???)                 |      |       |                   | |
|  +---------------------------+      |       v                   | |
|                                     |  Tool Calls (each logged) | |
|                                     |       |                   | |
|                                     |       v                   | |
|                                     |  Final Response           | |
|                                     |  (full trace available)   | |
|                                     +---------------------------+ |
+------------------------------------------------------------------+
```

---

### LangSmith Architecture

```
+-------------------+         +-------------------+         +-------------------+
|   Your LangChain  |  HTTPS  |   LangSmith API   |         |   LangSmith UI    |
|   Application     |-------->|   (Trace Ingest)  |-------->|   (Dashboard)     |
+-------------------+         +-------------------+         +-------------------+
        |                             |                             |
        |                             v                             |
        |                     +---------------+                     |
        |                     |   Trace       |                     |
        +-------------------->|   Storage     |<--------------------+
         Automatic tracing    +---------------+     Query & View
         via env variables
```

---

### Quick Start Setup

#### Step 1: Create LangSmith Account

1. Visit [smith.langchain.com](https://smith.langchain.com)
2. Sign up for an account
3. Navigate to Settings > API Keys
4. Create a new API key

#### Step 2: Set Environment Variables

```bash
# Required: Enable tracing
export LANGCHAIN_TRACING_V2=true

# Required: Your API key
export LANGCHAIN_API_KEY=your-api-key-here

# Optional: Project name (default: "default")
export LANGCHAIN_PROJECT=my-langchain-project

# Optional: Endpoint (only for self-hosted)
export LANGCHAIN_ENDPOINT=https://api.smith.langchain.com
```

For Windows PowerShell:
```powershell
$env:LANGCHAIN_TRACING_V2 = "true"
$env:LANGCHAIN_API_KEY = "your-api-key-here"
$env:LANGCHAIN_PROJECT = "my-langchain-project"
```

#### Step 3: Run Your Code

```python
# No code changes required!
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate

prompt = ChatPromptTemplate.from_template("Explain {topic} simply.")
llm = ChatOpenAI(model="gpt-4")
chain = prompt | llm

# Traces automatically sent to LangSmith
response = chain.invoke({"topic": "quantum computing"})
```

---

### Environment Variables Reference

| Variable | Required | Description |
|----------|----------|-------------|
| `LANGCHAIN_TRACING_V2` | Yes | Set to `true` to enable tracing |
| `LANGCHAIN_API_KEY` | Yes | Your LangSmith API key |
| `LANGSMITH_API_KEY` | Yes* | Alternative name (must match LANGCHAIN_API_KEY) |
| `LANGCHAIN_PROJECT` | No | Project name for organizing traces |
| `LANGCHAIN_ENDPOINT` | No | API endpoint (default: api.smith.langchain.com) |
| `LANGSMITH_TRACING` | No | Alternative to LANGCHAIN_TRACING_V2 |

**Note:** Both `LANGCHAIN_API_KEY` and `LANGSMITH_API_KEY` should be set to the same value for full compatibility.

---

### Trace Structure

```
Trace Hierarchy
===============

Run (Trace Root)
|
+-- Chain Run
|   |
|   +-- Prompt Formatting
|   |
|   +-- LLM Run
|   |   |
|   |   +-- Input Messages
|   |   +-- Model Parameters
|   |   +-- Output Response
|   |   +-- Token Usage
|   |   +-- Latency
|   |
|   +-- Output Parser Run
|
+-- Metadata
    |
    +-- run_id
    +-- parent_run_id
    +-- tags
    +-- session_id
    +-- feedback
```

---

### Trace Visualization in LangSmith

```
+-----------------------------------------------------------------------+
|  LangSmith Dashboard - Trace View                                      |
+-----------------------------------------------------------------------+
|                                                                        |
|  Project: my-langchain-project                                         |
|  Run ID: abc123-def456-789...                                          |
|                                                                        |
|  +------------------------------------------------------------------+ |
|  | TRACE TIMELINE                                                    | |
|  +------------------------------------------------------------------+ |
|  |                                                                   | |
|  |  [Chain] RunnableSequence                    [2.34s]             | |
|  |    |                                                              | |
|  |    +-- [Prompt] ChatPromptTemplate           [0.001s]            | |
|  |    |     Input: {"topic": "quantum computing"}                    | |
|  |    |     Output: [HumanMessage: "Explain quantum computing..."]   | |
|  |    |                                                              | |
|  |    +-- [LLM] ChatOpenAI                      [2.33s]             | |
|  |    |     Model: gpt-4                                             | |
|  |    |     Tokens: 156 prompt / 287 completion                      | |
|  |    |     Cost: $0.0234                                            | |
|  |    |                                                              | |
|  |    +-- [Parser] StrOutputParser              [0.001s]            | |
|  |          Output: "Quantum computing is..."                        | |
|  |                                                                   | |
|  +------------------------------------------------------------------+ |
|                                                                        |
|  INPUT                          | OUTPUT                               |
|  -------------------------------+--------------------------------------|
|  {"topic": "quantum computing"} | "Quantum computing is a type of..."  |
|                                                                        |
+-----------------------------------------------------------------------+
```

---

### Using the @traceable Decorator

Wrap non-LangChain functions to include them in traces:

```python
from langsmith import traceable
from langchain_openai import ChatOpenAI

@traceable(name="preprocess_query")
def preprocess_query(query: str) -> str:
    """Clean and normalize user query."""
    return query.strip().lower()

@traceable(name="postprocess_response")
def postprocess_response(response: str) -> dict:
    """Structure the response."""
    return {
        "answer": response,
        "word_count": len(response.split())
    }

@traceable(name="full_pipeline")
def process_question(query: str) -> dict:
    """Full Q&A pipeline with tracing."""
    # All nested calls appear in the same trace
    cleaned_query = preprocess_query(query)
    
    llm = ChatOpenAI(model="gpt-4")
    response = llm.invoke(cleaned_query)
    
    return postprocess_response(response.content)

# Usage - entire pipeline traced
result = process_question("What is machine learning?")
```

---

### Programmatic Tracing Control

```python
from langsmith import Client
from langchain_openai import ChatOpenAI

# Initialize client
client = Client()

# Create a custom run
with client.trace(
    name="custom_operation",
    project_name="my-project",
    tags=["production", "v2.0"],
    metadata={"user_id": "user123", "session_id": "sess456"}
) as run:
    llm = ChatOpenAI(model="gpt-4")
    response = llm.invoke("Hello!")
    
    # Run ID available for feedback
    print(f"Run ID: {run.id}")
```

---

### Adding Metadata and Tags

```python
from langchain_openai import ChatOpenAI
from langchain_core.runnables import RunnableConfig

llm = ChatOpenAI(model="gpt-4")

# Add metadata and tags via config
config = RunnableConfig(
    tags=["production", "user-facing"],
    metadata={
        "user_id": "user_123",
        "session_id": "session_456",
        "request_source": "web_app",
        "version": "2.0.0"
    },
    run_name="customer_support_query"
)

response = llm.invoke("How do I reset my password?", config=config)
```

---

### LangSmith Dashboard Features

```
+-----------------------------------------------------------------------+
|                        LangSmith Feature Map                           |
+-----------------------------------------------------------------------+
|                                                                        |
|  TRACING                         |  EVALUATION                         |
|  +-----------------------------+ |  +-----------------------------+    |
|  | - Full execution traces     | |  | - Custom evaluators         |    |
|  | - Token-by-token streaming  | |  | - LLM-as-judge              |    |
|  | - Nested component view     | |  | - Automated test suites     |    |
|  | - Error highlighting        | |  | - Dataset management        |    |
|  | - Latency breakdown         | |  | - A/B comparisons           |    |
|  +-----------------------------+ |  +-----------------------------+    |
|                                  |                                     |
|  MONITORING                      |  FEEDBACK                           |
|  +-----------------------------+ |  +-----------------------------+    |
|  | - P50/P99 latency metrics   | |  | - User thumbs up/down       |    |
|  | - Token usage trends        | |  | - Score collection          |    |
|  | - Error rate dashboards     | |  | - Comment capture           |    |
|  | - Cost tracking             | |  | - Correction logging        |    |
|  | - Custom alerting           | |  | - Fine-tuning datasets      |    |
|  +-----------------------------+ |  +-----------------------------+    |
|                                                                        |
+-----------------------------------------------------------------------+
```

---

### Production Monitoring Setup

```python
import os
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langsmith import Client

# Production configuration
os.environ["LANGCHAIN_TRACING_V2"] = "true"
os.environ["LANGCHAIN_PROJECT"] = "production-chatbot"

def create_production_chain():
    """Create a production-ready chain with full tracing."""
    
    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are a helpful customer support agent."),
        ("human", "{question}")
    ])
    
    llm = ChatOpenAI(
        model="gpt-4",
        temperature=0.7,
        max_tokens=500
    )
    
    chain = prompt | llm
    return chain

def handle_request(question: str, user_id: str, session_id: str):
    """Handle a user request with full observability."""
    
    chain = create_production_chain()
    
    config = {
        "tags": ["production", "customer-support"],
        "metadata": {
            "user_id": user_id,
            "session_id": session_id,
            "environment": "production"
        },
        "run_name": f"support_query_{session_id}"
    }
    
    response = chain.invoke({"question": question}, config=config)
    return response.content
```

---

### Collecting User Feedback

```python
from langsmith import Client

client = Client()

def submit_feedback(run_id: str, score: int, comment: str = None):
    """Submit user feedback for a trace."""
    
    client.create_feedback(
        run_id=run_id,
        key="user_rating",
        score=score,  # 0-1 scale
        comment=comment
    )

# In your application
run_id = "abc123..."  # Captured from trace
submit_feedback(
    run_id=run_id,
    score=1.0,  # Positive feedback
    comment="Very helpful response!"
)
```

---

### Serverless Considerations

**Critical for AWS Lambda, Vercel, and short-lived processes:**

```python
import atexit
from langsmith import Client

client = Client()

# Ensure traces flush before process exits
def flush_traces():
    """Force flush any pending traces."""
    # LangSmith batches traces - ensure they're sent
    import time
    time.sleep(1)  # Allow async flush

atexit.register(flush_traces)

# Or use context manager for explicit control
from langsmith import trace

def lambda_handler(event, context):
    with trace(name="lambda_invocation") as run:
        # Your logic here
        pass
    # Trace is flushed when context exits
```

---

### Kubernetes/Production Deployment

```yaml
# kubernetes deployment example
apiVersion: apps/v1
kind: Deployment
metadata:
  name: langchain-app
spec:
  template:
    spec:
      containers:
      - name: app
        image: my-langchain-app:latest
        env:
        - name: LANGCHAIN_TRACING_V2
          value: "true"
        - name: LANGCHAIN_PROJECT
          value: "production"
        - name: LANGCHAIN_API_KEY
          valueFrom:
            secretKeyRef:
              name: langsmith-secrets
              key: api-key
```

---

### LangSmith vs OpenTelemetry

```
+------------------------------------------------------------------+
|                    Tracing Options Comparison                     |
+------------------------------------------------------------------+
|                                                                   |
|  LangSmith                      |  OpenTelemetry + Backend        |
|  +----------------------------+ |  +----------------------------+ |
|  | PROS:                      | |  | PROS:                      | |
|  | - Zero config for LC       | |  | - Vendor neutral           | |
|  | - Deep LangChain insight   | |  | - Any backend (Jaeger,     | |
|  | - Built-in eval tools      | |  |   Zipkin, Grafana, etc.)   | |
|  | - Managed platform         | |  | - Full control             | |
|  |                            | |  | - Self-hosted option       | |
|  | CONS:                      | |  |                            | |
|  | - Vendor lock-in           | |  | CONS:                      | |
|  | - Pricing at scale         | |  | - More setup required      | |
|  | - Data in their infra      | |  | - Less LC-specific insight | |
|  +----------------------------+ |  +----------------------------+ |
|                                                                   |
|  RECOMMENDATION:                                                  |
|  - Start with LangSmith for fastest time-to-value                |
|  - Consider OTel for multi-vendor or self-hosted needs           |
+------------------------------------------------------------------+
```

---

### OpenTelemetry Integration

```python
# Alternative: Use OpenTelemetry for vendor-neutral tracing
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter

# Setup OTel
provider = TracerProvider()
processor = BatchSpanProcessor(OTLPSpanExporter())
provider.add_span_processor(processor)
trace.set_tracer_provider(provider)

# LangChain with OTel (via opentelemetry-instrumentation-langchain)
# pip install opentelemetry-instrumentation-langchain
from opentelemetry.instrumentation.langchain import LangChainInstrumentor
LangChainInstrumentor().instrument()
```

---

### Troubleshooting

| Issue | Solution |
|-------|----------|
| Traces not appearing | Verify `LANGCHAIN_TRACING_V2=true` and API key |
| Partial traces | Check `LANGSMITH_API_KEY` matches `LANGCHAIN_API_KEY` |
| Missing nested calls | Use `@traceable` decorator for non-LC functions |
| Lambda trace loss | Add flush/wait before process exit |
| High latency | Traces are async; check network to LangSmith |

---

### Key Takeaways

1. **Zero-Code Setup**: Just set environment variables
2. **Automatic Tracing**: All LangChain components traced automatically
3. **@traceable Decorator**: Include non-LangChain code in traces
4. **Metadata/Tags**: Add context for filtering and analysis
5. **Feedback Loop**: Collect user feedback tied to traces
6. **Serverless Caution**: Ensure traces flush before exit

---

### Next Steps

- **04_custom_callbacks.ipynb**: Build custom callback handlers
- **05_debugging_tracing.ipynb**: Advanced debugging and performance monitoring

---

### References

- [LangSmith Documentation](https://docs.langchain.com/langsmith/observability)
- [LangSmith Tracing Guide](https://theneuralbase.com/langchain-advanced/learn/beginner/tracing-to-langsmith/)
- [LangSmith Setup Guide](https://markaicode.com/howto/langsmith-setup-and-configuration-guide/)
- [LangChain + LangSmith Integration](https://markaicode.com/integrate/langsmith-with-langchain/)
