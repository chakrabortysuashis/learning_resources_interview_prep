# Module 08: Callbacks and Tracing

## 01 - Understanding the LangChain Callback System

### Introduction

Callbacks are lifecycle hooks that every chain, LLM, tool, retriever, and agent in LangChain emits during execution. They follow a publish-subscribe (observer) pattern where you attach handlers that receive typed events at each step of the execution pipeline.

The callback system enables you to:
- Monitor and log execution progress
- Stream tokens in real-time
- Track costs and token usage
- Build custom tracing solutions
- Debug complex chain behaviors
- Integrate with observability platforms

---

### Callback Architecture

```
+------------------+     +-----------------------+     +-------------------+
|   LangChain      |     |   Callback Manager    |     |  Callback Handler |
|   Component      |---->|   (Event Dispatcher)  |---->|  (Your Logic)     |
|   (LLM, Chain,   |     |                       |     |                   |
|    Agent, etc.)  |     |  - Maintains handlers |     | - on_llm_start    |
|                  |     |  - Routes events      |     | - on_llm_end      |
|                  |     |  - Handles inheritance|     | - on_chain_start  |
+------------------+     +-----------------------+     +-------------------+
```

### Callback Lifecycle Flow

```
                    Chain Execution Lifecycle
    ================================================================
    
    [Chain Start]
         |
         v
    on_chain_start(serialized, inputs, run_id, parent_run_id)
         |
         +---> [LLM/Chat Model Invocation]
         |          |
         |          v
         |     on_llm_start(serialized, prompts, run_id) 
         |     OR on_chat_model_start(serialized, messages, run_id)
         |          |
         |          +---> [Token Streaming (if enabled)]
         |          |          |
         |          |          v
         |          |     on_llm_new_token(token, run_id) [repeated]
         |          |          |
         |          v          v
         |     on_llm_end(response, run_id)
         |     OR on_llm_error(error, run_id)
         |          |
         +---> [Tool Invocation (if agent)]
         |          |
         |          v
         |     on_tool_start(serialized, input_str, run_id)
         |          |
         |          v
         |     on_tool_end(output, run_id)
         |     OR on_tool_error(error, run_id)
         |          |
         +---> [Retriever Invocation (if RAG)]
         |          |
         |          v
         |     on_retriever_start(serialized, query, run_id)
         |          |
         |          v
         |     on_retriever_end(documents, run_id)
         |          |
         v
    on_chain_end(outputs, run_id)
    OR on_chain_error(error, run_id)
```

---

### Base Callback Handler Classes

LangChain provides two primary base classes for creating callback handlers:

#### 1. BaseCallbackHandler (Synchronous)

```python
from langchain_core.callbacks import BaseCallbackHandler

class MyHandler(BaseCallbackHandler):
    """Synchronous callback handler."""
    
    def on_llm_start(self, serialized, prompts, **kwargs):
        """Called when LLM starts generating."""
        pass
    
    def on_llm_end(self, response, **kwargs):
        """Called when LLM finishes generating."""
        pass
```

#### 2. AsyncCallbackHandler (Asynchronous)

```python
from langchain_core.callbacks import AsyncCallbackHandler

class MyAsyncHandler(AsyncCallbackHandler):
    """Asynchronous callback handler for non-blocking operations."""
    
    async def on_llm_start(self, serialized, prompts, **kwargs):
        """Called when LLM starts generating."""
        pass
    
    async def on_llm_end(self, response, **kwargs):
        """Called when LLM finishes generating."""
        pass
```

**Important:** Use `AsyncCallbackHandler` in async serving paths. Sync handlers in async routes run on the default thread pool, adding latency per token.

---

### Core Callback Methods Reference

| Method | Trigger Event | Key Parameters |
|--------|---------------|----------------|
| `on_llm_start` | Before text LLM generation | `serialized`, `prompts`, `run_id` |
| `on_chat_model_start` | Before chat model generation | `serialized`, `messages`, `run_id` |
| `on_llm_new_token` | Each new token (streaming) | `token`, `run_id` |
| `on_llm_end` | After LLM completes | `response`, `run_id` |
| `on_llm_error` | On LLM error | `error`, `run_id` |
| `on_chain_start` | Before chain execution | `serialized`, `inputs`, `run_id` |
| `on_chain_end` | After chain completes | `outputs`, `run_id` |
| `on_chain_error` | On chain error | `error`, `run_id` |
| `on_tool_start` | Before tool execution | `serialized`, `input_str`, `run_id` |
| `on_tool_end` | After tool completes | `output`, `run_id` |
| `on_tool_error` | On tool error | `error`, `run_id` |
| `on_retriever_start` | Before retrieval | `serialized`, `query`, `run_id` |
| `on_retriever_end` | After retrieval | `documents`, `run_id` |
| `on_agent_action` | On agent action | `action`, `run_id` |
| `on_agent_finish` | On agent completion | `finish`, `run_id` |

---

### Method Signatures (Detailed)

```python
from typing import Any, Dict, List, Optional
from uuid import UUID
from langchain_core.outputs import LLMResult

class BaseCallbackHandler:
    
    def on_llm_start(
        self,
        serialized: Dict[str, Any],
        prompts: List[str],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any
    ) -> Any:
        """Run when LLM starts running."""
        pass

    def on_chat_model_start(
        self,
        serialized: Dict[str, Any],
        messages: List[List],  # List of message lists
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any
    ) -> Any:
        """Run when Chat Model starts running."""
        pass

    def on_llm_end(
        self,
        response: LLMResult,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any
    ) -> Any:
        """Run when LLM ends running."""
        pass

    def on_llm_new_token(
        self,
        token: str,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any
    ) -> Any:
        """Run on new LLM token. Only available when streaming is enabled."""
        pass
```

---

### Attaching Callbacks to Components

#### Method 1: Via RunnableConfig (Recommended)

```python
from langchain_core.runnables import RunnableConfig
from langchain_openai import ChatOpenAI

config = RunnableConfig(callbacks=[MyHandler()])
llm = ChatOpenAI(model="gpt-4")

# Pass config to invoke
response = llm.invoke("Hello!", config=config)

# Or with chains
chain = prompt | llm | output_parser
response = chain.invoke({"input": "Hello"}, config=config)
```

#### Method 2: Constructor-Level Callbacks

```python
# Callbacks attached at component construction
llm = ChatOpenAI(
    model="gpt-4",
    callbacks=[MyHandler()]
)
```

#### Method 3: Runtime Callbacks Parameter

```python
# Callbacks passed at invocation time
response = llm.invoke(
    "Hello!",
    callbacks=[MyHandler()]
)
```

---

### Callback Inheritance and Scoping

```
+-----------------------------------------------------------+
|  Global Callbacks (set via environment/config)            |
|  +-----------------------------------------------------+  |
|  |  Chain Callbacks (attached to chain)                |  |
|  |  +-----------------------------------------------+  |  |
|  |  |  Component Callbacks (attached to LLM/Tool)   |  |  |
|  |  |  +----------------------------------------+   |  |  |
|  |  |  |  Request Callbacks (via config)        |   |  |  |
|  |  |  +----------------------------------------+   |  |  |
|  |  +-----------------------------------------------+  |  |
|  +-----------------------------------------------------+  |
+-----------------------------------------------------------+
```

**Best Practice:** Prefer `RunnableConfig` and attach handlers per request, not per component. Global state is the biggest source of cross-tenant trace bleed in multi-tenant applications.

---

### Callback Manager

The `CallbackManager` coordinates callback dispatch:

```python
from langchain_core.callbacks import CallbackManager

# Create manager with handlers
manager = CallbackManager(handlers=[MyHandler()])

# Add/remove handlers dynamically
manager.add_handler(AnotherHandler(), inherit=True)
manager.remove_handler(old_handler)

# Set handlers (replaces all)
manager.set_handlers([NewHandler()], inherit=True)
```

The `inherit` parameter controls whether child components receive the handler.

---

### Run IDs and Parent-Child Relationships

Every callback event includes:
- `run_id`: Unique identifier for the current execution
- `parent_run_id`: ID of the parent execution (enables trace trees)

```
Chain (run_id: abc-123, parent_run_id: None)
    |
    +-- LLM (run_id: def-456, parent_run_id: abc-123)
    |       |
    |       +-- Token events (run_id: def-456)
    |
    +-- Tool (run_id: ghi-789, parent_run_id: abc-123)
```

This hierarchy enables building complete execution traces and understanding nested component relationships.

---

### Key Takeaways

1. **Callbacks are Observer Pattern** - Components emit events; handlers subscribe to them
2. **Use AsyncCallbackHandler for Production** - Sync handlers block execution
3. **Prefer RunnableConfig** - Attach handlers per-request to avoid cross-contamination
4. **run_id Links Events** - Use parent_run_id to build execution trees
5. **Only Override What You Need** - Base classes provide no-op defaults

---

### Next Steps

- **02_built_in_handlers.md**: Explore LangChain's built-in callback handlers
- **03_langsmith_integration.md**: Set up LangSmith for production tracing
- **04_custom_callbacks.ipynb**: Build your own callback handlers
- **05_debugging_tracing.ipynb**: Debug and monitor with callbacks

---

### References

- [LangChain Callbacks Documentation](https://python.langchain.com/api_reference/core/callbacks/)
- [BaseCallbackHandler API Reference](https://python.langchain.com/api_reference/core/callbacks/langchain_core.callbacks.base.BaseCallbackHandler.html)
- [AsyncCallbackHandler Reference](https://reference.langchain.com/python/langchain-core/callbacks/base/AsyncCallbackHandler)
