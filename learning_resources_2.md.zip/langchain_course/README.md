# LangChain Comprehensive Course

A hands-on, structured course to master LangChain from fundamentals to advanced applications.

## Course Structure

```
┌─────────────────────────────────────────────────────────────────────┐
│                    LANGCHAIN LEARNING PATH                          │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐             │
│  │   Module 1  │───▶│   Module 2  │───▶│   Module 3  │             │
│  │   Intro &   │    │   Models &  │    │  Prompts &  │             │
│  │   Setup     │    │    LLMs     │    │  Templates  │             │
│  └─────────────┘    └─────────────┘    └─────────────┘             │
│         │                                     │                     │
│         ▼                                     ▼                     │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐             │
│  │   Module 4  │◀───│   Module 5  │◀───│   Module 6  │             │
│  │   Output    │    │   Chains    │    │  Runnables  │             │
│  │   Parsers   │    │   Basics    │    │   & LCEL    │             │
│  └─────────────┘    └─────────────┘    └─────────────┘             │
│         │                                     │                     │
│         ▼                                     ▼                     │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐             │
│  │   Module 7  │───▶│   Module 8  │───▶│   Module 9  │             │
│  │   Tools &   │    │  Callbacks  │    │  Document   │             │
│  │   Agents    │    │  & Tracing  │    │  Loaders    │             │
│  └─────────────┘    └─────────────┘    └─────────────┘             │
│         │                                     │                     │
│         ▼                                     ▼                     │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐             │
│  │  Module 10  │◀───│  Module 11  │◀───│  Module 12  │             │
│  │    Text     │    │   Vector    │    │ Retrievers  │             │
│  │  Splitters  │    │   Stores    │    │             │             │
│  └─────────────┘    └─────────────┘    └─────────────┘             │
│         │                                     │                     │
│         ▼                                     ▼                     │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐             │
│  │  Module 13  │───▶│  Module 14  │───▶│  Module 15  │             │
│  │    RAG      │    │  Streaming  │    │ Middleware  │             │
│  │Applications │    │             │    │  & Memory   │             │
│  └─────────────┘    └─────────────┘    └─────────────┘             │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

## Modules Overview

| Module | Name | Key Topics |
|--------|------|------------|
| 01 | Introduction & Setup | LangChain architecture, installation, environment setup |
| 02 | Models & LLMs | Chat models, LLMs, embeddings, model providers |
| 03 | Prompts & Templates | PromptTemplate, ChatPromptTemplate, few-shot prompting |
| 04 | Output Parsers | JSON, Pydantic, structured output parsing |
| 05 | Chains Basics | LLMChain, Sequential chains, chain composition |
| 06 | Runnables & LCEL | Runnable interface, LCEL syntax, pipe operator |
| 07 | Tools & Agents | Tool creation, agents, ReAct pattern |
| 08 | Callbacks & Tracing | Callback handlers, LangSmith integration |
| 09 | Document Loaders | PyPDF, Docling, web loaders, custom loaders |
| 10 | Text Splitters | RecursiveCharacterTextSplitter, semantic splitting |
| 11 | Vector Stores | FAISS, ChromaDB, Pinecone, Weaviate |
| 12 | Retrievers | Vector retrievers, multi-query, contextual compression |
| 13 | RAG Applications | End-to-end RAG pipelines, evaluation |
| 14 | Streaming | Token streaming, async streaming, SSE |
| 15 | Middleware & Memory | Caching, memory types, conversation management |

## Prerequisites

- Python 3.9+
- Basic Python knowledge
- Understanding of APIs and JSON
- (Optional) Familiarity with ML/AI concepts

## Setup Instructions

```bash
# Create virtual environment
python -m venv langchain_env
source langchain_env/bin/activate  # On Windows: langchain_env\Scripts\activate

# Install core dependencies
pip install langchain langchain-core langchain-community
pip install langchain-openai langchain-anthropic  # For model providers
pip install chromadb faiss-cpu pinecone-client  # For vector stores
pip install pypdf docling  # For document loaders
pip install jupyter notebook  # For running notebooks
```

## How to Use This Course

1. **Sequential Learning**: Follow modules in order (01 → 15) for comprehensive understanding
2. **Topic-Based**: Jump to specific modules if you need particular concepts
3. **Hands-On Practice**: Each module contains `.ipynb` notebooks with runnable code
4. **Theory + Practice**: `.md` files provide conceptual explanations with diagrams

## LangChain Architecture Overview

```
┌────────────────────────────────────────────────────────────────────────┐
│                         LANGCHAIN ECOSYSTEM                            │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐                 │
│  │  langchain   │  │  langchain-  │  │  langchain-  │                 │
│  │    core      │  │   community  │  │   <provider> │                 │
│  │              │  │              │  │              │                 │
│  │ • Runnables  │  │ • Loaders    │  │ • OpenAI     │                 │
│  │ • LCEL       │  │ • Stores     │  │ • Anthropic  │                 │
│  │ • Prompts    │  │ • Tools      │  │ • Google     │                 │
│  │ • Parsers    │  │ • Retrievers │  │ • AWS        │                 │
│  └──────────────┘  └──────────────┘  └──────────────┘                 │
│         │                  │                  │                        │
│         └──────────────────┼──────────────────┘                        │
│                            │                                           │
│                            ▼                                           │
│  ┌─────────────────────────────────────────────────────────┐          │
│  │                    YOUR APPLICATION                      │          │
│  │  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐    │          │
│  │  │ Chains  │  │ Agents  │  │   RAG   │  │Chatbots │    │          │
│  │  └─────────┘  └─────────┘  └─────────┘  └─────────┘    │          │
│  └─────────────────────────────────────────────────────────┘          │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
```

## Version Information

- **LangChain Version**: 0.3.x (Latest as of 2024)
- **Python Version**: 3.9+
- **Last Updated**: September 2024

## Contributing

Feel free to add more examples, fix errors, or suggest improvements!
