# Module 14: Streaming Basics

## Why Streaming Matters

Streaming is one of the most critical features for building responsive LLM applications. Instead of waiting for the entire response to be generated before displaying anything to users, streaming allows you to show output token-by-token as it's being produced.

### The User Experience Problem

```
Traditional Request-Response (invoke):
=====================================

User Query -----> [    LLM Processing (5-30 seconds)    ] -----> Complete Response
                  ^                                      ^
                  |______________________________________|
                        User sees NOTHING during this time
                        (feels slow and unresponsive)


Streaming Response (stream):
============================

User Query -----> [LLM] --> token --> token --> token --> token --> ...
                     |        |         |         |         |
                     v        v         v         v         v
                   "The"   "quick"   "brown"    "fox"    "jumps"
                   
                   User sees EACH token immediately!
                   (feels fast and interactive)
```

### Key Benefits of Streaming

| Benefit | Description |
|---------|-------------|
| **Perceived Performance** | Users see immediate feedback, making the app feel faster |
| **Early Termination** | Users can stop generation if they see the response is going wrong |
| **Progressive Display** | Build chat interfaces that feel natural and responsive |
| **Memory Efficiency** | Process tokens as they arrive instead of buffering entire responses |
| **Real-time Processing** | Enable live translation, summarization, or analysis |

---

## stream() vs invoke(): The Core Difference

### invoke() - Synchronous, Complete Response

```python
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(model="gpt-4o")

# invoke() waits for the complete response
response = llm.invoke("Explain quantum computing")
print(response.content)  # Prints everything at once after waiting
```

**Characteristics of invoke():**
- Blocks until the entire response is ready
- Returns a complete `AIMessage` object
- Simple to use but poor UX for long responses
- Best for: Background processing, batch operations, short responses

### stream() - Real-time Token Output

```python
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(model="gpt-4o")

# stream() yields chunks as they're generated
for chunk in llm.stream("Explain quantum computing"):
    print(chunk.content, end="", flush=True)  # Prints token by token
```

**Characteristics of stream():**
- Returns an iterator of `AIMessageChunk` objects
- Each chunk contains a small piece of the response (often 1-3 tokens)
- Enables real-time display
- Best for: Chat interfaces, interactive applications, long responses

---

## Visual Comparison: stream() vs invoke()

```
                    invoke() Flow
                    =============

    +--------+     +-----------------+     +------------------+
    |  User  | --> |    LLM Call     | --> | Complete Message |
    | Query  |     | (blocks 5-30s)  |     |    Returned      |
    +--------+     +-----------------+     +------------------+
                          |
                          | User waits...
                          | waits...
                          | waits...
                          v
                   [Full response appears all at once]


                    stream() Flow
                    =============

    +--------+     +----------+     +--------+     +--------+     +--------+
    |  User  | --> | LLM Call | --> | Chunk1 | --> | Chunk2 | --> | Chunk3 | ...
    | Query  |     | (starts) |     |  "The" |     | "key"  |     | "is"   |
    +--------+     +----------+     +--------+     +--------+     +--------+
                        |               |              |              |
                        v               v              v              v
                      [immediate]  [instant]      [instant]      [instant]
                        
    Timeline: |---100ms---|---100ms---|---100ms---|---100ms---|...
              ^           ^           ^           ^
              First token Second      Third       Fourth
              visible     token       token       token
```

---

## Understanding AIMessageChunk

When streaming, LangChain returns `AIMessageChunk` objects instead of `AIMessage`:

```python
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(model="gpt-4o")

for chunk in llm.stream("Say hello"):
    print(f"Type: {type(chunk)}")
    print(f"Content: '{chunk.content}'")
    print(f"Additional kwargs: {chunk.additional_kwargs}")
    print("---")
```

**Output:**
```
Type: <class 'langchain_core.messages.ai.AIMessageChunk'>
Content: 'Hello'
Additional kwargs: {}
---
Type: <class 'langchain_core.messages.ai.AIMessageChunk'>
Content: '!'
Additional kwargs: {}
---
Type: <class 'langchain_core.messages.ai.AIMessageChunk'>
Content: ' How'
Additional kwargs: {}
---
```

### Chunk Aggregation

Chunks can be combined to reconstruct the full response:

```python
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(model="gpt-4o")

# Method 1: Manual concatenation
full_response = ""
for chunk in llm.stream("Say hello"):
    full_response += chunk.content

print(full_response)

# Method 2: Using chunk addition (LangChain feature)
chunks = list(llm.stream("Say hello"))
full_message = chunks[0]
for chunk in chunks[1:]:
    full_message = full_message + chunk

print(full_message.content)
```

---

## Streaming Architecture

```
                        LangChain Streaming Architecture
    ============================================================================

    +-----------+      +----------------+      +-------------------+
    |   User    |      |   LangChain    |      |   LLM Provider    |
    |  Request  | ---> |   Framework    | ---> |  (OpenAI, etc.)   |
    +-----------+      +----------------+      +-------------------+
                              |                        |
                              |    SSE/WebSocket       |
                              |    Connection          |
                              |<-----------------------|
                              |                        |
    +------------------+      |                        |
    | Generator/Async  | <----|                        |
    |    Iterator      |      |   Token Stream         |
    +------------------+      |<-----------------------|
           |                  |                        |
           v                  |                        |
    +------------------+      |                        |
    | Your Application | <----|                        |
    | (display/process)|      |                        |
    +------------------+      +------------------------+

    Key Components:
    ===============
    1. LLM Provider streams tokens via SSE (Server-Sent Events)
    2. LangChain wraps this in a Python generator
    3. Your code iterates through chunks in real-time
    4. Each chunk can be displayed or processed immediately
```

---

## When to Use Each Method

### Use invoke() when:

```python
# 1. Batch processing (no user waiting)
def process_documents(docs):
    results = []
    for doc in docs:
        result = llm.invoke(f"Summarize: {doc}")
        results.append(result.content)
    return results

# 2. Simple one-shot queries
answer = llm.invoke("What is 2 + 2?")

# 3. When you need the complete response for further processing
response = llm.invoke("Generate JSON config")
config = json.loads(response.content)

# 4. Background tasks
def background_analysis(data):
    return llm.invoke(f"Analyze: {data}")
```

### Use stream() when:

```python
# 1. Chat interfaces
def chat_response(user_message):
    for chunk in llm.stream(user_message):
        yield chunk.content  # Send to frontend

# 2. Long-form content generation
def generate_article(topic):
    print(f"Generating article about {topic}...")
    for chunk in llm.stream(f"Write an article about {topic}"):
        print(chunk.content, end="", flush=True)

# 3. Real-time applications
def live_translation(text):
    for chunk in llm.stream(f"Translate to Spanish: {text}"):
        display_to_user(chunk.content)

# 4. When users expect immediate feedback
def assistant_response(query):
    response_area.clear()
    for chunk in llm.stream(query):
        response_area.append(chunk.content)
```

---

## Common Streaming Patterns

### Pattern 1: Accumulate and Display

```python
def stream_with_accumulation(prompt):
    """Stream while keeping track of full response."""
    accumulated = ""
    
    for chunk in llm.stream(prompt):
        accumulated += chunk.content
        
        # Clear and redisplay (for terminal)
        print(f"\r{accumulated}", end="", flush=True)
    
    print()  # Newline at end
    return accumulated
```

### Pattern 2: Stream with Progress Indicator

```python
def stream_with_progress(prompt):
    """Show token count while streaming."""
    token_count = 0
    
    for chunk in llm.stream(prompt):
        print(chunk.content, end="", flush=True)
        token_count += 1
    
    print(f"\n[{token_count} chunks received]")
```

### Pattern 3: Stream with Timeout

```python
import time

def stream_with_timeout(prompt, timeout_seconds=30):
    """Stream with a timeout limit."""
    start_time = time.time()
    response = ""
    
    for chunk in llm.stream(prompt):
        if time.time() - start_time > timeout_seconds:
            print("\n[Timeout reached]")
            break
        
        response += chunk.content
        print(chunk.content, end="", flush=True)
    
    return response
```

---

## Summary

| Aspect | invoke() | stream() |
|--------|----------|----------|
| **Return Type** | `AIMessage` | Iterator of `AIMessageChunk` |
| **Blocking** | Yes (waits for complete response) | No (yields immediately) |
| **Best For** | Batch processing, short queries | Chat UIs, long content |
| **User Experience** | Poor for long responses | Excellent responsiveness |
| **Complexity** | Simple | Slightly more complex |
| **Memory** | Holds full response | Processes incrementally |

---

## Next Steps

In the following sections, we'll explore:
- **02_token_streaming.md**: Deep dive into token-by-token streaming with `astream()`
- **03_streaming_events.md**: Using `astream_events()` for complex chain visibility
- **04_basic_streaming.ipynb**: Hands-on basic streaming examples
- **05_streaming_with_chains.ipynb**: Streaming through LCEL chains
- **06_sse_integration.ipynb**: Building web apps with Server-Sent Events
