# Module 14: Token-by-Token Streaming

## Understanding Token Streaming

Token streaming is the process of receiving LLM output piece by piece as it's generated, rather than waiting for the complete response. This section covers synchronous `stream()` and asynchronous `astream()` methods in depth.

---

## Synchronous Streaming with stream()

### Basic Usage

```python
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage

llm = ChatOpenAI(model="gpt-4o", temperature=0.7)

# Simple streaming
for chunk in llm.stream("Explain the theory of relativity in simple terms"):
    print(chunk.content, end="", flush=True)
```

### How Tokens Are Delivered

```
Token Generation Timeline
=========================

LLM Internal State:                    What You Receive:
==================                    ==================

[Generating "The"] -----------------> AIMessageChunk(content="The")
        |
        v
[Generating " theory"] -------------> AIMessageChunk(content=" theory")
        |
        v
[Generating " of"] -----------------> AIMessageChunk(content=" of")
        |
        v
[Generating " relativity"] ---------> AIMessageChunk(content=" relativity")
        |
        v
       ...                           ...
        |
        v
[Generation Complete] --------------> AIMessageChunk(content="")  # Empty final chunk


Note: Chunk boundaries don't always align with word boundaries!
      You might receive: "relativ" then "ity" as separate chunks.
```

### Chunk Structure Deep Dive

```python
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(model="gpt-4o")

print("Analyzing chunk structure:\n")

for i, chunk in enumerate(llm.stream("Count from 1 to 5")):
    print(f"Chunk {i}:")
    print(f"  content: {repr(chunk.content)}")
    print(f"  type: {chunk.type}")
    print(f"  id: {chunk.id}")
    print(f"  response_metadata: {chunk.response_metadata}")
    print()
```

**Example Output:**
```
Chunk 0:
  content: ''
  type: 'AIMessageChunk'
  id: 'run-abc123'
  response_metadata: {}

Chunk 1:
  content: '1'
  type: 'AIMessageChunk'
  id: 'run-abc123'
  response_metadata: {}

Chunk 2:
  content: ', '
  type: 'AIMessageChunk'
  id: 'run-abc123'
  response_metadata: {}
...
```

---

## Asynchronous Streaming with astream()

### Why Async Streaming?

```
Synchronous Streaming:                 Asynchronous Streaming:
======================                 ======================

Thread 1: [Stream LLM Response]        Event Loop: [Stream LLM] + [Handle UI] + [Process Data]
                                                         |            |              |
Cannot do anything else                                  v            v              v
while streaming!                                    Concurrent operations!


Benefits of Async:
- Handle multiple streams simultaneously
- Maintain responsive UI while streaming
- Process other tasks during token wait times
- Better resource utilization in web servers
```

### Basic astream() Usage

```python
import asyncio
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(model="gpt-4o")

async def stream_response():
    """Basic async streaming."""
    async for chunk in llm.astream("Explain neural networks"):
        print(chunk.content, end="", flush=True)

# Run the async function
asyncio.run(stream_response())
```

### astream() with Type Annotations

```python
import asyncio
from langchain_openai import ChatOpenAI
from langchain_core.messages import AIMessageChunk

llm = ChatOpenAI(model="gpt-4o")

async def typed_stream() -> str:
    """Async streaming with proper type hints."""
    full_response: str = ""
    
    chunk: AIMessageChunk
    async for chunk in llm.astream("What is machine learning?"):
        content: str = chunk.content
        full_response += content
        print(content, end="", flush=True)
    
    return full_response

result = asyncio.run(typed_stream())
```

---

## Advanced Async Patterns

### Pattern 1: Multiple Concurrent Streams

```python
import asyncio
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(model="gpt-4o")

async def stream_query(query: str, query_id: int) -> str:
    """Stream a single query and collect the response."""
    response = ""
    async for chunk in llm.astream(query):
        response += chunk.content
        # Print with query ID for identification
        if chunk.content:
            print(f"[Q{query_id}] {chunk.content}", end="", flush=True)
    return response

async def concurrent_streams():
    """Run multiple streams concurrently."""
    queries = [
        "What is Python?",
        "What is JavaScript?",
        "What is Rust?"
    ]
    
    # Create tasks for concurrent execution
    tasks = [
        stream_query(query, i) 
        for i, query in enumerate(queries)
    ]
    
    # Run all streams concurrently
    results = await asyncio.gather(*tasks)
    
    print("\n\n--- Results ---")
    for i, result in enumerate(results):
        print(f"Query {i}: {result[:100]}...")

asyncio.run(concurrent_streams())
```

### Pattern 2: Stream with Async Callback

```python
import asyncio
from typing import Callable, Awaitable
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(model="gpt-4o")

async def stream_with_callback(
    prompt: str,
    on_token: Callable[[str], Awaitable[None]],
    on_complete: Callable[[str], Awaitable[None]]
) -> None:
    """Stream with async callbacks for each token and completion."""
    full_response = ""
    
    async for chunk in llm.astream(prompt):
        if chunk.content:
            await on_token(chunk.content)
            full_response += chunk.content
    
    await on_complete(full_response)

# Usage
async def handle_token(token: str):
    print(f"Token: {repr(token)}")

async def handle_complete(response: str):
    print(f"\nComplete! Total length: {len(response)}")

asyncio.run(stream_with_callback(
    "Count to 5",
    on_token=handle_token,
    on_complete=handle_complete
))
```

### Pattern 3: Stream with Timeout and Cancellation

```python
import asyncio
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(model="gpt-4o")

async def stream_with_timeout(prompt: str, timeout: float = 10.0) -> str:
    """Stream with a timeout limit."""
    response = ""
    
    try:
        async with asyncio.timeout(timeout):
            async for chunk in llm.astream(prompt):
                response += chunk.content
                print(chunk.content, end="", flush=True)
    except asyncio.TimeoutError:
        print(f"\n[Timeout after {timeout}s]")
    
    return response

async def stream_with_cancellation(prompt: str) -> str:
    """Stream with the ability to cancel mid-generation."""
    response = ""
    stop_flag = False
    
    async def check_for_stop():
        nonlocal stop_flag
        await asyncio.sleep(2)  # Simulate user pressing stop after 2s
        stop_flag = True
        print("\n[Stop requested]")
    
    # Start stop checker in background
    stop_task = asyncio.create_task(check_for_stop())
    
    async for chunk in llm.astream(prompt):
        if stop_flag:
            break
        response += chunk.content
        print(chunk.content, end="", flush=True)
    
    stop_task.cancel()
    return response

# Run with timeout
asyncio.run(stream_with_timeout("Write a long story", timeout=5.0))
```

---

## Streaming with Messages

### Streaming Chat Conversations

```python
import asyncio
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage, AIMessage

llm = ChatOpenAI(model="gpt-4o")

async def chat_stream():
    """Stream responses in a chat context."""
    messages = [
        SystemMessage(content="You are a helpful coding assistant."),
        HumanMessage(content="What is a decorator in Python?")
    ]
    
    # Stream the response
    response_content = ""
    async for chunk in llm.astream(messages):
        response_content += chunk.content
        print(chunk.content, end="", flush=True)
    
    # Add assistant response to history
    messages.append(AIMessage(content=response_content))
    
    # Continue conversation
    messages.append(HumanMessage(content="Show me an example"))
    
    print("\n\n--- Follow-up ---\n")
    async for chunk in llm.astream(messages):
        print(chunk.content, end="", flush=True)

asyncio.run(chat_stream())
```

### Building a Streaming Chat Class

```python
import asyncio
from typing import List, AsyncIterator
from langchain_openai import ChatOpenAI
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage, SystemMessage

class StreamingChat:
    """A chat interface with streaming support."""
    
    def __init__(self, model: str = "gpt-4o", system_prompt: str = None):
        self.llm = ChatOpenAI(model=model)
        self.history: List[BaseMessage] = []
        
        if system_prompt:
            self.history.append(SystemMessage(content=system_prompt))
    
    async def stream_response(self, user_input: str) -> AsyncIterator[str]:
        """Stream a response to user input."""
        self.history.append(HumanMessage(content=user_input))
        
        response_content = ""
        async for chunk in self.llm.astream(self.history):
            if chunk.content:
                response_content += chunk.content
                yield chunk.content
        
        self.history.append(AIMessage(content=response_content))
    
    async def get_response(self, user_input: str) -> str:
        """Get complete response (non-streaming)."""
        full_response = ""
        async for token in self.stream_response(user_input):
            full_response += token
        return full_response
    
    def clear_history(self):
        """Clear conversation history (keep system prompt)."""
        system_messages = [m for m in self.history if isinstance(m, SystemMessage)]
        self.history = system_messages

# Usage
async def demo_chat():
    chat = StreamingChat(system_prompt="You are a friendly assistant.")
    
    print("User: Hello!")
    print("Assistant: ", end="")
    async for token in chat.stream_response("Hello!"):
        print(token, end="", flush=True)
    
    print("\n\nUser: What can you help me with?")
    print("Assistant: ", end="")
    async for token in chat.stream_response("What can you help me with?"):
        print(token, end="", flush=True)

asyncio.run(demo_chat())
```

---

## Error Handling in Streams

### Handling Stream Errors

```python
import asyncio
from langchain_openai import ChatOpenAI
from langchain_core.exceptions import OutputParserException

llm = ChatOpenAI(model="gpt-4o")

async def safe_stream(prompt: str) -> str:
    """Stream with comprehensive error handling."""
    response = ""
    
    try:
        async for chunk in llm.astream(prompt):
            try:
                response += chunk.content
                print(chunk.content, end="", flush=True)
            except AttributeError as e:
                print(f"\n[Chunk processing error: {e}]")
                continue
                
    except Exception as e:
        error_type = type(e).__name__
        print(f"\n[Stream error ({error_type}): {e}]")
        
        # Implement retry logic if needed
        if "rate_limit" in str(e).lower():
            print("[Rate limited - waiting before retry...]")
            await asyncio.sleep(5)
            return await safe_stream(prompt)
        
        raise
    
    return response

asyncio.run(safe_stream("Tell me a joke"))
```

### Stream Recovery Pattern

```python
import asyncio
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(model="gpt-4o")

async def resilient_stream(prompt: str, max_retries: int = 3) -> str:
    """Stream with automatic recovery from failures."""
    
    for attempt in range(max_retries):
        response = ""
        
        try:
            async for chunk in llm.astream(prompt):
                response += chunk.content
                print(chunk.content, end="", flush=True)
            
            return response  # Success
            
        except Exception as e:
            print(f"\n[Attempt {attempt + 1} failed: {e}]")
            
            if attempt < max_retries - 1:
                wait_time = 2 ** attempt  # Exponential backoff
                print(f"[Retrying in {wait_time}s...]")
                await asyncio.sleep(wait_time)
            else:
                print("[Max retries reached]")
                raise

asyncio.run(resilient_stream("Explain quantum computing"))
```

---

## Streaming Flow Diagram

```
                    Async Streaming Architecture
    =====================================================================

    +------------------+
    | Your Application |
    |  (async code)    |
    +--------+---------+
             |
             | async for chunk in llm.astream(prompt)
             v
    +------------------+
    |   LangChain      |
    |   Async Layer    |
    +--------+---------+
             |
             | Async HTTP request (aiohttp/httpx)
             v
    +------------------+
    |   LLM Provider   |
    |   (OpenAI, etc)  |
    +--------+---------+
             |
             | Server-Sent Events (SSE)
             | Content-Type: text/event-stream
             v
    +------------------+
    |   Token Stream   |
    |   data: {"content": "Hello"}
    |   data: {"content": " world"}
    |   data: {"content": "!"}
    |   data: [DONE]
    +------------------+
             |
             | Parsed into AIMessageChunk objects
             v
    +------------------+
    | Your async for   |
    | loop receives    |
    | each chunk       |
    +------------------+


    Event Loop Utilization:
    =======================
    
    Time -->
    
    [Request]--[Wait]--[Chunk1]--[Wait]--[Chunk2]--[Wait]--[Chunk3]--[Done]
                 |                  |                  |
                 v                  v                  v
           [Other tasks]      [Other tasks]      [Other tasks]
           can run here!      can run here!      can run here!
```

---

## Performance Comparison

### stream() vs astream() Benchmarks

```python
import asyncio
import time
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(model="gpt-4o")

def sync_stream_benchmark(prompt: str) -> float:
    """Benchmark synchronous streaming."""
    start = time.perf_counter()
    tokens = 0
    
    for chunk in llm.stream(prompt):
        tokens += 1
    
    elapsed = time.perf_counter() - start
    print(f"Sync: {tokens} chunks in {elapsed:.2f}s")
    return elapsed

async def async_stream_benchmark(prompt: str) -> float:
    """Benchmark asynchronous streaming."""
    start = time.perf_counter()
    tokens = 0
    
    async for chunk in llm.astream(prompt):
        tokens += 1
    
    elapsed = time.perf_counter() - start
    print(f"Async: {tokens} chunks in {elapsed:.2f}s")
    return elapsed

# For single stream, performance is similar
# Async shines with concurrent operations
```

---

## Best Practices

### 1. Always Use flush=True for Terminal Output

```python
# Good - immediate display
for chunk in llm.stream(prompt):
    print(chunk.content, end="", flush=True)

# Bad - may buffer output
for chunk in llm.stream(prompt):
    print(chunk.content, end="")  # Missing flush!
```

### 2. Handle Empty Chunks

```python
async for chunk in llm.astream(prompt):
    if chunk.content:  # Skip empty chunks
        process(chunk.content)
```

### 3. Use Async for Web Applications

```python
# In FastAPI/async web frameworks, always use astream()
from fastapi import FastAPI
from fastapi.responses import StreamingResponse

app = FastAPI()

@app.get("/stream")
async def stream_endpoint(prompt: str):
    async def generate():
        async for chunk in llm.astream(prompt):
            yield chunk.content
    
    return StreamingResponse(generate(), media_type="text/plain")
```

### 4. Accumulate for Post-Processing

```python
async def stream_and_process(prompt: str):
    """Stream to user while accumulating for later processing."""
    full_response = ""
    
    async for chunk in llm.astream(prompt):
        print(chunk.content, end="", flush=True)
        full_response += chunk.content
    
    # Post-processing with complete response
    word_count = len(full_response.split())
    print(f"\n[Word count: {word_count}]")
    
    return full_response
```

---

## Summary

| Feature | stream() | astream() |
|---------|----------|-----------|
| **Execution Model** | Synchronous | Asynchronous |
| **Best For** | Simple scripts, CLI tools | Web apps, concurrent ops |
| **Concurrency** | Blocks thread | Event loop friendly |
| **Syntax** | `for chunk in ...` | `async for chunk in ...` |
| **Context** | Any Python code | Async context required |

---

## Next Steps

Continue to **03_streaming_events.md** to learn about `astream_events()` for getting granular visibility into complex chain execution.
