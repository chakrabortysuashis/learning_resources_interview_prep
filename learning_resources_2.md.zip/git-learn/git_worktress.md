# Git Worktrees - A Complete Guide

## What is a Git Worktree?

A **worktree** is a linked working directory connected to your Git repository. Instead of switching branches in one folder, you get **multiple folders**, each checked out to a different branch - all sharing the same `.git` history.

### The Problem Worktrees Solve

**Without worktrees (traditional approach):**
```
You're working on feature-login...
   |
   v
Boss: "Quick! Fix this bug on main!"
   |
   v
git stash (save your half-done work)
git checkout main
(fix the bug, commit)
git checkout feature-login
git stash pop (restore your work)
   |
   v
Context lost, flow interrupted!
```

**With worktrees:**
```
Working on feature-login in folder A...
   |
   v
Boss: "Quick! Fix this bug on main!"
   |
   v
Just open folder B (which has main)
Fix the bug, commit
Go back to folder A
   |
   v
Your feature-login work is untouched!
```

---

## Visual: How Worktrees Work

```
                    SINGLE GIT REPOSITORY
                    (shared .git folder)
                           |
        +------------------+------------------+
        |                  |                  |
        v                  v                  v
   +---------+        +---------+        +---------+
   | FOLDER  |        | FOLDER  |        | FOLDER  |
   | orches  |        | orches  |        | orches  |
   | _mcpv1  |        | -login  |        | -reports|
   +---------+        +---------+        +---------+
        |                  |                  |
        v                  v                  v
   [main branch]    [feature/login]    [feature/reports]
        |                  |                  |
        +------------------+------------------+
                           |
                    SAME COMMIT HISTORY
                    SAME REMOTES
                    SAME CONFIG
```

**Key Insight:** Each folder is a complete working directory, but they all point to the SAME repository. Commits made in any folder are visible to all others.

---

## Step-by-Step: Creating Worktrees

### Step 1: Start from your main repository

```
Downloads/
    |
    +-- orches_mcpv1/          <-- Your original repo (on main)
            |
            +-- .git/          <-- The actual Git database
            +-- src/
            +-- package.json
            +-- ...
```

### Step 2: Create worktrees for features

```powershell
cd C:\Users\suashischakraborty\Downloads\orches_mcpv1

# Create worktree + new branch in one command
git worktree add -b feature/login ..\orches_mcpv1-login main
git worktree add -b feature/reports ..\orches_mcpv1-reports main
```

**Breaking down the command:**
```
git worktree add -b feature/login ..\orches_mcpv1-login main
                 |        |              |              |
                 |        |              |              +-- Starting point (base branch)
                 |        |              +-- Folder path for the worktree
                 |        +-- Name of the NEW branch to create
                 +-- Flag to create a new branch
```

### Step 3: After creation, your folders look like this

```
Downloads/
    |
    +-- orches_mcpv1/              <-- main branch
    |       |
    |       +-- .git/              <-- REAL Git database lives here
    |       +-- src/
    |       +-- ...
    |
    +-- orches_mcpv1-login/        <-- feature/login branch
    |       |
    |       +-- .git               <-- Just a FILE pointing to main .git
    |       +-- src/
    |       +-- ...
    |
    +-- orches_mcpv1-reports/      <-- feature/reports branch
            |
            +-- .git               <-- Just a FILE pointing to main .git
            +-- src/
            +-- ...
```

**Notice:** In linked worktrees, `.git` is a FILE (not a folder) containing a path like:
```
gitdir: C:/Users/.../orches_mcpv1/.git/worktrees/orches_mcpv1-login
```

---

## Visual: The Development Workflow

```
TIME ------>

main         o---------o---------o---------o---------o (final merged state)
             |                   ^         ^
             |                   |         |
feature/     +---o---o---o-------+         |         (merged!)
login                   (commits)          |
             |                             |
feature/     +-------o-------o-------------+         (merged!)
reports                (commits)


FOLDERS:
=========
[orches_mcpv1]        Working on main, merging features
[orches_mcpv1-login]  Working on login feature
[orches_mcpv1-reports] Working on reports feature
```

---

## Working in Each Worktree

### Open each folder separately (in different terminals/editors)

**Terminal 1 - Login Feature:**
```powershell
cd C:\Users\suashischakraborty\Downloads\orches_mcpv1-login

# Check you're on the right branch
git branch --show-current
# Output: feature/login

# Make changes to files...
# Then commit
git add .
git commit -m "Add login form"
git commit -m "Add authentication logic"
```

**Terminal 2 - Reports Feature:**
```powershell
cd C:\Users\suashischakraborty\Downloads\orches_mcpv1-reports

# Make changes...
git add .
git commit -m "Add reports dashboard"
```

**Visual of what happens:**
```
                    SHARED REPOSITORY
                           |
    +----------------------+----------------------+
    |                      |                      |
    v                      v                      v
[orches_mcpv1]      [orches_mcpv1-login]   [orches_mcpv1-reports]
    |                      |                      |
    | (no changes)         | git commit           | git commit
    |                      |   |                  |   |
    v                      v   v                  v   v
    main               feature/login         feature/reports
    |                      |                      |
    +----------------------+----------------------+
                           |
                    ALL COMMITS GO TO
                    THE SAME REPOSITORY!
```

---

## Merging Worktrees Back to Main

### Step 1: Go to the main worktree

```powershell
cd C:\Users\suashischakraborty\Downloads\orches_mcpv1
git switch main
```

### Step 2: Merge each feature branch

```powershell
# Merge login feature
git merge feature/login

# Merge reports feature  
git merge feature/reports
```

### Visual: The Merge Process

```
BEFORE MERGE:
=============

main:           A---B---C
                         \
feature/login:            D---E---F
                         \
feature/reports:          G---H


AFTER MERGING feature/login:
============================

main:           A---B---C-----------M1 (merge commit)
                         \         /
feature/login:            D---E---F
                         \
feature/reports:          G---H


AFTER MERGING feature/reports:
==============================

main:           A---B---C-----------M1----------M2 (merge commit)
                         \         /           /
feature/login:            D---E---F           /
                         \                   /
feature/reports:          G-----------------H
```

### Step 3: Handle conflicts (if any)

```powershell
# If Git reports conflicts:
# 1. Open the conflicted files
# 2. Look for conflict markers:

<<<<<<< HEAD
your code on main
=======
code from feature branch
>>>>>>> feature/login

# 3. Edit to keep what you want
# 4. Stage and commit
git add .
git commit -m "Resolve merge conflicts"
```

---

## Cleaning Up After Merge

### Step 1: Remove the worktree folders

```powershell
cd C:\Users\suashischakraborty\Downloads\orches_mcpv1

git worktree remove ..\orches_mcpv1-login
git worktree remove ..\orches_mcpv1-reports
```

### Step 2: Delete the branches (optional, if fully merged)

```powershell
git branch -d feature/login
git branch -d feature/reports
```

**Visual: After Cleanup**
```
BEFORE CLEANUP:
===============
Downloads/
    +-- orches_mcpv1/           (main)
    +-- orches_mcpv1-login/     (feature/login)  
    +-- orches_mcpv1-reports/   (feature/reports)


AFTER CLEANUP:
==============
Downloads/
    +-- orches_mcpv1/           (main, with all features merged!)
```

---

## Useful Commands Reference

| Command | Description |
|---------|-------------|
| `git worktree list` | Show all worktrees and their branches |
| `git worktree add <path> <branch>` | Create worktree for existing branch |
| `git worktree add -b <new-branch> <path> <start-point>` | Create worktree with new branch |
| `git worktree remove <path>` | Remove a worktree |
| `git worktree prune` | Clean up stale worktree references |
| `git branch --show-current` | Show current branch in this worktree |

---

## Common Gotchas

### 1. One branch per worktree
A branch can only be checked out in ONE worktree at a time.
```powershell
# This will FAIL if feature/login is already checked out:
git worktree add ..\another-folder feature/login
# Error: 'feature/login' is already checked out at '...'
```

### 2. Dependencies need separate setup
Each worktree is a separate folder, so:
```powershell
cd ..\orches_mcpv1-login
npm install    # Need to install dependencies here too!
```

### 3. Environment files don't copy
`.env` files (usually gitignored) won't exist in new worktrees. Copy them manually:
```powershell
copy ..\orches_mcpv1\.env ..\orches_mcpv1-login\.env
```

---

## Complete Example Workflow

```powershell
# === SETUP ===
cd C:\Users\suashischakraborty\Downloads\orches_mcpv1

# Create worktrees
git worktree add -b feature/login ..\orches_mcpv1-login main
git worktree add -b feature/reports ..\orches_mcpv1-reports main

# Verify
git worktree list
# Output:
# C:/Users/.../orches_mcpv1         abc1234 [main]
# C:/Users/.../orches_mcpv1-login   abc1234 [feature/login]
# C:/Users/.../orches_mcpv1-reports abc1234 [feature/reports]


# === DEVELOP (in separate terminals) ===

# Terminal 1: Work on login
cd ..\orches_mcpv1-login
npm install
# ... make changes ...
git add .
git commit -m "Implement login feature"

# Terminal 2: Work on reports
cd ..\orches_mcpv1-reports
npm install
# ... make changes ...
git add .
git commit -m "Implement reports feature"


# === MERGE ===
cd ..\orches_mcpv1
git switch main
git pull origin main --ff-only    # Get latest from remote

git merge feature/login
git merge feature/reports

# Run tests
npm test

# Push to remote
git push origin main


# === CLEANUP ===
git worktree remove ..\orches_mcpv1-login
git worktree remove ..\orches_mcpv1-reports
git branch -d feature/login
git branch -d feature/reports
```

---

## Summary Visual

```
+------------------------------------------------------------------+
|                        GIT WORKTREES                             |
+------------------------------------------------------------------+
|                                                                  |
|   Traditional Git:          vs.        Git Worktrees:            |
|   ================                     ===============           |
|                                                                  |
|   ONE folder                           MULTIPLE folders          |
|   Switch branches                      Each folder = one branch  |
|   Stash/unstash work                   No stashing needed        |
|   Context switching                    Parallel development      |
|                                                                  |
|   [repo]                               [repo]    [repo-feature1] |
|     |                                    |            |          |
|   main -> feature -> main              main      feature1        |
|   (sequential)                         (parallel!)               |
|                                                                  |
+------------------------------------------------------------------+
```

**Remember:** Worktrees are perfect for:
- Working on multiple features simultaneously
- Quick bug fixes without losing your current work
- Code reviews (checkout PR branch in separate folder)
- Comparing behavior between branches side-by-side
