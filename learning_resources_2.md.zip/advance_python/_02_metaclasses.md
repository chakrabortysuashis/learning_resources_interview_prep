# Metaclasses in Python

## The Big Picture: Classes Creating Objects

Before we dive into metaclasses, let's understand the hierarchy:

```
┌─────────────────────────────────────────────────────────────┐
│                     PYTHON'S CREATION CHAIN                 │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│   metaclass (type)  ──creates──▶  class  ──creates──▶  object
│                                                             │
│   Example:                                                  │
│   type  ──creates──▶  Person  ──creates──▶  alice           │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

**In simple terms:**
- A **class** is a blueprint for creating **objects**
- A **metaclass** is a blueprint for creating **classes**

---

## Everything is an Object in Python

```python
# Numbers are objects
x = 42
print(type(x))  # <class 'int'>

# Strings are objects  
s = "hello"
print(type(s))  # <class 'str'>

# Functions are objects
def foo(): pass
print(type(foo))  # <class 'function'>

# And classes are ALSO objects!
class Person: pass
print(type(Person))  # <class 'type'>  ← A class is an instance of 'type'
```

---

## What is `type`?

`type` has **two uses** in Python:

### Use 1: Check the type of something
```python
print(type(42))        # <class 'int'>
print(type("hello"))   # <class 'str'>
```

### Use 2: Create new classes dynamically
```python
# These two are IDENTICAL:

# Method 1: Normal class definition
class Dog:
    def bark(self):
        return "Woof!"

# Method 2: Using type() to create a class
def bark(self):
    return "Woof!"

Dog = type('Dog', (), {'bark': bark})
```

### Syntax of `type()` for creating classes:
```python
type(name, bases, attrs)
#    │      │      │
#    │      │      └── Dictionary of attributes/methods
#    │      └── Tuple of parent classes (for inheritance)
#    └── Name of the class (string)
```

### Example: Creating Classes Dynamically

```python
# Create a simple class
Animal = type('Animal', (), {'species': 'unknown'})

# Create a class with inheritance
def speak(self):
    return f"I am a {self.name}"

Dog = type('Dog', (Animal,), {'name': 'dog', 'speak': speak})

# Use it like a normal class!
d = Dog()
print(d.species)  # unknown (inherited)
print(d.speak())  # I am a dog
```

---

## So What is a Metaclass?

A **metaclass** is the class of a class. Just like:
- `int` is the type of `42`
- `type` is the type of `int`

```
┌─────────────────────────────────────────────────┐
│              INSTANCE OF RELATIONSHIP           │
├─────────────────────────────────────────────────┤
│                                                 │
│     42  ─── is instance of ───▶  int            │
│                                                 │
│    int  ─── is instance of ───▶  type           │
│                                                 │
│   type  ─── is instance of ───▶  type  (itself!)│
│                                                 │
└─────────────────────────────────────────────────┘
```

```python
print(type(42))          # <class 'int'>
print(type(int))         # <class 'type'>
print(type(type))        # <class 'type'>  ← type is its own metaclass!
```

**`type` is the default metaclass** for all classes in Python.

---

## `__new__` vs `__init__`

Before creating custom metaclasses, we need to understand these two methods:

### `__init__`: Initialize an Instance

```python
class Person:
    def __init__(self, name):
        print(f"__init__ called with name={name}")
        self.name = name

p = Person("Alice")
# Output: __init__ called with name=Alice
```

`__init__` is called **AFTER** the object is created to initialize it.

### `__new__`: Create an Instance

```python
class Person:
    def __new__(cls, name):
        print(f"__new__ called for class {cls}")
        instance = super().__new__(cls)  # Actually create the object
        return instance
    
    def __init__(self, name):
        print(f"__init__ called with name={name}")
        self.name = name

p = Person("Alice")
# Output:
# __new__ called for class <class '__main__.Person'>
# __init__ called with name=Alice
```

### The Creation Flow:

```
Person("Alice") is called
         │
         ▼
┌─────────────────────────────┐
│  __new__(cls, "Alice")      │  ← Creates the object
│  Returns: <Person object>   │
└─────────────────────────────┘
         │
         ▼
┌─────────────────────────────┐
│  __init__(self, "Alice")    │  ← Initializes the object
│  Sets: self.name = "Alice"  │
└─────────────────────────────┘
         │
         ▼
    p = <Person object>
```

### Key Differences:

| Aspect | `__new__` | `__init__` |
|--------|-----------|------------|
| **Purpose** | Create the object | Initialize the object |
| **First argument** | `cls` (the class) | `self` (the instance) |
| **Returns** | Must return the new instance | Returns `None` |
| **When called** | Before `__init__` | After `__new__` |
| **Can prevent creation?** | Yes (return something else) | No |

### Using `__new__` for Singleton Pattern:

```python
class Singleton:
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            print("Creating new instance")
            cls._instance = super().__new__(cls)
        else:
            print("Returning existing instance")
        return cls._instance

s1 = Singleton()  # Creating new instance
s2 = Singleton()  # Returning existing instance
print(s1 is s2)   # True
```

---

## Creating a Custom Metaclass

A metaclass is just a class that inherits from `type`:

```python
class MyMetaclass(type):
    pass

class MyClass(metaclass=MyMetaclass):
    pass

print(type(MyClass))  # <class '__main__.MyMetaclass'>
```

### The Metaclass Creation Flow:

```
class Person(metaclass=MyMeta):
    name = "Unknown"
         │
         ▼
┌─────────────────────────────────────────┐
│  MyMeta.__new__(cls, name, bases, attrs)│
│  │                                      │
│  │  cls = MyMeta                        │
│  │  name = "Person"                     │
│  │  bases = ()                          │
│  │  attrs = {'name': 'Unknown', ...}    │
│  │                                      │
│  └── Returns: <class Person>            │
└─────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────┐
│  MyMeta.__init__(cls, name, bases, attrs)│
│  │                                      │
│  │  cls = <class Person>                │
│  │  Further initialization...           │
│  │                                      │
│  └── Returns: None                      │
└─────────────────────────────────────────┘
         │
         ▼
    Person class is ready to use
```

---

## Practical Metaclass Example 1: Auto-Register Classes

```python
# Registry to keep track of all classes
registry = {}

class RegisterMeta(type):
    def __new__(mcs, name, bases, attrs):
        # Create the class normally
        cls = super().__new__(mcs, name, bases, attrs)
        # Register it (skip the base class itself)
        if name != 'Plugin':
            registry[name] = cls
        return cls

class Plugin(metaclass=RegisterMeta):
    """Base class for all plugins"""
    pass

# These classes are automatically registered!
class PDFPlugin(Plugin):
    def process(self):
        return "Processing PDF"

class ImagePlugin(Plugin):
    def process(self):
        return "Processing Image"

class VideoPlugin(Plugin):
    def process(self):
        return "Processing Video"

# Check the registry
print(registry)
# {'PDFPlugin': <class 'PDFPlugin'>, 
#  'ImagePlugin': <class 'ImagePlugin'>, 
#  'VideoPlugin': <class 'VideoPlugin'>}

# Dynamically use a plugin
plugin_name = "PDFPlugin"
plugin_class = registry[plugin_name]
plugin = plugin_class()
print(plugin.process())  # Processing PDF
```

### Visual: Auto-Registration

```
class PDFPlugin(Plugin): ...
         │
         ▼
┌─────────────────────────────────────┐
│  RegisterMeta.__new__() is called   │
│  │                                  │
│  │  1. Create PDFPlugin class       │
│  │  2. Add to registry              │
│  │     registry["PDFPlugin"] = cls  │
│  │  3. Return the class             │
│  │                                  │
└─────────────────────────────────────┘
         │
         ▼
    PDFPlugin is now registered!
```

---

## Practical Metaclass Example 2: Enforce Method Implementation

```python
class InterfaceMeta(type):
    def __new__(mcs, name, bases, attrs):
        # Create the class
        cls = super().__new__(mcs, name, bases, attrs)
        
        # Skip the abstract base class itself
        if name == 'DatabaseInterface':
            return cls
        
        # Check for required methods
        required_methods = ['connect', 'disconnect', 'execute']
        
        for method in required_methods:
            if method not in attrs:
                raise TypeError(
                    f"Class '{name}' must implement method '{method}'"
                )
        
        return cls

class DatabaseInterface(metaclass=InterfaceMeta):
    """All database classes must implement connect, disconnect, execute"""
    pass

# This will FAIL at class definition time!
# class BadDatabase(DatabaseInterface):
#     def connect(self):
#         pass
#     # Missing disconnect and execute!
# TypeError: Class 'BadDatabase' must implement method 'disconnect'

# This works:
class PostgresDB(DatabaseInterface):
    def connect(self):
        print("Connecting to Postgres...")
    
    def disconnect(self):
        print("Disconnecting...")
    
    def execute(self, query):
        print(f"Executing: {query}")

db = PostgresDB()
db.connect()  # Connecting to Postgres...
```

---

## Practical Metaclass Example 3: Auto-Add Properties

```python
class AutoPropertyMeta(type):
    def __new__(mcs, name, bases, attrs):
        # Find all attributes starting with '_'
        private_attrs = [
            attr for attr in attrs 
            if attr.startswith('_') and not attr.startswith('__')
        ]
        
        # Create properties for each
        for attr in private_attrs:
            prop_name = attr[1:]  # Remove the leading '_'
            
            # Create getter
            def make_getter(attr_name):
                def getter(self):
                    return getattr(self, attr_name)
                return getter
            
            # Create setter
            def make_setter(attr_name):
                def setter(self, value):
                    setattr(self, attr_name, value)
                return setter
            
            attrs[prop_name] = property(
                make_getter(attr),
                make_setter(attr)
            )
        
        return super().__new__(mcs, name, bases, attrs)

class Person(metaclass=AutoPropertyMeta):
    _name = "Unknown"
    _age = 0

p = Person()
print(p.name)  # Unknown  (property auto-created!)
p.name = "Alice"
print(p.name)  # Alice
```

---

## Using `__init__` vs `__new__` in Metaclasses

### `__new__`: Control class creation
```python
class Meta(type):
    def __new__(mcs, name, bases, attrs):
        # Can modify name, bases, or attrs before class is created
        attrs['created_by'] = 'Meta'
        return super().__new__(mcs, name, bases, attrs)
```

### `__init__`: Post-creation setup
```python
class Meta(type):
    def __init__(cls, name, bases, attrs):
        super().__init__(name, bases, attrs)
        # Class already exists, do additional setup
        cls.registry_id = id(cls)
```

### `__call__`: Control instance creation
```python
class Meta(type):
    def __call__(cls, *args, **kwargs):
        print(f"Creating instance of {cls.__name__}")
        instance = super().__call__(*args, **kwargs)
        print(f"Instance created: {instance}")
        return instance

class MyClass(metaclass=Meta):
    def __init__(self, value):
        self.value = value

obj = MyClass(42)
# Output:
# Creating instance of MyClass
# Instance created: <__main__.MyClass object at ...>
```

### Complete Flow:

```
┌─────────────────────────────────────────────────────────────┐
│                    METACLASS LIFECYCLE                      │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  CLASS DEFINITION TIME:                                     │
│  ─────────────────────                                      │
│  class Person(metaclass=Meta):  ...                         │
│         │                                                   │
│         ▼                                                   │
│  Meta.__new__(mcs, 'Person', (), {...})  → Creates class    │
│         │                                                   │
│         ▼                                                   │
│  Meta.__init__(cls, 'Person', (), {...}) → Initializes class│
│                                                             │
│  INSTANCE CREATION TIME:                                    │
│  ───────────────────────                                    │
│  p = Person("Alice")                                        │
│         │                                                   │
│         ▼                                                   │
│  Meta.__call__(cls, "Alice")  → Controls instantiation      │
│         │                                                   │
│         ├──▶ Person.__new__(cls, "Alice")  → Creates object │
│         │                                                   │
│         └──▶ Person.__init__(self, "Alice") → Initializes   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## `__init_subclass__`: A Simpler Alternative

Python 3.6+ provides `__init_subclass__` as a simpler alternative for many metaclass use cases:

```python
class Plugin:
    registry = {}
    
    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        # Register the subclass
        Plugin.registry[cls.__name__] = cls

class PDFPlugin(Plugin):
    pass

class ImagePlugin(Plugin):
    pass

print(Plugin.registry)
# {'PDFPlugin': <class 'PDFPlugin'>, 'ImagePlugin': <class 'ImagePlugin'>}
```

### When to Use Each:

| Use Case | Solution |
|----------|----------|
| Simple subclass tracking | `__init_subclass__` |
| Validate subclass structure | `__init_subclass__` |
| Modify class at creation | Metaclass |
| Control instance creation | Metaclass with `__call__` |
| Apply to classes without inheritance | Metaclass |

---

## Real-World Metaclass: ORM Example

```python
class Field:
    def __init__(self, field_type):
        self.field_type = field_type
        self.name = None

class ModelMeta(type):
    def __new__(mcs, name, bases, attrs):
        # Collect all Field instances
        fields = {}
        for key, value in list(attrs.items()):
            if isinstance(value, Field):
                value.name = key
                fields[key] = value
        
        attrs['_fields'] = fields
        return super().__new__(mcs, name, bases, attrs)

class Model(metaclass=ModelMeta):
    def __init__(self, **kwargs):
        for name, field in self._fields.items():
            value = kwargs.get(name)
            setattr(self, name, value)
    
    def __repr__(self):
        values = ', '.join(
            f"{name}={getattr(self, name)!r}"
            for name in self._fields
        )
        return f"{self.__class__.__name__}({values})"

# Using it like Django/SQLAlchemy!
class User(Model):
    name = Field(str)
    age = Field(int)
    email = Field(str)

user = User(name="Alice", age=30, email="alice@example.com")
print(user)  # User(name='Alice', age=30, email='alice@example.com')
print(User._fields)  # {'name': <Field>, 'age': <Field>, 'email': <Field>}
```

---

## Summary

| Concept | Description |
|---------|-------------|
| **`type`** | The default metaclass; creates all classes |
| **`type(name, bases, attrs)`** | Dynamically create a class |
| **Metaclass** | A class that creates classes (inherits from `type`) |
| **`__new__`** | Creates the object/class |
| **`__init__`** | Initializes the object/class after creation |
| **`__call__`** | Controls how instances are created (in metaclass) |
| **`__init_subclass__`** | Simpler hook for subclass customization |

---

## When to Use Metaclasses

**Use metaclasses when you need to:**
- Automatically register classes
- Enforce interface/method requirements
- Modify class attributes at creation time
- Implement ORMs or DSLs
- Apply decorators to all methods automatically

**Don't use metaclasses when:**
- A simple decorator would work
- `__init_subclass__` is sufficient
- Class methods/properties solve the problem

As Tim Peters (Python core developer) said:
> "Metaclasses are deeper magic than 99% of users should ever worry about."

---

## Quick Reference

```python
# Custom metaclass template
class MyMeta(type):
    def __new__(mcs, name, bases, attrs):
        # Modify attrs, validate, register, etc.
        return super().__new__(mcs, name, bases, attrs)
    
    def __init__(cls, name, bases, attrs):
        # Post-creation setup
        super().__init__(name, bases, attrs)
    
    def __call__(cls, *args, **kwargs):
        # Control instance creation
        return super().__call__(*args, **kwargs)

# Using the metaclass
class MyClass(metaclass=MyMeta):
    pass

# Simpler alternative for subclass hooks
class Base:
    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        # Do something with cls
```
