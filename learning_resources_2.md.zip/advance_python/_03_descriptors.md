# Descriptors in Python

## What is a Descriptor?

A **descriptor** is an object that controls what happens when you **get**, **set**, or **delete** an attribute of another object.

Think of it like a **security guard** for an attribute:

```
┌─────────────────────────────────────────────────────────────┐
│                     ATTRIBUTE ACCESS                        │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│   obj.attribute = value                                     │
│         │                                                   │
│         ▼                                                   │
│   ┌─────────────────────┐                                   │
│   │   DESCRIPTOR        │                                   │
│   │   (Security Guard)  │                                   │
│   │                     │                                   │
│   │   ✓ Validate        │                                   │
│   │   ✓ Transform       │                                   │
│   │   ✓ Log             │                                   │
│   │   ✓ Compute         │                                   │
│   └─────────────────────┘                                   │
│         │                                                   │
│         ▼                                                   │
│   Actual storage                                            │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## The Three Magic Methods

A descriptor is any object that implements at least one of these methods:

| Method | Called When | Purpose |
|--------|-------------|---------|
| `__get__(self, obj, objtype)` | `value = obj.attr` | Get the attribute value |
| `__set__(self, obj, value)` | `obj.attr = value` | Set the attribute value |
| `__delete__(self, obj)` | `del obj.attr` | Delete the attribute |

---

## Types of Descriptors

```
┌─────────────────────────────────────────────────────────────┐
│                    DESCRIPTOR TYPES                         │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  NON-DATA DESCRIPTOR          DATA DESCRIPTOR               │
│  ────────────────────         ───────────────               │
│  Only has __get__             Has __get__ AND               │
│                               __set__ (and/or __delete__)   │
│                                                             │
│  Example: methods             Example: property             │
│                                                             │
│  Lower priority:              Higher priority:              │
│  Instance dict wins           Descriptor wins               │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Your First Descriptor

Let's create a descriptor that ensures a value is always positive:

```python
class PositiveNumber:
    """A descriptor that only allows positive numbers"""
    
    def __init__(self, name):
        self.name = name  # Name of the attribute
    
    def __get__(self, obj, objtype=None):
        if obj is None:
            return self  # Accessed from class, not instance
        return obj.__dict__.get(self.name, 0)
    
    def __set__(self, obj, value):
        if value < 0:
            raise ValueError(f"{self.name} must be positive, got {value}")
        obj.__dict__[self.name] = value
    
    def __delete__(self, obj):
        del obj.__dict__[self.name]


class Product:
    # These are descriptor INSTANCES
    price = PositiveNumber('price')
    quantity = PositiveNumber('quantity')
    
    def __init__(self, name, price, quantity):
        self.name = name
        self.price = price        # Calls PositiveNumber.__set__
        self.quantity = quantity  # Calls PositiveNumber.__set__


# Using it
laptop = Product("Laptop", 999.99, 10)
print(laptop.price)  # 999.99 - Calls PositiveNumber.__get__

laptop.price = 899.99  # OK
print(laptop.price)  # 899.99

laptop.price = -100  # ValueError: price must be positive, got -100
```

### How the Flow Works:

```
laptop.price = 899.99
      │
      ▼
Is 'price' a data descriptor in Product class?
      │
      YES (PositiveNumber has __set__)
      │
      ▼
┌─────────────────────────────────────┐
│  PositiveNumber.__set__(            │
│      self = <PositiveNumber>,       │
│      obj = laptop,                  │
│      value = 899.99                 │
│  )                                  │
│                                     │
│  Validates: 899.99 >= 0 ✓           │
│  Stores: laptop.__dict__['price']   │
│          = 899.99                   │
└─────────────────────────────────────┘
```

---

## Understanding `__get__` Parameters

```python
class Descriptor:
    def __get__(self, obj, objtype=None):
        # obj: The instance (e.g., laptop)
        # objtype: The class (e.g., Product)
        pass
```

### Different Access Scenarios:

```python
class MyDescriptor:
    def __get__(self, obj, objtype=None):
        print(f"obj = {obj}")
        print(f"objtype = {objtype}")
        return "descriptor value"

class MyClass:
    attr = MyDescriptor()

# Scenario 1: Access from instance
instance = MyClass()
value = instance.attr
# obj = <MyClass object>
# objtype = <class 'MyClass'>

# Scenario 2: Access from class
value = MyClass.attr
# obj = None  ← Important! This is how you know it's class access
# objtype = <class 'MyClass'>
```

### Common Pattern: Handle Both Cases

```python
def __get__(self, obj, objtype=None):
    if obj is None:
        # Accessed via class (MyClass.attr)
        return self  # Return the descriptor itself
    # Accessed via instance (instance.attr)
    return obj.__dict__.get(self.name)
```

---

## The Attribute Lookup Chain

When you access `obj.attr`, Python follows this order:

```
┌─────────────────────────────────────────────────────────────┐
│                  ATTRIBUTE LOOKUP ORDER                     │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  obj.attr                                                   │
│      │                                                      │
│      ▼                                                      │
│  1. DATA DESCRIPTOR in class (has __get__ + __set__)        │
│      │                                                      │
│      ▼ (if not found)                                       │
│  2. INSTANCE __dict__ (obj.__dict__['attr'])                │
│      │                                                      │
│      ▼ (if not found)                                       │
│  3. NON-DATA DESCRIPTOR in class (only has __get__)         │
│      │                                                      │
│      ▼ (if not found)                                       │
│  4. CLASS __dict__ (type(obj).__dict__['attr'])             │
│      │                                                      │
│      ▼ (if not found)                                       │
│  5. __getattr__ (if defined)                                │
│      │                                                      │
│      ▼ (if not found)                                       │
│  6. AttributeError                                          │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Why This Matters:

```python
class NonDataDescriptor:
    """Only has __get__, no __set__"""
    def __get__(self, obj, objtype=None):
        return "from descriptor"

class DataDescriptor:
    """Has both __get__ and __set__"""
    def __get__(self, obj, objtype=None):
        return "from descriptor"
    def __set__(self, obj, value):
        pass  # Do nothing

class Example:
    non_data = NonDataDescriptor()
    data = DataDescriptor()

e = Example()

# Non-data descriptor: instance dict CAN override
e.__dict__['non_data'] = "from instance"
print(e.non_data)  # "from instance" ← Instance dict wins!

# Data descriptor: instance dict CANNOT override
e.__dict__['data'] = "from instance"
print(e.data)  # "from descriptor" ← Descriptor wins!
```

---

## How `@property` Works Internally

The `@property` decorator is actually implemented using descriptors!

### Using @property (the easy way):

```python
class Circle:
    def __init__(self, radius):
        self._radius = radius
    
    @property
    def radius(self):
        """Getter"""
        return self._radius
    
    @radius.setter
    def radius(self, value):
        """Setter"""
        if value < 0:
            raise ValueError("Radius must be positive")
        self._radius = value
    
    @property
    def area(self):
        """Read-only property"""
        import math
        return math.pi * self._radius ** 2

c = Circle(5)
print(c.radius)  # 5
c.radius = 10    # OK
print(c.area)    # 314.159...
c.area = 100     # AttributeError: can't set attribute
```

### How Property is Implemented (simplified):

```python
class Property:
    """Simplified implementation of the built-in property"""
    
    def __init__(self, fget=None, fset=None, fdel=None, doc=None):
        self.fget = fget
        self.fset = fset
        self.fdel = fdel
        self.__doc__ = doc
    
    def __get__(self, obj, objtype=None):
        if obj is None:
            return self
        if self.fget is None:
            raise AttributeError("unreadable attribute")
        return self.fget(obj)
    
    def __set__(self, obj, value):
        if self.fset is None:
            raise AttributeError("can't set attribute")
        self.fset(obj, value)
    
    def __delete__(self, obj):
        if self.fdel is None:
            raise AttributeError("can't delete attribute")
        self.fdel(obj)
    
    def setter(self, fset):
        return Property(self.fget, fset, self.fdel, self.__doc__)
    
    def deleter(self, fdel):
        return Property(self.fget, self.fset, fdel, self.__doc__)
```

### Visual: How @property Works

```
@property
def radius(self):
    return self._radius
        │
        ▼
radius = property(fget=<function radius>)
        │
        ▼
radius is now a Property DESCRIPTOR in the class

─────────────────────────────────────────────

@radius.setter
def radius(self, value):
    self._radius = value
        │
        ▼
radius = radius.setter(fset=<function radius>)
        │
        ▼
radius is now a Property with BOTH fget and fset

─────────────────────────────────────────────

circle.radius = 10
        │
        ▼
Property.__set__(self, circle, 10)
        │
        ▼
self.fset(circle, 10)  → calls the setter function
```

---

## Practical Descriptor Examples

### Example 1: Type Validation

```python
class Typed:
    """Descriptor that enforces a specific type"""
    
    def __init__(self, name, expected_type):
        self.name = name
        self.expected_type = expected_type
    
    def __get__(self, obj, objtype=None):
        if obj is None:
            return self
        return obj.__dict__.get(self.name)
    
    def __set__(self, obj, value):
        if not isinstance(value, self.expected_type):
            raise TypeError(
                f"{self.name} must be {self.expected_type.__name__}, "
                f"got {type(value).__name__}"
            )
        obj.__dict__[self.name] = value


class Person:
    name = Typed('name', str)
    age = Typed('age', int)
    
    def __init__(self, name, age):
        self.name = name
        self.age = age


p = Person("Alice", 30)  # OK
p = Person("Bob", "thirty")  # TypeError: age must be int, got str
```

### Example 2: Lazy Property (Computed Once)

```python
class LazyProperty:
    """Compute value once, then cache it"""
    
    def __init__(self, func):
        self.func = func
        self.name = func.__name__
    
    def __get__(self, obj, objtype=None):
        if obj is None:
            return self
        
        # Compute the value
        value = self.func(obj)
        
        # Cache it in the instance dict
        # (This replaces the descriptor for this instance!)
        obj.__dict__[self.name] = value
        
        return value


class DataAnalyzer:
    def __init__(self, data):
        self.data = data
    
    @LazyProperty
    def expensive_computation(self):
        print("Computing... (this only happens once!)")
        import time
        time.sleep(1)  # Simulate expensive work
        return sum(self.data) / len(self.data)


analyzer = DataAnalyzer([1, 2, 3, 4, 5])

print(analyzer.expensive_computation)  # Computing... → 3.0
print(analyzer.expensive_computation)  # 3.0 (instant, cached!)
print(analyzer.expensive_computation)  # 3.0 (instant, cached!)
```

### How LazyProperty Works:

```
First access: analyzer.expensive_computation
      │
      ▼
LazyProperty.__get__ is called
      │
      ▼
Computes value (e.g., 3.0)
      │
      ▼
Stores in instance dict:
analyzer.__dict__['expensive_computation'] = 3.0
      │
      ▼
Returns 3.0

─────────────────────────────────────────────

Second access: analyzer.expensive_computation
      │
      ▼
Python checks instance dict FIRST (non-data descriptor)
      │
      ▼
Finds 'expensive_computation' = 3.0
      │
      ▼
Returns 3.0 directly (descriptor never called!)
```

### Example 3: Value Range Validation

```python
class Range:
    """Descriptor that validates values are within a range"""
    
    def __init__(self, name, min_val=None, max_val=None):
        self.name = name
        self.min_val = min_val
        self.max_val = max_val
    
    def __get__(self, obj, objtype=None):
        if obj is None:
            return self
        return obj.__dict__.get(self.name)
    
    def __set__(self, obj, value):
        if self.min_val is not None and value < self.min_val:
            raise ValueError(f"{self.name} must be >= {self.min_val}")
        if self.max_val is not None and value > self.max_val:
            raise ValueError(f"{self.name} must be <= {self.max_val}")
        obj.__dict__[self.name] = value


class Student:
    grade = Range('grade', min_val=0, max_val=100)
    
    def __init__(self, name, grade):
        self.name = name
        self.grade = grade


s = Student("Alice", 95)   # OK
s.grade = 105              # ValueError: grade must be <= 100
s.grade = -5               # ValueError: grade must be >= 0
```

---

## Using `__set_name__` (Python 3.6+)

Before Python 3.6, you had to pass the attribute name manually:

```python
class MyClass:
    attr = MyDescriptor('attr')  # Redundant! We already wrote 'attr'
```

Python 3.6+ added `__set_name__` to fix this:

```python
class Typed:
    def __set_name__(self, owner, name):
        # Called automatically when the class is created
        # owner = the class (MyClass)
        # name = the attribute name ('attr')
        self.name = name
    
    def __get__(self, obj, objtype=None):
        if obj is None:
            return self
        return obj.__dict__.get(self.name)
    
    def __set__(self, obj, value):
        obj.__dict__[self.name] = value


class Person:
    name = Typed()  # No need to pass 'name' anymore!
    age = Typed()   # __set_name__ sets self.name = 'age' automatically
```

### Visual: `__set_name__` Flow

```
class Person:
    name = Typed()
    age = Typed()
        │
        ▼ (class creation)
        
For each descriptor found:
        │
        ▼
Typed.__set_name__(
    self = <Typed object>,
    owner = <class 'Person'>,
    name = 'name'  ← Python tells the descriptor its name!
)
        │
        ▼
self.name = 'name'  (stored for later use)
```

---

## Methods are Descriptors Too!

Functions implement `__get__`, making them descriptors:

```python
class MyClass:
    def method(self):
        print(f"Called on {self}")

# method is a function
print(type(MyClass.__dict__['method']))  # <class 'function'>

# When accessed via instance, __get__ creates a bound method
obj = MyClass()
print(type(obj.method))  # <class 'method'>

# The function's __get__ binds it to the instance
func = MyClass.__dict__['method']
bound_method = func.__get__(obj, MyClass)
print(bound_method)  # <bound method MyClass.method of <MyClass object>>
```

### How Methods Bind to Instances:

```
obj.method()
      │
      ▼
Python looks up 'method' in class
      │
      ▼
Finds a function (which is a non-data descriptor)
      │
      ▼
Calls function.__get__(obj, MyClass)
      │
      ▼
Returns a "bound method" with self=obj
      │
      ▼
Calls bound_method()  →  method(obj)
```

---

## Summary

| Concept | Description |
|---------|-------------|
| **Descriptor** | Object with `__get__`, `__set__`, or `__delete__` |
| **Data Descriptor** | Has `__get__` AND `__set__`/`__delete__` (higher priority) |
| **Non-Data Descriptor** | Only has `__get__` (lower priority) |
| **`__get__(self, obj, objtype)`** | Called on attribute access |
| **`__set__(self, obj, value)`** | Called on attribute assignment |
| **`__delete__(self, obj)`** | Called on attribute deletion |
| **`__set_name__(self, owner, name)`** | Called when class is created (Python 3.6+) |
| **`property`** | Built-in descriptor for getters/setters |

---

## When to Use Descriptors

**Use descriptors when you need to:**
- Validate attribute values
- Compute attributes lazily (cache expensive operations)
- Log attribute access
- Implement type checking
- Create reusable attribute behaviors across multiple classes

**Use `@property` when:**
- You only need it for one or two attributes
- Simple getter/setter logic

**Use descriptors when:**
- You need the same behavior on many attributes
- You want reusable validation across classes
- You need complex attribute handling logic

---

## Quick Reference

```python
class MyDescriptor:
    """Template for a data descriptor"""
    
    def __set_name__(self, owner, name):
        self.name = name
    
    def __get__(self, obj, objtype=None):
        if obj is None:
            return self
        return obj.__dict__.get(self.name)
    
    def __set__(self, obj, value):
        # Add validation here
        obj.__dict__[self.name] = value
    
    def __delete__(self, obj):
        del obj.__dict__[self.name]


class MyClass:
    attr = MyDescriptor()  # __set_name__ is called automatically
    
    def __init__(self, attr_value):
        self.attr = attr_value  # __set__ is called
```

---

## Practice Exercises

1. **Create a `Readonly` descriptor** that allows setting a value only once.

2. **Create a `Cached` descriptor** that computes a value once and caches it, but allows invalidation.

3. **Create a `Logged` descriptor** that prints a message every time an attribute is accessed or modified.

4. **Create a `Choices` descriptor** that only allows values from a predefined list:
   ```python
   class Order:
       status = Choices('status', ['pending', 'processing', 'shipped', 'delivered'])
   ```
