# Generators and Iterators in Python

## The Big Picture

```
┌─────────────────────────────────────────────────────────────┐
│                  THE ITERATION ECOSYSTEM                    │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ITERABLE         ITERATOR          GENERATOR               │
│  ────────         ────────          ─────────               │
│  Has __iter__     Has __iter__      A type of iterator      │
│                   AND __next__      created with 'yield'    │
│                                                             │
│  Examples:        Examples:         Examples:               │
│  - list           - iter(list)      - generator function    │
│  - string         - file object     - generator expression  │
│  - dict                                                     │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Part 1: Iterables and Iterators

### What is an Iterable?

An **iterable** is anything you can loop over with `for`:

```python
# These are all iterables
for x in [1, 2, 3]:      # list
    print(x)

for char in "hello":      # string
    print(char)

for key in {"a": 1}:      # dict
    print(key)
```

**Technical definition:** An iterable is an object with an `__iter__` method that returns an iterator.

### What is an Iterator?

An **iterator** is an object that:
1. Has a `__next__` method that returns the next value
2. Has a `__iter__` method that returns itself
3. Raises `StopIteration` when exhausted

```python
# Get an iterator from a list
my_list = [1, 2, 3]
my_iterator = iter(my_list)  # Calls my_list.__iter__()

print(next(my_iterator))  # 1  (Calls __next__)
print(next(my_iterator))  # 2
print(next(my_iterator))  # 3
print(next(my_iterator))  # StopIteration exception!
```

### Visual: Iterator Flow

```
my_list = [1, 2, 3]
       │
       │ iter()
       ▼
┌─────────────────┐
│  ITERATOR       │
│  internal: [→1, 2, 3]
└─────────────────┘
       │
       │ next()
       ▼
       1
       │
       │ next()
       ▼
       2
       │
       │ next()
       ▼
       3
       │
       │ next()
       ▼
  StopIteration!
```

### Creating Your Own Iterator

```python
class CountUp:
    """Iterator that counts from start to end"""
    
    def __init__(self, start, end):
        self.current = start
        self.end = end
    
    def __iter__(self):
        return self  # Iterator returns itself
    
    def __next__(self):
        if self.current > self.end:
            raise StopIteration
        value = self.current
        self.current += 1
        return value


# Using it
for num in CountUp(1, 5):
    print(num)
# Output: 1, 2, 3, 4, 5
```

---

## Part 2: Generators

### What is a Generator?

A **generator** is a simpler way to create iterators using the `yield` keyword.

```python
def count_up(start, end):
    """Generator function"""
    current = start
    while current <= end:
        yield current  # Pause and return value
        current += 1


# Using it (same as the iterator!)
for num in count_up(1, 5):
    print(num)
# Output: 1, 2, 3, 4, 5
```

### How `yield` Works

```
┌─────────────────────────────────────────────────────────────┐
│                    yield vs return                          │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  return:                         yield:                     │
│  ───────                         ──────                     │
│  - Ends the function             - PAUSES the function      │
│  - Returns ONE value             - Returns value, remembers │
│  - Forgets state                   state for next call      │
│  - Can't be resumed              - Resumes on next()        │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Visual: Generator Execution

```python
def simple_gen():
    print("Start")
    yield 1
    print("Middle")
    yield 2
    print("End")
    yield 3

gen = simple_gen()  # Creates generator, doesn't run yet!
```

```
gen = simple_gen()
      │
      │ (nothing runs yet!)
      ▼
next(gen)
      │
      ├── print("Start")
      ├── yield 1 ──────────▶ Returns 1, PAUSES HERE
      │
next(gen)
      │
      ├── print("Middle")
      ├── yield 2 ──────────▶ Returns 2, PAUSES HERE
      │
next(gen)
      │
      ├── print("End")
      ├── yield 3 ──────────▶ Returns 3, PAUSES HERE
      │
next(gen)
      │
      └── StopIteration (function ended)
```

---

## Part 3: Generator Expressions

Like list comprehensions, but lazy (computed on demand):

```python
# List comprehension - creates entire list in memory
squares_list = [x**2 for x in range(1000000)]  # 1 million items in memory!

# Generator expression - computes on demand
squares_gen = (x**2 for x in range(1000000))   # Almost no memory used!

# Both can be iterated
for square in squares_gen:
    if square > 100:
        print(square)
        break  # Only computed what we needed!
```

### Memory Comparison

```
┌─────────────────────────────────────────────────────────────┐
│                   MEMORY USAGE                              │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  List comprehension:        Generator expression:           │
│  [x**2 for x in range(n)]   (x**2 for x in range(n))        │
│                                                             │
│  ┌────────────────────┐     ┌────────────────────┐          │
│  │ 0, 1, 4, 9, 16,    │     │ formula + current  │          │
│  │ 25, 36, 49, ...    │     │ position only      │          │
│  │ ALL values stored  │     │                    │          │
│  └────────────────────┘     └────────────────────┘          │
│                                                             │
│  Memory: O(n)               Memory: O(1)                    │
│  (grows with size)          (constant!)                     │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Part 4: `send()` - Two-Way Communication

Generators can receive values, not just produce them!

```python
def accumulator():
    total = 0
    while True:
        value = yield total  # Yields total, receives value
        if value is None:
            break
        total += value


gen = accumulator()

# Start the generator (must call next() or send(None) first!)
print(next(gen))        # 0 (initial total)

print(gen.send(10))     # 10 (total after adding 10)
print(gen.send(5))      # 15 (total after adding 5)
print(gen.send(25))     # 40 (total after adding 25)
```

### Visual: send() Flow

```
gen = accumulator()
      │
      │ next(gen) or gen.send(None)
      ▼
┌─────────────────────────────────────┐
│  total = 0                          │
│  value = yield total ◄── Returns 0  │
│          └─── PAUSED HERE           │
└─────────────────────────────────────┘
      │
      │ gen.send(10)  ← 10 becomes 'value'
      ▼
┌─────────────────────────────────────┐
│  value = 10  (received from send)   │
│  total += value  → total = 10       │
│  value = yield total ◄── Returns 10 │
│          └─── PAUSED HERE           │
└─────────────────────────────────────┘
```

### Practical Use: Running Average

```python
def running_average():
    """Generator that calculates running average"""
    total = 0
    count = 0
    average = None
    
    while True:
        value = yield average
        if value is None:
            break
        total += value
        count += 1
        average = total / count


avg = running_average()
next(avg)  # Start the generator

print(avg.send(10))   # 10.0
print(avg.send(20))   # 15.0 (average of 10, 20)
print(avg.send(30))   # 20.0 (average of 10, 20, 30)
print(avg.send(40))   # 25.0 (average of 10, 20, 30, 40)
```

---

## Part 5: `throw()` - Inject Exceptions

You can inject exceptions into a generator:

```python
def careful_generator():
    try:
        while True:
            value = yield
            print(f"Received: {value}")
    except ValueError as e:
        print(f"Caught ValueError: {e}")
        yield "Error handled!"


gen = careful_generator()
next(gen)  # Start

gen.send("Hello")   # Received: Hello
gen.send("World")   # Received: World

result = gen.throw(ValueError, "Something went wrong")
print(result)  # Error handled!
```

### Use Case: Graceful Shutdown

```python
def worker():
    """Worker that can be gracefully stopped"""
    try:
        while True:
            task = yield
            print(f"Processing: {task}")
    except GeneratorExit:
        print("Cleaning up before exit...")
        # Cleanup code here


w = worker()
next(w)

w.send("Task 1")  # Processing: Task 1
w.send("Task 2")  # Processing: Task 2

w.close()  # Cleaning up before exit...
```

---

## Part 6: `yield from` - Delegation

`yield from` delegates to another iterator:

```python
def chain(*iterables):
    """Yield all items from multiple iterables"""
    for iterable in iterables:
        yield from iterable  # Delegates to each iterable


# Without yield from (verbose):
def chain_old(*iterables):
    for iterable in iterables:
        for item in iterable:
            yield item


# Usage
result = list(chain([1, 2], [3, 4], [5, 6]))
print(result)  # [1, 2, 3, 4, 5, 6]
```

### Recursive Generators with `yield from`

```python
def flatten(nested_list):
    """Flatten a nested list of any depth"""
    for item in nested_list:
        if isinstance(item, list):
            yield from flatten(item)  # Recursive delegation
        else:
            yield item


nested = [1, [2, 3, [4, 5]], 6, [7, [8, [9]]]]
print(list(flatten(nested)))
# [1, 2, 3, 4, 5, 6, 7, 8, 9]
```

### Visual: yield from

```
def outer():
    yield 'A'
    yield from inner()  # Delegate to inner
    yield 'D'

def inner():
    yield 'B'
    yield 'C'

list(outer())  # ['A', 'B', 'C', 'D']

┌─────────────────────────────────────┐
│  outer()                            │
│  ├── yield 'A' ──────────────▶ 'A'  │
│  ├── yield from inner()             │
│  │   ├── yield 'B' ──────────▶ 'B'  │
│  │   └── yield 'C' ──────────▶ 'C'  │
│  └── yield 'D' ──────────────▶ 'D'  │
└─────────────────────────────────────┘
```

---

## Part 7: The `itertools` Module

Python's `itertools` module provides powerful iterator tools.

### Infinite Iterators

```python
from itertools import count, cycle, repeat

# count: Count forever from n
for i in count(10):  # 10, 11, 12, 13, ...
    if i > 15:
        break
    print(i)

# cycle: Cycle through elements forever
colors = cycle(['red', 'green', 'blue'])
for i, color in enumerate(colors):
    if i >= 6:
        break
    print(color)  # red, green, blue, red, green, blue

# repeat: Repeat an element
for x in repeat("Hello", 3):
    print(x)  # Hello, Hello, Hello
```

### Terminating Iterators

```python
from itertools import (
    chain, islice, takewhile, dropwhile,
    filterfalse, compress, accumulate, groupby
)

# chain: Connect multiple iterables
print(list(chain([1, 2], [3, 4])))  # [1, 2, 3, 4]

# islice: Slice an iterator
print(list(islice(range(100), 5, 10)))  # [5, 6, 7, 8, 9]

# takewhile: Take while condition is true
data = [1, 3, 5, 7, 2, 4, 6]
print(list(takewhile(lambda x: x < 6, data)))  # [1, 3, 5]

# dropwhile: Drop while condition is true
print(list(dropwhile(lambda x: x < 6, data)))  # [7, 2, 4, 6]

# filterfalse: Opposite of filter
print(list(filterfalse(lambda x: x % 2, range(10))))  # [0, 2, 4, 6, 8]

# accumulate: Running totals
print(list(accumulate([1, 2, 3, 4, 5])))  # [1, 3, 6, 10, 15]
```

### Combinatoric Iterators

```python
from itertools import permutations, combinations, product

# permutations: All orderings
print(list(permutations('ABC', 2)))
# [('A', 'B'), ('A', 'C'), ('B', 'A'), ('B', 'C'), ('C', 'A'), ('C', 'B')]

# combinations: All selections (order doesn't matter)
print(list(combinations('ABC', 2)))
# [('A', 'B'), ('A', 'C'), ('B', 'C')]

# product: Cartesian product
print(list(product('AB', '12')))
# [('A', '1'), ('A', '2'), ('B', '1'), ('B', '2')]
```

### `groupby`: Group consecutive elements

```python
from itertools import groupby

data = [
    ('Animal', 'Dog'),
    ('Animal', 'Cat'),
    ('Plant', 'Rose'),
    ('Plant', 'Tulip'),
    ('Animal', 'Bird'),
]

# IMPORTANT: Data must be sorted by key first!
sorted_data = sorted(data, key=lambda x: x[0])

for category, group in groupby(sorted_data, key=lambda x: x[0]):
    print(f"{category}: {[item[1] for item in group]}")

# Output:
# Animal: ['Dog', 'Cat', 'Bird']
# Plant: ['Rose', 'Tulip']
```

---

## Part 8: Practical Examples

### Example 1: Reading Large Files Efficiently

```python
def read_large_file(filepath):
    """Read a large file line by line without loading it all"""
    with open(filepath, 'r') as f:
        for line in f:  # File object is already an iterator!
            yield line.strip()


def count_words_in_large_file(filepath):
    """Count total words in a large file"""
    total = 0
    for line in read_large_file(filepath):
        total += len(line.split())
    return total
```

### Example 2: Infinite Fibonacci

```python
def fibonacci():
    """Generate infinite Fibonacci sequence"""
    a, b = 0, 1
    while True:
        yield a
        a, b = b, a + b


# Get first 10 Fibonacci numbers
from itertools import islice
print(list(islice(fibonacci(), 10)))
# [0, 1, 1, 2, 3, 5, 8, 13, 21, 34]
```

### Example 3: Pipeline Processing

```python
def read_data():
    """Simulate reading data from a source"""
    data = [
        "  John, 25  ",
        "  Jane, 30  ",
        "  Bob, 35   ",
    ]
    for line in data:
        yield line

def clean_data(lines):
    """Clean whitespace"""
    for line in lines:
        yield line.strip()

def parse_data(lines):
    """Parse into structured data"""
    for line in lines:
        name, age = line.split(',')
        yield {'name': name.strip(), 'age': int(age)}

def filter_adults(records):
    """Filter people over 28"""
    for record in records:
        if record['age'] > 28:
            yield record


# Create the pipeline (no data processed yet!)
pipeline = filter_adults(
    parse_data(
        clean_data(
            read_data()
        )
    )
)

# Now consume the data
for person in pipeline:
    print(person)
# {'name': 'Jane', 'age': 30}
# {'name': 'Bob', 'age': 35}
```

### Visual: Pipeline

```
┌──────────────┐
│  read_data() │ → yields raw lines
└──────┬───────┘
       │
       ▼
┌──────────────┐
│ clean_data() │ → yields cleaned lines
└──────┬───────┘
       │
       ▼
┌──────────────┐
│ parse_data() │ → yields dicts
└──────┬───────┘
       │
       ▼
┌───────────────┐
│filter_adults()│ → yields filtered dicts
└──────┬────────┘
       │
       ▼
    for loop consumes
```

### Example 4: Coroutine Pattern (Producer-Consumer)

```python
def coroutine(func):
    """Decorator to auto-start coroutines"""
    def wrapper(*args, **kwargs):
        gen = func(*args, **kwargs)
        next(gen)  # Prime the generator
        return gen
    return wrapper

@coroutine
def averager():
    """Coroutine that computes a running average"""
    total = 0.0
    count = 0
    average = None
    
    while True:
        term = yield average
        total += term
        count += 1
        average = total / count


coro = averager()
print(coro.send(10))  # 10.0
print(coro.send(30))  # 20.0
print(coro.send(5))   # 15.0
```

---

## Summary

| Concept | Description |
|---------|-------------|
| **Iterable** | Object with `__iter__()` that returns an iterator |
| **Iterator** | Object with `__next__()` and `__iter__()` |
| **Generator** | Function with `yield`, creates iterator automatically |
| **Generator Expression** | `(x for x in iterable)` - lazy evaluation |
| **`yield`** | Pause and produce a value |
| **`yield from`** | Delegate to another iterator |
| **`send()`** | Send a value INTO a generator |
| **`throw()`** | Inject an exception into a generator |
| **`itertools`** | Standard library for iterator utilities |

---

## Quick Reference

```python
# Basic generator
def my_generator():
    yield 1
    yield 2
    yield 3

# Generator expression
gen_expr = (x**2 for x in range(10))

# Using send()
def receiver():
    while True:
        value = yield
        print(f"Received: {value}")

gen = receiver()
next(gen)  # Prime it
gen.send("hello")

# yield from
def chain(*iterables):
    for it in iterables:
        yield from it

# Key itertools
from itertools import (
    count,          # Infinite counter
    cycle,          # Infinite cycle
    repeat,         # Repeat element
    chain,          # Connect iterables
    islice,         # Slice iterator
    takewhile,      # Take while condition true
    dropwhile,      # Drop while condition true
    groupby,        # Group consecutive elements
    permutations,   # All orderings
    combinations,   # All selections
    product,        # Cartesian product
    accumulate,     # Running totals
)
```

---

## Practice Exercises

1. **Create a generator** `countdown(n)` that counts down from n to 1.

2. **Create a generator** `file_reader(filepath)` that yields lines from a file one at a time.

3. **Create a pipeline** that:
   - Reads numbers from a list
   - Filters even numbers
   - Squares them
   - Takes only the first 5

4. **Create a coroutine** `grep(pattern)` that receives lines and prints ones matching the pattern.

5. **Use itertools** to generate all possible 3-letter combinations from 'ABCD'.
