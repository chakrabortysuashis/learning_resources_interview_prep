# Decorators in Python

## What is a Decorator?

Think of a decorator like a **gift wrapper**. You have a gift (your function), and the wrapper (decorator) adds something extra around it without changing the gift inside.

```
┌─────────────────────────────────────────┐
│           DECORATOR (Wrapper)           │
│  ┌───────────────────────────────────┐  │
│  │                                   │  │
│  │      YOUR ORIGINAL FUNCTION       │  │
│  │                                   │  │
│  └───────────────────────────────────┘  │
│                                         │
│  + Extra behavior before/after          │
└─────────────────────────────────────────┘
```

**In simple terms:** A decorator is a function that takes another function, adds some functionality, and returns it.

---

## Why Do We Need Decorators?

Imagine you have 10 functions and you want to:
- Print "Starting..." before each one runs
- Print "Finished!" after each one completes

**Without decorators:** You'd copy-paste the same code in all 10 functions.

**With decorators:** Write the extra behavior once, apply it to all functions!

---

## Your First Decorator

### Step 1: Understanding Functions as Objects

In Python, functions are like any other object - you can pass them around!

```python
def say_hello():
    print("Hello!")

# Functions can be assigned to variables
greet = say_hello
greet()  # Output: Hello!

# Functions can be passed to other functions
def call_twice(func):
    func()
    func()

call_twice(say_hello)
# Output:
# Hello!
# Hello!
```

### Step 2: A Simple Decorator

```python
def my_decorator(func):
    def wrapper():
        print("🎬 Before the function runs")
        func()  # Call the original function
        print("🎬 After the function runs")
    return wrapper

# Using the decorator
@my_decorator
def say_hello():
    print("Hello, World!")

say_hello()
```

**Output:**
```
🎬 Before the function runs
Hello, World!
🎬 After the function runs
```

### How Does `@my_decorator` Work?

```
┌─────────────────────────────────────────────────────────┐
│  @my_decorator                                          │
│  def say_hello():        IS THE SAME AS:                │
│      print("Hello")                                     │
│                          say_hello = my_decorator(say_hello)
└─────────────────────────────────────────────────────────┘
```

The `@` symbol is just **syntactic sugar** (a shortcut)!

---

## Decorators with Arguments

What if your function takes arguments?

```python
def my_decorator(func):
    def wrapper(*args, **kwargs):  # Accept any arguments
        print("🎬 Before")
        result = func(*args, **kwargs)  # Pass them to original function
        print("🎬 After")
        return result
    return wrapper

@my_decorator
def add(a, b):
    return a + b

result = add(3, 5)
print(f"Result: {result}")
```

**Output:**
```
🎬 Before
🎬 After
Result: 8
```

### Visual Flow:

```
add(3, 5) called
       │
       ▼
┌─────────────────────────┐
│  wrapper(3, 5)          │
│  ├── print "Before"     │
│  ├── func(3, 5) → 8     │  ← Original add() runs here
│  ├── print "After"      │
│  └── return 8           │
└─────────────────────────┘
       │
       ▼
    Result: 8
```

---

## The Problem: Lost Function Identity

```python
def my_decorator(func):
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)
    return wrapper

@my_decorator
def say_hello():
    """This function says hello"""
    print("Hello!")

print(say_hello.__name__)  # Output: wrapper  ← WRONG!
print(say_hello.__doc__)   # Output: None     ← WRONG!
```

The original function's name and docstring are lost!

---

## The Solution: `functools.wraps`

```python
from functools import wraps

def my_decorator(func):
    @wraps(func)  # ← This fixes the problem!
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)
    return wrapper

@my_decorator
def say_hello():
    """This function says hello"""
    print("Hello!")

print(say_hello.__name__)  # Output: say_hello  ← CORRECT!
print(say_hello.__doc__)   # Output: This function says hello  ← CORRECT!
```

### What `@wraps` Does:

```
┌─────────────────────────────────────────────────────────┐
│  Without @wraps:                                        │
│  ┌─────────────┐                                        │
│  │   wrapper   │  ← Lost original identity              │
│  │  __name__   │                                        │
│  │   __doc__   │                                        │
│  └─────────────┘                                        │
│                                                         │
│  With @wraps(func):                                     │
│  ┌─────────────┐     ┌─────────────┐                    │
│  │   wrapper   │ ←── │ say_hello   │  Copies metadata   │
│  │  __name__   │     │ __name__    │                    │
│  │   __doc__   │     │  __doc__    │                    │
│  └─────────────┘     └─────────────┘                    │
└─────────────────────────────────────────────────────────┘
```

**Always use `@wraps` in your decorators!**

---

## Decorator Factory (Decorators with Parameters)

What if you want your decorator to accept arguments?

```python
# Regular decorator: @my_decorator
# Decorator with args: @my_decorator(arg1, arg2)
```

You need a **decorator factory** - a function that creates decorators!

### Example: Repeat Decorator

```python
from functools import wraps

def repeat(times):  # ← This is the factory
    def decorator(func):  # ← This is the actual decorator
        @wraps(func)
        def wrapper(*args, **kwargs):
            for _ in range(times):
                result = func(*args, **kwargs)
            return result
        return wrapper
    return decorator

@repeat(times=3)
def say_hello():
    print("Hello!")

say_hello()
```

**Output:**
```
Hello!
Hello!
Hello!
```

### Visual: Three Layers

```
┌───────────────────────────────────────────────────┐
│  repeat(times=3)                                  │
│  └── Returns: decorator                           │
│       │                                           │
│       ▼                                           │
│       decorator(say_hello)                        │
│       └── Returns: wrapper                        │
│            │                                      │
│            ▼                                      │
│            wrapper() ← This replaces say_hello    │
└───────────────────────────────────────────────────┘
```

### Another Example: Timer with Precision

```python
from functools import wraps
import time

def timer(precision=2):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            start = time.time()
            result = func(*args, **kwargs)
            end = time.time()
            print(f"{func.__name__} took {end - start:.{precision}f} seconds")
            return result
        return wrapper
    return decorator

@timer(precision=4)
def slow_function():
    time.sleep(1)
    print("Done!")

slow_function()
```

**Output:**
```
Done!
slow_function took 1.0012 seconds
```

---

## Class Decorators

Decorators can also be applied to **classes**, not just functions!

### Example 1: Adding Attributes to a Class

```python
def add_greeting(cls):
    cls.greet = lambda self: f"Hello, I am {self.name}"
    return cls

@add_greeting
class Person:
    def __init__(self, name):
        self.name = name

p = Person("Alice")
print(p.greet())  # Output: Hello, I am Alice
```

### Example 2: Singleton Pattern

A **singleton** ensures only ONE instance of a class ever exists.

```python
def singleton(cls):
    instances = {}
    
    def get_instance(*args, **kwargs):
        if cls not in instances:
            instances[cls] = cls(*args, **kwargs)
        return instances[cls]
    
    return get_instance

@singleton
class Database:
    def __init__(self):
        print("Connecting to database...")
        self.connected = True

# First call - creates instance
db1 = Database()  # Output: Connecting to database...

# Second call - returns SAME instance
db2 = Database()  # No output - reuses existing!

print(db1 is db2)  # Output: True (same object!)
```

### Visual: Singleton Pattern

```
First call: Database()
       │
       ▼
┌─────────────────────────┐
│  instances = {}         │
│  Is Database in it? NO  │
│  Create new instance    │
│  instances = {Database: │
│              <obj>}     │
│  Return <obj>           │
└─────────────────────────┘

Second call: Database()
       │
       ▼
┌─────────────────────────┐
│  instances = {Database: │
│              <obj>}     │
│  Is Database in it? YES │
│  Return existing <obj>  │  ← Same object!
└─────────────────────────┘
```

---

## Using a Class as a Decorator

Instead of a function, you can use a **class** as a decorator!

```python
class CountCalls:
    def __init__(self, func):
        self.func = func
        self.count = 0
    
    def __call__(self, *args, **kwargs):
        self.count += 1
        print(f"Call #{self.count}")
        return self.func(*args, **kwargs)

@CountCalls
def say_hello():
    print("Hello!")

say_hello()  # Call #1 \n Hello!
say_hello()  # Call #2 \n Hello!
say_hello()  # Call #3 \n Hello!

print(f"Total calls: {say_hello.count}")  # Total calls: 3
```

### How It Works:

```
@CountCalls
def say_hello(): ...

# Is equivalent to:
say_hello = CountCalls(say_hello)  # say_hello is now a CountCalls object

# When you call say_hello():
say_hello()  # Calls CountCalls.__call__()
```

---

## Stacking Multiple Decorators

You can apply multiple decorators to a single function!

```python
from functools import wraps

def bold(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        return f"<b>{func(*args, **kwargs)}</b>"
    return wrapper

def italic(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        return f"<i>{func(*args, **kwargs)}</i>"
    return wrapper

@bold
@italic
def greet(name):
    return f"Hello, {name}"

print(greet("Alice"))
```

**Output:**
```
<b><i>Hello, Alice</i></b>
```

### Order Matters!

```
@bold
@italic
def greet(name): ...

# Is equivalent to:
greet = bold(italic(greet))

# Execution order (inside out):
# 1. greet("Alice") returns "Hello, Alice"
# 2. italic wraps it: "<i>Hello, Alice</i>"
# 3. bold wraps it: "<b><i>Hello, Alice</i></b>"
```

```
┌──────────────────────────────────────┐
│  @bold (applied second, runs first) │
│  ┌────────────────────────────────┐  │
│  │  @italic (applied first)      │  │
│  │  ┌──────────────────────────┐  │  │
│  │  │  greet("Alice")          │  │  │
│  │  │  → "Hello, Alice"        │  │  │
│  │  └──────────────────────────┘  │  │
│  │  → "<i>Hello, Alice</i>"       │  │
│  └────────────────────────────────┘  │
│  → "<b><i>Hello, Alice</i></b>"      │
└──────────────────────────────────────┘
```

---

## Real-World Decorator Examples

### 1. Logging Decorator

```python
from functools import wraps
import logging

logging.basicConfig(level=logging.INFO)

def log_calls(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        logging.info(f"Calling {func.__name__} with args={args}, kwargs={kwargs}")
        result = func(*args, **kwargs)
        logging.info(f"{func.__name__} returned {result}")
        return result
    return wrapper

@log_calls
def add(a, b):
    return a + b

add(3, 5)
# INFO:root:Calling add with args=(3, 5), kwargs={}
# INFO:root:add returned 8
```

### 2. Retry Decorator

```python
from functools import wraps
import time

def retry(max_attempts=3, delay=1):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            attempts = 0
            while attempts < max_attempts:
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    attempts += 1
                    print(f"Attempt {attempts} failed: {e}")
                    if attempts < max_attempts:
                        time.sleep(delay)
            raise Exception(f"All {max_attempts} attempts failed")
        return wrapper
    return decorator

@retry(max_attempts=3, delay=0.5)
def unreliable_api_call():
    import random
    if random.random() < 0.7:
        raise ConnectionError("Server unavailable")
    return "Success!"
```

### 3. Cache/Memoize Decorator

```python
from functools import wraps

def memoize(func):
    cache = {}
    
    @wraps(func)
    def wrapper(*args):
        if args not in cache:
            cache[args] = func(*args)
        return cache[args]
    
    return wrapper

@memoize
def fibonacci(n):
    if n < 2:
        return n
    return fibonacci(n - 1) + fibonacci(n - 2)

# Without memoize: fibonacci(35) takes ~3 seconds
# With memoize: fibonacci(35) is instant!
print(fibonacci(35))  # 9227465
```

---

## Summary

| Concept | Description |
|---------|-------------|
| **Basic Decorator** | A function that wraps another function |
| **`@wraps`** | Preserves the original function's metadata |
| **Decorator Factory** | A function that returns a decorator (allows passing arguments) |
| **Class Decorator** | A decorator applied to a class |
| **Class as Decorator** | Using `__call__` to make a class work as a decorator |
| **Stacked Decorators** | Multiple decorators applied bottom-up, executed top-down |

---

## Quick Reference

```python
from functools import wraps

# Basic decorator template
def decorator(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        # Before
        result = func(*args, **kwargs)
        # After
        return result
    return wrapper

# Decorator factory template
def decorator_with_args(arg1, arg2):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Use arg1, arg2 here
            result = func(*args, **kwargs)
            return result
        return wrapper
    return decorator

# Usage
@decorator
def my_function(): ...

@decorator_with_args("hello", 42)
def my_other_function(): ...
```

---

## Practice Exercises

1. **Create a `@timer` decorator** that prints how long a function takes to run.

2. **Create a `@validate_positive` decorator** that checks if all numeric arguments are positive.

3. **Create a `@require_auth` decorator factory** that checks if a user has a required role:
   ```python
   @require_auth(role="admin")
   def delete_user(user_id): ...
   ```

4. **Create a `@deprecated` decorator** that prints a warning when a function is used.
