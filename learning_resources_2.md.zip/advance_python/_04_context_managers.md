# Context Managers in Python

## What is a Context Manager?

A **context manager** is like a **responsible assistant** that:
1. Sets things up for you
2. Lets you do your work
3. Cleans up afterward (even if something goes wrong!)

```
┌─────────────────────────────────────────────────────────────┐
│                    CONTEXT MANAGER FLOW                     │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│   with something as x:      ← SETUP happens automatically  │
│       # do your work        ← You work with x              │
│       ...                                                   │
│   # CLEANUP happens automatically (even on error!)          │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Why Do We Need Context Managers?

### The Problem: Forgetting to Clean Up

```python
# BAD: If an error occurs, file might not be closed!
file = open('data.txt', 'r')
data = file.read()
process(data)  # What if this crashes?
file.close()   # This might never run!
```

### The Solution: Using `with`

```python
# GOOD: File is ALWAYS closed, even if an error occurs
with open('data.txt', 'r') as file:
    data = file.read()
    process(data)
# file.close() happens automatically here!
```

---

## The Two Magic Methods

A context manager implements these two methods:

| Method | Called When | Purpose |
|--------|-------------|---------|
| `__enter__(self)` | Entering the `with` block | Setup, returns the resource |
| `__exit__(self, exc_type, exc_val, exc_tb)` | Exiting the `with` block | Cleanup, handle exceptions |

---

## Your First Context Manager

```python
class FileManager:
    def __init__(self, filename, mode):
        self.filename = filename
        self.mode = mode
        self.file = None
    
    def __enter__(self):
        print("📂 Opening file...")
        self.file = open(self.filename, self.mode)
        return self.file  # This becomes 'f' in 'with ... as f'
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        print("📁 Closing file...")
        if self.file:
            self.file.close()
        return False  # Don't suppress exceptions


# Using it
with FileManager('test.txt', 'w') as f:
    f.write("Hello, World!")
# Output:
# 📂 Opening file...
# 📁 Closing file...
```

### Visual Flow:

```
with FileManager('test.txt', 'w') as f:
      │
      │  1. Create FileManager object
      ▼
┌─────────────────────────────────┐
│  __enter__()                    │
│  ├── Opens the file             │
│  └── Returns file object        │
└─────────────────────────────────┘
      │
      │  2. f = returned value
      ▼
┌─────────────────────────────────┐
│  YOUR CODE RUNS HERE            │
│  f.write("Hello, World!")       │
└─────────────────────────────────┘
      │
      │  3. Exiting block (success or error)
      ▼
┌─────────────────────────────────┐
│  __exit__(exc_type, ...)        │
│  ├── Closes the file            │
│  └── Handles any exception      │
└─────────────────────────────────┘
```

---

## Understanding `__exit__` Parameters

```python
def __exit__(self, exc_type, exc_val, exc_tb):
    # exc_type: The exception class (e.g., ValueError)
    # exc_val:  The exception instance (e.g., ValueError("bad value"))
    # exc_tb:   The traceback object
    
    # If no exception occurred, all three are None
    pass
```

### Handling Exceptions in `__exit__`:

```python
class SafeDivision:
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is ZeroDivisionError:
            print("⚠️ Caught division by zero! Handling it...")
            return True  # Suppress the exception
        return False  # Let other exceptions propagate


with SafeDivision():
    result = 10 / 0  # Would normally crash!
    print("This won't print")

print("Program continues!")  # This prints!

# Output:
# ⚠️ Caught division by zero! Handling it...
# Program continues!
```

### Return Values of `__exit__`:

```
┌─────────────────────────────────────────────────────────────┐
│                 __exit__ RETURN VALUES                      │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  return True   → Exception is SUPPRESSED (swallowed)        │
│                  Program continues after the 'with' block   │
│                                                             │
│  return False  → Exception is RE-RAISED (propagated)        │
│  (or None)       Program crashes (unless caught elsewhere)  │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## The `contextlib` Module

Python's `contextlib` module provides utilities for creating context managers more easily.

### 1. `@contextmanager` Decorator

Instead of writing a class, use a generator function:

```python
from contextlib import contextmanager

@contextmanager
def file_manager(filename, mode):
    print("📂 Opening file...")
    file = open(filename, mode)
    
    try:
        yield file  # This is what 'as f' receives
    finally:
        print("📁 Closing file...")
        file.close()


with file_manager('test.txt', 'w') as f:
    f.write("Hello!")
```

### How `@contextmanager` Works:

```
┌─────────────────────────────────────────────────────────────┐
│              @contextmanager STRUCTURE                      │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  @contextmanager                                            │
│  def my_context():                                          │
│      # SETUP CODE (like __enter__)                          │
│      ...                                                    │
│                                                             │
│      try:                                                   │
│          yield value  # 'value' goes to 'as x'              │
│                       # Your code runs here                 │
│      finally:                                               │
│          # CLEANUP CODE (like __exit__)                     │
│          ...                                                │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Example: Timer Context Manager

```python
from contextlib import contextmanager
import time

@contextmanager
def timer(label):
    start = time.time()
    print(f"⏱️ {label}: Starting...")
    
    try:
        yield  # No value needed
    finally:
        elapsed = time.time() - start
        print(f"⏱️ {label}: Finished in {elapsed:.2f} seconds")


with timer("Data Processing"):
    # Simulate work
    time.sleep(1.5)
    print("Processing data...")

# Output:
# ⏱️ Data Processing: Starting...
# Processing data...
# ⏱️ Data Processing: Finished in 1.50 seconds
```

### 2. `contextlib.closing`

For objects that have a `close()` method but aren't context managers:

```python
from contextlib import closing
from urllib.request import urlopen

# urlopen returns an object with close() but no __enter__/__exit__
with closing(urlopen('https://www.example.com')) as page:
    html = page.read()
# page.close() is called automatically
```

### 3. `contextlib.suppress`

Suppress specific exceptions:

```python
from contextlib import suppress
import os

# Instead of try/except to ignore errors:
with suppress(FileNotFoundError):
    os.remove('non_existent_file.txt')
# No error raised, program continues

# This is cleaner than:
try:
    os.remove('non_existent_file.txt')
except FileNotFoundError:
    pass
```

### 4. `contextlib.redirect_stdout`

Capture or redirect output:

```python
from contextlib import redirect_stdout
import io

# Capture print output to a string
buffer = io.StringIO()
with redirect_stdout(buffer):
    print("Hello, World!")
    print("This goes to buffer")

captured = buffer.getvalue()
print(f"Captured: {captured}")
# Captured: Hello, World!
# This goes to buffer
```

### 5. `contextlib.ExitStack`

Manage multiple context managers dynamically:

```python
from contextlib import ExitStack

filenames = ['file1.txt', 'file2.txt', 'file3.txt']

with ExitStack() as stack:
    files = [
        stack.enter_context(open(fname, 'w'))
        for fname in filenames
    ]
    
    # Write to all files
    for i, f in enumerate(files):
        f.write(f"Content for file {i + 1}")

# ALL files are closed automatically!
```

---

## Practical Examples

### Example 1: Database Connection

```python
class DatabaseConnection:
    def __init__(self, host, database):
        self.host = host
        self.database = database
        self.connection = None
    
    def __enter__(self):
        print(f"🔌 Connecting to {self.database}@{self.host}...")
        # In real code: self.connection = db.connect(...)
        self.connection = {"status": "connected"}
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        print("🔌 Closing database connection...")
        # In real code: self.connection.close()
        self.connection = None
        return False
    
    def query(self, sql):
        print(f"📊 Executing: {sql}")
        return [{"id": 1, "name": "Alice"}]


with DatabaseConnection("localhost", "mydb") as db:
    results = db.query("SELECT * FROM users")
    print(results)

# Output:
# 🔌 Connecting to mydb@localhost...
# 📊 Executing: SELECT * FROM users
# [{'id': 1, 'name': 'Alice'}]
# 🔌 Closing database connection...
```

### Example 2: Temporary Directory

```python
from contextlib import contextmanager
import tempfile
import shutil
import os

@contextmanager
def temporary_directory():
    """Create a temp directory and clean it up afterward"""
    path = tempfile.mkdtemp()
    print(f"📁 Created temp dir: {path}")
    
    try:
        yield path
    finally:
        print(f"🗑️ Removing temp dir: {path}")
        shutil.rmtree(path)


with temporary_directory() as tmpdir:
    # Create some files
    filepath = os.path.join(tmpdir, "test.txt")
    with open(filepath, 'w') as f:
        f.write("Temporary data")
    
    print(f"File exists: {os.path.exists(filepath)}")

# After the with block, the directory is gone!
```

### Example 3: Change Directory Temporarily

```python
from contextlib import contextmanager
import os

@contextmanager
def change_directory(new_path):
    """Temporarily change the working directory"""
    original = os.getcwd()
    print(f"📂 Changing to: {new_path}")
    os.chdir(new_path)
    
    try:
        yield
    finally:
        print(f"📂 Returning to: {original}")
        os.chdir(original)


print(f"Current: {os.getcwd()}")

with change_directory("/tmp"):
    print(f"Inside with: {os.getcwd()}")

print(f"After with: {os.getcwd()}")
```

### Example 4: Lock Manager (Thread Safety)

```python
from contextlib import contextmanager
import threading

@contextmanager
def locked(lock):
    """Acquire lock and ensure it's released"""
    print("🔒 Acquiring lock...")
    lock.acquire()
    
    try:
        yield
    finally:
        print("🔓 Releasing lock...")
        lock.release()


my_lock = threading.Lock()

with locked(my_lock):
    print("Critical section - only one thread can be here")
```

---

## Async Context Managers

For asynchronous code, use `__aenter__` and `__aexit__`:

```python
import asyncio

class AsyncDatabaseConnection:
    def __init__(self, host):
        self.host = host
    
    async def __aenter__(self):
        print(f"🔌 Async connecting to {self.host}...")
        await asyncio.sleep(0.5)  # Simulate async connection
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        print("🔌 Async closing connection...")
        await asyncio.sleep(0.1)  # Simulate async cleanup
        return False
    
    async def query(self, sql):
        await asyncio.sleep(0.2)
        return [{"result": "data"}]


async def main():
    async with AsyncDatabaseConnection("db.example.com") as db:
        result = await db.query("SELECT * FROM users")
        print(result)


asyncio.run(main())
```

### Using `@asynccontextmanager`

```python
from contextlib import asynccontextmanager
import asyncio

@asynccontextmanager
async def async_timer(label):
    import time
    start = time.time()
    print(f"⏱️ {label}: Starting...")
    
    try:
        yield
    finally:
        elapsed = time.time() - start
        print(f"⏱️ {label}: Finished in {elapsed:.2f}s")


async def main():
    async with async_timer("Async operation"):
        await asyncio.sleep(1)
        print("Working...")


asyncio.run(main())
```

### Comparison: Sync vs Async

```
┌────────────────────────────────────────────────────────────┐
│              SYNC vs ASYNC CONTEXT MANAGERS                │
├────────────────────────────────────────────────────────────┤
│                                                            │
│  SYNCHRONOUS                    ASYNCHRONOUS               │
│  ───────────                    ────────────               │
│                                                            │
│  __enter__()                    __aenter__()               │
│  __exit__(...)                  __aexit__(...)             │
│                                                            │
│  with ... as x:                 async with ... as x:       │
│      ...                            ...                    │
│                                                            │
│  @contextmanager                @asynccontextmanager       │
│                                                            │
└────────────────────────────────────────────────────────────┘
```

---

## Nested Context Managers

### Multiple `with` statements:

```python
# Method 1: Nested (old style)
with open('input.txt', 'r') as infile:
    with open('output.txt', 'w') as outfile:
        outfile.write(infile.read())

# Method 2: Single line (Python 3.1+)
with open('input.txt', 'r') as infile, open('output.txt', 'w') as outfile:
    outfile.write(infile.read())

# Method 3: Parentheses (Python 3.10+)
with (
    open('input.txt', 'r') as infile,
    open('output.txt', 'w') as outfile,
):
    outfile.write(infile.read())
```

---

## Common Use Cases

| Use Case | Example |
|----------|---------|
| **File operations** | `with open(...) as f:` |
| **Database connections** | `with db.connect() as conn:` |
| **Network connections** | `with socket.create_connection() as sock:` |
| **Locks** | `with threading.Lock():` |
| **Temporary resources** | Temp files, temp directories |
| **Timing code** | Start/stop timer |
| **Changing state** | Change directory, change settings |
| **Transaction management** | Commit on success, rollback on failure |

---

## Summary

| Concept | Description |
|---------|-------------|
| **`with` statement** | Uses a context manager for setup/cleanup |
| **`__enter__`** | Called on entry, returns the resource |
| **`__exit__`** | Called on exit (always!), handles cleanup |
| **`@contextmanager`** | Decorator to create context managers with generators |
| **`async with`** | For async context managers |
| **`__aenter__`/`__aexit__`** | Async versions of enter/exit |
| **`@asynccontextmanager`** | Async version of @contextmanager |

---

## Quick Reference

### Class-based Context Manager:
```python
class MyContext:
    def __enter__(self):
        # Setup
        return resource
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        # Cleanup
        return False  # True to suppress exceptions
```

### Generator-based Context Manager:
```python
from contextlib import contextmanager

@contextmanager
def my_context():
    # Setup
    try:
        yield resource
    finally:
        # Cleanup
```

### Async Context Manager:
```python
from contextlib import asynccontextmanager

@asynccontextmanager
async def my_async_context():
    # Async setup
    try:
        yield resource
    finally:
        # Async cleanup
```

---

## Practice Exercises

1. **Create a `@timer` context manager** that prints how long a block of code takes.

2. **Create an `@indented` context manager** that increases indentation level for nested blocks:
   ```python
   with indented():
       print("Level 1")
       with indented():
           print("Level 2")
   # Output:
   #     Level 1
   #         Level 2
   ```

3. **Create a `@transaction` context manager** for a simple in-memory "database" that rolls back on error.

4. **Create an async context manager** that limits the number of concurrent operations (semaphore).
