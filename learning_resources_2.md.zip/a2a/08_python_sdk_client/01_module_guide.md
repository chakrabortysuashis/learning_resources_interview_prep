# 08 - Build a client with the Python SDK

**Time:** 75-100 minutes. **Prerequisites:** modules 01-07 and the [course setup](../00_start_here.md). You should recognize cards, tasks, artifacts, and streaming events. The notebook explains the Python async syntax it uses.

Think of a student visiting a help desk. The student reads the service menu, chooses a communication method, submits a request, listens for updates, and checks the result. An A2A client performs those steps for software.

By the end, you can discover an Agent Card, select a supported binding, configure the official SDK client, handle both Message and Task responses, collect stream updates, retrieve final task state, and handle errors while closing resources.

## Learning path

1. Open [02_discover_call_and_observe.ipynb](02_discover_call_and_observe.ipynb) and run all cells in order.
2. Discover the public card using A2ACardResolver.
3. Build a client with ClientFactory and ClientConfig.
4. Send a protobuf SendMessageRequest and consume the async iterator.
5. Distinguish StreamResponse payloads using WhichOneof and HasField.
6. Observe streaming updates and confirm persisted output with GetTask.
7. Handle missing tasks, discovery failures, and a simulated transport timeout.
8. Complete three exercises, their worked solutions, and the self-check.

```text
Your Python program
    |
    +-- A2ACardResolver --> Agent Card --> choose compatible interface
    |
    +-- ClientFactory + ClientConfig --> official SDK client
                                            |
                                            +-- send_message --> async iterator
                                            |      Message / Task / updates
                                            +-- get_task -----> Task snapshot
```

## Vocabulary

| Term | Plain meaning |
|---|---|
| Resolver | Fetches and parses a card |
| Factory | Creates a suitable client from a card and configuration |
| Binding | A protocol mapping such as JSONRPC or HTTP+JSON |
| Coroutine | Work that can pause at await while waiting |
| Async iterator | Values produced over time; consumed with async for |
| Async context manager | Opens a resource and closes it even on exceptions |
| StreamResponse | SDK/protocol wrapper with one active payload member |
| Snapshot | State retrieved from the server at query time |
| Timeout | A waiting limit expired; it does not prove the server failed |

## Version and API notes

This module uses specification release **1.0.1**, wire version **1.0**, and **a2a-sdk==1.1.2**. Its domain messages are protobuf-native. Python attributes use snake_case and serialize to camelCase wire fields.

Use `A2ACardResolver`, `ClientFactory`, `ClientConfig`, and protobuf request objects. The official client's `send_message()` produces an async iterator even with `streaming=False`; it normalizes the response into a StreamResponse. Do not await it as though it returns a Task directly. Inspect the active payload before reading a task ID.

Card `version` describes the agent implementation; each supported interface has its own `protocolVersion`. This lesson checks for v1 interfaces and explicitly chooses bindings. The factory normally follows server preference unless configured to prefer the client's order. A retrieved card advertises capabilities; retrieval alone does not authenticate its claims.

## What the lab proves

Real SDK clients make discovery and protocol HTTP requests through real SDK ASGI routes. No live TCP listener, external network, LLM, or API key is used. ASGITransport does not reproduce real network timing or incremental byte delivery. The stream lesson validates event content and order, not internet latency.

One timeout exercise deliberately injects an HTTP transport failure with MockTransport and checks the SDK's exception translation. It is labeled as fault injection, not a real server timing measurement. The stream accumulator handles text Parts for this teaching agent; it is not a universal multimodal renderer.

HTTP clients, official SDK clients, and local server handlers each have cleanup responsibilities. The notebook uses context managers and explicit handler shutdown. In-memory tasks disappear on kernel restart.

## Official references

- [SDK 1.1.2 client API](https://github.com/a2aproject/a2a-python/tree/v1.1.2/src/a2a/client)
- [A2A v1.0.1 specification](https://github.com/a2aproject/A2A/blob/v1.0.1/docs/specification.md)
- [Normative protobuf](https://github.com/a2aproject/A2A/blob/v1.0.1/specification/a2a.proto): SendMessageRequest, StreamResponse, GetTaskRequest.

**Previous:** [07 - Python SDK server](../07_python_sdk_server/01_module_guide.md) | **Next:** [09 - Multi-agent workflows](../09_multi_agent_workflows/01_module_guide.md) | **Course map:** [Outline](../01_course_outline.md)
