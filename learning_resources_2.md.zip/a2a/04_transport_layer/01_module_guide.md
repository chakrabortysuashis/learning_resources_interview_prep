# 04 - Transport layer: how a request reaches an agent

**Time:** about 75 minutes. **Prerequisites:** modules 01-03, [course setup](../00_start_here.md), basic JSON. Open [02_transport_in_practice.ipynb](02_transport_in_practice.ipynb) after reading this guide.

By the end, you will separate an A2A Message from an operation and its transport envelope, compare the three standard bindings, send a real SDK JSON-RPC request, and distinguish an HTTP failure from a protocol error.

## 1. The envelope and the delivery service

Think of sending an assignment to a school office. The worksheet is the content; the envelope identifies the requested service; the delivery system carries it.

A2A uses the same separation. A **Message** describes a communication turn. **SendMessage** is the operation asking an agent to process that turn. A **binding** tells the participants how to represent that operation using a concrete communication system.

```text
Content                 Operation parameters        JSON-RPC envelope
Message + Parts  ----->  SendMessageRequest   ----->  method / id / params
                                                           |
                                                           v
                                                  HTTP POST + headers
                                                           |
                                                           v
                                                   Receiving SDK app
```

The word "transport" is often used broadly for this layer. More precisely, HTTP carries requests, and the A2A binding defines how operations and data map onto it.

## 2. Read HTTP without memorizing a networking textbook

An HTTP request includes a **method** such as GET or POST, a **URL**, **headers**, and sometimes a **body**. A response includes a status code, headers, and potentially a body.

| Piece | School analogy | Example meaning |
|---|---|---|
| Method | Action at the counter | GET retrieves; POST submits an operation |
| URL | Counter address | Where the selected agent interface lives |
| Header | Instruction on the envelope | Body format or requested protocol version |
| Body | Contents | An encoded request or response |
| Status code | Delivery outcome | Whether the HTTP request was handled successfully |

For a JSON-RPC request, `Content-Type: application/json` says how its body is encoded. `Accept: application/json` says which response format the client wants. `A2A-Version: 1.0` identifies the A2A wire protocol version; it is different from `jsonrpc: "2.0"` inside the JSON-RPC envelope.

On a deployed service, HTTPS protects communication in transit. This notebook runs through an in-process ASGI adapter: there is no socket, DNS lookup, or TLS handshake to inspect.

## 3. Compare the three standard bindings

| Binding | How an operation is selected | Ordinary payload | Streaming |
|---|---|---|---|
| JSON-RPC | A method name in a JSON envelope sent to the advertised endpoint | JSON | Server-Sent Events (SSE) |
| HTTP+JSON/REST | HTTP method and resource/action URL | ProtoJSON, with `application/a2a+json` recommended | SSE |
| gRPC | A generated service method | Binary Protocol Buffers | Server streaming RPC |

All three express the same underlying A2A concepts. gRPC adds generated, typed service interfaces and commonly uses HTTP/2. It is not simply JSON sent to a different path. An agent need not advertise every binding; select a supported interface from its Card.

| Operation | JSON-RPC method | HTTP+JSON/REST | gRPC method |
|---|---|---|---|
| Send a message | `SendMessage` | `POST /message:send` | `SendMessage` |
| Stream a message response | `SendStreamingMessage` | `POST /message:stream` | `SendStreamingMessage` |
| Get a task | `GetTask` | `GET /tasks/{id}` | `GetTask` |
| List tasks | `ListTasks` | `GET /tasks` | `ListTasks` |
| Cancel a task | `CancelTask` | `POST /tasks/{id}:cancel` | `CancelTask` |
| Subscribe to task updates | `SubscribeToTask` | `GET /tasks/{id}:subscribe` | `SubscribeToTask` |

These paths are shown without an optional tenant prefix. The subscription GET mapping follows the normative v1.0.1 `a2a.proto`; some prose tables at that release still show POST. The proto is authoritative.

The notebook executes real JSON-RPC and REST requests inside the Python process. Its gRPC section demonstrates protobuf serialization for comparison; it does not start a gRPC service.

## 4. Unpack JSON-RPC

Here is a complete request body for the SendMessage operation:

```json
{
  "jsonrpc": "2.0",
  "id": "request-1",
  "method": "SendMessage",
  "params": {
    "message": {
      "messageId": "b22d20be-aa72-407c-884c-26e25820df9d",
      "role": "ROLE_USER",
      "parts": [{"text": "Make a short study plan."}]
    }
  }
}
```

The outer `id` correlates this RPC request with its response. The nested `messageId` identifies the Message as an A2A data object. They serve different purposes, and neither automatically guarantees exactly-once execution.

The `params` object represents `SendMessageRequest`. A successful JSON-RPC response has `result`; the SendMessage result then contains either `task` or `message`. Other operations have their own result shapes. For example, GetTask returns the Task object itself.

A JSON-RPC error response has `error` instead of `result`. Read the error code, message, and any structured detail rather than treating the presence of valid JSON as success.

## 5. Two places a failure can appear

HTTP and A2A describe different levels of an interaction:

1. The HTTP exchange may fail, for example because a URL is missing or credentials are rejected.
2. An HTTP response may arrive successfully while the JSON-RPC body reports an operation error.
3. A successfully accepted operation may return a Task whose later processing fails.

An HTTP status of 200 is therefore insufficient to prove that the agent completed the job. The notebook demonstrates a valid SendMessage call and a GetTask call for an unknown ID. Both travel through the same actual SDK request handling.

Common JSON-RPC error codes include `-32700` (parse error), `-32600` (invalid request), `-32601` (method not found), `-32602` (invalid parameters), and A2A's `-32001` (task not found). HTTP+JSON/REST and gRPC map the same underlying problems into their own status and detail structures; do not assume negative JSON-RPC codes appear in every binding.

## 6. What the lab really tests

The notebook uses `httpx.AsyncClient` with `httpx.ASGITransport` and a real SDK application assembled by [course_runtime.py](../course_runtime.py).

```text
Notebook HTTP client
       |
       | HTTP method, URL, headers, serialized body
       v
httpx ASGITransport (inside this Python process)
       |
       v
SDK routes -> JSON-RPC decoding -> request handler -> executor
       |
       v
SDK serialization -> HTTP response -> client inspection
```

This is real SDK HTTP integration: routing, message parsing, execution, and response serialization run. It does not test TCP connectivity, proxies, TLS, or internet reachability. The test host name is an in-process address, so the notebook does not connect to a public server.

The helper hides server assembly so you can focus on transport. Module 07 explains that assembly. Every HTTP client is closed with `async with`; no server process or fixed port remains running.

## 7. Learning path and exercises

1. Inspect a Message, operation parameters, and JSON-RPC envelope.
2. Build the SDK app and discover its advertised endpoint.
3. Send an HTTP request through the in-process adapter.
4. Inspect response correlation and the returned Task or Message.
5. Trigger an operation error and a malformed request.
6. Compare equivalent REST and protobuf request representations.
7. Complete three exercises: change RPC correlation, diagnose a missing task, and map an operation into another binding.

The notebook includes worked solutions after the exercises. It also explains expected outputs and includes assertions so an unexpected behavior fails visibly.

## 8. Vocabulary and self-check

**Endpoint:** an interface address. **Envelope:** outer fields carrying an operation and its parameters. **Serialization:** conversion into an exchange format. **ASGI:** a Python interface between asynchronous web servers/adapters and applications. **SSE:** an HTTP response format carrying a sequence of text events.

1. Why are `jsonrpc: "2.0"` and `A2A-Version: 1.0` not contradictory?
2. Can HTTP 200 contain a JSON-RPC error?
3. Does a JSON-RPC endpoint have to be `/rpc`?
4. Does this notebook prove an agent is reachable across the internet?

**Answers:** (1) They name different protocols' versions. (2) Yes; inspect the body. (3) No; use the advertised interface URL. (4) No; the adapter stays in-process.

You can now follow how a data object becomes a request and where to inspect failures. Next, [module 05](../05_tasks_and_conversations/01_module_guide.md) explains the work being tracked after a message arrives.

## References and version notes

Baseline: specification release **1.0.1**, wire version **1.0**, Python SDK **1.1.2**. This SDK uses protobuf-native Python types; protobuf serialization produces the v1 JSON representation.

- [A2A specification v1.0.1](https://github.com/a2aproject/A2A/blob/v1.0.1/docs/specification.md), sections 3.6, 5, 9, 10, and 11.
- [Normative service mappings in a2a.proto](https://github.com/a2aproject/A2A/blob/v1.0.1/specification/a2a.proto).
- [JSON-RPC 2.0 specification](https://www.jsonrpc.org/specification).
- [HTTPX ASGI transport documentation](https://www.python-httpx.org/advanced/transports/#asgi-transport).
- [Course source and compatibility notes](../02_sources_and_versions.md).

**Previous:** [03 - Agent Cards and discovery](../03_agent_cards_and_discovery/01_module_guide.md). **Next:** [05 - tasks and conversations](../05_tasks_and_conversations/01_module_guide.md).

