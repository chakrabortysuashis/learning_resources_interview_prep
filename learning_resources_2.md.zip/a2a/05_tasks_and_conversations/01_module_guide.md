# 05 - Tasks and conversations

**Time:** 75-100 minutes. **Prerequisites:** modules 01-04, Python dictionaries/functions, and the [course setup](../00_start_here.md). Module 04 introduced the JSON-RPC envelopes used here. Server-building details return in module 07.

Imagine ordering a custom school poster. The conversation is your discussion with the print desk. A task is one poster order. The desk can ask for a missing detail, continue the same order when you answer, and later finish or cancel it. A second poster is a new order even if the conversation continues.

By the end, you can distinguish a direct Message from a Task, read task-state families, resume a task needing input, start new work in an existing context, poll an ongoing task, request cancellation, and list tasks across pages.

## Learning path

1. Run [02_task_lifecycles_and_conversations.ipynb](02_task_lifecycles_and_conversations.ipynb) from top to bottom.
2. Compare a direct Message response with a Task containing status and artifacts.
3. Follow a real SDK task from input-required through a follow-up to completion.
4. Keep the context but start a new task after terminal completion.
5. Retrieve snapshots and control history size with GetTask.
6. Use returnImmediately and bounded polling to observe unfinished work.
7. Request cancellation and use a preflight check for completed work.
8. Explore auth-required as a state, then page through ListTasks results.
9. Complete three exercises with worked solutions and a four-question self-check.

```text
One conversation context
  |
  +-- Task A: poster order
  |     submitted -> input required -> working -> completed
  |                       ^
  |                       | client supplies the missing detail
  |
  +-- Task B: another order -> input required -> canceled

These are example paths, not a mandatory or exhaustive transition graph.
```

## Vocabulary

| Term | Meaning |
|---|---|
| Task | Tracked work with an ID, status, and possible artifacts/history |
| Context | Related interactions that can contain several tasks |
| Snapshot | Task information returned at the time of a query |
| Active state | Submitted or working |
| Interrupted state | Input-required or auth-required; outside action is needed |
| Terminal state | Completed, failed, canceled, or rejected |
| Polling | Repeated GetTask calls with waits and a stopping condition |
| Cancellation | A request to stop work; success must be checked |
| History | Retained task messages, not a guaranteed complete transcript |
| Cursor/page token | Opaque continuation value for requesting the next page |

The notebook uses v1 wire names such as `TASK_STATE_INPUT_REQUIRED`. `TASK_STATE_UNSPECIFIED` means unknown/indeterminate; it is not a success state. A2A defines states and operation rules, while the exact work process belongs to the application.

## What is real in this lab?

SendMessage, GetTask, CancelTask, and ListTasks travel through real SDK JSON-RPC routes using `httpx.ASGITransport`. This is actual HTTP request/response handling inside Python, without a live TCP listener, DNS, TLS, or another process. No API keys or external services are needed. A small custom executor supplies predictable classroom behavior. The auth-required branch illustrates the state only; it does not authenticate anyone.

The SDK store is in memory. Restarting the kernel loses tasks. Production needs ownership checks, durable storage, access control, and reliable background execution. Modules 10 and 11 explain these topics.

**Versions:** specification release 1.0.1, wire version 1.0, SDK 1.1.2. SDK Python objects are protobuf-native. SDK 1.1.2 rejects a message to a terminal task with InvalidParams (`-32602`), while the specification names UnsupportedOperation (`-32004`). Its terminal-rejection path also has a resource-cleanup gap. The notebook uses real GetTask preflight checks to avoid deliberately executing that faulty path; this does not replace server validation. The protocol rule remains that terminal tasks cannot accept more messages.

## Rules to remember

- A new client Message may omit task/context IDs. Server Messages must include contextId, and include taskId only when a task exists.
- Answer a clarification with a new messageId and the existing taskId. If providing contextId too, it must match that task.
- After a terminal state, new work requires a new task. Keep contextId for a related conversation and omit taskId.
- Default SendMessage waits for a terminal or interrupted state. `configuration.returnImmediately: true` requests an early response; the client then monitors progress.
- `historyLength: 0` requests no history. Positive values are upper bounds; unset imposes no client limit. Servers may retain or return fewer messages.
- Check the cancellation response. A timeout alone does not prove the task stopped.
- The specification requires nextPageToken, empty on the final page. The pinned SDK may omit an empty token during serialization; the notebook defensively treats that observed omission as empty. Do not interpret tokens.

## Official references

- [A2A v1.0.1 specification](https://github.com/a2aproject/A2A/blob/v1.0.1/docs/specification.md): operations 3.1, configuration/history 3.2, multi-turn interactions 3.4.
- [Normative protobuf](https://github.com/a2aproject/A2A/blob/v1.0.1/specification/a2a.proto): Task, TaskState, GetTaskRequest, ListTasksRequest, CancelTaskRequest.
- [SDK v1.1.2](https://github.com/a2aproject/a2a-python/tree/v1.1.2): request handlers and TaskUpdater.

**Previous:** [04 - Transport layer](../04_transport_layer/01_module_guide.md) | **Next:** [06 - Streaming and notifications](../06_streaming_and_notifications/01_module_guide.md) | **Course map:** [Outline](../01_course_outline.md)
