"""Validate and execute the A2A notebooks with this interpreter in fresh kernels.

Run from any directory: python path/to/a2a/validate_notebooks.py
Optional: --module 04 --write-executed (also refresh checked-in notebook outputs).
"""

from __future__ import annotations

import argparse
import json
import platform
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from importlib.metadata import version
from pathlib import Path

import nbformat
from jupyter_client import KernelManager
from nbclient import NotebookClient

ROOT = Path(__file__).resolve().parent


def run_notebook(path: Path, write_executed: bool) -> dict:
    started = time.monotonic()
    relative = path.relative_to(ROOT)
    result = {"notebook": relative.as_posix(), "passed": False}
    notebook = None
    try:
        notebook = nbformat.read(path, as_version=4)
        nbformat.validate(notebook)
        assert any(cell.cell_type == "code" for cell in notebook.cells), "No code cells"
        # Pin the kernel to the interpreter running this checker. This changes
        # only the in-memory spec, never a user's installed kernelspec files.
        manager = KernelManager(kernel_name="python3")
        manager.kernel_spec.argv = [sys.executable, "-m", "ipykernel_launcher", "-f", "{connection_file}"]
        client = NotebookClient(
            notebook, km=manager, timeout=120, allow_errors=False,
            resources={"metadata": {"path": str(path.parent)}},
        )
        # A final temporary cell makes orphaned coroutine diagnostics visible
        # before the kernel exits. It is never included in the learning files.
        audit = nbformat.v4.new_code_cell(
            "import asyncio as _audit_asyncio\nimport gc as _audit_gc\n"
            "_audit_collected = _audit_gc.collect()\n"
            "await _audit_asyncio.sleep(0.05)\n"
            "_audit_collected = _audit_gc.collect()\n"
            "await _audit_asyncio.sleep(0.05)\n"
        )
        notebook.cells.append(audit)
        try:
            client.execute(cleanup_kc=True)
        finally:
            notebook.cells.remove(audit)
        warning_markers = (
            "Task was destroyed but it is pending", "Failed to detach context",
            "was never awaited",
        )
        diagnostics = []
        for cell in [*notebook.cells, audit]:
            for output in cell.get("outputs", []):
                output_text = output.get("text", "")
                if any(marker in output_text for marker in warning_markers):
                    diagnostics.append(output_text)
        if diagnostics:
            raise AssertionError("Background resource diagnostics: " + "\n".join(diagnostics))
        result.update(
            passed=True,
            cells=len(notebook.cells),
            code_cells=sum(c.cell_type == "code" for c in notebook.cells),
            lifecycle_audit="passed",
        )
        if write_executed:
            nbformat.write(notebook, path)
    except Exception as exc:
        result["error"] = f"{type(exc).__name__}: {exc}"
    finally:
        if notebook is not None:
            output_path = ROOT / ".validation" / relative
            output_path.parent.mkdir(parents=True, exist_ok=True)
            nbformat.write(notebook, output_path)
    result["seconds"] = round(time.monotonic() - started, 2)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--module", help="Only run this folder number, e.g. 04")
    parser.add_argument("--write-executed", action="store_true")
    parser.add_argument("--workers", type=int, default=2)
    args = parser.parse_args()
    if not 1 <= args.workers <= 4:
        parser.error("--workers must be between 1 and 4")
    paths = sorted(ROOT.glob(f"{args.module or '[0-9][0-9]'}_*/*.ipynb"))
    if not paths:
        parser.error("No matching notebooks found")
    report = {
        "checked_at_utc": datetime.now(timezone.utc).isoformat(),
        "python": platform.python_version(),
        "a2a_sdk": version("a2a-sdk"),
        "httpx": version("httpx"),
        "notebooks": [],
    }
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        jobs = {pool.submit(run_notebook, path, args.write_executed): path for path in paths}
        for job in as_completed(jobs):
            result = job.result()
            report["notebooks"].append(result)
            print(f"{'PASS' if result['passed'] else 'FAIL'} {result['notebook']} ({result['seconds']}s)", flush=True)
            if not result["passed"]:
                print(result["error"], flush=True)
    report["notebooks"].sort(key=lambda entry: entry["notebook"])
    report["passed"] = all(entry["passed"] for entry in report["notebooks"])
    report_path = ROOT / ".validation" / (f"report_{args.module}.json" if args.module else "report.json")
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(f"Report: {report_path}", flush=True)
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
