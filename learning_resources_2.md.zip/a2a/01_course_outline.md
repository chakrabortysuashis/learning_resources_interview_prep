# Agent2Agent (A2A): from first principles to a working agent team

Read [00_start_here.md](00_start_here.md) for installation and notebook instructions.

This course is for someone who knows a little Python and has never used A2A. An agent is a program that can carry out a job; our teaching agents use predictable Python rules so you can learn the protocol without buying an AI service. No API keys are required.

**Version baseline:** A2A specification release **1.0.1**, wire protocol version **1.0**, Python package **a2a-sdk==1.1.2**. These version numbers describe different things. Sources and compatibility notes are in [02_sources_and_versions.md](02_sources_and_versions.md).

## Learning path

Follow folders in numerical order. Inside each module, read `01_module_guide.md`, then run its `02_*.ipynb` notebook from top to bottom. Notebook exercises include solutions after the exercise so you can try first. Budget roughly 45–90 minutes per module, with 2–3 hours for the capstone; take longer whenever you need to.

| Module | Topics | What you will make or demonstrate |
|---|---|---|
| [01_introduction](01_introduction/01_module_guide.md) | Agents; interoperability; client/server roles; A2A versus APIs and MCP; Python/JSON/async primer; course architecture | Trace a student request between programs |
| [02_data_layer](02_data_layer/01_module_guide.md) | Message; role; Part; text/raw bytes/URL/structured data; Artifact; IDs; ProtoJSON; metadata | Construct and inspect valid v1 messages and artifacts |
| [03_agent_cards_and_discovery](03_agent_cards_and_discovery/01_module_guide.md) | AgentCard; AgentSkill; capabilities; supportedInterfaces; well-known discovery; extended card; versions; extensions | Read a card and select a suitable skill and interface |
| [04_transport_layer](04_transport_layer/01_module_guide.md) | HTTP; headers; JSON-RPC; HTTP+JSON/REST; gRPC; method mapping; envelopes; errors | Send a real A2A JSON-RPC request through a local SDK app |
| [05_tasks_and_conversations](05_tasks_and_conversations/01_module_guide.md) | Task versus Message; contextId/taskId/messageId; states; input/auth required; polling; cancellation; ListTasks and pagination | Follow a task and continue a conversation |
| [06_streaming_and_notifications](06_streaming_and_notifications/01_module_guide.md) | SSE; StreamResponse; status and artifact events; chunk assembly; SubscribeToTask; push configuration and delivery | Consume ordered updates and assemble an artifact |
| [07_python_sdk_server](07_python_sdk_server/01_module_guide.md) | AgentExecutor; RequestContext; EventQueue; TaskUpdater; request handler; store; app; cancellation | Implement and exercise a working SDK server |
| [08_python_sdk_client](08_python_sdk_client/01_module_guide.md) | Card resolver; client factory/config; messages; task/message results; streaming; errors; resource cleanup | Discover and call the server using the official client |
| [09_multi_agent_workflows](09_multi_agent_workflows/01_module_guide.md) | Coordinator and specialists; routing; sequential/parallel work; correlation; partial failure; application policies | Coordinate two specialist agents through A2A |
| [10_security_and_trust](10_security_and_trust/01_module_guide.md) | TLS; authentication versus authorization; declared schemes versus enforcement; task ownership; untrusted content; signed cards; webhook SSRF | Exercise local authorization and input-boundary checks |
| [11_testing_and_reliability](11_testing_and_reliability/01_module_guide.md) | Schema and integration checks; invalid requests; timeouts; retries; duplicate submissions; persistence; safe logs; deployment checklist | Test success and failure behavior reproducibly |
| [12_capstone_study_team](12_capstone_study_team/01_module_guide.md) | Design; cards; real SDK agents; discovery; coordination; task/artifact output; tests; improvement plan | Build a planner and quiz-maker study team |

## How lessons are taught

Each lesson starts with an everyday analogy, then names the actual protocol component, then shows code and the result. Diagrams use text or locally rendered HTML/SVG so they remain useful without a Mermaid extension or external image host. Examples explicitly distinguish protocol requirements, SDK behavior, and simplified classroom simulations.

The initial modules explain the pieces. The server and client modules put those pieces together. The capstone combines the pieces into one working project. Later notebooks remain independently runnable after installing the shared requirements: you do not need to keep an earlier notebook's kernel alive.

## Checkpoints

1. After module 03, explain the difference between a card, a message, a task and an artifact.
2. After module 06, trace one request from discovery to a finished result, including progress updates.
3. After module 08, build and call a local agent using the SDK.
4. After module 11, explain why an advertised security scheme does not implement security, and why a timeout does not prove a task failed.
5. Finish module 12 and assess your work using its rubric.
