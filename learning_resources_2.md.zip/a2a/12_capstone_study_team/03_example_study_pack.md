# Study pack

Your plan and quiz are ready.

## Fractions

Study budget: 20 minutes.

| Activity | Minutes |
|---|---:|
| Review equal parts and numerator/denominator | 7 |
| Compare halves and quarters with examples | 7 |
| Recall equivalent fractions without notes | 6 |

## Practice quiz

Try the questions before reading the answer key.

1. Which fraction is larger?
   - A. 1/2
   - B. 1/4

2. Which fraction equals 1/2?
   - A. 1/3
   - B. 2/4
   - C. 3/4

3. What does the denominator describe?
   - A. The number of equal parts in the whole
   - B. Only the selected parts

## Answer key

1. **A. 1/2** — One half is two quarters, so it is larger than one quarter.

2. **B. 2/4** — Multiplying numerator and denominator by two gives 2/4.

3. **A. The number of equal parts in the whole** — The denominator counts the equal parts into which the whole is divided.
