# 12 - Capstone: build an A2A study team

Build a small project that a student can actually use: enter a topic and study budget, receive a timed revision plan and a practice quiz, and save a readable study pack. A planner and quiz maker will communicate with a coordinator through real A2A requests.

**Time:** 2-3 hours. **Prerequisites:** modules 01-11, Python functions/dictionaries, `async`/`await`, and the [course environment](../00_start_here.md). Start with [02_build_a_study_team.ipynb](02_build_a_study_team.ipynb), then inspect the generated [03_example_study_pack.md](03_example_study_pack.md).

## What you will build

```text
Student: topic + minutes + number of questions
                         |
                         v
                  Local coordinator
                    |           |
      discovery + A2A send      | application workflow/correlation map
                    v           |
               Planner agent    |
               structured plan -+
                         |
          new A2A message containing that plan
                         v
                  Quiz-maker agent
                  structured quiz
                         |
                         v
            Study pack + separate answer key
            or an honest partial-result report
```

The two topics in the reference project are **fractions** and **photosynthesis**. All content is deterministic, so the project needs no paid services or API keys. The reference implementation is visible in the notebook. Exercises ask you to implement substantive functions before reading their runnable solutions.

## Learning path

1. Agree on the application input, plan and quiz contracts.
2. Implement a plan whose activity minutes exactly match the student's budget.
3. Implement a quiz from a small verified question bank and a validated plan.
4. Wrap those functions in SDK executors that return structured `Part.data` artifacts.
5. Discover each agent and call it through official clients.
6. Implement sequential coordination and per-agent correlation records.
7. Render a complete study pack as Markdown with answers in a separate section.
8. Exercise a failed quiz agent and invalid student input, preserving accurate outcomes.
9. Add a learner improvement and score the project using the rubric.

## Design checklist

- Agent Cards advertise `application/json` inputs and outputs that match actual structured parts.
- Each request/artifact has an application schema label, and required application fields are checked.
- The planner and quiz maker have separate task stores and task/context identifiers.
- The main workflow sends A2A requests; it does not directly call server-side project functions.
- The quiz receives the plan explicitly in a new message, without borrowing the planner's context ID.
- The coordinator distinguishes completed, partial and blocked application outcomes from A2A task states.
- A failed branch supplies no fabricated successful artifact; a transport timeout is not proof of non-execution.
- All HTTP clients, SDK clients and handlers close in context-manager/finally paths.

## Success criteria and rubric

| Area | Points | Evidence |
|---|---:|---|
| Data contracts and plan budget | 4 | Validated structured inputs/outputs; activity minutes sum exactly |
| Real A2A integration | 4 | Both cards discovered and both specialists called with official clients |
| Workflow and correlation | 4 | Plan passed to quiz; each remote task recorded with its owning agent |
| Honest failure handling | 4 | Failed quiz produces a partial pack; invalid input blocks dependent work |
| Useful output and cleanup | 4 | Readable study pack, separate answer key, all resources closed |
| **Total** | **20** | **16+ indicates a solid first project; explain any missing points** |

The notebook includes four exercises with reference solutions, happy-path assertions, a real failed-task scenario, invalid-input checks and a four-question self-check. The generated example study pack is a local file you can edit or share as a learning artifact.

## Boundaries and version choices

This capstone uses **specification v1.0.1**, **wire protocol 1.0** and **a2a-sdk 1.1.2**. Protobuf validates protocol field shapes; project validators enforce the additional application contract. `Part.data` can hold JSON values, but A2A does not automatically understand or validate this project's `schemaVersion` labels.

All discovery and calls use real SDK apps/clients through in-process ASGI HTTP. The project does not start TCP listeners or demonstrate a production deployment. The coordinator is local application code. The shared runtime supplies only already-explained server wiring; the plan, quiz, executor, validators, client calls, coordinator and renderer are shown here.

The demo has in-memory task stores, no external identity provider, and a deliberately small question bank. Agent Card declarations do not enforce authentication or answer correctness. A production version needs the security and reliability policies from modules 10-11. An optional future improvement is to replace a project function with an LLM-backed implementation, while preserving contracts, checks and real A2A calls; the reference project remains deterministic.

## References

- [A2A v1.0.1 specification](https://github.com/a2aproject/A2A/blob/v1.0.1/docs/specification.md)
- [Normative v1.0.1 protocol schema](https://github.com/a2aproject/A2A/blob/v1.0.1/specification/a2a.proto)
- [Python SDK v1.1.2](https://github.com/a2aproject/a2a-python/tree/v1.1.2)
- [ProtoJSON mapping](https://protobuf.dev/programming-guides/json/)
- [Course sources and versions](../02_sources_and_versions.md)

Previous: [11 - Testing and reliability](../11_testing_and_reliability/01_module_guide.md). After finishing, return to the [course outline](../01_course_outline.md) and explain how discovery, data, transport, tasks, security and application policy fit together.
