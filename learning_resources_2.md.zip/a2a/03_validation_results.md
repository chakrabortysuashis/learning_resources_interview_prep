# Course validation results

All **12 notebooks** passed fresh-kernel execution on **2026-09-13**, using **Python 3.13.0** and **a2a-sdk 1.1.2**. The notebooks contain **366 cells**, including **162 code cells**. Executed outputs are saved in the notebooks.

## Results by module

| Module notebook | Total cells | Code cells | Result |
|---|---:|---:|---|
| [01_introduction](01_introduction/02_meet_a2a.ipynb) | 32 | 11 | Passed |
| [02_data_layer](02_data_layer/02_messages_parts_and_artifacts.ipynb) | 29 | 13 | Passed |
| [03_agent_cards_and_discovery](03_agent_cards_and_discovery/02_reading_and_discovering_agents.ipynb) | 30 | 13 | Passed |
| [04_transport_layer](04_transport_layer/02_transport_in_practice.ipynb) | 32 | 14 | Passed |
| [05_tasks_and_conversations](05_tasks_and_conversations/02_task_lifecycles_and_conversations.ipynb) | 31 | 15 | Passed |
| [06_streaming_and_notifications](06_streaming_and_notifications/02_streaming_and_notifications.ipynb) | 30 | 14 | Passed |
| [07_python_sdk_server](07_python_sdk_server/02_build_an_sdk_server.ipynb) | 32 | 14 | Passed |
| [08_python_sdk_client](08_python_sdk_client/02_discover_call_and_observe.ipynb) | 29 | 14 | Passed |
| [09_multi_agent_workflows](09_multi_agent_workflows/02_coordinating_specialists.ipynb) | 31 | 14 | Passed |
| [10_security_and_trust](10_security_and_trust/02_security_boundaries.ipynb) | 32 | 13 | Passed |
| [11_testing_and_reliability](11_testing_and_reliability/02_test_failures_and_recovery.ipynb) | 28 | 13 | Passed |
| [12_capstone_study_team](12_capstone_study_team/02_build_a_study_team.ipynb) | 30 | 14 | Passed |

## What was checked

- Notebook format and cell identifiers; each notebook ran from its own module directory in an independent kernel.
- Every code cell, including worked solutions and embedded assertions; no failures were skipped.
- Temporary garbage-collection and event-loop checks after the lesson; no pending-task, unawaited-coroutine or telemetry-context cleanup diagnostics remained.
- Sequential module/file numbering, local navigation links and UTF-8 text.
- Dependency compatibility: `pip check` reported no broken requirements.
- Separate real localhost TCP checks: agent discovery, completed JSON-RPC task, SSE delivery, server shutdown and SDK handler cleanup through the application lifespan.
- The generated capstone handout, including activity durations, questions and a separate answer key.

The last checker's machine-readable output is [report.json](.validation/report.json). Its execution copies are in the ignored `.validation` folder; future checker runs refresh them. The permanent learning notebooks also contain their successful outputs.

## Reproduce notebook validation

From the `a2a` directory, after following [setup](00_start_here.md):

```powershell
.\.venv\Scripts\python.exe validate_notebooks.py
```

On macOS/Linux use `.venv/bin/python validate_notebooks.py`. To refresh outputs in the learning notebooks as well, add `--write-executed`. To check one module, add `--module 05`. The checker uses the Python interpreter you launch it with and closes its kernels afterward. The capstone regenerates its documented example Markdown handout.

## Limits of this evidence

These checks validate the included lessons and local reference implementation. They do not certify complete A2A conformance or production deployment behavior. The course distinguishes live SDK integration, classroom simulations and client preflight examples. Read [sources and known SDK differences](02_sources_and_versions.md) for the pinned library's rejection-path cleanup and serialization limitations.
