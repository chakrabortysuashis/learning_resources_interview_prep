# 06 - Streaming and notifications

When you order food, you can keep asking whether it is ready, watch a live order board, or receive a notification. A2A offers similar choices: polling, streaming and push notifications. They all report work; they differ in how updates reach the client.

**Time:** 75-90 minutes. **Prerequisites:** [module 05: tasks and conversations](../05_tasks_and_conversations/01_module_guide.md), Python dictionaries, and the idea of `await`. Follow [course setup](../00_start_here.md), then run [02_streaming_and_notifications.ipynb](02_streaming_and_notifications.ipynb) from top to bottom in a fresh kernel.

By the end, you will distinguish status changes from output chunks, inspect real SDK SSE responses, assemble a text artifact, recover a task snapshot, explain `SubscribeToTask`, and process a local webhook update with explicit checks.

## Learning path

1. Compare polling, SSE and webhooks using a restaurant analogy.
2. Build a small streaming executor with the shared course runtime and the official SDK.
3. Send `SendStreamingMessage`, inspect SSE framing and identify v1 `StreamResponse` variants.
4. Assemble artifact chunks using `artifactId`, `append` and `lastChunk`.
5. Use `GetTask` for a current snapshot; distinguish subscription from replay.
6. Read push-configuration fields and the create/get/list/delete operations.
7. Deliver a `StreamResponse` to a local webhook and check authentication, task identity and duplicate handling.
8. Complete three exercises and a four-question self-check.

```text
POLLING       client -- GetTask --> agent
              client <-- snapshot -- agent      (repeat as needed)

STREAMING     client -- request --> agent
              client <-- task ---------------- agent
              client <-- statusUpdate -------- agent
              client <-- artifactUpdate ------ agent
              client <-- statusUpdate -------- agent

PUSH          agent -- HTTP POST --> client's webhook
              agent <-- HTTP 2xx -- client's webhook
```

## Vocabulary

| Term | Meaning |
|---|---|
| SSE | Server-sent events: a text event stream carried by an HTTP response |
| `StreamResponse` | A wrapper containing one task, message, status update or artifact update |
| Status update | A change in the task's processing state |
| Artifact update | A piece of task output, possibly appended to earlier output |
| `append` | Append to the previously sent artifact with the same ID when true |
| `lastChunk` | This is the final chunk of that artifact; it does not complete the task |
| Subscription | A stream for an existing, nonterminal task |
| Webhook | An HTTP endpoint that receives an agent's notification |
| Idempotent processing | Receiving a duplicate does not repeat the business effect |

## Boundaries of the lab

The notebook uses **specification release v1.0.1**, **wire version 1.0** and **a2a-sdk 1.1.2**. The SDK uses protobuf objects; Python attributes use snake case and `MessageToDict` produces v1 camel-case JSON. V1 stream variants are identified by their member names. There is no v1 `kind` discriminator or `final` status-event flag.

The streaming request is **real official-SDK HTTP integration through an in-process ASGI transport**. It opens no TCP listener. HTTPX's ASGI transport buffers the response, so the notebook verifies event shape and order, not live arrival times, network disconnect handling, proxy buffering or backpressure.

The push-configuration dictionary is a clearly labeled classroom simulation. The local webhook is an actual Starlette HTTP route called through ASGI, but the delivery is manually driven by the notebook; no background SDK push sender or internet endpoint is involved. The receiver deliberately accepts status updates for one known task. Its fixed demo credential and in-memory status map are teaching devices, not a production authentication service or durable delivery system.

Streaming and push are optional capabilities. Advertising them does not implement them. A production webhook requires destination validation on the sender, source authentication and authorization on the receiver, suitable timeouts and durable duplicate handling. A2A requires a delivery attempt and allows retries; it does not guarantee every notification will be received exactly once.

## Expected observations

The producer emits an initial task, a working status, three artifact chunks, and a completed status. Your assembled artifact reads `One half means one of two equal parts.` A `GetTask` snapshot agrees. The client uses that completed snapshot to avoid sending a subscription request; it constructs and schema-checks the request shape without submitting it. A local webhook accepts a known task with the classroom credential and rejects an invalid credential or unrelated task.

## References

- [A2A v1.0.1 specification](https://github.com/a2aproject/A2A/blob/v1.0.1/docs/specification.md): sections 3.1.2, 3.1.6, 4.2, 4.3.3 and 13.2
- [Normative v1.0.1 protocol schema](https://github.com/a2aproject/A2A/blob/v1.0.1/specification/a2a.proto): `StreamResponse`, `TaskArtifactUpdateEvent`, `TaskPushNotificationConfig`
- [Python SDK v1.1.2](https://github.com/a2aproject/a2a-python/tree/v1.1.2)
- [SSE event-stream interpretation](https://html.spec.whatwg.org/multipage/server-sent-events.html#event-stream-interpretation)
- [Course versions and sources](../02_sources_and_versions.md)

Previous: [05 - Tasks and conversations](../05_tasks_and_conversations/01_module_guide.md). Next: [07 - Python SDK server](../07_python_sdk_server/01_module_guide.md).

## SDK subscription-lab limitation

The subscription example constructs a valid SubscribeToTask request and uses a real GetTask snapshot to decide whether to send it. It does not issue a live terminal-task subscription: SDK 1.1.2 can leave background queues unclosed on that rejection path. This client preflight is not a server authorization or race-prevention guarantee. The notebook still executes real SendStreamingMessage, GetTask, and local webhook HTTP calls.
