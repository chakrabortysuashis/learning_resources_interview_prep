"""Small, readable building blocks for the A2A course (SDK 1.1.2).

This is course code, not part of the A2A standard. It creates real SDK routes.
Each build_agent() call gets an independent in-memory task store. There are no
API keys, global server threads, automatic downloads, or open listening ports.
"""

from __future__ import annotations

import inspect
from collections.abc import Awaitable, Callable
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import Any
from uuid import uuid4

from google.protobuf.json_format import MessageToDict
from google.protobuf.message import Message as ProtoMessage
from starlette.applications import Starlette

from a2a.helpers.proto_helpers import new_task_from_user_message
from a2a.server.agent_execution import AgentExecutor, RequestContext
from a2a.server.events import EventQueue
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.routes import create_agent_card_routes, create_jsonrpc_routes, create_rest_routes
from a2a.server.tasks import InMemoryTaskStore, TaskUpdater
from a2a.types import AgentCapabilities, AgentCard, AgentInterface, AgentSkill, Message, Part, Role

PROTOCOL_VERSION = "1.0"
Responder = Callable[[str], str | Awaitable[str]]


def user_message(text: str, *, context_id: str = "", task_id: str = "") -> Message:
    """Build a new protobuf user message; IDs are not retry guarantees."""
    return Message(
        message_id=str(uuid4()), role=Role.ROLE_USER,
        parts=[Part(text=text)], context_id=context_id, task_id=task_id,
    )


def rpc_request(method: str, params: dict | ProtoMessage, *, request_id: str | int = "lesson-1") -> dict:
    """Wrap v1 parameters in JSON-RPC. The HTTP A2A-Version header is separate."""
    return {
        "jsonrpc": "2.0", "id": request_id, "method": method,
        "params": MessageToDict(params) if isinstance(params, ProtoMessage) else params,
    }


class StudyExecutor(AgentExecutor):
    """Publish a task, progress, one text artifact, and completion.

    The responder is ordinary application logic. The SDK transports its result.
    It can be synchronous or async, but must return a string. Inputs and outputs
    are intentionally small; this classroom helper is not a deployment template.
    """

    def __init__(self, responder: Responder | None = None):
        self.responder = responder or (lambda text: f"Study helper received: {text}")

    async def execute(self, context: RequestContext, event_queue: EventQueue) -> None:
        if context.message is None:
            raise ValueError("A message is required")
        if context.current_task is None:
            await event_queue.enqueue_event(new_task_from_user_message(context.message))
        updater = TaskUpdater(event_queue, context.task_id, context.context_id)
        await updater.start_work()
        result = self.responder(context.get_user_input())
        if inspect.isawaitable(result):
            result = await result
        if not isinstance(result, str):
            raise TypeError("The course responder must return text")
        await updater.add_artifact(
            [Part(text=result)], name="study-result", last_chunk=True,
        )
        await updater.complete()

    async def cancel(self, context: RequestContext, event_queue: EventQueue) -> None:
        await TaskUpdater(event_queue, context.task_id, context.context_id).cancel()


@dataclass
class AgentBundle:
    """App and its pieces. In ASGI labs, finish with await bundle.handler.aclose()."""

    app: Starlette
    card: AgentCard
    store: InMemoryTaskStore
    handler: DefaultRequestHandler
    executor: AgentExecutor
    base_url: str


def build_agent(
    *, name: str = "Study helper", skill_id: str = "study",
    responder: Responder | None = None, executor: AgentExecutor | None = None,
    streaming: bool = True, base_url: str = "http://study.local",
    include_rest: bool = False,
) -> AgentBundle:
    """Create a fresh local SDK agent with JSON-RPC at /rpc and public discovery.

    Supply either a responder or your own executor. No authentication is enabled;
    module 10 demonstrates enforcement separately. The HTTP scheme is for local
    learning only. A deployed interface must use HTTPS.
    """
    if responder is not None and executor is not None:
        raise ValueError("Choose responder or executor, not both")
    base_url = base_url.rstrip("/")
    interfaces = [AgentInterface(
        url=base_url + "/rpc", protocol_binding="JSONRPC", protocol_version=PROTOCOL_VERSION,
    )]
    if include_rest:
        interfaces.append(AgentInterface(
            url=base_url, protocol_binding="HTTP+JSON", protocol_version=PROTOCOL_VERSION,
        ))
    card = AgentCard(
        name=name, description=f"A local teaching agent: {name}.", version="1.0.0",
        supported_interfaces=interfaces,
        capabilities=AgentCapabilities(streaming=streaming),
        default_input_modes=["text/plain"], default_output_modes=["text/plain"],
        skills=[AgentSkill(
            id=skill_id, name=name, description="Respond to a short study request.",
            tags=["study", skill_id], examples=["Help me revise fractions"],
        )],
    )
    actual_executor = executor or StudyExecutor(responder)
    store = InMemoryTaskStore()
    handler = DefaultRequestHandler(agent_executor=actual_executor, task_store=store, agent_card=card)
    routes = create_agent_card_routes(card) + create_jsonrpc_routes(handler, rpc_url="/rpc")
    if include_rest:
        routes += create_rest_routes(handler)
    @asynccontextmanager
    async def lifespan(app: Starlette):
        # Uvicorn runs this lifecycle. HTTPX ASGITransport does not: notebook
        # callers explicitly close the handler after their HTTP clients finish.
        try:
            yield
        finally:
            await handler.aclose()

    app = Starlette(routes=routes, lifespan=lifespan)
    return AgentBundle(app, card, store, handler, actual_executor, base_url)


def create_demo_app() -> Starlette:
    """Uvicorn factory: python -m uvicorn course_runtime:create_demo_app --factory."""
    return build_agent(base_url="http://127.0.0.1:8000").app


def task_text(task: Any) -> str:
    """Join text artifact parts from a protobuf Task, without executing content."""
    return "\n".join(
        part.text for artifact in task.artifacts for part in artifact.parts if part.HasField("text")
    )
