# Sources and version choices

Checked on **2026-09-13** against the official A2A project and Python package index.

| Item | Course baseline | Meaning |
|---|---|---|
| A2A specification release | **v1.0.1** | The published protocol document release |
| A2A wire version | **1.0** | Major/minor value advertised per interface and sent in `A2A-Version` |
| Python SDK | **a2a-sdk==1.1.2** | Python library release; its version is independent of the protocol version |
| Python used for validation | **3.13.0** | Interpreter used to execute the course notebooks |

Install the pinned course requirements before running the labs. A newer SDK can change its Python API even when it supports the same wire protocol.

## Primary references

- [A2A v1.0.1 release](https://github.com/a2aproject/A2A/releases/tag/v1.0.1)
- [Versioned specification source](https://github.com/a2aproject/A2A/blob/v1.0.1/docs/specification.md)
- [Normative v1.0.1 protocol definitions, a2a.proto](https://github.com/a2aproject/A2A/blob/v1.0.1/specification/a2a.proto)
- [Rendered specification](https://a2a-protocol.org/latest/specification/) — convenient to read, but `latest` can change after this course was written.
- [What changed in v1](https://github.com/a2aproject/A2A/blob/v1.0.1/docs/whats-new-v1.md)
- [Python SDK v1.1.2 source and compatibility information](https://github.com/a2aproject/a2a-python/tree/v1.1.2)
- [Python SDK 1.1.2 package](https://pypi.org/project/a2a-sdk/1.1.2/)
- [ProtoJSON mapping](https://protobuf.dev/programming-guides/json/)
- [JSON-RPC 2.0](https://www.jsonrpc.org/specification)
- [Server-sent event format](https://html.spec.whatwg.org/multipage/server-sent-events.html)

The specification source contains generated-table placeholders. Use the normative `.proto` definitions to inspect fields and required annotations when a table is missing. Migration prose and examples can contain older details; the current normative definition takes precedence.

## Avoid mixing v0.3 and v1 examples

| Concept | Older v0.3 example | This course's v1 wire representation |
|---|---|---|
| JSON-RPC send method | `message/send` | `SendMessage` |
| Message role | `user` | `ROLE_USER` |
| Task state | `working` | `TASK_STATE_WORKING` |
| Text part | `{"kind":"text","text":"Hi"}` | `{"text":"Hi"}` |
| File part | Nested `file` object | `raw` (base64) or `url`, with optional `mediaType` and `filename` |
| Agent interfaces | Top-level `url`, `preferredTransport`, `additionalInterfaces` | `supportedInterfaces` entries with `url`, `protocolBinding`, `protocolVersion` |
| Extended-card support | `supportsAuthenticatedExtendedCard` | `capabilities.extendedAgentCard` |
| Send response | Direct task/message result | Result contains a `task` or `message` member |
| Stream event discriminator | `kind`, sometimes `final` | `task`, `message`, `statusUpdate` or `artifactUpdate` member; stream closure has binding-specific semantics |

JSON uses lower camel case, such as `messageId`. Python protobuf attributes use snake case, such as `message_id`. `MessageToDict` and `ParseDict` translate between them. A protobuf parser catches unknown fields and invalid types, but it does not enforce every A2A semantic rule or every required-field annotation.

## Scope of the examples

The course teaches the data model and all three standard bindings. Working integration labs use JSON-RPC over the official HTTP server/client implementation, and the transport module also executes equivalent REST requests. gRPC is explained through operation mapping and protobuf serialization; a separate gRPC service is not required for this beginner course. Push notifications are taught with local delivery/configuration examples, without contacting public webhook services. Security samples implement only the specific checks they explain, not a complete identity provider.

## Observed SDK differences

Testing SDK 1.1.2 identified background queues left open when some task operations reject terminal or inaccessible tasks during initialization. The affected lessons avoid deliberately triggering those paths and explain their use of client preflight checks. These checks do not replace server validation or eliminate races. Actual successful cancellation, task continuation, streaming, authentication and task reads are still exercised. Module 06 constructs a SubscribeToTask request but does not submit a live subscription.

The SDK can also omit an empty `nextPageToken` during ProtoJSON serialization, whereas the ListTasks operation prose explicitly requires the field with an empty string on the last page. Module 05 distinguishes this observation from the protocol requirement and reads the result defensively. Its version notes also explain the observed terminal-message error-code difference. These labs test the described behavior; they are not a complete protocol-conformance certification.
