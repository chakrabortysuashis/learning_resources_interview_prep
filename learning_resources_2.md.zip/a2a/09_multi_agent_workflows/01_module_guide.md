# 09 - Multi-agent workflows

A class project works better when a coordinator assigns clear jobs, passes along the right information, and notices when one teammate cannot finish. An A2A workflow does the same thing with programs. The protocol lets those programs communicate; your application decides who does what and how their results fit together.

**Time:** 75-90 minutes. **Prerequisites:** [module 08: Python SDK client](../08_python_sdk_client/01_module_guide.md), task/artifact concepts, and Python `async`/`await`. Follow [course setup](../00_start_here.md), then run [02_coordinating_specialists.ipynb](02_coordinating_specialists.ipynb) in a new kernel.

By the end, you will discover and route between two independent agents, run dependent steps in sequence, run independent steps concurrently, correlate each server's task IDs, combine completed artifacts, and preserve useful work when another specialist fails.

## Learning path

1. Model a school study team: local coordinator, planner and quiz maker.
2. Discover real Agent Cards and route using an explicit application policy.
3. Call each specialist with `A2ACardResolver`, `ClientFactory` and v1 protobuf messages.
4. Run a sequential workflow that passes the planner's artifact to the quiz maker.
5. Track workflow, agent, message, task and context identifiers separately.
6. Run independent jobs with `asyncio.gather` and collect their results.
7. Observe a real failed A2A task and keep the other specialist's successful output.
8. Apply a bounded retry to discovery and explain why retrying a work submission is different.
9. Complete three exercises and the self-check.

```text
SEQUENTIAL: output is needed by the next step
student -> coordinator -> planner -- plan artifact --> coordinator
                       coordinator -- plan text --> quiz maker

PARALLEL: neither request needs the other's output
                        +--> planner ---- plan ----+
student -> coordinator -+                         +-> combined report
                        +--> quiz maker -- quiz ---+

PARTIAL FAILURE: a report can retain the plan and identify the missing quiz
```

## Vocabulary

| Term | Meaning |
|---|---|
| Coordinator | Application code that chooses and combines specialist work |
| Specialist | An agent with a focused advertised skill |
| Routing policy | Your application's rule for selecting an agent |
| Sequential flow | A later request depends on an earlier result |
| Parallel flow | Independent requests are scheduled concurrently |
| Correlation map | Application-owned records linking a workflow to each agent's IDs |
| Partial result | Useful completed work together with a clearly identified missing/failed part |
| Bounded retry | A limited number of retries for explicitly chosen failure conditions |

## Real integration and classroom policy

The notebook targets **specification v1.0.1**, **wire version 1.0** and **a2a-sdk 1.1.2**. Each specialist is an independent official-SDK HTTP application with its own card, handler and task store. Official card resolvers and clients communicate through `httpx.ASGITransport`. No main workflow directly invokes a responder. Responders run on the server side after A2A requests arrive.

The ASGI calls happen inside the notebook process, without TCP listeners. They validate discovery, request/response behavior and isolation; they do not measure internet latency or demonstrate a deployment. The deterministic agents teach protocol coordination, so no model service or API key is needed. The local coordinator is ordinary Python application code, not an extra A2A server. The capstone extends that design.

Skill tags, routing choices, task dependencies, retry policies and the combined report format belong to the application. A2A does not automatically build a workflow graph or give different agents shared memory. Forward context deliberately in a new message; do not assume a context ID issued by one server is known to another. The application keeps its own workflow ID and maps it to each specialist's message/task/context identifiers.

The failure example returns an actual `TASK_STATE_FAILED` from the quiz agent. The coordinator retains the successful plan and marks its **application report** `partial`. That label is not a new A2A task state. A timeout can leave remote work in an uncertain state; it does not prove that submitting again is safe. Reusing a message ID alone is not an idempotency guarantee.

All HTTP/SDK clients close in `finally`/context-manager blocks. Every specialist team also closes its handlers in `finally`, including when a scenario fails.

## Expected results

The sequential quiz receives the plan as explicit request content. The two servers produce separate task/context records linked by one workflow ID. The parallel run completes both independent jobs. The failure run keeps one successful artifact and one failed-task record, with no false claim that the whole study pack is complete. A read-only discovery retry succeeds on the second attempt after an explicitly injected classroom connection failure.

## References

- [A2A v1.0.1 specification](https://github.com/a2aproject/A2A/blob/v1.0.1/docs/specification.md): messages/tasks, discovery and error handling
- [Normative v1.0.1 protocol schema](https://github.com/a2aproject/A2A/blob/v1.0.1/specification/a2a.proto)
- [Official Python SDK v1.1.2](https://github.com/a2aproject/a2a-python/tree/v1.1.2)
- [Python asyncio.gather](https://docs.python.org/3/library/asyncio-task.html#asyncio.gather)
- [Course sources and versions](../02_sources_and_versions.md)

Previous: [08 - Python SDK client](../08_python_sdk_client/01_module_guide.md). Next: [10 - Security and trust](../10_security_and_trust/01_module_guide.md).
