# A small reference to keep beside your notebook

Use this page to look up a word, then return to the lesson. It follows the course's **v1.0** wire protocol baseline.

## The objects

| Term | Plain meaning | Read next |
|---|---|---|
| Agent | A program that can do work on someone's behalf | [01](01_introduction/01_module_guide.md) |
| Client / server | The requester / the participant handling that request; one program can play both roles | [01](01_introduction/01_module_guide.md) |
| Message | One communication turn | [02](02_data_layer/01_module_guide.md) |
| Part | One content item: text, raw bytes, URL or JSON value | [02](02_data_layer/01_module_guide.md) |
| Artifact | An output produced for a task | [02](02_data_layer/01_module_guide.md) |
| Agent Card | A description of an agent's abilities and how to contact it | [03](03_agent_cards_and_discovery/01_module_guide.md) |
| Skill | A described area of expertise, such as making quizzes | [03](03_agent_cards_and_discovery/01_module_guide.md) |
| Capability | An optional protocol feature, such as streaming | [03](03_agent_cards_and_discovery/01_module_guide.md) |
| Interface | An endpoint paired with its protocol binding and version | [03](03_agent_cards_and_discovery/01_module_guide.md) |
| Task | A tracked unit of work, with status and possibly artifacts/history | [05](05_tasks_and_conversations/01_module_guide.md) |
| Context | A way to group related interactions; it does not automatically share memory | [05](05_tasks_and_conversations/01_module_guide.md) |
| Extension | An identified agreement adding behavior beyond core A2A | [03](03_agent_cards_and_discovery/01_module_guide.md) |

## The labels

```text
JSON-RPC request id    Labels this operation call and its response
Message.messageId     Labels this communication turn
Message.contextId     Groups related interactions
Message.taskId        Refers to existing tracked work, when applicable
Task.id               Identifies the tracked work itself
Artifact.artifactId   Identifies an output within its task
```

Use a new message ID for a new message. To continue interrupted work, refer to its task. To request new work after a task is finished, omit its task ID; you can retain the context. A2A does not promise that an ID prevents duplicate execution.

## How information travels

| Term | Plain meaning |
|---|---|
| JSON | A text format for exchanging data |
| Protobuf | A schema and serialization system used by A2A v1 definitions and the SDK |
| ProtoJSON | The rules for expressing protobuf objects as JSON |
| Serialization | Converting an in-memory object into a form another program can receive |
| HTTP | Request/response communication with methods, URLs, headers and bodies |
| HTTPS | HTTP protected with TLS while it travels |
| Binding | A mapping of A2A operations onto a concrete communication mechanism |
| JSON-RPC | A binding that selects operations through a JSON `method` field |
| HTTP+JSON / REST | A binding that selects operations through an HTTP method and path |
| gRPC | A binding using generated service methods and binary protobuf messages |
| SSE | Server-Sent Events: a sequence of text events in an HTTP response |
| Webhook | An HTTP endpoint that receives notifications sent by another service |
| ASGI | A Python interface between async web applications and servers or test adapters |

## Typical request journey

```text
Discover card
    |
Choose compatible interface and satisfy security/extension requirements
    |
SendMessage
    +----> Message: a direct reply
    |
    +----> Task: tracked work
               |
               +--> inspect state through response, polling or updates
               +--> provide input/authorization if interrupted
               +--> inspect terminal outcome and available artifacts
```

`TASK_STATE_COMPLETED` indicates successful completion. `TASK_STATE_FAILED`, `TASK_STATE_CANCELED` and `TASK_STATE_REJECTED` are other terminal outcomes. `TASK_STATE_INPUT_REQUIRED` and `TASK_STATE_AUTH_REQUIRED` are interruptions requiring action, not successful completion. A stream ending or an artifact's `lastChunk` alone is insufficient evidence that the task completed successfully.

## Trust and reliability

| Term | Plain meaning |
|---|---|
| Authentication | Establishing the identity of the caller or service |
| Authorization | Deciding what that identity is allowed to do |
| Timeout | A limit on how long a caller waits; it does not prove the server stopped |
| Retry | Making another attempt after a failure or uncertainty |
| Idempotency | Repeating an operation has the same intended effect as doing it once |
| Backoff | Increasing the delay between repeated attempts |
| Persistence | Saving state so it survives process restarts |
| Correlation | Keeping related requests, tasks and results associated |
| SSRF | An attacker persuading a server to make an unwanted network request |

Return to the [course outline](01_course_outline.md). Field definitions and protocol requirements are linked in [sources and versions](02_sources_and_versions.md).
