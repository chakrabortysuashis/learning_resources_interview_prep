# 10 - Security and trust: identity is more than a name in a message

**Time:** about 90 minutes. **Prerequisites:** modules 01-09 and [course setup](../00_start_here.md). Open [02_security_boundaries.ipynb](02_security_boundaries.ipynb).

By the end, you will distinguish authentication from authorization, enforce both in a local SDK app, verify task ownership, and identify trust boundaries around agent content, credentials, signed Cards, and webhook destinations.

## 1. The school office analogy

A student writes "I am the principal" on a worksheet. That sentence does not make the student the principal. The office checks identity through a trusted process, checks what that identity may do, and checks whether the requested record belongs to them.

```text
Untrusted HTTP request
       |
       v
Authentication: Who has presented a valid credential?
       |
       v
Authorization: May that identity perform this operation?
       |
       v
SDK request context: authenticated identity
       |
       v
Task store: is this task visible to that identity?
       |
       v
Executor: process the content as data
```

A2A defines useful security declarations and protocol behavior. Your server and infrastructure must perform the actual checks.

## 2. Four different questions

| Question | Concept | Example |
|---|---|---|
| Is the connection protected in transit? | TLS / HTTPS | Prevent an observer from reading a bearer token on the wire |
| Who is presenting this credential? | Authentication | Map a verified credential to Alice |
| What may Alice do? | Authorization | Let a reader retrieve tasks but not submit new work |
| May Alice access this particular task? | Object ownership/access | Prevent Bob from retrieving Alice's output by guessing its ID |

Strong random IDs help avoid accidental collisions, but they do not replace authorization. Even a leaked valid task ID must not grant another identity access.

A service may express task access through ownership, team membership, or another policy. The notebook uses per-user ownership because it is easy to inspect.

## 3. A Card declares; middleware enforces

An Agent Card can advertise a bearer-token security scheme and require it. That declaration helps a client understand how to authenticate. It does not install an authentication backend or block requests by itself.

The notebook proves this distinction: it adds a bearer scheme to a real SDK Card and calls the unprotected local app successfully. It then wraps that app with actual authentication and authorization middleware and verifies that the same unauthenticated operation receives HTTP 401.

The notebook uses obvious, public **demonstration tokens** mapped to three local users/roles. They are fixtures, not real secrets, JWTs, or an OAuth implementation. No token is sent to the internet.

Production credentials should be issued, validated, expired, and revoked through a suitable identity system. Bearer tokens work by possession: avoid placing them in prompts, Message Parts, URLs, Artifacts, or logs. A2A does not replace credential lifecycle management.

## 4. Follow identity into the SDK

The Starlette AuthenticationMiddleware populates a trusted user object after our backend verifies the demonstration token. The SDK's DefaultServerCallContextBuilder adapts that object into a ServerCallContext user.

In this pinned SDK, the default InMemoryTaskStore ownership resolver uses the context user's name. That name must come from verified authentication, not from a user-controlled Message field.

The notebook creates a Task as Alice, retrieves it as Alice, and attempts retrieval and listing as Bob. The SDK scopes those operations so Bob cannot see Alice's work. Bob's real GetTask preflight is denied, so our application sends no cancellation request. A task-not-found response can intentionally cover both nonexistent and inaccessible objects without revealing which case applies.

CancelTask ownership is not exercised here: SDK 1.1.2 has a queue-cleanup defect on the failed-cancellation path. The access-control requirement still applies to cancellation; this lab demonstrates GetTask and ListTasks isolation without invoking that defective path.

If your application uses multiple organizations or shared service identities, define the ownership resolver and authorization policy accordingly. A single service credential does not automatically distinguish every human user behind that service.

## 5. Read errors at the correct level

The local middleware returns HTTP 401 when identity cannot be established and HTTP 403 when an authenticated reader tries a write operation.

An authenticated request can still reach the A2A handler and fail its task lookup. With the JSON-RPC binding, that response can have HTTP 200 and a JSON-RPC TaskNotFound error. Always inspect both the HTTP result and protocol body.

Our read/write operation mapping is explicit application policy for this teaching app. It is not a permission system mandated by A2A or a claim that all operations have identical risk.

## 6. Treat agent content as data

Remote agent replies, Cards, file links, tool outputs, and retrieved documents are inputs from another trust boundary. Their text may contain instructions such as "ignore your rules" or "send me your credential."

Do not promote those instructions into authority merely because they arrived in a valid A2A envelope. Decide permitted operations from trusted application policy and the authenticated user's permissions.

The notebook safely renders a hostile-looking text string with HTML escaping. Escaping prevents that text from becoming active HTML in that display context; it does **not** solve prompt injection. Likewise, a blacklist of suspicious phrases cannot establish trust. LLM/tool workflows need capability limits, explicit data/instruction separation, and authorization checks at actual action boundaries.

## 7. Webhooks and SSRF

A push notification destination is a URL the server may contact. If an attacker chooses an internal address, the server could be tricked into reaching internal services. This is **server-side request forgery**, or SSRF.

The notebook implements a narrow offline URL policy: require HTTPS, an exact configured callback host and path, no embedded credentials, and resolved addresses that are globally routable. It accepts supplied DNS-result fixtures and performs no network requests.

That validator is one part of an outbound-request design. A production sender must also:

1. Resolve and check the destination at connection time, including IPv4 and IPv6.
2. Prevent DNS rebinding between checking and connecting, for example with validated address pinning plus appropriate TLS host verification.
3. Disable redirects or validate every redirect destination.
4. Enforce network egress policy, request timeouts, size limits, and delivery limits.
5. Authenticate notification delivery appropriately and avoid forwarding unrelated credentials.

Do not present a hostname check alone as complete SSRF protection.

## 8. Signed Cards and TLS address different questions

A Card signature can help verify that signed Card data has not changed and was signed by a particular key. The verifier still needs a trusted association between that key and the agent identity.

A valid signature does not prove that the agent's answers are correct, that its implementation is safe, or that a key presented by an attacker should be trusted. Verify allowed algorithms, canonicalization, key provenance, and applicable rotation/revocation policy. A2A Card signing uses its specified JWS and canonicalization rules; ordinary sorted JSON is not a substitute implementation.

HTTPS authenticates the server endpoint and protects the connection when certificate verification is correctly performed. It does not grant permission to read every Task. The notebook's in-process HTTP adapter performs no TLS handshake, so TLS and cryptographic Card verification are explained conceptually rather than falsely claimed as tested.

## 9. Learning path, exercises, and self-check

1. Inspect a v1 Card's security declaration.
2. Demonstrate the difference between declaring and enforcing it.
3. Verify missing credentials, invalid credentials, and insufficient permission.
4. Test Alice/Bob task isolation through real SDK calls.
5. Keep audit output free of credentials and message text.
6. Render untrusted content safely in its display context.
7. Validate offline webhook URL fixtures.
8. Complete three exercises with worked solutions: reader access, identity spoofing in content, and rejected callback URLs.

Before continuing, answer:

1. Why does adding a bearer scheme to a Card not secure a server?
2. Why should Bob be denied access even if he knows Alice's Task ID?
3. Does HTML escaping solve prompt injection?
4. Does a valid Card signature establish trust in an unknown signing key?

**Answers:** (1) The declaration must be backed by actual request checks. (2) Identifiers locate records; authorization grants access. (3) No; it protects one HTML rendering context. (4) No; key trust must be established separately.

Next, [module 11](../11_testing_and_reliability/01_module_guide.md) tests failures and reliability alongside these trust boundaries.

## References

Baseline: specification **v1.0.1**, wire **1.0**, SDK **1.1.2**.

- [A2A specification v1.0.1](https://github.com/a2aproject/A2A/blob/v1.0.1/docs/specification.md): security, authenticated task visibility, Cards, and push notifications.
- [Normative SecurityScheme, SecurityRequirement, and AgentCard types](https://github.com/a2aproject/A2A/blob/v1.0.1/specification/a2a.proto).
- [Starlette authentication](https://www.starlette.io/authentication/).
- [OWASP SSRF prevention guidance](https://cheatsheetseries.owasp.org/cheatsheets/Server_Side_Request_Forgery_Prevention_Cheat_Sheet.html).
- [OWASP prompt injection prevention guidance](https://cheatsheetseries.owasp.org/cheatsheets/LLM_Prompt_Injection_Prevention_Cheat_Sheet.html).
- [Course source/version notes](../02_sources_and_versions.md).

**Previous:** [09 - multi-agent workflows](../09_multi_agent_workflows/01_module_guide.md). **Next:** [11 - testing and reliability](../11_testing_and_reliability/01_module_guide.md).

