# 01 - Introduction: how agents cooperate

**Time:** about 60 minutes. **Prerequisites:** you can run a Python notebook; this lesson reviews the Python you need. Start with [course setup](../00_start_here.md), then open [02_meet_a2a.ipynb](02_meet_a2a.ipynb).

By the end, you will explain why two independent agents need a shared protocol, identify client and server roles, read a small JSON message, and trace a request and reply. You will also know which problems A2A does *not* solve.

## 1. Start with a school study team

Imagine asking a study coordinator, "Help me revise photosynthesis." The coordinator asks a biology specialist to explain the topic and a quiz specialist to prepare practice questions.

The specialists may use different textbooks and methods. They can still cooperate if they agree on how to describe their abilities, request work, report progress, and return results. They do not need to share their private notebooks.

An **agent** is a program that carries out work on someone's behalf. It may use a language model, ordinary code, tools, or a mixture. Our course uses predictable Python rules, so you can inspect every result without paying for an AI service.

```text
Student
   |
   | "Help me revise photosynthesis"
   v
Study coordinator
   |                    |
   | request an         | request practice
   | explanation        | questions
   v                    v
Biology specialist    Quiz specialist
   |                    |
   +------ results -----+
              |
              v
        Study coordinator --> Student
```

This picture describes an application workflow. A2A supplies the communication rules between programs. The developer still decides who gets which job and what counts as a useful answer.

## 2. What A2A standardizes

**Agent2Agent (A2A)** is an open protocol for communication between independent agent systems. A protocol is a shared set of rules, like the layout and delivery rules for a school assignment form.

A2A gives participants common ways to describe capabilities, exchange content, track work, and obtain updates. The receiving agent can keep its internal reasoning, tools, and memory private.

| School analogy | A2A concept | What it does |
|---|---|---|
| A specialist's introduction sheet | Agent Card | Describes identity, skills, interfaces, and declared security requirements |
| A note asking for help | Message | One communication turn containing content parts |
| A paragraph or attached file | Part | One content item inside a message or artifact |
| An assignment being tracked | Task | Holds an identifier, status, and potentially outputs/history |
| The finished revision sheet | Artifact | A task's output, made from parts |
| A folder grouping related work | Context | Associates related interactions; it does not imply automatic memory sharing |

An agent can reply directly with a Message for a simple interaction. A Task is useful when work needs tracking. Do not assume every message creates a new task.

A2A has three useful levels:

```text
DATA MODEL       What information?       Message, Part, Task, Artifact, Card
       |
OPERATIONS       What action?            SendMessage, GetTask, CancelTask, ...
       |
BINDINGS         How is it exchanged?    JSON-RPC, HTTP+JSON/REST, gRPC
```

The same underlying ideas can travel through different bindings. JSON is a format for data; HTTP is a communication mechanism. They are not interchangeable words.

## 3. Client and server are roles in an interaction

The **client** initiates a request. The **server**, also called the remote agent, exposes an A2A interface and handles that request.

For the coordinator-to-biology interaction, the coordinator is the client and biology is the server. If biology asks a separate research agent for help, biology becomes a client in that second interaction. One program can have both roles.

A client need not itself be an AI agent: a web application or ordinary script can use an A2A client. Also, the protocol's user message role means the client side of the exchange; it does not prove that a person typed the text.

## 4. Compare APIs, MCP, and A2A

An **API**, or application programming interface, is the broad idea of a defined way to use a program. A2A and MCP themselves expose interfaces; they are not alternatives to the existence of APIs.

| Concept | Helpful question | Study-team example |
|---|---|---|
| General API | "How do I call this software?" | Call a weather endpoint or calculator function |
| Model Context Protocol (MCP) | "How does an application discover and use tools, resources, and prompts?" | Let a study assistant read a textbook through a resource/tool integration |
| A2A | "How do independent agent systems describe capabilities and exchange work?" | Ask a separate quiz-making agent to produce practice material |

These are common uses, not an absolute boundary around every possible implementation. A tool can wrap an agent. An A2A server can use MCP internally. A2A does not require MCP, and neither protocol guarantees an intelligent or correct answer.

## 5. Read a first message

The notebook introduces Python dictionaries, lists, functions, JSON, and `async`/`await`. Here is a small **v1 JSON Message object**, before any transport envelope:

```json
{
  "messageId": "f6b3a675-99ea-4eb0-b9b5-b55b53d7f385",
  "role": "ROLE_USER",
  "parts": [
    {"text": "Explain photosynthesis in one sentence."}
  ]
}
```

Read it aloud: "This communication turn has an ID, comes from the client, and contains one text item." The identifier distinguishes messages; it is not an automatic guarantee that repeated submissions run only once.

The notebook's first exchange uses a local Python function and JSON strings. **It is a classroom simulation, not a conformant A2A server.** We deliberately postpone HTTP, discovery, security, and task storage. Module 04 introduces actual SDK HTTP integration, and later modules build servers and clients.

## 6. What A2A leaves to your application

A2A does not choose your language model, write your prompts, decide your plan, or ensure the returned work is factually correct. It does not automatically share hidden memory between agents. Your application must decide which agents to trust, how to review their answers, and what to do when a dependency fails.

A Card can declare authentication requirements, but server code and infrastructure must enforce them. Streaming and push notifications are capabilities you must check; do not assume every agent supports them. Cancellation is a request whose outcome must be checked, not a magic guarantee that work has stopped.

## 7. Notebook path and practice

1. Read the analogy and inspect ordinary Python data.
2. Serialize a dictionary into JSON text and parse it back.
3. Build a client Message with the v1 field names.
4. Trace the bytes-like boundary using serialized text and a local receiver.
5. Use `await` to let two simulated interactions make progress.
6. Try the three exercises before reading the worked solutions.

The exercises ask you to inspect a message with two text parts, reject the wrong sender role in our restricted receiver, and collect two asynchronous replies without mixing their identifiers. Solutions are in the notebook after all exercise prompts.

## 8. Vocabulary and self-check

**Interoperability** means independently built systems can work together through agreed interfaces. **Serialization** converts in-memory data to an exchange format. **Asynchronous** code can yield while waiting, so other work can proceed. **Binding** means a concrete mapping of protocol operations onto a communication mechanism.

Before continuing, answer:

1. If a quiz agent requests information from biology, which is the client?
2. Is a JSON dictionary alone a complete A2A server?
3. Must a request always return a Task?
4. Does `async` automatically make CPU-heavy arithmetic faster?

**Answers:** (1) The quiz agent is the client in that interaction. (2) No: the complete server must implement the required protocol behavior and interface. (3) No: a direct Message response is possible. (4) No: async helps overlap waiting; it does not automatically parallelize CPU computation.

You now have the vocabulary to inspect the actual data structures in [module 02: data layer](../02_data_layer/01_module_guide.md).

## Version baseline and references

This course uses specification release **1.0.1**, wire version **1.0**, and **a2a-sdk==1.1.2**. A release tag, wire compatibility version, and package version describe different things. SDK 1.1.2 uses protobuf-native Python objects; later modules serialize those objects into the v1 JSON representation at the transport boundary. Do not copy older wire examples into v1 requests.

- [Official specification at release v1.0.1](https://github.com/a2aproject/A2A/blob/v1.0.1/docs/specification.md), especially introduction, terminology, and operations.
- [Authoritative protocol data definitions at v1.0.1](https://github.com/a2aproject/A2A/blob/v1.0.1/specification/a2a.proto), especially Message, Part, and Role.
- [Official MCP introduction](https://modelcontextprotocol.io/docs/getting-started/intro).
- [Course source and compatibility notes](../02_sources_and_versions.md).

**Previous:** [start here](../00_start_here.md). **Next:** [02 - data layer](../02_data_layer/01_module_guide.md).

