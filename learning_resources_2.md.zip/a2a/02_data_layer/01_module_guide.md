# 02 - The data layer: what agents send

**Time:** about 60-90 minutes. **Prerequisites:** module 01 and basic Python dictionaries/lists. Run the [course setup](../00_start_here.md) first.

The data layer is the shared shape of information. Imagine a school's project desk: students hand in request envelopes, the desk labels each job, and teachers return completed worksheets. A2A gives programs comparable envelopes, labels, and results.

By the end, you can build a v1 Message, choose a Part type, distinguish conversation from task output, track the different IDs, and explain what protobuf parsing does and does not check.

## Learning path

1. Open [02_messages_parts_and_artifacts.ipynb](02_messages_parts_and_artifacts.ipynb) and run it from top to bottom.
2. Build a Message with a sender role and text.
3. Compare text, raw bytes, URL content, and structured data Parts.
4. Convert Python dictionaries to JSON and parse them with the SDK's generated v1 protobuf types.
5. Trace message, context, task, and artifact IDs.
6. Package a completed study plan as an Artifact.
7. Complete the three exercises before reading each worked solution, then answer the self-check.

```text
Student request                       Finished school project
Message                               Task
  messageId                             id: task identifier
  role: ROLE_USER                        contextId: conversation group
  parts                                 artifacts
    text: "Make a study plan"             Artifact
    data: {"minutes": 30}                   artifactId
                                             parts
                                               text: readable summary
                                               data: machine-readable plan
```

A Message is a unit of communication. A Part is one piece of content inside a Message or Artifact. An Artifact is a task output. A Task tracks a unit of work; its lifecycle is covered in module 05. An Agent Card advertises what a server offers; you will study it next.

## Vocabulary to keep nearby

| Word | Plain meaning |
|---|---|
| Data model | Agreed names, shapes, and meanings of fields |
| Message | A communication from client to server or server to client |
| Role | Which side sent the message: ROLE_USER or ROLE_AGENT |
| Part | One content item: text, raw bytes, a URL, or a JSON value |
| Artifact | A result produced for a task |
| ID | A label used to refer to a particular object |
| Context | A group of related interactions |
| MIME/media type | A label such as text/plain or application/json describing content format |
| Base64 | A way to represent binary bytes using JSON-safe text; it is not encryption |
| ProtoJSON | Rules for expressing protobuf messages as JSON |
| Metadata | Application-specific extra information alongside protocol content |
| Schema check | A check of field names, types, and structural rules |

## Important boundaries

The notebook uses **A2A specification release 1.0.1**, **wire version 1.0**, and the **a2a-sdk==1.1.2** installation shared by the course. The v1 JSON examples use names such as `messageId`, role values such as `ROLE_USER`, and Parts such as `{"text": "Hello"}`. A v1 Part has no `kind` discriminator. The pinned SDK exposes the v1 generated protobuf classes used here. Older tutorials and compatibility interfaces may use different shapes; always check the API and protocol version together.

The notebook is an offline data-model lab. It does not start a server, call an LLM, or download content URLs. Its SDK protobuf parser checks the generated schema, but it does **not** implement all protocol semantics, enforce required-field annotations, authorize requests, or prove that a server is conformant. A separate small lesson check is deliberately labeled as an incomplete application check.

A server-produced Message must include `contextId`; it includes `taskId` only when a task was created. A client's initial Message may omit both. When both are supplied, their association must match. `messageId` does not automatically prevent duplicate work. Artifacts have IDs unique within a task. Results from task work should be returned as Artifacts; progress and clarification belong in Messages.

For v1, Part `data` can contain any JSON value, including an object, array, string, number, boolean, or null. Metadata is a JSON **object**. `mediaType` can describe any Part type. A URL points to content; it does not contain the downloaded file or grant access to it.

## Exercises and self-check

The notebook includes three exercises with worked solutions: prepare a mixed-content request, repair a structurally invalid Part and explain a parser limitation, and produce a machine-readable result without confusing its IDs. Each exercise has observable output and assertions. The final four-question self-check includes answers.

## Official references

- [A2A v1.0.1 specification: Messages and Artifacts and the data model](https://github.com/a2aproject/A2A/blob/v1.0.1/docs/specification.md)
- [A2A v1.0.1 normative protobuf definitions: Message, Part, Artifact, Role](https://github.com/a2aproject/A2A/blob/v1.0.1/specification/a2a.proto)
- [Protocol Buffers: ProtoJSON format](https://protobuf.dev/programming-guides/json/)
- [Python SDK 1.1.2 source](https://github.com/a2aproject/a2a-python/tree/v1.1.2)

**Previous:** [01 - Introduction](../01_introduction/01_module_guide.md) | **Next:** [03 - Agent Cards and discovery](../03_agent_cards_and_discovery/01_module_guide.md) | **Course map:** [Outline](../01_course_outline.md)
