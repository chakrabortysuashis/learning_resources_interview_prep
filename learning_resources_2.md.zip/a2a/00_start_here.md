# Learn Agent2Agent, one small step at a time

A2A is a shared language for programs that delegate work to other agents. Think of a student asking a librarian for sources, then asking a tutor to explain them: each helper can work differently, but everyone needs a clear way to ask, report progress and deliver results.

Start with the [course outline](01_course_outline.md), then open [module 01](01_introduction/01_module_guide.md). All 12 module folders are numbered in reading order. Each folder contains `01_module_guide.md` followed by a `02_*.ipynb` notebook. The root documents are numbered separately.

Keep the [glossary and quick reference](04_glossary_and_quick_reference.md) nearby when a term is unfamiliar.

```text
01 Introduction -> 02 Data -> 03 Agent cards -> 04 Transports
                                                   |
08 Client <- 07 Server <- 06 Updates <- 05 Tasks <---+
    |
    +-> 09 Agent teams -> 10 Security -> 11 Reliability -> 12 Capstone
```

## What you need

- Basic Python: variables, lists, dictionaries, functions and `for` loops. Module 01 includes a short refresher.
- Python **3.11–3.13** recommended. The course is validated with Python 3.13. The SDK itself supports Python 3.10+.
- Internet access once to install dependencies. The notebooks then run locally, without API keys, external model services or downloads.

Our agents use simple Python rules. This makes their results repeatable and lets you concentrate on A2A. You can replace those rules with a language model later: A2A does not prescribe the agent's reasoning engine.

## Install on Windows (PowerShell)

Open a terminal in this `a2a` folder. You can use your editor's integrated terminal. Run each line:

```powershell
py -3.13 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m ipykernel install --sys-prefix --name a2a-course --display-name "Python (A2A course)"
.\.venv\Scripts\python.exe -m jupyterlab
```

If you have Python 3.11 or 3.12, replace `-3.13` with your installed version. `py --list` shows installed interpreters. We call the environment's Python directly, so changing PowerShell's script execution policy is unnecessary.

## Install on macOS or Linux

From this `a2a` folder:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m ipykernel install --sys-prefix --name a2a-course --display-name "Python (A2A course)"
.venv/bin/python -m jupyterlab
```

## Read and run a notebook

1. In JupyterLab's file browser, open `01_introduction`, then its `.ipynb` file.
2. Choose the **Python (A2A course)** kernel. In VS Code, select the interpreter inside `a2a/.venv` using the notebook's kernel selector.
3. A Markdown cell explains an idea; a code cell lets you try it. Select a cell and press **Shift+Enter** to run it and move forward.
4. Run cells from top to bottom. Stop at exercises and try your own answer before reading the solutions.
5. Use **Kernel → Restart Kernel and Run All Cells** to check that the notebook works from a clean start.

Each notebook creates its own examples. You never need another notebook running in the background. Shared helper code lives in `course_runtime.py`; later notebooks explain what it supplies. Code uses `await` directly because Jupyter already has an event loop.

Generated identifiers and timestamps will differ when you rerun a lesson. Compare the structure and behavior described beside each example rather than copying those values. Some cells deliberately trigger and catch errors to show how failures work; an uncaught error or failed assertion needs attention.

Diagrams use text and embedded HTML/SVG. Text diagrams work in any notebook reader; rich visual output appears after you run the relevant cell. No Mermaid extension is required.

## What is real and what is a teaching model?

Early lessons use clearly labeled Python simulations to make individual concepts visible. Later lessons call actual SDK server apps and SDK clients through an in-process HTTP adapter (`httpx.ASGITransport`). Requests pass through the SDK's HTTP routes and protocol serialization without opening a network port. This tests application behavior, but does not reproduce network timing, proxies or real-time stream delivery. The server module also explains how to run the same app on localhost using Uvicorn.

In-memory stores and demonstration credentials are classroom tools. The security and reliability modules explain what a deployed service needs beyond them. Optional streaming, push notifications and extended cards are advertised only when supported by the example being discussed.

## If something goes wrong

| Symptom | What to do |
|---|---|
| `ModuleNotFoundError: a2a` or `httpx` | Select the course environment's kernel and rerun the install command in that environment. The package is named `a2a-sdk`; Python imports it as `a2a`. |
| `NameError` in a later cell | Restart the kernel and run all earlier cells in order. |
| An `asyncio.run()` error | Use the notebook's supplied `await` examples; do not wrap them in `asyncio.run()`. |
| A helper import fails | Keep the module folders inside `a2a`, and launch Jupyter from this folder. |
| An online example uses `message/send` or `kind` | It may target A2A 0.3. This course uses version 1.0 wire messages; see [version notes](02_sources_and_versions.md). |

## Verify the course

From this folder, use your course environment's Python:

```powershell
.\.venv\Scripts\python.exe validate_notebooks.py
```

On macOS/Linux use `.venv/bin/python validate_notebooks.py`. This validates the notebook format and executes every notebook in a fresh Python kernel. It writes a report and executed copies inside `.validation`. It does not need an external service. See [validation results](03_validation_results.md) for the checks performed when the course was created.
