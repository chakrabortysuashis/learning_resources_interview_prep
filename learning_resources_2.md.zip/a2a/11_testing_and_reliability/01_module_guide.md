# 11 - Testing and reliability

**Time:** 75-100 minutes. **Prerequisites:** modules 01-10 and the [course setup](../00_start_here.md). You should recognize requests, task states, artifacts, and Python exceptions.

Imagine a school delivery desk. Testing checks that the right parcel gets the right receipt. Reliability also asks what happens when the receipt is lost, someone asks twice, or the desk closes and reopens. Those are different problems, and each needs evidence.

By the end, you can run named A2A integration checks, separate schema parsing from semantic validation, explain timeouts and late completion, retry safe reads with limits, demonstrate duplicate submissions, and identify the limits of an in-memory deduplication example.

## Learning path

1. Open [02_test_failures_and_recovery.ipynb](02_test_failures_and_recovery.ipynb) and run it in order.
2. Compare protobuf schema parsing with SDK request validation.
3. Run named success and failure tests through actual SDK HTTP routes.
4. Observe a task complete after an injected read timeout.
5. Retry a safe GetTask read with a bounded policy.
6. Submit the same messageId twice and inspect the results.
7. Build a small concurrent application deduplicator and state its limits.
8. Examine storage durability and safe observability.
9. Complete three exercises with solutions and the self-check.

```text
Test a request
    |
    +-- syntax/schema: can it be parsed?
    +-- protocol: ID correlation, response shape, expected errors
    +-- task outcome: completed / interrupted / failed / canceled
    +-- application result: is the requested output correct?

Then inject trouble: timeout -> retry/read policy -> stored state -> recovery
```

## Vocabulary

| Term | Meaning |
|---|---|
| Assertion | A statement that must be true for a check to pass |
| Integration test | Exercises components together, such as HTTP routes and a task store |
| Fault injection | Deliberately produces a controlled failure |
| Retry | Repeats an operation under a stated policy |
| Backoff | Waits longer between repeated attempts |
| Idempotency | Repeating an operation has the same intended effect as doing it once |
| Deduplication | Detects repeated requests and avoids repeating work |
| Race | Concurrent operations interleave and undermine an assumption |
| Durable storage | Survives process or machine restart according to its guarantees |
| Observability | Evidence from logs, metrics, and traces about system behavior |

## What is tested here

The named suite checks real SDK JSON-RPC success, response-ID correlation, missing tasks, invalid message semantics, method errors, and history limits. The suite prints a PASS line for each named case and raises if any case fails. Deliberate transport/read faults are labeled simulations; successful recovery reads use actual SDK routes.

The data model is protobuf-native with **SDK 1.1.2**, **wire version 1.0**, and **specification release 1.0.1**. Protobuf parsing does not enforce all REQUIRED annotations or authorization rules. A successful HTTP response also does not imply a successful task: inspect the JSON-RPC result/error and task state.

The local ASGI integration is real HTTP handling inside Python, not a live TCP network. It does not test TLS, DNS, real network delays, multiple worker processes, or deployment infrastructure. The in-memory store and deduplicator intentionally demonstrate limitations that production designs must address.

## Reliability principles

- A timeout means the client stopped waiting; server work may continue.
- Retry naturally idempotent reads with attempt/deadline limits. Do not retry every error or automatically resubmit new work.
- A messageId is a correlation label, not a universal exactly-once guarantee. Check the server's documented policy.
- In-process locking can prevent a local concurrent race but does not protect multiple processes or survive restart. Crash-safe idempotency needs durable, atomic state and careful treatment of external side effects.
- Logs should use an explicit field allowlist. Avoid copying message content, credentials, or entire requests into logs by default.
- Close clients and handlers after tests so background tasks do not contaminate later cases.

## Before deployment

Check authentication/ownership enforcement, durable storage, timeouts and cancellation, retry/idempotency policy, bounded resource use, logging rules, health checks, and recovery after a process restart. Run real TCP/TLS and multi-process tests where your deployment uses those boundaries. Passing this notebook is evidence for its tested contracts, not proof of complete protocol conformance.

## Official references

- [A2A v1.0.1 specification](https://github.com/a2aproject/A2A/blob/v1.0.1/docs/specification.md): operation semantics, errors, history, and authorization scoping.
- [Normative protobuf](https://github.com/a2aproject/A2A/blob/v1.0.1/specification/a2a.proto)
- [SDK 1.1.2](https://github.com/a2aproject/a2a-python/tree/v1.1.2)

**Previous:** [10 - Security and trust](../10_security_and_trust/01_module_guide.md) | **Next:** [12 - Capstone study team](../12_capstone_study_team/01_module_guide.md) | **Course map:** [Outline](../01_course_outline.md)
