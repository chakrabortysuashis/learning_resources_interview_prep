# 03 - Agent cards and discovery

An Agent Card is like a club's information board: it tells you who runs the club, what help it offers, and how to contact it. Reading the board does not do the work or prove that every promise is true.

**Time:** 60-90 minutes. **Prerequisites:** basic Python dictionaries and [module 02: data layer](../02_data_layer/01_module_guide.md). Follow [course setup](../00_start_here.md), then open [02_reading_and_discovering_agents.ipynb](02_reading_and_discovering_agents.ipynb).

By the end, you will be able to read an A2A v1 Agent Card, distinguish skills from protocol capabilities, discover a card, choose a compatible interface and skill, explain extended cards and extensions, and identify what a card does and does not prove.

## Learning path

1. Meet the card: identity, provider, software version, skills and input/output media types.
2. Read `supportedInterfaces`: endpoint, binding, wire protocol version and optional tenant.
3. Simulate discovery through `/.well-known/agent-card.json` and understand registry and direct-configuration alternatives.
4. Select the first compatible advertised interface, then choose a suitable skill using application policy.
5. Read security declarations and retrieve a simulated authenticated extended card.
6. Negotiate extensions and check trust before constructing a request plan.
7. Complete three exercises, inspect the worked solutions and answer the self-check.

```text
Known agent domain
        |
        v
GET /.well-known/agent-card.json
        |
        v
   Agent Card ----> trust checks
        |
        +----> compatible interface: WHERE and HOW to talk
        +----> skill + media modes: WHAT help to request
        +----> security + extensions: WHAT must be understood
        |
        v
   Client is ready to construct an A2A request
   (actual sending starts in the transport module)
```

## Vocabulary

| Term | Everyday meaning | A2A example |
|---|---|---|
| Agent Card | An information board for an agent | Name, skills, endpoint choices |
| Skill | A described area of expertise | Explain fractions |
| Capability | An optional protocol feature | Streaming responses |
| Interface | An address paired with a way of communicating | HTTPS endpoint using JSONRPC, version 1.0 |
| Discovery | Finding and reading a card | Fetching the well-known URL |
| Media type | A label for the form of content | `text/plain`, `application/json` |
| Extended card | A complete card obtained after authentication | Additional teacher-only skill |
| Extension | An identified addition to core A2A behavior | An application-defined citation convention |
| Trust | Evidence and policy for deciding what to accept | Trusted provider, HTTPS, verified signature |

## Version and implementation boundaries

This lesson targets **specification release v1.0.1** and **wire protocol 1.0**. The course installs **a2a-sdk 1.1.2**, but this notebook uses Python dictionaries to make the wire structure visible. A card's `version`, such as `2.4.0`, is the agent software's version. Each interface's `protocolVersion`, such as `1.0`, describes the wire protocol. These are independent of the SDK package version.

V1 puts URLs and protocol versions inside `supportedInterfaces`. Extended-card support lives in `capabilities.extendedAgentCard`. Security requirements use `securityRequirements` with `schemes`/`list` wrappers according to the normative proto. Older tutorials and older SDK releases use different field shapes. The pinned SDK 1.1.2 exposes v1 protobuf types; its Python attributes use snake_case and ProtoJSON converts them to camelCase.

All discovery, authentication and extension checks here are **explicit classroom simulations**. The notebook makes no network requests and is not a conformant A2A server, full schema validator, OAuth implementation or cryptographic verifier. [Module 08](../08_python_sdk_client/01_module_guide.md) performs real SDK discovery. [Module 10](../10_security_and_trust/01_module_guide.md) develops security boundaries further.

The key security lesson is practical: declaring Bearer authentication in a card does not check a token. A server must enforce authentication and authorization. An extended card may disclose additional abilities, but hiding a skill in a public card does not protect the corresponding operation. Descriptions, URLs and example prompts are untrusted input until your application has suitable evidence and policy.

## What to check while running

The card inspection prints two skills. The limited client skips the preferred GRPC interface and chooses JSONRPC version 1.0. Discovery of an unknown domain produces a caught error. A teacher session can retrieve a richer card; an unauthenticated session cannot. A required extension that the client cannot understand is rejected before planning a request. All failures are expected, explained and caught; assertions check the important decisions.

## References

- [Official v1.0.1 specification: Agent Discovery](https://github.com/a2aproject/A2A/blob/v1.0.1/docs/specification.md#8-agent-discovery-the-agent-card)
- [Normative v1.0.1 protobuf schema](https://github.com/a2aproject/A2A/blob/v1.0.1/specification/a2a.proto): `AgentCard`, `AgentInterface`, `AgentSkill`, `AgentCapabilities`, `SecurityRequirement`
- [Official specification: extensions](https://github.com/a2aproject/A2A/blob/v1.0.1/docs/specification.md#46-extensions)
- [Official specification: extended-card access control](https://github.com/a2aproject/A2A/blob/v1.0.1/docs/specification.md#133-extended-agent-card-access-control)
- [Course sources and version notes](../02_sources_and_versions.md)

Next: [04 - Transport layer](../04_transport_layer/01_module_guide.md).
