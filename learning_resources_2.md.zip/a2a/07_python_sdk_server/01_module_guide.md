# 07 - Build an A2A server with the Python SDK

**Time:** about 90 minutes. **Prerequisites:** modules 01-06, [course setup](../00_start_here.md), Python functions/classes and basic async code. Open [02_build_an_sdk_server.ipynb](02_build_an_sdk_server.ipynb).

By the end, you will assemble the SDK components yourself, explain how an executor publishes results, compare Task and direct Message responses, and exercise cancellation through a real SDK route.

## 1. Think of a school office with a specialist behind it

The office accepts a standard form. A clerk reads it, gives the work an identifier, and records updates. The specialist does the actual subject work.

```text
HTTP client
    |
    v
Routes: parse protocol request and serialize response
    |
    v
DefaultRequestHandler: connect request, execution, events, and storage
    |                         ^
    v                         |
RequestContext --> AgentExecutor --> EventQueue
                        |                 |
                   your Python       TaskUpdater helps
                   work logic        publish events
                                          |
                                          v
                                    InMemoryTaskStore
```

This is a conceptual view. The SDK coordinates event consumption and task updates; the executor should publish events instead of manually updating the HTTP response or mutating the store behind the handler's back.

The server's Agent Card describes its advertised interface and abilities. The Card is a description, not the component doing the work.

## 2. Learn the pieces by responsibility

| Component | What it does | What you supply |
|---|---|---|
| `AgentExecutor` | Defines execution and cancellation callbacks | Your subclass implementing `execute` and `cancel` |
| `RequestContext` | Exposes the message, task/context IDs, current task, and helpers | Read the incoming request through it |
| `EventQueue` | Accepts protocol events from the executor | Enqueue a Task, Message, or update event |
| `TaskUpdater` | Builds and publishes task status/artifact events | Call its methods at meaningful moments |
| `InMemoryTaskStore` | Holds current task records in this process | Create a fresh store for the app |
| `DefaultRequestHandler` | Coordinates requests with your executor and store | Connect executor, store, and Agent Card |
| SDK route factories | Expose the Card and JSON-RPC operations | Add their routes to the web app |
| `Starlette` | Holds the ASGI web application | Assemble the routes into one app |

These names belong to **a2a-sdk 1.1.2**, whose domain types are protobuf-native. Older tutorials may use different imports or Pydantic models. This module uses the pinned version throughout.

A class is a blueprint, and an object is one instance made from that blueprint. A subclass fills in or changes parts of an existing blueprint. Our executor subclass fills in the SDK's execution and cancellation instructions. Its event queue is an ordered tray of updates that the SDK consumes.

## 3. Put application logic in ordinary Python

The agent's subject knowledge is not part of the communication protocol. Our study planner uses a plain function that returns a short revision plan.

That function could later call a language model or a database, but the protocol does not require either. Keeping it ordinary and deterministic makes it easier to see whether a bug is in the work itself or in communication.

The executor reads text with `context.get_user_input()`. This helper suits our text-only agent; an agent accepting files or structured data should inspect the Message's Parts appropriately.

## 4. Publish a Task and its output

For a new tracked job, the executor publishes an initial Task. The SDK helper `new_task_from_user_message` creates one with the submitted state and request history.

The executor then creates a TaskUpdater using the event queue and the request's task/context identifiers. It publishes working status, an Artifact, and completed status.

```text
Initial Task --> Working status --> Artifact update --> Completed status
     |                 |                  |                    |
     +-----------------+------------------+--------------------+
                      event queue
```

This is the path for our particular successful job, not a complete mandatory transition graph for all A2A agents. Other jobs may request input, fail, or be canceled.

An Artifact represents output. A status message describes progress or a question. Publishing "done" as text is not the same as changing a Task's state to completed.

The executor must not keep using a request's context or event queue after its execution callback returns. Background work needs to fit the SDK's lifecycle rather than using a detached thread with stale objects.

## 5. Assemble the server visibly

The notebook constructs these objects in order:

1. A protobuf Agent Card with a JSON-RPC interface and a study-planning skill.
2. An instance of our executor.
3. A fresh in-memory Task store.
4. A DefaultRequestHandler connecting the executor, store, and Card.
5. Card routes and JSON-RPC routes.
6. A Starlette app containing those routes.

The notebook then sends a real JSON-RPC request through `httpx.ASGITransport`. You can inspect the HTTP response, retrieve the Task again, and see that the output came from your executor.

ASGI is the Python interface used between the adapter and app. This tests actual SDK handling inside one process; it does not open a network port or establish TLS.

## 6. Cancel real waiting work

Cancellation is a request to stop work, not a guarantee that every external effect can be undone. An agent may reject a cancellation, especially after work is already terminal.

Our executor contains an explicit **classroom test mode**: the exact input `hold for cancellation` publishes a Task and waits at an async checkpoint. The notebook requests an immediate Task response, waits until the executor reaches that checkpoint, and then calls CancelTask.

For this pinned SDK's in-process execution path, the handler cancels the executor coroutine and invokes its cancellation callback. Our executor uses `finally` to clean its local tracking set, and `cancel` publishes canceled status with TaskUpdater.

This proves cancellation for the waiting coroutine in our app. It does not prove that a database transaction, subprocess, blocking thread, or remote service has stopped. A real executor must coordinate and verify cancellation of any work it owns.

## 7. Return a direct Message when task tracking is unnecessary

A short greeting does not necessarily need an assignment ticket. The notebook also implements a second executor that enqueues one `ROLE_AGENT` Message with a new message ID and a context ID.

The SendMessage result then contains `message` rather than `task`. There is no Task ID to poll or cancel for that response. The protocol supports both patterns; your application's work determines which fits.

## 8. Run it locally, then understand deployment limits

The notebook leaves no listening server running and closes SDK-owned background resources with `await handler.aclose()`. To try a TCP server manually after the lesson, open a terminal in the course's `a2a` folder, use the course environment's Python directly:

```powershell
.\.venv\Scripts\python.exe -m uvicorn course_runtime:create_demo_app --factory --host 127.0.0.1 --port 8000
```

On macOS/Linux, use `.venv/bin/python` in place of the Windows interpreter path above.

This uses the shared course factory, which assembles the same kinds of SDK components. If port 8000 is busy, choose another free port and adjust the factory's advertised base URL accordingly. Stop the process with **Ctrl+C**. The notebook does not run this command for you.

A production service needs persistent storage, authentication/authorization enforcement, HTTPS, operational limits, and deployment supervision. InMemoryTaskStore loses its records when the process exits. Advertising security in a Card alone does not implement any of it.

## 9. Practice and self-check

The notebook provides three exercises with worked solutions:

1. Change a planner's application logic while preserving the protocol response shape.
2. Inspect stored task history and Artifacts after a real call.
3. Build a direct Message executor and identify why no Task lookup follows.

It also demonstrates active cancellation so you can compare a requested outcome with observed state.

Before continuing, answer:

1. Does TaskUpdater directly send an HTTP response?
2. Which component contains the subject-specific work?
3. Does an Artifact alone tell a caller that a Task is completed?
4. Why does in-memory storage fail to preserve tasks after restart?

**Answers:** (1) No; it publishes events through the queue, which the SDK processes. (2) Your executor and the ordinary functions it calls. (3) No; Task status communicates completion. (4) The records live only in the running process's memory.

You have now built the server behind the interface. Next, [module 08](../08_python_sdk_client/01_module_guide.md) uses the official client to discover and call it.

## References

Baseline: specification **v1.0.1**, wire **1.0**, Python SDK **1.1.2**.

- [A2A specification v1.0.1](https://github.com/a2aproject/A2A/blob/v1.0.1/docs/specification.md): operations, tasks, messages, and cancellation.
- [Authoritative protocol objects](https://github.com/a2aproject/A2A/blob/v1.0.1/specification/a2a.proto).
- [Python SDK v1.1.2](https://github.com/a2aproject/a2a-python/tree/v1.1.2/src/a2a): executor, handler, event queue, store, and route implementations.
- [Course runtime source](../course_runtime.py) and [version notes](../02_sources_and_versions.md).

**Previous:** [06 - streaming and notifications](../06_streaming_and_notifications/01_module_guide.md). **Next:** [08 - Python SDK client](../08_python_sdk_client/01_module_guide.md).
