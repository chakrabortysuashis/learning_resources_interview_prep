# Docker Complete Guide - Interview Preparation

## Table of Contents
1. [What is Docker?](#what-is-docker)
2. [Why Docker is Needed](#why-docker-is-needed)
3. [Docker Architecture](#docker-architecture)
4. [Advantages of Docker](#advantages-of-docker)
5. [Docker vs Virtual Machines](#docker-vs-virtual-machines)
6. [Core Docker Concepts](#core-docker-concepts)
7. [Dockerfile Explained](#dockerfile-explained)
8. [Essential Docker Commands](#essential-docker-commands)
9. [Docker Networking](#docker-networking)
10. [Docker Volumes](#docker-volumes)
11. [Docker Compose](#docker-compose)
12. [Best Practices](#best-practices)
13. [Interview Questions](#interview-questions)

---

## What is Docker?

Docker is an **open-source containerization platform** that allows you to package applications and their dependencies into lightweight, portable containers that can run consistently across different environments.

```
┌─────────────────────────────────────────────────────────────────┐
│                        DOCKER CONCEPT                           │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   ┌─────────────┐    docker build    ┌─────────────┐           │
│   │  Dockerfile │ ─────────────────► │   Image     │           │
│   │  (Recipe)   │                    │  (Template) │           │
│   └─────────────┘                    └──────┬──────┘           │
│                                             │                   │
│                                    docker run                   │
│                                             │                   │
│                                             ▼                   │
│                                    ┌─────────────┐              │
│                                    │  Container  │              │
│                                    │  (Running   │              │
│                                    │   Instance) │              │
│                                    └─────────────┘              │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘

Key Terms:
• Dockerfile = Recipe/Instructions to build an image
• Image = Blueprint/Template (read-only)
• Container = Running instance of an image
```

### Simple Analogy
Think of Docker like a shipping container:
- **Dockerfile** = Assembly instructions for a product
- **Docker Image** = A sealed shipping container with the product
- **Docker Container** = The container delivered and opened at destination

---

## Why Docker is Needed

### The "It Works on My Machine" Problem

```
┌─────────────────────────────────────────────────────────────────┐
│                    WITHOUT DOCKER                                │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Developer's Machine          Production Server                 │
│  ┌─────────────────┐          ┌─────────────────┐              │
│  │ Python 3.9      │          │ Python 3.7      │  ← Different!│
│  │ Node 16         │          │ Node 14         │  ← Different!│
│  │ MySQL 8.0       │          │ MySQL 5.7       │  ← Different!│
│  │ Ubuntu 22.04    │          │ CentOS 7        │  ← Different!│
│  └─────────────────┘          └─────────────────┘              │
│          │                            │                         │
│          ▼                            ▼                         │
│     ✓ Works!                     ✗ FAILS!                      │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                      WITH DOCKER                                 │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Developer's Machine          Production Server                 │
│  ┌─────────────────┐          ┌─────────────────┐              │
│  │ ┌─────────────┐ │          │ ┌─────────────┐ │              │
│  │ │  Container  │ │          │ │  Container  │ │              │
│  │ │ Python 3.9  │ │    =     │ │ Python 3.9  │ │  ← Same!    │
│  │ │ Node 16     │ │    =     │ │ Node 16     │ │  ← Same!    │
│  │ │ MySQL 8.0   │ │    =     │ │ MySQL 8.0   │ │  ← Same!    │
│  │ └─────────────┘ │          │ └─────────────┘ │              │
│  └─────────────────┘          └─────────────────┘              │
│          │                            │                         │
│          ▼                            ▼                         │
│     ✓ Works!                     ✓ Works!                      │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Docker Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     DOCKER ARCHITECTURE                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌────────────────────────────────────────────────────────┐    │
│  │                    DOCKER CLIENT                        │    │
│  │  (CLI commands: docker build, run, pull, push, etc.)   │    │
│  └─────────────────────────┬──────────────────────────────┘    │
│                            │ REST API                           │
│                            ▼                                    │
│  ┌────────────────────────────────────────────────────────┐    │
│  │                    DOCKER DAEMON                        │    │
│  │                    (dockerd)                            │    │
│  │  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐    │    │
│  │  │   Images     │ │  Containers  │ │   Networks   │    │    │
│  │  └──────────────┘ └──────────────┘ └──────────────┘    │    │
│  │  ┌──────────────┐ ┌──────────────┐                     │    │
│  │  │   Volumes    │ │   Plugins    │                     │    │
│  │  └──────────────┘ └──────────────┘                     │    │
│  └─────────────────────────┬──────────────────────────────┘    │
│                            │                                    │
│                            ▼                                    │
│  ┌────────────────────────────────────────────────────────┐    │
│  │                   DOCKER REGISTRY                       │    │
│  │              (Docker Hub, ECR, GCR, etc.)               │    │
│  │  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐   │    │
│  │  │  nginx   │ │  python  │ │   node   │ │  redis   │   │    │
│  │  └──────────┘ └──────────┘ └──────────┘ └──────────┘   │    │
│  └────────────────────────────────────────────────────────┘    │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Components Explained:

| Component | Description |
|-----------|-------------|
| **Docker Client** | CLI tool that users interact with (`docker` commands) |
| **Docker Daemon** | Background service that manages containers, images, networks |
| **Docker Registry** | Storage for Docker images (Docker Hub is the default public registry) |
| **Docker Images** | Read-only templates used to create containers |
| **Docker Containers** | Running instances of images |

---

## Advantages of Docker

```
┌─────────────────────────────────────────────────────────────────┐
│                   ADVANTAGES OF DOCKER                           │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  1. CONSISTENCY                                                 │
│     ┌─────────┐    ┌─────────┐    ┌─────────┐                  │
│     │   Dev   │ == │  Test   │ == │  Prod   │                  │
│     └─────────┘    └─────────┘    └─────────┘                  │
│     Same environment everywhere!                                │
│                                                                 │
│  2. ISOLATION                                                   │
│     ┌─────────┐  ┌─────────┐  ┌─────────┐                      │
│     │ App A   │  │ App B   │  │ App C   │                      │
│     │ Node 14 │  │ Node 18 │  │ Node 20 │                      │
│     └─────────┘  └─────────┘  └─────────┘                      │
│     No conflicts between applications!                          │
│                                                                 │
│  3. PORTABILITY                                                 │
│     ┌─────────────────────────────────────────┐                │
│     │              Container                   │                │
│     └─────────────────────────────────────────┘                │
│          ↓           ↓           ↓           ↓                 │
│       Laptop      Server      Cloud       Edge                 │
│     Runs anywhere that has Docker!                              │
│                                                                 │
│  4. LIGHTWEIGHT                                                 │
│     VM: 1-2 GB        Container: 10-100 MB                     │
│     ████████████      ██                                       │
│     Starts in minutes  Starts in seconds                       │
│                                                                 │
│  5. SCALABILITY                                                 │
│     ┌───┐ ┌───┐ ┌───┐ ┌───┐ ┌───┐                             │
│     │ C │ │ C │ │ C │ │ C │ │ C │                             │
│     └───┘ └───┘ └───┘ └───┘ └───┘                             │
│     Easy to scale up/down containers                           │
│                                                                 │
│  6. VERSION CONTROL                                             │
│     image:v1.0 → image:v1.1 → image:v2.0                       │
│     Easy rollback if something breaks                          │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Docker vs Virtual Machines

```
┌─────────────────────────────────────────────────────────────────┐
│              VIRTUAL MACHINES vs CONTAINERS                      │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│         VIRTUAL MACHINES                 CONTAINERS             │
│   ┌───────────────────────┐      ┌───────────────────────┐     │
│   │ ┌─────┐┌─────┐┌─────┐ │      │ ┌─────┐┌─────┐┌─────┐ │     │
│   │ │App A││App B││App C│ │      │ │App A││App B││App C│ │     │
│   │ └─────┘└─────┘└─────┘ │      │ └─────┘└─────┘└─────┘ │     │
│   │ ┌─────┐┌─────┐┌─────┐ │      │ ┌─────┐┌─────┐┌─────┐ │     │
│   │ │Bins/││Bins/││Bins/│ │      │ │Bins/││Bins/││Bins/│ │     │
│   │ │Libs ││Libs ││Libs │ │      │ │Libs ││Libs ││Libs │ │     │
│   │ └─────┘└─────┘└─────┘ │      │ └─────┘└─────┘└─────┘ │     │
│   │ ┌─────┐┌─────┐┌─────┐ │      │                       │     │
│   │ │Guest││Guest││Guest│ │      │                       │     │
│   │ │ OS  ││ OS  ││ OS  │ │      │                       │     │
│   │ └─────┘└─────┘└─────┘ │      │                       │     │
│   │ ┌─────────────────────┐│     │ ┌─────────────────────┐│    │
│   │ │     Hypervisor      ││     │ │    Docker Engine    ││    │
│   │ └─────────────────────┘│     │ └─────────────────────┘│    │
│   │ ┌─────────────────────┐│     │ ┌─────────────────────┐│    │
│   │ │      Host OS        ││     │ │      Host OS        ││    │
│   │ └─────────────────────┘│     │ └─────────────────────┘│    │
│   │ ┌─────────────────────┐│     │ ┌─────────────────────┐│    │
│   │ │   Infrastructure    ││     │ │   Infrastructure    ││    │
│   │ └─────────────────────┘│     │ └─────────────────────┘│    │
│   └───────────────────────┘      └───────────────────────┘     │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘

┌──────────────────┬─────────────────────┬───────────────────────┐
│     Aspect       │   Virtual Machines  │      Containers       │
├──────────────────┼─────────────────────┼───────────────────────┤
│ OS               │ Full Guest OS each  │ Shares Host OS kernel │
│ Size             │ GBs                 │ MBs                   │
│ Startup          │ Minutes             │ Seconds               │
│ Performance      │ Limited by overhead │ Near-native           │
│ Isolation        │ Complete (hardware) │ Process-level         │
│ Portability      │ Limited             │ Highly portable       │
│ Resource Usage   │ High                │ Low                   │
└──────────────────┴─────────────────────┴───────────────────────┘
```

---

## Core Docker Concepts

### Image Layers

```
┌─────────────────────────────────────────────────────────────────┐
│                     DOCKER IMAGE LAYERS                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Each instruction in Dockerfile creates a new layer             │
│                                                                 │
│  Dockerfile:                    Image Layers:                   │
│  ─────────────                  ─────────────                   │
│  FROM python:3.9      ───►  ┌─────────────────────┐            │
│                             │  Layer 1: Base OS    │ (Cached)  │
│                             │  + Python 3.9        │            │
│  WORKDIR /app         ───►  ├─────────────────────┤            │
│                             │  Layer 2: Set        │ (Cached)  │
│                             │  working directory   │            │
│  COPY requirements.txt───►  ├─────────────────────┤            │
│                             │  Layer 3: Copy       │ (Cached)  │
│                             │  requirements        │            │
│  RUN pip install      ───►  ├─────────────────────┤            │
│                             │  Layer 4: Install    │ (Cached)  │
│                             │  dependencies        │            │
│  COPY . .             ───►  ├─────────────────────┤            │
│                             │  Layer 5: Copy       │ (Rebuilt) │
│                             │  source code         │            │
│  CMD ["python","app"] ───►  ├─────────────────────┤            │
│                             │  Layer 6: Run        │            │
│                             │  command             │            │
│                             └─────────────────────┘            │
│                                                                 │
│  ★ Layers are cached! Only changed layers are rebuilt.         │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Dockerfile Explained

A Dockerfile is a text file containing instructions to build a Docker image.

### Common Dockerfile Instructions

```dockerfile
# ─────────────────────────────────────────────────────────────────
# DOCKERFILE INSTRUCTIONS REFERENCE
# ─────────────────────────────────────────────────────────────────

# FROM - Base image to start from
FROM python:3.9-slim

# LABEL - Metadata for the image
LABEL maintainer="your-email@example.com"
LABEL version="1.0"

# ARG - Build-time variables (not available in running container)
ARG APP_VERSION=1.0

# ENV - Environment variables (available at runtime)
ENV APP_ENV=production
ENV DEBUG=false

# WORKDIR - Set the working directory inside the container
WORKDIR /app

# COPY - Copy files from host to container
COPY requirements.txt .
COPY src/ ./src/

# ADD - Similar to COPY, but can also extract tar files and fetch URLs
ADD archive.tar.gz /app/
ADD https://example.com/file.txt /app/

# RUN - Execute commands during image build
RUN pip install --no-cache-dir -r requirements.txt
RUN apt-get update && apt-get install -y curl && rm -rf /var/lib/apt/lists/*

# EXPOSE - Document which ports the container listens on
EXPOSE 8080

# VOLUME - Create a mount point for persistent data
VOLUME ["/data"]

# USER - Set the user to run subsequent commands
USER appuser

# ENTRYPOINT - Main executable (not easily overridden)
ENTRYPOINT ["python"]

# CMD - Default arguments to ENTRYPOINT (can be overridden)
CMD ["app.py"]

# HEALTHCHECK - Container health monitoring
HEALTHCHECK --interval=30s --timeout=3s \
  CMD curl -f http://localhost:8080/health || exit 1
```

### ENTRYPOINT vs CMD

```
┌─────────────────────────────────────────────────────────────────┐
│                    ENTRYPOINT vs CMD                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ENTRYPOINT = The executable (What to run)                      │
│  CMD = Default arguments (How to run it)                        │
│                                                                 │
│  Example Dockerfile:                                            │
│  ┌─────────────────────────────────────┐                       │
│  │ ENTRYPOINT ["python"]               │                       │
│  │ CMD ["app.py"]                      │                       │
│  └─────────────────────────────────────┘                       │
│                                                                 │
│  Running the container:                                         │
│                                                                 │
│  $ docker run myapp                                             │
│  → Executes: python app.py                                      │
│                                                                 │
│  $ docker run myapp test.py                                     │
│  → Executes: python test.py  (CMD is overridden)                │
│                                                                 │
│  $ docker run --entrypoint bash myapp                           │
│  → Executes: bash  (ENTRYPOINT is overridden)                   │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Rule of Thumb:                                           │   │
│  │ • Use ENTRYPOINT for the main command                    │   │
│  │ • Use CMD for default arguments                          │   │
│  │ • Or use only CMD if you want easy override              │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### COPY vs ADD

```
┌─────────────────────────────────────────────────────────────────┐
│                       COPY vs ADD                                │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  COPY (Preferred for most cases)                                │
│  ────────────────────────────────                               │
│  • Simply copies files/directories from source to destination   │
│  • More transparent and predictable                             │
│                                                                 │
│  COPY requirements.txt /app/                                    │
│  COPY src/ /app/src/                                            │
│                                                                 │
│  ─────────────────────────────────────────────────────────────  │
│                                                                 │
│  ADD (Use only when needed)                                     │
│  ─────────────────────────────                                  │
│  • Can extract tar archives automatically                       │
│  • Can fetch from URLs (not recommended)                        │
│                                                                 │
│  ADD archive.tar.gz /app/          # Auto-extracts!            │
│  ADD https://example.com/file /app/ # Downloads file           │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Best Practice: Use COPY unless you need ADD features    │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Essential Docker Commands

### Image Commands

```bash
# ═══════════════════════════════════════════════════════════════
#                      IMAGE COMMANDS
# ═══════════════════════════════════════════════════════════════

# Pull an image from Docker Hub
docker pull nginx:latest
docker pull python:3.9-slim

# Build an image from Dockerfile
docker build -t myapp:1.0 .
docker build -t myapp:1.0 -f Dockerfile.prod .

# List all images
docker images
docker image ls

# Remove an image
docker rmi nginx:latest
docker image rm myapp:1.0

# Remove unused images
docker image prune

# Tag an image
docker tag myapp:1.0 myregistry.com/myapp:1.0

# Push image to registry
docker push myregistry.com/myapp:1.0

# Inspect image details
docker image inspect nginx:latest

# View image history (layers)
docker history nginx:latest
```

### Container Commands

```bash
# ═══════════════════════════════════════════════════════════════
#                    CONTAINER COMMANDS
# ═══════════════════════════════════════════════════════════════

# Run a container
docker run nginx                    # Basic run
docker run -d nginx                 # Detached mode (background)
docker run -it ubuntu bash          # Interactive with terminal
docker run -p 8080:80 nginx         # Port mapping (host:container)
docker run --name mycontainer nginx # Named container
docker run -v /host/path:/container/path nginx  # Volume mount
docker run -e MY_VAR=value nginx    # Environment variable
docker run --rm nginx               # Remove container after exit

# Combined example
docker run -d \
  --name web \
  -p 8080:80 \
  -v $(pwd)/html:/usr/share/nginx/html \
  -e NGINX_HOST=localhost \
  --restart unless-stopped \
  nginx:latest

# List containers
docker ps                  # Running containers
docker ps -a               # All containers (including stopped)

# Stop containers
docker stop mycontainer    # Graceful stop
docker kill mycontainer    # Force stop

# Start a stopped container
docker start mycontainer

# Restart a container
docker restart mycontainer

# Remove containers
docker rm mycontainer              # Remove stopped container
docker rm -f mycontainer           # Force remove running container
docker container prune             # Remove all stopped containers

# Execute command in running container
docker exec -it mycontainer bash   # Get shell access
docker exec mycontainer ls /app    # Run command

# View logs
docker logs mycontainer            # All logs
docker logs -f mycontainer         # Follow logs (live)
docker logs --tail 100 mycontainer # Last 100 lines

# Container stats
docker stats                       # Real-time stats
docker top mycontainer             # Running processes

# Copy files to/from container
docker cp mycontainer:/app/file.txt ./file.txt  # Container to host
docker cp ./file.txt mycontainer:/app/file.txt  # Host to container

# Inspect container
docker inspect mycontainer
```

### Command Flow Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                   DOCKER COMMAND WORKFLOW                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌──────────────┐                                               │
│  │ Dockerfile   │                                               │
│  └──────┬───────┘                                               │
│         │ docker build -t myapp .                               │
│         ▼                                                       │
│  ┌──────────────┐         docker push         ┌──────────────┐ │
│  │    Image     │ ◄─────────────────────────► │   Registry   │ │
│  │   (local)    │         docker pull         │ (Docker Hub) │ │
│  └──────┬───────┘                             └──────────────┘ │
│         │                                                       │
│         │ docker run                                            │
│         ▼                                                       │
│  ┌──────────────┐                                               │
│  │  Container   │◄─── docker start/stop/restart                │
│  │  (running)   │                                               │
│  └──────┬───────┘                                               │
│         │                                                       │
│         │ docker exec -it <container> bash                      │
│         ▼                                                       │
│  ┌──────────────┐                                               │
│  │   Shell      │                                               │
│  │   Inside     │                                               │
│  │  Container   │                                               │
│  └──────────────┘                                               │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Docker Networking

```
┌─────────────────────────────────────────────────────────────────┐
│                    DOCKER NETWORKING                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Network Types:                                                 │
│  ──────────────                                                 │
│                                                                 │
│  1. BRIDGE (Default)                                            │
│     ┌─────────────────────────────────────┐                    │
│     │         bridge network              │                    │
│     │  ┌───────┐  ┌───────┐  ┌───────┐   │                    │
│     │  │ App1  │  │ App2  │  │ App3  │   │                    │
│     │  │172.17 │  │172.17 │  │172.17 │   │                    │
│     │  │.0.2   │  │.0.3   │  │.0.4   │   │                    │
│     │  └───────┘  └───────┘  └───────┘   │                    │
│     └─────────────────────────────────────┘                    │
│     • Isolated network for containers                           │
│     • Containers can communicate via IP                         │
│                                                                 │
│  2. HOST                                                        │
│     ┌─────────────────────────────────────┐                    │
│     │           Host Network              │                    │
│     │  ┌───────────────────────────────┐ │                    │
│     │  │  Container uses host's        │ │                    │
│     │  │  network stack directly       │ │                    │
│     │  │  (No network isolation)       │ │                    │
│     │  └───────────────────────────────┘ │                    │
│     └─────────────────────────────────────┘                    │
│     • Best performance                                          │
│     • No port mapping needed                                    │
│                                                                 │
│  3. NONE                                                        │
│     • No network connectivity                                   │
│     • Complete network isolation                                │
│                                                                 │
│  4. CUSTOM BRIDGE (User-defined)                                │
│     ┌─────────────────────────────────────┐                    │
│     │       my-custom-network             │                    │
│     │  ┌───────┐         ┌───────┐       │                    │
│     │  │ web   │ ◄─────► │  db   │       │                    │
│     │  └───────┘   DNS   └───────┘       │                    │
│     └─────────────────────────────────────┘                    │
│     • Automatic DNS resolution by name                          │
│     • Better isolation                                          │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Network Commands

```bash
# Create a network
docker network create mynetwork

# List networks
docker network ls

# Run container in specific network
docker run -d --network mynetwork --name web nginx
docker run -d --network mynetwork --name db mysql

# Containers can now communicate by name:
# From 'web' container: ping db

# Connect existing container to network
docker network connect mynetwork existing-container

# Disconnect from network
docker network disconnect mynetwork existing-container

# Inspect network
docker network inspect mynetwork

# Remove network
docker network rm mynetwork
```

---

## Docker Volumes

```
┌─────────────────────────────────────────────────────────────────┐
│                      DOCKER VOLUMES                              │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Why Volumes?                                                   │
│  ────────────                                                   │
│  Container data is ephemeral - deleted when container is removed│
│  Volumes persist data outside the container lifecycle           │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                     HOST MACHINE                         │   │
│  │  ┌─────────────────────────────────────────────────┐    │   │
│  │  │              Docker Volume                       │    │   │
│  │  │         /var/lib/docker/volumes/                │    │   │
│  │  └─────────────────────────────────────────────────┘    │   │
│  │              ▲                 ▲                         │   │
│  │              │                 │                         │   │
│  │      ┌───────┴─────┐   ┌──────┴──────┐                  │   │
│  │      │ Container A │   │ Container B │                  │   │
│  │      │  /app/data  │   │  /app/data  │                  │   │
│  │      └─────────────┘   └─────────────┘                  │   │
│  │                                                          │   │
│  │  Both containers share the same data!                   │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  Volume Types:                                                  │
│  ─────────────                                                  │
│                                                                 │
│  1. Named Volumes (Recommended)                                 │
│     docker volume create mydata                                 │
│     docker run -v mydata:/app/data nginx                        │
│                                                                 │
│  2. Bind Mounts (Host path)                                     │
│     docker run -v /host/path:/container/path nginx              │
│     docker run -v $(pwd):/app nginx                             │
│                                                                 │
│  3. tmpfs Mounts (Memory only)                                  │
│     docker run --tmpfs /app/temp nginx                          │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Volume Commands

```bash
# Create a volume
docker volume create mydata

# List volumes
docker volume ls

# Inspect volume
docker volume inspect mydata

# Use volume in container
docker run -v mydata:/app/data nginx

# Remove volume
docker volume rm mydata

# Remove unused volumes
docker volume prune

# Bind mount example (development)
docker run -v $(pwd):/app -w /app node:18 npm start
```

---

## Docker Compose

Docker Compose is a tool for defining and running multi-container applications.

### docker-compose.yml Example

```yaml
version: '3.8'

services:
  web:
    build: ./web
    ports:
      - "8080:80"
    environment:
      - DATABASE_URL=postgres://db:5432/myapp
    depends_on:
      - db
      - redis
    volumes:
      - ./web/src:/app/src
    networks:
      - app-network

  db:
    image: postgres:14
    environment:
      POSTGRES_DB: myapp
      POSTGRES_USER: user
      POSTGRES_PASSWORD: password
    volumes:
      - postgres-data:/var/lib/postgresql/data
    networks:
      - app-network

  redis:
    image: redis:alpine
    networks:
      - app-network

volumes:
  postgres-data:

networks:
  app-network:
    driver: bridge
```

### Docker Compose Commands

```bash
# Start all services
docker-compose up              # Foreground
docker-compose up -d           # Detached mode

# Build and start
docker-compose up --build

# Stop services
docker-compose down

# Stop and remove volumes
docker-compose down -v

# View logs
docker-compose logs
docker-compose logs -f web     # Follow specific service

# List running services
docker-compose ps

# Execute command in service
docker-compose exec web bash

# Scale services
docker-compose up --scale web=3
```

---

## Best Practices

### Dockerfile Best Practices

```dockerfile
# ═══════════════════════════════════════════════════════════════
#                    BEST PRACTICES EXAMPLE
# ═══════════════════════════════════════════════════════════════

# 1. Use specific base image tags (not 'latest')
FROM python:3.9.18-slim-bookworm

# 2. Add labels for documentation
LABEL maintainer="team@company.com"
LABEL version="1.0.0"

# 3. Create non-root user for security
RUN groupadd -r appgroup && useradd -r -g appgroup appuser

# 4. Set working directory
WORKDIR /app

# 5. Copy dependency files first (for caching)
COPY requirements.txt .

# 6. Install dependencies in single layer
# - Combine commands with &&
# - Clean up in same layer
RUN pip install --no-cache-dir -r requirements.txt

# 7. Copy source code last (changes most often)
COPY --chown=appuser:appgroup . .

# 8. Switch to non-root user
USER appuser

# 9. Expose port (documentation)
EXPOSE 8000

# 10. Use exec form for CMD
CMD ["python", "app.py"]
```

### Security Best Practices

```
┌─────────────────────────────────────────────────────────────────┐
│                   SECURITY BEST PRACTICES                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  1. Never run as root                                           │
│     USER appuser                                                │
│                                                                 │
│  2. Use official base images                                    │
│     FROM python:3.9-slim (not random-user/python)               │
│                                                                 │
│  3. Scan images for vulnerabilities                             │
│     docker scan myimage                                         │
│                                                                 │
│  4. Don't store secrets in images                               │
│     Use environment variables or secret managers                │
│                                                                 │
│  5. Use multi-stage builds                                      │
│     Smaller images = smaller attack surface                     │
│                                                                 │
│  6. Keep images updated                                         │
│     Regularly rebuild with latest security patches              │
│                                                                 │
│  7. Use .dockerignore                                           │
│     Exclude sensitive files from build context                  │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### .dockerignore Example

```
# Version control
.git
.gitignore

# Dependencies (will be installed in container)
node_modules
__pycache__
*.pyc
venv/

# IDE
.idea
.vscode
*.swp

# Build artifacts
dist
build
*.egg-info

# Secrets and configs
.env
.env.local
*.pem
*.key

# Documentation
README.md
docs/

# Tests
tests/
*.test.js
```

---

## Interview Questions

### Basic Questions

1. **What is Docker?**
   - Containerization platform for packaging apps with dependencies

2. **What is the difference between an image and a container?**
   - Image: Read-only template (blueprint)
   - Container: Running instance of an image

3. **What is a Dockerfile?**
   - Text file with instructions to build a Docker image

4. **What is Docker Hub?**
   - Public registry for storing and sharing Docker images

5. **What is the difference between COPY and ADD?**
   - COPY: Simple file copy
   - ADD: Can extract archives and fetch URLs

### Intermediate Questions

6. **Explain multi-stage builds**
   ```dockerfile
   # Build stage
   FROM node:18 AS builder
   WORKDIR /app
   COPY package*.json ./
   RUN npm ci
   COPY . .
   RUN npm run build
   
   # Production stage
   FROM nginx:alpine
   COPY --from=builder /app/dist /usr/share/nginx/html
   ```

7. **How do you persist data in Docker?**
   - Volumes: `docker run -v myvolume:/data`
   - Bind mounts: `docker run -v /host/path:/container/path`

8. **Explain Docker networking**
   - Bridge: Default isolated network
   - Host: Uses host's network stack
   - None: No networking
   - Custom: User-defined networks with DNS

9. **What is the difference between CMD and ENTRYPOINT?**
   - ENTRYPOINT: Main executable, harder to override
   - CMD: Default arguments, easily overridden

10. **How do you optimize Docker image size?**
    - Use slim/alpine base images
    - Multi-stage builds
    - Combine RUN commands
    - Clean up in same layer
    - Use .dockerignore

### Advanced Questions

11. **What are Docker layers?**
    - Each instruction creates a layer
    - Layers are cached and reused
    - Only changed layers are rebuilt

12. **How does Docker isolate containers?**
    - Namespaces: Process, network, mount isolation
    - Cgroups: Resource limits (CPU, memory)
    - Union filesystem: Layered file system

13. **What is Docker Compose?**
    - Tool for defining multi-container applications
    - Uses YAML configuration
    - Manages services, networks, volumes together

14. **How do you handle secrets in Docker?**
    - Environment variables (basic)
    - Docker secrets (Swarm mode)
    - External secret managers (Vault, AWS Secrets Manager)

15. **What is container orchestration?**
    - Managing multiple containers at scale
    - Tools: Kubernetes, Docker Swarm
    - Features: Scaling, load balancing, self-healing

---

## Quick Reference Card

```
┌─────────────────────────────────────────────────────────────────┐
│                   DOCKER QUICK REFERENCE                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  BUILD & RUN                                                    │
│  docker build -t name:tag .                                     │
│  docker run -d -p 8080:80 --name web nginx                      │
│                                                                 │
│  CONTAINER LIFECYCLE                                            │
│  docker start/stop/restart <container>                          │
│  docker rm <container>                                          │
│  docker logs -f <container>                                     │
│  docker exec -it <container> bash                               │
│                                                                 │
│  IMAGES                                                         │
│  docker images / docker pull / docker push                      │
│  docker rmi <image>                                             │
│                                                                 │
│  CLEANUP                                                        │
│  docker system prune -a      # Remove everything unused         │
│  docker container prune      # Remove stopped containers        │
│  docker image prune          # Remove dangling images           │
│  docker volume prune         # Remove unused volumes            │
│                                                                 │
│  COMPOSE                                                        │
│  docker-compose up -d                                           │
│  docker-compose down                                            │
│  docker-compose logs -f                                         │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

*Good luck with your interview!*
