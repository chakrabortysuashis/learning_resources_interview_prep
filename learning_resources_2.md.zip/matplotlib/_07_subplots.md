# Subplots in Matplotlib

## What are Subplots?

Subplots let you put **multiple plots in one figure**. Instead of creating separate images, you can arrange plots side-by-side or in a grid.

**When to use subplots:**
- Comparing related datasets
- Showing different views of the same data
- Creating dashboards
- Before/after comparisons

## Basic Subplot: plt.subplot()

The simplest way to create subplots:

```python
import matplotlib.pyplot as plt

plt.subplot(1, 2, 1)  # 1 row, 2 columns, plot 1
plt.plot([1, 2, 3], [1, 2, 3])
plt.title("Plot 1")

plt.subplot(1, 2, 2)  # 1 row, 2 columns, plot 2
plt.plot([1, 2, 3], [3, 2, 1])
plt.title("Plot 2")

plt.show()
```

**What you see:** Two plots side by side - one line going up, one going down.

## Understanding subplot(rows, cols, index)

```
subplot(rows, cols, index)
```

- **rows**: Number of rows in the grid
- **cols**: Number of columns in the grid
- **index**: Which position (1, 2, 3... reading left-to-right, top-to-bottom)

### Grid Layout Examples

**2 plots side by side (1 row, 2 columns):**
```
subplot(1, 2, 1)    subplot(1, 2, 2)
    [1]                 [2]
```

**2 plots stacked (2 rows, 1 column):**
```
subplot(2, 1, 1)
    [1]
subplot(2, 1, 2)
    [2]
```

**4 plots in a grid (2 rows, 2 columns):**
```
subplot(2, 2, 1)    subplot(2, 2, 2)
    [1]                 [2]
subplot(2, 2, 3)    subplot(2, 2, 4)
    [3]                 [4]
```

## Better Way: plt.subplots()

More control and cleaner code:

```python
import matplotlib.pyplot as plt

fig, axes = plt.subplots(1, 2)  # 1 row, 2 columns

axes[0].plot([1, 2, 3], [1, 2, 3])
axes[0].set_title("Plot 1")

axes[1].plot([1, 2, 3], [3, 2, 1])
axes[1].set_title("Plot 2")

plt.show()
```

**Note:** With `subplots()`, use `set_title()` instead of `title()`.

## Naming Individual Axes

Unpack directly for cleaner code:

```python
fig, (ax1, ax2) = plt.subplots(1, 2)

ax1.plot([1, 2, 3], [1, 2, 3])
ax1.set_title("Left Plot")

ax2.plot([1, 2, 3], [3, 2, 1])
ax2.set_title("Right Plot")

plt.show()
```

## Setting Figure Size

Control the overall size:

```python
fig, axes = plt.subplots(1, 2, figsize=(12, 5))
# figsize=(width, height) in inches
```

Common sizes:
- `(10, 6)` - Standard
- `(12, 4)` - Wide and short
- `(8, 8)` - Square
- `(15, 10)` - Large dashboard

## 2x2 Grid Example

```python
import matplotlib.pyplot as plt

fig, axes = plt.subplots(2, 2, figsize=(10, 8))

# Top left
axes[0, 0].plot([1, 2, 3], [1, 4, 9])
axes[0, 0].set_title("Squares")

# Top right
axes[0, 1].bar(['A', 'B', 'C'], [3, 7, 5])
axes[0, 1].set_title("Bar Chart")

# Bottom left
axes[1, 0].scatter([1, 2, 3, 4], [4, 2, 5, 3])
axes[1, 0].set_title("Scatter")

# Bottom right
axes[1, 1].pie([30, 40, 30], labels=['X', 'Y', 'Z'])
axes[1, 1].set_title("Pie Chart")

plt.tight_layout()
plt.show()
```

**What you see:** Four different plot types arranged in a 2x2 grid.

## Sharing Axes

Make plots share the same x or y axis:

```python
fig, (ax1, ax2) = plt.subplots(1, 2, sharey=True)
# Both plots will have the same y-axis scale
```

Options:
- `sharey=True` - Share y-axis
- `sharex=True` - Share x-axis
- Both can be True at the same time

### Why Share Axes?

**Without sharing:** Each plot has its own scale - hard to compare.
**With sharing:** Same scale - easy to compare values across plots.

## Adding a Main Title

```python
fig, axes = plt.subplots(1, 2)
# ... plot stuff ...

fig.suptitle("Main Title for All Plots", fontsize=16)
plt.tight_layout()
```

## tight_layout() is Your Friend

Always use `plt.tight_layout()` to prevent overlapping:

```python
fig, axes = plt.subplots(2, 2)
# ... create plots ...
plt.tight_layout()  # Fixes spacing automatically
plt.show()
```

## Real World Example: Student Dashboard

```python
import matplotlib.pyplot as plt
import numpy as np

# Data
months = ['Sep', 'Oct', 'Nov', 'Dec']
grades = [85, 88, 82, 91]
study_hours = [10, 12, 8, 15]
attendance = [95, 92, 88, 98]

fig, axes = plt.subplots(2, 2, figsize=(12, 10))

# Grades over time (line)
axes[0, 0].plot(months, grades, 'b-o', linewidth=2, markersize=8)
axes[0, 0].set_ylabel('Grade')
axes[0, 0].set_title('Grade Trend')
axes[0, 0].set_ylim(70, 100)

# Study hours (bar)
axes[0, 1].bar(months, study_hours, color='green', edgecolor='black')
axes[0, 1].set_ylabel('Hours')
axes[0, 1].set_title('Weekly Study Hours')

# Attendance (line with area)
axes[1, 0].fill_between(months, attendance, alpha=0.3, color='purple')
axes[1, 0].plot(months, attendance, 'purple', linewidth=2)
axes[1, 0].set_ylabel('Percentage')
axes[1, 0].set_title('Attendance Rate')
axes[1, 0].set_ylim(80, 100)

# Grade distribution (pie)
grade_dist = [1, 2, 1, 0]  # A, B, C, D counts
axes[1, 1].pie([91, 9], labels=['Pass', 'Need Work'], 
               colors=['#2ecc71', '#e74c3c'], autopct='%1.0f%%')
axes[1, 1].set_title('Overall Status')

fig.suptitle("Student Performance Dashboard", fontsize=16, fontweight='bold')
plt.tight_layout()
plt.show()
```

## Different Plot Types Together

```python
import matplotlib.pyplot as plt
import numpy as np

x = np.linspace(0, 10, 100)

fig, axes = plt.subplots(1, 3, figsize=(15, 4))

# Line plot
axes[0].plot(x, np.sin(x), 'b-', linewidth=2)
axes[0].set_title('Line Plot')

# Scatter plot
axes[1].scatter(np.random.rand(50), np.random.rand(50), c='green', alpha=0.6)
axes[1].set_title('Scatter Plot')

# Bar chart
axes[2].bar(['A', 'B', 'C', 'D'], [25, 40, 30, 35], color='coral')
axes[2].set_title('Bar Chart')

plt.tight_layout()
plt.show()
```

## Uneven Subplot Sizes

Use `GridSpec` for custom layouts:

```python
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec

fig = plt.figure(figsize=(12, 8))
gs = GridSpec(2, 3, figure=fig)

# Large plot on the left (spans 2 rows)
ax1 = fig.add_subplot(gs[:, 0])
ax1.plot([1, 2, 3], [1, 4, 9])
ax1.set_title("Large Plot")

# Two smaller plots on the right
ax2 = fig.add_subplot(gs[0, 1:])
ax2.bar(['A', 'B', 'C'], [3, 5, 4])
ax2.set_title("Top Right")

ax3 = fig.add_subplot(gs[1, 1:])
ax3.scatter([1, 2, 3], [3, 1, 2])
ax3.set_title("Bottom Right")

plt.tight_layout()
plt.show()
```

## Pro Tips

1. **Always use tight_layout()** - Prevents text overlap
2. **Use figsize** - Make it big enough to read
3. **Share axes when comparing** - Same scale = fair comparison
4. **Name your axes** - `ax1, ax2` is clearer than `axes[0], axes[1]`
5. **Add a suptitle** - Give context to the whole figure
6. **Keep it simple** - 4-6 subplots max

## Common Mistakes

1. **Forgetting tight_layout()** - Titles and labels overlap
2. **Too small figsize** - Can't read anything
3. **Too many subplots** - Overwhelming and hard to read
4. **Inconsistent scales** - Use sharey/sharex when comparing
5. **No titles** - Which plot is which?

## Try It Yourself!

Create a dashboard showing:
- Your weekly activities as a pie chart
- Your test scores as a line plot
- Study hours as a bar chart
- Sleep vs. energy as a scatter plot

---

## Summary

- `plt.subplot(rows, cols, index)` for quick subplots
- `fig, axes = plt.subplots(rows, cols)` for more control
- Use `figsize=(width, height)` to set size
- Use `sharex/sharey` for fair comparisons
- Always call `plt.tight_layout()` to fix spacing
- Add `fig.suptitle()` for a main title

**Next up:** Customization - making your plots look amazing!
