# Introduction to Matplotlib

## What is Matplotlib?

Matplotlib is a **Python library for creating charts and graphs**. Think of it like having a digital art kit for data - instead of drawing with pencils, you use code to create beautiful visualizations!

**Why learn Matplotlib?**
- Turn boring numbers into cool visuals
- Make your school projects look professional
- Understand data better (pictures > numbers!)
- It's used by scientists, engineers, and data analysts everywhere

## Two Ways to Plot: pyplot vs Object-Oriented

### Way 1: pyplot (Quick and Easy)

pyplot is like using a TV remote - simple commands that just work.

```python
import matplotlib.pyplot as plt

plt.plot([1, 2, 3, 4], [1, 4, 9, 16])
plt.title("My First Plot!")
plt.show()
```

**What this creates:** A line going up from bottom-left to top-right, showing how numbers square (1, 4, 9, 16).

### Way 2: Object-Oriented (More Control)

This is like building with LEGO - you create each piece and put them together.

```python
import matplotlib.pyplot as plt

fig, ax = plt.subplots()
ax.plot([1, 2, 3, 4], [1, 4, 9, 16])
ax.set_title("My First Plot!")
plt.show()
```

**Same result, different approach!**

## Which Should I Use?

| pyplot | Object-Oriented |
|--------|-----------------|
| Quick one-off plots | Multiple plots together |
| Simple visualizations | Need precise control |
| Learning/experimenting | Professional projects |

**Pro Tip:** Start with pyplot, then level up to object-oriented when you need more power!

## Your First Plot: Step by Step

### Step 1: Import the library

```python
import matplotlib.pyplot as plt
```

We call it `plt` because typing `matplotlib.pyplot` every time is tiring!

### Step 2: Create some data

```python
days = [1, 2, 3, 4, 5]
temperatures = [72, 75, 71, 78, 82]
```

### Step 3: Make the plot

```python
plt.plot(days, temperatures)
```

### Step 4: Add labels (always do this!)

```python
plt.xlabel("Day of the Week")
plt.ylabel("Temperature (F)")
plt.title("Weekly Temperature")
```

### Step 5: Show it!

```python
plt.show()
```

**What you'll see:** A line chart showing temperature rising from about 72°F to 82°F over 5 days.

## Key Terms to Know

| Term | What It Means |
|------|---------------|
| **Figure** | The whole image/window |
| **Axes** | The actual plot area (where data goes) |
| **Plot** | The data visualization itself |
| **xlabel/ylabel** | Labels on the x and y axes |
| **Title** | The name at the top |

## Common Mistakes to Avoid

1. **Forgetting `plt.show()`** - Your plot won't appear!
2. **No labels** - Nobody knows what your graph means
3. **Wrong data order** - x values first, then y values

## Try It Yourself!

Create a plot showing your grades over a semester:
- Months: September, October, November, December
- Grades: 85, 88, 82, 91

**Hint:** Use numbers for months (1, 2, 3, 4) and we'll learn to add text labels later!

---

## Summary

- Matplotlib creates visualizations from data
- Import it as `plt` for convenience
- pyplot is quick; object-oriented gives more control
- Always add labels and titles!
- `plt.show()` displays your plot

**Next up:** Line plots in detail!
