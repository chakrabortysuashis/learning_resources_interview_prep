# Pie Charts in Matplotlib

## What is a Pie Chart?

A pie chart shows **parts of a whole** as slices of a circle. Each slice represents a percentage of the total.

**Best used for:**
- Showing how a total is divided up
- Comparing proportions (not exact values)
- When you have 2-6 categories

**Example questions pie charts answer:**
- "What percentage of students prefer each lunch option?"
- "How is my time divided between activities?"
- "What portion of the budget goes to each category?"

## When NOT to Use Pie Charts

**Avoid pie charts when:**
- You have more than 6-7 categories (too cluttered)
- Values are very similar (hard to compare small differences)
- You need to show exact values (bar charts are better)
- You want to compare across groups

## Basic Pie Chart

```python
import matplotlib.pyplot as plt

activities = ['Sleep', 'School', 'Homework', 'Free Time', 'Meals']
hours = [8, 7, 3, 4, 2]  # Hours per day

plt.pie(hours, labels=activities)
plt.title("How I Spend My Day")
plt.show()
```

**What you see:** A circle divided into 5 slices. Sleep takes up the biggest slice (8 hours), meals the smallest (2 hours).

## Adding Percentages

Show percentage labels on each slice:

```python
plt.pie(hours, labels=activities, autopct='%1.1f%%')
```

- `autopct='%1.1f%%'` = one decimal place (33.3%)
- `autopct='%1.0f%%'` = whole numbers (33%)
- `autopct='%.2f%%'` = two decimals (33.33%)

## Customizing Colors

```python
colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd']
plt.pie(hours, labels=activities, colors=colors)
```

### Recommended Color Palettes

**Professional Blues:**
```python
colors = ['#084c61', '#177e89', '#323031', '#db3a34', '#ffc857']
```

**Bright and Clear:**
```python
colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd']
```

**Pastels (Easy on eyes):**
```python
colors = ['#aec6cf', '#ffb347', '#77dd77', '#ff6961', '#b39eb5']
```

## Exploding Slices

Make one slice "pop out" for emphasis:

```python
explode = [0, 0, 0.1, 0, 0]  # Explode the 3rd slice by 0.1
plt.pie(hours, labels=activities, explode=explode)
```

- `0` = no explosion
- `0.1` = small pop out
- `0.2` = larger pop out

## Adding a Shadow

```python
plt.pie(hours, labels=activities, shadow=True)
```

**Pro Tip:** Shadows can look dated - use sparingly!

## Rotating the Start Angle

By default, pie starts at 3 o'clock and goes counter-clockwise. Change it:

```python
plt.pie(hours, labels=activities, startangle=90)  # Start at 12 o'clock
```

## Making it a Circle (Equal Aspect)

Without this, your pie might look oval:

```python
plt.pie(hours, labels=activities)
plt.axis('equal')  # Ensures perfect circle
```

## Donut Chart

A pie chart with a hole in the middle:

```python
# Create a white circle to overlay
centre_circle = plt.Circle((0,0), 0.7, fc='white')

plt.pie(hours, labels=activities, autopct='%1.0f%%')
plt.gca().add_artist(centre_circle)
plt.title("My Daily Activities")
plt.show()
```

**What you see:** A ring instead of a full circle. Looks more modern!

## Real World Example: Grade Distribution

```python
import matplotlib.pyplot as plt

grades = ['A', 'B', 'C', 'D', 'F']
counts = [8, 15, 10, 4, 3]
colors = ['#2ca02c', '#1f77b4', '#ff7f0e', '#9467bd', '#d62728']
explode = [0.05, 0, 0, 0, 0]  # Highlight A grades

plt.figure(figsize=(10, 8))

plt.pie(counts, labels=grades, colors=colors, explode=explode,
        autopct='%1.0f%%', startangle=90, shadow=False,
        textprops={'fontsize': 14})

plt.title("Class Grade Distribution", fontsize=16)
plt.axis('equal')
plt.show()
```

**What you see:** Most students got B's (38%), with A's highlighted/exploded (20%).

## Real World Example: Budget Breakdown

```python
import matplotlib.pyplot as plt

categories = ['Rent', 'Food', 'Transport', 'Entertainment', 'Savings', 'Other']
amounts = [1200, 400, 200, 150, 300, 150]
colors = ['#ff6b6b', '#4ecdc4', '#45b7d1', '#96ceb4', '#ffeaa7', '#dfe6e9']

plt.figure(figsize=(10, 8))

# Sort by size (optional but looks cleaner)
sorted_data = sorted(zip(amounts, categories, colors), reverse=True)
amounts_sorted = [a for a, c, col in sorted_data]
categories_sorted = [c for a, c, col in sorted_data]
colors_sorted = [col for a, c, col in sorted_data]

plt.pie(amounts_sorted, labels=categories_sorted, colors=colors_sorted,
        autopct=lambda p: f'${int(p*sum(amounts)/100)}', startangle=90,
        textprops={'fontsize': 12})

plt.title("Monthly Budget ($2,400 Total)", fontsize=16)
plt.axis('equal')
plt.show()
```

## Adding a Legend

When labels clutter the chart:

```python
plt.pie(hours, autopct='%1.0f%%')
plt.legend(activities, loc='best')
```

## Complete Professional Example

```python
import matplotlib.pyplot as plt

# Survey: Favorite music genre
genres = ['Pop', 'Hip Hop', 'Rock', 'Country', 'Electronic']
votes = [35, 28, 20, 10, 7]
colors = ['#e74c3c', '#3498db', '#2ecc71', '#f39c12', '#9b59b6']
explode = [0.05, 0, 0, 0, 0]  # Highlight winner

plt.figure(figsize=(10, 8))

wedges, texts, autotexts = plt.pie(votes, labels=genres, colors=colors,
                                    explode=explode, autopct='%1.0f%%',
                                    startangle=90, shadow=False,
                                    textprops={'fontsize': 12},
                                    wedgeprops={'edgecolor': 'white', 
                                               'linewidth': 2})

# Make percentage text bold
for autotext in autotexts:
    autotext.set_fontweight('bold')

plt.title("Favorite Music Genre Survey", fontsize=16, fontweight='bold')
plt.axis('equal')
plt.show()
```

## Pro Tips

1. **Limit to 5-6 slices** - More is confusing
2. **Order slices by size** - Largest to smallest
3. **Use contrasting colors** - Make slices easy to tell apart
4. **Start at 12 o'clock** - `startangle=90`
5. **Add white edges** - `wedgeprops={'edgecolor': 'white'}`
6. **Consider donut charts** - They look more modern
7. **Skip the shadow** - Often looks outdated

## Common Mistakes

1. **Too many slices** - Use "Other" category for small items
2. **Similar colors** - Can't tell slices apart
3. **3D effects** - Hard to read, looks unprofessional
4. **No percentages** - Hard to compare without numbers
5. **Values that don't add to 100%** - Pie charts show parts of a WHOLE

## Pie Chart vs Bar Chart

| Use Pie Chart | Use Bar Chart |
|---------------|---------------|
| Parts of a whole | Comparing values |
| 2-6 categories | Many categories |
| Percentages matter | Exact values matter |
| One time point | Changes over time |

## Try It Yourself!

Create pie charts showing:
- How you spend your allowance
- Your daily screen time by app
- Class votes for a field trip destination
- What's in your backpack by category

---

## Summary

- Pie charts show parts of a whole using `plt.pie()`
- Add percentages with `autopct='%1.0f%%'`
- Customize with `colors`, `explode`, `startangle`
- Use `plt.axis('equal')` for a perfect circle
- Keep it simple: 5-6 slices max, clear colors
- Consider donut charts for a modern look

**Next up:** Subplots - multiple plots in one figure!
