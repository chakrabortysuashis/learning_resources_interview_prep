# Practical Exercises: Real-World Matplotlib Projects

## About These Exercises

Time to put everything together! These exercises use real-world scenarios you might actually encounter. Each exercise builds on what you've learned.

**Difficulty Levels:**
- Easy - Basic plots with simple customization
- Medium - Multiple elements, more styling
- Challenge - Complex visualizations, creativity required

---

## Exercise 1: Weather Week Report (Easy)

**Scenario:** Your local news station needs a weather chart for their website.

**Data:**
```python
days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
high_temps = [72, 75, 68, 70, 74, 79, 82]
low_temps = [58, 60, 55, 54, 58, 62, 65]
```

**Your Task:**
1. Create a line plot with both high and low temperatures
2. Use red for highs, blue for lows
3. Add markers for each data point
4. Add a legend
5. Title: "This Week's Temperature Forecast"
6. Add a grid for easy reading

**Expected Output:** Two lines showing temperature range, clearly labeled, easy to read at a glance.

---

## Exercise 2: Class Grade Distribution (Easy)

**Scenario:** A teacher wants to show how the class did on the midterm exam.

**Data:**
```python
grades = ['A', 'B', 'C', 'D', 'F']
students = [8, 15, 10, 4, 3]
```

**Your Task:**
1. Create a bar chart
2. Color-code: A=green, B=blue, C=yellow, D=orange, F=red
3. Add the number of students above each bar
4. Add percentage labels
5. Title: "Midterm Exam Results"

**Bonus:** Calculate and display the class average.

---

## Exercise 3: Personal Budget Pie Chart (Easy)

**Scenario:** You're tracking your monthly spending.

**Data:**
```python
categories = ['Food', 'Entertainment', 'Transportation', 'Savings', 'Other']
amounts = [300, 150, 100, 200, 50]
```

**Your Task:**
1. Create a pie chart
2. Show percentages on each slice
3. Explode the "Savings" slice (encourage saving!)
4. Use a nice color palette
5. Add a title with the total amount

---

## Exercise 4: Fitness Progress Tracker (Medium)

**Scenario:** Track your workout progress over 4 weeks.

**Data:**
```python
weeks = [1, 2, 3, 4]
pushups = [10, 15, 22, 30]
situps = [20, 28, 35, 45]
squats = [15, 22, 30, 40]
```

**Your Task:**
1. Create a grouped bar chart (3 bars per week)
2. Different color for each exercise
3. Add a legend
4. Add value labels on top of each bar
5. Title: "4-Week Fitness Challenge Progress"
6. Y-axis label: "Repetitions"

**Bonus:** Add a goal line at 25 reps.

---

## Exercise 5: Test Score Histogram (Medium)

**Scenario:** Analyze the distribution of SAT scores.

**Data:**
```python
import numpy as np
np.random.seed(42)
scores = np.random.normal(1050, 150, 200)  # 200 students
```

**Your Task:**
1. Create a histogram with appropriate bins
2. Add a vertical line for the mean score
3. Add a vertical line for the median
4. Color the bars attractively
5. Add labels explaining the lines
6. Title: "SAT Score Distribution (n=200)"

**Bonus:** Shade the region above 1200 (good scores).

---

## Exercise 6: Sports Team Comparison (Medium)

**Scenario:** Compare two basketball teams' performance.

**Data:**
```python
categories = ['Points', 'Rebounds', 'Assists', 'Steals', 'Blocks']
team_a = [95, 45, 22, 8, 5]  # Eagles
team_b = [88, 52, 18, 10, 7]  # Hawks
```

**Your Task:**
1. Create a grouped horizontal bar chart
2. Eagles in blue, Hawks in red
3. Add value labels at the end of each bar
4. Add a legend
5. Title: "Eagles vs Hawks: Season Average Stats"

**Pro Tip:** Horizontal bars work better for this comparison.

---

## Exercise 7: Student Dashboard (Medium)

**Scenario:** Create a dashboard showing a student's performance.

**Data:**
```python
months = ['Sep', 'Oct', 'Nov', 'Dec', 'Jan']
grades = [78, 82, 85, 80, 88]
attendance = [95, 92, 98, 90, 96]
study_hours = [10, 12, 15, 11, 16]
```

**Your Task:**
Create a 2x2 subplot dashboard:
1. **Top-left:** Line plot of grades over time
2. **Top-right:** Bar chart of study hours
3. **Bottom-left:** Line plot of attendance
4. **Bottom:** Pie chart showing time allocation (school, study, sleep, other)

Add a main title: "Student Performance Dashboard"

---

## Exercise 8: Weather Scatter Analysis (Medium)

**Scenario:** Explore the relationship between temperature and ice cream sales.

**Data:**
```python
temperatures = [65, 70, 75, 80, 85, 90, 72, 78, 82, 88, 68, 74, 79, 84, 92]
sales = [100, 150, 200, 300, 400, 500, 175, 250, 350, 450, 120, 180, 275, 375, 550]
humidity = [40, 45, 50, 55, 60, 65, 42, 48, 52, 58, 38, 44, 50, 56, 62]
```

**Your Task:**
1. Create a scatter plot of temperature vs sales
2. Color points by humidity (use a colormap)
3. Add a colorbar
4. Add a trend line
5. Title: "Temperature vs Ice Cream Sales"

**Question:** What does the data suggest?

---

## Exercise 9: Multi-Year Comparison (Challenge)

**Scenario:** Compare sales across 4 years.

**Data:**
```python
quarters = ['Q1', 'Q2', 'Q3', 'Q4']
year_2021 = [150, 180, 200, 220]
year_2022 = [170, 210, 230, 250]
year_2023 = [190, 240, 280, 300]
year_2024 = [220, 260, 310, 340]
```

**Your Task:**
1. Create a stacked area chart OR grouped bar chart
2. Use a cohesive color palette (dark to light shades)
3. Add a legend
4. Add gridlines for readability
5. Title: "Quarterly Sales Growth 2021-2024"
6. Save as PNG and PDF

**Bonus:** Add percentage growth annotations.

---

## Exercise 10: Complete Report Visualization (Challenge)

**Scenario:** You're creating a quarterly report for a company.

**Create a professional dashboard (2x3 or 3x2 grid) including:**

1. **Revenue Trend** (line chart with markers)
   - Monthly revenue for 6 months
   - Add target line at $50K

2. **Expense Breakdown** (pie/donut chart)
   - Categories: Salaries, Marketing, Operations, R&D, Other

3. **Customer Growth** (area chart)
   - New customers each month
   - Show cumulative growth

4. **Product Performance** (horizontal bar chart)
   - 5 products ranked by sales

5. **Customer Satisfaction** (gauge-style or bar)
   - Score out of 5

6. **Regional Sales** (bar chart or pie)
   - Sales by 4 regions

**Requirements:**
- Consistent color scheme throughout
- Professional styling (remove unnecessary spines)
- Clear titles and labels
- Main title for the dashboard
- Save in high resolution (dpi=200)

---

## Tips for All Exercises

### Color Palette Recommendations

```python
# Professional Blue Palette
blues = ['#084c61', '#177e89', '#1f77b4', '#4a98c9', '#7fb8dc']

# Colorblind-Friendly
accessible = ['#0072B2', '#E69F00', '#009E73', '#CC79A7', '#F0E442']

# Traffic Light (Good/Warning/Bad)
traffic = ['#2ecc71', '#f39c12', '#e74c3c']
```

### Styling Checklist

- [ ] Figure size set (`figsize`)
- [ ] Title with fontsize and fontweight
- [ ] Axis labels with units
- [ ] Legend (if multiple data series)
- [ ] Grid (light, alpha=0.3)
- [ ] Spines removed (top, right)
- [ ] tight_layout() called

### Saving Checklist

- [ ] Save BEFORE show()
- [ ] bbox_inches='tight'
- [ ] Appropriate dpi (150-200 for presentations)
- [ ] facecolor='white'

---

## Solutions

Solutions are provided in the accompanying Jupyter notebook. Try the exercises yourself first - you'll learn more by struggling a bit!

**Remember:**
- There's no single "correct" solution
- Creativity is encouraged
- The goal is clear communication, not fancy graphics
- Simple is often better than complex

---

## What's Next?

After completing these exercises, you can:
- Explore more Matplotlib features (3D plots, animations)
- Learn Seaborn for statistical visualizations
- Try Plotly for interactive charts
- Create your own visualizations from real data

**Congratulations on completing the Matplotlib course!**
