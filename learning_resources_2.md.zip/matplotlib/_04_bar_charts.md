# Bar Charts in Matplotlib

## What is a Bar Chart?

A bar chart uses rectangular bars to compare values across categories. The height (or length) of each bar shows the value.

**Best used for:**
- Comparing different categories (sports teams, months, products)
- Showing rankings or totals
- When categories are distinct (not continuous like time)

**Example questions bar charts answer:**
- "Which subject has the most students?"
- "What was our best sales month?"
- "Which team scored the most points?"

## Basic Vertical Bar Chart

```python
import matplotlib.pyplot as plt

subjects = ['Math', 'Science', 'English', 'History']
students = [35, 28, 32, 25]

plt.bar(subjects, students)
plt.xlabel("Subject")
plt.ylabel("Number of Students")
plt.title("Students Per Subject")
plt.show()
```

**What you see:** Four vertical bars - Math is tallest (35 students), History is shortest (25 students).

## Horizontal Bar Chart

Use `barh()` instead of `bar()`:

```python
import matplotlib.pyplot as plt

subjects = ['Math', 'Science', 'English', 'History']
students = [35, 28, 32, 25]

plt.barh(subjects, students)
plt.xlabel("Number of Students")
plt.ylabel("Subject")
plt.title("Students Per Subject")
plt.show()
```

**What you see:** Same data, but bars go left-to-right. Better for long category names!

## When to Use Vertical vs Horizontal

| Vertical Bars | Horizontal Bars |
|--------------|-----------------|
| Short category names | Long category names |
| Fewer categories (3-7) | Many categories (7+) |
| Showing change over time-like periods | Rankings or lists |

## Changing Bar Color

```python
plt.bar(categories, values, color='green')
plt.bar(categories, values, color='#ff7f0e')  # Orange hex code
```

### Recommended Bar Colors

| Purpose | Color | Code |
|---------|-------|------|
| Primary | Blue | `#1f77b4` |
| Secondary | Orange | `#ff7f0e` |
| Positive | Green | `#2ca02c` |
| Negative | Red | `#d62728` |
| Neutral | Gray | `#7f7f7f` |

## Different Color for Each Bar

```python
colors = ['red', 'green', 'blue', 'orange']
plt.bar(categories, values, color=colors)
```

## Bar Width

Control how thick the bars are:

```python
plt.bar(categories, values, width=0.8)   # Default
plt.bar(categories, values, width=0.5)   # Thinner
plt.bar(categories, values, width=1.0)   # Full width (bars touch)
```

## Adding Edge Color

Make bars stand out with borders:

```python
plt.bar(categories, values, color='skyblue', edgecolor='navy', linewidth=2)
```

## Grouped Bar Charts

Compare multiple datasets side by side:

```python
import matplotlib.pyplot as plt
import numpy as np

categories = ['Math', 'Science', 'English']
class_a = [85, 78, 92]
class_b = [80, 88, 85]

x = np.arange(len(categories))  # [0, 1, 2]
width = 0.35

plt.bar(x - width/2, class_a, width, label='Class A', color='#1f77b4')
plt.bar(x + width/2, class_b, width, label='Class B', color='#ff7f0e')

plt.xticks(x, categories)
plt.ylabel('Average Score')
plt.title('Test Scores by Class')
plt.legend()
plt.show()
```

**What you see:** Two bars for each subject - Class A (blue) and Class B (orange) side by side. Easy to compare!

## Stacked Bar Charts

Stack values on top of each other:

```python
import matplotlib.pyplot as plt

categories = ['Q1', 'Q2', 'Q3', 'Q4']
product_a = [20, 25, 30, 35]
product_b = [15, 20, 25, 30]

plt.bar(categories, product_a, label='Product A', color='#1f77b4')
plt.bar(categories, product_b, bottom=product_a, label='Product B', color='#ff7f0e')

plt.xlabel('Quarter')
plt.ylabel('Sales (thousands)')
plt.title('Quarterly Sales by Product')
plt.legend()
plt.show()
```

**What you see:** Orange bars stacked on top of blue bars. Total height shows combined sales.

## Adding Value Labels on Bars

Show exact values above each bar:

```python
import matplotlib.pyplot as plt

categories = ['A', 'B', 'C', 'D']
values = [25, 40, 30, 35]

bars = plt.bar(categories, values, color='steelblue')

# Add value labels
for bar, value in zip(bars, values):
    plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 1,
             str(value), ha='center', fontsize=12)

plt.title('Values Labeled')
plt.show()
```

**What you see:** Numbers floating above each bar showing exact values.

## Real World Example: Sports Scores

```python
import matplotlib.pyplot as plt

teams = ['Eagles', 'Hawks', 'Lions', 'Tigers', 'Bears']
wins = [12, 10, 8, 11, 9]
losses = [4, 6, 8, 5, 7]

# Calculate win percentage for coloring
colors = ['#2ca02c' if w > 10 else '#1f77b4' if w >= 9 else '#ff7f0e' 
          for w in wins]

plt.figure(figsize=(10, 6))
bars = plt.bar(teams, wins, color=colors, edgecolor='black')

# Add value labels
for bar, win in zip(bars, wins):
    plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.3,
             str(win), ha='center', fontsize=14, fontweight='bold')

plt.xlabel('Team')
plt.ylabel('Wins')
plt.title('Season Wins by Team')
plt.show()
```

**What you see:** Each team's wins as bars. Green = great (11+ wins), blue = good (9-10), orange = okay (below 9).

## Real World Example: Survey Results

```python
import matplotlib.pyplot as plt

questions = ['Easy to use?', 'Would recommend?', 'Value for money?', 'Good support?']
yes_percent = [85, 78, 65, 72]

plt.figure(figsize=(10, 6))

# Color based on percentage
colors = ['#2ca02c' if p >= 80 else '#1f77b4' if p >= 70 else '#ff7f0e' 
          for p in yes_percent]

plt.barh(questions, yes_percent, color=colors, edgecolor='black')

# Add percentage labels
for i, (q, p) in enumerate(zip(questions, yes_percent)):
    plt.text(p + 1, i, f'{p}%', va='center', fontsize=12)

plt.xlabel('Percentage')
plt.title('Customer Survey Results')
plt.xlim(0, 100)
plt.show()
```

## Pro Tips

1. **Start y-axis at zero** - Otherwise bars can be misleading
2. **Order bars meaningfully** - By value, alphabetically, or logically
3. **Limit categories** - More than 10 bars gets cluttered
4. **Use horizontal bars** for long labels
5. **Add data labels** when exact values matter
6. **Color consistently** - Same color = same meaning

## Common Mistakes

1. **Not starting at zero** - Makes differences look bigger than they are
2. **Too many bars** - Hard to compare, split into multiple charts
3. **3D bars** - Looks cool but hard to read accurately
4. **Rainbow colors** - Distracting, use one color or meaningful colors
5. **No labels** - What do these bars represent?

## Try It Yourself!

Create a bar chart showing:
- Favorite pizza toppings voted by classmates
- Points scored by players on your team
- Hours spent on different activities this week

---

## Summary

- Bar charts compare categories using rectangular bars
- Use `plt.bar()` for vertical, `plt.barh()` for horizontal
- Group bars with `np.arange()` and width offsets
- Stack bars using the `bottom` parameter
- Add labels with `plt.text()`
- Color meaningfully and always start y-axis at zero!

**Next up:** Histograms - for showing distributions!
