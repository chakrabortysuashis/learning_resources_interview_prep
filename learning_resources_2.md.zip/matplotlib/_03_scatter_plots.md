# Scatter Plots in Matplotlib

## What is a Scatter Plot?

A scatter plot shows individual data points as dots. Unlike line plots, it doesn't connect the dots - it just shows where each point is.

**Best used for:**
- Showing relationships between two things
- Finding patterns or clusters in data
- Spotting outliers (weird data points)
- When data points don't follow a sequence

**Example questions scatter plots answer:**
- "Do taller students weigh more?"
- "Does more study time lead to better grades?"
- "Is there a connection between sleep and mood?"

## Basic Scatter Plot

```python
import matplotlib.pyplot as plt

# Study hours vs test scores
study_hours = [1, 2, 3, 4, 5, 6, 7, 8]
test_scores = [55, 60, 65, 70, 80, 85, 88, 95]

plt.scatter(study_hours, test_scores)
plt.xlabel("Hours Studied")
plt.ylabel("Test Score")
plt.title("Study Time vs Test Performance")
plt.show()
```

**What you see:** Dots going from bottom-left to top-right, showing that more study hours = higher scores. Clear pattern!

## Changing Dot Color

```python
plt.scatter(x, y, color='red')
plt.scatter(x, y, c='blue')        # 'c' is shortcut for color
plt.scatter(x, y, color='#2ca02c') # Hex code
```

### Recommended Scatter Plot Colors

| Use Case | Color | Code |
|----------|-------|------|
| Single dataset | Blue | `#1f77b4` |
| Highlighting | Orange | `#ff7f0e` |
| Positive correlation | Green | `#2ca02c` |
| Negative/warning | Red | `#d62728` |

## Changing Dot Size

```python
plt.scatter(x, y, s=50)   # Default size
plt.scatter(x, y, s=100)  # Bigger dots
plt.scatter(x, y, s=200)  # Even bigger!
```

**Pro Tip:** Use size 50-100 for most plots. Go bigger for presentations.

## Changing Marker Style

```python
plt.scatter(x, y, marker='o')  # Circle (default)
plt.scatter(x, y, marker='s')  # Square
plt.scatter(x, y, marker='^')  # Triangle
plt.scatter(x, y, marker='*')  # Star
plt.scatter(x, y, marker='D')  # Diamond
```

## Adding Transparency

When dots overlap, transparency helps see density:

```python
plt.scatter(x, y, alpha=0.5)  # 50% transparent
```

- `alpha=1.0` = fully solid (default)
- `alpha=0.5` = half transparent
- `alpha=0.1` = very transparent

## Color by Value (Color Mapping)

Make dots different colors based on a third variable!

```python
import matplotlib.pyplot as plt

students = [1, 2, 3, 4, 5, 6, 7, 8]
study_hours = [2, 4, 3, 6, 5, 7, 8, 6]
test_scores = [60, 75, 65, 85, 80, 90, 95, 82]
sleep_hours = [5, 6, 5, 8, 7, 8, 9, 7]  # This determines color!

plt.scatter(study_hours, test_scores, c=sleep_hours, cmap='viridis', s=100)
plt.colorbar(label='Hours of Sleep')
plt.xlabel("Study Hours")
plt.ylabel("Test Score")
plt.title("Study Time, Scores, and Sleep")
plt.show()
```

**What you see:** Dots colored from dark purple (less sleep) to yellow (more sleep). Shows three variables at once!

### Best Colormaps

| Colormap | Use For |
|----------|---------|
| `viridis` | General use (default, colorblind-friendly) |
| `plasma` | Heatmap style |
| `coolwarm` | Positive vs negative values |
| `Blues` | Single-color gradient |
| `RdYlGn` | Bad to good (red-yellow-green) |

## Size by Value

Make dot size represent another variable:

```python
ages = [15, 16, 15, 17, 16, 17, 18, 16]
heights = [62, 65, 60, 68, 64, 70, 72, 66]
weights = [120, 140, 110, 160, 135, 175, 180, 145]

# Size based on weight (multiply to make visible)
plt.scatter(ages, heights, s=[w/2 for w in weights])
```

**What you see:** Bigger dots = heavier students. Shows three dimensions of data!

## Multiple Groups

Show different categories with different colors:

```python
import matplotlib.pyplot as plt

# Boys data
boys_height = [64, 66, 68, 70, 72]
boys_weight = [130, 140, 155, 170, 180]

# Girls data
girls_height = [60, 62, 64, 65, 67]
girls_weight = [105, 115, 125, 130, 140]

plt.scatter(boys_height, boys_weight, color='blue', label='Boys', s=80)
plt.scatter(girls_height, girls_weight, color='red', label='Girls', s=80)

plt.xlabel("Height (inches)")
plt.ylabel("Weight (lbs)")
plt.title("Height vs Weight by Gender")
plt.legend()
plt.show()
```

**What you see:** Two clusters - blue dots (boys) in upper right, red dots (girls) in lower left.

## Real World Example: Sports Stats

```python
import matplotlib.pyplot as plt

# Basketball players
players = ['Player A', 'Player B', 'Player C', 'Player D', 'Player E']
points = [25, 18, 22, 15, 28]
assists = [5, 8, 6, 10, 4]
games_played = [80, 75, 82, 70, 78]

plt.figure(figsize=(10, 6))
scatter = plt.scatter(points, assists, c=games_played, s=200, 
                      cmap='YlOrRd', edgecolor='black')

plt.colorbar(scatter, label='Games Played')
plt.xlabel("Points Per Game")
plt.ylabel("Assists Per Game")
plt.title("NBA Player Stats: Points vs Assists")

# Label each point
for i, player in enumerate(players):
    plt.annotate(player, (points[i]+0.3, assists[i]+0.2))

plt.show()
```

**What you see:** Each player is a dot. Position shows their points vs assists, color shows games played, and labels identify each player.

## Adding a Trend Line

Show the overall pattern:

```python
import matplotlib.pyplot as plt
import numpy as np

x = [1, 2, 3, 4, 5, 6, 7, 8]
y = [2, 4, 5, 4, 5, 7, 8, 9]

# Scatter plot
plt.scatter(x, y, s=100)

# Add trend line
z = np.polyfit(x, y, 1)  # 1 = linear
p = np.poly1d(z)
plt.plot(x, p(x), 'r--', linewidth=2, label='Trend')

plt.legend()
plt.show()
```

## Pro Tips

1. **Use transparency** when you have many points - overlapping dots create darker areas
2. **Add a grid** to help read values: `plt.grid(True, alpha=0.3)`
3. **Don't overcrowd** - too many points = messy plot
4. **Use colorbar** when using color mapping
5. **Label outliers** - interesting points deserve attention

## Common Mistakes

1. **Dots too small** - Can't see the pattern
2. **No transparency with many points** - Just a blob of color
3. **Confusing color schemes** - Stick to standard colormaps
4. **Missing labels** - What do the axes mean?

## When to Use Scatter vs Line Plots

| Use Scatter Plot | Use Line Plot |
|------------------|---------------|
| Comparing two variables | Showing change over time |
| Looking for correlations | Data has a natural sequence |
| Each point is independent | Points should be connected |
| Finding clusters/patterns | Showing trends |

## Try It Yourself!

Create a scatter plot showing:
- Height vs. Shoe Size for your classmates
- Hours of sleep vs. Energy level
- Time spent on homework vs. Grade

---

## Summary

- Scatter plots show relationships between variables
- Use `plt.scatter(x, y)` for basic plots
- Customize with `color`, `s` (size), `marker`, `alpha`
- Color mapping (`c=values, cmap='viridis'`) adds a third dimension
- Size mapping (`s=sizes`) adds a fourth dimension
- Always add labels and consider transparency for many points

**Next up:** Bar charts!
