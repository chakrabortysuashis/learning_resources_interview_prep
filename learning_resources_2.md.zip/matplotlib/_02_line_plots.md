# Line Plots in Matplotlib

## What is a Line Plot?

A line plot connects data points with lines. It's perfect for showing how something **changes over time** - like tracking your grades, temperature, or stock prices.

**Best used for:**
- Data that changes over time (days, months, years)
- Showing trends (going up, down, or staying flat)
- Comparing multiple things over the same time period

## Basic Line Plot

```python
import matplotlib.pyplot as plt

# Test scores over 5 tests
tests = [1, 2, 3, 4, 5]
scores = [75, 82, 78, 91, 88]

plt.plot(tests, scores)
plt.xlabel("Test Number")
plt.ylabel("Score")
plt.title("My Test Scores")
plt.show()
```

**What you see:** A line that starts at 75, jumps to 82, dips to 78, peaks at 91, then settles at 88. You can see the improvement trend!

## Line Colors

Make your plots pop with colors!

```python
plt.plot(x, y, color='red')       # Color name
plt.plot(x, y, color='#FF5733')   # Hex code (like in web design)
plt.plot(x, y, color='b')         # Single letter shortcut
```

### Color Shortcuts

| Letter | Color |
|--------|-------|
| `b` | Blue |
| `g` | Green |
| `r` | Red |
| `c` | Cyan |
| `m` | Magenta |
| `y` | Yellow |
| `k` | Black |
| `w` | White |

### Recommended Colors for Plots

| Purpose | Color | Code |
|---------|-------|------|
| Primary data | Blue | `#1f77b4` |
| Secondary data | Orange | `#ff7f0e` |
| Positive/Good | Green | `#2ca02c` |
| Negative/Bad | Red | `#d62728` |
| Neutral | Gray | `#7f7f7f` |

## Line Styles

```python
plt.plot(x, y, linestyle='-')     # Solid line (default)
plt.plot(x, y, linestyle='--')    # Dashed line
plt.plot(x, y, linestyle='-.')    # Dash-dot line
plt.plot(x, y, linestyle=':')     # Dotted line
```

**Visual Guide:**

```
Solid:    _______________
Dashed:   _ _ _ _ _ _ _ _
Dash-dot: _._._._._._._._
Dotted:   ...............
```

## Line Width

Control how thick your lines are:

```python
plt.plot(x, y, linewidth=1)   # Thin (default)
plt.plot(x, y, linewidth=2)   # Medium
plt.plot(x, y, linewidth=4)   # Thick
```

**Pro Tip:** Use thicker lines (2-3) for presentations, thinner (1) for detailed data.

## Adding Markers

Markers show exactly where your data points are:

```python
plt.plot(x, y, marker='o')    # Circle markers
```

### Common Markers

| Marker | Shape |
|--------|-------|
| `o` | Circle |
| `s` | Square |
| `^` | Triangle up |
| `v` | Triangle down |
| `*` | Star |
| `+` | Plus |
| `x` | X |
| `D` | Diamond |

## The Shortcut Format String

Combine color, marker, and line style in one string!

```python
plt.plot(x, y, 'ro-')   # Red, circle markers, solid line
plt.plot(x, y, 'g^--')  # Green, triangle markers, dashed line
plt.plot(x, y, 'bs:')   # Blue, square markers, dotted line
```

**Format:** `'[color][marker][line]'`

## Multiple Lines on One Plot

Compare different datasets by plotting multiple lines:

```python
import matplotlib.pyplot as plt

months = [1, 2, 3, 4, 5]
student_a = [85, 88, 82, 90, 92]
student_b = [78, 80, 85, 88, 89]

plt.plot(months, student_a, 'b-o', label='Alex')
plt.plot(months, student_b, 'r-s', label='Jordan')

plt.xlabel("Month")
plt.ylabel("Grade")
plt.title("Student Progress Comparison")
plt.legend()  # Shows the labels!
plt.show()
```

**What you see:** Two lines - a blue one with circles (Alex) starting higher but both trending up, and a red one with squares (Jordan) catching up over time.

## Adding a Legend

When you have multiple lines, you NEED a legend:

```python
plt.plot(x, y1, label='Line 1')
plt.plot(x, y2, label='Line 2')
plt.legend()  # Add this line!
```

### Legend Positions

```python
plt.legend(loc='upper right')   # Default
plt.legend(loc='upper left')
plt.legend(loc='lower right')
plt.legend(loc='lower left')
plt.legend(loc='center')
plt.legend(loc='best')          # Matplotlib picks the best spot
```

## Real World Example: Weather Comparison

```python
import matplotlib.pyplot as plt

days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri']
day_nums = [1, 2, 3, 4, 5]

this_week = [72, 75, 68, 70, 74]
last_week = [65, 68, 71, 69, 67]

plt.plot(day_nums, this_week, 'r-o', linewidth=2, label='This Week')
plt.plot(day_nums, last_week, 'b--s', linewidth=2, label='Last Week')

plt.xlabel("Day")
plt.ylabel("Temperature (°F)")
plt.title("Weekly Temperature Comparison")
plt.legend(loc='best')
plt.show()
```

**What you see:** This week (red solid line with circles) is generally warmer than last week (blue dashed line with squares).

## Pro Tips

1. **Use contrasting colors** for multiple lines (blue vs orange, not blue vs dark blue)
2. **Limit to 3-4 lines max** - more gets confusing
3. **Always add a legend** when you have multiple lines
4. **Use markers sparingly** - they can clutter busy plots
5. **Match line width to audience** - thicker for presentations, thinner for reports

## Common Mistakes

1. **Too many lines** - Hard to read, split into multiple plots
2. **Similar colors** - Can't tell lines apart
3. **No legend** - Nobody knows which line is which
4. **Markers too big** - Overwhelm the data

## Try It Yourself!

Plot your daily steps for a week, then add your friend's steps on the same chart. Use different colors and add a legend!

---

## Summary

- Line plots show change over time
- Customize with `color`, `linestyle`, `linewidth`, `marker`
- Use format strings for quick styling: `'ro-'`
- Multiple lines need `label` and `plt.legend()`
- Keep it simple and readable!

**Next up:** Scatter plots!
