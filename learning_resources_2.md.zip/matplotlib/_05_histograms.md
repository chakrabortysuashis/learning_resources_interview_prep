# Histograms in Matplotlib

## What is a Histogram?

A histogram shows how data is **distributed** - it groups values into "bins" and counts how many fall into each bin.

**Think of it like sorting coins:**
- You have 100 pennies of different years
- You sort them into decade buckets (1980s, 1990s, 2000s, etc.)
- The height of each bucket shows how many coins are in that decade

**Best used for:**
- Understanding the "shape" of your data
- Finding the most common values
- Spotting outliers (unusual values)
- Comparing distributions

**Example questions histograms answer:**
- "What's the most common test score?"
- "Are most students getting A's or C's?"
- "Is there a typical height for 10th graders?"

## Bar Chart vs Histogram

| Bar Chart | Histogram |
|-----------|-----------|
| Categories (Math, Science) | Continuous values (0-100 scores) |
| Bars don't touch | Bars touch (continuous) |
| Order doesn't matter | Order matters (low to high) |
| Counts for each category | Counts in ranges (bins) |

## Basic Histogram

```python
import matplotlib.pyplot as plt

# Test scores for 30 students
scores = [72, 85, 78, 92, 88, 76, 95, 82, 79, 88,
          91, 84, 77, 86, 90, 75, 83, 87, 81, 89,
          73, 80, 85, 78, 94, 86, 82, 79, 88, 91]

plt.hist(scores)
plt.xlabel("Score")
plt.ylabel("Number of Students")
plt.title("Test Score Distribution")
plt.show()
```

**What you see:** Bars showing how many students fall into each score range. Most students scored in the 80s!

## Controlling the Number of Bins

Bins = how many groups to divide your data into.

```python
plt.hist(scores, bins=5)   # 5 wide bins
plt.hist(scores, bins=10)  # 10 medium bins (default)
plt.hist(scores, bins=20)  # 20 narrow bins
```

**Rule of thumb:**
- Too few bins = lose detail
- Too many bins = too noisy
- Start with 10-15 bins and adjust

## Specifying Exact Bin Edges

```python
# Bins for letter grades
bin_edges = [60, 70, 80, 90, 100]
plt.hist(scores, bins=bin_edges)
```

This creates bins: 60-70, 70-80, 80-90, 90-100 (letter grades D, C, B, A!)

## Histogram Color and Style

```python
plt.hist(scores, bins=10, 
         color='skyblue',        # Fill color
         edgecolor='black',       # Border color
         linewidth=1.2)           # Border thickness
```

### Recommended Histogram Colors

| Use Case | Color | Code |
|----------|-------|------|
| General | Blue | `#1f77b4` |
| Positive data | Green | `#2ca02c` |
| Highlighting issues | Red | `#d62728` |
| Neutral | Gray | `#7f7f7f` |

## Adding Transparency (Alpha)

When comparing multiple histograms, transparency helps see overlap:

```python
plt.hist(data1, alpha=0.5, label='Group 1')
plt.hist(data2, alpha=0.5, label='Group 2')
plt.legend()
```

## Density vs Count

By default, histograms show **counts** (how many). You can show **density** (proportion) instead:

```python
plt.hist(scores, density=True)  # Area under histogram = 1
```

**When to use density:**
- Comparing datasets of different sizes
- When proportion matters more than count

## Cumulative Histogram

Shows "how many values are less than or equal to X":

```python
plt.hist(scores, cumulative=True)
```

**What you see:** A staircase going up. At score 80, you can read how many students scored 80 or below.

## Multiple Histograms

Compare two groups:

```python
import matplotlib.pyplot as plt

class_a = [75, 82, 88, 79, 91, 85, 78, 92, 84, 87]
class_b = [68, 72, 78, 85, 71, 76, 80, 74, 82, 77]

plt.hist(class_a, bins=10, alpha=0.5, label='Class A', color='blue')
plt.hist(class_b, bins=10, alpha=0.5, label='Class B', color='red')

plt.xlabel("Score")
plt.ylabel("Frequency")
plt.title("Score Distribution: Class A vs Class B")
plt.legend()
plt.show()
```

**What you see:** Overlapping histograms showing Class A (blue) scores higher overall than Class B (red).

## Side-by-Side Histograms

```python
import matplotlib.pyplot as plt

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

ax1.hist(class_a, bins=10, color='blue', edgecolor='black')
ax1.set_title('Class A')
ax1.set_xlabel('Score')

ax2.hist(class_b, bins=10, color='red', edgecolor='black')
ax2.set_title('Class B')
ax2.set_xlabel('Score')

plt.tight_layout()
plt.show()
```

## Real World Example: Height Distribution

```python
import matplotlib.pyplot as plt
import numpy as np

# Heights of 100 10th graders (simulated)
np.random.seed(42)
heights = np.random.normal(66, 4, 100)  # Mean 66 inches, std 4

plt.figure(figsize=(10, 6))
plt.hist(heights, bins=15, color='steelblue', edgecolor='black', alpha=0.7)

# Add a vertical line for the average
plt.axvline(heights.mean(), color='red', linestyle='--', linewidth=2, 
            label=f'Average: {heights.mean():.1f} inches')

plt.xlabel("Height (inches)")
plt.ylabel("Number of Students")
plt.title("Height Distribution of 10th Graders")
plt.legend()
plt.show()
```

**What you see:** A bell-shaped curve centered around 66 inches, with a red dashed line showing the average.

## Adding Statistical Information

```python
import matplotlib.pyplot as plt
import numpy as np

data = [72, 85, 78, 92, 88, 76, 95, 82, 79, 88,
        91, 84, 77, 86, 90, 75, 83, 87, 81, 89]

plt.figure(figsize=(10, 6))
plt.hist(data, bins=10, color='lightgreen', edgecolor='black')

# Add mean and median lines
mean_val = np.mean(data)
median_val = np.median(data)

plt.axvline(mean_val, color='red', linestyle='-', linewidth=2, label=f'Mean: {mean_val:.1f}')
plt.axvline(median_val, color='blue', linestyle='--', linewidth=2, label=f'Median: {median_val:.1f}')

plt.xlabel("Value")
plt.ylabel("Frequency")
plt.title("Distribution with Mean and Median")
plt.legend()
plt.show()
```

## Common Distribution Shapes

| Shape | What it looks like | Example |
|-------|-------------------|---------|
| **Normal (Bell)** | Tall in middle, symmetric | Heights, test scores |
| **Skewed Right** | Tail stretches right | Income, home prices |
| **Skewed Left** | Tail stretches left | Age at retirement |
| **Bimodal** | Two peaks | Mixed populations |
| **Uniform** | Flat, even heights | Dice rolls |

## Pro Tips

1. **Start with ~10 bins** and adjust based on data
2. **Use edgecolor='black'** to see bin boundaries clearly
3. **Add mean/median lines** for context
4. **Use transparency** when overlapping histograms
5. **Match bin edges** when comparing multiple histograms
6. **Label your axes** - what are the units?

## Common Mistakes

1. **Wrong number of bins** - Too few hides patterns, too many adds noise
2. **Forgetting to label** - What does the x-axis represent?
3. **Not matching bins** - When comparing, use same bin edges
4. **Using bar charts instead** - Histograms are for continuous data!

## Try It Yourself!

Create histograms for:
- Daily temperatures for a month
- Page counts of books you've read
- Time spent on homework each day
- Ages of people at a family reunion

---

## Summary

- Histograms show data distribution using bins
- Use `plt.hist(data, bins=n)` for basic histogram
- Adjust `bins`, `color`, `edgecolor`, `alpha`
- Use `density=True` for proportions instead of counts
- Compare groups with transparency or side-by-side plots
- Add mean/median lines for statistical context

**Next up:** Pie charts!
