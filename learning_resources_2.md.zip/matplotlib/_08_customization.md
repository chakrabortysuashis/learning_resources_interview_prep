# Customization in Matplotlib

## Why Customize?

Default plots are functional but boring. Customization makes your plots:
- **Professional** - Look like they belong in a presentation
- **Clear** - Easy to understand at a glance
- **Attractive** - People actually want to look at them
- **Accessible** - Readable by everyone (including colorblind viewers)

## Titles and Labels

### Adding Titles

```python
plt.title("My Awesome Plot")                     # Basic
plt.title("My Awesome Plot", fontsize=16)        # Bigger
plt.title("My Awesome Plot", fontweight='bold')  # Bold
plt.title("My Awesome Plot", color='navy')       # Colored
```

### Axis Labels

```python
plt.xlabel("Time (seconds)")
plt.ylabel("Speed (mph)")

# With formatting
plt.xlabel("Time (seconds)", fontsize=12, fontweight='bold')
plt.ylabel("Speed (mph)", fontsize=12, color='darkblue')
```

## Font Customization

### Font Sizes

```python
plt.title("Title", fontsize=18)
plt.xlabel("X Label", fontsize=14)
plt.ylabel("Y Label", fontsize=14)
plt.xticks(fontsize=12)
plt.yticks(fontsize=12)
```

### Font Weights

- `'normal'` - Regular
- `'bold'` - **Bold**
- `'light'` - Light

### Font Families

```python
plt.title("Title", fontfamily='serif')        # Times-like
plt.title("Title", fontfamily='sans-serif')   # Arial-like
plt.title("Title", fontfamily='monospace')    # Code-like
```

## Colors

### Named Colors

```python
color='red'
color='blue'
color='green'
color='orange'
color='purple'
color='navy'
color='coral'
color='steelblue'
color='forestgreen'
```

### Hex Codes (Web Colors)

```python
color='#1f77b4'   # Matplotlib blue
color='#ff7f0e'   # Orange
color='#2ca02c'   # Green
color='#d62728'   # Red
color='#9467bd'   # Purple
```

### RGB/RGBA Tuples

```python
color=(0.2, 0.4, 0.6)        # RGB (0-1 scale)
color=(0.2, 0.4, 0.6, 0.5)   # RGBA with transparency
```

## Professional Color Palettes

### Colorblind-Friendly Palette

```python
colors = ['#0072B2', '#E69F00', '#009E73', '#CC79A7', '#F0E442', '#56B4E9']
```

### Corporate/Professional

```python
colors = ['#2C3E50', '#E74C3C', '#3498DB', '#1ABC9C', '#F39C12']
```

### Soft/Pastel

```python
colors = ['#A8D5E2', '#F9A826', '#6BCB77', '#FF6B6B', '#C9B1FF']
```

## Legends

### Basic Legend

```python
plt.plot(x, y1, label='Line 1')
plt.plot(x, y2, label='Line 2')
plt.legend()
```

### Legend Position

```python
plt.legend(loc='upper right')    # Default
plt.legend(loc='upper left')
plt.legend(loc='lower right')
plt.legend(loc='lower left')
plt.legend(loc='center')
plt.legend(loc='best')           # Auto-choose best spot
```

### Legend Outside the Plot

```python
plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
```

### Customizing Legend Appearance

```python
plt.legend(
    fontsize=12,
    frameon=True,           # Show box
    fancybox=True,          # Rounded corners
    shadow=True,            # Drop shadow
    facecolor='white',      # Background color
    edgecolor='gray'        # Border color
)
```

## Grid Lines

### Basic Grid

```python
plt.grid(True)
```

### Custom Grid

```python
plt.grid(True, linestyle='--', alpha=0.5, color='gray')
```

### Grid Options

- `linestyle`: `'-'`, `'--'`, `'-.'`, `':'`
- `alpha`: 0.0 (invisible) to 1.0 (solid)
- `color`: Any color
- `linewidth`: Thickness

### Major and Minor Grids

```python
plt.grid(True, which='major', linestyle='-', alpha=0.5)
plt.grid(True, which='minor', linestyle=':', alpha=0.2)
plt.minorticks_on()
```

## Axis Limits and Ticks

### Setting Limits

```python
plt.xlim(0, 100)       # X-axis from 0 to 100
plt.ylim(0, 50)        # Y-axis from 0 to 50
```

### Custom Tick Marks

```python
plt.xticks([0, 25, 50, 75, 100])
plt.yticks([0, 10, 20, 30, 40, 50])
```

### Custom Tick Labels

```python
plt.xticks([1, 2, 3, 4, 5], ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'])
```

### Rotating Tick Labels

```python
plt.xticks(rotation=45)   # Rotate 45 degrees
plt.xticks(rotation=90)   # Vertical
```

## Figure Size and DPI

### Setting Size

```python
plt.figure(figsize=(10, 6))   # Width=10, Height=6 inches
```

### Common Sizes

| Purpose | Size |
|---------|------|
| Standard | `(10, 6)` |
| Wide/Presentation | `(14, 6)` |
| Square | `(8, 8)` |
| Portrait | `(8, 12)` |
| Small | `(6, 4)` |

### DPI (Resolution)

```python
plt.figure(figsize=(10, 6), dpi=100)   # Default
plt.figure(figsize=(10, 6), dpi=150)   # Higher quality
```

## Spines (Plot Borders)

### Remove Top and Right Spines

```python
ax = plt.gca()  # Get current axes
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
```

### Change Spine Color

```python
ax.spines['bottom'].set_color('gray')
ax.spines['left'].set_color('gray')
```

## Background Colors

### Figure Background

```python
plt.figure(facecolor='lightgray')
```

### Axes Background

```python
ax = plt.gca()
ax.set_facecolor('#f0f0f0')
```

## Adding Text and Annotations

### Adding Text

```python
plt.text(x, y, "Some text", fontsize=12)
```

### Annotating Points

```python
plt.annotate('Peak!', 
             xy=(5, 100),           # Point to annotate
             xytext=(6, 110),       # Text position
             arrowprops=dict(arrowstyle='->', color='red'),
             fontsize=12)
```

## Adding Horizontal/Vertical Lines

```python
plt.axhline(y=50, color='red', linestyle='--', label='Target')   # Horizontal
plt.axvline(x=10, color='blue', linestyle=':', label='Start')    # Vertical
```

## Complete Example: Before and After

### Before (Plain)

```python
plt.plot([1,2,3,4,5], [10,15,13,18,20])
plt.show()
```

**What it looks like:** A plain blue line with no context.

### After (Professional)

```python
import matplotlib.pyplot as plt

x = [1, 2, 3, 4, 5]
y = [10, 15, 13, 18, 20]

plt.figure(figsize=(10, 6), facecolor='white')

plt.plot(x, y, 'o-', color='#1f77b4', linewidth=2, markersize=8, label='Sales')

# Customization
plt.title('Monthly Sales Growth', fontsize=16, fontweight='bold', pad=20)
plt.xlabel('Month', fontsize=12)
plt.ylabel('Sales (thousands)', fontsize=12)
plt.xticks([1,2,3,4,5], ['Jan', 'Feb', 'Mar', 'Apr', 'May'], fontsize=11)
plt.yticks(fontsize=11)

# Grid
plt.grid(True, linestyle='--', alpha=0.3)

# Legend
plt.legend(loc='upper left', fontsize=11)

# Remove top and right spines
ax = plt.gca()
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)

# Add target line
plt.axhline(y=15, color='gray', linestyle=':', alpha=0.5, label='Target')

plt.tight_layout()
plt.show()
```

**What it looks like:** A clean, professional chart with clear labels, grid, and styling.

## Pro Tips

1. **Consistency is key** - Use same fonts, colors, styles across plots
2. **Less is more** - Don't over-decorate
3. **Think about your audience** - Presentations need bigger fonts
4. **Use colorblind-friendly palettes** - ~8% of men are colorblind
5. **Always add units** - "Time" vs "Time (seconds)"
6. **Remove clutter** - Hide unnecessary spines and gridlines

## Common Mistakes

1. **Tiny fonts** - Can't read from a distance
2. **Too many colors** - Looks chaotic
3. **No axis labels** - What am I looking at?
4. **Overcrowded** - Too much information
5. **3D effects** - Usually makes plots harder to read

## Quick Reference: Most Used Options

| What | Code |
|------|------|
| Title | `plt.title("Title", fontsize=16)` |
| X Label | `plt.xlabel("Label", fontsize=12)` |
| Y Label | `plt.ylabel("Label", fontsize=12)` |
| Legend | `plt.legend(loc='best')` |
| Grid | `plt.grid(True, alpha=0.3)` |
| Figure Size | `plt.figure(figsize=(10, 6))` |
| Axis Limits | `plt.xlim(0, 10)` |
| Tick Labels | `plt.xticks([1,2,3], ['A','B','C'])` |
| Rotate Labels | `plt.xticks(rotation=45)` |

---

## Summary

- **Titles & Labels**: Always add them with appropriate font sizes
- **Colors**: Use professional palettes, consider accessibility
- **Legends**: Position appropriately, customize appearance
- **Grid**: Light grids help readability
- **Spines**: Remove unnecessary borders for cleaner look
- **Consistency**: Keep styles consistent across your plots

**Next up:** Saving figures to files!
