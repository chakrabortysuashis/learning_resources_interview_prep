# Saving Figures in Matplotlib

## Why Save Figures?

You've created an awesome plot - now you need to:
- Put it in a report or presentation
- Share it on social media
- Print it as a poster
- Include it in a website

Matplotlib can save your plots as image files in many formats!

## Basic Saving: plt.savefig()

```python
import matplotlib.pyplot as plt

plt.plot([1, 2, 3], [1, 4, 9])
plt.title("My Plot")
plt.savefig("my_plot.png")  # Save as PNG
plt.show()
```

**Important:** Call `savefig()` BEFORE `show()`, or you'll save a blank image!

## File Formats

### PNG - Best for Most Uses

```python
plt.savefig("plot.png")
```

- **Pros:** Good quality, supports transparency, small file size
- **Cons:** Quality degrades if you zoom in (raster image)
- **Best for:** Web, presentations, social media

### PDF - Best for Documents

```python
plt.savefig("plot.pdf")
```

- **Pros:** Perfect quality at any zoom, editable in vector software
- **Cons:** Larger file size, not all apps support it
- **Best for:** Reports, publications, printing

### SVG - Best for Web (Vector)

```python
plt.savefig("plot.svg")
```

- **Pros:** Perfect quality at any size, editable, small file
- **Cons:** Not supported everywhere
- **Best for:** Web pages, logos, graphics that need to scale

### JPEG - Compressed, but Not for Charts

```python
plt.savefig("plot.jpg")
```

- **Pros:** Very small file size
- **Cons:** Lossy compression (text looks blurry), no transparency
- **Best for:** Photos, NOT charts (avoid for data visualization)

## Format Comparison

| Format | Quality | Size | Transparency | Best For |
|--------|---------|------|--------------|----------|
| PNG | High | Medium | Yes | General use |
| PDF | Perfect | Large | Yes | Documents |
| SVG | Perfect | Small | Yes | Web |
| JPEG | Medium | Small | No | Avoid for charts |

## DPI (Dots Per Inch)

DPI controls the resolution - higher DPI = sharper image:

```python
plt.savefig("plot.png", dpi=100)   # Default, good for screen
plt.savefig("plot.png", dpi=150)   # Better quality
plt.savefig("plot.png", dpi=300)   # Print quality
plt.savefig("plot.png", dpi=600)   # High-res printing
```

### DPI Guidelines

| Use Case | DPI |
|----------|-----|
| Screen/web | 100-150 |
| Presentations | 150-200 |
| Printing | 300 |
| Professional printing | 600 |

**Pro Tip:** Higher DPI = larger file size. Use only what you need!

## Removing White Space

By default, Matplotlib leaves margins. Remove them:

```python
plt.savefig("plot.png", bbox_inches='tight')
```

### Adjusting Padding

Add or remove padding around the plot:

```python
plt.savefig("plot.png", bbox_inches='tight', pad_inches=0.1)   # Small margin
plt.savefig("plot.png", bbox_inches='tight', pad_inches=0)     # No margin
```

## Transparent Background

Great for presentations or web pages with colored backgrounds:

```python
plt.savefig("plot.png", transparent=True)
```

**Note:** Only works with PNG and SVG formats (not JPEG).

## Setting Figure Background Color

```python
plt.figure(facecolor='white')
# ... create plot ...
plt.savefig("plot.png", facecolor='white')
```

### Common Background Options

```python
facecolor='white'      # White (default for saving)
facecolor='#f0f0f0'    # Light gray
facecolor='none'       # Transparent (use with transparent=True)
```

## Specifying Full Path

Save to a specific folder:

```python
# Windows
plt.savefig("C:/Users/YourName/Documents/plots/my_chart.png")

# Or use raw string
plt.savefig(r"C:\Users\YourName\Documents\plots\my_chart.png")
```

## Complete Example

```python
import matplotlib.pyplot as plt

# Create the plot
plt.figure(figsize=(10, 6), facecolor='white')

x = [1, 2, 3, 4, 5]
y = [10, 25, 20, 35, 30]

plt.plot(x, y, 'b-o', linewidth=2, markersize=8)
plt.title("Sales Trend", fontsize=16, fontweight='bold')
plt.xlabel("Month", fontsize=12)
plt.ylabel("Sales ($K)", fontsize=12)
plt.grid(True, alpha=0.3)

# Save in multiple formats
plt.savefig("sales_chart.png", dpi=150, bbox_inches='tight', facecolor='white')
plt.savefig("sales_chart.pdf", bbox_inches='tight')
plt.savefig("sales_chart.svg", bbox_inches='tight')

plt.show()

print("Charts saved!")
```

## Saving Subplots

Works the same way - saves the entire figure:

```python
fig, axes = plt.subplots(1, 2, figsize=(12, 5))

axes[0].plot([1, 2, 3], [1, 4, 9])
axes[0].set_title("Plot 1")

axes[1].bar(['A', 'B', 'C'], [3, 5, 4])
axes[1].set_title("Plot 2")

plt.tight_layout()

# Save the entire figure with both subplots
plt.savefig("both_plots.png", dpi=150, bbox_inches='tight')
plt.show()
```

## Using the Object-Oriented Approach

```python
fig, ax = plt.subplots(figsize=(10, 6))

ax.plot([1, 2, 3, 4], [1, 4, 9, 16])
ax.set_title("Squares")

# Save using the figure object
fig.savefig("squares.png", dpi=150, bbox_inches='tight')

plt.show()
```

## Common Issues and Fixes

### 1. Blank Image Saved

**Problem:** Called `show()` before `savefig()`

```python
# WRONG
plt.show()
plt.savefig("plot.png")  # Saves blank!

# CORRECT
plt.savefig("plot.png")
plt.show()
```

### 2. Labels Cut Off

**Problem:** Labels extend beyond the figure bounds

```python
# FIX: Use bbox_inches='tight'
plt.savefig("plot.png", bbox_inches='tight')
```

### 3. Black Background in PNG

**Problem:** Default background might be transparent

```python
# FIX: Specify white background
plt.savefig("plot.png", facecolor='white')
```

### 4. Blurry Text

**Problem:** DPI too low

```python
# FIX: Increase DPI
plt.savefig("plot.png", dpi=200)
```

## Quick Reference

```python
# Basic save
plt.savefig("plot.png")

# High quality for printing
plt.savefig("plot.png", dpi=300, bbox_inches='tight')

# For presentations
plt.savefig("plot.png", dpi=150, bbox_inches='tight', facecolor='white')

# For web (transparent)
plt.savefig("plot.png", transparent=True, bbox_inches='tight')

# For documents
plt.savefig("plot.pdf", bbox_inches='tight')

# Multiple formats at once
for fmt in ['png', 'pdf', 'svg']:
    plt.savefig(f"plot.{fmt}", bbox_inches='tight')
```

## Pro Tips

1. **Always use bbox_inches='tight'** - Prevents cut-off labels
2. **Use PNG for general use** - Best balance of quality and size
3. **Use PDF/SVG for documents** - Perfect quality at any size
4. **Match DPI to purpose** - Don't use 300 DPI for web images
5. **Set facecolor for consistency** - Especially when transparent=False
6. **Create a folder for outputs** - Keep your figures organized

## File Size Comparison

For a typical chart (10x6 inches):

| Format | DPI 100 | DPI 150 | DPI 300 |
|--------|---------|---------|---------|
| PNG | ~50 KB | ~100 KB | ~350 KB |
| PDF | ~30 KB | ~30 KB | ~30 KB |
| SVG | ~20 KB | ~20 KB | ~20 KB |

**Note:** PDF and SVG are vector formats, so DPI doesn't affect them much.

---

## Summary

- Use `plt.savefig("filename.format")` to save
- PNG for general use, PDF for documents, SVG for web
- Adjust quality with `dpi` parameter
- Use `bbox_inches='tight'` to avoid cut-off labels
- Use `transparent=True` for transparent backgrounds
- Always save BEFORE calling `show()`

**Next up:** Practical exercises to put it all together!
